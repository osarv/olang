; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, { i64, [3 x i64] }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr } }
%"compiler/ast:If" = type { ptr, ptr, ptr }
%"compiler/ast:Branch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, { i64, [2 x i64] }, i32, i1 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1 }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32 }
%"compiler/check:frame" = type { i64, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/generic:Context", i32, i32, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i32, i64, i64, i64, i1, i64, i1, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, i64, i64, i64, i1, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64 }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [2 x i64] } }
%"compiler/typed:Capture" = type { i32, ptr }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/names:Ref" = type { i32, i64, i64 }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/check:litv" = type { i1, i1, i1, i64, double, i1 }
%"compiler/ast:Chain" = type { { i64, ptr }, { i64, ptr } }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/ast:Catch" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1 }
%"compiler/ast:TopIf" = type { ptr, ptr, ptr, ptr }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/check:Gap" = type { i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/ast:Match" = type { %"compiler/source:Span", ptr, i1, { i64, ptr }, ptr }
%"compiler/ast:Case" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, ptr }
%"compiler/generic:Binding" = type { i64, i64, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/check:narrowed" = type { i64, i64, i32, i64, i64 }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr }
%"compiler/ast:TypeParam" = type { %"compiler/source:Span", i32, ptr, { i64, ptr } }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/check:atRec" = type { i64, i64, ptr, i32 }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr } }
%"compiler/generic:AnySlot" = type { i32, i32, i64, i64, i1, i32 }
%"compiler/typed:If" = type { ptr, ptr, ptr }
@G_2ecompiler_2fcheck_2eCtEns = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eCtEntry = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eCtReq = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes = constant <{ [8 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [16 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k1, [24 x i8] c"\01\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k2, [24 x i8] c"\01\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k3, [24 x i8] c"\01\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k4, [24 x i8] c"\01\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k5, [24 x i8] c"\01\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k6, [24 x i8] c"\01\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k7, [24 x i8] c"\00\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k8, [24 x i8] c"\01\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k9, [24 x i8] c"\01\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k10, [24 x i8] c"\02\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k11, [24 x i8] c"\02\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k12, [24 x i8] c"\01\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k13, [24 x i8] c"\01\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k14, [24 x i8] c"\01\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\09\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k15, [24 x i8] c"\01\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\0A\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k16, [24 x i8] c"\01\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k17, [24 x i8] c"\00\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k18, [24 x i8] c"\00\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k19, [24 x i8] c"\00\00\00\00\00\00\00\00\01\01\00\00\00\00\00\00\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k20, [24 x i8] c"\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k21, [24 x i8] c"\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eOpShapes.k22, [16 x i8] c"\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00" }>, align 64
@G_2ecompiler_2fcheck_2eOpShapes.k1 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\50\6C\75\73" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k2 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\4D\69\6E\75\73" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k3 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\4D\75\6C" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k4 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\44\69\76" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k5 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\52\65\6D" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k6 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\4D\61\74\4D\75\6C" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k7 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\4E\65\67" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k8 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\4C\65\73\73" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k9 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\41\74" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k10 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\53\65\74\41\74" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k11 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\53\6C\69\63\65" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k12 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\42\69\74\41\6E\64" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k13 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\42\69\74\4F\72" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k14 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\42\69\74\58\6F\72" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k15 = internal constant <{ [9 x i8] }> <{ [9 x i8] c"\53\68\69\66\74\4C\65\66\74" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k16 = internal constant <{ [10 x i8] }> <{ [10 x i8] c"\53\68\69\66\74\52\69\67\68\74" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k17 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\42\69\74\4E\6F\74" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k18 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\49\6E\63" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k19 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\44\65\63" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k20 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\4C\65\6E" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k21 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\45\71" }>, align 8
@G_2ecompiler_2fcheck_2eOpShapes.k22 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\53\74\72" }>, align 8
@G_2ecompiler_2fcheck_2eRoDecl = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eRoGlobal = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eRoReturned = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eRoStored = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eliteralOrder = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eliteralOrder.k1, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eliteralOrder.k2, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eliteralOrder.k3, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eliteralOrder.k4, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eliteralOrder.k5, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eliteralOrder.k6, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eliteralOrder.k7, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eliteralOrder.k8, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eliteralOrder.k9, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eliteralOrder.k10, [8 x i8] c"\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eliteralOrder.k11, [8 x i8] c"\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fcheck_2eliteralOrder.k12 }>, align 64
@G_2ecompiler_2fcheck_2eliteralOrder.k1 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\46\36\34" }>, align 8
@G_2ecompiler_2fcheck_2eliteralOrder.k2 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\49\36\34" }>, align 8
@G_2ecompiler_2fcheck_2eliteralOrder.k3 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\55\36\34" }>, align 8
@G_2ecompiler_2fcheck_2eliteralOrder.k4 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\46\33\32" }>, align 8
@G_2ecompiler_2fcheck_2eliteralOrder.k5 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\49\33\32" }>, align 8
@G_2ecompiler_2fcheck_2eliteralOrder.k6 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\55\33\32" }>, align 8
@G_2ecompiler_2fcheck_2eliteralOrder.k7 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\46\31\36" }>, align 8
@G_2ecompiler_2fcheck_2eliteralOrder.k8 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\42\46\31\36" }>, align 8
@G_2ecompiler_2fcheck_2eliteralOrder.k9 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\49\31\36" }>, align 8
@G_2ecompiler_2fcheck_2eliteralOrder.k10 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\55\31\36" }>, align 8
@G_2ecompiler_2fcheck_2eliteralOrder.k11 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\49\38" }>, align 8
@G_2ecompiler_2fcheck_2eliteralOrder.k12 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\55\38" }>, align 8
define dso_local void @compiler_2fcheck_2eRoDecl_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 1, ptr @G_2ecompiler_2fcheck_2eRoDecl, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ebadSeparator(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l12 = alloca i64
  %l15 = alloca i64
  %l33 = alloca { i64, ptr }
  %l39 = alloca i1
  %l46 = alloca { i64, ptr }
  %l50 = alloca i1
  %l52 = alloca i1
  %l53 = alloca { i64, ptr }
  %l57 = alloca i1
  %l60 = alloca { i64, ptr }
  %l64 = alloca i1
  %l66 = alloca i1
  %l67 = alloca { i64, ptr }
  %l71 = alloca i1
  %l76 = alloca i1
  %l77 = alloca { i64, ptr }
  %l82 = alloca i1
  %l83 = alloca { i64, ptr }
  %l88 = alloca i1
  %l91 = alloca i1
  %l92 = alloca { i64, ptr }
  %l97 = alloca i1
  %l98 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load i64, ptr %l1, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l3, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l12, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l2, !tbaa !24
  %t16 = load i64, ptr %l1, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l3, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l3, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l15, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l15, !tbaa !24
  store i64 %t31, ptr %l12, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l12, !tbaa !24
  store i64 %t32, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load i64, ptr %l5, !tbaa !24
  %t34 = load i64, ptr %l4, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb55
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l1, !tbaa !24
  %t42 = load i64, ptr %l5, !tbaa !24
  %t43 = load i64, ptr %l3, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l6, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t51, ptr %l33, !tbaa !27
  %t52 = load i64, ptr %l6, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i8, ptr %t55, i64 %t52
  %t57 = load i8, ptr %t56, !tbaa !32
  %t59 = icmp ne i8 %t57, 95
  br i1 %t59, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb54
bb12:
  br label %bb13
bb13:
  %t61 = load i64, ptr %l6, !tbaa !24
  %t63 = icmp eq i64 %t61, 0
  br i1 %t63, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb16
bb15:
  %t65 = load i64, ptr %l6, !tbaa !24
  %t67 = add i64 %t65, 1
  %t68 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t68, 0
  %t73 = icmp sge i64 %t67, %t70
  store i1 %t73, ptr %l39, !tbaa !21
  br label %bb16
bb16:
  %t75 = load i1, ptr %l39, !tbaa !21
  br i1 %t75, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t77 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t77, ptr %l46, !tbaa !27
  %t78 = load i64, ptr %l6, !tbaa !24
  %t80 = sub i64 %t78, 1
  %t82 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr i8, ptr %t83, i64 %t80
  %t85 = load i8, ptr %t84, !tbaa !32
  %t87 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t85)
  store i1 %t87, ptr %l50
  br label %bb20
bb20:
  %t88 = load i1, ptr %l50, !tbaa !21
  %t89 = xor i1 %t88, true
  br i1 %t89, label %bb21, label %bb22
bb21:
  %t91 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t91, ptr %l53, !tbaa !27
  %t92 = load i64, ptr %l6, !tbaa !24
  %t94 = sub i64 %t92, 1
  %t96 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr i8, ptr %t97, i64 %t94
  %t99 = load i8, ptr %t98, !tbaa !32
  %t101 = call i1 @compiler_2fcheck_2eisHexDigit(i8 %t99)
  store i1 %t101, ptr %l57
  br label %bb23
bb22:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb24
bb23:
  %t102 = load i1, ptr %l57, !tbaa !21
  %t103 = xor i1 %t102, true
  store i1 %t103, ptr %l52, !tbaa !21
  br label %bb24
bb24:
  %t105 = load i1, ptr %l52, !tbaa !21
  br i1 %t105, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t107 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t107, ptr %l60, !tbaa !27
  %t108 = load i64, ptr %l6, !tbaa !24
  %t110 = add i64 %t108, 1
  %t112 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr i8, ptr %t113, i64 %t110
  %t115 = load i8, ptr %t114, !tbaa !32
  %t117 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t115)
  store i1 %t117, ptr %l64
  br label %bb28
bb28:
  %t118 = load i1, ptr %l64, !tbaa !21
  %t119 = xor i1 %t118, true
  br i1 %t119, label %bb29, label %bb30
bb29:
  %t121 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t121, ptr %l67, !tbaa !27
  %t122 = load i64, ptr %l6, !tbaa !24
  %t124 = add i64 %t122, 1
  %t126 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr i8, ptr %t127, i64 %t124
  %t129 = load i8, ptr %t128, !tbaa !32
  %t131 = call i1 @compiler_2fcheck_2eisHexDigit(i8 %t129)
  store i1 %t131, ptr %l71
  br label %bb31
bb30:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb32
bb31:
  %t132 = load i1, ptr %l71, !tbaa !21
  %t133 = xor i1 %t132, true
  store i1 %t133, ptr %l66, !tbaa !21
  br label %bb32
bb32:
  %t135 = load i1, ptr %l66, !tbaa !21
  br i1 %t135, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t137 = load i64, ptr %l6, !tbaa !24
  %t139 = icmp sge i64 %t137, 2
  br i1 %t139, label %bb36, label %bb37
bb36:
  %t141 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t141, ptr %l77, !tbaa !27
  %t142 = load i64, ptr %l6, !tbaa !24
  %t144 = sub i64 %t142, 1
  %t146 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr i8, ptr %t147, i64 %t144
  %t149 = load i8, ptr %t148, !tbaa !32
  %t151 = icmp eq i8 %t149, 120
  store i1 %t151, ptr %l76, !tbaa !21
  br label %bb38
bb37:
  store i1 false, ptr %l76, !tbaa !21
  br label %bb38
bb38:
  %t153 = load i1, ptr %l76, !tbaa !21
  br i1 %t153, label %bb39, label %bb40
bb39:
  %t154 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t154, ptr %l83, !tbaa !27
  %t155 = load i64, ptr %l6, !tbaa !24
  %t157 = sub i64 %t155, 2
  %t159 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = getelementptr i8, ptr %t160, i64 %t157
  %t162 = load i8, ptr %t161, !tbaa !32
  %t164 = icmp eq i8 %t162, 48
  store i1 %t164, ptr %l82, !tbaa !21
  br label %bb41
bb40:
  store i1 false, ptr %l82, !tbaa !21
  br label %bb41
bb41:
  %t166 = load i1, ptr %l82, !tbaa !21
  br i1 %t166, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l88, !tbaa !21
  br label %bb50
bb43:
  %t167 = load i64, ptr %l6, !tbaa !24
  %t169 = icmp sge i64 %t167, 2
  br i1 %t169, label %bb44, label %bb45
bb44:
  %t171 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t171, ptr %l92, !tbaa !27
  %t172 = load i64, ptr %l6, !tbaa !24
  %t174 = sub i64 %t172, 1
  %t176 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr i8, ptr %t177, i64 %t174
  %t179 = load i8, ptr %t178, !tbaa !32
  %t181 = icmp eq i8 %t179, 98
  store i1 %t181, ptr %l91, !tbaa !21
  br label %bb46
bb45:
  store i1 false, ptr %l91, !tbaa !21
  br label %bb46
bb46:
  %t183 = load i1, ptr %l91, !tbaa !21
  br i1 %t183, label %bb47, label %bb48
bb47:
  %t184 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t184, ptr %l98, !tbaa !27
  %t185 = load i64, ptr %l6, !tbaa !24
  %t187 = sub i64 %t185, 2
  %t189 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !27
  %t191 = getelementptr i8, ptr %t190, i64 %t187
  %t192 = load i8, ptr %t191, !tbaa !32
  %t194 = icmp eq i8 %t192, 48
  store i1 %t194, ptr %l97, !tbaa !21
  br label %bb49
bb48:
  store i1 false, ptr %l97, !tbaa !21
  br label %bb49
bb49:
  %t196 = load i1, ptr %l97, !tbaa !21
  store i1 %t196, ptr %l88, !tbaa !21
  br label %bb50
bb50:
  %t197 = load i1, ptr %l88, !tbaa !21
  br i1 %t197, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb52:
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s2)
  br label %bb54
bb54:
  %t199 = load i64, ptr %l5, !tbaa !24
  %t201 = add i64 %t199, 1
  store i64 %t201, ptr %l5, !tbaa !24
  br label %bb7
bb55:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ebitOp(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %l18 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 12, ptr @.d0 })
  store i1 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i1, ptr %l3, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb5
bb4:
  store i32 30, ptr %l1
  br label %bb35
bb5:
  %t6 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t6, { i64, ptr } { i64 13, ptr @.d1 })
  store i1 %t8, ptr %l6
  br label %bb6
bb6:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i32 31, ptr %l1
  br label %bb35
bb10:
  %t11 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t13 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t11, { i64, ptr } { i64 8, ptr @.d2 })
  store i1 %t13, ptr %l9
  br label %bb11
bb11:
  %t14 = load i1, ptr %l9, !tbaa !21
  br i1 %t14, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i32 32, ptr %l1
  br label %bb35
bb15:
  %t16 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t18 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t16, { i64, ptr } { i64 10, ptr @.d3 })
  store i1 %t18, ptr %l12
  br label %bb16
bb16:
  %t19 = load i1, ptr %l12, !tbaa !21
  br i1 %t19, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i32 33, ptr %l1
  br label %bb35
bb20:
  %t21 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t23 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t21, { i64, ptr } { i64 11, ptr @.d4 })
  store i1 %t23, ptr %l15
  br label %bb21
bb21:
  %t24 = load i1, ptr %l15, !tbaa !21
  br i1 %t24, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  store i32 34, ptr %l1
  br label %bb35
bb25:
  %t26 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t28 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t26, { i64, ptr } { i64 8, ptr @.d5 })
  store i1 %t28, ptr %l18
  br label %bb26
bb26:
  %t29 = load i1, ptr %l18, !tbaa !21
  br i1 %t29, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  store i32 35, ptr %l1
  br label %bb35
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  store i32 29, ptr %l1
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_a3fc486149a2dc5d_17491af4361141b9)
  unreachable
bb35:
  call void @__olang_scope_close(ptr %s0)
  %t32 = load i32, ptr %l1
  store i32 %t32, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fcheck_2ecommutative(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0
  %t3 = trunc i64 48 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l0
  %t8 = trunc i64 50 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l3, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  %t12 = load i32, ptr %l0
  %t14 = trunc i64 80 to i32
  %t15 = icmp eq i32 %t12, %t14
  store i1 %t15, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l6, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb9
bb8:
  %t18 = load i32, ptr %l0
  %t20 = trunc i64 81 to i32
  %t21 = icmp eq i32 %t18, %t20
  store i1 %t21, ptr %l9, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l9, !tbaa !21
  br i1 %t23, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb12
bb11:
  %t24 = load i32, ptr %l0
  %t26 = trunc i64 82 to i32
  %t27 = icmp eq i32 %t24, %t26
  store i1 %t27, ptr %l12, !tbaa !21
  br label %bb12
bb12:
  %t29 = load i1, ptr %l12, !tbaa !21
  store i1 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eBodyOfInstance(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 16
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t3, i64 %a1)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l7
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11
ok.11:
  store i64 %t8, ptr %l6
  br label %bb1
bb1:
  %t12 = load i64, ptr %l6, !tbaa !24
  store i64 %t12, ptr %l2, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l2, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l2, !tbaa !24
  store i64 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eRunning(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l17 = alloca i1
  %l18 = alloca ptr
  %l26 = alloca i1
  %l27 = alloca ptr
  %l40 = alloca ptr
  %l41 = alloca i1
  %l49 = alloca i1
  %l58 = alloca i1
  %l59 = alloca ptr
  %l67 = alloca i1
  %l68 = alloca ptr
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 4
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l2, !tbaa !29
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = getelementptr %"compiler/ast:If", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = icmp eq ptr %t15, null
  br i1 %t17, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_1b45850c01c63cc9_5ae567fd22704b05)
  unreachable
bb2:
  br label %bb3
bb3:
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr %"compiler/ast:If", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t25 = getelementptr %"compiler/ast:Branch", ptr %t22, i32 0, i32 2
  %t26 = load i64, ptr %t25, !tbaa !24
  %t28 = icmp sge i64 %t26, 0
  br i1 %t28, label %bb4, label %bb5
bb4:
  %t30 = load ptr, ptr %l2, !tbaa !29
  store ptr %t30, ptr %l18, !tbaa !29
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr %"compiler/ast:If", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = icmp eq ptr %t34, null
  br i1 %t36, label %bb6, label %bb7
bb5:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb10
bb6:
  call void @__olang_check_failed(ptr @olang_loc_1b45850c01c63cc9_5ae567fd22704b05)
  unreachable
bb7:
  br label %bb8
bb8:
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr %"compiler/ast:If", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t44 = getelementptr %"compiler/ast:Branch", ptr %t41, i32 0, i32 2
  %t45 = load i64, ptr %t44, !tbaa !24
  %t46 = load ptr, ptr %l18, !tbaa !29
  %t48 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eIsPending(ptr %v0, ptr %t46, i64 %t45)
  store i1 %t48, ptr %l26
  br label %bb9
bb9:
  %t49 = load i1, ptr %l26, !tbaa !21
  store i1 %t49, ptr %l17, !tbaa !21
  br label %bb10
bb10:
  %t50 = load i1, ptr %l17, !tbaa !21
  br i1 %t50, label %bb11, label %bb12
bb11:
  %t51 = load ptr, ptr %l2, !tbaa !29
  store ptr %t51, ptr %l27, !tbaa !29
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = getelementptr %"compiler/ast:If", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = icmp eq ptr %t55, null
  br i1 %t57, label %bb13, label %bb14
bb12:
  br label %bb17
bb13:
  call void @__olang_check_failed(ptr @olang_loc_1b45850c01c63cc9_5ae567fd22704b05)
  unreachable
bb14:
  br label %bb15
bb15:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr %"compiler/ast:If", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t65 = getelementptr %"compiler/ast:Branch", ptr %t62, i32 0, i32 2
  %t66 = load i64, ptr %t65, !tbaa !24
  %t67 = load ptr, ptr %l27, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eChoose(ptr %v0, ptr %t67, i64 %t66)
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t71 = getelementptr %"compiler/ast:If", ptr %t69, i32 0, i32 2
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = icmp eq ptr %t72, null
  br i1 %t74, label %bb18, label %bb19
bb18:
  br label %ret
bb19:
  br label %bb20
bb20:
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr %"compiler/ast:If", ptr %t76, i32 0, i32 2
  %t79 = load ptr, ptr %t78, !tbaa !29
  store ptr %t79, ptr %l3, !tbaa !29
  %t81 = load ptr, ptr %l3, !tbaa !29
  store ptr %t81, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t82 = load ptr, ptr %l40, !tbaa !29
  %t83 = icmp ne ptr %t82, null
  br i1 %t83, label %bb21, label %bb22
bb21:
  %t85 = load ptr, ptr %l40, !tbaa !29
  %t86 = load i64, ptr %t85
  %t88 = icmp eq i64 %t86, 5
  store i1 %t88, ptr %l41, !tbaa !21
  br label %bb22
bb22:
  %t89 = load i1, ptr %l41, !tbaa !21
  br i1 %t89, label %bb23, label %bb24
bb23:
  %t90 = load ptr, ptr %l3, !tbaa !29
  %t92 = getelementptr { i64, [4 x i64] }, ptr %t90, i32 0, i32 1
  %t93 = getelementptr { %"compiler/source:Span", ptr }, ptr %t92, i32 0, i32 1
  %t94 = load ptr, ptr %t93
  store ptr %t94, ptr %l4, !tbaa !29
  br label %bb25
bb24:
  br label %bb46
bb25:
  %t96 = load ptr, ptr %l4, !tbaa !29
  %t98 = getelementptr %"compiler/ast:If", ptr %t96, i32 0, i32 0
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = icmp eq ptr %t99, null
  br i1 %t101, label %bb26, label %bb27
bb26:
  %t103 = load ptr, ptr %l4, !tbaa !29
  %t105 = getelementptr %"compiler/ast:If", ptr %t103, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = icmp eq ptr %t106, null
  br i1 %t108, label %bb28, label %bb29
bb27:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb31
bb28:
  call void @__olang_check_failed(ptr @olang_loc_fd7ab254095cc62_437ccc419ec0735e)
  unreachable
bb29:
  br label %bb30
bb30:
  %t110 = load ptr, ptr %l4, !tbaa !29
  %t112 = getelementptr %"compiler/ast:If", ptr %t110, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t116 = getelementptr %"compiler/ast:Branch", ptr %t113, i32 0, i32 2
  %t117 = load i64, ptr %t116, !tbaa !24
  %t119 = icmp sge i64 %t117, 0
  store i1 %t119, ptr %l49, !tbaa !21
  br label %bb31
bb31:
  %t121 = load i1, ptr %l49, !tbaa !21
  br i1 %t121, label %bb32, label %bb33
bb32:
  %t122 = load ptr, ptr %l2, !tbaa !29
  store ptr %t122, ptr %l59, !tbaa !29
  %t123 = load ptr, ptr %l4, !tbaa !29
  %t125 = getelementptr %"compiler/ast:If", ptr %t123, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t128 = icmp eq ptr %t126, null
  br i1 %t128, label %bb34, label %bb35
bb33:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb38
bb34:
  call void @__olang_check_failed(ptr @olang_loc_fd7ab254095cc62_437ccc419ec0735e)
  unreachable
bb35:
  br label %bb36
bb36:
  %t130 = load ptr, ptr %l4, !tbaa !29
  %t132 = getelementptr %"compiler/ast:If", ptr %t130, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !29
  %t136 = getelementptr %"compiler/ast:Branch", ptr %t133, i32 0, i32 2
  %t137 = load i64, ptr %t136, !tbaa !24
  %t138 = load ptr, ptr %l59, !tbaa !29
  %t140 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eIsPending(ptr %v0, ptr %t138, i64 %t137)
  store i1 %t140, ptr %l67
  br label %bb37
bb37:
  %t141 = load i1, ptr %l67, !tbaa !21
  store i1 %t141, ptr %l58, !tbaa !21
  br label %bb38
bb38:
  %t142 = load i1, ptr %l58, !tbaa !21
  br i1 %t142, label %bb39, label %bb40
bb39:
  %t143 = load ptr, ptr %l2, !tbaa !29
  store ptr %t143, ptr %l68, !tbaa !29
  %t144 = load ptr, ptr %l4, !tbaa !29
  %t146 = getelementptr %"compiler/ast:If", ptr %t144, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !29
  %t149 = icmp eq ptr %t147, null
  br i1 %t149, label %bb41, label %bb42
bb40:
  br label %bb45
bb41:
  call void @__olang_check_failed(ptr @olang_loc_fd7ab254095cc62_437ccc419ec0735e)
  unreachable
bb42:
  br label %bb43
bb43:
  %t151 = load ptr, ptr %l4, !tbaa !29
  %t153 = getelementptr %"compiler/ast:If", ptr %t151, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t157 = getelementptr %"compiler/ast:Branch", ptr %t154, i32 0, i32 2
  %t158 = load i64, ptr %t157, !tbaa !24
  %t159 = load ptr, ptr %l68, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eChoose(ptr %v0, ptr %t159, i64 %t158)
  br label %bb44
bb44:
  br label %bb45
bb45:
  br label %bb47
bb46:
  br label %bb47
bb47:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eallFixed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l18 = alloca { i64, ptr }
  %l25 = alloca i1
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t22, ptr %l18, !tbaa !27
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  %t37 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eonlyFixed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %t28, ptr %a2)
  store i1 %t37, ptr %l25
  br label %bb8
bb8:
  %t38 = load i1, ptr %l25, !tbaa !21
  %t39 = xor i1 %t38, true
  br i1 %t39, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  store i1 false, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb12
bb12:
  %t42 = load i64, ptr %l4, !tbaa !24
  %t44 = add i64 %t42, 1
  store i64 %t44, ptr %l4, !tbaa !24
  br label %bb4
bb13:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyAs(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l9 = alloca %"compiler/source:Span"
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca %"compiler/source:Span"
  %l15 = alloca i32
  %l17 = alloca i32
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca ptr
  %l30 = alloca i32
  %l31 = alloca { i64, ptr }
  %l32 = alloca ptr
  %l34 = alloca %"compiler/source:Span"
  %l36 = alloca %"compiler/source:Span"
  %l37 = alloca %"compiler/source:Span"
  %l38 = alloca i32
  %l39 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2, ptr %l7, !tbaa !29
  %t3 = load ptr, ptr %l3, !tbaa !29
  %t5 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t3)
  store %"compiler/source:Span" %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t8 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v2, ptr %t6)
  store %"compiler/source:Span" %t8, ptr %l11
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l7, !tbaa !29
  %t10 = load %"compiler/source:Span", ptr %l9
  %t11 = load %"compiler/source:Span", ptr %l11
  %t12 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t9, %"compiler/source:Span" %t10, %"compiler/source:Span" %t11, i64 2)
  store %"compiler/source:Span" %t12, ptr %l12
  br label %bb3
bb3:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t16 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t13)
  store i32 %t16, ptr %l15
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l4, !tbaa !29
  %t18 = load ptr, ptr %l6, !tbaa !29
  %t19 = load %"compiler/source:Span", ptr %l12
  %t20 = load i32, ptr %l15, !tbaa !23
  %t22 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyCaseType(ptr %v0, ptr %v2, ptr %t18, %"compiler/source:Span" %t19, i32 %t20, ptr %t17)
  store i32 %t22, ptr %l17
  br label %bb5
bb5:
  %t23 = load i32, ptr %l17, !tbaa !23
  store i32 %t23, ptr %l5, !tbaa !23
  %t24 = load i32, ptr %l5, !tbaa !23
  %t25 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t28 = icmp eq i32 %t24, %t25
  br i1 %t28, label %bb6, label %bb7
bb6:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load %"compiler/source:Span", ptr %l1
  %t34 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t30, %"compiler/source:Span" %t31)
  store ptr %t34, ptr %l23
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t35 = load ptr, ptr %l23, !tbaa !29
  store ptr %t35, ptr %rv
  br label %ret
bb9:
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l24, !tbaa !29
  %t37 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t37, ptr %l25
  %t38 = load ptr, ptr %l2, !tbaa !29
  store ptr %t38, ptr %l26, !tbaa !29
  %t39 = load i32, ptr %l5, !tbaa !23
  store i32 %t39, ptr %l27, !tbaa !23
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l28, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrongCase(ptr %v0, ptr %t41)
  store i32 %t43, ptr %l30
  br label %bb10
bb10:
  %t44 = mul i64 1, 4
  %t45 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t44)
  %t46 = insertvalue { i64, ptr } undef, i64 1, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  store { i64, ptr } %t47, ptr %l31, !tbaa !27
  %t48 = load i32, ptr %l30, !tbaa !23
  %t49 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr i32, ptr %t50, i64 0
  store i32 %t48, ptr %t51, !tbaa !33
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l32, !tbaa !29
  %t53 = load ptr, ptr %l3, !tbaa !29
  %t55 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t53)
  store %"compiler/source:Span" %t55, ptr %l34
  br label %bb11
bb11:
  %t56 = load ptr, ptr %l4, !tbaa !29
  %t58 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v2, ptr %t56)
  store %"compiler/source:Span" %t58, ptr %l36
  br label %bb12
bb12:
  %t59 = load ptr, ptr %l32, !tbaa !29
  %t60 = load %"compiler/source:Span", ptr %l34
  %t61 = load %"compiler/source:Span", ptr %l36
  %t62 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t59, %"compiler/source:Span" %t60, %"compiler/source:Span" %t61, i64 2)
  store %"compiler/source:Span" %t62, ptr %l37
  br label %bb13
bb13:
  %t63 = load ptr, ptr %l28, !tbaa !29
  %t64 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t65 = load %"compiler/source:Span", ptr %l37
  %t66 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efailOp(ptr %v0, ptr %s0, ptr %t63, { i64, ptr } %t64, %"compiler/source:Span" %t65, i1 true)
  store i32 %t66, ptr %l38
  br label %bb14
bb14:
  %t67 = load ptr, ptr %l24, !tbaa !29
  %t68 = load %"compiler/source:Span", ptr %l25
  %t69 = load ptr, ptr %l26, !tbaa !29
  %t70 = load i32, ptr %l27, !tbaa !23
  %t71 = load i32, ptr %l38
  %t72 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyInstance(ptr %v0, ptr %t67, %"compiler/source:Span" %t68, ptr %t69, i32 %t70, i32 %t71)
  store ptr %t72, ptr %l39
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  %t73 = load ptr, ptr %l39, !tbaa !29
  store ptr %t73, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earmPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l23 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l35 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i1
  %l48 = alloca i1
  %l50 = alloca { i64, ptr }
  %l52 = alloca %"compiler/source:Span"
  %l54 = alloca %"compiler/source:Span"
  %l56 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l67 = alloca i1
  %l71 = alloca i1
  %l72 = alloca ptr
  %l73 = alloca i1
  %l76 = alloca ptr
  %l77 = alloca i1
  %l82 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t7 = load ptr, ptr %l10, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l10, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 3
  store i1 %t13, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l11, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  store i1 true, ptr %rv
  br label %ret
bb9:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t17 = load ptr, ptr %l15, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb10, label %bb11
bb10:
  %t20 = load ptr, ptr %l15, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 2
  store i1 %t23, ptr %l16, !tbaa !21
  br label %bb11
bb11:
  %t24 = load i1, ptr %l16, !tbaa !21
  br i1 %t24, label %bb12, label %bb13
bb12:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t27, i32 0, i32 1
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l2, !tbaa !23
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l2, !tbaa !23
  %t35 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t31, i32 %t32)
  store i1 %t35, ptr %l23
  br label %bb15
bb15:
  %t36 = load i1, ptr %l23, !tbaa !21
  %t37 = xor i1 %t36, true
  store i1 %t37, ptr %rv
  br label %ret
bb16:
  %t39 = load ptr, ptr %l1, !tbaa !29
  store ptr %t39, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t40 = load ptr, ptr %l25, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %bb17, label %bb18
bb17:
  %t43 = load ptr, ptr %l25, !tbaa !29
  %t44 = load i64, ptr %t43
  %t46 = icmp eq i64 %t44, 5
  store i1 %t46, ptr %l26, !tbaa !21
  br label %bb18
bb18:
  %t47 = load i1, ptr %l26, !tbaa !21
  br i1 %t47, label %bb19, label %bb20
bb19:
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr { i64, [5 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t50, i32 0, i32 2
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l3, !tbaa !29
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l3, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Promote", ptr %t55, i32 0, i32 0
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t62 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earmPlace(ptr %v0, ptr %v1, ptr %t54, ptr %t58)
  store i1 %t62, ptr %l35
  br label %bb22
bb22:
  %t63 = load i1, ptr %l35, !tbaa !21
  store i1 %t63, ptr %rv
  br label %ret
bb23:
  %t64 = load ptr, ptr %l1, !tbaa !29
  store ptr %t64, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t65 = load ptr, ptr %l36, !tbaa !29
  %t66 = icmp ne ptr %t65, null
  br i1 %t66, label %bb24, label %bb25
bb24:
  %t68 = load ptr, ptr %l36, !tbaa !29
  %t69 = load i64, ptr %t68
  %t71 = icmp eq i64 %t69, 6
  store i1 %t71, ptr %l37, !tbaa !21
  br label %bb25
bb25:
  %t72 = load i1, ptr %l37, !tbaa !21
  br i1 %t72, label %bb26, label %bb27
bb26:
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr { i64, [5 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t75, i32 0, i32 0
  %t77 = load %"compiler/source:Span", ptr %t76
  store %"compiler/source:Span" %t77, ptr %l4
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr { i64, [5 x i64] }, ptr %t79, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t81, i32 0, i32 2
  %t83 = load ptr, ptr %t82
  store ptr %t83, ptr %l5, !tbaa !29
  br label %bb28
bb27:
  br label %bb34
bb28:
  %t85 = load ptr, ptr %l5, !tbaa !29
  %t87 = getelementptr %"compiler/typed:Call", ptr %t85, i32 0, i32 1
  %t88 = load { i64, ptr }, ptr %t87, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t88, 0
  %t92 = icmp sgt i64 %t90, 0
  br i1 %t92, label %bb29, label %bb30
bb29:
  %t94 = load ptr, ptr %l5, !tbaa !29
  %t96 = getelementptr %"compiler/typed:Call", ptr %t94, i32 0, i32 1
  %t97 = load { i64, ptr }, ptr %t96, !tbaa !27
  store { i64, ptr } %t97, ptr %l50, !tbaa !27
  %t98 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr ptr, ptr %t99, i64 0
  %t101 = load ptr, ptr %t100, !tbaa !39
  %t103 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t101)
  store %"compiler/source:Span" %t103, ptr %l52
  br label %bb31
bb30:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb33
bb31:
  %t104 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t104, ptr %l54
  %t107 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %l52, ptr %l54)
  store i1 %t107, ptr %l56
  br label %bb32
bb32:
  %t108 = load i1, ptr %l56, !tbaa !21
  store i1 %t108, ptr %l48, !tbaa !21
  br label %bb33
bb33:
  %t109 = load i1, ptr %l48, !tbaa !21
  store i1 %t109, ptr %rv
  br label %ret
bb34:
  %t110 = load ptr, ptr %l1, !tbaa !29
  store ptr %t110, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t111 = load ptr, ptr %l57, !tbaa !29
  %t112 = icmp ne ptr %t111, null
  br i1 %t112, label %bb35, label %bb36
bb35:
  %t114 = load ptr, ptr %l57, !tbaa !29
  %t115 = load i64, ptr %t114
  %t117 = icmp eq i64 %t115, 14
  store i1 %t117, ptr %l58, !tbaa !21
  br label %bb36
bb36:
  %t118 = load i1, ptr %l58, !tbaa !21
  br i1 %t118, label %bb37, label %bb38
bb37:
  %t119 = load ptr, ptr %l1, !tbaa !29
  %t121 = getelementptr { i64, [5 x i64] }, ptr %t119, i32 0, i32 1
  %t122 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t121, i32 0, i32 2
  %t123 = load ptr, ptr %t122
  store ptr %t123, ptr %l6, !tbaa !29
  br label %bb39
bb38:
  br label %bb44
bb39:
  %t125 = load ptr, ptr %l6, !tbaa !29
  %t127 = getelementptr %"compiler/typed:Try", ptr %t125, i32 0, i32 0
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t130 = icmp eq ptr %t128, null
  %t132 = xor i1 %t130, true
  br i1 %t132, label %bb40, label %bb41
bb40:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load ptr, ptr %l6, !tbaa !29
  %t137 = getelementptr %"compiler/typed:Try", ptr %t135, i32 0, i32 0
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t141 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earmPlace(ptr %v0, ptr %v1, ptr %t134, ptr %t138)
  store i1 %t141, ptr %l71
  br label %bb42
bb41:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb43
bb42:
  %t142 = load i1, ptr %l71, !tbaa !21
  store i1 %t142, ptr %l67, !tbaa !21
  br label %bb43
bb43:
  %t143 = load i1, ptr %l67, !tbaa !21
  store i1 %t143, ptr %rv
  br label %ret
bb44:
  %t144 = load ptr, ptr %l1, !tbaa !29
  store ptr %t144, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t145 = load ptr, ptr %l72, !tbaa !29
  %t146 = icmp ne ptr %t145, null
  br i1 %t146, label %bb45, label %bb46
bb45:
  %t148 = load ptr, ptr %l72, !tbaa !29
  %t149 = load i64, ptr %t148
  %t151 = icmp eq i64 %t149, 11
  store i1 %t151, ptr %l73, !tbaa !21
  br label %bb46
bb46:
  %t152 = load i1, ptr %l73, !tbaa !21
  br i1 %t152, label %bb47, label %bb48
bb47:
  br label %bb53
bb48:
  %t153 = load ptr, ptr %l1, !tbaa !29
  store ptr %t153, ptr %l76, !tbaa !29
  store i1 false, ptr %l77, !tbaa !21
  %t154 = load ptr, ptr %l76, !tbaa !29
  %t155 = icmp ne ptr %t154, null
  br i1 %t155, label %bb49, label %bb50
bb49:
  %t157 = load ptr, ptr %l76, !tbaa !29
  %t158 = load i64, ptr %t157
  %t160 = icmp eq i64 %t158, 13
  store i1 %t160, ptr %l77, !tbaa !21
  br label %bb50
bb50:
  %t161 = load i1, ptr %l77, !tbaa !21
  br i1 %t161, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb55
bb53:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t163 = load ptr, ptr %l1, !tbaa !29
  %t166 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econdChoosesPlace(ptr %v0, ptr %v1, ptr %t162, ptr %t163)
  store i1 %t166, ptr %l82
  br label %bb54
bb54:
  %t167 = load i1, ptr %l82, !tbaa !21
  store i1 %t167, ptr %rv
  br label %ret
bb55:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayMake(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, ptr } %a3, i32 %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i64
  %l13 = alloca { i64, [3 x i64] }
  %l14 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca i1
  %l17 = alloca { i64, [3 x i64] }
  %l19 = alloca i32
  %l20 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca ptr
  %l29 = alloca i32
  %l32 = alloca i32
  %l37 = alloca i1
  %l40 = alloca ptr
  %l43 = alloca i32
  %l44 = alloca i32
  %l47 = alloca i1
  %l50 = alloca ptr
  %l53 = alloca i32
  %l54 = alloca i32
  %l59 = alloca ptr
  %l61 = alloca ptr
  %l64 = alloca { i64, ptr }
  %l67 = alloca i32
  %l72 = alloca i32
  %l75 = alloca i1
  %l80 = alloca i64
  %l82 = alloca ptr
  %l83 = alloca { i64, ptr }
  %l85 = alloca %"compiler/source:Span"
  %l90 = alloca i64
  %l91 = alloca %"compiler/msgs:Msg"
  %l92 = alloca i64
  %l99 = alloca i32
  %l102 = alloca i64
  %l113 = alloca ptr
  %l116 = alloca { i64, ptr }
  %l119 = alloca ptr
  %l124 = alloca i1
  %l126 = alloca ptr
  %l128 = alloca ptr
  %l129 = alloca { i64, ptr }
  %l131 = alloca %"compiler/source:Span"
  %l133 = alloca i1
  %l141 = alloca ptr
  %l143 = alloca ptr
  %l145 = alloca ptr
  %l146 = alloca { i64, ptr }
  %l147 = alloca ptr
  %l149 = alloca i32
  %l150 = alloca i32
  %l155 = alloca i32
  %l158 = alloca i1
  %l163 = alloca i64
  %l171 = alloca i1
  %l174 = alloca i1
  %l176 = alloca ptr
  %l180 = alloca ptr
  %l190 = alloca ptr
  %l196 = alloca { i64, ptr }
  %l198 = alloca %"compiler/source:Span"
  %l199 = alloca i32
  %l200 = alloca i32
  %l201 = alloca { i64, ptr }
  %l203 = alloca ptr
  %l207 = alloca i32
  %l209 = alloca %"compiler/typed:Make"
  %s2 = alloca %olang.scope
  %rv = alloca ptr
  %t185 = alloca { i64, [3 x i64] }, align 8
  %t312 = alloca { i64, [3 x i64] }, align 8
  %t393 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store i32 %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l20, !tbaa !29
  %t2 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t2, ptr %l21, !tbaa !27
  %t3 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !27
  %t5 = getelementptr ptr, ptr %t4, i64 0
  %t6 = load ptr, ptr %t5, !tbaa !39
  store ptr %t6, ptr %l22, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t7)
  store i32 %t9, ptr %l24
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l20, !tbaa !29
  %t11 = load ptr, ptr %l22, !tbaa !29
  %t12 = load i32, ptr %l24, !tbaa !23
  %t13 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %t10, ptr %t11, i32 %t12)
  store ptr %t13, ptr %l25
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l25, !tbaa !29
  store ptr %t14, ptr %l6, !tbaa !29
  store i32 0, ptr %l7, !tbaa !23
  %t15 = load i32, ptr %l4, !tbaa !23
  %t16 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t19 = icmp ne i32 %t15, %t16
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l4, !tbaa !23
  %t25 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l32
  br label %bb5
bb4:
  %t26 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t26, ptr %l29, !tbaa !23
  br label %bb6
bb5:
  %t28 = load i32, ptr %l32, !tbaa !23
  store i32 %t28, ptr %l29, !tbaa !23
  br label %bb6
bb6:
  %t29 = load i32, ptr %l29, !tbaa !23
  store i32 %t29, ptr %l8, !tbaa !23
  %t30 = load i32, ptr %l8, !tbaa !23
  %t31 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t34 = icmp ne i32 %t30, %t31
  br i1 %t34, label %bb7, label %bb8
bb7:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = getelementptr %"compiler/generic:Program", ptr %t39, i32 0, i32 2
  store ptr %t41, ptr %l40, !tbaa !29
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i32, ptr %l8, !tbaa !23
  %t46 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t42, i32 %t43)
  store i32 %t46, ptr %l43
  br label %bb9
bb8:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb11
bb9:
  %t47 = load ptr, ptr %l40, !tbaa !29
  %t48 = load i32, ptr %l43, !tbaa !23
  %t49 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t47, i32 %t48)
  store i32 %t49, ptr %l44
  br label %bb10
bb10:
  %t50 = load i32, ptr %l44
  %t52 = trunc i64 19 to i32
  %t53 = icmp eq i32 %t50, %t52
  store i1 %t53, ptr %l37, !tbaa !21
  br label %bb11
bb11:
  %t55 = load i1, ptr %l37, !tbaa !21
  br i1 %t55, label %bb12, label %bb13
bb12:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 2
  store ptr %t61, ptr %l50, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load i32, ptr %l8, !tbaa !23
  %t66 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t62, i32 %t63)
  store i32 %t66, ptr %l53
  br label %bb14
bb13:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb16
bb14:
  %t67 = load ptr, ptr %l50, !tbaa !29
  %t68 = load i32, ptr %l53, !tbaa !23
  %t69 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t67, i32 %t68)
  store i32 %t69, ptr %l54
  br label %bb15
bb15:
  %t70 = load i32, ptr %l54, !tbaa !23
  %t71 = icmp eq i32 %t70, 0
  store i1 %t71, ptr %l47, !tbaa !21
  br label %bb16
bb16:
  %t73 = load i1, ptr %l47, !tbaa !21
  %t76 = xor i1 %t73, true
  br i1 %t76, label %bb17, label %bb18
bb17:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/check:Checker", ptr %t78, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !29
  store ptr %t81, ptr %l59, !tbaa !29
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t82)
  store ptr %t84, ptr %l61
  br label %bb19
bb18:
  br label %bb33
bb19:
  %t85 = load ptr, ptr %l61, !tbaa !29
  %t87 = getelementptr %"compiler/check:frame", ptr %t85, i32 0, i32 4
  %t88 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t88, ptr %l64, !tbaa !27
  %t89 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr ptr, ptr %t90, i64 0
  %t92 = load ptr, ptr %t91, !tbaa !39
  %t94 = load ptr, ptr %l59, !tbaa !29
  %t97 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFoldLength(ptr %v0, ptr %v0, ptr %v1, ptr %t94, ptr %t87, ptr %t92)
  store i32 %t97, ptr %l67
  br label %bb20
bb20:
  %t98 = load i32, ptr %l67, !tbaa !23
  store i32 %t98, ptr %l10, !tbaa !23
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/check:Checker", ptr %t99, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t104 = getelementptr %"compiler/generic:Program", ptr %t102, i32 0, i32 2
  %t105 = load i32, ptr %l10, !tbaa !23
  %t108 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t104, i32 %t105)
  store i32 %t108, ptr %l72
  br label %bb21
bb21:
  %t109 = load i32, ptr %l72
  %t111 = trunc i64 26 to i32
  %t112 = icmp eq i32 %t109, %t111
  br i1 %t112, label %bb22, label %bb23
bb22:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/check:Checker", ptr %t114, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !29
  %t119 = getelementptr %"compiler/generic:Program", ptr %t117, i32 0, i32 2
  %t120 = load i32, ptr %l10, !tbaa !23
  %t123 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t119, i32 %t120)
  store i64 %t123, ptr %l80
  br label %bb24
bb23:
  store i1 false, ptr %l75, !tbaa !21
  br label %bb25
bb24:
  %t124 = load i64, ptr %l80, !tbaa !24
  %t125 = icmp slt i64 %t124, 0
  store i1 %t125, ptr %l75, !tbaa !21
  br label %bb25
bb25:
  %t127 = load i1, ptr %l75, !tbaa !21
  br i1 %t127, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s2
  %t128 = load ptr, ptr %l0, !tbaa !29
  store ptr %t128, ptr %l82, !tbaa !29
  %t129 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t129, ptr %l83, !tbaa !27
  %t130 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr ptr, ptr %t131, i64 0
  %t133 = load ptr, ptr %t132, !tbaa !39
  %t135 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t133)
  store %"compiler/source:Span" %t135, ptr %l85
  br label %bb28
bb27:
  %t136 = load i32, ptr %l10, !tbaa !23
  store i32 %t136, ptr %l7, !tbaa !23
  br label %bb32
bb28:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/check:Checker", ptr %t138, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !29
  %t143 = getelementptr %"compiler/generic:Program", ptr %t141, i32 0, i32 2
  %t144 = load i32, ptr %l10, !tbaa !23
  %t147 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t143, i32 %t144)
  store i64 %t147, ptr %l90
  br label %bb29
bb29:
  %t148 = load i64, ptr %l90, !tbaa !24
  %t149 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayLengthRange(ptr %s2, i64 %t148)
  store %"compiler/msgs:Msg" %t149, ptr %l91
  br label %bb30
bb30:
  %t150 = load ptr, ptr %l82, !tbaa !29
  %t151 = load %"compiler/source:Span", ptr %l85
  %t152 = load %"compiler/msgs:Msg", ptr %l91
  %t153 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t150, %"compiler/source:Span" %t151, %"compiler/msgs:Msg" %t152)
  store i64 %t153, ptr %l92
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/check:Checker", ptr %t154, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !29
  %t159 = getelementptr %"compiler/generic:Program", ptr %t157, i32 0, i32 2
  %t160 = load i32, ptr %l2, !tbaa !23
  %t161 = load i32, ptr %l7, !tbaa !23
  %t165 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t159, i32 %t160, i32 %t161)
  store i32 %t165, ptr %l99
  br label %bb34
bb34:
  %t166 = load i32, ptr %l99, !tbaa !23
  store i32 %t166, ptr %l11, !tbaa !23
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/check:Checker", ptr %t167, i32 0, i32 31
  %t171 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t169)
  store i64 %t171, ptr %l102
  br label %bb35
bb35:
  %t172 = load i64, ptr %l102, !tbaa !24
  store i64 %t172, ptr %l12, !tbaa !24
  %t173 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t175 = extractvalue { i64, ptr } %t173, 0
  %t177 = icmp eq i64 %t175, 2
  br i1 %t177, label %bb36, label %bb37
bb36:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/check:Checker", ptr %t179, i32 0, i32 9
  %t182 = load { i64, [3 x i64] }, ptr %t181
  store { i64, [3 x i64] } %t182, ptr %l13
  %t184 = load ptr, ptr %l0, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t185
  %t186 = getelementptr { i64, [3 x i64] }, ptr %t185, i32 0, i32 0
  store i64 0, ptr %t186
  %t187 = load { i64, [3 x i64] }, ptr %t185
  %t190 = getelementptr %"compiler/check:Checker", ptr %t184, i32 0, i32 9
  store { i64, [3 x i64] } %t187, ptr %t190
  %t191 = load ptr, ptr %l5, !tbaa !29
  %t193 = icmp eq ptr %t191, null
  %t195 = xor i1 %t193, true
  br i1 %t195, label %bb38, label %bb39
bb37:
  br label %bb49
bb38:
  %t197 = load ptr, ptr %l5, !tbaa !29
  store ptr %t197, ptr %l113, !tbaa !29
  br label %bb41
bb39:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t200, ptr %l116, !tbaa !27
  %t201 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !27
  %t203 = getelementptr ptr, ptr %t202, i64 1
  %t204 = load ptr, ptr %t203, !tbaa !39
  %t205 = load i32, ptr %l2, !tbaa !23
  %t209 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %t199, ptr %t204, i32 %t205)
  store ptr %t209, ptr %l119
  br label %bb40
bb40:
  %t210 = load ptr, ptr %l119, !tbaa !29
  store ptr %t210, ptr %l113, !tbaa !29
  br label %bb41
bb41:
  %t211 = load ptr, ptr %l113, !tbaa !29
  store ptr %t211, ptr %l14, !tbaa !29
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load { i64, [3 x i64] }, ptr %l13
  %t216 = getelementptr %"compiler/check:Checker", ptr %t212, i32 0, i32 9
  store { i64, [3 x i64] } %t213, ptr %t216
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load i32, ptr %l2, !tbaa !23
  %t221 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t217, i32 %t218)
  store i1 %t221, ptr %l124
  br label %bb42
bb42:
  %t222 = load i1, ptr %l124, !tbaa !21
  %t223 = xor i1 %t222, true
  br i1 %t223, label %bb43, label %bb44
bb43:
  %t225 = load ptr, ptr %l0, !tbaa !29
  store ptr %t225, ptr %l126, !tbaa !29
  %t226 = load ptr, ptr %l14, !tbaa !29
  store ptr %t226, ptr %l128, !tbaa !29
  %t228 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t228, ptr %l129, !tbaa !27
  %t229 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t230 = load ptr, ptr %t229, !tbaa !27
  %t231 = getelementptr ptr, ptr %t230, i64 1
  %t232 = load ptr, ptr %t231, !tbaa !39
  %t234 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t232)
  store %"compiler/source:Span" %t234, ptr %l131
  br label %bb45
bb44:
  br label %bb47
bb45:
  %t235 = load i64, ptr @G_2ecompiler_2fcheck_2eRoStored, !tbaa !24
  %t236 = load ptr, ptr %l126, !tbaa !29
  %t237 = load ptr, ptr %l128, !tbaa !29
  %t238 = load %"compiler/source:Span", ptr %l131
  %t240 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v0, ptr %t236, ptr %t237, %"compiler/source:Span" %t238, i64 %t235)
  store i1 %t240, ptr %l133
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr %"compiler/check:Checker", ptr %t241, i32 0, i32 31
  %t244 = load ptr, ptr %l14, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t243, ptr %t244)
  br label %bb48
bb48:
  br label %bb49
bb49:
  %t247 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t249 = extractvalue { i64, ptr } %t247, 0
  %t251 = icmp eq i64 %t249, 1
  br i1 %t251, label %bb50, label %bb51
bb50:
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t255 = getelementptr %"compiler/check:Checker", ptr %t253, i32 0, i32 1
  %t256 = load ptr, ptr %t255, !tbaa !29
  store ptr %t256, ptr %l141, !tbaa !29
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t257)
  store ptr %t259, ptr %l143
  br label %bb52
bb51:
  br label %bb74
bb52:
  %t260 = load ptr, ptr %l143, !tbaa !29
  %t262 = getelementptr %"compiler/check:frame", ptr %t260, i32 0, i32 4
  store ptr %t262, ptr %l145, !tbaa !29
  %t263 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t263, ptr %l146, !tbaa !27
  %t264 = getelementptr { i64, ptr }, ptr %l146, i32 0, i32 1
  %t265 = load ptr, ptr %t264, !tbaa !27
  %t266 = getelementptr ptr, ptr %t265, i64 0
  %t267 = load ptr, ptr %t266, !tbaa !39
  store ptr %t267, ptr %l147, !tbaa !29
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t270 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t268)
  store i32 %t270, ptr %l149
  br label %bb53
bb53:
  %t271 = load ptr, ptr %l141, !tbaa !29
  %t272 = load ptr, ptr %l145, !tbaa !29
  %t273 = load ptr, ptr %l147, !tbaa !29
  %t274 = load i32, ptr %l149, !tbaa !23
  %t275 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFoldKnown(ptr %v0, ptr %v0, ptr %v1, ptr %t271, ptr %t272, ptr %t273, i32 %t274)
  store i32 %t275, ptr %l150
  br label %bb54
bb54:
  %t276 = load i32, ptr %l150, !tbaa !23
  store i32 %t276, ptr %l15, !tbaa !23
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t279 = getelementptr %"compiler/check:Checker", ptr %t277, i32 0, i32 1
  %t280 = load ptr, ptr %t279, !tbaa !29
  %t282 = getelementptr %"compiler/generic:Program", ptr %t280, i32 0, i32 2
  %t283 = load i32, ptr %l15, !tbaa !23
  %t286 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t282, i32 %t283)
  store i32 %t286, ptr %l155
  br label %bb55
bb55:
  %t287 = load i32, ptr %l155
  %t289 = trunc i64 26 to i32
  %t290 = icmp eq i32 %t287, %t289
  br i1 %t290, label %bb56, label %bb57
bb56:
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = getelementptr %"compiler/check:Checker", ptr %t292, i32 0, i32 1
  %t295 = load ptr, ptr %t294, !tbaa !29
  %t297 = getelementptr %"compiler/generic:Program", ptr %t295, i32 0, i32 2
  %t298 = load i32, ptr %l15, !tbaa !23
  %t301 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t297, i32 %t298)
  store i64 %t301, ptr %l163
  br label %bb58
bb57:
  store i1 false, ptr %l158, !tbaa !21
  br label %bb59
bb58:
  %t302 = load i64, ptr %l163, !tbaa !24
  %t303 = icmp eq i64 %t302, 0
  store i1 %t303, ptr %l158, !tbaa !21
  br label %bb59
bb59:
  %t305 = load i1, ptr %l158, !tbaa !21
  store i1 %t305, ptr %l16, !tbaa !21
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t308 = getelementptr %"compiler/check:Checker", ptr %t306, i32 0, i32 9
  %t309 = load { i64, [3 x i64] }, ptr %t308
  store { i64, [3 x i64] } %t309, ptr %l17
  %t311 = load ptr, ptr %l0, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t312
  %t313 = getelementptr { i64, [3 x i64] }, ptr %t312, i32 0, i32 0
  store i64 0, ptr %t313
  %t314 = load { i64, [3 x i64] }, ptr %t312
  %t317 = getelementptr %"compiler/check:Checker", ptr %t311, i32 0, i32 9
  store { i64, [3 x i64] } %t314, ptr %t317
  %t318 = load i1, ptr %l16, !tbaa !21
  %t320 = xor i1 %t318, true
  br i1 %t320, label %bb60, label %bb61
bb60:
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t323 = load i32, ptr %l2, !tbaa !23
  %t326 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezeroCalls(ptr %v0, ptr %t322, i32 %t323)
  store i1 %t326, ptr %l174
  br label %bb62
bb61:
  store i1 false, ptr %l171, !tbaa !21
  br label %bb63
bb62:
  %t327 = load i1, ptr %l174, !tbaa !21
  store i1 %t327, ptr %l171, !tbaa !21
  br label %bb63
bb63:
  %t328 = load i1, ptr %l171, !tbaa !21
  br i1 %t328, label %bb64, label %bb65
bb64:
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t331 = getelementptr %"compiler/check:Checker", ptr %t329, i32 0, i32 31
  store ptr %t331, ptr %l176, !tbaa !29
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t333 = load %"compiler/source:Span", ptr %l1
  %t334 = load i32, ptr %l2, !tbaa !23
  %t338 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %t332, %"compiler/source:Span" %t333, i32 %t334)
  store ptr %t338, ptr %l180
  br label %bb66
bb65:
  %t339 = load i1, ptr %l16, !tbaa !21
  %t341 = xor i1 %t339, true
  br i1 %t341, label %bb69, label %bb70
bb66:
  %t343 = load ptr, ptr %l176, !tbaa !29
  %t344 = load ptr, ptr %l180, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t343, ptr %t344)
  br label %bb67
bb67:
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t346 = load %"compiler/source:Span", ptr %l1
  %t347 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2easkValue(ptr %v0, ptr %v0, ptr %t345, i32 2, %"compiler/source:Span" %t346, i32 %t347, ptr null)
  br label %bb68
bb68:
  br label %bb73
bb69:
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t353 = load %"compiler/source:Span", ptr %l1
  %t354 = load i32, ptr %l2, !tbaa !23
  %t358 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %t352, %"compiler/source:Span" %t353, i32 %t354)
  store ptr %t358, ptr %l190
  br label %bb71
bb70:
  br label %bb72
bb71:
  br label %bb72
bb72:
  br label %bb73
bb73:
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t360 = load { i64, [3 x i64] }, ptr %l17
  %t363 = getelementptr %"compiler/check:Checker", ptr %t359, i32 0, i32 9
  store { i64, [3 x i64] } %t360, ptr %t363
  br label %bb74
bb74:
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t366 = getelementptr %"compiler/check:Checker", ptr %t364, i32 0, i32 31
  %t367 = load i64, ptr %l12, !tbaa !24
  %t370 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t366, i64 %t367)
  store { i64, ptr } %t370, ptr %l196
  br label %bb75
bb75:
  %t371 = load { i64, ptr }, ptr %l196, !tbaa !27
  store i32 1, ptr %l19
  %t373 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t373, ptr %l198
  %t374 = load i32, ptr %l11, !tbaa !23
  store i32 %t374, ptr %l199, !tbaa !23
  store i32 3, ptr %l200
  store { i64, ptr } %t371, ptr %l201, !tbaa !27
  %t376 = load ptr, ptr %l6, !tbaa !29
  store ptr %t376, ptr %l203, !tbaa !29
  %t378 = load ptr, ptr %l0, !tbaa !29
  %t379 = load %"compiler/source:Span", ptr %l1
  %t383 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t378, i32 1, %"compiler/source:Span" %t379)
  store i32 %t383, ptr %l207
  br label %bb76
bb76:
  %t384 = load i32, ptr %l19
  %t385 = load i32, ptr %l200
  %t386 = load { i64, ptr }, ptr %l201, !tbaa !27
  %t387 = load ptr, ptr %l203, !tbaa !29
  %t388 = load i32, ptr %l207, !tbaa !23
  %t390 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t385, i64 0, { i64, ptr } %t386, ptr %t387, i32 %t388, i32 %t384)
  store %"compiler/typed:Make" %t390, ptr %l209
  br label %bb77
bb77:
  %t391 = load %"compiler/typed:Make", ptr %l209
  %t392 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store %"compiler/typed:Make" %t391, ptr %t392
  store { i64, [5 x i64] } zeroinitializer, ptr %t393
  %t394 = getelementptr { i64, [5 x i64] }, ptr %t393, i32 0, i32 0
  store i64 7, ptr %t394
  %t395 = load %"compiler/source:Span", ptr %l198
  %t396 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t395, 0
  %t397 = load i32, ptr %l199, !tbaa !23
  %t398 = insertvalue { %"compiler/source:Span", i32, ptr } %t396, i32 %t397, 1
  %t400 = insertvalue { %"compiler/source:Span", i32, ptr } %t398, ptr %t392, 2
  %t401 = getelementptr { i64, [5 x i64] }, ptr %t393, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t400, ptr %t401
  %t402 = load { i64, [5 x i64] }, ptr %t393
  %t404 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t402, ptr %t404
  store ptr %t404, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eblockOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, i64, i64 }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l11 = alloca i64
  %l15 = alloca { i64, i64, i64 }
  %l26 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 32
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i64, ptr %l11, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t13 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t7, i32 %a2, %"compiler/source:Span" %a3)
  store { i64, i64, i64 } %t13, ptr %l15
  br label %bb2
bb2:
  %t14 = load { i64, i64, i64 }, ptr %l15
  store { i64, i64, i64 } %t14, ptr %l5
  %t15 = getelementptr { i64, i64, i64 }, ptr %l5, i32 0, i32 0
  %t16 = load i64, ptr %t15, !tbaa !24
  store i64 %t16, ptr %l6, !tbaa !24
  %t18 = getelementptr { i64, i64, i64 }, ptr %l5, i32 0, i32 1
  %t19 = load i64, ptr %t18, !tbaa !24
  store i64 %t19, ptr %l7, !tbaa !24
  %t21 = getelementptr { i64, i64, i64 }, ptr %l5, i32 0, i32 2
  %t22 = load i64, ptr %t21, !tbaa !24
  store i64 %t22, ptr %l8, !tbaa !24
  %t24 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %t24, { i64, ptr } %a1)
  br label %bb3
bb3:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i64, ptr %l6, !tbaa !24
  %t30 = load i64, ptr %l7, !tbaa !24
  %t31 = load i64, ptr %l8, !tbaa !24
  %t32 = load i64, ptr %l4, !tbaa !24
  %t38 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t28, i64 %t29, i64 %t30, i64 %t31, i64 %t32)
  store ptr %t38, ptr %l26
  br label %bb4
bb4:
  %t39 = load ptr, ptr %l26, !tbaa !29
  store ptr %t39, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallArgs(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca i1
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = icmp sge i64 0, 0
  br i1 %t5, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  %t7 = icmp sle i64 0, 1152921504606846975
  br i1 %t7, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_fa88b19e51866753_1c515c5623826c7f)
  unreachable
bb5:
  %t9 = mul i64 0, 8
  %t10 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 0, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %rv
  br label %ret
bb6:
  call void @__olang_check_failed(ptr @olang_loc_fa88b19e51866753_1c515c5623826c7f)
  unreachable
bb7:
  %t14 = load ptr, ptr %l1, !tbaa !29
  store ptr %t14, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t15 = load ptr, ptr %l9, !tbaa !29
  %t16 = icmp ne ptr %t15, null
  br i1 %t16, label %bb8, label %bb9
bb8:
  %t18 = load ptr, ptr %l9, !tbaa !29
  %t19 = load i64, ptr %t18
  %t21 = icmp eq i64 %t19, 6
  store i1 %t21, ptr %l10, !tbaa !21
  br label %bb9
bb9:
  %t22 = load i1, ptr %l10, !tbaa !21
  br i1 %t22, label %bb10, label %bb11
bb10:
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t25 = getelementptr { i64, [5 x i64] }, ptr %t23, i32 0, i32 1
  %t26 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t25, i32 0, i32 2
  %t27 = load ptr, ptr %t26
  store ptr %t27, ptr %l2, !tbaa !29
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t31 = getelementptr %"compiler/typed:Call", ptr %t29, i32 0, i32 1
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  store { i64, ptr } %t32, ptr %l8, !tbaa !27
  br label %bb22
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb21
bb16:
  %t34 = icmp sge i64 0, 0
  br i1 %t34, label %bb17, label %bb18
bb17:
  %t36 = icmp sle i64 0, 1152921504606846975
  br i1 %t36, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_962a22c7791f971e_263bae1157bb3aaa)
  unreachable
bb19:
  %t38 = mul i64 0, 8
  %t39 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t38)
  %t40 = insertvalue { i64, ptr } undef, i64 0, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  store { i64, ptr } %t41, ptr %l8, !tbaa !27
  br label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_962a22c7791f971e_263bae1157bb3aaa)
  unreachable
bb21:
  call void @__olang_check_failed(ptr @olang_loc_bce8d8bde069702e_ffe04dc686cce872)
  unreachable
bb22:
  %t43 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t43, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallbackType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i32
  %l11 = alloca i32
  %l15 = alloca i1
  %l18 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l48 = alloca i1
  %l49 = alloca i1
  %l52 = alloca i1
  %l53 = alloca i1
  %l54 = alloca ptr
  %l59 = alloca i32
  %l60 = alloca i1
  %l69 = alloca i32
  %l73 = alloca i1
  %l76 = alloca i1
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l11
  br label %bb1
bb1:
  %t11 = load i32, ptr %l11
  %t13 = trunc i64 21 to i32
  %t14 = icmp eq i32 %t11, %t13
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb6
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/generic:Program", ptr %t21, i32 0, i32 2
  store ptr %t23, ptr %l18, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Program", ptr %t27, i32 0, i32 2
  %t30 = load i32, ptr %l1, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t29, i32 %t30)
  store i32 %t33, ptr %l23
  br label %bb4
bb4:
  %t34 = load ptr, ptr %l18, !tbaa !29
  %t35 = load i32, ptr %l23, !tbaa !23
  %t36 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t34, i32 %t35)
  store { i64, ptr } %t36, ptr %l24
  br label %bb5
bb5:
  %t37 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 0
  %t40 = icmp sgt i64 %t38, 0
  store i1 %t40, ptr %l15, !tbaa !21
  br label %bb6
bb6:
  %t42 = load i1, ptr %l15, !tbaa !21
  br i1 %t42, label %bb7, label %bb8
bb7:
  store i1 false, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 2
  store ptr %t49, ptr %l30, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 2
  %t56 = load i32, ptr %l1, !tbaa !23
  %t59 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t55, i32 %t56)
  store i32 %t59, ptr %l35
  br label %bb10
bb10:
  %t60 = load ptr, ptr %l30, !tbaa !29
  %t61 = load i32, ptr %l35, !tbaa !23
  %t62 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t60, i32 %t61)
  store { i64, ptr } %t62, ptr %l36
  br label %bb11
bb11:
  %t63 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t63, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t64, 0
  store i64 %t66, ptr %l4, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t68 = load i64, ptr %l3, !tbaa !24
  %t69 = load i64, ptr %l4, !tbaa !24
  %t72 = icmp slt i64 %t68, %t69
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb14:
  br label %bb15
bb15:
  %t76 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t76, ptr %l43, !tbaa !27
  %t77 = load i64, ptr %l3, !tbaa !24
  %t79 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr i32, ptr %t80, i64 %t77
  %t82 = load i32, ptr %t81, !tbaa !33
  store i32 %t82, ptr %l5, !tbaa !23
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load i32, ptr %l5, !tbaa !23
  %t88 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternValue(ptr %v0, ptr %t84, i32 %t85)
  store i1 %t88, ptr %l48
  br label %bb16
bb16:
  %t89 = load i1, ptr %l48, !tbaa !21
  br i1 %t89, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb25
bb18:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load i32, ptr %l5, !tbaa !23
  %t94 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t90, i32 %t91)
  store i1 %t94, ptr %l52
  br label %bb19
bb19:
  %t95 = load i1, ptr %l52, !tbaa !21
  br i1 %t95, label %bb20, label %bb21
bb20:
  %t96 = load ptr, ptr %l0, !tbaa !29
  store ptr %t96, ptr %l54, !tbaa !29
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Program", ptr %t100, i32 0, i32 2
  %t103 = load i32, ptr %l5, !tbaa !23
  %t106 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t102, i32 %t103)
  store i32 %t106, ptr %l59
  br label %bb22
bb21:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb24
bb22:
  %t107 = load ptr, ptr %l54, !tbaa !29
  %t108 = load i32, ptr %l59, !tbaa !23
  %t109 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainStruct(ptr %v0, ptr %t107, i32 %t108, i64 0)
  store i1 %t109, ptr %l60
  br label %bb23
bb23:
  %t110 = load i1, ptr %l60, !tbaa !21
  store i1 %t110, ptr %l53, !tbaa !21
  br label %bb24
bb24:
  %t111 = load i1, ptr %l53, !tbaa !21
  store i1 %t111, ptr %l49, !tbaa !21
  br label %bb25
bb25:
  %t112 = load i1, ptr %l49, !tbaa !21
  %t113 = xor i1 %t112, true
  br i1 %t113, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s3)
  store i1 false, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s3)
  br label %bb29
bb29:
  %t116 = load i64, ptr %l3, !tbaa !24
  %t118 = add i64 %t116, 1
  store i64 %t118, ptr %l3, !tbaa !24
  br label %bb12
bb30:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/check:Checker", ptr %t120, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t125 = getelementptr %"compiler/generic:Program", ptr %t123, i32 0, i32 2
  %t126 = load i32, ptr %l1, !tbaa !23
  %t129 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t125, i32 %t126)
  store i32 %t129, ptr %l69
  br label %bb31
bb31:
  %t130 = load i32, ptr %l69, !tbaa !23
  store i32 %t130, ptr %l6, !tbaa !23
  %t131 = load i32, ptr %l6, !tbaa !23
  %t132 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t135 = icmp eq i32 %t131, %t132
  br i1 %t135, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l73, !tbaa !21
  br label %bb35
bb33:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load i32, ptr %l6, !tbaa !23
  %t141 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternValue(ptr %v0, ptr %t137, i32 %t138)
  store i1 %t141, ptr %l76
  br label %bb34
bb34:
  %t142 = load i1, ptr %l76, !tbaa !21
  store i1 %t142, ptr %l73, !tbaa !21
  br label %bb35
bb35:
  %t143 = load i1, ptr %l73, !tbaa !21
  store i1 %t143, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaptureIn(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i32
  %l25 = alloca i1
  %l35 = alloca i64
  %l40 = alloca ptr
  %l45 = alloca ptr
  %l48 = alloca ptr
  %l52 = alloca %"compiler/typed:Local"
  %l64 = alloca i1
  %l66 = alloca i1
  %l69 = alloca i32
  %l77 = alloca i32
  %l92 = alloca ptr
  %l93 = alloca ptr
  %l99 = alloca %"compiler/typed:Local"
  %l100 = alloca i32
  %l107 = alloca ptr
  %l110 = alloca i32
  %l114 = alloca %"compiler/typed:Capture"
  %l118 = alloca i1
  %l119 = alloca i1
  %l124 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i64
  %t90 = alloca { i64, [4 x i64] }, align 8
  %t139 = alloca { i64, [5 x i64] }, align 8
  %t157 = alloca { i64, [5 x i64] }, align 8
  %t185 = alloca { i64, [2 x i64] }, align 8
  %t252 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 12
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_Hbcd822ae67306ca6a025f17ed2cfb61c(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l16
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l16, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t11 = getelementptr %"compiler/check:frame", ptr %t9, i32 0, i32 8
  %t12 = load i32, ptr %l2, !tbaa !23
  %t15 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t11, i32 %t12)
  %t16 = extractvalue { i32, i64 } %t15, 1
  %t17 = extractvalue { i32, i64 } %t15, 0
  store i32 %t17, ptr %l22
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb3, label %ok.19
ok.19:
  store i64 %t16, ptr %l21
  br label %bb2
bb2:
  %t20 = load i64, ptr %l21, !tbaa !24
  store i64 %t20, ptr %l17, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t21 = load i64, ptr %l17, !tbaa !24
  store i64 %t21, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l5, !tbaa !24
  %t24 = icmp sge i64 %t22, 0
  br i1 %t24, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb8
bb7:
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t28 = getelementptr %"compiler/check:frame", ptr %t26, i32 0, i32 19
  %t29 = load i64, ptr %t28, !tbaa !24
  %t31 = icmp slt i64 %t29, 0
  store i1 %t31, ptr %l25, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l25, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t34 = load i64, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t34, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load ptr, ptr %l4, !tbaa !29
  %t39 = getelementptr %"compiler/check:frame", ptr %t37, i32 0, i32 19
  %t40 = load i64, ptr %t39, !tbaa !24
  %t41 = load i32, ptr %l2, !tbaa !23
  %t42 = load %"compiler/source:Span", ptr %l3
  %t47 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaptureIn(ptr %v0, ptr %t36, i64 %t40, i32 %t41, %"compiler/source:Span" %t42)
  store i64 %t47, ptr %l35
  br label %bb12
bb12:
  %t48 = load i64, ptr %l35, !tbaa !24
  store i64 %t48, ptr %l6, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t51 = icmp slt i64 %t49, 0
  br i1 %t51, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 10
  store ptr %t56, ptr %l40, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 12
  %t60 = load ptr, ptr %l4, !tbaa !29
  %t62 = getelementptr %"compiler/check:frame", ptr %t60, i32 0, i32 19
  %t63 = load i64, ptr %t62, !tbaa !24
  %t66 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_Hbcd822ae67306ca6a025f17ed2cfb61c(ptr %v0, ptr %v0, ptr %t59, i64 %t63)
  store ptr %t66, ptr %l45
  br label %bb16
bb16:
  %t67 = load ptr, ptr %l45, !tbaa !29
  %t69 = getelementptr %"compiler/check:frame", ptr %t67, i32 0, i32 0
  %t70 = load i64, ptr %t69, !tbaa !24
  %t71 = load ptr, ptr %l40, !tbaa !29
  %t73 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t71, i64 %t70)
  store ptr %t73, ptr %l48
  br label %bb17
bb17:
  %t74 = load ptr, ptr %l48, !tbaa !29
  %t76 = getelementptr %"compiler/typed:Body", ptr %t74, i32 0, i32 7
  %t77 = load i64, ptr %l6, !tbaa !24
  %t80 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t76, i64 %t77)
  store %"compiler/typed:Local" %t80, ptr %l52
  br label %bb18
bb18:
  %t81 = getelementptr %"compiler/typed:Local", ptr %l52, i32 0, i32 2
  %t82 = load i32, ptr %t81, !tbaa !23
  store i32 %t82, ptr %l7, !tbaa !23
  %t84 = load %"compiler/source:Span", ptr %l3
  %t85 = load i32, ptr %l7, !tbaa !23
  %t86 = load i64, ptr %l6, !tbaa !24
  %t88 = trunc i64 %t86 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t90
  %t91 = getelementptr { i64, [4 x i64] }, ptr %t90, i32 0, i32 0
  store i64 0, ptr %t91
  %t93 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t84, 0
  %t95 = insertvalue { %"compiler/source:Span", i32, i32 } %t93, i32 %t85, 1
  %t97 = insertvalue { %"compiler/source:Span", i32, i32 } %t95, i32 %t88, 2
  %t98 = getelementptr { i64, [4 x i64] }, ptr %t90, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t97, ptr %t98
  %t99 = load { i64, [4 x i64] }, ptr %t90
  %t101 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t99, ptr %t101
  store ptr %t101, ptr %l8, !tbaa !29
  %t103 = load i32, ptr %l7, !tbaa !23
  store i32 %t103, ptr %l9, !tbaa !23
  store ptr null, ptr %l10, !tbaa !29
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load i32, ptr %l7, !tbaa !23
  %t109 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t105, i32 %t106)
  store i1 %t109, ptr %l64
  br label %bb19
bb19:
  %t110 = load i1, ptr %l64, !tbaa !21
  %t111 = xor i1 %t110, true
  br i1 %t111, label %bb20, label %bb21
bb20:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load i32, ptr %l7, !tbaa !23
  %t117 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t113, i32 %t114)
  store i32 %t117, ptr %l69
  br label %bb22
bb21:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb23
bb22:
  %t118 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t119 = load i32, ptr %l69, !tbaa !23
  %t121 = icmp ne i32 %t119, %t118
  store i1 %t121, ptr %l66, !tbaa !21
  br label %bb23
bb23:
  %t123 = load i1, ptr %l66, !tbaa !21
  br i1 %t123, label %bb24, label %bb25
bb24:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/check:Checker", ptr %t124, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !29
  %t129 = getelementptr %"compiler/generic:Program", ptr %t127, i32 0, i32 2
  %t130 = load i32, ptr %l7, !tbaa !23
  %t131 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t135 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t129, i32 %t130, i64 %t131)
  store i32 %t135, ptr %l77
  br label %bb26
bb25:
  %t136 = load %"compiler/source:Span", ptr %l3
  %t137 = load i32, ptr %l7, !tbaa !23
  %t138 = load ptr, ptr %l8, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t139
  %t140 = getelementptr { i64, [5 x i64] }, ptr %t139, i32 0, i32 0
  store i64 2, ptr %t140
  %t142 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } undef, %"compiler/source:Span" %t136, 0
  %t144 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t142, i32 %t137, 1
  %t146 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t144, ptr %t138, 2
  %t147 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t146, i32 -1, 3
  %t148 = getelementptr { i64, [5 x i64] }, ptr %t139, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i32 } %t147, ptr %t148
  %t149 = load { i64, [5 x i64] }, ptr %t139
  %t151 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t149, ptr %t151
  store ptr %t151, ptr %l10, !tbaa !29
  br label %bb27
bb26:
  %t153 = load i32, ptr %l77, !tbaa !23
  store i32 %t153, ptr %l9, !tbaa !23
  %t154 = load %"compiler/source:Span", ptr %l3
  %t155 = load i32, ptr %l9, !tbaa !23
  %t156 = load ptr, ptr %l8, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t157
  %t158 = getelementptr { i64, [5 x i64] }, ptr %t157, i32 0, i32 0
  store i64 3, ptr %t158
  %t160 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t154, 0
  %t162 = insertvalue { %"compiler/source:Span", i32, ptr } %t160, i32 %t155, 1
  %t164 = insertvalue { %"compiler/source:Span", i32, ptr } %t162, ptr %t156, 2
  %t165 = getelementptr { i64, [5 x i64] }, ptr %t157, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t164, ptr %t165
  %t166 = load { i64, [5 x i64] }, ptr %t157
  %t168 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t166, ptr %t168
  store ptr %t168, ptr %l10, !tbaa !29
  br label %bb27
bb27:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/check:Checker", ptr %t170, i32 0, i32 10
  %t173 = load ptr, ptr %l4, !tbaa !29
  %t175 = getelementptr %"compiler/check:frame", ptr %t173, i32 0, i32 0
  %t176 = load i64, ptr %t175, !tbaa !24
  %t179 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t172, i64 %t176)
  store ptr %t179, ptr %l92
  br label %bb28
bb28:
  %t180 = load ptr, ptr %l92, !tbaa !29
  store ptr %t180, ptr %l11, !tbaa !29
  %t181 = load ptr, ptr %l11, !tbaa !29
  store ptr %t181, ptr %l93, !tbaa !29
  %t182 = load i32, ptr %l2, !tbaa !23
  %t183 = load %"compiler/source:Span", ptr %l3
  %t184 = load i32, ptr %l9, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t185
  %t186 = getelementptr { i64, [2 x i64] }, ptr %t185, i32 0, i32 0
  store i64 5, ptr %t186
  %t187 = load { i64, [2 x i64] }, ptr %t185
  %t193 = call %"compiler/typed:Local" @compiler_2ftyped_3aLocal_2ector(ptr %s0, i32 %t182, %"compiler/source:Span" %t183, i32 %t184, i32 0, i32 5, { i64, [2 x i64] } %t187)
  store %"compiler/typed:Local" %t193, ptr %l99
  br label %bb29
bb29:
  %t194 = load ptr, ptr %l93, !tbaa !29
  %t195 = load %"compiler/typed:Local", ptr %l99
  %t196 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddLocal(ptr %v0, ptr %t194, %"compiler/typed:Local" %t195)
  store i32 %t196, ptr %l100
  br label %bb30
bb30:
  %t197 = load i32, ptr %l100, !tbaa !23
  %t198 = sext i32 %t197 to i64
  store i64 %t198, ptr %l12, !tbaa !24
  %t200 = load ptr, ptr %l4, !tbaa !29
  %t202 = getelementptr %"compiler/check:frame", ptr %t200, i32 0, i32 8
  %t203 = load i32, ptr %l2, !tbaa !23
  %t204 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %t202, i32 %t203, i64 %t204)
  br label %bb31
bb31:
  %t208 = load ptr, ptr %l4, !tbaa !29
  %t210 = getelementptr %"compiler/check:frame", ptr %t208, i32 0, i32 25
  store ptr %t210, ptr %l107, !tbaa !29
  %t211 = load i64, ptr %l12, !tbaa !24
  %t213 = trunc i64 %t211 to i32
  store i32 %t213, ptr %l110, !tbaa !23
  %t215 = load ptr, ptr %l10, !tbaa !29
  %t217 = icmp eq ptr %t215, null
  br i1 %t217, label %bb32, label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_486b3db7a819736b_b4c2afa2fe5bd5af)
  unreachable
bb33:
  br label %bb34
bb34:
  %t219 = load ptr, ptr %l10, !tbaa !29
  %t220 = load i32, ptr %l110, !tbaa !23
  %t222 = call %"compiler/typed:Capture" @compiler_2ftyped_3aCapture_2ector(ptr %v0, ptr %v0, i32 %t220, ptr %t219)
  store %"compiler/typed:Capture" %t222, ptr %l114
  br label %bb35
bb35:
  %t223 = load %"compiler/typed:Capture", ptr %l114
  %t224 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store %"compiler/typed:Capture" %t223, ptr %t224
  %t225 = load ptr, ptr %l107, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aCapture_26_3e_2e_He39a1cf375adb47168dea91a05758aa9(ptr %v0, ptr %v0, ptr %t225, ptr %t224)
  br label %bb36
bb36:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = load i32, ptr %l9, !tbaa !23
  %t231 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t227, i32 %t228)
  store i1 %t231, ptr %l118
  br label %bb37
bb37:
  %t232 = load i1, ptr %l118, !tbaa !21
  br i1 %t232, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l119, !tbaa !21
  br label %bb41
bb39:
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t235 = getelementptr %"compiler/check:Checker", ptr %t233, i32 0, i32 1
  %t236 = load ptr, ptr %t235, !tbaa !29
  %t238 = getelementptr %"compiler/generic:Program", ptr %t236, i32 0, i32 2
  %t239 = load i32, ptr %l9, !tbaa !23
  %t242 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t238, i32 %t239)
  store i1 %t242, ptr %l124
  br label %bb40
bb40:
  %t243 = load i1, ptr %l124, !tbaa !21
  store i1 %t243, ptr %l119, !tbaa !21
  br label %bb41
bb41:
  %t244 = load i1, ptr %l119, !tbaa !21
  br i1 %t244, label %bb42, label %bb43
bb42:
  %t245 = load ptr, ptr %l11, !tbaa !29
  %t247 = getelementptr %"compiler/typed:Body", ptr %t245, i32 0, i32 6
  %t248 = load i64, ptr %l12, !tbaa !24
  %t250 = trunc i64 %t248 to i32
  store { i64, [1 x i64] } zeroinitializer, ptr %t252
  %t253 = getelementptr { i64, [1 x i64] }, ptr %t252, i32 0, i32 0
  store i64 4, ptr %t253
  %t255 = insertvalue { i32 } undef, i32 %t250, 0
  %t256 = getelementptr { i64, [1 x i64] }, ptr %t252, i32 0, i32 1
  store { i32 } %t255, ptr %t256
  %t257 = load { i64, [1 x i64] }, ptr %t252
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2ePu_Hdbf2db28b3dbd7714059bb41361f5f89(ptr %v0, ptr %t247, { i64, [1 x i64] } %t257)
  br label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb45
bb45:
  %t260 = load i64, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t260, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecapturedValue(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i1
  %l24 = alloca ptr
  %l26 = alloca %"compiler/typed:Local"
  %l32 = alloca ptr
  %l35 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca i32
  %l48 = alloca { i64, ptr }
  %l57 = alloca i1
  %l58 = alloca ptr
  %l59 = alloca i1
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fcheck_2eunwrapped(ptr %v1, ptr %a1)
  store ptr %t3, ptr %l12
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l12, !tbaa !29
  %t5 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v1, ptr %t4)
  store ptr %t5, ptr %l13
  br label %bb2
bb2:
  %t6 = load ptr, ptr %l13, !tbaa !29
  store ptr %t6, ptr %l2, !tbaa !29
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb3, label %bb4
bb3:
  store i1 false, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t12 = load ptr, ptr %l2, !tbaa !29
  store ptr %t12, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t13 = load ptr, ptr %l17, !tbaa !29
  %t14 = icmp ne ptr %t13, null
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t16 = load ptr, ptr %l17, !tbaa !29
  %t17 = load i64, ptr %t16
  %t19 = icmp eq i64 %t17, 0
  store i1 %t19, ptr %l18, !tbaa !21
  br label %bb7
bb7:
  %t20 = load i1, ptr %l18, !tbaa !21
  br i1 %t20, label %bb8, label %bb9
bb8:
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr { i64, [4 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t23, i32 0, i32 2
  %t25 = load i32, ptr %t24
  store i32 %t25, ptr %l3, !tbaa !23
  br label %bb10
bb9:
  br label %bb46
bb10:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t27)
  store ptr %t29, ptr %l24
  br label %bb11
bb11:
  %t30 = load i32, ptr %l3, !tbaa !23
  %t31 = load ptr, ptr %l24, !tbaa !29
  %t33 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t31, i32 %t30)
  store %"compiler/typed:Local" %t33, ptr %l26
  br label %bb12
bb12:
  %t34 = getelementptr %"compiler/typed:Local", ptr %l26, i32 0, i32 4
  %t35 = load i32, ptr %t34
  %t37 = trunc i64 5 to i32
  %t38 = icmp eq i32 %t35, %t37
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb13, label %bb14
bb13:
  store i1 false, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t43)
  store ptr %t45, ptr %l32
  br label %bb16
bb16:
  %t46 = load ptr, ptr %l32, !tbaa !29
  %t48 = getelementptr %"compiler/check:frame", ptr %t46, i32 0, i32 25
  store ptr %t48, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s5
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aCapture_26_3e_2e_H29428d146645d03428956d524c855061(ptr %v0, ptr %t50, i64 %t51)
  %t55 = extractvalue { i32, { i64, ptr } } %t54, 1
  %t56 = extractvalue { i32, { i64, ptr } } %t54, 0
  store i32 %t56, ptr %l39
  %t57 = icmp ne i32 %t56, 0
  br i1 %t57, label %bb19, label %ok.58
ok.58:
  store { i64, ptr } %t55, ptr %l38
  br label %bb18
bb18:
  %t59 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t59, ptr %l35, !tbaa !27
  br label %bb23
bb19:
  %t60 = load i32, ptr %l39, !tbaa !23
  %t61 = ashr i32 %t60, 16
  %t63 = icmp eq i32 %t61, 1
  br i1 %t63, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_3fa0bc2758d24028_39c102aa9b869b2c)
  unreachable
bb22:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s5)
  br label %bb45
bb23:
  %t65 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t65, ptr %l6, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t66, 0
  store i64 %t68, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s6
  %t70 = load i64, ptr %l8, !tbaa !24
  %t71 = load i64, ptr %l7, !tbaa !24
  %t74 = icmp slt i64 %t70, %t71
  %t76 = xor i1 %t74, true
  br i1 %t76, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s6)
  br label %bb43
bb26:
  br label %bb27
bb27:
  %t78 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t78, ptr %l48, !tbaa !27
  %t79 = load i64, ptr %l8, !tbaa !24
  %t81 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr ptr, ptr %t82, i64 %t79
  %t84 = load ptr, ptr %t83, !tbaa !39
  store ptr %t84, ptr %l9, !tbaa !29
  %t86 = load ptr, ptr %l9, !tbaa !29
  %t88 = getelementptr %"compiler/typed:Capture", ptr %t86, i32 0, i32 0
  %t89 = load i32, ptr %t88, !tbaa !23
  %t90 = load i32, ptr %l3, !tbaa !23
  %t93 = icmp ne i32 %t89, %t90
  br i1 %t93, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s6)
  br label %bb42
bb29:
  br label %bb30
bb30:
  %t95 = load ptr, ptr %l9, !tbaa !29
  %t97 = getelementptr %"compiler/typed:Capture", ptr %t95, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !29
  store ptr %t98, ptr %l58, !tbaa !29
  store i1 false, ptr %l59, !tbaa !21
  %t101 = load ptr, ptr %l58, !tbaa !29
  %t102 = icmp ne ptr %t101, null
  br i1 %t102, label %bb31, label %bb32
bb31:
  %t104 = load ptr, ptr %l58, !tbaa !29
  %t105 = load i64, ptr %t104
  %t107 = icmp eq i64 %t105, 3
  store i1 %t107, ptr %l59, !tbaa !21
  br label %bb32
bb32:
  %t108 = load i1, ptr %l59, !tbaa !21
  br i1 %t108, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store i1 true, ptr %l57, !tbaa !21
  br label %bb41
bb36:
  br i1 true, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_386bb7dc57d3fef9_468931e243621ddd)
  unreachable
bb41:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  %t109 = load i1, ptr %l57, !tbaa !21
  store i1 %t109, ptr %rv
  br label %ret
bb42:
  %t110 = load i64, ptr %l8, !tbaa !24
  %t112 = add i64 %t110, 1
  store i64 %t112, ptr %l8, !tbaa !24
  br label %bb24
bb43:
  %t114 = load i64, ptr %l5, !tbaa !24
  %t115 = load i64, ptr %l7, !tbaa !24
  %t118 = add i64 %t114, %t115
  store i64 %t118, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb44
bb44:
  br label %bb17
bb45:
  br label %bb47
bb46:
  br label %bb47
bb47:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseName(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l6 = alloca %"compiler/names:Ref"
  %l7 = alloca ptr
  %l8 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l29 = alloca ptr
  %l31 = alloca ptr
  %l35 = alloca %"compiler/names:Ref"
  %l38 = alloca ptr
  %l39 = alloca %"compiler/source:Span"
  %l42 = alloca { i64, ptr }
  %l44 = alloca %"compiler/msgs:Msg"
  %l45 = alloca i64
  %l47 = alloca ptr
  %l49 = alloca ptr
  %l54 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l58 = alloca i1
  %l61 = alloca i1
  %l64 = alloca i64
  %l67 = alloca ptr
  %l68 = alloca %"compiler/source:Span"
  %l71 = alloca { i64, ptr }
  %l73 = alloca %"compiler/msgs:Msg"
  %l74 = alloca i64
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l3, !tbaa !29
  br label %bb9
bb4:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 4
  store i1 %t23, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l14, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", ptr }, ptr %t27, i32 0, i32 1
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l3, !tbaa !29
  br label %bb9
bb8:
  br label %bb41
bb9:
  %t31 = load ptr, ptr %l3, !tbaa !29
  store ptr %t31, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t32 = load ptr, ptr %l19, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb10, label %bb11
bb10:
  %t35 = load ptr, ptr %l19, !tbaa !29
  %t36 = load i64, ptr %t35
  %t38 = icmp eq i64 %t36, 0
  store i1 %t38, ptr %l20, !tbaa !21
  br label %bb11
bb11:
  %t39 = load i1, ptr %l20, !tbaa !21
  br i1 %t39, label %bb12, label %bb13
bb12:
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t42 = getelementptr { i64, [5 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32 }, ptr %t42, i32 0, i32 0
  %t44 = load %"compiler/source:Span", ptr %t43
  store %"compiler/source:Span" %t44, ptr %l4
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t48 = getelementptr { i64, [5 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", i32 }, ptr %t48, i32 0, i32 1
  %t50 = load i32, ptr %t49
  store i32 %t50, ptr %l5, !tbaa !23
  br label %bb14
bb13:
  br label %bb39
bb14:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = getelementptr %"compiler/generic:Program", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  store ptr %t58, ptr %l29, !tbaa !29
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t59)
  store ptr %t61, ptr %l31
  br label %bb15
bb15:
  %t62 = load ptr, ptr %l31, !tbaa !29
  %t64 = getelementptr %"compiler/check:frame", ptr %t62, i32 0, i32 2
  %t65 = load i64, ptr %t64, !tbaa !24
  %t66 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 0
  %t67 = load i32, ptr %t66, !tbaa !23
  %t68 = load ptr, ptr %l29, !tbaa !29
  %t71 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t68, i64 %t65, i32 %t67)
  store %"compiler/names:Ref" %t71, ptr %l35
  br label %bb16
bb16:
  %t72 = load %"compiler/names:Ref", ptr %l35
  store %"compiler/names:Ref" %t72, ptr %l6
  %t73 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 0
  %t74 = load i32, ptr %t73
  %t76 = trunc i64 0 to i32
  %t77 = icmp eq i32 %t74, %t76
  br i1 %t77, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l38, !tbaa !29
  %t80 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t80, ptr %l39
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load i32, ptr %l5, !tbaa !23
  %t85 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s3, ptr %t81, i32 %t82)
  store { i64, ptr } %t85, ptr %l42
  br label %bb19
bb18:
  br label %bb25
bb19:
  %t86 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 0
  %t88 = extractvalue { i64, ptr } %t86, 1
  %t89 = mul i64 %t87, 1
  %t90 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t89)
  call void @llvm.memcpy.p0.p0.i64(ptr %t90, ptr %t88, i64 %t89, i1 false)
  %t91 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t90, 1
  %t94 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseUnknownName(ptr %s3, ptr %s3, { i64, ptr } %t92)
  store %"compiler/msgs:Msg" %t94, ptr %l44
  br label %bb20
bb20:
  %t95 = load ptr, ptr %l38, !tbaa !29
  %t96 = load %"compiler/source:Span", ptr %l39
  %t97 = load %"compiler/msgs:Msg", ptr %l44
  %t98 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t95, %"compiler/source:Span" %t96, %"compiler/msgs:Msg" %t97)
  store i64 %t98, ptr %l45
  br label %bb21
bb21:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/check:Checker", ptr %t99, i32 0, i32 68
  store ptr %t101, ptr %l47, !tbaa !29
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t102)
  store ptr %t104, ptr %l49
  br label %bb22
bb22:
  %t105 = load ptr, ptr %l49, !tbaa !29
  %t107 = getelementptr %"compiler/check:frame", ptr %t105, i32 0, i32 0
  %t108 = load i64, ptr %t107, !tbaa !24
  %t109 = load i32, ptr %l5, !tbaa !23
  %t111 = sext i32 %t109 to i64
  %t114 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s3, i64 %t108, i64 %t111)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t114, ptr %l54
  br label %bb23
bb23:
  %t115 = load ptr, ptr %l47, !tbaa !29
  %t116 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l54
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t115, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t116, i1 true)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb25:
  %t118 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 0
  %t119 = load i32, ptr %t118
  %t121 = trunc i64 1 to i32
  %t122 = icmp eq i32 %t119, %t121
  br i1 %t122, label %bb26, label %bb27
bb26:
  %t124 = load i64, ptr %l2, !tbaa !24
  %t126 = icmp sge i64 %t124, 0
  store i1 %t126, ptr %l58, !tbaa !21
  br label %bb28
bb27:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb28
bb28:
  %t128 = load i1, ptr %l58, !tbaa !21
  br i1 %t128, label %bb29, label %bb30
bb29:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load i32, ptr %l5, !tbaa !23
  %t133 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %t129, i32 %t130)
  store i64 %t133, ptr %l64
  br label %bb31
bb30:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb32
bb31:
  %t134 = load i64, ptr %l2, !tbaa !24
  %t135 = load i64, ptr %l64, !tbaa !24
  %t137 = icmp eq i64 %t135, %t134
  store i1 %t137, ptr %l61, !tbaa !21
  br label %bb32
bb32:
  %t139 = load i1, ptr %l61, !tbaa !21
  br i1 %t139, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s4
  %t140 = load ptr, ptr %l0, !tbaa !29
  store ptr %t140, ptr %l67, !tbaa !29
  %t141 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t141, ptr %l68
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load i32, ptr %l5, !tbaa !23
  %t146 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s4, ptr %t142, i32 %t143)
  store { i64, ptr } %t146, ptr %l71
  br label %bb35
bb34:
  br label %bb38
bb35:
  %t147 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t147, 0
  %t149 = extractvalue { i64, ptr } %t147, 1
  %t150 = mul i64 %t148, 1
  %t151 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t150)
  call void @llvm.memcpy.p0.p0.i64(ptr %t151, ptr %t149, i64 %t150, i1 false)
  %t152 = insertvalue { i64, ptr } undef, i64 %t148, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr %t151, 1
  %t155 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseIsSubject(ptr %s4, ptr %s4, { i64, ptr } %t153)
  store %"compiler/msgs:Msg" %t155, ptr %l73
  br label %bb36
bb36:
  %t156 = load ptr, ptr %l67, !tbaa !29
  %t157 = load %"compiler/source:Span", ptr %l68
  %t158 = load %"compiler/msgs:Msg", ptr %l73
  %t159 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t156, %"compiler/source:Span" %t157, %"compiler/msgs:Msg" %t158)
  store i64 %t159, ptr %l74
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s4)
  store i1 true, ptr %rv
  br label %ret
bb38:
  br label %bb40
bb39:
  br label %bb40
bb40:
  br label %bb42
bb41:
  br label %bb42
bb42:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echain(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %lp5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca i32
  %l34 = alloca i32
  %l35 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i64
  %l38 = alloca ptr
  %l41 = alloca i64
  %l45 = alloca i64
  %l52 = alloca i64
  %l55 = alloca i64
  %l73 = alloca i64
  %l76 = alloca { i64, ptr }
  %l80 = alloca %"compiler/check:litv"
  %l84 = alloca i64
  %l91 = alloca i64
  %l94 = alloca i64
  %l112 = alloca i64
  %l115 = alloca { i64, ptr }
  %l118 = alloca i1
  %l122 = alloca ptr
  %l125 = alloca ptr
  %l127 = alloca ptr
  %l128 = alloca ptr
  %l131 = alloca { i64, ptr }
  %l136 = alloca ptr
  %l138 = alloca { i64, ptr }
  %l141 = alloca %"compiler/source:Span"
  %l142 = alloca ptr
  %l149 = alloca i64
  %l152 = alloca i64
  %l173 = alloca i1
  %l180 = alloca i64
  %l183 = alloca i64
  %l205 = alloca i1
  %l219 = alloca i1
  %l231 = alloca { i64, ptr }
  %l237 = alloca ptr
  %l240 = alloca i64
  %l241 = alloca ptr
  %l246 = alloca ptr
  %l248 = alloca %"compiler/source:Span"
  %l249 = alloca ptr
  %l255 = alloca ptr
  %l257 = alloca i32
  %l260 = alloca i1
  %l261 = alloca i32
  %l264 = alloca i32
  %l269 = alloca i1
  %l270 = alloca ptr
  %l271 = alloca ptr
  %l273 = alloca ptr
  %l275 = alloca i32
  %l278 = alloca ptr
  %l280 = alloca %"compiler/source:Span"
  %l281 = alloca ptr
  %l285 = alloca i64
  %l290 = alloca ptr
  %l291 = alloca ptr
  %l293 = alloca { i64, ptr }
  %l296 = alloca %"compiler/source:Span"
  %l298 = alloca { i64, ptr }
  %l302 = alloca %"compiler/source:Span"
  %l304 = alloca { i64, ptr }
  %l307 = alloca { i64, ptr }
  %l309 = alloca %"compiler/source:Span"
  %l310 = alloca i32
  %l313 = alloca i32
  %l314 = alloca i1
  %l323 = alloca ptr
  %l324 = alloca %"compiler/source:Span"
  %l325 = alloca ptr
  %l326 = alloca i64
  %l327 = alloca { i64, ptr }
  %l329 = alloca ptr
  %l333 = alloca ptr
  %l335 = alloca ptr
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 31
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l41
  br label %bb1
bb1:
  %t6 = load i64, ptr %l41, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = getelementptr %"compiler/ast:Chain", ptr %t7, i32 0, i32 1
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  store i64 %t14, ptr %l45, !tbaa !24
  %t15 = load i64, ptr %l45, !tbaa !24
  %t16 = icmp sge i64 %t15, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = load i64, ptr %l45, !tbaa !24
  %t19 = mul i64 %t18, 1
  %t20 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t23 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t23, ptr %lp5
  %t25 = load ptr, ptr %lp5
  store { i64, ptr } %t22, ptr %t25, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t26 = load i64, ptr %l4, !tbaa !24
  store i64 %t26, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t28 = load i64, ptr %l7, !tbaa !24
  %t29 = load i64, ptr %l6, !tbaa !24
  %t32 = icmp sgt i64 %t28, %t29
  br i1 %t32, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_514ceade83978a4d_1843f44cd2570191)
  unreachable
bb4:
  %t34 = load i64, ptr %l8, !tbaa !24
  %t36 = icmp sgt i64 %t34, 0
  br i1 %t36, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l52, !tbaa !24
  br label %bb9
bb6:
  %t38 = load i64, ptr %l7, !tbaa !24
  %t39 = load i64, ptr %l6, !tbaa !24
  %t42 = sub i64 %t38, %t39
  %t43 = load i64, ptr %l8, !tbaa !24
  %t46 = add i64 %t42, %t43
  %t48 = sub i64 %t46, 1
  %t49 = load i64, ptr %l8, !tbaa !24
  %t52 = sdiv i64 %t48, %t49
  store i64 %t52, ptr %l55, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l55, !tbaa !24
  br label %bb8
bb8:
  %t54 = load i64, ptr %l55, !tbaa !24
  store i64 %t54, ptr %l52, !tbaa !24
  br label %bb9
bb9:
  %t55 = load i64, ptr %l52, !tbaa !24
  store i64 %t55, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t56 = load i64, ptr %l10, !tbaa !24
  %t57 = load i64, ptr %l9, !tbaa !24
  %t60 = icmp slt i64 %t56, %t57
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb12:
  br label %bb13
bb13:
  %t64 = load i64, ptr %l6, !tbaa !24
  %t65 = load i64, ptr %l10, !tbaa !24
  %t66 = load i64, ptr %l8, !tbaa !24
  %t69 = mul i64 %t65, %t66
  %t72 = add i64 %t64, %t69
  store i64 %t72, ptr %l11, !tbaa !24
  %t74 = load i64, ptr %l11, !tbaa !24
  store i64 %t74, ptr %l73, !tbaa !24
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load ptr, ptr %l2, !tbaa !29
  %t78 = getelementptr %"compiler/ast:Chain", ptr %t76, i32 0, i32 1
  %t79 = load { i64, ptr }, ptr %t78, !tbaa !27
  store { i64, ptr } %t79, ptr %l76, !tbaa !27
  %t80 = load i64, ptr %l11, !tbaa !24
  %t82 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr ptr, ptr %t83, i64 %t80
  %t85 = load ptr, ptr %t84, !tbaa !39
  %t89 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t75, ptr %t85)
  store %"compiler/check:litv" %t89, ptr %l80
  br label %bb14
bb14:
  %t90 = getelementptr %"compiler/check:litv", ptr %l80, i32 0, i32 0
  %t91 = load i1, ptr %t90, !tbaa !21
  %t93 = load ptr, ptr %lp5
  %t94 = load i64, ptr %l73, !tbaa !24
  %t95 = getelementptr { i64, ptr }, ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr i1, ptr %t96, i64 %t94
  store i1 %t91, ptr %t97, !tbaa !31
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  %t98 = load i64, ptr %l10, !tbaa !24
  %t100 = add i64 %t98, 1
  store i64 %t100, ptr %l10, !tbaa !24
  br label %bb10
bb16:
  %t102 = load i64, ptr %l4, !tbaa !24
  store i64 %t102, ptr %l84, !tbaa !24
  %t103 = load i64, ptr %l84, !tbaa !24
  %t104 = icmp sge i64 %t103, 0
  br i1 %t104, label %bb17, label %bb18
bb17:
  %t106 = load i64, ptr %l84, !tbaa !24
  %t107 = mul i64 %t106, 1
  %t108 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t107)
  %t109 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t108, 1
  store { i64, ptr } %t110, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t112 = load i64, ptr %l4, !tbaa !24
  store i64 %t112, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t114 = load i64, ptr %l14, !tbaa !24
  %t115 = load i64, ptr %l13, !tbaa !24
  %t118 = icmp sgt i64 %t114, %t115
  br i1 %t118, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_8bbd92ac148fb220_5a9ba8c1b178084)
  unreachable
bb19:
  %t120 = load i64, ptr %l15, !tbaa !24
  %t122 = icmp sgt i64 %t120, 0
  br i1 %t122, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l91, !tbaa !24
  br label %bb24
bb21:
  %t124 = load i64, ptr %l14, !tbaa !24
  %t125 = load i64, ptr %l13, !tbaa !24
  %t128 = sub i64 %t124, %t125
  %t129 = load i64, ptr %l15, !tbaa !24
  %t132 = add i64 %t128, %t129
  %t134 = sub i64 %t132, 1
  %t135 = load i64, ptr %l15, !tbaa !24
  %t138 = sdiv i64 %t134, %t135
  store i64 %t138, ptr %l94, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l94, !tbaa !24
  br label %bb23
bb23:
  %t140 = load i64, ptr %l94, !tbaa !24
  store i64 %t140, ptr %l91, !tbaa !24
  br label %bb24
bb24:
  %t141 = load i64, ptr %l91, !tbaa !24
  store i64 %t141, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s5
  %t142 = load i64, ptr %l17, !tbaa !24
  %t143 = load i64, ptr %l16, !tbaa !24
  %t146 = icmp slt i64 %t142, %t143
  %t148 = xor i1 %t146, true
  br i1 %t148, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s5)
  br label %bb40
bb27:
  br label %bb28
bb28:
  %t150 = load i64, ptr %l13, !tbaa !24
  %t151 = load i64, ptr %l17, !tbaa !24
  %t152 = load i64, ptr %l15, !tbaa !24
  %t155 = mul i64 %t151, %t152
  %t158 = add i64 %t150, %t155
  store i64 %t158, ptr %l18, !tbaa !24
  %t160 = load i64, ptr %l18, !tbaa !24
  store i64 %t160, ptr %l112, !tbaa !24
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load ptr, ptr %l2, !tbaa !29
  %t164 = getelementptr %"compiler/ast:Chain", ptr %t162, i32 0, i32 1
  %t165 = load { i64, ptr }, ptr %t164, !tbaa !27
  store { i64, ptr } %t165, ptr %l115, !tbaa !27
  %t166 = load i64, ptr %l18, !tbaa !24
  %t168 = getelementptr { i64, ptr }, ptr %l115, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !27
  %t170 = getelementptr ptr, ptr %t169, i64 %t166
  %t171 = load ptr, ptr %t170, !tbaa !39
  %t174 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t161, ptr %t171)
  store i1 %t174, ptr %l118
  br label %bb29
bb29:
  %t175 = load i1, ptr %l118, !tbaa !21
  %t176 = load i64, ptr %l112, !tbaa !24
  %t177 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = getelementptr i1, ptr %t178, i64 %t176
  store i1 %t175, ptr %t179, !tbaa !31
  %t180 = load i64, ptr %l18, !tbaa !24
  %t182 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !27
  %t184 = getelementptr i1, ptr %t183, i64 %t180
  %t185 = load i1, ptr %t184, !tbaa !31
  br i1 %t185, label %bb30, label %bb31
bb30:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/check:Checker", ptr %t187, i32 0, i32 31
  store ptr %t189, ptr %l122, !tbaa !29
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load %"compiler/source:Span", ptr %l1
  %t194 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t190, %"compiler/source:Span" %t191)
  store ptr %t194, ptr %l125
  br label %bb32
bb31:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/check:Checker", ptr %t195, i32 0, i32 31
  store ptr %t197, ptr %l127, !tbaa !29
  %t198 = load ptr, ptr %l0, !tbaa !29
  store ptr %t198, ptr %l128, !tbaa !29
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = load ptr, ptr %l2, !tbaa !29
  %t202 = getelementptr %"compiler/ast:Chain", ptr %t200, i32 0, i32 1
  %t203 = load { i64, ptr }, ptr %t202, !tbaa !27
  store { i64, ptr } %t203, ptr %l131, !tbaa !27
  %t204 = load i64, ptr %l18, !tbaa !24
  %t206 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t207 = load ptr, ptr %t206, !tbaa !27
  %t208 = getelementptr ptr, ptr %t207, i64 %t204
  %t209 = load ptr, ptr %t208, !tbaa !39
  %t211 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t215 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t199, ptr %t209, i32 %t211)
  store ptr %t215, ptr %l136
  br label %bb34
bb32:
  %t216 = load ptr, ptr %l122, !tbaa !29
  %t217 = load ptr, ptr %l125, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t216, ptr %t217)
  br label %bb33
bb33:
  br label %bb38
bb34:
  %t218 = load ptr, ptr %l2, !tbaa !29
  %t220 = getelementptr %"compiler/ast:Chain", ptr %t218, i32 0, i32 1
  %t221 = load { i64, ptr }, ptr %t220, !tbaa !27
  store { i64, ptr } %t221, ptr %l138, !tbaa !27
  %t222 = load i64, ptr %l18, !tbaa !24
  %t224 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !27
  %t226 = getelementptr ptr, ptr %t225, i64 %t222
  %t227 = load ptr, ptr %t226, !tbaa !39
  %t229 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t227)
  store %"compiler/source:Span" %t229, ptr %l141
  br label %bb35
bb35:
  %t230 = load ptr, ptr %l128, !tbaa !29
  %t231 = load ptr, ptr %l136, !tbaa !29
  %t232 = load %"compiler/source:Span", ptr %l141
  %t233 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t230, ptr %t231, %"compiler/source:Span" %t232)
  store ptr %t233, ptr %l142
  br label %bb36
bb36:
  %t234 = load ptr, ptr %l127, !tbaa !29
  %t235 = load ptr, ptr %l142, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t234, ptr %t235)
  br label %bb37
bb37:
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s5)
  br label %bb39
bb39:
  %t236 = load i64, ptr %l17, !tbaa !24
  %t238 = add i64 %t236, 1
  store i64 %t238, ptr %l17, !tbaa !24
  br label %bb25
bb40:
  store i64 0, ptr %l19, !tbaa !24
  %t240 = load i64, ptr %l4, !tbaa !24
  store i64 %t240, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t242 = load i64, ptr %l20, !tbaa !24
  %t243 = load i64, ptr %l19, !tbaa !24
  %t246 = icmp sgt i64 %t242, %t243
  br i1 %t246, label %bb41, label %bb42
bb41:
  %t248 = load i64, ptr %l21, !tbaa !24
  %t250 = icmp sgt i64 %t248, 0
  br i1 %t250, label %bb43, label %bb44
bb42:
  store i64 0, ptr %l149, !tbaa !24
  br label %bb46
bb43:
  %t252 = load i64, ptr %l20, !tbaa !24
  %t253 = load i64, ptr %l19, !tbaa !24
  %t256 = sub i64 %t252, %t253
  %t257 = load i64, ptr %l21, !tbaa !24
  %t260 = add i64 %t256, %t257
  %t262 = sub i64 %t260, 1
  %t263 = load i64, ptr %l21, !tbaa !24
  %t266 = sdiv i64 %t262, %t263
  store i64 %t266, ptr %l152, !tbaa !24
  br label %bb45
bb44:
  store i64 0, ptr %l152, !tbaa !24
  br label %bb45
bb45:
  %t268 = load i64, ptr %l152, !tbaa !24
  store i64 %t268, ptr %l149, !tbaa !24
  br label %bb46
bb46:
  %t269 = load i64, ptr %l149, !tbaa !24
  store i64 %t269, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb47
bb47:
  store %olang.scope zeroinitializer, ptr %s10
  %t270 = load i64, ptr %l23, !tbaa !24
  %t271 = load i64, ptr %l22, !tbaa !24
  %t274 = icmp slt i64 %t270, %t271
  %t276 = xor i1 %t274, true
  br i1 %t276, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s10)
  br label %bb116
bb49:
  br label %bb50
bb50:
  %t278 = load i64, ptr %l19, !tbaa !24
  %t279 = load i64, ptr %l23, !tbaa !24
  %t280 = load i64, ptr %l21, !tbaa !24
  %t283 = mul i64 %t279, %t280
  %t286 = add i64 %t278, %t283
  store i64 %t286, ptr %l24, !tbaa !24
  %t288 = load i64, ptr %l24, !tbaa !24
  %t290 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t291 = load ptr, ptr %t290, !tbaa !27
  %t292 = getelementptr i1, ptr %t291, i64 %t288
  %t293 = load i1, ptr %t292, !tbaa !31
  %t295 = xor i1 %t293, true
  br i1 %t295, label %bb51, label %bb52
bb51:
  store i1 true, ptr %l173, !tbaa !21
  br label %bb53
bb52:
  %t297 = load i64, ptr %l24, !tbaa !24
  %t298 = load ptr, ptr %lp5
  %t300 = getelementptr { i64, ptr }, ptr %t298, i32 0, i32 1
  %t301 = load ptr, ptr %t300, !tbaa !27
  %t302 = getelementptr i1, ptr %t301, i64 %t297
  %t303 = load i1, ptr %t302, !tbaa !31
  store i1 %t303, ptr %l173, !tbaa !21
  br label %bb53
bb53:
  %t305 = load i1, ptr %l173, !tbaa !21
  br i1 %t305, label %bb54, label %bb55
bb54:
  call void @__olang_scope_close(ptr %s10)
  br label %bb115
bb55:
  br label %bb56
bb56:
  store i64 -1, ptr %l25, !tbaa !24
  store i64 1, ptr %l26, !tbaa !24
  %t306 = load i64, ptr %l4, !tbaa !24
  store i64 %t306, ptr %l27, !tbaa !24
  store i64 1, ptr %l28, !tbaa !24
  %t308 = load i64, ptr %l27, !tbaa !24
  %t309 = load i64, ptr %l26, !tbaa !24
  %t312 = icmp sgt i64 %t308, %t309
  br i1 %t312, label %bb57, label %bb58
bb57:
  %t314 = load i64, ptr %l28, !tbaa !24
  %t316 = icmp sgt i64 %t314, 0
  br i1 %t316, label %bb59, label %bb60
bb58:
  store i64 0, ptr %l180, !tbaa !24
  br label %bb62
bb59:
  %t318 = load i64, ptr %l27, !tbaa !24
  %t319 = load i64, ptr %l26, !tbaa !24
  %t322 = sub i64 %t318, %t319
  %t323 = load i64, ptr %l28, !tbaa !24
  %t326 = add i64 %t322, %t323
  %t328 = sub i64 %t326, 1
  %t329 = load i64, ptr %l28, !tbaa !24
  %t332 = sdiv i64 %t328, %t329
  store i64 %t332, ptr %l183, !tbaa !24
  br label %bb61
bb60:
  store i64 0, ptr %l183, !tbaa !24
  br label %bb61
bb61:
  %t334 = load i64, ptr %l183, !tbaa !24
  store i64 %t334, ptr %l180, !tbaa !24
  br label %bb62
bb62:
  %t335 = load i64, ptr %l180, !tbaa !24
  store i64 %t335, ptr %l29, !tbaa !24
  store i64 0, ptr %l30, !tbaa !24
  br label %bb63
bb63:
  store %olang.scope zeroinitializer, ptr %s13
  %t336 = load i64, ptr %l30, !tbaa !24
  %t337 = load i64, ptr %l29, !tbaa !24
  %t340 = icmp slt i64 %t336, %t337
  %t342 = xor i1 %t340, true
  br i1 %t342, label %bb64, label %bb65
bb64:
  call void @__olang_scope_close(ptr %s13)
  br label %bb80
bb65:
  br label %bb66
bb66:
  %t344 = load i64, ptr %l26, !tbaa !24
  %t345 = load i64, ptr %l30, !tbaa !24
  %t346 = load i64, ptr %l28, !tbaa !24
  %t349 = mul i64 %t345, %t346
  %t352 = add i64 %t344, %t349
  store i64 %t352, ptr %l31, !tbaa !24
  %t354 = load i64, ptr %l24, !tbaa !24
  %t355 = load i64, ptr %l31, !tbaa !24
  %t358 = sub i64 %t354, %t355
  %t360 = icmp sge i64 %t358, 0
  br i1 %t360, label %bb67, label %bb68
bb67:
  %t362 = load i64, ptr %l24, !tbaa !24
  %t363 = load i64, ptr %l31, !tbaa !24
  %t366 = sub i64 %t362, %t363
  %t368 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t369 = load ptr, ptr %t368, !tbaa !27
  %t370 = getelementptr i1, ptr %t369, i64 %t366
  %t371 = load i1, ptr %t370, !tbaa !31
  %t373 = xor i1 %t371, true
  store i1 %t373, ptr %l205, !tbaa !21
  br label %bb69
bb68:
  store i1 false, ptr %l205, !tbaa !21
  br label %bb69
bb69:
  %t375 = load i1, ptr %l205, !tbaa !21
  br i1 %t375, label %bb70, label %bb71
bb70:
  %t376 = load i64, ptr %l24, !tbaa !24
  %t377 = load i64, ptr %l31, !tbaa !24
  %t380 = sub i64 %t376, %t377
  store i64 %t380, ptr %l25, !tbaa !24
  call void @__olang_scope_close(ptr %s13)
  br label %bb80
bb71:
  br label %bb72
bb72:
  %t382 = load i64, ptr %l24, !tbaa !24
  %t383 = load i64, ptr %l31, !tbaa !24
  %t386 = add i64 %t382, %t383
  %t387 = load i64, ptr %l4, !tbaa !24
  %t390 = icmp slt i64 %t386, %t387
  br i1 %t390, label %bb73, label %bb74
bb73:
  %t392 = load i64, ptr %l24, !tbaa !24
  %t393 = load i64, ptr %l31, !tbaa !24
  %t396 = add i64 %t392, %t393
  %t398 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t399 = load ptr, ptr %t398, !tbaa !27
  %t400 = getelementptr i1, ptr %t399, i64 %t396
  %t401 = load i1, ptr %t400, !tbaa !31
  %t403 = xor i1 %t401, true
  store i1 %t403, ptr %l219, !tbaa !21
  br label %bb75
bb74:
  store i1 false, ptr %l219, !tbaa !21
  br label %bb75
bb75:
  %t405 = load i1, ptr %l219, !tbaa !21
  br i1 %t405, label %bb76, label %bb77
bb76:
  %t406 = load i64, ptr %l24, !tbaa !24
  %t407 = load i64, ptr %l31, !tbaa !24
  %t410 = add i64 %t406, %t407
  store i64 %t410, ptr %l25, !tbaa !24
  call void @__olang_scope_close(ptr %s13)
  br label %bb80
bb77:
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s13)
  br label %bb79
bb79:
  %t412 = load i64, ptr %l30, !tbaa !24
  %t414 = add i64 %t412, 1
  store i64 %t414, ptr %l30, !tbaa !24
  br label %bb63
bb80:
  %t416 = load ptr, ptr %l2, !tbaa !29
  %t418 = getelementptr %"compiler/ast:Chain", ptr %t416, i32 0, i32 1
  %t419 = load { i64, ptr }, ptr %t418, !tbaa !27
  store { i64, ptr } %t419, ptr %l231, !tbaa !27
  %t420 = load i64, ptr %l24, !tbaa !24
  %t422 = getelementptr { i64, ptr }, ptr %l231, i32 0, i32 1
  %t423 = load ptr, ptr %t422, !tbaa !27
  %t424 = getelementptr ptr, ptr %t423, i64 %t420
  %t425 = load ptr, ptr %t424, !tbaa !39
  store ptr %t425, ptr %l32, !tbaa !29
  %t427 = load i64, ptr %l25, !tbaa !24
  %t429 = icmp slt i64 %t427, 0
  br i1 %t429, label %bb81, label %bb82
bb81:
  %t431 = load ptr, ptr %l0, !tbaa !29
  %t433 = getelementptr %"compiler/check:Checker", ptr %t431, i32 0, i32 31
  store ptr %t433, ptr %l237, !tbaa !29
  %t434 = load i64, ptr %l3, !tbaa !24
  %t435 = load i64, ptr %l24, !tbaa !24
  %t438 = add i64 %t434, %t435
  store i64 %t438, ptr %l240, !tbaa !24
  %t439 = load ptr, ptr %l0, !tbaa !29
  store ptr %t439, ptr %l241, !tbaa !29
  %t440 = load ptr, ptr %l0, !tbaa !29
  %t441 = load ptr, ptr %l32, !tbaa !29
  %t443 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t447 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t440, ptr %t441, i32 %t443)
  store ptr %t447, ptr %l246
  br label %bb83
bb82:
  br label %bb87
bb83:
  %t448 = load ptr, ptr %l32, !tbaa !29
  %t450 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t448)
  store %"compiler/source:Span" %t450, ptr %l248
  br label %bb84
bb84:
  %t451 = load ptr, ptr %l241, !tbaa !29
  %t452 = load ptr, ptr %l246, !tbaa !29
  %t453 = load %"compiler/source:Span", ptr %l248
  %t454 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t451, ptr %t452, %"compiler/source:Span" %t453)
  store ptr %t454, ptr %l249
  br label %bb85
bb85:
  %t455 = load ptr, ptr %l237, !tbaa !29
  %t456 = load i64, ptr %l240, !tbaa !24
  %t457 = load ptr, ptr %l249, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eSet_H7eb7f72699477ff6ed0f03fe599574de(ptr %v0, ptr %v0, ptr %t455, i64 %t456, ptr %t457)
  br label %bb86
bb86:
  call void @__olang_scope_close(ptr %s10)
  br label %bb115
bb87:
  %t458 = load ptr, ptr %l0, !tbaa !29
  %t460 = getelementptr %"compiler/check:Checker", ptr %t458, i32 0, i32 31
  %t461 = load i64, ptr %l3, !tbaa !24
  %t462 = load i64, ptr %l25, !tbaa !24
  %t465 = add i64 %t461, %t462
  %t468 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %s10, ptr %t460, i64 %t465)
  store ptr %t468, ptr %l255
  br label %bb88
bb88:
  %t469 = load ptr, ptr %l255, !tbaa !29
  %t471 = call i32 @compiler_2fcheck_2etypeOf(ptr %s10, ptr %t469)
  store i32 %t471, ptr %l257
  br label %bb89
bb89:
  %t472 = load i32, ptr %l257, !tbaa !23
  store i32 %t472, ptr %l33, !tbaa !23
  %t473 = load ptr, ptr %l0, !tbaa !29
  %t474 = load i32, ptr %l33, !tbaa !23
  %t477 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t473, i32 %t474)
  store i1 %t477, ptr %l260
  br label %bb90
bb90:
  %t478 = load i1, ptr %l260, !tbaa !21
  br i1 %t478, label %bb91, label %bb92
bb91:
  %t479 = load ptr, ptr %l0, !tbaa !29
  %t480 = load i32, ptr %l33, !tbaa !23
  %t483 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralBeside(ptr %v0, ptr %t479, i32 %t480)
  store i32 %t483, ptr %l264
  br label %bb93
bb92:
  %t484 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t484, ptr %l261, !tbaa !23
  br label %bb94
bb93:
  %t486 = load i32, ptr %l264, !tbaa !23
  store i32 %t486, ptr %l261, !tbaa !23
  br label %bb94
bb94:
  %t487 = load i32, ptr %l261, !tbaa !23
  store i32 %t487, ptr %l34, !tbaa !23
  %t488 = load ptr, ptr %l0, !tbaa !29
  %t489 = load ptr, ptr %l32, !tbaa !29
  %t490 = load i32, ptr %l34, !tbaa !23
  %t494 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLikeFits(ptr %v0, ptr %v1, ptr %t488, ptr %t489, i32 %t490)
  store i1 %t494, ptr %l269
  br label %bb95
bb95:
  %t495 = load i1, ptr %l269, !tbaa !21
  store i1 %t495, ptr %l35, !tbaa !21
  %t496 = load ptr, ptr %l0, !tbaa !29
  store ptr %t496, ptr %l270, !tbaa !29
  %t497 = load ptr, ptr %l0, !tbaa !29
  store ptr %t497, ptr %l271, !tbaa !29
  %t498 = load ptr, ptr %l32, !tbaa !29
  store ptr %t498, ptr %l273, !tbaa !29
  %t500 = load i1, ptr %l35, !tbaa !21
  br i1 %t500, label %bb96, label %bb97
bb96:
  %t502 = load i32, ptr %l34, !tbaa !23
  store i32 %t502, ptr %l275, !tbaa !23
  br label %bb98
bb97:
  %t504 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t504, ptr %l275, !tbaa !23
  br label %bb98
bb98:
  %t506 = load ptr, ptr %l271, !tbaa !29
  %t507 = load ptr, ptr %l273, !tbaa !29
  %t508 = load i32, ptr %l275, !tbaa !23
  %t509 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t506, ptr %t507, i32 %t508)
  store ptr %t509, ptr %l278
  br label %bb99
bb99:
  %t510 = load ptr, ptr %l32, !tbaa !29
  %t512 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t510)
  store %"compiler/source:Span" %t512, ptr %l280
  br label %bb100
bb100:
  %t513 = load ptr, ptr %l270, !tbaa !29
  %t514 = load ptr, ptr %l278, !tbaa !29
  %t515 = load %"compiler/source:Span", ptr %l280
  %t516 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t513, ptr %t514, %"compiler/source:Span" %t515)
  store ptr %t516, ptr %l281
  br label %bb101
bb101:
  %t517 = load ptr, ptr %l281, !tbaa !29
  store ptr %t517, ptr %l36, !tbaa !29
  %t518 = load i64, ptr %l24, !tbaa !24
  %t519 = load i64, ptr %l25, !tbaa !24
  %t522 = icmp slt i64 %t518, %t519
  br i1 %t522, label %bb102, label %bb103
bb102:
  %t524 = load i64, ptr %l24, !tbaa !24
  store i64 %t524, ptr %l285, !tbaa !24
  br label %bb104
bb103:
  %t526 = load i64, ptr %l25, !tbaa !24
  store i64 %t526, ptr %l285, !tbaa !24
  br label %bb104
bb104:
  %t528 = load i64, ptr %l285, !tbaa !24
  store i64 %t528, ptr %l37, !tbaa !24
  %t529 = load i1, ptr %l35, !tbaa !21
  %t531 = xor i1 %t529, true
  br i1 %t531, label %bb105, label %bb106
bb105:
  store %olang.scope zeroinitializer, ptr %s18
  %t533 = load ptr, ptr %l0, !tbaa !29
  store ptr %t533, ptr %l290, !tbaa !29
  %t534 = load ptr, ptr %l0, !tbaa !29
  store ptr %t534, ptr %l291, !tbaa !29
  %t535 = load ptr, ptr %l2, !tbaa !29
  %t537 = getelementptr %"compiler/ast:Chain", ptr %t535, i32 0, i32 1
  %t538 = load { i64, ptr }, ptr %t537, !tbaa !27
  store { i64, ptr } %t538, ptr %l293, !tbaa !27
  %t539 = load i64, ptr %l37, !tbaa !24
  %t541 = getelementptr { i64, ptr }, ptr %l293, i32 0, i32 1
  %t542 = load ptr, ptr %t541, !tbaa !27
  %t543 = getelementptr ptr, ptr %t542, i64 %t539
  %t544 = load ptr, ptr %t543, !tbaa !39
  %t546 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t544)
  store %"compiler/source:Span" %t546, ptr %l296
  br label %bb107
bb106:
  br label %bb113
bb107:
  %t547 = load ptr, ptr %l2, !tbaa !29
  %t549 = getelementptr %"compiler/ast:Chain", ptr %t547, i32 0, i32 1
  %t550 = load { i64, ptr }, ptr %t549, !tbaa !27
  store { i64, ptr } %t550, ptr %l298, !tbaa !27
  %t551 = load i64, ptr %l37, !tbaa !24
  %t553 = add i64 %t551, 1
  %t555 = getelementptr { i64, ptr }, ptr %l298, i32 0, i32 1
  %t556 = load ptr, ptr %t555, !tbaa !27
  %t557 = getelementptr ptr, ptr %t556, i64 %t553
  %t558 = load ptr, ptr %t557, !tbaa !39
  %t560 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t558)
  store %"compiler/source:Span" %t560, ptr %l302
  br label %bb108
bb108:
  %t561 = load ptr, ptr %l2, !tbaa !29
  %t563 = getelementptr %"compiler/ast:Chain", ptr %t561, i32 0, i32 0
  %t564 = load { i64, ptr }, ptr %t563, !tbaa !27
  store { i64, ptr } %t564, ptr %l304, !tbaa !27
  %t565 = load i64, ptr %l37, !tbaa !24
  %t567 = getelementptr { i64, ptr }, ptr %l304, i32 0, i32 1
  %t568 = load ptr, ptr %t567, !tbaa !27
  %t569 = getelementptr i32, ptr %t568, i64 %t565
  %t570 = load i32, ptr %t569
  %t572 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s18, i32 %t570)
  store { i64, ptr } %t572, ptr %l307
  br label %bb109
bb109:
  %t573 = load { i64, ptr }, ptr %l307, !tbaa !27
  %t574 = extractvalue { i64, ptr } %t573, 0
  %t575 = load ptr, ptr %l291, !tbaa !29
  %t576 = load %"compiler/source:Span", ptr %l296
  %t577 = load %"compiler/source:Span", ptr %l302
  %t579 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t575, %"compiler/source:Span" %t576, %"compiler/source:Span" %t577, i64 %t574)
  store %"compiler/source:Span" %t579, ptr %l309
  br label %bb110
bb110:
  %t580 = load i32, ptr %l33, !tbaa !23
  store i32 %t580, ptr %l310, !tbaa !23
  %t581 = load ptr, ptr %l36, !tbaa !29
  %t584 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t581)
  store i32 %t584, ptr %l313
  br label %bb111
bb111:
  %t585 = load ptr, ptr %l290, !tbaa !29
  %t586 = load %"compiler/source:Span", ptr %l309
  %t587 = load i32, ptr %l310, !tbaa !23
  %t588 = load i32, ptr %l313, !tbaa !23
  %t589 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoMeet(ptr %v0, ptr %t585, %"compiler/source:Span" %t586, i32 %t587, i32 %t588)
  store i1 %t589, ptr %l314
  br label %bb112
bb112:
  call void @__olang_scope_close(ptr %s18)
  br label %bb113
bb113:
  %t590 = load ptr, ptr %l0, !tbaa !29
  %t592 = getelementptr %"compiler/check:Checker", ptr %t590, i32 0, i32 31
  %t593 = load i64, ptr %l3, !tbaa !24
  %t594 = load i64, ptr %l24, !tbaa !24
  %t597 = add i64 %t593, %t594
  %t598 = load ptr, ptr %l36, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eSet_H7eb7f72699477ff6ed0f03fe599574de(ptr %v0, ptr %v0, ptr %t592, i64 %t597, ptr %t598)
  br label %bb114
bb114:
  call void @__olang_scope_close(ptr %s10)
  br label %bb115
bb115:
  %t602 = load i64, ptr %l23, !tbaa !24
  %t604 = add i64 %t602, 1
  store i64 %t604, ptr %l23, !tbaa !24
  br label %bb47
bb116:
  %t606 = load ptr, ptr %l0, !tbaa !29
  store ptr %t606, ptr %l323, !tbaa !29
  %t607 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t607, ptr %l324
  %t608 = load ptr, ptr %l2, !tbaa !29
  store ptr %t608, ptr %l325, !tbaa !29
  %t609 = load i64, ptr %l3, !tbaa !24
  store i64 %t609, ptr %l326, !tbaa !24
  %t610 = load ptr, ptr %lp5
  %t611 = load { i64, ptr }, ptr %t610, !tbaa !27
  store { i64, ptr } %t611, ptr %l327, !tbaa !27
  %t612 = load ptr, ptr %lp5
  %t613 = getelementptr { i64, ptr }, ptr %t612, i32 0, i32 1
  %t614 = load ptr, ptr %t613, !tbaa !27
  %t615 = getelementptr i1, ptr %t614, i64 0
  %t616 = load i1, ptr %t615, !tbaa !31
  br i1 %t616, label %bb117, label %bb118
bb117:
  store ptr null, ptr %l329, !tbaa !29
  br label %bb120
bb118:
  %t618 = load ptr, ptr %l0, !tbaa !29
  %t620 = getelementptr %"compiler/check:Checker", ptr %t618, i32 0, i32 31
  %t621 = load i64, ptr %l3, !tbaa !24
  %t624 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t620, i64 %t621)
  store ptr %t624, ptr %l333
  br label %bb119
bb119:
  %t625 = load ptr, ptr %l333, !tbaa !29
  store ptr %t625, ptr %l329, !tbaa !29
  br label %bb120
bb120:
  %t627 = load ptr, ptr %l323, !tbaa !29
  %t628 = load %"compiler/source:Span", ptr %l324
  %t629 = load ptr, ptr %l325, !tbaa !29
  %t630 = load i64, ptr %l326, !tbaa !24
  %t631 = load { i64, ptr }, ptr %l327, !tbaa !27
  %t632 = load ptr, ptr %l329, !tbaa !29
  %t633 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echainFrom(ptr %v0, ptr %v1, ptr %v0, ptr %t627, %"compiler/source:Span" %t628, ptr %t629, i64 %t630, { i64, ptr } %t631, i64 0, ptr %t632)
  store ptr %t633, ptr %l335
  br label %bb121
bb121:
  %t634 = load ptr, ptr %l335, !tbaa !29
  store ptr %t634, ptr %l38, !tbaa !29
  %t635 = load ptr, ptr %l0, !tbaa !29
  %t637 = getelementptr %"compiler/check:Checker", ptr %t635, i32 0, i32 31
  %t638 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eTru_H381e973120335535f017a290d5069d76(ptr %v0, ptr %t637, i64 %t638)
  br label %bb122
bb122:
  %t641 = load ptr, ptr %l38, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t641, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclauseHandler(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %lp26 = alloca ptr
  %lp27 = alloca ptr
  %l30 = alloca i1
  %l41 = alloca i1
  %l44 = alloca i1
  %l49 = alloca i1
  %l52 = alloca ptr
  %l55 = alloca %"compiler/source:Span"
  %l56 = alloca %"compiler/msgs:Msg"
  %l57 = alloca i64
  %l61 = alloca i32
  %l68 = alloca i32
  %l70 = alloca ptr
  %l73 = alloca i64
  %l86 = alloca i64
  %l95 = alloca ptr
  %l103 = alloca ptr
  %l107 = alloca i32
  %l109 = alloca ptr
  %l113 = alloca { i64, ptr }
  %l117 = alloca i64
  %l127 = alloca { i64, ptr }
  %l138 = alloca i1
  %l143 = alloca ptr
  %l145 = alloca %"compiler/source:Span"
  %l148 = alloca { i64, ptr }
  %l151 = alloca ptr
  %l159 = alloca i32
  %l162 = alloca { i64, ptr }
  %l165 = alloca ptr
  %l170 = alloca i32
  %l171 = alloca { i64, ptr }
  %l181 = alloca ptr
  %l183 = alloca %"compiler/source:Span"
  %l189 = alloca %"compiler/msgs:Msg"
  %l190 = alloca i64
  %l193 = alloca i64
  %l199 = alloca i64
  %l202 = alloca i64
  %l221 = alloca ptr
  %l224 = alloca { i64, ptr }
  %l227 = alloca { i64, ptr }
  %l230 = alloca ptr
  %l236 = alloca { i64, ptr }
  %l237 = alloca ptr
  %l239 = alloca %"compiler/source:Span"
  %l241 = alloca %"compiler/source:Span"
  %l242 = alloca i32
  %l246 = alloca %"compiler/typed:Make"
  %l255 = alloca { i64, ptr }
  %l256 = alloca %"compiler/typed:Block"
  %l258 = alloca ptr
  %l263 = alloca i1
  %l266 = alloca i1
  %l268 = alloca ptr
  %l272 = alloca i1
  %l274 = alloca i1
  %l276 = alloca ptr
  %l278 = alloca %"compiler/source:Span"
  %l279 = alloca %"compiler/msgs:Msg"
  %l280 = alloca i64
  %l282 = alloca ptr
  %l285 = alloca { i64, ptr }
  %l291 = alloca %"compiler/source:Span"
  %l292 = alloca i32
  %l295 = alloca i32
  %l296 = alloca { i64, ptr }
  %l301 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %rv = alloca ptr
  %t99 = alloca { i64, [2 x i64] }, align 8
  %t275 = alloca { i64, [3 x i64] }, align 8
  %t468 = alloca { i64, [5 x i64] }, align 8
  %t480 = alloca { i64, [3 x i64] }, align 8
  %t588 = alloca { i64, [4 x i64] }, align 8
  %t600 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Catch", ptr %t1, i32 0, i32 4
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/ast:Catch", ptr %t6, i32 0, i32 2
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  %t13 = icmp sgt i64 %t11, 0
  store i1 %t13, ptr %l30, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l30, !tbaa !21
  store i1 %t15, ptr %l4, !tbaa !21
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/ast:Catch", ptr %t16, i32 0, i32 3
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 0
  %t23 = icmp sgt i64 %t21, 0
  store i1 %t23, ptr %l5, !tbaa !21
  %t25 = load i1, ptr %l4, !tbaa !21
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb4, label %bb5
bb4:
  %t29 = load i1, ptr %l5, !tbaa !21
  %t31 = xor i1 %t29, true
  store i1 %t31, ptr %l41, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb6
bb6:
  %t33 = load i1, ptr %l41, !tbaa !21
  br i1 %t33, label %bb7, label %bb8
bb7:
  %t34 = load i64, ptr %l3, !tbaa !24
  %t36 = icmp eq i64 %t34, 0
  store i1 %t36, ptr %l44, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb9
bb9:
  %t38 = load i1, ptr %l44, !tbaa !21
  br i1 %t38, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t40 = load i1, ptr %l5, !tbaa !21
  br i1 %t40, label %bb13, label %bb14
bb13:
  %t42 = load i64, ptr %l3, !tbaa !24
  %t44 = icmp eq i64 %t42, 0
  store i1 %t44, ptr %l49, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb15
bb15:
  %t46 = load i1, ptr %l49, !tbaa !21
  br i1 %t46, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s2
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l52, !tbaa !29
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t52 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultSpan(ptr %v0, ptr %v1, ptr %t48, ptr %t49)
  store %"compiler/source:Span" %t52, ptr %l55
  br label %bb18
bb17:
  br label %bb21
bb18:
  %t53 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskDefaultInStatement(ptr %s2)
  store %"compiler/msgs:Msg" %t53, ptr %l56
  br label %bb19
bb19:
  %t54 = load ptr, ptr %l52, !tbaa !29
  %t55 = load %"compiler/source:Span", ptr %l55
  %t56 = load %"compiler/msgs:Msg", ptr %l56
  %t57 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t54, %"compiler/source:Span" %t55, %"compiler/msgs:Msg" %t56)
  store i64 %t57, ptr %l57
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb21:
  %t59 = load i64, ptr %l3, !tbaa !24
  %t61 = icmp sgt i64 %t59, 0
  br i1 %t61, label %bb22, label %bb23
bb22:
  %t63 = load i32, ptr %l2, !tbaa !23
  store i32 %t63, ptr %l61, !tbaa !23
  br label %bb24
bb23:
  %t65 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t65, ptr %l61, !tbaa !23
  br label %bb24
bb24:
  %t67 = load i32, ptr %l61, !tbaa !23
  store i32 %t67, ptr %l6, !tbaa !23
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/check:Checker", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = getelementptr %"compiler/generic:Program", ptr %t71, i32 0, i32 2
  %t74 = load i32, ptr %l6, !tbaa !23
  %t77 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t73, i32 0, i32 %t74, i32 0, i32 0, i64 0)
  store i32 %t77, ptr %l68
  br label %bb25
bb25:
  %t78 = load i32, ptr %l68, !tbaa !23
  store i32 %t78, ptr %l7, !tbaa !23
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t79)
  store ptr %t81, ptr %l70
  br label %bb26
bb26:
  %t82 = load ptr, ptr %l70, !tbaa !29
  store ptr %t82, ptr %l8, !tbaa !29
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 12
  %t87 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_H2d42092ce658fb6cce0104fa754a4e33(ptr %v0, ptr %t85)
  store i64 %t87, ptr %l73
  br label %bb27
bb27:
  %t88 = load i64, ptr %l73, !tbaa !24
  %t89 = sub i64 %t88, 1
  store i64 %t89, ptr %l9, !tbaa !24
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l8, !tbaa !29
  %t94 = getelementptr %"compiler/check:frame", ptr %t92, i32 0, i32 0
  %t95 = load i64, ptr %t94, !tbaa !24
  %t97 = trunc i64 %t95 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t99
  %t100 = getelementptr { i64, [2 x i64] }, ptr %t99, i32 0, i32 0
  store i64 4, ptr %t100
  %t102 = insertvalue { i32 } undef, i32 %t97, 0
  %t103 = getelementptr { i64, [2 x i64] }, ptr %t99, i32 0, i32 1
  store { i32 } %t102, ptr %t103
  %t104 = load { i64, [2 x i64] }, ptr %t99
  %t105 = load i32, ptr %l7, !tbaa !23
  %t106 = load ptr, ptr %l8, !tbaa !29
  %t108 = getelementptr %"compiler/check:frame", ptr %t106, i32 0, i32 1
  %t109 = load i64, ptr %t108, !tbaa !24
  %t110 = load ptr, ptr %l1, !tbaa !29
  %t112 = getelementptr %"compiler/ast:Catch", ptr %t110, i32 0, i32 0
  %t113 = load %"compiler/source:Span", ptr %t112
  %t119 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t91, { i64, [2 x i64] } %t104, i32 %t105, i64 %t109, %"compiler/source:Span" %t113)
  store i64 %t119, ptr %l86
  br label %bb28
bb28:
  %t120 = load i64, ptr %l86, !tbaa !24
  store i64 %t120, ptr %l10, !tbaa !24
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/check:Checker", ptr %t121, i32 0, i32 15
  %t124 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t123, i64 %t124, i64 1)
  br label %bb29
bb29:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load i64, ptr %l10, !tbaa !24
  %t129 = load ptr, ptr %l8, !tbaa !29
  %t131 = getelementptr %"compiler/check:frame", ptr %t129, i32 0, i32 1
  %t132 = load i64, ptr %t131, !tbaa !24
  %t133 = load i32, ptr %l6, !tbaa !23
  %t138 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %t127, i64 %t128, i64 %t132, i32 %t133, i32 0)
  store ptr %t138, ptr %l95
  br label %bb30
bb30:
  %t139 = load ptr, ptr %l95, !tbaa !29
  store ptr %t139, ptr %l11, !tbaa !29
  %t140 = load ptr, ptr %l11, !tbaa !29
  %t141 = load ptr, ptr %l8, !tbaa !29
  %t143 = getelementptr %"compiler/check:frame", ptr %t141, i32 0, i32 4
  %t144 = load %"compiler/generic:Context", ptr %t143
  %t147 = getelementptr %"compiler/check:frame", ptr %t140, i32 0, i32 4
  store %"compiler/generic:Context" %t144, ptr %t147
  %t148 = load ptr, ptr %l11, !tbaa !29
  %t149 = load i64, ptr %l9, !tbaa !24
  %t152 = getelementptr %"compiler/check:frame", ptr %t148, i32 0, i32 19
  store i64 %t149, ptr %t152, !tbaa !24
  %t153 = load ptr, ptr %l11, !tbaa !29
  %t155 = getelementptr %"compiler/check:frame", ptr %t153, i32 0, i32 27
  store i1 true, ptr %t155, !tbaa !21
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t156)
  store ptr %t158, ptr %l103
  br label %bb31
bb31:
  %t159 = load ptr, ptr %l1, !tbaa !29
  %t161 = getelementptr %"compiler/ast:Catch", ptr %t159, i32 0, i32 0
  %t162 = load %"compiler/source:Span", ptr %t161
  %t163 = load ptr, ptr %l103, !tbaa !29
  %t166 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %t163, i32 -1, i32 0, %"compiler/source:Span" %t162)
  store i32 %t166, ptr %l107
  br label %bb32
bb32:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t167)
  store ptr %t169, ptr %l109
  br label %bb33
bb33:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/check:Checker", ptr %t170, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !29
  %t174 = load i32, ptr %l7, !tbaa !23
  %t177 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t173, i32 %t174)
  store { i64, ptr } %t177, ptr %l113
  br label %bb34
bb34:
  %t178 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t178, 0
  %t180 = extractvalue { i64, ptr } %t178, 1
  %t181 = mul i64 %t179, 8
  %t182 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t181)
  call void @llvm.memcpy.p0.p0.i64(ptr %t182, ptr %t180, i64 %t181, i1 false)
  %t183 = insertvalue { i64, ptr } undef, i64 %t179, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t182, 1
  %t185 = load ptr, ptr %l109, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eSetVars(ptr %v0, ptr %s0, ptr %t185, { i64, ptr } %t184)
  br label %bb35
bb35:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/check:Checker", ptr %t187, i32 0, i32 32
  %t191 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t189)
  store i64 %t191, ptr %l117
  br label %bb36
bb36:
  %t192 = load i64, ptr %l117, !tbaa !24
  store i64 %t192, ptr %l12, !tbaa !24
  %t193 = load i1, ptr %l4, !tbaa !21
  br i1 %t193, label %bb37, label %bb38
bb37:
  %t195 = load ptr, ptr %l1, !tbaa !29
  %t197 = getelementptr %"compiler/ast:Catch", ptr %t195, i32 0, i32 2
  %t198 = load { i64, ptr }, ptr %t197, !tbaa !27
  store { i64, ptr } %t198, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t200 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t202 = extractvalue { i64, ptr } %t200, 0
  store i64 %t202, ptr %l15, !tbaa !24
  br label %bb39
bb38:
  br label %bb46
bb39:
  store %olang.scope zeroinitializer, ptr %s5
  %t204 = load i64, ptr %l14, !tbaa !24
  %t205 = load i64, ptr %l15, !tbaa !24
  %t208 = icmp slt i64 %t204, %t205
  %t210 = xor i1 %t208, true
  br i1 %t210, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s5)
  br label %bb45
bb41:
  br label %bb42
bb42:
  %t212 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t212, ptr %l127, !tbaa !27
  %t213 = load i64, ptr %l14, !tbaa !24
  %t215 = getelementptr { i64, ptr }, ptr %l127, i32 0, i32 1
  %t216 = load ptr, ptr %t215, !tbaa !27
  %t217 = getelementptr ptr, ptr %t216, i64 %t213
  %t218 = load ptr, ptr %t217, !tbaa !39
  %t220 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %t220, ptr %t218)
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s5)
  br label %bb44
bb44:
  %t225 = load i64, ptr %l14, !tbaa !24
  %t227 = add i64 %t225, 1
  store i64 %t227, ptr %l14, !tbaa !24
  br label %bb39
bb45:
  br label %bb46
bb46:
  %t229 = load i1, ptr %l5, !tbaa !21
  br i1 %t229, label %bb47, label %bb48
bb47:
  %t231 = load i64, ptr %l3, !tbaa !24
  %t233 = icmp eq i64 %t231, 1
  br i1 %t233, label %bb49, label %bb50
bb48:
  br label %bb90
bb49:
  store i1 true, ptr %l138, !tbaa !21
  br label %bb51
bb50:
  %t235 = load ptr, ptr %l1, !tbaa !29
  %t237 = getelementptr %"compiler/ast:Catch", ptr %t235, i32 0, i32 3
  %t238 = load { i64, ptr }, ptr %t237, !tbaa !27
  %t240 = extractvalue { i64, ptr } %t238, 0
  %t242 = icmp eq i64 %t240, 1
  store i1 %t242, ptr %l138, !tbaa !21
  br label %bb51
bb51:
  %t244 = load i1, ptr %l138, !tbaa !21
  br i1 %t244, label %bb52, label %bb53
bb52:
  %t245 = load ptr, ptr %l0, !tbaa !29
  store ptr %t245, ptr %l143, !tbaa !29
  %t246 = load ptr, ptr %l1, !tbaa !29
  %t248 = getelementptr %"compiler/ast:Catch", ptr %t246, i32 0, i32 0
  %t249 = load %"compiler/source:Span", ptr %t248
  store %"compiler/source:Span" %t249, ptr %l145
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t251 = load ptr, ptr %l1, !tbaa !29
  %t253 = getelementptr %"compiler/ast:Catch", ptr %t251, i32 0, i32 3
  %t254 = load { i64, ptr }, ptr %t253, !tbaa !27
  store { i64, ptr } %t254, ptr %l148, !tbaa !27
  %t255 = getelementptr { i64, ptr }, ptr %l148, i32 0, i32 1
  %t256 = load ptr, ptr %t255, !tbaa !27
  %t257 = getelementptr ptr, ptr %t256, i64 0
  %t258 = load ptr, ptr %t257, !tbaa !39
  %t259 = load i32, ptr %l2, !tbaa !23
  %t263 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etaskDefault(ptr %v0, ptr %v1, ptr %t250, ptr %t258, i32 %t259)
  store ptr %t263, ptr %l151
  br label %bb54
bb53:
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t266 = getelementptr %"compiler/check:Checker", ptr %t264, i32 0, i32 1
  %t267 = load ptr, ptr %t266, !tbaa !29
  %t269 = getelementptr %"compiler/generic:Program", ptr %t267, i32 0, i32 2
  %t270 = load i32, ptr %l2, !tbaa !23
  %t273 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t269, i32 %t270)
  store i32 %t273, ptr %l159
  br label %bb56
bb54:
  %t274 = load ptr, ptr %l151, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t275
  %t276 = getelementptr { i64, [3 x i64] }, ptr %t275, i32 0, i32 0
  store i64 6, ptr %t276
  %t277 = load %"compiler/source:Span", ptr %l145
  %t278 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t277, 0
  %t280 = insertvalue { %"compiler/source:Span", ptr } %t278, ptr %t274, 1
  %t281 = getelementptr { i64, [3 x i64] }, ptr %t275, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t280, ptr %t281
  %t282 = load { i64, [3 x i64] }, ptr %t275
  %t284 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t282, ptr %t284
  %t285 = load ptr, ptr %l143, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t285, ptr %t284)
  br label %bb55
bb55:
  br label %bb89
bb56:
  %t287 = load i32, ptr %l159
  %t289 = trunc i64 22 to i32
  %t290 = icmp eq i32 %t287, %t289
  br i1 %t290, label %bb57, label %bb58
bb57:
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = getelementptr %"compiler/check:Checker", ptr %t292, i32 0, i32 1
  %t295 = load ptr, ptr %t294, !tbaa !29
  %t297 = getelementptr %"compiler/generic:Program", ptr %t295, i32 0, i32 2
  store ptr %t297, ptr %l165, !tbaa !29
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t300 = getelementptr %"compiler/check:Checker", ptr %t298, i32 0, i32 1
  %t301 = load ptr, ptr %t300, !tbaa !29
  %t303 = getelementptr %"compiler/generic:Program", ptr %t301, i32 0, i32 2
  %t304 = load i32, ptr %l2, !tbaa !23
  %t307 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t303, i32 %t304)
  store i32 %t307, ptr %l170
  br label %bb59
bb58:
  %t308 = icmp sge i64 0, 0
  br i1 %t308, label %bb61, label %bb62
bb59:
  %t310 = load ptr, ptr %l165, !tbaa !29
  %t311 = load i32, ptr %l170, !tbaa !23
  %t312 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t310, i32 %t311)
  store { i64, ptr } %t312, ptr %l171
  br label %bb60
bb60:
  %t313 = load { i64, ptr }, ptr %l171, !tbaa !27
  store { i64, ptr } %t313, ptr %l162, !tbaa !27
  br label %bb65
bb61:
  %t314 = icmp sle i64 0, 2305843009213693951
  br i1 %t314, label %bb63, label %bb64
bb62:
  call void @__olang_check_failed(ptr @olang_loc_b7a62f2efaadd4af_1b278ceebf7ddf33)
  unreachable
bb63:
  %t316 = mul i64 0, 4
  %t317 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t316)
  %t318 = insertvalue { i64, ptr } undef, i64 0, 0
  %t319 = insertvalue { i64, ptr } %t318, ptr %t317, 1
  store { i64, ptr } %t319, ptr %l162, !tbaa !27
  br label %bb65
bb64:
  call void @__olang_check_failed(ptr @olang_loc_b7a62f2efaadd4af_1b278ceebf7ddf33)
  unreachable
bb65:
  %t321 = load { i64, ptr }, ptr %l162, !tbaa !27
  store { i64, ptr } %t321, ptr %l17, !tbaa !27
  %t322 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t324 = extractvalue { i64, ptr } %t322, 0
  %t325 = load ptr, ptr %l1, !tbaa !29
  %t327 = getelementptr %"compiler/ast:Catch", ptr %t325, i32 0, i32 3
  %t328 = load { i64, ptr }, ptr %t327, !tbaa !27
  %t330 = extractvalue { i64, ptr } %t328, 0
  %t333 = icmp ne i64 %t324, %t330
  br i1 %t333, label %bb66, label %bb67
bb66:
  store %olang.scope zeroinitializer, ptr %s10
  %t335 = load ptr, ptr %l0, !tbaa !29
  store ptr %t335, ptr %l181, !tbaa !29
  %t336 = load ptr, ptr %l1, !tbaa !29
  %t338 = getelementptr %"compiler/ast:Catch", ptr %t336, i32 0, i32 0
  %t339 = load %"compiler/source:Span", ptr %t338
  store %"compiler/source:Span" %t339, ptr %l183
  %t340 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t342 = extractvalue { i64, ptr } %t340, 0
  %t343 = load ptr, ptr %l1, !tbaa !29
  %t345 = getelementptr %"compiler/ast:Catch", ptr %t343, i32 0, i32 3
  %t346 = load { i64, ptr }, ptr %t345, !tbaa !27
  %t348 = extractvalue { i64, ptr } %t346, 0
  %t351 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestructCount(ptr %s10, i64 %t342, i64 %t348)
  store %"compiler/msgs:Msg" %t351, ptr %l189
  br label %bb68
bb67:
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t354 = getelementptr %"compiler/check:Checker", ptr %t352, i32 0, i32 31
  %t356 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t354)
  store i64 %t356, ptr %l193
  br label %bb70
bb68:
  %t357 = load ptr, ptr %l181, !tbaa !29
  %t358 = load %"compiler/source:Span", ptr %l183
  %t359 = load %"compiler/msgs:Msg", ptr %l189
  %t360 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s10, ptr %t357, %"compiler/source:Span" %t358, %"compiler/msgs:Msg" %t359)
  store i64 %t360, ptr %l190
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s10)
  br label %bb88
bb70:
  %t361 = load i64, ptr %l193, !tbaa !24
  store i64 %t361, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  %t362 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t364 = extractvalue { i64, ptr } %t362, 0
  store i64 %t364, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t366 = load i64, ptr %l20, !tbaa !24
  %t367 = load i64, ptr %l19, !tbaa !24
  %t370 = icmp sgt i64 %t366, %t367
  br i1 %t370, label %bb71, label %bb72
bb71:
  %t372 = load i64, ptr %l21, !tbaa !24
  %t374 = icmp sgt i64 %t372, 0
  br i1 %t374, label %bb73, label %bb74
bb72:
  store i64 0, ptr %l199, !tbaa !24
  br label %bb76
bb73:
  %t376 = load i64, ptr %l20, !tbaa !24
  %t377 = load i64, ptr %l19, !tbaa !24
  %t380 = sub i64 %t376, %t377
  %t381 = load i64, ptr %l21, !tbaa !24
  %t384 = add i64 %t380, %t381
  %t386 = sub i64 %t384, 1
  %t387 = load i64, ptr %l21, !tbaa !24
  %t390 = sdiv i64 %t386, %t387
  store i64 %t390, ptr %l202, !tbaa !24
  br label %bb75
bb74:
  store i64 0, ptr %l202, !tbaa !24
  br label %bb75
bb75:
  %t392 = load i64, ptr %l202, !tbaa !24
  store i64 %t392, ptr %l199, !tbaa !24
  br label %bb76
bb76:
  %t393 = load i64, ptr %l199, !tbaa !24
  store i64 %t393, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb77
bb77:
  store %olang.scope zeroinitializer, ptr %s13
  %t394 = load i64, ptr %l23, !tbaa !24
  %t395 = load i64, ptr %l22, !tbaa !24
  %t398 = icmp slt i64 %t394, %t395
  %t400 = xor i1 %t398, true
  br i1 %t400, label %bb78, label %bb79
bb78:
  call void @__olang_scope_close(ptr %s13)
  br label %bb84
bb79:
  br label %bb80
bb80:
  %t402 = load i64, ptr %l19, !tbaa !24
  %t403 = load i64, ptr %l23, !tbaa !24
  %t404 = load i64, ptr %l21, !tbaa !24
  %t407 = mul i64 %t403, %t404
  %t410 = add i64 %t402, %t407
  store i64 %t410, ptr %l24, !tbaa !24
  %t412 = load ptr, ptr %l0, !tbaa !29
  %t414 = getelementptr %"compiler/check:Checker", ptr %t412, i32 0, i32 31
  store ptr %t414, ptr %l221, !tbaa !29
  %t415 = load ptr, ptr %l0, !tbaa !29
  %t416 = load ptr, ptr %l1, !tbaa !29
  %t418 = getelementptr %"compiler/ast:Catch", ptr %t416, i32 0, i32 3
  %t419 = load { i64, ptr }, ptr %t418, !tbaa !27
  store { i64, ptr } %t419, ptr %l224, !tbaa !27
  %t420 = load i64, ptr %l24, !tbaa !24
  %t422 = getelementptr { i64, ptr }, ptr %l224, i32 0, i32 1
  %t423 = load ptr, ptr %t422, !tbaa !27
  %t424 = getelementptr ptr, ptr %t423, i64 %t420
  %t425 = load ptr, ptr %t424, !tbaa !39
  %t426 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t426, ptr %l227, !tbaa !27
  %t427 = load i64, ptr %l24, !tbaa !24
  %t429 = getelementptr { i64, ptr }, ptr %l227, i32 0, i32 1
  %t430 = load ptr, ptr %t429, !tbaa !27
  %t431 = getelementptr i32, ptr %t430, i64 %t427
  %t432 = load i32, ptr %t431, !tbaa !33
  %t436 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etaskDefault(ptr %v0, ptr %v1, ptr %t415, ptr %t425, i32 %t432)
  store ptr %t436, ptr %l230
  br label %bb81
bb81:
  %t437 = load ptr, ptr %l221, !tbaa !29
  %t438 = load ptr, ptr %l230, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t437, ptr %t438)
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s13)
  br label %bb83
bb83:
  %t439 = load i64, ptr %l23, !tbaa !24
  %t441 = add i64 %t439, 1
  store i64 %t441, ptr %l23, !tbaa !24
  br label %bb77
bb84:
  %t443 = load ptr, ptr %l0, !tbaa !29
  %t445 = getelementptr %"compiler/check:Checker", ptr %t443, i32 0, i32 31
  %t446 = load i64, ptr %l18, !tbaa !24
  %t449 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t445, i64 %t446)
  store { i64, ptr } %t449, ptr %l236
  br label %bb85
bb85:
  %t450 = load { i64, ptr }, ptr %l236, !tbaa !27
  %t451 = load ptr, ptr %l0, !tbaa !29
  store ptr %t451, ptr %l237, !tbaa !29
  %t452 = load ptr, ptr %l1, !tbaa !29
  %t454 = getelementptr %"compiler/ast:Catch", ptr %t452, i32 0, i32 0
  %t455 = load %"compiler/source:Span", ptr %t454
  store %"compiler/source:Span" %t455, ptr %l239
  %t456 = load ptr, ptr %l1, !tbaa !29
  %t458 = getelementptr %"compiler/ast:Catch", ptr %t456, i32 0, i32 0
  %t459 = load %"compiler/source:Span", ptr %t458
  store %"compiler/source:Span" %t459, ptr %l241
  %t460 = load i32, ptr %l2, !tbaa !23
  store i32 %t460, ptr %l242, !tbaa !23
  %t465 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v0, ptr %v0, i32 0, i64 0, { i64, ptr } %t450, ptr null, i32 -1, i32 0)
  store %"compiler/typed:Make" %t465, ptr %l246
  br label %bb86
bb86:
  %t466 = load %"compiler/typed:Make", ptr %l246
  %t467 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store %"compiler/typed:Make" %t466, ptr %t467
  store { i64, [5 x i64] } zeroinitializer, ptr %t468
  %t469 = getelementptr { i64, [5 x i64] }, ptr %t468, i32 0, i32 0
  store i64 7, ptr %t469
  %t470 = load %"compiler/source:Span", ptr %l241
  %t471 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t470, 0
  %t472 = load i32, ptr %l242, !tbaa !23
  %t473 = insertvalue { %"compiler/source:Span", i32, ptr } %t471, i32 %t472, 1
  %t475 = insertvalue { %"compiler/source:Span", i32, ptr } %t473, ptr %t467, 2
  %t476 = getelementptr { i64, [5 x i64] }, ptr %t468, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t475, ptr %t476
  %t477 = load { i64, [5 x i64] }, ptr %t468
  %t479 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t477, ptr %t479
  store { i64, [3 x i64] } zeroinitializer, ptr %t480
  %t481 = getelementptr { i64, [3 x i64] }, ptr %t480, i32 0, i32 0
  store i64 6, ptr %t481
  %t482 = load %"compiler/source:Span", ptr %l239
  %t483 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t482, 0
  %t485 = insertvalue { %"compiler/source:Span", ptr } %t483, ptr %t479, 1
  %t486 = getelementptr { i64, [3 x i64] }, ptr %t480, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t485, ptr %t486
  %t487 = load { i64, [3 x i64] }, ptr %t480
  %t489 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t487, ptr %t489
  %t490 = load ptr, ptr %l237, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t490, ptr %t489)
  br label %bb87
bb87:
  br label %bb88
bb88:
  br label %bb89
bb89:
  br label %bb90
bb90:
  %t492 = load ptr, ptr %l0, !tbaa !29
  %t494 = getelementptr %"compiler/check:Checker", ptr %t492, i32 0, i32 32
  %t495 = load i64, ptr %l12, !tbaa !24
  %t498 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t494, i64 %t495)
  store { i64, ptr } %t498, ptr %l255
  br label %bb91
bb91:
  %t499 = load { i64, ptr }, ptr %l255, !tbaa !27
  %t500 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 0, { i64, ptr } %t499)
  store %"compiler/typed:Block" %t500, ptr %l256
  br label %bb92
bb92:
  %t501 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store ptr %t501, ptr %lp26
  %t502 = load %"compiler/typed:Block", ptr %l256
  %t503 = load ptr, ptr %lp26
  store %"compiler/typed:Block" %t502, ptr %t503
  %t504 = load ptr, ptr %l0, !tbaa !29
  %t506 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t504)
  store ptr %t506, ptr %l258
  br label %bb93
bb93:
  %t507 = load ptr, ptr %l258, !tbaa !29
  %t508 = load ptr, ptr %lp26
  %t511 = getelementptr %"compiler/typed:Body", ptr %t507, i32 0, i32 11
  store ptr %t508, ptr %t511, !tbaa !29
  %t512 = load i64, ptr %l3, !tbaa !24
  %t514 = icmp sgt i64 %t512, 0
  br i1 %t514, label %bb94, label %bb95
bb94:
  %t516 = load i1, ptr %l5, !tbaa !21
  %t518 = xor i1 %t516, true
  store i1 %t518, ptr %l263, !tbaa !21
  br label %bb96
bb95:
  store i1 false, ptr %l263, !tbaa !21
  br label %bb96
bb96:
  %t520 = load i1, ptr %l263, !tbaa !21
  br i1 %t520, label %bb97, label %bb98
bb97:
  %t521 = load ptr, ptr %l0, !tbaa !29
  %t523 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t521)
  store ptr %t523, ptr %l268
  br label %bb99
bb98:
  store i1 false, ptr %l266, !tbaa !21
  br label %bb100
bb99:
  %t524 = load ptr, ptr %l268, !tbaa !29
  %t526 = getelementptr %"compiler/check:frame", ptr %t524, i32 0, i32 18
  %t527 = load i1, ptr %t526, !tbaa !21
  %t529 = xor i1 %t527, true
  store i1 %t529, ptr %l266, !tbaa !21
  br label %bb100
bb100:
  %t531 = load i1, ptr %l266, !tbaa !21
  br i1 %t531, label %bb101, label %bb102
bb101:
  %t532 = load ptr, ptr %lp26
  %t534 = call i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %t532)
  store i1 %t534, ptr %l274
  br label %bb103
bb102:
  store i1 false, ptr %l272, !tbaa !21
  br label %bb104
bb103:
  %t535 = load i1, ptr %l274, !tbaa !21
  %t536 = xor i1 %t535, true
  store i1 %t536, ptr %l272, !tbaa !21
  br label %bb104
bb104:
  %t538 = load i1, ptr %l272, !tbaa !21
  br i1 %t538, label %bb105, label %bb106
bb105:
  store %olang.scope zeroinitializer, ptr %s15
  %t539 = load ptr, ptr %l0, !tbaa !29
  store ptr %t539, ptr %l276, !tbaa !29
  %t540 = load ptr, ptr %l1, !tbaa !29
  %t542 = getelementptr %"compiler/ast:Catch", ptr %t540, i32 0, i32 0
  %t543 = load %"compiler/source:Span", ptr %t542
  store %"compiler/source:Span" %t543, ptr %l278
  %t544 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskClauseNeedsDefault(ptr %s15)
  store %"compiler/msgs:Msg" %t544, ptr %l279
  br label %bb107
bb106:
  br label %bb109
bb107:
  %t545 = load ptr, ptr %l276, !tbaa !29
  %t546 = load %"compiler/source:Span", ptr %l278
  %t547 = load %"compiler/msgs:Msg", ptr %l279
  %t548 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s15, ptr %t545, %"compiler/source:Span" %t546, %"compiler/msgs:Msg" %t547)
  store i64 %t548, ptr %l280
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s15)
  br label %bb109
bb109:
  %t549 = load ptr, ptr %l0, !tbaa !29
  %t551 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t549)
  store ptr %t551, ptr %l282
  br label %bb110
bb110:
  %t552 = load ptr, ptr %l282, !tbaa !29
  %t554 = getelementptr %"compiler/check:frame", ptr %t552, i32 0, i32 25
  %t556 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aCapture_26_3e_2e_Hc9219e836d6ca52518c31537b8e6a8eb(ptr %v0, ptr %v0, ptr %t554)
  store { i64, ptr } %t556, ptr %l285
  br label %bb111
bb111:
  %t557 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t557, ptr %lp27
  %t558 = load { i64, ptr }, ptr %l285, !tbaa !27
  %t559 = load ptr, ptr %lp27
  store { i64, ptr } %t558, ptr %t559, !tbaa !27
  %t560 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t560)
  br label %bb112
bb112:
  %t562 = load ptr, ptr %l0, !tbaa !29
  %t564 = getelementptr %"compiler/check:Checker", ptr %t562, i32 0, i32 15
  %t565 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t564, i64 %t565, i64 2)
  br label %bb113
bb113:
  %t568 = load ptr, ptr %l1, !tbaa !29
  %t570 = getelementptr %"compiler/ast:Catch", ptr %t568, i32 0, i32 0
  %t571 = load %"compiler/source:Span", ptr %t570
  store %"compiler/source:Span" %t571, ptr %l291
  %t572 = load i32, ptr %l7, !tbaa !23
  store i32 %t572, ptr %l292, !tbaa !23
  %t573 = load i64, ptr %l10, !tbaa !24
  %t575 = trunc i64 %t573 to i32
  store i32 %t575, ptr %l295, !tbaa !23
  %t577 = load ptr, ptr %lp27
  %t578 = load { i64, ptr }, ptr %t577, !tbaa !27
  store { i64, ptr } %t578, ptr %l296, !tbaa !27
  %t579 = load ptr, ptr %l0, !tbaa !29
  %t580 = load ptr, ptr %l1, !tbaa !29
  %t582 = getelementptr %"compiler/ast:Catch", ptr %t580, i32 0, i32 0
  %t583 = load %"compiler/source:Span", ptr %t582
  %t587 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t579, i32 5, %"compiler/source:Span" %t583)
  store i32 %t587, ptr %l301
  br label %bb114
bb114:
  store { i64, [4 x i64] } zeroinitializer, ptr %t588
  %t589 = getelementptr { i64, [4 x i64] }, ptr %t588, i32 0, i32 0
  store i64 1, ptr %t589
  %t590 = load i32, ptr %l295, !tbaa !23
  %t591 = insertvalue { i32, { i64, ptr }, i32 } undef, i32 %t590, 0
  %t592 = load { i64, ptr }, ptr %l296, !tbaa !27
  %t593 = insertvalue { i32, { i64, ptr }, i32 } %t591, { i64, ptr } %t592, 1
  %t594 = load i32, ptr %l301, !tbaa !23
  %t595 = insertvalue { i32, { i64, ptr }, i32 } %t593, i32 %t594, 2
  %t596 = getelementptr { i64, [4 x i64] }, ptr %t588, i32 0, i32 1
  store { i32, { i64, ptr }, i32 } %t595, ptr %t596
  %t597 = load { i64, [4 x i64] }, ptr %t588
  %t599 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t597, ptr %t599
  store { i64, [5 x i64] } zeroinitializer, ptr %t600
  %t601 = getelementptr { i64, [5 x i64] }, ptr %t600, i32 0, i32 0
  store i64 15, ptr %t601
  %t602 = load %"compiler/source:Span", ptr %l291
  %t603 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t602, 0
  %t604 = load i32, ptr %l292, !tbaa !23
  %t605 = insertvalue { %"compiler/source:Span", i32, ptr } %t603, i32 %t604, 1
  %t607 = insertvalue { %"compiler/source:Span", i32, ptr } %t605, ptr %t599, 2
  %t608 = getelementptr { i64, [5 x i64] }, ptr %t600, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t607, ptr %t608
  %t609 = load { i64, [5 x i64] }, ptr %t600
  %t611 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t609, ptr %t611
  call void @__olang_scope_close(ptr %s0)
  store ptr %t611, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd1(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l9 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca ptr
  %l15 = alloca i32
  %l19 = alloca i1
  %l23 = alloca ptr
  %l25 = alloca %"compiler/source:Span"
  %l28 = alloca { i64, ptr }
  %l30 = alloca %"compiler/msgs:Msg"
  %l31 = alloca i64
  %l32 = alloca ptr
  %l34 = alloca %"compiler/source:Span"
  %l35 = alloca ptr
  %s1 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t5 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t9 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t2, ptr %t3, i32 %t5)
  store ptr %t9, ptr %l9
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t10)
  store %"compiler/source:Span" %t12, ptr %l11
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l4, !tbaa !29
  %t14 = load ptr, ptr %l9, !tbaa !29
  %t15 = load %"compiler/source:Span", ptr %l11
  %t16 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t13, ptr %t14, %"compiler/source:Span" %t15)
  store ptr %t16, ptr %l12
  br label %bb3
bb3:
  %t17 = load ptr, ptr %l12, !tbaa !29
  store ptr %t17, ptr %l2, !tbaa !29
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t21 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t18)
  store i32 %t21, ptr %l15
  br label %bb4
bb4:
  %t22 = load i32, ptr %l15, !tbaa !23
  store i32 %t22, ptr %l3, !tbaa !23
  %t23 = load i32, ptr %l3, !tbaa !23
  %t24 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t27 = icmp ne i32 %t23, %t24
  br i1 %t27, label %bb5, label %bb6
bb5:
  %t29 = load i32, ptr %l3, !tbaa !23
  %t30 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t33 = icmp ne i32 %t29, %t30
  store i1 %t33, ptr %l19, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb7
bb7:
  %t35 = load i1, ptr %l19, !tbaa !21
  br i1 %t35, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s1
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l23, !tbaa !29
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t37)
  store %"compiler/source:Span" %t39, ptr %l25
  br label %bb10
bb9:
  br label %bb16
bb10:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l3, !tbaa !23
  %t44 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t40, i32 %t41)
  store { i64, ptr } %t44, ptr %l28
  br label %bb11
bb11:
  %t45 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t45, 0
  %t47 = extractvalue { i64, ptr } %t45, 1
  %t48 = mul i64 %t46, 1
  %t49 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t48)
  call void @llvm.memcpy.p0.p0.i64(ptr %t49, ptr %t47, i64 %t48, i1 false)
  %t50 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  %t53 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondNotBoolType(ptr %s1, ptr %s1, { i64, ptr } %t51)
  store %"compiler/msgs:Msg" %t53, ptr %l30
  br label %bb12
bb12:
  %t54 = load ptr, ptr %l23, !tbaa !29
  %t55 = load %"compiler/source:Span", ptr %l25
  %t56 = load %"compiler/msgs:Msg", ptr %l30
  %t57 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t54, %"compiler/source:Span" %t55, %"compiler/msgs:Msg" %t56)
  store i64 %t57, ptr %l31
  br label %bb13
bb13:
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l32, !tbaa !29
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t59)
  store %"compiler/source:Span" %t61, ptr %l34
  br label %bb14
bb14:
  %t62 = load ptr, ptr %l32, !tbaa !29
  %t63 = load %"compiler/source:Span", ptr %l34
  %t64 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t62, %"compiler/source:Span" %t63)
  store ptr %t64, ptr %l35
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s1)
  %t65 = load ptr, ptr %l35, !tbaa !29
  store ptr %t65, ptr %rv
  br label %ret
bb16:
  %t66 = load ptr, ptr %l2, !tbaa !29
  store ptr %t66, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecover(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, ptr %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca i64
  %l27 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca i1
  %l41 = alloca i32
  %l46 = alloca ptr
  %l47 = alloca i1
  %l55 = alloca i1
  %l56 = alloca i32
  %l59 = alloca ptr
  %l63 = alloca i32
  %l64 = alloca i32
  %l67 = alloca ptr
  %l72 = alloca i32
  %l73 = alloca { i64, ptr }
  %l83 = alloca i64
  %l86 = alloca i64
  %l104 = alloca i64
  %l106 = alloca i64
  %l108 = alloca i1
  %l115 = alloca i1
  %l118 = alloca i1
  %l119 = alloca i1
  %l121 = alloca ptr
  %l122 = alloca %"compiler/source:Span"
  %l125 = alloca { i64, ptr }
  %l127 = alloca %"compiler/msgs:Msg"
  %l128 = alloca i64
  %l133 = alloca ptr
  %l134 = alloca i1
  %l139 = alloca ptr
  %l140 = alloca i1
  %l148 = alloca i64
  %l153 = alloca ptr
  %l154 = alloca i1
  %l168 = alloca { i64, ptr }
  %l171 = alloca ptr
  %l172 = alloca i1
  %l175 = alloca ptr
  %l176 = alloca i1
  %l184 = alloca i64
  %s2 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s16 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t3 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eLen_3cBool_3e(ptr %v2, ptr %t1)
  store i64 %t3, ptr %l27
  br label %bb1
bb1:
  %t4 = load i64, ptr %l27, !tbaa !24
  %t5 = icmp eq i64 %t4, 0
  br i1 %t5, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t7 = load ptr, ptr %l1, !tbaa !29
  store ptr %t7, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t8 = load ptr, ptr %l29, !tbaa !29
  %t9 = icmp ne ptr %t8, null
  br i1 %t9, label %bb5, label %bb6
bb5:
  %t11 = load ptr, ptr %l29, !tbaa !29
  %t12 = load i64, ptr %t11
  %t14 = icmp eq i64 %t12, 5
  store i1 %t14, ptr %l30, !tbaa !21
  br label %bb6
bb6:
  %t15 = load i1, ptr %l30, !tbaa !21
  br i1 %t15, label %bb7, label %bb8
bb7:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", ptr, i32, %"compiler/source:Span" }, ptr %t18, i32 0, i32 0
  %t20 = load %"compiler/source:Span", ptr %t19
  store %"compiler/source:Span" %t20, ptr %l5
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [4 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", ptr, i32, %"compiler/source:Span" }, ptr %t24, i32 0, i32 1
  %t26 = load ptr, ptr %t25
  store ptr %t26, ptr %l6, !tbaa !29
  br label %bb9
bb8:
  br label %bb63
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 2
  %t34 = load i32, ptr %l2, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t37, ptr %l41
  br label %bb10
bb10:
  %t38 = load i32, ptr %l41
  %t40 = trunc i64 29 to i32
  %t41 = icmp eq i32 %t38, %t40
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb12:
  br label %bb13
bb13:
  %t45 = load ptr, ptr %l6, !tbaa !29
  store ptr %t45, ptr %l7, !tbaa !29
  %t47 = load ptr, ptr %l6, !tbaa !29
  store ptr %t47, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t48 = load ptr, ptr %l46, !tbaa !29
  %t49 = icmp ne ptr %t48, null
  br i1 %t49, label %bb14, label %bb15
bb14:
  %t51 = load ptr, ptr %l46, !tbaa !29
  %t52 = load i64, ptr %t51
  %t54 = icmp eq i64 %t52, 3
  store i1 %t54, ptr %l47, !tbaa !21
  br label %bb15
bb15:
  %t55 = load i1, ptr %l47, !tbaa !21
  br i1 %t55, label %bb16, label %bb17
bb16:
  %t56 = load ptr, ptr %l6, !tbaa !29
  %t58 = getelementptr { i64, [5 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", ptr, i32, i1 }, ptr %t58, i32 0, i32 1
  %t60 = load ptr, ptr %t59
  store ptr %t60, ptr %l8, !tbaa !29
  br label %bb18
bb17:
  br label %bb19
bb18:
  %t62 = load ptr, ptr %l8, !tbaa !29
  store ptr %t62, ptr %l7, !tbaa !29
  br label %bb20
bb19:
  br label %bb20
bb20:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load ptr, ptr %l7, !tbaa !29
  %t68 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTypeWritten(ptr %v0, ptr %v1, ptr %t64, ptr %t65, i1 false)
  store i1 %t68, ptr %l55
  br label %bb21
bb21:
  %t69 = load i1, ptr %l55, !tbaa !21
  br i1 %t69, label %bb22, label %bb23
bb22:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/check:Checker", ptr %t70, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/generic:Program", ptr %t73, i32 0, i32 2
  store ptr %t75, ptr %l59, !tbaa !29
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load ptr, ptr %l7, !tbaa !29
  %t81 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %t76, ptr %t77)
  store i32 %t81, ptr %l63
  br label %bb24
bb23:
  %t82 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t82, ptr %l56, !tbaa !23
  br label %bb26
bb24:
  %t84 = load ptr, ptr %l59, !tbaa !29
  %t85 = load i32, ptr %l63, !tbaa !23
  %t86 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t84, i32 %t85)
  store i32 %t86, ptr %l64
  br label %bb25
bb25:
  %t87 = load i32, ptr %l64, !tbaa !23
  store i32 %t87, ptr %l56, !tbaa !23
  br label %bb26
bb26:
  %t88 = load i32, ptr %l56, !tbaa !23
  store i32 %t88, ptr %l9, !tbaa !23
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/check:Checker", ptr %t89, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !29
  store ptr %t92, ptr %l67, !tbaa !29
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = getelementptr %"compiler/generic:Program", ptr %t96, i32 0, i32 2
  %t99 = load i32, ptr %l2, !tbaa !23
  %t102 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t98, i32 %t99)
  store i32 %t102, ptr %l72
  br label %bb27
bb27:
  %t103 = load ptr, ptr %l67, !tbaa !29
  %t104 = load i32, ptr %l72, !tbaa !23
  %t105 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMembers(ptr %v0, ptr %s2, ptr %t103, i32 %t104)
  store { i64, ptr } %t105, ptr %l73
  br label %bb28
bb28:
  %t106 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t106, ptr %l10, !tbaa !27
  %t107 = load i32, ptr %l9, !tbaa !23
  %t108 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t111 = icmp eq i32 %t107, %t108
  br i1 %t111, label %bb29, label %bb30
bb29:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/check:Checker", ptr %t113, i32 0, i32 90
  store i1 true, ptr %t115, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb30:
  br label %bb31
bb31:
  store i64 0, ptr %l11, !tbaa !24
  %t116 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t116, 0
  store i64 %t118, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t120 = load i64, ptr %l12, !tbaa !24
  %t121 = load i64, ptr %l11, !tbaa !24
  %t124 = icmp sgt i64 %t120, %t121
  br i1 %t124, label %bb32, label %bb33
bb32:
  %t126 = load i64, ptr %l13, !tbaa !24
  %t128 = icmp sgt i64 %t126, 0
  br i1 %t128, label %bb34, label %bb35
bb33:
  store i64 0, ptr %l83, !tbaa !24
  br label %bb37
bb34:
  %t130 = load i64, ptr %l12, !tbaa !24
  %t131 = load i64, ptr %l11, !tbaa !24
  %t134 = sub i64 %t130, %t131
  %t135 = load i64, ptr %l13, !tbaa !24
  %t138 = add i64 %t134, %t135
  %t140 = sub i64 %t138, 1
  %t141 = load i64, ptr %l13, !tbaa !24
  %t144 = sdiv i64 %t140, %t141
  store i64 %t144, ptr %l86, !tbaa !24
  br label %bb36
bb35:
  store i64 0, ptr %l86, !tbaa !24
  br label %bb36
bb36:
  %t146 = load i64, ptr %l86, !tbaa !24
  store i64 %t146, ptr %l83, !tbaa !24
  br label %bb37
bb37:
  %t147 = load i64, ptr %l83, !tbaa !24
  store i64 %t147, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb38
bb38:
  store %olang.scope zeroinitializer, ptr %s8
  %t148 = load i64, ptr %l15, !tbaa !24
  %t149 = load i64, ptr %l14, !tbaa !24
  %t152 = icmp slt i64 %t148, %t149
  %t154 = xor i1 %t152, true
  br i1 %t154, label %bb39, label %bb40
bb39:
  call void @__olang_scope_close(ptr %s8)
  br label %bb62
bb40:
  br label %bb41
bb41:
  %t156 = load i64, ptr %l11, !tbaa !24
  %t157 = load i64, ptr %l15, !tbaa !24
  %t158 = load i64, ptr %l13, !tbaa !24
  %t161 = mul i64 %t157, %t158
  %t164 = add i64 %t156, %t161
  store i64 %t164, ptr %l16, !tbaa !24
  %t166 = load i64, ptr %l16, !tbaa !24
  store i64 %t166, ptr %l104, !tbaa !24
  %t167 = load ptr, ptr %l3, !tbaa !29
  %t169 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eLen_3cBool_3e(ptr %v2, ptr %t167)
  store i64 %t169, ptr %l106
  br label %bb42
bb42:
  %t170 = load i64, ptr %l104, !tbaa !24
  %t171 = load i64, ptr %l106, !tbaa !24
  %t172 = icmp slt i64 %t170, %t171
  br i1 %t172, label %bb43, label %bb44
bb43:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/check:Checker", ptr %t174, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !29
  %t179 = getelementptr %"compiler/generic:Program", ptr %t177, i32 0, i32 2
  %t180 = load i64, ptr %l16, !tbaa !24
  %t182 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !27
  %t184 = getelementptr i32, ptr %t183, i64 %t180
  %t185 = load i32, ptr %t184, !tbaa !33
  %t186 = load i32, ptr %l9, !tbaa !23
  %t190 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t179, i32 %t185, i32 %t186)
  store i1 %t190, ptr %l115
  br label %bb45
bb44:
  store i1 false, ptr %l108, !tbaa !21
  br label %bb46
bb45:
  %t191 = load i1, ptr %l115, !tbaa !21
  store i1 %t191, ptr %l108, !tbaa !21
  br label %bb46
bb46:
  %t192 = load i1, ptr %l108, !tbaa !21
  br i1 %t192, label %bb47, label %bb48
bb47:
  %t193 = load ptr, ptr %l3, !tbaa !29
  %t194 = load i64, ptr %l16, !tbaa !24
  %t197 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v2, ptr %t193, i64 %t194)
  store i1 %t197, ptr %l118
  br label %bb49
bb48:
  br label %bb60
bb49:
  %t198 = load i1, ptr %l118, !tbaa !21
  br i1 %t198, label %bb50, label %bb51
bb50:
  store i1 true, ptr %l119, !tbaa !21
  br label %bb52
bb51:
  store i1 %a4, ptr %l119, !tbaa !21
  br label %bb52
bb52:
  %t201 = load i1, ptr %l119, !tbaa !21
  br i1 %t201, label %bb53, label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s10
  %t202 = load ptr, ptr %l0, !tbaa !29
  store ptr %t202, ptr %l121, !tbaa !29
  %t203 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t203, ptr %l122
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t205 = load i32, ptr %l9, !tbaa !23
  %t208 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s10, ptr %t204, i32 %t205)
  store { i64, ptr } %t208, ptr %l125
  br label %bb55
bb54:
  br label %bb58
bb55:
  %t209 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t210 = extractvalue { i64, ptr } %t209, 0
  %t211 = extractvalue { i64, ptr } %t209, 1
  %t212 = mul i64 %t210, 1
  %t213 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t212)
  call void @llvm.memcpy.p0.p0.i64(ptr %t213, ptr %t211, i64 %t212, i1 false)
  %t214 = insertvalue { i64, ptr } undef, i64 %t210, 0
  %t215 = insertvalue { i64, ptr } %t214, ptr %t213, 1
  %t217 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyCaseTwice(ptr %s10, ptr %s10, { i64, ptr } %t215)
  store %"compiler/msgs:Msg" %t217, ptr %l127
  br label %bb56
bb56:
  %t218 = load ptr, ptr %l121, !tbaa !29
  %t219 = load %"compiler/source:Span", ptr %l122
  %t220 = load %"compiler/msgs:Msg", ptr %l127
  %t221 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s10, ptr %t218, %"compiler/source:Span" %t219, %"compiler/msgs:Msg" %t220)
  store i64 %t221, ptr %l128
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s10)
  br label %bb58
bb58:
  %t222 = load ptr, ptr %l3, !tbaa !29
  %t223 = load i64, ptr %l16, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v2, ptr %t222, i64 %t223, i1 true)
  br label %bb59
bb59:
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s8)
  br label %bb61
bb61:
  %t226 = load i64, ptr %l15, !tbaa !24
  %t228 = add i64 %t226, 1
  store i64 %t228, ptr %l15, !tbaa !24
  br label %bb38
bb62:
  call void @__olang_scope_close(ptr %s2)
  br label %bb107
bb63:
  %t230 = load ptr, ptr %l1, !tbaa !29
  store ptr %t230, ptr %l133, !tbaa !29
  store i1 false, ptr %l134, !tbaa !21
  %t231 = load ptr, ptr %l133, !tbaa !29
  %t232 = icmp ne ptr %t231, null
  br i1 %t232, label %bb64, label %bb65
bb64:
  %t234 = load ptr, ptr %l133, !tbaa !29
  %t235 = load i64, ptr %t234
  %t237 = icmp eq i64 %t235, 1
  store i1 %t237, ptr %l134, !tbaa !21
  br label %bb65
bb65:
  %t238 = load i1, ptr %l134, !tbaa !21
  br i1 %t238, label %bb66, label %bb67
bb66:
  %t239 = load ptr, ptr %l1, !tbaa !29
  %t241 = getelementptr { i64, [4 x i64] }, ptr %t239, i32 0, i32 1
  %t242 = getelementptr { %"compiler/source:Span", ptr }, ptr %t241, i32 0, i32 1
  %t243 = load ptr, ptr %t242
  store ptr %t243, ptr %l17, !tbaa !29
  br label %bb72
bb67:
  %t245 = load ptr, ptr %l1, !tbaa !29
  store ptr %t245, ptr %l139, !tbaa !29
  store i1 false, ptr %l140, !tbaa !21
  %t246 = load ptr, ptr %l139, !tbaa !29
  %t247 = icmp ne ptr %t246, null
  br i1 %t247, label %bb68, label %bb69
bb68:
  %t249 = load ptr, ptr %l139, !tbaa !29
  %t250 = load i64, ptr %t249
  %t252 = icmp eq i64 %t250, 4
  store i1 %t252, ptr %l140, !tbaa !21
  br label %bb69
bb69:
  %t253 = load i1, ptr %l140, !tbaa !21
  br i1 %t253, label %bb70, label %bb71
bb70:
  %t254 = load ptr, ptr %l1, !tbaa !29
  %t256 = getelementptr { i64, [4 x i64] }, ptr %t254, i32 0, i32 1
  %t257 = getelementptr { %"compiler/source:Span", ptr }, ptr %t256, i32 0, i32 1
  %t258 = load ptr, ptr %t257
  store ptr %t258, ptr %l17, !tbaa !29
  br label %bb72
bb71:
  br label %bb78
bb72:
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t261 = load ptr, ptr %l17, !tbaa !29
  %t262 = load i32, ptr %l2, !tbaa !23
  %t266 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %t260, ptr %t261, i32 %t262)
  store i64 %t266, ptr %l148
  br label %bb73
bb73:
  %t267 = load i64, ptr %l148, !tbaa !24
  store i64 %t267, ptr %l18, !tbaa !24
  %t268 = load i64, ptr %l18, !tbaa !24
  %t270 = icmp sge i64 %t268, 0
  br i1 %t270, label %bb74, label %bb75
bb74:
  %t272 = load ptr, ptr %l3, !tbaa !29
  %t273 = load i64, ptr %l18, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v2, ptr %t272, i64 %t273, i1 true)
  br label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb77
bb77:
  br label %bb107
bb78:
  %t276 = load ptr, ptr %l1, !tbaa !29
  store ptr %t276, ptr %l153, !tbaa !29
  store i1 false, ptr %l154, !tbaa !21
  %t277 = load ptr, ptr %l153, !tbaa !29
  %t278 = icmp ne ptr %t277, null
  br i1 %t278, label %bb79, label %bb80
bb79:
  %t280 = load ptr, ptr %l153, !tbaa !29
  %t281 = load i64, ptr %t280
  %t283 = icmp eq i64 %t281, 2
  store i1 %t283, ptr %l154, !tbaa !21
  br label %bb80
bb80:
  %t284 = load i1, ptr %l154, !tbaa !21
  br i1 %t284, label %bb81, label %bb82
bb81:
  %t285 = load ptr, ptr %l1, !tbaa !29
  %t287 = getelementptr { i64, [4 x i64] }, ptr %t285, i32 0, i32 1
  %t288 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t287, i32 0, i32 1
  %t289 = load ptr, ptr %t288
  store ptr %t289, ptr %l19, !tbaa !29
  %t291 = load ptr, ptr %l1, !tbaa !29
  %t293 = getelementptr { i64, [4 x i64] }, ptr %t291, i32 0, i32 1
  %t294 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t293, i32 0, i32 2
  %t295 = load { i64, ptr }, ptr %t294
  store { i64, ptr } %t295, ptr %l20, !tbaa !27
  br label %bb83
bb82:
  br label %bb106
bb83:
  %t297 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t297, ptr %l21, !tbaa !27
  store i64 0, ptr %l22, !tbaa !24
  %t299 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t301 = extractvalue { i64, ptr } %t299, 0
  store i64 %t301, ptr %l23, !tbaa !24
  br label %bb84
bb84:
  store %olang.scope zeroinitializer, ptr %s16
  %t303 = load i64, ptr %l22, !tbaa !24
  %t304 = load i64, ptr %l23, !tbaa !24
  %t307 = icmp slt i64 %t303, %t304
  %t309 = xor i1 %t307, true
  br i1 %t309, label %bb85, label %bb86
bb85:
  call void @__olang_scope_close(ptr %s16)
  br label %bb100
bb86:
  br label %bb87
bb87:
  %t311 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t311, ptr %l168, !tbaa !27
  %t312 = load i64, ptr %l22, !tbaa !24
  %t314 = getelementptr { i64, ptr }, ptr %l168, i32 0, i32 1
  %t315 = load ptr, ptr %t314, !tbaa !27
  %t316 = getelementptr ptr, ptr %t315, i64 %t312
  %t317 = load ptr, ptr %t316, !tbaa !39
  store ptr %t317, ptr %l24, !tbaa !29
  %t319 = load ptr, ptr %l24, !tbaa !29
  store ptr %t319, ptr %l171, !tbaa !29
  store i1 false, ptr %l172, !tbaa !21
  %t320 = load ptr, ptr %l171, !tbaa !29
  %t321 = icmp ne ptr %t320, null
  br i1 %t321, label %bb88, label %bb89
bb88:
  %t323 = load ptr, ptr %l171, !tbaa !29
  %t324 = load i64, ptr %t323
  %t326 = icmp eq i64 %t324, 3
  store i1 %t326, ptr %l172, !tbaa !21
  br label %bb89
bb89:
  %t327 = load i1, ptr %l172, !tbaa !21
  br i1 %t327, label %bb90, label %bb91
bb90:
  br label %bb96
bb91:
  %t328 = load ptr, ptr %l24, !tbaa !29
  store ptr %t328, ptr %l175, !tbaa !29
  store i1 false, ptr %l176, !tbaa !21
  %t329 = load ptr, ptr %l175, !tbaa !29
  %t330 = icmp ne ptr %t329, null
  br i1 %t330, label %bb92, label %bb93
bb92:
  %t332 = load ptr, ptr %l175, !tbaa !29
  %t333 = load i64, ptr %t332
  %t335 = icmp eq i64 %t333, 0
  store i1 %t335, ptr %l176, !tbaa !21
  br label %bb93
bb93:
  %t336 = load i1, ptr %l176, !tbaa !21
  br i1 %t336, label %bb94, label %bb95
bb94:
  br label %bb96
bb95:
  br label %bb97
bb96:
  br label %bb98
bb97:
  call void @__olang_scope_close(ptr %s16)
  br label %ret
bb98:
  call void @__olang_scope_close(ptr %s16)
  br label %bb99
bb99:
  %t337 = load i64, ptr %l22, !tbaa !24
  %t339 = add i64 %t337, 1
  store i64 %t339, ptr %l22, !tbaa !24
  br label %bb84
bb100:
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t342 = load ptr, ptr %l19, !tbaa !29
  %t343 = load i32, ptr %l2, !tbaa !23
  %t347 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %t341, ptr %t342, i32 %t343)
  store i64 %t347, ptr %l184
  br label %bb101
bb101:
  %t348 = load i64, ptr %l184, !tbaa !24
  store i64 %t348, ptr %l25, !tbaa !24
  %t349 = load i64, ptr %l25, !tbaa !24
  %t351 = icmp sge i64 %t349, 0
  br i1 %t351, label %bb102, label %bb103
bb102:
  %t353 = load ptr, ptr %l3, !tbaa !29
  %t354 = load i64, ptr %l25, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v2, ptr %t353, i64 %t354, i1 true)
  br label %bb104
bb103:
  br label %bb105
bb104:
  br label %bb105
bb105:
  br label %bb107
bb106:
  br label %bb107
bb107:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectErr(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, %"compiler/msgs:Msg" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %l13 = alloca ptr
  %l22 = alloca i64
  %rv = alloca i64
  %t36 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 4
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l7, !tbaa !29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 0
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/load:Loader", ptr %t17, i32 0, i32 5
  %t23 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t19, i64 %a1)
  store ptr %t23, ptr %l13
  br label %bb1
bb1:
  %t24 = load ptr, ptr %l13, !tbaa !29
  %t26 = getelementptr %"compiler/load:Module", ptr %t24, i32 0, i32 4
  %t27 = load i64, ptr %t26, !tbaa !24
  %t28 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t29 = load i32, ptr %t28, !tbaa !23
  %t31 = sext i32 %t29 to i64
  %t32 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t33 = load i32, ptr %t32, !tbaa !23
  %t35 = sext i32 %t33 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t36
  %t37 = getelementptr { i64, [3 x i64] }, ptr %t36, i32 0, i32 0
  store i64 3, ptr %t37
  %t39 = insertvalue { i64, i64, i64 } undef, i64 %t27, 0
  %t41 = insertvalue { i64, i64, i64 } %t39, i64 %t31, 1
  %t43 = insertvalue { i64, i64, i64 } %t41, i64 %t35, 2
  %t44 = getelementptr { i64, [3 x i64] }, ptr %t36, i32 0, i32 1
  store { i64, i64, i64 } %t43, ptr %t44
  %t45 = load { i64, [3 x i64] }, ptr %t36
  %t47 = load ptr, ptr %l7, !tbaa !29
  %t50 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %t47, { i64, [3 x i64] } %t45, %"compiler/msgs:Msg" %a3)
  store i64 %t50, ptr %l22
  br label %bb2
bb2:
  %t51 = load i64, ptr %l22, !tbaa !24
  store i64 %t51, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l4, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t12, i32 %a1)
  store i32 %t16, ptr %l9
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l4, !tbaa !29
  %t18 = load i32, ptr %l9, !tbaa !23
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t19, ptr %l10
  br label %bb2
bb2:
  %t20 = load i32, ptr %l10
  store i32 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edecls(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca { i64, ptr }
  %l15 = alloca %"compiler/source:Span"
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l29 = alloca i1
  %l42 = alloca { i64, ptr }
  %l46 = alloca ptr
  %l50 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l54 = alloca i64
  %l57 = alloca ptr
  %l58 = alloca i1
  %l78 = alloca ptr
  %l79 = alloca i1
  %l107 = alloca ptr
  %l108 = alloca i1
  %l113 = alloca ptr
  %l114 = alloca i64
  %l115 = alloca ptr
  %l118 = alloca ptr
  %l119 = alloca i64
  %l125 = alloca %"compiler/source:Span"
  %l127 = alloca i64
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  store { i64, ptr } %a2, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l6, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l5, !tbaa !24
  %t8 = load i64, ptr %l6, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb55
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t15, ptr %l25, !tbaa !27
  %t16 = load i64, ptr %l5, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l7, !tbaa !29
  %t23 = load ptr, ptr %l7, !tbaa !29
  store ptr %t23, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t24 = load ptr, ptr %l28, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t27 = load ptr, ptr %l28, !tbaa !29
  %t28 = load i64, ptr %t27
  %t30 = icmp eq i64 %t28, 3
  store i1 %t30, ptr %l29, !tbaa !21
  br label %bb6
bb6:
  %t31 = load i1, ptr %l29, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t32 = load ptr, ptr %l7, !tbaa !29
  %t34 = getelementptr { i64, [4 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", ptr }, ptr %t34, i32 0, i32 1
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l8, !tbaa !29
  br label %bb9
bb8:
  br label %bb19
bb9:
  %t38 = load ptr, ptr %l8, !tbaa !29
  %t40 = getelementptr %"compiler/ast:VarDecl", ptr %t38, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t43 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  store i64 %t45, ptr %l11, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s5
  %t47 = load i64, ptr %l10, !tbaa !24
  %t48 = load i64, ptr %l11, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s5)
  br label %bb18
bb12:
  br label %bb13
bb13:
  %t55 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t55, ptr %l42, !tbaa !27
  %t56 = load i64, ptr %l10, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr i32, ptr %t59, i64 %t56
  %t61 = load i32, ptr %t60, !tbaa !33
  store i32 %t61, ptr %l12, !tbaa !23
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 24
  store ptr %t65, ptr %l46, !tbaa !29
  %t66 = load i64, ptr %l1, !tbaa !24
  %t67 = load i32, ptr %l12, !tbaa !23
  %t69 = sext i32 %t67 to i64
  %t72 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s5, i64 %t66, i64 %t69)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t72, ptr %l50
  br label %bb14
bb14:
  %t73 = load ptr, ptr %l46, !tbaa !29
  %t74 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l50
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_Hb6f924c91b81223120b2cba278ece4a6(ptr %v0, ptr %t73, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t74)
  br label %bb15
bb15:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i64, ptr %l1, !tbaa !24
  %t77 = load i32, ptr %l12, !tbaa !23
  %t81 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalBody(ptr %v0, ptr %t75, i64 %t76, i32 %t77)
  store i64 %t81, ptr %l54
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s5)
  br label %bb17
bb17:
  %t82 = load i64, ptr %l10, !tbaa !24
  %t84 = add i64 %t82, 1
  store i64 %t84, ptr %l10, !tbaa !24
  br label %bb10
bb18:
  br label %bb53
bb19:
  %t86 = load ptr, ptr %l7, !tbaa !29
  store ptr %t86, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t87 = load ptr, ptr %l57, !tbaa !29
  %t88 = icmp ne ptr %t87, null
  br i1 %t88, label %bb20, label %bb21
bb20:
  %t90 = load ptr, ptr %l57, !tbaa !29
  %t91 = load i64, ptr %t90
  %t93 = icmp eq i64 %t91, 6
  store i1 %t93, ptr %l58, !tbaa !21
  br label %bb21
bb21:
  %t94 = load i1, ptr %l58, !tbaa !21
  br i1 %t94, label %bb22, label %bb23
bb22:
  %t95 = load ptr, ptr %l7, !tbaa !29
  %t97 = getelementptr { i64, [4 x i64] }, ptr %t95, i32 0, i32 1
  %t98 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } }, ptr %t97, i32 0, i32 0
  %t99 = load %"compiler/source:Span", ptr %t98
  store %"compiler/source:Span" %t99, ptr %l13
  %t101 = load ptr, ptr %l7, !tbaa !29
  %t103 = getelementptr { i64, [4 x i64] }, ptr %t101, i32 0, i32 1
  %t104 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } }, ptr %t103, i32 0, i32 2
  %t105 = load { i64, ptr }, ptr %t104
  store { i64, ptr } %t105, ptr %l14, !tbaa !27
  br label %bb24
bb23:
  br label %bb29
bb24:
  %t107 = load i64, ptr %l1, !tbaa !24
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/check:Checker", ptr %t108, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = getelementptr %"compiler/generic:Program", ptr %t111, i32 0, i32 0
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = getelementptr %"compiler/load:Loader", ptr %t114, i32 0, i32 7
  %t117 = load i64, ptr %t116, !tbaa !24
  %t120 = icmp eq i64 %t107, %t117
  br i1 %t120, label %bb25, label %bb26
bb25:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load i64, ptr %l1, !tbaa !24
  %t124 = load %"compiler/source:Span", ptr %l13
  %t125 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t126 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etestBody(ptr %v0, ptr %v1, ptr %t122, i64 %t123, %"compiler/source:Span" %t124, { i64, ptr } %t125, i64 %t126)
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb28
bb28:
  %t132 = load i64, ptr %l3, !tbaa !24
  %t134 = add i64 %t132, 1
  store i64 %t134, ptr %l3, !tbaa !24
  br label %bb53
bb29:
  %t136 = load ptr, ptr %l7, !tbaa !29
  store ptr %t136, ptr %l78, !tbaa !29
  store i1 false, ptr %l79, !tbaa !21
  %t137 = load ptr, ptr %l78, !tbaa !29
  %t138 = icmp ne ptr %t137, null
  br i1 %t138, label %bb30, label %bb31
bb30:
  %t140 = load ptr, ptr %l78, !tbaa !29
  %t141 = load i64, ptr %t140
  %t143 = icmp eq i64 %t141, 2
  store i1 %t143, ptr %l79, !tbaa !21
  br label %bb31
bb31:
  %t144 = load i1, ptr %l79, !tbaa !21
  br i1 %t144, label %bb32, label %bb33
bb32:
  %t145 = load ptr, ptr %l7, !tbaa !29
  %t147 = getelementptr { i64, [4 x i64] }, ptr %t145, i32 0, i32 1
  %t148 = getelementptr { %"compiler/source:Span", ptr }, ptr %t147, i32 0, i32 0
  %t149 = load %"compiler/source:Span", ptr %t148
  store %"compiler/source:Span" %t149, ptr %l15
  %t151 = load ptr, ptr %l7, !tbaa !29
  %t153 = getelementptr { i64, [4 x i64] }, ptr %t151, i32 0, i32 1
  %t154 = getelementptr { %"compiler/source:Span", ptr }, ptr %t153, i32 0, i32 1
  %t155 = load ptr, ptr %t154
  store ptr %t155, ptr %l16, !tbaa !29
  br label %bb34
bb33:
  br label %bb40
bb34:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load i64, ptr %l1, !tbaa !24
  %t159 = load %"compiler/source:Span", ptr %l15
  %t160 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeRules(ptr %v0, ptr %v1, ptr %t157, i64 %t158, %"compiler/source:Span" %t159, ptr %t160)
  br label %bb35
bb35:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load i64, ptr %l1, !tbaa !24
  %t168 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaredCtor(ptr %v0, ptr %v1, ptr %t166, i64 %t167, ptr %t168)
  br label %bb36
bb36:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load i64, ptr %l1, !tbaa !24
  %t175 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitSets(ptr %v0, ptr %v1, ptr %t173, i64 %t174, ptr %t175)
  br label %bb37
bb37:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load i64, ptr %l1, !tbaa !24
  %t182 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitHeader(ptr %v0, ptr %v1, ptr %t180, i64 %t181, ptr %t182)
  br label %bb38
bb38:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load i64, ptr %l1, !tbaa !24
  %t189 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitContracts(ptr %v0, ptr %v1, ptr %t187, i64 %t188, ptr %t189)
  br label %bb39
bb39:
  br label %bb53
bb40:
  %t194 = load ptr, ptr %l7, !tbaa !29
  store ptr %t194, ptr %l107, !tbaa !29
  store i1 false, ptr %l108, !tbaa !21
  %t195 = load ptr, ptr %l107, !tbaa !29
  %t196 = icmp ne ptr %t195, null
  br i1 %t196, label %bb41, label %bb42
bb41:
  %t198 = load ptr, ptr %l107, !tbaa !29
  %t199 = load i64, ptr %t198
  %t201 = icmp eq i64 %t199, 7
  store i1 %t201, ptr %l108, !tbaa !21
  br label %bb42
bb42:
  %t202 = load i1, ptr %l108, !tbaa !21
  br i1 %t202, label %bb43, label %bb44
bb43:
  %t203 = load ptr, ptr %l7, !tbaa !29
  %t205 = getelementptr { i64, [4 x i64] }, ptr %t203, i32 0, i32 1
  %t206 = getelementptr { %"compiler/source:Span", ptr }, ptr %t205, i32 0, i32 1
  %t207 = load ptr, ptr %t206
  store ptr %t207, ptr %l17, !tbaa !29
  br label %bb45
bb44:
  br label %bb52
bb45:
  %t209 = load ptr, ptr %l0, !tbaa !29
  store ptr %t209, ptr %l113, !tbaa !29
  %t210 = load i64, ptr %l1, !tbaa !24
  store i64 %t210, ptr %l114, !tbaa !24
  %t211 = load ptr, ptr %l17, !tbaa !29
  store ptr %t211, ptr %l115, !tbaa !29
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"compiler/check:Checker", ptr %t212, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !29
  %t217 = getelementptr %"compiler/generic:Program", ptr %t215, i32 0, i32 0
  %t218 = load ptr, ptr %t217, !tbaa !29
  store ptr %t218, ptr %l118, !tbaa !29
  %t219 = load i64, ptr %l1, !tbaa !24
  store i64 %t219, ptr %l119, !tbaa !24
  %t220 = load ptr, ptr %l17, !tbaa !29
  %t222 = getelementptr %"compiler/ast:TopIf", ptr %t220, i32 0, i32 0
  %t223 = load ptr, ptr %t222, !tbaa !29
  %t225 = icmp eq ptr %t223, null
  br i1 %t225, label %bb46, label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_9f7e5ad647601e13_a7b1cb3e26ad346f)
  unreachable
bb47:
  br label %bb48
bb48:
  %t227 = load ptr, ptr %l17, !tbaa !29
  %t229 = getelementptr %"compiler/ast:TopIf", ptr %t227, i32 0, i32 0
  %t230 = load ptr, ptr %t229, !tbaa !29
  %t232 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t230)
  store %"compiler/source:Span" %t232, ptr %l125
  br label %bb49
bb49:
  %t233 = getelementptr %"compiler/source:Span", ptr %l125, i32 0, i32 0
  %t234 = load i32, ptr %t233, !tbaa !23
  %t235 = load ptr, ptr %l118, !tbaa !29
  %t236 = load i64, ptr %l119, !tbaa !24
  %t238 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eChosen(ptr %v0, ptr %t235, i64 %t236, i32 %t234)
  store i64 %t238, ptr %l127
  br label %bb50
bb50:
  %t239 = load ptr, ptr %l113, !tbaa !29
  %t240 = load i64, ptr %l114, !tbaa !24
  %t241 = load ptr, ptr %l115, !tbaa !29
  %t242 = load i64, ptr %l127, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclsIf(ptr %v0, ptr %v1, ptr %t239, i64 %t240, ptr %t241, i64 %t242, i64 0)
  br label %bb51
bb51:
  br label %bb53
bb52:
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s2)
  br label %bb54
bb54:
  %t243 = load i64, ptr %l5, !tbaa !24
  %t245 = add i64 %t243, 1
  store i64 %t245, ptr %l5, !tbaa !24
  br label %bb1
bb55:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eescapes(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l25 = alloca ptr
  %l35 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l41 = alloca i64
  %l45 = alloca i64
  %l48 = alloca i64
  %l66 = alloca ptr
  %l70 = alloca i32
  %l80 = alloca i64
  %l83 = alloca i64
  %l102 = alloca ptr
  %l106 = alloca i32
  %l113 = alloca { i64, ptr }
  %l116 = alloca { i64, ptr }
  %l117 = alloca i32
  %l126 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l25
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l25, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i64, ptr %l2, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eescapeRules(ptr %v0, ptr %t9, %"compiler/source:Span" %a1, i64 %t11, i64 %t12)
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l4, !tbaa !29
  %t19 = getelementptr %"compiler/check:frame", ptr %t17, i32 0, i32 15
  %t20 = load i64, ptr %t19, !tbaa !24
  %t22 = icmp eq i64 %t20, 0
  br i1 %t22, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  br label %bb8
bb8:
  %t24 = load ptr, ptr @__olang_prog_scope
  %t25 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %t24)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l35
  br label %bb9
bb9:
  %t26 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l35
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t26, ptr %l5
  %t27 = load i64, ptr %l2, !tbaa !24
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = add i64 %t27, %t28
  store i64 %t31, ptr %l6, !tbaa !24
  %t33 = load ptr, ptr %l4, !tbaa !29
  %t35 = getelementptr %"compiler/check:frame", ptr %t33, i32 0, i32 23
  %t37 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t35)
  store i64 %t37, ptr %l41
  br label %bb10
bb10:
  %t38 = load i64, ptr %l41, !tbaa !24
  store i64 %t38, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t39 = load i64, ptr %l7, !tbaa !24
  %t40 = load i64, ptr %l6, !tbaa !24
  %t43 = icmp sgt i64 %t39, %t40
  br i1 %t43, label %bb11, label %bb12
bb11:
  %t45 = load i64, ptr %l8, !tbaa !24
  %t47 = icmp sgt i64 %t45, 0
  br i1 %t47, label %bb13, label %bb14
bb12:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb16
bb13:
  %t49 = load i64, ptr %l7, !tbaa !24
  %t50 = load i64, ptr %l6, !tbaa !24
  %t53 = sub i64 %t49, %t50
  %t54 = load i64, ptr %l8, !tbaa !24
  %t57 = add i64 %t53, %t54
  %t59 = sub i64 %t57, 1
  %t60 = load i64, ptr %l8, !tbaa !24
  %t63 = sdiv i64 %t59, %t60
  store i64 %t63, ptr %l48, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l48, !tbaa !24
  br label %bb15
bb15:
  %t65 = load i64, ptr %l48, !tbaa !24
  store i64 %t65, ptr %l45, !tbaa !24
  br label %bb16
bb16:
  %t66 = load i64, ptr %l45, !tbaa !24
  store i64 %t66, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s4
  %t67 = load i64, ptr %l10, !tbaa !24
  %t68 = load i64, ptr %l9, !tbaa !24
  %t71 = icmp slt i64 %t67, %t68
  %t73 = xor i1 %t71, true
  br i1 %t73, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s4)
  br label %bb24
bb19:
  br label %bb20
bb20:
  %t75 = load i64, ptr %l6, !tbaa !24
  %t76 = load i64, ptr %l10, !tbaa !24
  %t77 = load i64, ptr %l8, !tbaa !24
  %t80 = mul i64 %t76, %t77
  %t83 = add i64 %t75, %t80
  store ptr %l5, ptr %l66, !tbaa !29
  %t85 = load ptr, ptr %l4, !tbaa !29
  %t87 = getelementptr %"compiler/check:frame", ptr %t85, i32 0, i32 23
  %t91 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t87, i64 %t83)
  store i32 %t91, ptr %l70
  br label %bb21
bb21:
  %t92 = load ptr, ptr %l66, !tbaa !29
  %t93 = load i32, ptr %l70, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t92, i32 %t93)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb23:
  %t94 = load i64, ptr %l10, !tbaa !24
  %t96 = add i64 %t94, 1
  store i64 %t96, ptr %l10, !tbaa !24
  br label %bb17
bb24:
  %t98 = load i64, ptr %l2, !tbaa !24
  store i64 %t98, ptr %l12, !tbaa !24
  %t100 = load i64, ptr %l2, !tbaa !24
  %t101 = load i64, ptr %l3, !tbaa !24
  %t104 = add i64 %t100, %t101
  store i64 %t104, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t106 = load i64, ptr %l13, !tbaa !24
  %t107 = load i64, ptr %l12, !tbaa !24
  %t110 = icmp sgt i64 %t106, %t107
  br i1 %t110, label %bb25, label %bb26
bb25:
  %t112 = load i64, ptr %l14, !tbaa !24
  %t114 = icmp sgt i64 %t112, 0
  br i1 %t114, label %bb27, label %bb28
bb26:
  store i64 0, ptr %l80, !tbaa !24
  br label %bb30
bb27:
  %t116 = load i64, ptr %l13, !tbaa !24
  %t117 = load i64, ptr %l12, !tbaa !24
  %t120 = sub i64 %t116, %t117
  %t121 = load i64, ptr %l14, !tbaa !24
  %t124 = add i64 %t120, %t121
  %t126 = sub i64 %t124, 1
  %t127 = load i64, ptr %l14, !tbaa !24
  %t130 = sdiv i64 %t126, %t127
  store i64 %t130, ptr %l83, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l83, !tbaa !24
  br label %bb29
bb29:
  %t132 = load i64, ptr %l83, !tbaa !24
  store i64 %t132, ptr %l80, !tbaa !24
  br label %bb30
bb30:
  %t133 = load i64, ptr %l80, !tbaa !24
  store i64 %t133, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb31
bb31:
  store %olang.scope zeroinitializer, ptr %s7
  %t134 = load i64, ptr %l16, !tbaa !24
  %t135 = load i64, ptr %l15, !tbaa !24
  %t138 = icmp slt i64 %t134, %t135
  %t140 = xor i1 %t138, true
  br i1 %t140, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s7)
  br label %bb38
bb33:
  br label %bb34
bb34:
  %t142 = load i64, ptr %l12, !tbaa !24
  %t143 = load i64, ptr %l16, !tbaa !24
  %t144 = load i64, ptr %l14, !tbaa !24
  %t147 = mul i64 %t143, %t144
  %t150 = add i64 %t142, %t147
  %t152 = load ptr, ptr %l4, !tbaa !29
  %t154 = getelementptr %"compiler/check:frame", ptr %t152, i32 0, i32 24
  store ptr %t154, ptr %l102, !tbaa !29
  %t155 = load ptr, ptr %l4, !tbaa !29
  %t157 = getelementptr %"compiler/check:frame", ptr %t155, i32 0, i32 23
  %t161 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t157, i64 %t150)
  store i32 %t161, ptr %l106
  br label %bb35
bb35:
  %t162 = load ptr, ptr %l102, !tbaa !29
  %t163 = load i32, ptr %l106, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t162, i32 %t163)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s7)
  br label %bb37
bb37:
  %t164 = load i64, ptr %l16, !tbaa !24
  %t166 = add i64 %t164, 1
  store i64 %t166, ptr %l16, !tbaa !24
  br label %bb31
bb38:
  %t168 = load ptr, ptr %l4, !tbaa !29
  %t170 = getelementptr %"compiler/check:frame", ptr %t168, i32 0, i32 23
  %t171 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eTrun_H62a150000c9aaeb3d030aed80f9d3e2e(ptr %v0, ptr %t170, i64 %t171)
  br label %bb39
bb39:
  store ptr %l5, ptr %l18, !tbaa !29
  store i64 0, ptr %l19, !tbaa !24
  br label %bb40
bb40:
  store %olang.scope zeroinitializer, ptr %s10
  %t175 = load ptr, ptr %l18, !tbaa !29
  %t176 = load i64, ptr %l19, !tbaa !24
  %t179 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eRunF_H9c1707946c43ec840ffe1821bea89b1f(ptr %s0, ptr %t175, i64 %t176)
  %t180 = extractvalue { i32, { i64, ptr } } %t179, 1
  %t181 = extractvalue { i32, { i64, ptr } } %t179, 0
  store i32 %t181, ptr %l117
  %t182 = icmp ne i32 %t181, 0
  br i1 %t182, label %bb42, label %ok.183
ok.183:
  store { i64, ptr } %t180, ptr %l116
  br label %bb41
bb41:
  %t184 = load { i64, ptr }, ptr %l116, !tbaa !27
  store { i64, ptr } %t184, ptr %l113, !tbaa !27
  br label %bb46
bb42:
  %t185 = load i32, ptr %l117, !tbaa !23
  %t186 = ashr i32 %t185, 16
  %t188 = icmp eq i32 %t186, 1
  br i1 %t188, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  call void @__olang_check_failed(ptr @olang_loc_294a26fa6e899319_197e495586e916bd)
  unreachable
bb45:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s10)
  br label %bb55
bb46:
  %t190 = load { i64, ptr }, ptr %l113, !tbaa !27
  store { i64, ptr } %t190, ptr %l20, !tbaa !27
  %t191 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t191, 0
  store i64 %t193, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb47
bb47:
  store %olang.scope zeroinitializer, ptr %s11
  %t195 = load i64, ptr %l22, !tbaa !24
  %t196 = load i64, ptr %l21, !tbaa !24
  %t199 = icmp slt i64 %t195, %t196
  %t201 = xor i1 %t199, true
  br i1 %t201, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s11)
  br label %bb53
bb49:
  br label %bb50
bb50:
  %t203 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t203, ptr %l126, !tbaa !27
  %t204 = load i64, ptr %l22, !tbaa !24
  %t206 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t207 = load ptr, ptr %t206, !tbaa !27
  %t208 = getelementptr i32, ptr %t207, i64 %t204
  %t209 = load i32, ptr %t208, !tbaa !33
  %t211 = load ptr, ptr %l4, !tbaa !29
  %t213 = getelementptr %"compiler/check:frame", ptr %t211, i32 0, i32 23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t213, i32 %t209)
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s11)
  br label %bb52
bb52:
  %t217 = load i64, ptr %l22, !tbaa !24
  %t219 = add i64 %t217, 1
  store i64 %t219, ptr %l22, !tbaa !24
  br label %bb47
bb53:
  %t221 = load i64, ptr %l19, !tbaa !24
  %t222 = load i64, ptr %l21, !tbaa !24
  %t225 = add i64 %t221, %t222
  store i64 %t225, ptr %l19, !tbaa !24
  call void @__olang_scope_close(ptr %s10)
  br label %bb54
bb54:
  br label %bb40
bb55:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexportArray(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l5 = alloca i1
  %l9 = alloca i32
  %l14 = alloca i32
  %l17 = alloca i1
  %l18 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i1, ptr %l5, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load i32, ptr %l1, !tbaa !23
  %t12 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t8, i32 %t9)
  store i32 %t12, ptr %l9
  br label %bb5
bb5:
  %t13 = load i32, ptr %l9, !tbaa !23
  store i32 %t13, ptr %l2, !tbaa !23
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/generic:Program", ptr %t17, i32 0, i32 2
  %t20 = load i32, ptr %l2, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t19, i32 %t20)
  store i32 %t23, ptr %l14
  br label %bb6
bb6:
  %t24 = load i32, ptr %l14
  %t26 = trunc i64 19 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l18, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/generic:Program", ptr %t33, i32 0, i32 2
  %t36 = load i32, ptr %l2, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t35, i32 %t36)
  store i32 %t39, ptr %l23
  br label %bb9
bb8:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb11
bb9:
  %t40 = load ptr, ptr %l18, !tbaa !29
  %t41 = load i32, ptr %l23, !tbaa !23
  %t42 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternValue(ptr %v0, ptr %t40, i32 %t41)
  store i1 %t42, ptr %l24
  br label %bb10
bb10:
  %t43 = load i1, ptr %l24, !tbaa !21
  store i1 %t43, ptr %l17, !tbaa !21
  br label %bb11
bb11:
  %t44 = load i1, ptr %l17, !tbaa !21
  store i1 %t44, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforRange(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3, ptr %a4, i32 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l6 = alloca i32
  %lp7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca %"compiler/check:litv"
  %l13 = alloca ptr
  %lp14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca %"compiler/check:litv"
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l37 = alloca ptr
  %l38 = alloca i64
  %l39 = alloca i64
  %l41 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l49 = alloca { i64, ptr }
  %l55 = alloca %"compiler/check:litv"
  %l57 = alloca i1
  %l59 = alloca ptr
  %l61 = alloca %"compiler/source:Span"
  %l62 = alloca %"compiler/msgs:Msg"
  %l63 = alloca i64
  %l67 = alloca ptr
  %l72 = alloca ptr
  %l74 = alloca %"compiler/source:Span"
  %l75 = alloca ptr
  %l78 = alloca i32
  %l81 = alloca i1
  %l82 = alloca ptr
  %l85 = alloca i32
  %l86 = alloca i1
  %l88 = alloca ptr
  %l90 = alloca %"compiler/source:Span"
  %l91 = alloca ptr
  %l94 = alloca i32
  %l95 = alloca { i64, ptr }
  %l97 = alloca %"compiler/msgs:Msg"
  %l98 = alloca i64
  %l103 = alloca i1
  %l104 = alloca ptr
  %l107 = alloca i32
  %l108 = alloca i1
  %l111 = alloca i32
  %l118 = alloca { i64, ptr }
  %l123 = alloca i32
  %l127 = alloca ptr
  %l128 = alloca { i64, ptr }
  %l130 = alloca { i64, ptr }
  %l132 = alloca ptr
  %l134 = alloca %"compiler/source:Span"
  %l135 = alloca ptr
  %l136 = alloca i1
  %l137 = alloca ptr
  %l138 = alloca i1
  %l145 = alloca { i64, ptr }
  %l148 = alloca %"compiler/check:litv"
  %l150 = alloca i1
  %l153 = alloca i1
  %l156 = alloca i1
  %l159 = alloca ptr
  %l160 = alloca { i64, ptr }
  %l162 = alloca %"compiler/source:Span"
  %l163 = alloca %"compiler/msgs:Msg"
  %l164 = alloca i64
  %l168 = alloca i64
  %l174 = alloca i64
  %l177 = alloca i64
  %l195 = alloca { i64, ptr }
  %l200 = alloca ptr
  %l201 = alloca ptr
  %l202 = alloca { i64, ptr }
  %l204 = alloca ptr
  %l206 = alloca { i64, ptr }
  %l210 = alloca %"compiler/check:litv"
  %l212 = alloca ptr
  %l214 = alloca ptr
  %l215 = alloca ptr
  %l216 = alloca { i64, ptr }
  %l221 = alloca ptr
  %l222 = alloca i32
  %l223 = alloca { i64, ptr }
  %l226 = alloca %"compiler/source:Span"
  %l227 = alloca ptr
  %l233 = alloca { i64, ptr }
  %l237 = alloca ptr
  %l241 = alloca ptr
  %l245 = alloca { i64, ptr }
  %l248 = alloca { i64, ptr }
  %l250 = alloca { i64, ptr }
  %l256 = alloca { i64, ptr }
  %l261 = alloca i64
  %l273 = alloca i64
  %l274 = alloca ptr
  %l275 = alloca %"compiler/source:Span"
  %l278 = alloca i32
  %l287 = alloca i64
  %l296 = alloca ptr
  %l297 = alloca %"compiler/source:Span"
  %l298 = alloca i32
  %l299 = alloca i32
  %l303 = alloca ptr
  %l307 = alloca ptr
  %l309 = alloca ptr
  %l310 = alloca ptr
  %l311 = alloca %"compiler/source:Span"
  %l312 = alloca i32
  %l313 = alloca i32
  %l314 = alloca ptr
  %l315 = alloca %"compiler/source:Span"
  %l316 = alloca i32
  %l317 = alloca i32
  %l318 = alloca ptr
  %l322 = alloca ptr
  %l324 = alloca ptr
  %l328 = alloca ptr
  %l330 = alloca ptr
  %l331 = alloca ptr
  %l332 = alloca %"compiler/source:Span"
  %l333 = alloca i32
  %l334 = alloca i32
  %l338 = alloca ptr
  %l342 = alloca ptr
  %l344 = alloca ptr
  %l345 = alloca ptr
  %l346 = alloca %"compiler/source:Span"
  %l347 = alloca i32
  %l348 = alloca i32
  %l352 = alloca ptr
  %l356 = alloca ptr
  %l358 = alloca ptr
  %l359 = alloca %"compiler/source:Span"
  %l360 = alloca i32
  %l361 = alloca ptr
  %l362 = alloca ptr
  %l363 = alloca %"compiler/source:Span"
  %l364 = alloca i32
  %l365 = alloca i32
  %l366 = alloca ptr
  %l370 = alloca ptr
  %l372 = alloca ptr
  %l373 = alloca ptr
  %l377 = alloca ptr
  %l378 = alloca %"compiler/typed:Cond"
  %l382 = alloca %"compiler/source:Span"
  %l383 = alloca i32
  %l384 = alloca ptr
  %l386 = alloca ptr
  %l390 = alloca ptr
  %l391 = alloca %"compiler/typed:Cond"
  %l398 = alloca i64
  %l410 = alloca i64
  %l411 = alloca ptr
  %l412 = alloca %"compiler/source:Span"
  %l415 = alloca i32
  %l419 = alloca ptr
  %l435 = alloca ptr
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %rv = alloca ptr
  %t474 = alloca { i64, [3 x i64] }, align 8
  %t507 = alloca { i64, [3 x i64] }, align 8
  %t536 = alloca { i64, [3 x i64] }, align 8
  %t702 = alloca { i64, [5 x i64] }, align 8
  %t733 = alloca { i64, [5 x i64] }, align 8
  %t761 = alloca { i64, [3 x i64] }, align 8
  %t796 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t1, ptr %l6, !tbaa !23
  %t3 = load ptr, ptr @__olang_prog_scope
  %t4 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_3f_26_3e(ptr %t3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %l41
  br label %bb1
bb1:
  %t5 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store ptr %t5, ptr %lp7
  %t6 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l41
  %t7 = load ptr, ptr %lp7
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %t7
  %t8 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t8, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l10, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t14 = load i64, ptr %l9, !tbaa !24
  %t15 = load i64, ptr %l10, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb48
bb4:
  br label %bb5
bb5:
  %t22 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t22, ptr %l49, !tbaa !27
  %t23 = load i64, ptr %l9, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l11, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l11, !tbaa !29
  %t35 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v2, ptr %t30, ptr %t31)
  store %"compiler/check:litv" %t35, ptr %l55
  br label %bb6
bb6:
  %t36 = load %"compiler/check:litv", ptr %l55
  store %"compiler/check:litv" %t36, ptr %l12
  %t37 = getelementptr %"compiler/check:litv", ptr %l12, i32 0, i32 0
  %t38 = load i1, ptr %t37, !tbaa !21
  br i1 %t38, label %bb7, label %bb8
bb7:
  %t40 = getelementptr %"compiler/check:litv", ptr %l12, i32 0, i32 1
  %t41 = load i1, ptr %t40, !tbaa !21
  store i1 %t41, ptr %l57, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb9
bb9:
  %t43 = load i1, ptr %l57, !tbaa !21
  br i1 %t43, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l59, !tbaa !29
  %t45 = load ptr, ptr %l11, !tbaa !29
  %t47 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t45)
  store %"compiler/source:Span" %t47, ptr %l61
  br label %bb12
bb11:
  br label %bb15
bb12:
  %t48 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eRangeNotInt(ptr %s3, ptr %s3, { i64, ptr } { i64 3, ptr @.d6 })
  store %"compiler/msgs:Msg" %t48, ptr %l62
  br label %bb13
bb13:
  %t49 = load ptr, ptr %l59, !tbaa !29
  %t50 = load %"compiler/source:Span", ptr %l61
  %t51 = load %"compiler/msgs:Msg", ptr %l62
  %t52 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t49, %"compiler/source:Span" %t50, %"compiler/msgs:Msg" %t51)
  store i64 %t52, ptr %l63
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  store ptr null, ptr %rv
  br label %ret
bb15:
  %t54 = getelementptr %"compiler/check:litv", ptr %l12, i32 0, i32 0
  %t55 = load i1, ptr %t54, !tbaa !21
  br i1 %t55, label %bb16, label %bb17
bb16:
  %t57 = load ptr, ptr %lp7
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_3f_26_3e_2e_H4d3879e0682f4949b04a377fac27da65(ptr %v0, ptr %v0, ptr %t57, ptr null)
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb47
bb19:
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l67, !tbaa !29
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l11, !tbaa !29
  %t63 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t67 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %t60, ptr %t61, i32 %t63)
  store ptr %t67, ptr %l72
  br label %bb20
bb20:
  %t68 = load ptr, ptr %l11, !tbaa !29
  %t70 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t68)
  store %"compiler/source:Span" %t70, ptr %l74
  br label %bb21
bb21:
  %t71 = load ptr, ptr %l67, !tbaa !29
  %t72 = load ptr, ptr %l72, !tbaa !29
  %t73 = load %"compiler/source:Span", ptr %l74
  %t74 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t71, ptr %t72, %"compiler/source:Span" %t73)
  store ptr %t74, ptr %l75
  br label %bb22
bb22:
  %t75 = load ptr, ptr %l75, !tbaa !29
  store ptr %t75, ptr %l13, !tbaa !29
  %t76 = load ptr, ptr %l13, !tbaa !29
  %t79 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t76)
  store i32 %t79, ptr %l78
  br label %bb23
bb23:
  %t80 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t81 = load i32, ptr %l78, !tbaa !23
  %t83 = icmp ne i32 %t81, %t80
  br i1 %t83, label %bb24, label %bb25
bb24:
  %t85 = load ptr, ptr %l0, !tbaa !29
  store ptr %t85, ptr %l82, !tbaa !29
  %t86 = load ptr, ptr %l13, !tbaa !29
  %t89 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t86)
  store i32 %t89, ptr %l85
  br label %bb26
bb25:
  store i1 false, ptr %l81, !tbaa !21
  br label %bb28
bb26:
  %t90 = load ptr, ptr %l82, !tbaa !29
  %t91 = load i32, ptr %l85, !tbaa !23
  %t92 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %t90, i32 %t91)
  store i1 %t92, ptr %l86
  br label %bb27
bb27:
  %t93 = load i1, ptr %l86, !tbaa !21
  %t94 = xor i1 %t93, true
  store i1 %t94, ptr %l81, !tbaa !21
  br label %bb28
bb28:
  %t96 = load i1, ptr %l81, !tbaa !21
  br i1 %t96, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s5
  %t97 = load ptr, ptr %l0, !tbaa !29
  store ptr %t97, ptr %l88, !tbaa !29
  %t98 = load ptr, ptr %l11, !tbaa !29
  %t100 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t98)
  store %"compiler/source:Span" %t100, ptr %l90
  br label %bb31
bb30:
  br label %bb36
bb31:
  %t101 = load ptr, ptr %l0, !tbaa !29
  store ptr %t101, ptr %l91, !tbaa !29
  %t102 = load ptr, ptr %l13, !tbaa !29
  %t105 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t102)
  store i32 %t105, ptr %l94
  br label %bb32
bb32:
  %t106 = load ptr, ptr %l91, !tbaa !29
  %t107 = load i32, ptr %l94, !tbaa !23
  %t108 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s5, ptr %t106, i32 %t107)
  store { i64, ptr } %t108, ptr %l95
  br label %bb33
bb33:
  %t109 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 0
  %t111 = extractvalue { i64, ptr } %t109, 1
  %t112 = mul i64 %t110, 1
  %t113 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t112)
  call void @llvm.memcpy.p0.p0.i64(ptr %t113, ptr %t111, i64 %t112, i1 false)
  %t114 = insertvalue { i64, ptr } undef, i64 %t110, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t113, 1
  %t117 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eRangeNotInt(ptr %s5, ptr %s5, { i64, ptr } %t115)
  store %"compiler/msgs:Msg" %t117, ptr %l97
  br label %bb34
bb34:
  %t118 = load ptr, ptr %l88, !tbaa !29
  %t119 = load %"compiler/source:Span", ptr %l90
  %t120 = load %"compiler/msgs:Msg", ptr %l97
  %t121 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t118, %"compiler/source:Span" %t119, %"compiler/msgs:Msg" %t120)
  store i64 %t121, ptr %l98
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s2)
  store ptr null, ptr %rv
  br label %ret
bb36:
  %t123 = load i32, ptr %l6, !tbaa !23
  %t124 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t127 = icmp eq i32 %t123, %t124
  br i1 %t127, label %bb37, label %bb38
bb37:
  %t129 = load ptr, ptr %l0, !tbaa !29
  store ptr %t129, ptr %l104, !tbaa !29
  %t130 = load ptr, ptr %l13, !tbaa !29
  %t133 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t130)
  store i32 %t133, ptr %l107
  br label %bb39
bb38:
  store i1 false, ptr %l103, !tbaa !21
  br label %bb41
bb39:
  %t134 = load ptr, ptr %l104, !tbaa !29
  %t135 = load i32, ptr %l107, !tbaa !23
  %t136 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %t134, i32 %t135)
  store i1 %t136, ptr %l108
  br label %bb40
bb40:
  %t137 = load i1, ptr %l108, !tbaa !21
  store i1 %t137, ptr %l103, !tbaa !21
  br label %bb41
bb41:
  %t138 = load i1, ptr %l103, !tbaa !21
  br i1 %t138, label %bb42, label %bb43
bb42:
  %t139 = load ptr, ptr %l13, !tbaa !29
  %t142 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t139)
  store i32 %t142, ptr %l111
  br label %bb44
bb43:
  br label %bb45
bb44:
  %t143 = load i32, ptr %l111, !tbaa !23
  store i32 %t143, ptr %l6, !tbaa !23
  br label %bb45
bb45:
  %t144 = load ptr, ptr %lp7
  %t145 = load ptr, ptr %l13, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_3f_26_3e_2e_H4d3879e0682f4949b04a377fac27da65(ptr %v0, ptr %v0, ptr %t144, ptr %t145)
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s2)
  br label %bb47
bb47:
  %t149 = load i64, ptr %l9, !tbaa !24
  %t151 = add i64 %t149, 1
  store i64 %t151, ptr %l9, !tbaa !24
  br label %bb2
bb48:
  %t153 = load ptr, ptr %lp7
  %t155 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_3f_26_3e_2e_H8799d60eecda5ec9994329473f90a64e(ptr %v0, ptr %v0, ptr %t153)
  store { i64, ptr } %t155, ptr %l118
  br label %bb49
bb49:
  %t156 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t156, ptr %lp14
  %t157 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t158 = load ptr, ptr %lp14
  store { i64, ptr } %t157, ptr %t158, !tbaa !27
  %t159 = load i32, ptr %l6, !tbaa !23
  %t160 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t163 = icmp eq i32 %t159, %t160
  br i1 %t163, label %bb50, label %bb51
bb50:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t165)
  store i32 %t167, ptr %l123
  br label %bb52
bb51:
  br label %bb68
bb52:
  %t168 = load i32, ptr %l123, !tbaa !23
  store i32 %t168, ptr %l6, !tbaa !23
  %t169 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t169, 0
  %t173 = icmp eq i64 %t171, 1
  br i1 %t173, label %bb53, label %bb54
bb53:
  %t175 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t175, ptr %l128, !tbaa !27
  %t176 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr ptr, ptr %t177, i64 0
  %t179 = load ptr, ptr %t178, !tbaa !39
  store ptr %t179, ptr %l127, !tbaa !29
  br label %bb55
bb54:
  %t181 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t181, ptr %l130, !tbaa !27
  %t182 = getelementptr { i64, ptr }, ptr %l130, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !27
  %t184 = getelementptr ptr, ptr %t183, i64 1
  %t185 = load ptr, ptr %t184, !tbaa !39
  store ptr %t185, ptr %l127, !tbaa !29
  br label %bb55
bb55:
  %t187 = load ptr, ptr %l127, !tbaa !29
  store ptr %t187, ptr %l15, !tbaa !29
  %t188 = load ptr, ptr %l0, !tbaa !29
  store ptr %t188, ptr %l132, !tbaa !29
  %t189 = load ptr, ptr %l15, !tbaa !29
  %t191 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t189)
  store %"compiler/source:Span" %t191, ptr %l134
  br label %bb56
bb56:
  %t192 = load %"compiler/source:Span", ptr %l134
  %t193 = load ptr, ptr %l132, !tbaa !29
  %t194 = getelementptr %"compiler/check:Checker", ptr %t193, i32 0, i32 29
  store %"compiler/source:Span" %t192, ptr %t194
  %t195 = load ptr, ptr %l0, !tbaa !29
  store ptr %t195, ptr %l135, !tbaa !29
  %t196 = load ptr, ptr %l15, !tbaa !29
  store ptr %t196, ptr %l137, !tbaa !29
  store i1 false, ptr %l138, !tbaa !21
  %t197 = load ptr, ptr %l137, !tbaa !29
  %t198 = icmp ne ptr %t197, null
  br i1 %t198, label %bb57, label %bb58
bb57:
  %t200 = load ptr, ptr %l137, !tbaa !29
  %t201 = load i64, ptr %t200
  %t203 = icmp eq i64 %t201, 1
  store i1 %t203, ptr %l138, !tbaa !21
  br label %bb58
bb58:
  %t204 = load i1, ptr %l138, !tbaa !21
  br i1 %t204, label %bb59, label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb62
bb61:
  store i1 true, ptr %l136, !tbaa !21
  br label %bb67
bb62:
  br i1 true, label %bb63, label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb66
bb65:
  store i1 false, ptr %l136, !tbaa !21
  br label %bb67
bb66:
  call void @__olang_check_failed(ptr @olang_loc_b274f9b5a1d6f283_4bd77c9dbb9826e7)
  unreachable
bb67:
  %t205 = load i1, ptr %l136, !tbaa !21
  %t206 = load ptr, ptr %l135, !tbaa !29
  %t207 = getelementptr %"compiler/check:Checker", ptr %t206, i32 0, i32 30
  store i1 %t205, ptr %t207, !tbaa !21
  br label %bb68
bb68:
  %t208 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t210 = extractvalue { i64, ptr } %t208, 0
  %t212 = icmp sgt i64 %t210, 2
  br i1 %t212, label %bb69, label %bb70
bb69:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t215 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t215, ptr %l145, !tbaa !27
  %t216 = getelementptr { i64, ptr }, ptr %l145, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !27
  %t218 = getelementptr ptr, ptr %t217, i64 2
  %t219 = load ptr, ptr %t218, !tbaa !39
  %t223 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v2, ptr %t214, ptr %t219)
  store %"compiler/check:litv" %t223, ptr %l148
  br label %bb71
bb70:
  br label %bb87
bb71:
  %t224 = load %"compiler/check:litv", ptr %l148
  store %"compiler/check:litv" %t224, ptr %l16
  %t225 = getelementptr %"compiler/check:litv", ptr %l16, i32 0, i32 0
  %t226 = load i1, ptr %t225, !tbaa !21
  br i1 %t226, label %bb72, label %bb73
bb72:
  %t228 = getelementptr %"compiler/check:litv", ptr %l16, i32 0, i32 1
  %t229 = load i1, ptr %t228, !tbaa !21
  %t231 = xor i1 %t229, true
  store i1 %t231, ptr %l150, !tbaa !21
  br label %bb74
bb73:
  store i1 false, ptr %l150, !tbaa !21
  br label %bb74
bb74:
  %t233 = load i1, ptr %l150, !tbaa !21
  br i1 %t233, label %bb75, label %bb76
bb75:
  %t234 = getelementptr %"compiler/check:litv", ptr %l16, i32 0, i32 2
  %t235 = load i1, ptr %t234, !tbaa !21
  %t237 = xor i1 %t235, true
  store i1 %t237, ptr %l153, !tbaa !21
  br label %bb77
bb76:
  store i1 false, ptr %l153, !tbaa !21
  br label %bb77
bb77:
  %t239 = load i1, ptr %l153, !tbaa !21
  br i1 %t239, label %bb78, label %bb79
bb78:
  %t240 = getelementptr %"compiler/check:litv", ptr %l16, i32 0, i32 3
  %t241 = load i64, ptr %t240, !tbaa !24
  %t243 = icmp sle i64 %t241, 0
  store i1 %t243, ptr %l156, !tbaa !21
  br label %bb80
bb79:
  store i1 false, ptr %l156, !tbaa !21
  br label %bb80
bb80:
  %t245 = load i1, ptr %l156, !tbaa !21
  br i1 %t245, label %bb81, label %bb82
bb81:
  store %olang.scope zeroinitializer, ptr %s12
  %t246 = load ptr, ptr %l0, !tbaa !29
  store ptr %t246, ptr %l159, !tbaa !29
  %t247 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t247, ptr %l160, !tbaa !27
  %t248 = getelementptr { i64, ptr }, ptr %l160, i32 0, i32 1
  %t249 = load ptr, ptr %t248, !tbaa !27
  %t250 = getelementptr ptr, ptr %t249, i64 2
  %t251 = load ptr, ptr %t250, !tbaa !39
  %t253 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t251)
  store %"compiler/source:Span" %t253, ptr %l162
  br label %bb83
bb82:
  br label %bb86
bb83:
  %t254 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eRangeStep(ptr %s12)
  store %"compiler/msgs:Msg" %t254, ptr %l163
  br label %bb84
bb84:
  %t255 = load ptr, ptr %l159, !tbaa !29
  %t256 = load %"compiler/source:Span", ptr %l162
  %t257 = load %"compiler/msgs:Msg", ptr %l163
  %t258 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s12, ptr %t255, %"compiler/source:Span" %t256, %"compiler/msgs:Msg" %t257)
  store i64 %t258, ptr %l164
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s12)
  store ptr null, ptr %rv
  br label %ret
bb86:
  br label %bb87
bb87:
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t262 = getelementptr %"compiler/check:Checker", ptr %t260, i32 0, i32 31
  %t264 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t262)
  store i64 %t264, ptr %l168
  br label %bb88
bb88:
  %t265 = load i64, ptr %l168, !tbaa !24
  store i64 %t265, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  %t266 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t268 = extractvalue { i64, ptr } %t266, 0
  store i64 %t268, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t270 = load i64, ptr %l19, !tbaa !24
  %t271 = load i64, ptr %l18, !tbaa !24
  %t274 = icmp sgt i64 %t270, %t271
  br i1 %t274, label %bb89, label %bb90
bb89:
  %t276 = load i64, ptr %l20, !tbaa !24
  %t278 = icmp sgt i64 %t276, 0
  br i1 %t278, label %bb91, label %bb92
bb90:
  store i64 0, ptr %l174, !tbaa !24
  br label %bb94
bb91:
  %t280 = load i64, ptr %l19, !tbaa !24
  %t281 = load i64, ptr %l18, !tbaa !24
  %t284 = sub i64 %t280, %t281
  %t285 = load i64, ptr %l20, !tbaa !24
  %t288 = add i64 %t284, %t285
  %t290 = sub i64 %t288, 1
  %t291 = load i64, ptr %l20, !tbaa !24
  %t294 = sdiv i64 %t290, %t291
  store i64 %t294, ptr %l177, !tbaa !24
  br label %bb93
bb92:
  store i64 0, ptr %l177, !tbaa !24
  br label %bb93
bb93:
  %t296 = load i64, ptr %l177, !tbaa !24
  store i64 %t296, ptr %l174, !tbaa !24
  br label %bb94
bb94:
  %t297 = load i64, ptr %l174, !tbaa !24
  store i64 %t297, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb95
bb95:
  store %olang.scope zeroinitializer, ptr %s14
  %t298 = load i64, ptr %l22, !tbaa !24
  %t299 = load i64, ptr %l21, !tbaa !24
  %t302 = icmp slt i64 %t298, %t299
  %t304 = xor i1 %t302, true
  br i1 %t304, label %bb96, label %bb97
bb96:
  call void @__olang_scope_close(ptr %s14)
  br label %bb112
bb97:
  br label %bb98
bb98:
  %t306 = load i64, ptr %l18, !tbaa !24
  %t307 = load i64, ptr %l22, !tbaa !24
  %t308 = load i64, ptr %l20, !tbaa !24
  %t311 = mul i64 %t307, %t308
  %t314 = add i64 %t306, %t311
  store i64 %t314, ptr %l23, !tbaa !24
  %t316 = load ptr, ptr %lp14
  %t317 = load { i64, ptr }, ptr %t316, !tbaa !27
  store { i64, ptr } %t317, ptr %l195, !tbaa !27
  %t318 = load i64, ptr %l23, !tbaa !24
  %t320 = getelementptr { i64, ptr }, ptr %l195, i32 0, i32 1
  %t321 = load ptr, ptr %t320, !tbaa !27
  %t322 = getelementptr ptr, ptr %t321, i64 %t318
  %t323 = load ptr, ptr %t322, !tbaa !39
  %t325 = icmp eq ptr %t323, null
  br i1 %t325, label %bb99, label %bb100
bb99:
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t329 = getelementptr %"compiler/check:Checker", ptr %t327, i32 0, i32 31
  store ptr %t329, ptr %l200, !tbaa !29
  %t330 = load ptr, ptr %l0, !tbaa !29
  store ptr %t330, ptr %l201, !tbaa !29
  %t331 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t331, ptr %l202, !tbaa !27
  %t332 = load i64, ptr %l23, !tbaa !24
  %t334 = getelementptr { i64, ptr }, ptr %l202, i32 0, i32 1
  %t335 = load ptr, ptr %t334, !tbaa !27
  %t336 = getelementptr ptr, ptr %t335, i64 %t332
  %t337 = load ptr, ptr %t336, !tbaa !39
  store ptr %t337, ptr %l204, !tbaa !29
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t339 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t339, ptr %l206, !tbaa !27
  %t340 = load i64, ptr %l23, !tbaa !24
  %t342 = getelementptr { i64, ptr }, ptr %l206, i32 0, i32 1
  %t343 = load ptr, ptr %t342, !tbaa !27
  %t344 = getelementptr ptr, ptr %t343, i64 %t340
  %t345 = load ptr, ptr %t344, !tbaa !39
  %t349 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v2, ptr %t338, ptr %t345)
  store %"compiler/check:litv" %t349, ptr %l210
  br label %bb101
bb100:
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t352 = getelementptr %"compiler/check:Checker", ptr %t350, i32 0, i32 31
  store ptr %t352, ptr %l214, !tbaa !29
  %t353 = load ptr, ptr %l0, !tbaa !29
  store ptr %t353, ptr %l215, !tbaa !29
  %t354 = load ptr, ptr %lp14
  %t355 = load { i64, ptr }, ptr %t354, !tbaa !27
  store { i64, ptr } %t355, ptr %l216, !tbaa !27
  %t356 = load i64, ptr %l23, !tbaa !24
  %t358 = getelementptr { i64, ptr }, ptr %l216, i32 0, i32 1
  %t359 = load ptr, ptr %t358, !tbaa !27
  %t360 = getelementptr ptr, ptr %t359, i64 %t356
  %t361 = load ptr, ptr %t360, !tbaa !39
  store ptr %t361, ptr %l24, !tbaa !29
  %t363 = load ptr, ptr %l24, !tbaa !29
  %t365 = icmp eq ptr %t363, null
  br i1 %t365, label %bb104, label %bb105
bb101:
  %t367 = load i32, ptr %l6, !tbaa !23
  %t368 = load ptr, ptr %l201, !tbaa !29
  %t369 = load ptr, ptr %l204, !tbaa !29
  %t370 = load %"compiler/check:litv", ptr %l210
  %t372 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitOf(ptr %v0, ptr %v2, ptr %t368, ptr %t369, %"compiler/check:litv" %t370, i32 %t367)
  store ptr %t372, ptr %l212
  br label %bb102
bb102:
  %t373 = load ptr, ptr %l200, !tbaa !29
  %t374 = load ptr, ptr %l212, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t373, ptr %t374)
  br label %bb103
bb103:
  br label %bb110
bb104:
  call void @__olang_check_failed(ptr @olang_loc_81853a8b5abe7edb_5bbff5245f4bcfbf)
  unreachable
bb105:
  br label %bb106
bb106:
  %t375 = load ptr, ptr %l24, !tbaa !29
  store ptr %t375, ptr %l221, !tbaa !29
  %t376 = load i32, ptr %l6, !tbaa !23
  store i32 %t376, ptr %l222, !tbaa !23
  %t377 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t377, ptr %l223, !tbaa !27
  %t378 = load i64, ptr %l23, !tbaa !24
  %t380 = getelementptr { i64, ptr }, ptr %l223, i32 0, i32 1
  %t381 = load ptr, ptr %t380, !tbaa !27
  %t382 = getelementptr ptr, ptr %t381, i64 %t378
  %t383 = load ptr, ptr %t382, !tbaa !39
  %t385 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t383)
  store %"compiler/source:Span" %t385, ptr %l226
  br label %bb107
bb107:
  %t386 = load ptr, ptr %l215, !tbaa !29
  %t387 = load ptr, ptr %l221, !tbaa !29
  %t388 = load i32, ptr %l222, !tbaa !23
  %t389 = load %"compiler/source:Span", ptr %l226
  %t390 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t386, ptr %t387, i32 %t388, %"compiler/source:Span" %t389)
  store ptr %t390, ptr %l227
  br label %bb108
bb108:
  %t391 = load ptr, ptr %l214, !tbaa !29
  %t392 = load ptr, ptr %l227, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t391, ptr %t392)
  br label %bb109
bb109:
  br label %bb110
bb110:
  call void @__olang_scope_close(ptr %s14)
  br label %bb111
bb111:
  %t393 = load i64, ptr %l22, !tbaa !24
  %t395 = add i64 %t393, 1
  store i64 %t395, ptr %l22, !tbaa !24
  br label %bb95
bb112:
  %t397 = load ptr, ptr %l0, !tbaa !29
  %t399 = getelementptr %"compiler/check:Checker", ptr %t397, i32 0, i32 31
  %t400 = load i64, ptr %l17, !tbaa !24
  %t403 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t399, i64 %t400)
  store { i64, ptr } %t403, ptr %l233
  br label %bb113
bb113:
  %t404 = load { i64, ptr }, ptr %l233, !tbaa !27
  store { i64, ptr } %t404, ptr %l25, !tbaa !27
  %t405 = load ptr, ptr %l0, !tbaa !29
  %t406 = load %"compiler/source:Span", ptr %l1
  %t407 = load i32, ptr %l6, !tbaa !23
  %t411 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t405, %"compiler/source:Span" %t406, i32 %t407, i64 0)
  store ptr %t411, ptr %l237
  br label %bb114
bb114:
  %t412 = load ptr, ptr %l237, !tbaa !29
  store ptr %t412, ptr %l26, !tbaa !29
  store ptr null, ptr %l27, !tbaa !29
  %t413 = load ptr, ptr %l0, !tbaa !29
  %t414 = load %"compiler/source:Span", ptr %l1
  %t415 = load i32, ptr %l6, !tbaa !23
  %t419 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t413, %"compiler/source:Span" %t414, i32 %t415, i64 1)
  store ptr %t419, ptr %l241
  br label %bb115
bb115:
  %t420 = load ptr, ptr %l241, !tbaa !29
  store ptr %t420, ptr %l28, !tbaa !29
  %t421 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t423 = extractvalue { i64, ptr } %t421, 0
  %t425 = icmp eq i64 %t423, 1
  br i1 %t425, label %bb116, label %bb117
bb116:
  %t427 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t427, ptr %l245, !tbaa !27
  %t428 = getelementptr { i64, ptr }, ptr %l245, i32 0, i32 1
  %t429 = load ptr, ptr %t428, !tbaa !27
  %t430 = getelementptr ptr, ptr %t429, i64 0
  %t431 = load ptr, ptr %t430, !tbaa !39
  store ptr %t431, ptr %l27, !tbaa !29
  br label %bb121
bb117:
  %t434 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t434, ptr %l248, !tbaa !27
  %t435 = getelementptr { i64, ptr }, ptr %l248, i32 0, i32 1
  %t436 = load ptr, ptr %t435, !tbaa !27
  %t437 = getelementptr ptr, ptr %t436, i64 0
  %t438 = load ptr, ptr %t437, !tbaa !39
  store ptr %t438, ptr %l26, !tbaa !29
  %t440 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t440, ptr %l250, !tbaa !27
  %t441 = getelementptr { i64, ptr }, ptr %l250, i32 0, i32 1
  %t442 = load ptr, ptr %t441, !tbaa !27
  %t443 = getelementptr ptr, ptr %t442, i64 1
  %t444 = load ptr, ptr %t443, !tbaa !39
  store ptr %t444, ptr %l27, !tbaa !29
  %t447 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t449 = extractvalue { i64, ptr } %t447, 0
  %t451 = icmp sgt i64 %t449, 2
  br i1 %t451, label %bb118, label %bb119
bb118:
  %t453 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t453, ptr %l256, !tbaa !27
  %t454 = getelementptr { i64, ptr }, ptr %l256, i32 0, i32 1
  %t455 = load ptr, ptr %t454, !tbaa !27
  %t456 = getelementptr ptr, ptr %t455, i64 2
  %t457 = load ptr, ptr %t456, !tbaa !39
  store ptr %t457, ptr %l28, !tbaa !29
  br label %bb120
bb119:
  br label %bb120
bb120:
  br label %bb121
bb121:
  %t459 = load ptr, ptr %l0, !tbaa !29
  %t460 = load %"compiler/source:Span", ptr %l1
  %t461 = load i32, ptr %l6, !tbaa !23
  %t465 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t459, %"compiler/source:Span" %t460, i32 %t461)
  store i64 %t465, ptr %l261
  br label %bb122
bb122:
  %t466 = load i64, ptr %l261, !tbaa !24
  store i64 %t466, ptr %l29, !tbaa !24
  %t467 = load ptr, ptr %l0, !tbaa !29
  %t468 = load %"compiler/source:Span", ptr %l1
  %t469 = load i64, ptr %l29, !tbaa !24
  %t471 = trunc i64 %t469 to i32
  %t473 = load ptr, ptr %l26, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t474
  %t475 = getelementptr { i64, [3 x i64] }, ptr %t474, i32 0, i32 0
  store i64 0, ptr %t475
  %t477 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t468, 0
  %t479 = insertvalue { %"compiler/source:Span", i32, ptr } %t477, i32 %t471, 1
  %t481 = insertvalue { %"compiler/source:Span", i32, ptr } %t479, ptr %t473, 2
  %t482 = getelementptr { i64, [3 x i64] }, ptr %t474, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t481, ptr %t482
  %t483 = load { i64, [3 x i64] }, ptr %t474
  %t485 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t483, ptr %t485
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t467, ptr %t485)
  br label %bb123
bb123:
  %t488 = load ptr, ptr %l0, !tbaa !29
  %t489 = load %"compiler/source:Span", ptr %l1
  %t490 = load i32, ptr %l6, !tbaa !23
  %t494 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t488, %"compiler/source:Span" %t489, i32 %t490)
  store i64 %t494, ptr %l273
  br label %bb124
bb124:
  %t495 = load i64, ptr %l273, !tbaa !24
  store i64 %t495, ptr %l30, !tbaa !24
  %t496 = load ptr, ptr %l0, !tbaa !29
  store ptr %t496, ptr %l274, !tbaa !29
  %t497 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t497, ptr %l275
  %t498 = load i64, ptr %l30, !tbaa !24
  %t500 = trunc i64 %t498 to i32
  store i32 %t500, ptr %l278, !tbaa !23
  %t502 = load ptr, ptr %l27, !tbaa !29
  %t504 = icmp eq ptr %t502, null
  br i1 %t504, label %bb125, label %bb126
bb125:
  call void @__olang_check_failed(ptr @olang_loc_e4731602e9e5e1a_1dd19577095c0d0e)
  unreachable
bb126:
  br label %bb127
bb127:
  %t506 = load ptr, ptr %l27, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t507
  %t508 = getelementptr { i64, [3 x i64] }, ptr %t507, i32 0, i32 0
  store i64 0, ptr %t508
  %t509 = load %"compiler/source:Span", ptr %l275
  %t510 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t509, 0
  %t511 = load i32, ptr %l278, !tbaa !23
  %t512 = insertvalue { %"compiler/source:Span", i32, ptr } %t510, i32 %t511, 1
  %t514 = insertvalue { %"compiler/source:Span", i32, ptr } %t512, ptr %t506, 2
  %t515 = getelementptr { i64, [3 x i64] }, ptr %t507, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t514, ptr %t515
  %t516 = load { i64, [3 x i64] }, ptr %t507
  %t518 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t516, ptr %t518
  %t519 = load ptr, ptr %l274, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t519, ptr %t518)
  br label %bb128
bb128:
  %t521 = load ptr, ptr %l0, !tbaa !29
  %t522 = load %"compiler/source:Span", ptr %l1
  %t523 = load i32, ptr %l6, !tbaa !23
  %t527 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t521, %"compiler/source:Span" %t522, i32 %t523)
  store i64 %t527, ptr %l287
  br label %bb129
bb129:
  %t528 = load i64, ptr %l287, !tbaa !24
  store i64 %t528, ptr %l31, !tbaa !24
  %t529 = load ptr, ptr %l0, !tbaa !29
  %t530 = load %"compiler/source:Span", ptr %l1
  %t531 = load i64, ptr %l31, !tbaa !24
  %t533 = trunc i64 %t531 to i32
  %t535 = load ptr, ptr %l28, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t536
  %t537 = getelementptr { i64, [3 x i64] }, ptr %t536, i32 0, i32 0
  store i64 0, ptr %t537
  %t539 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t530, 0
  %t541 = insertvalue { %"compiler/source:Span", i32, ptr } %t539, i32 %t533, 1
  %t543 = insertvalue { %"compiler/source:Span", i32, ptr } %t541, ptr %t535, 2
  %t544 = getelementptr { i64, [3 x i64] }, ptr %t536, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t543, ptr %t544
  %t545 = load { i64, [3 x i64] }, ptr %t536
  %t547 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t545, ptr %t547
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t529, ptr %t547)
  br label %bb130
bb130:
  %t550 = load ptr, ptr %l0, !tbaa !29
  store ptr %t550, ptr %l296, !tbaa !29
  %t551 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t551, ptr %l297
  %t552 = load i32, ptr %l6, !tbaa !23
  store i32 %t552, ptr %l298, !tbaa !23
  store i32 4, ptr %l299
  %t553 = load ptr, ptr %l0, !tbaa !29
  %t554 = load %"compiler/source:Span", ptr %l1
  %t555 = load i64, ptr %l30, !tbaa !24
  %t559 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t553, %"compiler/source:Span" %t554, i64 %t555)
  store ptr %t559, ptr %l303
  br label %bb131
bb131:
  %t560 = load ptr, ptr %l0, !tbaa !29
  %t561 = load %"compiler/source:Span", ptr %l1
  %t562 = load i64, ptr %l29, !tbaa !24
  %t566 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t560, %"compiler/source:Span" %t561, i64 %t562)
  store ptr %t566, ptr %l307
  br label %bb132
bb132:
  %t567 = load ptr, ptr %l307, !tbaa !29
  %t568 = load ptr, ptr %l296, !tbaa !29
  %t569 = load %"compiler/source:Span", ptr %l297
  %t570 = load i32, ptr %l298, !tbaa !23
  %t571 = load i32, ptr %l299
  %t572 = load ptr, ptr %l303, !tbaa !29
  %t574 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t568, %"compiler/source:Span" %t569, i32 %t570, i32 %t571, ptr %t572, ptr %t567)
  store ptr %t574, ptr %l309
  br label %bb133
bb133:
  %t575 = load ptr, ptr %l309, !tbaa !29
  %t576 = load ptr, ptr %l0, !tbaa !29
  store ptr %t576, ptr %l310, !tbaa !29
  %t577 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t577, ptr %l311
  %t578 = load i32, ptr %l6, !tbaa !23
  store i32 %t578, ptr %l312, !tbaa !23
  store i32 4, ptr %l313
  %t579 = load ptr, ptr %l0, !tbaa !29
  store ptr %t579, ptr %l314, !tbaa !29
  %t580 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t580, ptr %l315
  %t581 = load i32, ptr %l6, !tbaa !23
  store i32 %t581, ptr %l316, !tbaa !23
  store i32 3, ptr %l317
  store ptr %t575, ptr %l318, !tbaa !29
  %t583 = load ptr, ptr %l0, !tbaa !29
  %t584 = load %"compiler/source:Span", ptr %l1
  %t585 = load i64, ptr %l31, !tbaa !24
  %t589 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t583, %"compiler/source:Span" %t584, i64 %t585)
  store ptr %t589, ptr %l322
  br label %bb134
bb134:
  %t590 = load ptr, ptr %l322, !tbaa !29
  %t591 = load ptr, ptr %l314, !tbaa !29
  %t592 = load %"compiler/source:Span", ptr %l315
  %t593 = load i32, ptr %l316, !tbaa !23
  %t594 = load i32, ptr %l317
  %t595 = load ptr, ptr %l318, !tbaa !29
  %t597 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t591, %"compiler/source:Span" %t592, i32 %t593, i32 %t594, ptr %t595, ptr %t590)
  store ptr %t597, ptr %l324
  br label %bb135
bb135:
  %t598 = load ptr, ptr %l0, !tbaa !29
  %t599 = load %"compiler/source:Span", ptr %l1
  %t600 = load i32, ptr %l6, !tbaa !23
  %t604 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t598, %"compiler/source:Span" %t599, i32 %t600, i64 1)
  store ptr %t604, ptr %l328
  br label %bb136
bb136:
  %t605 = load ptr, ptr %l328, !tbaa !29
  %t606 = load ptr, ptr %l310, !tbaa !29
  %t607 = load %"compiler/source:Span", ptr %l311
  %t608 = load i32, ptr %l312, !tbaa !23
  %t609 = load i32, ptr %l313
  %t610 = load ptr, ptr %l324, !tbaa !29
  %t612 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t606, %"compiler/source:Span" %t607, i32 %t608, i32 %t609, ptr %t610, ptr %t605)
  store ptr %t612, ptr %l330
  br label %bb137
bb137:
  %t613 = load ptr, ptr %l330, !tbaa !29
  store ptr %t613, ptr %l33, !tbaa !29
  %t614 = load ptr, ptr %l0, !tbaa !29
  store ptr %t614, ptr %l331, !tbaa !29
  %t615 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t615, ptr %l332
  %t616 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t616, ptr %l333, !tbaa !23
  store i32 17, ptr %l334
  %t617 = load ptr, ptr %l0, !tbaa !29
  %t618 = load %"compiler/source:Span", ptr %l1
  %t619 = load i64, ptr %l30, !tbaa !24
  %t623 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t617, %"compiler/source:Span" %t618, i64 %t619)
  store ptr %t623, ptr %l338
  br label %bb138
bb138:
  %t624 = load ptr, ptr %l0, !tbaa !29
  %t625 = load %"compiler/source:Span", ptr %l1
  %t626 = load i64, ptr %l29, !tbaa !24
  %t630 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t624, %"compiler/source:Span" %t625, i64 %t626)
  store ptr %t630, ptr %l342
  br label %bb139
bb139:
  %t631 = load ptr, ptr %l342, !tbaa !29
  %t632 = load ptr, ptr %l331, !tbaa !29
  %t633 = load %"compiler/source:Span", ptr %l332
  %t634 = load i32, ptr %l333, !tbaa !23
  %t635 = load i32, ptr %l334
  %t636 = load ptr, ptr %l338, !tbaa !29
  %t638 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t632, %"compiler/source:Span" %t633, i32 %t634, i32 %t635, ptr %t636, ptr %t631)
  store ptr %t638, ptr %l344
  br label %bb140
bb140:
  %t639 = load ptr, ptr %l344, !tbaa !29
  store ptr %t639, ptr %l34, !tbaa !29
  %t640 = load ptr, ptr %l0, !tbaa !29
  store ptr %t640, ptr %l345, !tbaa !29
  %t641 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t641, ptr %l346
  %t642 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t642, ptr %l347, !tbaa !23
  store i32 17, ptr %l348
  %t643 = load ptr, ptr %l0, !tbaa !29
  %t644 = load %"compiler/source:Span", ptr %l1
  %t645 = load i64, ptr %l31, !tbaa !24
  %t649 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t643, %"compiler/source:Span" %t644, i64 %t645)
  store ptr %t649, ptr %l352
  br label %bb141
bb141:
  %t650 = load ptr, ptr %l0, !tbaa !29
  %t651 = load %"compiler/source:Span", ptr %l1
  %t652 = load i32, ptr %l6, !tbaa !23
  %t656 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t650, %"compiler/source:Span" %t651, i32 %t652, i64 0)
  store ptr %t656, ptr %l356
  br label %bb142
bb142:
  %t657 = load ptr, ptr %l356, !tbaa !29
  %t658 = load ptr, ptr %l345, !tbaa !29
  %t659 = load %"compiler/source:Span", ptr %l346
  %t660 = load i32, ptr %l347, !tbaa !23
  %t661 = load i32, ptr %l348
  %t662 = load ptr, ptr %l352, !tbaa !29
  %t664 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t658, %"compiler/source:Span" %t659, i32 %t660, i32 %t661, ptr %t662, ptr %t657)
  store ptr %t664, ptr %l358
  br label %bb143
bb143:
  %t665 = load ptr, ptr %l358, !tbaa !29
  %t666 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t666, ptr %l359
  %t667 = load i32, ptr %l6, !tbaa !23
  store i32 %t667, ptr %l360, !tbaa !23
  store ptr %t665, ptr %l361, !tbaa !29
  %t669 = load ptr, ptr %l0, !tbaa !29
  store ptr %t669, ptr %l362, !tbaa !29
  %t670 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t670, ptr %l363
  %t671 = load i32, ptr %l6, !tbaa !23
  store i32 %t671, ptr %l364, !tbaa !23
  store i32 6, ptr %l365
  %t672 = load ptr, ptr %l33, !tbaa !29
  store ptr %t672, ptr %l366, !tbaa !29
  %t673 = load ptr, ptr %l0, !tbaa !29
  %t674 = load %"compiler/source:Span", ptr %l1
  %t675 = load i64, ptr %l31, !tbaa !24
  %t679 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t673, %"compiler/source:Span" %t674, i64 %t675)
  store ptr %t679, ptr %l370
  br label %bb144
bb144:
  %t680 = load ptr, ptr %l370, !tbaa !29
  %t681 = load ptr, ptr %l362, !tbaa !29
  %t682 = load %"compiler/source:Span", ptr %l363
  %t683 = load i32, ptr %l364, !tbaa !23
  %t684 = load i32, ptr %l365
  %t685 = load ptr, ptr %l366, !tbaa !29
  %t687 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t681, %"compiler/source:Span" %t682, i32 %t683, i32 %t684, ptr %t685, ptr %t680)
  store ptr %t687, ptr %l372
  br label %bb145
bb145:
  %t688 = load ptr, ptr %l372, !tbaa !29
  store ptr %t688, ptr %l373, !tbaa !29
  %t689 = load ptr, ptr %l0, !tbaa !29
  %t690 = load %"compiler/source:Span", ptr %l1
  %t691 = load i32, ptr %l6, !tbaa !23
  %t695 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t689, %"compiler/source:Span" %t690, i32 %t691, i64 0)
  store ptr %t695, ptr %l377
  br label %bb146
bb146:
  %t696 = load ptr, ptr %l361, !tbaa !29
  %t697 = load ptr, ptr %l373, !tbaa !29
  %t698 = load ptr, ptr %l377, !tbaa !29
  %t699 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t696, ptr %t697, ptr %t698)
  store %"compiler/typed:Cond" %t699, ptr %l378
  br label %bb147
bb147:
  %t700 = load %"compiler/typed:Cond", ptr %l378
  %t701 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Cond" %t700, ptr %t701
  store { i64, [5 x i64] } zeroinitializer, ptr %t702
  %t703 = getelementptr { i64, [5 x i64] }, ptr %t702, i32 0, i32 0
  store i64 11, ptr %t703
  %t704 = load %"compiler/source:Span", ptr %l359
  %t705 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t704, 0
  %t706 = load i32, ptr %l360, !tbaa !23
  %t707 = insertvalue { %"compiler/source:Span", i32, ptr } %t705, i32 %t706, 1
  %t709 = insertvalue { %"compiler/source:Span", i32, ptr } %t707, ptr %t701, 2
  %t710 = getelementptr { i64, [5 x i64] }, ptr %t702, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t709, ptr %t710
  %t711 = load { i64, [5 x i64] }, ptr %t702
  %t713 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t711, ptr %t713
  %t715 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t715, ptr %l382
  %t716 = load i32, ptr %l6, !tbaa !23
  store i32 %t716, ptr %l383, !tbaa !23
  %t717 = load ptr, ptr %l34, !tbaa !29
  store ptr %t717, ptr %l384, !tbaa !29
  store ptr %t713, ptr %l386, !tbaa !29
  %t720 = load ptr, ptr %l0, !tbaa !29
  %t721 = load %"compiler/source:Span", ptr %l1
  %t722 = load i32, ptr %l6, !tbaa !23
  %t726 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t720, %"compiler/source:Span" %t721, i32 %t722, i64 0)
  store ptr %t726, ptr %l390
  br label %bb148
bb148:
  %t727 = load ptr, ptr %l384, !tbaa !29
  %t728 = load ptr, ptr %l386, !tbaa !29
  %t729 = load ptr, ptr %l390, !tbaa !29
  %t730 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t727, ptr %t728, ptr %t729)
  store %"compiler/typed:Cond" %t730, ptr %l391
  br label %bb149
bb149:
  %t731 = load %"compiler/typed:Cond", ptr %l391
  %t732 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Cond" %t731, ptr %t732
  store { i64, [5 x i64] } zeroinitializer, ptr %t733
  %t734 = getelementptr { i64, [5 x i64] }, ptr %t733, i32 0, i32 0
  store i64 11, ptr %t734
  %t735 = load %"compiler/source:Span", ptr %l382
  %t736 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t735, 0
  %t737 = load i32, ptr %l383, !tbaa !23
  %t738 = insertvalue { %"compiler/source:Span", i32, ptr } %t736, i32 %t737, 1
  %t740 = insertvalue { %"compiler/source:Span", i32, ptr } %t738, ptr %t732, 2
  %t741 = getelementptr { i64, [5 x i64] }, ptr %t733, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t740, ptr %t741
  %t742 = load { i64, [5 x i64] }, ptr %t733
  %t744 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t742, ptr %t744
  store ptr %t744, ptr %l37, !tbaa !29
  %t746 = load ptr, ptr %l0, !tbaa !29
  %t747 = load %"compiler/source:Span", ptr %l1
  %t748 = load i32, ptr %l6, !tbaa !23
  %t752 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t746, %"compiler/source:Span" %t747, i32 %t748)
  store i64 %t752, ptr %l398
  br label %bb150
bb150:
  %t753 = load i64, ptr %l398, !tbaa !24
  store i64 %t753, ptr %l38, !tbaa !24
  %t754 = load ptr, ptr %l0, !tbaa !29
  %t755 = load %"compiler/source:Span", ptr %l1
  %t756 = load i64, ptr %l38, !tbaa !24
  %t758 = trunc i64 %t756 to i32
  %t760 = load ptr, ptr %l37, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t761
  %t762 = getelementptr { i64, [3 x i64] }, ptr %t761, i32 0, i32 0
  store i64 0, ptr %t762
  %t764 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t755, 0
  %t766 = insertvalue { %"compiler/source:Span", i32, ptr } %t764, i32 %t758, 1
  %t768 = insertvalue { %"compiler/source:Span", i32, ptr } %t766, ptr %t760, 2
  %t769 = getelementptr { i64, [3 x i64] }, ptr %t761, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t768, ptr %t769
  %t770 = load { i64, [3 x i64] }, ptr %t761
  %t772 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t770, ptr %t772
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t754, ptr %t772)
  br label %bb151
bb151:
  %t775 = load ptr, ptr %l0, !tbaa !29
  %t776 = load %"compiler/source:Span", ptr %l1
  %t777 = load i32, ptr %l6, !tbaa !23
  %t781 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t775, %"compiler/source:Span" %t776, i32 %t777)
  store i64 %t781, ptr %l410
  br label %bb152
bb152:
  %t782 = load i64, ptr %l410, !tbaa !24
  store i64 %t782, ptr %l39, !tbaa !24
  %t783 = load ptr, ptr %l0, !tbaa !29
  store ptr %t783, ptr %l411, !tbaa !29
  %t784 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t784, ptr %l412
  %t785 = load i64, ptr %l39, !tbaa !24
  %t787 = trunc i64 %t785 to i32
  store i32 %t787, ptr %l415, !tbaa !23
  %t789 = load ptr, ptr %l0, !tbaa !29
  %t790 = load %"compiler/source:Span", ptr %l1
  %t791 = load i32, ptr %l6, !tbaa !23
  %t795 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t789, %"compiler/source:Span" %t790, i32 %t791, i64 0)
  store ptr %t795, ptr %l419
  br label %bb153
bb153:
  store { i64, [3 x i64] } zeroinitializer, ptr %t796
  %t797 = getelementptr { i64, [3 x i64] }, ptr %t796, i32 0, i32 0
  store i64 0, ptr %t797
  %t798 = load %"compiler/source:Span", ptr %l412
  %t799 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t798, 0
  %t800 = load i32, ptr %l415, !tbaa !23
  %t801 = insertvalue { %"compiler/source:Span", i32, ptr } %t799, i32 %t800, 1
  %t802 = load ptr, ptr %l419, !tbaa !29
  %t803 = insertvalue { %"compiler/source:Span", i32, ptr } %t801, ptr %t802, 2
  %t804 = getelementptr { i64, [3 x i64] }, ptr %t796, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t803, ptr %t804
  %t805 = load { i64, [3 x i64] }, ptr %t796
  %t807 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t805, ptr %t807
  %t808 = load ptr, ptr %l411, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t808, ptr %t807)
  br label %bb154
bb154:
  %t810 = load ptr, ptr %l0, !tbaa !29
  %t811 = load %"compiler/source:Span", ptr %l1
  %t813 = load i64, ptr %l39, !tbaa !24
  %t814 = load i64, ptr %l38, !tbaa !24
  %t815 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t816 = load i64, ptr %l29, !tbaa !24
  %t817 = load i64, ptr %l31, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecounted(ptr %v0, ptr %v1, ptr %v3, ptr %t810, %"compiler/source:Span" %t811, ptr %a2, i64 %t813, i64 %t814, i64 -1, i32 %t815, i64 %t816, i64 %t817, ptr %a4, i32 %a5)
  br label %bb155
bb155:
  %t830 = load ptr, ptr %l0, !tbaa !29
  %t831 = load %"compiler/source:Span", ptr %l1
  %t832 = load i64, ptr %l38, !tbaa !24
  %t836 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t830, %"compiler/source:Span" %t831, i64 %t832)
  store ptr %t836, ptr %l435
  br label %bb156
bb156:
  %t837 = load ptr, ptr %l435, !tbaa !29
  store ptr %t837, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca i64
  %l9 = alloca ptr
  %l13 = alloca ptr
  %l16 = alloca ptr
  %l22 = alloca %"compiler/check:Gap"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 -1, ptr %l3, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 12
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_H2d42092ce658fb6cce0104fa754a4e33(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6, !tbaa !24
  %t7 = icmp sgt i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t9)
  store ptr %t11, ptr %l9
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t12 = load ptr, ptr %l9, !tbaa !29
  %t14 = getelementptr %"compiler/check:frame", ptr %t12, i32 0, i32 2
  %t15 = load i64, ptr %t14, !tbaa !24
  store i64 %t15, ptr %l3, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t17)
  store ptr %t19, ptr %l13
  br label %bb5
bb5:
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t22 = getelementptr %"compiler/check:frame", ptr %t20, i32 0, i32 18
  store i1 true, ptr %t22, !tbaa !21
  br label %bb6
bb6:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 11
  store ptr %t25, ptr %l16, !tbaa !29
  %t26 = load i64, ptr %l3, !tbaa !24
  %t30 = extractvalue { i64, ptr } %a2, 1
  %t31 = extractvalue { i64, ptr } %a2, 0
  %t32 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t31)
  call void @olang_textcopy(ptr %t32, ptr %t30, i64 %t31)
  %t33 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t37 = extractvalue { i64, ptr } %t34, 1
  %t38 = mul i64 %t36, 1
  %t39 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t38)
  call void @llvm.memcpy.p0.p0.i64(ptr %t39, ptr %t37, i64 %t38, i1 false)
  %t40 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  %t45 = call %"compiler/check:Gap" @compiler_2fcheck_3aGap_2ector(ptr %v0, ptr %v0, i64 %t26, %"compiler/source:Span" %a1, { i64, ptr } %t41)
  store %"compiler/check:Gap" %t45, ptr %l22
  br label %bb7
bb7:
  %t46 = load ptr, ptr %l16, !tbaa !29
  %t47 = load %"compiler/check:Gap", ptr %l22
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aGap_3e_2ePush_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %v0, ptr %t46, %"compiler/check:Gap" %t47)
  br label %bb8
bb8:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einfersErrs(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l5, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t12, i32 %a1)
  store i32 %t16, ptr %l10
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l5, !tbaa !29
  %t18 = load i32, ptr %l10, !tbaa !23
  %t19 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t17, i32 %t18)
  store { i64, ptr } %t19, ptr %l11
  br label %bb2
bb2:
  %t20 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t20, ptr %l2, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t25 = icmp eq i64 %t23, 1
  br i1 %t25, label %bb3, label %bb4
bb3:
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t27, ptr %l16, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr i32, ptr %t29, i64 0
  %t31 = load i32, ptr %t30, !tbaa !33
  %t32 = load i32, ptr @G_2ecompiler_2ftypes_2eDefaultErrT, !tbaa !23
  %t35 = icmp eq i32 %t31, %t32
  store i1 %t35, ptr %l15, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb5
bb5:
  %t37 = load i1, ptr %l15, !tbaa !21
  store i1 %t37, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l6 = alloca i1
  %l7 = alloca i64
  %l10 = alloca i64
  %l16 = alloca ptr
  %l19 = alloca i1
  %l25 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca { i64, ptr }
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l7, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 10
  %t10 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_Ha6bcf4d517e3d7b46809e1dbf938da91(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l10
  br label %bb3
bb3:
  %t11 = load i64, ptr %l7, !tbaa !24
  %t12 = load i64, ptr %l10, !tbaa !24
  %t13 = icmp sge i64 %t11, %t12
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l6, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  store i1 false, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/check:Checker", ptr %t17, i32 0, i32 10
  %t20 = load i64, ptr %l1, !tbaa !24
  %t23 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t19, i64 %t20)
  store ptr %t23, ptr %l16
  br label %bb8
bb8:
  %t24 = load ptr, ptr %l16, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Body", ptr %t24, i32 0, i32 1
  %t27 = load { i64, [2 x i64] }, ptr %t26
  store { i64, [2 x i64] } %t27, ptr %l2
  %t29 = load { i64, [2 x i64] }, ptr %l2
  %t31 = extractvalue { i64, [2 x i64] } %t29, 0
  %t32 = icmp eq i64 %t31, 0
  br i1 %t32, label %bb9, label %bb10
bb9:
  %t34 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t35 = getelementptr { i64 }, ptr %t34, i32 0, i32 0
  %t36 = load i64, ptr %t35
  store i64 %t36, ptr %l3, !tbaa !24
  br label %bb11
bb10:
  br label %bb14
bb11:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/check:Checker", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/generic:Program", ptr %t41, i32 0, i32 2
  store ptr %t43, ptr %l25, !tbaa !29
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t48 = load i64, ptr %l3, !tbaa !24
  %t51 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %t47, i64 %t48)
  store i32 %t51, ptr %l29
  br label %bb12
bb12:
  %t52 = load ptr, ptr %l25, !tbaa !29
  %t53 = load i32, ptr %l29, !tbaa !23
  %t54 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t52, i32 %t53)
  store { i64, ptr } %t54, ptr %l30
  br label %bb13
bb13:
  %t55 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 0
  %t58 = icmp sgt i64 %t56, 0
  store i1 %t58, ptr %l19, !tbaa !21
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_9109cadfb541186e_2a46ab96c2b41f0a)
  unreachable
bb19:
  %t60 = load i1, ptr %l19, !tbaa !21
  store i1 %t60, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l4, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t7, i32 %a1)
  store i32 %t11, ptr %l7
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l4, !tbaa !29
  %t13 = load i32, ptr %l7, !tbaa !23
  %t14 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t14, ptr %l8
  br label %bb2
bb2:
  %t15 = load i1, ptr %l8, !tbaa !21
  store i1 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleadWord(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca { i64, ptr }
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l15 = alloca i1
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %l20 = alloca i1
  %l21 = alloca i1
  %l22 = alloca { i64, ptr }
  %l31 = alloca %"compiler/source:Span"
  %l37 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t2 = load %"compiler/source:Span", ptr %l1
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %a0, %"compiler/source:Span" %t2)
  store { i64, ptr } %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t13 = icmp slt i64 %t7, %t10
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l12, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i8, ptr %t19, i64 %t16
  %t21 = load i8, ptr %t20, !tbaa !32
  %t23 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t21)
  store i1 %t23, ptr %l15
  br label %bb5
bb4:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb13
bb5:
  %t24 = load i1, ptr %l15, !tbaa !21
  br i1 %t24, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb9
bb7:
  %t25 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t25, ptr %l17, !tbaa !27
  %t26 = load i64, ptr %l3, !tbaa !24
  %t28 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr i8, ptr %t29, i64 %t26
  %t31 = load i8, ptr %t30, !tbaa !32
  %t33 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t31)
  store i1 %t33, ptr %l20
  br label %bb8
bb8:
  %t34 = load i1, ptr %l20, !tbaa !21
  store i1 %t34, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t35 = load i1, ptr %l16, !tbaa !21
  br i1 %t35, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb12
bb11:
  %t36 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t36, ptr %l22, !tbaa !27
  %t37 = load i64, ptr %l3, !tbaa !24
  %t39 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr i8, ptr %t40, i64 %t37
  %t42 = load i8, ptr %t41, !tbaa !32
  %t44 = icmp eq i8 %t42, 95
  store i1 %t44, ptr %l21, !tbaa !21
  br label %bb12
bb12:
  %t46 = load i1, ptr %l21, !tbaa !21
  store i1 %t46, ptr %l11, !tbaa !21
  br label %bb13
bb13:
  %t47 = load i1, ptr %l11, !tbaa !21
  %t48 = xor i1 %t47, true
  br i1 %t48, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s1)
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t50 = load i64, ptr %l3, !tbaa !24
  %t52 = add i64 %t50, 1
  store i64 %t52, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb17
bb17:
  br label %bb2
bb18:
  %t54 = load i64, ptr %l3, !tbaa !24
  %t56 = icmp sgt i64 %t54, 0
  br i1 %t56, label %bb19, label %bb20
bb19:
  %t58 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t59 = load i32, ptr %t58, !tbaa !23
  %t60 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t61 = load i32, ptr %t60, !tbaa !23
  %t62 = load i64, ptr %l3, !tbaa !24
  %t64 = trunc i64 %t62 to i32
  %t67 = add i32 %t61, %t64
  %t70 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t59, i32 %t67)
  store %"compiler/source:Span" %t70, ptr %l37
  br label %bb21
bb20:
  %t71 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t71, ptr %l31
  br label %bb22
bb21:
  %t73 = load %"compiler/source:Span", ptr %l37
  store %"compiler/source:Span" %t73, ptr %l31
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t74 = load %"compiler/source:Span", ptr %l31
  store %"compiler/source:Span" %t74, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsWritable(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l11 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l23 = alloca i1
  %l28 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t6, i32 %a1)
  store { i64, ptr } %t10, ptr %l11
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t11, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  store i64 %t14, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t16 = load i64, ptr %l4, !tbaa !24
  %t17 = load i64, ptr %l5, !tbaa !24
  %t20 = icmp slt i64 %t16, %t17
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb4:
  br label %bb5
bb5:
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t24, ptr %l18, !tbaa !27
  %t25 = load i64, ptr %l4, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i32, ptr %t28, i64 %t25
  %t30 = load i32, ptr %t29, !tbaa !33
  store i32 %t30, ptr %l6, !tbaa !23
  %t32 = load i32, ptr %l6, !tbaa !23
  %t34 = icmp ne i32 %t32, 0
  br i1 %t34, label %bb6, label %bb7
bb6:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i32, ptr %l6, !tbaa !23
  %t40 = add i64 %a2, 1
  %t44 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritableAt(ptr %v0, ptr %t36, i32 %t37, i64 %t40)
  store i1 %t44, ptr %l28
  br label %bb8
bb7:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb9
bb8:
  %t45 = load i1, ptr %l28, !tbaa !21
  store i1 %t45, ptr %l23, !tbaa !21
  br label %bb9
bb9:
  %t46 = load i1, ptr %l23, !tbaa !21
  br i1 %t46, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  %t48 = load i64, ptr %l4, !tbaa !24
  %t50 = add i64 %t48, 1
  store i64 %t50, ptr %l4, !tbaa !24
  br label %bb2
bb14:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ematchValue(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca ptr
  %l12 = alloca i64
  %l17 = alloca ptr
  %l20 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l30 = alloca i1
  %l38 = alloca ptr
  %l43 = alloca ptr
  %l46 = alloca i64
  %l51 = alloca ptr
  %l55 = alloca { i64, ptr }
  %l61 = alloca ptr
  %l64 = alloca %"compiler/source:Span"
  %l65 = alloca %"compiler/msgs:Msg"
  %l66 = alloca i64
  %l69 = alloca ptr
  %l77 = alloca ptr
  %l82 = alloca ptr
  %l87 = alloca ptr
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Match", ptr %t1, i32 0, i32 2
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ematchOnType(ptr %v0, ptr %v1, ptr %t6, ptr %t7)
  store i64 %t10, ptr %l12
  br label %bb3
bb2:
  br label %bb20
bb3:
  %t11 = load i64, ptr %l12, !tbaa !24
  store i64 %t11, ptr %l4, !tbaa !24
  %t12 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp eq i64 %t12, -2
  br i1 %t14, label %bb4, label %bb5
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load %"compiler/source:Span", ptr %l1
  %t20 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t16, %"compiler/source:Span" %t17)
  store ptr %t20, ptr %l17
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t21 = load ptr, ptr %l17, !tbaa !29
  store ptr %t21, ptr %rv
  br label %ret
bb7:
  %t22 = load i64, ptr %l4, !tbaa !24
  %t24 = icmp slt i64 %t22, 0
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = getelementptr %"compiler/ast:Match", ptr %t26, i32 0, i32 4
  %t29 = load ptr, ptr %t28, !tbaa !29
  store ptr %t29, ptr %l20, !tbaa !29
  br label %bb10
bb9:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = getelementptr %"compiler/ast:Match", ptr %t31, i32 0, i32 3
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  store { i64, ptr } %t34, ptr %l24, !tbaa !27
  %t35 = load i64, ptr %l4, !tbaa !24
  %t37 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr ptr, ptr %t38, i64 %t35
  %t40 = load ptr, ptr %t39, !tbaa !39
  store ptr %t40, ptr %l20, !tbaa !29
  br label %bb10
bb10:
  %t43 = load ptr, ptr %l20, !tbaa !29
  store ptr %t43, ptr %l5, !tbaa !29
  %t44 = load ptr, ptr %l5, !tbaa !29
  %t46 = icmp eq ptr %t44, null
  br i1 %t46, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb13
bb12:
  %t48 = load ptr, ptr %l5, !tbaa !29
  %t50 = getelementptr %"compiler/ast:Case", ptr %t48, i32 0, i32 5
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = icmp eq ptr %t51, null
  store i1 %t53, ptr %l30, !tbaa !21
  br label %bb13
bb13:
  %t55 = load i1, ptr %l30, !tbaa !21
  br i1 %t55, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s3, ptr %t56, %"compiler/source:Span" %t57, { i64, ptr } { i64 51, ptr @.d7 })
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load %"compiler/source:Span", ptr %l1
  %t64 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t60, %"compiler/source:Span" %t61)
  store ptr %t64, ptr %l38
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s3)
  %t65 = load ptr, ptr %l38, !tbaa !29
  store ptr %t65, ptr %rv
  br label %ret
bb18:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load ptr, ptr %l5, !tbaa !29
  %t69 = getelementptr %"compiler/ast:Case", ptr %t67, i32 0, i32 5
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t71 = load i32, ptr %l3, !tbaa !23
  %t75 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t66, ptr %t70, i32 %t71)
  store ptr %t75, ptr %l43
  br label %bb19
bb19:
  %t76 = load ptr, ptr %l43, !tbaa !29
  store ptr %t76, ptr %rv
  br label %ret
bb20:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load ptr, ptr %l2, !tbaa !29
  %t81 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elenMatch(ptr %v0, ptr %v1, ptr %t77, ptr %t78)
  store i64 %t81, ptr %l46
  br label %bb21
bb21:
  %t82 = load i64, ptr %l46, !tbaa !24
  store i64 %t82, ptr %l6, !tbaa !24
  %t83 = load i64, ptr %l6, !tbaa !24
  %t85 = icmp ne i64 %t83, -2
  br i1 %t85, label %bb22, label %bb23
bb22:
  %t87 = load i64, ptr %l6, !tbaa !24
  %t89 = icmp slt i64 %t87, 0
  br i1 %t89, label %bb24, label %bb25
bb23:
  br label %bb40
bb24:
  %t91 = load ptr, ptr %l2, !tbaa !29
  %t93 = getelementptr %"compiler/ast:Match", ptr %t91, i32 0, i32 4
  %t94 = load ptr, ptr %t93, !tbaa !29
  store ptr %t94, ptr %l51, !tbaa !29
  br label %bb26
bb25:
  %t96 = load ptr, ptr %l2, !tbaa !29
  %t98 = getelementptr %"compiler/ast:Match", ptr %t96, i32 0, i32 3
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  store { i64, ptr } %t99, ptr %l55, !tbaa !27
  %t100 = load i64, ptr %l6, !tbaa !24
  %t102 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr ptr, ptr %t103, i64 %t100
  %t105 = load ptr, ptr %t104, !tbaa !39
  store ptr %t105, ptr %l51, !tbaa !29
  br label %bb26
bb26:
  %t108 = load ptr, ptr %l51, !tbaa !29
  store ptr %t108, ptr %l7, !tbaa !29
  %t109 = load ptr, ptr %l7, !tbaa !29
  %t111 = icmp eq ptr %t109, null
  br i1 %t111, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s5
  %t113 = load ptr, ptr %l0, !tbaa !29
  store ptr %t113, ptr %l61, !tbaa !29
  %t114 = load ptr, ptr %l2, !tbaa !29
  %t116 = getelementptr %"compiler/ast:Match", ptr %t114, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !29
  %t119 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t117)
  store %"compiler/source:Span" %t119, ptr %l64
  br label %bb29
bb28:
  br label %bb33
bb29:
  %t120 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMatchValueNone(ptr %s5)
  store %"compiler/msgs:Msg" %t120, ptr %l65
  br label %bb30
bb30:
  %t121 = load ptr, ptr %l61, !tbaa !29
  %t122 = load %"compiler/source:Span", ptr %l64
  %t123 = load %"compiler/msgs:Msg", ptr %l65
  %t124 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t121, %"compiler/source:Span" %t122, %"compiler/msgs:Msg" %t123)
  store i64 %t124, ptr %l66
  br label %bb31
bb31:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load %"compiler/source:Span", ptr %l1
  %t129 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t125, %"compiler/source:Span" %t126)
  store ptr %t129, ptr %l69
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s5)
  %t130 = load ptr, ptr %l69, !tbaa !29
  store ptr %t130, ptr %rv
  br label %ret
bb33:
  %t131 = load ptr, ptr %l7, !tbaa !29
  %t133 = getelementptr %"compiler/ast:Case", ptr %t131, i32 0, i32 5
  %t134 = load ptr, ptr %t133, !tbaa !29
  %t136 = icmp eq ptr %t134, null
  br i1 %t136, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s6
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s6, ptr %t138, %"compiler/source:Span" %t139, { i64, ptr } { i64 53, ptr @.d8 })
  br label %bb36
bb35:
  br label %bb38
bb36:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load %"compiler/source:Span", ptr %l1
  %t146 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t142, %"compiler/source:Span" %t143)
  store ptr %t146, ptr %l77
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s6)
  %t147 = load ptr, ptr %l77, !tbaa !29
  store ptr %t147, ptr %rv
  br label %ret
bb38:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load ptr, ptr %l7, !tbaa !29
  %t151 = getelementptr %"compiler/ast:Case", ptr %t149, i32 0, i32 5
  %t152 = load ptr, ptr %t151, !tbaa !29
  %t153 = load i32, ptr %l3, !tbaa !23
  %t157 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t148, ptr %t152, i32 %t153)
  store ptr %t157, ptr %l82
  br label %bb39
bb39:
  %t158 = load ptr, ptr %l82, !tbaa !29
  store ptr %t158, ptr %rv
  br label %ret
bb40:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load %"compiler/source:Span", ptr %l1
  %t161 = load ptr, ptr %l2, !tbaa !29
  %t162 = load i32, ptr %l3, !tbaa !23
  %t167 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ematchExpr(ptr %v0, ptr %v1, ptr %t159, %"compiler/source:Span" %t160, ptr %t161, i1 true, i32 %t162)
  store ptr %t167, ptr %l87
  br label %bb41
bb41:
  %t168 = load ptr, ptr %l87, !tbaa !29
  store ptr %t168, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emembership(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca %"compiler/generic:Binding"
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca i32
  %l36 = alloca ptr
  %l40 = alloca ptr
  %l43 = alloca i32
  %l47 = alloca i32
  %l52 = alloca i32
  %l57 = alloca ptr
  %l58 = alloca i32
  %l59 = alloca ptr
  %l61 = alloca %"compiler/source:Span"
  %l63 = alloca %"compiler/source:Span"
  %l64 = alloca %"compiler/source:Span"
  %l65 = alloca i64
  %l70 = alloca ptr
  %l73 = alloca ptr
  %l77 = alloca i32
  %l78 = alloca i32
  %l79 = alloca { i64, ptr }
  %l81 = alloca i64
  %l85 = alloca i64
  %l91 = alloca { i64, ptr }
  %l93 = alloca i32
  %l98 = alloca { i64, ptr }
  %l100 = alloca i32
  %l106 = alloca %"compiler/generic:Binding"
  %l107 = alloca ptr
  %l108 = alloca { i64, ptr }
  %l109 = alloca i32
  %l112 = alloca i32
  %l117 = alloca i32
  %l122 = alloca ptr
  %l125 = alloca ptr
  %l126 = alloca ptr
  %l129 = alloca i32
  %l130 = alloca i32
  %l132 = alloca i1
  %l133 = alloca { i64, ptr }
  %l134 = alloca ptr
  %l135 = alloca i32
  %l136 = alloca { i64, ptr }
  %l137 = alloca ptr
  %l139 = alloca %"compiler/source:Span"
  %l141 = alloca %"compiler/source:Span"
  %l142 = alloca %"compiler/source:Span"
  %l143 = alloca i64
  %l146 = alloca i1
  %l147 = alloca ptr
  %l148 = alloca i32
  %l149 = alloca { i64, ptr }
  %l150 = alloca ptr
  %l152 = alloca %"compiler/source:Span"
  %l154 = alloca %"compiler/source:Span"
  %l155 = alloca %"compiler/source:Span"
  %l156 = alloca i1
  %l160 = alloca ptr
  %l163 = alloca ptr
  %l164 = alloca ptr
  %l166 = alloca %"compiler/source:Span"
  %l168 = alloca %"compiler/source:Span"
  %l169 = alloca %"compiler/source:Span"
  %l170 = alloca { i64, ptr }
  %l173 = alloca { i64, ptr }
  %l175 = alloca %"compiler/msgs:Msg"
  %l176 = alloca i64
  %l180 = alloca ptr
  %l181 = alloca ptr
  %l182 = alloca ptr
  %l186 = alloca ptr
  %l189 = alloca { i64, ptr }
  %l190 = alloca ptr
  %l191 = alloca ptr
  %l193 = alloca %"compiler/source:Span"
  %l195 = alloca %"compiler/source:Span"
  %l196 = alloca %"compiler/source:Span"
  %l197 = alloca ptr
  %l198 = alloca %"compiler/source:Span"
  %l201 = alloca i32
  %l202 = alloca i64
  %l205 = alloca i64
  %l215 = alloca ptr
  %l216 = alloca %"compiler/source:Span"
  %l217 = alloca %"compiler/source:Span"
  %l218 = alloca i64
  %l220 = alloca ptr
  %l223 = alloca { i64, ptr }
  %l224 = alloca ptr
  %l228 = alloca ptr
  %l229 = alloca { i64, ptr }
  %l233 = alloca ptr
  %l234 = alloca %"compiler/source:Span"
  %l237 = alloca i32
  %l241 = alloca { i64, ptr }
  %l244 = alloca %"compiler/typed:Seq"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca ptr
  %t394 = alloca { i64, [3 x i64] }, align 8
  %t470 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t4 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t8 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %t1, ptr %t2, i32 %t4)
  store ptr %t8, ptr %l23
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l23, !tbaa !29
  store ptr %t9, ptr %l4, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l24, !tbaa !29
  %t11 = load ptr, ptr %l4, !tbaa !29
  %t14 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t11)
  store i32 %t14, ptr %l27
  br label %bb2
bb2:
  %t15 = load ptr, ptr %l24, !tbaa !29
  %t16 = load i32, ptr %l27, !tbaa !23
  %t17 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t17, ptr %l28
  br label %bb3
bb3:
  %t18 = load i32, ptr %l28, !tbaa !23
  store i32 %t18, ptr %l5, !tbaa !23
  %t19 = load i32, ptr %l5, !tbaa !23
  %t20 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t23 = icmp eq i32 %t19, %t20
  br i1 %t23, label %bb4, label %bb5
bb4:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t32 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t25, ptr %t26, i32 %t28)
  store ptr %t32, ptr %l36
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load %"compiler/source:Span", ptr %l1
  %t35 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t39 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t33, %"compiler/source:Span" %t34, i32 %t35, i64 0)
  store ptr %t39, ptr %l40
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t40 = load ptr, ptr %l40, !tbaa !29
  store ptr %t40, ptr %rv
  br label %ret
bb8:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i32, ptr %l5, !tbaa !23
  %t45 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t41, i32 %t42)
  store i32 %t45, ptr %l43
  br label %bb9
bb9:
  %t46 = load i32, ptr %l43, !tbaa !23
  store i32 %t46, ptr %l6, !tbaa !23
  %t47 = load i32, ptr %l6, !tbaa !23
  %t48 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t51 = icmp ne i32 %t47, %t48
  br i1 %t51, label %bb10, label %bb11
bb10:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = getelementptr %"compiler/generic:Program", ptr %t56, i32 0, i32 2
  %t59 = load i32, ptr %l6, !tbaa !23
  %t62 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t58, i32 %t59)
  store i32 %t62, ptr %l52
  br label %bb12
bb11:
  %t63 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t63, ptr %l47, !tbaa !23
  br label %bb13
bb12:
  %t65 = load i32, ptr %l52, !tbaa !23
  store i32 %t65, ptr %l47, !tbaa !23
  br label %bb13
bb13:
  %t66 = load i32, ptr %l47, !tbaa !23
  store i32 %t66, ptr %l7, !tbaa !23
  %t67 = load i32, ptr %l6, !tbaa !23
  %t68 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t71 = icmp eq i32 %t67, %t68
  br i1 %t71, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s2
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l57, !tbaa !29
  %t74 = load i32, ptr %l5, !tbaa !23
  store i32 %t74, ptr %l58, !tbaa !23
  %t75 = load ptr, ptr %l0, !tbaa !29
  store ptr %t75, ptr %l59, !tbaa !29
  %t76 = load ptr, ptr %l2, !tbaa !29
  %t78 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t76)
  store %"compiler/source:Span" %t78, ptr %l61
  br label %bb16
bb15:
  br label %bb43
bb16:
  %t79 = load ptr, ptr %l3, !tbaa !29
  %t81 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t79)
  store %"compiler/source:Span" %t81, ptr %l63
  br label %bb17
bb17:
  %t82 = load ptr, ptr %l59, !tbaa !29
  %t83 = load %"compiler/source:Span", ptr %l61
  %t84 = load %"compiler/source:Span", ptr %l63
  %t85 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t82, %"compiler/source:Span" %t83, %"compiler/source:Span" %t84, i64 2)
  store %"compiler/source:Span" %t85, ptr %l64
  br label %bb18
bb18:
  %t86 = load ptr, ptr %l57, !tbaa !29
  %t87 = load i32, ptr %l58, !tbaa !23
  %t88 = load %"compiler/source:Span", ptr %l64
  %t89 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %s2, ptr %s2, ptr %t86, i32 %t87, { i64, ptr } { i64 3, ptr @.d9 }, i64 1, %"compiler/source:Span" %t88, { i64, ptr } { i64 4, ptr @.d10 })
  store i64 %t89, ptr %l65
  br label %bb19
bb19:
  %t90 = load i64, ptr %l65, !tbaa !24
  store i64 %t90, ptr %l8, !tbaa !24
  %t91 = load i64, ptr %l8, !tbaa !24
  %t93 = icmp sge i64 %t91, 0
  br i1 %t93, label %bb20, label %bb21
bb20:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/check:Checker", ptr %t95, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t100 = getelementptr %"compiler/generic:Program", ptr %t98, i32 0, i32 2
  store ptr %t100, ptr %l70, !tbaa !29
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/check:Checker", ptr %t101, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t106 = getelementptr %"compiler/generic:Program", ptr %t104, i32 0, i32 2
  store ptr %t106, ptr %l73, !tbaa !29
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/check:Checker", ptr %t107, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t111 = load i64, ptr %l8, !tbaa !24
  %t114 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t110, i64 %t111)
  store i32 %t114, ptr %l77
  br label %bb22
bb21:
  br label %bb42
bb22:
  %t115 = load ptr, ptr %l73, !tbaa !29
  %t116 = load i32, ptr %l77, !tbaa !23
  %t117 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t115, i32 %t116)
  store i32 %t117, ptr %l78
  br label %bb23
bb23:
  %t118 = load ptr, ptr %l70, !tbaa !29
  %t119 = load i32, ptr %l78, !tbaa !23
  %t120 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t118, i32 %t119)
  store { i64, ptr } %t120, ptr %l79
  br label %bb24
bb24:
  %t121 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t121, ptr %l9, !tbaa !27
  %t122 = load i64, ptr %l8, !tbaa !24
  %t124 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t122)
  store i64 %t124, ptr %l81
  br label %bb25
bb25:
  %t125 = load i64, ptr %l81, !tbaa !24
  store i64 %t125, ptr %l10, !tbaa !24
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/check:Checker", ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t130 = load i64, ptr %l10, !tbaa !24
  %t133 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t129, i64 %t130)
  store i64 %t133, ptr %l85
  br label %bb26
bb26:
  %t134 = load i64, ptr %l85, !tbaa !24
  store i64 %t134, ptr %l11, !tbaa !24
  %t135 = load i64, ptr %l11, !tbaa !24
  %t137 = icmp eq i64 %t135, 0
  br i1 %t137, label %bb27, label %bb28
bb27:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/check:Checker", ptr %t139, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t144 = getelementptr %"compiler/generic:Program", ptr %t142, i32 0, i32 2
  %t145 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t145, ptr %l91, !tbaa !27
  %t146 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr i32, ptr %t147, i64 1
  %t149 = load i32, ptr %t148, !tbaa !33
  %t152 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t144, i32 %t149)
  store i32 %t152, ptr %l93
  br label %bb29
bb28:
  %t153 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t153, 0
  %t157 = icmp sgt i64 %t155, 1
  br i1 %t157, label %bb34, label %bb35
bb29:
  %t159 = load i32, ptr %l93
  %t161 = trunc i64 25 to i32
  %t162 = icmp eq i32 %t159, %t161
  %t164 = xor i1 %t162, true
  br i1 %t164, label %bb30, label %bb31
bb30:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t167, ptr %l98, !tbaa !27
  %t168 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !27
  %t170 = getelementptr i32, ptr %t169, i64 1
  %t171 = load i32, ptr %t170, !tbaa !33
  %t174 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t166, i32 %t171)
  store i32 %t174, ptr %l100
  br label %bb32
bb31:
  br label %bb33
bb32:
  %t175 = load i32, ptr %l100, !tbaa !23
  store i32 %t175, ptr %l7, !tbaa !23
  br label %bb33
bb33:
  br label %bb41
bb34:
  store %olang.scope zeroinitializer, ptr %s7
  %t176 = load i64, ptr %l10, !tbaa !24
  %t177 = load i64, ptr %l11, !tbaa !24
  %t180 = call %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %s7, i64 %t176, i64 %t177)
  store %"compiler/generic:Binding" %t180, ptr %l106
  br label %bb36
bb35:
  br label %bb40
bb36:
  %t181 = load %"compiler/generic:Binding", ptr %l106
  store %"compiler/generic:Binding" %t181, ptr %l12
  %t182 = load ptr, ptr %l0, !tbaa !29
  store ptr %t182, ptr %l107, !tbaa !29
  %t183 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t183, ptr %l108, !tbaa !27
  %t184 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !27
  %t186 = getelementptr i32, ptr %t185, i64 0
  %t187 = load i32, ptr %t186, !tbaa !33
  store i32 %t187, ptr %l109, !tbaa !23
  %t188 = load ptr, ptr %l4, !tbaa !29
  %t191 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t188)
  store i32 %t191, ptr %l112
  br label %bb37
bb37:
  %t192 = load ptr, ptr %l107, !tbaa !29
  %t193 = load i32, ptr %l109, !tbaa !23
  %t194 = load i32, ptr %l112, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %s7, ptr %t192, i32 %t193, i32 %t194, ptr %l12, i1 false, i1 true)
  br label %bb38
bb38:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t201 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eboundParam(ptr %v0, ptr %v0, ptr %s7, ptr %t196, { i64, ptr } %t197, i64 1, ptr %l12)
  store i32 %t201, ptr %l117
  br label %bb39
bb39:
  %t202 = load i32, ptr %l117, !tbaa !23
  store i32 %t202, ptr %l7, !tbaa !23
  call void @__olang_scope_close(ptr %s7)
  br label %bb40
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s2)
  br label %bb43
bb43:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load ptr, ptr %l2, !tbaa !29
  %t206 = load i32, ptr %l7, !tbaa !23
  %t210 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t203, ptr %t204, i32 %t206)
  store ptr %t210, ptr %l122
  br label %bb44
bb44:
  %t211 = load ptr, ptr %l122, !tbaa !29
  store ptr %t211, ptr %l13, !tbaa !29
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"compiler/check:Checker", ptr %t212, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !29
  %t217 = getelementptr %"compiler/generic:Program", ptr %t215, i32 0, i32 2
  store ptr %t217, ptr %l125, !tbaa !29
  %t218 = load ptr, ptr %l0, !tbaa !29
  store ptr %t218, ptr %l126, !tbaa !29
  %t219 = load ptr, ptr %l13, !tbaa !29
  %t222 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t219)
  store i32 %t222, ptr %l129
  br label %bb45
bb45:
  %t223 = load ptr, ptr %l126, !tbaa !29
  %t224 = load i32, ptr %l129, !tbaa !23
  %t225 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t223, i32 %t224)
  store i32 %t225, ptr %l130
  br label %bb46
bb46:
  %t226 = load i32, ptr %l5, !tbaa !23
  %t227 = load ptr, ptr %l125, !tbaa !29
  %t228 = load i32, ptr %l130, !tbaa !23
  %t230 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t227, i32 %t228, i32 %t226)
  store i1 %t230, ptr %l132
  br label %bb47
bb47:
  %t231 = load i1, ptr %l132, !tbaa !21
  br i1 %t231, label %bb48, label %bb49
bb48:
  store { i64, ptr } { i64 8, ptr @.d11 }, ptr %l133, !tbaa !27
  br label %bb50
bb49:
  store { i64, ptr } { i64 3, ptr @.d12 }, ptr %l133, !tbaa !27
  br label %bb50
bb50:
  %t232 = load { i64, ptr }, ptr %l133, !tbaa !27
  store { i64, ptr } %t232, ptr %l14, !tbaa !27
  %t233 = load ptr, ptr %l0, !tbaa !29
  store ptr %t233, ptr %l134, !tbaa !29
  %t234 = load i32, ptr %l5, !tbaa !23
  store i32 %t234, ptr %l135, !tbaa !23
  %t235 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t235, ptr %l136, !tbaa !27
  %t236 = load ptr, ptr %l0, !tbaa !29
  store ptr %t236, ptr %l137, !tbaa !29
  %t237 = load ptr, ptr %l2, !tbaa !29
  %t239 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t237)
  store %"compiler/source:Span" %t239, ptr %l139
  br label %bb51
bb51:
  %t240 = load ptr, ptr %l3, !tbaa !29
  %t242 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t240)
  store %"compiler/source:Span" %t242, ptr %l141
  br label %bb52
bb52:
  %t243 = load ptr, ptr %l137, !tbaa !29
  %t244 = load %"compiler/source:Span", ptr %l139
  %t245 = load %"compiler/source:Span", ptr %l141
  %t246 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t243, %"compiler/source:Span" %t244, %"compiler/source:Span" %t245, i64 2)
  store %"compiler/source:Span" %t246, ptr %l142
  br label %bb53
bb53:
  %t247 = load ptr, ptr @__olang_prog_scope
  %t248 = load ptr, ptr %l134, !tbaa !29
  %t249 = load i32, ptr %l135, !tbaa !23
  %t250 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t251 = load %"compiler/source:Span", ptr %l142
  %t252 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %t247, ptr %s0, ptr %t248, i32 %t249, { i64, ptr } %t250, i64 1, %"compiler/source:Span" %t251, { i64, ptr } { i64 4, ptr @.d13 })
  store i64 %t252, ptr %l143
  br label %bb54
bb54:
  %t253 = load i64, ptr %l143, !tbaa !24
  store i64 %t253, ptr %l15, !tbaa !24
  %t254 = load i64, ptr %l15, !tbaa !24
  %t256 = icmp slt i64 %t254, 0
  br i1 %t256, label %bb55, label %bb56
bb55:
  %t258 = load ptr, ptr %l0, !tbaa !29
  store ptr %t258, ptr %l147, !tbaa !29
  %t259 = load i32, ptr %l5, !tbaa !23
  store i32 %t259, ptr %l148, !tbaa !23
  %t260 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t260, ptr %l149, !tbaa !27
  %t261 = load ptr, ptr %l0, !tbaa !29
  store ptr %t261, ptr %l150, !tbaa !29
  %t262 = load ptr, ptr %l2, !tbaa !29
  %t264 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t262)
  store %"compiler/source:Span" %t264, ptr %l152
  br label %bb57
bb56:
  store i1 false, ptr %l146, !tbaa !21
  br label %bb61
bb57:
  %t265 = load ptr, ptr %l3, !tbaa !29
  %t267 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t265)
  store %"compiler/source:Span" %t267, ptr %l154
  br label %bb58
bb58:
  %t268 = load ptr, ptr %l150, !tbaa !29
  %t269 = load %"compiler/source:Span", ptr %l152
  %t270 = load %"compiler/source:Span", ptr %l154
  %t271 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t268, %"compiler/source:Span" %t269, %"compiler/source:Span" %t270, i64 2)
  store %"compiler/source:Span" %t271, ptr %l155
  br label %bb59
bb59:
  %t272 = load ptr, ptr @__olang_prog_scope
  %t273 = load ptr, ptr %l147, !tbaa !29
  %t274 = load i32, ptr %l148, !tbaa !23
  %t275 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t276 = load %"compiler/source:Span", ptr %l155
  %t277 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %t272, ptr %s0, ptr %t273, i32 %t274, { i64, ptr } %t275, %"compiler/source:Span" %t276, { i64, ptr } { i64 8, ptr @.d14 }, i64 1, i1 false)
  store i1 %t277, ptr %l156
  br label %bb60
bb60:
  %t278 = load i1, ptr %l156, !tbaa !21
  store i1 %t278, ptr %l146, !tbaa !21
  br label %bb61
bb61:
  %t279 = load i1, ptr %l146, !tbaa !21
  br i1 %t279, label %bb62, label %bb63
bb62:
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t281 = load %"compiler/source:Span", ptr %l1
  %t282 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t286 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t280, %"compiler/source:Span" %t281, i32 %t282, i64 0)
  store ptr %t286, ptr %l160
  br label %bb64
bb63:
  br label %bb65
bb64:
  call void @__olang_scope_close(ptr %s0)
  %t287 = load ptr, ptr %l160, !tbaa !29
  store ptr %t287, ptr %rv
  br label %ret
bb65:
  %t288 = load i64, ptr %l15, !tbaa !24
  %t290 = icmp slt i64 %t288, 0
  br i1 %t290, label %bb66, label %bb67
bb66:
  store %olang.scope zeroinitializer, ptr %s9
  %t292 = load ptr, ptr %l0, !tbaa !29
  store ptr %t292, ptr %l163, !tbaa !29
  %t293 = load ptr, ptr %l0, !tbaa !29
  store ptr %t293, ptr %l164, !tbaa !29
  %t294 = load ptr, ptr %l2, !tbaa !29
  %t296 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t294)
  store %"compiler/source:Span" %t296, ptr %l166
  br label %bb68
bb67:
  br label %bb75
bb68:
  %t297 = load ptr, ptr %l3, !tbaa !29
  %t299 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t297)
  store %"compiler/source:Span" %t299, ptr %l168
  br label %bb69
bb69:
  %t300 = load ptr, ptr %l164, !tbaa !29
  %t301 = load %"compiler/source:Span", ptr %l166
  %t302 = load %"compiler/source:Span", ptr %l168
  %t303 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t300, %"compiler/source:Span" %t301, %"compiler/source:Span" %t302, i64 2)
  store %"compiler/source:Span" %t303, ptr %l169
  br label %bb70
bb70:
  %t304 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t304, ptr %l170, !tbaa !27
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t306 = load i32, ptr %l5, !tbaa !23
  %t309 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s9, ptr %t305, i32 %t306)
  store { i64, ptr } %t309, ptr %l173
  br label %bb71
bb71:
  %t310 = load { i64, ptr }, ptr %l173, !tbaa !27
  %t311 = extractvalue { i64, ptr } %t310, 0
  %t312 = extractvalue { i64, ptr } %t310, 1
  %t313 = mul i64 %t311, 1
  %t314 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t313)
  call void @llvm.memcpy.p0.p0.i64(ptr %t314, ptr %t312, i64 %t313, i1 false)
  %t315 = insertvalue { i64, ptr } undef, i64 %t311, 0
  %t316 = insertvalue { i64, ptr } %t315, ptr %t314, 1
  %t317 = load ptr, ptr @__olang_prog_scope
  %t318 = load { i64, ptr }, ptr %l170, !tbaa !27
  %t320 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMembershipNoMethod(ptr %t317, ptr %s9, ptr %s9, { i64, ptr } %t318, { i64, ptr } %t316)
  store %"compiler/msgs:Msg" %t320, ptr %l175
  br label %bb72
bb72:
  %t321 = load ptr, ptr %l163, !tbaa !29
  %t322 = load %"compiler/source:Span", ptr %l169
  %t323 = load %"compiler/msgs:Msg", ptr %l175
  %t324 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s9, ptr %t321, %"compiler/source:Span" %t322, %"compiler/msgs:Msg" %t323)
  store i64 %t324, ptr %l176
  br label %bb73
bb73:
  %t325 = load ptr, ptr %l0, !tbaa !29
  %t326 = load %"compiler/source:Span", ptr %l1
  %t327 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t331 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t325, %"compiler/source:Span" %t326, i32 %t327, i64 0)
  store ptr %t331, ptr %l180
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t332 = load ptr, ptr %l180, !tbaa !29
  store ptr %t332, ptr %rv
  br label %ret
bb75:
  %t333 = load ptr, ptr %l0, !tbaa !29
  store ptr %t333, ptr %l181, !tbaa !29
  %t334 = load ptr, ptr %l0, !tbaa !29
  store ptr %t334, ptr %l182, !tbaa !29
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t337 = getelementptr %"compiler/check:Checker", ptr %t335, i32 0, i32 1
  %t338 = load ptr, ptr %t337, !tbaa !29
  %t339 = load i64, ptr %l15, !tbaa !24
  %t342 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t338, i64 %t339)
  store ptr %t342, ptr %l186
  br label %bb76
bb76:
  %t343 = load ptr, ptr %l186, !tbaa !29
  %t345 = getelementptr %"compiler/ast:Func", ptr %t343, i32 0, i32 2
  %t346 = load i32, ptr %t345, !tbaa !23
  %t347 = load ptr, ptr %l182, !tbaa !29
  %t349 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t347, i32 %t346)
  store { i64, ptr } %t349, ptr %l189
  br label %bb77
bb77:
  %t350 = load { i64, ptr }, ptr %l189, !tbaa !27
  %t351 = load ptr, ptr %l181, !tbaa !29
  %t352 = getelementptr %"compiler/check:Checker", ptr %t351, i32 0, i32 42
  store { i64, ptr } %t350, ptr %t352, !tbaa !27
  %t353 = load ptr, ptr %l0, !tbaa !29
  store ptr %t353, ptr %l190, !tbaa !29
  %t354 = load ptr, ptr %l0, !tbaa !29
  store ptr %t354, ptr %l191, !tbaa !29
  %t355 = load ptr, ptr %l2, !tbaa !29
  %t357 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t355)
  store %"compiler/source:Span" %t357, ptr %l193
  br label %bb78
bb78:
  %t358 = load ptr, ptr %l3, !tbaa !29
  %t360 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t358)
  store %"compiler/source:Span" %t360, ptr %l195
  br label %bb79
bb79:
  %t361 = load ptr, ptr %l191, !tbaa !29
  %t362 = load %"compiler/source:Span", ptr %l193
  %t363 = load %"compiler/source:Span", ptr %l195
  %t364 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t361, %"compiler/source:Span" %t362, %"compiler/source:Span" %t363, i64 2)
  store %"compiler/source:Span" %t364, ptr %l196
  br label %bb80
bb80:
  %t365 = load %"compiler/source:Span", ptr %l196
  %t366 = load ptr, ptr %l190, !tbaa !29
  %t367 = getelementptr %"compiler/check:Checker", ptr %t366, i32 0, i32 41
  store %"compiler/source:Span" %t365, ptr %t367
  %t368 = load ptr, ptr %l0, !tbaa !29
  store ptr %t368, ptr %l197, !tbaa !29
  %t369 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t369, ptr %l198
  %t370 = load ptr, ptr %l13, !tbaa !29
  %t373 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t370)
  store i32 %t373, ptr %l201
  br label %bb81
bb81:
  %t374 = load ptr, ptr %l197, !tbaa !29
  %t375 = load %"compiler/source:Span", ptr %l198
  %t376 = load i32, ptr %l201, !tbaa !23
  %t377 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t374, %"compiler/source:Span" %t375, i32 %t376)
  store i64 %t377, ptr %l202
  br label %bb82
bb82:
  %t378 = load i64, ptr %l202, !tbaa !24
  store i64 %t378, ptr %l16, !tbaa !24
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t381 = getelementptr %"compiler/check:Checker", ptr %t379, i32 0, i32 32
  %t383 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t381)
  store i64 %t383, ptr %l205
  br label %bb83
bb83:
  %t384 = load i64, ptr %l205, !tbaa !24
  store i64 %t384, ptr %l17, !tbaa !24
  %t385 = load ptr, ptr %l0, !tbaa !29
  %t387 = getelementptr %"compiler/check:Checker", ptr %t385, i32 0, i32 32
  %t388 = load %"compiler/source:Span", ptr %l1
  %t389 = load i64, ptr %l16, !tbaa !24
  %t391 = trunc i64 %t389 to i32
  %t393 = load ptr, ptr %l13, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t394
  %t395 = getelementptr { i64, [3 x i64] }, ptr %t394, i32 0, i32 0
  store i64 0, ptr %t395
  %t397 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t388, 0
  %t399 = insertvalue { %"compiler/source:Span", i32, ptr } %t397, i32 %t391, 1
  %t401 = insertvalue { %"compiler/source:Span", i32, ptr } %t399, ptr %t393, 2
  %t402 = getelementptr { i64, [3 x i64] }, ptr %t394, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t401, ptr %t402
  %t403 = load { i64, [3 x i64] }, ptr %t394
  %t405 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t403, ptr %t405
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ePus_He68407854d25cdd1c04f001baf21eeaa(ptr %v0, ptr %v0, ptr %t387, ptr %t405)
  br label %bb84
bb84:
  %t408 = load ptr, ptr %l0, !tbaa !29
  store ptr %t408, ptr %l215, !tbaa !29
  %t409 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t409, ptr %l216
  %t410 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t410, ptr %l217
  %t411 = load i64, ptr %l15, !tbaa !24
  store i64 %t411, ptr %l218, !tbaa !24
  %t412 = load ptr, ptr %l4, !tbaa !29
  store ptr %t412, ptr %l220, !tbaa !29
  %t414 = icmp sge i64 0, 0
  br i1 %t414, label %bb85, label %bb86
bb85:
  %t416 = icmp sle i64 0, 1152921504606846975
  br i1 %t416, label %bb87, label %bb88
bb86:
  call void @__olang_check_failed(ptr @olang_loc_1fa90a145069ae20_a62c963c9e2d6294)
  unreachable
bb87:
  %t418 = mul i64 0, 8
  %t419 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t418)
  %t420 = insertvalue { i64, ptr } undef, i64 0, 0
  %t421 = insertvalue { i64, ptr } %t420, ptr %t419, 1
  store { i64, ptr } %t421, ptr %l223, !tbaa !27
  %t422 = load ptr, ptr %l0, !tbaa !29
  store ptr %t422, ptr %l224, !tbaa !29
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t424 = load %"compiler/source:Span", ptr %l1
  %t425 = load i64, ptr %l16, !tbaa !24
  %t429 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t423, %"compiler/source:Span" %t424, i64 %t425)
  store ptr %t429, ptr %l228
  br label %bb89
bb88:
  call void @__olang_check_failed(ptr @olang_loc_1fa90a145069ae20_a62c963c9e2d6294)
  unreachable
bb89:
  %t430 = load ptr, ptr %l224, !tbaa !29
  %t431 = load ptr, ptr %l228, !tbaa !29
  %t432 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %t430, ptr %t431)
  store { i64, ptr } %t432, ptr %l229
  br label %bb90
bb90:
  %t433 = icmp sge i64 0, 0
  br i1 %t433, label %bb91, label %bb92
bb91:
  %t435 = icmp sle i64 0, 2305843009213693951
  br i1 %t435, label %bb93, label %bb94
bb92:
  call void @__olang_check_failed(ptr @olang_loc_e5386246bf71864d_e9422de20f0d1fa1)
  unreachable
bb93:
  %t437 = mul i64 0, 4
  %t438 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t437)
  %t439 = insertvalue { i64, ptr } undef, i64 0, 0
  %t440 = insertvalue { i64, ptr } %t439, ptr %t438, 1
  %t441 = load ptr, ptr %l215, !tbaa !29
  %t442 = load %"compiler/source:Span", ptr %l216
  %t443 = load %"compiler/source:Span", ptr %l217
  %t444 = load i64, ptr %l218, !tbaa !24
  %t445 = load ptr, ptr %l220, !tbaa !29
  %t446 = load { i64, ptr }, ptr %l223, !tbaa !27
  %t447 = load { i64, ptr }, ptr %l229, !tbaa !27
  %t449 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %s0, ptr %t441, %"compiler/source:Span" %t442, %"compiler/source:Span" %t443, i64 %t444, ptr %t445, { i64, ptr } %t446, { i64, ptr } %t447, { i64, ptr } %t440)
  store ptr %t449, ptr %l233
  br label %bb95
bb94:
  call void @__olang_check_failed(ptr @olang_loc_e5386246bf71864d_e9422de20f0d1fa1)
  unreachable
bb95:
  %t450 = load ptr, ptr %l233, !tbaa !29
  store ptr %t450, ptr %l18, !tbaa !29
  %t451 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t451, ptr %l234
  %t452 = load ptr, ptr %l18, !tbaa !29
  %t455 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t452)
  store i32 %t455, ptr %l237
  br label %bb96
bb96:
  %t456 = load ptr, ptr %l0, !tbaa !29
  %t458 = getelementptr %"compiler/check:Checker", ptr %t456, i32 0, i32 32
  %t459 = load i64, ptr %l17, !tbaa !24
  %t462 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t458, i64 %t459)
  store { i64, ptr } %t462, ptr %l241
  br label %bb97
bb97:
  %t463 = load ptr, ptr %l18, !tbaa !29
  %t465 = load { i64, ptr }, ptr %l241, !tbaa !27
  %t467 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t465, ptr %t463)
  store %"compiler/typed:Seq" %t467, ptr %l244
  br label %bb98
bb98:
  %t468 = load %"compiler/typed:Seq", ptr %l244
  %t469 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Seq" %t468, ptr %t469
  store { i64, [5 x i64] } zeroinitializer, ptr %t470
  %t471 = getelementptr { i64, [5 x i64] }, ptr %t470, i32 0, i32 0
  store i64 12, ptr %t471
  %t472 = load %"compiler/source:Span", ptr %l234
  %t473 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t472, 0
  %t474 = load i32, ptr %l237, !tbaa !23
  %t475 = insertvalue { %"compiler/source:Span", i32, ptr } %t473, i32 %t474, 1
  %t477 = insertvalue { %"compiler/source:Span", i32, ptr } %t475, ptr %t469, 2
  %t478 = getelementptr { i64, [5 x i64] }, ptr %t470, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t477, ptr %t478
  %t479 = load { i64, [5 x i64] }, ptr %t470
  %t481 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t479, ptr %t481
  call void @__olang_scope_close(ptr %s0)
  store ptr %t481, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emethodCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5, { i64, ptr } %a6, %"compiler/source:Span" %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca i64
  %l11 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l16 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l24 = alloca ptr
  %l27 = alloca i32
  %l35 = alloca ptr
  %l40 = alloca ptr
  %l43 = alloca i32
  %l45 = alloca i64
  %l49 = alloca ptr
  %l52 = alloca i32
  %l54 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l56 = alloca i64
  %l59 = alloca i64
  %l62 = alloca i1
  %l65 = alloca { i64, ptr }
  %l66 = alloca i1
  %l67 = alloca i1
  %l68 = alloca ptr
  %l71 = alloca i32
  %l72 = alloca i1
  %l79 = alloca ptr
  %l82 = alloca i1
  %l85 = alloca ptr
  %l88 = alloca i32
  %l89 = alloca i32
  %l92 = alloca ptr
  %l93 = alloca { i64, ptr }
  %l95 = alloca %"compiler/source:Span"
  %l98 = alloca { i64, ptr }
  %l100 = alloca %"compiler/msgs:Msg"
  %l101 = alloca i64
  %l106 = alloca ptr
  %l111 = alloca { i64, ptr }
  %l119 = alloca ptr
  %l122 = alloca { i64, ptr }
  %l123 = alloca { i64, ptr }
  %l125 = alloca i1
  %l127 = alloca i1
  %l131 = alloca i64
  %l133 = alloca ptr
  %l137 = alloca ptr
  %l138 = alloca %"compiler/source:Span"
  %l141 = alloca { i64, ptr }
  %l143 = alloca %"compiler/msgs:Msg"
  %l144 = alloca i64
  %l145 = alloca ptr
  %l146 = alloca %"compiler/source:Span"
  %l147 = alloca %"compiler/source:Span"
  %l148 = alloca i64
  %l150 = alloca ptr
  %l151 = alloca { i64, ptr }
  %l156 = alloca ptr
  %l159 = alloca { i64, ptr }
  %l162 = alloca ptr
  %l165 = alloca i32
  %l166 = alloca i32
  %l176 = alloca ptr
  %l178 = alloca ptr
  %l181 = alloca i32
  %l183 = alloca i64
  %l187 = alloca ptr
  %l190 = alloca i32
  %l192 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l194 = alloca i64
  %l196 = alloca ptr
  %l197 = alloca %"compiler/source:Span"
  %l198 = alloca ptr
  %l201 = alloca i32
  %l202 = alloca { i64, ptr }
  %l203 = alloca { i64, ptr }
  %l206 = alloca { i64, ptr }
  %l208 = alloca %"compiler/msgs:Msg"
  %l209 = alloca i64
  %l214 = alloca ptr
  %l216 = alloca i64
  %l219 = alloca i64
  %l222 = alloca i1
  %l225 = alloca i1
  %l226 = alloca i1
  %l231 = alloca i1
  %l232 = alloca ptr
  %l234 = alloca %"compiler/source:Span"
  %l235 = alloca ptr
  %l237 = alloca %"compiler/source:Span"
  %l238 = alloca { i64, ptr }
  %l241 = alloca { i64, ptr }
  %l242 = alloca { i64, ptr }
  %l243 = alloca ptr
  %l245 = alloca %"compiler/source:Span"
  %l246 = alloca { i64, ptr }
  %l247 = alloca { i64, ptr }
  %l249 = alloca %"compiler/msgs:Msg"
  %l250 = alloca i64
  %l255 = alloca i32
  %l258 = alloca i1
  %l260 = alloca i1
  %l261 = alloca i1
  %l265 = alloca i1
  %l268 = alloca i32
  %l271 = alloca ptr
  %l272 = alloca %"compiler/source:Span"
  %l274 = alloca i32
  %l277 = alloca ptr
  %l280 = alloca i1
  %l283 = alloca i32
  %l286 = alloca i1
  %l287 = alloca ptr
  %l290 = alloca i32
  %l291 = alloca i1
  %l296 = alloca ptr
  %l299 = alloca i1
  %l301 = alloca i1
  %l303 = alloca i1
  %l304 = alloca ptr
  %l307 = alloca i32
  %l308 = alloca i1
  %l309 = alloca i1
  %l310 = alloca ptr
  %l313 = alloca i32
  %l314 = alloca i1
  %l315 = alloca i1
  %l317 = alloca ptr
  %l320 = alloca i32
  %l321 = alloca i1
  %l323 = alloca i1
  %l324 = alloca ptr
  %l327 = alloca i32
  %l329 = alloca i1
  %l330 = alloca ptr
  %l331 = alloca %"compiler/source:Span"
  %l332 = alloca ptr
  %l335 = alloca i32
  %l336 = alloca { i64, ptr }
  %l337 = alloca { i64, ptr }
  %l340 = alloca { i64, ptr }
  %l342 = alloca %"compiler/msgs:Msg"
  %l343 = alloca i64
  %l348 = alloca ptr
  %l358 = alloca ptr
  %l365 = alloca i32
  %l368 = alloca i1
  %l369 = alloca i1
  %l373 = alloca i64
  %l376 = alloca ptr
  %l380 = alloca %"compiler/source:Span"
  %l381 = alloca i32
  %l382 = alloca ptr
  %l383 = alloca ptr
  %l384 = alloca i32
  %l386 = alloca %"compiler/source:Span"
  %l387 = alloca i32
  %l390 = alloca ptr
  %l391 = alloca %"compiler/source:Span"
  %l392 = alloca %"compiler/source:Span"
  %l397 = alloca ptr
  %l401 = alloca ptr
  %l402 = alloca %"compiler/source:Span"
  %l403 = alloca %"compiler/source:Span"
  %l407 = alloca ptr
  %l409 = alloca ptr
  %l412 = alloca i1
  %l413 = alloca i1
  %l416 = alloca i32
  %l423 = alloca ptr
  %l425 = alloca i1
  %l426 = alloca i1
  %l428 = alloca i1
  %l431 = alloca ptr
  %l432 = alloca %"compiler/source:Span"
  %l435 = alloca { i64, ptr }
  %l436 = alloca { i64, ptr }
  %l439 = alloca { i64, ptr }
  %l441 = alloca %"compiler/msgs:Msg"
  %l442 = alloca i64
  %l447 = alloca ptr
  %l448 = alloca { i64, ptr }
  %l450 = alloca i1
  %l452 = alloca i1
  %l456 = alloca i64
  %l458 = alloca ptr
  %l462 = alloca ptr
  %l463 = alloca %"compiler/source:Span"
  %l466 = alloca { i64, ptr }
  %l468 = alloca %"compiler/msgs:Msg"
  %l469 = alloca i64
  %l470 = alloca ptr
  %l471 = alloca %"compiler/source:Span"
  %l472 = alloca %"compiler/source:Span"
  %l473 = alloca i64
  %l475 = alloca ptr
  %l476 = alloca { i64, ptr }
  %l479 = alloca { i64, ptr }
  %l483 = alloca ptr
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %rv = alloca ptr
  %t757 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  store { i64, ptr } %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t4 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t8 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t1, ptr %t2, i32 %t4)
  store ptr %t8, ptr %l24
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l24, !tbaa !29
  store ptr %t9, ptr %l8, !tbaa !29
  %t10 = load ptr, ptr %l8, !tbaa !29
  %t13 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t10)
  store i32 %t13, ptr %l27
  br label %bb2
bb2:
  %t14 = load i32, ptr %l27, !tbaa !23
  store i32 %t14, ptr %l9, !tbaa !23
  %t15 = load i32, ptr %l9, !tbaa !23
  %t16 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t19 = icmp eq i32 %t15, %t16
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t21, { i64, ptr } %t22)
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load %"compiler/source:Span", ptr %l1
  %t29 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t25, %"compiler/source:Span" %t26)
  store ptr %t29, ptr %l35
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t30 = load ptr, ptr %l35, !tbaa !29
  store ptr %t30, ptr %rv
  br label %ret
bb7:
  %t31 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t35 = icmp sgt i64 %t33, 0
  br i1 %t35, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  store ptr %t40, ptr %l40, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i32, ptr %l9, !tbaa !23
  %t45 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t41, i32 %t42)
  store i32 %t45, ptr %l43
  br label %bb10
bb9:
  br label %bb74
bb10:
  %t46 = load i32, ptr %l3, !tbaa !23
  %t47 = load ptr, ptr %l40, !tbaa !29
  %t48 = load i32, ptr %l43, !tbaa !23
  %t50 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t47, i32 %t48, i32 %t46)
  store i64 %t50, ptr %l45
  br label %bb11
bb11:
  %t51 = load i64, ptr %l45, !tbaa !24
  store i64 %t51, ptr %l10, !tbaa !24
  %t52 = load i64, ptr %l10, !tbaa !24
  %t54 = icmp slt i64 %t52, 0
  br i1 %t54, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  store ptr %t59, ptr %l49, !tbaa !29
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load i32, ptr %l9, !tbaa !23
  %t64 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t60, i32 %t61)
  store i32 %t64, ptr %l52
  br label %bb14
bb13:
  br label %bb21
bb14:
  %t65 = load i32, ptr %l3, !tbaa !23
  %t66 = load ptr, ptr %l49, !tbaa !29
  %t67 = load i32, ptr %l52, !tbaa !23
  %t69 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultMethods(ptr %v0, ptr %s3, ptr %t66, i32 %t67, i32 %t65)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t69, ptr %l54
  br label %bb15
bb15:
  %t70 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l54
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t70, ptr %l11
  %t72 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %s3, ptr %l11)
  store i64 %t72, ptr %l56
  br label %bb16
bb16:
  %t73 = load i64, ptr %l56, !tbaa !24
  %t74 = icmp eq i64 %t73, 1
  br i1 %t74, label %bb17, label %bb18
bb17:
  %t77 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s3, ptr %l11, i64 0)
  store i64 %t77, ptr %l59
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t78 = load i64, ptr %l59, !tbaa !24
  store i64 %t78, ptr %l10, !tbaa !24
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb21:
  %t79 = load i64, ptr %l10, !tbaa !24
  %t81 = icmp slt i64 %t79, 0
  br i1 %t81, label %bb22, label %bb23
bb22:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load i32, ptr %l3, !tbaa !23
  %t87 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t83, i32 %t84)
  store { i64, ptr } %t87, ptr %l65
  br label %bb24
bb23:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb26
bb24:
  %t88 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t89 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t88, { i64, ptr } { i64 6, ptr @.d15 })
  store i1 %t89, ptr %l66
  br label %bb25
bb25:
  %t90 = load i1, ptr %l66, !tbaa !21
  store i1 %t90, ptr %l62, !tbaa !21
  br label %bb26
bb26:
  %t91 = load i1, ptr %l62, !tbaa !21
  br i1 %t91, label %bb27, label %bb28
bb27:
  %t92 = load ptr, ptr %l0, !tbaa !29
  store ptr %t92, ptr %l68, !tbaa !29
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load i32, ptr %l9, !tbaa !23
  %t97 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t93, i32 %t94)
  store i32 %t97, ptr %l71
  br label %bb29
bb28:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb31
bb29:
  %t98 = load ptr, ptr %l68, !tbaa !29
  %t99 = load i32, ptr %l71, !tbaa !23
  %t100 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t98, i32 %t99)
  store i1 %t100, ptr %l72
  br label %bb30
bb30:
  %t101 = load i1, ptr %l72, !tbaa !21
  store i1 %t101, ptr %l67, !tbaa !21
  br label %bb31
bb31:
  %t102 = load i1, ptr %l67, !tbaa !21
  br i1 %t102, label %bb32, label %bb33
bb32:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load %"compiler/source:Span", ptr %l1
  %t105 = load %"compiler/source:Span", ptr %l4
  %t106 = load ptr, ptr %l8, !tbaa !29
  %t107 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t108 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t115 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowCall(ptr %v0, ptr %v3, ptr %v2, ptr %t103, %"compiler/source:Span" %t104, %"compiler/source:Span" %t105, ptr %t106, { i64, ptr } %t107, { i64, ptr } %t108)
  store ptr %t115, ptr %l79
  br label %bb34
bb33:
  br label %bb35
bb34:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t116 = load ptr, ptr %l79, !tbaa !29
  store ptr %t116, ptr %rv
  br label %ret
bb35:
  %t117 = load i64, ptr %l10, !tbaa !24
  %t119 = icmp slt i64 %t117, 0
  br i1 %t119, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l82, !tbaa !21
  br label %bb40
bb37:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/check:Checker", ptr %t121, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t126 = getelementptr %"compiler/generic:Program", ptr %t124, i32 0, i32 2
  store ptr %t126, ptr %l85, !tbaa !29
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load i32, ptr %l9, !tbaa !23
  %t131 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t127, i32 %t128)
  store i32 %t131, ptr %l88
  br label %bb38
bb38:
  %t132 = load ptr, ptr %l85, !tbaa !29
  %t133 = load i32, ptr %l88, !tbaa !23
  %t134 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t132, i32 %t133)
  store i32 %t134, ptr %l89
  br label %bb39
bb39:
  %t135 = load i32, ptr %l89
  %t137 = trunc i64 29 to i32
  %t138 = icmp eq i32 %t135, %t137
  store i1 %t138, ptr %l82, !tbaa !21
  br label %bb40
bb40:
  %t140 = load i1, ptr %l82, !tbaa !21
  br i1 %t140, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s6
  %t141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t141, ptr %l92, !tbaa !29
  %t142 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t142, ptr %l93, !tbaa !27
  %t143 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !27
  %t145 = getelementptr ptr, ptr %t144, i64 0
  %t146 = load ptr, ptr %t145, !tbaa !39
  %t148 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v3, ptr %t146)
  store %"compiler/source:Span" %t148, ptr %l95
  br label %bb43
bb42:
  br label %bb49
bb43:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load i32, ptr %l3, !tbaa !23
  %t153 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s6, ptr %t149, i32 %t150)
  store { i64, ptr } %t153, ptr %l98
  br label %bb44
bb44:
  %t154 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t154, 0
  %t156 = extractvalue { i64, ptr } %t154, 1
  %t157 = mul i64 %t155, 1
  %t158 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t157)
  call void @llvm.memcpy.p0.p0.i64(ptr %t158, ptr %t156, i64 %t157, i1 false)
  %t159 = insertvalue { i64, ptr } undef, i64 %t155, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t158, 1
  %t162 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgsOnNonGeneric(ptr %s6, ptr %s6, { i64, ptr } %t160)
  store %"compiler/msgs:Msg" %t162, ptr %l100
  br label %bb45
bb45:
  %t163 = load ptr, ptr %l92, !tbaa !29
  %t164 = load %"compiler/source:Span", ptr %l95
  %t165 = load %"compiler/msgs:Msg", ptr %l100
  %t166 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s6, ptr %t163, %"compiler/source:Span" %t164, %"compiler/msgs:Msg" %t165)
  store i64 %t166, ptr %l101
  br label %bb46
bb46:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t167, { i64, ptr } %t168)
  br label %bb47
bb47:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load %"compiler/source:Span", ptr %l1
  %t175 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t171, %"compiler/source:Span" %t172)
  store ptr %t175, ptr %l106
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t176 = load ptr, ptr %l106, !tbaa !29
  store ptr %t176, ptr %rv
  br label %ret
bb49:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load i64, ptr %l10, !tbaa !24
  %t179 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t185 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexplicitArgs(ptr %v0, ptr %v3, ptr %t177, i64 %t178, { i64, ptr } %t179, %"compiler/source:Span" %a7)
  store { i64, ptr } %t185, ptr %l111
  br label %bb50
bb50:
  %t186 = load { i64, ptr }, ptr %l111, !tbaa !27
  store { i64, ptr } %t186, ptr %l12, !tbaa !27
  %t187 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t187, 0
  %t191 = icmp eq i64 %t189, 0
  br i1 %t191, label %bb51, label %bb52
bb51:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t193, { i64, ptr } %t194)
  br label %bb53
bb52:
  br label %bb55
bb53:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t198 = load %"compiler/source:Span", ptr %l1
  %t201 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t197, %"compiler/source:Span" %t198)
  store ptr %t201, ptr %l119
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t202 = load ptr, ptr %l119, !tbaa !29
  store ptr %t202, ptr %rv
  br label %ret
bb55:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load i32, ptr %l3, !tbaa !23
  %t207 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t203, i32 %t204)
  store { i64, ptr } %t207, ptr %l122
  br label %bb56
bb56:
  %t208 = load { i64, ptr }, ptr %l122, !tbaa !27
  store { i64, ptr } %t208, ptr %l123, !tbaa !27
  %t209 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t210 = load ptr, ptr %t209, !tbaa !27
  %t211 = getelementptr i8, ptr %t210, i64 0
  %t212 = load i8, ptr %t211, !tbaa !32
  %t214 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t212)
  store i1 %t214, ptr %l125
  br label %bb57
bb57:
  %t215 = load i1, ptr %l125, !tbaa !21
  %t216 = xor i1 %t215, true
  br i1 %t216, label %bb58, label %bb59
bb58:
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t220 = getelementptr %"compiler/check:Checker", ptr %t218, i32 0, i32 1
  %t221 = load ptr, ptr %t220, !tbaa !29
  %t222 = load i64, ptr %l10, !tbaa !24
  %t225 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t221, i64 %t222)
  store i64 %t225, ptr %l131
  br label %bb60
bb59:
  store i1 false, ptr %l127, !tbaa !21
  br label %bb62
bb60:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t226)
  store ptr %t228, ptr %l133
  br label %bb61
bb61:
  %t229 = load ptr, ptr %l133, !tbaa !29
  %t231 = getelementptr %"compiler/check:frame", ptr %t229, i32 0, i32 1
  %t232 = load i64, ptr %t231, !tbaa !24
  %t233 = load i64, ptr %l131, !tbaa !24
  %t235 = icmp ne i64 %t233, %t232
  store i1 %t235, ptr %l127, !tbaa !21
  br label %bb62
bb62:
  %t237 = load i1, ptr %l127, !tbaa !21
  br i1 %t237, label %bb63, label %bb64
bb63:
  store %olang.scope zeroinitializer, ptr %s8
  %t238 = load ptr, ptr %l0, !tbaa !29
  store ptr %t238, ptr %l137, !tbaa !29
  %t239 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t239, ptr %l138
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t241 = load i32, ptr %l3, !tbaa !23
  %t244 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s8, ptr %t240, i32 %t241)
  store { i64, ptr } %t244, ptr %l141
  br label %bb65
bb64:
  br label %bb68
bb65:
  %t245 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t246 = extractvalue { i64, ptr } %t245, 0
  %t247 = extractvalue { i64, ptr } %t245, 1
  %t248 = mul i64 %t246, 1
  %t249 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t248)
  call void @llvm.memcpy.p0.p0.i64(ptr %t249, ptr %t247, i64 %t248, i1 false)
  %t250 = insertvalue { i64, ptr } undef, i64 %t246, 0
  %t251 = insertvalue { i64, ptr } %t250, ptr %t249, 1
  %t253 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodIsPrivate(ptr %s8, ptr %s8, { i64, ptr } %t251)
  store %"compiler/msgs:Msg" %t253, ptr %l143
  br label %bb66
bb66:
  %t254 = load ptr, ptr %l137, !tbaa !29
  %t255 = load %"compiler/source:Span", ptr %l138
  %t256 = load %"compiler/msgs:Msg", ptr %l143
  %t257 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s8, ptr %t254, %"compiler/source:Span" %t255, %"compiler/msgs:Msg" %t256)
  store i64 %t257, ptr %l144
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s8)
  br label %bb68
bb68:
  %t258 = load ptr, ptr %l0, !tbaa !29
  store ptr %t258, ptr %l145, !tbaa !29
  %t259 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t259, ptr %l146
  %t260 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t260, ptr %l147
  %t261 = load i64, ptr %l10, !tbaa !24
  store i64 %t261, ptr %l148, !tbaa !24
  %t262 = load ptr, ptr %l8, !tbaa !29
  store ptr %t262, ptr %l150, !tbaa !29
  %t264 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t264, ptr %l151, !tbaa !27
  %t265 = icmp sge i64 0, 0
  br i1 %t265, label %bb69, label %bb70
bb69:
  %t267 = icmp sle i64 0, 1152921504606846975
  br i1 %t267, label %bb71, label %bb72
bb70:
  call void @__olang_check_failed(ptr @olang_loc_d23330c3ef7ea91b_34477ea00961dc87)
  unreachable
bb71:
  %t269 = mul i64 0, 8
  %t270 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t269)
  %t271 = insertvalue { i64, ptr } undef, i64 0, 0
  %t272 = insertvalue { i64, ptr } %t271, ptr %t270, 1
  %t273 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t274 = load ptr, ptr %l145, !tbaa !29
  %t275 = load %"compiler/source:Span", ptr %l146
  %t276 = load %"compiler/source:Span", ptr %l147
  %t277 = load i64, ptr %l148, !tbaa !24
  %t278 = load ptr, ptr %l150, !tbaa !29
  %t279 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t282 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v2, ptr %v0, ptr %t274, %"compiler/source:Span" %t275, %"compiler/source:Span" %t276, i64 %t277, ptr %t278, { i64, ptr } %t279, { i64, ptr } %t272, { i64, ptr } %t273)
  store ptr %t282, ptr %l156
  br label %bb73
bb72:
  call void @__olang_check_failed(ptr @olang_loc_d23330c3ef7ea91b_34477ea00961dc87)
  unreachable
bb73:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t283 = load ptr, ptr %l156, !tbaa !29
  store ptr %t283, ptr %rv
  br label %ret
bb74:
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t285 = load i32, ptr %l3, !tbaa !23
  %t288 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t284, i32 %t285)
  store { i64, ptr } %t288, ptr %l159
  br label %bb75
bb75:
  %t289 = load { i64, ptr }, ptr %l159, !tbaa !27
  store { i64, ptr } %t289, ptr %l13, !tbaa !27
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t292 = getelementptr %"compiler/check:Checker", ptr %t290, i32 0, i32 1
  %t293 = load ptr, ptr %t292, !tbaa !29
  %t295 = getelementptr %"compiler/generic:Program", ptr %t293, i32 0, i32 2
  store ptr %t295, ptr %l162, !tbaa !29
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t297 = load i32, ptr %l9, !tbaa !23
  %t300 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t296, i32 %t297)
  store i32 %t300, ptr %l165
  br label %bb76
bb76:
  %t301 = load ptr, ptr %l162, !tbaa !29
  %t302 = load i32, ptr %l165, !tbaa !23
  %t303 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t301, i32 %t302)
  store i32 %t303, ptr %l166
  br label %bb77
bb77:
  %t304 = load i32, ptr %l166
  %t306 = trunc i64 29 to i32
  %t307 = icmp eq i32 %t304, %t306
  br i1 %t307, label %bb78, label %bb79
bb78:
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t310 = load %"compiler/source:Span", ptr %l1
  %t311 = load ptr, ptr %l2, !tbaa !29
  %t312 = load ptr, ptr %l8, !tbaa !29
  %t313 = load i32, ptr %l3, !tbaa !23
  %t314 = load %"compiler/source:Span", ptr %l4
  %t315 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t323 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyCall(ptr %v0, ptr %v1, ptr %v2, ptr %t309, %"compiler/source:Span" %t310, ptr %t311, ptr %t312, i32 %t313, %"compiler/source:Span" %t314, { i64, ptr } %t315)
  store ptr %t323, ptr %l176
  br label %bb80
bb79:
  br label %bb81
bb80:
  call void @__olang_scope_close(ptr %s0)
  %t324 = load ptr, ptr %l176, !tbaa !29
  store ptr %t324, ptr %rv
  br label %ret
bb81:
  %t325 = load ptr, ptr %l0, !tbaa !29
  %t327 = getelementptr %"compiler/check:Checker", ptr %t325, i32 0, i32 1
  %t328 = load ptr, ptr %t327, !tbaa !29
  store ptr %t328, ptr %l178, !tbaa !29
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t330 = load i32, ptr %l9, !tbaa !23
  %t333 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t329, i32 %t330)
  store i32 %t333, ptr %l181
  br label %bb82
bb82:
  %t334 = load i32, ptr %l3, !tbaa !23
  %t335 = load ptr, ptr %l178, !tbaa !29
  %t336 = load i32, ptr %l181, !tbaa !23
  %t338 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t335, i32 %t336, i32 %t334)
  store i64 %t338, ptr %l183
  br label %bb83
bb83:
  %t339 = load i64, ptr %l183, !tbaa !24
  store i64 %t339, ptr %l14, !tbaa !24
  %t340 = load i64, ptr %l14, !tbaa !24
  %t342 = icmp slt i64 %t340, 0
  br i1 %t342, label %bb84, label %bb85
bb84:
  store %olang.scope zeroinitializer, ptr %s10
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t346 = getelementptr %"compiler/check:Checker", ptr %t344, i32 0, i32 1
  %t347 = load ptr, ptr %t346, !tbaa !29
  store ptr %t347, ptr %l187, !tbaa !29
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t349 = load i32, ptr %l9, !tbaa !23
  %t352 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t348, i32 %t349)
  store i32 %t352, ptr %l190
  br label %bb86
bb85:
  br label %bb104
bb86:
  %t353 = load i32, ptr %l3, !tbaa !23
  %t354 = load ptr, ptr %l187, !tbaa !29
  %t355 = load i32, ptr %l190, !tbaa !23
  %t357 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultMethods(ptr %v0, ptr %s10, ptr %t354, i32 %t355, i32 %t353)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t357, ptr %l192
  br label %bb87
bb87:
  %t358 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l192
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t358, ptr %l15
  %t360 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %s10, ptr %l15)
  store i64 %t360, ptr %l194
  br label %bb88
bb88:
  %t361 = load i64, ptr %l194, !tbaa !24
  %t362 = icmp sgt i64 %t361, 1
  br i1 %t362, label %bb89, label %bb90
bb89:
  store %olang.scope zeroinitializer, ptr %s11
  %t364 = load ptr, ptr %l0, !tbaa !29
  store ptr %t364, ptr %l196, !tbaa !29
  %t365 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t365, ptr %l197
  %t366 = load ptr, ptr %l0, !tbaa !29
  store ptr %t366, ptr %l198, !tbaa !29
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t368 = load i32, ptr %l9, !tbaa !23
  %t371 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t367, i32 %t368)
  store i32 %t371, ptr %l201
  br label %bb91
bb90:
  br label %bb98
bb91:
  %t372 = load ptr, ptr %l198, !tbaa !29
  %t373 = load i32, ptr %l201, !tbaa !23
  %t374 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s11, ptr %t372, i32 %t373)
  store { i64, ptr } %t374, ptr %l202
  br label %bb92
bb92:
  %t375 = load { i64, ptr }, ptr %l202, !tbaa !27
  %t376 = extractvalue { i64, ptr } %t375, 0
  %t377 = extractvalue { i64, ptr } %t375, 1
  %t378 = mul i64 %t376, 1
  %t379 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t378)
  call void @llvm.memcpy.p0.p0.i64(ptr %t379, ptr %t377, i64 %t378, i1 false)
  %t380 = insertvalue { i64, ptr } undef, i64 %t376, 0
  %t381 = insertvalue { i64, ptr } %t380, ptr %t379, 1
  store { i64, ptr } %t381, ptr %l203, !tbaa !27
  %t382 = load ptr, ptr %l0, !tbaa !29
  %t383 = load i32, ptr %l3, !tbaa !23
  %t386 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s11, ptr %t382, i32 %t383)
  store { i64, ptr } %t386, ptr %l206
  br label %bb93
bb93:
  %t387 = load { i64, ptr }, ptr %l206, !tbaa !27
  %t388 = extractvalue { i64, ptr } %t387, 0
  %t389 = extractvalue { i64, ptr } %t387, 1
  %t390 = mul i64 %t388, 1
  %t391 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t390)
  call void @llvm.memcpy.p0.p0.i64(ptr %t391, ptr %t389, i64 %t390, i1 false)
  %t392 = insertvalue { i64, ptr } undef, i64 %t388, 0
  %t393 = insertvalue { i64, ptr } %t392, ptr %t391, 1
  %t394 = load { i64, ptr }, ptr %l203, !tbaa !27
  %t396 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultAmbiguous(ptr %s11, ptr %s11, ptr %s11, { i64, ptr } %t394, { i64, ptr } %t393)
  store %"compiler/msgs:Msg" %t396, ptr %l208
  br label %bb94
bb94:
  %t397 = load ptr, ptr %l196, !tbaa !29
  %t398 = load %"compiler/source:Span", ptr %l197
  %t399 = load %"compiler/msgs:Msg", ptr %l208
  %t400 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s11, ptr %t397, %"compiler/source:Span" %t398, %"compiler/msgs:Msg" %t399)
  store i64 %t400, ptr %l209
  br label %bb95
bb95:
  %t401 = load ptr, ptr %l0, !tbaa !29
  %t402 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t401, { i64, ptr } %t402)
  br label %bb96
bb96:
  %t405 = load ptr, ptr %l0, !tbaa !29
  %t406 = load %"compiler/source:Span", ptr %l1
  %t409 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t405, %"compiler/source:Span" %t406)
  store ptr %t409, ptr %l214
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t410 = load ptr, ptr %l214, !tbaa !29
  store ptr %t410, ptr %rv
  br label %ret
bb98:
  %t412 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %s10, ptr %l15)
  store i64 %t412, ptr %l216
  br label %bb99
bb99:
  %t413 = load i64, ptr %l216, !tbaa !24
  %t414 = icmp eq i64 %t413, 1
  br i1 %t414, label %bb100, label %bb101
bb100:
  %t417 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s10, ptr %l15, i64 0)
  store i64 %t417, ptr %l219
  br label %bb102
bb101:
  br label %bb103
bb102:
  %t418 = load i64, ptr %l219, !tbaa !24
  store i64 %t418, ptr %l14, !tbaa !24
  br label %bb103
bb103:
  call void @__olang_scope_close(ptr %s10)
  br label %bb104
bb104:
  %t419 = load i64, ptr %l14, !tbaa !24
  %t421 = icmp slt i64 %t419, 0
  br i1 %t421, label %bb105, label %bb106
bb105:
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t424 = load i32, ptr %l9, !tbaa !23
  %t427 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t423, i32 %t424)
  store i1 %t427, ptr %l225
  br label %bb107
bb106:
  store i1 false, ptr %l222, !tbaa !21
  br label %bb108
bb107:
  %t428 = load i1, ptr %l225, !tbaa !21
  store i1 %t428, ptr %l222, !tbaa !21
  br label %bb108
bb108:
  %t429 = load i1, ptr %l222, !tbaa !21
  br i1 %t429, label %bb109, label %bb110
bb109:
  %t430 = load ptr, ptr %l0, !tbaa !29
  %t432 = getelementptr %"compiler/check:Checker", ptr %t430, i32 0, i32 1
  %t433 = load ptr, ptr %t432, !tbaa !29
  %t435 = getelementptr %"compiler/generic:Program", ptr %t433, i32 0, i32 2
  %t436 = load i32, ptr %l9, !tbaa !23
  %t439 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t435, i32 %t436)
  store i1 %t439, ptr %l231
  br label %bb111
bb110:
  store i1 false, ptr %l226, !tbaa !21
  br label %bb112
bb111:
  %t440 = load i1, ptr %l231, !tbaa !21
  store i1 %t440, ptr %l226, !tbaa !21
  br label %bb112
bb112:
  %t441 = load i1, ptr %l226, !tbaa !21
  br i1 %t441, label %bb113, label %bb114
bb113:
  store %olang.scope zeroinitializer, ptr %s13
  %t442 = load ptr, ptr %l0, !tbaa !29
  store ptr %t442, ptr %l232, !tbaa !29
  %t443 = load ptr, ptr %l2, !tbaa !29
  %t445 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t443)
  store %"compiler/source:Span" %t445, ptr %l234
  br label %bb115
bb114:
  br label %bb125
bb115:
  %t446 = load ptr, ptr %l0, !tbaa !29
  store ptr %t446, ptr %l235, !tbaa !29
  %t447 = load ptr, ptr %l2, !tbaa !29
  %t449 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t447)
  store %"compiler/source:Span" %t449, ptr %l237
  br label %bb116
bb116:
  %t450 = load ptr, ptr %l235, !tbaa !29
  %t451 = load %"compiler/source:Span", ptr %l237
  %t452 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t450, %"compiler/source:Span" %t451)
  store { i64, ptr } %t452, ptr %l238
  br label %bb117
bb117:
  %t453 = load ptr, ptr %l0, !tbaa !29
  %t454 = load i32, ptr %l9, !tbaa !23
  %t457 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s13, ptr %t453, i32 %t454)
  store { i64, ptr } %t457, ptr %l241
  br label %bb118
bb118:
  %t458 = load { i64, ptr }, ptr %l241, !tbaa !27
  %t459 = extractvalue { i64, ptr } %t458, 0
  %t460 = extractvalue { i64, ptr } %t458, 1
  %t461 = mul i64 %t459, 1
  %t462 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t461)
  call void @llvm.memcpy.p0.p0.i64(ptr %t462, ptr %t460, i64 %t461, i1 false)
  %t463 = insertvalue { i64, ptr } undef, i64 %t459, 0
  %t464 = insertvalue { i64, ptr } %t463, ptr %t462, 1
  store { i64, ptr } %t464, ptr %l242, !tbaa !27
  %t465 = load ptr, ptr %l0, !tbaa !29
  store ptr %t465, ptr %l243, !tbaa !29
  %t466 = load ptr, ptr %l2, !tbaa !29
  %t468 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t466)
  store %"compiler/source:Span" %t468, ptr %l245
  br label %bb119
bb119:
  %t469 = load ptr, ptr %l243, !tbaa !29
  %t470 = load %"compiler/source:Span", ptr %l245
  %t471 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t469, %"compiler/source:Span" %t470)
  store { i64, ptr } %t471, ptr %l246
  br label %bb120
bb120:
  %t472 = load { i64, ptr }, ptr %l246, !tbaa !27
  %t473 = call { i64, ptr } @compiler_2fcheck_2ebangOf(ptr %v0, ptr %s13, { i64, ptr } %t472)
  store { i64, ptr } %t473, ptr %l247
  br label %bb121
bb121:
  %t474 = load { i64, ptr }, ptr %l247, !tbaa !27
  %t475 = extractvalue { i64, ptr } %t474, 0
  %t476 = extractvalue { i64, ptr } %t474, 1
  %t477 = mul i64 %t475, 1
  %t478 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t477)
  call void @llvm.memcpy.p0.p0.i64(ptr %t478, ptr %t476, i64 %t477, i1 false)
  %t479 = insertvalue { i64, ptr } undef, i64 %t475, 0
  %t480 = insertvalue { i64, ptr } %t479, ptr %t478, 1
  %t481 = load { i64, ptr }, ptr %l238, !tbaa !27
  %t482 = load { i64, ptr }, ptr %l242, !tbaa !27
  %t484 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadMaybeNull(ptr %v0, ptr %s13, ptr %s13, ptr %s13, { i64, ptr } %t481, { i64, ptr } %t482, { i64, ptr } %t480)
  store %"compiler/msgs:Msg" %t484, ptr %l249
  br label %bb122
bb122:
  %t485 = load ptr, ptr %l232, !tbaa !29
  %t486 = load %"compiler/source:Span", ptr %l234
  %t487 = load %"compiler/msgs:Msg", ptr %l249
  %t488 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s13, ptr %t485, %"compiler/source:Span" %t486, %"compiler/msgs:Msg" %t487)
  store i64 %t488, ptr %l250
  br label %bb123
bb123:
  %t489 = load ptr, ptr %l0, !tbaa !29
  %t491 = getelementptr %"compiler/check:Checker", ptr %t489, i32 0, i32 1
  %t492 = load ptr, ptr %t491, !tbaa !29
  %t494 = getelementptr %"compiler/generic:Program", ptr %t492, i32 0, i32 2
  %t495 = load i32, ptr %l9, !tbaa !23
  %t498 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNonNull(ptr %v0, ptr %t494, i32 %t495)
  store i32 %t498, ptr %l255
  br label %bb124
bb124:
  %t499 = load i32, ptr %l255, !tbaa !23
  store i32 %t499, ptr %l9, !tbaa !23
  call void @__olang_scope_close(ptr %s13)
  br label %bb125
bb125:
  %t500 = load i64, ptr %l14, !tbaa !24
  %t502 = icmp slt i64 %t500, 0
  br i1 %t502, label %bb126, label %bb127
bb126:
  %t504 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t506 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t504, { i64, ptr } { i64 3, ptr @.d16 })
  store i1 %t506, ptr %l260
  br label %bb128
bb127:
  store i1 false, ptr %l258, !tbaa !21
  br label %bb129
bb128:
  %t507 = load i1, ptr %l260, !tbaa !21
  store i1 %t507, ptr %l258, !tbaa !21
  br label %bb129
bb129:
  %t508 = load i1, ptr %l258, !tbaa !21
  br i1 %t508, label %bb130, label %bb131
bb130:
  %t509 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t511 = extractvalue { i64, ptr } %t509, 0
  %t513 = icmp eq i64 %t511, 0
  store i1 %t513, ptr %l261, !tbaa !21
  br label %bb132
bb131:
  store i1 false, ptr %l261, !tbaa !21
  br label %bb132
bb132:
  %t515 = load i1, ptr %l261, !tbaa !21
  br i1 %t515, label %bb133, label %bb134
bb133:
  %t516 = load ptr, ptr %l0, !tbaa !29
  %t517 = load i32, ptr %l9, !tbaa !23
  %t520 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t516, i32 %t517)
  store i32 %t520, ptr %l268
  br label %bb135
bb134:
  store i1 false, ptr %l265, !tbaa !21
  br label %bb136
bb135:
  %t521 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t522 = load i32, ptr %l268, !tbaa !23
  %t524 = icmp ne i32 %t522, %t521
  store i1 %t524, ptr %l265, !tbaa !21
  br label %bb136
bb136:
  %t526 = load i1, ptr %l265, !tbaa !21
  br i1 %t526, label %bb137, label %bb138
bb137:
  %t527 = load ptr, ptr %l0, !tbaa !29
  store ptr %t527, ptr %l271, !tbaa !29
  %t528 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t528, ptr %l272
  %t529 = load ptr, ptr %l0, !tbaa !29
  %t531 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t529)
  store i32 %t531, ptr %l274
  br label %bb139
bb138:
  br label %bb141
bb139:
  %t532 = load ptr, ptr %l8, !tbaa !29
  %t533 = load ptr, ptr %l271, !tbaa !29
  %t534 = load %"compiler/source:Span", ptr %l272
  %t535 = load i32, ptr %l274, !tbaa !23
  %t538 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t533, %"compiler/source:Span" %t534, i32 %t535, i32 22, ptr %t532, ptr null)
  store ptr %t538, ptr %l277
  br label %bb140
bb140:
  call void @__olang_scope_close(ptr %s0)
  %t539 = load ptr, ptr %l277, !tbaa !29
  store ptr %t539, ptr %rv
  br label %ret
bb141:
  %t540 = load i64, ptr %l14, !tbaa !24
  %t542 = icmp slt i64 %t540, 0
  br i1 %t542, label %bb142, label %bb143
bb142:
  %t544 = load ptr, ptr %l0, !tbaa !29
  %t545 = load i32, ptr %l9, !tbaa !23
  %t548 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t544, i32 %t545)
  store i32 %t548, ptr %l283
  br label %bb144
bb143:
  store i1 false, ptr %l280, !tbaa !21
  br label %bb150
bb144:
  %t549 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t550 = load i32, ptr %l283, !tbaa !23
  %t552 = icmp eq i32 %t550, %t549
  br i1 %t552, label %bb145, label %bb146
bb145:
  store i1 true, ptr %l286, !tbaa !21
  br label %bb149
bb146:
  %t554 = load ptr, ptr %l0, !tbaa !29
  store ptr %t554, ptr %l287, !tbaa !29
  %t555 = load ptr, ptr %l0, !tbaa !29
  %t556 = load i32, ptr %l9, !tbaa !23
  %t559 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t555, i32 %t556)
  store i32 %t559, ptr %l290
  br label %bb147
bb147:
  %t560 = load ptr, ptr %l287, !tbaa !29
  %t561 = load i32, ptr %l290, !tbaa !23
  %t562 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebadOver(ptr %v0, ptr %t560, i32 %t561)
  store i1 %t562, ptr %l291
  br label %bb148
bb148:
  %t563 = load i1, ptr %l291, !tbaa !21
  store i1 %t563, ptr %l286, !tbaa !21
  br label %bb149
bb149:
  %t564 = load i1, ptr %l286, !tbaa !21
  store i1 %t564, ptr %l280, !tbaa !21
  br label %bb150
bb150:
  %t565 = load i1, ptr %l280, !tbaa !21
  br i1 %t565, label %bb151, label %bb152
bb151:
  %t566 = load ptr, ptr %l0, !tbaa !29
  %t567 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t566, { i64, ptr } %t567)
  br label %bb153
bb152:
  br label %bb155
bb153:
  %t570 = load ptr, ptr %l0, !tbaa !29
  %t571 = load %"compiler/source:Span", ptr %l1
  %t574 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t570, %"compiler/source:Span" %t571)
  store ptr %t574, ptr %l296
  br label %bb154
bb154:
  call void @__olang_scope_close(ptr %s0)
  %t575 = load ptr, ptr %l296, !tbaa !29
  store ptr %t575, ptr %rv
  br label %ret
bb155:
  %t576 = load i64, ptr %l14, !tbaa !24
  %t578 = icmp slt i64 %t576, 0
  br i1 %t578, label %bb156, label %bb157
bb156:
  %t580 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t582 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t580, { i64, ptr } { i64 3, ptr @.d17 })
  store i1 %t582, ptr %l301
  br label %bb158
bb157:
  store i1 false, ptr %l299, !tbaa !21
  br label %bb159
bb158:
  %t583 = load i1, ptr %l301, !tbaa !21
  %t584 = xor i1 %t583, true
  store i1 %t584, ptr %l299, !tbaa !21
  br label %bb159
bb159:
  %t586 = load i1, ptr %l299, !tbaa !21
  br i1 %t586, label %bb160, label %bb161
bb160:
  %t587 = load ptr, ptr %l0, !tbaa !29
  store ptr %t587, ptr %l304, !tbaa !29
  %t588 = load ptr, ptr %l0, !tbaa !29
  %t589 = load i32, ptr %l9, !tbaa !23
  %t592 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t588, i32 %t589)
  store i32 %t592, ptr %l307
  br label %bb162
bb161:
  store i1 false, ptr %l303, !tbaa !21
  br label %bb164
bb162:
  %t593 = load ptr, ptr %l304, !tbaa !29
  %t594 = load i32, ptr %l307, !tbaa !23
  %t595 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t593, i32 %t594)
  store i1 %t595, ptr %l308
  br label %bb163
bb163:
  %t596 = load i1, ptr %l308, !tbaa !21
  store i1 %t596, ptr %l303, !tbaa !21
  br label %bb164
bb164:
  %t597 = load i1, ptr %l303, !tbaa !21
  br i1 %t597, label %bb165, label %bb166
bb165:
  %t598 = load ptr, ptr %l0, !tbaa !29
  store ptr %t598, ptr %l310, !tbaa !29
  %t599 = load ptr, ptr %l0, !tbaa !29
  %t600 = load i32, ptr %l9, !tbaa !23
  %t603 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t599, i32 %t600)
  store i32 %t603, ptr %l313
  br label %bb167
bb166:
  store i1 false, ptr %l309, !tbaa !21
  br label %bb169
bb167:
  %t604 = load ptr, ptr %l310, !tbaa !29
  %t605 = load i32, ptr %l313, !tbaa !23
  %t606 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisOver(ptr %v0, ptr %t604, i32 %t605)
  store i1 %t606, ptr %l314
  br label %bb168
bb168:
  %t607 = load i1, ptr %l314, !tbaa !21
  store i1 %t607, ptr %l309, !tbaa !21
  br label %bb169
bb169:
  %t608 = load i1, ptr %l309, !tbaa !21
  br i1 %t608, label %bb170, label %bb171
bb170:
  %t609 = load ptr, ptr %l0, !tbaa !29
  %t611 = getelementptr %"compiler/check:Checker", ptr %t609, i32 0, i32 1
  %t612 = load ptr, ptr %t611, !tbaa !29
  store ptr %t612, ptr %l317, !tbaa !29
  %t613 = load ptr, ptr %l0, !tbaa !29
  %t614 = load i32, ptr %l9, !tbaa !23
  %t617 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t613, i32 %t614)
  store i32 %t617, ptr %l320
  br label %bb172
bb171:
  store i1 false, ptr %l315, !tbaa !21
  br label %bb174
bb172:
  %t618 = load ptr, ptr %l317, !tbaa !29
  %t619 = load i32, ptr %l320, !tbaa !23
  %t620 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t618, i32 %t619)
  store i1 %t620, ptr %l321
  br label %bb173
bb173:
  %t621 = load i1, ptr %l321, !tbaa !21
  %t622 = xor i1 %t621, true
  store i1 %t622, ptr %l315, !tbaa !21
  br label %bb174
bb174:
  %t624 = load i1, ptr %l315, !tbaa !21
  br i1 %t624, label %bb175, label %bb176
bb175:
  %t625 = load ptr, ptr %l0, !tbaa !29
  store ptr %t625, ptr %l324, !tbaa !29
  %t626 = load ptr, ptr %l0, !tbaa !29
  %t627 = load i32, ptr %l9, !tbaa !23
  %t630 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t626, i32 %t627)
  store i32 %t630, ptr %l327
  br label %bb177
bb176:
  store i1 false, ptr %l323, !tbaa !21
  br label %bb179
bb177:
  %t631 = load i32, ptr %l3, !tbaa !23
  %t632 = load ptr, ptr %l324, !tbaa !29
  %t633 = load i32, ptr %l327, !tbaa !23
  %t635 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebaseHas(ptr %v0, ptr %t632, i32 %t633, i32 %t631)
  store i1 %t635, ptr %l329
  br label %bb178
bb178:
  %t636 = load i1, ptr %l329, !tbaa !21
  store i1 %t636, ptr %l323, !tbaa !21
  br label %bb179
bb179:
  %t637 = load i1, ptr %l323, !tbaa !21
  br i1 %t637, label %bb180, label %bb181
bb180:
  store %olang.scope zeroinitializer, ptr %s16
  %t638 = load ptr, ptr %l0, !tbaa !29
  store ptr %t638, ptr %l330, !tbaa !29
  %t639 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t639, ptr %l331
  %t640 = load ptr, ptr %l0, !tbaa !29
  store ptr %t640, ptr %l332, !tbaa !29
  %t641 = load ptr, ptr %l0, !tbaa !29
  %t642 = load i32, ptr %l9, !tbaa !23
  %t645 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t641, i32 %t642)
  store i32 %t645, ptr %l335
  br label %bb182
bb181:
  br label %bb189
bb182:
  %t646 = load ptr, ptr %l332, !tbaa !29
  %t647 = load i32, ptr %l335, !tbaa !23
  %t648 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s16, ptr %t646, i32 %t647)
  store { i64, ptr } %t648, ptr %l336
  br label %bb183
bb183:
  %t649 = load { i64, ptr }, ptr %l336, !tbaa !27
  %t650 = extractvalue { i64, ptr } %t649, 0
  %t651 = extractvalue { i64, ptr } %t649, 1
  %t652 = mul i64 %t650, 1
  %t653 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t652)
  call void @llvm.memcpy.p0.p0.i64(ptr %t653, ptr %t651, i64 %t652, i1 false)
  %t654 = insertvalue { i64, ptr } undef, i64 %t650, 0
  %t655 = insertvalue { i64, ptr } %t654, ptr %t653, 1
  store { i64, ptr } %t655, ptr %l337, !tbaa !27
  %t656 = load ptr, ptr %l0, !tbaa !29
  %t657 = load i32, ptr %l3, !tbaa !23
  %t660 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s16, ptr %t656, i32 %t657)
  store { i64, ptr } %t660, ptr %l340
  br label %bb184
bb184:
  %t661 = load { i64, ptr }, ptr %l340, !tbaa !27
  %t662 = extractvalue { i64, ptr } %t661, 0
  %t663 = extractvalue { i64, ptr } %t661, 1
  %t664 = mul i64 %t662, 1
  %t665 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t664)
  call void @llvm.memcpy.p0.p0.i64(ptr %t665, ptr %t663, i64 %t664, i1 false)
  %t666 = insertvalue { i64, ptr } undef, i64 %t662, 0
  %t667 = insertvalue { i64, ptr } %t666, ptr %t665, 1
  %t668 = load { i64, ptr }, ptr %l337, !tbaa !27
  %t670 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodNotInherited(ptr %s16, ptr %s16, ptr %s16, { i64, ptr } %t668, { i64, ptr } %t667)
  store %"compiler/msgs:Msg" %t670, ptr %l342
  br label %bb185
bb185:
  %t671 = load ptr, ptr %l330, !tbaa !29
  %t672 = load %"compiler/source:Span", ptr %l331
  %t673 = load %"compiler/msgs:Msg", ptr %l342
  %t674 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s16, ptr %t671, %"compiler/source:Span" %t672, %"compiler/msgs:Msg" %t673)
  store i64 %t674, ptr %l343
  br label %bb186
bb186:
  %t675 = load ptr, ptr %l0, !tbaa !29
  %t676 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t675, { i64, ptr } %t676)
  br label %bb187
bb187:
  %t679 = load ptr, ptr %l0, !tbaa !29
  %t680 = load %"compiler/source:Span", ptr %l1
  %t683 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t679, %"compiler/source:Span" %t680)
  store ptr %t683, ptr %l348
  br label %bb188
bb188:
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s0)
  %t684 = load ptr, ptr %l348, !tbaa !29
  store ptr %t684, ptr %rv
  br label %ret
bb189:
  %t685 = load i64, ptr %l14, !tbaa !24
  %t687 = icmp slt i64 %t685, 0
  br i1 %t687, label %bb190, label %bb191
bb190:
  store %olang.scope zeroinitializer, ptr %s17
  %t689 = load ptr, ptr %l0, !tbaa !29
  %t690 = load %"compiler/source:Span", ptr %l1
  %t691 = load %"compiler/source:Span", ptr %l4
  %t692 = load ptr, ptr %l2, !tbaa !29
  %t693 = load ptr, ptr %l8, !tbaa !29
  %t694 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t695 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t703 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esuppliedCall(ptr %v0, ptr %v1, ptr %v0, ptr %v2, ptr %t689, %"compiler/source:Span" %t690, %"compiler/source:Span" %t691, ptr %t692, ptr %t693, { i64, ptr } %t694, { i64, ptr } %t695)
  store ptr %t703, ptr %l358
  br label %bb192
bb191:
  br label %bb246
bb192:
  %t704 = load ptr, ptr %l358, !tbaa !29
  store ptr %t704, ptr %l16, !tbaa !29
  %t705 = load ptr, ptr %l16, !tbaa !29
  %t707 = icmp eq ptr %t705, null
  %t709 = xor i1 %t707, true
  br i1 %t709, label %bb193, label %bb194
bb193:
  %t711 = load ptr, ptr %l16, !tbaa !29
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t711, ptr %rv
  br label %ret
bb194:
  br label %bb195
bb195:
  %t713 = load ptr, ptr %l0, !tbaa !29
  %t714 = load i32, ptr %l9, !tbaa !23
  %t717 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t713, i32 %t714)
  store i32 %t717, ptr %l365
  br label %bb196
bb196:
  %t718 = load i32, ptr %l365, !tbaa !23
  store i32 %t718, ptr %l17, !tbaa !23
  %t719 = load ptr, ptr %l0, !tbaa !29
  %t720 = load i32, ptr %l17, !tbaa !23
  %t723 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t719, i32 %t720)
  store i1 %t723, ptr %l368
  br label %bb197
bb197:
  %t724 = load i1, ptr %l368, !tbaa !21
  br i1 %t724, label %bb198, label %bb199
bb198:
  %t725 = load ptr, ptr %l0, !tbaa !29
  %t726 = load i32, ptr %l17, !tbaa !23
  %t727 = load i32, ptr %l3, !tbaa !23
  %t731 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldIndex(ptr %v0, ptr %t725, i32 %t726, i32 %t727)
  store i64 %t731, ptr %l373
  br label %bb200
bb199:
  store i1 false, ptr %l369, !tbaa !21
  br label %bb201
bb200:
  %t732 = load i64, ptr %l373, !tbaa !24
  %t733 = icmp sge i64 %t732, 0
  store i1 %t733, ptr %l369, !tbaa !21
  br label %bb201
bb201:
  %t735 = load i1, ptr %l369, !tbaa !21
  br i1 %t735, label %bb202, label %bb203
bb202:
  %t736 = load ptr, ptr %l8, !tbaa !29
  %t738 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %t736)
  store ptr %t738, ptr %l376
  br label %bb204
bb203:
  br label %bb220
bb204:
  %t739 = load ptr, ptr %l376, !tbaa !29
  store ptr %t739, ptr %l18, !tbaa !29
  %t740 = load ptr, ptr %l18, !tbaa !29
  %t742 = icmp eq ptr %t740, null
  br i1 %t742, label %bb205, label %bb206
bb205:
  %t744 = load ptr, ptr %l2, !tbaa !29
  %t746 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t744)
  store %"compiler/source:Span" %t746, ptr %l380
  br label %bb207
bb206:
  br label %bb210
bb207:
  %t747 = load i32, ptr %l9, !tbaa !23
  store i32 %t747, ptr %l381, !tbaa !23
  %t748 = load ptr, ptr %l8, !tbaa !29
  store ptr %t748, ptr %l382, !tbaa !29
  %t749 = load ptr, ptr %l0, !tbaa !29
  store ptr %t749, ptr %l383, !tbaa !29
  store i32 8, ptr %l384
  %t750 = load ptr, ptr %l2, !tbaa !29
  %t752 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t750)
  store %"compiler/source:Span" %t752, ptr %l386
  br label %bb208
bb208:
  %t753 = load ptr, ptr %l383, !tbaa !29
  %t754 = load i32, ptr %l384
  %t755 = load %"compiler/source:Span", ptr %l386
  %t756 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t753, i32 %t754, %"compiler/source:Span" %t755)
  store i32 %t756, ptr %l387
  br label %bb209
bb209:
  store { i64, [4 x i64] } zeroinitializer, ptr %t757
  %t758 = getelementptr { i64, [4 x i64] }, ptr %t757, i32 0, i32 0
  store i64 6, ptr %t758
  %t759 = load %"compiler/source:Span", ptr %l380
  %t760 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } undef, %"compiler/source:Span" %t759, 0
  %t761 = load i32, ptr %l381, !tbaa !23
  %t762 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t760, i32 %t761, 1
  %t763 = load ptr, ptr %l382, !tbaa !29
  %t764 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t762, ptr %t763, 2
  %t765 = load i32, ptr %l387, !tbaa !23
  %t766 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t764, i32 %t765, 3
  %t767 = getelementptr { i64, [4 x i64] }, ptr %t757, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i32 } %t766, ptr %t767
  %t768 = load { i64, [4 x i64] }, ptr %t757
  %t770 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t768, ptr %t770
  store ptr %t770, ptr %l18, !tbaa !29
  br label %bb210
bb210:
  %t772 = load ptr, ptr %l0, !tbaa !29
  store ptr %t772, ptr %l390, !tbaa !29
  %t773 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t773, ptr %l391
  %t774 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t774, ptr %l392
  %t775 = load ptr, ptr %l18, !tbaa !29
  %t777 = icmp eq ptr %t775, null
  br i1 %t777, label %bb211, label %bb212
bb211:
  call void @__olang_check_failed(ptr @olang_loc_897998a95b9e5e2e_e7f90bd867c953f2)
  unreachable
bb212:
  br label %bb213
bb213:
  %t779 = load ptr, ptr %l18, !tbaa !29
  %t780 = load i32, ptr %l3, !tbaa !23
  %t781 = load ptr, ptr %l390, !tbaa !29
  %t782 = load %"compiler/source:Span", ptr %l391
  %t783 = load %"compiler/source:Span", ptr %l392
  %t786 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efield(ptr %v0, ptr %t781, %"compiler/source:Span" %t782, %"compiler/source:Span" %t783, ptr %t779, i32 %t780)
  store ptr %t786, ptr %l397
  br label %bb214
bb214:
  %t787 = load ptr, ptr %l397, !tbaa !29
  store ptr %t787, ptr %l19, !tbaa !29
  %t788 = load ptr, ptr %l19, !tbaa !29
  %t790 = icmp eq ptr %t788, null
  %t792 = xor i1 %t790, true
  br i1 %t792, label %bb215, label %bb216
bb215:
  %t794 = load ptr, ptr %l0, !tbaa !29
  store ptr %t794, ptr %l401, !tbaa !29
  %t795 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t795, ptr %l402
  %t796 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t796, ptr %l403
  %t797 = load ptr, ptr %l0, !tbaa !29
  %t798 = load %"compiler/source:Span", ptr %l1
  %t799 = load ptr, ptr %l19, !tbaa !29
  %t803 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t797, %"compiler/source:Span" %t798, ptr %t799)
  store ptr %t803, ptr %l407
  br label %bb217
bb216:
  br label %bb219
bb217:
  %t804 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t805 = load ptr, ptr %l401, !tbaa !29
  %t806 = load %"compiler/source:Span", ptr %l402
  %t807 = load %"compiler/source:Span", ptr %l403
  %t808 = load ptr, ptr %l407, !tbaa !29
  %t810 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallValue(ptr %v0, ptr %v2, ptr %t805, %"compiler/source:Span" %t806, %"compiler/source:Span" %t807, ptr %t808, { i64, ptr } %t804)
  store ptr %t810, ptr %l409
  br label %bb218
bb218:
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s0)
  %t811 = load ptr, ptr %l409, !tbaa !29
  store ptr %t811, ptr %rv
  br label %ret
bb219:
  br label %bb220
bb220:
  %t812 = load ptr, ptr %l0, !tbaa !29
  %t813 = load i32, ptr %l17, !tbaa !23
  %t816 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t812, i32 %t813)
  store i1 %t816, ptr %l412
  br label %bb221
bb221:
  %t817 = load i1, ptr %l412, !tbaa !21
  br i1 %t817, label %bb222, label %bb223
bb222:
  %t818 = load ptr, ptr %l0, !tbaa !29
  %t819 = load i32, ptr %l17, !tbaa !23
  %t822 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t818, i32 %t819)
  store i32 %t822, ptr %l416
  br label %bb224
bb223:
  store i1 false, ptr %l413, !tbaa !21
  br label %bb225
bb224:
  %t823 = load i32, ptr %l416
  %t825 = trunc i64 3 to i32
  %t826 = icmp eq i32 %t823, %t825
  store i1 %t826, ptr %l413, !tbaa !21
  br label %bb225
bb225:
  %t828 = load i1, ptr %l413, !tbaa !21
  br i1 %t828, label %bb226, label %bb227
bb226:
  %t829 = load ptr, ptr %l0, !tbaa !29
  %t830 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t829, { i64, ptr } %t830)
  br label %bb228
bb227:
  br label %bb230
bb228:
  %t833 = load ptr, ptr %l0, !tbaa !29
  %t834 = load %"compiler/source:Span", ptr %l1
  %t837 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t833, %"compiler/source:Span" %t834)
  store ptr %t837, ptr %l423
  br label %bb229
bb229:
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s0)
  %t838 = load ptr, ptr %l423, !tbaa !29
  store ptr %t838, ptr %rv
  br label %ret
bb230:
  %t839 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t841 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s17, { i64, ptr } %t839, { i64, ptr } { i64 4, ptr @.d18 })
  store i1 %t841, ptr %l425
  br label %bb231
bb231:
  %t842 = load i1, ptr %l425, !tbaa !21
  br i1 %t842, label %bb232, label %bb233
bb232:
  store i1 true, ptr %l426, !tbaa !21
  br label %bb235
bb233:
  %t843 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t845 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s17, { i64, ptr } %t843, { i64, ptr } { i64 3, ptr @.d19 })
  store i1 %t845, ptr %l428
  br label %bb234
bb234:
  %t846 = load i1, ptr %l428, !tbaa !21
  store i1 %t846, ptr %l426, !tbaa !21
  br label %bb235
bb235:
  %t847 = load i1, ptr %l426, !tbaa !21
  br i1 %t847, label %bb236, label %bb237
bb236:
  store %olang.scope zeroinitializer, ptr %s23
  %t848 = load ptr, ptr %l0, !tbaa !29
  %t849 = load %"compiler/source:Span", ptr %l4
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s23, ptr %t848, %"compiler/source:Span" %t849, { i64, ptr } { i64 43, ptr @.d20 })
  br label %bb238
bb237:
  store %olang.scope zeroinitializer, ptr %s24
  %t852 = load ptr, ptr %l0, !tbaa !29
  store ptr %t852, ptr %l431, !tbaa !29
  %t853 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t853, ptr %l432
  %t854 = load ptr, ptr %l0, !tbaa !29
  %t855 = load i32, ptr %l9, !tbaa !23
  %t858 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s24, ptr %t854, i32 %t855)
  store { i64, ptr } %t858, ptr %l435
  br label %bb239
bb238:
  call void @__olang_scope_close(ptr %s23)
  br label %bb243
bb239:
  %t859 = load { i64, ptr }, ptr %l435, !tbaa !27
  %t860 = extractvalue { i64, ptr } %t859, 0
  %t861 = extractvalue { i64, ptr } %t859, 1
  %t862 = mul i64 %t860, 1
  %t863 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t862)
  call void @llvm.memcpy.p0.p0.i64(ptr %t863, ptr %t861, i64 %t862, i1 false)
  %t864 = insertvalue { i64, ptr } undef, i64 %t860, 0
  %t865 = insertvalue { i64, ptr } %t864, ptr %t863, 1
  store { i64, ptr } %t865, ptr %l436, !tbaa !27
  %t866 = load ptr, ptr %l0, !tbaa !29
  %t867 = load i32, ptr %l3, !tbaa !23
  %t870 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s24, ptr %t866, i32 %t867)
  store { i64, ptr } %t870, ptr %l439
  br label %bb240
bb240:
  %t871 = load { i64, ptr }, ptr %l439, !tbaa !27
  %t872 = extractvalue { i64, ptr } %t871, 0
  %t873 = extractvalue { i64, ptr } %t871, 1
  %t874 = mul i64 %t872, 1
  %t875 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t874)
  call void @llvm.memcpy.p0.p0.i64(ptr %t875, ptr %t873, i64 %t874, i1 false)
  %t876 = insertvalue { i64, ptr } undef, i64 %t872, 0
  %t877 = insertvalue { i64, ptr } %t876, ptr %t875, 1
  %t878 = load { i64, ptr }, ptr %l436, !tbaa !27
  %t880 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownMethod(ptr %s24, ptr %s24, ptr %s24, { i64, ptr } %t878, { i64, ptr } %t877)
  store %"compiler/msgs:Msg" %t880, ptr %l441
  br label %bb241
bb241:
  %t881 = load ptr, ptr %l431, !tbaa !29
  %t882 = load %"compiler/source:Span", ptr %l432
  %t883 = load %"compiler/msgs:Msg", ptr %l441
  %t884 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s24, ptr %t881, %"compiler/source:Span" %t882, %"compiler/msgs:Msg" %t883)
  store i64 %t884, ptr %l442
  br label %bb242
bb242:
  call void @__olang_scope_close(ptr %s24)
  br label %bb243
bb243:
  %t885 = load ptr, ptr %l0, !tbaa !29
  %t886 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t885, { i64, ptr } %t886)
  br label %bb244
bb244:
  %t889 = load ptr, ptr %l0, !tbaa !29
  %t890 = load %"compiler/source:Span", ptr %l1
  %t893 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t889, %"compiler/source:Span" %t890)
  store ptr %t893, ptr %l447
  br label %bb245
bb245:
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s0)
  %t894 = load ptr, ptr %l447, !tbaa !29
  store ptr %t894, ptr %rv
  br label %ret
bb246:
  %t895 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t895, ptr %l448, !tbaa !27
  %t896 = getelementptr { i64, ptr }, ptr %l448, i32 0, i32 1
  %t897 = load ptr, ptr %t896, !tbaa !27
  %t898 = getelementptr i8, ptr %t897, i64 0
  %t899 = load i8, ptr %t898, !tbaa !32
  %t901 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t899)
  store i1 %t901, ptr %l450
  br label %bb247
bb247:
  %t902 = load i1, ptr %l450, !tbaa !21
  %t903 = xor i1 %t902, true
  br i1 %t903, label %bb248, label %bb249
bb248:
  %t905 = load ptr, ptr %l0, !tbaa !29
  %t907 = getelementptr %"compiler/check:Checker", ptr %t905, i32 0, i32 1
  %t908 = load ptr, ptr %t907, !tbaa !29
  %t909 = load i64, ptr %l14, !tbaa !24
  %t912 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t908, i64 %t909)
  store i64 %t912, ptr %l456
  br label %bb250
bb249:
  store i1 false, ptr %l452, !tbaa !21
  br label %bb252
bb250:
  %t913 = load ptr, ptr %l0, !tbaa !29
  %t915 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t913)
  store ptr %t915, ptr %l458
  br label %bb251
bb251:
  %t916 = load ptr, ptr %l458, !tbaa !29
  %t918 = getelementptr %"compiler/check:frame", ptr %t916, i32 0, i32 1
  %t919 = load i64, ptr %t918, !tbaa !24
  %t920 = load i64, ptr %l456, !tbaa !24
  %t922 = icmp ne i64 %t920, %t919
  store i1 %t922, ptr %l452, !tbaa !21
  br label %bb252
bb252:
  %t924 = load i1, ptr %l452, !tbaa !21
  br i1 %t924, label %bb253, label %bb254
bb253:
  store %olang.scope zeroinitializer, ptr %s25
  %t925 = load ptr, ptr %l0, !tbaa !29
  store ptr %t925, ptr %l462, !tbaa !29
  %t926 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t926, ptr %l463
  %t927 = load ptr, ptr %l0, !tbaa !29
  %t928 = load i32, ptr %l3, !tbaa !23
  %t931 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s25, ptr %t927, i32 %t928)
  store { i64, ptr } %t931, ptr %l466
  br label %bb255
bb254:
  br label %bb258
bb255:
  %t932 = load { i64, ptr }, ptr %l466, !tbaa !27
  %t933 = extractvalue { i64, ptr } %t932, 0
  %t934 = extractvalue { i64, ptr } %t932, 1
  %t935 = mul i64 %t933, 1
  %t936 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t935)
  call void @llvm.memcpy.p0.p0.i64(ptr %t936, ptr %t934, i64 %t935, i1 false)
  %t937 = insertvalue { i64, ptr } undef, i64 %t933, 0
  %t938 = insertvalue { i64, ptr } %t937, ptr %t936, 1
  %t940 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodIsPrivate(ptr %s25, ptr %s25, { i64, ptr } %t938)
  store %"compiler/msgs:Msg" %t940, ptr %l468
  br label %bb256
bb256:
  %t941 = load ptr, ptr %l462, !tbaa !29
  %t942 = load %"compiler/source:Span", ptr %l463
  %t943 = load %"compiler/msgs:Msg", ptr %l468
  %t944 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s25, ptr %t941, %"compiler/source:Span" %t942, %"compiler/msgs:Msg" %t943)
  store i64 %t944, ptr %l469
  br label %bb257
bb257:
  call void @__olang_scope_close(ptr %s25)
  br label %bb258
bb258:
  %t945 = load ptr, ptr %l0, !tbaa !29
  store ptr %t945, ptr %l470, !tbaa !29
  %t946 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t946, ptr %l471
  %t947 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t947, ptr %l472
  %t948 = load i64, ptr %l14, !tbaa !24
  store i64 %t948, ptr %l473, !tbaa !24
  %t949 = load ptr, ptr %l8, !tbaa !29
  store ptr %t949, ptr %l475, !tbaa !29
  %t951 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t951, ptr %l476, !tbaa !27
  %t952 = icmp sge i64 0, 0
  br i1 %t952, label %bb259, label %bb260
bb259:
  %t954 = icmp sle i64 0, 1152921504606846975
  br i1 %t954, label %bb261, label %bb262
bb260:
  call void @__olang_check_failed(ptr @olang_loc_97297cf958301a5_897be3a3c1a33231)
  unreachable
bb261:
  %t956 = mul i64 0, 8
  %t957 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t956)
  %t958 = insertvalue { i64, ptr } undef, i64 0, 0
  %t959 = insertvalue { i64, ptr } %t958, ptr %t957, 1
  store { i64, ptr } %t959, ptr %l479, !tbaa !27
  %t960 = icmp sge i64 0, 0
  br i1 %t960, label %bb263, label %bb264
bb262:
  call void @__olang_check_failed(ptr @olang_loc_97297cf958301a5_897be3a3c1a33231)
  unreachable
bb263:
  %t962 = icmp sle i64 0, 2305843009213693951
  br i1 %t962, label %bb265, label %bb266
bb264:
  call void @__olang_check_failed(ptr @olang_loc_f4ec2e4bc4870738_831a294d3dfd1224)
  unreachable
bb265:
  %t964 = mul i64 0, 4
  %t965 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t964)
  %t966 = insertvalue { i64, ptr } undef, i64 0, 0
  %t967 = insertvalue { i64, ptr } %t966, ptr %t965, 1
  %t968 = load ptr, ptr %l470, !tbaa !29
  %t969 = load %"compiler/source:Span", ptr %l471
  %t970 = load %"compiler/source:Span", ptr %l472
  %t971 = load i64, ptr %l473, !tbaa !24
  %t972 = load ptr, ptr %l475, !tbaa !29
  %t973 = load { i64, ptr }, ptr %l476, !tbaa !27
  %t974 = load { i64, ptr }, ptr %l479, !tbaa !27
  %t976 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v2, ptr %s0, ptr %t968, %"compiler/source:Span" %t969, %"compiler/source:Span" %t970, i64 %t971, ptr %t972, { i64, ptr } %t973, { i64, ptr } %t974, { i64, ptr } %t967)
  store ptr %t976, ptr %l483
  br label %bb267
bb266:
  call void @__olang_check_failed(ptr @olang_loc_f4ec2e4bc4870738_831a294d3dfd1224)
  unreachable
bb267:
  call void @__olang_scope_close(ptr %s0)
  %t977 = load ptr, ptr %l483, !tbaa !29
  store ptr %t977, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamedHolds(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l11 = alloca i64
  %l14 = alloca i64
  %l36 = alloca i32
  %l44 = alloca i32
  %l49 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  store i64 8, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t1 = load i64, ptr %l3, !tbaa !24
  %t2 = load i64, ptr %l2, !tbaa !24
  %t5 = icmp sgt i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp sgt i64 %t7, 0
  br i1 %t9, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l11, !tbaa !24
  br label %bb6
bb3:
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l2, !tbaa !24
  %t15 = sub i64 %t11, %t12
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = add i64 %t15, %t16
  %t21 = sub i64 %t19, 1
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = sdiv i64 %t21, %t22
  store i64 %t25, ptr %l14, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb5
bb5:
  %t27 = load i64, ptr %l14, !tbaa !24
  store i64 %t27, ptr %l11, !tbaa !24
  br label %bb6
bb6:
  %t28 = load i64, ptr %l11, !tbaa !24
  store i64 %t28, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t29 = load i64, ptr %l6, !tbaa !24
  %t30 = load i64, ptr %l5, !tbaa !24
  %t33 = icmp slt i64 %t29, %t30
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb9:
  br label %bb10
bb10:
  %t37 = load i64, ptr %l2, !tbaa !24
  %t38 = load i64, ptr %l6, !tbaa !24
  %t39 = load i64, ptr %l4, !tbaa !24
  %t42 = mul i64 %t38, %t39
  %t45 = add i64 %t37, %t42
  store i64 %t45, ptr %l7, !tbaa !24
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = getelementptr %"compiler/generic:Program", ptr %t50, i32 0, i32 2
  %t53 = load i32, ptr %l1, !tbaa !23
  %t56 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t52, i32 %t53)
  store i32 %t56, ptr %l36
  br label %bb11
bb11:
  %t57 = load i32, ptr %l36
  %t59 = trunc i64 19 to i32
  %t60 = icmp eq i32 %t57, %t59
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb13:
  br label %bb14
bb14:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  %t70 = load i32, ptr %l1, !tbaa !23
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t69, i32 %t70)
  store i32 %t73, ptr %l44
  br label %bb15
bb15:
  %t74 = load i32, ptr %l44, !tbaa !23
  store i32 %t74, ptr %l1, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  %t75 = load i64, ptr %l6, !tbaa !24
  %t77 = add i64 %t75, 1
  store i64 %t77, ptr %l6, !tbaa !24
  br label %bb7
bb17:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load i32, ptr %l1, !tbaa !23
  %t83 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %t79, i32 %t80)
  store i1 %t83, ptr %l49
  br label %bb18
bb18:
  %t84 = load i1, ptr %l49, !tbaa !21
  store i1 %t84, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrow(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca ptr
  %l22 = alloca ptr
  %l25 = alloca i32
  %l28 = alloca i32
  %l31 = alloca i64
  %l34 = alloca ptr
  %l37 = alloca ptr
  %l42 = alloca i32
  %l43 = alloca i32
  %l44 = alloca { i64, ptr }
  %l58 = alloca i1
  %l59 = alloca %"compiler/source:Span"
  %l60 = alloca i32
  %l64 = alloca ptr
  %l69 = alloca ptr
  %l74 = alloca i32
  %l75 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l79 = alloca %"compiler/source:Span"
  %l80 = alloca i32
  %l84 = alloca %"compiler/typed:Payload"
  %l93 = alloca i64
  %l96 = alloca i64
  %l116 = alloca { i64, ptr }
  %l121 = alloca i64
  %l125 = alloca { i64, ptr }
  %l132 = alloca ptr
  %l150 = alloca ptr
  %l157 = alloca %"compiler/check:narrowed"
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %t64 = alloca { i64, [4 x i64] }, align 8
  %t94 = alloca { i64, [4 x i64] }, align 8
  %t144 = alloca { i64, [4 x i64] }, align 8
  %t216 = alloca { i64, [2 x i64] }, align 8
  %t238 = alloca { i64, [4 x i64] }, align 8
  %t270 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l22
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l22, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t5, i64 %t6)
  store i32 %t9, ptr %l25
  br label %bb2
bb2:
  %t10 = load i32, ptr %l25, !tbaa !23
  store i32 %t10, ptr %l5, !tbaa !23
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l5, !tbaa !23
  %t15 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t15, ptr %l28
  br label %bb3
bb3:
  %t16 = load i32, ptr %l28, !tbaa !23
  store i32 %t16, ptr %l6, !tbaa !23
  %t17 = load ptr, ptr %l4, !tbaa !29
  %t19 = getelementptr %"compiler/check:frame", ptr %t17, i32 0, i32 42
  %t21 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t19)
  store i64 %t21, ptr %l31
  br label %bb4
bb4:
  %t22 = load i64, ptr %l31, !tbaa !24
  store i64 %t22, ptr %l7, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  store ptr %t28, ptr %l34, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  store ptr %t34, ptr %l37, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t39 = load i32, ptr %l6, !tbaa !23
  %t40 = load i64, ptr %l3, !tbaa !24
  %t44 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %t38, i32 %t39, i64 %t40)
  store i32 %t44, ptr %l42
  br label %bb5
bb5:
  %t45 = load ptr, ptr %l37, !tbaa !29
  %t46 = load i32, ptr %l42, !tbaa !23
  %t47 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t45, i32 %t46)
  store i32 %t47, ptr %l43
  br label %bb6
bb6:
  %t48 = load ptr, ptr %l34, !tbaa !29
  %t49 = load i32, ptr %l43, !tbaa !23
  %t50 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t48, i32 %t49)
  store { i64, ptr } %t50, ptr %l44
  br label %bb7
bb7:
  %t51 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t51, ptr %l8, !tbaa !27
  %t52 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t52, 0
  %t56 = icmp sgt i64 %t54, 0
  br i1 %t56, label %bb8, label %bb9
bb8:
  %t58 = load %"compiler/source:Span", ptr %l1
  %t59 = load i32, ptr %l5, !tbaa !23
  %t60 = load i64, ptr %l2, !tbaa !24
  %t62 = trunc i64 %t60 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t64
  %t65 = getelementptr { i64, [4 x i64] }, ptr %t64, i32 0, i32 0
  store i64 0, ptr %t65
  %t67 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t58, 0
  %t69 = insertvalue { %"compiler/source:Span", i32, i32 } %t67, i32 %t59, 1
  %t71 = insertvalue { %"compiler/source:Span", i32, i32 } %t69, i32 %t62, 2
  %t72 = getelementptr { i64, [4 x i64] }, ptr %t64, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t71, ptr %t72
  %t73 = load { i64, [4 x i64] }, ptr %t64
  %t75 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t73, ptr %t75
  store ptr %t75, ptr %l9, !tbaa !29
  %t77 = load ptr, ptr %l9, !tbaa !29
  store ptr %t77, ptr %l10, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load i32, ptr %l5, !tbaa !23
  %t83 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t79, i32 %t80)
  store i1 %t83, ptr %l58
  br label %bb10
bb9:
  br label %bb35
bb10:
  %t84 = load i1, ptr %l58, !tbaa !21
  br i1 %t84, label %bb11, label %bb12
bb11:
  %t85 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t85, ptr %l59
  %t86 = load i32, ptr %l6, !tbaa !23
  store i32 %t86, ptr %l60, !tbaa !23
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load %"compiler/source:Span", ptr %l1
  %t89 = load ptr, ptr %l9, !tbaa !29
  %t93 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t87, %"compiler/source:Span" %t88, ptr %t89)
  store ptr %t93, ptr %l64
  br label %bb13
bb12:
  br label %bb14
bb13:
  store { i64, [4 x i64] } zeroinitializer, ptr %t94
  %t95 = getelementptr { i64, [4 x i64] }, ptr %t94, i32 0, i32 0
  store i64 2, ptr %t95
  %t96 = load %"compiler/source:Span", ptr %l59
  %t97 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t96, 0
  %t98 = load i32, ptr %l60, !tbaa !23
  %t99 = insertvalue { %"compiler/source:Span", i32, ptr } %t97, i32 %t98, 1
  %t100 = load ptr, ptr %l64, !tbaa !29
  %t101 = insertvalue { %"compiler/source:Span", i32, ptr } %t99, ptr %t100, 2
  %t102 = getelementptr { i64, [4 x i64] }, ptr %t94, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t101, ptr %t102
  %t103 = load { i64, [4 x i64] }, ptr %t94
  %t105 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t103, ptr %t105
  store ptr %t105, ptr %l10, !tbaa !29
  br label %bb14
bb14:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/check:Checker", ptr %t107, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = getelementptr %"compiler/generic:Program", ptr %t110, i32 0, i32 2
  store ptr %t112, ptr %l69, !tbaa !29
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/check:Checker", ptr %t113, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t118 = getelementptr %"compiler/generic:Program", ptr %t116, i32 0, i32 2
  %t119 = load i32, ptr %l6, !tbaa !23
  %t122 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t118, i32 %t119)
  store i32 %t122, ptr %l74
  br label %bb15
bb15:
  %t123 = load ptr, ptr %l69, !tbaa !29
  %t124 = load i32, ptr %l74, !tbaa !23
  %t125 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t123, i32 %t124)
  store { i64, ptr } %t125, ptr %l75
  br label %bb16
bb16:
  %t126 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t126, ptr %l76, !tbaa !27
  %t127 = load i64, ptr %l3, !tbaa !24
  %t129 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr i32, ptr %t130, i64 %t127
  %t132 = load i32, ptr %t131, !tbaa !33
  %t134 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t134, ptr %l79
  store i32 %t132, ptr %l80, !tbaa !23
  %t136 = load ptr, ptr %l10, !tbaa !29
  %t137 = load i64, ptr %l3, !tbaa !24
  %t141 = call %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v0, ptr %v0, ptr %t136, i64 %t137, i32 0)
  store %"compiler/typed:Payload" %t141, ptr %l84
  br label %bb17
bb17:
  %t142 = load %"compiler/typed:Payload", ptr %l84
  %t143 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Payload" %t142, ptr %t143
  store { i64, [4 x i64] } zeroinitializer, ptr %t144
  %t145 = getelementptr { i64, [4 x i64] }, ptr %t144, i32 0, i32 0
  store i64 5, ptr %t145
  %t146 = load %"compiler/source:Span", ptr %l79
  %t147 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t146, 0
  %t148 = load i32, ptr %l80, !tbaa !23
  %t149 = insertvalue { %"compiler/source:Span", i32, ptr } %t147, i32 %t148, 1
  %t151 = insertvalue { %"compiler/source:Span", i32, ptr } %t149, ptr %t143, 2
  %t152 = getelementptr { i64, [4 x i64] }, ptr %t144, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t151, ptr %t152
  %t153 = load { i64, [4 x i64] }, ptr %t144
  %t155 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t153, ptr %t155
  store ptr %t155, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  %t157 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t159 = extractvalue { i64, ptr } %t157, 0
  store i64 %t159, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t161 = load i64, ptr %l14, !tbaa !24
  %t162 = load i64, ptr %l13, !tbaa !24
  %t165 = icmp sgt i64 %t161, %t162
  br i1 %t165, label %bb18, label %bb19
bb18:
  %t167 = load i64, ptr %l15, !tbaa !24
  %t169 = icmp sgt i64 %t167, 0
  br i1 %t169, label %bb20, label %bb21
bb19:
  store i64 0, ptr %l93, !tbaa !24
  br label %bb23
bb20:
  %t171 = load i64, ptr %l14, !tbaa !24
  %t172 = load i64, ptr %l13, !tbaa !24
  %t175 = sub i64 %t171, %t172
  %t176 = load i64, ptr %l15, !tbaa !24
  %t179 = add i64 %t175, %t176
  %t181 = sub i64 %t179, 1
  %t182 = load i64, ptr %l15, !tbaa !24
  %t185 = sdiv i64 %t181, %t182
  store i64 %t185, ptr %l96, !tbaa !24
  br label %bb22
bb21:
  store i64 0, ptr %l96, !tbaa !24
  br label %bb22
bb22:
  %t187 = load i64, ptr %l96, !tbaa !24
  store i64 %t187, ptr %l93, !tbaa !24
  br label %bb23
bb23:
  %t188 = load i64, ptr %l93, !tbaa !24
  store i64 %t188, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s4
  %t189 = load i64, ptr %l17, !tbaa !24
  %t190 = load i64, ptr %l16, !tbaa !24
  %t193 = icmp slt i64 %t189, %t190
  %t195 = xor i1 %t193, true
  br i1 %t195, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s4)
  br label %bb34
bb26:
  br label %bb27
bb27:
  %t197 = load i64, ptr %l13, !tbaa !24
  %t198 = load i64, ptr %l17, !tbaa !24
  %t199 = load i64, ptr %l15, !tbaa !24
  %t202 = mul i64 %t198, %t199
  %t205 = add i64 %t197, %t202
  store i64 %t205, ptr %l18, !tbaa !24
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load %"compiler/source:Span", ptr %l1
  %t209 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t209, ptr %l116, !tbaa !27
  %t210 = load i64, ptr %l18, !tbaa !24
  %t212 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t213 = load ptr, ptr %t212, !tbaa !27
  %t214 = getelementptr i32, ptr %t213, i64 %t210
  %t215 = load i32, ptr %t214, !tbaa !33
  store { i64, [2 x i64] } zeroinitializer, ptr %t216
  %t217 = getelementptr { i64, [2 x i64] }, ptr %t216, i32 0, i32 0
  store i64 5, ptr %t217
  %t218 = load { i64, [2 x i64] }, ptr %t216
  %t224 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t207, i32 0, %"compiler/source:Span" %t208, i32 %t215, i32 4, { i64, [2 x i64] } %t218)
  store i64 %t224, ptr %l121
  br label %bb28
bb28:
  %t225 = load i64, ptr %l121, !tbaa !24
  store i64 %t225, ptr %l19, !tbaa !24
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t227 = load %"compiler/source:Span", ptr %l1
  %t228 = load %"compiler/source:Span", ptr %l1
  %t229 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t229, ptr %l125, !tbaa !27
  %t230 = load i64, ptr %l18, !tbaa !24
  %t232 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !27
  %t234 = getelementptr i32, ptr %t233, i64 %t230
  %t235 = load i32, ptr %t234, !tbaa !33
  %t236 = load ptr, ptr %l12, !tbaa !29
  %t237 = load i64, ptr %l18, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t238
  %t239 = getelementptr { i64, [4 x i64] }, ptr %t238, i32 0, i32 0
  store i64 3, ptr %t239
  %t241 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t228, 0
  %t243 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t241, i32 %t235, 1
  %t245 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t243, ptr %t236, 2
  %t247 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t245, i64 %t237, 3
  %t248 = getelementptr { i64, [4 x i64] }, ptr %t238, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t247, ptr %t248
  %t249 = load { i64, [4 x i64] }, ptr %t238
  %t251 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t249, ptr %t251
  %t255 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t226, %"compiler/source:Span" %t227, ptr %t251)
  store ptr %t255, ptr %l132
  br label %bb29
bb29:
  %t256 = load ptr, ptr %l132, !tbaa !29
  store ptr %t256, ptr %l20, !tbaa !29
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load i64, ptr %l19, !tbaa !24
  %t259 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v0, ptr %t257, i64 %t258, ptr %t259)
  br label %bb30
bb30:
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t264 = load %"compiler/source:Span", ptr %l1
  %t265 = load i64, ptr %l19, !tbaa !24
  %t267 = trunc i64 %t265 to i32
  %t269 = load ptr, ptr %l20, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t270
  %t271 = getelementptr { i64, [3 x i64] }, ptr %t270, i32 0, i32 0
  store i64 0, ptr %t271
  %t273 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t264, 0
  %t275 = insertvalue { %"compiler/source:Span", i32, ptr } %t273, i32 %t267, 1
  %t277 = insertvalue { %"compiler/source:Span", i32, ptr } %t275, ptr %t269, 2
  %t278 = getelementptr { i64, [3 x i64] }, ptr %t270, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t277, ptr %t278
  %t279 = load { i64, [3 x i64] }, ptr %t270
  %t281 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t279, ptr %t281
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t263, ptr %t281)
  br label %bb31
bb31:
  %t284 = load ptr, ptr %l4, !tbaa !29
  %t286 = getelementptr %"compiler/check:frame", ptr %t284, i32 0, i32 42
  %t287 = load i64, ptr %l19, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t286, i64 %t287)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s4)
  br label %bb33
bb33:
  %t290 = load i64, ptr %l17, !tbaa !24
  %t292 = add i64 %t290, 1
  store i64 %t292, ptr %l17, !tbaa !24
  br label %bb24
bb34:
  br label %bb35
bb35:
  %t294 = load ptr, ptr %l4, !tbaa !29
  %t296 = getelementptr %"compiler/check:frame", ptr %t294, i32 0, i32 41
  store ptr %t296, ptr %l150, !tbaa !29
  %t297 = load i64, ptr %l2, !tbaa !24
  %t298 = load i64, ptr %l3, !tbaa !24
  %t299 = load i32, ptr %l6, !tbaa !23
  %t300 = load i64, ptr %l7, !tbaa !24
  %t301 = load ptr, ptr %l4, !tbaa !29
  %t303 = getelementptr %"compiler/check:frame", ptr %t301, i32 0, i32 7
  %t304 = load i64, ptr %t303, !tbaa !24
  %t310 = call %"compiler/check:narrowed" @compiler_2fcheck_3anarrowed_2ector(ptr %s0, i64 %t297, i64 %t298, i32 %t299, i64 %t300, i64 %t304)
  store %"compiler/check:narrowed" %t310, ptr %l157
  br label %bb36
bb36:
  %t311 = load ptr, ptr %l150, !tbaa !29
  %t312 = load %"compiler/check:narrowed", ptr %l157
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anarrowed_3e_2ePu_H8ca7ff483075a23de06ba27b878260e2(ptr %v0, ptr %t311, %"compiler/check:narrowed" %t312)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/msgs:Msg" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoCase(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca i64
  %l14 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l27 = alloca i64
  %l38 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l52 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l55 = alloca i64
  %l57 = alloca i64
  %l58 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l73 = alloca %"compiler/msgs:Msg"
  %l76 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l82 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t1, i32 %t2)
  store { i64, ptr } %t5, ptr %l14
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %t12, i32 %t13)
  store { i64, ptr } %t16, ptr %l19
  br label %bb2
bb2:
  %t17 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t17, ptr %l4, !tbaa !27
  store { i64, ptr } { i64 0, ptr @.d21 }, ptr %l20, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t18, ptr %l21, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 0
  store i64 %t20, ptr %l22, !tbaa !24
  %t21 = load i64, ptr %l22, !tbaa !24
  %t22 = mul i64 %t21, 1
  %t23 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t22)
  %t24 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l23, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = load i64, ptr %l22, !tbaa !24
  %t31 = mul i64 %t30, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t27, ptr %t29, i64 %t31, i1 false)
  %t32 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t32, ptr %l5, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t37 = icmp sle i64 %t35, 4
  br i1 %t37, label %bb3, label %bb4
bb3:
  store i64 2, ptr %l27, !tbaa !24
  br label %bb5
bb4:
  store i64 3, ptr %l27, !tbaa !24
  br label %bb5
bb5:
  %t39 = load i64, ptr %l27, !tbaa !24
  store i64 %t39, ptr %l6, !tbaa !24
  %t40 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t40, 0
  %t44 = icmp sgt i64 %t42, 0
  br i1 %t44, label %bb6, label %bb7
bb6:
  %t46 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t46, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t48 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t48, 0
  store i64 %t50, ptr %l9, !tbaa !24
  br label %bb8
bb7:
  br label %bb23
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t52 = load i64, ptr %l8, !tbaa !24
  %t53 = load i64, ptr %l9, !tbaa !24
  %t56 = icmp slt i64 %t52, %t53
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb10:
  br label %bb11
bb11:
  %t60 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t60, ptr %l38, !tbaa !27
  %t61 = load i64, ptr %l8, !tbaa !24
  %t63 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr i32, ptr %t64, i64 %t61
  %t66 = load i32, ptr %t65, !tbaa !33
  store i32 %t66, ptr %l10, !tbaa !23
  %t68 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t68, ptr %l41, !tbaa !27
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i32, ptr %l10, !tbaa !23
  %t73 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t69, i32 %t70)
  store { i64, ptr } %t73, ptr %l44
  br label %bb12
bb12:
  %t74 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t76 = call i64 @compiler_2fcheck_2enameDistance(ptr %v0, ptr %v0, { i64, ptr } %t74, { i64, ptr } %t75)
  store i64 %t76, ptr %l45
  br label %bb13
bb13:
  %t77 = load i64, ptr %l45, !tbaa !24
  store i64 %t77, ptr %l11, !tbaa !24
  %t78 = load i64, ptr %l11, !tbaa !24
  %t79 = load i64, ptr %l6, !tbaa !24
  %t82 = icmp slt i64 %t78, %t79
  br i1 %t82, label %bb14, label %bb15
bb14:
  %t84 = load i64, ptr %l11, !tbaa !24
  store i64 %t84, ptr %l6, !tbaa !24
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load i32, ptr %l10, !tbaa !23
  %t90 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t86, i32 %t87)
  store { i64, ptr } %t90, ptr %l52
  br label %bb16
bb15:
  br label %bb20
bb16:
  %t91 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t91, ptr %l53, !tbaa !27
  %t92 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 0
  %t94 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 0
  store i64 %t95, ptr %l55, !tbaa !24
  %t97 = load i64, ptr %l55, !tbaa !24
  %t98 = icmp eq i64 %t93, %t97
  br i1 %t98, label %bb17, label %bb18
bb17:
  %t100 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = load i64, ptr %l55, !tbaa !24
  %t105 = mul i64 %t104, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t101, ptr %t103, i64 %t105, i1 false)
  br label %bb19
bb18:
  %t106 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t106, 0
  store i64 %t107, ptr %l57, !tbaa !24
  %t108 = load i64, ptr %l57, !tbaa !24
  %t109 = mul i64 %t108, 1
  %t110 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t109)
  %t111 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l58, !tbaa !27
  %t113 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = load i64, ptr %l57, !tbaa !24
  %t118 = mul i64 %t117, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t114, ptr %t116, i64 %t118, i1 false)
  %t119 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t119, ptr %l5, !tbaa !27
  br label %bb19
bb19:
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb21:
  %t120 = load i64, ptr %l8, !tbaa !24
  %t122 = add i64 %t120, 1
  store i64 %t122, ptr %l8, !tbaa !24
  br label %bb8
bb22:
  br label %bb23
bb23:
  %t124 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t124, 0
  %t128 = icmp sgt i64 %t126, 0
  br i1 %t128, label %bb24, label %bb25
bb24:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t131 = load i32, ptr %l1, !tbaa !23
  %t134 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %t130, i32 %t131)
  store { i64, ptr } %t134, ptr %l66
  br label %bb26
bb25:
  br label %bb29
bb26:
  %t135 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t135, 0
  %t137 = extractvalue { i64, ptr } %t135, 1
  %t138 = mul i64 %t136, 1
  %t139 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t138)
  call void @llvm.memcpy.p0.p0.i64(ptr %t139, ptr %t137, i64 %t138, i1 false)
  %t140 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t139, 1
  store { i64, ptr } %t141, ptr %l67, !tbaa !27
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load i32, ptr %l2, !tbaa !23
  %t146 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %t142, i32 %t143)
  store { i64, ptr } %t146, ptr %l70
  br label %bb27
bb27:
  %t147 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t147, 0
  %t149 = extractvalue { i64, ptr } %t147, 1
  %t150 = mul i64 %t148, 1
  %t151 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t150)
  call void @llvm.memcpy.p0.p0.i64(ptr %t151, ptr %t149, i64 %t150, i1 false)
  %t152 = insertvalue { i64, ptr } undef, i64 %t148, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr %t151, 1
  %t154 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t155 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t158 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSuchCaseMeant(ptr %v1, ptr %v1, ptr %s0, ptr %v1, { i64, ptr } %t155, { i64, ptr } %t153, { i64, ptr } %t154)
  store %"compiler/msgs:Msg" %t158, ptr %l73
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s0)
  %t159 = load %"compiler/msgs:Msg", ptr %l73
  store %"compiler/msgs:Msg" %t159, ptr %rv
  br label %ret
bb29:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load i32, ptr %l1, !tbaa !23
  %t164 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %t160, i32 %t161)
  store { i64, ptr } %t164, ptr %l76
  br label %bb30
bb30:
  %t165 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t166 = extractvalue { i64, ptr } %t165, 0
  %t167 = extractvalue { i64, ptr } %t165, 1
  %t168 = mul i64 %t166, 1
  %t169 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t168)
  call void @llvm.memcpy.p0.p0.i64(ptr %t169, ptr %t167, i64 %t168, i1 false)
  %t170 = insertvalue { i64, ptr } undef, i64 %t166, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr %t169, 1
  store { i64, ptr } %t171, ptr %l77, !tbaa !27
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load i32, ptr %l2, !tbaa !23
  %t176 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %t172, i32 %t173)
  store { i64, ptr } %t176, ptr %l80
  br label %bb31
bb31:
  %t177 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t177, 0
  %t179 = extractvalue { i64, ptr } %t177, 1
  %t180 = mul i64 %t178, 1
  %t181 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t180)
  call void @llvm.memcpy.p0.p0.i64(ptr %t181, ptr %t179, i64 %t180, i1 false)
  %t182 = insertvalue { i64, ptr } undef, i64 %t178, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t181, 1
  %t184 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t186 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSuchCase(ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t184, { i64, ptr } %t183)
  store %"compiler/msgs:Msg" %t186, ptr %l82
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s0)
  %t187 = load %"compiler/msgs:Msg", ptr %l82
  store %"compiler/msgs:Msg" %t187, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorCall(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l14 = alloca i1
  %l16 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca i32
  %l23 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca { i64, ptr }
  %l29 = alloca %"compiler/source:Span"
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l34 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca ptr
  %l43 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l49 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca %"compiler/source:Span"
  %l54 = alloca %"compiler/source:Span"
  %l55 = alloca i64
  %l57 = alloca ptr
  %l60 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l67 = alloca ptr
  %l70 = alloca ptr
  %l74 = alloca ptr
  %l78 = alloca ptr
  %l79 = alloca %"compiler/source:Span"
  %l80 = alloca %"compiler/source:Span"
  %l81 = alloca i64
  %l83 = alloca ptr
  %l86 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l93 = alloca ptr
  %l96 = alloca ptr
  %l100 = alloca ptr
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store i32 %a3, ptr %l3
  store ptr %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l3
  %t3 = call { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %s0, i32 %t1)
  store { i64, ptr } %t3, ptr %l12
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t4, ptr %l6, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 0, ptr @.d22 })
  store i1 %t7, ptr %l14
  br label %bb2
bb2:
  %t8 = load i1, ptr %l14, !tbaa !21
  br i1 %t8, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l16, !tbaa !29
  %t11 = load ptr, ptr %l4, !tbaa !29
  %t14 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t11)
  store i32 %t14, ptr %l19
  br label %bb6
bb6:
  %t15 = load ptr, ptr %l16, !tbaa !29
  %t16 = load i32, ptr %l19, !tbaa !23
  %t17 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t17, ptr %l20
  br label %bb7
bb7:
  %t18 = load i32, ptr %l20, !tbaa !23
  store i32 %t18, ptr %l7, !tbaa !23
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load i32, ptr %l7, !tbaa !23
  %t23 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t19, i32 %t20)
  store i1 %t23, ptr %l23
  br label %bb8
bb8:
  %t24 = load i1, ptr %l23, !tbaa !21
  %t25 = xor i1 %t24, true
  br i1 %t25, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l26, !tbaa !29
  %t29 = load i32, ptr %l7, !tbaa !23
  store i32 %t29, ptr %l27, !tbaa !23
  %t30 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t30, ptr %l28, !tbaa !27
  %t31 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t31, ptr %l29
  %t32 = load i32, ptr %l3
  %t34 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s0, i32 %t32)
  store { i64, ptr } %t34, ptr %l31
  br label %bb12
bb12:
  %t35 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t36 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s0, ptr %s0, { i64, ptr } %t35)
  store { i64, ptr } %t36, ptr %l32
  br label %bb13
bb13:
  %t37 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 0
  %t39 = extractvalue { i64, ptr } %t37, 1
  %t40 = mul i64 %t38, 1
  %t41 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t40)
  call void @llvm.memcpy.p0.p0.i64(ptr %t41, ptr %t39, i64 %t40, i1 false)
  %t42 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t41, 1
  %t44 = load ptr, ptr %l26, !tbaa !29
  %t45 = load i32, ptr %l27, !tbaa !23
  %t46 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t47 = load %"compiler/source:Span", ptr %l29
  %t49 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %s0, ptr %s0, ptr %t44, i32 %t45, { i64, ptr } %t46, i64 1, %"compiler/source:Span" %t47, { i64, ptr } %t43)
  store i64 %t49, ptr %l34
  br label %bb14
bb14:
  %t50 = load i64, ptr %l34, !tbaa !24
  store i64 %t50, ptr %l8, !tbaa !24
  %t51 = load i64, ptr %l8, !tbaa !24
  %t53 = icmp slt i64 %t51, 0
  br i1 %t53, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l38, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l39, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/check:Checker", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t62 = load i64, ptr %l8, !tbaa !24
  %t65 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t61, i64 %t62)
  store ptr %t65, ptr %l43
  br label %bb18
bb18:
  %t66 = load ptr, ptr %l43, !tbaa !29
  %t68 = getelementptr %"compiler/ast:Func", ptr %t66, i32 0, i32 2
  %t69 = load i32, ptr %t68, !tbaa !23
  %t70 = load ptr, ptr %l39, !tbaa !29
  %t72 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t70, i32 %t69)
  store { i64, ptr } %t72, ptr %l46
  br label %bb19
bb19:
  %t73 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t74 = load ptr, ptr %l38, !tbaa !29
  %t75 = getelementptr %"compiler/check:Checker", ptr %t74, i32 0, i32 42
  store { i64, ptr } %t73, ptr %t75, !tbaa !27
  %t76 = load i32, ptr %l3
  %t78 = trunc i64 78 to i32
  %t79 = icmp eq i32 %t76, %t78
  br i1 %t79, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb22
bb21:
  %t81 = load i32, ptr %l3
  %t83 = trunc i64 77 to i32
  %t84 = icmp eq i32 %t81, %t83
  store i1 %t84, ptr %l49, !tbaa !21
  br label %bb22
bb22:
  %t86 = load i1, ptr %l49, !tbaa !21
  br i1 %t86, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s4
  %t87 = load ptr, ptr %l0, !tbaa !29
  store ptr %t87, ptr %l52, !tbaa !29
  %t88 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t88, ptr %l53
  %t89 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t89, ptr %l54
  %t90 = load i64, ptr %l8, !tbaa !24
  store i64 %t90, ptr %l55, !tbaa !24
  %t91 = load ptr, ptr %l5, !tbaa !29
  store ptr %t91, ptr %l57, !tbaa !29
  %t93 = icmp sge i64 0, 0
  br i1 %t93, label %bb25, label %bb26
bb24:
  br label %bb39
bb25:
  %t95 = icmp sle i64 0, 1152921504606846975
  br i1 %t95, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_9311a1fdea965308_123228c6f8b4663c)
  unreachable
bb27:
  %t97 = mul i64 0, 8
  %t98 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t97)
  %t99 = insertvalue { i64, ptr } undef, i64 0, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  store { i64, ptr } %t100, ptr %l60, !tbaa !27
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load ptr, ptr %l4, !tbaa !29
  %t105 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %t101, ptr %t102)
  store { i64, ptr } %t105, ptr %l63
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_9311a1fdea965308_123228c6f8b4663c)
  unreachable
bb29:
  %t106 = icmp sge i64 0, 0
  br i1 %t106, label %bb30, label %bb31
bb30:
  %t108 = icmp sle i64 0, 2305843009213693951
  br i1 %t108, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @olang_loc_6fa6db75017b9575_1d827b27b68e8189)
  unreachable
bb32:
  %t110 = mul i64 0, 4
  %t111 = call ptr @__olang_scope_alloc_zeroed(ptr %s4, i64 %t110)
  %t112 = insertvalue { i64, ptr } undef, i64 0, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t111, 1
  %t114 = load ptr, ptr %l52, !tbaa !29
  %t115 = load %"compiler/source:Span", ptr %l53
  %t116 = load %"compiler/source:Span", ptr %l54
  %t117 = load i64, ptr %l55, !tbaa !24
  %t118 = load ptr, ptr %l57, !tbaa !29
  %t119 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t120 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t122 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %s4, ptr %t114, %"compiler/source:Span" %t115, %"compiler/source:Span" %t116, i64 %t117, ptr %t118, { i64, ptr } %t119, { i64, ptr } %t120, { i64, ptr } %t113)
  store ptr %t122, ptr %l67
  br label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_6fa6db75017b9575_1d827b27b68e8189)
  unreachable
bb34:
  %t123 = load ptr, ptr %l67, !tbaa !29
  store ptr %t123, ptr %l9, !tbaa !29
  %t124 = load i32, ptr %l3
  %t126 = trunc i64 77 to i32
  %t127 = icmp eq i32 %t124, %t126
  br i1 %t127, label %bb35, label %bb36
bb35:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load %"compiler/source:Span", ptr %l1
  %t131 = load ptr, ptr %l9, !tbaa !29
  %t135 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %t129, %"compiler/source:Span" %t130, ptr %t131)
  store ptr %t135, ptr %l74
  br label %bb37
bb36:
  %t136 = load ptr, ptr %l9, !tbaa !29
  store ptr %t136, ptr %l70, !tbaa !29
  br label %bb38
bb37:
  %t139 = load ptr, ptr %l74, !tbaa !29
  store ptr %t139, ptr %l70, !tbaa !29
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t141 = load ptr, ptr %l70, !tbaa !29
  store ptr %t141, ptr %rv
  br label %ret
bb39:
  %t142 = load ptr, ptr %l0, !tbaa !29
  store ptr %t142, ptr %l78, !tbaa !29
  %t143 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t143, ptr %l79
  %t144 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t144, ptr %l80
  %t145 = load i64, ptr %l8, !tbaa !24
  store i64 %t145, ptr %l81, !tbaa !24
  %t146 = load ptr, ptr %l4, !tbaa !29
  store ptr %t146, ptr %l83, !tbaa !29
  %t148 = icmp sge i64 0, 0
  br i1 %t148, label %bb40, label %bb41
bb40:
  %t150 = icmp sle i64 0, 1152921504606846975
  br i1 %t150, label %bb42, label %bb43
bb41:
  call void @__olang_check_failed(ptr @olang_loc_53860b63ce2a3756_eab450cf1ae092ca)
  unreachable
bb42:
  %t152 = mul i64 0, 8
  %t153 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t152)
  %t154 = insertvalue { i64, ptr } undef, i64 0, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t153, 1
  store { i64, ptr } %t155, ptr %l86, !tbaa !27
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load ptr, ptr %l5, !tbaa !29
  %t160 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %t156, ptr %t157)
  store { i64, ptr } %t160, ptr %l89
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_53860b63ce2a3756_eab450cf1ae092ca)
  unreachable
bb44:
  %t161 = icmp sge i64 0, 0
  br i1 %t161, label %bb45, label %bb46
bb45:
  %t163 = icmp sle i64 0, 2305843009213693951
  br i1 %t163, label %bb47, label %bb48
bb46:
  call void @__olang_check_failed(ptr @olang_loc_6fa6db75017b9575_1d827b27b68e8189)
  unreachable
bb47:
  %t165 = mul i64 0, 4
  %t166 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t165)
  %t167 = insertvalue { i64, ptr } undef, i64 0, 0
  %t168 = insertvalue { i64, ptr } %t167, ptr %t166, 1
  %t169 = load ptr, ptr %l78, !tbaa !29
  %t170 = load %"compiler/source:Span", ptr %l79
  %t171 = load %"compiler/source:Span", ptr %l80
  %t172 = load i64, ptr %l81, !tbaa !24
  %t173 = load ptr, ptr %l83, !tbaa !29
  %t174 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t175 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t177 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %s0, ptr %t169, %"compiler/source:Span" %t170, %"compiler/source:Span" %t171, i64 %t172, ptr %t173, { i64, ptr } %t174, { i64, ptr } %t175, { i64, ptr } %t168)
  store ptr %t177, ptr %l93
  br label %bb49
bb48:
  call void @__olang_check_failed(ptr @olang_loc_6fa6db75017b9575_1d827b27b68e8189)
  unreachable
bb49:
  %t178 = load ptr, ptr %l93, !tbaa !29
  store ptr %t178, ptr %l10, !tbaa !29
  %t179 = load i32, ptr %l3
  %t181 = trunc i64 79 to i32
  %t182 = icmp eq i32 %t179, %t181
  br i1 %t182, label %bb50, label %bb51
bb50:
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t185 = load %"compiler/source:Span", ptr %l1
  %t186 = load ptr, ptr %l10, !tbaa !29
  %t190 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %t184, %"compiler/source:Span" %t185, ptr %t186)
  store ptr %t190, ptr %l100
  br label %bb52
bb51:
  %t191 = load ptr, ptr %l10, !tbaa !29
  store ptr %t191, ptr %l96, !tbaa !29
  br label %bb53
bb52:
  %t194 = load ptr, ptr %l100, !tbaa !29
  store ptr %t194, ptr %l96, !tbaa !29
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s0)
  %t196 = load ptr, ptr %l96, !tbaa !29
  store ptr %t196, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epartsEqual(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca ptr
  %l22 = alloca i1
  %l27 = alloca i32
  %l28 = alloca ptr
  %l29 = alloca %"compiler/source:Span"
  %l30 = alloca i32
  %l31 = alloca ptr
  %l32 = alloca %"compiler/source:Span"
  %l37 = alloca ptr
  %l39 = alloca ptr
  %l40 = alloca ptr
  %l41 = alloca %"compiler/source:Span"
  %l46 = alloca ptr
  %l48 = alloca ptr
  %l49 = alloca ptr
  %l55 = alloca i32
  %l58 = alloca i1
  %l65 = alloca i32
  %l68 = alloca i1
  %l71 = alloca i32
  %l78 = alloca i32
  %l86 = alloca ptr
  %l90 = alloca i1
  %l93 = alloca i32
  %l101 = alloca ptr
  %l106 = alloca i64
  %l107 = alloca ptr
  %l108 = alloca %"compiler/source:Span"
  %l113 = alloca ptr
  %l114 = alloca ptr
  %l115 = alloca ptr
  %l116 = alloca %"compiler/source:Span"
  %l121 = alloca ptr
  %l122 = alloca ptr
  %l127 = alloca { i64, ptr }
  %l131 = alloca ptr
  %l137 = alloca i64
  %l140 = alloca i64
  %l158 = alloca ptr
  %l159 = alloca %"compiler/source:Span"
  %l160 = alloca i32
  %l164 = alloca { i64, ptr }
  %l171 = alloca ptr
  %l175 = alloca { i64, ptr }
  %l182 = alloca ptr
  %l183 = alloca ptr
  %l186 = alloca ptr
  %l188 = alloca %"compiler/source:Span"
  %l189 = alloca i32
  %l190 = alloca ptr
  %l192 = alloca ptr
  %l196 = alloca ptr
  %l197 = alloca %"compiler/typed:Cond"
  %l205 = alloca i64
  %l208 = alloca %"compiler/source:Span"
  %l209 = alloca i32
  %l213 = alloca { i64, ptr }
  %l216 = alloca %"compiler/typed:Seq"
  %s11 = alloca %olang.scope
  %rv = alloca ptr
  %t291 = alloca { i64, [4 x i64] }, align 8
  %t321 = alloca { i64, [4 x i64] }, align 8
  %t370 = alloca { i64, [5 x i64] }, align 8
  %t414 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l4, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisOver(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l22
  br label %bb1
bb1:
  %t6 = load i1, ptr %l22, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l4, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l27
  br label %bb4
bb3:
  br label %bb10
bb4:
  %t17 = load i32, ptr %l27, !tbaa !23
  store i32 %t17, ptr %l5, !tbaa !23
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l28, !tbaa !29
  %t19 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t19, ptr %l29
  store i32 72, ptr %l30
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l31, !tbaa !29
  %t21 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t21, ptr %l32
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t24 = load i32, ptr %l4, !tbaa !23
  %t25 = load %"compiler/source:Span", ptr %l1
  %t30 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t22, ptr %t23, i32 %t24, %"compiler/source:Span" %t25)
  store ptr %t30, ptr %l37
  br label %bb5
bb5:
  %t31 = load i32, ptr %l5, !tbaa !23
  %t32 = load ptr, ptr %l31, !tbaa !29
  %t33 = load %"compiler/source:Span", ptr %l32
  %t34 = load ptr, ptr %l37, !tbaa !29
  %t36 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %t32, %"compiler/source:Span" %t33, ptr %t34, i32 %t31)
  store ptr %t36, ptr %l39
  br label %bb6
bb6:
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l40, !tbaa !29
  %t38 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t38, ptr %l41
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t41 = load i32, ptr %l4, !tbaa !23
  %t42 = load %"compiler/source:Span", ptr %l1
  %t47 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t39, ptr %t40, i32 %t41, %"compiler/source:Span" %t42)
  store ptr %t47, ptr %l46
  br label %bb7
bb7:
  %t48 = load i32, ptr %l5, !tbaa !23
  %t49 = load ptr, ptr %l40, !tbaa !29
  %t50 = load %"compiler/source:Span", ptr %l41
  %t51 = load ptr, ptr %l46, !tbaa !29
  %t53 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %t49, %"compiler/source:Span" %t50, ptr %t51, i32 %t48)
  store ptr %t53, ptr %l48
  br label %bb8
bb8:
  %t54 = load ptr, ptr %l28, !tbaa !29
  %t55 = load %"compiler/source:Span", ptr %l29
  %t56 = load i32, ptr %l30
  %t57 = load ptr, ptr %l39, !tbaa !29
  %t58 = load ptr, ptr %l48, !tbaa !29
  %t59 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eequality(ptr %v0, ptr %t54, %"compiler/source:Span" %t55, i32 %t56, ptr %t57, ptr %t58)
  store ptr %t59, ptr %l49
  br label %bb9
bb9:
  %t60 = load ptr, ptr %l49, !tbaa !29
  store ptr %t60, ptr %rv
  br label %ret
bb10:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 2
  %t68 = load i32, ptr %l4, !tbaa !23
  %t71 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t67, i32 %t68)
  store i32 %t71, ptr %l55
  br label %bb11
bb11:
  %t72 = load i32, ptr %l55
  store i32 %t72, ptr %l6
  store i32 0, ptr %l7, !tbaa !23
  %t73 = load i32, ptr %l6
  %t75 = trunc i64 23 to i32
  %t76 = icmp eq i32 %t73, %t75
  br i1 %t76, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l58, !tbaa !21
  br label %bb14
bb13:
  %t78 = load i32, ptr %l6
  %t80 = trunc i64 22 to i32
  %t81 = icmp eq i32 %t78, %t80
  store i1 %t81, ptr %l58, !tbaa !21
  br label %bb14
bb14:
  %t83 = load i1, ptr %l58, !tbaa !21
  br i1 %t83, label %bb15, label %bb16
bb15:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/check:Checker", ptr %t84, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !29
  %t89 = getelementptr %"compiler/generic:Program", ptr %t87, i32 0, i32 2
  %t90 = load i32, ptr %l4, !tbaa !23
  %t93 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t89, i32 %t90)
  store i32 %t93, ptr %l65
  br label %bb17
bb16:
  %t94 = load i32, ptr %l6
  %t96 = trunc i64 18 to i32
  %t97 = icmp eq i32 %t94, %t96
  br i1 %t97, label %bb18, label %bb19
bb17:
  %t99 = load i32, ptr %l65, !tbaa !23
  store i32 %t99, ptr %l7, !tbaa !23
  br label %bb36
bb18:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load i32, ptr %l4, !tbaa !23
  %t104 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t100, i32 %t101)
  store i32 %t104, ptr %l71
  br label %bb20
bb19:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb21
bb20:
  %t105 = load i32, ptr %l71
  %t107 = trunc i64 0 to i32
  %t108 = icmp eq i32 %t105, %t107
  store i1 %t108, ptr %l68, !tbaa !21
  br label %bb21
bb21:
  %t110 = load i1, ptr %l68, !tbaa !21
  br i1 %t110, label %bb22, label %bb23
bb22:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/check:Checker", ptr %t111, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = getelementptr %"compiler/generic:Program", ptr %t114, i32 0, i32 2
  %t117 = load i32, ptr %l4, !tbaa !23
  %t120 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t116, i32 %t117)
  store i32 %t120, ptr %l78
  br label %bb24
bb23:
  %t121 = load i32, ptr %l6
  %t123 = trunc i64 19 to i32
  %t124 = icmp eq i32 %t121, %t123
  br i1 %t124, label %bb25, label %bb26
bb24:
  %t126 = load i32, ptr %l78, !tbaa !23
  store i32 %t126, ptr %l7, !tbaa !23
  br label %bb35
bb25:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load %"compiler/source:Span", ptr %l1
  %t129 = load ptr, ptr %l2, !tbaa !29
  %t130 = load ptr, ptr %l3, !tbaa !29
  %t131 = load i32, ptr %l4, !tbaa !23
  %t137 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earraysEqual(ptr %v0, ptr %t127, %"compiler/source:Span" %t128, ptr %t129, ptr %t130, i32 %t131)
  store ptr %t137, ptr %l86
  br label %bb27
bb26:
  %t138 = load i32, ptr %l6
  %t140 = trunc i64 18 to i32
  %t141 = icmp eq i32 %t138, %t140
  br i1 %t141, label %bb28, label %bb29
bb27:
  %t143 = load ptr, ptr %l86, !tbaa !29
  store ptr %t143, ptr %rv
  br label %ret
bb28:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load i32, ptr %l4, !tbaa !23
  %t149 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t145, i32 %t146)
  store i32 %t149, ptr %l93
  br label %bb30
bb29:
  store i1 false, ptr %l90, !tbaa !21
  br label %bb31
bb30:
  %t150 = load i32, ptr %l93
  %t152 = trunc i64 1 to i32
  %t153 = icmp eq i32 %t150, %t152
  store i1 %t153, ptr %l90, !tbaa !21
  br label %bb31
bb31:
  %t155 = load i1, ptr %l90, !tbaa !21
  br i1 %t155, label %bb32, label %bb33
bb32:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load %"compiler/source:Span", ptr %l1
  %t158 = load ptr, ptr %l2, !tbaa !29
  %t159 = load ptr, ptr %l3, !tbaa !29
  %t160 = load i32, ptr %l4, !tbaa !23
  %t166 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eenumsEqual(ptr %v0, ptr %t156, %"compiler/source:Span" %t157, ptr %t158, ptr %t159, i32 %t160)
  store ptr %t166, ptr %l101
  br label %bb34
bb33:
  store ptr null, ptr %rv
  br label %ret
bb34:
  %t168 = load ptr, ptr %l101, !tbaa !29
  store ptr %t168, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/check:Checker", ptr %t170, i32 0, i32 32
  %t174 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t172)
  store i64 %t174, ptr %l106
  br label %bb37
bb37:
  %t175 = load i64, ptr %l106, !tbaa !24
  store i64 %t175, ptr %l8, !tbaa !24
  %t176 = load ptr, ptr %l0, !tbaa !29
  store ptr %t176, ptr %l107, !tbaa !29
  %t177 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t177, ptr %l108
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load ptr, ptr %l2, !tbaa !29
  %t180 = load i32, ptr %l4, !tbaa !23
  %t181 = load %"compiler/source:Span", ptr %l1
  %t186 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t178, ptr %t179, i32 %t180, %"compiler/source:Span" %t181)
  store ptr %t186, ptr %l113
  br label %bb38
bb38:
  %t187 = load ptr, ptr %l107, !tbaa !29
  %t188 = load %"compiler/source:Span", ptr %l108
  %t189 = load ptr, ptr %l113, !tbaa !29
  %t190 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldOf(ptr %v0, ptr %t187, %"compiler/source:Span" %t188, ptr %t189)
  store ptr %t190, ptr %l114
  br label %bb39
bb39:
  %t191 = load ptr, ptr %l114, !tbaa !29
  store ptr %t191, ptr %l9, !tbaa !29
  %t192 = load ptr, ptr %l0, !tbaa !29
  store ptr %t192, ptr %l115, !tbaa !29
  %t193 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t193, ptr %l116
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load ptr, ptr %l3, !tbaa !29
  %t196 = load i32, ptr %l4, !tbaa !23
  %t197 = load %"compiler/source:Span", ptr %l1
  %t202 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t194, ptr %t195, i32 %t196, %"compiler/source:Span" %t197)
  store ptr %t202, ptr %l121
  br label %bb40
bb40:
  %t203 = load ptr, ptr %l115, !tbaa !29
  %t204 = load %"compiler/source:Span", ptr %l116
  %t205 = load ptr, ptr %l121, !tbaa !29
  %t206 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldOf(ptr %v0, ptr %t203, %"compiler/source:Span" %t204, ptr %t205)
  store ptr %t206, ptr %l122
  br label %bb41
bb41:
  %t207 = load ptr, ptr %l122, !tbaa !29
  store ptr %t207, ptr %l10, !tbaa !29
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/check:Checker", ptr %t208, i32 0, i32 1
  %t211 = load ptr, ptr %t210, !tbaa !29
  %t213 = getelementptr %"compiler/generic:Program", ptr %t211, i32 0, i32 2
  %t214 = load i32, ptr %l7, !tbaa !23
  %t217 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t213, i32 %t214)
  store { i64, ptr } %t217, ptr %l127
  br label %bb42
bb42:
  %t218 = load { i64, ptr }, ptr %l127, !tbaa !27
  store { i64, ptr } %t218, ptr %l11, !tbaa !27
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load %"compiler/source:Span", ptr %l1
  %t221 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t225 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t219, %"compiler/source:Span" %t220, i32 %t221, i64 1)
  store ptr %t225, ptr %l131
  br label %bb43
bb43:
  %t226 = load ptr, ptr %l131, !tbaa !29
  store ptr %t226, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  %t227 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t229 = extractvalue { i64, ptr } %t227, 0
  store i64 %t229, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t231 = load i64, ptr %l14, !tbaa !24
  %t232 = load i64, ptr %l13, !tbaa !24
  %t235 = icmp sgt i64 %t231, %t232
  br i1 %t235, label %bb44, label %bb45
bb44:
  %t237 = load i64, ptr %l15, !tbaa !24
  %t239 = icmp sgt i64 %t237, 0
  br i1 %t239, label %bb46, label %bb47
bb45:
  store i64 0, ptr %l137, !tbaa !24
  br label %bb49
bb46:
  %t241 = load i64, ptr %l14, !tbaa !24
  %t242 = load i64, ptr %l13, !tbaa !24
  %t245 = sub i64 %t241, %t242
  %t246 = load i64, ptr %l15, !tbaa !24
  %t249 = add i64 %t245, %t246
  %t251 = sub i64 %t249, 1
  %t252 = load i64, ptr %l15, !tbaa !24
  %t255 = sdiv i64 %t251, %t252
  store i64 %t255, ptr %l140, !tbaa !24
  br label %bb48
bb47:
  store i64 0, ptr %l140, !tbaa !24
  br label %bb48
bb48:
  %t257 = load i64, ptr %l140, !tbaa !24
  store i64 %t257, ptr %l137, !tbaa !24
  br label %bb49
bb49:
  %t258 = load i64, ptr %l137, !tbaa !24
  store i64 %t258, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb50
bb50:
  store %olang.scope zeroinitializer, ptr %s11
  %t259 = load i64, ptr %l17, !tbaa !24
  %t260 = load i64, ptr %l16, !tbaa !24
  %t263 = icmp slt i64 %t259, %t260
  %t265 = xor i1 %t263, true
  br i1 %t265, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s11)
  br label %bb63
bb52:
  br label %bb53
bb53:
  %t267 = load i64, ptr %l13, !tbaa !24
  %t268 = load i64, ptr %l17, !tbaa !24
  %t269 = load i64, ptr %l15, !tbaa !24
  %t272 = mul i64 %t268, %t269
  %t275 = add i64 %t267, %t272
  store i64 %t275, ptr %l18, !tbaa !24
  %t277 = load ptr, ptr %l0, !tbaa !29
  store ptr %t277, ptr %l158, !tbaa !29
  %t278 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t278, ptr %l159
  store i32 72, ptr %l160
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t280 = load %"compiler/source:Span", ptr %l1
  %t281 = load %"compiler/source:Span", ptr %l1
  %t282 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t282, ptr %l164, !tbaa !27
  %t283 = load i64, ptr %l18, !tbaa !24
  %t285 = getelementptr { i64, ptr }, ptr %l164, i32 0, i32 1
  %t286 = load ptr, ptr %t285, !tbaa !27
  %t287 = getelementptr i32, ptr %t286, i64 %t283
  %t288 = load i32, ptr %t287, !tbaa !33
  %t289 = load ptr, ptr %l9, !tbaa !29
  %t290 = load i64, ptr %l18, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t291
  %t292 = getelementptr { i64, [4 x i64] }, ptr %t291, i32 0, i32 0
  store i64 3, ptr %t292
  %t294 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t281, 0
  %t296 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t294, i32 %t288, 1
  %t298 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t296, ptr %t289, 2
  %t300 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t298, i64 %t290, 3
  %t301 = getelementptr { i64, [4 x i64] }, ptr %t291, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t300, ptr %t301
  %t302 = load { i64, [4 x i64] }, ptr %t291
  %t304 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t302, ptr %t304
  %t308 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t279, %"compiler/source:Span" %t280, ptr %t304)
  store ptr %t308, ptr %l171
  br label %bb54
bb54:
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t310 = load %"compiler/source:Span", ptr %l1
  %t311 = load %"compiler/source:Span", ptr %l1
  %t312 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t312, ptr %l175, !tbaa !27
  %t313 = load i64, ptr %l18, !tbaa !24
  %t315 = getelementptr { i64, ptr }, ptr %l175, i32 0, i32 1
  %t316 = load ptr, ptr %t315, !tbaa !27
  %t317 = getelementptr i32, ptr %t316, i64 %t313
  %t318 = load i32, ptr %t317, !tbaa !33
  %t319 = load ptr, ptr %l10, !tbaa !29
  %t320 = load i64, ptr %l18, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t321
  %t322 = getelementptr { i64, [4 x i64] }, ptr %t321, i32 0, i32 0
  store i64 3, ptr %t322
  %t324 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t311, 0
  %t326 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t324, i32 %t318, 1
  %t328 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t326, ptr %t319, 2
  %t330 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t328, i64 %t320, 3
  %t331 = getelementptr { i64, [4 x i64] }, ptr %t321, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t330, ptr %t331
  %t332 = load { i64, [4 x i64] }, ptr %t321
  %t334 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t332, ptr %t334
  %t338 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t309, %"compiler/source:Span" %t310, ptr %t334)
  store ptr %t338, ptr %l182
  br label %bb55
bb55:
  %t339 = load ptr, ptr %l158, !tbaa !29
  %t340 = load %"compiler/source:Span", ptr %l159
  %t341 = load i32, ptr %l160
  %t342 = load ptr, ptr %l171, !tbaa !29
  %t343 = load ptr, ptr %l182, !tbaa !29
  %t344 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eequality(ptr %v0, ptr %t339, %"compiler/source:Span" %t340, i32 %t341, ptr %t342, ptr %t343)
  store ptr %t344, ptr %l183
  br label %bb56
bb56:
  %t345 = load ptr, ptr %l183, !tbaa !29
  store ptr %t345, ptr %l19, !tbaa !29
  %t346 = load i64, ptr %l18, !tbaa !24
  %t348 = icmp eq i64 %t346, 0
  br i1 %t348, label %bb57, label %bb58
bb57:
  %t350 = load ptr, ptr %l19, !tbaa !29
  store ptr %t350, ptr %l186, !tbaa !29
  br label %bb61
bb58:
  %t352 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t352, ptr %l188
  %t353 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t353, ptr %l189, !tbaa !23
  %t354 = load ptr, ptr %l12, !tbaa !29
  store ptr %t354, ptr %l190, !tbaa !29
  %t355 = load ptr, ptr %l19, !tbaa !29
  store ptr %t355, ptr %l192, !tbaa !29
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t358 = load %"compiler/source:Span", ptr %l1
  %t359 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t363 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t357, %"compiler/source:Span" %t358, i32 %t359, i64 0)
  store ptr %t363, ptr %l196
  br label %bb59
bb59:
  %t364 = load ptr, ptr %l190, !tbaa !29
  %t365 = load ptr, ptr %l192, !tbaa !29
  %t366 = load ptr, ptr %l196, !tbaa !29
  %t367 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t364, ptr %t365, ptr %t366)
  store %"compiler/typed:Cond" %t367, ptr %l197
  br label %bb60
bb60:
  %t368 = load %"compiler/typed:Cond", ptr %l197
  %t369 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Cond" %t368, ptr %t369
  store { i64, [5 x i64] } zeroinitializer, ptr %t370
  %t371 = getelementptr { i64, [5 x i64] }, ptr %t370, i32 0, i32 0
  store i64 11, ptr %t371
  %t372 = load %"compiler/source:Span", ptr %l188
  %t373 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t372, 0
  %t374 = load i32, ptr %l189, !tbaa !23
  %t375 = insertvalue { %"compiler/source:Span", i32, ptr } %t373, i32 %t374, 1
  %t377 = insertvalue { %"compiler/source:Span", i32, ptr } %t375, ptr %t369, 2
  %t378 = getelementptr { i64, [5 x i64] }, ptr %t370, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t377, ptr %t378
  %t379 = load { i64, [5 x i64] }, ptr %t370
  %t381 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t379, ptr %t381
  store ptr %t381, ptr %l186, !tbaa !29
  br label %bb61
bb61:
  %t383 = load ptr, ptr %l186, !tbaa !29
  store ptr %t383, ptr %l12, !tbaa !29
  call void @__olang_scope_close(ptr %s11)
  br label %bb62
bb62:
  %t384 = load i64, ptr %l17, !tbaa !24
  %t386 = add i64 %t384, 1
  store i64 %t386, ptr %l17, !tbaa !24
  br label %bb50
bb63:
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t390 = getelementptr %"compiler/check:Checker", ptr %t388, i32 0, i32 32
  %t392 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t390)
  store i64 %t392, ptr %l205
  br label %bb64
bb64:
  %t393 = load i64, ptr %l8, !tbaa !24
  %t394 = load i64, ptr %l205, !tbaa !24
  %t396 = icmp sgt i64 %t394, %t393
  br i1 %t396, label %bb65, label %bb66
bb65:
  %t398 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t398, ptr %l208
  %t399 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t399, ptr %l209, !tbaa !23
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t402 = getelementptr %"compiler/check:Checker", ptr %t400, i32 0, i32 32
  %t403 = load i64, ptr %l8, !tbaa !24
  %t406 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t402, i64 %t403)
  store { i64, ptr } %t406, ptr %l213
  br label %bb67
bb66:
  br label %bb69
bb67:
  %t407 = load ptr, ptr %l12, !tbaa !29
  %t409 = load { i64, ptr }, ptr %l213, !tbaa !27
  %t411 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t409, ptr %t407)
  store %"compiler/typed:Seq" %t411, ptr %l216
  br label %bb68
bb68:
  %t412 = load %"compiler/typed:Seq", ptr %l216
  %t413 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Seq" %t412, ptr %t413
  store { i64, [5 x i64] } zeroinitializer, ptr %t414
  %t415 = getelementptr { i64, [5 x i64] }, ptr %t414, i32 0, i32 0
  store i64 12, ptr %t415
  %t416 = load %"compiler/source:Span", ptr %l208
  %t417 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t416, 0
  %t418 = load i32, ptr %l209, !tbaa !23
  %t419 = insertvalue { %"compiler/source:Span", i32, ptr } %t417, i32 %t418, 1
  %t421 = insertvalue { %"compiler/source:Span", i32, ptr } %t419, ptr %t413, 2
  %t422 = getelementptr { i64, [5 x i64] }, ptr %t414, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t421, ptr %t422
  %t423 = load { i64, [5 x i64] }, ptr %t414
  %t425 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t423, ptr %t425
  store ptr %t425, ptr %rv
  br label %ret
bb69:
  %t427 = load ptr, ptr %l12, !tbaa !29
  store ptr %t427, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epartsHaveEq(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l23 = alloca i32
  %l26 = alloca ptr
  %l31 = alloca i32
  %l33 = alloca i1
  %l36 = alloca i1
  %l40 = alloca i1
  %l43 = alloca i32
  %l48 = alloca ptr
  %l53 = alloca i32
  %l54 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l67 = alloca i1
  %l73 = alloca i32
  %l78 = alloca ptr
  %l83 = alloca i32
  %l84 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l97 = alloca i1
  %l103 = alloca i1
  %l104 = alloca ptr
  %l109 = alloca i32
  %l111 = alloca i1
  %l114 = alloca i1
  %l119 = alloca ptr
  %l124 = alloca i32
  %l125 = alloca { i64, ptr }
  %l132 = alloca { i64, ptr }
  %l138 = alloca i1
  %s6 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sgt i64 %t1, 8
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 2
  %t12 = load i32, ptr %l1, !tbaa !23
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t15, ptr %l23
  br label %bb4
bb4:
  %t16 = load i32, ptr %l23
  store i32 %t16, ptr %l3
  %t17 = load i32, ptr %l3
  %t19 = trunc i64 19 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb5, label %bb6
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l26, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  %t29 = load i32, ptr %l1, !tbaa !23
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t32, ptr %l31
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t33 = load i64, ptr %l2, !tbaa !24
  %t34 = load ptr, ptr %l26, !tbaa !29
  %t35 = load i32, ptr %l31, !tbaa !23
  %t37 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeHasEq(ptr %v0, ptr %t34, i32 %t35, i64 %t33)
  store i1 %t37, ptr %l33
  br label %bb8
bb8:
  %t38 = load i1, ptr %l33, !tbaa !21
  store i1 %t38, ptr %rv
  br label %ret
bb9:
  %t39 = load i32, ptr %l3
  %t41 = trunc i64 18 to i32
  %t42 = icmp eq i32 %t39, %t41
  br i1 %t42, label %bb10, label %bb11
bb10:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t48 = load i32, ptr %l1, !tbaa !23
  %t51 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t47, i32 %t48)
  store i1 %t51, ptr %l40
  br label %bb12
bb11:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb13
bb12:
  %t52 = load i1, ptr %l40, !tbaa !21
  store i1 %t52, ptr %l36, !tbaa !21
  br label %bb13
bb13:
  %t53 = load i1, ptr %l36, !tbaa !21
  br i1 %t53, label %bb14, label %bb15
bb14:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load i32, ptr %l1, !tbaa !23
  %t58 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t54, i32 %t55)
  store i32 %t58, ptr %l43
  br label %bb16
bb15:
  br label %bb54
bb16:
  %t59 = load i32, ptr %l43
  %t61 = trunc i64 0 to i32
  %t62 = icmp eq i32 %t59, %t61
  br i1 %t62, label %bb17, label %bb18
bb17:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  store ptr %t69, ptr %l48, !tbaa !29
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/check:Checker", ptr %t70, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/generic:Program", ptr %t73, i32 0, i32 2
  %t76 = load i32, ptr %l1, !tbaa !23
  %t79 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t75, i32 %t76)
  store i32 %t79, ptr %l53
  br label %bb19
bb18:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load i32, ptr %l1, !tbaa !23
  %t84 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t80, i32 %t81)
  store i32 %t84, ptr %l73
  br label %bb31
bb19:
  %t85 = load ptr, ptr %l48, !tbaa !29
  %t86 = load i32, ptr %l53, !tbaa !23
  %t87 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t85, i32 %t86)
  store { i64, ptr } %t87, ptr %l54
  br label %bb20
bb20:
  %t88 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t88, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t89 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t89, 0
  store i64 %t91, ptr %l6, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s6
  %t93 = load i64, ptr %l5, !tbaa !24
  %t94 = load i64, ptr %l6, !tbaa !24
  %t97 = icmp slt i64 %t93, %t94
  %t99 = xor i1 %t97, true
  br i1 %t99, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s6)
  br label %bb30
bb23:
  br label %bb24
bb24:
  %t101 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t101, ptr %l61, !tbaa !27
  %t102 = load i64, ptr %l5, !tbaa !24
  %t104 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr i32, ptr %t105, i64 %t102
  %t107 = load i32, ptr %t106, !tbaa !33
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = load i64, ptr %l2, !tbaa !24
  %t115 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeHasEq(ptr %v0, ptr %t109, i32 %t107, i64 %t111)
  store i1 %t115, ptr %l67
  br label %bb25
bb25:
  %t116 = load i1, ptr %l67, !tbaa !21
  br i1 %t116, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s6)
  store i1 true, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s6)
  br label %bb29
bb29:
  %t118 = load i64, ptr %l5, !tbaa !24
  %t120 = add i64 %t118, 1
  store i64 %t120, ptr %l5, !tbaa !24
  br label %bb21
bb30:
  br label %bb53
bb31:
  %t122 = load i32, ptr %l73
  %t124 = trunc i64 1 to i32
  %t125 = icmp eq i32 %t122, %t124
  br i1 %t125, label %bb32, label %bb33
bb32:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/check:Checker", ptr %t127, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t132 = getelementptr %"compiler/generic:Program", ptr %t130, i32 0, i32 2
  store ptr %t132, ptr %l78, !tbaa !29
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/check:Checker", ptr %t133, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !29
  %t138 = getelementptr %"compiler/generic:Program", ptr %t136, i32 0, i32 2
  %t139 = load i32, ptr %l1, !tbaa !23
  %t142 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t138, i32 %t139)
  store i32 %t142, ptr %l83
  br label %bb34
bb33:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load i32, ptr %l1, !tbaa !23
  %t147 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisOver(ptr %v0, ptr %t143, i32 %t144)
  store i1 %t147, ptr %l103
  br label %bb46
bb34:
  %t148 = load ptr, ptr %l78, !tbaa !29
  %t149 = load i32, ptr %l83, !tbaa !23
  %t150 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t148, i32 %t149)
  store { i64, ptr } %t150, ptr %l84
  br label %bb35
bb35:
  %t151 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t151, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t152 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t154 = extractvalue { i64, ptr } %t152, 0
  store i64 %t154, ptr %l10, !tbaa !24
  br label %bb36
bb36:
  store %olang.scope zeroinitializer, ptr %s12
  %t156 = load i64, ptr %l9, !tbaa !24
  %t157 = load i64, ptr %l10, !tbaa !24
  %t160 = icmp slt i64 %t156, %t157
  %t162 = xor i1 %t160, true
  br i1 %t162, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s12)
  br label %bb45
bb38:
  br label %bb39
bb39:
  %t164 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t164, ptr %l91, !tbaa !27
  %t165 = load i64, ptr %l9, !tbaa !24
  %t167 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t168 = load ptr, ptr %t167, !tbaa !27
  %t169 = getelementptr i32, ptr %t168, i64 %t165
  %t170 = load i32, ptr %t169, !tbaa !33
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = load i64, ptr %l2, !tbaa !24
  %t178 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeHasEq(ptr %v0, ptr %t172, i32 %t170, i64 %t174)
  store i1 %t178, ptr %l97
  br label %bb40
bb40:
  %t179 = load i1, ptr %l97, !tbaa !21
  br i1 %t179, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s12)
  store i1 true, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s12)
  br label %bb44
bb44:
  %t181 = load i64, ptr %l9, !tbaa !24
  %t183 = add i64 %t181, 1
  store i64 %t183, ptr %l9, !tbaa !24
  br label %bb36
bb45:
  br label %bb52
bb46:
  %t185 = load i1, ptr %l103, !tbaa !21
  br i1 %t185, label %bb47, label %bb48
bb47:
  %t186 = load ptr, ptr %l0, !tbaa !29
  store ptr %t186, ptr %l104, !tbaa !29
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/check:Checker", ptr %t187, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !29
  %t192 = getelementptr %"compiler/generic:Program", ptr %t190, i32 0, i32 2
  %t193 = load i32, ptr %l1, !tbaa !23
  %t196 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t192, i32 %t193)
  store i32 %t196, ptr %l109
  br label %bb49
bb48:
  br label %bb51
bb49:
  %t197 = load i64, ptr %l2, !tbaa !24
  %t198 = load ptr, ptr %l104, !tbaa !29
  %t199 = load i32, ptr %l109, !tbaa !23
  %t201 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeHasEq(ptr %v0, ptr %t198, i32 %t199, i64 %t197)
  store i1 %t201, ptr %l111
  br label %bb50
bb50:
  %t202 = load i1, ptr %l111, !tbaa !21
  store i1 %t202, ptr %rv
  br label %ret
bb51:
  br label %bb52
bb52:
  br label %bb53
bb53:
  br label %bb54
bb54:
  %t203 = load i32, ptr %l3
  %t205 = trunc i64 23 to i32
  %t206 = icmp eq i32 %t203, %t205
  br i1 %t206, label %bb55, label %bb56
bb55:
  store i1 true, ptr %l114, !tbaa !21
  br label %bb57
bb56:
  %t208 = load i32, ptr %l3
  %t210 = trunc i64 22 to i32
  %t211 = icmp eq i32 %t208, %t210
  store i1 %t211, ptr %l114, !tbaa !21
  br label %bb57
bb57:
  %t213 = load i1, ptr %l114, !tbaa !21
  br i1 %t213, label %bb58, label %bb59
bb58:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/check:Checker", ptr %t214, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !29
  %t219 = getelementptr %"compiler/generic:Program", ptr %t217, i32 0, i32 2
  store ptr %t219, ptr %l119, !tbaa !29
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t222 = getelementptr %"compiler/check:Checker", ptr %t220, i32 0, i32 1
  %t223 = load ptr, ptr %t222, !tbaa !29
  %t225 = getelementptr %"compiler/generic:Program", ptr %t223, i32 0, i32 2
  %t226 = load i32, ptr %l1, !tbaa !23
  %t229 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t225, i32 %t226)
  store i32 %t229, ptr %l124
  br label %bb60
bb59:
  br label %bb72
bb60:
  %t230 = load ptr, ptr %l119, !tbaa !29
  %t231 = load i32, ptr %l124, !tbaa !23
  %t232 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t230, i32 %t231)
  store { i64, ptr } %t232, ptr %l125
  br label %bb61
bb61:
  %t233 = load { i64, ptr }, ptr %l125, !tbaa !27
  store { i64, ptr } %t233, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t234 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t236 = extractvalue { i64, ptr } %t234, 0
  store i64 %t236, ptr %l14, !tbaa !24
  br label %bb62
bb62:
  store %olang.scope zeroinitializer, ptr %s19
  %t238 = load i64, ptr %l13, !tbaa !24
  %t239 = load i64, ptr %l14, !tbaa !24
  %t242 = icmp slt i64 %t238, %t239
  %t244 = xor i1 %t242, true
  br i1 %t244, label %bb63, label %bb64
bb63:
  call void @__olang_scope_close(ptr %s19)
  br label %bb71
bb64:
  br label %bb65
bb65:
  %t246 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t246, ptr %l132, !tbaa !27
  %t247 = load i64, ptr %l13, !tbaa !24
  %t249 = getelementptr { i64, ptr }, ptr %l132, i32 0, i32 1
  %t250 = load ptr, ptr %t249, !tbaa !27
  %t251 = getelementptr i32, ptr %t250, i64 %t247
  %t252 = load i32, ptr %t251, !tbaa !33
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = load i64, ptr %l2, !tbaa !24
  %t260 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeHasEq(ptr %v0, ptr %t254, i32 %t252, i64 %t256)
  store i1 %t260, ptr %l138
  br label %bb66
bb66:
  %t261 = load i1, ptr %l138, !tbaa !21
  br i1 %t261, label %bb67, label %bb68
bb67:
  call void @__olang_scope_close(ptr %s19)
  store i1 true, ptr %rv
  br label %ret
bb68:
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s19)
  br label %bb70
bb70:
  %t263 = load i64, ptr %l13, !tbaa !24
  %t265 = add i64 %t263, 1
  store i64 %t265, ptr %l13, !tbaa !24
  br label %bb62
bb71:
  br label %bb72
bb72:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKeepVal(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l5 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l14 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l19 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l25 = alloca i32
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %a1, i64 %a2)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t9, ptr %l10
  br label %bb4
bb4:
  %t10 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l10
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t10, ptr %l4
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 61
  %t14 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l4
  %t17 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H4c470d2e80d9fd53b2c4a8b35e81296f(ptr %v0, ptr %t13, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t14)
  store i1 %t17, ptr %l14
  br label %bb5
bb5:
  %t18 = load i1, ptr %l14, !tbaa !21
  %t19 = xor i1 %t18, true
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 61
  store ptr %t23, ptr %l17, !tbaa !29
  %t24 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l4
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t24, ptr %l18
  %t25 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l19
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t26 = load ptr, ptr %l17, !tbaa !29
  %t27 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l18
  %t28 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H64396385e4e6d43afa926b839ce2258a(ptr %v0, ptr %v0, ptr %t26, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t27, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t28)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 61
  %t32 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l4
  %t35 = call { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H6388cc594ade7977543a45717e2b755f(ptr %v0, ptr %v0, ptr %t31, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t32)
  %t36 = extractvalue { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } %t35, 1
  %t37 = extractvalue { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } %t35, 0
  store i32 %t37, ptr %l25
  %t38 = icmp ne i32 %t37, 0
  br i1 %t38, label %bb12, label %ok.39
ok.39:
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t36, ptr %l24
  br label %bb11
bb11:
  %t40 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l24
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t40, ptr %l20
  br label %bb14
bb12:
  br label %bb13
bb13:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb14:
  %t41 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l20
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t41, ptr %l5
  %t42 = load ptr, ptr %l3, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v1, ptr %l5, ptr %t42)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l6 = alloca i1
  %l8 = alloca ptr
  %l11 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l14 = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t6 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroValue(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i1 %t6, ptr %l6
  br label %bb1
bb1:
  %t7 = load i1, ptr %l6, !tbaa !21
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/check:Checker", ptr %t8, i32 0, i32 54
  store ptr %t10, ptr %l8, !tbaa !29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i64, ptr %l1, !tbaa !24
  %t15 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %t11, i64 %t12)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t15, ptr %l11
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroName(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i32 %t20, ptr %l14
  br label %bb5
bb5:
  %t21 = load ptr, ptr %l8, !tbaa !29
  %t22 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l11
  %t23 = load i32, ptr %l14, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hc59e30334647acda8fe9b2b02a632dfd(ptr %v0, ptr %t21, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t22, i32 %t23)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i64, ptr %l1, !tbaa !24
  %t26 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroTrack(ptr %v0, ptr %v1, ptr %t24, i64 %t25, ptr %t26)
  br label %bb8
bb8:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca i64
  %l21 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca i64
  %l26 = alloca i1
  %l27 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca i1
  %l31 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l40 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l50 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i1
  %l61 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca i1
  %l70 = alloca i1
  %l71 = alloca ptr
  %l72 = alloca i1
  %l80 = alloca i1
  %l81 = alloca i1
  %l85 = alloca i1
  %l87 = alloca { i64, ptr }
  %l90 = alloca i1
  %l91 = alloca ptr
  %l92 = alloca i1
  %l95 = alloca ptr
  %l96 = alloca i1
  %l99 = alloca ptr
  %l100 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 2
  store ptr %t11, ptr %l13, !tbaa !29
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t15 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t12)
  store i32 %t15, ptr %l16
  br label %bb4
bb4:
  %t16 = load ptr, ptr %l13, !tbaa !29
  %t17 = load i32, ptr %l16, !tbaa !23
  %t18 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t16, i32 %t17)
  store i64 %t18, ptr %l17
  br label %bb5
bb5:
  %t19 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t20 = load i64, ptr %l17, !tbaa !24
  %t22 = and i64 %t20, %t19
  %t24 = icmp ne i64 %t22, 0
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l21, !tbaa !29
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v1, ptr %t27)
  store ptr %t29, ptr %l23
  br label %bb8
bb7:
  br label %bb15
bb8:
  %t30 = load ptr, ptr %l21, !tbaa !29
  %t31 = load ptr, ptr %l23, !tbaa !29
  %t32 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRoot(ptr %v0, ptr %v1, ptr %t30, ptr %t31)
  store i64 %t32, ptr %l24
  br label %bb9
bb9:
  %t33 = load i64, ptr %l24, !tbaa !24
  %t34 = icmp sge i64 %t33, 0
  br i1 %t34, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb14
bb11:
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l27, !tbaa !29
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v1, ptr %t37)
  store ptr %t39, ptr %l29
  br label %bb12
bb12:
  %t40 = load ptr, ptr %l27, !tbaa !29
  %t41 = load ptr, ptr %l29, !tbaa !29
  %t42 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroTempBase(ptr %v0, ptr %v1, ptr %t40, ptr %t41)
  store i1 %t42, ptr %l30
  br label %bb13
bb13:
  %t43 = load i1, ptr %l30, !tbaa !21
  store i1 %t43, ptr %l26, !tbaa !21
  br label %bb14
bb14:
  %t44 = load i1, ptr %l26, !tbaa !21
  store i1 %t44, ptr %rv
  br label %ret
bb15:
  %t45 = load ptr, ptr %l1, !tbaa !29
  store ptr %t45, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t46 = load ptr, ptr %l32, !tbaa !29
  %t47 = icmp ne ptr %t46, null
  br i1 %t47, label %bb16, label %bb17
bb16:
  %t49 = load ptr, ptr %l32, !tbaa !29
  %t50 = load i64, ptr %t49
  %t52 = icmp eq i64 %t50, 2
  store i1 %t52, ptr %l33, !tbaa !21
  br label %bb17
bb17:
  %t53 = load i1, ptr %l33, !tbaa !21
  br i1 %t53, label %bb18, label %bb19
bb18:
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr { i64, [5 x i64] }, ptr %t54, i32 0, i32 1
  %t57 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t56, i32 0, i32 2
  %t58 = load ptr, ptr %t57
  store ptr %t58, ptr %l2, !tbaa !29
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l2, !tbaa !29
  %t64 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRead(ptr %v0, ptr %v1, ptr %t60, ptr %t61)
  store i1 %t64, ptr %l40
  br label %bb21
bb21:
  %t65 = load i1, ptr %l40, !tbaa !21
  store i1 %t65, ptr %l31, !tbaa !21
  br label %bb76
bb22:
  %t66 = load ptr, ptr %l1, !tbaa !29
  store ptr %t66, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t67 = load ptr, ptr %l41, !tbaa !29
  %t68 = icmp ne ptr %t67, null
  br i1 %t68, label %bb23, label %bb24
bb23:
  %t70 = load ptr, ptr %l41, !tbaa !29
  %t71 = load i64, ptr %t70
  %t73 = icmp eq i64 %t71, 3
  store i1 %t73, ptr %l42, !tbaa !21
  br label %bb24
bb24:
  %t74 = load i1, ptr %l42, !tbaa !21
  br i1 %t74, label %bb25, label %bb26
bb25:
  %t75 = load ptr, ptr %l1, !tbaa !29
  %t77 = getelementptr { i64, [5 x i64] }, ptr %t75, i32 0, i32 1
  %t78 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t77, i32 0, i32 2
  %t79 = load ptr, ptr %t78
  store ptr %t79, ptr %l3, !tbaa !29
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load ptr, ptr %l3, !tbaa !29
  %t86 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroPlace(ptr %v0, ptr %v1, ptr %t81, ptr %t82)
  store i1 %t86, ptr %l50
  br label %bb28
bb28:
  %t87 = load i1, ptr %l50, !tbaa !21
  store i1 %t87, ptr %l31, !tbaa !21
  br label %bb76
bb29:
  %t88 = load ptr, ptr %l1, !tbaa !29
  store ptr %t88, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t89 = load ptr, ptr %l51, !tbaa !29
  %t90 = icmp ne ptr %t89, null
  br i1 %t90, label %bb30, label %bb31
bb30:
  %t92 = load ptr, ptr %l51, !tbaa !29
  %t93 = load i64, ptr %t92
  %t95 = icmp eq i64 %t93, 10
  store i1 %t95, ptr %l52, !tbaa !21
  br label %bb31
bb31:
  %t96 = load i1, ptr %l52, !tbaa !21
  br i1 %t96, label %bb32, label %bb33
bb32:
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr { i64, [5 x i64] }, ptr %t97, i32 0, i32 1
  %t100 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t99, i32 0, i32 2
  %t101 = load ptr, ptr %t100
  store ptr %t101, ptr %l4, !tbaa !29
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load ptr, ptr %l4, !tbaa !29
  %t106 = getelementptr %"compiler/typed:Slice", ptr %t104, i32 0, i32 0
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t111 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroPlace(ptr %v0, ptr %v1, ptr %t103, ptr %t107)
  store i1 %t111, ptr %l61
  br label %bb35
bb35:
  %t112 = load i1, ptr %l61, !tbaa !21
  store i1 %t112, ptr %l31, !tbaa !21
  br label %bb76
bb36:
  %t113 = load ptr, ptr %l1, !tbaa !29
  store ptr %t113, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t114 = load ptr, ptr %l62, !tbaa !29
  %t115 = icmp ne ptr %t114, null
  br i1 %t115, label %bb37, label %bb38
bb37:
  %t117 = load ptr, ptr %l62, !tbaa !29
  %t118 = load i64, ptr %t117
  %t120 = icmp eq i64 %t118, 6
  store i1 %t120, ptr %l63, !tbaa !21
  br label %bb38
bb38:
  %t121 = load i1, ptr %l63, !tbaa !21
  br i1 %t121, label %bb39, label %bb40
bb39:
  %t122 = load ptr, ptr %l1, !tbaa !29
  %t124 = getelementptr { i64, [5 x i64] }, ptr %t122, i32 0, i32 1
  %t125 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t124, i32 0, i32 2
  %t126 = load ptr, ptr %t125
  store ptr %t126, ptr %l5, !tbaa !29
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load ptr, ptr %l5, !tbaa !29
  %t132 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCallRef(ptr %v0, ptr %v1, ptr %t128, ptr %t129)
  store i1 %t132, ptr %l70
  br label %bb42
bb42:
  %t133 = load i1, ptr %l70, !tbaa !21
  store i1 %t133, ptr %l31, !tbaa !21
  br label %bb76
bb43:
  %t134 = load ptr, ptr %l1, !tbaa !29
  store ptr %t134, ptr %l71, !tbaa !29
  store i1 false, ptr %l72, !tbaa !21
  %t135 = load ptr, ptr %l71, !tbaa !29
  %t136 = icmp ne ptr %t135, null
  br i1 %t136, label %bb44, label %bb45
bb44:
  %t138 = load ptr, ptr %l71, !tbaa !29
  %t139 = load i64, ptr %t138
  %t141 = icmp eq i64 %t139, 9
  store i1 %t141, ptr %l72, !tbaa !21
  br label %bb45
bb45:
  %t142 = load i1, ptr %l72, !tbaa !21
  br i1 %t142, label %bb46, label %bb47
bb46:
  %t143 = load ptr, ptr %l1, !tbaa !29
  %t145 = getelementptr { i64, [5 x i64] }, ptr %t143, i32 0, i32 1
  %t146 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t145, i32 0, i32 2
  %t147 = load i32, ptr %t146
  store i32 %t147, ptr %l6
  %t149 = load ptr, ptr %l1, !tbaa !29
  %t151 = getelementptr { i64, [5 x i64] }, ptr %t149, i32 0, i32 1
  %t152 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t151, i32 0, i32 4
  %t153 = load { i64, ptr }, ptr %t152
  store { i64, ptr } %t153, ptr %l7, !tbaa !27
  br label %bb48
bb47:
  br label %bb57
bb48:
  %t155 = load i32, ptr %l6
  %t157 = call i1 @compiler_2ftyped_2ePassesRefs(i32 %t155)
  store i1 %t157, ptr %l80
  br label %bb49
bb49:
  %t158 = load i1, ptr %l80, !tbaa !21
  br i1 %t158, label %bb50, label %bb51
bb50:
  %t159 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t161 = extractvalue { i64, ptr } %t159, 0
  %t163 = icmp sgt i64 %t161, 0
  store i1 %t163, ptr %l81, !tbaa !21
  br label %bb52
bb51:
  store i1 false, ptr %l81, !tbaa !21
  br label %bb52
bb52:
  %t165 = load i1, ptr %l81, !tbaa !21
  br i1 %t165, label %bb53, label %bb54
bb53:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t167, ptr %l87, !tbaa !27
  %t168 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !27
  %t170 = getelementptr ptr, ptr %t169, i64 0
  %t171 = load ptr, ptr %t170, !tbaa !39
  %t175 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v1, ptr %t166, ptr %t171)
  store i1 %t175, ptr %l90
  br label %bb55
bb54:
  store i1 true, ptr %l85, !tbaa !21
  br label %bb56
bb55:
  %t176 = load i1, ptr %l90, !tbaa !21
  store i1 %t176, ptr %l85, !tbaa !21
  br label %bb56
bb56:
  %t177 = load i1, ptr %l85, !tbaa !21
  store i1 %t177, ptr %l31, !tbaa !21
  br label %bb76
bb57:
  %t178 = load ptr, ptr %l1, !tbaa !29
  store ptr %t178, ptr %l91, !tbaa !29
  store i1 false, ptr %l92, !tbaa !21
  %t179 = load ptr, ptr %l91, !tbaa !29
  %t180 = icmp ne ptr %t179, null
  br i1 %t180, label %bb58, label %bb59
bb58:
  %t182 = load ptr, ptr %l91, !tbaa !29
  %t183 = load i64, ptr %t182
  %t185 = icmp eq i64 %t183, 5
  store i1 %t185, ptr %l92, !tbaa !21
  br label %bb59
bb59:
  %t186 = load i1, ptr %l92, !tbaa !21
  br i1 %t186, label %bb60, label %bb61
bb60:
  br label %bb70
bb61:
  %t187 = load ptr, ptr %l1, !tbaa !29
  store ptr %t187, ptr %l95, !tbaa !29
  store i1 false, ptr %l96, !tbaa !21
  %t188 = load ptr, ptr %l95, !tbaa !29
  %t189 = icmp ne ptr %t188, null
  br i1 %t189, label %bb62, label %bb63
bb62:
  %t191 = load ptr, ptr %l95, !tbaa !29
  %t192 = load i64, ptr %t191
  %t194 = icmp eq i64 %t192, 1
  store i1 %t194, ptr %l96, !tbaa !21
  br label %bb63
bb63:
  %t195 = load i1, ptr %l96, !tbaa !21
  br i1 %t195, label %bb64, label %bb65
bb64:
  br label %bb70
bb65:
  %t196 = load ptr, ptr %l1, !tbaa !29
  store ptr %t196, ptr %l99, !tbaa !29
  store i1 false, ptr %l100, !tbaa !21
  %t197 = load ptr, ptr %l99, !tbaa !29
  %t198 = icmp ne ptr %t197, null
  br i1 %t198, label %bb66, label %bb67
bb66:
  %t200 = load ptr, ptr %l99, !tbaa !29
  %t201 = load i64, ptr %t200
  %t203 = icmp eq i64 %t201, 0
  store i1 %t203, ptr %l100, !tbaa !21
  br label %bb67
bb67:
  %t204 = load i1, ptr %l100, !tbaa !21
  br i1 %t204, label %bb68, label %bb69
bb68:
  br label %bb70
bb69:
  br label %bb71
bb70:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb76
bb71:
  br i1 true, label %bb72, label %bb73
bb72:
  br label %bb74
bb73:
  br label %bb75
bb74:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb76
bb75:
  call void @__olang_check_failed(ptr @olang_loc_62c5ac3e914a4019_8e197c98e172d865)
  unreachable
bb76:
  %t205 = load i1, ptr %l31, !tbaa !21
  store i1 %t205, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootStmts(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca %"compiler/typed:Block"
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 32
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eentryChecks(ptr %v0, ptr %t7)
  br label %bb2
bb2:
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t10)
  store ptr %t12, ptr %l9
  br label %bb3
bb3:
  %t13 = load ptr, ptr %l9, !tbaa !29
  %t15 = getelementptr %"compiler/check:frame", ptr %t13, i32 0, i32 38
  %t16 = load { i64, ptr }, ptr %l7, !tbaa !27
  call void @compiler_2fcheck_2estoredIn(ptr %v1, ptr %v0, { i64, ptr } %t16, ptr %t15)
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  %t22 = icmp sgt i64 %t20, 0
  br i1 %t22, label %bb5, label %bb6
bb5:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load { i64, ptr }, ptr %l1, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %t24, { i64, ptr } %t25)
  br label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb8
bb8:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 32
  %t31 = load i64, ptr %l2, !tbaa !24
  %t34 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t30, i64 %t31)
  store { i64, ptr } %t34, ptr %l20
  br label %bb9
bb9:
  %t35 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t36 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 0, { i64, ptr } %t35)
  store %"compiler/typed:Block" %t36, ptr %l21
  br label %bb10
bb10:
  %t37 = load %"compiler/typed:Block", ptr %l21
  %t38 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Block" %t37, ptr %t38
  store ptr %t38, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshapeErr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3, %"compiler/msgs:Msg" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l10 = alloca i64
  %l14 = alloca { i64, ptr }
  %l17 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i64
  %l26 = alloca { i64, [3 x i64] }
  %l30 = alloca %"compiler/msgs:Msg"
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load %"compiler/source:Span", ptr %l1
  %t7 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v3, ptr %t1, %"compiler/source:Span" %t2, %"compiler/msgs:Msg" %a4)
  store i64 %t7, ptr %l10
  br label %bb1
bb1:
  %t8 = load i64, ptr %l10, !tbaa !24
  store i64 %t8, ptr %l5, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/ast:Func", ptr %a2, i32 0, i32 2
  %t13 = load i32, ptr %t12, !tbaa !23
  %t16 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t9, i32 %t13)
  store { i64, ptr } %t16, ptr %l14
  br label %bb2
bb2:
  %t17 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t17, ptr %l6, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t22 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v2, { i64, ptr } %t18, { i64, ptr } %t19)
  store i1 %t22, ptr %l17
  br label %bb3
bb3:
  %t23 = load i1, ptr %l17, !tbaa !21
  %t24 = xor i1 %t23, true
  br i1 %t24, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/generic:Program", ptr %t29, i32 0, i32 0
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/load:Loader", ptr %t32, i32 0, i32 4
  %t35 = load ptr, ptr %t34, !tbaa !29
  store ptr %t35, ptr %l22, !tbaa !29
  %t36 = load i64, ptr %l5, !tbaa !24
  store i64 %t36, ptr %l23, !tbaa !24
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load %"compiler/source:Span", ptr %l1
  %t41 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t37, %"compiler/source:Span" %t38)
  store { i64, [3 x i64] } %t41, ptr %l26
  br label %bb6
bb5:
  br label %bb9
bb6:
  %t42 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t48 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteProtocolSpelling(ptr %v0, ptr %v2, ptr %v2, ptr %s1, { i64, ptr } %t42, { i64, ptr } %t43, { i64, ptr } %t44)
  store %"compiler/msgs:Msg" %t48, ptr %l30
  br label %bb7
bb7:
  %t49 = load ptr, ptr %l22, !tbaa !29
  %t50 = load i64, ptr %l23, !tbaa !24
  %t51 = load { i64, [3 x i64] }, ptr %l26
  %t52 = load %"compiler/msgs:Msg", ptr %l30
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s1, ptr %t49, i64 %t50, { i64, [3 x i64] } %t51, %"compiler/msgs:Msg" %t52)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l4 = alloca ptr
  %l7 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %a0)
  store ptr %t3, ptr %l4
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t9 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddSite(ptr %v0, ptr %t6, i32 %a1, %"compiler/source:Span" %a2)
  store i32 %t9, ptr %l7
  br label %bb2
bb2:
  %t10 = load i32, ptr %l7, !tbaa !23
  store i32 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esliceOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, ptr %a4, i32 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l26 = alloca i32
  %l31 = alloca i64
  %l34 = alloca i64
  %l54 = alloca i1
  %l62 = alloca i64
  %l65 = alloca %"compiler/source:Span"
  %l70 = alloca i32
  %l74 = alloca ptr
  %l81 = alloca i32
  %l86 = alloca i32
  %l93 = alloca i1
  %l96 = alloca i1
  %l100 = alloca ptr
  %l103 = alloca i64
  %l109 = alloca i1
  %l111 = alloca ptr
  %l112 = alloca %"compiler/source:Span"
  %l115 = alloca { i64, ptr }
  %l117 = alloca %"compiler/msgs:Msg"
  %l118 = alloca i64
  %l121 = alloca ptr
  %l124 = alloca i64
  %l127 = alloca i1
  %l134 = alloca ptr
  %l137 = alloca ptr
  %l138 = alloca ptr
  %l139 = alloca %"compiler/source:Span"
  %l141 = alloca i32
  %l142 = alloca ptr
  %l143 = alloca ptr
  %l144 = alloca ptr
  %l145 = alloca ptr
  %l147 = alloca i32
  %l148 = alloca ptr
  %l150 = alloca %"compiler/source:Span"
  %l151 = alloca ptr
  %l154 = alloca ptr
  %l155 = alloca %"compiler/source:Span"
  %l156 = alloca %"compiler/source:Span"
  %l157 = alloca i64
  %l161 = alloca ptr
  %l162 = alloca ptr
  %l165 = alloca { i64, ptr }
  %l168 = alloca { i64, ptr }
  %l172 = alloca ptr
  %l174 = alloca ptr
  %l175 = alloca ptr
  %l176 = alloca ptr
  %l178 = alloca i32
  %l179 = alloca ptr
  %l181 = alloca %"compiler/source:Span"
  %l182 = alloca ptr
  %l186 = alloca i64
  %l191 = alloca ptr
  %l195 = alloca ptr
  %l196 = alloca %"compiler/source:Span"
  %l197 = alloca %"compiler/source:Span"
  %l198 = alloca i64
  %l202 = alloca ptr
  %l203 = alloca ptr
  %l206 = alloca { i64, ptr }
  %l210 = alloca { i64, ptr }
  %l214 = alloca ptr
  %l217 = alloca ptr
  %l218 = alloca %"compiler/source:Span"
  %l220 = alloca i32
  %l221 = alloca ptr
  %l223 = alloca ptr
  %l224 = alloca ptr
  %l226 = alloca i32
  %l227 = alloca ptr
  %l231 = alloca ptr
  %l232 = alloca %"compiler/source:Span"
  %l234 = alloca i32
  %l235 = alloca i32
  %l236 = alloca %"compiler/source:Span"
  %l242 = alloca i32
  %l246 = alloca ptr
  %l248 = alloca ptr
  %l249 = alloca ptr
  %l251 = alloca i32
  %l252 = alloca ptr
  %l256 = alloca i1
  %l257 = alloca i32
  %l261 = alloca ptr
  %l266 = alloca i32
  %l269 = alloca i32
  %l274 = alloca i32
  %l275 = alloca i32
  %l276 = alloca %"compiler/source:Span"
  %l282 = alloca i32
  %l283 = alloca ptr
  %l286 = alloca ptr
  %l291 = alloca %"compiler/typed:Slice"
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca ptr
  %t100 = alloca { i64, [4 x i64] }, align 8
  %t456 = alloca { i64, [5 x i64] }, align 8
  %t559 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store i32 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a2, ptr %l6, !tbaa !29
  %t3 = load ptr, ptr %l6, !tbaa !29
  %t5 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v0, ptr %t3)
  store i32 %t5, ptr %l26
  br label %bb1
bb1:
  %t6 = load i32, ptr %l26, !tbaa !23
  store i32 %t6, ptr %l7, !tbaa !23
  %t7 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  store i64 %t7, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  store i64 4, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t9 = load i64, ptr %l10, !tbaa !24
  %t10 = load i64, ptr %l9, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = load i64, ptr %l11, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb7
bb4:
  %t19 = load i64, ptr %l10, !tbaa !24
  %t20 = load i64, ptr %l9, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l11, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l11, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l34, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l34, !tbaa !24
  store i64 %t35, ptr %l31, !tbaa !24
  br label %bb7
bb7:
  %t36 = load i64, ptr %l31, !tbaa !24
  store i64 %t36, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = load i64, ptr %l13, !tbaa !24
  %t38 = load i64, ptr %l12, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb10:
  br label %bb11
bb11:
  %t45 = load i64, ptr %l9, !tbaa !24
  %t46 = load i64, ptr %l13, !tbaa !24
  %t47 = load i64, ptr %l11, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l14, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load i32, ptr %l7, !tbaa !23
  %t59 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t55, i32 %t56)
  store i1 %t59, ptr %l54
  br label %bb12
bb12:
  %t60 = load i1, ptr %l54, !tbaa !21
  %t61 = xor i1 %t60, true
  br i1 %t61, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb14:
  br label %bb15
bb15:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullRead(ptr %v0, ptr %v0, ptr %t63, ptr %t64)
  br label %bb16
bb16:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = getelementptr %"compiler/generic:Program", ptr %t70, i32 0, i32 2
  %t73 = load i32, ptr %l7, !tbaa !23
  %t76 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t72, i32 %t73)
  store i64 %t76, ptr %l62
  br label %bb17
bb17:
  %t77 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t78 = load i64, ptr %l62, !tbaa !24
  %t80 = and i64 %t78, %t77
  store i64 %t80, ptr %l8, !tbaa !24
  %t82 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t82, ptr %l65
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 2
  %t89 = load i32, ptr %l7, !tbaa !23
  %t92 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t88, i32 %t89)
  store i32 %t92, ptr %l70
  br label %bb18
bb18:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load %"compiler/source:Span", ptr %l1
  %t95 = load ptr, ptr %l6, !tbaa !29
  %t99 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t93, %"compiler/source:Span" %t94, ptr %t95)
  store ptr %t99, ptr %l74
  br label %bb19
bb19:
  store { i64, [4 x i64] } zeroinitializer, ptr %t100
  %t101 = getelementptr { i64, [4 x i64] }, ptr %t100, i32 0, i32 0
  store i64 2, ptr %t101
  %t102 = load %"compiler/source:Span", ptr %l65
  %t103 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t102, 0
  %t104 = load i32, ptr %l70, !tbaa !23
  %t105 = insertvalue { %"compiler/source:Span", i32, ptr } %t103, i32 %t104, 1
  %t106 = load ptr, ptr %l74, !tbaa !29
  %t107 = insertvalue { %"compiler/source:Span", i32, ptr } %t105, ptr %t106, 2
  %t108 = getelementptr { i64, [4 x i64] }, ptr %t100, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t107, ptr %t108
  %t109 = load { i64, [4 x i64] }, ptr %t100
  %t111 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t109, ptr %t111
  store ptr %t111, ptr %l6, !tbaa !29
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/check:Checker", ptr %t113, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t118 = getelementptr %"compiler/generic:Program", ptr %t116, i32 0, i32 2
  %t119 = load i32, ptr %l7, !tbaa !23
  %t122 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t118, i32 %t119)
  store i32 %t122, ptr %l81
  br label %bb20
bb20:
  %t123 = load i32, ptr %l81, !tbaa !23
  store i32 %t123, ptr %l7, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb21:
  %t124 = load i64, ptr %l13, !tbaa !24
  %t126 = add i64 %t124, 1
  store i64 %t126, ptr %l13, !tbaa !24
  br label %bb8
bb22:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load i32, ptr %l7, !tbaa !23
  %t132 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t128, i32 %t129)
  store i32 %t132, ptr %l86
  br label %bb23
bb23:
  %t133 = load i32, ptr %l86, !tbaa !23
  store i32 %t133, ptr %l15, !tbaa !23
  %t134 = load i32, ptr %l15, !tbaa !23
  %t135 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t138 = icmp eq i32 %t134, %t135
  br i1 %t138, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s5
  %t140 = load i32, ptr %l7, !tbaa !23
  %t141 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t144 = icmp eq i32 %t140, %t141
  br i1 %t144, label %bb26, label %bb27
bb25:
  br label %bb102
bb26:
  store i1 true, ptr %l93, !tbaa !21
  br label %bb29
bb27:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load i32, ptr %l7, !tbaa !23
  %t150 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t146, i32 %t147)
  store i1 %t150, ptr %l96
  br label %bb28
bb28:
  %t151 = load i1, ptr %l96, !tbaa !21
  %t152 = xor i1 %t151, true
  store i1 %t152, ptr %l93, !tbaa !21
  br label %bb29
bb29:
  %t154 = load i1, ptr %l93, !tbaa !21
  br i1 %t154, label %bb30, label %bb31
bb30:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load %"compiler/source:Span", ptr %l1
  %t159 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t155, %"compiler/source:Span" %t156)
  store ptr %t159, ptr %l100
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_scope_close(ptr %s5)
  %t160 = load ptr, ptr %l100, !tbaa !29
  store ptr %t160, ptr %rv
  br label %ret
bb33:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load i32, ptr %l7, !tbaa !23
  %t165 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s5, ptr %t161, i32 %t162, { i64, ptr } { i64 5, ptr @.d23 }, i64 2)
  store i64 %t165, ptr %l103
  br label %bb34
bb34:
  %t166 = load i64, ptr %l103, !tbaa !24
  store i64 %t166, ptr %l16, !tbaa !24
  %t167 = load i64, ptr %l16, !tbaa !24
  %t169 = icmp slt i64 %t167, 0
  br i1 %t169, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s7
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load i32, ptr %l7, !tbaa !23
  %t173 = load %"compiler/source:Span", ptr %l1
  %t177 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %s7, ptr %s7, ptr %t171, i32 %t172, { i64, ptr } { i64 5, ptr @.d24 }, %"compiler/source:Span" %t173, { i64, ptr } { i64 10, ptr @.d25 }, i64 2, i1 false)
  store i1 %t177, ptr %l109
  br label %bb37
bb36:
  br label %bb45
bb37:
  %t178 = load i1, ptr %l109, !tbaa !21
  %t179 = xor i1 %t178, true
  br i1 %t179, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s8
  %t181 = load ptr, ptr %l0, !tbaa !29
  store ptr %t181, ptr %l111, !tbaa !29
  %t182 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t182, ptr %l112
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = load i32, ptr %l7, !tbaa !23
  %t187 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s8, ptr %t183, i32 %t184)
  store { i64, ptr } %t187, ptr %l115
  br label %bb40
bb39:
  br label %bb43
bb40:
  %t188 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t188, 0
  %t190 = extractvalue { i64, ptr } %t188, 1
  %t191 = mul i64 %t189, 1
  %t192 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t191)
  call void @llvm.memcpy.p0.p0.i64(ptr %t192, ptr %t190, i64 %t191, i1 false)
  %t193 = insertvalue { i64, ptr } undef, i64 %t189, 0
  %t194 = insertvalue { i64, ptr } %t193, ptr %t192, 1
  %t196 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotIndexable(ptr %s8, ptr %s8, { i64, ptr } %t194)
  store %"compiler/msgs:Msg" %t196, ptr %l117
  br label %bb41
bb41:
  %t197 = load ptr, ptr %l111, !tbaa !29
  %t198 = load %"compiler/source:Span", ptr %l112
  %t199 = load %"compiler/msgs:Msg", ptr %l117
  %t200 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s8, ptr %t197, %"compiler/source:Span" %t198, %"compiler/msgs:Msg" %t199)
  store i64 %t200, ptr %l118
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s8)
  br label %bb43
bb43:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load %"compiler/source:Span", ptr %l1
  %t205 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t201, %"compiler/source:Span" %t202)
  store ptr %t205, ptr %l121
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s5)
  %t206 = load ptr, ptr %l121, !tbaa !29
  store ptr %t206, ptr %rv
  br label %ret
bb45:
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load i32, ptr %l7, !tbaa !23
  %t211 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s5, ptr %t207, i32 %t208, { i64, ptr } { i64 3, ptr @.d26 }, i64 0)
  store i64 %t211, ptr %l124
  br label %bb46
bb46:
  %t212 = load i64, ptr %l124, !tbaa !24
  store i64 %t212, ptr %l17, !tbaa !24
  %t213 = load ptr, ptr %l4, !tbaa !29
  %t215 = icmp eq ptr %t213, null
  br i1 %t215, label %bb47, label %bb48
bb47:
  %t217 = load i64, ptr %l17, !tbaa !24
  %t219 = icmp slt i64 %t217, 0
  store i1 %t219, ptr %l127, !tbaa !21
  br label %bb49
bb48:
  store i1 false, ptr %l127, !tbaa !21
  br label %bb49
bb49:
  %t221 = load i1, ptr %l127, !tbaa !21
  br i1 %t221, label %bb50, label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s9
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t223 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s9, ptr %t222, %"compiler/source:Span" %t223, { i64, ptr } { i64 47, ptr @.d27 })
  br label %bb52
bb51:
  br label %bb54
bb52:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t227 = load %"compiler/source:Span", ptr %l1
  %t230 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t226, %"compiler/source:Span" %t227)
  store ptr %t230, ptr %l134
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s5)
  %t231 = load ptr, ptr %l134, !tbaa !29
  store ptr %t231, ptr %rv
  br label %ret
bb54:
  %t232 = load ptr, ptr %l3, !tbaa !29
  %t234 = icmp eq ptr %t232, null
  br i1 %t234, label %bb55, label %bb56
bb55:
  %t236 = load ptr, ptr %l0, !tbaa !29
  store ptr %t236, ptr %l138, !tbaa !29
  %t237 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t237, ptr %l139
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t238)
  store i32 %t240, ptr %l141
  br label %bb57
bb56:
  %t241 = load ptr, ptr %l0, !tbaa !29
  store ptr %t241, ptr %l143, !tbaa !29
  %t242 = load ptr, ptr %l0, !tbaa !29
  store ptr %t242, ptr %l144, !tbaa !29
  %t243 = load ptr, ptr %l3, !tbaa !29
  store ptr %t243, ptr %l145, !tbaa !29
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t244)
  store i32 %t246, ptr %l147
  br label %bb59
bb57:
  %t247 = load ptr, ptr %l138, !tbaa !29
  %t248 = load %"compiler/source:Span", ptr %l139
  %t249 = load i32, ptr %l141, !tbaa !23
  %t250 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t247, %"compiler/source:Span" %t248, i32 %t249, i64 0)
  store ptr %t250, ptr %l142
  br label %bb58
bb58:
  %t251 = load ptr, ptr %l142, !tbaa !29
  store ptr %t251, ptr %l137, !tbaa !29
  br label %bb63
bb59:
  %t252 = load ptr, ptr %l144, !tbaa !29
  %t253 = load ptr, ptr %l145, !tbaa !29
  %t254 = load i32, ptr %l147, !tbaa !23
  %t255 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %t252, ptr %t253, i32 %t254)
  store ptr %t255, ptr %l148
  br label %bb60
bb60:
  %t256 = load ptr, ptr %l3, !tbaa !29
  %t258 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t256)
  store %"compiler/source:Span" %t258, ptr %l150
  br label %bb61
bb61:
  %t259 = load ptr, ptr %l143, !tbaa !29
  %t260 = load ptr, ptr %l148, !tbaa !29
  %t261 = load %"compiler/source:Span", ptr %l150
  %t262 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t259, ptr %t260, %"compiler/source:Span" %t261)
  store ptr %t262, ptr %l151
  br label %bb62
bb62:
  %t263 = load ptr, ptr %l151, !tbaa !29
  store ptr %t263, ptr %l137, !tbaa !29
  br label %bb63
bb63:
  %t264 = load ptr, ptr %l137, !tbaa !29
  store ptr %t264, ptr %l18, !tbaa !29
  store ptr null, ptr %l19, !tbaa !29
  %t265 = load ptr, ptr %l4, !tbaa !29
  %t267 = icmp eq ptr %t265, null
  br i1 %t267, label %bb64, label %bb65
bb64:
  store %olang.scope zeroinitializer, ptr %s10
  %t269 = load ptr, ptr %l0, !tbaa !29
  store ptr %t269, ptr %l154, !tbaa !29
  %t270 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t270, ptr %l155
  %t271 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t271, ptr %l156
  %t272 = load i64, ptr %l17, !tbaa !24
  store i64 %t272, ptr %l157, !tbaa !24
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t274 = load %"compiler/source:Span", ptr %l1
  %t275 = load ptr, ptr %l6, !tbaa !29
  %t279 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t273, %"compiler/source:Span" %t274, ptr %t275)
  store ptr %t279, ptr %l161
  br label %bb66
bb65:
  %t280 = load ptr, ptr %l0, !tbaa !29
  store ptr %t280, ptr %l174, !tbaa !29
  %t281 = load ptr, ptr %l0, !tbaa !29
  store ptr %t281, ptr %l175, !tbaa !29
  %t282 = load ptr, ptr %l4, !tbaa !29
  store ptr %t282, ptr %l176, !tbaa !29
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t285 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t283)
  store i32 %t285, ptr %l178
  br label %bb80
bb66:
  %t286 = load ptr, ptr %l161, !tbaa !29
  store ptr %t286, ptr %l162, !tbaa !29
  %t287 = icmp sge i64 0, 0
  br i1 %t287, label %bb67, label %bb68
bb67:
  %t289 = icmp sle i64 0, 1152921504606846975
  br i1 %t289, label %bb69, label %bb70
bb68:
  call void @__olang_check_failed(ptr @olang_loc_5aa0e1f55b10e6f_53045464d54dc2fb)
  unreachable
bb69:
  %t291 = mul i64 0, 8
  %t292 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t291)
  %t293 = insertvalue { i64, ptr } undef, i64 0, 0
  %t294 = insertvalue { i64, ptr } %t293, ptr %t292, 1
  store { i64, ptr } %t294, ptr %l165, !tbaa !27
  %t295 = icmp sge i64 0, 0
  br i1 %t295, label %bb71, label %bb72
bb70:
  call void @__olang_check_failed(ptr @olang_loc_5aa0e1f55b10e6f_53045464d54dc2fb)
  unreachable
bb71:
  %t297 = icmp sle i64 0, 1152921504606846975
  br i1 %t297, label %bb73, label %bb74
bb72:
  call void @__olang_check_failed(ptr @olang_loc_5aa0e1f55b10e6f_53045464d54dc2fb)
  unreachable
bb73:
  %t299 = mul i64 0, 8
  %t300 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t299)
  %t301 = insertvalue { i64, ptr } undef, i64 0, 0
  %t302 = insertvalue { i64, ptr } %t301, ptr %t300, 1
  store { i64, ptr } %t302, ptr %l168, !tbaa !27
  %t303 = icmp sge i64 0, 0
  br i1 %t303, label %bb75, label %bb76
bb74:
  call void @__olang_check_failed(ptr @olang_loc_5aa0e1f55b10e6f_53045464d54dc2fb)
  unreachable
bb75:
  %t305 = icmp sle i64 0, 2305843009213693951
  br i1 %t305, label %bb77, label %bb78
bb76:
  call void @__olang_check_failed(ptr @olang_loc_e4f33d7277813d9a_8adeed4fca551266)
  unreachable
bb77:
  %t307 = mul i64 0, 4
  %t308 = call ptr @__olang_scope_alloc_zeroed(ptr %s10, i64 %t307)
  %t309 = insertvalue { i64, ptr } undef, i64 0, 0
  %t310 = insertvalue { i64, ptr } %t309, ptr %t308, 1
  %t311 = load ptr, ptr %l154, !tbaa !29
  %t312 = load %"compiler/source:Span", ptr %l155
  %t313 = load %"compiler/source:Span", ptr %l156
  %t314 = load i64, ptr %l157, !tbaa !24
  %t315 = load ptr, ptr %l162, !tbaa !29
  %t316 = load { i64, ptr }, ptr %l165, !tbaa !27
  %t317 = load { i64, ptr }, ptr %l168, !tbaa !27
  %t319 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %s10, ptr %t311, %"compiler/source:Span" %t312, %"compiler/source:Span" %t313, i64 %t314, ptr %t315, { i64, ptr } %t316, { i64, ptr } %t317, { i64, ptr } %t310)
  store ptr %t319, ptr %l172
  br label %bb79
bb78:
  call void @__olang_check_failed(ptr @olang_loc_e4f33d7277813d9a_8adeed4fca551266)
  unreachable
bb79:
  %t320 = load ptr, ptr %l172, !tbaa !29
  store ptr %t320, ptr %l19, !tbaa !29
  call void @__olang_scope_close(ptr %s10)
  br label %bb84
bb80:
  %t322 = load ptr, ptr %l175, !tbaa !29
  %t323 = load ptr, ptr %l176, !tbaa !29
  %t324 = load i32, ptr %l178, !tbaa !23
  %t325 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v2, ptr %t322, ptr %t323, i32 %t324)
  store ptr %t325, ptr %l179
  br label %bb81
bb81:
  %t326 = load ptr, ptr %l4, !tbaa !29
  %t328 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t326)
  store %"compiler/source:Span" %t328, ptr %l181
  br label %bb82
bb82:
  %t329 = load ptr, ptr %l174, !tbaa !29
  %t330 = load ptr, ptr %l179, !tbaa !29
  %t331 = load %"compiler/source:Span", ptr %l181
  %t332 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t329, ptr %t330, %"compiler/source:Span" %t331)
  store ptr %t332, ptr %l182
  br label %bb83
bb83:
  %t333 = load ptr, ptr %l182, !tbaa !29
  store ptr %t333, ptr %l19, !tbaa !29
  br label %bb84
bb84:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t337 = getelementptr %"compiler/check:Checker", ptr %t335, i32 0, i32 31
  %t339 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t337)
  store i64 %t339, ptr %l186
  br label %bb85
bb85:
  %t340 = load i64, ptr %l186, !tbaa !24
  store i64 %t340, ptr %l20, !tbaa !24
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t343 = getelementptr %"compiler/check:Checker", ptr %t341, i32 0, i32 31
  %t344 = load ptr, ptr %l18, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t343, ptr %t344)
  br label %bb86
bb86:
  %t347 = load ptr, ptr %l0, !tbaa !29
  %t349 = getelementptr %"compiler/check:Checker", ptr %t347, i32 0, i32 31
  store ptr %t349, ptr %l191, !tbaa !29
  %t350 = load ptr, ptr %l19, !tbaa !29
  %t352 = icmp eq ptr %t350, null
  br i1 %t352, label %bb87, label %bb88
bb87:
  call void @__olang_check_failed(ptr @olang_loc_b203c9fbf4c249fb_735051f472c86bf)
  unreachable
bb88:
  br label %bb89
bb89:
  %t354 = load ptr, ptr %l19, !tbaa !29
  %t355 = load ptr, ptr %l191, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t355, ptr %t354)
  br label %bb90
bb90:
  %t357 = load ptr, ptr %l0, !tbaa !29
  store ptr %t357, ptr %l195, !tbaa !29
  %t358 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t358, ptr %l196
  %t359 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t359, ptr %l197
  %t360 = load i64, ptr %l16, !tbaa !24
  store i64 %t360, ptr %l198, !tbaa !24
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t362 = load %"compiler/source:Span", ptr %l1
  %t363 = load ptr, ptr %l6, !tbaa !29
  %t367 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t361, %"compiler/source:Span" %t362, ptr %t363)
  store ptr %t367, ptr %l202
  br label %bb91
bb91:
  %t368 = load ptr, ptr %l202, !tbaa !29
  store ptr %t368, ptr %l203, !tbaa !29
  %t369 = icmp sge i64 0, 0
  br i1 %t369, label %bb92, label %bb93
bb92:
  %t371 = icmp sle i64 0, 1152921504606846975
  br i1 %t371, label %bb94, label %bb95
bb93:
  call void @__olang_check_failed(ptr @olang_loc_85a2f2931038d80c_e5a946dd8e187d18)
  unreachable
bb94:
  %t373 = mul i64 0, 8
  %t374 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t373)
  %t375 = insertvalue { i64, ptr } undef, i64 0, 0
  %t376 = insertvalue { i64, ptr } %t375, ptr %t374, 1
  store { i64, ptr } %t376, ptr %l206, !tbaa !27
  %t377 = load ptr, ptr %l0, !tbaa !29
  %t379 = getelementptr %"compiler/check:Checker", ptr %t377, i32 0, i32 31
  %t380 = load i64, ptr %l20, !tbaa !24
  %t383 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t379, i64 %t380)
  store { i64, ptr } %t383, ptr %l210
  br label %bb96
bb95:
  call void @__olang_check_failed(ptr @olang_loc_85a2f2931038d80c_e5a946dd8e187d18)
  unreachable
bb96:
  %t384 = icmp sge i64 0, 0
  br i1 %t384, label %bb97, label %bb98
bb97:
  %t386 = icmp sle i64 0, 2305843009213693951
  br i1 %t386, label %bb99, label %bb100
bb98:
  call void @__olang_check_failed(ptr @olang_loc_e4f33d7277813d9a_8adeed4fca551266)
  unreachable
bb99:
  %t388 = mul i64 0, 4
  %t389 = call ptr @__olang_scope_alloc_zeroed(ptr %s5, i64 %t388)
  %t390 = insertvalue { i64, ptr } undef, i64 0, 0
  %t391 = insertvalue { i64, ptr } %t390, ptr %t389, 1
  %t392 = load ptr, ptr %l195, !tbaa !29
  %t393 = load %"compiler/source:Span", ptr %l196
  %t394 = load %"compiler/source:Span", ptr %l197
  %t395 = load i64, ptr %l198, !tbaa !24
  %t396 = load ptr, ptr %l203, !tbaa !29
  %t397 = load { i64, ptr }, ptr %l206, !tbaa !27
  %t398 = load { i64, ptr }, ptr %l210, !tbaa !27
  %t400 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %s5, ptr %t392, %"compiler/source:Span" %t393, %"compiler/source:Span" %t394, i64 %t395, ptr %t396, { i64, ptr } %t397, { i64, ptr } %t398, { i64, ptr } %t391)
  store ptr %t400, ptr %l214
  br label %bb101
bb100:
  call void @__olang_check_failed(ptr @olang_loc_e4f33d7277813d9a_8adeed4fca551266)
  unreachable
bb101:
  call void @__olang_scope_close(ptr %s5)
  %t401 = load ptr, ptr %l214, !tbaa !29
  store ptr %t401, ptr %rv
  br label %ret
bb102:
  store ptr null, ptr %l21, !tbaa !29
  %t402 = load ptr, ptr %l3, !tbaa !29
  %t404 = icmp eq ptr %t402, null
  br i1 %t404, label %bb103, label %bb104
bb103:
  %t406 = load ptr, ptr %l0, !tbaa !29
  store ptr %t406, ptr %l217, !tbaa !29
  %t407 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t407, ptr %l218
  %t408 = load ptr, ptr %l0, !tbaa !29
  %t410 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t408)
  store i32 %t410, ptr %l220
  br label %bb105
bb104:
  %t411 = load ptr, ptr %l0, !tbaa !29
  store ptr %t411, ptr %l223, !tbaa !29
  %t412 = load ptr, ptr %l3, !tbaa !29
  store ptr %t412, ptr %l224, !tbaa !29
  %t413 = load ptr, ptr %l0, !tbaa !29
  %t415 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t413)
  store i32 %t415, ptr %l226
  br label %bb107
bb105:
  %t416 = load ptr, ptr %l217, !tbaa !29
  %t417 = load %"compiler/source:Span", ptr %l218
  %t418 = load i32, ptr %l220, !tbaa !23
  %t419 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t416, %"compiler/source:Span" %t417, i32 %t418, i64 0)
  store ptr %t419, ptr %l221
  br label %bb106
bb106:
  %t420 = load ptr, ptr %l221, !tbaa !29
  store ptr %t420, ptr %l21, !tbaa !29
  br label %bb109
bb107:
  %t422 = load ptr, ptr %l223, !tbaa !29
  %t423 = load ptr, ptr %l224, !tbaa !29
  %t424 = load i32, ptr %l226, !tbaa !23
  %t425 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %t422, ptr %t423, i32 %t424)
  store ptr %t425, ptr %l227
  br label %bb108
bb108:
  %t426 = load ptr, ptr %l227, !tbaa !29
  store ptr %t426, ptr %l21, !tbaa !29
  br label %bb109
bb109:
  store ptr null, ptr %l22, !tbaa !29
  %t428 = load ptr, ptr %l4, !tbaa !29
  %t430 = icmp eq ptr %t428, null
  br i1 %t430, label %bb110, label %bb111
bb110:
  %t432 = load ptr, ptr %l0, !tbaa !29
  store ptr %t432, ptr %l231, !tbaa !29
  %t433 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t433, ptr %l232
  %t434 = load ptr, ptr %l0, !tbaa !29
  %t436 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t434)
  store i32 %t436, ptr %l234
  br label %bb112
bb111:
  %t437 = load ptr, ptr %l0, !tbaa !29
  store ptr %t437, ptr %l248, !tbaa !29
  %t438 = load ptr, ptr %l4, !tbaa !29
  store ptr %t438, ptr %l249, !tbaa !29
  %t439 = load ptr, ptr %l0, !tbaa !29
  %t441 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t439)
  store i32 %t441, ptr %l251
  br label %bb115
bb112:
  store i32 22, ptr %l235
  %t442 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t442, ptr %l236
  %t443 = load ptr, ptr %l0, !tbaa !29
  %t445 = getelementptr %"compiler/check:Checker", ptr %t443, i32 0, i32 1
  %t446 = load ptr, ptr %t445, !tbaa !29
  %t448 = getelementptr %"compiler/generic:Program", ptr %t446, i32 0, i32 2
  %t449 = load i32, ptr %l7, !tbaa !23
  %t450 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t454 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t448, i32 %t449, i64 %t450)
  store i32 %t454, ptr %l242
  br label %bb113
bb113:
  %t455 = load ptr, ptr %l6, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t456
  %t457 = getelementptr { i64, [5 x i64] }, ptr %t456, i32 0, i32 0
  store i64 3, ptr %t457
  %t458 = load %"compiler/source:Span", ptr %l236
  %t459 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t458, 0
  %t460 = load i32, ptr %l242, !tbaa !23
  %t461 = insertvalue { %"compiler/source:Span", i32, ptr } %t459, i32 %t460, 1
  %t463 = insertvalue { %"compiler/source:Span", i32, ptr } %t461, ptr %t455, 2
  %t464 = getelementptr { i64, [5 x i64] }, ptr %t456, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t463, ptr %t464
  %t465 = load { i64, [5 x i64] }, ptr %t456
  %t467 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t465, ptr %t467
  %t468 = load ptr, ptr %l231, !tbaa !29
  %t469 = load %"compiler/source:Span", ptr %l232
  %t470 = load i32, ptr %l234, !tbaa !23
  %t471 = load i32, ptr %l235
  %t473 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t468, %"compiler/source:Span" %t469, i32 %t470, i32 %t471, ptr %t467, ptr null)
  store ptr %t473, ptr %l246
  br label %bb114
bb114:
  %t474 = load ptr, ptr %l246, !tbaa !29
  store ptr %t474, ptr %l22, !tbaa !29
  br label %bb117
bb115:
  %t476 = load ptr, ptr %l248, !tbaa !29
  %t477 = load ptr, ptr %l249, !tbaa !29
  %t478 = load i32, ptr %l251, !tbaa !23
  %t479 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v2, ptr %t476, ptr %t477, i32 %t478)
  store ptr %t479, ptr %l252
  br label %bb116
bb116:
  %t480 = load ptr, ptr %l252, !tbaa !29
  store ptr %t480, ptr %l22, !tbaa !29
  br label %bb117
bb117:
  %t482 = load ptr, ptr %l0, !tbaa !29
  %t483 = load i32, ptr %l7, !tbaa !23
  %t486 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t482, i32 %t483)
  store i1 %t486, ptr %l256
  br label %bb118
bb118:
  %t487 = load i1, ptr %l256, !tbaa !21
  br i1 %t487, label %bb119, label %bb120
bb119:
  %t488 = load i32, ptr %l7, !tbaa !23
  store i32 %t488, ptr %l257, !tbaa !23
  br label %bb127
bb120:
  %t490 = load ptr, ptr %l0, !tbaa !29
  %t492 = getelementptr %"compiler/check:Checker", ptr %t490, i32 0, i32 1
  %t493 = load ptr, ptr %t492, !tbaa !29
  %t495 = getelementptr %"compiler/generic:Program", ptr %t493, i32 0, i32 2
  store ptr %t495, ptr %l261, !tbaa !29
  %t496 = load ptr, ptr %l0, !tbaa !29
  %t498 = getelementptr %"compiler/check:Checker", ptr %t496, i32 0, i32 1
  %t499 = load ptr, ptr %t498, !tbaa !29
  %t501 = getelementptr %"compiler/generic:Program", ptr %t499, i32 0, i32 2
  %t502 = load i32, ptr %l15, !tbaa !23
  %t505 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t501, i32 %t502)
  store i32 %t505, ptr %l266
  br label %bb121
bb121:
  %t506 = load i32, ptr %l5
  %t508 = trunc i64 1 to i32
  %t509 = icmp eq i32 %t506, %t508
  br i1 %t509, label %bb122, label %bb123
bb122:
  %t511 = load ptr, ptr %l0, !tbaa !29
  %t512 = load i32, ptr %l15, !tbaa !23
  %t513 = load ptr, ptr %l3, !tbaa !29
  %t514 = load ptr, ptr %l4, !tbaa !29
  %t519 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esliceLength(ptr %v0, ptr %v1, ptr %v2, ptr %t511, i32 %t512, ptr %t513, ptr %t514)
  store i32 %t519, ptr %l274
  br label %bb124
bb123:
  store i32 0, ptr %l269, !tbaa !23
  br label %bb125
bb124:
  %t520 = load i32, ptr %l274, !tbaa !23
  store i32 %t520, ptr %l269, !tbaa !23
  br label %bb125
bb125:
  %t521 = load ptr, ptr %l261, !tbaa !29
  %t522 = load i32, ptr %l266, !tbaa !23
  %t523 = load i32, ptr %l269, !tbaa !23
  %t524 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t521, i32 %t522, i32 %t523)
  store i32 %t524, ptr %l275
  br label %bb126
bb126:
  %t525 = load i32, ptr %l275, !tbaa !23
  store i32 %t525, ptr %l257, !tbaa !23
  br label %bb127
bb127:
  %t526 = load i32, ptr %l257, !tbaa !23
  %t527 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t527, ptr %l276
  %t528 = load ptr, ptr %l0, !tbaa !29
  %t530 = getelementptr %"compiler/check:Checker", ptr %t528, i32 0, i32 1
  %t531 = load ptr, ptr %t530, !tbaa !29
  %t533 = getelementptr %"compiler/generic:Program", ptr %t531, i32 0, i32 2
  %t535 = load i64, ptr %l8, !tbaa !24
  %t539 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t533, i32 %t526, i64 %t535)
  store i32 %t539, ptr %l282
  br label %bb128
bb128:
  %t540 = load ptr, ptr %l6, !tbaa !29
  store ptr %t540, ptr %l283, !tbaa !29
  %t541 = load ptr, ptr %l21, !tbaa !29
  %t543 = icmp eq ptr %t541, null
  br i1 %t543, label %bb129, label %bb130
bb129:
  call void @__olang_check_failed(ptr @olang_loc_2f1aad6b95023edd_c82f5ce971f0d619)
  unreachable
bb130:
  br label %bb131
bb131:
  %t545 = load ptr, ptr %l21, !tbaa !29
  store ptr %t545, ptr %l286, !tbaa !29
  %t546 = load ptr, ptr %l22, !tbaa !29
  %t548 = icmp eq ptr %t546, null
  br i1 %t548, label %bb132, label %bb133
bb132:
  call void @__olang_check_failed(ptr @olang_loc_2f1aad6b95023edd_c82f5ce971f0d619)
  unreachable
bb133:
  br label %bb134
bb134:
  %t550 = load ptr, ptr %l22, !tbaa !29
  %t551 = load i32, ptr %l5
  %t552 = load ptr, ptr %l283, !tbaa !29
  %t553 = load ptr, ptr %l286, !tbaa !29
  %t556 = call %"compiler/typed:Slice" @compiler_2ftyped_3aSlice_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t552, ptr %t553, ptr %t550, i32 %t551)
  store %"compiler/typed:Slice" %t556, ptr %l291
  br label %bb135
bb135:
  %t557 = load %"compiler/typed:Slice", ptr %l291
  %t558 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/typed:Slice" %t557, ptr %t558
  store { i64, [5 x i64] } zeroinitializer, ptr %t559
  %t560 = getelementptr { i64, [5 x i64] }, ptr %t559, i32 0, i32 0
  store i64 10, ptr %t560
  %t561 = load %"compiler/source:Span", ptr %l276
  %t562 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t561, 0
  %t563 = load i32, ptr %l282, !tbaa !23
  %t564 = insertvalue { %"compiler/source:Span", i32, ptr } %t562, i32 %t563, 1
  %t566 = insertvalue { %"compiler/source:Span", i32, ptr } %t564, ptr %t558, 2
  %t567 = getelementptr { i64, [5 x i64] }, ptr %t559, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t566, ptr %t567
  %t568 = load { i64, [5 x i64] }, ptr %t559
  %t570 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t568, ptr %t570
  store ptr %t570, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estrBytes(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
  store { i64, ptr } %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t7 = call { i64, ptr } @compiler_2fscan_2eLiteralBytes(ptr %v0, ptr %v0, { i64, ptr } %t6)
  store { i64, ptr } %t7, ptr %l5
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  %t10 = extractvalue { i64, ptr } %t8, 1
  %t11 = mul i64 %t9, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t10, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etaskDefault(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l9 = alloca ptr
  %l12 = alloca i1
  %l13 = alloca i1
  %l18 = alloca i1
  %l22 = alloca %"compiler/source:Span"
  %l25 = alloca ptr
  %l26 = alloca %"compiler/source:Span"
  %l27 = alloca %"compiler/msgs:Msg"
  %l28 = alloca i64
  %l29 = alloca ptr
  %l31 = alloca %"compiler/source:Span"
  %l32 = alloca ptr
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l35 = alloca i32
  %l38 = alloca %"compiler/source:Span"
  %l39 = alloca ptr
  %s2 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i32, ptr %l2, !tbaa !23
  %t8 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t1, ptr %t2, i32 %t4)
  store ptr %t8, ptr %l9
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l9, !tbaa !29
  store ptr %t9, ptr %l3, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l2, !tbaa !23
  %t14 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t10, i32 %t11)
  store i1 %t14, ptr %l12
  br label %bb2
bb2:
  %t15 = load i1, ptr %l12, !tbaa !21
  br i1 %t15, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb6
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %l2, !tbaa !23
  %t25 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t21, i32 %t22)
  store i1 %t25, ptr %l18
  br label %bb5
bb5:
  %t26 = load i1, ptr %l18, !tbaa !21
  store i1 %t26, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l13, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t33 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexistingIn(ptr %v0, ptr %v0, ptr %t28, ptr %t29)
  store %"compiler/source:Span" %t33, ptr %l22
  br label %bb9
bb8:
  br label %bb17
bb9:
  %t34 = load %"compiler/source:Span", ptr %l22
  store %"compiler/source:Span" %t34, ptr %l4
  %t35 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 0
  %t36 = load i32, ptr %t35, !tbaa !23
  %t38 = icmp sge i32 %t36, 0
  br i1 %t38, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l25, !tbaa !29
  %t41 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t41, ptr %l26
  %t42 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskDefaultExisting(ptr %s2)
  store %"compiler/msgs:Msg" %t42, ptr %l27
  br label %bb12
bb11:
  br label %bb16
bb12:
  %t43 = load ptr, ptr %l25, !tbaa !29
  %t44 = load %"compiler/source:Span", ptr %l26
  %t45 = load %"compiler/msgs:Msg", ptr %l27
  %t46 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t43, %"compiler/source:Span" %t44, %"compiler/msgs:Msg" %t45)
  store i64 %t46, ptr %l28
  br label %bb13
bb13:
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l29, !tbaa !29
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t48)
  store %"compiler/source:Span" %t50, ptr %l31
  br label %bb14
bb14:
  %t51 = load ptr, ptr %l29, !tbaa !29
  %t52 = load %"compiler/source:Span", ptr %l31
  %t53 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t51, %"compiler/source:Span" %t52)
  store ptr %t53, ptr %l32
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  %t54 = load ptr, ptr %l32, !tbaa !29
  store ptr %t54, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l33, !tbaa !29
  %t56 = load ptr, ptr %l3, !tbaa !29
  store ptr %t56, ptr %l34, !tbaa !29
  %t57 = load i32, ptr %l2, !tbaa !23
  store i32 %t57, ptr %l35, !tbaa !23
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t62 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargSpan(ptr %v0, ptr %v1, ptr %t58, ptr %t59)
  store %"compiler/source:Span" %t62, ptr %l38
  br label %bb18
bb18:
  %t63 = load ptr, ptr %l33, !tbaa !29
  %t64 = load ptr, ptr %l34, !tbaa !29
  %t65 = load i32, ptr %l35, !tbaa !23
  %t66 = load %"compiler/source:Span", ptr %l38
  %t67 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t63, ptr %t64, i32 %t65, %"compiler/source:Span" %t66)
  store ptr %t67, ptr %l39
  br label %bb19
bb19:
  %t68 = load ptr, ptr %l39, !tbaa !29
  store ptr %t68, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etestBody(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/source:Span"
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l10 = alloca { i64, [2 x i64] }
  %l15 = alloca i32
  %l18 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l29 = alloca %"compiler/generic:Context"
  %l32 = alloca ptr
  %l35 = alloca i32
  %l38 = alloca ptr
  %l40 = alloca ptr
  %t3 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t3
  %t4 = getelementptr { i64, [2 x i64] }, ptr %t3, i32 0, i32 0
  store i64 5, ptr %t4
  %t6 = insertvalue { i64 } undef, i64 %a4, 0
  %t7 = getelementptr { i64, [2 x i64] }, ptr %t3, i32 0, i32 1
  store { i64 } %t6, ptr %t7
  %t8 = load { i64, [2 x i64] }, ptr %t3
  store { i64, [2 x i64] } %t8, ptr %l10
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/generic:Program", ptr %t12, i32 0, i32 2
  %t15 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t14, i32 0, i32 %t15, i32 0, i32 0, i64 0)
  store i32 %t18, ptr %l15
  br label %bb1
bb1:
  %t19 = load i64, ptr %l1, !tbaa !24
  %t20 = load %"compiler/source:Span", ptr %l2
  %t21 = load ptr, ptr %l8, !tbaa !29
  %t22 = load { i64, [2 x i64] }, ptr %l10
  %t23 = load i32, ptr %l15, !tbaa !23
  %t26 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t21, { i64, [2 x i64] } %t22, i32 %t23, i64 %t19, %"compiler/source:Span" %t20)
  store i64 %t26, ptr %l18
  br label %bb2
bb2:
  %t27 = load i64, ptr %l18, !tbaa !24
  store i64 %t27, ptr %l5, !tbaa !24
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 15
  %t31 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t30, i64 %t31, i64 1)
  br label %bb3
bb3:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i64, ptr %l5, !tbaa !24
  %t36 = load i64, ptr %l1, !tbaa !24
  %t37 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t42 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %t34, i64 %t35, i64 %t36, i32 %t37, i32 0)
  store ptr %t42, ptr %l26
  br label %bb4
bb4:
  %t43 = load ptr, ptr %l26, !tbaa !29
  store ptr %t43, ptr %l6, !tbaa !29
  %t44 = load ptr, ptr %l6, !tbaa !29
  store ptr %t44, ptr %l27, !tbaa !29
  %t45 = load i64, ptr %l1, !tbaa !24
  %t47 = call %"compiler/generic:Context" @compiler_2fgeneric_3aContext_2ector(ptr %v0, i64 %t45, i64 -1)
  store %"compiler/generic:Context" %t47, ptr %l29
  br label %bb5
bb5:
  %t48 = load %"compiler/generic:Context", ptr %l29
  %t49 = load ptr, ptr %l27, !tbaa !29
  %t50 = getelementptr %"compiler/check:frame", ptr %t49, i32 0, i32 4
  store %"compiler/generic:Context" %t48, ptr %t50
  %t51 = load ptr, ptr %l6, !tbaa !29
  %t53 = getelementptr %"compiler/check:frame", ptr %t51, i32 0, i32 12
  store i1 true, ptr %t53, !tbaa !21
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t54)
  store ptr %t56, ptr %l32
  br label %bb6
bb6:
  %t57 = load %"compiler/source:Span", ptr %l2
  %t58 = load ptr, ptr %l32, !tbaa !29
  %t61 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %t58, i32 -1, i32 0, %"compiler/source:Span" %t57)
  store i32 %t61, ptr %l35
  br label %bb7
bb7:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t66 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootStmts(ptr %v0, ptr %v1, ptr %t62, { i64, ptr } %a3)
  store ptr %t66, ptr %l38
  br label %bb8
bb8:
  %t67 = load ptr, ptr %l38, !tbaa !29
  store ptr %t67, ptr %l7, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t68)
  store ptr %t70, ptr %l40
  br label %bb9
bb9:
  %t71 = load ptr, ptr %l40, !tbaa !29
  %t72 = load ptr, ptr %l7, !tbaa !29
  %t76 = getelementptr %"compiler/typed:Body", ptr %t71, i32 0, i32 11
  store ptr %t72, ptr %t76, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t77)
  br label %bb10
bb10:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t79, i32 0, i32 15
  %t82 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t81, i64 %t82, i64 2)
  br label %bb11
bb11:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l7 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 3
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t14 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t10, i32 %a1)
  store { i64, ptr } %t14, ptr %l7
  br label %bb1
bb1:
  %t15 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t15, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeContexts(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca %"compiler/generic:Origin"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l16 = alloca %"compiler/generic:Origin"
  %l19 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca { i64, ptr }
  %l28 = alloca i1
  %l32 = alloca i1
  %l35 = alloca i1
  %l43 = alloca i64
  %l46 = alloca i64
  %l47 = alloca %"std/prelude/text:StringBuilder"
  %l54 = alloca i64
  %l57 = alloca i64
  %l80 = alloca ptr
  %l83 = alloca { i64, ptr }
  %l84 = alloca ptr
  %l87 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l93 = alloca ptr
  %l95 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l105 = alloca ptr
  %l111 = alloca { i64, [3 x i64] }
  %l113 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i64
  %t207 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  %t8 = call %"compiler/generic:Origin" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeOrigin(ptr %v0, ptr %t4, i32 %t5)
  store %"compiler/generic:Origin" %t8, ptr %l16
  br label %bb1
bb1:
  %t9 = load %"compiler/generic:Origin", ptr %l16
  store %"compiler/generic:Origin" %t9, ptr %l3
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  store ptr %t15, ptr %l19, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %l1, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l24
  br label %bb2
bb2:
  %t26 = load ptr, ptr %l19, !tbaa !29
  %t27 = load i32, ptr %l24, !tbaa !23
  %t28 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t26, i32 %t27)
  store { i64, ptr } %t28, ptr %l25
  br label %bb3
bb3:
  %t29 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t29, ptr %l4, !tbaa !27
  %t30 = getelementptr %"compiler/generic:Origin", ptr %l3, i32 0, i32 0
  %t31 = load i64, ptr %t30, !tbaa !24
  %t33 = icmp slt i64 %t31, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb6
bb5:
  %t35 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t39 = icmp eq i64 %t37, 0
  store i1 %t39, ptr %l28, !tbaa !21
  br label %bb6
bb6:
  %t41 = load i1, ptr %l28, !tbaa !21
  br i1 %t41, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb9
bb8:
  %t42 = load ptr, ptr %l2, !tbaa !29
  %t44 = icmp eq ptr %t42, null
  store i1 %t44, ptr %l32, !tbaa !21
  br label %bb9
bb9:
  %t46 = load i1, ptr %l32, !tbaa !21
  br i1 %t46, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb12
bb11:
  %t47 = load ptr, ptr %l2, !tbaa !29
  %t49 = getelementptr %"compiler/ast:TypeDecl", ptr %t47, i32 0, i32 1
  %t50 = load { i64, ptr }, ptr %t49, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t50, 0
  %t54 = icmp eq i64 %t52, 0
  store i1 %t54, ptr %l35, !tbaa !21
  br label %bb12
bb12:
  %t56 = load i1, ptr %l35, !tbaa !21
  br i1 %t56, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  store i64 0, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t58 = getelementptr %"compiler/generic:Origin", ptr %l3, i32 0, i32 2
  %t59 = load i64, ptr %t58, !tbaa !24
  %t61 = icmp sge i64 %t59, 0
  br i1 %t61, label %bb16, label %bb17
bb16:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Origin", ptr %l3, i32 0, i32 2
  %t65 = load i64, ptr %t64, !tbaa !24
  %t68 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstContexts(ptr %v0, ptr %t63, i64 %t65)
  store i64 %t68, ptr %l46
  br label %bb18
bb17:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb19
bb18:
  %t69 = load i64, ptr %l46, !tbaa !24
  store i64 %t69, ptr %l43, !tbaa !24
  br label %bb19
bb19:
  %t70 = load i64, ptr %l43, !tbaa !24
  store i64 %t70, ptr %l5, !tbaa !24
  %t71 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t71, ptr %l47
  br label %bb20
bb20:
  %t72 = load %"std/prelude/text:StringBuilder", ptr %l47
  store %"std/prelude/text:StringBuilder" %t72, ptr %l6
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } { i64 17, ptr @.d28 })
  br label %bb21
bb21:
  store i64 0, ptr %l7, !tbaa !24
  %t74 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t74, 0
  store i64 %t76, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t78 = load i64, ptr %l8, !tbaa !24
  %t79 = load i64, ptr %l7, !tbaa !24
  %t82 = icmp sgt i64 %t78, %t79
  br i1 %t82, label %bb22, label %bb23
bb22:
  %t84 = load i64, ptr %l9, !tbaa !24
  %t86 = icmp sgt i64 %t84, 0
  br i1 %t86, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb27
bb24:
  %t88 = load i64, ptr %l8, !tbaa !24
  %t89 = load i64, ptr %l7, !tbaa !24
  %t92 = sub i64 %t88, %t89
  %t93 = load i64, ptr %l9, !tbaa !24
  %t96 = add i64 %t92, %t93
  %t98 = sub i64 %t96, 1
  %t99 = load i64, ptr %l9, !tbaa !24
  %t102 = sdiv i64 %t98, %t99
  store i64 %t102, ptr %l57, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l57, !tbaa !24
  br label %bb26
bb26:
  %t104 = load i64, ptr %l57, !tbaa !24
  store i64 %t104, ptr %l54, !tbaa !24
  br label %bb27
bb27:
  %t105 = load i64, ptr %l54, !tbaa !24
  store i64 %t105, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s3
  %t106 = load i64, ptr %l11, !tbaa !24
  %t107 = load i64, ptr %l10, !tbaa !24
  %t110 = icmp slt i64 %t106, %t107
  %t112 = xor i1 %t110, true
  br i1 %t112, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s3)
  br label %bb45
bb30:
  br label %bb31
bb31:
  %t114 = load i64, ptr %l7, !tbaa !24
  %t115 = load i64, ptr %l11, !tbaa !24
  %t116 = load i64, ptr %l9, !tbaa !24
  %t119 = mul i64 %t115, %t116
  %t122 = add i64 %t114, %t119
  store i64 %t122, ptr %l12, !tbaa !24
  %t124 = load i64, ptr %l12, !tbaa !24
  %t125 = load ptr, ptr %l2, !tbaa !29
  %t127 = getelementptr %"compiler/ast:TypeDecl", ptr %t125, i32 0, i32 1
  %t128 = load { i64, ptr }, ptr %t127, !tbaa !27
  %t130 = extractvalue { i64, ptr } %t128, 0
  %t133 = icmp sge i64 %t124, %t130
  br i1 %t133, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s3)
  br label %bb45
bb33:
  br label %bb34
bb34:
  store ptr %l6, ptr %l80, !tbaa !29
  %t135 = load i64, ptr %l12, !tbaa !24
  %t137 = icmp eq i64 %t135, 0
  br i1 %t137, label %bb35, label %bb36
bb35:
  store { i64, ptr } { i64 7, ptr @.d29 }, ptr %l83, !tbaa !27
  br label %bb37
bb36:
  store { i64, ptr } { i64 2, ptr @.d30 }, ptr %l83, !tbaa !27
  br label %bb37
bb37:
  %t139 = load ptr, ptr %l80, !tbaa !29
  %t140 = load { i64, ptr }, ptr %l83, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %t139, { i64, ptr } %t140)
  br label %bb38
bb38:
  store ptr %l6, ptr %l84, !tbaa !29
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load ptr, ptr %l2, !tbaa !29
  %t144 = getelementptr %"compiler/ast:TypeDecl", ptr %t142, i32 0, i32 1
  %t145 = load { i64, ptr }, ptr %t144, !tbaa !27
  store { i64, ptr } %t145, ptr %l87, !tbaa !27
  %t146 = load i64, ptr %l12, !tbaa !24
  %t148 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !27
  %t150 = getelementptr ptr, ptr %t149, i64 %t146
  %t151 = load ptr, ptr %t150, !tbaa !39
  %t153 = getelementptr %"compiler/ast:TypeParam", ptr %t151, i32 0, i32 1
  %t154 = load i32, ptr %t153, !tbaa !23
  %t157 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t141, i32 %t154)
  store { i64, ptr } %t157, ptr %l91
  br label %bb39
bb39:
  %t158 = load ptr, ptr %l84, !tbaa !29
  %t159 = load { i64, ptr }, ptr %l91, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t158, { i64, ptr } %t159)
  br label %bb40
bb40:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l6, { i64, ptr } { i64 3, ptr @.d31 })
  br label %bb41
bb41:
  store ptr %l6, ptr %l93, !tbaa !29
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t162, ptr %l95, !tbaa !27
  %t163 = load i64, ptr %l12, !tbaa !24
  %t165 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !27
  %t167 = getelementptr i32, ptr %t166, i64 %t163
  %t168 = load i32, ptr %t167, !tbaa !33
  %t171 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s3, ptr %t161, i32 %t168)
  store { i64, ptr } %t171, ptr %l98
  br label %bb42
bb42:
  %t172 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t173 = extractvalue { i64, ptr } %t172, 0
  %t174 = extractvalue { i64, ptr } %t172, 1
  %t175 = mul i64 %t173, 1
  %t176 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t175)
  call void @llvm.memcpy.p0.p0.i64(ptr %t176, ptr %t174, i64 %t175, i1 false)
  %t177 = insertvalue { i64, ptr } undef, i64 %t173, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t176, 1
  %t179 = load ptr, ptr %l93, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %t179, { i64, ptr } %t178)
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s3)
  br label %bb44
bb44:
  %t181 = load i64, ptr %l11, !tbaa !24
  %t183 = add i64 %t181, 1
  store i64 %t183, ptr %l11, !tbaa !24
  br label %bb28
bb45:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/check:Checker", ptr %t185, i32 0, i32 1
  %t188 = load ptr, ptr %t187, !tbaa !29
  %t190 = getelementptr %"compiler/generic:Program", ptr %t188, i32 0, i32 0
  %t191 = load ptr, ptr %t190, !tbaa !29
  %t193 = getelementptr %"compiler/load:Loader", ptr %t191, i32 0, i32 4
  %t194 = load ptr, ptr %t193, !tbaa !29
  store ptr %t194, ptr %l105, !tbaa !29
  %t195 = getelementptr %"compiler/generic:Origin", ptr %l3, i32 0, i32 0
  %t196 = load i64, ptr %t195, !tbaa !24
  %t197 = getelementptr %"compiler/generic:Origin", ptr %l3, i32 0, i32 1
  %t198 = getelementptr %"compiler/source:Span", ptr %t197, i32 0, i32 0
  %t199 = load i32, ptr %t198, !tbaa !23
  %t201 = sext i32 %t199 to i64
  %t202 = getelementptr %"compiler/generic:Origin", ptr %l3, i32 0, i32 1
  %t203 = getelementptr %"compiler/source:Span", ptr %t202, i32 0, i32 1
  %t204 = load i32, ptr %t203, !tbaa !23
  %t206 = sext i32 %t204 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t207
  %t208 = getelementptr { i64, [3 x i64] }, ptr %t207, i32 0, i32 0
  store i64 3, ptr %t208
  %t210 = insertvalue { i64, i64, i64 } undef, i64 %t196, 0
  %t212 = insertvalue { i64, i64, i64 } %t210, i64 %t201, 1
  %t214 = insertvalue { i64, i64, i64 } %t212, i64 %t206, 2
  %t215 = getelementptr { i64, [3 x i64] }, ptr %t207, i32 0, i32 1
  store { i64, i64, i64 } %t214, ptr %t215
  %t216 = load { i64, [3 x i64] }, ptr %t207
  store { i64, [3 x i64] } %t216, ptr %l111
  %t218 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l6)
  store { i64, ptr } %t218, ptr %l113
  br label %bb46
bb46:
  %t219 = load ptr, ptr %l105, !tbaa !29
  %t220 = load { i64, [3 x i64] }, ptr %l111
  %t221 = load { i64, ptr }, ptr %l113, !tbaa !27
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePushContext(ptr %v0, ptr %s0, ptr %t219, { i64, [3 x i64] } %t220, { i64, ptr } %t221)
  br label %bb47
bb47:
  %t222 = load i64, ptr %l5, !tbaa !24
  %t224 = add i64 %t222, 1
  call void @__olang_scope_close(ptr %s0)
  store i64 %t224, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunary(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %lp11 = alloca ptr
  %l18 = alloca ptr
  %l21 = alloca i32
  %l24 = alloca i1
  %l27 = alloca i32
  %l30 = alloca ptr
  %l32 = alloca %"compiler/source:Span"
  %l33 = alloca ptr
  %l36 = alloca i32
  %l37 = alloca { i64, ptr }
  %l39 = alloca %"compiler/msgs:Msg"
  %l40 = alloca i64
  %l44 = alloca ptr
  %l48 = alloca i1
  %l51 = alloca ptr
  %l56 = alloca ptr
  %l58 = alloca %"compiler/source:Span"
  %l59 = alloca ptr
  %l62 = alloca i32
  %l68 = alloca ptr
  %l71 = alloca i32
  %l72 = alloca i1
  %l73 = alloca i1
  %l76 = alloca i1
  %l77 = alloca i1
  %l81 = alloca i1
  %l85 = alloca { i64, ptr }
  %l86 = alloca ptr
  %l89 = alloca i32
  %l90 = alloca { i64, ptr }
  %l91 = alloca %"compiler/source:Span"
  %l93 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l96 = alloca i64
  %l99 = alloca ptr
  %l100 = alloca ptr
  %l104 = alloca ptr
  %l107 = alloca { i64, ptr }
  %l108 = alloca ptr
  %l109 = alloca %"compiler/source:Span"
  %l110 = alloca %"compiler/source:Span"
  %l111 = alloca i64
  %l113 = alloca ptr
  %l116 = alloca { i64, ptr }
  %l119 = alloca { i64, ptr }
  %l123 = alloca ptr
  %l125 = alloca ptr
  %l128 = alloca i32
  %l129 = alloca { i64, ptr }
  %l130 = alloca %"compiler/source:Span"
  %l132 = alloca { i64, ptr }
  %l133 = alloca { i64, ptr }
  %l135 = alloca i1
  %l138 = alloca ptr
  %l142 = alloca i1
  %l143 = alloca ptr
  %l144 = alloca %"compiler/source:Span"
  %l147 = alloca { i64, ptr }
  %l148 = alloca { i64, ptr }
  %l150 = alloca { i64, ptr }
  %l151 = alloca { i64, ptr }
  %l156 = alloca %"compiler/msgs:Msg"
  %l157 = alloca i64
  %l160 = alloca ptr
  %l166 = alloca i1
  %l168 = alloca ptr
  %l169 = alloca %"compiler/source:Span"
  %l172 = alloca { i64, ptr }
  %l174 = alloca %"compiler/msgs:Msg"
  %l175 = alloca i64
  %l178 = alloca ptr
  %l182 = alloca i64
  %l186 = alloca %"compiler/source:Span"
  %l187 = alloca i32
  %l188 = alloca i32
  %l189 = alloca i32
  %l193 = alloca { i64, ptr }
  %l198 = alloca i1
  %l200 = alloca ptr
  %l201 = alloca %"compiler/source:Span"
  %l204 = alloca { i64, ptr }
  %l206 = alloca %"compiler/msgs:Msg"
  %l207 = alloca i64
  %l210 = alloca ptr
  %l217 = alloca ptr
  %l221 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l222 = alloca ptr
  %l226 = alloca ptr
  %l227 = alloca %"compiler/source:Span"
  %l229 = alloca i32
  %l231 = alloca { i64, ptr }
  %l235 = alloca i32
  %l236 = alloca %"compiler/typed:Text"
  %l244 = alloca ptr
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca ptr
  %t403 = alloca { i64, [5 x i64] }, align 8
  %t505 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l2
  %t3 = trunc i64 47 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load ptr, ptr %l3, !tbaa !29
  %t9 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t13 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t6, ptr %t7, i32 %t9)
  store ptr %t13, ptr %l18
  br label %bb3
bb2:
  br label %bb18
bb3:
  %t14 = load ptr, ptr %l18, !tbaa !29
  store ptr %t14, ptr %l5, !tbaa !29
  %t15 = load ptr, ptr %l5, !tbaa !29
  %t18 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t15)
  store i32 %t18, ptr %l21
  br label %bb4
bb4:
  %t19 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t20 = load i32, ptr %l21, !tbaa !23
  %t22 = icmp ne i32 %t20, %t19
  br i1 %t22, label %bb5, label %bb6
bb5:
  %t24 = load ptr, ptr %l5, !tbaa !29
  %t27 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t24)
  store i32 %t27, ptr %l27
  br label %bb7
bb6:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb8
bb7:
  %t28 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t29 = load i32, ptr %l27, !tbaa !23
  %t31 = icmp ne i32 %t29, %t28
  store i1 %t31, ptr %l24, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l24, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l30, !tbaa !29
  %t35 = load ptr, ptr %l3, !tbaa !29
  %t37 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t35)
  store %"compiler/source:Span" %t37, ptr %l32
  br label %bb11
bb10:
  br label %bb16
bb11:
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l33, !tbaa !29
  %t39 = load ptr, ptr %l5, !tbaa !29
  %t42 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t39)
  store i32 %t42, ptr %l36
  br label %bb12
bb12:
  %t43 = load ptr, ptr %l33, !tbaa !29
  %t44 = load i32, ptr %l36, !tbaa !23
  %t45 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t43, i32 %t44)
  store { i64, ptr } %t45, ptr %l37
  br label %bb13
bb13:
  %t46 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 0
  %t48 = extractvalue { i64, ptr } %t46, 1
  %t49 = mul i64 %t47, 1
  %t50 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t49)
  call void @llvm.memcpy.p0.p0.i64(ptr %t50, ptr %t48, i64 %t49, i1 false)
  %t51 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  %t54 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperandNotBool(ptr %s2, ptr %s2, ptr %s2, { i64, ptr } { i64 5, ptr @.d32 }, { i64, ptr } %t52)
  store %"compiler/msgs:Msg" %t54, ptr %l39
  br label %bb14
bb14:
  %t55 = load ptr, ptr %l30, !tbaa !29
  %t56 = load %"compiler/source:Span", ptr %l32
  %t57 = load %"compiler/msgs:Msg", ptr %l39
  %t58 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t55, %"compiler/source:Span" %t56, %"compiler/msgs:Msg" %t57)
  store i64 %t58, ptr %l40
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load %"compiler/source:Span", ptr %l1
  %t61 = load ptr, ptr %l5, !tbaa !29
  %t65 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %t59, %"compiler/source:Span" %t60, ptr %t61)
  store ptr %t65, ptr %l44
  br label %bb17
bb17:
  %t66 = load ptr, ptr %l44, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t66, ptr %rv
  br label %ret
bb18:
  %t68 = load i32, ptr %l2
  %t70 = trunc i64 49 to i32
  %t71 = icmp eq i32 %t68, %t70
  br i1 %t71, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb21
bb20:
  %t73 = load i32, ptr %l2
  %t75 = trunc i64 83 to i32
  %t76 = icmp eq i32 %t73, %t75
  store i1 %t76, ptr %l48, !tbaa !21
  br label %bb21
bb21:
  %t78 = load i1, ptr %l48, !tbaa !21
  br i1 %t78, label %bb22, label %bb23
bb22:
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l51, !tbaa !29
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load ptr, ptr %l3, !tbaa !29
  %t87 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t80, ptr %t81, i32 %a4)
  store ptr %t87, ptr %l56
  br label %bb24
bb23:
  br label %bb110
bb24:
  %t88 = load ptr, ptr %l3, !tbaa !29
  %t90 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t88)
  store %"compiler/source:Span" %t90, ptr %l58
  br label %bb25
bb25:
  %t91 = load ptr, ptr %l51, !tbaa !29
  %t92 = load ptr, ptr %l56, !tbaa !29
  %t93 = load %"compiler/source:Span", ptr %l58
  %t94 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t91, ptr %t92, %"compiler/source:Span" %t93)
  store ptr %t94, ptr %l59
  br label %bb26
bb26:
  %t95 = load ptr, ptr %l59, !tbaa !29
  store ptr %t95, ptr %l6, !tbaa !29
  %t96 = load ptr, ptr %l6, !tbaa !29
  %t99 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t96)
  store i32 %t99, ptr %l62
  br label %bb27
bb27:
  %t100 = load i32, ptr %l62, !tbaa !23
  store i32 %t100, ptr %l7, !tbaa !23
  %t101 = load i32, ptr %l7, !tbaa !23
  %t102 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t105 = icmp eq i32 %t101, %t102
  br i1 %t105, label %bb28, label %bb29
bb28:
  %t107 = load ptr, ptr %l6, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t107, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t110 = load ptr, ptr %l0, !tbaa !29
  store ptr %t110, ptr %l68, !tbaa !29
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load i32, ptr %l7, !tbaa !23
  %t115 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t111, i32 %t112)
  store i32 %t115, ptr %l71
  br label %bb31
bb31:
  %t116 = load ptr, ptr %l68, !tbaa !29
  %t117 = load i32, ptr %l71, !tbaa !23
  %t118 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t116, i32 %t117)
  store i1 %t118, ptr %l72
  br label %bb32
bb32:
  %t119 = load i1, ptr %l72, !tbaa !21
  br i1 %t119, label %bb33, label %bb34
bb33:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load i32, ptr %l7, !tbaa !23
  %t124 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t120, i32 %t121)
  store i1 %t124, ptr %l76
  br label %bb35
bb34:
  store i1 false, ptr %l73, !tbaa !21
  br label %bb40
bb35:
  %t125 = load i1, ptr %l76, !tbaa !21
  br i1 %t125, label %bb36, label %bb37
bb36:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/check:Checker", ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t130 = load i32, ptr %l7, !tbaa !23
  %t133 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t129, i32 %t130)
  store i1 %t133, ptr %l81
  br label %bb38
bb37:
  store i1 false, ptr %l77, !tbaa !21
  br label %bb39
bb38:
  %t134 = load i1, ptr %l81, !tbaa !21
  store i1 %t134, ptr %l77, !tbaa !21
  br label %bb39
bb39:
  %t135 = load i1, ptr %l77, !tbaa !21
  %t136 = xor i1 %t135, true
  store i1 %t136, ptr %l73, !tbaa !21
  br label %bb40
bb40:
  %t138 = load i1, ptr %l73, !tbaa !21
  br i1 %t138, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s5
  %t139 = load i32, ptr %l2
  %t141 = trunc i64 49 to i32
  %t142 = icmp eq i32 %t139, %t141
  br i1 %t142, label %bb43, label %bb44
bb42:
  br label %bb86
bb43:
  store { i64, ptr } { i64 3, ptr @.d33 }, ptr %l85, !tbaa !27
  br label %bb45
bb44:
  store { i64, ptr } { i64 6, ptr @.d34 }, ptr %l85, !tbaa !27
  br label %bb45
bb45:
  %t144 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t144, ptr %l8, !tbaa !27
  %t145 = load ptr, ptr %l0, !tbaa !29
  store ptr %t145, ptr %l86, !tbaa !29
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load i32, ptr %l7, !tbaa !23
  %t150 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t146, i32 %t147)
  store i32 %t150, ptr %l89
  br label %bb46
bb46:
  %t151 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t151, ptr %l90, !tbaa !27
  %t152 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t152, ptr %l91
  %t153 = load i32, ptr %l2
  %t155 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s5, i32 %t153)
  store { i64, ptr } %t155, ptr %l93
  br label %bb47
bb47:
  %t156 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t157 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s5, ptr %s5, { i64, ptr } %t156)
  store { i64, ptr } %t157, ptr %l94
  br label %bb48
bb48:
  %t158 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t159 = extractvalue { i64, ptr } %t158, 0
  %t160 = extractvalue { i64, ptr } %t158, 1
  %t161 = mul i64 %t159, 1
  %t162 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t161)
  call void @llvm.memcpy.p0.p0.i64(ptr %t162, ptr %t160, i64 %t161, i1 false)
  %t163 = insertvalue { i64, ptr } undef, i64 %t159, 0
  %t164 = insertvalue { i64, ptr } %t163, ptr %t162, 1
  %t165 = load ptr, ptr @__olang_prog_scope
  %t166 = load ptr, ptr %l86, !tbaa !29
  %t167 = load i32, ptr %l89, !tbaa !23
  %t168 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t169 = load %"compiler/source:Span", ptr %l91
  %t171 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %t165, ptr %s5, ptr %t166, i32 %t167, { i64, ptr } %t168, i64 0, %"compiler/source:Span" %t169, { i64, ptr } %t164)
  store i64 %t171, ptr %l96
  br label %bb49
bb49:
  %t172 = load i64, ptr %l96, !tbaa !24
  store i64 %t172, ptr %l9, !tbaa !24
  %t173 = load i64, ptr %l9, !tbaa !24
  %t175 = icmp sge i64 %t173, 0
  br i1 %t175, label %bb50, label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s6
  %t177 = load ptr, ptr %l0, !tbaa !29
  store ptr %t177, ptr %l99, !tbaa !29
  %t178 = load ptr, ptr %l0, !tbaa !29
  store ptr %t178, ptr %l100, !tbaa !29
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/check:Checker", ptr %t179, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !29
  %t183 = load i64, ptr %l9, !tbaa !24
  %t186 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t182, i64 %t183)
  store ptr %t186, ptr %l104
  br label %bb52
bb51:
  br label %bb67
bb52:
  %t187 = load ptr, ptr %l104, !tbaa !29
  %t189 = getelementptr %"compiler/ast:Func", ptr %t187, i32 0, i32 2
  %t190 = load i32, ptr %t189, !tbaa !23
  %t191 = load ptr, ptr %l100, !tbaa !29
  %t193 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t191, i32 %t190)
  store { i64, ptr } %t193, ptr %l107
  br label %bb53
bb53:
  %t194 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t195 = load ptr, ptr %l99, !tbaa !29
  %t196 = getelementptr %"compiler/check:Checker", ptr %t195, i32 0, i32 42
  store { i64, ptr } %t194, ptr %t196, !tbaa !27
  %t197 = load ptr, ptr %l0, !tbaa !29
  store ptr %t197, ptr %l108, !tbaa !29
  %t198 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t198, ptr %l109
  %t199 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t199, ptr %l110
  %t200 = load i64, ptr %l9, !tbaa !24
  store i64 %t200, ptr %l111, !tbaa !24
  %t201 = load ptr, ptr %l6, !tbaa !29
  store ptr %t201, ptr %l113, !tbaa !29
  %t203 = icmp sge i64 0, 0
  br i1 %t203, label %bb54, label %bb55
bb54:
  %t205 = icmp sle i64 0, 1152921504606846975
  br i1 %t205, label %bb56, label %bb57
bb55:
  call void @__olang_check_failed(ptr @olang_loc_39a940d28383dd1b_3bbc1f844fb62f37)
  unreachable
bb56:
  %t207 = mul i64 0, 8
  %t208 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t207)
  %t209 = insertvalue { i64, ptr } undef, i64 0, 0
  %t210 = insertvalue { i64, ptr } %t209, ptr %t208, 1
  store { i64, ptr } %t210, ptr %l116, !tbaa !27
  %t211 = icmp sge i64 0, 0
  br i1 %t211, label %bb58, label %bb59
bb57:
  call void @__olang_check_failed(ptr @olang_loc_39a940d28383dd1b_3bbc1f844fb62f37)
  unreachable
bb58:
  %t213 = icmp sle i64 0, 1152921504606846975
  br i1 %t213, label %bb60, label %bb61
bb59:
  call void @__olang_check_failed(ptr @olang_loc_39a940d28383dd1b_3bbc1f844fb62f37)
  unreachable
bb60:
  %t215 = mul i64 0, 8
  %t216 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t215)
  %t217 = insertvalue { i64, ptr } undef, i64 0, 0
  %t218 = insertvalue { i64, ptr } %t217, ptr %t216, 1
  store { i64, ptr } %t218, ptr %l119, !tbaa !27
  %t219 = icmp sge i64 0, 0
  br i1 %t219, label %bb62, label %bb63
bb61:
  call void @__olang_check_failed(ptr @olang_loc_39a940d28383dd1b_3bbc1f844fb62f37)
  unreachable
bb62:
  %t221 = icmp sle i64 0, 2305843009213693951
  br i1 %t221, label %bb64, label %bb65
bb63:
  call void @__olang_check_failed(ptr @olang_loc_ed7947026d051386_3326ccf8e0a65a82)
  unreachable
bb64:
  %t223 = mul i64 0, 4
  %t224 = call ptr @__olang_scope_alloc_zeroed(ptr %s6, i64 %t223)
  %t225 = insertvalue { i64, ptr } undef, i64 0, 0
  %t226 = insertvalue { i64, ptr } %t225, ptr %t224, 1
  %t227 = load ptr, ptr %l108, !tbaa !29
  %t228 = load %"compiler/source:Span", ptr %l109
  %t229 = load %"compiler/source:Span", ptr %l110
  %t230 = load i64, ptr %l111, !tbaa !24
  %t231 = load ptr, ptr %l113, !tbaa !29
  %t232 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t233 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t235 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %s6, ptr %t227, %"compiler/source:Span" %t228, %"compiler/source:Span" %t229, i64 %t230, ptr %t231, { i64, ptr } %t232, { i64, ptr } %t233, { i64, ptr } %t226)
  store ptr %t235, ptr %l123
  br label %bb66
bb65:
  call void @__olang_check_failed(ptr @olang_loc_ed7947026d051386_3326ccf8e0a65a82)
  unreachable
bb66:
  %t236 = load ptr, ptr %l123, !tbaa !29
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t236, ptr %rv
  br label %ret
bb67:
  %t238 = load ptr, ptr %l0, !tbaa !29
  store ptr %t238, ptr %l125, !tbaa !29
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t240 = load i32, ptr %l7, !tbaa !23
  %t243 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t239, i32 %t240)
  store i32 %t243, ptr %l128
  br label %bb68
bb68:
  %t244 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t244, ptr %l129, !tbaa !27
  %t245 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t245, ptr %l130
  %t246 = load i32, ptr %l2
  %t248 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s5, i32 %t246)
  store { i64, ptr } %t248, ptr %l132
  br label %bb69
bb69:
  %t249 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t250 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s5, ptr %s5, { i64, ptr } %t249)
  store { i64, ptr } %t250, ptr %l133
  br label %bb70
bb70:
  %t251 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t252 = extractvalue { i64, ptr } %t251, 0
  %t253 = extractvalue { i64, ptr } %t251, 1
  %t254 = mul i64 %t252, 1
  %t255 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t254)
  call void @llvm.memcpy.p0.p0.i64(ptr %t255, ptr %t253, i64 %t254, i1 false)
  %t256 = insertvalue { i64, ptr } undef, i64 %t252, 0
  %t257 = insertvalue { i64, ptr } %t256, ptr %t255, 1
  %t258 = load ptr, ptr @__olang_prog_scope
  %t259 = load ptr, ptr %l125, !tbaa !29
  %t260 = load i32, ptr %l128, !tbaa !23
  %t261 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t262 = load %"compiler/source:Span", ptr %l130
  %t264 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %t258, ptr %s5, ptr %t259, i32 %t260, { i64, ptr } %t261, %"compiler/source:Span" %t262, { i64, ptr } %t257, i64 0, i1 false)
  store i1 %t264, ptr %l135
  br label %bb71
bb71:
  %t265 = load i1, ptr %l135, !tbaa !21
  br i1 %t265, label %bb72, label %bb73
bb72:
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t267 = load %"compiler/source:Span", ptr %l1
  %t270 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t266, %"compiler/source:Span" %t267)
  store ptr %t270, ptr %l138
  br label %bb74
bb73:
  br label %bb75
bb74:
  %t271 = load ptr, ptr %l138, !tbaa !29
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t271, ptr %rv
  br label %ret
bb75:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t274 = load i32, ptr %l7, !tbaa !23
  %t277 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t273, i32 %t274)
  store i1 %t277, ptr %l142
  br label %bb76
bb76:
  %t278 = load i1, ptr %l142, !tbaa !21
  br i1 %t278, label %bb77, label %bb78
bb77:
  store %olang.scope zeroinitializer, ptr %s8
  %t279 = load ptr, ptr %l0, !tbaa !29
  store ptr %t279, ptr %l143, !tbaa !29
  %t280 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t280, ptr %l144
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t282 = load i32, ptr %l7, !tbaa !23
  %t285 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s8, ptr %t281, i32 %t282)
  store { i64, ptr } %t285, ptr %l147
  br label %bb79
bb78:
  br label %bb85
bb79:
  %t286 = load { i64, ptr }, ptr %l147, !tbaa !27
  %t287 = extractvalue { i64, ptr } %t286, 0
  %t288 = extractvalue { i64, ptr } %t286, 1
  %t289 = mul i64 %t287, 1
  %t290 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t289)
  call void @llvm.memcpy.p0.p0.i64(ptr %t290, ptr %t288, i64 %t289, i1 false)
  %t291 = insertvalue { i64, ptr } undef, i64 %t287, 0
  %t292 = insertvalue { i64, ptr } %t291, ptr %t290, 1
  store { i64, ptr } %t292, ptr %l148, !tbaa !27
  %t293 = load i32, ptr %l2
  %t295 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s8, i32 %t293)
  store { i64, ptr } %t295, ptr %l150
  br label %bb80
bb80:
  %t296 = load { i64, ptr }, ptr %l150, !tbaa !27
  %t297 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s8, ptr %s8, { i64, ptr } %t296)
  store { i64, ptr } %t297, ptr %l151
  br label %bb81
bb81:
  %t298 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t299 = extractvalue { i64, ptr } %t298, 0
  %t300 = extractvalue { i64, ptr } %t298, 1
  %t301 = mul i64 %t299, 1
  %t302 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t301)
  call void @llvm.memcpy.p0.p0.i64(ptr %t302, ptr %t300, i64 %t301, i1 false)
  %t303 = insertvalue { i64, ptr } undef, i64 %t299, 0
  %t304 = insertvalue { i64, ptr } %t303, ptr %t302, 1
  %t305 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t306 = extractvalue { i64, ptr } { i64 1, ptr @.d35 }, 1
  %t307 = extractvalue { i64, ptr } { i64 1, ptr @.d35 }, 0
  %t309 = extractvalue { i64, ptr } %t305, 1
  %t310 = extractvalue { i64, ptr } %t305, 0
  %t311 = add i64 %t307, %t310
  %t312 = extractvalue { i64, ptr } { i64 1, ptr @.d36 }, 1
  %t313 = extractvalue { i64, ptr } { i64 1, ptr @.d36 }, 0
  %t314 = add i64 %t311, %t313
  %t315 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t314)
  call void @olang_textcopy(ptr %t315, ptr %t306, i64 %t307)
  %t316 = getelementptr i8, ptr %t315, i64 %t307
  call void @olang_textcopy(ptr %t316, ptr %t309, i64 %t310)
  %t317 = getelementptr i8, ptr %t316, i64 %t310
  call void @olang_textcopy(ptr %t317, ptr %t312, i64 %t313)
  %t318 = insertvalue { i64, ptr } undef, i64 %t314, 0
  %t319 = insertvalue { i64, ptr } %t318, ptr %t315, 1
  %t321 = extractvalue { i64, ptr } %t319, 0
  %t322 = extractvalue { i64, ptr } %t319, 1
  %t323 = mul i64 %t321, 1
  %t324 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t323)
  call void @llvm.memcpy.p0.p0.i64(ptr %t324, ptr %t322, i64 %t323, i1 false)
  %t325 = insertvalue { i64, ptr } undef, i64 %t321, 0
  %t326 = insertvalue { i64, ptr } %t325, ptr %t324, 1
  %t327 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t330 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotExtendedOp(ptr %s8, ptr %s8, ptr %s8, ptr %s8, { i64, ptr } %t327, { i64, ptr } %t304, { i64, ptr } %t326)
  store %"compiler/msgs:Msg" %t330, ptr %l156
  br label %bb82
bb82:
  %t331 = load ptr, ptr %l143, !tbaa !29
  %t332 = load %"compiler/source:Span", ptr %l144
  %t333 = load %"compiler/msgs:Msg", ptr %l156
  %t334 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s8, ptr %t331, %"compiler/source:Span" %t332, %"compiler/msgs:Msg" %t333)
  store i64 %t334, ptr %l157
  br label %bb83
bb83:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t336 = load %"compiler/source:Span", ptr %l1
  %t339 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t335, %"compiler/source:Span" %t336)
  store ptr %t339, ptr %l160
  br label %bb84
bb84:
  %t340 = load ptr, ptr %l160, !tbaa !29
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t340, ptr %rv
  br label %ret
bb85:
  call void @__olang_scope_close(ptr %s5)
  br label %bb86
bb86:
  %t342 = load i32, ptr %l2
  %t344 = trunc i64 49 to i32
  %t345 = icmp eq i32 %t342, %t344
  br i1 %t345, label %bb87, label %bb88
bb87:
  %t347 = load ptr, ptr %l0, !tbaa !29
  %t348 = load i32, ptr %l7, !tbaa !23
  %t351 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t347, i32 %t348)
  store i1 %t351, ptr %l166
  br label %bb89
bb88:
  br label %bb100
bb89:
  %t352 = load i1, ptr %l166, !tbaa !21
  %t353 = xor i1 %t352, true
  br i1 %t353, label %bb90, label %bb91
bb90:
  store %olang.scope zeroinitializer, ptr %s11
  %t355 = load ptr, ptr %l0, !tbaa !29
  store ptr %t355, ptr %l168, !tbaa !29
  %t356 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t356, ptr %l169
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t358 = load i32, ptr %l7, !tbaa !23
  %t361 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s11, ptr %t357, i32 %t358)
  store { i64, ptr } %t361, ptr %l172
  br label %bb92
bb91:
  br label %bb96
bb92:
  %t362 = load { i64, ptr }, ptr %l172, !tbaa !27
  %t363 = extractvalue { i64, ptr } %t362, 0
  %t364 = extractvalue { i64, ptr } %t362, 1
  %t365 = mul i64 %t363, 1
  %t366 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t365)
  call void @llvm.memcpy.p0.p0.i64(ptr %t366, ptr %t364, i64 %t365, i1 false)
  %t367 = insertvalue { i64, ptr } undef, i64 %t363, 0
  %t368 = insertvalue { i64, ptr } %t367, ptr %t366, 1
  %t370 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperandNotNumber(ptr %s11, ptr %s11, ptr %s11, { i64, ptr } { i64 3, ptr @.d37 }, { i64, ptr } %t368)
  store %"compiler/msgs:Msg" %t370, ptr %l174
  br label %bb93
bb93:
  %t371 = load ptr, ptr %l168, !tbaa !29
  %t372 = load %"compiler/source:Span", ptr %l169
  %t373 = load %"compiler/msgs:Msg", ptr %l174
  %t374 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s11, ptr %t371, %"compiler/source:Span" %t372, %"compiler/msgs:Msg" %t373)
  store i64 %t374, ptr %l175
  br label %bb94
bb94:
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t376 = load %"compiler/source:Span", ptr %l1
  %t379 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t375, %"compiler/source:Span" %t376)
  store ptr %t379, ptr %l178
  br label %bb95
bb95:
  %t380 = load ptr, ptr %l178, !tbaa !29
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t380, ptr %rv
  br label %ret
bb96:
  %t382 = load ptr, ptr %l0, !tbaa !29
  %t384 = getelementptr %"compiler/check:Checker", ptr %t382, i32 0, i32 31
  %t386 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t384)
  store i64 %t386, ptr %l182
  br label %bb97
bb97:
  %t387 = load i64, ptr %l182, !tbaa !24
  store i64 %t387, ptr %l10, !tbaa !24
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t390 = getelementptr %"compiler/check:Checker", ptr %t388, i32 0, i32 31
  %t391 = load ptr, ptr %l6, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t390, ptr %t391)
  br label %bb98
bb98:
  %t394 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t394, ptr %l186
  %t395 = load i32, ptr %l7, !tbaa !23
  store i32 %t395, ptr %l187, !tbaa !23
  store i32 0, ptr %l188
  store i32 0, ptr %l189
  %t396 = load ptr, ptr %l0, !tbaa !29
  %t398 = getelementptr %"compiler/check:Checker", ptr %t396, i32 0, i32 31
  %t399 = load i64, ptr %l10, !tbaa !24
  %t402 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t398, i64 %t399)
  store { i64, ptr } %t402, ptr %l193
  br label %bb99
bb99:
  store { i64, [5 x i64] } zeroinitializer, ptr %t403
  %t404 = getelementptr { i64, [5 x i64] }, ptr %t403, i32 0, i32 0
  store i64 9, ptr %t404
  %t405 = load %"compiler/source:Span", ptr %l186
  %t406 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } undef, %"compiler/source:Span" %t405, 0
  %t407 = load i32, ptr %l187, !tbaa !23
  %t408 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t406, i32 %t407, 1
  %t409 = load i32, ptr %l188
  %t410 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t408, i32 %t409, 2
  %t411 = load i32, ptr %l189
  %t412 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t410, i32 %t411, 3
  %t413 = load { i64, ptr }, ptr %l193, !tbaa !27
  %t414 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t412, { i64, ptr } %t413, 4
  %t415 = getelementptr { i64, [5 x i64] }, ptr %t403, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t414, ptr %t415
  %t416 = load { i64, [5 x i64] }, ptr %t403
  %t418 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t416, ptr %t418
  call void @__olang_scope_close(ptr %s0)
  store ptr %t418, ptr %rv
  br label %ret
bb100:
  %t420 = load ptr, ptr %l0, !tbaa !29
  %t421 = load i32, ptr %l7, !tbaa !23
  %t424 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %t420, i32 %t421)
  store i1 %t424, ptr %l198
  br label %bb101
bb101:
  %t425 = load i1, ptr %l198, !tbaa !21
  %t426 = xor i1 %t425, true
  br i1 %t426, label %bb102, label %bb103
bb102:
  store %olang.scope zeroinitializer, ptr %s12
  %t428 = load ptr, ptr %l0, !tbaa !29
  store ptr %t428, ptr %l200, !tbaa !29
  %t429 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t429, ptr %l201
  %t430 = load ptr, ptr %l0, !tbaa !29
  %t431 = load i32, ptr %l7, !tbaa !23
  %t434 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s12, ptr %t430, i32 %t431)
  store { i64, ptr } %t434, ptr %l204
  br label %bb104
bb103:
  br label %bb108
bb104:
  %t435 = load { i64, ptr }, ptr %l204, !tbaa !27
  %t436 = extractvalue { i64, ptr } %t435, 0
  %t437 = extractvalue { i64, ptr } %t435, 1
  %t438 = mul i64 %t436, 1
  %t439 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t438)
  call void @llvm.memcpy.p0.p0.i64(ptr %t439, ptr %t437, i64 %t438, i1 false)
  %t440 = insertvalue { i64, ptr } undef, i64 %t436, 0
  %t441 = insertvalue { i64, ptr } %t440, ptr %t439, 1
  %t443 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperandNotInt(ptr %s12, ptr %s12, ptr %s12, { i64, ptr } { i64 3, ptr @.d38 }, { i64, ptr } %t441)
  store %"compiler/msgs:Msg" %t443, ptr %l206
  br label %bb105
bb105:
  %t444 = load ptr, ptr %l200, !tbaa !29
  %t445 = load %"compiler/source:Span", ptr %l201
  %t446 = load %"compiler/msgs:Msg", ptr %l206
  %t447 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s12, ptr %t444, %"compiler/source:Span" %t445, %"compiler/msgs:Msg" %t446)
  store i64 %t447, ptr %l207
  br label %bb106
bb106:
  %t448 = load ptr, ptr %l0, !tbaa !29
  %t449 = load %"compiler/source:Span", ptr %l1
  %t452 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t448, %"compiler/source:Span" %t449)
  store ptr %t452, ptr %l210
  br label %bb107
bb107:
  %t453 = load ptr, ptr %l210, !tbaa !29
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t453, ptr %rv
  br label %ret
bb108:
  %t455 = load ptr, ptr %l0, !tbaa !29
  %t456 = load %"compiler/source:Span", ptr %l1
  %t457 = load i32, ptr %l7, !tbaa !23
  %t458 = load ptr, ptr %l6, !tbaa !29
  %t464 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t455, %"compiler/source:Span" %t456, i32 %t457, i32 1, ptr %t458, ptr null)
  store ptr %t464, ptr %l217
  br label %bb109
bb109:
  %t465 = load ptr, ptr %l217, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t465, ptr %rv
  br label %ret
bb110:
  %t467 = load i32, ptr %l2
  %t469 = trunc i64 84 to i32
  %t470 = icmp eq i32 %t467, %t469
  br i1 %t470, label %bb111, label %bb112
bb111:
  %t472 = load ptr, ptr @__olang_prog_scope
  %t473 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPiece_26_3e(ptr %t472)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t473, ptr %l221
  br label %bb113
bb112:
  br label %bb120
bb113:
  %t474 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store ptr %t474, ptr %lp11
  %t475 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l221
  %t476 = load ptr, ptr %lp11
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t475, ptr %t476
  %t477 = load ptr, ptr %lp11
  store ptr %t477, ptr %l222, !tbaa !29
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t479 = load %"compiler/source:Span", ptr %l1
  %t480 = load ptr, ptr %l3, !tbaa !29
  %t484 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erenderPiece(ptr %v0, ptr %v1, ptr %t478, %"compiler/source:Span" %t479, ptr %t480)
  store ptr %t484, ptr %l226
  br label %bb114
bb114:
  %t485 = load ptr, ptr %l222, !tbaa !29
  %t486 = load ptr, ptr %l226, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPiece_26_3e_2ePu_Hf3d190a214b599b1db3fb8bde0778037(ptr %v0, ptr %v0, ptr %t485, ptr %t486)
  br label %bb115
bb115:
  %t487 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t487, ptr %l227
  %t488 = load ptr, ptr %l0, !tbaa !29
  %t490 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t488)
  store i32 %t490, ptr %l229
  br label %bb116
bb116:
  %t491 = load ptr, ptr %lp11
  %t493 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPiece_26_3e_2eTo_H8a5ee0a19875600d5129e9d1ac97555e(ptr %v0, ptr %v0, ptr %t491)
  store { i64, ptr } %t493, ptr %l231
  br label %bb117
bb117:
  %t494 = load ptr, ptr %l0, !tbaa !29
  %t495 = load %"compiler/source:Span", ptr %l1
  %t499 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t494, i32 4, %"compiler/source:Span" %t495)
  store i32 %t499, ptr %l235
  br label %bb118
bb118:
  %t500 = load { i64, ptr }, ptr %l231, !tbaa !27
  %t501 = load i32, ptr %l235, !tbaa !23
  %t502 = call %"compiler/typed:Text" @compiler_2ftyped_3aText_2ector(ptr %v0, ptr %v0, { i64, ptr } %t500, i32 %t501)
  store %"compiler/typed:Text" %t502, ptr %l236
  br label %bb119
bb119:
  %t503 = load %"compiler/typed:Text", ptr %l236
  %t504 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Text" %t503, ptr %t504
  store { i64, [5 x i64] } zeroinitializer, ptr %t505
  %t506 = getelementptr { i64, [5 x i64] }, ptr %t505, i32 0, i32 0
  store i64 16, ptr %t506
  %t507 = load %"compiler/source:Span", ptr %l227
  %t508 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t507, 0
  %t509 = load i32, ptr %l229, !tbaa !23
  %t510 = insertvalue { %"compiler/source:Span", i32, ptr } %t508, i32 %t509, 1
  %t512 = insertvalue { %"compiler/source:Span", i32, ptr } %t510, ptr %t504, 2
  %t513 = getelementptr { i64, [5 x i64] }, ptr %t505, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t512, ptr %t513
  %t514 = load { i64, [5 x i64] }, ptr %t505
  %t516 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t514, ptr %t516
  call void @__olang_scope_close(ptr %s0)
  store ptr %t516, ptr %rv
  br label %ret
bb120:
  %t518 = load ptr, ptr %l0, !tbaa !29
  %t519 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s0, ptr %t518, %"compiler/source:Span" %t519, { i64, ptr } { i64 20, ptr @.d39 })
  br label %bb121
bb121:
  %t522 = load ptr, ptr %l0, !tbaa !29
  %t523 = load %"compiler/source:Span", ptr %l1
  %t526 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t522, %"compiler/source:Span" %t523)
  store ptr %t526, ptr %l244
  br label %bb122
bb122:
  %t527 = load ptr, ptr %l244, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t527, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euncovered(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i64
  %l15 = alloca i32
  %l20 = alloca i64
  %l25 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l39 = alloca i32
  %l42 = alloca i64
  %l47 = alloca i64
  %l54 = alloca i64
  %l57 = alloca i64
  %l59 = alloca i64
  %l71 = alloca i32
  %l78 = alloca i32
  %s2 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l15
  br label %bb1
bb1:
  %t11 = load i32, ptr %l15, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  %t18 = load i32, ptr %l2, !tbaa !23
  %t21 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t17, i32 %t18)
  store i64 %t21, ptr %l20
  br label %bb2
bb2:
  %t22 = load i64, ptr %l20, !tbaa !65
  store i64 %t22, ptr %l4, !tbaa !65
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  %t32 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t28, i32 %a1)
  store { i64, ptr } %t32, ptr %l25
  br label %bb3
bb3:
  %t33 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t33, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t34 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t34, 0
  store i64 %t36, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t38 = load i64, ptr %l6, !tbaa !24
  %t39 = load i64, ptr %l7, !tbaa !24
  %t42 = icmp slt i64 %t38, %t39
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb6:
  br label %bb7
bb7:
  %t46 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t46, ptr %l32, !tbaa !27
  %t47 = load i64, ptr %l6, !tbaa !24
  %t49 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr i32, ptr %t50, i64 %t47
  %t52 = load i32, ptr %t51, !tbaa !33
  store i32 %t52, ptr %l8, !tbaa !23
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = getelementptr %"compiler/generic:Program", ptr %t57, i32 0, i32 2
  %t60 = load i32, ptr %l8, !tbaa !23
  %t63 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t59, i32 %t60)
  store i32 %t63, ptr %l39
  br label %bb8
bb8:
  %t64 = load i32, ptr %l3, !tbaa !23
  %t65 = load i32, ptr %l39, !tbaa !23
  %t67 = icmp eq i32 %t65, %t64
  br i1 %t67, label %bb9, label %bb10
bb9:
  %t69 = load i64, ptr %l4, !tbaa !65
  store i64 %t69, ptr %l42, !tbaa !65
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/check:Checker", ptr %t70, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/generic:Program", ptr %t73, i32 0, i32 2
  %t76 = load i32, ptr %l8, !tbaa !23
  %t79 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t75, i32 %t76)
  store i64 %t79, ptr %l47
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t80 = load i64, ptr %l47, !tbaa !65
  %t81 = xor i64 %t80, -1
  %t82 = load i64, ptr %l42, !tbaa !65
  %t84 = and i64 %t82, %t81
  store i64 %t84, ptr %l4, !tbaa !65
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  %t86 = load i64, ptr %l6, !tbaa !24
  %t88 = add i64 %t86, 1
  store i64 %t88, ptr %l6, !tbaa !24
  br label %bb4
bb14:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load i32, ptr %l3, !tbaa !23
  %t94 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordCount(ptr %v0, ptr %t90, i32 %t91)
  store i64 %t94, ptr %l54
  br label %bb15
bb15:
  %t95 = load i64, ptr %l54, !tbaa !24
  store i64 %t95, ptr %l9, !tbaa !24
  %t96 = load i64, ptr %l9, !tbaa !24
  %t98 = icmp sge i64 %t96, 64
  br i1 %t98, label %bb16, label %bb17
bb16:
  %t100 = sub i64 0, 1
  store i64 %t100, ptr %l57, !tbaa !65
  br label %bb18
bb17:
  %t102 = load i64, ptr %l9, !tbaa !24
  store i64 %t102, ptr %l59, !tbaa !24
  %t103 = load i64, ptr %l59, !tbaa !24
  %t104 = load i64, ptr %l59, !tbaa !24
  %t105 = shl i64 1, %t104
  %t107 = sub i64 %t105, 1
  store i64 %t107, ptr %l57, !tbaa !65
  br label %bb18
bb18:
  %t109 = load i64, ptr %l57, !tbaa !65
  store i64 %t109, ptr %l10, !tbaa !65
  %t110 = load i64, ptr %l4, !tbaa !65
  %t111 = load i64, ptr %l10, !tbaa !65
  %t114 = and i64 %t110, %t111
  store i64 %t114, ptr %l4, !tbaa !65
  %t116 = load i64, ptr %l4, !tbaa !65
  %t118 = icmp eq i64 %t116, 0
  br i1 %t118, label %bb19, label %bb20
bb19:
  %t120 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t120, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t122 = load i64, ptr %l4, !tbaa !65
  %t123 = load i64, ptr %l10, !tbaa !65
  %t126 = icmp eq i64 %t122, %t123
  br i1 %t126, label %bb22, label %bb23
bb22:
  %t128 = load i32, ptr %l3, !tbaa !23
  store i32 %t128, ptr %l71, !tbaa !23
  br label %bb25
bb23:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/check:Checker", ptr %t130, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !29
  %t135 = getelementptr %"compiler/generic:Program", ptr %t133, i32 0, i32 2
  %t136 = load i32, ptr %l3, !tbaa !23
  %t137 = load i64, ptr %l4, !tbaa !65
  %t141 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %t135, i32 %t136, i64 %t137)
  store i32 %t141, ptr %l78
  br label %bb24
bb24:
  %t142 = load i32, ptr %l78, !tbaa !23
  store i32 %t142, ptr %l71, !tbaa !23
  br label %bb25
bb25:
  %t143 = load i32, ptr %l71, !tbaa !23
  store i32 %t143, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i64
  %l36 = alloca i1
  %l43 = alloca i32
  %s2 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i32 %a1, ptr %l2, !tbaa !23
  store i64 0, ptr %l3, !tbaa !24
  store i64 32, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t3 = load i64, ptr %l4, !tbaa !24
  %t4 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp sgt i64 %t3, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l13, !tbaa !24
  br label %bb6
bb3:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = sub i64 %t13, %t14
  %t18 = load i64, ptr %l5, !tbaa !24
  %t21 = add i64 %t17, %t18
  %t23 = sub i64 %t21, 1
  %t24 = load i64, ptr %l5, !tbaa !24
  %t27 = sdiv i64 %t23, %t24
  store i64 %t27, ptr %l16, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l16, !tbaa !24
  store i64 %t29, ptr %l13, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l13, !tbaa !24
  store i64 %t30, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t31 = load i64, ptr %l7, !tbaa !24
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb9:
  br label %bb10
bb10:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = load i64, ptr %l7, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = mul i64 %t40, %t41
  %t47 = add i64 %t39, %t44
  store i64 %t47, ptr %l8, !tbaa !24
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i32, ptr %l2, !tbaa !23
  %t53 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisOver(ptr %v0, ptr %t49, i32 %t50)
  store i1 %t53, ptr %l36
  br label %bb11
bb11:
  %t54 = load i1, ptr %l36, !tbaa !21
  %t55 = xor i1 %t54, true
  br i1 %t55, label %bb12, label %bb13
bb12:
  %t57 = load i32, ptr %l2, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  store i32 %t57, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 2
  %t65 = load i32, ptr %l2, !tbaa !23
  %t68 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t64, i32 %t65)
  store i32 %t68, ptr %l43
  br label %bb15
bb15:
  %t69 = load i32, ptr %l43, !tbaa !23
  store i32 %t69, ptr %l2, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  %t70 = load i64, ptr %l7, !tbaa !24
  %t72 = add i64 %t70, 1
  store i64 %t72, ptr %l7, !tbaa !24
  br label %bb7
bb17:
  %t74 = load i32, ptr %l2, !tbaa !23
  store i32 %t74, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalueTemp(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i1
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i1
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca i1
  %l41 = alloca i64
  %l42 = alloca ptr
  %l43 = alloca i1
  %l49 = alloca ptr
  %l54 = alloca i64
  %l58 = alloca i64
  %l61 = alloca i64
  %l82 = alloca %"compiler/check:atRec"
  %l86 = alloca i1
  %l90 = alloca %"compiler/check:atRec"
  %s6 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t2 = load ptr, ptr %l13, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l13, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l14, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l14, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalueTemp(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i64 %t20, ptr %l21
  br label %bb6
bb6:
  %t21 = load i64, ptr %l21, !tbaa !24
  store i64 %t21, ptr %rv
  br label %ret
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t23 = load ptr, ptr %l22, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l22, !tbaa !29
  %t27 = load i64, ptr %t26
  %t29 = icmp eq i64 %t27, 4
  store i1 %t29, ptr %l23, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l23, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Elem", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t44 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalueTemp(ptr %v0, ptr %v1, ptr %t37, ptr %t41)
  store i64 %t44, ptr %l31
  br label %bb13
bb13:
  %t45 = load i64, ptr %l31, !tbaa !24
  store i64 %t45, ptr %rv
  br label %ret
bb14:
  %t46 = load ptr, ptr %l1, !tbaa !29
  store ptr %t46, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t47 = load ptr, ptr %l32, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb15, label %bb16
bb15:
  %t50 = load ptr, ptr %l32, !tbaa !29
  %t51 = load i64, ptr %t50
  %t53 = icmp eq i64 %t51, 5
  store i1 %t53, ptr %l33, !tbaa !21
  br label %bb16
bb16:
  %t54 = load i1, ptr %l33, !tbaa !21
  br i1 %t54, label %bb17, label %bb18
bb17:
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr { i64, [4 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t57, i32 0, i32 2
  %t59 = load ptr, ptr %t58
  store ptr %t59, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t64 = getelementptr %"compiler/typed:Payload", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t68 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalueTemp(ptr %v0, ptr %v1, ptr %t61, ptr %t65)
  store i64 %t68, ptr %l41
  br label %bb20
bb20:
  %t69 = load i64, ptr %l41, !tbaa !24
  store i64 %t69, ptr %rv
  br label %ret
bb21:
  %t70 = load ptr, ptr %l1, !tbaa !29
  store ptr %t70, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t71 = load ptr, ptr %l42, !tbaa !29
  %t72 = icmp ne ptr %t71, null
  br i1 %t72, label %bb22, label %bb23
bb22:
  %t74 = load ptr, ptr %l42, !tbaa !29
  %t75 = load i64, ptr %t74
  %t77 = icmp eq i64 %t75, 6
  store i1 %t77, ptr %l43, !tbaa !21
  br label %bb23
bb23:
  %t78 = load i1, ptr %l43, !tbaa !21
  br i1 %t78, label %bb24, label %bb25
bb24:
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr { i64, [4 x i64] }, ptr %t79, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t81, i32 0, i32 3
  %t83 = load i32, ptr %t82
  store i32 %t83, ptr %l5, !tbaa !23
  br label %bb26
bb25:
  br label %bb49
bb26:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t85)
  store ptr %t87, ptr %l49
  br label %bb27
bb27:
  %t88 = load ptr, ptr %l49, !tbaa !29
  %t90 = getelementptr %"compiler/check:frame", ptr %t88, i32 0, i32 0
  %t91 = load i64, ptr %t90, !tbaa !24
  store i64 %t91, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 33
  %t97 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aatRec_3e_2eLen_3ccompiler_2fcheck_3aatRec_3e(ptr %v0, ptr %t95)
  store i64 %t97, ptr %l54
  br label %bb28
bb28:
  %t98 = load i64, ptr %l54, !tbaa !24
  store i64 %t98, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t99 = load i64, ptr %l8, !tbaa !24
  %t100 = load i64, ptr %l7, !tbaa !24
  %t103 = icmp sgt i64 %t99, %t100
  br i1 %t103, label %bb29, label %bb30
bb29:
  %t105 = load i64, ptr %l9, !tbaa !24
  %t107 = icmp sgt i64 %t105, 0
  br i1 %t107, label %bb31, label %bb32
bb30:
  store i64 0, ptr %l58, !tbaa !24
  br label %bb34
bb31:
  %t109 = load i64, ptr %l8, !tbaa !24
  %t110 = load i64, ptr %l7, !tbaa !24
  %t113 = sub i64 %t109, %t110
  %t114 = load i64, ptr %l9, !tbaa !24
  %t117 = add i64 %t113, %t114
  %t119 = sub i64 %t117, 1
  %t120 = load i64, ptr %l9, !tbaa !24
  %t123 = sdiv i64 %t119, %t120
  store i64 %t123, ptr %l61, !tbaa !24
  br label %bb33
bb32:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb33
bb33:
  %t125 = load i64, ptr %l61, !tbaa !24
  store i64 %t125, ptr %l58, !tbaa !24
  br label %bb34
bb34:
  %t126 = load i64, ptr %l58, !tbaa !24
  store i64 %t126, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb35
bb35:
  store %olang.scope zeroinitializer, ptr %s6
  %t127 = load i64, ptr %l11, !tbaa !24
  %t128 = load i64, ptr %l10, !tbaa !24
  %t131 = icmp slt i64 %t127, %t128
  %t133 = xor i1 %t131, true
  br i1 %t133, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s6)
  br label %bb48
bb37:
  br label %bb38
bb38:
  %t135 = load i64, ptr %l7, !tbaa !24
  %t136 = load i64, ptr %l11, !tbaa !24
  %t137 = load i64, ptr %l9, !tbaa !24
  %t140 = mul i64 %t136, %t137
  %t143 = add i64 %t135, %t140
  store i64 %t143, ptr %l12, !tbaa !24
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/check:Checker", ptr %t145, i32 0, i32 33
  %t148 = load i64, ptr %l12, !tbaa !24
  %t151 = call %"compiler/check:atRec" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aatRec_3e_2eAt_3ccompiler_2fcheck_3aatRec_3e(ptr %v0, ptr %s6, ptr %t147, i64 %t148)
  store %"compiler/check:atRec" %t151, ptr %l82
  br label %bb39
bb39:
  %t152 = getelementptr %"compiler/check:atRec", ptr %l82, i32 0, i32 0
  %t153 = load i64, ptr %t152, !tbaa !24
  %t154 = load i64, ptr %l6, !tbaa !24
  %t157 = icmp eq i64 %t153, %t154
  br i1 %t157, label %bb40, label %bb41
bb40:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/check:Checker", ptr %t159, i32 0, i32 33
  %t162 = load i64, ptr %l12, !tbaa !24
  %t165 = call %"compiler/check:atRec" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aatRec_3e_2eAt_3ccompiler_2fcheck_3aatRec_3e(ptr %v0, ptr %s6, ptr %t161, i64 %t162)
  store %"compiler/check:atRec" %t165, ptr %l90
  br label %bb42
bb41:
  store i1 false, ptr %l86, !tbaa !21
  br label %bb43
bb42:
  %t166 = getelementptr %"compiler/check:atRec", ptr %l90, i32 0, i32 1
  %t167 = load i64, ptr %t166, !tbaa !24
  %t168 = load i32, ptr %l5, !tbaa !23
  %t170 = sext i32 %t168 to i64
  %t173 = icmp eq i64 %t167, %t170
  store i1 %t173, ptr %l86, !tbaa !21
  br label %bb43
bb43:
  %t175 = load i1, ptr %l86, !tbaa !21
  br i1 %t175, label %bb44, label %bb45
bb44:
  %t176 = load i64, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  store i64 %t176, ptr %rv
  br label %ret
bb45:
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s6)
  br label %bb47
bb47:
  %t178 = load i64, ptr %l11, !tbaa !24
  %t180 = add i64 %t178, 1
  store i64 %t180, ptr %l11, !tbaa !24
  br label %bb35
bb48:
  store i64 -1, ptr %rv
  br label %ret
bb49:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarInArray(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i64 %a3, i1 %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l18 = alloca i32
  %l22 = alloca i1
  %l27 = alloca i64
  %l30 = alloca i1
  %l35 = alloca i64
  %l40 = alloca ptr
  %l45 = alloca i32
  %l50 = alloca i1
  %l53 = alloca ptr
  %l58 = alloca i32
  %l63 = alloca i1
  %l68 = alloca ptr
  %l73 = alloca i32
  %l74 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l90 = alloca i1
  %s7 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l5, !tbaa !24
  %t3 = icmp sgt i64 %t1, 16
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 2
  %t12 = load i32, ptr %l1, !tbaa !23
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t15, ptr %l18
  br label %bb4
bb4:
  %t16 = load i32, ptr %l18
  store i32 %t16, ptr %l6
  %t17 = load i32, ptr %l6
  %t19 = trunc i64 25 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb16
bb7:
  br i1 %a4, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Program", ptr %t27, i32 0, i32 2
  %t30 = load i32, ptr %l1, !tbaa !23
  %t33 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t29, i32 %t30)
  store i64 %t33, ptr %l27
  br label %bb10
bb9:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb11
bb10:
  %t34 = load i64, ptr %l2, !tbaa !24
  %t35 = load i64, ptr %l27, !tbaa !24
  %t37 = icmp eq i64 %t35, %t34
  store i1 %t37, ptr %l22, !tbaa !21
  br label %bb11
bb11:
  %t39 = load i1, ptr %l22, !tbaa !21
  br i1 %t39, label %bb12, label %bb13
bb12:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/check:Checker", ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = getelementptr %"compiler/generic:Program", ptr %t43, i32 0, i32 2
  %t46 = load i32, ptr %l1, !tbaa !23
  %t49 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t45, i32 %t46)
  store i64 %t49, ptr %l35
  br label %bb14
bb13:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb15
bb14:
  %t50 = load i64, ptr %l3, !tbaa !24
  %t51 = load i64, ptr %l35, !tbaa !24
  %t53 = icmp eq i64 %t51, %t50
  store i1 %t53, ptr %l30, !tbaa !21
  br label %bb15
bb15:
  %t55 = load i1, ptr %l30, !tbaa !21
  store i1 %t55, ptr %rv
  br label %ret
bb16:
  %t56 = load i32, ptr %l6
  %t58 = trunc i64 19 to i32
  %t59 = icmp eq i32 %t56, %t58
  br i1 %t59, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb22
bb19:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l40, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 2
  %t68 = load i32, ptr %l1, !tbaa !23
  %t71 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t67, i32 %t68)
  store i32 %t71, ptr %l45
  br label %bb20
bb20:
  %t72 = load i64, ptr %l2, !tbaa !24
  %t73 = load i64, ptr %l3, !tbaa !24
  %t74 = load i64, ptr %l5, !tbaa !24
  %t76 = add i64 %t74, 1
  %t77 = load ptr, ptr %l40, !tbaa !29
  %t78 = load i32, ptr %l45, !tbaa !23
  %t82 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarInArray(ptr %v0, ptr %t77, i32 %t78, i64 %t72, i64 %t73, i1 true, i64 %t76)
  store i1 %t82, ptr %l50
  br label %bb21
bb21:
  %t83 = load i1, ptr %l50, !tbaa !21
  store i1 %t83, ptr %rv
  br label %ret
bb22:
  %t84 = load i32, ptr %l6
  %t86 = trunc i64 20 to i32
  %t87 = icmp eq i32 %t84, %t86
  br i1 %t87, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb28
bb25:
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l53, !tbaa !29
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/check:Checker", ptr %t90, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t95 = getelementptr %"compiler/generic:Program", ptr %t93, i32 0, i32 2
  %t96 = load i32, ptr %l1, !tbaa !23
  %t99 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t95, i32 %t96)
  store i32 %t99, ptr %l58
  br label %bb26
bb26:
  %t100 = load i64, ptr %l2, !tbaa !24
  %t101 = load i64, ptr %l3, !tbaa !24
  %t102 = load i64, ptr %l5, !tbaa !24
  %t104 = add i64 %t102, 1
  %t105 = load ptr, ptr %l53, !tbaa !29
  %t106 = load i32, ptr %l58, !tbaa !23
  %t110 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarInArray(ptr %v0, ptr %t105, i32 %t106, i64 %t100, i64 %t101, i1 false, i64 %t104)
  store i1 %t110, ptr %l63
  br label %bb27
bb27:
  %t111 = load i1, ptr %l63, !tbaa !21
  store i1 %t111, ptr %rv
  br label %ret
bb28:
  %t112 = load i32, ptr %l6
  %t114 = trunc i64 18 to i32
  %t115 = icmp eq i32 %t112, %t114
  br i1 %t115, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb44
bb31:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/check:Checker", ptr %t117, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t122 = getelementptr %"compiler/generic:Program", ptr %t120, i32 0, i32 2
  store ptr %t122, ptr %l68, !tbaa !29
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/check:Checker", ptr %t123, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t128 = getelementptr %"compiler/generic:Program", ptr %t126, i32 0, i32 2
  %t129 = load i32, ptr %l1, !tbaa !23
  %t132 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t128, i32 %t129)
  store i32 %t132, ptr %l73
  br label %bb32
bb32:
  %t133 = load ptr, ptr %l68, !tbaa !29
  %t134 = load i32, ptr %l73, !tbaa !23
  %t135 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t133, i32 %t134)
  store { i64, ptr } %t135, ptr %l74
  br label %bb33
bb33:
  %t136 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t136, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t137 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t137, 0
  store i64 %t139, ptr %l9, !tbaa !24
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s7
  %t141 = load i64, ptr %l8, !tbaa !24
  %t142 = load i64, ptr %l9, !tbaa !24
  %t145 = icmp slt i64 %t141, %t142
  %t147 = xor i1 %t145, true
  br i1 %t147, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s7)
  br label %bb43
bb36:
  br label %bb37
bb37:
  %t149 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t149, ptr %l81, !tbaa !27
  %t150 = load i64, ptr %l8, !tbaa !24
  %t152 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = getelementptr i32, ptr %t153, i64 %t150
  %t155 = load i32, ptr %t154, !tbaa !33
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = load i64, ptr %l2, !tbaa !24
  %t160 = load i64, ptr %l3, !tbaa !24
  %t161 = load i64, ptr %l5, !tbaa !24
  %t163 = add i64 %t161, 1
  %t169 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarInArray(ptr %v0, ptr %t157, i32 %t155, i64 %t159, i64 %t160, i1 true, i64 %t163)
  store i1 %t169, ptr %l90
  br label %bb38
bb38:
  %t170 = load i1, ptr %l90, !tbaa !21
  br i1 %t170, label %bb39, label %bb40
bb39:
  call void @__olang_scope_close(ptr %s7)
  store i1 true, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s7)
  br label %bb42
bb42:
  %t172 = load i64, ptr %l8, !tbaa !24
  %t174 = add i64 %t172, 1
  store i64 %t174, ptr %l8, !tbaa !24
  br label %bb34
bb43:
  store i1 false, ptr %rv
  br label %ret
bb44:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalk(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca i1
  %l44 = alloca ptr
  %l48 = alloca ptr
  %l49 = alloca ptr
  %l57 = alloca ptr
  %l61 = alloca ptr
  %l62 = alloca ptr
  %l67 = alloca i32
  %l74 = alloca i32
  %l80 = alloca i1
  %l81 = alloca i32
  %l88 = alloca i32
  %l92 = alloca i64
  %l94 = alloca ptr
  %l97 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l100 = alloca i1
  %l101 = alloca i1
  %l105 = alloca i1
  %l106 = alloca ptr
  %l108 = alloca ptr
  %l109 = alloca i1
  %l110 = alloca ptr
  %l111 = alloca ptr
  %l112 = alloca i32
  %l115 = alloca %"compiler/source:Span"
  %l116 = alloca ptr
  %l129 = alloca ptr
  %l130 = alloca %"compiler/source:Span"
  %l132 = alloca i32
  %l133 = alloca i64
  %l134 = alloca ptr
  %l135 = alloca %"compiler/source:Span"
  %l138 = alloca i32
  %l139 = alloca ptr
  %l140 = alloca %"compiler/source:Span"
  %l142 = alloca i32
  %l143 = alloca ptr
  %l146 = alloca ptr
  %l147 = alloca %"compiler/source:Span"
  %l149 = alloca i32
  %l150 = alloca i64
  %l151 = alloca ptr
  %l152 = alloca %"compiler/source:Span"
  %l155 = alloca i32
  %l156 = alloca ptr
  %l157 = alloca %"compiler/source:Span"
  %l159 = alloca i32
  %l160 = alloca i32
  %l164 = alloca ptr
  %l165 = alloca ptr
  %l180 = alloca ptr
  %l184 = alloca i32
  %l189 = alloca i32
  %l193 = alloca ptr
  %l198 = alloca i32
  %l199 = alloca { i64, ptr }
  %l205 = alloca i64
  %l208 = alloca i64
  %l227 = alloca { i64, ptr }
  %l230 = alloca { i64, ptr }
  %l231 = alloca i1
  %l232 = alloca i1
  %l235 = alloca ptr
  %l239 = alloca { i64, ptr }
  %l242 = alloca i32
  %l243 = alloca { i64, ptr }
  %l257 = alloca ptr
  %l260 = alloca %"compiler/source:Span"
  %l263 = alloca { i64, ptr }
  %l265 = alloca %"compiler/msgs:Msg"
  %l266 = alloca i64
  %l271 = alloca i64
  %l275 = alloca i64
  %l278 = alloca i1
  %l281 = alloca i1
  %l285 = alloca i1
  %l309 = alloca i64
  %l312 = alloca ptr
  %l313 = alloca %"compiler/source:Span"
  %l316 = alloca %"compiler/source:Span"
  %l317 = alloca i64
  %l319 = alloca ptr
  %l322 = alloca { i64, ptr }
  %l325 = alloca { i64, ptr }
  %l329 = alloca ptr
  %l330 = alloca ptr
  %l331 = alloca ptr
  %l334 = alloca i32
  %l335 = alloca i32
  %l336 = alloca i64
  %l339 = alloca ptr
  %l342 = alloca %"compiler/source:Span"
  %l355 = alloca i64
  %l358 = alloca i64
  %l361 = alloca i1
  %l364 = alloca ptr
  %l367 = alloca ptr
  %l371 = alloca i32
  %l372 = alloca i32
  %l373 = alloca { i64, ptr }
  %l377 = alloca ptr
  %l378 = alloca ptr
  %l383 = alloca i1
  %l398 = alloca i1
  %l400 = alloca ptr
  %l403 = alloca %"compiler/source:Span"
  %l406 = alloca { i64, ptr }
  %l408 = alloca %"compiler/msgs:Msg"
  %l409 = alloca i64
  %s0 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %rv = alloca ptr
  %t196 = alloca { i64, [3 x i64] }, align 8
  %t235 = alloca { i64, [3 x i64] }, align 8
  %t283 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:ForIn", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l5, !tbaa !29
  store ptr %t6, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t7 = load ptr, ptr %l32, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l32, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 25
  store i1 %t13, ptr %l33, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l33, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l5, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t17, i32 0, i32 1
  %t19 = load { i64, ptr }, ptr %t18
  store { i64, ptr } %t19, ptr %l6, !tbaa !27
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load %"compiler/source:Span", ptr %l1
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t24 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t25 = load ptr, ptr %l3, !tbaa !29
  %t26 = load i32, ptr %l4, !tbaa !23
  %t33 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforRange(ptr %v0, ptr %v1, ptr %v1, ptr %v2, ptr %t21, %"compiler/source:Span" %t22, ptr %t23, { i64, ptr } %t24, ptr %t25, i32 %t26)
  store ptr %t33, ptr %l44
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t34 = load ptr, ptr %l44, !tbaa !29
  store ptr %t34, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"compiler/ast:ForIn", ptr %t35, i32 0, i32 3
  %t38 = load i1, ptr %t37, !tbaa !21
  br i1 %t38, label %bb9, label %bb10
bb9:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t40)
  store ptr %t42, ptr %l48
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t43 = load ptr, ptr %l48, !tbaa !29
  store ptr %t43, ptr %l49, !tbaa !29
  %t44 = load ptr, ptr %l49, !tbaa !29
  %t45 = getelementptr %"compiler/check:frame", ptr %t44, i32 0, i32 15
  %t46 = load i64, ptr %t45, !tbaa !24
  %t48 = add i64 %t46, 1
  %t50 = load ptr, ptr %l49, !tbaa !29
  %t51 = getelementptr %"compiler/check:frame", ptr %t50, i32 0, i32 15
  store i64 %t48, ptr %t51, !tbaa !24
  br label %bb12
bb12:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t55 = getelementptr %"compiler/ast:ForIn", ptr %t53, i32 0, i32 2
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t62 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t52, ptr %t56, i32 %t58)
  store ptr %t62, ptr %l57
  br label %bb13
bb13:
  %t63 = load ptr, ptr %l57, !tbaa !29
  store ptr %t63, ptr %l7, !tbaa !29
  %t64 = load ptr, ptr %l2, !tbaa !29
  %t66 = getelementptr %"compiler/ast:ForIn", ptr %t64, i32 0, i32 3
  %t67 = load i1, ptr %t66, !tbaa !21
  br i1 %t67, label %bb14, label %bb15
bb14:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t69)
  store ptr %t71, ptr %l61
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t72 = load ptr, ptr %l61, !tbaa !29
  store ptr %t72, ptr %l62, !tbaa !29
  %t73 = load ptr, ptr %l62, !tbaa !29
  %t74 = getelementptr %"compiler/check:frame", ptr %t73, i32 0, i32 15
  %t75 = load i64, ptr %t74, !tbaa !24
  %t77 = sub i64 %t75, 1
  %t79 = load ptr, ptr %l62, !tbaa !29
  %t80 = getelementptr %"compiler/check:frame", ptr %t79, i32 0, i32 15
  store i64 %t77, ptr %t80, !tbaa !24
  br label %bb17
bb17:
  %t81 = load ptr, ptr %l7, !tbaa !29
  %t84 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t81)
  store i32 %t84, ptr %l67
  br label %bb18
bb18:
  %t85 = load i32, ptr %l67, !tbaa !23
  store i32 %t85, ptr %l8, !tbaa !23
  %t86 = load i32, ptr %l8, !tbaa !23
  %t87 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t90 = icmp eq i32 %t86, %t87
  br i1 %t90, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load i32, ptr %l8, !tbaa !23
  %t97 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t93, i32 %t94)
  store i32 %t97, ptr %l74
  br label %bb22
bb22:
  %t98 = load i32, ptr %l74, !tbaa !23
  store i32 %t98, ptr %l9, !tbaa !23
  %t99 = load i32, ptr %l9, !tbaa !23
  %t100 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t103 = icmp ne i32 %t99, %t100
  br i1 %t103, label %bb23, label %bb24
bb23:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load i32, ptr %l8, !tbaa !23
  %t109 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t105, i32 %t106)
  store i1 %t109, ptr %l80
  br label %bb25
bb24:
  br label %bb57
bb25:
  %t110 = load i1, ptr %l80, !tbaa !21
  br i1 %t110, label %bb26, label %bb27
bb26:
  %t111 = load i32, ptr %l8, !tbaa !23
  store i32 %t111, ptr %l81, !tbaa !23
  br label %bb29
bb27:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/check:Checker", ptr %t113, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t118 = getelementptr %"compiler/generic:Program", ptr %t116, i32 0, i32 2
  %t119 = load i32, ptr %l8, !tbaa !23
  %t120 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t124 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t118, i32 %t119, i64 %t120)
  store i32 %t124, ptr %l88
  br label %bb28
bb28:
  %t125 = load i32, ptr %l88, !tbaa !23
  store i32 %t125, ptr %l81, !tbaa !23
  br label %bb29
bb29:
  %t126 = load i32, ptr %l81, !tbaa !23
  store i32 %t126, ptr %l10, !tbaa !23
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load %"compiler/source:Span", ptr %l1
  %t129 = load i32, ptr %l10, !tbaa !23
  %t133 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t127, %"compiler/source:Span" %t128, i32 %t129)
  store i64 %t133, ptr %l92
  br label %bb30
bb30:
  %t134 = load i64, ptr %l92, !tbaa !24
  store i64 %t134, ptr %l11, !tbaa !24
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/check:Checker", ptr %t135, i32 0, i32 55
  store ptr %t137, ptr %l94, !tbaa !29
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load i64, ptr %l11, !tbaa !24
  %t142 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %t138, i64 %t139)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t142, ptr %l97
  br label %bb31
bb31:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load i32, ptr %l8, !tbaa !23
  %t147 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t143, i32 %t144)
  store i1 %t147, ptr %l100
  br label %bb32
bb32:
  %t148 = load i1, ptr %l100, !tbaa !21
  br i1 %t148, label %bb33, label %bb34
bb33:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load ptr, ptr %l7, !tbaa !29
  %t154 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v0, ptr %t149, ptr %t150)
  store i1 %t154, ptr %l105
  br label %bb35
bb34:
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l106, !tbaa !29
  %t156 = load ptr, ptr %l7, !tbaa !29
  %t158 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %t156)
  store ptr %t158, ptr %l108
  br label %bb36
bb35:
  %t159 = load i1, ptr %l105, !tbaa !21
  store i1 %t159, ptr %l101, !tbaa !21
  br label %bb38
bb36:
  %t160 = load ptr, ptr %l106, !tbaa !29
  %t161 = load ptr, ptr %l108, !tbaa !29
  %t162 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroPlace(ptr %v0, ptr %v0, ptr %t160, ptr %t161)
  store i1 %t162, ptr %l109
  br label %bb37
bb37:
  %t163 = load i1, ptr %l109, !tbaa !21
  store i1 %t163, ptr %l101, !tbaa !21
  br label %bb38
bb38:
  %t164 = load ptr, ptr %l94, !tbaa !29
  %t165 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l97
  %t166 = load i1, ptr %l101, !tbaa !21
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t164, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t165, i1 %t166)
  br label %bb39
bb39:
  %t167 = load ptr, ptr %l0, !tbaa !29
  store ptr %t167, ptr %l110, !tbaa !29
  %t168 = load ptr, ptr %l7, !tbaa !29
  store ptr %t168, ptr %l111, !tbaa !29
  %t169 = load i32, ptr %l10, !tbaa !23
  store i32 %t169, ptr %l112, !tbaa !23
  %t170 = load ptr, ptr %l2, !tbaa !29
  %t172 = getelementptr %"compiler/ast:ForIn", ptr %t170, i32 0, i32 2
  %t173 = load ptr, ptr %t172, !tbaa !29
  %t175 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t173)
  store %"compiler/source:Span" %t175, ptr %l115
  br label %bb40
bb40:
  %t176 = load ptr, ptr %l110, !tbaa !29
  %t177 = load ptr, ptr %l111, !tbaa !29
  %t178 = load i32, ptr %l112, !tbaa !23
  %t179 = load %"compiler/source:Span", ptr %l115
  %t180 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t176, ptr %t177, i32 %t178, %"compiler/source:Span" %t179)
  store ptr %t180, ptr %l116
  br label %bb41
bb41:
  %t181 = load ptr, ptr %l116, !tbaa !29
  store ptr %t181, ptr %l12, !tbaa !29
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load i64, ptr %l11, !tbaa !24
  %t184 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroTrack(ptr %v0, ptr %v0, ptr %t182, i64 %t183, ptr %t184)
  br label %bb42
bb42:
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load %"compiler/source:Span", ptr %l1
  %t191 = load i64, ptr %l11, !tbaa !24
  %t193 = trunc i64 %t191 to i32
  %t195 = load ptr, ptr %l12, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t196
  %t197 = getelementptr { i64, [3 x i64] }, ptr %t196, i32 0, i32 0
  store i64 0, ptr %t197
  %t199 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t190, 0
  %t201 = insertvalue { %"compiler/source:Span", i32, ptr } %t199, i32 %t193, 1
  %t203 = insertvalue { %"compiler/source:Span", i32, ptr } %t201, ptr %t195, 2
  %t204 = getelementptr { i64, [3 x i64] }, ptr %t196, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t203, ptr %t204
  %t205 = load { i64, [3 x i64] }, ptr %t196
  %t207 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t205, ptr %t207
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t189, ptr %t207)
  br label %bb43
bb43:
  %t210 = load ptr, ptr %l0, !tbaa !29
  store ptr %t210, ptr %l129, !tbaa !29
  %t211 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t211, ptr %l130
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t212)
  store i32 %t214, ptr %l132
  br label %bb44
bb44:
  %t215 = load ptr, ptr %l129, !tbaa !29
  %t216 = load %"compiler/source:Span", ptr %l130
  %t217 = load i32, ptr %l132, !tbaa !23
  %t218 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t215, %"compiler/source:Span" %t216, i32 %t217)
  store i64 %t218, ptr %l133
  br label %bb45
bb45:
  %t219 = load i64, ptr %l133, !tbaa !24
  store i64 %t219, ptr %l13, !tbaa !24
  %t220 = load ptr, ptr %l0, !tbaa !29
  store ptr %t220, ptr %l134, !tbaa !29
  %t221 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t221, ptr %l135
  %t222 = load i64, ptr %l13, !tbaa !24
  %t224 = trunc i64 %t222 to i32
  store i32 %t224, ptr %l138, !tbaa !23
  %t226 = load ptr, ptr %l0, !tbaa !29
  store ptr %t226, ptr %l139, !tbaa !29
  %t227 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t227, ptr %l140
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t228)
  store i32 %t230, ptr %l142
  br label %bb46
bb46:
  %t231 = load ptr, ptr %l139, !tbaa !29
  %t232 = load %"compiler/source:Span", ptr %l140
  %t233 = load i32, ptr %l142, !tbaa !23
  %t234 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t231, %"compiler/source:Span" %t232, i32 %t233, i64 0)
  store ptr %t234, ptr %l143
  br label %bb47
bb47:
  store { i64, [3 x i64] } zeroinitializer, ptr %t235
  %t236 = getelementptr { i64, [3 x i64] }, ptr %t235, i32 0, i32 0
  store i64 0, ptr %t236
  %t237 = load %"compiler/source:Span", ptr %l135
  %t238 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t237, 0
  %t239 = load i32, ptr %l138, !tbaa !23
  %t240 = insertvalue { %"compiler/source:Span", i32, ptr } %t238, i32 %t239, 1
  %t241 = load ptr, ptr %l143, !tbaa !29
  %t242 = insertvalue { %"compiler/source:Span", i32, ptr } %t240, ptr %t241, 2
  %t243 = getelementptr { i64, [3 x i64] }, ptr %t235, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t242, ptr %t243
  %t244 = load { i64, [3 x i64] }, ptr %t235
  %t246 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t244, ptr %t246
  %t247 = load ptr, ptr %l134, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t247, ptr %t246)
  br label %bb48
bb48:
  %t249 = load ptr, ptr %l0, !tbaa !29
  store ptr %t249, ptr %l146, !tbaa !29
  %t250 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t250, ptr %l147
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t253 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t251)
  store i32 %t253, ptr %l149
  br label %bb49
bb49:
  %t254 = load ptr, ptr %l146, !tbaa !29
  %t255 = load %"compiler/source:Span", ptr %l147
  %t256 = load i32, ptr %l149, !tbaa !23
  %t257 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t254, %"compiler/source:Span" %t255, i32 %t256)
  store i64 %t257, ptr %l150
  br label %bb50
bb50:
  %t258 = load i64, ptr %l150, !tbaa !24
  store i64 %t258, ptr %l14, !tbaa !24
  %t259 = load ptr, ptr %l0, !tbaa !29
  store ptr %t259, ptr %l151, !tbaa !29
  %t260 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t260, ptr %l152
  %t261 = load i64, ptr %l14, !tbaa !24
  %t263 = trunc i64 %t261 to i32
  store i32 %t263, ptr %l155, !tbaa !23
  %t265 = load ptr, ptr %l0, !tbaa !29
  store ptr %t265, ptr %l156, !tbaa !29
  %t266 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t266, ptr %l157
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t267)
  store i32 %t269, ptr %l159
  br label %bb51
bb51:
  store i32 22, ptr %l160
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t271 = load %"compiler/source:Span", ptr %l1
  %t272 = load i64, ptr %l11, !tbaa !24
  %t276 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t270, %"compiler/source:Span" %t271, i64 %t272)
  store ptr %t276, ptr %l164
  br label %bb52
bb52:
  %t277 = load ptr, ptr %l156, !tbaa !29
  %t278 = load %"compiler/source:Span", ptr %l157
  %t279 = load i32, ptr %l159, !tbaa !23
  %t280 = load i32, ptr %l160
  %t281 = load ptr, ptr %l164, !tbaa !29
  %t282 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t277, %"compiler/source:Span" %t278, i32 %t279, i32 %t280, ptr %t281, ptr null)
  store ptr %t282, ptr %l165
  br label %bb53
bb53:
  store { i64, [3 x i64] } zeroinitializer, ptr %t283
  %t284 = getelementptr { i64, [3 x i64] }, ptr %t283, i32 0, i32 0
  store i64 0, ptr %t284
  %t285 = load %"compiler/source:Span", ptr %l152
  %t286 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t285, 0
  %t287 = load i32, ptr %l155, !tbaa !23
  %t288 = insertvalue { %"compiler/source:Span", i32, ptr } %t286, i32 %t287, 1
  %t289 = load ptr, ptr %l165, !tbaa !29
  %t290 = insertvalue { %"compiler/source:Span", i32, ptr } %t288, ptr %t289, 2
  %t291 = getelementptr { i64, [3 x i64] }, ptr %t283, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t290, ptr %t291
  %t292 = load { i64, [3 x i64] }, ptr %t283
  %t294 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t292, ptr %t294
  %t295 = load ptr, ptr %l151, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t295, ptr %t294)
  br label %bb54
bb54:
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t298 = load %"compiler/source:Span", ptr %l1
  %t299 = load ptr, ptr %l2, !tbaa !29
  %t300 = load i64, ptr %l13, !tbaa !24
  %t301 = load i64, ptr %l14, !tbaa !24
  %t302 = load i64, ptr %l11, !tbaa !24
  %t303 = load i32, ptr %l9, !tbaa !23
  %t304 = load ptr, ptr %l3, !tbaa !29
  %t305 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecounted(ptr %v0, ptr %v1, ptr %v2, ptr %t297, %"compiler/source:Span" %t298, ptr %t299, i64 %t300, i64 %t301, i64 %t302, i32 %t303, i64 -1, i64 -1, ptr %t304, i32 %t305)
  br label %bb55
bb55:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t316 = load %"compiler/source:Span", ptr %l1
  %t317 = load i64, ptr %l14, !tbaa !24
  %t321 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t315, %"compiler/source:Span" %t316, i64 %t317)
  store ptr %t321, ptr %l180
  br label %bb56
bb56:
  %t322 = load ptr, ptr %l180, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t322, ptr %rv
  br label %ret
bb57:
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t325 = load i32, ptr %l8, !tbaa !23
  %t328 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t324, i32 %t325)
  store i32 %t328, ptr %l184
  br label %bb58
bb58:
  %t329 = load i32, ptr %l184, !tbaa !23
  store i32 %t329, ptr %l15, !tbaa !23
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t332 = getelementptr %"compiler/check:Checker", ptr %t330, i32 0, i32 1
  %t333 = load ptr, ptr %t332, !tbaa !29
  %t335 = getelementptr %"compiler/generic:Program", ptr %t333, i32 0, i32 2
  %t336 = load i32, ptr %l15, !tbaa !23
  %t339 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t335, i32 %t336)
  store i32 %t339, ptr %l189
  br label %bb59
bb59:
  %t340 = load i32, ptr %l189
  %t342 = trunc i64 29 to i32
  %t343 = icmp eq i32 %t340, %t342
  br i1 %t343, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s7
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t347 = getelementptr %"compiler/check:Checker", ptr %t345, i32 0, i32 1
  %t348 = load ptr, ptr %t347, !tbaa !29
  store ptr %t348, ptr %l193, !tbaa !29
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t351 = getelementptr %"compiler/check:Checker", ptr %t349, i32 0, i32 1
  %t352 = load ptr, ptr %t351, !tbaa !29
  %t354 = getelementptr %"compiler/generic:Program", ptr %t352, i32 0, i32 2
  %t355 = load i32, ptr %l15, !tbaa !23
  %t358 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t354, i32 %t355)
  store i32 %t358, ptr %l198
  br label %bb62
bb61:
  br label %bb91
bb62:
  %t359 = load ptr, ptr %l193, !tbaa !29
  %t360 = load i32, ptr %l198, !tbaa !23
  %t361 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %t359, i32 %t360)
  store { i64, ptr } %t361, ptr %l199
  br label %bb63
bb63:
  %t362 = load { i64, ptr }, ptr %l199, !tbaa !27
  store { i64, ptr } %t362, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t363 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t365 = extractvalue { i64, ptr } %t363, 0
  store i64 %t365, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t367 = load i64, ptr %l18, !tbaa !24
  %t368 = load i64, ptr %l17, !tbaa !24
  %t371 = icmp sgt i64 %t367, %t368
  br i1 %t371, label %bb64, label %bb65
bb64:
  %t373 = load i64, ptr %l19, !tbaa !24
  %t375 = icmp sgt i64 %t373, 0
  br i1 %t375, label %bb66, label %bb67
bb65:
  store i64 0, ptr %l205, !tbaa !24
  br label %bb69
bb66:
  %t377 = load i64, ptr %l18, !tbaa !24
  %t378 = load i64, ptr %l17, !tbaa !24
  %t381 = sub i64 %t377, %t378
  %t382 = load i64, ptr %l19, !tbaa !24
  %t385 = add i64 %t381, %t382
  %t387 = sub i64 %t385, 1
  %t388 = load i64, ptr %l19, !tbaa !24
  %t391 = sdiv i64 %t387, %t388
  store i64 %t391, ptr %l208, !tbaa !24
  br label %bb68
bb67:
  store i64 0, ptr %l208, !tbaa !24
  br label %bb68
bb68:
  %t393 = load i64, ptr %l208, !tbaa !24
  store i64 %t393, ptr %l205, !tbaa !24
  br label %bb69
bb69:
  %t394 = load i64, ptr %l205, !tbaa !24
  store i64 %t394, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb70
bb70:
  store %olang.scope zeroinitializer, ptr %s9
  %t395 = load i64, ptr %l21, !tbaa !24
  %t396 = load i64, ptr %l20, !tbaa !24
  %t399 = icmp slt i64 %t395, %t396
  %t401 = xor i1 %t399, true
  br i1 %t401, label %bb71, label %bb72
bb71:
  call void @__olang_scope_close(ptr %s9)
  br label %bb86
bb72:
  br label %bb73
bb73:
  %t403 = load i64, ptr %l17, !tbaa !24
  %t404 = load i64, ptr %l21, !tbaa !24
  %t405 = load i64, ptr %l19, !tbaa !24
  %t408 = mul i64 %t404, %t405
  %t411 = add i64 %t403, %t408
  store i64 %t411, ptr %l22, !tbaa !24
  %t413 = load ptr, ptr %l0, !tbaa !29
  %t414 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t414, ptr %l227, !tbaa !27
  %t415 = load i64, ptr %l22, !tbaa !24
  %t417 = getelementptr { i64, ptr }, ptr %l227, i32 0, i32 1
  %t418 = load ptr, ptr %t417, !tbaa !27
  %t419 = getelementptr %"compiler/generic:AnySlot", ptr %t418, i64 %t415
  %t420 = getelementptr %"compiler/generic:AnySlot", ptr %t419, i32 0, i32 0
  %t421 = load i32, ptr %t420, !tbaa !23
  %t424 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t413, i32 %t421)
  store { i64, ptr } %t424, ptr %l230
  br label %bb74
bb74:
  %t425 = load { i64, ptr }, ptr %l230, !tbaa !27
  %t426 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s9, { i64, ptr } %t425, { i64, ptr } { i64 4, ptr @.d40 })
  store i1 %t426, ptr %l231
  br label %bb75
bb75:
  %t427 = load i1, ptr %l231, !tbaa !21
  br i1 %t427, label %bb76, label %bb77
bb76:
  %t428 = load ptr, ptr %l0, !tbaa !29
  %t430 = getelementptr %"compiler/check:Checker", ptr %t428, i32 0, i32 1
  %t431 = load ptr, ptr %t430, !tbaa !29
  %t433 = getelementptr %"compiler/generic:Program", ptr %t431, i32 0, i32 2
  store ptr %t433, ptr %l235, !tbaa !29
  %t434 = load ptr, ptr %l0, !tbaa !29
  %t436 = getelementptr %"compiler/check:Checker", ptr %t434, i32 0, i32 1
  %t437 = load ptr, ptr %t436, !tbaa !29
  %t439 = getelementptr %"compiler/generic:Program", ptr %t437, i32 0, i32 2
  %t440 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t440, ptr %l239, !tbaa !27
  %t441 = load i64, ptr %l22, !tbaa !24
  %t443 = getelementptr { i64, ptr }, ptr %l239, i32 0, i32 1
  %t444 = load ptr, ptr %t443, !tbaa !27
  %t445 = getelementptr %"compiler/generic:AnySlot", ptr %t444, i64 %t441
  %t446 = getelementptr %"compiler/generic:AnySlot", ptr %t445, i32 0, i32 5
  %t447 = load i32, ptr %t446, !tbaa !23
  %t450 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t439, i32 %t447)
  store i32 %t450, ptr %l242
  br label %bb78
bb77:
  store i1 false, ptr %l232, !tbaa !21
  br label %bb80
bb78:
  %t451 = load ptr, ptr %l235, !tbaa !29
  %t452 = load i32, ptr %l242, !tbaa !23
  %t453 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t451, i32 %t452)
  store { i64, ptr } %t453, ptr %l243
  br label %bb79
bb79:
  %t454 = load { i64, ptr }, ptr %l243, !tbaa !27
  %t455 = extractvalue { i64, ptr } %t454, 0
  %t457 = icmp eq i64 %t455, 1
  store i1 %t457, ptr %l232, !tbaa !21
  br label %bb80
bb80:
  %t459 = load i1, ptr %l232, !tbaa !21
  br i1 %t459, label %bb81, label %bb82
bb81:
  %t460 = load ptr, ptr %l0, !tbaa !29
  %t461 = load %"compiler/source:Span", ptr %l1
  %t462 = load ptr, ptr %l2, !tbaa !29
  %t463 = load ptr, ptr %l7, !tbaa !29
  %t464 = load i64, ptr %l22, !tbaa !24
  %t466 = sub i64 -2, %t464
  %t467 = load ptr, ptr %l3, !tbaa !29
  %t468 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkIter(ptr %v0, ptr %v1, ptr %v2, ptr %t460, %"compiler/source:Span" %t461, ptr %t462, ptr %t463, i64 %t466, ptr %t467, i32 %t468)
  br label %bb83
bb82:
  br label %bb84
bb83:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb84:
  call void @__olang_scope_close(ptr %s9)
  br label %bb85
bb85:
  %t477 = load i64, ptr %l21, !tbaa !24
  %t479 = add i64 %t477, 1
  store i64 %t479, ptr %l21, !tbaa !24
  br label %bb70
bb86:
  %t481 = load ptr, ptr %l0, !tbaa !29
  store ptr %t481, ptr %l257, !tbaa !29
  %t482 = load ptr, ptr %l2, !tbaa !29
  %t484 = getelementptr %"compiler/ast:ForIn", ptr %t482, i32 0, i32 2
  %t485 = load ptr, ptr %t484, !tbaa !29
  %t487 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t485)
  store %"compiler/source:Span" %t487, ptr %l260
  br label %bb87
bb87:
  %t488 = load ptr, ptr %l0, !tbaa !29
  %t489 = load i32, ptr %l8, !tbaa !23
  %t492 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s7, ptr %t488, i32 %t489)
  store { i64, ptr } %t492, ptr %l263
  br label %bb88
bb88:
  %t493 = load { i64, ptr }, ptr %l263, !tbaa !27
  %t494 = extractvalue { i64, ptr } %t493, 0
  %t495 = extractvalue { i64, ptr } %t493, 1
  %t496 = mul i64 %t494, 1
  %t497 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t496)
  call void @llvm.memcpy.p0.p0.i64(ptr %t497, ptr %t495, i64 %t496, i1 false)
  %t498 = insertvalue { i64, ptr } undef, i64 %t494, 0
  %t499 = insertvalue { i64, ptr } %t498, ptr %t497, 1
  %t501 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotIterable(ptr %s7, ptr %s7, { i64, ptr } %t499)
  store %"compiler/msgs:Msg" %t501, ptr %l265
  br label %bb89
bb89:
  %t502 = load ptr, ptr %l257, !tbaa !29
  %t503 = load %"compiler/source:Span", ptr %l260
  %t504 = load %"compiler/msgs:Msg", ptr %l265
  %t505 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t502, %"compiler/source:Span" %t503, %"compiler/msgs:Msg" %t504)
  store i64 %t505, ptr %l266
  br label %bb90
bb90:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb91:
  %t507 = load ptr, ptr %l0, !tbaa !29
  %t508 = load i32, ptr %l15, !tbaa !23
  %t509 = load %"compiler/source:Span", ptr %l1
  %t513 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %s0, ptr %s0, ptr %t507, i32 %t508, { i64, ptr } { i64 7, ptr @.d41 }, i64 1, %"compiler/source:Span" %t509, { i64, ptr } { i64 5, ptr @.d42 })
  store i64 %t513, ptr %l271
  br label %bb92
bb92:
  %t514 = load i64, ptr %l271, !tbaa !24
  store i64 %t514, ptr %l23, !tbaa !24
  %t515 = load ptr, ptr %l0, !tbaa !29
  %t516 = load i32, ptr %l15, !tbaa !23
  %t517 = load %"compiler/source:Span", ptr %l1
  %t521 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %s0, ptr %s0, ptr %t515, i32 %t516, { i64, ptr } { i64 4, ptr @.d43 }, i64 0, %"compiler/source:Span" %t517, { i64, ptr } { i64 5, ptr @.d44 })
  store i64 %t521, ptr %l275
  br label %bb93
bb93:
  %t522 = load i64, ptr %l275, !tbaa !24
  store i64 %t522, ptr %l24, !tbaa !24
  %t523 = load i64, ptr %l24, !tbaa !24
  %t525 = icmp sge i64 %t523, 0
  br i1 %t525, label %bb94, label %bb95
bb94:
  %t527 = load ptr, ptr %l0, !tbaa !29
  %t528 = load i64, ptr %l24, !tbaa !24
  %t531 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eiterShaped(ptr %v0, ptr %t527, i64 %t528)
  store i1 %t531, ptr %l281
  br label %bb96
bb95:
  store i1 false, ptr %l278, !tbaa !21
  br label %bb97
bb96:
  %t532 = load i1, ptr %l281, !tbaa !21
  %t533 = xor i1 %t532, true
  store i1 %t533, ptr %l278, !tbaa !21
  br label %bb97
bb97:
  %t535 = load i1, ptr %l278, !tbaa !21
  br i1 %t535, label %bb98, label %bb99
bb98:
  store i64 -1, ptr %l24, !tbaa !24
  br label %bb100
bb99:
  br label %bb100
bb100:
  %t536 = load i64, ptr %l23, !tbaa !24
  %t538 = icmp sge i64 %t536, 0
  br i1 %t538, label %bb101, label %bb102
bb101:
  %t540 = load i64, ptr %l24, !tbaa !24
  %t542 = icmp slt i64 %t540, 0
  store i1 %t542, ptr %l285, !tbaa !21
  br label %bb103
bb102:
  store i1 false, ptr %l285, !tbaa !21
  br label %bb103
bb103:
  %t544 = load i1, ptr %l285, !tbaa !21
  br i1 %t544, label %bb104, label %bb105
bb104:
  %t545 = load ptr, ptr %l0, !tbaa !29
  %t546 = load %"compiler/source:Span", ptr %l1
  %t547 = load ptr, ptr %l2, !tbaa !29
  %t548 = load ptr, ptr %l7, !tbaa !29
  %t549 = load i64, ptr %l23, !tbaa !24
  %t550 = load ptr, ptr %l3, !tbaa !29
  %t551 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkRuns(ptr %v0, ptr %v1, ptr %v2, ptr %t545, %"compiler/source:Span" %t546, ptr %t547, ptr %t548, i64 %t549, ptr %t550, i32 %t551)
  br label %bb106
bb105:
  br label %bb107
bb106:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb107:
  %t560 = load i64, ptr %l24, !tbaa !24
  %t562 = icmp sge i64 %t560, 0
  br i1 %t562, label %bb108, label %bb109
bb108:
  %t564 = load ptr, ptr %l0, !tbaa !29
  %t565 = load %"compiler/source:Span", ptr %l1
  %t566 = load ptr, ptr %l2, !tbaa !29
  %t567 = load ptr, ptr %l7, !tbaa !29
  %t568 = load i64, ptr %l24, !tbaa !24
  %t569 = load ptr, ptr %l3, !tbaa !29
  %t570 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkIter(ptr %v0, ptr %v1, ptr %v2, ptr %t564, %"compiler/source:Span" %t565, ptr %t566, ptr %t567, i64 %t568, ptr %t569, i32 %t570)
  br label %bb110
bb109:
  br label %bb111
bb110:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb111:
  %t579 = load ptr, ptr %l0, !tbaa !29
  %t580 = load i32, ptr %l15, !tbaa !23
  %t581 = load %"compiler/source:Span", ptr %l1
  %t585 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %s0, ptr %s0, ptr %t579, i32 %t580, { i64, ptr } { i64 4, ptr @.d45 }, i64 0, %"compiler/source:Span" %t581, { i64, ptr } { i64 5, ptr @.d46 })
  store i64 %t585, ptr %l309
  br label %bb112
bb112:
  %t586 = load i64, ptr %l309, !tbaa !24
  store i64 %t586, ptr %l25, !tbaa !24
  %t587 = load i64, ptr %l25, !tbaa !24
  %t589 = icmp sge i64 %t587, 0
  br i1 %t589, label %bb113, label %bb114
bb113:
  store %olang.scope zeroinitializer, ptr %s15
  %t591 = load ptr, ptr %l0, !tbaa !29
  store ptr %t591, ptr %l312, !tbaa !29
  %t592 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t592, ptr %l313
  %t593 = load ptr, ptr %l2, !tbaa !29
  %t595 = getelementptr %"compiler/ast:ForIn", ptr %t593, i32 0, i32 2
  %t596 = load ptr, ptr %t595, !tbaa !29
  %t598 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t596)
  store %"compiler/source:Span" %t598, ptr %l316
  br label %bb115
bb114:
  br label %bb138
bb115:
  %t599 = load i64, ptr %l25, !tbaa !24
  store i64 %t599, ptr %l317, !tbaa !24
  %t600 = load ptr, ptr %l7, !tbaa !29
  store ptr %t600, ptr %l319, !tbaa !29
  %t602 = icmp sge i64 0, 0
  br i1 %t602, label %bb116, label %bb117
bb116:
  %t604 = icmp sle i64 0, 1152921504606846975
  br i1 %t604, label %bb118, label %bb119
bb117:
  call void @__olang_check_failed(ptr @olang_loc_b5c196eacf828aab_2dac07573477728f)
  unreachable
bb118:
  %t606 = mul i64 0, 8
  %t607 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t606)
  %t608 = insertvalue { i64, ptr } undef, i64 0, 0
  %t609 = insertvalue { i64, ptr } %t608, ptr %t607, 1
  store { i64, ptr } %t609, ptr %l322, !tbaa !27
  %t610 = icmp sge i64 0, 0
  br i1 %t610, label %bb120, label %bb121
bb119:
  call void @__olang_check_failed(ptr @olang_loc_b5c196eacf828aab_2dac07573477728f)
  unreachable
bb120:
  %t612 = icmp sle i64 0, 1152921504606846975
  br i1 %t612, label %bb122, label %bb123
bb121:
  call void @__olang_check_failed(ptr @olang_loc_b5c196eacf828aab_2dac07573477728f)
  unreachable
bb122:
  %t614 = mul i64 0, 8
  %t615 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t614)
  %t616 = insertvalue { i64, ptr } undef, i64 0, 0
  %t617 = insertvalue { i64, ptr } %t616, ptr %t615, 1
  store { i64, ptr } %t617, ptr %l325, !tbaa !27
  %t618 = icmp sge i64 0, 0
  br i1 %t618, label %bb124, label %bb125
bb123:
  call void @__olang_check_failed(ptr @olang_loc_b5c196eacf828aab_2dac07573477728f)
  unreachable
bb124:
  %t620 = icmp sle i64 0, 2305843009213693951
  br i1 %t620, label %bb126, label %bb127
bb125:
  call void @__olang_check_failed(ptr @olang_loc_139af6e2a2dcda96_1438f6a9e620193a)
  unreachable
bb126:
  %t622 = mul i64 0, 4
  %t623 = call ptr @__olang_scope_alloc_zeroed(ptr %s15, i64 %t622)
  %t624 = insertvalue { i64, ptr } undef, i64 0, 0
  %t625 = insertvalue { i64, ptr } %t624, ptr %t623, 1
  %t626 = load ptr, ptr %l312, !tbaa !29
  %t627 = load %"compiler/source:Span", ptr %l313
  %t628 = load %"compiler/source:Span", ptr %l316
  %t629 = load i64, ptr %l317, !tbaa !24
  %t630 = load ptr, ptr %l319, !tbaa !29
  %t631 = load { i64, ptr }, ptr %l322, !tbaa !27
  %t632 = load { i64, ptr }, ptr %l325, !tbaa !27
  %t634 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %s15, ptr %t626, %"compiler/source:Span" %t627, %"compiler/source:Span" %t628, i64 %t629, ptr %t630, { i64, ptr } %t631, { i64, ptr } %t632, { i64, ptr } %t625)
  store ptr %t634, ptr %l329
  br label %bb128
bb127:
  call void @__olang_check_failed(ptr @olang_loc_139af6e2a2dcda96_1438f6a9e620193a)
  unreachable
bb128:
  %t635 = load ptr, ptr %l329, !tbaa !29
  store ptr %t635, ptr %l26, !tbaa !29
  %t636 = load ptr, ptr %l0, !tbaa !29
  store ptr %t636, ptr %l330, !tbaa !29
  %t637 = load ptr, ptr %l0, !tbaa !29
  store ptr %t637, ptr %l331, !tbaa !29
  %t638 = load ptr, ptr %l26, !tbaa !29
  %t641 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t638)
  store i32 %t641, ptr %l334
  br label %bb129
bb129:
  %t642 = load ptr, ptr %l331, !tbaa !29
  %t643 = load i32, ptr %l334, !tbaa !23
  %t644 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t642, i32 %t643)
  store i32 %t644, ptr %l335
  br label %bb130
bb130:
  %t645 = load ptr, ptr %l330, !tbaa !29
  %t646 = load i32, ptr %l335, !tbaa !23
  %t647 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s15, ptr %t645, i32 %t646, { i64, ptr } { i64 4, ptr @.d47 }, i64 0)
  store i64 %t647, ptr %l336
  br label %bb131
bb131:
  %t648 = load i64, ptr %l336, !tbaa !24
  store i64 %t648, ptr %l27, !tbaa !24
  %t649 = load i64, ptr %l27, !tbaa !24
  %t651 = icmp slt i64 %t649, 0
  br i1 %t651, label %bb132, label %bb133
bb132:
  store %olang.scope zeroinitializer, ptr %s16
  %t653 = load ptr, ptr %l0, !tbaa !29
  store ptr %t653, ptr %l339, !tbaa !29
  %t654 = load ptr, ptr %l2, !tbaa !29
  %t656 = getelementptr %"compiler/ast:ForIn", ptr %t654, i32 0, i32 2
  %t657 = load ptr, ptr %t656, !tbaa !29
  %t659 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t657)
  store %"compiler/source:Span" %t659, ptr %l342
  br label %bb134
bb133:
  br label %bb136
bb134:
  %t660 = load ptr, ptr %l339, !tbaa !29
  %t661 = load %"compiler/source:Span", ptr %l342
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s16, ptr %t660, %"compiler/source:Span" %t661, { i64, ptr } { i64 43, ptr @.d48 })
  br label %bb135
bb135:
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb136:
  %t663 = load ptr, ptr %l0, !tbaa !29
  %t664 = load %"compiler/source:Span", ptr %l1
  %t665 = load ptr, ptr %l2, !tbaa !29
  %t666 = load ptr, ptr %l26, !tbaa !29
  %t667 = load i64, ptr %l27, !tbaa !24
  %t668 = load ptr, ptr %l3, !tbaa !29
  %t669 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkIter(ptr %v0, ptr %v1, ptr %v2, ptr %t663, %"compiler/source:Span" %t664, ptr %t665, ptr %t666, i64 %t667, ptr %t668, i32 %t669)
  br label %bb137
bb137:
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb138:
  %t678 = load ptr, ptr %l0, !tbaa !29
  %t679 = load i32, ptr %l15, !tbaa !23
  %t680 = load %"compiler/source:Span", ptr %l1
  %t684 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %s0, ptr %s0, ptr %t678, i32 %t679, { i64, ptr } { i64 2, ptr @.d49 }, i64 1, %"compiler/source:Span" %t680, { i64, ptr } { i64 5, ptr @.d50 })
  store i64 %t684, ptr %l355
  br label %bb139
bb139:
  %t685 = load i64, ptr %l355, !tbaa !24
  store i64 %t685, ptr %l28, !tbaa !24
  %t686 = load ptr, ptr %l0, !tbaa !29
  %t687 = load i32, ptr %l15, !tbaa !23
  %t690 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s0, ptr %t686, i32 %t687, { i64, ptr } { i64 3, ptr @.d51 }, i64 0)
  store i64 %t690, ptr %l358
  br label %bb140
bb140:
  %t691 = load i64, ptr %l358, !tbaa !24
  store i64 %t691, ptr %l29, !tbaa !24
  %t692 = load i64, ptr %l28, !tbaa !24
  %t694 = icmp sge i64 %t692, 0
  br i1 %t694, label %bb141, label %bb142
bb141:
  %t696 = load ptr, ptr %l0, !tbaa !29
  %t698 = getelementptr %"compiler/check:Checker", ptr %t696, i32 0, i32 1
  %t699 = load ptr, ptr %t698, !tbaa !29
  %t701 = getelementptr %"compiler/generic:Program", ptr %t699, i32 0, i32 2
  store ptr %t701, ptr %l364, !tbaa !29
  %t702 = load ptr, ptr %l0, !tbaa !29
  %t704 = getelementptr %"compiler/check:Checker", ptr %t702, i32 0, i32 1
  %t705 = load ptr, ptr %t704, !tbaa !29
  %t707 = getelementptr %"compiler/generic:Program", ptr %t705, i32 0, i32 2
  store ptr %t707, ptr %l367, !tbaa !29
  %t708 = load ptr, ptr %l0, !tbaa !29
  %t710 = getelementptr %"compiler/check:Checker", ptr %t708, i32 0, i32 1
  %t711 = load ptr, ptr %t710, !tbaa !29
  %t712 = load i64, ptr %l28, !tbaa !24
  %t715 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t711, i64 %t712)
  store i32 %t715, ptr %l371
  br label %bb143
bb142:
  store i1 false, ptr %l361, !tbaa !21
  br label %bb146
bb143:
  %t716 = load ptr, ptr %l367, !tbaa !29
  %t717 = load i32, ptr %l371, !tbaa !23
  %t718 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t716, i32 %t717)
  store i32 %t718, ptr %l372
  br label %bb144
bb144:
  %t719 = load ptr, ptr %l364, !tbaa !29
  %t720 = load i32, ptr %l372, !tbaa !23
  %t721 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t719, i32 %t720)
  store { i64, ptr } %t721, ptr %l373
  br label %bb145
bb145:
  %t722 = load { i64, ptr }, ptr %l373, !tbaa !27
  %t723 = extractvalue { i64, ptr } %t722, 0
  %t725 = icmp sgt i64 %t723, 0
  store i1 %t725, ptr %l361, !tbaa !21
  br label %bb146
bb146:
  %t727 = load i1, ptr %l361, !tbaa !21
  br i1 %t727, label %bb147, label %bb148
bb147:
  %t728 = load ptr, ptr %l0, !tbaa !29
  %t730 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t728)
  store ptr %t730, ptr %l377
  br label %bb149
bb148:
  br label %bb150
bb149:
  %t731 = load ptr, ptr %l377, !tbaa !29
  store ptr %t731, ptr %l378, !tbaa !29
  %t732 = load ptr, ptr %l378, !tbaa !29
  %t733 = getelementptr %"compiler/check:frame", ptr %t732, i32 0, i32 17
  %t734 = load i64, ptr %t733, !tbaa !24
  %t736 = add i64 %t734, 1
  %t738 = load ptr, ptr %l378, !tbaa !29
  %t739 = getelementptr %"compiler/check:frame", ptr %t738, i32 0, i32 17
  store i64 %t736, ptr %t739, !tbaa !24
  br label %bb150
bb150:
  %t740 = load i64, ptr %l28, !tbaa !24
  %t742 = icmp sge i64 %t740, 0
  br i1 %t742, label %bb151, label %bb152
bb151:
  %t744 = load i64, ptr %l29, !tbaa !24
  %t746 = icmp sge i64 %t744, 0
  store i1 %t746, ptr %l383, !tbaa !21
  br label %bb153
bb152:
  store i1 false, ptr %l383, !tbaa !21
  br label %bb153
bb153:
  %t748 = load i1, ptr %l383, !tbaa !21
  br i1 %t748, label %bb154, label %bb155
bb154:
  %t749 = load ptr, ptr %l0, !tbaa !29
  %t750 = load %"compiler/source:Span", ptr %l1
  %t751 = load ptr, ptr %l2, !tbaa !29
  %t752 = load ptr, ptr %l7, !tbaa !29
  %t753 = load i64, ptr %l28, !tbaa !24
  %t754 = load i64, ptr %l29, !tbaa !24
  %t755 = load ptr, ptr %l3, !tbaa !29
  %t756 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkIndexed(ptr %v0, ptr %v1, ptr %v2, ptr %t749, %"compiler/source:Span" %t750, ptr %t751, ptr %t752, i64 %t753, i64 %t754, ptr %t755, i32 %t756)
  br label %bb156
bb155:
  br label %bb157
bb156:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb157:
  %t766 = load ptr, ptr %l0, !tbaa !29
  %t767 = load i32, ptr %l15, !tbaa !23
  %t768 = load %"compiler/source:Span", ptr %l1
  %t772 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %s0, ptr %s0, ptr %t766, i32 %t767, { i64, ptr } { i64 4, ptr @.d52 }, %"compiler/source:Span" %t768, { i64, ptr } { i64 12, ptr @.d53 }, i64 0, i1 false)
  store i1 %t772, ptr %l398
  br label %bb158
bb158:
  %t773 = load i1, ptr %l398, !tbaa !21
  br i1 %t773, label %bb159, label %bb160
bb159:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb160:
  br label %bb161
bb161:
  %t775 = load ptr, ptr %l0, !tbaa !29
  store ptr %t775, ptr %l400, !tbaa !29
  %t776 = load ptr, ptr %l2, !tbaa !29
  %t778 = getelementptr %"compiler/ast:ForIn", ptr %t776, i32 0, i32 2
  %t779 = load ptr, ptr %t778, !tbaa !29
  %t781 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t779)
  store %"compiler/source:Span" %t781, ptr %l403
  br label %bb162
bb162:
  %t782 = load ptr, ptr %l0, !tbaa !29
  %t783 = load i32, ptr %l8, !tbaa !23
  %t786 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t782, i32 %t783)
  store { i64, ptr } %t786, ptr %l406
  br label %bb163
bb163:
  %t787 = load { i64, ptr }, ptr %l406, !tbaa !27
  %t788 = extractvalue { i64, ptr } %t787, 0
  %t789 = extractvalue { i64, ptr } %t787, 1
  %t790 = mul i64 %t788, 1
  %t791 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t790)
  call void @llvm.memcpy.p0.p0.i64(ptr %t791, ptr %t789, i64 %t790, i1 false)
  %t792 = insertvalue { i64, ptr } undef, i64 %t788, 0
  %t793 = insertvalue { i64, ptr } %t792, ptr %t791, 1
  %t795 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotIterable(ptr %s0, ptr %s0, { i64, ptr } %t793)
  store %"compiler/msgs:Msg" %t795, ptr %l408
  br label %bb164
bb164:
  %t796 = load ptr, ptr %l400, !tbaa !29
  %t797 = load %"compiler/source:Span", ptr %l403
  %t798 = load %"compiler/msgs:Msg", ptr %l408
  %t799 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t796, %"compiler/source:Span" %t797, %"compiler/msgs:Msg" %t798)
  store i64 %t799, ptr %l409
  br label %bb165
bb165:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/check:litv" @compiler_2fcheck_2efloatLit(double %a0) #0 {
entry:
  %l2 = alloca %"compiler/check:litv"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/check:litv"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %s0, i1 true, i1 true, i1 false, i64 0, double %a0)
  store %"compiler/check:litv" %t3, ptr %l2
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t4 = load %"compiler/check:litv", ptr %l2
  store %"compiler/check:litv" %t4, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:litv", ptr %rv
  ret %"compiler/check:litv" %rr
}

define dso_local i1 @compiler_2fcheck_2eleavesValue(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l7 = alloca i1
  %l17 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l21 = alloca i1
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %t1)
  store i1 %t4, ptr %l7
  br label %bb1
bb1:
  %t5 = load i1, ptr %l7, !tbaa !21
  br i1 %t5, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/typed:Block", ptr %t7, i32 0, i32 1
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  store { i64, ptr } %t10, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  store i64 %t14, ptr %l3, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t16 = load i64, ptr %l2, !tbaa !24
  %t17 = load i64, ptr %l3, !tbaa !24
  %t20 = icmp slt i64 %t16, %t17
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb7:
  br label %bb8
bb8:
  %t24 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t24, ptr %l17, !tbaa !27
  %t25 = load i64, ptr %l2, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr ptr, ptr %t28, i64 %t25
  %t30 = load ptr, ptr %t29, !tbaa !39
  store ptr %t30, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t33 = load ptr, ptr %l20, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t36 = load ptr, ptr %l20, !tbaa !29
  %t37 = load i64, ptr %t36
  %t39 = icmp eq i64 %t37, 5
  store i1 %t39, ptr %l21, !tbaa !21
  br label %bb10
bb10:
  %t40 = load i1, ptr %l21, !tbaa !21
  br i1 %t40, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb16:
  %t42 = load i64, ptr %l2, !tbaa !24
  %t44 = add i64 %t42, 1
  store i64 %t44, ptr %l2, !tbaa !24
  br label %bb5
bb17:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2elowerFirst(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca i64
  %l17 = alloca i64
  %l35 = alloca ptr
  %l38 = alloca i8
  %l39 = alloca { i64, ptr }
  %l42 = alloca i8
  %l43 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l8
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l3, !tbaa !24
  %t18 = load i64, ptr %l2, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l17, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l17, !tbaa !24
  store i64 %t33, ptr %l14, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l14, !tbaa !24
  store i64 %t34, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i64, ptr %l6, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l2, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l7, !tbaa !24
  store ptr %l1, ptr %l35, !tbaa !29
  %t53 = load i64, ptr %l7, !tbaa !24
  %t55 = icmp eq i64 %t53, 0
  br i1 %t55, label %bb12, label %bb13
bb12:
  %t57 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t57, ptr %l39, !tbaa !27
  %t58 = load i64, ptr %l7, !tbaa !24
  %t60 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr i8, ptr %t61, i64 %t58
  %t63 = load i8, ptr %t62, !tbaa !32
  %t65 = call i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToLower(i8 %t63)
  store i8 %t65, ptr %l42
  br label %bb14
bb13:
  %t66 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t66, ptr %l43, !tbaa !27
  %t67 = load i64, ptr %l7, !tbaa !24
  %t69 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr i8, ptr %t70, i64 %t67
  %t72 = load i8, ptr %t71, !tbaa !32
  store i8 %t72, ptr %l38, !tbaa !22
  br label %bb15
bb14:
  %t74 = load i8, ptr %l42, !tbaa !22
  store i8 %t74, ptr %l38, !tbaa !22
  br label %bb15
bb15:
  %t75 = load ptr, ptr %l35, !tbaa !29
  %t76 = load i8, ptr %l38, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t75, i8 %t76)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  %t77 = load i64, ptr %l6, !tbaa !24
  %t79 = add i64 %t77, 1
  store i64 %t79, ptr %l6, !tbaa !24
  br label %bb8
bb18:
  %t82 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t82, ptr %l49
  br label %bb19
bb19:
  %t83 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t83, ptr %l50, !tbaa !27
  %t84 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t84, 0
  store i64 %t85, ptr %l51, !tbaa !24
  %t86 = load i64, ptr %l51, !tbaa !24
  %t87 = mul i64 %t86, 1
  %t88 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t87)
  %t89 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  store { i64, ptr } %t90, ptr %l52, !tbaa !27
  %t91 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = load i64, ptr %l51, !tbaa !24
  %t96 = mul i64 %t95, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t92, ptr %t94, i64 %t96, i1 false)
  %t97 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t97, ptr %l50, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t98 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t98, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcheck_2enullDefault(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l20 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l39 = alloca i1
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t8, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t14 = load i64, ptr %l2, !tbaa !24
  %t15 = load i64, ptr %l3, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t22, ptr %l20, !tbaa !27
  %t23 = load i64, ptr %l2, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l4, !tbaa !29
  %t30 = load ptr, ptr %l4, !tbaa !29
  %t32 = getelementptr %"compiler/ast:Catch", ptr %t30, i32 0, i32 3
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t37 = icmp eq i64 %t35, 0
  br i1 %t37, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb9:
  br label %bb10
bb10:
  %t39 = load ptr, ptr %l4, !tbaa !29
  %t41 = getelementptr %"compiler/ast:Catch", ptr %t39, i32 0, i32 3
  %t42 = load { i64, ptr }, ptr %t41, !tbaa !27
  store { i64, ptr } %t42, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  store i64 %t46, ptr %l7, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s6
  %t48 = load i64, ptr %l6, !tbaa !24
  %t49 = load i64, ptr %l7, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s6)
  br label %bb20
bb13:
  br label %bb14
bb14:
  %t56 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t56, ptr %l35, !tbaa !27
  %t57 = load i64, ptr %l6, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr ptr, ptr %t60, i64 %t57
  %t62 = load ptr, ptr %t61, !tbaa !39
  %t66 = call i1 @compiler_2fcheck_2eisNullLit(ptr %v0, ptr %t62)
  store i1 %t66, ptr %l39
  br label %bb15
bb15:
  %t67 = load i1, ptr %l39, !tbaa !21
  br i1 %t67, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s6)
  br label %bb19
bb19:
  %t69 = load i64, ptr %l6, !tbaa !24
  %t71 = add i64 %t69, 1
  store i64 %t71, ptr %l6, !tbaa !24
  br label %bb11
bb20:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb21:
  %t73 = load i64, ptr %l2, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l2, !tbaa !24
  br label %bb4
bb22:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2epureRead(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca i1
  %l10 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = call i1 @compiler_2fcheck_2epurePlace(ptr %v0, ptr %t16)
  store i1 %t18, ptr %l10
  br label %bb6
bb6:
  %t19 = load i1, ptr %l10, !tbaa !21
  store i1 %t19, ptr %l2, !tbaa !21
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_327c34393f585585_f16c5fd873651789)
  unreachable
bb12:
  %t20 = load i1, ptr %l2, !tbaa !21
  store i1 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eskipsRest(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l22 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l37 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l49 = alloca i1
  %l53 = alloca i1
  %l54 = alloca i1
  %l57 = alloca i1
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Block", ptr %t6, i32 0, i32 1
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  store { i64, ptr } %t9, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t15 = load i64, ptr %l2, !tbaa !24
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb47
bb6:
  br label %bb7
bb7:
  %t23 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t23, ptr %l18, !tbaa !27
  %t24 = load i64, ptr %l2, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr ptr, ptr %t27, i64 %t24
  %t29 = load ptr, ptr %t28, !tbaa !39
  store ptr %t29, ptr %l4, !tbaa !29
  %t31 = load ptr, ptr %l4, !tbaa !29
  %t33 = call i1 @compiler_2fcheck_2eleaves(ptr %v0, ptr %t31)
  store i1 %t33, ptr %l22
  br label %bb8
bb8:
  %t34 = load i1, ptr %l22, !tbaa !21
  br i1 %t34, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t36 = load ptr, ptr %l4, !tbaa !29
  store ptr %t36, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t37 = load ptr, ptr %l24, !tbaa !29
  %t38 = icmp ne ptr %t37, null
  br i1 %t38, label %bb12, label %bb13
bb12:
  %t40 = load ptr, ptr %l24, !tbaa !29
  %t41 = load i64, ptr %t40
  %t43 = icmp eq i64 %t41, 5
  store i1 %t43, ptr %l25, !tbaa !21
  br label %bb13
bb13:
  %t44 = load i1, ptr %l25, !tbaa !21
  br i1 %t44, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb17:
  %t46 = load ptr, ptr %l4, !tbaa !29
  store ptr %t46, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t47 = load ptr, ptr %l29, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb18, label %bb19
bb18:
  %t50 = load ptr, ptr %l29, !tbaa !29
  %t51 = load i64, ptr %t50
  %t53 = icmp eq i64 %t51, 10
  store i1 %t53, ptr %l30, !tbaa !21
  br label %bb19
bb19:
  %t54 = load i1, ptr %l30, !tbaa !21
  br i1 %t54, label %bb20, label %bb21
bb20:
  %t55 = load ptr, ptr %l4, !tbaa !29
  %t57 = getelementptr { i64, [3 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", ptr }, ptr %t57, i32 0, i32 1
  %t59 = load ptr, ptr %t58
  store ptr %t59, ptr %l5, !tbaa !29
  br label %bb22
bb21:
  br label %bb27
bb22:
  %t61 = load ptr, ptr %l5, !tbaa !29
  %t64 = call i1 @compiler_2fcheck_2eskipsRest(ptr %v0, ptr %t61)
  store i1 %t64, ptr %l37
  br label %bb23
bb23:
  %t65 = load i1, ptr %l37, !tbaa !21
  br i1 %t65, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  br label %bb45
bb27:
  %t67 = load ptr, ptr %l4, !tbaa !29
  store ptr %t67, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t68 = load ptr, ptr %l39, !tbaa !29
  %t69 = icmp ne ptr %t68, null
  br i1 %t69, label %bb28, label %bb29
bb28:
  %t71 = load ptr, ptr %l39, !tbaa !29
  %t72 = load i64, ptr %t71
  %t74 = icmp eq i64 %t72, 3
  store i1 %t74, ptr %l40, !tbaa !21
  br label %bb29
bb29:
  %t75 = load i1, ptr %l40, !tbaa !21
  br i1 %t75, label %bb30, label %bb31
bb30:
  %t76 = load ptr, ptr %l4, !tbaa !29
  %t78 = getelementptr { i64, [3 x i64] }, ptr %t76, i32 0, i32 1
  %t79 = getelementptr { %"compiler/source:Span", ptr }, ptr %t78, i32 0, i32 1
  %t80 = load ptr, ptr %t79
  store ptr %t80, ptr %l6, !tbaa !29
  br label %bb32
bb31:
  br label %bb44
bb32:
  %t82 = load ptr, ptr %l6, !tbaa !29
  %t84 = getelementptr %"compiler/typed:If", ptr %t82, i32 0, i32 2
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = icmp eq ptr %t85, null
  %t89 = xor i1 %t87, true
  br i1 %t89, label %bb33, label %bb34
bb33:
  %t91 = load ptr, ptr %l6, !tbaa !29
  %t93 = getelementptr %"compiler/typed:If", ptr %t91, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t97 = call i1 @compiler_2fcheck_2eskipsRest(ptr %v0, ptr %t94)
  store i1 %t97, ptr %l53
  br label %bb35
bb34:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb36
bb35:
  %t98 = load i1, ptr %l53, !tbaa !21
  store i1 %t98, ptr %l49, !tbaa !21
  br label %bb36
bb36:
  %t99 = load i1, ptr %l49, !tbaa !21
  br i1 %t99, label %bb37, label %bb38
bb37:
  %t100 = load ptr, ptr %l6, !tbaa !29
  %t102 = getelementptr %"compiler/typed:If", ptr %t100, i32 0, i32 2
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t105 = call i1 @compiler_2fcheck_2eskipsRest(ptr %v0, ptr %t103)
  store i1 %t105, ptr %l57
  br label %bb39
bb38:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb40
bb39:
  %t106 = load i1, ptr %l57, !tbaa !21
  store i1 %t106, ptr %l54, !tbaa !21
  br label %bb40
bb40:
  %t107 = load i1, ptr %l54, !tbaa !21
  br i1 %t107, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  br label %bb45
bb44:
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s3)
  br label %bb46
bb46:
  %t109 = load i64, ptr %l2, !tbaa !24
  %t111 = add i64 %t109, 1
  store i64 %t111, ptr %l2, !tbaa !24
  br label %bb4
bb47:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2estoredCatches(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l16 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t13 = load i64, ptr %l3, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb11
bb6:
  br label %bb7
bb7:
  %t21 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t21, ptr %l16, !tbaa !27
  %t22 = load i64, ptr %l3, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr ptr, ptr %t25, i64 %t22
  %t27 = load ptr, ptr %t26, !tbaa !39
  store ptr %t27, ptr %l5, !tbaa !29
  %t29 = load ptr, ptr %l5, !tbaa !29
  %t31 = getelementptr %"compiler/ast:Catch", ptr %t29, i32 0, i32 2
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  %t33 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredIn(ptr %v0, ptr %v1, { i64, ptr } %t32, ptr %t33)
  br label %bb8
bb8:
  %t36 = load ptr, ptr %l5, !tbaa !29
  %t38 = getelementptr %"compiler/ast:Catch", ptr %t36, i32 0, i32 3
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  %t40 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExprs(ptr %v0, ptr %v1, { i64, ptr } %t39, ptr %t40)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb10
bb10:
  %t43 = load i64, ptr %l3, !tbaa !24
  %t45 = add i64 %t43, 1
  store i64 %t45, ptr %l3, !tbaa !24
  br label %bb4
bb11:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2estoredMatch(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l18 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Match", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t4, ptr %t6)
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/ast:Match", ptr %t9, i32 0, i32 3
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  store { i64, ptr } %t12, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t14 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  store i64 %t16, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t18 = load i64, ptr %l3, !tbaa !24
  %t19 = load i64, ptr %l4, !tbaa !24
  %t22 = icmp slt i64 %t18, %t19
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t26, ptr %l18, !tbaa !27
  %t27 = load i64, ptr %l3, !tbaa !24
  %t29 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr ptr, ptr %t30, i64 %t27
  %t32 = load ptr, ptr %t31, !tbaa !39
  %t35 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredCase(ptr %v0, ptr %v1, ptr %t32, ptr %t35)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb7
bb7:
  %t38 = load i64, ptr %l3, !tbaa !24
  %t40 = add i64 %t38, 1
  store i64 %t40, ptr %l3, !tbaa !24
  br label %bb2
bb8:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/ast:Match", ptr %t42, i32 0, i32 4
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = icmp eq ptr %t45, null
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb9, label %bb10
bb9:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/ast:Match", ptr %t51, i32 0, i32 4
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = icmp eq ptr %t54, null
  br i1 %t56, label %bb11, label %bb12
bb10:
  br label %bb15
bb11:
  call void @__olang_check_failed(ptr @olang_loc_dafed6c5ce7057e_e7afeb5c7864030a)
  unreachable
bb12:
  br label %bb13
bb13:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/ast:Match", ptr %t58, i32 0, i32 4
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t62 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredCase(ptr %v0, ptr %v1, ptr %t61, ptr %t62)
  br label %bb14
bb14:
  br label %bb15
bb15:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ewrittenMut(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t7 = load ptr, ptr %l6, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l6, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 4
  store i1 %t13, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l7, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t17, i32 0, i32 2
  %t19 = load i1, ptr %t18
  store i1 %t19, ptr %l1, !tbaa !21
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t21 = load i1, ptr %l1, !tbaa !21
  store i1 %t21, ptr %l5, !tbaa !21
  br label %bb14
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_dd9051e7d89be652_5717c5df078d4726)
  unreachable
bb14:
  %t23 = load i1, ptr %l5, !tbaa !21
  store i1 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/check:narrowed" @compiler_2fcheck_3anarrowed_2ector(ptr %v0, i64 %a0, i64 %a1, i32 %a2, i64 %a3, i64 %a4) #0 {
entry:
  %rv = alloca %"compiler/check:narrowed"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/check:narrowed" undef, i64 %a0, 0
  %t14 = insertvalue %"compiler/check:narrowed" %t12, i64 %a1, 1
  %t16 = insertvalue %"compiler/check:narrowed" %t14, i32 %a2, 2
  %t18 = insertvalue %"compiler/check:narrowed" %t16, i64 %a3, 3
  %t20 = insertvalue %"compiler/check:narrowed" %t18, i64 %a4, 4
  store %"compiler/check:narrowed" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:narrowed", ptr %rv
  ret %"compiler/check:narrowed" %rr
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d0 = private constant [12 x i8] c"LeadingZeros"
@.d1 = private constant [13 x i8] c"TrailingZeros"
@.d2 = private constant [8 x i8] c"PopCount"
@.d3 = private constant [10 x i8] c"RotateLeft"
@.d4 = private constant [11 x i8] c"RotateRight"
@.d5 = private constant [8 x i8] c"ByteSwap"
declare void @__olang_check_failed(ptr)
declare void @__olang_ert_req_clear()
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = getelementptr %"compiler/source:Span", ptr %t1, i32 0, i32 0
  %t3 = load i32, ptr %t2, !tbaa !23
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/source:Span", ptr %t4, i32 0, i32 0
  %t6 = load i32, ptr %t5, !tbaa !23
  %t9 = icmp eq i32 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb4
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/source:Span", ptr %t11, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/source:Span", ptr %t14, i32 0, i32 1
  %t16 = load i32, ptr %t15, !tbaa !23
  %t19 = icmp eq i32 %t13, %t16
  br i1 %t19, label %bb3, label %bb1
bb3:
  br label %bb4
bb4:
  %t21 = load i1, ptr %l2, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_3f_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_3f_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d6 = private constant [3 x i8] c"F64"
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d7 = private constant [51 x i8] c"a match on a type giving its value by a block (G15)"
@.d8 = private constant [53 x i8] c"a match on a length giving its value by a block (G30)"
@.d9 = private constant [3 x i8] c"Has"
@.d10 = private constant [4 x i8] c"'in'"
@.d11 = private constant [8 x i8] c"Contains"
@.d12 = private constant [3 x i8] c"Has"
@.d13 = private constant [4 x i8] c"'in'"
@.d14 = private constant [8 x i8] c"'x in c'"
@.d15 = private constant [6 x i8] c"Narrow"
@.d16 = private constant [3 x i8] c"Len"
@.d17 = private constant [3 x i8] c"Len"
@.d18 = private constant [4 x i8] c"Hash"
@.d19 = private constant [3 x i8] c"Str"
@.d20 = private constant [43 x i8] c"a method the compiler supplies (E10b, E11c)"
@.d21 = private constant [0 x i8] c""
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d22 = private constant [0 x i8] c""
@.d23 = private constant [5 x i8] c"Slice"
@.d24 = private constant [5 x i8] c"Slice"
@.d25 = private constant [10 x i8] c"'x[lo:hi]'"
@.d26 = private constant [3 x i8] c"Len"
@.d27 = private constant [47 x i8] c"a slice with no end of a type with no Len (E31)"
@.d28 = private constant [17 x i8] c"instantiated here"
@.d29 = private constant [7 x i8] c", with "
@.d30 = private constant [2 x i8] c", "
@.d31 = private constant [3 x i8] c" = "
@.d32 = private constant [5 x i8] c"'not'"
@.d33 = private constant [3 x i8] c"Neg"
@.d34 = private constant [6 x i8] c"BitNot"
@.d35 = private constant [1 x i8] c"'"
@.d36 = private constant [1 x i8] c"'"
@.d37 = private constant [3 x i8] c"'-'"
@.d38 = private constant [3 x i8] c"'~'"
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPiece_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPiece_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d39 = private constant [20 x i8] c"this prefix operator"
@.d40 = private constant [4 x i8] c"Next"
@.d41 = private constant [7 x i8] c"RunFrom"
@.d42 = private constant [5 x i8] c"'for'"
@.d43 = private constant [4 x i8] c"Next"
@.d44 = private constant [5 x i8] c"'for'"
@.d45 = private constant [4 x i8] c"Iter"
@.d46 = private constant [5 x i8] c"'for'"
@.d47 = private constant [4 x i8] c"Next"
@.d48 = private constant [43 x i8] c"an Iter() whose result is no iterator (S9c)"
@.d49 = private constant [2 x i8] c"At"
@.d50 = private constant [5 x i8] c"'for'"
@.d51 = private constant [3 x i8] c"Len"
@.d52 = private constant [4 x i8] c"Next"
@.d53 = private constant [12 x i8] c"'for ... in'"
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare i1 @compiler_2fcheck_2eisHexDigit(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_a3fc486149a2dc5d_17491af4361141b9 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_1b45850c01c63cc9_5ae567fd22704b05 = external constant [0 x i8]
declare i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eIsPending(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eChoose(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_fd7ab254095cc62_437ccc419ec0735e = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eonlyFixed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3)
declare i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyCaseType(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrongCase(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efailOp(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, %"compiler/source:Span" %a2, i1 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyInstance(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3, i32 %a4)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econdChoosesPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFoldLength(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayLengthRange(ptr %v0, i64 %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/msgs:Msg" %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i64 %a3)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFoldKnown(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezeroCalls(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2easkValue(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, i64 %a1, { i64, ptr } %a2, ptr %a3, i32 %a4, i32 %a5)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0)
declare { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4)
@olang_loc_fa88b19e51866753_1c515c5623826c7f = external constant [0 x i8]
@olang_loc_962a22c7791f971e_263bae1157bb3aaa = external constant [0 x i8]
@olang_loc_bce8d8bde069702e_ffe04dc686cce872 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternValue(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainStruct(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_Hbcd822ae67306ca6a025f17ed2cfb61c(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %a0, i32 %a1)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare %"compiler/typed:Local" @compiler_2ftyped_3aLocal_2ector(ptr %v0, i32 %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, i32 %a4, { i64, [2 x i64] } %a5)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddLocal(ptr %v0, ptr %a0, %"compiler/typed:Local" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_486b3db7a819736b_b4c2afa2fe5bd5af = external constant [0 x i8]
declare %"compiler/typed:Capture" @compiler_2ftyped_3aCapture_2ector(ptr %v0, ptr %v1, i32 %a0, ptr %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aCapture_26_3e_2e_He39a1cf375adb47168dea91a05758aa9(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2ePu_Hdbf2db28b3dbd7714059bb41361f5f89(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare ptr @compiler_2fcheck_2eunwrapped(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %a0)
declare %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %a0, i32 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aCapture_26_3e_2e_H29428d146645d03428956d524c855061(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_3fa0bc2758d24028_39c102aa9b869b2c = external constant [0 x i8]
@olang_loc_386bb7dc57d3fef9_468931e243621ddd = external constant [0 x i8]
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseUnknownName(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i1 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseIsSubject(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_514ceade83978a4d_1843f44cd2570191 = external constant [0 x i8]
declare %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_8bbd92ac148fb220_5a9ba8c1b178084 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eSet_H7eb7f72699477ff6ed0f03fe599574de(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralBeside(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLikeFits(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v0, i32 %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoMeet(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echainFrom(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, { i64, ptr } %a4, i64 %a5, ptr %a6)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eTru_H381e973120335535f017a290d5069d76(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskDefaultInStatement(ptr %v0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_H2d42092ce658fb6cce0104fa754a4e33(ptr %v0, ptr %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i32 %a3, i32 %a4)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eSetVars(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_b7a62f2efaadd4af_1b278ceebf7ddf33 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestructCount(ptr %v0, i64 %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v1, i32 %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskClauseNeedsDefault(ptr %v0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aCapture_26_3e_2e_Hc9219e836d6ca52518c31537b8e6a8eb(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %a0)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondNotBoolType(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTypeWritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMembers(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyCaseTwice(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_Hb6f924c91b81223120b2cba278ece4a6(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalBody(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeRules(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, ptr %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaredCtor(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitSets(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitHeader(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitContracts(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
@olang_loc_9f7e5ad647601e13_a7b1cb3e26ad346f = external constant [0 x i8]
declare i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eChosen(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclsIf(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3, i64 %a4)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eescapeRules(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i64 %a3)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eTrun_H62a150000c9aaeb3d030aed80f9d3e2e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eRunF_H9c1707946c43ec840ffe1821bea89b1f(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_294a26fa6e899319_197e495586e916bd = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eRangeNotInt(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_3f_26_3e_2e_H4d3879e0682f4949b04a377fac27da65(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_3f_26_3e_2e_H8799d60eecda5ec9994329473f90a64e(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_b274f9b5a1d6f283_4bd77c9dbb9826e7 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eRangeStep(ptr %v0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/check:litv" %a2, i32 %a3)
@olang_loc_81853a8b5abe7edb_5bbff5245f4bcfbf = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
@olang_loc_e4731602e9e5e1a_1dd19577095c0d0e = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5)
declare %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecounted(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, i64 %a4, i64 %a5, i32 %a6, i64 %a7, i64 %a8, ptr %a9, i32 %a10)
declare %"compiler/check:Gap" @compiler_2fcheck_3aGap_2ector(ptr %v0, ptr %v1, i64 %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aGap_3e_2ePush_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:Gap" %a1)
@G_2ecompiler_2ftypes_2eDefaultErrT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\10\00\00\00" }>, align 8
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_Ha6bcf4d517e3d7b46809e1dbf938da91(ptr %v0, ptr %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_9109cadfb541186e_2a46ab96c2b41f0a = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritableAt(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ematchOnType(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elenMatch(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eMatchValueNone(ptr %v0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ematchExpr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i1 %a3, i32 %a4)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2eFnOwner(i64 %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %v0, i64 %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3, i1 %a4, i1 %a5)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eboundParam(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i64 %a2, ptr %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3, { i64, ptr } %a4, i64 %a5, i1 %a6)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eMembershipNoMethod(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ePus_He68407854d25cdd1c04f001baf21eeaa(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_1fa90a145069ae20_a62c963c9e2d6294 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %a0, ptr %a1)
@olang_loc_e5386246bf71864d_e9422de20f0d1fa1 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3, ptr %a4, { i64, ptr } %a5, { i64, ptr } %a6, { i64, ptr } %a7)
declare %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultMethods(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowCall(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, { i64, ptr } %a4, { i64, ptr } %a5)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgsOnNonGeneric(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexplicitArgs(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodIsPrivate(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_d23330c3ef7ea91b_34477ea00961dc87 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyCall(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i32 %a4, %"compiler/source:Span" %a5, { i64, ptr } %a6)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultAmbiguous(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ebangOf(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadMaybeNull(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNonNull(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebadOver(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisOver(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebaseHas(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodNotInherited(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esuppliedCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, ptr %a4, { i64, ptr } %a5, { i64, ptr } %a6)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldIndex(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@olang_loc_897998a95b9e5e2e_e7f90bd867c953f2 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efield(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, i32 %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallValue(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, { i64, ptr } %a4)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownMethod(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_97297cf958301a5_897be3a3c1a33231 = external constant [0 x i8]
@olang_loc_f4ec2e4bc4870738_831a294d3dfd1224 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, [2 x i64] } %a5)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anarrowed_3e_2ePu_H8ca7ff483075a23de06ba27b878260e2(ptr %v0, ptr %a0, %"compiler/check:narrowed" %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2enameDistance(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSuchCaseMeant(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSuchCase(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %v0, i32 %a0)
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_9311a1fdea965308_123228c6f8b4663c = external constant [0 x i8]
@olang_loc_6fa6db75017b9575_1d827b27b68e8189 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
@olang_loc_53860b63ce2a3756_eab450cf1ae092ca = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eequality(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earraysEqual(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i32 %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eenumsEqual(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i32 %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldOf(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeHasEq(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H4c470d2e80d9fd53b2c4a8b35e81296f(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H64396385e4e6d43afa926b839ce2258a(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a2)
declare { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H6388cc594ade7977543a45717e2b755f(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroValue(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroName(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hc59e30334647acda8fe9b2b02a632dfd(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroTrack(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroTempBase(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRead(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCallRef(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ftyped_2ePassesRefs(i32 %a0)
@olang_loc_62c5ac3e914a4019_8e197c98e172d865 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eentryChecks(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2estoredIn(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteProtocolSpelling(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2, %"compiler/msgs:Msg" %a3)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddSite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullRead(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotIndexable(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_5aa0e1f55b10e6f_53045464d54dc2fb = external constant [0 x i8]
@olang_loc_e4f33d7277813d9a_8adeed4fca551266 = external constant [0 x i8]
@olang_loc_b203c9fbf4c249fb_735051f472c86bf = external constant [0 x i8]
@olang_loc_85a2f2931038d80c_e5a946dd8e187d18 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esliceLength(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2, ptr %a3)
@olang_loc_2f1aad6b95023edd_c82f5ce971f0d619 = external constant [0 x i8]
declare %"compiler/typed:Slice" @compiler_2ftyped_3aSlice_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
declare { i64, ptr } @compiler_2fscan_2eLiteralBytes(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexistingIn(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskDefaultExisting(ptr %v0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/generic:Context" @compiler_2fgeneric_3aContext_2ector(ptr %v0, i64 %a0, i64 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/generic:Origin" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeOrigin(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstContexts(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePushContext(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, { i64, ptr } %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperandNotBool(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_39a940d28383dd1b_3bbc1f844fb62f37 = external constant [0 x i8]
@olang_loc_ed7947026d051386_3326ccf8e0a65a82 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotExtendedOp(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperandNotNumber(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperandNotInt(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erenderPiece(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPiece_26_3e_2ePu_Hf3d190a214b599b1db3fb8bde0778037(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPiece_26_3e_2eTo_H8a5ee0a19875600d5129e9d1ac97555e(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/typed:Text" @compiler_2ftyped_3aText_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordCount(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aatRec_3e_2eLen_3ccompiler_2fcheck_3aatRec_3e(ptr %v0, ptr %a0)
declare %"compiler/check:atRec" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aatRec_3e_2eAt_3ccompiler_2fcheck_3aatRec_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkIter(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i64 %a4, ptr %a5, i32 %a6)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotIterable(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eiterShaped(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkRuns(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i64 %a4, ptr %a5, i32 %a6)
@olang_loc_b5c196eacf828aab_2dac07573477728f = external constant [0 x i8]
@olang_loc_139af6e2a2dcda96_1438f6a9e620193a = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkIndexed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i64 %a4, i64 %a5, ptr %a6, i32 %a7)
declare %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %v0, i1 %a0, i1 %a1, i1 %a2, i64 %a3, double %a4)
declare i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToLower(i8 %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare i1 @compiler_2fcheck_2eisNullLit(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2epurePlace(ptr %v0, ptr %a0)
@olang_loc_327c34393f585585_f16c5fd873651789 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2eleaves(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2estoredExprs(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
declare void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2estoredCase(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_dafed6c5ce7057e_e7afeb5c7864030a = external constant [0 x i8]
@olang_loc_dd9051e7d89be652_5717c5df078d4726 = external constant [0 x i8]
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_3f_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPiece_26_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
