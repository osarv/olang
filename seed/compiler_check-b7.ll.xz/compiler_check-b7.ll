; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/names:Ref" = type { i32, i64, i64 }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i64, i1, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, i64, i32, i32, i1, { i64, [3 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, i64, %"compiler/source:Span", i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/check:knownRange", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, %"compiler/source:Span", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, i64, i64, i64, i1, i1, i1, i32, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/diag:Taken", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/text:StringBuilder", i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/check:knownRange" = type { i64, i64, i64 }
%"compiler/diag:Taken" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"compiler/facts:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/facts:Table" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64 }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/check:frame" = type { i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/generic:Context", i32, i32, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i32, i64, i64, i64, i1, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i64, i64, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i64, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", i64, i1 }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/check:ContractAsk" = type { i64, i64, %"compiler/source:Span", i64, %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, i1, i64, i64 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" = type { { ptr, ptr } }
%"compiler/diagmsg:Msg" = type { i32, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, i32, i1, ptr, i32 }
%"compiler/ast:TypeParam" = type { %"compiler/source:Span", i32, ptr, { i64, ptr }, i1, ptr }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/generic:AnyTable" = type { i32, i32, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:AnySlot" = type { i32, i32, i64, i64, i1, i32, i32 }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, ptr, i32 }
%"compiler/generic:Desc" = type { i64, i32, i64, i64 }
%"compiler/check:reflList" = type { i1, i32, i64, i64 }
%"compiler/check:reflVal" = type { i1, i64, i64, { i64, ptr }, i32 }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, i1, i1, { i64, ptr }, i1 }
%"compiler/check:typeCase" = type { i1, i1, i32, i64, i64, i1 }
%"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" = type { ptr, i64 }
%"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" = type { i32, i32 }
%"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" = type { i32, i64 }
%"compiler/names:Entry" = type { i32, %"compiler/source:Span", i32, i1, ptr }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1, i1 }
%"compiler/names:Resolver" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/names:Table" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/check:heldCand" = type { i64, i64, i64 }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebareDecl(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"compiler/names:Ref"
  %l5 = alloca ptr
  %l6 = alloca i1
  %l15 = alloca ptr
  %l17 = alloca ptr
  %l21 = alloca %"compiler/names:Ref"
  %l25 = alloca i1
  %l28 = alloca i1
  %l35 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t18, i32 0, i32 2
  %t20 = load { i64, ptr }, ptr %t19
  store { i64, ptr } %t20, ptr %l3, !tbaa !27
  br label %bb5
bb4:
  br label %bb18
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  store ptr %t28, ptr %l15, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t29)
  store ptr %t31, ptr %l17
  br label %bb6
bb6:
  %t32 = load ptr, ptr %l17, !tbaa !29
  %t34 = getelementptr %"compiler/check:frame", ptr %t32, i32 0, i32 2
  %t35 = load i64, ptr %t34, !tbaa !24
  %t36 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t37 = load i32, ptr %t36, !tbaa !23
  %t38 = load ptr, ptr %l15, !tbaa !29
  %t41 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t38, i64 %t35, i32 %t37)
  store %"compiler/names:Ref" %t41, ptr %l21
  br label %bb7
bb7:
  %t42 = load %"compiler/names:Ref", ptr %l21
  store %"compiler/names:Ref" %t42, ptr %l4
  %t43 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t47 = icmp eq i64 %t45, 0
  br i1 %t47, label %bb8, label %bb9
bb8:
  %t49 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 0
  %t50 = load i32, ptr %t49, !range !{i32 0, i32 9}
  %t52 = trunc i64 4 to i32
  %t53 = icmp eq i32 %t50, %t52
  store i1 %t53, ptr %l25, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb10
bb10:
  %t55 = load i1, ptr %l25, !tbaa !21
  br i1 %t55, label %bb11, label %bb12
bb11:
  %t56 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 2
  %t57 = load i64, ptr %t56, !tbaa !24
  %t59 = icmp sge i64 %t57, 0
  store i1 %t59, ptr %l28, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb13
bb13:
  %t61 = load i1, ptr %l28, !tbaa !21
  br i1 %t61, label %bb14, label %bb15
bb14:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t66 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 1
  %t67 = load i64, ptr %t66, !tbaa !24
  %t68 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 2
  %t69 = load i64, ptr %t68, !tbaa !24
  %t73 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t65, i64 %t67, i64 %t69)
  store i32 %t73, ptr %l35
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t74 = load i32, ptr %l35, !tbaa !23
  store i32 %t74, ptr %rv
  br label %ret
bb17:
  store i32 -1, ptr %rv
  br label %ret
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  store i32 -1, ptr %rv
  br label %ret
bb22:
  call void @__olang_check_failed(ptr @olang_loc_9eb839b1731ec753_72a752a69f5cff)
  unreachable
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econversionAt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { { i64, [3 x i64] }, { i64, ptr } }
  %lp15 = alloca ptr
  %l17 = alloca ptr
  %l21 = alloca i1
  %l25 = alloca i1
  %l27 = alloca i1
  %l28 = alloca i1
  %l30 = alloca i1
  %l40 = alloca { i64, ptr }
  %l43 = alloca ptr
  %l46 = alloca { i64, [2 x i64] }
  %l51 = alloca i32
  %l54 = alloca i64
  %l62 = alloca ptr
  %l63 = alloca ptr
  %l64 = alloca i64
  %l67 = alloca %"compiler/generic:Context"
  %l69 = alloca %"compiler/generic:Context"
  %l80 = alloca ptr
  %l83 = alloca i32
  %l86 = alloca i64
  %l88 = alloca ptr
  %l89 = alloca %"compiler/source:Span"
  %l90 = alloca ptr
  %l91 = alloca %"compiler/source:Span"
  %l95 = alloca ptr
  %l97 = alloca ptr
  %l102 = alloca ptr
  %l103 = alloca ptr
  %l107 = alloca { i64, ptr }
  %l108 = alloca %"compiler/typed:Block"
  %l118 = alloca { { i64, [3 x i64] }, { i64, ptr } }
  %l120 = alloca { i64, ptr }
  %l121 = alloca i64
  %l122 = alloca { i64, ptr }
  %l124 = alloca ptr
  %l125 = alloca i64
  %l126 = alloca i64
  %l127 = alloca %"compiler/source:Span"
  %l128 = alloca i64
  %l129 = alloca %"compiler/source:Span"
  %l130 = alloca { i64, ptr }
  %l131 = alloca { i64, [3 x i64] }
  %l132 = alloca { i64, ptr }
  %l133 = alloca i64
  %l137 = alloca { i64, ptr }
  %l140 = alloca %"compiler/check:ContractAsk"
  %s0 = alloca %olang.scope
  %t64 = alloca { i64, [2 x i64] }, align 8
  %t115 = alloca %"compiler/generic:Context", align 8
  %t349 = alloca { i64, [3 x i64] }, align 8
  %t453 = alloca %"compiler/check:ContractAsk", align 8
  %t464 = alloca %"compiler/check:ContractAsk", align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l17
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l17, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 58
  %t8 = load i64, ptr %t7, !tbaa !24
  %t10 = icmp ne i64 %t8, 0
  br i1 %t10, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb4
bb3:
  %t12 = load ptr, ptr %l5, !tbaa !29
  %t14 = getelementptr %"compiler/check:frame", ptr %t12, i32 0, i32 0
  %t15 = load i64, ptr %t14, !tbaa !24
  %t17 = icmp slt i64 %t15, 0
  store i1 %t17, ptr %l21, !tbaa !21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l21, !tbaa !21
  br i1 %t19, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb8
bb6:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eevalOnly(ptr %v0, ptr %t20)
  store i1 %t22, ptr %l27
  br label %bb7
bb7:
  %t23 = load i1, ptr %l27, !tbaa !21
  store i1 %t23, ptr %l25, !tbaa !21
  br label %bb8
bb8:
  %t24 = load i1, ptr %l25, !tbaa !21
  br i1 %t24, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb12
bb10:
  %t25 = load ptr, ptr %l3, !tbaa !29
  %t27 = call i1 @compiler_2fcheck_2eclosedExpr(ptr %v1, ptr %t25)
  store i1 %t27, ptr %l30
  br label %bb11
bb11:
  %t28 = load i1, ptr %l30, !tbaa !21
  %t29 = xor i1 %t28, true
  store i1 %t29, ptr %l28, !tbaa !21
  br label %bb12
bb12:
  %t31 = load i1, ptr %l28, !tbaa !21
  br i1 %t31, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb14:
  br label %bb15
bb15:
  %t32 = load ptr, ptr %l5, !tbaa !29
  %t34 = getelementptr %"compiler/check:frame", ptr %t32, i32 0, i32 1
  %t35 = load i64, ptr %t34, !tbaa !24
  store i64 %t35, ptr %l6, !tbaa !24
  %t37 = load ptr, ptr %l5, !tbaa !29
  %t39 = getelementptr %"compiler/check:frame", ptr %t37, i32 0, i32 2
  %t40 = load i64, ptr %t39, !tbaa !24
  store i64 %t40, ptr %l7, !tbaa !24
  %t42 = load ptr, ptr %l5, !tbaa !29
  %t44 = getelementptr %"compiler/check:frame", ptr %t42, i32 0, i32 0
  %t45 = load i64, ptr %t44, !tbaa !24
  store i64 %t45, ptr %l8, !tbaa !24
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load %"compiler/source:Span", ptr %l2
  %t51 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %s0, ptr %t47, %"compiler/source:Span" %t48)
  store { i64, ptr } %t51, ptr %l40
  br label %bb16
bb16:
  %t52 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 1
  %t54 = extractvalue { i64, ptr } %t52, 0
  %t55 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t54)
  call void @olang_textcopy(ptr %t55, ptr %t53, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l9, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l43, !tbaa !29
  %t61 = load i64, ptr %l6, !tbaa !24
  %t62 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t63 = load i32, ptr %t62, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t64
  %t65 = getelementptr { i64, [2 x i64] }, ptr %t64, i32 0, i32 0
  store i64 7, ptr %t65
  %t67 = insertvalue { i64, i32 } undef, i64 %t61, 0
  %t69 = insertvalue { i64, i32 } %t67, i32 %t63, 1
  %t70 = getelementptr { i64, [2 x i64] }, ptr %t64, i32 0, i32 1
  store { i64, i32 } %t69, ptr %t70
  %t71 = load { i64, [2 x i64] }, ptr %t64
  store { i64, [2 x i64] } %t71, ptr %l46
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/check:Checker", ptr %t72, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t77 = getelementptr %"compiler/generic:Program", ptr %t75, i32 0, i32 2
  %t78 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t81 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t77, i32 0, i32 %t78, i32 0, i32 0, i64 0, i1 false, i32 0, i64 0)
  store i32 %t81, ptr %l51
  br label %bb17
bb17:
  %t82 = load i64, ptr %l6, !tbaa !24
  %t83 = load %"compiler/source:Span", ptr %l1
  %t84 = load ptr, ptr %l43, !tbaa !29
  %t85 = load { i64, [2 x i64] }, ptr %l46
  %t86 = load i32, ptr %l51, !tbaa !23
  %t89 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t84, { i64, [2 x i64] } %t85, i32 %t86, i64 %t82, %"compiler/source:Span" %t83)
  store i64 %t89, ptr %l54
  br label %bb18
bb18:
  %t90 = load i64, ptr %l54, !tbaa !24
  store i64 %t90, ptr %l10, !tbaa !24
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/check:Checker", ptr %t91, i32 0, i32 24
  %t94 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t93, i64 %t94, i64 1)
  br label %bb19
bb19:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load i64, ptr %l10, !tbaa !24
  %t99 = load i64, ptr %l6, !tbaa !24
  %t100 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t105 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v0, ptr %t97, i64 %t98, i64 %t99, i32 %t100, i32 0)
  store ptr %t105, ptr %l62
  br label %bb20
bb20:
  %t106 = load ptr, ptr %l62, !tbaa !29
  store ptr %t106, ptr %l63, !tbaa !29
  %t108 = call ptr @__olang_scope_hold(ptr %v0)
  %t109 = ptrtoint ptr %t108 to i64
  store i64 %t109, ptr %l64, !tbaa !24
  %t110 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e4
  br i1 %t110, label %bb21, label %bb22
bb21:
  %t112 = call ptr @__olang_region_make(ptr %v0)
  %t113 = ptrtoint ptr %t112 to i64
  store i64 %t113, ptr %l64, !tbaa !24
  br label %bb22
bb22:
  %t114 = load i64, ptr %l6, !tbaa !24
  %t116 = load i64, ptr %l64
  %t117 = inttoptr i64 %t116 to ptr
  call void @compiler_2fgeneric_3aContext_2ector(ptr %t115, ptr %t117, i64 %t114, i64 -1)
  call void @llvm.memmove.p0.p0.i64(ptr %l67, ptr %t115, i64 160, i1 false)
  br label %bb23
bb23:
  %t119 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e4
  br i1 %t119, label %bb24, label %bb25
bb24:
  %t121 = load i64, ptr %l64
  %t122 = inttoptr i64 %t121 to ptr
  %t123 = getelementptr %"compiler/generic:Context", ptr %l67, i32 0, i32 3
  %t124 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t123, i32 0, i32 2
  %t125 = load { i64, ptr }, ptr %t124
  %t126 = extractvalue { i64, ptr } %t125, 1
  %t127 = call ptr @__olang_region_or(ptr %t126, ptr null)
  %t128 = call ptr @__olang_region_home(ptr %t127)
  %t129 = icmp ne ptr %t128, null
  %t130 = select i1 %t129, ptr %t128, ptr null
  %t131 = getelementptr %"compiler/generic:Context", ptr %l67, i32 0, i32 3
  %t132 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t131, i32 0, i32 1
  %t133 = load { i64, ptr }, ptr %t132
  %t134 = extractvalue { i64, ptr } %t133, 1
  %t135 = call ptr @__olang_region_or(ptr %t134, ptr null)
  %t136 = call ptr @__olang_region_home(ptr %t135)
  %t137 = icmp ne ptr %t136, null
  %t138 = select i1 %t137, ptr %t136, ptr %t130
  %t139 = getelementptr %"compiler/generic:Context", ptr %l67, i32 0, i32 3
  %t140 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t139, i32 0, i32 0
  %t141 = load { i64, ptr }, ptr %t140
  %t142 = extractvalue { i64, ptr } %t141, 1
  %t143 = call ptr @__olang_region_or(ptr %t142, ptr null)
  %t144 = call ptr @__olang_region_home(ptr %t143)
  %t145 = icmp ne ptr %t144, null
  %t146 = select i1 %t145, ptr %t144, ptr %t138
  %t147 = getelementptr %"compiler/generic:Context", ptr %l67, i32 0, i32 2
  %t148 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t147, i32 0, i32 2
  %t149 = load { i64, ptr }, ptr %t148
  %t150 = extractvalue { i64, ptr } %t149, 1
  %t151 = call ptr @__olang_region_or(ptr %t150, ptr null)
  %t152 = call ptr @__olang_region_home(ptr %t151)
  %t153 = icmp ne ptr %t152, null
  %t154 = select i1 %t153, ptr %t152, ptr %t146
  %t155 = getelementptr %"compiler/generic:Context", ptr %l67, i32 0, i32 2
  %t156 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t155, i32 0, i32 1
  %t157 = load { i64, ptr }, ptr %t156
  %t158 = extractvalue { i64, ptr } %t157, 1
  %t159 = call ptr @__olang_region_or(ptr %t158, ptr null)
  %t160 = call ptr @__olang_region_home(ptr %t159)
  %t161 = icmp ne ptr %t160, null
  %t162 = select i1 %t161, ptr %t160, ptr %t154
  %t163 = getelementptr %"compiler/generic:Context", ptr %l67, i32 0, i32 2
  %t164 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t163, i32 0, i32 0
  %t165 = load { i64, ptr }, ptr %t164
  %t166 = extractvalue { i64, ptr } %t165, 1
  %t167 = call ptr @__olang_region_or(ptr %t166, ptr null)
  %t168 = call ptr @__olang_region_home(ptr %t167)
  %t169 = icmp ne ptr %t168, null
  %t170 = select i1 %t169, ptr %t168, ptr %t162
  call void @__olang_region_settle_in(ptr %t122, ptr %t170)
  br label %bb25
bb25:
  %t171 = load ptr, ptr %l63, !tbaa !29
  %t172 = getelementptr %"compiler/check:frame", ptr %t171, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %l69, ptr %t172, i64 160, i1 false)
  %t173 = load ptr, ptr %l63, !tbaa !29
  %t174 = getelementptr %"compiler/check:frame", ptr %t173, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %t174, ptr %l67, i64 160, i1 false)
  %t175 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e4
  br i1 %t175, label %bb26, label %bb27
bb26:
  %t177 = getelementptr %"compiler/generic:Context", ptr %l69, i32 0, i32 3
  %t178 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t177, i32 0, i32 2
  %t179 = load { i64, ptr }, ptr %t178
  %t180 = extractvalue { i64, ptr } %t179, 1
  %t181 = call ptr @__olang_region_or(ptr %t180, ptr null)
  %t182 = call ptr @__olang_region_home(ptr %t181)
  %t183 = icmp ne ptr %t182, null
  %t184 = select i1 %t183, ptr %t182, ptr null
  %t185 = getelementptr %"compiler/generic:Context", ptr %l69, i32 0, i32 3
  %t186 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t185, i32 0, i32 1
  %t187 = load { i64, ptr }, ptr %t186
  %t188 = extractvalue { i64, ptr } %t187, 1
  %t189 = call ptr @__olang_region_or(ptr %t188, ptr null)
  %t190 = call ptr @__olang_region_home(ptr %t189)
  %t191 = icmp ne ptr %t190, null
  %t192 = select i1 %t191, ptr %t190, ptr %t184
  %t193 = getelementptr %"compiler/generic:Context", ptr %l69, i32 0, i32 3
  %t194 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t193, i32 0, i32 0
  %t195 = load { i64, ptr }, ptr %t194
  %t196 = extractvalue { i64, ptr } %t195, 1
  %t197 = call ptr @__olang_region_or(ptr %t196, ptr null)
  %t198 = call ptr @__olang_region_home(ptr %t197)
  %t199 = icmp ne ptr %t198, null
  %t200 = select i1 %t199, ptr %t198, ptr %t192
  %t201 = getelementptr %"compiler/generic:Context", ptr %l69, i32 0, i32 2
  %t202 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t201, i32 0, i32 2
  %t203 = load { i64, ptr }, ptr %t202
  %t204 = extractvalue { i64, ptr } %t203, 1
  %t205 = call ptr @__olang_region_or(ptr %t204, ptr null)
  %t206 = call ptr @__olang_region_home(ptr %t205)
  %t207 = icmp ne ptr %t206, null
  %t208 = select i1 %t207, ptr %t206, ptr %t200
  %t209 = getelementptr %"compiler/generic:Context", ptr %l69, i32 0, i32 2
  %t210 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t209, i32 0, i32 1
  %t211 = load { i64, ptr }, ptr %t210
  %t212 = extractvalue { i64, ptr } %t211, 1
  %t213 = call ptr @__olang_region_or(ptr %t212, ptr null)
  %t214 = call ptr @__olang_region_home(ptr %t213)
  %t215 = icmp ne ptr %t214, null
  %t216 = select i1 %t215, ptr %t214, ptr %t208
  %t217 = getelementptr %"compiler/generic:Context", ptr %l69, i32 0, i32 2
  %t218 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t217, i32 0, i32 0
  %t219 = load { i64, ptr }, ptr %t218
  %t220 = extractvalue { i64, ptr } %t219, 1
  %t221 = call ptr @__olang_region_or(ptr %t220, ptr null)
  %t222 = call ptr @__olang_region_home(ptr %t221)
  %t223 = icmp ne ptr %t222, null
  %t224 = select i1 %t223, ptr %t222, ptr %t216
  call void @__olang_region_drop(ptr %t224)
  store %"compiler/generic:Context" zeroinitializer, ptr %l69
  br label %bb27
bb27:
  %t225 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aContext_2e2
  br i1 %t225, label %bb28, label %bb29
bb28:
  %t227 = getelementptr %"compiler/generic:Context", ptr %l69, i32 0, i32 2
  %t228 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t227, i32 0, i32 2
  %t229 = load { i64, ptr }, ptr %t228
  %t230 = extractvalue { i64, ptr } %t229, 1
  %t231 = call ptr @__olang_region_or(ptr %t230, ptr null)
  %t232 = call ptr @__olang_region_home(ptr %t231)
  %t233 = icmp ne ptr %t232, null
  %t234 = select i1 %t233, ptr %t232, ptr null
  %t235 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t227, i32 0, i32 1
  %t236 = load { i64, ptr }, ptr %t235
  %t237 = extractvalue { i64, ptr } %t236, 1
  %t238 = call ptr @__olang_region_or(ptr %t237, ptr null)
  %t239 = call ptr @__olang_region_home(ptr %t238)
  %t240 = icmp ne ptr %t239, null
  %t241 = select i1 %t240, ptr %t239, ptr %t234
  %t242 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t227, i32 0, i32 0
  %t243 = load { i64, ptr }, ptr %t242
  %t244 = extractvalue { i64, ptr } %t243, 1
  %t245 = call ptr @__olang_region_or(ptr %t244, ptr null)
  %t246 = call ptr @__olang_region_home(ptr %t245)
  %t247 = icmp ne ptr %t246, null
  %t248 = select i1 %t247, ptr %t246, ptr %t241
  call void @__olang_region_drop(ptr %t248)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" zeroinitializer, ptr %t227
  br label %bb29
bb29:
  %t249 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aContext_2e3
  br i1 %t249, label %bb30, label %bb31
bb30:
  %t251 = getelementptr %"compiler/generic:Context", ptr %l69, i32 0, i32 3
  %t252 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t251, i32 0, i32 2
  %t253 = load { i64, ptr }, ptr %t252
  %t254 = extractvalue { i64, ptr } %t253, 1
  %t255 = call ptr @__olang_region_or(ptr %t254, ptr null)
  %t256 = call ptr @__olang_region_home(ptr %t255)
  %t257 = icmp ne ptr %t256, null
  %t258 = select i1 %t257, ptr %t256, ptr null
  %t259 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t251, i32 0, i32 1
  %t260 = load { i64, ptr }, ptr %t259
  %t261 = extractvalue { i64, ptr } %t260, 1
  %t262 = call ptr @__olang_region_or(ptr %t261, ptr null)
  %t263 = call ptr @__olang_region_home(ptr %t262)
  %t264 = icmp ne ptr %t263, null
  %t265 = select i1 %t264, ptr %t263, ptr %t258
  %t266 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t251, i32 0, i32 0
  %t267 = load { i64, ptr }, ptr %t266
  %t268 = extractvalue { i64, ptr } %t267, 1
  %t269 = call ptr @__olang_region_or(ptr %t268, ptr null)
  %t270 = call ptr @__olang_region_home(ptr %t269)
  %t271 = icmp ne ptr %t270, null
  %t272 = select i1 %t271, ptr %t270, ptr %t265
  call void @__olang_region_drop(ptr %t272)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" zeroinitializer, ptr %t251
  br label %bb31
bb31:
  %t273 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e0
  br i1 %t273, label %bb32, label %bb33
bb32:
  %t275 = getelementptr %"compiler/generic:Context", ptr %l69, i32 0, i32 2
  %t276 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t275, i32 0, i32 0
  %t277 = load { i64, ptr }, ptr %t276
  %t278 = extractvalue { i64, ptr } %t277, 0
  %t279 = extractvalue { i64, ptr } %t277, 1
  call void @__olang_region_release_part(ptr %t279, i64 %t278)
  store { i64, ptr } zeroinitializer, ptr %t276
  br label %bb33
bb33:
  %t280 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e1
  br i1 %t280, label %bb34, label %bb35
bb34:
  %t282 = getelementptr %"compiler/generic:Context", ptr %l69, i32 0, i32 2
  %t283 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t282, i32 0, i32 1
  %t284 = load { i64, ptr }, ptr %t283
  %t285 = extractvalue { i64, ptr } %t284, 0
  %t286 = extractvalue { i64, ptr } %t284, 1
  call void @__olang_region_release_part(ptr %t286, i64 %t285)
  store { i64, ptr } zeroinitializer, ptr %t283
  br label %bb35
bb35:
  %t287 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e2
  br i1 %t287, label %bb36, label %bb37
bb36:
  %t289 = getelementptr %"compiler/generic:Context", ptr %l69, i32 0, i32 2
  %t290 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t289, i32 0, i32 2
  %t291 = load { i64, ptr }, ptr %t290
  %t292 = extractvalue { i64, ptr } %t291, 0
  %t293 = extractvalue { i64, ptr } %t291, 1
  call void @__olang_region_release_part(ptr %t293, i64 %t292)
  store { i64, ptr } zeroinitializer, ptr %t290
  br label %bb37
bb37:
  %t294 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e0
  br i1 %t294, label %bb38, label %bb39
bb38:
  %t296 = getelementptr %"compiler/generic:Context", ptr %l69, i32 0, i32 3
  %t297 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t296, i32 0, i32 0
  %t298 = load { i64, ptr }, ptr %t297
  %t299 = extractvalue { i64, ptr } %t298, 0
  %t300 = extractvalue { i64, ptr } %t298, 1
  call void @__olang_region_release_part(ptr %t300, i64 %t299)
  store { i64, ptr } zeroinitializer, ptr %t297
  br label %bb39
bb39:
  %t301 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e1
  br i1 %t301, label %bb40, label %bb41
bb40:
  %t303 = getelementptr %"compiler/generic:Context", ptr %l69, i32 0, i32 3
  %t304 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t303, i32 0, i32 1
  %t305 = load { i64, ptr }, ptr %t304
  %t306 = extractvalue { i64, ptr } %t305, 0
  %t307 = extractvalue { i64, ptr } %t305, 1
  call void @__olang_region_release_part(ptr %t307, i64 %t306)
  store { i64, ptr } zeroinitializer, ptr %t304
  br label %bb41
bb41:
  %t308 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e2
  br i1 %t308, label %bb42, label %bb43
bb42:
  %t310 = getelementptr %"compiler/generic:Context", ptr %l69, i32 0, i32 3
  %t311 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t310, i32 0, i32 2
  %t312 = load { i64, ptr }, ptr %t311
  %t313 = extractvalue { i64, ptr } %t312, 0
  %t314 = extractvalue { i64, ptr } %t312, 1
  call void @__olang_region_release_part(ptr %t314, i64 %t313)
  store { i64, ptr } zeroinitializer, ptr %t311
  br label %bb43
bb43:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t317 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t315)
  store ptr %t317, ptr %l80
  br label %bb44
bb44:
  %t318 = load %"compiler/source:Span", ptr %l1
  %t319 = load ptr, ptr %l80, !tbaa !29
  %t322 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %t319, i32 -1, i32 0, %"compiler/source:Span" %t318)
  store i32 %t322, ptr %l83
  br label %bb45
bb45:
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t325 = getelementptr %"compiler/check:Checker", ptr %t323, i32 0, i32 48
  %t327 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t325)
  store i64 %t327, ptr %l86
  br label %bb46
bb46:
  %t328 = load i64, ptr %l86, !tbaa !24
  store i64 %t328, ptr %l12, !tbaa !24
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t331 = getelementptr %"compiler/check:Checker", ptr %t329, i32 0, i32 48
  store ptr %t331, ptr %l88, !tbaa !29
  %t332 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t332, ptr %l89
  %t333 = load ptr, ptr %l0, !tbaa !29
  store ptr %t333, ptr %l90, !tbaa !29
  %t334 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t334, ptr %l91
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t336 = load ptr, ptr %l3, !tbaa !29
  %t337 = load i64, ptr %l8, !tbaa !24
  %t341 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %v0, ptr %t335, ptr %t336, i64 %t337)
  store ptr %t341, ptr %l95
  br label %bb47
bb47:
  %t342 = load i32, ptr %l4, !tbaa !23
  %t343 = load ptr, ptr %l90, !tbaa !29
  %t344 = load %"compiler/source:Span", ptr %l91
  %t345 = load ptr, ptr %l95, !tbaa !29
  %t347 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efitsTest(ptr %v0, ptr %v0, ptr %v0, ptr %t343, %"compiler/source:Span" %t344, ptr %t345, i32 %t342)
  store ptr %t347, ptr %l97
  br label %bb48
bb48:
  %t348 = load ptr, ptr %l97, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t349
  %t350 = getelementptr { i64, [3 x i64] }, ptr %t349, i32 0, i32 0
  store i64 6, ptr %t350
  %t351 = load %"compiler/source:Span", ptr %l89
  %t352 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t351, 0
  %t354 = insertvalue { %"compiler/source:Span", ptr } %t352, ptr %t348, 1
  %t355 = getelementptr { i64, [3 x i64] }, ptr %t349, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t354, ptr %t355
  %t356 = load { i64, [3 x i64] }, ptr %t349
  %t358 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t356, ptr %t358
  %t359 = load ptr, ptr %l88, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t359, ptr %t358)
  br label %bb49
bb49:
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t363 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t361)
  store ptr %t363, ptr %l102
  br label %bb50
bb50:
  %t364 = load ptr, ptr %l102, !tbaa !29
  store ptr %t364, ptr %l103, !tbaa !29
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t367 = getelementptr %"compiler/check:Checker", ptr %t365, i32 0, i32 48
  %t368 = load i64, ptr %l12, !tbaa !24
  %t371 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t367, i64 %t368)
  store { i64, ptr } %t371, ptr %l107
  br label %bb51
bb51:
  %t372 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t373 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 0, { i64, ptr } %t372)
  store %"compiler/typed:Block" %t373, ptr %l108
  br label %bb52
bb52:
  %t374 = load %"compiler/typed:Block", ptr %l108
  %t375 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Block" %t374, ptr %t375
  %t377 = load ptr, ptr %l103, !tbaa !29
  %t378 = getelementptr %"compiler/typed:Body", ptr %t377, i32 0, i32 11
  store ptr %t375, ptr %t378, !tbaa !29
  %t379 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t379)
  br label %bb53
bb53:
  %t381 = load ptr, ptr %l0, !tbaa !29
  %t383 = getelementptr %"compiler/check:Checker", ptr %t381, i32 0, i32 24
  %t384 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t383, i64 %t384, i64 2)
  br label %bb54
bb54:
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t389 = getelementptr %"compiler/check:Checker", ptr %t387, i32 0, i32 1
  %t390 = load ptr, ptr %t389, !tbaa !29
  %t392 = getelementptr %"compiler/generic:Program", ptr %t390, i32 0, i32 0
  %t393 = load ptr, ptr %t392, !tbaa !29
  %t395 = getelementptr %"compiler/load:Loader", ptr %t393, i32 0, i32 4
  %t396 = load ptr, ptr %t395, !tbaa !29
  %t398 = call { { i64, [3 x i64] }, { i64, ptr } } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTopContext(ptr %v0, ptr %s0, ptr %t396)
  store { { i64, [3 x i64] }, { i64, ptr } } %t398, ptr %l118
  br label %bb55
bb55:
  %t399 = load { { i64, [3 x i64] }, { i64, ptr } }, ptr %l118
  store { { i64, [3 x i64] }, { i64, ptr } } %t399, ptr %l13
  %t400 = getelementptr { { i64, [3 x i64] }, { i64, ptr } }, ptr %l13, i32 0, i32 0
  %t401 = load { i64, [3 x i64] }, ptr %t400
  %t403 = getelementptr { { i64, [3 x i64] }, { i64, ptr } }, ptr %l13, i32 0, i32 1
  %t404 = load { i64, ptr }, ptr %t403, !tbaa !27
  store { i64, ptr } %t404, ptr %l120, !tbaa !27
  %t405 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t406 = extractvalue { i64, ptr } %t405, 0
  store i64 %t406, ptr %l121, !tbaa !24
  %t407 = load i64, ptr %l121, !tbaa !24
  %t408 = mul i64 %t407, 1
  %t409 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t408)
  %t410 = insertvalue { i64, ptr } undef, i64 %t407, 0
  %t411 = insertvalue { i64, ptr } %t410, ptr %t409, 1
  store { i64, ptr } %t411, ptr %l122, !tbaa !27
  %t412 = getelementptr { i64, ptr }, ptr %l122, i32 0, i32 1
  %t413 = load ptr, ptr %t412, !tbaa !27
  %t414 = getelementptr { i64, ptr }, ptr %l120, i32 0, i32 1
  %t415 = load ptr, ptr %t414, !tbaa !27
  %t416 = load i64, ptr %l121, !tbaa !24
  %t417 = mul i64 %t416, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t413, ptr %t415, i64 %t417, i1 false)
  %t418 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t418, ptr %lp15
  %t419 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t420 = load ptr, ptr %lp15
  store { i64, ptr } %t419, ptr %t420, !tbaa !27
  %t421 = load ptr, ptr %l0, !tbaa !29
  %t423 = getelementptr %"compiler/check:Checker", ptr %t421, i32 0, i32 151
  store ptr %t423, ptr %l124, !tbaa !29
  %t424 = load i64, ptr %l10, !tbaa !24
  store i64 %t424, ptr %l125, !tbaa !24
  %t425 = load i64, ptr %l7, !tbaa !24
  store i64 %t425, ptr %l126, !tbaa !24
  %t426 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t426, ptr %l127
  %t427 = load i64, ptr %l7, !tbaa !24
  store i64 %t427, ptr %l128, !tbaa !24
  %t428 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t428, ptr %l129
  %t429 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t429, ptr %l130, !tbaa !27
  store { i64, [3 x i64] } %t401, ptr %l131
  %t431 = load ptr, ptr %lp15
  %t432 = load { i64, ptr }, ptr %t431, !tbaa !27
  store { i64, ptr } %t432, ptr %l132, !tbaa !27
  %t433 = call ptr @__olang_scope_hold(ptr %v0)
  %t434 = ptrtoint ptr %t433 to i64
  store i64 %t434, ptr %l133, !tbaa !24
  %t435 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aContractAsk_2e9
  br i1 %t435, label %bb56, label %bb57
bb56:
  %t437 = call ptr @__olang_region_make(ptr %v0)
  %t438 = ptrtoint ptr %t437 to i64
  store i64 %t438, ptr %l133, !tbaa !24
  br label %bb57
bb57:
  %t439 = load ptr, ptr %l0, !tbaa !29
  %t440 = load i32, ptr %l4, !tbaa !23
  %t443 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t439, i32 %t440)
  store { i64, ptr } %t443, ptr %l137
  br label %bb58
bb58:
  %t444 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t445 = extractvalue { i64, ptr } %t444, 1
  %t446 = extractvalue { i64, ptr } %t444, 0
  %t447 = load i64, ptr %l133
  %t448 = inttoptr i64 %t447 to ptr
  %t449 = call ptr @__olang_held_alloc(ptr %t448, i64 %t446)
  call void @olang_textcopy(ptr %t449, ptr %t445, i64 %t446)
  %t450 = insertvalue { i64, ptr } undef, i64 %t446, 0
  %t451 = insertvalue { i64, ptr } %t450, ptr %t449, 1
  %t454 = load i64, ptr %l125, !tbaa !24
  %t455 = load i64, ptr %l126, !tbaa !24
  %t456 = load %"compiler/source:Span", ptr %l127
  %t457 = load i64, ptr %l128, !tbaa !24
  %t458 = load %"compiler/source:Span", ptr %l129
  %t459 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t460 = load { i64, [3 x i64] }, ptr %l131
  %t461 = load { i64, ptr }, ptr %l132, !tbaa !27
  call void @compiler_2fcheck_3aContractAsk_2ector(ptr %t453, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, i64 %t454, i64 %t455, %"compiler/source:Span" %t456, i64 %t457, %"compiler/source:Span" %t458, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d0, i32 0, i32 1) }, { i64, ptr } %t459, { i64, [3 x i64] } %t460, { i64, ptr } %t461, { i64, ptr } %t451, i1 false, i64 -1, i64 -1)
  call void @llvm.memmove.p0.p0.i64(ptr %l140, ptr %t453, i64 160, i1 false)
  br label %bb59
bb59:
  %t463 = load ptr, ptr %l124, !tbaa !29
  call void @llvm.memmove.p0.p0.i64(ptr %t464, ptr %l140, i64 160, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aContractAsk_3e_2ePu_H286c5e5dcd81788bf1de6ef6fc9774a9(ptr %v0, ptr %v0, ptr %t463, ptr %t464)
  br label %bb60
bb60:
  %t465 = load ptr, ptr %l0, !tbaa !29
  %t467 = getelementptr %"compiler/check:Checker", ptr %t465, i32 0, i32 152
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t467, i64 -1)
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecoversBool(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca [2 x i64]
  %l5 = alloca ptr
  %l6 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l25 = alloca i64
  %l27 = alloca i64
  %l32 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l45 = alloca i1
  %l48 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l51 = alloca i64
  %l53 = alloca i64
  %l58 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l62 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l77 = alloca i1
  %l81 = alloca i64
  %l84 = alloca i64
  %l102 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l105 = alloca i64
  %l107 = alloca i64
  %l112 = alloca { i64, ptr }
  %l114 = alloca { i64, ptr }
  %l116 = alloca i1
  %l117 = alloca i1
  %l119 = alloca { i64, ptr }
  %l121 = alloca i64
  %l124 = alloca ptr
  %l125 = alloca { i64, ptr }
  %l129 = alloca { i64, ptr }
  %l138 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [2 x i64] undef, i64 0, 0
  %t2 = insertvalue [2 x i64] %t1, i64 0, 1
  store [2 x i64] %t2, ptr %l4
  %t4 = load ptr, ptr %l1, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6, !tbaa !24
  store i64 %t6, ptr %l25, !tbaa !24
  %t7 = load ptr, ptr %l5, !tbaa !29
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_H06f4ae43b564aa38800728c5b9a6edfe(ptr %v1, ptr %t7)
  store i64 %t9, ptr %l27
  br label %bb2
bb2:
  %t10 = load i64, ptr %l25, !tbaa !24
  %t11 = load i64, ptr %l27, !tbaa !24
  %t12 = icmp slt i64 %t10, %t11
  %t14 = xor i1 %t12, true
  br i1 %t14, label %bb3, label %bb4
bb3:
  br label %bb12
bb4:
  br label %bb5
bb5:
  %t16 = load ptr, ptr %l5, !tbaa !29
  %t17 = load i64, ptr %l6, !tbaa !24
  %t20 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_Hb04d670045d084ea2498d9030c4fbba9(ptr %v1, ptr %v1, ptr %t16, i64 %t17)
  store { i64, ptr } %t20, ptr %l32
  br label %bb6
bb6:
  %t21 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t22 = load ptr, ptr %l0, !tbaa !29
  store { i64, ptr } %t21, ptr %l34, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr ptr, ptr %t25, i64 0
  %t27 = load ptr, ptr %t26, !tbaa !39
  %t30 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epatBool(ptr %v0, ptr %v1, ptr %t22, ptr %t27)
  store i64 %t30, ptr %l36
  br label %bb7
bb7:
  %t31 = load i64, ptr %l36, !tbaa !24
  store i64 %t31, ptr %l8, !tbaa !24
  %t32 = load i64, ptr %l8, !tbaa !24
  %t34 = icmp sge i64 %t32, 0
  br i1 %t34, label %bb8, label %bb9
bb8:
  %t36 = load i64, ptr %l8, !tbaa !24
  %t38 = getelementptr [2 x i64], ptr %l4, i64 0, i64 %t36
  store i64 1, ptr %t38, !tbaa !34
  br label %bb10
bb9:
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t39 = load i64, ptr %l6, !tbaa !24
  %t42 = add i64 %t39, 1
  store i64 %t42, ptr %l6, !tbaa !24
  br label %bb1
bb12:
  %t44 = getelementptr [2 x i64], ptr %l4, i64 0, i64 0
  %t45 = load i64, ptr %t44, !tbaa !34
  %t47 = icmp eq i64 %t45, 0
  br i1 %t47, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb15
bb14:
  %t49 = getelementptr [2 x i64], ptr %l4, i64 0, i64 1
  %t50 = load i64, ptr %t49, !tbaa !34
  %t52 = icmp eq i64 %t50, 0
  store i1 %t52, ptr %l45, !tbaa !21
  br label %bb15
bb15:
  %t54 = load i1, ptr %l45, !tbaa !21
  br i1 %t54, label %bb16, label %bb17
bb16:
  %t55 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t55, ptr %l48
  br label %bb18
bb17:
  br label %bb38
bb18:
  %t56 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l48
  %t57 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t56, ptr %t57
  store ptr %t57, ptr %l9, !tbaa !29
  %t59 = load ptr, ptr %l1, !tbaa !29
  store ptr %t59, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb19
bb19:
  %t61 = load i64, ptr %l11, !tbaa !24
  store i64 %t61, ptr %l51, !tbaa !24
  %t62 = load ptr, ptr %l10, !tbaa !29
  %t64 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_H06f4ae43b564aa38800728c5b9a6edfe(ptr %v1, ptr %t62)
  store i64 %t64, ptr %l53
  br label %bb20
bb20:
  %t65 = load i64, ptr %l51, !tbaa !24
  %t66 = load i64, ptr %l53, !tbaa !24
  %t67 = icmp slt i64 %t65, %t66
  %t69 = xor i1 %t67, true
  br i1 %t69, label %bb21, label %bb22
bb21:
  br label %bb36
bb22:
  br label %bb23
bb23:
  %t71 = load ptr, ptr %l10, !tbaa !29
  %t72 = load i64, ptr %l11, !tbaa !24
  %t75 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_Hb04d670045d084ea2498d9030c4fbba9(ptr %v1, ptr %v1, ptr %t71, i64 %t72)
  store { i64, ptr } %t75, ptr %l58
  br label %bb24
bb24:
  %t76 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t76, ptr %l12, !tbaa !27
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t78, ptr %l60, !tbaa !27
  %t79 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr ptr, ptr %t80, i64 0
  %t82 = load ptr, ptr %t81, !tbaa !39
  %t85 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epatWild(ptr %v0, ptr %v1, ptr %t77, ptr %t82)
  store i1 %t85, ptr %l62
  br label %bb25
bb25:
  %t86 = load i1, ptr %l62, !tbaa !21
  br i1 %t86, label %bb26, label %bb27
bb26:
  %t87 = load ptr, ptr %l9, !tbaa !29
  store ptr %t87, ptr %l63, !tbaa !29
  %t88 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t88, ptr %l64, !tbaa !27
  %t89 = icmp sge i64 0, 0
  br i1 %t89, label %bb28, label %bb29
bb27:
  br label %bb34
bb28:
  %t91 = icmp sle i64 0, 1152921504606846975
  br i1 %t91, label %bb30, label %bb31
bb29:
  call void @__olang_check_failed(ptr @olang_loc_fbe266e4ae717040_cab691a9684e8df4)
  unreachable
bb30:
  %t93 = mul i64 0, 8
  %t94 = insertvalue { i64, ptr } undef, i64 0, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t96 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t98 = call { i64, ptr } @compiler_2fcheck_2epatTail(ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t96, { i64, ptr } %t95, i64 0)
  store { i64, ptr } %t98, ptr %l68
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_fbe266e4ae717040_cab691a9684e8df4)
  unreachable
bb32:
  %t99 = load ptr, ptr %l63, !tbaa !29
  %t100 = load { i64, ptr }, ptr %l68, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_H19842cc3f9f17801919cd111c108caa0(ptr %v0, ptr %v1, ptr %t99, { i64, ptr } %t100)
  br label %bb33
bb33:
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t101 = load i64, ptr %l11, !tbaa !24
  %t104 = add i64 %t101, 1
  store i64 %t104, ptr %l11, !tbaa !24
  br label %bb19
bb36:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load ptr, ptr %l9, !tbaa !29
  %t108 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t109 = load i64, ptr %l3, !tbaa !24
  %t111 = add i64 %t109, 1
  %t116 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecoversRows(ptr %v0, ptr %v0, ptr %v2, ptr %t106, ptr %t107, { i64, ptr } %t108, i64 %t111)
  store i1 %t116, ptr %l77
  br label %bb37
bb37:
  %t117 = load i1, ptr %l77, !tbaa !21
  store i1 %t117, ptr %rv
  br label %ret
bb38:
  store i64 0, ptr %l13, !tbaa !24
  store i64 2, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t118 = load i64, ptr %l14, !tbaa !24
  %t119 = load i64, ptr %l13, !tbaa !24
  %t122 = icmp sgt i64 %t118, %t119
  br i1 %t122, label %bb39, label %bb40
bb39:
  %t124 = load i64, ptr %l15, !tbaa !24
  %t126 = icmp sgt i64 %t124, 0
  br i1 %t126, label %bb41, label %bb42
bb40:
  store i64 0, ptr %l81, !tbaa !24
  br label %bb44
bb41:
  %t128 = load i64, ptr %l14, !tbaa !24
  %t129 = load i64, ptr %l13, !tbaa !24
  %t132 = sub i64 %t128, %t129
  %t133 = load i64, ptr %l15, !tbaa !24
  %t136 = add i64 %t132, %t133
  %t138 = sub i64 %t136, 1
  %t139 = load i64, ptr %l15, !tbaa !24
  %t142 = sdiv i64 %t138, %t139
  store i64 %t142, ptr %l84, !tbaa !24
  br label %bb43
bb42:
  store i64 0, ptr %l84, !tbaa !24
  br label %bb43
bb43:
  %t144 = load i64, ptr %l84, !tbaa !24
  store i64 %t144, ptr %l81, !tbaa !24
  br label %bb44
bb44:
  %t145 = load i64, ptr %l81, !tbaa !24
  store i64 %t145, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb45
bb45:
  %t146 = load i64, ptr %l17, !tbaa !24
  %t147 = load i64, ptr %l16, !tbaa !24
  %t150 = icmp slt i64 %t146, %t147
  %t152 = xor i1 %t150, true
  br i1 %t152, label %bb46, label %bb47
bb46:
  br label %bb77
bb47:
  br label %bb48
bb48:
  %t154 = load i64, ptr %l13, !tbaa !24
  %t155 = load i64, ptr %l17, !tbaa !24
  %t156 = load i64, ptr %l15, !tbaa !24
  %t159 = mul i64 %t155, %t156
  %t162 = add i64 %t154, %t159
  store i64 %t162, ptr %l18, !tbaa !24
  %t164 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t164, ptr %l102
  br label %bb49
bb49:
  %t165 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l102
  %t166 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t165, ptr %t166
  store ptr %t166, ptr %l19, !tbaa !29
  %t168 = load ptr, ptr %l1, !tbaa !29
  store ptr %t168, ptr %l20, !tbaa !29
  store i64 0, ptr %l21, !tbaa !24
  br label %bb50
bb50:
  %t170 = load i64, ptr %l21, !tbaa !24
  store i64 %t170, ptr %l105, !tbaa !24
  %t171 = load ptr, ptr %l20, !tbaa !29
  %t173 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_H06f4ae43b564aa38800728c5b9a6edfe(ptr %v1, ptr %t171)
  store i64 %t173, ptr %l107
  br label %bb51
bb51:
  %t174 = load i64, ptr %l105, !tbaa !24
  %t175 = load i64, ptr %l107, !tbaa !24
  %t176 = icmp slt i64 %t174, %t175
  %t178 = xor i1 %t176, true
  br i1 %t178, label %bb52, label %bb53
bb52:
  br label %bb71
bb53:
  br label %bb54
bb54:
  %t180 = load ptr, ptr %l20, !tbaa !29
  %t181 = load i64, ptr %l21, !tbaa !24
  %t184 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_Hb04d670045d084ea2498d9030c4fbba9(ptr %v1, ptr %v1, ptr %t180, i64 %t181)
  store { i64, ptr } %t184, ptr %l112
  br label %bb55
bb55:
  %t185 = load { i64, ptr }, ptr %l112, !tbaa !27
  store { i64, ptr } %t185, ptr %l22, !tbaa !27
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t187, ptr %l114, !tbaa !27
  %t188 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = getelementptr ptr, ptr %t189, i64 0
  %t191 = load ptr, ptr %t190, !tbaa !39
  %t194 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epatWild(ptr %v0, ptr %v1, ptr %t186, ptr %t191)
  store i1 %t194, ptr %l116
  br label %bb56
bb56:
  %t195 = load i1, ptr %l116, !tbaa !21
  br i1 %t195, label %bb57, label %bb58
bb57:
  store i1 true, ptr %l117, !tbaa !21
  br label %bb60
bb58:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t197, ptr %l119, !tbaa !27
  %t198 = getelementptr { i64, ptr }, ptr %l119, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !27
  %t200 = getelementptr ptr, ptr %t199, i64 0
  %t201 = load ptr, ptr %t200, !tbaa !39
  %t204 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epatBool(ptr %v0, ptr %v1, ptr %t196, ptr %t201)
  store i64 %t204, ptr %l121
  br label %bb59
bb59:
  %t205 = load i64, ptr %l18, !tbaa !24
  %t206 = load i64, ptr %l121, !tbaa !24
  %t208 = icmp eq i64 %t206, %t205
  store i1 %t208, ptr %l117, !tbaa !21
  br label %bb60
bb60:
  %t210 = load i1, ptr %l117, !tbaa !21
  br i1 %t210, label %bb61, label %bb62
bb61:
  %t211 = load ptr, ptr %l19, !tbaa !29
  store ptr %t211, ptr %l124, !tbaa !29
  %t212 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t212, ptr %l125, !tbaa !27
  %t213 = icmp sge i64 0, 0
  br i1 %t213, label %bb63, label %bb64
bb62:
  br label %bb69
bb63:
  %t215 = icmp sle i64 0, 1152921504606846975
  br i1 %t215, label %bb65, label %bb66
bb64:
  call void @__olang_check_failed(ptr @olang_loc_ab02bd200d42d56d_7bb0032642cbe501)
  unreachable
bb65:
  %t217 = mul i64 0, 8
  %t218 = insertvalue { i64, ptr } undef, i64 0, 0
  %t219 = insertvalue { i64, ptr } %t218, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t220 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t222 = call { i64, ptr } @compiler_2fcheck_2epatTail(ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t220, { i64, ptr } %t219, i64 0)
  store { i64, ptr } %t222, ptr %l129
  br label %bb67
bb66:
  call void @__olang_check_failed(ptr @olang_loc_ab02bd200d42d56d_7bb0032642cbe501)
  unreachable
bb67:
  %t223 = load ptr, ptr %l124, !tbaa !29
  %t224 = load { i64, ptr }, ptr %l129, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_H19842cc3f9f17801919cd111c108caa0(ptr %v0, ptr %v1, ptr %t223, { i64, ptr } %t224)
  br label %bb68
bb68:
  br label %bb69
bb69:
  br label %bb70
bb70:
  %t225 = load i64, ptr %l21, !tbaa !24
  %t228 = add i64 %t225, 1
  store i64 %t228, ptr %l21, !tbaa !24
  br label %bb50
bb71:
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load ptr, ptr %l19, !tbaa !29
  %t232 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t233 = load i64, ptr %l3, !tbaa !24
  %t235 = add i64 %t233, 1
  %t240 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecoversRows(ptr %v0, ptr %v0, ptr %v2, ptr %t230, ptr %t231, { i64, ptr } %t232, i64 %t235)
  store i1 %t240, ptr %l138
  br label %bb72
bb72:
  %t241 = load i1, ptr %l138, !tbaa !21
  %t242 = xor i1 %t241, true
  br i1 %t242, label %bb73, label %bb74
bb73:
  store i1 false, ptr %rv
  br label %ret
bb74:
  br label %bb75
bb75:
  br label %bb76
bb76:
  %t245 = load i64, ptr %l17, !tbaa !24
  %t248 = add i64 %t245, 1
  store i64 %t248, ptr %l17, !tbaa !24
  br label %bb45
bb77:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorVarRules(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd"
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l35 = alloca i32
  %l37 = alloca i32
  %l41 = alloca { i64, ptr }
  %l45 = alloca %"compiler/source:Span"
  %l49 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l58 = alloca %"compiler/diagmsg:Msg"
  %l59 = alloca i64
  %l62 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l67 = alloca %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd"
  %l68 = alloca ptr
  %l70 = alloca ptr
  %l71 = alloca i32
  %l73 = alloca i1
  %l80 = alloca i64
  %l83 = alloca i64
  %l104 = alloca i1
  %l109 = alloca ptr
  %l111 = alloca { i64, ptr }
  %l113 = alloca %"compiler/source:Span"
  %l116 = alloca { i64, ptr }
  %l119 = alloca { i64, ptr }
  %l122 = alloca %"compiler/diagmsg:Msg"
  %l123 = alloca i64
  %l128 = alloca i1
  %l133 = alloca i1
  %l146 = alloca { i64, ptr }
  %l152 = alloca { i64, ptr }
  %l171 = alloca { i64, ptr }
  %l174 = alloca ptr
  %l176 = alloca %"compiler/source:Span"
  %l180 = alloca { i64, ptr }
  %l181 = alloca %"compiler/source:Span"
  %l184 = alloca ptr
  %l186 = alloca { i64, ptr }
  %l188 = alloca %"compiler/source:Span"
  %l191 = alloca { i64, ptr }
  %l194 = alloca { i64, ptr }
  %l195 = alloca { i64, ptr }
  %l199 = alloca { i64, ptr }
  %l203 = alloca { i64, ptr }
  %l207 = alloca { i64, ptr }
  %l208 = alloca %"compiler/diagmsg:Msg"
  %l209 = alloca i64
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %wh3 = alloca ptr
  %wc3 = alloca ptr
  %ws3 = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:StructBody", ptr %t1, i32 0, i32 5
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp eq i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/ast:TypeDecl", ptr %t10, i32 0, i32 1
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = getelementptr %"compiler/ast:StructBody", ptr %t19, i32 0, i32 5
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  store { i64, ptr } %t22, ptr %l31, !tbaa !27
  %t23 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr ptr, ptr %t24, i64 0
  %t26 = load ptr, ptr %t25, !tbaa !39
  store ptr %t26, ptr %l3, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l33, !tbaa !29
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t31 = getelementptr %"compiler/ast:TypeParam", ptr %t29, i32 0, i32 0
  %t32 = getelementptr %"compiler/source:Span", ptr %t31, i32 0, i32 0
  %t33 = load i32, ptr %t32, !tbaa !23
  store i32 %t33, ptr %l35, !tbaa !23
  %t34 = load ptr, ptr %l3, !tbaa !29
  %t36 = getelementptr %"compiler/ast:TypeParam", ptr %t34, i32 0, i32 0
  %t37 = getelementptr %"compiler/source:Span", ptr %t36, i32 0, i32 0
  %t38 = load i32, ptr %t37, !tbaa !23
  store i32 %t38, ptr %l37, !tbaa !23
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t42 = getelementptr %"compiler/ast:TypeParam", ptr %t40, i32 0, i32 1
  %t43 = load i32, ptr %t42, !tbaa !23
  %t46 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s2, ptr %t39, i32 %t43)
  store { i64, ptr } %t46, ptr %l41
  br label %bb6
bb5:
  br label %bb13
bb6:
  %t47 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t47, 0
  %t50 = trunc i64 %t48 to i32
  %t51 = load i32, ptr %l37, !tbaa !23
  %t53 = add i32 %t51, %t50
  %t54 = load i32, ptr %l35, !tbaa !23
  %t56 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s2, i32 %t54, i32 %t53)
  store %"compiler/source:Span" %t56, ptr %l45
  br label %bb7
bb7:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load ptr, ptr %l3, !tbaa !29
  %t60 = getelementptr %"compiler/ast:TypeParam", ptr %t58, i32 0, i32 1
  %t61 = load i32, ptr %t60, !tbaa !23
  %t64 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t57, i32 %t61)
  store { i64, ptr } %t64, ptr %l49
  br label %bb8
bb8:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr %"compiler/ast:TypeDecl", ptr %t66, i32 0, i32 0
  %t69 = load i32, ptr %t68, !tbaa !23
  %t72 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t65, i32 %t69)
  store { i64, ptr } %t72, ptr %l53
  br label %bb9
bb9:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load ptr, ptr %l3, !tbaa !29
  %t76 = getelementptr %"compiler/ast:TypeParam", ptr %t74, i32 0, i32 1
  %t77 = load i32, ptr %t76, !tbaa !23
  %t80 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t73, i32 %t77)
  store { i64, ptr } %t80, ptr %l57
  br label %bb10
bb10:
  %t81 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t82 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t83 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t84 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCtorVarOfGeneric(ptr %v0, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t81, { i64, ptr } %t82, { i64, ptr } %t83)
  store %"compiler/diagmsg:Msg" %t84, ptr %l58
  br label %bb11
bb11:
  %t85 = load ptr, ptr %l33, !tbaa !29
  %t86 = load %"compiler/source:Span", ptr %l45
  %t87 = load %"compiler/diagmsg:Msg", ptr %l58
  %t88 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t85, %"compiler/source:Span" %t86, %"compiler/diagmsg:Msg" %t87)
  store i64 %t88, ptr %l59
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb13:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load ptr, ptr %l2, !tbaa !29
  %t92 = getelementptr %"compiler/ast:StructBody", ptr %t90, i32 0, i32 5
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !27
  store { i64, ptr } %t93, ptr %l62, !tbaa !27
  %t94 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr ptr, ptr %t95, i64 0
  %t97 = load ptr, ptr %t96, !tbaa !39
  %t99 = getelementptr %"compiler/ast:TypeParam", ptr %t97, i32 0, i32 1
  %t100 = load i32, ptr %t99, !tbaa !23
  %t103 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t89, i32 %t100)
  store { i64, ptr } %t103, ptr %l65
  br label %bb14
bb14:
  %t104 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t104, ptr %l4, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s3
  %t105 = load ptr, ptr %l2, !tbaa !29
  %t107 = call %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" @compiler_2fgeneric_2eFieldDecls.walk(ptr %v2, ptr %s3, ptr %t105)
  %t108 = extractvalue %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" %t107, 0, 1
  %t109 = extractvalue %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" %t107, 0, 0
  store ptr %t108, ptr %wh3
  store ptr %t109, ptr %wc3
  store %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" %t107, ptr %l67
  br label %bb15
bb15:
  %t110 = load %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd", ptr %l67
  store %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" %t110, ptr %l5
  br label %bb16
bb16:
  %t112 = call { i32, ptr } @std_2fprelude_2fiterator_2estd_2fprelude_2fiterator_3aViewGenerator_3ccompiler_2fast_3aV_Hf179e857cb72c72900f4614cd5df5a25(ptr %s3, ptr %l5)
  %t113 = extractvalue { i32, ptr } %t112, 1
  %t114 = extractvalue { i32, ptr } %t112, 0
  store i32 %t114, ptr %l71
  %t115 = icmp ne i32 %t114, 0
  br i1 %t115, label %bb18, label %ok.116, !prof !99
ok.116:
  store ptr %t113, ptr %l70
  br label %bb17
bb17:
  %t117 = load ptr, ptr %l70, !tbaa !29
  store ptr %t117, ptr %l68, !tbaa !29
  br label %bb20
bb18:
  %t118 = load i32, ptr %l71, !tbaa !23
  %t119 = ashr i32 %t118, 16
  %t121 = icmp eq i32 %t119, 1
  store i1 %t121, ptr %l73, !tbaa !21
  br label %bb19
bb19:
  br label %bb82
bb20:
  %t122 = load ptr, ptr %l68, !tbaa !29
  store ptr %t122, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  %t123 = load ptr, ptr %l6, !tbaa !29
  %t125 = getelementptr %"compiler/ast:VarDecl", ptr %t123, i32 0, i32 0
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t126, 0
  store i64 %t128, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t130 = load i64, ptr %l8, !tbaa !24
  %t131 = load i64, ptr %l7, !tbaa !24
  %t134 = icmp sgt i64 %t130, %t131
  br i1 %t134, label %bb21, label %bb22
bb21:
  %t136 = load i64, ptr %l9, !tbaa !24
  %t138 = icmp sgt i64 %t136, 0
  br i1 %t138, label %bb23, label %bb24
bb22:
  store i64 0, ptr %l80, !tbaa !24
  br label %bb26
bb23:
  %t140 = load i64, ptr %l8, !tbaa !24
  %t141 = load i64, ptr %l7, !tbaa !24
  %t144 = sub i64 %t140, %t141
  %t145 = load i64, ptr %l9, !tbaa !24
  %t148 = add i64 %t144, %t145
  %t150 = sub i64 %t148, 1
  %t151 = load i64, ptr %l9, !tbaa !24
  %t154 = sdiv i64 %t150, %t151
  store i64 %t154, ptr %l83, !tbaa !24
  br label %bb25
bb24:
  store i64 0, ptr %l83, !tbaa !24
  br label %bb25
bb25:
  %t156 = load i64, ptr %l83, !tbaa !24
  store i64 %t156, ptr %l80, !tbaa !24
  br label %bb26
bb26:
  %t157 = load i64, ptr %l80, !tbaa !24
  store i64 %t157, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb27
bb27:
  %t158 = load i64, ptr %l11, !tbaa !24
  %t159 = load i64, ptr %l10, !tbaa !24
  %t162 = icmp slt i64 %t158, %t159
  %t164 = xor i1 %t162, true
  br i1 %t164, label %bb28, label %bb29
bb28:
  br label %bb80
bb29:
  br label %bb30
bb30:
  %t166 = load i64, ptr %l7, !tbaa !24
  %t167 = load i64, ptr %l11, !tbaa !24
  %t168 = load i64, ptr %l9, !tbaa !24
  %t171 = mul i64 %t167, %t168
  %t174 = add i64 %t166, %t171
  store i64 %t174, ptr %l12, !tbaa !24
  %t176 = load ptr, ptr %l6, !tbaa !29
  %t178 = getelementptr %"compiler/ast:VarDecl", ptr %t176, i32 0, i32 2
  %t179 = load ptr, ptr %t178, !tbaa !29
  %t181 = icmp eq ptr %t179, null
  br i1 %t181, label %bb31, label %bb32
bb31:
  %t183 = load ptr, ptr %l6, !tbaa !29
  %t185 = getelementptr %"compiler/ast:VarDecl", ptr %t183, i32 0, i32 3
  %t186 = load { i64, ptr }, ptr %t185, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t186, 0
  %t190 = icmp sgt i64 %t188, 0
  store i1 %t190, ptr %l104, !tbaa !21
  br label %bb33
bb32:
  store i1 false, ptr %l104, !tbaa !21
  br label %bb33
bb33:
  %t192 = load i1, ptr %l104, !tbaa !21
  br i1 %t192, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s7
  %t193 = load ptr, ptr %l0, !tbaa !29
  store ptr %t193, ptr %l109, !tbaa !29
  %t194 = load ptr, ptr %l6, !tbaa !29
  %t196 = getelementptr %"compiler/ast:VarDecl", ptr %t194, i32 0, i32 1
  %t197 = load { i64, ptr }, ptr %t196, !tbaa !27
  store { i64, ptr } %t197, ptr %l111, !tbaa !27
  %t198 = load i64, ptr %l12, !tbaa !24
  %t200 = getelementptr { i64, ptr }, ptr %l111, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !27
  %t202 = getelementptr %"compiler/source:Span", ptr %t201, i64 %t198
  %t203 = load %"compiler/source:Span", ptr %t202
  store %"compiler/source:Span" %t203, ptr %l113
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t205 = load ptr, ptr %l6, !tbaa !29
  %t207 = getelementptr %"compiler/ast:VarDecl", ptr %t205, i32 0, i32 0
  %t208 = load { i64, ptr }, ptr %t207, !tbaa !27
  store { i64, ptr } %t208, ptr %l116, !tbaa !27
  %t209 = load i64, ptr %l12, !tbaa !24
  %t211 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t212 = load ptr, ptr %t211, !tbaa !27
  %t213 = getelementptr i32, ptr %t212, i64 %t209
  %t214 = load i32, ptr %t213, !tbaa !33
  %t217 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s7, ptr %t204, i32 %t214)
  store { i64, ptr } %t217, ptr %l119
  br label %bb36
bb35:
  br label %bb39
bb36:
  %t218 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t219 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t222 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCtorGenericInferredField(ptr %s7, ptr %v0, ptr %v0, { i64, ptr } %t218, { i64, ptr } %t219)
  store %"compiler/diagmsg:Msg" %t222, ptr %l122
  br label %bb37
bb37:
  %t223 = load ptr, ptr %l109, !tbaa !29
  %t224 = load %"compiler/source:Span", ptr %l113
  %t225 = load %"compiler/diagmsg:Msg", ptr %l122
  %t226 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t223, %"compiler/source:Span" %t224, %"compiler/diagmsg:Msg" %t225)
  store i64 %t226, ptr %l123
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s7)
  store i32 0, ptr %ws3
  br label %wend3
wend3.c0:
  call void @__olang_scope_close(ptr %s3)
  br label %ret
bb39:
  %t227 = load ptr, ptr %l6, !tbaa !29
  %t229 = getelementptr %"compiler/ast:VarDecl", ptr %t227, i32 0, i32 2
  %t230 = load ptr, ptr %t229, !tbaa !29
  store ptr %t230, ptr %l13, !tbaa !29
  %t232 = load ptr, ptr %l13, !tbaa !29
  %t234 = icmp eq ptr %t232, null
  br i1 %t234, label %bb40, label %bb41
bb40:
  %t236 = load ptr, ptr %l6, !tbaa !29
  %t238 = getelementptr %"compiler/ast:VarDecl", ptr %t236, i32 0, i32 3
  %t239 = load { i64, ptr }, ptr %t238, !tbaa !27
  %t241 = extractvalue { i64, ptr } %t239, 0
  %t243 = icmp eq i64 %t241, 0
  store i1 %t243, ptr %l128, !tbaa !21
  br label %bb42
bb41:
  store i1 false, ptr %l128, !tbaa !21
  br label %bb42
bb42:
  %t245 = load i1, ptr %l128, !tbaa !21
  br i1 %t245, label %bb43, label %bb44
bb43:
  %t246 = load ptr, ptr %l2, !tbaa !29
  %t248 = getelementptr %"compiler/ast:StructBody", ptr %t246, i32 0, i32 0
  %t249 = load { i64, ptr }, ptr %t248, !tbaa !27
  %t251 = extractvalue { i64, ptr } %t249, 0
  %t253 = icmp sgt i64 %t251, 0
  store i1 %t253, ptr %l133, !tbaa !21
  br label %bb45
bb44:
  store i1 false, ptr %l133, !tbaa !21
  br label %bb45
bb45:
  %t255 = load i1, ptr %l133, !tbaa !21
  br i1 %t255, label %bb46, label %bb47
bb46:
  %t256 = load ptr, ptr %l2, !tbaa !29
  %t258 = getelementptr %"compiler/ast:StructBody", ptr %t256, i32 0, i32 0
  %t259 = load { i64, ptr }, ptr %t258, !tbaa !27
  store { i64, ptr } %t259, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t261 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t263 = extractvalue { i64, ptr } %t261, 0
  store i64 %t263, ptr %l16, !tbaa !24
  br label %bb48
bb47:
  br label %bb57
bb48:
  %t265 = load i64, ptr %l15, !tbaa !24
  %t266 = load i64, ptr %l16, !tbaa !24
  %t269 = icmp slt i64 %t265, %t266
  %t271 = xor i1 %t269, true
  br i1 %t271, label %bb49, label %bb50
bb49:
  br label %bb56
bb50:
  br label %bb51
bb51:
  %t273 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t273, ptr %l146, !tbaa !27
  %t274 = load i64, ptr %l15, !tbaa !24
  %t276 = getelementptr { i64, ptr }, ptr %l146, i32 0, i32 1
  %t277 = load ptr, ptr %t276, !tbaa !27
  %t278 = getelementptr ptr, ptr %t277, i64 %t274
  %t279 = load ptr, ptr %t278, !tbaa !39
  store ptr %t279, ptr %l17, !tbaa !29
  %t281 = load ptr, ptr %l17, !tbaa !29
  %t283 = getelementptr %"compiler/ast:Param", ptr %t281, i32 0, i32 1
  %t284 = load i32, ptr %t283, !tbaa !23
  %t285 = load ptr, ptr %l6, !tbaa !29
  %t287 = getelementptr %"compiler/ast:VarDecl", ptr %t285, i32 0, i32 0
  %t288 = load { i64, ptr }, ptr %t287, !tbaa !27
  store { i64, ptr } %t288, ptr %l152, !tbaa !27
  %t289 = load i64, ptr %l12, !tbaa !24
  %t291 = getelementptr { i64, ptr }, ptr %l152, i32 0, i32 1
  %t292 = load ptr, ptr %t291, !tbaa !27
  %t293 = getelementptr i32, ptr %t292, i64 %t289
  %t294 = load i32, ptr %t293, !tbaa !33
  %t297 = icmp eq i32 %t284, %t294
  br i1 %t297, label %bb52, label %bb53
bb52:
  %t299 = load ptr, ptr %l17, !tbaa !29
  %t301 = getelementptr %"compiler/ast:Param", ptr %t299, i32 0, i32 2
  %t302 = load ptr, ptr %t301, !tbaa !29
  store ptr %t302, ptr %l13, !tbaa !29
  br label %bb54
bb53:
  br label %bb54
bb54:
  br label %bb55
bb55:
  %t304 = load i64, ptr %l15, !tbaa !24
  %t307 = add i64 %t304, 1
  store i64 %t307, ptr %l15, !tbaa !24
  br label %bb48
bb56:
  br label %bb57
bb57:
  %t309 = load ptr, ptr %l13, !tbaa !29
  %t311 = icmp eq ptr %t309, null
  br i1 %t311, label %bb58, label %bb59
bb58:
  br label %bb79
bb59:
  br label %bb60
bb60:
  %t313 = load ptr, ptr %l2, !tbaa !29
  %t315 = getelementptr %"compiler/ast:StructBody", ptr %t313, i32 0, i32 5
  %t316 = load { i64, ptr }, ptr %t315, !tbaa !27
  store { i64, ptr } %t316, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t318 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t320 = extractvalue { i64, ptr } %t318, 0
  store i64 %t320, ptr %l20, !tbaa !24
  br label %bb61
bb61:
  store %olang.scope zeroinitializer, ptr %s15
  %t322 = load i64, ptr %l19, !tbaa !24
  %t323 = load i64, ptr %l20, !tbaa !24
  %t326 = icmp slt i64 %t322, %t323
  %t328 = xor i1 %t326, true
  br i1 %t328, label %bb62, label %bb63
bb62:
  call void @__olang_scope_close(ptr %s15)
  br label %bb78
bb63:
  br label %bb64
bb64:
  %t330 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t330, ptr %l171, !tbaa !27
  %t331 = load i64, ptr %l19, !tbaa !24
  %t333 = getelementptr { i64, ptr }, ptr %l171, i32 0, i32 1
  %t334 = load ptr, ptr %t333, !tbaa !27
  %t335 = getelementptr ptr, ptr %t334, i64 %t331
  %t336 = load ptr, ptr %t335, !tbaa !39
  store ptr %t336, ptr %l21, !tbaa !29
  %t338 = load ptr, ptr %l0, !tbaa !29
  store ptr %t338, ptr %l174, !tbaa !29
  %t339 = load ptr, ptr %l13, !tbaa !29
  %t341 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v2, ptr %t339)
  store %"compiler/source:Span" %t341, ptr %l176
  br label %bb65
bb65:
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t343 = load ptr, ptr %l21, !tbaa !29
  %t345 = getelementptr %"compiler/ast:TypeParam", ptr %t343, i32 0, i32 1
  %t346 = load i32, ptr %t345, !tbaa !23
  %t349 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t342, i32 %t346)
  store { i64, ptr } %t349, ptr %l180
  br label %bb66
bb66:
  %t350 = load ptr, ptr %l174, !tbaa !29
  %t351 = load %"compiler/source:Span", ptr %l176
  %t352 = load { i64, ptr }, ptr %l180, !tbaa !27
  %t353 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordIn(ptr %v0, ptr %v0, ptr %t350, %"compiler/source:Span" %t351, { i64, ptr } %t352)
  store %"compiler/source:Span" %t353, ptr %l181
  br label %bb67
bb67:
  %t354 = getelementptr %"compiler/source:Span", ptr %l181, i32 0, i32 0
  %t355 = load i32, ptr %t354, !tbaa !23
  %t357 = icmp slt i32 %t355, 0
  br i1 %t357, label %bb68, label %bb69
bb68:
  call void @__olang_scope_close(ptr %s15)
  br label %bb77
bb69:
  br label %bb70
bb70:
  %t359 = load ptr, ptr %l0, !tbaa !29
  store ptr %t359, ptr %l184, !tbaa !29
  %t360 = load ptr, ptr %l6, !tbaa !29
  %t362 = getelementptr %"compiler/ast:VarDecl", ptr %t360, i32 0, i32 1
  %t363 = load { i64, ptr }, ptr %t362, !tbaa !27
  store { i64, ptr } %t363, ptr %l186, !tbaa !27
  %t364 = load i64, ptr %l12, !tbaa !24
  %t366 = getelementptr { i64, ptr }, ptr %l186, i32 0, i32 1
  %t367 = load ptr, ptr %t366, !tbaa !27
  %t368 = getelementptr %"compiler/source:Span", ptr %t367, i64 %t364
  %t369 = load %"compiler/source:Span", ptr %t368
  store %"compiler/source:Span" %t369, ptr %l188
  %t370 = load ptr, ptr %l0, !tbaa !29
  %t371 = load ptr, ptr %l6, !tbaa !29
  %t373 = getelementptr %"compiler/ast:VarDecl", ptr %t371, i32 0, i32 0
  %t374 = load { i64, ptr }, ptr %t373, !tbaa !27
  store { i64, ptr } %t374, ptr %l191, !tbaa !27
  %t375 = load i64, ptr %l12, !tbaa !24
  %t377 = getelementptr { i64, ptr }, ptr %l191, i32 0, i32 1
  %t378 = load ptr, ptr %t377, !tbaa !27
  %t379 = getelementptr i32, ptr %t378, i64 %t375
  %t380 = load i32, ptr %t379, !tbaa !33
  %t383 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s15, ptr %t370, i32 %t380)
  store { i64, ptr } %t383, ptr %l194
  br label %bb71
bb71:
  %t384 = load { i64, ptr }, ptr %l194, !tbaa !27
  store { i64, ptr } %t384, ptr %l195, !tbaa !27
  %t385 = load ptr, ptr %l0, !tbaa !29
  %t386 = load ptr, ptr %l21, !tbaa !29
  %t388 = getelementptr %"compiler/ast:TypeParam", ptr %t386, i32 0, i32 1
  %t389 = load i32, ptr %t388, !tbaa !23
  %t392 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t385, i32 %t389)
  store { i64, ptr } %t392, ptr %l199
  br label %bb72
bb72:
  %t393 = load ptr, ptr %l0, !tbaa !29
  %t394 = load ptr, ptr %l1, !tbaa !29
  %t396 = getelementptr %"compiler/ast:TypeDecl", ptr %t394, i32 0, i32 0
  %t397 = load i32, ptr %t396, !tbaa !23
  %t400 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t393, i32 %t397)
  store { i64, ptr } %t400, ptr %l203
  br label %bb73
bb73:
  %t401 = load ptr, ptr %l0, !tbaa !29
  %t402 = load ptr, ptr %l21, !tbaa !29
  %t404 = getelementptr %"compiler/ast:TypeParam", ptr %t402, i32 0, i32 1
  %t405 = load i32, ptr %t404, !tbaa !23
  %t408 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t401, i32 %t405)
  store { i64, ptr } %t408, ptr %l207
  br label %bb74
bb74:
  %t409 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t410 = load { i64, ptr }, ptr %l199, !tbaa !27
  %t411 = load { i64, ptr }, ptr %l203, !tbaa !27
  %t412 = load { i64, ptr }, ptr %l207, !tbaa !27
  %t413 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCtorFieldNamesVar(ptr %s15, ptr %v0, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t409, { i64, ptr } %t410, { i64, ptr } %t411, { i64, ptr } %t412)
  store %"compiler/diagmsg:Msg" %t413, ptr %l208
  br label %bb75
bb75:
  %t414 = load ptr, ptr %l184, !tbaa !29
  %t415 = load %"compiler/source:Span", ptr %l188
  %t416 = load %"compiler/diagmsg:Msg", ptr %l208
  %t417 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t414, %"compiler/source:Span" %t415, %"compiler/diagmsg:Msg" %t416)
  store i64 %t417, ptr %l209
  br label %bb76
bb76:
  call void @__olang_scope_close(ptr %s15)
  store i32 1, ptr %ws3
  br label %wend3
wend3.c1:
  call void @__olang_scope_close(ptr %s3)
  br label %ret
bb77:
  %t418 = load i64, ptr %l19, !tbaa !24
  %t421 = add i64 %t418, 1
  store i64 %t421, ptr %l19, !tbaa !24
  br label %bb61
bb78:
  br label %bb79
bb79:
  %t423 = load i64, ptr %l11, !tbaa !24
  %t426 = add i64 %t423, 1
  store i64 %t426, ptr %l11, !tbaa !24
  br label %bb27
bb80:
  br label %bb81
bb81:
  br label %bb16
bb82:
  store i32 2, ptr %ws3
  br label %wend3
wend3.c2:
  call void @__olang_scope_close(ptr %s3)
  br label %ret
wend3:
  %t428 = load ptr, ptr %wh3
  %t429 = load ptr, ptr %wc3
  %t430 = call ptr @llvm.coro.promise(ptr %t428, i32 8, i1 false)
  %t431 = getelementptr { { i32, ptr }, i32 }, ptr %t430, i32 0, i32 1
  store i32 2, ptr %t431
  %t432 = call { i32, ptr } %t429(ptr %t428, ptr null)
  %t433 = load i32, ptr %ws3
  switch i32 %t433, label %wend3.c0 [ i32 1, label %wend3.c1 i32 2, label %wend3.c2 ]
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egeneratorCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i64
  %l16 = alloca i1
  %l18 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i64 @compiler_2ftyped_2eCalledBody(ptr %v1, ptr %a1)
  store i64 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i64, ptr %l5, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t7 = icmp slt i64 %t5, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 19
  %t13 = load i64, ptr %l2, !tbaa !24
  %t16 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t12, i64 %t13)
  store ptr %t16, ptr %l12
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l12, !tbaa !29
  %t18 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eInst(ptr %v0, ptr %t17)
  store i64 %t18, ptr %l13
  br label %bb6
bb6:
  %t19 = load i64, ptr %l13, !tbaa !24
  store i64 %t19, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l3, !tbaa !24
  %t22 = icmp sge i64 %t20, 0
  br i1 %t22, label %bb7, label %bb8
bb7:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  store ptr %t27, ptr %l18, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t32 = load i64, ptr %l3, !tbaa !24
  %t35 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t31, i64 %t32)
  store i64 %t35, ptr %l22
  br label %bb9
bb8:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb11
bb9:
  %t36 = load ptr, ptr %l18, !tbaa !29
  %t37 = load i64, ptr %l22, !tbaa !24
  %t38 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsGenerator(ptr %v0, ptr %t36, i64 %t37)
  store i1 %t38, ptr %l23
  br label %bb10
bb10:
  %t39 = load i1, ptr %l23, !tbaa !21
  store i1 %t39, ptr %l16, !tbaa !21
  br label %bb11
bb11:
  %t40 = load i1, ptr %l16, !tbaa !21
  store i1 %t40, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritableAt(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i32
  %l7 = alloca i1
  %l16 = alloca i32
  %l23 = alloca i64
  %l27 = alloca i1
  %l36 = alloca i32
  %l39 = alloca ptr
  %l44 = alloca i32
  %l47 = alloca i1
  %l52 = alloca ptr
  %l57 = alloca i32
  %l59 = alloca i1
  %l62 = alloca ptr
  %l67 = alloca i32
  %l69 = alloca i1
  %l75 = alloca i1
  %l80 = alloca i32
  %l83 = alloca ptr
  %l88 = alloca i32
  %l90 = alloca i1
  %l93 = alloca ptr
  %l98 = alloca i32
  %l100 = alloca i1
  %l103 = alloca ptr
  %l108 = alloca i32
  %l111 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sgt i64 %t1, 16
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t9 = icmp eq i32 %t5, %t6
  store i1 %t9, ptr %l7, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l7, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %l1, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l16
  br label %bb7
bb7:
  %t23 = load i32, ptr %l16, !range !{i32 0, i32 33}
  store i32 %t23, ptr %l3
  %t24 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t26 = trunc i64 20 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb15
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  %t35 = load i32, ptr %l1, !tbaa !23
  %t38 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t34, i32 %t35)
  store i64 %t38, ptr %l23
  br label %bb11
bb11:
  %t39 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t40 = load i64, ptr %l23, !tbaa !24
  %t42 = and i64 %t40, %t39
  %t44 = icmp ne i64 %t42, 0
  br i1 %t44, label %bb12, label %bb13
bb12:
  %t46 = load i64, ptr %l2, !tbaa !24
  %t48 = icmp sgt i64 %t46, 0
  store i1 %t48, ptr %l27, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb14
bb14:
  %t50 = load i1, ptr %l27, !tbaa !21
  store i1 %t50, ptr %rv
  br label %ret
bb15:
  %t51 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t53 = trunc i64 19 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb25
bb18:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 2
  %t62 = load i32, ptr %l1, !tbaa !23
  %t65 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t61, i32 %t62)
  store i32 %t65, ptr %l36
  br label %bb19
bb19:
  %t66 = load i32, ptr %l36, !tbaa !23
  %t67 = icmp eq i32 %t66, 0
  br i1 %t67, label %bb20, label %bb21
bb20:
  store i1 false, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l39, !tbaa !29
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/check:Checker", ptr %t71, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = getelementptr %"compiler/generic:Program", ptr %t74, i32 0, i32 2
  %t77 = load i32, ptr %l1, !tbaa !23
  %t80 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t76, i32 %t77)
  store i32 %t80, ptr %l44
  br label %bb23
bb23:
  %t81 = load i64, ptr %l2, !tbaa !24
  %t83 = add i64 %t81, 1
  %t84 = load ptr, ptr %l39, !tbaa !29
  %t85 = load i32, ptr %l44, !tbaa !23
  %t87 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritableAt(ptr %v0, ptr %t84, i32 %t85, i64 %t83)
  store i1 %t87, ptr %l47
  br label %bb24
bb24:
  %t88 = load i1, ptr %l47, !tbaa !21
  store i1 %t88, ptr %rv
  br label %ret
bb25:
  %t89 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t91 = trunc i64 22 to i32
  %t92 = icmp eq i32 %t89, %t91
  br i1 %t92, label %bb26, label %bb27
bb26:
  br label %bb30
bb27:
  %t94 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t96 = trunc i64 23 to i32
  %t97 = icmp eq i32 %t94, %t96
  br i1 %t97, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb33
bb30:
  %t99 = load ptr, ptr %l0, !tbaa !29
  store ptr %t99, ptr %l52, !tbaa !29
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/check:Checker", ptr %t100, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t105 = getelementptr %"compiler/generic:Program", ptr %t103, i32 0, i32 2
  %t106 = load i32, ptr %l1, !tbaa !23
  %t109 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t105, i32 %t106)
  store i32 %t109, ptr %l57
  br label %bb31
bb31:
  %t110 = load i64, ptr %l2, !tbaa !24
  %t111 = load ptr, ptr %l52, !tbaa !29
  %t112 = load i32, ptr %l57, !tbaa !23
  %t114 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsWritable(ptr %v0, ptr %t111, i32 %t112, i64 %t110)
  store i1 %t114, ptr %l59
  br label %bb32
bb32:
  %t115 = load i1, ptr %l59, !tbaa !21
  store i1 %t115, ptr %rv
  br label %ret
bb33:
  %t116 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t118 = trunc i64 24 to i32
  %t119 = icmp eq i32 %t116, %t118
  br i1 %t119, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb39
bb36:
  %t121 = load ptr, ptr %l0, !tbaa !29
  store ptr %t121, ptr %l62, !tbaa !29
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/check:Checker", ptr %t122, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !29
  %t127 = getelementptr %"compiler/generic:Program", ptr %t125, i32 0, i32 2
  %t128 = load i32, ptr %l1, !tbaa !23
  %t131 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t127, i32 %t128)
  store i32 %t131, ptr %l67
  br label %bb37
bb37:
  %t132 = load i64, ptr %l2, !tbaa !24
  %t133 = load ptr, ptr %l62, !tbaa !29
  %t134 = load i32, ptr %l67, !tbaa !23
  %t136 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsWritable(ptr %v0, ptr %t133, i32 %t134, i64 %t132)
  store i1 %t136, ptr %l69
  br label %bb38
bb38:
  %t137 = load i1, ptr %l69, !tbaa !21
  store i1 %t137, ptr %rv
  br label %ret
bb39:
  %t138 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t140 = trunc i64 18 to i32
  %t141 = icmp eq i32 %t138, %t140
  br i1 %t141, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb63
bb42:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/check:Checker", ptr %t143, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t147 = load i32, ptr %l1, !tbaa !23
  %t150 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t146, i32 %t147)
  store i1 %t150, ptr %l75
  br label %bb43
bb43:
  %t151 = load i1, ptr %l75, !tbaa !21
  %t152 = xor i1 %t151, true
  br i1 %t152, label %bb44, label %bb45
bb44:
  store i1 false, ptr %rv
  br label %ret
bb45:
  br label %bb46
bb46:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load i32, ptr %l1, !tbaa !23
  %t159 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t155, i32 %t156)
  store i32 %t159, ptr %l80
  br label %bb47
bb47:
  %t160 = load i32, ptr %l80, !range !{i32 0, i32 6}
  store i32 %t160, ptr %l4
  %t161 = load i32, ptr %l4, !range !{i32 0, i32 6}
  %t163 = trunc i64 0 to i32
  %t164 = icmp eq i32 %t161, %t163
  br i1 %t164, label %bb48, label %bb49
bb48:
  %t166 = load ptr, ptr %l0, !tbaa !29
  store ptr %t166, ptr %l83, !tbaa !29
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/check:Checker", ptr %t167, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !29
  %t172 = getelementptr %"compiler/generic:Program", ptr %t170, i32 0, i32 2
  %t173 = load i32, ptr %l1, !tbaa !23
  %t176 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t172, i32 %t173)
  store i32 %t176, ptr %l88
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t177 = load i64, ptr %l2, !tbaa !24
  %t178 = load ptr, ptr %l83, !tbaa !29
  %t179 = load i32, ptr %l88, !tbaa !23
  %t181 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsWritable(ptr %v0, ptr %t178, i32 %t179, i64 %t177)
  store i1 %t181, ptr %l90
  br label %bb51
bb51:
  %t182 = load i1, ptr %l90, !tbaa !21
  store i1 %t182, ptr %rv
  br label %ret
bb52:
  %t183 = load i32, ptr %l4, !range !{i32 0, i32 6}
  %t185 = trunc i64 1 to i32
  %t186 = icmp eq i32 %t183, %t185
  br i1 %t186, label %bb53, label %bb54
bb53:
  %t188 = load ptr, ptr %l0, !tbaa !29
  store ptr %t188, ptr %l93, !tbaa !29
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/check:Checker", ptr %t189, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !29
  %t194 = getelementptr %"compiler/generic:Program", ptr %t192, i32 0, i32 2
  %t195 = load i32, ptr %l1, !tbaa !23
  %t198 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t194, i32 %t195)
  store i32 %t198, ptr %l98
  br label %bb55
bb54:
  br label %bb57
bb55:
  %t199 = load i64, ptr %l2, !tbaa !24
  %t200 = load ptr, ptr %l93, !tbaa !29
  %t201 = load i32, ptr %l98, !tbaa !23
  %t203 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsWritable(ptr %v0, ptr %t200, i32 %t201, i64 %t199)
  store i1 %t203, ptr %l100
  br label %bb56
bb56:
  %t204 = load i1, ptr %l100, !tbaa !21
  store i1 %t204, ptr %rv
  br label %ret
bb57:
  %t205 = load i32, ptr %l4, !range !{i32 0, i32 6}
  %t207 = trunc i64 4 to i32
  %t208 = icmp eq i32 %t205, %t207
  br i1 %t208, label %bb58, label %bb59
bb58:
  %t210 = load ptr, ptr %l0, !tbaa !29
  store ptr %t210, ptr %l103, !tbaa !29
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/check:Checker", ptr %t211, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !29
  %t216 = getelementptr %"compiler/generic:Program", ptr %t214, i32 0, i32 2
  %t217 = load i32, ptr %l1, !tbaa !23
  %t220 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t216, i32 %t217)
  store i32 %t220, ptr %l108
  br label %bb60
bb59:
  br label %bb62
bb60:
  %t221 = load i64, ptr %l2, !tbaa !24
  %t223 = add i64 %t221, 1
  %t224 = load ptr, ptr %l103, !tbaa !29
  %t225 = load i32, ptr %l108, !tbaa !23
  %t227 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritableAt(ptr %v0, ptr %t224, i32 %t225, i64 %t223)
  store i1 %t227, ptr %l111
  br label %bb61
bb61:
  %t228 = load i1, ptr %l111, !tbaa !21
  store i1 %t228, ptr %rv
  br label %ret
bb62:
  store i1 false, ptr %rv
  br label %ret
bb63:
  br i1 true, label %bb64, label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb67
bb66:
  store i1 false, ptr %rv
  br label %ret
bb67:
  call void @__olang_check_failed(ptr @olang_loc_7aa3345d2beba7fc_151c01b23d5f0fc0)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholeFits(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l12 = alloca i1
  %l13 = alloca i1
  %l17 = alloca i1
  %l21 = alloca ptr
  %l24 = alloca i32
  %l27 = alloca i32
  %l28 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/check:Checker", ptr %t8, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/generic:Program", ptr %t11, i32 0, i32 2
  %t14 = load i32, ptr %l1, !tbaa !23
  %t15 = load i32, ptr %l2, !tbaa !23
  %t19 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t13, i32 %t14, i32 %t15)
  store i1 %t19, ptr %l12
  br label %bb4
bb4:
  %t20 = load i1, ptr %l12, !tbaa !21
  br i1 %t20, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb8
bb6:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l1, !tbaa !23
  %t23 = load i32, ptr %l2, !tbaa !23
  %t27 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %t21, i32 %t22, i32 %t23)
  store i1 %t27, ptr %l17
  br label %bb7
bb7:
  %t28 = load i1, ptr %l17, !tbaa !21
  store i1 %t28, ptr %l13, !tbaa !21
  br label %bb8
bb8:
  %t29 = load i1, ptr %l13, !tbaa !21
  br i1 %t29, label %bb9, label %bb10
bb9:
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = getelementptr %"compiler/generic:Program", ptr %t34, i32 0, i32 2
  store ptr %t36, ptr %l21, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i32, ptr %l1, !tbaa !23
  %t41 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l24
  br label %bb12
bb12:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i32, ptr %l2, !tbaa !23
  %t46 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t42, i32 %t43)
  store i32 %t46, ptr %l27
  br label %bb13
bb13:
  %t47 = load ptr, ptr %l21, !tbaa !29
  %t48 = load i32, ptr %l24, !tbaa !23
  %t49 = load i32, ptr %l27, !tbaa !23
  %t50 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t47, i32 %t48, i32 %t49)
  store i1 %t50, ptr %l28
  br label %bb14
bb14:
  %t51 = load i1, ptr %l28, !tbaa !21
  store i1 %t51, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einferReturn(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l17 = alloca ptr
  %l30 = alloca i64
  %l32 = alloca i64
  %l41 = alloca i64
  %l44 = alloca i64
  %l62 = alloca ptr
  %l64 = alloca { i64, ptr }
  %l69 = alloca ptr
  %l70 = alloca { i64, ptr }
  %l73 = alloca %"compiler/source:Span"
  %l74 = alloca ptr
  %l77 = alloca i32
  %l81 = alloca i1
  %l85 = alloca ptr
  %l86 = alloca { i64, ptr }
  %l89 = alloca %"compiler/source:Span"
  %l90 = alloca %"compiler/diagmsg:Msg"
  %l91 = alloca i64
  %l97 = alloca { i64, ptr }
  %l101 = alloca i32
  %l105 = alloca ptr
  %l106 = alloca ptr
  %l107 = alloca ptr
  %l108 = alloca i32
  %l109 = alloca { i64, ptr }
  %l112 = alloca %"compiler/source:Span"
  %l113 = alloca ptr
  %l120 = alloca { i64, ptr }
  %l126 = alloca { i64, ptr }
  %l128 = alloca i32
  %l130 = alloca i32
  %l132 = alloca i1
  %l133 = alloca ptr
  %l136 = alloca i32
  %l137 = alloca i1
  %l145 = alloca ptr
  %l152 = alloca ptr
  %l155 = alloca ptr
  %l160 = alloca i32
  %l161 = alloca i32
  %l162 = alloca ptr
  %l163 = alloca %"compiler/source:Span"
  %l164 = alloca %"compiler/source:Span"
  %l166 = alloca i32
  %l170 = alloca %"compiler/typed:Make"
  %s0 = alloca %olang.scope
  %t21 = alloca { i64, [3 x i64] }, align 8
  %t278 = alloca { i64, [4 x i64] }, align 8
  %t299 = alloca { i64, [3 x i64] }, align 8
  %t348 = alloca { i64, [5 x i64] }, align 8
  %t360 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l17
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l17, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 25
  store i1 false, ptr %t7, !tbaa !21
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t12 = icmp eq i64 %t10, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = load ptr, ptr %l3, !tbaa !29
  %t15 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t18 = getelementptr %"compiler/check:frame", ptr %t14, i32 0, i32 5
  store i32 %t15, ptr %t18, !tbaa !23
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load %"compiler/source:Span", ptr %l1
  store { i64, [3 x i64] } zeroinitializer, ptr %t21
  %t22 = getelementptr { i64, [3 x i64] }, ptr %t21, i32 0, i32 0
  store i64 6, ptr %t22
  %t24 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t20, 0
  %t25 = insertvalue { %"compiler/source:Span", ptr } %t24, ptr null, 1
  %t26 = getelementptr { i64, [3 x i64] }, ptr %t21, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t25, ptr %t26
  %t27 = load { i64, [3 x i64] }, ptr %t21
  %t29 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t27, ptr %t29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t19, ptr %t29)
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 47
  %t36 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t34)
  store i64 %t36, ptr %l30
  br label %bb6
bb6:
  %t37 = load i64, ptr %l30, !tbaa !24
  store i64 %t37, ptr %l4, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t38, 0
  store i64 %t40, ptr %l32, !tbaa !24
  %t41 = load i64, ptr %l32, !tbaa !24
  %t42 = icmp sge i64 %t41, 0
  br i1 %t42, label %bb7, label %bb8
bb7:
  %t44 = load i64, ptr %l32, !tbaa !24
  %t45 = icmp sle i64 %t44, 2305843009213693951
  br i1 %t45, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_a6a18c8586cf83c4_fafef84db4cc6ad8)
  unreachable
bb9:
  %t47 = load i64, ptr %l32, !tbaa !24
  %t48 = mul i64 %t47, 4
  %t49 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t48)
  %t50 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  store { i64, ptr } %t51, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t53 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 0
  store i64 %t55, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t57 = load i64, ptr %l7, !tbaa !24
  %t58 = load i64, ptr %l6, !tbaa !24
  %t61 = icmp sgt i64 %t57, %t58
  br i1 %t61, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_a6a18c8586cf83c4_fafef84db4cc6ad8)
  unreachable
bb11:
  %t63 = load i64, ptr %l8, !tbaa !24
  %t65 = icmp sgt i64 %t63, 0
  br i1 %t65, label %bb13, label %bb14
bb12:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb16
bb13:
  %t67 = load i64, ptr %l7, !tbaa !24
  %t68 = load i64, ptr %l6, !tbaa !24
  %t71 = sub i64 %t67, %t68
  %t72 = load i64, ptr %l8, !tbaa !24
  %t75 = add i64 %t71, %t72
  %t77 = sub i64 %t75, 1
  %t78 = load i64, ptr %l8, !tbaa !24
  %t81 = sdiv i64 %t77, %t78
  store i64 %t81, ptr %l44, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb15
bb15:
  %t83 = load i64, ptr %l44, !tbaa !24
  store i64 %t83, ptr %l41, !tbaa !24
  br label %bb16
bb16:
  %t84 = load i64, ptr %l41, !tbaa !24
  store i64 %t84, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb17
bb17:
  %t85 = load i64, ptr %l10, !tbaa !24
  %t86 = load i64, ptr %l9, !tbaa !24
  %t89 = icmp slt i64 %t85, %t86
  %t91 = xor i1 %t89, true
  br i1 %t91, label %bb18, label %bb19
bb18:
  br label %bb42
bb19:
  br label %bb20
bb20:
  %t93 = load i64, ptr %l6, !tbaa !24
  %t94 = load i64, ptr %l10, !tbaa !24
  %t95 = load i64, ptr %l8, !tbaa !24
  %t98 = mul i64 %t94, %t95
  %t101 = add i64 %t93, %t98
  store i64 %t101, ptr %l11, !tbaa !24
  %t103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t103, ptr %l62, !tbaa !29
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t105, ptr %l64, !tbaa !27
  %t106 = load i64, ptr %l11, !tbaa !24
  %t108 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr ptr, ptr %t109, i64 %t106
  %t111 = load ptr, ptr %t110, !tbaa !39
  %t113 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t117 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t104, ptr %t111, i32 %t113)
  store ptr %t117, ptr %l69
  br label %bb21
bb21:
  %t118 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t118, ptr %l70, !tbaa !27
  %t119 = load i64, ptr %l11, !tbaa !24
  %t121 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = getelementptr ptr, ptr %t122, i64 %t119
  %t124 = load ptr, ptr %t123, !tbaa !39
  %t126 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t124)
  store %"compiler/source:Span" %t126, ptr %l73
  br label %bb22
bb22:
  %t127 = load ptr, ptr %l62, !tbaa !29
  %t128 = load ptr, ptr %l69, !tbaa !29
  %t129 = load %"compiler/source:Span", ptr %l73
  %t130 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v0, ptr %v0, ptr %t127, ptr %t128, %"compiler/source:Span" %t129)
  store ptr %t130, ptr %l74
  br label %bb23
bb23:
  %t131 = load ptr, ptr %l74, !tbaa !29
  store ptr %t131, ptr %l12, !tbaa !29
  %t132 = load ptr, ptr %l12, !tbaa !29
  %t135 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t132)
  store i32 %t135, ptr %l77
  br label %bb24
bb24:
  %t136 = load i32, ptr %l77, !tbaa !23
  store i32 %t136, ptr %l13, !tbaa !23
  %t137 = load i32, ptr %l13, !tbaa !23
  %t138 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t141 = icmp eq i32 %t137, %t138
  br i1 %t141, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l81, !tbaa !21
  br label %bb27
bb26:
  %t143 = load i32, ptr %l13, !tbaa !23
  %t144 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t147 = icmp eq i32 %t143, %t144
  store i1 %t147, ptr %l81, !tbaa !21
  br label %bb27
bb27:
  %t149 = load i1, ptr %l81, !tbaa !21
  br i1 %t149, label %bb28, label %bb29
bb28:
  %t150 = load ptr, ptr %l0, !tbaa !29
  store ptr %t150, ptr %l85, !tbaa !29
  %t151 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t151, ptr %l86, !tbaa !27
  %t152 = load i64, ptr %l11, !tbaa !24
  %t154 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = getelementptr ptr, ptr %t155, i64 %t152
  %t157 = load ptr, ptr %t156, !tbaa !39
  %t159 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t157)
  store %"compiler/source:Span" %t159, ptr %l89
  br label %bb30
bb29:
  %t160 = load i32, ptr %l13, !tbaa !23
  %t161 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t164 = icmp ne i32 %t160, %t161
  br i1 %t164, label %bb33, label %bb34
bb30:
  %t166 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLambdaResultUninferable(ptr %v0)
  store %"compiler/diagmsg:Msg" %t166, ptr %l90
  br label %bb31
bb31:
  %t167 = load ptr, ptr %l85, !tbaa !29
  %t168 = load %"compiler/source:Span", ptr %l89
  %t169 = load %"compiler/diagmsg:Msg", ptr %l90
  %t170 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t167, %"compiler/source:Span" %t168, %"compiler/diagmsg:Msg" %t169)
  store i64 %t170, ptr %l91
  br label %bb32
bb32:
  %t171 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t171, ptr %l13, !tbaa !23
  br label %bb37
bb33:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t174, ptr %l97, !tbaa !27
  %t175 = load i64, ptr %l11, !tbaa !24
  %t177 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = getelementptr ptr, ptr %t178, i64 %t175
  %t180 = load ptr, ptr %t179, !tbaa !39
  %t181 = load ptr, ptr %l12, !tbaa !29
  %t185 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einferred(ptr %v0, ptr %v1, ptr %v0, ptr %t173, ptr %t180, ptr %t181, i1 false)
  store i32 %t185, ptr %l101
  br label %bb35
bb34:
  br label %bb36
bb35:
  %t186 = load i32, ptr %l101, !tbaa !23
  store i32 %t186, ptr %l13, !tbaa !23
  br label %bb36
bb36:
  br label %bb37
bb37:
  %t187 = load i64, ptr %l11, !tbaa !24
  %t188 = load i32, ptr %l13, !tbaa !23
  %t191 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !27
  %t193 = getelementptr i32, ptr %t192, i64 %t187
  store i32 %t188, ptr %t193, !tbaa !33
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/check:Checker", ptr %t194, i32 0, i32 47
  store ptr %t196, ptr %l105, !tbaa !29
  %t197 = load ptr, ptr %l0, !tbaa !29
  store ptr %t197, ptr %l106, !tbaa !29
  %t198 = load ptr, ptr %l12, !tbaa !29
  store ptr %t198, ptr %l107, !tbaa !29
  %t199 = load i32, ptr %l13, !tbaa !23
  store i32 %t199, ptr %l108, !tbaa !23
  %t200 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t200, ptr %l109, !tbaa !27
  %t201 = load i64, ptr %l11, !tbaa !24
  %t203 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t204 = load ptr, ptr %t203, !tbaa !27
  %t205 = getelementptr ptr, ptr %t204, i64 %t201
  %t206 = load ptr, ptr %t205, !tbaa !39
  %t208 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t206)
  store %"compiler/source:Span" %t208, ptr %l112
  br label %bb38
bb38:
  %t209 = load ptr, ptr %l106, !tbaa !29
  %t210 = load ptr, ptr %l107, !tbaa !29
  %t211 = load i32, ptr %l108, !tbaa !23
  %t212 = load %"compiler/source:Span", ptr %l112
  %t213 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v0, ptr %v0, ptr %t209, ptr %t210, i32 %t211, %"compiler/source:Span" %t212)
  store ptr %t213, ptr %l113
  br label %bb39
bb39:
  %t214 = load ptr, ptr %l105, !tbaa !29
  %t215 = load ptr, ptr %l113, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t214, ptr %t215)
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t216 = load i64, ptr %l10, !tbaa !24
  %t219 = add i64 %t216, 1
  store i64 %t219, ptr %l10, !tbaa !24
  br label %bb17
bb42:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr %"compiler/check:Checker", ptr %t221, i32 0, i32 47
  %t224 = load i64, ptr %l4, !tbaa !24
  %t227 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t223, i64 %t224)
  store { i64, ptr } %t227, ptr %l120
  br label %bb43
bb43:
  %t228 = load { i64, ptr }, ptr %l120, !tbaa !27
  store { i64, ptr } %t228, ptr %l14, !tbaa !27
  %t229 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t231 = extractvalue { i64, ptr } %t229, 0
  %t233 = icmp eq i64 %t231, 1
  br i1 %t233, label %bb44, label %bb45
bb44:
  %t235 = load ptr, ptr %l3, !tbaa !29
  %t236 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t237 = load ptr, ptr %t236, !tbaa !27
  %t238 = getelementptr i32, ptr %t237, i64 0
  %t239 = load i32, ptr %t238, !tbaa !33
  %t242 = getelementptr %"compiler/check:frame", ptr %t235, i32 0, i32 5
  store i32 %t239, ptr %t242, !tbaa !23
  %t243 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t243, ptr %l126, !tbaa !27
  %t244 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t245 = load ptr, ptr %t244, !tbaa !27
  %t246 = getelementptr ptr, ptr %t245, i64 0
  %t247 = load ptr, ptr %t246, !tbaa !39
  store ptr %t247, ptr %l15, !tbaa !29
  %t249 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t250 = load ptr, ptr %t249, !tbaa !27
  %t251 = getelementptr i32, ptr %t250, i64 0
  %t252 = load i32, ptr %t251, !tbaa !33
  store i32 %t252, ptr %l128, !tbaa !23
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t255 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t253)
  store i32 %t255, ptr %l130
  br label %bb46
bb45:
  br label %bb57
bb46:
  %t256 = load i32, ptr %l128, !tbaa !23
  %t257 = load i32, ptr %l130, !tbaa !23
  %t258 = icmp eq i32 %t256, %t257
  br i1 %t258, label %bb47, label %bb48
bb47:
  %t260 = load ptr, ptr %l0, !tbaa !29
  store ptr %t260, ptr %l133, !tbaa !29
  %t261 = load ptr, ptr %l15, !tbaa !29
  %t264 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t261)
  store i32 %t264, ptr %l136
  br label %bb49
bb48:
  store i1 false, ptr %l132, !tbaa !21
  br label %bb51
bb49:
  %t265 = load ptr, ptr %l133, !tbaa !29
  %t266 = load i32, ptr %l136, !tbaa !23
  %t267 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t265, i32 %t266)
  store i1 %t267, ptr %l137
  br label %bb50
bb50:
  %t268 = load i1, ptr %l137, !tbaa !21
  store i1 %t268, ptr %l132, !tbaa !21
  br label %bb51
bb51:
  %t269 = load i1, ptr %l132, !tbaa !21
  br i1 %t269, label %bb52, label %bb53
bb52:
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t271 = load %"compiler/source:Span", ptr %l1
  %t272 = load %"compiler/source:Span", ptr %l1
  %t273 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t274 = load ptr, ptr %t273, !tbaa !27
  %t275 = getelementptr i32, ptr %t274, i64 0
  %t276 = load i32, ptr %t275, !tbaa !33
  %t277 = load ptr, ptr %l15, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t278
  %t279 = getelementptr { i64, [4 x i64] }, ptr %t278, i32 0, i32 0
  store i64 2, ptr %t279
  %t281 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t272, 0
  %t283 = insertvalue { %"compiler/source:Span", i32, ptr } %t281, i32 %t276, 1
  %t285 = insertvalue { %"compiler/source:Span", i32, ptr } %t283, ptr %t277, 2
  %t286 = getelementptr { i64, [4 x i64] }, ptr %t278, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t285, ptr %t286
  %t287 = load { i64, [4 x i64] }, ptr %t278
  %t289 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t287, ptr %t289
  %t293 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t270, %"compiler/source:Span" %t271, ptr %t289)
  store ptr %t293, ptr %l145
  br label %bb54
bb53:
  br label %bb55
bb54:
  %t294 = load ptr, ptr %l145, !tbaa !29
  store ptr %t294, ptr %l15, !tbaa !29
  br label %bb55
bb55:
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t296 = load %"compiler/source:Span", ptr %l1
  %t297 = load ptr, ptr %l15, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t299
  %t300 = getelementptr { i64, [3 x i64] }, ptr %t299, i32 0, i32 0
  store i64 6, ptr %t300
  %t302 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t296, 0
  %t304 = insertvalue { %"compiler/source:Span", ptr } %t302, ptr %t297, 1
  %t305 = getelementptr { i64, [3 x i64] }, ptr %t299, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t304, ptr %t305
  %t306 = load { i64, [3 x i64] }, ptr %t299
  %t308 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t306, ptr %t308
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t295, ptr %t308)
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb57:
  %t311 = load ptr, ptr %l3, !tbaa !29
  store ptr %t311, ptr %l152, !tbaa !29
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t314 = getelementptr %"compiler/check:Checker", ptr %t312, i32 0, i32 1
  %t315 = load ptr, ptr %t314, !tbaa !29
  %t317 = getelementptr %"compiler/generic:Program", ptr %t315, i32 0, i32 2
  store ptr %t317, ptr %l155, !tbaa !29
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t320 = getelementptr %"compiler/check:Checker", ptr %t318, i32 0, i32 1
  %t321 = load ptr, ptr %t320, !tbaa !29
  %t323 = getelementptr %"compiler/generic:Program", ptr %t321, i32 0, i32 2
  %t324 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t327 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t323, { i64, ptr } %t324)
  store i32 %t327, ptr %l160
  br label %bb58
bb58:
  %t328 = load ptr, ptr %l155, !tbaa !29
  %t329 = load i32, ptr %l160, !tbaa !23
  %t330 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eTuple(ptr %v0, ptr %t328, i32 %t329)
  store i32 %t330, ptr %l161
  br label %bb59
bb59:
  %t331 = load i32, ptr %l161, !tbaa !23
  %t332 = load ptr, ptr %l152, !tbaa !29
  %t333 = getelementptr %"compiler/check:frame", ptr %t332, i32 0, i32 5
  store i32 %t331, ptr %t333, !tbaa !23
  %t334 = load ptr, ptr %l0, !tbaa !29
  store ptr %t334, ptr %l162, !tbaa !29
  %t335 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t335, ptr %l163
  %t336 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t336, ptr %l164
  %t337 = load ptr, ptr %l3, !tbaa !29
  %t339 = getelementptr %"compiler/check:frame", ptr %t337, i32 0, i32 5
  %t340 = load i32, ptr %t339, !tbaa !23
  store i32 %t340, ptr %l166, !tbaa !23
  %t341 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t345 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v0, ptr %v0, i32 0, i64 0, { i64, ptr } %t341, ptr null, i32 -1, i32 0, i1 false)
  store %"compiler/typed:Make" %t345, ptr %l170
  br label %bb60
bb60:
  %t346 = load %"compiler/typed:Make", ptr %l170
  %t347 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/typed:Make" %t346, ptr %t347
  store { i64, [5 x i64] } zeroinitializer, ptr %t348
  %t349 = getelementptr { i64, [5 x i64] }, ptr %t348, i32 0, i32 0
  store i64 7, ptr %t349
  %t350 = load %"compiler/source:Span", ptr %l164
  %t351 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t350, 0
  %t352 = load i32, ptr %l166, !tbaa !23
  %t353 = insertvalue { %"compiler/source:Span", i32, ptr } %t351, i32 %t352, 1
  %t355 = insertvalue { %"compiler/source:Span", i32, ptr } %t353, ptr %t347, 2
  %t356 = getelementptr { i64, [5 x i64] }, ptr %t348, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t355, ptr %t356
  %t357 = load { i64, [5 x i64] }, ptr %t348
  %t359 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t357, ptr %t359
  store { i64, [3 x i64] } zeroinitializer, ptr %t360
  %t361 = getelementptr { i64, [3 x i64] }, ptr %t360, i32 0, i32 0
  store i64 6, ptr %t361
  %t362 = load %"compiler/source:Span", ptr %l163
  %t363 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t362, 0
  %t365 = insertvalue { %"compiler/source:Span", ptr } %t363, ptr %t359, 1
  %t366 = getelementptr { i64, [3 x i64] }, ptr %t360, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t365, ptr %t366
  %t367 = load { i64, [3 x i64] }, ptr %t360
  %t369 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t367, ptr %t369
  %t370 = load ptr, ptr %l162, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t370, ptr %t369)
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisTrait(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l6 = alloca i32
  %l9 = alloca i1
  %l12 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l6
  br label %bb1
bb1:
  %t11 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t13 = trunc i64 18 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  store ptr %t21, ptr %l12, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  %t28 = load i32, ptr %l1, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l17
  br label %bb4
bb3:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb6
bb4:
  %t32 = load ptr, ptr %l12, !tbaa !29
  %t33 = load i32, ptr %l17, !tbaa !23
  %t34 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t32, i32 %t33)
  store i32 %t34, ptr %l18
  br label %bb5
bb5:
  %t35 = load i32, ptr %l18, !range !{i32 0, i32 6}
  %t37 = trunc i64 3 to i32
  %t38 = icmp eq i32 %t35, %t37
  store i1 %t38, ptr %l9, !tbaa !21
  br label %bb6
bb6:
  %t40 = load i1, ptr %l9, !tbaa !21
  store i1 %t40, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ejudgeTables(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca %"compiler/generic:AnyTable"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l18 = alloca i64
  %l20 = alloca i1
  %l25 = alloca i64
  %l31 = alloca i64
  %l35 = alloca i64
  %l38 = alloca i64
  %l60 = alloca %"compiler/generic:AnyTable"
  %l61 = alloca %"compiler/generic:AnyTable"
  %l62 = alloca i64
  %l64 = alloca { i64, ptr }
  %l65 = alloca i64
  %l66 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l75 = alloca i64
  %l79 = alloca i64
  %l82 = alloca i64
  %l100 = alloca ptr
  %l101 = alloca ptr
  %l102 = alloca { i64, ptr }
  %l107 = alloca ptr
  %l110 = alloca i64
  %l111 = alloca i1
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 70
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnyTable_3e_2eLen_H9daf28210c013890fd7cb07d1d61ba6e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l18
  br label %bb1
bb1:
  %t9 = load i64, ptr %l18, !tbaa !24
  %t10 = icmp eq i64 %t9, 0
  br i1 %t10, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb5
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 0
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/load:Loader", ptr %t18, i32 0, i32 4
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v0, ptr %t21)
  store i64 %t23, ptr %l25
  br label %bb4
bb4:
  %t24 = load i64, ptr %l25, !tbaa !24
  %t25 = icmp sgt i64 %t24, 0
  store i1 %t25, ptr %l20, !tbaa !21
  br label %bb5
bb5:
  %t27 = load i1, ptr %l20, !tbaa !21
  br i1 %t27, label %bb6, label %bb7
bb6:
  br label %ret
bb7:
  br label %bb8
bb8:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 9
  store ptr null, ptr %t30, !tbaa !29
  store i64 0, ptr %l1, !tbaa !24
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = getelementptr %"compiler/generic:Program", ptr %t34, i32 0, i32 70
  %t38 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnyTable_3e_2eLen_H9daf28210c013890fd7cb07d1d61ba6e(ptr %v0, ptr %t36)
  store i64 %t38, ptr %l31
  br label %bb9
bb9:
  %t39 = load i64, ptr %l31, !tbaa !24
  store i64 %t39, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t40 = load i64, ptr %l2, !tbaa !24
  %t41 = load i64, ptr %l1, !tbaa !24
  %t44 = icmp sgt i64 %t40, %t41
  br i1 %t44, label %bb10, label %bb11
bb10:
  %t46 = load i64, ptr %l3, !tbaa !24
  %t48 = icmp sgt i64 %t46, 0
  br i1 %t48, label %bb12, label %bb13
bb11:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb15
bb12:
  %t50 = load i64, ptr %l2, !tbaa !24
  %t51 = load i64, ptr %l1, !tbaa !24
  %t54 = sub i64 %t50, %t51
  %t55 = load i64, ptr %l3, !tbaa !24
  %t58 = add i64 %t54, %t55
  %t60 = sub i64 %t58, 1
  %t61 = load i64, ptr %l3, !tbaa !24
  %t64 = sdiv i64 %t60, %t61
  store i64 %t64, ptr %l38, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l38, !tbaa !24
  br label %bb14
bb14:
  %t66 = load i64, ptr %l38, !tbaa !24
  store i64 %t66, ptr %l35, !tbaa !24
  br label %bb15
bb15:
  %t67 = load i64, ptr %l35, !tbaa !24
  store i64 %t67, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  %t68 = load i64, ptr %l5, !tbaa !24
  %t69 = load i64, ptr %l4, !tbaa !24
  %t72 = icmp slt i64 %t68, %t69
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb47
bb18:
  br label %bb19
bb19:
  %t76 = load i64, ptr %l1, !tbaa !24
  %t77 = load i64, ptr %l5, !tbaa !24
  %t78 = load i64, ptr %l3, !tbaa !24
  %t81 = mul i64 %t77, %t78
  %t84 = add i64 %t76, %t81
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/check:Checker", ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = getelementptr %"compiler/generic:Program", ptr %t89, i32 0, i32 70
  %t95 = call %"compiler/generic:AnyTable" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnyTable_3e_2eAt__He9601a52fe5cfa5abe1b41d520aed001(ptr %v0, ptr %v0, ptr %t91, i64 %t84)
  store %"compiler/generic:AnyTable" %t95, ptr %l60
  br label %bb20
bb20:
  %t96 = load %"compiler/generic:AnyTable", ptr %l60
  store %"compiler/generic:AnyTable" %t96, ptr %l61
  %t97 = call ptr @__olang_scope_hold(ptr %s3)
  %t98 = ptrtoint ptr %t97 to i64
  store i64 %t98, ptr %l62, !tbaa !24
  %t99 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t99, label %bb21, label %bb22
bb21:
  %t101 = call ptr @__olang_region_make_part(ptr %s3)
  %t102 = ptrtoint ptr %t101 to i64
  store i64 %t102, ptr %l62, !tbaa !24
  br label %bb22
bb22:
  %t103 = getelementptr %"compiler/generic:AnyTable", ptr %l61, i32 0, i32 5
  %t104 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t103, i32 0, i32 0
  %t105 = load { i64, ptr }, ptr %t104, !tbaa !27
  store { i64, ptr } %t105, ptr %l64, !tbaa !27
  %t106 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t106, 0
  store i64 %t107, ptr %l65, !tbaa !24
  %t108 = load i64, ptr %l65, !tbaa !24
  %t109 = mul i64 %t108, 8
  %t110 = load i64, ptr %l62
  %t111 = inttoptr i64 %t110 to ptr
  %t112 = call ptr @__olang_held_alloc(ptr %t111, i64 %t109)
  %t113 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t114 = insertvalue { i64, ptr } %t113, ptr %t112, 1
  store { i64, ptr } %t114, ptr %l66, !tbaa !27
  %t115 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !27
  %t119 = load i64, ptr %l65, !tbaa !24
  %t120 = mul i64 %t119, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t116, ptr %t118, i64 %t120, i1 false)
  %t121 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t122 = getelementptr %"compiler/generic:AnyTable", ptr %l61, i32 0, i32 5
  %t123 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t122, i32 0, i32 0
  store { i64, ptr } %t121, ptr %t123, !tbaa !27
  %t124 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t124, label %bb23, label %bb24
bb23:
  %t126 = getelementptr %"compiler/generic:AnyTable", ptr %l61, i32 0, i32 5
  %t127 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t126, i32 0, i32 0
  %t128 = load { i64, ptr }, ptr %t127, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t128, 0
  %t131 = icmp eq i64 %t129, 0
  br i1 %t131, label %bb25, label %bb26
bb24:
  %t133 = load %"compiler/generic:AnyTable", ptr %l61
  store %"compiler/generic:AnyTable" %t133, ptr %l7
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/check:Checker", ptr %t134, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !29
  %t138 = getelementptr %"compiler/generic:AnyTable", ptr %l7, i32 0, i32 1
  %t139 = load i32, ptr %t138, !tbaa !23
  %t142 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v0, ptr %t137, i32 %t139)
  store { i64, ptr } %t142, ptr %l73
  br label %bb27
bb25:
  %t143 = getelementptr %"compiler/generic:AnyTable", ptr %l61, i32 0, i32 5
  %t144 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t143, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t144, !tbaa !27
  br label %bb26
bb26:
  %t145 = getelementptr %"compiler/generic:AnyTable", ptr %l61, i32 0, i32 5
  %t146 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t145, i32 0, i32 0
  %t147 = load i64, ptr %l62
  %t148 = inttoptr i64 %t147 to ptr
  %t149 = load { i64, ptr }, ptr %t146
  %t150 = extractvalue { i64, ptr } %t149, 1
  %t151 = call ptr @__olang_region_or(ptr %t150, ptr null)
  %t152 = icmp ne ptr %t151, null
  %t153 = select i1 %t152, ptr %t151, ptr null
  call void @__olang_region_settle_in(ptr %t148, ptr %t153)
  br label %bb24
bb27:
  %t154 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t154, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t155 = getelementptr %"compiler/generic:AnyTable", ptr %l7, i32 0, i32 5
  %t157 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s3, ptr %t155)
  store i64 %t157, ptr %l75
  br label %bb28
bb28:
  %t158 = load i64, ptr %l75, !tbaa !24
  store i64 %t158, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t159 = load i64, ptr %l10, !tbaa !24
  %t160 = load i64, ptr %l9, !tbaa !24
  %t163 = icmp sgt i64 %t159, %t160
  br i1 %t163, label %bb29, label %bb30
bb29:
  %t165 = load i64, ptr %l11, !tbaa !24
  %t167 = icmp sgt i64 %t165, 0
  br i1 %t167, label %bb31, label %bb32
bb30:
  store i64 0, ptr %l79, !tbaa !24
  br label %bb34
bb31:
  %t169 = load i64, ptr %l10, !tbaa !24
  %t170 = load i64, ptr %l9, !tbaa !24
  %t173 = sub i64 %t169, %t170
  %t174 = load i64, ptr %l11, !tbaa !24
  %t177 = add i64 %t173, %t174
  %t179 = sub i64 %t177, 1
  %t180 = load i64, ptr %l11, !tbaa !24
  %t183 = sdiv i64 %t179, %t180
  store i64 %t183, ptr %l82, !tbaa !24
  br label %bb33
bb32:
  store i64 0, ptr %l82, !tbaa !24
  br label %bb33
bb33:
  %t185 = load i64, ptr %l82, !tbaa !24
  store i64 %t185, ptr %l79, !tbaa !24
  br label %bb34
bb34:
  %t186 = load i64, ptr %l79, !tbaa !24
  store i64 %t186, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb35
bb35:
  %t187 = load i64, ptr %l13, !tbaa !24
  %t188 = load i64, ptr %l12, !tbaa !24
  %t191 = icmp slt i64 %t187, %t188
  %t193 = xor i1 %t191, true
  br i1 %t193, label %bb36, label %bb37
bb36:
  br label %bb45
bb37:
  br label %bb38
bb38:
  %t195 = load i64, ptr %l9, !tbaa !24
  %t196 = load i64, ptr %l13, !tbaa !24
  %t197 = load i64, ptr %l11, !tbaa !24
  %t200 = mul i64 %t196, %t197
  %t203 = add i64 %t195, %t200
  store i64 %t203, ptr %l14, !tbaa !24
  %t205 = load ptr, ptr %l0, !tbaa !29
  store ptr %t205, ptr %l100, !tbaa !29
  store ptr %l7, ptr %l101, !tbaa !29
  %t206 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t206, ptr %l102, !tbaa !27
  %t207 = load i64, ptr %l14, !tbaa !24
  %t208 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t210 = extractvalue { i64, ptr } %t208, 0
  %t213 = srem i64 %t207, %t210
  %t215 = getelementptr { i64, ptr }, ptr %l102, i32 0, i32 1
  %t216 = load ptr, ptr %t215, !tbaa !27
  %t217 = getelementptr %"compiler/generic:AnySlot", ptr %t216, i64 %t213
  store ptr %t217, ptr %l107, !tbaa !29
  %t218 = getelementptr %"compiler/generic:AnyTable", ptr %l7, i32 0, i32 5
  %t219 = load i64, ptr %l14, !tbaa !24
  %t222 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s3, ptr %t218, i64 %t219)
  store i64 %t222, ptr %l110
  br label %bb39
bb39:
  %t223 = load ptr, ptr %l100, !tbaa !29
  %t224 = load ptr, ptr %l101, !tbaa !29
  %t225 = load ptr, ptr %l107, !tbaa !29
  %t226 = load i64, ptr %l110, !tbaa !24
  %t227 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ejudgeSlot(ptr %v0, ptr %s3, ptr %v0, ptr %t223, ptr %t224, ptr %t225, i64 %t226)
  store i1 %t227, ptr %l111
  br label %bb40
bb40:
  %t228 = load i1, ptr %l111, !tbaa !21
  br i1 %t228, label %bb41, label %bb42
bb41:
  br label %bb45
bb42:
  br label %bb43
bb43:
  br label %bb44
bb44:
  %t229 = load i64, ptr %l13, !tbaa !24
  %t232 = add i64 %t229, 1
  store i64 %t232, ptr %l13, !tbaa !24
  br label %bb35
bb45:
  call void @__olang_scope_close(ptr %s3)
  br label %bb46
bb46:
  %t234 = load i64, ptr %l5, !tbaa !24
  %t237 = add i64 %t234, 1
  store i64 %t237, ptr %l5, !tbaa !24
  br label %bb16
bb47:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsWritable(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l11 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l23 = alloca i1
  %l28 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t6, i32 %a1)
  store { i64, ptr } %t10, ptr %l11
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t11, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  store i64 %t14, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t16 = load i64, ptr %l4, !tbaa !24
  %t17 = load i64, ptr %l5, !tbaa !24
  %t20 = icmp slt i64 %t16, %t17
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb3, label %bb4
bb3:
  br label %bb14
bb4:
  br label %bb5
bb5:
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t24, ptr %l18, !tbaa !27
  %t25 = load i64, ptr %l4, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i32, ptr %t28, i64 %t25
  %t30 = load i32, ptr %t29, !tbaa !33
  store i32 %t30, ptr %l6, !tbaa !23
  %t32 = load i32, ptr %l6, !tbaa !23
  %t34 = icmp ne i32 %t32, 0
  br i1 %t34, label %bb6, label %bb7
bb6:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i32, ptr %l6, !tbaa !23
  %t40 = add i64 %a2, 1
  %t44 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritableAt(ptr %v0, ptr %t36, i32 %t37, i64 %t40)
  store i1 %t44, ptr %l28
  br label %bb8
bb7:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb9
bb8:
  %t45 = load i1, ptr %l28, !tbaa !21
  store i1 %t45, ptr %l23, !tbaa !21
  br label %bb9
bb9:
  %t46 = load i1, ptr %l23, !tbaa !21
  br i1 %t46, label %bb10, label %bb11
bb10:
  store i1 true, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t48 = load i64, ptr %l4, !tbaa !24
  %t51 = add i64 %t48, 1
  store i64 %t51, ptr %l4, !tbaa !24
  br label %bb2
bb14:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ememberRules(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/source:Span"
  %l4 = alloca i64
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca { i64, ptr }
  %l11 = alloca %"compiler/source:Span"
  %l16 = alloca i64
  %l22 = alloca ptr
  %l26 = alloca ptr
  %l28 = alloca %"compiler/source:Span"
  %l31 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l35 = alloca %"compiler/source:Span"
  %l36 = alloca %"compiler/diagmsg:Msg"
  %l37 = alloca i64
  %l43 = alloca i32
  %l51 = alloca i32
  %l56 = alloca i32
  %l60 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l65 = alloca ptr
  %l68 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l71 = alloca i1
  %l72 = alloca i1
  %l77 = alloca i32
  %l81 = alloca i1
  %l86 = alloca i64
  %l88 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %l92 = alloca i32
  %l94 = alloca i32
  %l97 = alloca { i64, ptr }
  %l101 = alloca %"compiler/source:Span"
  %l104 = alloca { i64, ptr }
  %l106 = alloca %"compiler/source:Span"
  %l108 = alloca i1
  %l110 = alloca ptr
  %l111 = alloca %"compiler/source:Span"
  %l112 = alloca { i64, ptr }
  %l115 = alloca { i64, ptr }
  %l118 = alloca %"compiler/diagmsg:Msg"
  %l119 = alloca i64
  %l124 = alloca i64
  %l126 = alloca ptr
  %l127 = alloca %"compiler/source:Span"
  %l128 = alloca { i64, ptr }
  %l131 = alloca { i64, ptr }
  %l133 = alloca %"compiler/diagmsg:Msg"
  %l134 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t6 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t7 = load i32, ptr %t6, !tbaa !23
  %t11 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberAt(ptr %v0, ptr %t4, i64 %t5, i32 %t7)
  store i64 %t11, ptr %l16
  br label %bb1
bb1:
  %t12 = load i64, ptr %l16, !tbaa !24
  store i64 %t12, ptr %l4, !tbaa !24
  %t13 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp slt i64 %t13, 0
  br i1 %t15, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i64, ptr %l1, !tbaa !24
  %t19 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t23 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v0, ptr %t17, i64 -1, i64 %t18, i32 %t19, i32 0)
  store ptr %t23, ptr %l22
  br label %bb5
bb5:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberOwnerRef(ptr %v0, ptr %v0, ptr %t27, i64 %t28)
  store ptr %t31, ptr %l26
  br label %bb6
bb6:
  %t32 = load ptr, ptr %l26, !tbaa !29
  %t35 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %t32)
  store %"compiler/source:Span" %t35, ptr %l28
  br label %bb7
bb7:
  %t36 = load %"compiler/source:Span", ptr %l28
  store %"compiler/source:Span" %t36, ptr %l6
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load %"compiler/source:Span", ptr %l6
  %t41 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t37, %"compiler/source:Span" %t38)
  store { i64, ptr } %t41, ptr %l31
  br label %bb8
bb8:
  %t42 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t42, ptr %l7, !tbaa !27
  %t45 = xor i1 %a3, true
  br i1 %t45, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l34, !tbaa !29
  %t48 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t48, ptr %l35
  %t49 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMemberInPlaceKind(ptr %s2, ptr %v0, { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t49, ptr %l36
  br label %bb11
bb10:
  br label %bb14
bb11:
  %t50 = load ptr, ptr %l34, !tbaa !29
  %t51 = load %"compiler/source:Span", ptr %l35
  %t52 = load %"compiler/diagmsg:Msg", ptr %l36
  %t53 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t50, %"compiler/source:Span" %t51, %"compiler/diagmsg:Msg" %t52)
  store i64 %t53, ptr %l37
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  %t54 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t54)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb14:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load i64, ptr %l1, !tbaa !24
  %t58 = load i64, ptr %l4, !tbaa !24
  %t59 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t64 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ememberOwnerOk(ptr %v0, ptr %v0, ptr %t56, i64 %t57, i64 %t58, { i64, ptr } %t59)
  store i32 %t64, ptr %l43
  br label %bb15
bb15:
  %t65 = load i32, ptr %l43, !tbaa !23
  store i32 %t65, ptr %l8, !tbaa !23
  %t66 = load i32, ptr %l8, !tbaa !23
  %t67 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t70 = icmp eq i32 %t66, %t67
  br i1 %t70, label %bb16, label %bb17
bb16:
  %t72 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t72)
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb19:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/check:Checker", ptr %t74, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t78 = load i64, ptr %l4, !tbaa !24
  %t81 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberName(ptr %v0, ptr %t77, i64 %t78)
  store i32 %t81, ptr %l51
  br label %bb20
bb20:
  %t82 = load i32, ptr %l51, !tbaa !23
  store i32 %t82, ptr %l9, !tbaa !23
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 2
  %t89 = load i32, ptr %l8, !tbaa !23
  %t92 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t88, i32 %t89)
  store i32 %t92, ptr %l56
  br label %bb21
bb21:
  %t93 = load i32, ptr %l56, !range !{i32 0, i32 33}
  %t95 = trunc i64 25 to i32
  %t96 = icmp eq i32 %t93, %t95
  %t98 = xor i1 %t96, true
  br i1 %t98, label %bb22, label %bb23
bb22:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load i32, ptr %l8, !tbaa !23
  %t102 = load i32, ptr %l9, !tbaa !23
  %t106 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamespaceTaken(ptr %v0, ptr %s0, ptr %t100, i32 %t101, i32 %t102)
  store { i64, ptr } %t106, ptr %l64
  br label %bb24
bb23:
  %t107 = load ptr, ptr %l0, !tbaa !29
  store ptr %t107, ptr %l65, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load i32, ptr %l9, !tbaa !23
  %t112 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t108, i32 %t109)
  store { i64, ptr } %t112, ptr %l68
  br label %bb25
bb24:
  %t113 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t113, ptr %l60, !tbaa !27
  br label %bb27
bb25:
  %t114 = load ptr, ptr %l65, !tbaa !29
  %t115 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t116 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflectedName(ptr %v0, ptr %v0, ptr %s0, ptr %t114, { i64, ptr } %t115)
  store { i64, ptr } %t116, ptr %l69
  br label %bb26
bb26:
  %t117 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t117, ptr %l60, !tbaa !27
  br label %bb27
bb27:
  %t118 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t118, ptr %l10, !tbaa !27
  %t119 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t121 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t119, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i1 %t121, ptr %l71
  br label %bb28
bb28:
  %t122 = load i1, ptr %l71, !tbaa !21
  br i1 %t122, label %bb29, label %bb30
bb29:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/check:Checker", ptr %t123, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t128 = getelementptr %"compiler/generic:Program", ptr %t126, i32 0, i32 2
  %t129 = load i32, ptr %l8, !tbaa !23
  %t132 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t128, i32 %t129)
  store i32 %t132, ptr %l77
  br label %bb31
bb30:
  store i1 false, ptr %l72, !tbaa !21
  br label %bb32
bb31:
  %t133 = load i32, ptr %l77, !range !{i32 0, i32 33}
  %t135 = trunc i64 25 to i32
  %t136 = icmp eq i32 %t133, %t135
  %t138 = xor i1 %t136, true
  store i1 %t138, ptr %l72, !tbaa !21
  br label %bb32
bb32:
  %t140 = load i1, ptr %l72, !tbaa !21
  br i1 %t140, label %bb33, label %bb34
bb33:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/check:Checker", ptr %t141, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !29
  %t145 = load i32, ptr %l8, !tbaa !23
  %t146 = load i32, ptr %l9, !tbaa !23
  %t150 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBuilderOf(ptr %v0, ptr %t144, i32 %t145, i32 %t146, i1 false)
  store i64 %t150, ptr %l86
  br label %bb35
bb34:
  store i1 false, ptr %l81, !tbaa !21
  br label %bb36
bb35:
  %t151 = load i64, ptr %l86, !tbaa !24
  %t152 = icmp sge i64 %t151, 0
  store i1 %t152, ptr %l81, !tbaa !21
  br label %bb36
bb36:
  %t154 = load i1, ptr %l81, !tbaa !21
  br i1 %t154, label %bb37, label %bb38
bb37:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d3, i32 0, i32 1) }, ptr %l88, !tbaa !27
  %t155 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t156 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t156, ptr %l90, !tbaa !27
  store { i64, ptr } %t155, ptr %l10, !tbaa !27
  %t158 = load i1, ptr @olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2ememberRules_2elocal_2e10
  br i1 %t158, label %bb39, label %bb40
bb38:
  br label %bb41
bb39:
  %t160 = load { i64, ptr }, ptr %l90
  %t161 = extractvalue { i64, ptr } %t160, 1
  call void @__olang_region_release(ptr %t161)
  store { i64, ptr } zeroinitializer, ptr %l90
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t162 = getelementptr %"compiler/source:Span", ptr %l6, i32 0, i32 0
  %t163 = load i32, ptr %t162, !tbaa !23
  store i32 %t163, ptr %l92, !tbaa !23
  %t164 = getelementptr %"compiler/source:Span", ptr %l6, i32 0, i32 1
  %t165 = load i32, ptr %t164, !tbaa !23
  %t167 = add i32 %t165, 1
  store i32 %t167, ptr %l94, !tbaa !23
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t169 = load i32, ptr %l9, !tbaa !23
  %t172 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s0, ptr %t168, i32 %t169)
  store { i64, ptr } %t172, ptr %l97
  br label %bb42
bb42:
  %t173 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t174 = extractvalue { i64, ptr } %t173, 0
  %t176 = trunc i64 %t174 to i32
  %t177 = load i32, ptr %l94, !tbaa !23
  %t179 = add i32 %t177, %t176
  %t180 = load i32, ptr %l92, !tbaa !23
  %t182 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t180, i32 %t179)
  store %"compiler/source:Span" %t182, ptr %l101
  br label %bb43
bb43:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = load i32, ptr %l9, !tbaa !23
  %t187 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s0, ptr %t183, i32 %t184)
  store { i64, ptr } %t187, ptr %l104
  br label %bb44
bb44:
  %t188 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t188, 0
  %t190 = load %"compiler/source:Span", ptr %l101
  %t192 = call %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %t190, i64 %t189)
  store %"compiler/source:Span" %t192, ptr %l106
  br label %bb45
bb45:
  %t193 = load %"compiler/source:Span", ptr %l106
  store %"compiler/source:Span" %t193, ptr %l11
  %t194 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t196 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t194, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store i1 %t196, ptr %l108
  br label %bb46
bb46:
  %t197 = load i1, ptr %l108, !tbaa !21
  %t198 = xor i1 %t197, true
  br i1 %t198, label %bb47, label %bb48
bb47:
  store %olang.scope zeroinitializer, ptr %s7
  %t200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t200, ptr %l110, !tbaa !29
  %t201 = load %"compiler/source:Span", ptr %l11
  store %"compiler/source:Span" %t201, ptr %l111
  %t202 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t202, ptr %l112, !tbaa !27
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load i32, ptr %l9, !tbaa !23
  %t207 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s7, ptr %t203, i32 %t204)
  store { i64, ptr } %t207, ptr %l115
  br label %bb49
bb48:
  br label %bb53
bb49:
  %t208 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t209 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t210 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t213 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMemberNameTaken(ptr %v0, ptr %s7, ptr %s0, ptr %v0, { i64, ptr } %t210, { i64, ptr } %t208, { i64, ptr } %t209)
  store %"compiler/diagmsg:Msg" %t213, ptr %l118
  br label %bb50
bb50:
  %t214 = load ptr, ptr %l110, !tbaa !29
  %t215 = load %"compiler/source:Span", ptr %l111
  %t216 = load %"compiler/diagmsg:Msg", ptr %l118
  %t217 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t214, %"compiler/source:Span" %t215, %"compiler/diagmsg:Msg" %t216)
  store i64 %t217, ptr %l119
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s7)
  %t218 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t218)
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb53:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t222 = getelementptr %"compiler/check:Checker", ptr %t220, i32 0, i32 1
  %t223 = load ptr, ptr %t222, !tbaa !29
  %t224 = load i64, ptr %l4, !tbaa !24
  %t227 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberBefore(ptr %v0, ptr %t223, i64 %t224)
  store i64 %t227, ptr %l124
  br label %bb54
bb54:
  %t228 = load i64, ptr %l124, !tbaa !24
  %t229 = icmp sge i64 %t228, 0
  br i1 %t229, label %bb55, label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s9
  %t231 = load ptr, ptr %l0, !tbaa !29
  store ptr %t231, ptr %l126, !tbaa !29
  %t232 = load %"compiler/source:Span", ptr %l11
  store %"compiler/source:Span" %t232, ptr %l127
  %t233 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t233, ptr %l128, !tbaa !27
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load i32, ptr %l9, !tbaa !23
  %t238 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s9, ptr %t234, i32 %t235)
  store { i64, ptr } %t238, ptr %l131
  br label %bb57
bb56:
  br label %bb60
bb57:
  %t239 = load { i64, ptr }, ptr %l131, !tbaa !27
  %t240 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t242 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMemberTwice(ptr %v0, ptr %s9, ptr %v0, { i64, ptr } %t240, { i64, ptr } %t239)
  store %"compiler/diagmsg:Msg" %t242, ptr %l133
  br label %bb58
bb58:
  %t243 = load ptr, ptr %l126, !tbaa !29
  %t244 = load %"compiler/source:Span", ptr %l127
  %t245 = load %"compiler/diagmsg:Msg", ptr %l133
  %t246 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t243, %"compiler/source:Span" %t244, %"compiler/diagmsg:Msg" %t245)
  store i64 %t246, ptr %l134
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s9)
  br label %bb60
bb60:
  %t247 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t247)
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownerWritten(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l16 = alloca i32
  %l21 = alloca ptr
  %l23 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca ptr
  %l32 = alloca i1
  %l43 = alloca ptr
  %l44 = alloca i1
  %l56 = alloca { i64, ptr }
  %l57 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l58 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l73 = alloca i64
  %l78 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l85 = alloca ptr
  %l89 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l101 = alloca ptr
  %l102 = alloca ptr
  %l105 = alloca ptr
  %l109 = alloca i32
  %l110 = alloca i32
  %l111 = alloca i32
  %l112 = alloca i32
  %l117 = alloca i32
  %l120 = alloca i1
  %l125 = alloca i32
  %l130 = alloca i32
  %l132 = alloca i1
  %l135 = alloca { i64, ptr }
  %l138 = alloca i1
  %l140 = alloca { i64, ptr }
  %l143 = alloca { i64, ptr }
  %l146 = alloca ptr
  %l147 = alloca %"compiler/source:Span"
  %l148 = alloca { i64, ptr }
  %l149 = alloca { i64, ptr }
  %l150 = alloca { i64, ptr }
  %l154 = alloca { i64, ptr }
  %l155 = alloca %"compiler/diagmsg:Msg"
  %l156 = alloca i64
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l21
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l21, !tbaa !29
  store ptr %t9, ptr %l4, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  store ptr %t13, ptr %l23, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/generic:Program", ptr %t17, i32 0, i32 2
  %t20 = load i32, ptr %l2, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t19, i32 %t20)
  store i32 %t23, ptr %l28
  br label %bb2
bb2:
  %t24 = load ptr, ptr %l23, !tbaa !29
  %t25 = load i32, ptr %l28, !tbaa !23
  %t26 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v0, ptr %t24, i32 %t25)
  store ptr %t26, ptr %l29
  br label %bb3
bb3:
  %t27 = load ptr, ptr %l29, !tbaa !29
  store ptr %t27, ptr %l5, !tbaa !29
  %t28 = load ptr, ptr %l5, !tbaa !29
  %t30 = icmp eq ptr %t28, null
  br i1 %t30, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb6
bb5:
  %t32 = load ptr, ptr %l5, !tbaa !29
  %t34 = getelementptr %"compiler/ast:TypeDecl", ptr %t32, i32 0, i32 1
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t39 = icmp eq i64 %t37, 0
  store i1 %t39, ptr %l32, !tbaa !21
  br label %bb6
bb6:
  %t41 = load i1, ptr %l32, !tbaa !21
  br i1 %t41, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t43 = load ptr, ptr %l4, !tbaa !29
  %t45 = getelementptr %"compiler/ast:Func", ptr %t43, i32 0, i32 8
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = icmp eq ptr %t46, null
  br i1 %t48, label %bb10, label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_cc787edf2deeff46_6db42fab5d8ba9ba)
  unreachable
bb11:
  br label %bb12
bb12:
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t52 = getelementptr %"compiler/ast:Func", ptr %t50, i32 0, i32 8
  %t53 = load ptr, ptr %t52, !tbaa !29
  store ptr %t53, ptr %l6, !tbaa !29
  %t55 = load ptr, ptr %l6, !tbaa !29
  store ptr %t55, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t56 = load ptr, ptr %l43, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb13, label %bb14
bb13:
  %t59 = load ptr, ptr %l43, !tbaa !29
  %t60 = load i64, ptr %t59, !range !{i64 0, i64 8}
  %t62 = icmp eq i64 %t60, 0
  store i1 %t62, ptr %l44, !tbaa !21
  br label %bb14
bb14:
  %t63 = load i1, ptr %l44, !tbaa !21
  br i1 %t63, label %bb15, label %bb16
bb15:
  %t64 = load ptr, ptr %l6, !tbaa !29
  %t66 = getelementptr { i64, [5 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t66, i32 0, i32 2
  %t68 = load { i64, ptr }, ptr %t67
  store { i64, ptr } %t68, ptr %l7, !tbaa !27
  br label %bb17
bb16:
  br label %bb20
bb17:
  %t70 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t70, 0
  %t74 = icmp sgt i64 %t72, 0
  br i1 %t74, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_ca5f636100c98fd4_9c6d5a533441f8c8)
  unreachable
bb25:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load ptr, ptr %l5, !tbaa !29
  %t80 = getelementptr %"compiler/ast:TypeDecl", ptr %t78, i32 0, i32 0
  %t81 = load i32, ptr %t80, !tbaa !23
  %t84 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t77, i32 %t81)
  store { i64, ptr } %t84, ptr %l56
  br label %bb26
bb26:
  %t85 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t85, ptr %l8, !tbaa !27
  %t86 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t86, ptr %l57
  br label %bb27
bb27:
  %t87 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l57
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t87, ptr %l9
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d5, i32 0, i32 1) }, ptr %l58, !tbaa !27
  %t88 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t88, ptr %l10, !tbaa !27
  %t90 = load ptr, ptr %l5, !tbaa !29
  %t92 = getelementptr %"compiler/ast:TypeDecl", ptr %t90, i32 0, i32 1
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !27
  store { i64, ptr } %t93, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t95 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t95, 0
  store i64 %t97, ptr %l13, !tbaa !24
  br label %bb28
bb28:
  %t99 = load i64, ptr %l12, !tbaa !24
  %t100 = load i64, ptr %l13, !tbaa !24
  %t103 = icmp slt i64 %t99, %t100
  %t105 = xor i1 %t103, true
  br i1 %t105, label %bb29, label %bb30
bb29:
  br label %bb47
bb30:
  br label %bb31
bb31:
  %t107 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t107, ptr %l68, !tbaa !27
  %t108 = load i64, ptr %l12, !tbaa !24
  %t110 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr ptr, ptr %t111, i64 %t108
  %t113 = load ptr, ptr %t112, !tbaa !39
  store ptr %t113, ptr %l14, !tbaa !29
  %t115 = load ptr, ptr %l14, !tbaa !29
  %t117 = getelementptr %"compiler/ast:TypeParam", ptr %t115, i32 0, i32 4
  %t118 = load i1, ptr %t117, !tbaa !21
  br i1 %t118, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s6
  %t120 = call ptr @__olang_scope_hold(ptr %s0)
  %t121 = ptrtoint ptr %t120 to i64
  store i64 %t121, ptr %l73, !tbaa !24
  %t122 = load i1, ptr @olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2eownerWritten_2elocal_2e10
  br i1 %t122, label %bb34, label %bb35
bb33:
  store %olang.scope zeroinitializer, ptr %s8
  store ptr %l9, ptr %l85, !tbaa !29
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load ptr, ptr %l14, !tbaa !29
  %t127 = getelementptr %"compiler/ast:TypeParam", ptr %t125, i32 0, i32 1
  %t128 = load i32, ptr %t127, !tbaa !23
  %t131 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s8, ptr %t124, i32 %t128)
  store { i64, ptr } %t131, ptr %l89
  br label %bb43
bb34:
  %t132 = call ptr @__olang_region_make(ptr %s0)
  %t133 = ptrtoint ptr %t132 to i64
  store i64 %t133, ptr %l73, !tbaa !24
  br label %bb35
bb35:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load ptr, ptr %l14, !tbaa !29
  %t137 = getelementptr %"compiler/ast:TypeParam", ptr %t135, i32 0, i32 1
  %t138 = load i32, ptr %t137, !tbaa !23
  %t141 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s6, ptr %t134, i32 %t138)
  store { i64, ptr } %t141, ptr %l78
  br label %bb36
bb36:
  %t142 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t143 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t144 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t144, 1
  %t146 = extractvalue { i64, ptr } %t144, 0
  %t147 = add i64 %t143, %t146
  %t148 = load i64, ptr %l73
  %t149 = inttoptr i64 %t148 to ptr
  %t150 = call ptr @__olang_held_alloc(ptr %t149, i64 %t147)
  call void @olang_textcopy(ptr %t150, ptr %t142, i64 %t143)
  %t151 = getelementptr i8, ptr %t150, i64 %t143
  call void @olang_textcopy(ptr %t151, ptr %t145, i64 %t146)
  %t152 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr %t150, 1
  store { i64, ptr } %t153, ptr %l79, !tbaa !27
  %t154 = load i1, ptr @olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2eownerWritten_2elocal_2e10
  br i1 %t154, label %bb37, label %bb38
bb37:
  %t156 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t157 = extractvalue { i64, ptr } %t156, 0
  %t159 = icmp eq i64 %t157, 0
  br i1 %t159, label %bb39, label %bb40
bb38:
  %t161 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t161, ptr %l83, !tbaa !27
  %t162 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t162, ptr %l10, !tbaa !27
  %t163 = load i1, ptr @olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2eownerWritten_2elocal_2e10
  br i1 %t163, label %bb41, label %bb42
bb39:
  store { i64, ptr } zeroinitializer, ptr %l79, !tbaa !27
  br label %bb40
bb40:
  %t165 = load i64, ptr %l73
  %t166 = inttoptr i64 %t165 to ptr
  %t167 = load { i64, ptr }, ptr %l79
  %t168 = extractvalue { i64, ptr } %t167, 1
  %t169 = call ptr @__olang_region_or(ptr %t168, ptr null)
  %t170 = icmp ne ptr %t169, null
  %t171 = select i1 %t170, ptr %t169, ptr null
  call void @__olang_region_settle_in(ptr %t166, ptr %t171)
  br label %bb38
bb41:
  %t172 = load { i64, ptr }, ptr %l83
  %t173 = extractvalue { i64, ptr } %t172, 1
  call void @__olang_region_release(ptr %t173)
  store { i64, ptr } zeroinitializer, ptr %l83
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s6)
  br label %bb45
bb43:
  %t174 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t175 = extractvalue { i64, ptr } %t174, 1
  %t176 = extractvalue { i64, ptr } %t174, 0
  %t177 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t176)
  call void @olang_textcopy(ptr %t177, ptr %t175, i64 %t176)
  %t178 = insertvalue { i64, ptr } undef, i64 %t176, 0
  %t179 = insertvalue { i64, ptr } %t178, ptr %t177, 1
  %t180 = load ptr, ptr %l85, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_3e_2ePus_H7d1143c374f11cf9cab67f1e79e7bcb4(ptr %s0, ptr %t180, { i64, ptr } %t179)
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s8)
  br label %bb45
bb45:
  br label %bb46
bb46:
  %t182 = load i64, ptr %l12, !tbaa !24
  %t185 = add i64 %t182, 1
  store i64 %t185, ptr %l12, !tbaa !24
  br label %bb28
bb47:
  %t187 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t187, ptr %l94, !tbaa !27
  %t189 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_3e_2eJoin(ptr %s0, ptr %s0, ptr %s0, ptr %l9, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store { i64, ptr } %t189, ptr %l96
  br label %bb48
bb48:
  %t190 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t191 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t191, 1
  %t193 = extractvalue { i64, ptr } %t191, 0
  %t194 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t195 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t196 = add i64 %t193, %t195
  %t197 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t197, 1
  %t199 = extractvalue { i64, ptr } %t197, 0
  %t200 = add i64 %t196, %t199
  %t202 = extractvalue { i64, ptr } %t190, 1
  %t203 = extractvalue { i64, ptr } %t190, 0
  %t204 = add i64 %t200, %t203
  %t205 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t206 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t207 = add i64 %t204, %t206
  %t208 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t207)
  call void @olang_textcopy(ptr %t208, ptr %t192, i64 %t193)
  %t209 = getelementptr i8, ptr %t208, i64 %t193
  call void @olang_textcopy(ptr %t209, ptr %t194, i64 %t195)
  %t210 = getelementptr i8, ptr %t209, i64 %t195
  call void @olang_textcopy(ptr %t210, ptr %t198, i64 %t199)
  %t211 = getelementptr i8, ptr %t210, i64 %t199
  call void @olang_textcopy(ptr %t211, ptr %t202, i64 %t203)
  %t212 = getelementptr i8, ptr %t211, i64 %t203
  call void @olang_textcopy(ptr %t212, ptr %t205, i64 %t206)
  %t213 = insertvalue { i64, ptr } undef, i64 %t207, 0
  %t214 = insertvalue { i64, ptr } %t213, ptr %t208, 1
  store { i64, ptr } %t214, ptr %l15, !tbaa !27
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/check:Checker", ptr %t216, i32 0, i32 1
  %t219 = load ptr, ptr %t218, !tbaa !29
  %t221 = getelementptr %"compiler/generic:Program", ptr %t219, i32 0, i32 2
  store ptr %t221, ptr %l101, !tbaa !29
  %t222 = load ptr, ptr %l0, !tbaa !29
  store ptr %t222, ptr %l102, !tbaa !29
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t225 = getelementptr %"compiler/check:Checker", ptr %t223, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !29
  %t228 = getelementptr %"compiler/generic:Program", ptr %t226, i32 0, i32 2
  store ptr %t228, ptr %l105, !tbaa !29
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"compiler/check:Checker", ptr %t229, i32 0, i32 1
  %t232 = load ptr, ptr %t231, !tbaa !29
  %t233 = load i64, ptr %l1, !tbaa !24
  %t236 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t232, i64 %t233)
  store i32 %t236, ptr %l109
  br label %bb49
bb49:
  %t237 = load ptr, ptr %l105, !tbaa !29
  %t238 = load i32, ptr %l109, !tbaa !23
  %t239 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t237, i32 %t238)
  store i32 %t239, ptr %l110
  br label %bb50
bb50:
  %t240 = load ptr, ptr %l102, !tbaa !29
  %t241 = load i32, ptr %l110, !tbaa !23
  %t242 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t240, i32 %t241)
  store i32 %t242, ptr %l111
  br label %bb51
bb51:
  %t243 = load ptr, ptr %l101, !tbaa !29
  %t244 = load i32, ptr %l111, !tbaa !23
  %t245 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t243, i32 %t244)
  store i32 %t245, ptr %l112
  br label %bb52
bb52:
  %t246 = load i32, ptr %l112, !tbaa !23
  store i32 %t246, ptr %l16, !tbaa !23
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t249 = getelementptr %"compiler/check:Checker", ptr %t247, i32 0, i32 1
  %t250 = load ptr, ptr %t249, !tbaa !29
  %t252 = getelementptr %"compiler/generic:Program", ptr %t250, i32 0, i32 2
  %t253 = load i32, ptr %l16, !tbaa !23
  %t256 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t252, i32 %t253)
  store i32 %t256, ptr %l117
  br label %bb53
bb53:
  %t257 = load i32, ptr %l117, !range !{i32 0, i32 33}
  %t259 = trunc i64 18 to i32
  %t260 = icmp eq i32 %t257, %t259
  br i1 %t260, label %bb54, label %bb55
bb54:
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t264 = getelementptr %"compiler/check:Checker", ptr %t262, i32 0, i32 1
  %t265 = load ptr, ptr %t264, !tbaa !29
  %t267 = getelementptr %"compiler/generic:Program", ptr %t265, i32 0, i32 2
  %t268 = load i32, ptr %l16, !tbaa !23
  %t271 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t267, i32 %t268)
  store i32 %t271, ptr %l125
  br label %bb56
bb55:
  store i1 false, ptr %l120, !tbaa !21
  br label %bb58
bb56:
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t274 = getelementptr %"compiler/check:Checker", ptr %t272, i32 0, i32 1
  %t275 = load ptr, ptr %t274, !tbaa !29
  %t277 = getelementptr %"compiler/generic:Program", ptr %t275, i32 0, i32 2
  %t278 = load i32, ptr %l2, !tbaa !23
  %t281 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t277, i32 %t278)
  store i32 %t281, ptr %l130
  br label %bb57
bb57:
  %t282 = load i32, ptr %l125, !tbaa !23
  %t283 = load i32, ptr %l130, !tbaa !23
  %t284 = icmp eq i32 %t282, %t283
  store i1 %t284, ptr %l120, !tbaa !21
  br label %bb58
bb58:
  %t286 = load i1, ptr %l120, !tbaa !21
  br i1 %t286, label %bb59, label %bb60
bb59:
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t288 = load i32, ptr %l16, !tbaa !23
  %t291 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t287, i32 %t288)
  store { i64, ptr } %t291, ptr %l135
  br label %bb61
bb60:
  store i1 false, ptr %l132, !tbaa !21
  br label %bb63
bb61:
  %t292 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t293 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t296 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t292, { i64, ptr } %t293)
  store i1 %t296, ptr %l138
  br label %bb62
bb62:
  %t297 = load i1, ptr %l138, !tbaa !21
  %t298 = xor i1 %t297, true
  store i1 %t298, ptr %l132, !tbaa !21
  br label %bb63
bb63:
  %t300 = load i1, ptr %l132, !tbaa !21
  br i1 %t300, label %bb64, label %bb65
bb64:
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t302 = load i32, ptr %l16, !tbaa !23
  %t305 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t301, i32 %t302)
  store { i64, ptr } %t305, ptr %l143
  br label %bb66
bb65:
  %t306 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t308 = extractvalue { i64, ptr } %t306, 1
  %t309 = extractvalue { i64, ptr } %t306, 0
  %t310 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t311 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t312 = add i64 %t309, %t311
  %t313 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t312)
  call void @olang_textcopy(ptr %t313, ptr %t308, i64 %t309)
  %t314 = getelementptr i8, ptr %t313, i64 %t309
  call void @olang_textcopy(ptr %t314, ptr %t310, i64 %t311)
  %t315 = insertvalue { i64, ptr } undef, i64 %t312, 0
  %t316 = insertvalue { i64, ptr } %t315, ptr %t313, 1
  store { i64, ptr } %t316, ptr %l140, !tbaa !27
  br label %bb67
bb66:
  %t318 = load { i64, ptr }, ptr %l143, !tbaa !27
  store { i64, ptr } %t318, ptr %l140, !tbaa !27
  br label %bb67
bb67:
  %t319 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t320 = load ptr, ptr %l0, !tbaa !29
  store ptr %t320, ptr %l146, !tbaa !29
  store %"compiler/source:Span" %a3, ptr %l147
  %t322 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t322, ptr %l148, !tbaa !27
  %t323 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t323, ptr %l149, !tbaa !27
  store { i64, ptr } %t319, ptr %l150, !tbaa !27
  %t325 = load ptr, ptr %l0, !tbaa !29
  %t326 = load ptr, ptr %l4, !tbaa !29
  %t328 = getelementptr %"compiler/ast:Func", ptr %t326, i32 0, i32 9
  %t329 = load i32, ptr %t328, !tbaa !23
  %t332 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t325, i32 %t329)
  store { i64, ptr } %t332, ptr %l154
  br label %bb68
bb68:
  %t333 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t334 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t335 = load { i64, ptr }, ptr %l150, !tbaa !27
  %t336 = load { i64, ptr }, ptr %l154, !tbaa !27
  %t337 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuilderOwnerBare(ptr %v0, ptr %s0, ptr %s0, ptr %v0, ptr %v0, { i64, ptr } %t333, { i64, ptr } %t334, { i64, ptr } %t335, { i64, ptr } %t336)
  store %"compiler/diagmsg:Msg" %t337, ptr %l155
  br label %bb69
bb69:
  %t338 = load ptr, ptr %l146, !tbaa !29
  %t339 = load %"compiler/source:Span", ptr %l147
  %t340 = load %"compiler/diagmsg:Msg", ptr %l155
  %t341 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t338, %"compiler/source:Span" %t339, %"compiler/diagmsg:Msg" %t340)
  store i64 %t341, ptr %l156
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epatBool(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l29 = alloca { i64, ptr }
  %l30 = alloca i1
  %l31 = alloca i64
  %s3 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 9}
  %t8 = icmp eq i64 %t6, 4
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb9
bb4:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t17 = load ptr, ptr %l11, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l11, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 9}
  %t23 = icmp eq i64 %t21, 1
  store i1 %t23, ptr %l12, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", ptr }, ptr %t27, i32 0, i32 1
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l2, !tbaa !29
  br label %bb9
bb8:
  br label %bb29
bb9:
  %t31 = load ptr, ptr %l2, !tbaa !29
  store ptr %t31, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t32 = load ptr, ptr %l17, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb10, label %bb11
bb10:
  %t35 = load ptr, ptr %l17, !tbaa !29
  %t36 = load i64, ptr %t35, !range !{i64 0, i64 28}
  %t38 = icmp eq i64 %t36, 1
  store i1 %t38, ptr %l18, !tbaa !21
  br label %bb11
bb11:
  %t39 = load i1, ptr %l18, !tbaa !21
  br i1 %t39, label %bb12, label %bb13
bb12:
  %t40 = load ptr, ptr %l2, !tbaa !29
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32 }, ptr %t42, i32 0, i32 0
  %t44 = load %"compiler/source:Span", ptr %t43
  store %"compiler/source:Span" %t44, ptr %l3
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t48 = getelementptr { i64, [4 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", i32 }, ptr %t48, i32 0, i32 1
  %t50 = load i32, ptr %t49, !range !{i32 0, i32 116}
  store i32 %t50, ptr %l4
  br label %bb14
bb13:
  br label %bb23
bb14:
  %t52 = load i32, ptr %l4, !range !{i32 0, i32 116}
  %t54 = trunc i64 6 to i32
  %t55 = icmp eq i32 %t52, %t54
  br i1 %t55, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t58 = load %"compiler/source:Span", ptr %l3
  %t61 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %a0, %"compiler/source:Span" %t58)
  store { i64, ptr } %t61, ptr %l29
  br label %bb17
bb16:
  br label %bb22
bb17:
  %t62 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t63 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s3, { i64, ptr } %t62, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store i1 %t63, ptr %l30
  br label %bb18
bb18:
  %t64 = load i1, ptr %l30, !tbaa !21
  br i1 %t64, label %bb19, label %bb20
bb19:
  store i64 1, ptr %l31, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s3)
  %t65 = load i64, ptr %l31, !tbaa !24
  store i64 %t65, ptr %rv
  br label %ret
bb22:
  br label %bb28
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_a6377e7673ccb83e_f00ca4f503dea522)
  unreachable
bb28:
  br label %bb34
bb29:
  br i1 true, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_4543a2f38c43ab3f_a376b2729e3ac623)
  unreachable
bb34:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflDefault(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/generic:Desc" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/generic:Desc"
  %l4 = alloca { i32, { i64, ptr } }
  %l5 = alloca i32
  %l6 = alloca %"compiler/generic:Desc"
  %l8 = alloca i32
  %l12 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca %"compiler/source:Span"
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l25 = alloca %"compiler/diagmsg:Msg"
  %l26 = alloca i64
  %l29 = alloca ptr
  %l33 = alloca { i32, { i64, ptr } }
  %l38 = alloca %"compiler/generic:Desc"
  %l45 = alloca ptr
  %l50 = alloca ptr
  %l51 = alloca %"compiler/source:Span"
  %l52 = alloca i64
  %l53 = alloca i64
  %l55 = alloca i64
  %l58 = alloca ptr
  %l67 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/generic:Desc" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load %"compiler/generic:Desc", ptr %l2
  %t5 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamDefault(ptr %v0, ptr %s0, ptr %t1, %"compiler/generic:Desc" %t2)
  store ptr %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l12, !tbaa !29
  %t9 = icmp eq ptr %t6, null
  br i1 %t9, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l15, !tbaa !29
  %t12 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t12, ptr %l16
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load %"compiler/generic:Desc", ptr %l2
  %t17 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescName(ptr %v0, ptr %s1, ptr %t13, %"compiler/generic:Desc" %t14)
  store { i64, ptr } %t17, ptr %l19
  br label %bb4
bb3:
  br label %bb9
bb4:
  %t18 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t18, ptr %l20, !tbaa !27
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/generic:Desc", ptr %l2, i32 0, i32 1
  %t21 = load i32, ptr %t20, !tbaa !23
  %t24 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t19, i32 %t21)
  store { i64, ptr } %t24, ptr %l23
  br label %bb5
bb5:
  %t25 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t28 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflNoDefault(ptr %s1, ptr %s1, ptr %v0, { i64, ptr } %t26, { i64, ptr } %t25)
  store %"compiler/diagmsg:Msg" %t28, ptr %l25
  br label %bb6
bb6:
  %t29 = load ptr, ptr %l15, !tbaa !29
  %t30 = load %"compiler/source:Span", ptr %l16
  %t31 = load %"compiler/diagmsg:Msg", ptr %l25
  %t32 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t29, %"compiler/source:Span" %t30, %"compiler/diagmsg:Msg" %t31)
  store i64 %t32, ptr %l26
  br label %bb7
bb7:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load %"compiler/source:Span", ptr %l1
  %t37 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %t33, %"compiler/source:Span" %t34)
  store ptr %t37, ptr %l29
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t38 = load ptr, ptr %l29, !tbaa !29
  store ptr %t38, ptr %rv
  br label %ret
bb9:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t43 = load %"compiler/generic:Desc", ptr %l2
  %t46 = call { i32, { i64, ptr } } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescType(ptr %v0, ptr %s0, ptr %t42, %"compiler/generic:Desc" %t43)
  store { i32, { i64, ptr } } %t46, ptr %l33
  br label %bb10
bb10:
  %t47 = load { i32, { i64, ptr } }, ptr %l33
  store { i32, { i64, ptr } } %t47, ptr %l4
  %t48 = getelementptr { i32, { i64, ptr } }, ptr %l4, i32 0, i32 0
  %t49 = load i32, ptr %t48, !tbaa !23
  store i32 %t49, ptr %l5, !tbaa !23
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/check:Checker", ptr %t51, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Desc", ptr %l2, i32 0, i32 1
  %t56 = load i32, ptr %t55, !tbaa !23
  %t59 = call %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %t54, i32 %t56)
  store %"compiler/generic:Desc" %t59, ptr %l38
  br label %bb11
bb11:
  %t60 = load %"compiler/generic:Desc", ptr %l38
  store %"compiler/generic:Desc" %t60, ptr %l6
  %t61 = getelementptr %"compiler/generic:Desc", ptr %l6, i32 0, i32 0
  %t62 = load i64, ptr %t61, !tbaa !24
  %t63 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescFunc, !tbaa !24
  %t66 = icmp eq i64 %t62, %t63
  br i1 %t66, label %bb12, label %bb13
bb12:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/check:Checker", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t72 = getelementptr %"compiler/generic:Desc", ptr %l6, i32 0, i32 2
  %t73 = load i64, ptr %t72, !tbaa !24
  %t76 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t71, i64 %t73)
  store ptr %t76, ptr %l45
  br label %bb14
bb13:
  br label %bb19
bb14:
  %t77 = load ptr, ptr %l45, !tbaa !29
  %t79 = getelementptr %"compiler/ast:Func", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = icmp eq ptr %t80, null
  %t84 = xor i1 %t82, true
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l50, !tbaa !29
  %t87 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t87, ptr %l51
  %t88 = getelementptr %"compiler/generic:Desc", ptr %l6, i32 0, i32 2
  %t89 = load i64, ptr %t88, !tbaa !24
  store i64 %t89, ptr %l52, !tbaa !24
  %t90 = getelementptr %"compiler/generic:Desc", ptr %l2, i32 0, i32 3
  %t91 = load i64, ptr %t90, !tbaa !24
  store i64 %t91, ptr %l53, !tbaa !24
  br i1 %t84, label %bb15, label %bb16
bb15:
  store i64 1, ptr %l55, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l55, !tbaa !24
  br label %bb17
bb17:
  %t94 = load i64, ptr %l53, !tbaa !24
  %t95 = load i64, ptr %l55, !tbaa !24
  %t96 = add i64 %t94, %t95
  %t97 = load i32, ptr %l5, !tbaa !23
  %t98 = load ptr, ptr %l50, !tbaa !29
  %t99 = load %"compiler/source:Span", ptr %l51
  %t100 = load i64, ptr %l52, !tbaa !24
  %t103 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultArg(ptr %v0, ptr %v1, ptr %t98, %"compiler/source:Span" %t99, i64 %t100, i64 %t96, i1 false, i32 %t97, i32 0)
  store ptr %t103, ptr %l58
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s0)
  %t104 = load ptr, ptr %l58, !tbaa !29
  store ptr %t104, ptr %rv
  br label %ret
bb19:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/check:Checker", ptr %t105, i32 0, i32 29
  %t108 = load i32, ptr %t107, !tbaa !23
  store i32 %t108, ptr %l8, !tbaa !23
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/generic:Desc", ptr %l2, i32 0, i32 1
  %t112 = load i32, ptr %t111, !tbaa !23
  %t115 = getelementptr %"compiler/check:Checker", ptr %t110, i32 0, i32 29
  store i32 %t112, ptr %t115, !tbaa !23
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load %"compiler/source:Span", ptr %l1
  %t118 = getelementptr %"compiler/generic:Desc", ptr %l2, i32 0, i32 3
  %t119 = load i64, ptr %t118, !tbaa !24
  %t120 = load i32, ptr %l5, !tbaa !23
  %t125 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorDefault(ptr %v0, ptr %v1, ptr %t116, %"compiler/source:Span" %t117, i64 %t119, i32 %t120)
  store ptr %t125, ptr %l67
  br label %bb20
bb20:
  %t126 = load ptr, ptr %l67, !tbaa !29
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load i32, ptr %l8, !tbaa !23
  %t131 = getelementptr %"compiler/check:Checker", ptr %t127, i32 0, i32 29
  store i32 %t128, ptr %t131, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store ptr %t126, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflMember(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"compiler/check:reflList"
  %l7 = alloca i32
  %lp8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca %"compiler/generic:Desc"
  %lp11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l18 = alloca { i64, ptr }
  %l25 = alloca %"compiler/check:reflList"
  %l27 = alloca ptr
  %l28 = alloca %"compiler/source:Span"
  %l31 = alloca { i64, ptr }
  %l34 = alloca %"compiler/diagmsg:Msg"
  %l35 = alloca i64
  %l38 = alloca ptr
  %l42 = alloca i32
  %l50 = alloca ptr
  %l54 = alloca i1
  %l55 = alloca i1
  %l58 = alloca i1
  %l60 = alloca i1
  %l64 = alloca i1
  %l67 = alloca i1
  %l68 = alloca i1
  %l73 = alloca i64
  %l75 = alloca ptr
  %l76 = alloca %"compiler/source:Span"
  %l79 = alloca { i64, ptr }
  %l82 = alloca %"compiler/diagmsg:Msg"
  %l83 = alloca i64
  %l86 = alloca ptr
  %l89 = alloca i1
  %l90 = alloca i1
  %l92 = alloca i1
  %l93 = alloca i1
  %l95 = alloca i1
  %l96 = alloca i1
  %l98 = alloca i1
  %l99 = alloca i1
  %l101 = alloca i1
  %l102 = alloca i1
  %l104 = alloca i1
  %l108 = alloca %"compiler/check:reflVal"
  %l113 = alloca ptr
  %l116 = alloca i1
  %l117 = alloca ptr
  %l118 = alloca %"compiler/source:Span"
  %l121 = alloca { i64, ptr }
  %l123 = alloca %"compiler/diagmsg:Msg"
  %l124 = alloca i64
  %l126 = alloca i1
  %l127 = alloca ptr
  %l128 = alloca %"compiler/source:Span"
  %l131 = alloca { i64, ptr }
  %l133 = alloca %"compiler/diagmsg:Msg"
  %l134 = alloca i64
  %l136 = alloca i1
  %l137 = alloca i1
  %l139 = alloca i1
  %l140 = alloca ptr
  %l141 = alloca %"compiler/source:Span"
  %l144 = alloca { i64, ptr }
  %l147 = alloca %"compiler/diagmsg:Msg"
  %l148 = alloca i64
  %l151 = alloca ptr
  %l155 = alloca i1
  %l156 = alloca i1
  %l158 = alloca i1
  %l162 = alloca i1
  %l166 = alloca i1
  %l167 = alloca i1
  %l170 = alloca i32
  %l174 = alloca ptr
  %l175 = alloca %"compiler/source:Span"
  %l178 = alloca { i64, ptr }
  %l181 = alloca %"compiler/diagmsg:Msg"
  %l182 = alloca i64
  %l185 = alloca ptr
  %l189 = alloca i32
  %l198 = alloca ptr
  %l203 = alloca %"compiler/generic:Desc"
  %l205 = alloca i1
  %l206 = alloca i1
  %l210 = alloca ptr
  %l211 = alloca %"compiler/source:Span"
  %l214 = alloca { i64, ptr }
  %l217 = alloca %"compiler/diagmsg:Msg"
  %l218 = alloca i64
  %l221 = alloca ptr
  %l224 = alloca i1
  %l225 = alloca i1
  %l232 = alloca ptr
  %l237 = alloca %"compiler/check:reflVal"
  %l242 = alloca ptr
  %l245 = alloca { i64, ptr }
  %l259 = alloca { i64, ptr }
  %l272 = alloca ptr
  %l273 = alloca %"compiler/source:Span"
  %l277 = alloca %"compiler/diagmsg:Msg"
  %l278 = alloca i64
  %l281 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %rv = alloca ptr
  %t11 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l4, !tbaa !23
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t1, i32 %t2)
  store { i64, ptr } %t5, ptr %l18
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t6, ptr %l5, !tbaa !27
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t10 = load i32, ptr %l4, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t11
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t11, i32 0, i32 0
  store i64 12, ptr %t12
  %t14 = insertvalue { %"compiler/source:Span", ptr, i32 } undef, %"compiler/source:Span" %t8, 0
  %t16 = insertvalue { %"compiler/source:Span", ptr, i32 } %t14, ptr %t9, 1
  %t18 = insertvalue { %"compiler/source:Span", ptr, i32 } %t16, i32 %t10, 2
  %t19 = getelementptr { i64, [4 x i64] }, ptr %t11, i32 0, i32 1
  store { %"compiler/source:Span", ptr, i32 } %t18, ptr %t19
  %t20 = load { i64, [4 x i64] }, ptr %t11
  %t22 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t20, ptr %t22
  %t25 = call %"compiler/check:reflList" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistOf(ptr %v0, ptr %v0, ptr %t7, ptr %t22)
  store %"compiler/check:reflList" %t25, ptr %l25
  br label %bb2
bb2:
  %t26 = load %"compiler/check:reflList", ptr %l25
  store %"compiler/check:reflList" %t26, ptr %l6
  %t27 = getelementptr %"compiler/check:reflList", ptr %l6, i32 0, i32 0
  %t28 = load i1, ptr %t27, !tbaa !21
  br i1 %t28, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l27, !tbaa !29
  %t31 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t31, ptr %l28
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load %"compiler/source:Span", ptr %l1
  %t36 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %s1, ptr %t32, %"compiler/source:Span" %t33)
  store { i64, ptr } %t36, ptr %l31
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t37 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 1
  %t39 = extractvalue { i64, ptr } %t37, 0
  %t40 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t39)
  call void @olang_textcopy(ptr %t40, ptr %t38, i64 %t39)
  %t41 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  %t45 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflListValue(ptr %s1, ptr %v0, { i64, ptr } %t42)
  store %"compiler/diagmsg:Msg" %t45, ptr %l34
  br label %bb6
bb6:
  %t46 = load ptr, ptr %l27, !tbaa !29
  %t47 = load %"compiler/source:Span", ptr %l28
  %t48 = load %"compiler/diagmsg:Msg", ptr %l34
  %t49 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t46, %"compiler/source:Span" %t47, %"compiler/diagmsg:Msg" %t48)
  store i64 %t49, ptr %l35
  br label %bb7
bb7:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load %"compiler/source:Span", ptr %l1
  %t54 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t50, %"compiler/source:Span" %t51)
  store ptr %t54, ptr %l38
  br label %bb8
bb8:
  %t55 = load ptr, ptr %l38, !tbaa !29
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t55, ptr %rv
  br label %ret
bb9:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load ptr, ptr %l3, !tbaa !29
  %t61 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflType(ptr %v0, ptr %v1, ptr %t57, ptr %t58)
  store i32 %t61, ptr %l42
  br label %bb10
bb10:
  %t62 = load i32, ptr %l42, !tbaa !23
  store i32 %t62, ptr %l7, !tbaa !23
  %t63 = load i32, ptr %l7, !tbaa !23
  %t65 = icmp sge i32 %t63, 0
  br i1 %t65, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t67 = load i32, ptr %l7, !tbaa !23
  %t68 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t71 = icmp eq i32 %t67, %t68
  br i1 %t71, label %bb13, label %bb14
bb12:
  br label %bb120
bb13:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load %"compiler/source:Span", ptr %l1
  %t77 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t73, %"compiler/source:Span" %t74)
  store ptr %t77, ptr %l50
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t78 = load ptr, ptr %l50, !tbaa !29
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t78, ptr %rv
  br label %ret
bb16:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load i32, ptr %l7, !tbaa !23
  %t84 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t80, i32 %t81)
  store i1 %t84, ptr %l54
  br label %bb17
bb17:
  %t85 = load i1, ptr %l54, !tbaa !21
  br i1 %t85, label %bb18, label %bb19
bb18:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load ptr, ptr %l3, !tbaa !29
  %t90 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eviaTypeVar(ptr %v0, ptr %v1, ptr %t86, ptr %t87)
  store i1 %t90, ptr %l58
  br label %bb20
bb19:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb21
bb20:
  %t91 = load i1, ptr %l58, !tbaa !21
  %t92 = xor i1 %t91, true
  store i1 %t92, ptr %l55, !tbaa !21
  br label %bb21
bb21:
  %t94 = load i1, ptr %l55, !tbaa !21
  br i1 %t94, label %bb22, label %bb23
bb22:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load i32, ptr %l7, !tbaa !23
  %t97 = load i32, ptr %l4, !tbaa !23
  %t101 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasCase(ptr %v0, ptr %t95, i32 %t96, i32 %t97)
  store i1 %t101, ptr %l64
  br label %bb24
bb23:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb25
bb24:
  %t102 = load i1, ptr %l64, !tbaa !21
  store i1 %t102, ptr %l60, !tbaa !21
  br label %bb25
bb25:
  %t103 = load i1, ptr %l60, !tbaa !21
  br i1 %t103, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t105 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t107 = call i1 @compiler_2fgeneric_2eProjectsType(ptr %v0, { i64, ptr } %t105)
  store i1 %t107, ptr %l67
  br label %bb29
bb29:
  %t108 = load i1, ptr %l67, !tbaa !21
  br i1 %t108, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l68, !tbaa !21
  br label %bb33
bb31:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/check:Checker", ptr %t109, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t113 = load i32, ptr %l7, !tbaa !23
  %t114 = load i32, ptr %l4, !tbaa !23
  %t118 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberOf(ptr %v0, ptr %t112, i32 %t113, i32 %t114)
  store i64 %t118, ptr %l73
  br label %bb32
bb32:
  %t119 = load i64, ptr %l73, !tbaa !24
  %t120 = icmp sge i64 %t119, 0
  store i1 %t120, ptr %l68, !tbaa !21
  br label %bb33
bb33:
  %t122 = load i1, ptr %l68, !tbaa !21
  br i1 %t122, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s6
  %t123 = load ptr, ptr %l0, !tbaa !29
  store ptr %t123, ptr %l75, !tbaa !29
  %t124 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t124, ptr %l76
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load %"compiler/source:Span", ptr %l1
  %t129 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %s6, ptr %t125, %"compiler/source:Span" %t126)
  store { i64, ptr } %t129, ptr %l79
  br label %bb36
bb35:
  br label %bb40
bb36:
  %t130 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t130, 1
  %t132 = extractvalue { i64, ptr } %t130, 0
  %t133 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t132)
  call void @olang_textcopy(ptr %t133, ptr %t131, i64 %t132)
  %t134 = insertvalue { i64, ptr } undef, i64 %t132, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr %t133, 1
  %t138 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflTypeNotValue(ptr %s6, ptr %v0, { i64, ptr } %t135)
  store %"compiler/diagmsg:Msg" %t138, ptr %l82
  br label %bb37
bb37:
  %t139 = load ptr, ptr %l75, !tbaa !29
  %t140 = load %"compiler/source:Span", ptr %l76
  %t141 = load %"compiler/diagmsg:Msg", ptr %l82
  %t142 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t139, %"compiler/source:Span" %t140, %"compiler/diagmsg:Msg" %t141)
  store i64 %t142, ptr %l83
  br label %bb38
bb38:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load %"compiler/source:Span", ptr %l1
  %t147 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t143, %"compiler/source:Span" %t144)
  store ptr %t147, ptr %l86
  br label %bb39
bb39:
  %t148 = load ptr, ptr %l86, !tbaa !29
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t148, ptr %rv
  br label %ret
bb40:
  %t150 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t152 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s3, { i64, ptr } %t150, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i1 %t152, ptr %l89
  br label %bb41
bb41:
  %t153 = load i1, ptr %l89, !tbaa !21
  br i1 %t153, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l90, !tbaa !21
  br label %bb45
bb43:
  %t154 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t156 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s3, { i64, ptr } %t154, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store i1 %t156, ptr %l92
  br label %bb44
bb44:
  %t157 = load i1, ptr %l92, !tbaa !21
  store i1 %t157, ptr %l90, !tbaa !21
  br label %bb45
bb45:
  %t158 = load i1, ptr %l90, !tbaa !21
  br i1 %t158, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l93, !tbaa !21
  br label %bb49
bb47:
  %t159 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t161 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s3, { i64, ptr } %t159, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d14, i32 0, i32 1) })
  store i1 %t161, ptr %l95
  br label %bb48
bb48:
  %t162 = load i1, ptr %l95, !tbaa !21
  store i1 %t162, ptr %l93, !tbaa !21
  br label %bb49
bb49:
  %t163 = load i1, ptr %l93, !tbaa !21
  br i1 %t163, label %bb50, label %bb51
bb50:
  store i1 true, ptr %l96, !tbaa !21
  br label %bb53
bb51:
  %t164 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t166 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s3, { i64, ptr } %t164, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i1 %t166, ptr %l98
  br label %bb52
bb52:
  %t167 = load i1, ptr %l98, !tbaa !21
  store i1 %t167, ptr %l96, !tbaa !21
  br label %bb53
bb53:
  %t168 = load i1, ptr %l96, !tbaa !21
  br i1 %t168, label %bb54, label %bb55
bb54:
  store i1 true, ptr %l99, !tbaa !21
  br label %bb57
bb55:
  %t169 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t171 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s3, { i64, ptr } %t169, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d16, i32 0, i32 1) })
  store i1 %t171, ptr %l101
  br label %bb56
bb56:
  %t172 = load i1, ptr %l101, !tbaa !21
  store i1 %t172, ptr %l99, !tbaa !21
  br label %bb57
bb57:
  %t173 = load i1, ptr %l99, !tbaa !21
  br i1 %t173, label %bb58, label %bb59
bb58:
  store i1 true, ptr %l102, !tbaa !21
  br label %bb61
bb59:
  %t174 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t176 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s3, { i64, ptr } %t174, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d17, i32 0, i32 1) })
  store i1 %t176, ptr %l104
  br label %bb60
bb60:
  %t177 = load i1, ptr %l104, !tbaa !21
  store i1 %t177, ptr %l102, !tbaa !21
  br label %bb61
bb61:
  %t178 = load i1, ptr %l102, !tbaa !21
  br i1 %t178, label %bb62, label %bb63
bb62:
  store %olang.scope zeroinitializer, ptr %s8
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load ptr, ptr %l3, !tbaa !29
  %t181 = load i32, ptr %l4, !tbaa !23
  %t185 = call %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflConst(ptr %v0, ptr %v1, ptr %v2, ptr %t179, ptr %t180, i32 %t181)
  store %"compiler/check:reflVal" %t185, ptr %l108
  br label %bb64
bb63:
  br label %bb95
bb64:
  %t186 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store ptr %t186, ptr %lp8
  %t187 = load %"compiler/check:reflVal", ptr %l108
  %t188 = load ptr, ptr %lp8
  store %"compiler/check:reflVal" %t187, ptr %t188
  %t189 = load ptr, ptr %lp8
  %t190 = getelementptr %"compiler/check:reflVal", ptr %t189, i32 0, i32 0
  %t191 = load i1, ptr %t190, !tbaa !21
  br i1 %t191, label %bb65, label %bb66
bb65:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load %"compiler/source:Span", ptr %l1
  %t195 = load ptr, ptr %lp8
  %t196 = load %"compiler/check:reflVal", ptr %t195
  %t200 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflExpr(ptr %v0, ptr %v2, ptr %v2, ptr %t193, %"compiler/source:Span" %t194, %"compiler/check:reflVal" %t196)
  store ptr %t200, ptr %l113
  br label %bb67
bb66:
  br label %bb68
bb67:
  %t201 = load ptr, ptr %l113, !tbaa !29
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t201, ptr %rv
  br label %ret
bb68:
  %t203 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t205 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s8, { i64, ptr } %t203, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d18, i32 0, i32 1) })
  store i1 %t205, ptr %l116
  br label %bb69
bb69:
  %t206 = load i1, ptr %l116, !tbaa !21
  br i1 %t206, label %bb70, label %bb71
bb70:
  store %olang.scope zeroinitializer, ptr %s10
  %t207 = load ptr, ptr %l0, !tbaa !29
  store ptr %t207, ptr %l117, !tbaa !29
  %t208 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t208, ptr %l118
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load i32, ptr %l7, !tbaa !23
  %t213 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s10, ptr %t209, i32 %t210)
  store { i64, ptr } %t213, ptr %l121
  br label %bb72
bb71:
  br label %bb75
bb72:
  %t214 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t216 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflNoKind(ptr %s10, ptr %v0, { i64, ptr } %t214)
  store %"compiler/diagmsg:Msg" %t216, ptr %l123
  br label %bb73
bb73:
  %t217 = load ptr, ptr %l117, !tbaa !29
  %t218 = load %"compiler/source:Span", ptr %l118
  %t219 = load %"compiler/diagmsg:Msg", ptr %l123
  %t220 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t217, %"compiler/source:Span" %t218, %"compiler/diagmsg:Msg" %t219)
  store i64 %t220, ptr %l124
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s10)
  br label %bb75
bb75:
  %t221 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t223 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s8, { i64, ptr } %t221, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d19, i32 0, i32 1) })
  store i1 %t223, ptr %l126
  br label %bb76
bb76:
  %t224 = load i1, ptr %l126, !tbaa !21
  br i1 %t224, label %bb77, label %bb78
bb77:
  store %olang.scope zeroinitializer, ptr %s11
  %t225 = load ptr, ptr %l0, !tbaa !29
  store ptr %t225, ptr %l127, !tbaa !29
  %t226 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t226, ptr %l128
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = load i32, ptr %l7, !tbaa !23
  %t231 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s11, ptr %t227, i32 %t228)
  store { i64, ptr } %t231, ptr %l131
  br label %bb79
bb78:
  br label %bb82
bb79:
  %t232 = load { i64, ptr }, ptr %l131, !tbaa !27
  %t234 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflNoLength(ptr %s11, ptr %v0, { i64, ptr } %t232)
  store %"compiler/diagmsg:Msg" %t234, ptr %l133
  br label %bb80
bb80:
  %t235 = load ptr, ptr %l127, !tbaa !29
  %t236 = load %"compiler/source:Span", ptr %l128
  %t237 = load %"compiler/diagmsg:Msg", ptr %l133
  %t238 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t235, %"compiler/source:Span" %t236, %"compiler/diagmsg:Msg" %t237)
  store i64 %t238, ptr %l134
  br label %bb81
bb81:
  call void @__olang_scope_close(ptr %s11)
  br label %bb82
bb82:
  %t239 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t241 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s8, { i64, ptr } %t239, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d20, i32 0, i32 1) })
  store i1 %t241, ptr %l136
  br label %bb83
bb83:
  %t242 = load i1, ptr %l136, !tbaa !21
  br i1 %t242, label %bb84, label %bb85
bb84:
  store i1 true, ptr %l137, !tbaa !21
  br label %bb87
bb85:
  %t243 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t245 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s8, { i64, ptr } %t243, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d21, i32 0, i32 1) })
  store i1 %t245, ptr %l139
  br label %bb86
bb86:
  %t246 = load i1, ptr %l139, !tbaa !21
  store i1 %t246, ptr %l137, !tbaa !21
  br label %bb87
bb87:
  %t247 = load i1, ptr %l137, !tbaa !21
  br i1 %t247, label %bb88, label %bb89
bb88:
  store %olang.scope zeroinitializer, ptr %s12
  %t248 = load ptr, ptr %l0, !tbaa !29
  store ptr %t248, ptr %l140, !tbaa !29
  %t249 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t249, ptr %l141
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t251 = load i32, ptr %l7, !tbaa !23
  %t254 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s12, ptr %t250, i32 %t251)
  store { i64, ptr } %t254, ptr %l144
  br label %bb90
bb89:
  br label %bb93
bb90:
  %t255 = load { i64, ptr }, ptr %l144, !tbaa !27
  %t256 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t259 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflNoLayout(ptr %s12, ptr %v0, ptr %v0, { i64, ptr } %t255, { i64, ptr } %t256)
  store %"compiler/diagmsg:Msg" %t259, ptr %l147
  br label %bb91
bb91:
  %t260 = load ptr, ptr %l140, !tbaa !29
  %t261 = load %"compiler/source:Span", ptr %l141
  %t262 = load %"compiler/diagmsg:Msg", ptr %l147
  %t263 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t260, %"compiler/source:Span" %t261, %"compiler/diagmsg:Msg" %t262)
  store i64 %t263, ptr %l148
  br label %bb92
bb92:
  call void @__olang_scope_close(ptr %s12)
  br label %bb93
bb93:
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t265 = load %"compiler/source:Span", ptr %l1
  %t268 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t264, %"compiler/source:Span" %t265)
  store ptr %t268, ptr %l151
  br label %bb94
bb94:
  %t269 = load ptr, ptr %l151, !tbaa !29
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t269, ptr %rv
  br label %ret
bb95:
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t272 = load i32, ptr %l7, !tbaa !23
  %t275 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t271, i32 %t272)
  store i1 %t275, ptr %l155
  br label %bb96
bb96:
  %t276 = load i1, ptr %l155, !tbaa !21
  br i1 %t276, label %bb97, label %bb98
bb97:
  store i1 true, ptr %l156, !tbaa !21
  br label %bb100
bb98:
  %t277 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t279 = call i1 @compiler_2fcheck_2eisLimitName(ptr %v0, { i64, ptr } %t277)
  store i1 %t279, ptr %l158
  br label %bb99
bb99:
  %t280 = load i1, ptr %l158, !tbaa !21
  store i1 %t280, ptr %l156, !tbaa !21
  br label %bb100
bb100:
  %t281 = load i1, ptr %l156, !tbaa !21
  br i1 %t281, label %bb101, label %bb102
bb101:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb102:
  br label %bb103
bb103:
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t284 = load i32, ptr %l7, !tbaa !23
  %t287 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t283, i32 %t284)
  store i1 %t287, ptr %l162
  br label %bb104
bb104:
  %t288 = load i1, ptr %l162, !tbaa !21
  br i1 %t288, label %bb105, label %bb106
bb105:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb106:
  br label %bb107
bb107:
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t291 = load i32, ptr %l7, !tbaa !23
  %t294 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t290, i32 %t291)
  store i1 %t294, ptr %l166
  br label %bb108
bb108:
  %t295 = load i1, ptr %l166, !tbaa !21
  br i1 %t295, label %bb109, label %bb110
bb109:
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t297 = load i32, ptr %l7, !tbaa !23
  %t300 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t296, i32 %t297)
  store i32 %t300, ptr %l170
  br label %bb111
bb110:
  store i1 false, ptr %l167, !tbaa !21
  br label %bb112
bb111:
  %t301 = load i32, ptr %l170, !range !{i32 0, i32 6}
  %t303 = trunc i64 2 to i32
  %t304 = icmp eq i32 %t301, %t303
  store i1 %t304, ptr %l167, !tbaa !21
  br label %bb112
bb112:
  %t306 = load i1, ptr %l167, !tbaa !21
  br i1 %t306, label %bb113, label %bb114
bb113:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb114:
  br label %bb115
bb115:
  %t308 = load ptr, ptr %l0, !tbaa !29
  store ptr %t308, ptr %l174, !tbaa !29
  %t309 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t309, ptr %l175
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t311 = load i32, ptr %l7, !tbaa !23
  %t314 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s3, ptr %t310, i32 %t311)
  store { i64, ptr } %t314, ptr %l178
  br label %bb116
bb116:
  %t315 = load { i64, ptr }, ptr %l178, !tbaa !27
  %t316 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t319 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflNoMember(ptr %s3, ptr %v0, ptr %v0, { i64, ptr } %t315, { i64, ptr } %t316)
  store %"compiler/diagmsg:Msg" %t319, ptr %l181
  br label %bb117
bb117:
  %t320 = load ptr, ptr %l174, !tbaa !29
  %t321 = load %"compiler/source:Span", ptr %l175
  %t322 = load %"compiler/diagmsg:Msg", ptr %l181
  %t323 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t320, %"compiler/source:Span" %t321, %"compiler/diagmsg:Msg" %t322)
  store i64 %t323, ptr %l182
  br label %bb118
bb118:
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t325 = load %"compiler/source:Span", ptr %l1
  %t328 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t324, %"compiler/source:Span" %t325)
  store ptr %t328, ptr %l185
  br label %bb119
bb119:
  %t329 = load ptr, ptr %l185, !tbaa !29
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t329, ptr %rv
  br label %ret
bb120:
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t332 = load ptr, ptr %l3, !tbaa !29
  %t335 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescTypeOf(ptr %v0, ptr %v1, ptr %t331, ptr %t332)
  store i32 %t335, ptr %l189
  br label %bb121
bb121:
  %t336 = load i32, ptr %l189, !tbaa !23
  store i32 %t336, ptr %l9, !tbaa !23
  %t337 = load i32, ptr %l9, !tbaa !23
  %t339 = icmp slt i32 %t337, 0
  br i1 %t339, label %bb122, label %bb123
bb122:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb123:
  br label %bb124
bb124:
  %t342 = load i32, ptr %l9, !tbaa !23
  %t343 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t346 = icmp eq i32 %t342, %t343
  br i1 %t346, label %bb125, label %bb126
bb125:
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t349 = load %"compiler/source:Span", ptr %l1
  %t352 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t348, %"compiler/source:Span" %t349)
  store ptr %t352, ptr %l198
  br label %bb127
bb126:
  br label %bb128
bb127:
  %t353 = load ptr, ptr %l198, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t353, ptr %rv
  br label %ret
bb128:
  %t355 = load ptr, ptr %l0, !tbaa !29
  %t357 = getelementptr %"compiler/check:Checker", ptr %t355, i32 0, i32 1
  %t358 = load ptr, ptr %t357, !tbaa !29
  %t359 = load i32, ptr %l9, !tbaa !23
  %t362 = call %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %t358, i32 %t359)
  store %"compiler/generic:Desc" %t362, ptr %l203
  br label %bb129
bb129:
  %t363 = load %"compiler/generic:Desc", ptr %l203
  store %"compiler/generic:Desc" %t363, ptr %l10
  %t364 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t366 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t364, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d22, i32 0, i32 1) })
  store i1 %t366, ptr %l205
  br label %bb130
bb130:
  %t367 = load i1, ptr %l205, !tbaa !21
  br i1 %t367, label %bb131, label %bb132
bb131:
  %t368 = getelementptr %"compiler/generic:Desc", ptr %l10, i32 0, i32 0
  %t369 = load i64, ptr %t368, !tbaa !24
  %t370 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescCase, !tbaa !24
  %t373 = icmp ne i64 %t369, %t370
  store i1 %t373, ptr %l206, !tbaa !21
  br label %bb133
bb132:
  store i1 false, ptr %l206, !tbaa !21
  br label %bb133
bb133:
  %t375 = load i1, ptr %l206, !tbaa !21
  br i1 %t375, label %bb134, label %bb135
bb134:
  store %olang.scope zeroinitializer, ptr %s18
  %t376 = load ptr, ptr %l0, !tbaa !29
  store ptr %t376, ptr %l210, !tbaa !29
  %t377 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t377, ptr %l211
  %t378 = load ptr, ptr %l0, !tbaa !29
  %t379 = load %"compiler/source:Span", ptr %l1
  %t382 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %s18, ptr %t378, %"compiler/source:Span" %t379)
  store { i64, ptr } %t382, ptr %l214
  br label %bb136
bb135:
  br label %bb140
bb136:
  %t383 = load { i64, ptr }, ptr %l214, !tbaa !27
  %t384 = extractvalue { i64, ptr } %t383, 1
  %t385 = extractvalue { i64, ptr } %t383, 0
  %t386 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t385)
  call void @olang_textcopy(ptr %t386, ptr %t384, i64 %t385)
  %t387 = insertvalue { i64, ptr } undef, i64 %t385, 0
  %t388 = insertvalue { i64, ptr } %t387, ptr %t386, 1
  %t391 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflTypeNotValue(ptr %s18, ptr %v0, { i64, ptr } %t388)
  store %"compiler/diagmsg:Msg" %t391, ptr %l217
  br label %bb137
bb137:
  %t392 = load ptr, ptr %l210, !tbaa !29
  %t393 = load %"compiler/source:Span", ptr %l211
  %t394 = load %"compiler/diagmsg:Msg", ptr %l217
  %t395 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t392, %"compiler/source:Span" %t393, %"compiler/diagmsg:Msg" %t394)
  store i64 %t395, ptr %l218
  br label %bb138
bb138:
  %t396 = load ptr, ptr %l0, !tbaa !29
  %t397 = load %"compiler/source:Span", ptr %l1
  %t400 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t396, %"compiler/source:Span" %t397)
  store ptr %t400, ptr %l221
  br label %bb139
bb139:
  %t401 = load ptr, ptr %l221, !tbaa !29
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t401, ptr %rv
  br label %ret
bb140:
  %t403 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t405 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t403, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d23, i32 0, i32 1) })
  store i1 %t405, ptr %l224
  br label %bb141
bb141:
  %t406 = load i1, ptr %l224, !tbaa !21
  br i1 %t406, label %bb142, label %bb143
bb142:
  %t407 = getelementptr %"compiler/generic:Desc", ptr %l10, i32 0, i32 0
  %t408 = load i64, ptr %t407, !tbaa !24
  %t409 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescParam, !tbaa !24
  %t412 = icmp eq i64 %t408, %t409
  store i1 %t412, ptr %l225, !tbaa !21
  br label %bb144
bb143:
  store i1 false, ptr %l225, !tbaa !21
  br label %bb144
bb144:
  %t414 = load i1, ptr %l225, !tbaa !21
  br i1 %t414, label %bb145, label %bb146
bb145:
  %t415 = load ptr, ptr %l0, !tbaa !29
  %t416 = load %"compiler/source:Span", ptr %l1
  %t417 = load %"compiler/generic:Desc", ptr %l10
  %t421 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflDefault(ptr %v0, ptr %v2, ptr %t415, %"compiler/source:Span" %t416, %"compiler/generic:Desc" %t417)
  store ptr %t421, ptr %l232
  br label %bb147
bb146:
  br label %bb148
bb147:
  %t422 = load ptr, ptr %l232, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t422, ptr %rv
  br label %ret
bb148:
  %t424 = load ptr, ptr %l0, !tbaa !29
  %t425 = load ptr, ptr %l3, !tbaa !29
  %t426 = load i32, ptr %l4, !tbaa !23
  %t430 = call %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflConst(ptr %v0, ptr %v1, ptr %v2, ptr %t424, ptr %t425, i32 %t426)
  store %"compiler/check:reflVal" %t430, ptr %l237
  br label %bb149
bb149:
  %t431 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store ptr %t431, ptr %lp11
  %t432 = load %"compiler/check:reflVal", ptr %l237
  %t433 = load ptr, ptr %lp11
  store %"compiler/check:reflVal" %t432, ptr %t433
  %t434 = load ptr, ptr %lp11
  %t435 = getelementptr %"compiler/check:reflVal", ptr %t434, i32 0, i32 0
  %t436 = load i1, ptr %t435, !tbaa !21
  br i1 %t436, label %bb150, label %bb151
bb150:
  %t438 = load ptr, ptr %l0, !tbaa !29
  %t439 = load %"compiler/source:Span", ptr %l1
  %t440 = load ptr, ptr %lp11
  %t441 = load %"compiler/check:reflVal", ptr %t440
  %t445 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflExpr(ptr %v0, ptr %v2, ptr %v2, ptr %t438, %"compiler/source:Span" %t439, %"compiler/check:reflVal" %t441)
  store ptr %t445, ptr %l242
  br label %bb152
bb151:
  br label %bb153
bb152:
  %t446 = load ptr, ptr %l242, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t446, ptr %rv
  br label %ret
bb153:
  %t448 = getelementptr %"compiler/generic:Desc", ptr %l10, i32 0, i32 0
  %t449 = load i64, ptr %t448, !tbaa !24
  store i64 %t449, ptr %l12, !tbaa !24
  %t451 = load i64, ptr %l12, !tbaa !24
  %t452 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescField, !tbaa !24
  %t455 = icmp eq i64 %t451, %t452
  br i1 %t455, label %bb154, label %bb155
bb154:
  br label %bb156
bb155:
  br label %bb157
bb156:
  store { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d24, i32 0, i32 1) }, ptr %l245, !tbaa !27
  br label %bb174
bb157:
  %t457 = load i64, ptr %l12, !tbaa !24
  %t458 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescCase, !tbaa !24
  %t461 = icmp eq i64 %t457, %t458
  br i1 %t461, label %bb158, label %bb159
bb158:
  br label %bb160
bb159:
  br label %bb161
bb160:
  store { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d25, i32 0, i32 1) }, ptr %l245, !tbaa !27
  br label %bb174
bb161:
  %t463 = load i64, ptr %l12, !tbaa !24
  %t464 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescParam, !tbaa !24
  %t467 = icmp eq i64 %t463, %t464
  br i1 %t467, label %bb162, label %bb163
bb162:
  br label %bb164
bb163:
  br label %bb165
bb164:
  store { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d26, i32 0, i32 1) }, ptr %l245, !tbaa !27
  br label %bb174
bb165:
  %t469 = load i64, ptr %l12, !tbaa !24
  %t470 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescFunc, !tbaa !24
  %t473 = icmp eq i64 %t469, %t470
  br i1 %t473, label %bb166, label %bb167
bb166:
  br label %bb168
bb167:
  br label %bb169
bb168:
  store { i64, ptr } { i64 108, ptr getelementptr inbounds (<{ i64, [108 x i8] }>, ptr @.d27, i32 0, i32 1) }, ptr %l245, !tbaa !27
  br label %bb174
bb169:
  br i1 true, label %bb170, label %bb171
bb170:
  br label %bb172
bb171:
  br label %bb173
bb172:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d28, i32 0, i32 1) }, ptr %l245, !tbaa !27
  br label %bb174
bb173:
  call void @__olang_check_failed(ptr @olang_loc_6fa12bf18c08968_7f63ef0109416d3c)
  unreachable
bb174:
  %t475 = load { i64, ptr }, ptr %l245, !tbaa !27
  store { i64, ptr } %t475, ptr %l13, !tbaa !27
  %t476 = getelementptr %"compiler/generic:Desc", ptr %l10, i32 0, i32 0
  %t477 = load i64, ptr %t476, !tbaa !24
  store i64 %t477, ptr %l14, !tbaa !24
  %t479 = load i64, ptr %l14, !tbaa !24
  %t480 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescField, !tbaa !24
  %t483 = icmp eq i64 %t479, %t480
  br i1 %t483, label %bb175, label %bb176
bb175:
  br label %bb177
bb176:
  br label %bb178
bb177:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d29, i32 0, i32 1) }, ptr %l259, !tbaa !27
  br label %bb195
bb178:
  %t485 = load i64, ptr %l14, !tbaa !24
  %t486 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescCase, !tbaa !24
  %t489 = icmp eq i64 %t485, %t486
  br i1 %t489, label %bb179, label %bb180
bb179:
  br label %bb181
bb180:
  br label %bb182
bb181:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d30, i32 0, i32 1) }, ptr %l259, !tbaa !27
  br label %bb195
bb182:
  %t491 = load i64, ptr %l14, !tbaa !24
  %t492 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescParam, !tbaa !24
  %t495 = icmp eq i64 %t491, %t492
  br i1 %t495, label %bb183, label %bb184
bb183:
  br label %bb185
bb184:
  br label %bb186
bb185:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d31, i32 0, i32 1) }, ptr %l259, !tbaa !27
  br label %bb195
bb186:
  %t497 = load i64, ptr %l14, !tbaa !24
  %t498 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescFunc, !tbaa !24
  %t501 = icmp eq i64 %t497, %t498
  br i1 %t501, label %bb187, label %bb188
bb187:
  br label %bb189
bb188:
  br label %bb190
bb189:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d32, i32 0, i32 1) }, ptr %l259, !tbaa !27
  br label %bb195
bb190:
  br i1 true, label %bb191, label %bb192
bb191:
  br label %bb193
bb192:
  br label %bb194
bb193:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d33, i32 0, i32 1) }, ptr %l259, !tbaa !27
  br label %bb195
bb194:
  call void @__olang_check_failed(ptr @olang_loc_366830190f407939_a82d5f1c611378ed)
  unreachable
bb195:
  %t503 = load { i64, ptr }, ptr %l259, !tbaa !27
  %t504 = load ptr, ptr %l0, !tbaa !29
  store ptr %t504, ptr %l272, !tbaa !29
  %t505 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t505, ptr %l273
  %t507 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t508 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t509 = load ptr, ptr @__olang_prog_scope
  %t510 = load ptr, ptr @__olang_prog_scope
  %t514 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflDescNoMember(ptr %t509, ptr %v0, ptr %t510, ptr %v0, { i64, ptr } %t503, { i64, ptr } %t507, { i64, ptr } %t508)
  store %"compiler/diagmsg:Msg" %t514, ptr %l277
  br label %bb196
bb196:
  %t515 = load ptr, ptr %l272, !tbaa !29
  %t516 = load %"compiler/source:Span", ptr %l273
  %t517 = load %"compiler/diagmsg:Msg", ptr %l277
  %t518 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t515, %"compiler/source:Span" %t516, %"compiler/diagmsg:Msg" %t517)
  store i64 %t518, ptr %l278
  br label %bb197
bb197:
  %t519 = load ptr, ptr %l0, !tbaa !29
  %t520 = load %"compiler/source:Span", ptr %l1
  %t523 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t519, %"compiler/source:Span" %t520)
  store ptr %t523, ptr %l281
  br label %bb198
bb198:
  %t524 = load ptr, ptr %l281, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t524, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estepMethod(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i1
  %l5 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca ptr
  %l13 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i32
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca %"compiler/source:Span"
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l44 = alloca ptr
  %l45 = alloca ptr
  %l46 = alloca %"compiler/source:Span"
  %l47 = alloca ptr
  %l52 = alloca ptr
  %l56 = alloca ptr
  %l57 = alloca i32
  %l59 = alloca { i64, ptr }
  %l60 = alloca i64
  %l63 = alloca ptr
  %l64 = alloca i32
  %l66 = alloca { i64, ptr }
  %l67 = alloca %"compiler/source:Span"
  %l69 = alloca { i64, ptr }
  %l70 = alloca i1
  %l71 = alloca ptr
  %l74 = alloca ptr
  %l77 = alloca ptr
  %l81 = alloca i32
  %l82 = alloca i32
  %l83 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l86 = alloca i32
  %l89 = alloca i1
  %l92 = alloca ptr
  %l93 = alloca %"compiler/source:Span"
  %l94 = alloca i32
  %l97 = alloca ptr
  %l100 = alloca i32
  %l101 = alloca i1
  %l102 = alloca i64
  %l105 = alloca i32
  %l106 = alloca i64
  %l107 = alloca ptr
  %l108 = alloca ptr
  %l109 = alloca %"compiler/source:Span"
  %l110 = alloca %"compiler/source:Span"
  %l111 = alloca i64
  %l118 = alloca ptr
  %l119 = alloca ptr
  %l122 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l129 = alloca ptr
  %l130 = alloca ptr
  %l131 = alloca %"compiler/source:Span"
  %l132 = alloca ptr
  %l137 = alloca ptr
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i1
  %t31 = alloca { i64, [4 x i64] }, align 8
  %t89 = alloca { i64, [3 x i64] }, align 8
  %t216 = alloca { i64, [4 x i64] }, align 8
  %t272 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  store i1 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l3, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load i1, ptr %l13, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l16, !tbaa !29
  %t11 = load i32, ptr %l3, !tbaa !23
  store i32 %t11, ptr %l17, !tbaa !23
  %t12 = load i1, ptr %l4, !tbaa !21
  br i1 %t12, label %bb5, label %bb6
bb5:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d34, i32 0, i32 1) }, ptr %l19, !tbaa !27
  br label %bb7
bb6:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d35, i32 0, i32 1) }, ptr %l19, !tbaa !27
  br label %bb7
bb7:
  %t14 = load ptr, ptr %l16, !tbaa !29
  %t15 = load i32, ptr %l17, !tbaa !23
  %t16 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t17 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s0, ptr %t14, i32 %t15, { i64, ptr } %t16, i64 0)
  store i64 %t17, ptr %l20
  br label %bb8
bb8:
  %t18 = load i64, ptr %l20, !tbaa !24
  store i64 %t18, ptr %l5, !tbaa !24
  %t19 = load i64, ptr %l5, !tbaa !24
  %t21 = icmp sge i64 %t19, 0
  br i1 %t21, label %bb9, label %bb10
bb9:
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l23, !tbaa !29
  %t24 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t24, ptr %l24
  %t25 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t25, ptr %l25
  %t26 = load i64, ptr %l5, !tbaa !24
  store i64 %t26, ptr %l26, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load %"compiler/source:Span", ptr %l1
  %t29 = load %"compiler/source:Span", ptr %l1
  %t30 = load i32, ptr %l3, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t31
  %t32 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 0
  store i64 7, ptr %t32
  %t34 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t29, 0
  %t36 = insertvalue { %"compiler/source:Span", i32 } %t34, i32 %t30, 1
  %t37 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t36, ptr %t37
  %t38 = load { i64, [4 x i64] }, ptr %t31
  %t40 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t38, ptr %t40
  %t44 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t27, %"compiler/source:Span" %t28, ptr %t40)
  store ptr %t44, ptr %l33
  br label %bb11
bb10:
  br label %bb27
bb11:
  %t45 = load ptr, ptr %l33, !tbaa !29
  store ptr %t45, ptr %l34, !tbaa !29
  %t46 = icmp sge i64 0, 0
  br i1 %t46, label %bb12, label %bb13
bb12:
  %t48 = icmp sle i64 0, 1152921504606846975
  br i1 %t48, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_fe73ad2ef66395ad_6bb388f528f40629)
  unreachable
bb14:
  %t50 = mul i64 0, 8
  %t51 = insertvalue { i64, ptr } undef, i64 0, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t52, ptr %l37, !tbaa !27
  %t53 = icmp sge i64 0, 0
  br i1 %t53, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_fe73ad2ef66395ad_6bb388f528f40629)
  unreachable
bb16:
  %t55 = icmp sle i64 0, 1152921504606846975
  br i1 %t55, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_fe73ad2ef66395ad_6bb388f528f40629)
  unreachable
bb18:
  %t57 = mul i64 0, 8
  %t58 = insertvalue { i64, ptr } undef, i64 0, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t59, ptr %l40, !tbaa !27
  %t60 = icmp sge i64 0, 0
  br i1 %t60, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_fe73ad2ef66395ad_6bb388f528f40629)
  unreachable
bb20:
  %t62 = icmp sle i64 0, 2305843009213693951
  br i1 %t62, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_97840d8df2a94e80_8f65c6ae19d7bb5c)
  unreachable
bb22:
  %t64 = mul i64 0, 4
  %t65 = insertvalue { i64, ptr } undef, i64 0, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t67 = load ptr, ptr %l23, !tbaa !29
  %t68 = load %"compiler/source:Span", ptr %l24
  %t69 = load %"compiler/source:Span", ptr %l25
  %t70 = load i64, ptr %l26, !tbaa !24
  %t71 = load ptr, ptr %l34, !tbaa !29
  %t72 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t73 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t75 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t67, %"compiler/source:Span" %t68, %"compiler/source:Span" %t69, i64 %t70, ptr %t71, { i64, ptr } %t72, { i64, ptr } %t73, { i64, ptr } %t66)
  store ptr %t75, ptr %l44
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_97840d8df2a94e80_8f65c6ae19d7bb5c)
  unreachable
bb24:
  %t76 = load ptr, ptr %l44, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l45, !tbaa !29
  %t78 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t78, ptr %l46
  %t79 = load ptr, ptr %l2, !tbaa !29
  store ptr %t79, ptr %l47, !tbaa !29
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = load i32, ptr %l3, !tbaa !23
  %t83 = load %"compiler/source:Span", ptr %l1
  %t88 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v0, ptr %v0, ptr %t80, ptr %t76, i32 %t82, %"compiler/source:Span" %t83)
  store ptr %t88, ptr %l52
  br label %bb25
bb25:
  store { i64, [3 x i64] } zeroinitializer, ptr %t89
  %t90 = getelementptr { i64, [3 x i64] }, ptr %t89, i32 0, i32 0
  store i64 1, ptr %t90
  %t91 = load %"compiler/source:Span", ptr %l46
  %t92 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t91, 0
  %t93 = load ptr, ptr %l47, !tbaa !29
  %t94 = insertvalue { %"compiler/source:Span", ptr, ptr } %t92, ptr %t93, 1
  %t95 = load ptr, ptr %l52, !tbaa !29
  %t96 = insertvalue { %"compiler/source:Span", ptr, ptr } %t94, ptr %t95, 2
  %t97 = getelementptr { i64, [3 x i64] }, ptr %t89, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t96, ptr %t97
  %t98 = load { i64, [3 x i64] }, ptr %t89
  %t100 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t98, ptr %t100
  %t101 = load ptr, ptr %l45, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t101, ptr %t100)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb27:
  %t104 = load ptr, ptr %l0, !tbaa !29
  store ptr %t104, ptr %l56, !tbaa !29
  %t105 = load i32, ptr %l3, !tbaa !23
  store i32 %t105, ptr %l57, !tbaa !23
  %t106 = load i1, ptr %l4, !tbaa !21
  br i1 %t106, label %bb28, label %bb29
bb28:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d36, i32 0, i32 1) }, ptr %l59, !tbaa !27
  br label %bb30
bb29:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d37, i32 0, i32 1) }, ptr %l59, !tbaa !27
  br label %bb30
bb30:
  %t108 = load ptr, ptr %l56, !tbaa !29
  %t109 = load i32, ptr %l57, !tbaa !23
  %t110 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t111 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s0, ptr %t108, i32 %t109, { i64, ptr } %t110, i64 1)
  store i64 %t111, ptr %l60
  br label %bb31
bb31:
  %t112 = load i64, ptr %l60, !tbaa !24
  store i64 %t112, ptr %l7, !tbaa !24
  %t113 = load i64, ptr %l7, !tbaa !24
  %t115 = icmp slt i64 %t113, 0
  br i1 %t115, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s3
  %t117 = load ptr, ptr %l0, !tbaa !29
  store ptr %t117, ptr %l63, !tbaa !29
  %t118 = load i32, ptr %l3, !tbaa !23
  store i32 %t118, ptr %l64, !tbaa !23
  %t119 = load i1, ptr %l4, !tbaa !21
  br i1 %t119, label %bb34, label %bb35
bb33:
  br label %bb41
bb34:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %l66, !tbaa !27
  br label %bb36
bb35:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d39, i32 0, i32 1) }, ptr %l66, !tbaa !27
  br label %bb36
bb36:
  %t121 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t121, ptr %l67
  %t122 = load i1, ptr %l4, !tbaa !21
  br i1 %t122, label %bb37, label %bb38
bb37:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d40, i32 0, i32 1) }, ptr %l69, !tbaa !27
  br label %bb39
bb38:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d41, i32 0, i32 1) }, ptr %l69, !tbaa !27
  br label %bb39
bb39:
  %t124 = load ptr, ptr %l63, !tbaa !29
  %t125 = load i32, ptr %l64, !tbaa !23
  %t126 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t127 = load %"compiler/source:Span", ptr %l67
  %t128 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t129 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %s3, ptr %s3, ptr %t124, i32 %t125, { i64, ptr } %t126, %"compiler/source:Span" %t127, { i64, ptr } %t128, i64 0, i1 false)
  store i1 %t129, ptr %l70
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t130 = load i1, ptr %l70, !tbaa !21
  store i1 %t130, ptr %rv
  br label %ret
bb41:
  %t131 = load ptr, ptr %l0, !tbaa !29
  store ptr %t131, ptr %l71, !tbaa !29
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/check:Checker", ptr %t132, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !29
  %t137 = getelementptr %"compiler/generic:Program", ptr %t135, i32 0, i32 2
  store ptr %t137, ptr %l74, !tbaa !29
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/check:Checker", ptr %t138, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !29
  %t143 = getelementptr %"compiler/generic:Program", ptr %t141, i32 0, i32 2
  store ptr %t143, ptr %l77, !tbaa !29
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/check:Checker", ptr %t144, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !29
  %t148 = load i64, ptr %l7, !tbaa !24
  %t151 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t147, i64 %t148)
  store i32 %t151, ptr %l81
  br label %bb42
bb42:
  %t152 = load ptr, ptr %l77, !tbaa !29
  %t153 = load i32, ptr %l81, !tbaa !23
  %t154 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t152, i32 %t153)
  store i32 %t154, ptr %l82
  br label %bb43
bb43:
  %t155 = load ptr, ptr %l74, !tbaa !29
  %t156 = load i32, ptr %l82, !tbaa !23
  %t157 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t155, i32 %t156)
  store { i64, ptr } %t157, ptr %l83
  br label %bb44
bb44:
  %t158 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t158, ptr %l84, !tbaa !27
  %t159 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = getelementptr i32, ptr %t160, i64 1
  %t162 = load i32, ptr %t161, !tbaa !33
  %t163 = load ptr, ptr %l71, !tbaa !29
  %t165 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t163, i32 %t162)
  store i32 %t165, ptr %l86
  br label %bb45
bb45:
  %t166 = load i32, ptr %l86, !tbaa !23
  store i32 %t166, ptr %l8, !tbaa !23
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load i32, ptr %l8, !tbaa !23
  %t171 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t167, i32 %t168)
  store i1 %t171, ptr %l89
  br label %bb46
bb46:
  %t172 = load i1, ptr %l89, !tbaa !21
  %t173 = xor i1 %t172, true
  br i1 %t173, label %bb47, label %bb48
bb47:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb48:
  br label %bb49
bb49:
  %t176 = load ptr, ptr %l0, !tbaa !29
  store ptr %t176, ptr %l92, !tbaa !29
  %t177 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t177, ptr %l93
  %t178 = load i32, ptr %l8, !tbaa !23
  store i32 %t178, ptr %l94, !tbaa !23
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/check:Checker", ptr %t179, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !29
  %t184 = getelementptr %"compiler/generic:Program", ptr %t182, i32 0, i32 2
  store ptr %t184, ptr %l97, !tbaa !29
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load i32, ptr %l8, !tbaa !23
  %t189 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t185, i32 %t186)
  store i32 %t189, ptr %l100
  br label %bb50
bb50:
  %t190 = load ptr, ptr %l97, !tbaa !29
  %t191 = load i32, ptr %l100, !tbaa !23
  %t192 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t190, i32 %t191)
  store i1 %t192, ptr %l101
  br label %bb51
bb51:
  %t193 = load i1, ptr %l101, !tbaa !21
  br i1 %t193, label %bb52, label %bb53
bb52:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load i32, ptr %l8, !tbaa !23
  %t198 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t194, i32 %t195)
  store i32 %t198, ptr %l105
  br label %bb54
bb53:
  store i64 1, ptr %l102, !tbaa !24
  br label %bb56
bb54:
  %t199 = load i32, ptr %l105, !tbaa !23
  %t200 = call i64 @compiler_2fcheck_2efloatBits(i32 %t199, double 0x3ff0000000000000)
  store i64 %t200, ptr %l106
  br label %bb55
bb55:
  %t201 = load i64, ptr %l106, !tbaa !24
  store i64 %t201, ptr %l102, !tbaa !24
  br label %bb56
bb56:
  %t202 = load ptr, ptr %l92, !tbaa !29
  %t203 = load %"compiler/source:Span", ptr %l93
  %t204 = load i32, ptr %l94, !tbaa !23
  %t205 = load i64, ptr %l102, !tbaa !24
  %t206 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t202, %"compiler/source:Span" %t203, i32 %t204, i64 %t205)
  store ptr %t206, ptr %l107
  br label %bb57
bb57:
  %t207 = load ptr, ptr %l107, !tbaa !29
  store ptr %t207, ptr %l9, !tbaa !29
  %t208 = load ptr, ptr %l0, !tbaa !29
  store ptr %t208, ptr %l108, !tbaa !29
  %t209 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t209, ptr %l109
  %t210 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t210, ptr %l110
  %t211 = load i64, ptr %l7, !tbaa !24
  store i64 %t211, ptr %l111, !tbaa !24
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load %"compiler/source:Span", ptr %l1
  %t214 = load %"compiler/source:Span", ptr %l1
  %t215 = load i32, ptr %l3, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t216
  %t217 = getelementptr { i64, [4 x i64] }, ptr %t216, i32 0, i32 0
  store i64 7, ptr %t217
  %t219 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t214, 0
  %t221 = insertvalue { %"compiler/source:Span", i32 } %t219, i32 %t215, 1
  %t222 = getelementptr { i64, [4 x i64] }, ptr %t216, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t221, ptr %t222
  %t223 = load { i64, [4 x i64] }, ptr %t216
  %t225 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t223, ptr %t225
  %t229 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t212, %"compiler/source:Span" %t213, ptr %t225)
  store ptr %t229, ptr %l118
  br label %bb58
bb58:
  %t230 = load ptr, ptr %l118, !tbaa !29
  store ptr %t230, ptr %l119, !tbaa !29
  %t231 = icmp sge i64 0, 0
  br i1 %t231, label %bb59, label %bb60
bb59:
  %t233 = icmp sle i64 0, 1152921504606846975
  br i1 %t233, label %bb61, label %bb62
bb60:
  call void @__olang_check_failed(ptr @olang_loc_729de81d3b051823_7dce08f61f50e4bf)
  unreachable
bb61:
  %t235 = mul i64 0, 8
  %t236 = insertvalue { i64, ptr } undef, i64 0, 0
  %t237 = insertvalue { i64, ptr } %t236, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t237, ptr %l122, !tbaa !27
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t239 = load ptr, ptr %l9, !tbaa !29
  %t242 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v0, ptr %v0, ptr %t238, ptr %t239)
  store { i64, ptr } %t242, ptr %l125
  br label %bb63
bb62:
  call void @__olang_check_failed(ptr @olang_loc_729de81d3b051823_7dce08f61f50e4bf)
  unreachable
bb63:
  %t243 = icmp sge i64 0, 0
  br i1 %t243, label %bb64, label %bb65
bb64:
  %t245 = icmp sle i64 0, 2305843009213693951
  br i1 %t245, label %bb66, label %bb67
bb65:
  call void @__olang_check_failed(ptr @olang_loc_97840d8df2a94e80_8f65c6ae19d7bb5c)
  unreachable
bb66:
  %t247 = mul i64 0, 4
  %t248 = insertvalue { i64, ptr } undef, i64 0, 0
  %t249 = insertvalue { i64, ptr } %t248, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t250 = load ptr, ptr %l108, !tbaa !29
  %t251 = load %"compiler/source:Span", ptr %l109
  %t252 = load %"compiler/source:Span", ptr %l110
  %t253 = load i64, ptr %l111, !tbaa !24
  %t254 = load ptr, ptr %l119, !tbaa !29
  %t255 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t256 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t258 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t250, %"compiler/source:Span" %t251, %"compiler/source:Span" %t252, i64 %t253, ptr %t254, { i64, ptr } %t255, { i64, ptr } %t256, { i64, ptr } %t249)
  store ptr %t258, ptr %l129
  br label %bb68
bb67:
  call void @__olang_check_failed(ptr @olang_loc_97840d8df2a94e80_8f65c6ae19d7bb5c)
  unreachable
bb68:
  %t259 = load ptr, ptr %l129, !tbaa !29
  %t260 = load ptr, ptr %l0, !tbaa !29
  store ptr %t260, ptr %l130, !tbaa !29
  %t261 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t261, ptr %l131
  %t262 = load ptr, ptr %l2, !tbaa !29
  store ptr %t262, ptr %l132, !tbaa !29
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t265 = load i32, ptr %l3, !tbaa !23
  %t266 = load %"compiler/source:Span", ptr %l1
  %t271 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v0, ptr %v0, ptr %t263, ptr %t259, i32 %t265, %"compiler/source:Span" %t266)
  store ptr %t271, ptr %l137
  br label %bb69
bb69:
  store { i64, [3 x i64] } zeroinitializer, ptr %t272
  %t273 = getelementptr { i64, [3 x i64] }, ptr %t272, i32 0, i32 0
  store i64 1, ptr %t273
  %t274 = load %"compiler/source:Span", ptr %l131
  %t275 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t274, 0
  %t276 = load ptr, ptr %l132, !tbaa !29
  %t277 = insertvalue { %"compiler/source:Span", ptr, ptr } %t275, ptr %t276, 1
  %t278 = load ptr, ptr %l137, !tbaa !29
  %t279 = insertvalue { %"compiler/source:Span", ptr, ptr } %t277, ptr %t278, 2
  %t280 = getelementptr { i64, [3 x i64] }, ptr %t272, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t279, ptr %t280
  %t281 = load { i64, [3 x i64] }, ptr %t272
  %t283 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t281, ptr %t283
  %t284 = load ptr, ptr %l130, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t284, ptr %t283)
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esuppliedAtomic(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, ptr %a4, i32 %a5, i32 %a6, { i64, ptr } %a7, { i64, ptr } %a8) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i32
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l20 = alloca i1
  %l23 = alloca i1
  %l26 = alloca i1
  %l29 = alloca i1
  %l32 = alloca i1
  %l39 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca %"compiler/source:Span"
  %l45 = alloca { i64, ptr }
  %l47 = alloca %"compiler/diagmsg:Msg"
  %l48 = alloca i64
  %l51 = alloca ptr
  %l55 = alloca ptr
  %l56 = alloca %"compiler/source:Span"
  %l59 = alloca { i64, ptr }
  %l61 = alloca %"compiler/diagmsg:Msg"
  %l62 = alloca i64
  %l65 = alloca ptr
  %l68 = alloca ptr
  %l71 = alloca ptr
  %l74 = alloca %"compiler/source:Span"
  %l75 = alloca %"compiler/diagmsg:Msg"
  %l76 = alloca i64
  %l79 = alloca ptr
  %l81 = alloca ptr
  %l82 = alloca ptr
  %l85 = alloca %"compiler/source:Span"
  %l86 = alloca i1
  %l89 = alloca ptr
  %l99 = alloca i1
  %l102 = alloca i1
  %l104 = alloca ptr
  %l107 = alloca %"compiler/source:Span"
  %l108 = alloca %"compiler/diagmsg:Msg"
  %l109 = alloca i64
  %l112 = alloca ptr
  %l118 = alloca ptr
  %l119 = alloca %"compiler/source:Span"
  %l120 = alloca i64
  %l123 = alloca { i64, ptr }
  %l126 = alloca %"compiler/diagmsg:Msg"
  %l127 = alloca i64
  %l130 = alloca ptr
  %l134 = alloca i64
  %l136 = alloca ptr
  %l137 = alloca %"compiler/source:Span"
  %l143 = alloca i32
  %l154 = alloca { i64, ptr }
  %l158 = alloca ptr
  %l162 = alloca ptr
  %l168 = alloca i32
  %l171 = alloca %"compiler/source:Span"
  %l172 = alloca i32
  %l173 = alloca i32
  %l174 = alloca i32
  %l178 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %rv = alloca ptr
  %t234 = alloca { i64, [5 x i64] }, align 8
  %t307 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i32 %a5, ptr %l5
  store i32 %a6, ptr %l6
  store { i64, ptr } %a7, ptr %l7
  store { i64, ptr } %a8, ptr %l8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 24, ptr %l9
  store i64 0, ptr %l10, !tbaa !24
  %t2 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t4 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t2, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d42, i32 0, i32 1) })
  store i1 %t4, ptr %l20
  br label %bb1
bb1:
  %t5 = load i1, ptr %l20, !tbaa !21
  br i1 %t5, label %bb2, label %bb3
bb2:
  store i32 25, ptr %l9
  store i64 1, ptr %l10, !tbaa !24
  br label %bb20
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t9 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s2, { i64, ptr } %t7, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d43, i32 0, i32 1) })
  store i1 %t9, ptr %l23
  br label %bb4
bb4:
  %t10 = load i1, ptr %l23, !tbaa !21
  br i1 %t10, label %bb5, label %bb6
bb5:
  store i32 26, ptr %l9
  store i64 1, ptr %l10, !tbaa !24
  br label %bb19
bb6:
  store %olang.scope zeroinitializer, ptr %s4
  %t12 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t14 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s4, { i64, ptr } %t12, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d44, i32 0, i32 1) })
  store i1 %t14, ptr %l26
  br label %bb7
bb7:
  %t15 = load i1, ptr %l26, !tbaa !21
  br i1 %t15, label %bb8, label %bb9
bb8:
  store i32 27, ptr %l9
  store i64 1, ptr %l10, !tbaa !24
  br label %bb18
bb9:
  store %olang.scope zeroinitializer, ptr %s6
  %t17 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s6, { i64, ptr } %t17, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d45, i32 0, i32 1) })
  store i1 %t19, ptr %l29
  br label %bb10
bb10:
  %t20 = load i1, ptr %l29, !tbaa !21
  br i1 %t20, label %bb11, label %bb12
bb11:
  store i32 28, ptr %l9
  store i64 2, ptr %l10, !tbaa !24
  br label %bb17
bb12:
  store %olang.scope zeroinitializer, ptr %s8
  %t22 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t24 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s8, { i64, ptr } %t22, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d46, i32 0, i32 1) })
  store i1 %t24, ptr %l32
  br label %bb13
bb13:
  %t25 = load i1, ptr %l32, !tbaa !21
  %t26 = xor i1 %t25, true
  br i1 %t26, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s8)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s6)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s4)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb20:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  %t35 = load i32, ptr %l6, !tbaa !23
  %t38 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t34, i32 %t35)
  store i1 %t38, ptr %l39
  br label %bb21
bb21:
  %t39 = load i1, ptr %l39, !tbaa !21
  %t40 = xor i1 %t39, true
  br i1 %t40, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s10
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l41, !tbaa !29
  %t43 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t43, ptr %l42
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load i32, ptr %l5, !tbaa !23
  %t48 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s10, ptr %t44, i32 %t45)
  store { i64, ptr } %t48, ptr %l45
  br label %bb24
bb23:
  br label %bb28
bb24:
  %t49 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t51 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAtomicNotInteger(ptr %s10, ptr %v0, { i64, ptr } %t49)
  store %"compiler/diagmsg:Msg" %t51, ptr %l47
  br label %bb25
bb25:
  %t52 = load ptr, ptr %l41, !tbaa !29
  %t53 = load %"compiler/source:Span", ptr %l42
  %t54 = load %"compiler/diagmsg:Msg", ptr %l47
  %t55 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t52, %"compiler/source:Span" %t53, %"compiler/diagmsg:Msg" %t54)
  store i64 %t55, ptr %l48
  br label %bb26
bb26:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load %"compiler/source:Span", ptr %l1
  %t60 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v5, ptr %t56, %"compiler/source:Span" %t57)
  store ptr %t60, ptr %l51
  br label %bb27
bb27:
  %t61 = load ptr, ptr %l51, !tbaa !29
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t61, ptr %rv
  br label %ret
bb28:
  %t63 = load i32, ptr %l6, !tbaa !23
  %t65 = icmp sgt i32 %t63, 14
  br i1 %t65, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s11
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l55, !tbaa !29
  %t68 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t68, ptr %l56
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i32, ptr %l5, !tbaa !23
  %t73 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s11, ptr %t69, i32 %t70)
  store { i64, ptr } %t73, ptr %l59
  br label %bb31
bb30:
  br label %bb35
bb31:
  %t74 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t76 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAtomicWidth(ptr %s11, ptr %v0, { i64, ptr } %t74)
  store %"compiler/diagmsg:Msg" %t76, ptr %l61
  br label %bb32
bb32:
  %t77 = load ptr, ptr %l55, !tbaa !29
  %t78 = load %"compiler/source:Span", ptr %l56
  %t79 = load %"compiler/diagmsg:Msg", ptr %l61
  %t80 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t77, %"compiler/source:Span" %t78, %"compiler/diagmsg:Msg" %t79)
  store i64 %t80, ptr %l62
  br label %bb33
bb33:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load %"compiler/source:Span", ptr %l1
  %t85 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v5, ptr %t81, %"compiler/source:Span" %t82)
  store ptr %t85, ptr %l65
  br label %bb34
bb34:
  %t86 = load ptr, ptr %l65, !tbaa !29
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t86, ptr %rv
  br label %ret
bb35:
  %t90 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v2, ptr %v5, ptr %a4)
  store ptr %t90, ptr %l68
  br label %bb36
bb36:
  %t91 = load ptr, ptr %l68, !tbaa !29
  store ptr %t91, ptr %l11, !tbaa !29
  %t92 = load ptr, ptr %l11, !tbaa !29
  %t94 = icmp eq ptr %t92, null
  br i1 %t94, label %bb37, label %bb38
bb37:
  %t96 = load ptr, ptr %l0, !tbaa !29
  store ptr %t96, ptr %l71, !tbaa !29
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load ptr, ptr %l3, !tbaa !29
  %t101 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperandAt(ptr %v0, ptr %v1, ptr %t97, ptr %t98)
  store %"compiler/source:Span" %t101, ptr %l74
  br label %bb39
bb38:
  br label %bb43
bb39:
  %t102 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAtomicNotPlace(ptr %v0)
  store %"compiler/diagmsg:Msg" %t102, ptr %l75
  br label %bb40
bb40:
  %t103 = load ptr, ptr %l71, !tbaa !29
  %t104 = load %"compiler/source:Span", ptr %l74
  %t105 = load %"compiler/diagmsg:Msg", ptr %l75
  %t106 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t103, %"compiler/source:Span" %t104, %"compiler/diagmsg:Msg" %t105)
  store i64 %t106, ptr %l76
  br label %bb41
bb41:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load %"compiler/source:Span", ptr %l1
  %t111 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v5, ptr %t107, %"compiler/source:Span" %t108)
  store ptr %t111, ptr %l79
  br label %bb42
bb42:
  %t112 = load ptr, ptr %l79, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t112, ptr %rv
  br label %ret
bb43:
  %t114 = load ptr, ptr %l0, !tbaa !29
  store ptr %t114, ptr %l81, !tbaa !29
  %t115 = load ptr, ptr %l11, !tbaa !29
  store ptr %t115, ptr %l82, !tbaa !29
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load ptr, ptr %l3, !tbaa !29
  %t120 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperandAt(ptr %v0, ptr %v1, ptr %t116, ptr %t117)
  store %"compiler/source:Span" %t120, ptr %l85
  br label %bb44
bb44:
  %t121 = load ptr, ptr %l81, !tbaa !29
  %t122 = load ptr, ptr %l82, !tbaa !29
  %t123 = load %"compiler/source:Span", ptr %l85
  %t124 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elendsPacked(ptr %v0, ptr %v5, ptr %t121, ptr %t122, %"compiler/source:Span" %t123)
  store i1 %t124, ptr %l86
  br label %bb45
bb45:
  %t125 = load i1, ptr %l86, !tbaa !21
  br i1 %t125, label %bb46, label %bb47
bb46:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load %"compiler/source:Span", ptr %l1
  %t130 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v5, ptr %t126, %"compiler/source:Span" %t127)
  store ptr %t130, ptr %l89
  br label %bb48
bb47:
  br label %bb49
bb48:
  %t131 = load ptr, ptr %l89, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t131, ptr %rv
  br label %ret
bb49:
  %t133 = load i32, ptr %l9, !range !{i32 0, i32 54}
  %t135 = trunc i64 24 to i32
  %t136 = icmp eq i32 %t133, %t135
  %t138 = xor i1 %t136, true
  br i1 %t138, label %bb50, label %bb51
bb50:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteWrite(ptr %v0, ptr %v5, ptr %t140, ptr %t141)
  br label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb53
bb53:
  %t144 = load i32, ptr %l9, !range !{i32 0, i32 54}
  %t146 = trunc i64 24 to i32
  %t147 = icmp eq i32 %t144, %t146
  %t149 = xor i1 %t147, true
  br i1 %t149, label %bb54, label %bb55
bb54:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load ptr, ptr %l11, !tbaa !29
  %t155 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceWritable(ptr %v0, ptr %v5, ptr %t151, ptr %t152)
  store i1 %t155, ptr %l102
  br label %bb56
bb55:
  store i1 false, ptr %l99, !tbaa !21
  br label %bb57
bb56:
  %t156 = load i1, ptr %l102, !tbaa !21
  %t157 = xor i1 %t156, true
  store i1 %t157, ptr %l99, !tbaa !21
  br label %bb57
bb57:
  %t159 = load i1, ptr %l99, !tbaa !21
  br i1 %t159, label %bb58, label %bb59
bb58:
  %t160 = load ptr, ptr %l0, !tbaa !29
  store ptr %t160, ptr %l104, !tbaa !29
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load ptr, ptr %l3, !tbaa !29
  %t165 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperandAt(ptr %v0, ptr %v1, ptr %t161, ptr %t162)
  store %"compiler/source:Span" %t165, ptr %l107
  br label %bb60
bb59:
  br label %bb64
bb60:
  %t166 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAtomicNotWritable(ptr %v0)
  store %"compiler/diagmsg:Msg" %t166, ptr %l108
  br label %bb61
bb61:
  %t167 = load ptr, ptr %l104, !tbaa !29
  %t168 = load %"compiler/source:Span", ptr %l107
  %t169 = load %"compiler/diagmsg:Msg", ptr %l108
  %t170 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t167, %"compiler/source:Span" %t168, %"compiler/diagmsg:Msg" %t169)
  store i64 %t170, ptr %l109
  br label %bb62
bb62:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load %"compiler/source:Span", ptr %l1
  %t175 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v5, ptr %t171, %"compiler/source:Span" %t172)
  store ptr %t175, ptr %l112
  br label %bb63
bb63:
  %t176 = load ptr, ptr %l112, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t176, ptr %rv
  br label %ret
bb64:
  %t178 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t181 = load i64, ptr %l10, !tbaa !24
  %t184 = icmp ne i64 %t180, %t181
  br i1 %t184, label %bb65, label %bb66
bb65:
  store %olang.scope zeroinitializer, ptr %s16
  %t186 = load ptr, ptr %l0, !tbaa !29
  store ptr %t186, ptr %l118, !tbaa !29
  %t187 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t187, ptr %l119
  %t188 = load i64, ptr %l10, !tbaa !24
  store i64 %t188, ptr %l120, !tbaa !24
  %t189 = load i64, ptr %l10, !tbaa !24
  %t191 = icmp eq i64 %t189, 1
  br i1 %t191, label %bb67, label %bb68
bb66:
  br label %bb73
bb67:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d47, i32 0, i32 1) }, ptr %l123, !tbaa !27
  br label %bb69
bb68:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d48, i32 0, i32 1) }, ptr %l123, !tbaa !27
  br label %bb69
bb69:
  %t193 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t195 = extractvalue { i64, ptr } %t193, 0
  %t196 = load i64, ptr %l120, !tbaa !24
  %t197 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t199 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArgCount(ptr %s16, ptr %v0, i64 %t196, { i64, ptr } %t197, i64 %t195)
  store %"compiler/diagmsg:Msg" %t199, ptr %l126
  br label %bb70
bb70:
  %t200 = load ptr, ptr %l118, !tbaa !29
  %t201 = load %"compiler/source:Span", ptr %l119
  %t202 = load %"compiler/diagmsg:Msg", ptr %l126
  %t203 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t200, %"compiler/source:Span" %t201, %"compiler/diagmsg:Msg" %t202)
  store i64 %t203, ptr %l127
  br label %bb71
bb71:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t205 = load %"compiler/source:Span", ptr %l1
  %t208 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v5, ptr %t204, %"compiler/source:Span" %t205)
  store ptr %t208, ptr %l130
  br label %bb72
bb72:
  %t209 = load ptr, ptr %l130, !tbaa !29
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t209, ptr %rv
  br label %ret
bb73:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/check:Checker", ptr %t211, i32 0, i32 47
  %t215 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t213)
  store i64 %t215, ptr %l134
  br label %bb74
bb74:
  %t216 = load i64, ptr %l134, !tbaa !24
  store i64 %t216, ptr %l12, !tbaa !24
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t219 = getelementptr %"compiler/check:Checker", ptr %t217, i32 0, i32 47
  store ptr %t219, ptr %l136, !tbaa !29
  %t220 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t220, ptr %l137
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr %"compiler/check:Checker", ptr %t221, i32 0, i32 1
  %t224 = load ptr, ptr %t223, !tbaa !29
  %t226 = getelementptr %"compiler/generic:Program", ptr %t224, i32 0, i32 2
  %t227 = load i32, ptr %l5, !tbaa !23
  %t228 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t232 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t226, i32 %t227, i64 %t228)
  store i32 %t232, ptr %l143
  br label %bb75
bb75:
  %t233 = load ptr, ptr %l11, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t234
  %t235 = getelementptr { i64, [5 x i64] }, ptr %t234, i32 0, i32 0
  store i64 3, ptr %t235
  %t236 = load %"compiler/source:Span", ptr %l137
  %t237 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t236, 0
  %t238 = load i32, ptr %l143, !tbaa !23
  %t239 = insertvalue { %"compiler/source:Span", i32, ptr } %t237, i32 %t238, 1
  %t241 = insertvalue { %"compiler/source:Span", i32, ptr } %t239, ptr %t233, 2
  %t242 = getelementptr { i64, [5 x i64] }, ptr %t234, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t241, ptr %t242
  %t243 = load { i64, [5 x i64] }, ptr %t234
  %t245 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t243, ptr %t245
  %t246 = load ptr, ptr %l136, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t246, ptr %t245)
  br label %bb76
bb76:
  %t248 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t248, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t250 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t252 = extractvalue { i64, ptr } %t250, 0
  store i64 %t252, ptr %l15, !tbaa !24
  br label %bb77
bb77:
  %t254 = load i64, ptr %l14, !tbaa !24
  %t255 = load i64, ptr %l15, !tbaa !24
  %t258 = icmp slt i64 %t254, %t255
  %t260 = xor i1 %t258, true
  br i1 %t260, label %bb78, label %bb79
bb78:
  br label %bb84
bb79:
  br label %bb80
bb80:
  %t262 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t262, ptr %l154, !tbaa !27
  %t263 = load i64, ptr %l14, !tbaa !24
  %t265 = getelementptr { i64, ptr }, ptr %l154, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !27
  %t267 = getelementptr ptr, ptr %t266, i64 %t263
  %t268 = load ptr, ptr %t267, !tbaa !39
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t272 = getelementptr %"compiler/check:Checker", ptr %t270, i32 0, i32 47
  store ptr %t272, ptr %l158, !tbaa !29
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = load i32, ptr %l5, !tbaa !23
  %t279 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v4, ptr %v0, ptr %t273, ptr %t268, i32 %t275)
  store ptr %t279, ptr %l162
  br label %bb81
bb81:
  %t280 = load ptr, ptr %l158, !tbaa !29
  %t281 = load ptr, ptr %l162, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t280, ptr %t281)
  br label %bb82
bb82:
  br label %bb83
bb83:
  %t282 = load i64, ptr %l14, !tbaa !24
  %t285 = add i64 %t282, 1
  store i64 %t285, ptr %l14, !tbaa !24
  br label %bb77
bb84:
  %t287 = load i32, ptr %l9, !range !{i32 0, i32 54}
  %t289 = trunc i64 25 to i32
  %t290 = icmp eq i32 %t287, %t289
  br i1 %t290, label %bb85, label %bb86
bb85:
  %t292 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t292, ptr %l168, !tbaa !23
  br label %bb87
bb86:
  %t294 = load i32, ptr %l5, !tbaa !23
  store i32 %t294, ptr %l168, !tbaa !23
  br label %bb87
bb87:
  %t296 = load i32, ptr %l168, !tbaa !23
  %t297 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t297, ptr %l171
  store i32 %t296, ptr %l172, !tbaa !23
  %t299 = load i32, ptr %l9, !range !{i32 0, i32 54}
  store i32 %t299, ptr %l173
  store i32 0, ptr %l174
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t302 = getelementptr %"compiler/check:Checker", ptr %t300, i32 0, i32 47
  %t303 = load i64, ptr %l12, !tbaa !24
  %t306 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v5, ptr %t302, i64 %t303)
  store { i64, ptr } %t306, ptr %l178
  br label %bb88
bb88:
  store { i64, [5 x i64] } zeroinitializer, ptr %t307
  %t308 = getelementptr { i64, [5 x i64] }, ptr %t307, i32 0, i32 0
  store i64 9, ptr %t308
  %t309 = load %"compiler/source:Span", ptr %l171
  %t310 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } undef, %"compiler/source:Span" %t309, 0
  %t311 = load i32, ptr %l172, !tbaa !23
  %t312 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t310, i32 %t311, 1
  %t313 = load i32, ptr %l173, !range !{i32 0, i32 54}
  %t314 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t312, i32 %t313, 2
  %t315 = load i32, ptr %l174, !range !{i32 0, i32 4}
  %t316 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t314, i32 %t315, 3
  %t317 = load { i64, ptr }, ptr %l178, !tbaa !27
  %t318 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t316, { i64, ptr } %t317, 4
  %t319 = getelementptr { i64, [5 x i64] }, ptr %t307, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t318, ptr %t319
  %t320 = load { i64, [5 x i64] }, ptr %t307
  %t322 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 48, i64 8)
  store { i64, [5 x i64] } %t320, ptr %t322
  call void @__olang_scope_close(ptr %s0)
  store ptr %t322, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopBody(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca i64
  %l11 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i64
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca ptr
  %l29 = alloca { i64, [2 x i64] }
  %l34 = alloca i32
  %l37 = alloca i64
  %l45 = alloca ptr
  %l46 = alloca ptr
  %l47 = alloca i64
  %l50 = alloca %"compiler/generic:Context"
  %l52 = alloca %"compiler/generic:Context"
  %l63 = alloca ptr
  %l66 = alloca i32
  %l69 = alloca i64
  %l73 = alloca ptr
  %l76 = alloca ptr
  %l77 = alloca ptr
  %l82 = alloca ptr
  %l85 = alloca ptr
  %l94 = alloca ptr
  %l95 = alloca ptr
  %l99 = alloca { i64, ptr }
  %l100 = alloca %"compiler/typed:Block"
  %l108 = alloca i64
  %l111 = alloca i1
  %l114 = alloca i64
  %l117 = alloca i1
  %l125 = alloca ptr
  %rv = alloca i64
  %t35 = alloca { i64, [2 x i64] }, align 8
  %t86 = alloca %"compiler/generic:Context", align 8
  %t336 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 4
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l4, !tbaa !29
  %t12 = load ptr, ptr %l4, !tbaa !29
  %t14 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t12)
  store i64 %t14, ptr %l18
  br label %bb1
bb1:
  %t15 = load i64, ptr %l18, !tbaa !24
  store i64 %t15, ptr %l5, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 20
  %t20 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2eLen_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %t18)
  store i64 %t20, ptr %l21
  br label %bb2
bb2:
  %t21 = load i64, ptr %l21, !tbaa !24
  store i64 %t21, ptr %l6, !tbaa !24
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 159
  %t25 = load i64, ptr %t24, !tbaa !24
  store i64 %t25, ptr %l7, !tbaa !24
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t29 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t27)
  store %"compiler/source:Span" %t29, ptr %l25
  br label %bb3
bb3:
  %t30 = load %"compiler/source:Span", ptr %l25
  store %"compiler/source:Span" %t30, ptr %l8
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l26, !tbaa !29
  %t32 = load i64, ptr %l1, !tbaa !24
  %t33 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 0
  %t34 = load i32, ptr %t33, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t35
  %t36 = getelementptr { i64, [2 x i64] }, ptr %t35, i32 0, i32 0
  store i64 7, ptr %t36
  %t38 = insertvalue { i64, i32 } undef, i64 %t32, 0
  %t40 = insertvalue { i64, i32 } %t38, i32 %t34, 1
  %t41 = getelementptr { i64, [2 x i64] }, ptr %t35, i32 0, i32 1
  store { i64, i32 } %t40, ptr %t41
  %t42 = load { i64, [2 x i64] }, ptr %t35
  store { i64, [2 x i64] } %t42, ptr %l29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/generic:Program", ptr %t46, i32 0, i32 2
  %t49 = load i32, ptr %l3, !tbaa !23
  %t52 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t48, i32 0, i32 %t49, i32 0, i32 0, i64 0, i1 false, i32 0, i64 0)
  store i32 %t52, ptr %l34
  br label %bb4
bb4:
  %t53 = load i64, ptr %l1, !tbaa !24
  %t54 = load %"compiler/source:Span", ptr %l8
  %t55 = load ptr, ptr %l26, !tbaa !29
  %t56 = load { i64, [2 x i64] }, ptr %l29
  %t57 = load i32, ptr %l34, !tbaa !23
  %t60 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t55, { i64, [2 x i64] } %t56, i32 %t57, i64 %t53, %"compiler/source:Span" %t54)
  store i64 %t60, ptr %l37
  br label %bb5
bb5:
  %t61 = load i64, ptr %l37, !tbaa !24
  store i64 %t61, ptr %l9, !tbaa !24
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 24
  %t65 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t64, i64 %t65, i64 1)
  br label %bb6
bb6:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i64, ptr %l9, !tbaa !24
  %t70 = load i64, ptr %l1, !tbaa !24
  %t71 = load i32, ptr %l3, !tbaa !23
  %t76 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v0, ptr %t68, i64 %t69, i64 %t70, i32 %t71, i32 0)
  store ptr %t76, ptr %l45
  br label %bb7
bb7:
  %t77 = load ptr, ptr %l45, !tbaa !29
  store ptr %t77, ptr %l46, !tbaa !29
  %t79 = call ptr @__olang_scope_hold(ptr %v0)
  %t80 = ptrtoint ptr %t79 to i64
  store i64 %t80, ptr %l47, !tbaa !24
  %t81 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e4
  br i1 %t81, label %bb8, label %bb9
bb8:
  %t83 = call ptr @__olang_region_make(ptr %v0)
  %t84 = ptrtoint ptr %t83 to i64
  store i64 %t84, ptr %l47, !tbaa !24
  br label %bb9
bb9:
  %t85 = load i64, ptr %l1, !tbaa !24
  %t87 = load i64, ptr %l47
  %t88 = inttoptr i64 %t87 to ptr
  call void @compiler_2fgeneric_3aContext_2ector(ptr %t86, ptr %t88, i64 %t85, i64 -1)
  call void @llvm.memmove.p0.p0.i64(ptr %l50, ptr %t86, i64 160, i1 false)
  br label %bb10
bb10:
  %t90 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e4
  br i1 %t90, label %bb11, label %bb12
bb11:
  %t92 = load i64, ptr %l47
  %t93 = inttoptr i64 %t92 to ptr
  %t94 = getelementptr %"compiler/generic:Context", ptr %l50, i32 0, i32 3
  %t95 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t94, i32 0, i32 2
  %t96 = load { i64, ptr }, ptr %t95
  %t97 = extractvalue { i64, ptr } %t96, 1
  %t98 = call ptr @__olang_region_or(ptr %t97, ptr null)
  %t99 = call ptr @__olang_region_home(ptr %t98)
  %t100 = icmp ne ptr %t99, null
  %t101 = select i1 %t100, ptr %t99, ptr null
  %t102 = getelementptr %"compiler/generic:Context", ptr %l50, i32 0, i32 3
  %t103 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t102, i32 0, i32 1
  %t104 = load { i64, ptr }, ptr %t103
  %t105 = extractvalue { i64, ptr } %t104, 1
  %t106 = call ptr @__olang_region_or(ptr %t105, ptr null)
  %t107 = call ptr @__olang_region_home(ptr %t106)
  %t108 = icmp ne ptr %t107, null
  %t109 = select i1 %t108, ptr %t107, ptr %t101
  %t110 = getelementptr %"compiler/generic:Context", ptr %l50, i32 0, i32 3
  %t111 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t110, i32 0, i32 0
  %t112 = load { i64, ptr }, ptr %t111
  %t113 = extractvalue { i64, ptr } %t112, 1
  %t114 = call ptr @__olang_region_or(ptr %t113, ptr null)
  %t115 = call ptr @__olang_region_home(ptr %t114)
  %t116 = icmp ne ptr %t115, null
  %t117 = select i1 %t116, ptr %t115, ptr %t109
  %t118 = getelementptr %"compiler/generic:Context", ptr %l50, i32 0, i32 2
  %t119 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t118, i32 0, i32 2
  %t120 = load { i64, ptr }, ptr %t119
  %t121 = extractvalue { i64, ptr } %t120, 1
  %t122 = call ptr @__olang_region_or(ptr %t121, ptr null)
  %t123 = call ptr @__olang_region_home(ptr %t122)
  %t124 = icmp ne ptr %t123, null
  %t125 = select i1 %t124, ptr %t123, ptr %t117
  %t126 = getelementptr %"compiler/generic:Context", ptr %l50, i32 0, i32 2
  %t127 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t126, i32 0, i32 1
  %t128 = load { i64, ptr }, ptr %t127
  %t129 = extractvalue { i64, ptr } %t128, 1
  %t130 = call ptr @__olang_region_or(ptr %t129, ptr null)
  %t131 = call ptr @__olang_region_home(ptr %t130)
  %t132 = icmp ne ptr %t131, null
  %t133 = select i1 %t132, ptr %t131, ptr %t125
  %t134 = getelementptr %"compiler/generic:Context", ptr %l50, i32 0, i32 2
  %t135 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t134, i32 0, i32 0
  %t136 = load { i64, ptr }, ptr %t135
  %t137 = extractvalue { i64, ptr } %t136, 1
  %t138 = call ptr @__olang_region_or(ptr %t137, ptr null)
  %t139 = call ptr @__olang_region_home(ptr %t138)
  %t140 = icmp ne ptr %t139, null
  %t141 = select i1 %t140, ptr %t139, ptr %t133
  call void @__olang_region_settle_in(ptr %t93, ptr %t141)
  br label %bb12
bb12:
  %t142 = load ptr, ptr %l46, !tbaa !29
  %t143 = getelementptr %"compiler/check:frame", ptr %t142, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %l52, ptr %t143, i64 160, i1 false)
  %t144 = load ptr, ptr %l46, !tbaa !29
  %t145 = getelementptr %"compiler/check:frame", ptr %t144, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %t145, ptr %l50, i64 160, i1 false)
  %t146 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e4
  br i1 %t146, label %bb13, label %bb14
bb13:
  %t148 = getelementptr %"compiler/generic:Context", ptr %l52, i32 0, i32 3
  %t149 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t148, i32 0, i32 2
  %t150 = load { i64, ptr }, ptr %t149
  %t151 = extractvalue { i64, ptr } %t150, 1
  %t152 = call ptr @__olang_region_or(ptr %t151, ptr null)
  %t153 = call ptr @__olang_region_home(ptr %t152)
  %t154 = icmp ne ptr %t153, null
  %t155 = select i1 %t154, ptr %t153, ptr null
  %t156 = getelementptr %"compiler/generic:Context", ptr %l52, i32 0, i32 3
  %t157 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t156, i32 0, i32 1
  %t158 = load { i64, ptr }, ptr %t157
  %t159 = extractvalue { i64, ptr } %t158, 1
  %t160 = call ptr @__olang_region_or(ptr %t159, ptr null)
  %t161 = call ptr @__olang_region_home(ptr %t160)
  %t162 = icmp ne ptr %t161, null
  %t163 = select i1 %t162, ptr %t161, ptr %t155
  %t164 = getelementptr %"compiler/generic:Context", ptr %l52, i32 0, i32 3
  %t165 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t164, i32 0, i32 0
  %t166 = load { i64, ptr }, ptr %t165
  %t167 = extractvalue { i64, ptr } %t166, 1
  %t168 = call ptr @__olang_region_or(ptr %t167, ptr null)
  %t169 = call ptr @__olang_region_home(ptr %t168)
  %t170 = icmp ne ptr %t169, null
  %t171 = select i1 %t170, ptr %t169, ptr %t163
  %t172 = getelementptr %"compiler/generic:Context", ptr %l52, i32 0, i32 2
  %t173 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t172, i32 0, i32 2
  %t174 = load { i64, ptr }, ptr %t173
  %t175 = extractvalue { i64, ptr } %t174, 1
  %t176 = call ptr @__olang_region_or(ptr %t175, ptr null)
  %t177 = call ptr @__olang_region_home(ptr %t176)
  %t178 = icmp ne ptr %t177, null
  %t179 = select i1 %t178, ptr %t177, ptr %t171
  %t180 = getelementptr %"compiler/generic:Context", ptr %l52, i32 0, i32 2
  %t181 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t180, i32 0, i32 1
  %t182 = load { i64, ptr }, ptr %t181
  %t183 = extractvalue { i64, ptr } %t182, 1
  %t184 = call ptr @__olang_region_or(ptr %t183, ptr null)
  %t185 = call ptr @__olang_region_home(ptr %t184)
  %t186 = icmp ne ptr %t185, null
  %t187 = select i1 %t186, ptr %t185, ptr %t179
  %t188 = getelementptr %"compiler/generic:Context", ptr %l52, i32 0, i32 2
  %t189 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t188, i32 0, i32 0
  %t190 = load { i64, ptr }, ptr %t189
  %t191 = extractvalue { i64, ptr } %t190, 1
  %t192 = call ptr @__olang_region_or(ptr %t191, ptr null)
  %t193 = call ptr @__olang_region_home(ptr %t192)
  %t194 = icmp ne ptr %t193, null
  %t195 = select i1 %t194, ptr %t193, ptr %t187
  call void @__olang_region_drop(ptr %t195)
  store %"compiler/generic:Context" zeroinitializer, ptr %l52
  br label %bb14
bb14:
  %t196 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aContext_2e2
  br i1 %t196, label %bb15, label %bb16
bb15:
  %t198 = getelementptr %"compiler/generic:Context", ptr %l52, i32 0, i32 2
  %t199 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t198, i32 0, i32 2
  %t200 = load { i64, ptr }, ptr %t199
  %t201 = extractvalue { i64, ptr } %t200, 1
  %t202 = call ptr @__olang_region_or(ptr %t201, ptr null)
  %t203 = call ptr @__olang_region_home(ptr %t202)
  %t204 = icmp ne ptr %t203, null
  %t205 = select i1 %t204, ptr %t203, ptr null
  %t206 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t198, i32 0, i32 1
  %t207 = load { i64, ptr }, ptr %t206
  %t208 = extractvalue { i64, ptr } %t207, 1
  %t209 = call ptr @__olang_region_or(ptr %t208, ptr null)
  %t210 = call ptr @__olang_region_home(ptr %t209)
  %t211 = icmp ne ptr %t210, null
  %t212 = select i1 %t211, ptr %t210, ptr %t205
  %t213 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t198, i32 0, i32 0
  %t214 = load { i64, ptr }, ptr %t213
  %t215 = extractvalue { i64, ptr } %t214, 1
  %t216 = call ptr @__olang_region_or(ptr %t215, ptr null)
  %t217 = call ptr @__olang_region_home(ptr %t216)
  %t218 = icmp ne ptr %t217, null
  %t219 = select i1 %t218, ptr %t217, ptr %t212
  call void @__olang_region_drop(ptr %t219)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" zeroinitializer, ptr %t198
  br label %bb16
bb16:
  %t220 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aContext_2e3
  br i1 %t220, label %bb17, label %bb18
bb17:
  %t222 = getelementptr %"compiler/generic:Context", ptr %l52, i32 0, i32 3
  %t223 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t222, i32 0, i32 2
  %t224 = load { i64, ptr }, ptr %t223
  %t225 = extractvalue { i64, ptr } %t224, 1
  %t226 = call ptr @__olang_region_or(ptr %t225, ptr null)
  %t227 = call ptr @__olang_region_home(ptr %t226)
  %t228 = icmp ne ptr %t227, null
  %t229 = select i1 %t228, ptr %t227, ptr null
  %t230 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t222, i32 0, i32 1
  %t231 = load { i64, ptr }, ptr %t230
  %t232 = extractvalue { i64, ptr } %t231, 1
  %t233 = call ptr @__olang_region_or(ptr %t232, ptr null)
  %t234 = call ptr @__olang_region_home(ptr %t233)
  %t235 = icmp ne ptr %t234, null
  %t236 = select i1 %t235, ptr %t234, ptr %t229
  %t237 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t222, i32 0, i32 0
  %t238 = load { i64, ptr }, ptr %t237
  %t239 = extractvalue { i64, ptr } %t238, 1
  %t240 = call ptr @__olang_region_or(ptr %t239, ptr null)
  %t241 = call ptr @__olang_region_home(ptr %t240)
  %t242 = icmp ne ptr %t241, null
  %t243 = select i1 %t242, ptr %t241, ptr %t236
  call void @__olang_region_drop(ptr %t243)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" zeroinitializer, ptr %t222
  br label %bb18
bb18:
  %t244 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e0
  br i1 %t244, label %bb19, label %bb20
bb19:
  %t246 = getelementptr %"compiler/generic:Context", ptr %l52, i32 0, i32 2
  %t247 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t246, i32 0, i32 0
  %t248 = load { i64, ptr }, ptr %t247
  %t249 = extractvalue { i64, ptr } %t248, 0
  %t250 = extractvalue { i64, ptr } %t248, 1
  call void @__olang_region_release_part(ptr %t250, i64 %t249)
  store { i64, ptr } zeroinitializer, ptr %t247
  br label %bb20
bb20:
  %t251 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e1
  br i1 %t251, label %bb21, label %bb22
bb21:
  %t253 = getelementptr %"compiler/generic:Context", ptr %l52, i32 0, i32 2
  %t254 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t253, i32 0, i32 1
  %t255 = load { i64, ptr }, ptr %t254
  %t256 = extractvalue { i64, ptr } %t255, 0
  %t257 = extractvalue { i64, ptr } %t255, 1
  call void @__olang_region_release_part(ptr %t257, i64 %t256)
  store { i64, ptr } zeroinitializer, ptr %t254
  br label %bb22
bb22:
  %t258 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e2
  br i1 %t258, label %bb23, label %bb24
bb23:
  %t260 = getelementptr %"compiler/generic:Context", ptr %l52, i32 0, i32 2
  %t261 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t260, i32 0, i32 2
  %t262 = load { i64, ptr }, ptr %t261
  %t263 = extractvalue { i64, ptr } %t262, 0
  %t264 = extractvalue { i64, ptr } %t262, 1
  call void @__olang_region_release_part(ptr %t264, i64 %t263)
  store { i64, ptr } zeroinitializer, ptr %t261
  br label %bb24
bb24:
  %t265 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e0
  br i1 %t265, label %bb25, label %bb26
bb25:
  %t267 = getelementptr %"compiler/generic:Context", ptr %l52, i32 0, i32 3
  %t268 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t267, i32 0, i32 0
  %t269 = load { i64, ptr }, ptr %t268
  %t270 = extractvalue { i64, ptr } %t269, 0
  %t271 = extractvalue { i64, ptr } %t269, 1
  call void @__olang_region_release_part(ptr %t271, i64 %t270)
  store { i64, ptr } zeroinitializer, ptr %t268
  br label %bb26
bb26:
  %t272 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e1
  br i1 %t272, label %bb27, label %bb28
bb27:
  %t274 = getelementptr %"compiler/generic:Context", ptr %l52, i32 0, i32 3
  %t275 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t274, i32 0, i32 1
  %t276 = load { i64, ptr }, ptr %t275
  %t277 = extractvalue { i64, ptr } %t276, 0
  %t278 = extractvalue { i64, ptr } %t276, 1
  call void @__olang_region_release_part(ptr %t278, i64 %t277)
  store { i64, ptr } zeroinitializer, ptr %t275
  br label %bb28
bb28:
  %t279 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e2
  br i1 %t279, label %bb29, label %bb30
bb29:
  %t281 = getelementptr %"compiler/generic:Context", ptr %l52, i32 0, i32 3
  %t282 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t281, i32 0, i32 2
  %t283 = load { i64, ptr }, ptr %t282
  %t284 = extractvalue { i64, ptr } %t283, 0
  %t285 = extractvalue { i64, ptr } %t283, 1
  call void @__olang_region_release_part(ptr %t285, i64 %t284)
  store { i64, ptr } zeroinitializer, ptr %t282
  br label %bb30
bb30:
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t288 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t286)
  store ptr %t288, ptr %l63
  br label %bb31
bb31:
  %t289 = load %"compiler/source:Span", ptr %l8
  %t290 = load ptr, ptr %l63, !tbaa !29
  %t293 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %t290, i32 -1, i32 0, %"compiler/source:Span" %t289)
  store i32 %t293, ptr %l66
  br label %bb32
bb32:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t296 = getelementptr %"compiler/check:Checker", ptr %t294, i32 0, i32 48
  %t298 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t296)
  store i64 %t298, ptr %l69
  br label %bb33
bb33:
  %t299 = load i64, ptr %l69, !tbaa !24
  store i64 %t299, ptr %l11, !tbaa !24
  %t300 = load i32, ptr %l3, !tbaa !23
  %t301 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t304 = icmp eq i32 %t300, %t301
  br i1 %t304, label %bb34, label %bb35
bb34:
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t307 = load ptr, ptr %l2, !tbaa !29
  %t310 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd1(ptr %v0, ptr %v1, ptr %v0, ptr %t306, ptr %t307)
  store ptr %t310, ptr %l76
  br label %bb36
bb35:
  %t311 = load ptr, ptr %l0, !tbaa !29
  store ptr %t311, ptr %l77, !tbaa !29
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t313 = load ptr, ptr %l2, !tbaa !29
  %t315 = load i32, ptr %l3, !tbaa !23
  %t319 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t312, ptr %t313, i32 %t315)
  store ptr %t319, ptr %l82
  br label %bb37
bb36:
  %t320 = load ptr, ptr %l76, !tbaa !29
  store ptr %t320, ptr %l73, !tbaa !29
  br label %bb39
bb37:
  %t321 = load i32, ptr %l3, !tbaa !23
  %t322 = load %"compiler/source:Span", ptr %l8
  %t323 = load ptr, ptr %l77, !tbaa !29
  %t324 = load ptr, ptr %l82, !tbaa !29
  %t327 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v0, ptr %v0, ptr %t323, ptr %t324, i32 %t321, %"compiler/source:Span" %t322)
  store ptr %t327, ptr %l85
  br label %bb38
bb38:
  %t328 = load ptr, ptr %l85, !tbaa !29
  store ptr %t328, ptr %l73, !tbaa !29
  br label %bb39
bb39:
  %t329 = load ptr, ptr %l73, !tbaa !29
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t332 = getelementptr %"compiler/check:Checker", ptr %t330, i32 0, i32 48
  %t333 = load %"compiler/source:Span", ptr %l8
  store { i64, [3 x i64] } zeroinitializer, ptr %t336
  %t337 = getelementptr { i64, [3 x i64] }, ptr %t336, i32 0, i32 0
  store i64 6, ptr %t337
  %t339 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t333, 0
  %t341 = insertvalue { %"compiler/source:Span", ptr } %t339, ptr %t329, 1
  %t342 = getelementptr { i64, [3 x i64] }, ptr %t336, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t341, ptr %t342
  %t343 = load { i64, [3 x i64] }, ptr %t336
  %t345 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t343, ptr %t345
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t332, ptr %t345)
  br label %bb40
bb40:
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t350 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t348)
  store ptr %t350, ptr %l94
  br label %bb41
bb41:
  %t351 = load ptr, ptr %l94, !tbaa !29
  store ptr %t351, ptr %l95, !tbaa !29
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t354 = getelementptr %"compiler/check:Checker", ptr %t352, i32 0, i32 48
  %t355 = load i64, ptr %l11, !tbaa !24
  %t358 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t354, i64 %t355)
  store { i64, ptr } %t358, ptr %l99
  br label %bb42
bb42:
  %t359 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t360 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 0, { i64, ptr } %t359)
  store %"compiler/typed:Block" %t360, ptr %l100
  br label %bb43
bb43:
  %t361 = load %"compiler/typed:Block", ptr %l100
  %t362 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Block" %t361, ptr %t362
  %t364 = load ptr, ptr %l95, !tbaa !29
  %t365 = getelementptr %"compiler/typed:Body", ptr %t364, i32 0, i32 11
  store ptr %t362, ptr %t365, !tbaa !29
  %t366 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t366)
  br label %bb44
bb44:
  %t368 = load ptr, ptr %l0, !tbaa !29
  %t370 = getelementptr %"compiler/check:Checker", ptr %t368, i32 0, i32 24
  %t371 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t370, i64 %t371, i64 2)
  br label %bb45
bb45:
  %t374 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edrain(ptr %v0, ptr %t374)
  br label %bb46
bb46:
  %t376 = load ptr, ptr %l4, !tbaa !29
  %t378 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t376)
  store i64 %t378, ptr %l108
  br label %bb47
bb47:
  %t379 = load i64, ptr %l5, !tbaa !24
  %t380 = load i64, ptr %l108, !tbaa !24
  %t382 = icmp sgt i64 %t380, %t379
  br i1 %t382, label %bb48, label %bb49
bb48:
  store i1 true, ptr %l111, !tbaa !21
  br label %bb51
bb49:
  %t384 = load ptr, ptr %l0, !tbaa !29
  %t386 = getelementptr %"compiler/check:Checker", ptr %t384, i32 0, i32 20
  %t388 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2eLen_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %t386)
  store i64 %t388, ptr %l114
  br label %bb50
bb50:
  %t389 = load i64, ptr %l6, !tbaa !24
  %t390 = load i64, ptr %l114, !tbaa !24
  %t392 = icmp sgt i64 %t390, %t389
  store i1 %t392, ptr %l111, !tbaa !21
  br label %bb51
bb51:
  %t394 = load i1, ptr %l111, !tbaa !21
  br i1 %t394, label %bb52, label %bb53
bb52:
  store i1 true, ptr %l117, !tbaa !21
  br label %bb54
bb53:
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t397 = getelementptr %"compiler/check:Checker", ptr %t395, i32 0, i32 159
  %t398 = load i64, ptr %t397, !tbaa !24
  %t399 = load i64, ptr %l7, !tbaa !24
  %t402 = icmp sgt i64 %t398, %t399
  store i1 %t402, ptr %l117, !tbaa !21
  br label %bb54
bb54:
  %t404 = load i1, ptr %l117, !tbaa !21
  br i1 %t404, label %bb55, label %bb56
bb55:
  %t405 = load ptr, ptr %l0, !tbaa !29
  %t407 = getelementptr %"compiler/check:Checker", ptr %t405, i32 0, i32 19
  %t408 = load i64, ptr %l9, !tbaa !24
  %t411 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t407, i64 %t408)
  store ptr %t411, ptr %l125
  br label %bb57
bb56:
  br label %bb58
bb57:
  %t412 = load ptr, ptr %l125, !tbaa !29
  %t414 = getelementptr %"compiler/typed:Body", ptr %t412, i32 0, i32 11
  store ptr null, ptr %t414, !tbaa !29
  store i64 -1, ptr %rv
  br label %ret
bb58:
  %t416 = load i64, ptr %l9, !tbaa !24
  store i64 %t416, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitSets(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l13 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l28 = alloca ptr
  %l34 = alloca i64
  %l37 = alloca ptr
  %l38 = alloca i64
  %l41 = alloca ptr
  %l46 = alloca i32
  %l47 = alloca %"compiler/generic:Context"
  %l49 = alloca %"compiler/generic:Context"
  %l66 = alloca { i64, ptr }
  %l72 = alloca i1
  %l78 = alloca ptr
  %l80 = alloca i32
  %l82 = alloca i32
  %l86 = alloca { i64, ptr }
  %l90 = alloca %"compiler/source:Span"
  %l91 = alloca %"compiler/diagmsg:Msg"
  %l92 = alloca i64
  %l95 = alloca i1
  %l103 = alloca i1
  %s6 = alloca %olang.scope
  %t80 = alloca %"compiler/generic:Context", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/ast:TypeDecl", ptr %t5, i32 0, i32 3
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = icmp eq ptr %t8, null
  store i1 %t10, ptr %l13, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l13, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t15 = getelementptr %"compiler/ast:TypeDecl", ptr %t13, i32 0, i32 3
  %t16 = load ptr, ptr %t15, !tbaa !29
  store ptr %t16, ptr %l3, !tbaa !29
  %t18 = load ptr, ptr %l3, !tbaa !29
  store ptr %t18, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t19 = load ptr, ptr %l19, !tbaa !29
  %t20 = icmp ne ptr %t19, null
  br i1 %t20, label %bb7, label %bb8
bb7:
  %t22 = load ptr, ptr %l19, !tbaa !29
  %t23 = load i64, ptr %t22, !range !{i64 0, i64 5}
  %t25 = icmp eq i64 %t23, 2
  store i1 %t25, ptr %l20, !tbaa !21
  br label %bb8
bb8:
  %t26 = load i1, ptr %l20, !tbaa !21
  br i1 %t26, label %bb9, label %bb10
bb9:
  %t27 = load ptr, ptr %l3, !tbaa !29
  %t29 = getelementptr { i64, [6 x i64] }, ptr %t27, i32 0, i32 1
  %t30 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t29, i32 0, i32 0
  %t31 = load { i64, ptr }, ptr %t30
  store { i64, ptr } %t31, ptr %l4, !tbaa !27
  br label %bb11
bb10:
  br label %bb65
bb11:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i64, ptr %l1, !tbaa !24
  %t35 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t39 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v0, ptr %t33, i64 -1, i64 %t34, i32 %t35, i32 0)
  store ptr %t39, ptr %l28
  br label %bb12
bb12:
  %t40 = load ptr, ptr %l28, !tbaa !29
  store ptr %t40, ptr %l5, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t45 = load i64, ptr %l1, !tbaa !24
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t48 = getelementptr %"compiler/ast:TypeDecl", ptr %t46, i32 0, i32 0
  %t49 = load i32, ptr %t48, !tbaa !23
  %t53 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %t44, i64 %t45, i32 %t49)
  store i64 %t53, ptr %l34
  br label %bb13
bb13:
  %t54 = load i64, ptr %l34, !tbaa !24
  store i64 %t54, ptr %l6, !tbaa !24
  %t55 = load i64, ptr %l6, !tbaa !24
  %t57 = icmp sge i64 %t55, 0
  br i1 %t57, label %bb14, label %bb15
bb14:
  %t59 = load ptr, ptr %l5, !tbaa !29
  store ptr %t59, ptr %l37, !tbaa !29
  %t60 = call ptr @__olang_scope_hold(ptr %v0)
  %t61 = ptrtoint ptr %t60 to i64
  store i64 %t61, ptr %l38, !tbaa !24
  %t62 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e4
  br i1 %t62, label %bb16, label %bb17
bb15:
  br label %bb40
bb16:
  %t64 = call ptr @__olang_region_make(ptr %v0)
  %t65 = ptrtoint ptr %t64 to i64
  store i64 %t65, ptr %l38, !tbaa !24
  br label %bb17
bb17:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/check:Checker", ptr %t66, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !29
  store ptr %t69, ptr %l41, !tbaa !29
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/check:Checker", ptr %t70, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t74 = load i64, ptr %l1, !tbaa !24
  %t75 = load i64, ptr %l6, !tbaa !24
  %t79 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t73, i64 %t74, i64 %t75)
  store i32 %t79, ptr %l46
  br label %bb18
bb18:
  %t81 = load i64, ptr %l38
  %t82 = inttoptr i64 %t81 to ptr
  %t83 = load ptr, ptr %l41, !tbaa !29
  %t84 = load i32, ptr %l46, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclContext(ptr %t80, ptr %v0, ptr %t82, ptr %t83, i32 %t84)
  call void @llvm.memmove.p0.p0.i64(ptr %l47, ptr %t80, i64 160, i1 false)
  br label %bb19
bb19:
  %t85 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e4
  br i1 %t85, label %bb20, label %bb21
bb20:
  %t87 = load i64, ptr %l38
  %t88 = inttoptr i64 %t87 to ptr
  %t89 = getelementptr %"compiler/generic:Context", ptr %l47, i32 0, i32 3
  %t90 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t89, i32 0, i32 2
  %t91 = load { i64, ptr }, ptr %t90
  %t92 = extractvalue { i64, ptr } %t91, 1
  %t93 = call ptr @__olang_region_or(ptr %t92, ptr null)
  %t94 = call ptr @__olang_region_home(ptr %t93)
  %t95 = icmp ne ptr %t94, null
  %t96 = select i1 %t95, ptr %t94, ptr null
  %t97 = getelementptr %"compiler/generic:Context", ptr %l47, i32 0, i32 3
  %t98 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t97, i32 0, i32 1
  %t99 = load { i64, ptr }, ptr %t98
  %t100 = extractvalue { i64, ptr } %t99, 1
  %t101 = call ptr @__olang_region_or(ptr %t100, ptr null)
  %t102 = call ptr @__olang_region_home(ptr %t101)
  %t103 = icmp ne ptr %t102, null
  %t104 = select i1 %t103, ptr %t102, ptr %t96
  %t105 = getelementptr %"compiler/generic:Context", ptr %l47, i32 0, i32 3
  %t106 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t105, i32 0, i32 0
  %t107 = load { i64, ptr }, ptr %t106
  %t108 = extractvalue { i64, ptr } %t107, 1
  %t109 = call ptr @__olang_region_or(ptr %t108, ptr null)
  %t110 = call ptr @__olang_region_home(ptr %t109)
  %t111 = icmp ne ptr %t110, null
  %t112 = select i1 %t111, ptr %t110, ptr %t104
  %t113 = getelementptr %"compiler/generic:Context", ptr %l47, i32 0, i32 2
  %t114 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t113, i32 0, i32 2
  %t115 = load { i64, ptr }, ptr %t114
  %t116 = extractvalue { i64, ptr } %t115, 1
  %t117 = call ptr @__olang_region_or(ptr %t116, ptr null)
  %t118 = call ptr @__olang_region_home(ptr %t117)
  %t119 = icmp ne ptr %t118, null
  %t120 = select i1 %t119, ptr %t118, ptr %t112
  %t121 = getelementptr %"compiler/generic:Context", ptr %l47, i32 0, i32 2
  %t122 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t121, i32 0, i32 1
  %t123 = load { i64, ptr }, ptr %t122
  %t124 = extractvalue { i64, ptr } %t123, 1
  %t125 = call ptr @__olang_region_or(ptr %t124, ptr null)
  %t126 = call ptr @__olang_region_home(ptr %t125)
  %t127 = icmp ne ptr %t126, null
  %t128 = select i1 %t127, ptr %t126, ptr %t120
  %t129 = getelementptr %"compiler/generic:Context", ptr %l47, i32 0, i32 2
  %t130 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t129, i32 0, i32 0
  %t131 = load { i64, ptr }, ptr %t130
  %t132 = extractvalue { i64, ptr } %t131, 1
  %t133 = call ptr @__olang_region_or(ptr %t132, ptr null)
  %t134 = call ptr @__olang_region_home(ptr %t133)
  %t135 = icmp ne ptr %t134, null
  %t136 = select i1 %t135, ptr %t134, ptr %t128
  call void @__olang_region_settle_in(ptr %t88, ptr %t136)
  br label %bb21
bb21:
  %t137 = load ptr, ptr %l37, !tbaa !29
  %t138 = getelementptr %"compiler/check:frame", ptr %t137, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %l49, ptr %t138, i64 160, i1 false)
  %t139 = load ptr, ptr %l37, !tbaa !29
  %t140 = getelementptr %"compiler/check:frame", ptr %t139, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %t140, ptr %l47, i64 160, i1 false)
  %t141 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e4
  br i1 %t141, label %bb22, label %bb23
bb22:
  %t143 = getelementptr %"compiler/generic:Context", ptr %l49, i32 0, i32 3
  %t144 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t143, i32 0, i32 2
  %t145 = load { i64, ptr }, ptr %t144
  %t146 = extractvalue { i64, ptr } %t145, 1
  %t147 = call ptr @__olang_region_or(ptr %t146, ptr null)
  %t148 = call ptr @__olang_region_home(ptr %t147)
  %t149 = icmp ne ptr %t148, null
  %t150 = select i1 %t149, ptr %t148, ptr null
  %t151 = getelementptr %"compiler/generic:Context", ptr %l49, i32 0, i32 3
  %t152 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t151, i32 0, i32 1
  %t153 = load { i64, ptr }, ptr %t152
  %t154 = extractvalue { i64, ptr } %t153, 1
  %t155 = call ptr @__olang_region_or(ptr %t154, ptr null)
  %t156 = call ptr @__olang_region_home(ptr %t155)
  %t157 = icmp ne ptr %t156, null
  %t158 = select i1 %t157, ptr %t156, ptr %t150
  %t159 = getelementptr %"compiler/generic:Context", ptr %l49, i32 0, i32 3
  %t160 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t159, i32 0, i32 0
  %t161 = load { i64, ptr }, ptr %t160
  %t162 = extractvalue { i64, ptr } %t161, 1
  %t163 = call ptr @__olang_region_or(ptr %t162, ptr null)
  %t164 = call ptr @__olang_region_home(ptr %t163)
  %t165 = icmp ne ptr %t164, null
  %t166 = select i1 %t165, ptr %t164, ptr %t158
  %t167 = getelementptr %"compiler/generic:Context", ptr %l49, i32 0, i32 2
  %t168 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t167, i32 0, i32 2
  %t169 = load { i64, ptr }, ptr %t168
  %t170 = extractvalue { i64, ptr } %t169, 1
  %t171 = call ptr @__olang_region_or(ptr %t170, ptr null)
  %t172 = call ptr @__olang_region_home(ptr %t171)
  %t173 = icmp ne ptr %t172, null
  %t174 = select i1 %t173, ptr %t172, ptr %t166
  %t175 = getelementptr %"compiler/generic:Context", ptr %l49, i32 0, i32 2
  %t176 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t175, i32 0, i32 1
  %t177 = load { i64, ptr }, ptr %t176
  %t178 = extractvalue { i64, ptr } %t177, 1
  %t179 = call ptr @__olang_region_or(ptr %t178, ptr null)
  %t180 = call ptr @__olang_region_home(ptr %t179)
  %t181 = icmp ne ptr %t180, null
  %t182 = select i1 %t181, ptr %t180, ptr %t174
  %t183 = getelementptr %"compiler/generic:Context", ptr %l49, i32 0, i32 2
  %t184 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t183, i32 0, i32 0
  %t185 = load { i64, ptr }, ptr %t184
  %t186 = extractvalue { i64, ptr } %t185, 1
  %t187 = call ptr @__olang_region_or(ptr %t186, ptr null)
  %t188 = call ptr @__olang_region_home(ptr %t187)
  %t189 = icmp ne ptr %t188, null
  %t190 = select i1 %t189, ptr %t188, ptr %t182
  call void @__olang_region_drop(ptr %t190)
  store %"compiler/generic:Context" zeroinitializer, ptr %l49
  br label %bb23
bb23:
  %t191 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aContext_2e2
  br i1 %t191, label %bb24, label %bb25
bb24:
  %t193 = getelementptr %"compiler/generic:Context", ptr %l49, i32 0, i32 2
  %t194 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t193, i32 0, i32 2
  %t195 = load { i64, ptr }, ptr %t194
  %t196 = extractvalue { i64, ptr } %t195, 1
  %t197 = call ptr @__olang_region_or(ptr %t196, ptr null)
  %t198 = call ptr @__olang_region_home(ptr %t197)
  %t199 = icmp ne ptr %t198, null
  %t200 = select i1 %t199, ptr %t198, ptr null
  %t201 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t193, i32 0, i32 1
  %t202 = load { i64, ptr }, ptr %t201
  %t203 = extractvalue { i64, ptr } %t202, 1
  %t204 = call ptr @__olang_region_or(ptr %t203, ptr null)
  %t205 = call ptr @__olang_region_home(ptr %t204)
  %t206 = icmp ne ptr %t205, null
  %t207 = select i1 %t206, ptr %t205, ptr %t200
  %t208 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t193, i32 0, i32 0
  %t209 = load { i64, ptr }, ptr %t208
  %t210 = extractvalue { i64, ptr } %t209, 1
  %t211 = call ptr @__olang_region_or(ptr %t210, ptr null)
  %t212 = call ptr @__olang_region_home(ptr %t211)
  %t213 = icmp ne ptr %t212, null
  %t214 = select i1 %t213, ptr %t212, ptr %t207
  call void @__olang_region_drop(ptr %t214)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" zeroinitializer, ptr %t193
  br label %bb25
bb25:
  %t215 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aContext_2e3
  br i1 %t215, label %bb26, label %bb27
bb26:
  %t217 = getelementptr %"compiler/generic:Context", ptr %l49, i32 0, i32 3
  %t218 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t217, i32 0, i32 2
  %t219 = load { i64, ptr }, ptr %t218
  %t220 = extractvalue { i64, ptr } %t219, 1
  %t221 = call ptr @__olang_region_or(ptr %t220, ptr null)
  %t222 = call ptr @__olang_region_home(ptr %t221)
  %t223 = icmp ne ptr %t222, null
  %t224 = select i1 %t223, ptr %t222, ptr null
  %t225 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t217, i32 0, i32 1
  %t226 = load { i64, ptr }, ptr %t225
  %t227 = extractvalue { i64, ptr } %t226, 1
  %t228 = call ptr @__olang_region_or(ptr %t227, ptr null)
  %t229 = call ptr @__olang_region_home(ptr %t228)
  %t230 = icmp ne ptr %t229, null
  %t231 = select i1 %t230, ptr %t229, ptr %t224
  %t232 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t217, i32 0, i32 0
  %t233 = load { i64, ptr }, ptr %t232
  %t234 = extractvalue { i64, ptr } %t233, 1
  %t235 = call ptr @__olang_region_or(ptr %t234, ptr null)
  %t236 = call ptr @__olang_region_home(ptr %t235)
  %t237 = icmp ne ptr %t236, null
  %t238 = select i1 %t237, ptr %t236, ptr %t231
  call void @__olang_region_drop(ptr %t238)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" zeroinitializer, ptr %t217
  br label %bb27
bb27:
  %t239 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e0
  br i1 %t239, label %bb28, label %bb29
bb28:
  %t241 = getelementptr %"compiler/generic:Context", ptr %l49, i32 0, i32 2
  %t242 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t241, i32 0, i32 0
  %t243 = load { i64, ptr }, ptr %t242
  %t244 = extractvalue { i64, ptr } %t243, 0
  %t245 = extractvalue { i64, ptr } %t243, 1
  call void @__olang_region_release_part(ptr %t245, i64 %t244)
  store { i64, ptr } zeroinitializer, ptr %t242
  br label %bb29
bb29:
  %t246 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e1
  br i1 %t246, label %bb30, label %bb31
bb30:
  %t248 = getelementptr %"compiler/generic:Context", ptr %l49, i32 0, i32 2
  %t249 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t248, i32 0, i32 1
  %t250 = load { i64, ptr }, ptr %t249
  %t251 = extractvalue { i64, ptr } %t250, 0
  %t252 = extractvalue { i64, ptr } %t250, 1
  call void @__olang_region_release_part(ptr %t252, i64 %t251)
  store { i64, ptr } zeroinitializer, ptr %t249
  br label %bb31
bb31:
  %t253 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e2
  br i1 %t253, label %bb32, label %bb33
bb32:
  %t255 = getelementptr %"compiler/generic:Context", ptr %l49, i32 0, i32 2
  %t256 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t255, i32 0, i32 2
  %t257 = load { i64, ptr }, ptr %t256
  %t258 = extractvalue { i64, ptr } %t257, 0
  %t259 = extractvalue { i64, ptr } %t257, 1
  call void @__olang_region_release_part(ptr %t259, i64 %t258)
  store { i64, ptr } zeroinitializer, ptr %t256
  br label %bb33
bb33:
  %t260 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e0
  br i1 %t260, label %bb34, label %bb35
bb34:
  %t262 = getelementptr %"compiler/generic:Context", ptr %l49, i32 0, i32 3
  %t263 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t262, i32 0, i32 0
  %t264 = load { i64, ptr }, ptr %t263
  %t265 = extractvalue { i64, ptr } %t264, 0
  %t266 = extractvalue { i64, ptr } %t264, 1
  call void @__olang_region_release_part(ptr %t266, i64 %t265)
  store { i64, ptr } zeroinitializer, ptr %t263
  br label %bb35
bb35:
  %t267 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e1
  br i1 %t267, label %bb36, label %bb37
bb36:
  %t269 = getelementptr %"compiler/generic:Context", ptr %l49, i32 0, i32 3
  %t270 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t269, i32 0, i32 1
  %t271 = load { i64, ptr }, ptr %t270
  %t272 = extractvalue { i64, ptr } %t271, 0
  %t273 = extractvalue { i64, ptr } %t271, 1
  call void @__olang_region_release_part(ptr %t273, i64 %t272)
  store { i64, ptr } zeroinitializer, ptr %t270
  br label %bb37
bb37:
  %t274 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e2
  br i1 %t274, label %bb38, label %bb39
bb38:
  %t276 = getelementptr %"compiler/generic:Context", ptr %l49, i32 0, i32 3
  %t277 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t276, i32 0, i32 2
  %t278 = load { i64, ptr }, ptr %t277
  %t279 = extractvalue { i64, ptr } %t278, 0
  %t280 = extractvalue { i64, ptr } %t278, 1
  call void @__olang_region_release_part(ptr %t280, i64 %t279)
  store { i64, ptr } zeroinitializer, ptr %t277
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t281 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t281, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t283 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t285 = extractvalue { i64, ptr } %t283, 0
  store i64 %t285, ptr %l9, !tbaa !24
  br label %bb41
bb41:
  %t287 = load i64, ptr %l8, !tbaa !24
  %t288 = load i64, ptr %l9, !tbaa !24
  %t291 = icmp slt i64 %t287, %t288
  %t293 = xor i1 %t291, true
  br i1 %t293, label %bb42, label %bb43
bb42:
  br label %bb63
bb43:
  br label %bb44
bb44:
  %t295 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t295, ptr %l66, !tbaa !27
  %t296 = load i64, ptr %l8, !tbaa !24
  %t298 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t299 = load ptr, ptr %t298, !tbaa !27
  %t300 = getelementptr ptr, ptr %t299, i64 %t296
  %t301 = load ptr, ptr %t300, !tbaa !39
  store ptr %t301, ptr %l10, !tbaa !29
  %t303 = load ptr, ptr %l10, !tbaa !29
  %t305 = getelementptr %"compiler/ast:Func", ptr %t303, i32 0, i32 3
  %t306 = load ptr, ptr %t305, !tbaa !29
  %t308 = getelementptr %"compiler/ast:Sig", ptr %t306, i32 0, i32 2
  %t309 = load i1, ptr %t308, !tbaa !21
  br i1 %t309, label %bb45, label %bb46
bb45:
  %t311 = load ptr, ptr %l10, !tbaa !29
  %t313 = getelementptr %"compiler/ast:Func", ptr %t311, i32 0, i32 3
  %t314 = load ptr, ptr %t313, !tbaa !29
  %t316 = getelementptr %"compiler/ast:Sig", ptr %t314, i32 0, i32 3
  %t317 = load { i64, ptr }, ptr %t316, !tbaa !27
  %t319 = extractvalue { i64, ptr } %t317, 0
  %t321 = icmp eq i64 %t319, 0
  store i1 %t321, ptr %l72, !tbaa !21
  br label %bb47
bb46:
  store i1 false, ptr %l72, !tbaa !21
  br label %bb47
bb47:
  %t323 = load i1, ptr %l72, !tbaa !21
  br i1 %t323, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s6
  %t324 = load ptr, ptr %l0, !tbaa !29
  store ptr %t324, ptr %l78, !tbaa !29
  %t325 = load ptr, ptr %l10, !tbaa !29
  %t327 = getelementptr %"compiler/ast:Func", ptr %t325, i32 0, i32 0
  %t328 = getelementptr %"compiler/source:Span", ptr %t327, i32 0, i32 0
  %t329 = load i32, ptr %t328, !tbaa !23
  store i32 %t329, ptr %l80, !tbaa !23
  %t330 = load ptr, ptr %l10, !tbaa !29
  %t332 = getelementptr %"compiler/ast:Func", ptr %t330, i32 0, i32 0
  %t333 = getelementptr %"compiler/source:Span", ptr %t332, i32 0, i32 0
  %t334 = load i32, ptr %t333, !tbaa !23
  store i32 %t334, ptr %l82, !tbaa !23
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t336 = load ptr, ptr %l10, !tbaa !29
  %t338 = getelementptr %"compiler/ast:Func", ptr %t336, i32 0, i32 2
  %t339 = load i32, ptr %t338, !tbaa !23
  %t342 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s6, ptr %t335, i32 %t339)
  store { i64, ptr } %t342, ptr %l86
  br label %bb50
bb49:
  br label %bb54
bb50:
  %t343 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t344 = extractvalue { i64, ptr } %t343, 0
  %t346 = trunc i64 %t344 to i32
  %t347 = load i32, ptr %l82, !tbaa !23
  %t349 = add i32 %t347, %t346
  %t350 = load i32, ptr %l80, !tbaa !23
  %t352 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s6, i32 %t350, i32 %t349)
  store %"compiler/source:Span" %t352, ptr %l90
  br label %bb51
bb51:
  %t353 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTraitErrsUnwritten(ptr %v0)
  store %"compiler/diagmsg:Msg" %t353, ptr %l91
  br label %bb52
bb52:
  %t354 = load ptr, ptr %l78, !tbaa !29
  %t355 = load %"compiler/source:Span", ptr %l90
  %t356 = load %"compiler/diagmsg:Msg", ptr %l91
  %t357 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t354, %"compiler/source:Span" %t355, %"compiler/diagmsg:Msg" %t356)
  store i64 %t357, ptr %l92
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s6)
  br label %bb54
bb54:
  %t358 = load i64, ptr %l6, !tbaa !24
  %t360 = icmp sge i64 %t358, 0
  br i1 %t360, label %bb55, label %bb56
bb55:
  %t362 = load ptr, ptr %l10, !tbaa !29
  %t364 = getelementptr %"compiler/ast:Func", ptr %t362, i32 0, i32 5
  %t365 = load { i64, ptr }, ptr %t364, !tbaa !27
  %t367 = extractvalue { i64, ptr } %t365, 0
  %t369 = icmp eq i64 %t367, 0
  store i1 %t369, ptr %l95, !tbaa !21
  br label %bb57
bb56:
  store i1 false, ptr %l95, !tbaa !21
  br label %bb57
bb57:
  %t371 = load i1, ptr %l95, !tbaa !21
  br i1 %t371, label %bb58, label %bb59
bb58:
  %t372 = load ptr, ptr %l0, !tbaa !29
  %t373 = load ptr, ptr %l10, !tbaa !29
  %t375 = getelementptr %"compiler/ast:Func", ptr %t373, i32 0, i32 3
  %t376 = load ptr, ptr %t375, !tbaa !29
  %t379 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esigWritten(ptr %v0, ptr %v1, ptr %t372, ptr %t376)
  store i1 %t379, ptr %l103
  br label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb61
bb61:
  br label %bb62
bb62:
  %t380 = load i64, ptr %l8, !tbaa !24
  %t383 = add i64 %t380, 1
  store i64 %t383, ptr %l8, !tbaa !24
  br label %bb41
bb63:
  %t385 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t385)
  br label %bb64
bb64:
  br label %bb70
bb65:
  br i1 true, label %bb66, label %bb67
bb66:
  br label %bb68
bb67:
  br label %bb69
bb68:
  br label %bb70
bb69:
  call void @__olang_check_failed(ptr @olang_loc_cc3b7a6e318210b6_464c855cb4a991aa)
  unreachable
bb70:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/check:typeCase" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeCaseOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca %"compiler/generic:Context"
  %l6 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l7 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l8 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l9 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca %"compiler/check:typeCase"
  %l27 = alloca %"compiler/check:typeCase"
  %l28 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca i64
  %l36 = alloca %"compiler/source:Span"
  %l41 = alloca ptr
  %l46 = alloca %"compiler/generic:Context"
  %l49 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l50 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l52 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l53 = alloca i32
  %l55 = alloca i1
  %l61 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l62 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l64 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l65 = alloca i32
  %l67 = alloca i1
  %l72 = alloca i64
  %l76 = alloca i64
  %l79 = alloca i64
  %l97 = alloca ptr
  %l100 = alloca i32
  %l107 = alloca i32
  %l116 = alloca i32
  %l122 = alloca i32
  %l125 = alloca i64
  %l130 = alloca i64
  %l133 = alloca i64
  %l141 = alloca i64
  %l144 = alloca i64
  %l162 = alloca i64
  %l165 = alloca ptr
  %l166 = alloca i64
  %l168 = alloca i64
  %l172 = alloca i32
  %l177 = alloca ptr
  %l178 = alloca i32
  %l183 = alloca i32
  %l184 = alloca i32
  %l187 = alloca i1
  %l188 = alloca i32
  %l190 = alloca i64
  %l193 = alloca %"compiler/check:typeCase"
  %l202 = alloca i32
  %l204 = alloca %"compiler/check:typeCase"
  %l207 = alloca i1
  %l208 = alloca i32
  %l210 = alloca i64
  %l211 = alloca %"compiler/check:typeCase"
  %s0 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca %"compiler/check:typeCase"
  %t37 = alloca %"compiler/generic:Context", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l28
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l28
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epatternNames(ptr %v0, ptr %v1, ptr %s0, ptr %t3, ptr %t4, ptr %l2, i1 false)
  br label %bb2
bb2:
  %t9 = shl i64 1, 40
  %t11 = sub i64 0, %t9
  store i64 %t11, ptr %l34, !tbaa !24
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t12)
  store %"compiler/source:Span" %t14, ptr %l36
  br label %bb3
bb3:
  %t15 = getelementptr %"compiler/source:Span", ptr %l36, i32 0, i32 0
  %t16 = load i32, ptr %t15, !tbaa !23
  %t18 = sext i32 %t16 to i64
  %t19 = load i64, ptr %l34, !tbaa !24
  %t21 = sub i64 %t19, %t18
  store i64 %t21, ptr %l3, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t23)
  store ptr %t25, ptr %l41
  br label %bb4
bb4:
  %t26 = load ptr, ptr %l41, !tbaa !29
  store ptr %t26, ptr %l4, !tbaa !29
  %t27 = load ptr, ptr %l4, !tbaa !29
  %t29 = getelementptr %"compiler/check:frame", ptr %t27, i32 0, i32 4
  %t30 = getelementptr %"compiler/generic:Context", ptr %t29, i32 0, i32 0
  %t31 = load i64, ptr %t30, !tbaa !24
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t34 = getelementptr %"compiler/check:frame", ptr %t32, i32 0, i32 4
  %t35 = getelementptr %"compiler/generic:Context", ptr %t34, i32 0, i32 1
  %t36 = load i64, ptr %t35, !tbaa !24
  call void @compiler_2fgeneric_3aContext_2ector(ptr %t37, ptr %s0, i64 %t31, i64 %t36)
  call void @llvm.memmove.p0.p0.i64(ptr %l46, ptr %t37, i64 160, i1 false)
  br label %bb5
bb5:
  call void @llvm.memmove.p0.p0.i64(ptr %l5, ptr %l46, i64 160, i1 false)
  %t40 = load ptr, ptr %l4, !tbaa !29
  %t42 = getelementptr %"compiler/check:frame", ptr %t40, i32 0, i32 4
  %t43 = getelementptr %"compiler/generic:Context", ptr %t42, i32 0, i32 2
  %t45 = call %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Ha72624ba64524ee3315305b5d1bfb369(ptr %v0, ptr %v0, ptr %t43)
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t45, ptr %l49
  br label %bb6
bb6:
  %t46 = load %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l49
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t46, ptr %l6
  br label %bb7
bb7:
  %t48 = call { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20co_H6cf169b12565f300e9fe11f1c8d55061(ptr %v0, ptr %l6)
  %t49 = extractvalue { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } %t48, 1
  %t50 = extractvalue { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } %t48, 0
  store i32 %t50, ptr %l53
  %t51 = icmp ne i32 %t50, 0
  br i1 %t51, label %bb9, label %ok.52, !prof !99
ok.52:
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t49, ptr %l52
  br label %bb8
bb8:
  %t53 = load %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l52
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t53, ptr %l50
  br label %bb11
bb9:
  %t54 = load i32, ptr %l53, !tbaa !23
  %t55 = ashr i32 %t54, 16
  %t57 = icmp eq i32 %t55, 1
  store i1 %t57, ptr %l55, !tbaa !21
  br label %bb10
bb10:
  br label %bb14
bb11:
  %t58 = load %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l50
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t58, ptr %l7
  %t59 = getelementptr %"compiler/generic:Context", ptr %l5, i32 0, i32 2
  %t60 = getelementptr %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l7, i32 0, i32 0
  %t61 = load i32, ptr %t60, !tbaa !23
  %t62 = getelementptr %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l7, i32 0, i32 1
  %t63 = load i32, ptr %t62, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H943a9bb03970f71acf57214091669a7d(ptr %s0, ptr %t59, i32 %t61, i32 %t63)
  br label %bb12
bb12:
  br label %bb13
bb13:
  br label %bb7
bb14:
  %t67 = load ptr, ptr %l4, !tbaa !29
  %t69 = getelementptr %"compiler/check:frame", ptr %t67, i32 0, i32 4
  %t70 = getelementptr %"compiler/generic:Context", ptr %t69, i32 0, i32 3
  %t72 = call %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Ha72624ba64524ee3315305b5d1bfb369(ptr %v0, ptr %v0, ptr %t70)
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t72, ptr %l61
  br label %bb15
bb15:
  %t73 = load %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l61
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t73, ptr %l8
  br label %bb16
bb16:
  %t75 = call { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20co_H6cf169b12565f300e9fe11f1c8d55061(ptr %v0, ptr %l8)
  %t76 = extractvalue { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } %t75, 1
  %t77 = extractvalue { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } %t75, 0
  store i32 %t77, ptr %l65
  %t78 = icmp ne i32 %t77, 0
  br i1 %t78, label %bb18, label %ok.79, !prof !99
ok.79:
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t76, ptr %l64
  br label %bb17
bb17:
  %t80 = load %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l64
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t80, ptr %l62
  br label %bb20
bb18:
  %t81 = load i32, ptr %l65, !tbaa !23
  %t82 = ashr i32 %t81, 16
  %t84 = icmp eq i32 %t82, 1
  store i1 %t84, ptr %l67, !tbaa !21
  br label %bb19
bb19:
  br label %bb23
bb20:
  %t85 = load %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l62
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t85, ptr %l9
  %t86 = getelementptr %"compiler/generic:Context", ptr %l5, i32 0, i32 3
  %t87 = getelementptr %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l9, i32 0, i32 0
  %t88 = load i32, ptr %t87, !tbaa !23
  %t89 = getelementptr %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l9, i32 0, i32 1
  %t90 = load i32, ptr %t89, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H943a9bb03970f71acf57214091669a7d(ptr %s0, ptr %t86, i32 %t88, i32 %t90)
  br label %bb21
bb21:
  br label %bb22
bb22:
  br label %bb16
bb23:
  store i64 0, ptr %l10, !tbaa !24
  %t95 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l2)
  store i64 %t95, ptr %l72
  br label %bb24
bb24:
  %t96 = load i64, ptr %l72, !tbaa !24
  store i64 %t96, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t97 = load i64, ptr %l11, !tbaa !24
  %t98 = load i64, ptr %l10, !tbaa !24
  %t101 = icmp sgt i64 %t97, %t98
  br i1 %t101, label %bb25, label %bb26
bb25:
  %t103 = load i64, ptr %l12, !tbaa !24
  %t105 = icmp sgt i64 %t103, 0
  br i1 %t105, label %bb27, label %bb28
bb26:
  store i64 0, ptr %l76, !tbaa !24
  br label %bb30
bb27:
  %t107 = load i64, ptr %l11, !tbaa !24
  %t108 = load i64, ptr %l10, !tbaa !24
  %t111 = sub i64 %t107, %t108
  %t112 = load i64, ptr %l12, !tbaa !24
  %t115 = add i64 %t111, %t112
  %t117 = sub i64 %t115, 1
  %t118 = load i64, ptr %l12, !tbaa !24
  %t121 = sdiv i64 %t117, %t118
  store i64 %t121, ptr %l79, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l79, !tbaa !24
  br label %bb29
bb29:
  %t123 = load i64, ptr %l79, !tbaa !24
  store i64 %t123, ptr %l76, !tbaa !24
  br label %bb30
bb30:
  %t124 = load i64, ptr %l76, !tbaa !24
  store i64 %t124, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb31
bb31:
  %t125 = load i64, ptr %l14, !tbaa !24
  %t126 = load i64, ptr %l13, !tbaa !24
  %t129 = icmp slt i64 %t125, %t126
  %t131 = xor i1 %t129, true
  br i1 %t131, label %bb32, label %bb33
bb32:
  br label %bb39
bb33:
  br label %bb34
bb34:
  %t133 = load i64, ptr %l10, !tbaa !24
  %t134 = load i64, ptr %l14, !tbaa !24
  %t135 = load i64, ptr %l12, !tbaa !24
  %t138 = mul i64 %t134, %t135
  %t141 = add i64 %t133, %t138
  store i64 %t141, ptr %l15, !tbaa !24
  %t143 = getelementptr %"compiler/generic:Context", ptr %l5, i32 0, i32 2
  store ptr %t143, ptr %l97, !tbaa !29
  %t144 = load i64, ptr %l15, !tbaa !24
  %t147 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l2, i64 %t144)
  store i32 %t147, ptr %l100
  br label %bb35
bb35:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/check:Checker", ptr %t148, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !29
  %t153 = getelementptr %"compiler/generic:Program", ptr %t151, i32 0, i32 2
  %t154 = load i64, ptr %l3, !tbaa !24
  %t155 = load i64, ptr %l15, !tbaa !24
  %t156 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t161 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eVar(ptr %v0, ptr %t153, i64 %t154, i64 %t155, i64 %t156)
  store i32 %t161, ptr %l107
  br label %bb36
bb36:
  %t162 = load ptr, ptr %l97, !tbaa !29
  %t163 = load i32, ptr %l100, !tbaa !23
  %t164 = load i32, ptr %l107, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H943a9bb03970f71acf57214091669a7d(ptr %s0, ptr %t162, i32 %t163, i32 %t164)
  br label %bb37
bb37:
  br label %bb38
bb38:
  %t165 = load i64, ptr %l14, !tbaa !24
  %t168 = add i64 %t165, 1
  store i64 %t168, ptr %l14, !tbaa !24
  br label %bb31
bb39:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/check:Checker", ptr %t170, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !29
  %t174 = load ptr, ptr %l1, !tbaa !29
  %t179 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %s0, ptr %v1, ptr %t173, ptr %l5, ptr %t174)
  store i32 %t179, ptr %l116
  br label %bb40
bb40:
  %t180 = load i32, ptr %l116, !tbaa !23
  store i32 %t180, ptr %l16, !tbaa !23
  %t181 = load i32, ptr %l16, !tbaa !23
  %t182 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t185 = icmp eq i32 %t181, %t182
  br i1 %t185, label %bb41, label %bb42
bb41:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load ptr, ptr %l1, !tbaa !29
  %t191 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebareDecl(ptr %v0, ptr %v1, ptr %t187, ptr %t188)
  store i32 %t191, ptr %l122
  br label %bb43
bb42:
  br label %bb74
bb43:
  %t192 = load i32, ptr %l122, !tbaa !23
  store i32 %t192, ptr %l17, !tbaa !23
  %t193 = load i32, ptr %l17, !tbaa !23
  %t195 = icmp sge i32 %t193, 0
  br i1 %t195, label %bb44, label %bb45
bb44:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = getelementptr %"compiler/check:Checker", ptr %t197, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !29
  %t202 = getelementptr %"compiler/generic:Program", ptr %t200, i32 0, i32 2
  %t203 = load i32, ptr %l17, !tbaa !23
  %t206 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclParams(ptr %v0, ptr %t202, i32 %t203)
  store i64 %t206, ptr %l130
  br label %bb46
bb45:
  store i64 0, ptr %l125, !tbaa !24
  br label %bb47
bb46:
  %t207 = load i64, ptr %l130, !tbaa !24
  store i64 %t207, ptr %l125, !tbaa !24
  br label %bb47
bb47:
  %t208 = load i64, ptr %l125, !tbaa !24
  store i64 %t208, ptr %l18, !tbaa !24
  %t209 = load i64, ptr %l18, !tbaa !24
  %t211 = icmp sgt i64 %t209, 0
  br i1 %t211, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s9
  %t213 = load i64, ptr %l18, !tbaa !24
  store i64 %t213, ptr %l133, !tbaa !24
  %t214 = load i64, ptr %l133, !tbaa !24
  %t215 = icmp sge i64 %t214, 0
  br i1 %t215, label %bb50, label %bb51
bb49:
  br label %bb73
bb50:
  %t217 = load i64, ptr %l133, !tbaa !24
  %t218 = icmp sle i64 %t217, 2305843009213693951
  br i1 %t218, label %bb52, label %bb53
bb51:
  call void @__olang_check_failed(ptr @olang_loc_894a72349cd7ef67_30624e129d4b77a3)
  unreachable
bb52:
  %t220 = load i64, ptr %l133, !tbaa !24
  %t221 = mul i64 %t220, 4
  %t222 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t221)
  %t223 = insertvalue { i64, ptr } undef, i64 %t220, 0
  %t224 = insertvalue { i64, ptr } %t223, ptr %t222, 1
  store { i64, ptr } %t224, ptr %l19, !tbaa !27
  store i64 0, ptr %l20, !tbaa !24
  %t226 = load i64, ptr %l18, !tbaa !24
  store i64 %t226, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t228 = load i64, ptr %l21, !tbaa !24
  %t229 = load i64, ptr %l20, !tbaa !24
  %t232 = icmp sgt i64 %t228, %t229
  br i1 %t232, label %bb54, label %bb55
bb53:
  call void @__olang_check_failed(ptr @olang_loc_894a72349cd7ef67_30624e129d4b77a3)
  unreachable
bb54:
  %t234 = load i64, ptr %l22, !tbaa !24
  %t236 = icmp sgt i64 %t234, 0
  br i1 %t236, label %bb56, label %bb57
bb55:
  store i64 0, ptr %l141, !tbaa !24
  br label %bb59
bb56:
  %t238 = load i64, ptr %l21, !tbaa !24
  %t239 = load i64, ptr %l20, !tbaa !24
  %t242 = sub i64 %t238, %t239
  %t243 = load i64, ptr %l22, !tbaa !24
  %t246 = add i64 %t242, %t243
  %t248 = sub i64 %t246, 1
  %t249 = load i64, ptr %l22, !tbaa !24
  %t252 = sdiv i64 %t248, %t249
  store i64 %t252, ptr %l144, !tbaa !24
  br label %bb58
bb57:
  store i64 0, ptr %l144, !tbaa !24
  br label %bb58
bb58:
  %t254 = load i64, ptr %l144, !tbaa !24
  store i64 %t254, ptr %l141, !tbaa !24
  br label %bb59
bb59:
  %t255 = load i64, ptr %l141, !tbaa !24
  store i64 %t255, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb60
bb60:
  %t256 = load i64, ptr %l24, !tbaa !24
  %t257 = load i64, ptr %l23, !tbaa !24
  %t260 = icmp slt i64 %t256, %t257
  %t262 = xor i1 %t260, true
  br i1 %t262, label %bb61, label %bb62
bb61:
  br label %bb67
bb62:
  br label %bb63
bb63:
  %t264 = load i64, ptr %l20, !tbaa !24
  %t265 = load i64, ptr %l24, !tbaa !24
  %t266 = load i64, ptr %l22, !tbaa !24
  %t269 = mul i64 %t265, %t266
  %t272 = add i64 %t264, %t269
  store i64 %t272, ptr %l25, !tbaa !24
  %t274 = load i64, ptr %l25, !tbaa !24
  store i64 %t274, ptr %l162, !tbaa !24
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t277 = getelementptr %"compiler/check:Checker", ptr %t275, i32 0, i32 1
  %t278 = load ptr, ptr %t277, !tbaa !29
  %t280 = getelementptr %"compiler/generic:Program", ptr %t278, i32 0, i32 2
  store ptr %t280, ptr %l165, !tbaa !29
  %t281 = load i64, ptr %l3, !tbaa !24
  store i64 %t281, ptr %l166, !tbaa !24
  %t283 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l2)
  store i64 %t283, ptr %l168
  br label %bb64
bb64:
  %t284 = load i64, ptr %l25, !tbaa !24
  %t285 = load i64, ptr %l168, !tbaa !24
  %t287 = add i64 %t285, %t284
  %t288 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t289 = load ptr, ptr %l165, !tbaa !29
  %t290 = load i64, ptr %l166, !tbaa !24
  %t293 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eVar(ptr %v0, ptr %t289, i64 %t290, i64 %t287, i64 %t288)
  store i32 %t293, ptr %l172
  br label %bb65
bb65:
  %t294 = load i32, ptr %l172, !tbaa !23
  %t295 = load i64, ptr %l162, !tbaa !24
  %t296 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t297 = load ptr, ptr %t296, !tbaa !27
  %t298 = getelementptr i32, ptr %t297, i64 %t295
  store i32 %t294, ptr %t298, !tbaa !33
  br label %bb66
bb66:
  %t299 = load i64, ptr %l24, !tbaa !24
  %t302 = add i64 %t299, 1
  store i64 %t302, ptr %l24, !tbaa !24
  br label %bb60
bb67:
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t306 = getelementptr %"compiler/check:Checker", ptr %t304, i32 0, i32 1
  %t307 = load ptr, ptr %t306, !tbaa !29
  store ptr %t307, ptr %l177, !tbaa !29
  %t308 = load i32, ptr %l17, !tbaa !23
  store i32 %t308, ptr %l178, !tbaa !23
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t311 = getelementptr %"compiler/check:Checker", ptr %t309, i32 0, i32 1
  %t312 = load ptr, ptr %t311, !tbaa !29
  %t314 = getelementptr %"compiler/generic:Program", ptr %t312, i32 0, i32 2
  %t315 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t318 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s9, ptr %t314, { i64, ptr } %t315)
  store i32 %t318, ptr %l183
  br label %bb68
bb68:
  %t319 = load ptr, ptr %l177, !tbaa !29
  %t320 = load i32, ptr %l178, !tbaa !23
  %t321 = load i32, ptr %l183, !tbaa !23
  %t322 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstance(ptr %v0, ptr %t319, i32 %t320, i32 %t321)
  store i32 %t322, ptr %l184
  br label %bb69
bb69:
  %t323 = load i32, ptr %l184, !tbaa !23
  store i32 %t323, ptr %l16, !tbaa !23
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t325 = load i32, ptr %l16, !tbaa !23
  %t328 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisTrait(ptr %v0, ptr %t324, i32 %t325)
  store i1 %t328, ptr %l187
  br label %bb70
bb70:
  %t329 = load i32, ptr %l16, !tbaa !23
  store i32 %t329, ptr %l188, !tbaa !23
  %t331 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l2)
  store i64 %t331, ptr %l190
  br label %bb71
bb71:
  %t332 = load i64, ptr %l18, !tbaa !24
  %t333 = load i64, ptr %l190, !tbaa !24
  %t335 = add i64 %t333, %t332
  %t336 = load i1, ptr %l187, !tbaa !21
  %t337 = load i32, ptr %l188, !tbaa !23
  %t339 = call %"compiler/check:typeCase" @compiler_2fcheck_3atypeCase_2ector(ptr %s9, i1 false, i1 %t336, i32 %t337, i64 %t335)
  store %"compiler/check:typeCase" %t339, ptr %l193
  br label %bb72
bb72:
  %t340 = load %"compiler/check:typeCase", ptr %l193
  store %"compiler/check:typeCase" %t340, ptr %l26
  %t341 = load i64, ptr %l3, !tbaa !24
  %t343 = getelementptr %"compiler/check:typeCase", ptr %l26, i32 0, i32 4
  store i64 %t341, ptr %t343, !tbaa !24
  %t344 = getelementptr %"compiler/check:typeCase", ptr %l26, i32 0, i32 5
  store i1 true, ptr %t344, !tbaa !21
  %t345 = load %"compiler/check:typeCase", ptr %l26
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/check:typeCase" %t345, ptr %rv
  br label %ret
bb73:
  br label %bb74
bb74:
  %t347 = load i32, ptr %l16, !tbaa !23
  %t348 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t351 = icmp eq i32 %t347, %t348
  br i1 %t351, label %bb75, label %bb76
bb75:
  store %olang.scope zeroinitializer, ptr %s13
  %t353 = load ptr, ptr %l0, !tbaa !29
  %t354 = load ptr, ptr %l1, !tbaa !29
  %t358 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %t353, ptr %t354)
  store i32 %t358, ptr %l202
  br label %bb77
bb76:
  br label %bb79
bb77:
  %t359 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t361 = call %"compiler/check:typeCase" @compiler_2fcheck_3atypeCase_2ector(ptr %s13, i1 false, i1 false, i32 %t359, i64 0)
  store %"compiler/check:typeCase" %t361, ptr %l204
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  %t362 = load %"compiler/check:typeCase", ptr %l204
  store %"compiler/check:typeCase" %t362, ptr %rv
  br label %ret
bb79:
  %t363 = load ptr, ptr %l0, !tbaa !29
  %t364 = load i32, ptr %l16, !tbaa !23
  %t367 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisTrait(ptr %v0, ptr %t363, i32 %t364)
  store i1 %t367, ptr %l207
  br label %bb80
bb80:
  %t368 = load i32, ptr %l16, !tbaa !23
  store i32 %t368, ptr %l208, !tbaa !23
  %t370 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l2)
  store i64 %t370, ptr %l210
  br label %bb81
bb81:
  %t371 = load i1, ptr %l207, !tbaa !21
  %t372 = load i32, ptr %l208, !tbaa !23
  %t373 = load i64, ptr %l210, !tbaa !24
  %t374 = call %"compiler/check:typeCase" @compiler_2fcheck_3atypeCase_2ector(ptr %s0, i1 false, i1 %t371, i32 %t372, i64 %t373)
  store %"compiler/check:typeCase" %t374, ptr %l211
  br label %bb82
bb82:
  %t375 = load %"compiler/check:typeCase", ptr %l211
  store %"compiler/check:typeCase" %t375, ptr %l27
  %t376 = load i64, ptr %l3, !tbaa !24
  %t378 = getelementptr %"compiler/check:typeCase", ptr %l27, i32 0, i32 4
  store i64 %t376, ptr %t378, !tbaa !24
  %t379 = load %"compiler/check:typeCase", ptr %l27
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/check:typeCase" %t379, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:typeCase", ptr %rv
  ret %"compiler/check:typeCase" %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypedHole(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l5 = alloca %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca %"compiler/names:Entry"
  %l16 = alloca ptr
  %l17 = alloca %"compiler/source:Span"
  %l18 = alloca %"compiler/diagmsg:Msg"
  %l19 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca ptr
  %l28 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l29 = alloca %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed"
  %l31 = alloca %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed"
  %l32 = alloca i32
  %l34 = alloca i1
  %l37 = alloca { i64, ptr }
  %l38 = alloca i1
  %l40 = alloca i1
  %l41 = alloca ptr
  %l44 = alloca i32
  %l46 = alloca i1
  %l51 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l53 = alloca i64
  %l55 = alloca i64
  %l60 = alloca i64
  %l61 = alloca ptr
  %l62 = alloca i64
  %l64 = alloca ptr
  %l66 = alloca ptr
  %l70 = alloca %"compiler/typed:Local"
  %l72 = alloca { i64, ptr }
  %l81 = alloca ptr
  %l83 = alloca ptr
  %l86 = alloca ptr
  %l89 = alloca i64
  %l91 = alloca i64
  %l96 = alloca %"compiler/names:Entry"
  %l99 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca ptr
  %l103 = alloca ptr
  %l107 = alloca i32
  %l109 = alloca i1
  %l110 = alloca ptr
  %l111 = alloca i64
  %l115 = alloca { i64, ptr }
  %l122 = alloca i64
  %l125 = alloca ptr
  %l126 = alloca %"compiler/source:Span"
  %l129 = alloca { i64, ptr }
  %l130 = alloca { i64, ptr }
  %l132 = alloca { i64, ptr }
  %l134 = alloca %"compiler/diagmsg:Msg"
  %l135 = alloca i64
  %l138 = alloca ptr
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l2, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l16, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t8, ptr %l17
  %t9 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypedHoleUntyped(ptr %v0)
  store %"compiler/diagmsg:Msg" %t9, ptr %l18
  br label %bb3
bb2:
  br label %bb6
bb3:
  %t10 = load ptr, ptr %l16, !tbaa !29
  %t11 = load %"compiler/source:Span", ptr %l17
  %t12 = load %"compiler/diagmsg:Msg", ptr %l18
  %t13 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t10, %"compiler/source:Span" %t11, %"compiler/diagmsg:Msg" %t12)
  store i64 %t13, ptr %l19
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load %"compiler/source:Span", ptr %l1
  %t18 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %t14, %"compiler/source:Span" %t15)
  store ptr %t18, ptr %l22
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t19 = load ptr, ptr %l22, !tbaa !29
  store ptr %t19, ptr %rv
  br label %ret
bb6:
  %t20 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %l23
  br label %bb7
bb7:
  %t21 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l3
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t22)
  store ptr %t24, ptr %l25
  br label %bb8
bb8:
  %t25 = load ptr, ptr %l25, !tbaa !29
  %t27 = getelementptr %"compiler/check:frame", ptr %t25, i32 0, i32 8
  %t29 = call %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hda627d7755eecb5b938ca977110d67b2(ptr %v0, ptr %v0, ptr %t27)
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t29, ptr %l28
  br label %bb9
bb9:
  %t30 = load %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l28
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t30, ptr %l4
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t32 = call { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20I6_Hd1b8e91149b724287340e79c8c928444(ptr %v0, ptr %l4)
  %t33 = extractvalue { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } %t32, 1
  %t34 = extractvalue { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } %t32, 0
  store i32 %t34, ptr %l32
  %t35 = icmp ne i32 %t34, 0
  br i1 %t35, label %bb12, label %ok.36, !prof !99
ok.36:
  store %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" %t33, ptr %l31
  br label %bb11
bb11:
  %t37 = load %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l31
  store %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" %t37, ptr %l29
  br label %bb14
bb12:
  %t38 = load i32, ptr %l32, !tbaa !23
  %t39 = ashr i32 %t38, 16
  %t41 = icmp eq i32 %t39, 1
  store i1 %t41, ptr %l34, !tbaa !21
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb27
bb14:
  %t42 = load %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l29
  store %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" %t42, ptr %l5
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l5, i32 0, i32 0
  %t45 = load i32, ptr %t44, !tbaa !23
  %t48 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t43, i32 %t45)
  store { i64, ptr } %t48, ptr %l37
  br label %bb15
bb15:
  %t49 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t50 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s3, { i64, ptr } %t49, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d49, i32 0, i32 1) })
  store i1 %t50, ptr %l38
  br label %bb16
bb16:
  %t51 = load i1, ptr %l38, !tbaa !21
  %t52 = xor i1 %t51, true
  br i1 %t52, label %bb17, label %bb18
bb17:
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l41, !tbaa !29
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l5, i32 0, i32 1
  %t57 = load i64, ptr %t56, !tbaa !24
  %t60 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t55, i64 %t57)
  store i32 %t60, ptr %l44
  br label %bb19
bb18:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb21
bb19:
  %t61 = load i32, ptr %l2, !tbaa !23
  %t62 = load ptr, ptr %l41, !tbaa !29
  %t63 = load i32, ptr %l44, !tbaa !23
  %t65 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholeFits(ptr %v0, ptr %t62, i32 %t63, i32 %t61)
  store i1 %t65, ptr %l46
  br label %bb20
bb20:
  %t66 = load i1, ptr %l46, !tbaa !21
  store i1 %t66, ptr %l40, !tbaa !21
  br label %bb21
bb21:
  %t67 = load i1, ptr %l40, !tbaa !21
  br i1 %t67, label %bb22, label %bb23
bb22:
  %t68 = getelementptr %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l5, i32 0, i32 1
  %t69 = load i64, ptr %t68, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t69)
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s3)
  br label %bb26
bb26:
  br label %bb10
bb27:
  %t72 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_50, 0
  %t73 = insertvalue { ptr, ptr } %t72, ptr null, 1
  %t76 = extractvalue { ptr, ptr } %t73, 0
  %t77 = extractvalue { ptr, ptr } %t73, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %s0, ptr %s0, ptr %l3, ptr %t76, ptr %t77)
  br label %bb28
bb28:
  %t78 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t78, ptr %l51
  br label %bb29
bb29:
  %t79 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l51
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t79, ptr %l6
  store ptr %l3, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s6
  %t81 = load i64, ptr %l8, !tbaa !24
  store i64 %t81, ptr %l53, !tbaa !24
  %t82 = load ptr, ptr %l7, !tbaa !29
  %t84 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t82)
  store i64 %t84, ptr %l55
  br label %bb31
bb31:
  %t85 = load i64, ptr %l53, !tbaa !24
  %t86 = load i64, ptr %l55, !tbaa !24
  %t87 = icmp slt i64 %t85, %t86
  %t89 = xor i1 %t87, true
  br i1 %t89, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s6)
  br label %bb43
bb33:
  br label %bb34
bb34:
  %t91 = load ptr, ptr %l7, !tbaa !29
  %t92 = load i64, ptr %l8, !tbaa !24
  %t95 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t91, i64 %t92)
  store i64 %t95, ptr %l60
  br label %bb35
bb35:
  %t96 = load i64, ptr %l60, !tbaa !24
  store i64 %t96, ptr %l9, !tbaa !24
  store ptr %l6, ptr %l61, !tbaa !29
  %t97 = call ptr @__olang_scope_hold(ptr %s0)
  %t98 = ptrtoint ptr %t97 to i64
  store i64 %t98, ptr %l62, !tbaa !24
  %t99 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t99, label %bb36, label %bb37
bb36:
  %t101 = call ptr @__olang_region_make(ptr %s0)
  %t102 = ptrtoint ptr %t101 to i64
  store i64 %t102, ptr %l62, !tbaa !24
  br label %bb37
bb37:
  %t103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t103, ptr %l64, !tbaa !29
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t104)
  store ptr %t106, ptr %l66
  br label %bb38
bb38:
  %t107 = load ptr, ptr %l66, !tbaa !29
  %t109 = getelementptr %"compiler/typed:Body", ptr %t107, i32 0, i32 7
  %t110 = load i64, ptr %l9, !tbaa !24
  %t113 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t109, i64 %t110)
  store %"compiler/typed:Local" %t113, ptr %l70
  br label %bb39
bb39:
  %t114 = getelementptr %"compiler/typed:Local", ptr %l70, i32 0, i32 0
  %t115 = load i32, ptr %t114, !tbaa !23
  %t116 = load ptr, ptr %l64, !tbaa !29
  %t118 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s6, ptr %t116, i32 %t115)
  store { i64, ptr } %t118, ptr %l72
  br label %bb40
bb40:
  %t119 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t119, 1
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t122 = load i64, ptr %l62
  %t123 = inttoptr i64 %t122 to ptr
  %t124 = call ptr @__olang_held_alloc(ptr %t123, i64 %t121)
  call void @olang_textcopy(ptr %t124, ptr %t120, i64 %t121)
  %t125 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t124, 1
  %t128 = load ptr, ptr %l61, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t128, { i64, ptr } %t126)
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s6)
  br label %bb42
bb42:
  %t130 = load i64, ptr %l8, !tbaa !24
  %t133 = add i64 %t130, 1
  store i64 %t133, ptr %l8, !tbaa !24
  br label %bb30
bb43:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/check:Checker", ptr %t135, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t140 = getelementptr %"compiler/generic:Program", ptr %t138, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !29
  %t143 = getelementptr %"compiler/names:Resolver", ptr %t141, i32 0, i32 1
  store ptr %t143, ptr %l81, !tbaa !29
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t144)
  store ptr %t146, ptr %l83
  br label %bb44
bb44:
  %t147 = load ptr, ptr %l83, !tbaa !29
  %t149 = getelementptr %"compiler/check:frame", ptr %t147, i32 0, i32 1
  %t150 = load i64, ptr %t149, !tbaa !24
  %t151 = load ptr, ptr %l81, !tbaa !29
  %t153 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t151, i64 %t150)
  store ptr %t153, ptr %l86
  br label %bb45
bb45:
  %t154 = load ptr, ptr %l86, !tbaa !29
  %t156 = getelementptr %"compiler/names:Table", ptr %t154, i32 0, i32 0
  store ptr %t156, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb46
bb46:
  %t158 = load i64, ptr %l11, !tbaa !24
  store i64 %t158, ptr %l89, !tbaa !24
  %t159 = load ptr, ptr %l10, !tbaa !29
  %t161 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t159)
  store i64 %t161, ptr %l91
  br label %bb47
bb47:
  %t162 = load i64, ptr %l89, !tbaa !24
  %t163 = load i64, ptr %l91, !tbaa !24
  %t164 = icmp slt i64 %t162, %t163
  %t166 = xor i1 %t164, true
  br i1 %t166, label %bb48, label %bb49
bb48:
  br label %bb66
bb49:
  br label %bb50
bb50:
  %t168 = load ptr, ptr %l10, !tbaa !29
  %t169 = load i64, ptr %l11, !tbaa !24
  %t172 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t168, i64 %t169)
  store %"compiler/names:Entry" %t172, ptr %l96
  br label %bb51
bb51:
  %t173 = load %"compiler/names:Entry", ptr %l96
  store %"compiler/names:Entry" %t173, ptr %l12
  %t174 = getelementptr %"compiler/names:Entry", ptr %l12, i32 0, i32 2
  %t175 = load i32, ptr %t174, !range !{i32 0, i32 9}
  %t177 = trunc i64 2 to i32
  %t178 = icmp eq i32 %t175, %t177
  br i1 %t178, label %bb52, label %bb53
bb52:
  %t180 = load ptr, ptr %l0, !tbaa !29
  store ptr %t180, ptr %l100, !tbaa !29
  %t181 = load ptr, ptr %l0, !tbaa !29
  store ptr %t181, ptr %l101, !tbaa !29
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t182)
  store ptr %t184, ptr %l103
  br label %bb54
bb53:
  store i1 false, ptr %l99, !tbaa !21
  br label %bb57
bb54:
  %t185 = load ptr, ptr %l103, !tbaa !29
  %t187 = getelementptr %"compiler/check:frame", ptr %t185, i32 0, i32 1
  %t188 = load i64, ptr %t187, !tbaa !24
  %t189 = getelementptr %"compiler/names:Entry", ptr %l12, i32 0, i32 0
  %t190 = load i32, ptr %t189, !tbaa !23
  %t191 = load ptr, ptr %l101, !tbaa !29
  %t194 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalType(ptr %v0, ptr %t191, i64 %t188, i32 %t190)
  store i32 %t194, ptr %l107
  br label %bb55
bb55:
  %t195 = load i32, ptr %l2, !tbaa !23
  %t196 = load ptr, ptr %l100, !tbaa !29
  %t197 = load i32, ptr %l107, !tbaa !23
  %t199 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholeFits(ptr %v0, ptr %t196, i32 %t197, i32 %t195)
  store i1 %t199, ptr %l109
  br label %bb56
bb56:
  %t200 = load i1, ptr %l109, !tbaa !21
  store i1 %t200, ptr %l99, !tbaa !21
  br label %bb57
bb57:
  %t201 = load i1, ptr %l99, !tbaa !21
  br i1 %t201, label %bb58, label %bb59
bb58:
  store %olang.scope zeroinitializer, ptr %s11
  store ptr %l6, ptr %l110, !tbaa !29
  %t202 = call ptr @__olang_scope_hold(ptr %s0)
  %t203 = ptrtoint ptr %t202 to i64
  store i64 %t203, ptr %l111, !tbaa !24
  %t204 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t204, label %bb60, label %bb61
bb59:
  br label %bb64
bb60:
  %t206 = call ptr @__olang_region_make(ptr %s0)
  %t207 = ptrtoint ptr %t206 to i64
  store i64 %t207, ptr %l111, !tbaa !24
  br label %bb61
bb61:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t209 = getelementptr %"compiler/names:Entry", ptr %l12, i32 0, i32 0
  %t210 = load i32, ptr %t209, !tbaa !23
  %t213 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s11, ptr %t208, i32 %t210)
  store { i64, ptr } %t213, ptr %l115
  br label %bb62
bb62:
  %t214 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t215 = extractvalue { i64, ptr } %t214, 1
  %t216 = extractvalue { i64, ptr } %t214, 0
  %t217 = load i64, ptr %l111
  %t218 = inttoptr i64 %t217 to ptr
  %t219 = call ptr @__olang_held_alloc(ptr %t218, i64 %t216)
  call void @olang_textcopy(ptr %t219, ptr %t215, i64 %t216)
  %t220 = insertvalue { i64, ptr } undef, i64 %t216, 0
  %t221 = insertvalue { i64, ptr } %t220, ptr %t219, 1
  %t223 = load ptr, ptr %l110, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t223, { i64, ptr } %t221)
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s11)
  br label %bb64
bb64:
  br label %bb65
bb65:
  %t225 = load i64, ptr %l11, !tbaa !24
  %t228 = add i64 %t225, 1
  store i64 %t228, ptr %l11, !tbaa !24
  br label %bb46
bb66:
  %t231 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l6)
  store i64 %t231, ptr %l122
  br label %bb67
bb67:
  %t232 = load i64, ptr %l122, !tbaa !24
  %t233 = icmp sgt i64 %t232, 8
  br i1 %t233, label %bb68, label %bb69
bb68:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H88f30ae03b1b7707751e39c47edff247(ptr %s0, ptr %l6, i64 8)
  br label %bb70
bb69:
  br label %bb71
bb70:
  br label %bb71
bb71:
  %t236 = load ptr, ptr %l0, !tbaa !29
  store ptr %t236, ptr %l125, !tbaa !29
  %t237 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t237, ptr %l126
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t239 = load i32, ptr %l2, !tbaa !23
  %t242 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t238, i32 %t239)
  store { i64, ptr } %t242, ptr %l129
  br label %bb72
bb72:
  %t243 = load { i64, ptr }, ptr %l129, !tbaa !27
  store { i64, ptr } %t243, ptr %l130, !tbaa !27
  %t245 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s0, ptr %s0, ptr %s0, ptr %l6, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d51, i32 0, i32 1) })
  store { i64, ptr } %t245, ptr %l132
  br label %bb73
bb73:
  %t246 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t247 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t249 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypedHole(ptr %s0, ptr %s0, ptr %v0, { i64, ptr } %t247, { i64, ptr } %t246)
  store %"compiler/diagmsg:Msg" %t249, ptr %l134
  br label %bb74
bb74:
  %t250 = load ptr, ptr %l125, !tbaa !29
  %t251 = load %"compiler/source:Span", ptr %l126
  %t252 = load %"compiler/diagmsg:Msg", ptr %l134
  %t253 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t250, %"compiler/source:Span" %t251, %"compiler/diagmsg:Msg" %t252)
  store i64 %t253, ptr %l135
  br label %bb75
bb75:
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t255 = load %"compiler/source:Span", ptr %l1
  %t258 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %t254, %"compiler/source:Span" %t255)
  store ptr %t258, ptr %l138
  br label %bb76
bb76:
  call void @__olang_scope_close(ptr %s0)
  %t259 = load ptr, ptr %l138, !tbaa !29
  store ptr %t259, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkIter(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i64 %a4, ptr %a5, i32 %a6, i1 %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i64, i64, i64 }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca %"compiler/source:Span"
  %l24 = alloca i32
  %l25 = alloca i64
  %l28 = alloca i1
  %l30 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca i1
  %l49 = alloca ptr
  %l51 = alloca %"compiler/typed:Local"
  %l55 = alloca ptr
  %l57 = alloca ptr
  %l63 = alloca %"compiler/check:heldCand"
  %l75 = alloca ptr
  %l76 = alloca %"compiler/source:Span"
  %l78 = alloca i32
  %l79 = alloca i64
  %l80 = alloca ptr
  %l81 = alloca %"compiler/source:Span"
  %l84 = alloca i32
  %l85 = alloca ptr
  %l86 = alloca %"compiler/source:Span"
  %l88 = alloca i32
  %l89 = alloca ptr
  %l94 = alloca i64
  %l98 = alloca { i64, i64, i64 }
  %l103 = alloca ptr
  %l108 = alloca ptr
  %l112 = alloca ptr
  %l113 = alloca %"compiler/source:Span"
  %l114 = alloca i64
  %l118 = alloca ptr
  %l122 = alloca ptr
  %l127 = alloca ptr
  %l129 = alloca ptr
  %l130 = alloca ptr
  %l131 = alloca %"compiler/source:Span"
  %l132 = alloca %"compiler/source:Span"
  %l135 = alloca ptr
  %l138 = alloca i32
  %l139 = alloca i32
  %l143 = alloca ptr
  %l145 = alloca ptr
  %l156 = alloca i64
  %l158 = alloca ptr
  %l161 = alloca i64
  %l162 = alloca i32
  %l163 = alloca i64
  %l165 = alloca ptr
  %l168 = alloca i64
  %l169 = alloca i32
  %l175 = alloca ptr
  %l176 = alloca ptr
  %l177 = alloca %"compiler/source:Span"
  %l178 = alloca ptr
  %l182 = alloca ptr
  %s4 = alloca %olang.scope
  %t100 = alloca { i64, [3 x i64] }, align 8
  %t146 = alloca { i64, [3 x i64] }, align 8
  %t254 = alloca { i64, [4 x i64] }, align 8
  %t344 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i1 %a7, ptr %l7
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l20, !tbaa !29
  %t2 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t2, ptr %l21
  %t3 = load ptr, ptr %l3, !tbaa !29
  %t6 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t3)
  store i32 %t6, ptr %l24
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l20, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l21
  %t9 = load i32, ptr %l24, !tbaa !23
  %t10 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t7, %"compiler/source:Span" %t8, i32 %t9)
  store i64 %t10, ptr %l25
  br label %bb2
bb2:
  %t11 = load i64, ptr %l25, !tbaa !24
  store i64 %t11, ptr %l8, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load ptr, ptr %l3, !tbaa !29
  %t16 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egeneratorCall(ptr %v0, ptr %v2, ptr %t12, ptr %t13)
  store i1 %t16, ptr %l28
  br label %bb3
bb3:
  %t17 = load i1, ptr %l28, !tbaa !21
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t18)
  store ptr %t20, ptr %l30
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t21 = load ptr, ptr %l30, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Body", ptr %t21, i32 0, i32 17
  %t24 = load i64, ptr %l8, !tbaa !24
  %t26 = trunc i64 %t24 to i32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2ePush_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t23, i32 %t26)
  br label %bb7
bb7:
  br label %bb8
bb8:
  %t30 = load ptr, ptr %l3, !tbaa !29
  store ptr %t30, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t31 = load ptr, ptr %l36, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb9, label %bb10
bb9:
  %t34 = load ptr, ptr %l36, !tbaa !29
  %t35 = load i64, ptr %t34, !range !{i64 0, i64 18}
  %t37 = icmp eq i64 %t35, 2
  store i1 %t37, ptr %l37, !tbaa !21
  br label %bb10
bb10:
  %t38 = load i1, ptr %l37, !tbaa !21
  br i1 %t38, label %bb11, label %bb12
bb11:
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = getelementptr { i64, [5 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t41, i32 0, i32 2
  %t43 = load ptr, ptr %t42
  store ptr %t43, ptr %l9, !tbaa !29
  br label %bb13
bb12:
  br label %bb33
bb13:
  %t45 = load ptr, ptr %l9, !tbaa !29
  store ptr %t45, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t46 = load ptr, ptr %l42, !tbaa !29
  %t47 = icmp ne ptr %t46, null
  br i1 %t47, label %bb14, label %bb15
bb14:
  %t49 = load ptr, ptr %l42, !tbaa !29
  %t50 = load i64, ptr %t49, !range !{i64 0, i64 8}
  %t52 = icmp eq i64 %t50, 0
  store i1 %t52, ptr %l43, !tbaa !21
  br label %bb15
bb15:
  %t53 = load i1, ptr %l43, !tbaa !21
  br i1 %t53, label %bb16, label %bb17
bb16:
  %t54 = load ptr, ptr %l9, !tbaa !29
  %t56 = getelementptr { i64, [4 x i64] }, ptr %t54, i32 0, i32 1
  %t57 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t56, i32 0, i32 2
  %t58 = load i32, ptr %t57
  store i32 %t58, ptr %l10, !tbaa !23
  br label %bb18
bb17:
  br label %bb27
bb18:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t60)
  store ptr %t62, ptr %l49
  br label %bb19
bb19:
  %t63 = load i32, ptr %l10, !tbaa !23
  %t64 = load ptr, ptr %l49, !tbaa !29
  %t66 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t64, i32 %t63)
  store %"compiler/typed:Local" %t66, ptr %l51
  br label %bb20
bb20:
  %t67 = getelementptr %"compiler/typed:Local", ptr %l51, i32 0, i32 4
  %t68 = load i32, ptr %t67, !range !{i32 0, i32 7}
  %t70 = trunc i64 1 to i32
  %t71 = icmp eq i32 %t68, %t70
  br i1 %t71, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/check:Checker", ptr %t73, i32 0, i32 130
  store ptr %t75, ptr %l55, !tbaa !29
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t76)
  store ptr %t78, ptr %l57
  br label %bb23
bb22:
  br label %bb26
bb23:
  %t79 = load ptr, ptr %l57, !tbaa !29
  %t81 = getelementptr %"compiler/check:frame", ptr %t79, i32 0, i32 0
  %t82 = load i64, ptr %t81, !tbaa !24
  %t83 = load i32, ptr %l10, !tbaa !23
  %t85 = sext i32 %t83 to i64
  %t86 = load i64, ptr %l8, !tbaa !24
  %t90 = call %"compiler/check:heldCand" @compiler_2fcheck_3aheldCand_2ector(ptr %s4, i64 %t82, i64 %t85, i64 %t86)
  store %"compiler/check:heldCand" %t90, ptr %l63
  br label %bb24
bb24:
  %t91 = load ptr, ptr %l55, !tbaa !29
  %t92 = load %"compiler/check:heldCand", ptr %l63
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aheldCand_3e_2ePush_3ccompiler_2fcheck_3aheldCand_3e(ptr %v0, ptr %t91, %"compiler/check:heldCand" %t92)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s4)
  br label %bb26
bb26:
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_b35f41bb006554d6_a1d87dcad76a5f72)
  unreachable
bb32:
  br label %bb38
bb33:
  br i1 true, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_943678799cf3b8f7_240de00f13c53f3)
  unreachable
bb38:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load %"compiler/source:Span", ptr %l1
  %t95 = load i64, ptr %l8, !tbaa !24
  %t97 = trunc i64 %t95 to i32
  %t99 = load ptr, ptr %l3, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t100
  %t101 = getelementptr { i64, [3 x i64] }, ptr %t100, i32 0, i32 0
  store i64 0, ptr %t101
  %t103 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t94, 0
  %t105 = insertvalue { %"compiler/source:Span", i32, ptr } %t103, i32 %t97, 1
  %t107 = insertvalue { %"compiler/source:Span", i32, ptr } %t105, ptr %t99, 2
  %t108 = getelementptr { i64, [3 x i64] }, ptr %t100, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t107, ptr %t108
  %t109 = load { i64, [3 x i64] }, ptr %t100
  %t111 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t109, ptr %t111
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t93, ptr %t111)
  br label %bb39
bb39:
  store i64 -1, ptr %l11, !tbaa !24
  %t114 = load ptr, ptr %l2, !tbaa !29
  %t116 = getelementptr %"compiler/ast:ForIn", ptr %t114, i32 0, i32 0
  %t117 = load i32, ptr %t116, !tbaa !23
  %t119 = icmp ne i32 %t117, 0
  br i1 %t119, label %bb40, label %bb41
bb40:
  %t121 = load ptr, ptr %l0, !tbaa !29
  store ptr %t121, ptr %l75, !tbaa !29
  %t122 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t122, ptr %l76
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t123)
  store i32 %t125, ptr %l78
  br label %bb42
bb41:
  br label %bb47
bb42:
  %t126 = load ptr, ptr %l75, !tbaa !29
  %t127 = load %"compiler/source:Span", ptr %l76
  %t128 = load i32, ptr %l78, !tbaa !23
  %t129 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t126, %"compiler/source:Span" %t127, i32 %t128)
  store i64 %t129, ptr %l79
  br label %bb43
bb43:
  %t130 = load i64, ptr %l79, !tbaa !24
  store i64 %t130, ptr %l11, !tbaa !24
  %t131 = load ptr, ptr %l0, !tbaa !29
  store ptr %t131, ptr %l80, !tbaa !29
  %t132 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t132, ptr %l81
  %t133 = load i64, ptr %l11, !tbaa !24
  %t135 = trunc i64 %t133 to i32
  store i32 %t135, ptr %l84, !tbaa !23
  %t137 = load ptr, ptr %l0, !tbaa !29
  store ptr %t137, ptr %l85, !tbaa !29
  %t138 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t138, ptr %l86
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t139)
  store i32 %t141, ptr %l88
  br label %bb44
bb44:
  %t142 = load ptr, ptr %l85, !tbaa !29
  %t143 = load %"compiler/source:Span", ptr %l86
  %t144 = load i32, ptr %l88, !tbaa !23
  %t145 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t142, %"compiler/source:Span" %t143, i32 %t144, i64 0)
  store ptr %t145, ptr %l89
  br label %bb45
bb45:
  store { i64, [3 x i64] } zeroinitializer, ptr %t146
  %t147 = getelementptr { i64, [3 x i64] }, ptr %t146, i32 0, i32 0
  store i64 0, ptr %t147
  %t148 = load %"compiler/source:Span", ptr %l81
  %t149 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t148, 0
  %t150 = load i32, ptr %l84, !tbaa !23
  %t151 = insertvalue { %"compiler/source:Span", i32, ptr } %t149, i32 %t150, 1
  %t152 = load ptr, ptr %l89, !tbaa !29
  %t153 = insertvalue { %"compiler/source:Span", i32, ptr } %t151, ptr %t152, 2
  %t154 = getelementptr { i64, [3 x i64] }, ptr %t146, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t153, ptr %t154
  %t155 = load { i64, [3 x i64] }, ptr %t146
  %t157 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t155, ptr %t157
  %t158 = load ptr, ptr %l80, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t158, ptr %t157)
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/check:Checker", ptr %t160, i32 0, i32 48
  %t164 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t162)
  store i64 %t164, ptr %l94
  br label %bb48
bb48:
  %t165 = load i64, ptr %l94, !tbaa !24
  store i64 %t165, ptr %l12, !tbaa !24
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load %"compiler/source:Span", ptr %l1
  %t171 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t166, i32 2, %"compiler/source:Span" %t167)
  store { i64, i64, i64 } %t171, ptr %l98
  br label %bb49
bb49:
  %t172 = load { i64, i64, i64 }, ptr %l98
  store { i64, i64, i64 } %t172, ptr %l13
  %t173 = getelementptr { i64, i64, i64 }, ptr %l13, i32 0, i32 0
  %t174 = load i64, ptr %t173, !tbaa !24
  store i64 %t174, ptr %l14, !tbaa !24
  %t176 = getelementptr { i64, i64, i64 }, ptr %l13, i32 0, i32 1
  %t177 = load i64, ptr %t176, !tbaa !24
  store i64 %t177, ptr %l15, !tbaa !24
  %t179 = getelementptr { i64, i64, i64 }, ptr %l13, i32 0, i32 2
  %t180 = load i64, ptr %t179, !tbaa !24
  store i64 %t180, ptr %l16, !tbaa !24
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t182)
  store ptr %t184, ptr %l103
  br label %bb50
bb50:
  %t185 = load ptr, ptr %l103, !tbaa !29
  %t187 = getelementptr %"compiler/check:frame", ptr %t185, i32 0, i32 10
  %t188 = load i64, ptr %l14, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t187, i64 %t188)
  br label %bb51
bb51:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t191)
  store ptr %t193, ptr %l108
  br label %bb52
bb52:
  %t194 = load ptr, ptr %l108, !tbaa !29
  %t196 = getelementptr %"compiler/check:frame", ptr %t194, i32 0, i32 11
  %t197 = load i64, ptr %l14, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t196, i64 %t197)
  br label %bb53
bb53:
  %t200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t200, ptr %l112, !tbaa !29
  %t201 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t201, ptr %l113
  store i64 %a4, ptr %l114, !tbaa !24
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load %"compiler/source:Span", ptr %l1
  %t205 = load i64, ptr %l8, !tbaa !24
  %t209 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t203, %"compiler/source:Span" %t204, i64 %t205)
  store ptr %t209, ptr %l118
  br label %bb54
bb54:
  %t210 = icmp sge i64 0, 0
  br i1 %t210, label %bb55, label %bb56
bb55:
  %t212 = icmp sle i64 0, 1152921504606846975
  br i1 %t212, label %bb57, label %bb58
bb56:
  call void @__olang_check_failed(ptr @olang_loc_dcf5b9aec39ad50b_4fa64d0de79beb7f)
  unreachable
bb57:
  %t214 = mul i64 0, 8
  %t215 = insertvalue { i64, ptr } undef, i64 0, 0
  %t216 = insertvalue { i64, ptr } %t215, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t217 = load ptr, ptr %l112, !tbaa !29
  %t218 = load %"compiler/source:Span", ptr %l113
  %t219 = load i64, ptr %l114, !tbaa !24
  %t220 = load ptr, ptr %l118, !tbaa !29
  %t222 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloopCall(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t217, %"compiler/source:Span" %t218, i64 %t219, ptr %t220, { i64, ptr } %t216)
  store ptr %t222, ptr %l122
  br label %bb59
bb58:
  call void @__olang_check_failed(ptr @olang_loc_dcf5b9aec39ad50b_4fa64d0de79beb7f)
  unreachable
bb59:
  %t223 = load ptr, ptr %l122, !tbaa !29
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t225 = load %"compiler/source:Span", ptr %l1
  %t227 = load i64, ptr %l14, !tbaa !24
  %t232 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexhaustedOrBreak(ptr %v0, ptr %v0, ptr %v0, ptr %t224, %"compiler/source:Span" %t225, ptr %t223, i64 %t227)
  store ptr %t232, ptr %l127
  br label %bb60
bb60:
  %t233 = load ptr, ptr %l127, !tbaa !29
  store ptr %t233, ptr %l18, !tbaa !29
  %t234 = load i1, ptr %l7, !tbaa !21
  br i1 %t234, label %bb61, label %bb62
bb61:
  %t236 = load ptr, ptr %l0, !tbaa !29
  store ptr %t236, ptr %l129, !tbaa !29
  %t237 = load ptr, ptr %l0, !tbaa !29
  store ptr %t237, ptr %l130, !tbaa !29
  %t238 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t238, ptr %l131
  %t239 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t239, ptr %l132
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t242 = getelementptr %"compiler/check:Checker", ptr %t240, i32 0, i32 1
  %t243 = load ptr, ptr %t242, !tbaa !29
  %t245 = getelementptr %"compiler/generic:Program", ptr %t243, i32 0, i32 2
  store ptr %t245, ptr %l135, !tbaa !29
  %t246 = load ptr, ptr %l18, !tbaa !29
  %t249 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t246)
  store i32 %t249, ptr %l138
  br label %bb63
bb62:
  br label %bb67
bb63:
  %t250 = load ptr, ptr %l135, !tbaa !29
  %t251 = load i32, ptr %l138, !tbaa !23
  %t252 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t250, i32 %t251)
  store i32 %t252, ptr %l139
  br label %bb64
bb64:
  %t253 = load ptr, ptr %l18, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t254
  %t255 = getelementptr { i64, [4 x i64] }, ptr %t254, i32 0, i32 0
  store i64 2, ptr %t255
  %t256 = load %"compiler/source:Span", ptr %l132
  %t257 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t256, 0
  %t258 = load i32, ptr %l139, !tbaa !23
  %t259 = insertvalue { %"compiler/source:Span", i32, ptr } %t257, i32 %t258, 1
  %t261 = insertvalue { %"compiler/source:Span", i32, ptr } %t259, ptr %t253, 2
  %t262 = getelementptr { i64, [4 x i64] }, ptr %t254, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t261, ptr %t262
  %t263 = load { i64, [4 x i64] }, ptr %t254
  %t265 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t263, ptr %t265
  %t266 = load ptr, ptr %l130, !tbaa !29
  %t267 = load %"compiler/source:Span", ptr %l131
  %t269 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t266, %"compiler/source:Span" %t267, ptr %t265)
  store ptr %t269, ptr %l143
  br label %bb65
bb65:
  %t270 = load %"compiler/source:Span", ptr %l1
  %t271 = load ptr, ptr %l129, !tbaa !29
  %t272 = load ptr, ptr %l143, !tbaa !29
  %t274 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueRef(ptr %v0, ptr %v0, ptr %v0, ptr %t271, ptr %t272, %"compiler/source:Span" %t270, i1 false, i1 true)
  store ptr %t274, ptr %l145
  br label %bb66
bb66:
  %t275 = load ptr, ptr %l145, !tbaa !29
  store ptr %t275, ptr %l18, !tbaa !29
  br label %bb67
bb67:
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t277 = load %"compiler/source:Span", ptr %l1
  %t278 = load ptr, ptr %l2, !tbaa !29
  %t279 = load i64, ptr %l11, !tbaa !24
  %t280 = load ptr, ptr %l18, !tbaa !29
  %t281 = load i1, ptr %l7, !tbaa !21
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelementLocals(ptr %v0, ptr %v1, ptr %v0, ptr %t276, %"compiler/source:Span" %t277, ptr %t278, i64 %t279, ptr %t280, i1 %t281)
  br label %bb68
bb68:
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t289 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkBody(ptr %v0, ptr %v1, ptr %v3, ptr %t288, ptr %t289, ptr %a5, i32 %a6)
  br label %bb69
bb69:
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t298 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t296)
  store ptr %t298, ptr %l158
  br label %bb70
bb70:
  %t299 = load ptr, ptr %l158, !tbaa !29
  %t301 = getelementptr %"compiler/check:frame", ptr %t299, i32 0, i32 10
  %t303 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t301)
  %t304 = extractvalue { i32, i64 } %t303, 1
  %t305 = extractvalue { i32, i64 } %t303, 0
  store i32 %t305, ptr %l162
  %t306 = icmp ne i32 %t305, 0
  br i1 %t306, label %bb72, label %ok.307, !prof !99
ok.307:
  store i64 %t304, ptr %l161
  br label %bb71
bb71:
  %t308 = load i64, ptr %l161, !tbaa !24
  store i64 %t308, ptr %l156, !tbaa !24
  br label %bb74
bb72:
  br label %bb73
bb73:
  br label %bb74
bb74:
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t311 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t309)
  store ptr %t311, ptr %l165
  br label %bb75
bb75:
  %t312 = load ptr, ptr %l165, !tbaa !29
  %t314 = getelementptr %"compiler/check:frame", ptr %t312, i32 0, i32 11
  %t316 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t314)
  %t317 = extractvalue { i32, i64 } %t316, 1
  %t318 = extractvalue { i32, i64 } %t316, 0
  store i32 %t318, ptr %l169
  %t319 = icmp ne i32 %t318, 0
  br i1 %t319, label %bb77, label %ok.320, !prof !99
ok.320:
  store i64 %t317, ptr %l168
  br label %bb76
bb76:
  %t321 = load i64, ptr %l168, !tbaa !24
  store i64 %t321, ptr %l163, !tbaa !24
  br label %bb79
bb77:
  br label %bb78
bb78:
  br label %bb79
bb79:
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t323 = load i64, ptr %l14, !tbaa !24
  %t324 = load i64, ptr %l15, !tbaa !24
  %t325 = load i64, ptr %l16, !tbaa !24
  %t326 = load i64, ptr %l12, !tbaa !24
  %t332 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v0, ptr %t322, i64 %t323, i64 %t324, i64 %t325, i64 %t326)
  store ptr %t332, ptr %l175
  br label %bb80
bb80:
  %t333 = load ptr, ptr %l175, !tbaa !29
  %t334 = load ptr, ptr %l0, !tbaa !29
  store ptr %t334, ptr %l176, !tbaa !29
  %t335 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t335, ptr %l177
  store ptr %t333, ptr %l178, !tbaa !29
  %t337 = load ptr, ptr %l0, !tbaa !29
  %t338 = load %"compiler/source:Span", ptr %l1
  %t339 = load i64, ptr %l11, !tbaa !24
  %t343 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecountPost(ptr %v0, ptr %v0, ptr %t337, %"compiler/source:Span" %t338, i64 %t339, i64 1)
  store ptr %t343, ptr %l182
  br label %bb81
bb81:
  store { i64, [3 x i64] } zeroinitializer, ptr %t344
  %t345 = getelementptr { i64, [3 x i64] }, ptr %t344, i32 0, i32 0
  store i64 4, ptr %t345
  %t346 = load %"compiler/source:Span", ptr %l177
  %t347 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t346, 0
  %t348 = load ptr, ptr %l178, !tbaa !29
  %t349 = insertvalue { %"compiler/source:Span", ptr, ptr } %t347, ptr %t348, 1
  %t350 = load ptr, ptr %l182, !tbaa !29
  %t351 = insertvalue { %"compiler/source:Span", ptr, ptr } %t349, ptr %t350, 2
  %t352 = getelementptr { i64, [3 x i64] }, ptr %t344, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t351, ptr %t352
  %t353 = load { i64, [3 x i64] }, ptr %t344
  %t355 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t353, ptr %t355
  %t356 = load ptr, ptr %l176, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t356, ptr %t355)
  br label %bb82
bb82:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkRuns(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i64 %a4, ptr %a5, i32 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l5 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, i64, i64 }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca { i64, i64, i64 }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i32
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca { i64, i64, i64 }
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l39 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca %"compiler/source:Span"
  %l43 = alloca i32
  %l44 = alloca i64
  %l45 = alloca ptr
  %l46 = alloca %"compiler/source:Span"
  %l49 = alloca i32
  %l50 = alloca ptr
  %l51 = alloca %"compiler/source:Span"
  %l53 = alloca i32
  %l54 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca %"compiler/source:Span"
  %l63 = alloca i32
  %l64 = alloca i64
  %l65 = alloca ptr
  %l66 = alloca %"compiler/source:Span"
  %l69 = alloca i32
  %l70 = alloca ptr
  %l71 = alloca %"compiler/source:Span"
  %l73 = alloca i32
  %l74 = alloca ptr
  %l79 = alloca i64
  %l83 = alloca { i64, i64, i64 }
  %l88 = alloca ptr
  %l93 = alloca ptr
  %l97 = alloca ptr
  %l98 = alloca %"compiler/source:Span"
  %l99 = alloca i64
  %l103 = alloca ptr
  %l104 = alloca ptr
  %l108 = alloca ptr
  %l109 = alloca { i64, ptr }
  %l110 = alloca ptr
  %l113 = alloca i32
  %l117 = alloca i64
  %l118 = alloca ptr
  %l119 = alloca %"compiler/source:Span"
  %l122 = alloca i32
  %l127 = alloca ptr
  %l130 = alloca ptr
  %l131 = alloca %"compiler/source:Span"
  %l133 = alloca i32
  %l134 = alloca i64
  %l135 = alloca ptr
  %l136 = alloca %"compiler/source:Span"
  %l139 = alloca i32
  %l140 = alloca ptr
  %l141 = alloca %"compiler/source:Span"
  %l143 = alloca i32
  %l144 = alloca i32
  %l148 = alloca ptr
  %l149 = alloca ptr
  %l152 = alloca ptr
  %l153 = alloca %"compiler/source:Span"
  %l155 = alloca i32
  %l156 = alloca i64
  %l157 = alloca ptr
  %l158 = alloca %"compiler/source:Span"
  %l161 = alloca i32
  %l162 = alloca ptr
  %l163 = alloca %"compiler/source:Span"
  %l165 = alloca i32
  %l166 = alloca ptr
  %l171 = alloca i64
  %l175 = alloca { i64, i64, i64 }
  %l179 = alloca i64
  %l181 = alloca ptr
  %l184 = alloca i64
  %l185 = alloca i32
  %l187 = alloca ptr
  %l191 = alloca ptr
  %l192 = alloca ptr
  %l193 = alloca %"compiler/source:Span"
  %l194 = alloca ptr
  %l195 = alloca %"compiler/source:Span"
  %l196 = alloca i32
  %l197 = alloca i32
  %l201 = alloca ptr
  %l205 = alloca ptr
  %l207 = alloca ptr
  %l209 = alloca ptr
  %l212 = alloca i32
  %l213 = alloca %"compiler/source:Span"
  %l216 = alloca i32
  %l220 = alloca ptr
  %l223 = alloca ptr
  %l224 = alloca %"compiler/source:Span"
  %l225 = alloca %"compiler/source:Span"
  %l230 = alloca i32
  %l231 = alloca ptr
  %l235 = alloca ptr
  %l237 = alloca %"compiler/typed:Elem"
  %l241 = alloca ptr
  %l242 = alloca ptr
  %l243 = alloca %"compiler/source:Span"
  %l244 = alloca ptr
  %l245 = alloca i64
  %l249 = alloca ptr
  %l254 = alloca ptr
  %l255 = alloca ptr
  %l259 = alloca i64
  %l264 = alloca i32
  %l269 = alloca i64
  %l271 = alloca ptr
  %l274 = alloca i64
  %l275 = alloca i32
  %l276 = alloca i64
  %l278 = alloca ptr
  %l281 = alloca i64
  %l282 = alloca i32
  %l288 = alloca ptr
  %l291 = alloca i64
  %l295 = alloca { i64, i64, i64 }
  %l299 = alloca ptr
  %l300 = alloca ptr
  %l301 = alloca %"compiler/source:Span"
  %l302 = alloca i64
  %l303 = alloca ptr
  %l304 = alloca %"compiler/source:Span"
  %l306 = alloca i32
  %l307 = alloca ptr
  %l308 = alloca ptr
  %l311 = alloca ptr
  %l312 = alloca ptr
  %l313 = alloca %"compiler/source:Span"
  %l314 = alloca i64
  %l315 = alloca ptr
  %l316 = alloca %"compiler/source:Span"
  %l318 = alloca i32
  %l319 = alloca ptr
  %l320 = alloca ptr
  %l326 = alloca ptr
  %l334 = alloca ptr
  %l335 = alloca ptr
  %l336 = alloca %"compiler/source:Span"
  %l337 = alloca i64
  %l341 = alloca ptr
  %l342 = alloca ptr
  %l348 = alloca ptr
  %t34 = alloca { i64, [3 x i64] }, align 8
  %t80 = alloca { i64, [3 x i64] }, align 8
  %t190 = alloca { i64, [3 x i64] }, align 8
  %t238 = alloca { i64, [3 x i64] }, align 8
  %t277 = alloca { i64, [3 x i64] }, align 8
  %t390 = alloca { i64, [4 x i64] }, align 8
  %t430 = alloca { i64, [4 x i64] }, align 8
  %t623 = alloca { i64, [3 x i64] }, align 8
  %t670 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load %"compiler/source:Span", ptr %l1
  %t7 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eborrowedSource(ptr %v0, ptr %v2, ptr %t1, %"compiler/source:Span" %t2, ptr %a3)
  store i64 %t7, ptr %l39
  br label %bb1
bb1:
  %t8 = load i64, ptr %l39, !tbaa !24
  store i64 %t8, ptr %l7, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l40, !tbaa !29
  %t10 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t10, ptr %l41
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t11)
  store i32 %t13, ptr %l43
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l40, !tbaa !29
  %t15 = load %"compiler/source:Span", ptr %l41
  %t16 = load i32, ptr %l43, !tbaa !23
  %t17 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t14, %"compiler/source:Span" %t15, i32 %t16)
  store i64 %t17, ptr %l44
  br label %bb3
bb3:
  %t18 = load i64, ptr %l44, !tbaa !24
  store i64 %t18, ptr %l8, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l45, !tbaa !29
  %t20 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t20, ptr %l46
  %t21 = load i64, ptr %l8, !tbaa !24
  %t23 = trunc i64 %t21 to i32
  store i32 %t23, ptr %l49, !tbaa !23
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l50, !tbaa !29
  %t26 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t26, ptr %l51
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t27)
  store i32 %t29, ptr %l53
  br label %bb4
bb4:
  %t30 = load ptr, ptr %l50, !tbaa !29
  %t31 = load %"compiler/source:Span", ptr %l51
  %t32 = load i32, ptr %l53, !tbaa !23
  %t33 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t30, %"compiler/source:Span" %t31, i32 %t32, i64 0)
  store ptr %t33, ptr %l54
  br label %bb5
bb5:
  store { i64, [3 x i64] } zeroinitializer, ptr %t34
  %t35 = getelementptr { i64, [3 x i64] }, ptr %t34, i32 0, i32 0
  store i64 0, ptr %t35
  %t36 = load %"compiler/source:Span", ptr %l46
  %t37 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t36, 0
  %t38 = load i32, ptr %l49, !tbaa !23
  %t39 = insertvalue { %"compiler/source:Span", i32, ptr } %t37, i32 %t38, 1
  %t40 = load ptr, ptr %l54, !tbaa !29
  %t41 = insertvalue { %"compiler/source:Span", i32, ptr } %t39, ptr %t40, 2
  %t42 = getelementptr { i64, [3 x i64] }, ptr %t34, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t41, ptr %t42
  %t43 = load { i64, [3 x i64] }, ptr %t34
  %t45 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t43, ptr %t45
  %t46 = load ptr, ptr %l45, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t46, ptr %t45)
  br label %bb6
bb6:
  store i64 -1, ptr %l9, !tbaa !24
  %t48 = load ptr, ptr %l2, !tbaa !29
  %t50 = getelementptr %"compiler/ast:ForIn", ptr %t48, i32 0, i32 0
  %t51 = load i32, ptr %t50, !tbaa !23
  %t53 = icmp ne i32 %t51, 0
  br i1 %t53, label %bb7, label %bb8
bb7:
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l60, !tbaa !29
  %t56 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t56, ptr %l61
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t57)
  store i32 %t59, ptr %l63
  br label %bb9
bb8:
  br label %bb14
bb9:
  %t60 = load ptr, ptr %l60, !tbaa !29
  %t61 = load %"compiler/source:Span", ptr %l61
  %t62 = load i32, ptr %l63, !tbaa !23
  %t63 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t60, %"compiler/source:Span" %t61, i32 %t62)
  store i64 %t63, ptr %l64
  br label %bb10
bb10:
  %t64 = load i64, ptr %l64, !tbaa !24
  store i64 %t64, ptr %l9, !tbaa !24
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l65, !tbaa !29
  %t66 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t66, ptr %l66
  %t67 = load i64, ptr %l9, !tbaa !24
  %t69 = trunc i64 %t67 to i32
  store i32 %t69, ptr %l69, !tbaa !23
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l70, !tbaa !29
  %t72 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t72, ptr %l71
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t73)
  store i32 %t75, ptr %l73
  br label %bb11
bb11:
  %t76 = load ptr, ptr %l70, !tbaa !29
  %t77 = load %"compiler/source:Span", ptr %l71
  %t78 = load i32, ptr %l73, !tbaa !23
  %t79 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t76, %"compiler/source:Span" %t77, i32 %t78, i64 0)
  store ptr %t79, ptr %l74
  br label %bb12
bb12:
  store { i64, [3 x i64] } zeroinitializer, ptr %t80
  %t81 = getelementptr { i64, [3 x i64] }, ptr %t80, i32 0, i32 0
  store i64 0, ptr %t81
  %t82 = load %"compiler/source:Span", ptr %l66
  %t83 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t82, 0
  %t84 = load i32, ptr %l69, !tbaa !23
  %t85 = insertvalue { %"compiler/source:Span", i32, ptr } %t83, i32 %t84, 1
  %t86 = load ptr, ptr %l74, !tbaa !29
  %t87 = insertvalue { %"compiler/source:Span", i32, ptr } %t85, ptr %t86, 2
  %t88 = getelementptr { i64, [3 x i64] }, ptr %t80, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t87, ptr %t88
  %t89 = load { i64, [3 x i64] }, ptr %t80
  %t91 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t89, ptr %t91
  %t92 = load ptr, ptr %l65, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t92, ptr %t91)
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/check:Checker", ptr %t94, i32 0, i32 48
  %t98 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t96)
  store i64 %t98, ptr %l79
  br label %bb15
bb15:
  %t99 = load i64, ptr %l79, !tbaa !24
  store i64 %t99, ptr %l10, !tbaa !24
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load %"compiler/source:Span", ptr %l1
  %t105 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t100, i32 2, %"compiler/source:Span" %t101)
  store { i64, i64, i64 } %t105, ptr %l83
  br label %bb16
bb16:
  %t106 = load { i64, i64, i64 }, ptr %l83
  store { i64, i64, i64 } %t106, ptr %l11
  %t107 = getelementptr { i64, i64, i64 }, ptr %l11, i32 0, i32 0
  %t108 = load i64, ptr %t107, !tbaa !24
  store i64 %t108, ptr %l12, !tbaa !24
  %t110 = getelementptr { i64, i64, i64 }, ptr %l11, i32 0, i32 1
  %t111 = load i64, ptr %t110, !tbaa !24
  store i64 %t111, ptr %l13, !tbaa !24
  %t113 = getelementptr { i64, i64, i64 }, ptr %l11, i32 0, i32 2
  %t114 = load i64, ptr %t113, !tbaa !24
  store i64 %t114, ptr %l14, !tbaa !24
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t116)
  store ptr %t118, ptr %l88
  br label %bb17
bb17:
  %t119 = load ptr, ptr %l88, !tbaa !29
  %t121 = getelementptr %"compiler/check:frame", ptr %t119, i32 0, i32 10
  %t122 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t121, i64 %t122)
  br label %bb18
bb18:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t125)
  store ptr %t127, ptr %l93
  br label %bb19
bb19:
  %t128 = load ptr, ptr %l93, !tbaa !29
  %t130 = getelementptr %"compiler/check:frame", ptr %t128, i32 0, i32 11
  %t131 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t130, i64 %t131)
  br label %bb20
bb20:
  %t134 = load ptr, ptr %l0, !tbaa !29
  store ptr %t134, ptr %l97, !tbaa !29
  %t135 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t135, ptr %l98
  store i64 %a4, ptr %l99, !tbaa !24
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load %"compiler/source:Span", ptr %l1
  %t139 = load i64, ptr %l7, !tbaa !24
  %t143 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t137, %"compiler/source:Span" %t138, i64 %t139)
  store ptr %t143, ptr %l103
  br label %bb21
bb21:
  %t144 = load ptr, ptr %l0, !tbaa !29
  store ptr %t144, ptr %l104, !tbaa !29
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load %"compiler/source:Span", ptr %l1
  %t147 = load i64, ptr %l8, !tbaa !24
  %t151 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t145, %"compiler/source:Span" %t146, i64 %t147)
  store ptr %t151, ptr %l108
  br label %bb22
bb22:
  %t152 = load ptr, ptr %l104, !tbaa !29
  %t153 = load ptr, ptr %l108, !tbaa !29
  %t154 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v0, ptr %v0, ptr %t152, ptr %t153)
  store { i64, ptr } %t154, ptr %l109
  br label %bb23
bb23:
  %t155 = load ptr, ptr %l97, !tbaa !29
  %t156 = load %"compiler/source:Span", ptr %l98
  %t157 = load i64, ptr %l99, !tbaa !24
  %t158 = load ptr, ptr %l103, !tbaa !29
  %t159 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t160 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloopCall(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t155, %"compiler/source:Span" %t156, i64 %t157, ptr %t158, { i64, ptr } %t159)
  store ptr %t160, ptr %l110
  br label %bb24
bb24:
  %t161 = load ptr, ptr %l110, !tbaa !29
  store ptr %t161, ptr %l15, !tbaa !29
  %t162 = load ptr, ptr %l15, !tbaa !29
  %t165 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t162)
  store i32 %t165, ptr %l113
  br label %bb25
bb25:
  %t166 = load i32, ptr %l113, !tbaa !23
  store i32 %t166, ptr %l16, !tbaa !23
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load %"compiler/source:Span", ptr %l1
  %t169 = load i32, ptr %l16, !tbaa !23
  %t173 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t167, %"compiler/source:Span" %t168, i32 %t169)
  store i64 %t173, ptr %l117
  br label %bb26
bb26:
  %t174 = load i64, ptr %l117, !tbaa !24
  store i64 %t174, ptr %l17, !tbaa !24
  %t175 = load ptr, ptr %l0, !tbaa !29
  store ptr %t175, ptr %l118, !tbaa !29
  %t176 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t176, ptr %l119
  %t177 = load i64, ptr %l17, !tbaa !24
  %t179 = trunc i64 %t177 to i32
  store i32 %t179, ptr %l122, !tbaa !23
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load %"compiler/source:Span", ptr %l1
  %t183 = load ptr, ptr %l15, !tbaa !29
  %t184 = load i64, ptr %l12, !tbaa !24
  %t189 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexhaustedOrBreak(ptr %v0, ptr %v0, ptr %v0, ptr %t181, %"compiler/source:Span" %t182, ptr %t183, i64 %t184)
  store ptr %t189, ptr %l127
  br label %bb27
bb27:
  store { i64, [3 x i64] } zeroinitializer, ptr %t190
  %t191 = getelementptr { i64, [3 x i64] }, ptr %t190, i32 0, i32 0
  store i64 0, ptr %t191
  %t192 = load %"compiler/source:Span", ptr %l119
  %t193 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t192, 0
  %t194 = load i32, ptr %l122, !tbaa !23
  %t195 = insertvalue { %"compiler/source:Span", i32, ptr } %t193, i32 %t194, 1
  %t196 = load ptr, ptr %l127, !tbaa !29
  %t197 = insertvalue { %"compiler/source:Span", i32, ptr } %t195, ptr %t196, 2
  %t198 = getelementptr { i64, [3 x i64] }, ptr %t190, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t197, ptr %t198
  %t199 = load { i64, [3 x i64] }, ptr %t190
  %t201 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t199, ptr %t201
  %t202 = load ptr, ptr %l118, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t202, ptr %t201)
  br label %bb28
bb28:
  %t204 = load ptr, ptr %l0, !tbaa !29
  store ptr %t204, ptr %l130, !tbaa !29
  %t205 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t205, ptr %l131
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t206)
  store i32 %t208, ptr %l133
  br label %bb29
bb29:
  %t209 = load ptr, ptr %l130, !tbaa !29
  %t210 = load %"compiler/source:Span", ptr %l131
  %t211 = load i32, ptr %l133, !tbaa !23
  %t212 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t209, %"compiler/source:Span" %t210, i32 %t211)
  store i64 %t212, ptr %l134
  br label %bb30
bb30:
  %t213 = load i64, ptr %l134, !tbaa !24
  store i64 %t213, ptr %l18, !tbaa !24
  %t214 = load ptr, ptr %l0, !tbaa !29
  store ptr %t214, ptr %l135, !tbaa !29
  %t215 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t215, ptr %l136
  %t216 = load i64, ptr %l18, !tbaa !24
  %t218 = trunc i64 %t216 to i32
  store i32 %t218, ptr %l139, !tbaa !23
  %t220 = load ptr, ptr %l0, !tbaa !29
  store ptr %t220, ptr %l140, !tbaa !29
  %t221 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t221, ptr %l141
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t222)
  store i32 %t224, ptr %l143
  br label %bb31
bb31:
  store i32 22, ptr %l144
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load %"compiler/source:Span", ptr %l1
  %t227 = load i64, ptr %l17, !tbaa !24
  %t231 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t225, %"compiler/source:Span" %t226, i64 %t227)
  store ptr %t231, ptr %l148
  br label %bb32
bb32:
  %t232 = load ptr, ptr %l140, !tbaa !29
  %t233 = load %"compiler/source:Span", ptr %l141
  %t234 = load i32, ptr %l143, !tbaa !23
  %t235 = load i32, ptr %l144, !range !{i32 0, i32 54}
  %t236 = load ptr, ptr %l148, !tbaa !29
  %t237 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t232, %"compiler/source:Span" %t233, i32 %t234, i32 %t235, ptr %t236, ptr null)
  store ptr %t237, ptr %l149
  br label %bb33
bb33:
  store { i64, [3 x i64] } zeroinitializer, ptr %t238
  %t239 = getelementptr { i64, [3 x i64] }, ptr %t238, i32 0, i32 0
  store i64 0, ptr %t239
  %t240 = load %"compiler/source:Span", ptr %l136
  %t241 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t240, 0
  %t242 = load i32, ptr %l139, !tbaa !23
  %t243 = insertvalue { %"compiler/source:Span", i32, ptr } %t241, i32 %t242, 1
  %t244 = load ptr, ptr %l149, !tbaa !29
  %t245 = insertvalue { %"compiler/source:Span", i32, ptr } %t243, ptr %t244, 2
  %t246 = getelementptr { i64, [3 x i64] }, ptr %t238, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t245, ptr %t246
  %t247 = load { i64, [3 x i64] }, ptr %t238
  %t249 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t247, ptr %t249
  %t250 = load ptr, ptr %l135, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t250, ptr %t249)
  br label %bb34
bb34:
  %t252 = load ptr, ptr %l0, !tbaa !29
  store ptr %t252, ptr %l152, !tbaa !29
  %t253 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t253, ptr %l153
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t254)
  store i32 %t256, ptr %l155
  br label %bb35
bb35:
  %t257 = load ptr, ptr %l152, !tbaa !29
  %t258 = load %"compiler/source:Span", ptr %l153
  %t259 = load i32, ptr %l155, !tbaa !23
  %t260 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t257, %"compiler/source:Span" %t258, i32 %t259)
  store i64 %t260, ptr %l156
  br label %bb36
bb36:
  %t261 = load i64, ptr %l156, !tbaa !24
  store i64 %t261, ptr %l19, !tbaa !24
  %t262 = load ptr, ptr %l0, !tbaa !29
  store ptr %t262, ptr %l157, !tbaa !29
  %t263 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t263, ptr %l158
  %t264 = load i64, ptr %l19, !tbaa !24
  %t266 = trunc i64 %t264 to i32
  store i32 %t266, ptr %l161, !tbaa !23
  %t268 = load ptr, ptr %l0, !tbaa !29
  store ptr %t268, ptr %l162, !tbaa !29
  %t269 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t269, ptr %l163
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t272 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t270)
  store i32 %t272, ptr %l165
  br label %bb37
bb37:
  %t273 = load ptr, ptr %l162, !tbaa !29
  %t274 = load %"compiler/source:Span", ptr %l163
  %t275 = load i32, ptr %l165, !tbaa !23
  %t276 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t273, %"compiler/source:Span" %t274, i32 %t275, i64 0)
  store ptr %t276, ptr %l166
  br label %bb38
bb38:
  store { i64, [3 x i64] } zeroinitializer, ptr %t277
  %t278 = getelementptr { i64, [3 x i64] }, ptr %t277, i32 0, i32 0
  store i64 0, ptr %t278
  %t279 = load %"compiler/source:Span", ptr %l158
  %t280 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t279, 0
  %t281 = load i32, ptr %l161, !tbaa !23
  %t282 = insertvalue { %"compiler/source:Span", i32, ptr } %t280, i32 %t281, 1
  %t283 = load ptr, ptr %l166, !tbaa !29
  %t284 = insertvalue { %"compiler/source:Span", i32, ptr } %t282, ptr %t283, 2
  %t285 = getelementptr { i64, [3 x i64] }, ptr %t277, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t284, ptr %t285
  %t286 = load { i64, [3 x i64] }, ptr %t277
  %t288 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t286, ptr %t288
  %t289 = load ptr, ptr %l157, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t289, ptr %t288)
  br label %bb39
bb39:
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t293 = getelementptr %"compiler/check:Checker", ptr %t291, i32 0, i32 48
  %t295 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t293)
  store i64 %t295, ptr %l171
  br label %bb40
bb40:
  %t296 = load i64, ptr %l171, !tbaa !24
  store i64 %t296, ptr %l20, !tbaa !24
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t298 = load %"compiler/source:Span", ptr %l1
  %t302 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t297, i32 2, %"compiler/source:Span" %t298)
  store { i64, i64, i64 } %t302, ptr %l175
  br label %bb41
bb41:
  %t303 = load { i64, i64, i64 }, ptr %l175
  store { i64, i64, i64 } %t303, ptr %l21
  %t304 = getelementptr { i64, i64, i64 }, ptr %l21, i32 0, i32 0
  %t305 = load i64, ptr %t304, !tbaa !24
  store i64 %t305, ptr %l22, !tbaa !24
  %t307 = getelementptr { i64, i64, i64 }, ptr %l21, i32 0, i32 1
  %t308 = load i64, ptr %t307, !tbaa !24
  store i64 %t308, ptr %l23, !tbaa !24
  %t310 = getelementptr { i64, i64, i64 }, ptr %l21, i32 0, i32 2
  %t311 = load i64, ptr %t310, !tbaa !24
  store i64 %t311, ptr %l24, !tbaa !24
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t315 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t313)
  store ptr %t315, ptr %l181
  br label %bb42
bb42:
  %t316 = load ptr, ptr %l181, !tbaa !29
  %t318 = getelementptr %"compiler/check:frame", ptr %t316, i32 0, i32 10
  %t320 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t318)
  %t321 = extractvalue { i32, i64 } %t320, 1
  %t322 = extractvalue { i32, i64 } %t320, 0
  store i32 %t322, ptr %l185
  %t323 = icmp ne i32 %t322, 0
  br i1 %t323, label %bb44, label %ok.324, !prof !99
ok.324:
  store i64 %t321, ptr %l184
  br label %bb43
bb43:
  %t325 = load i64, ptr %l184, !tbaa !24
  store i64 %t325, ptr %l179, !tbaa !24
  br label %bb46
bb44:
  br label %bb45
bb45:
  br label %bb46
bb46:
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t328 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t326)
  store ptr %t328, ptr %l187
  br label %bb47
bb47:
  %t329 = load ptr, ptr %l187, !tbaa !29
  %t331 = getelementptr %"compiler/check:frame", ptr %t329, i32 0, i32 10
  %t332 = load i64, ptr %l22, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t331, i64 %t332)
  br label %bb48
bb48:
  %t335 = load ptr, ptr %l0, !tbaa !29
  store ptr %t335, ptr %l191, !tbaa !29
  %t336 = load ptr, ptr %l0, !tbaa !29
  store ptr %t336, ptr %l192, !tbaa !29
  %t337 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t337, ptr %l193
  %t338 = load ptr, ptr %l0, !tbaa !29
  store ptr %t338, ptr %l194, !tbaa !29
  %t339 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t339, ptr %l195
  %t340 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t340, ptr %l196, !tbaa !23
  store i32 15, ptr %l197
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t342 = load %"compiler/source:Span", ptr %l1
  %t343 = load i64, ptr %l19, !tbaa !24
  %t347 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t341, %"compiler/source:Span" %t342, i64 %t343)
  store ptr %t347, ptr %l201
  br label %bb49
bb49:
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t349 = load %"compiler/source:Span", ptr %l1
  %t350 = load i64, ptr %l18, !tbaa !24
  %t354 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t348, %"compiler/source:Span" %t349, i64 %t350)
  store ptr %t354, ptr %l205
  br label %bb50
bb50:
  %t355 = load ptr, ptr %l205, !tbaa !29
  %t356 = load ptr, ptr %l194, !tbaa !29
  %t357 = load %"compiler/source:Span", ptr %l195
  %t358 = load i32, ptr %l196, !tbaa !23
  %t359 = load i32, ptr %l197, !range !{i32 0, i32 54}
  %t360 = load ptr, ptr %l201, !tbaa !29
  %t362 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t356, %"compiler/source:Span" %t357, i32 %t358, i32 %t359, ptr %t360, ptr %t355)
  store ptr %t362, ptr %l207
  br label %bb51
bb51:
  %t363 = load i64, ptr %l22, !tbaa !24
  %t364 = load ptr, ptr %l192, !tbaa !29
  %t365 = load %"compiler/source:Span", ptr %l193
  %t366 = load ptr, ptr %l207, !tbaa !29
  %t368 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebreakUnless(ptr %v0, ptr %v0, ptr %v0, ptr %t364, %"compiler/source:Span" %t365, ptr %t366, i64 %t363)
  store ptr %t368, ptr %l209
  br label %bb52
bb52:
  %t369 = load ptr, ptr %l191, !tbaa !29
  %t370 = load ptr, ptr %l209, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t369, ptr %t370)
  br label %bb53
bb53:
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t372 = load i32, ptr %l16, !tbaa !23
  %t375 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t371, i32 %t372)
  store i32 %t375, ptr %l212
  br label %bb54
bb54:
  %t376 = load i32, ptr %l212, !tbaa !23
  store i32 %t376, ptr %l25, !tbaa !23
  %t377 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t377, ptr %l213
  %t378 = load ptr, ptr %l0, !tbaa !29
  %t379 = load i32, ptr %l16, !tbaa !23
  %t382 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t378, i32 %t379)
  store i32 %t382, ptr %l216
  br label %bb55
bb55:
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t384 = load %"compiler/source:Span", ptr %l1
  %t385 = load i64, ptr %l17, !tbaa !24
  %t389 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t383, %"compiler/source:Span" %t384, i64 %t385)
  store ptr %t389, ptr %l220
  br label %bb56
bb56:
  store { i64, [4 x i64] } zeroinitializer, ptr %t390
  %t391 = getelementptr { i64, [4 x i64] }, ptr %t390, i32 0, i32 0
  store i64 2, ptr %t391
  %t392 = load %"compiler/source:Span", ptr %l213
  %t393 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t392, 0
  %t394 = load i32, ptr %l216, !tbaa !23
  %t395 = insertvalue { %"compiler/source:Span", i32, ptr } %t393, i32 %t394, 1
  %t396 = load ptr, ptr %l220, !tbaa !29
  %t397 = insertvalue { %"compiler/source:Span", i32, ptr } %t395, ptr %t396, 2
  %t398 = getelementptr { i64, [4 x i64] }, ptr %t390, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t397, ptr %t398
  %t399 = load { i64, [4 x i64] }, ptr %t390
  %t401 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t399, ptr %t401
  store ptr %t401, ptr %l26, !tbaa !29
  %t403 = load ptr, ptr %l0, !tbaa !29
  store ptr %t403, ptr %l223, !tbaa !29
  %t404 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t404, ptr %l224
  %t405 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t405, ptr %l225
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t408 = getelementptr %"compiler/check:Checker", ptr %t406, i32 0, i32 1
  %t409 = load ptr, ptr %t408, !tbaa !29
  %t411 = getelementptr %"compiler/generic:Program", ptr %t409, i32 0, i32 2
  %t412 = load i32, ptr %l25, !tbaa !23
  %t415 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t411, i32 %t412)
  store i32 %t415, ptr %l230
  br label %bb57
bb57:
  %t416 = load ptr, ptr %l26, !tbaa !29
  store ptr %t416, ptr %l231, !tbaa !29
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t418 = load %"compiler/source:Span", ptr %l1
  %t419 = load i64, ptr %l19, !tbaa !24
  %t423 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t417, %"compiler/source:Span" %t418, i64 %t419)
  store ptr %t423, ptr %l235
  br label %bb58
bb58:
  %t424 = load ptr, ptr %l231, !tbaa !29
  %t425 = load ptr, ptr %l235, !tbaa !29
  %t427 = call %"compiler/typed:Elem" @compiler_2ftyped_3aElem_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %t424, ptr %t425, i32 0)
  store %"compiler/typed:Elem" %t427, ptr %l237
  br label %bb59
bb59:
  %t428 = load %"compiler/typed:Elem", ptr %l237
  %t429 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Elem" %t428, ptr %t429
  store { i64, [4 x i64] } zeroinitializer, ptr %t430
  %t431 = getelementptr { i64, [4 x i64] }, ptr %t430, i32 0, i32 0
  store i64 4, ptr %t431
  %t432 = load %"compiler/source:Span", ptr %l225
  %t433 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t432, 0
  %t434 = load i32, ptr %l230, !tbaa !23
  %t435 = insertvalue { %"compiler/source:Span", i32, ptr } %t433, i32 %t434, 1
  %t437 = insertvalue { %"compiler/source:Span", i32, ptr } %t435, ptr %t429, 2
  %t438 = getelementptr { i64, [4 x i64] }, ptr %t430, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t437, ptr %t438
  %t439 = load { i64, [4 x i64] }, ptr %t430
  %t441 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t439, ptr %t441
  %t442 = load ptr, ptr %l223, !tbaa !29
  %t443 = load %"compiler/source:Span", ptr %l224
  %t445 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t442, %"compiler/source:Span" %t443, ptr %t441)
  store ptr %t445, ptr %l241
  br label %bb60
bb60:
  %t446 = load ptr, ptr %l241, !tbaa !29
  store ptr %t446, ptr %l27, !tbaa !29
  %t447 = load ptr, ptr %l0, !tbaa !29
  store ptr %t447, ptr %l242, !tbaa !29
  %t448 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t448, ptr %l243
  %t449 = load ptr, ptr %l2, !tbaa !29
  store ptr %t449, ptr %l244, !tbaa !29
  %t450 = load i64, ptr %l9, !tbaa !24
  store i64 %t450, ptr %l245, !tbaa !24
  %t451 = load ptr, ptr %l5, !tbaa !29
  %t453 = icmp eq ptr %t451, null
  %t455 = xor i1 %t453, true
  br i1 %t455, label %bb61, label %bb62
bb61:
  %t457 = load ptr, ptr %l27, !tbaa !29
  store ptr %t457, ptr %l249, !tbaa !29
  br label %bb64
bb62:
  %t459 = load ptr, ptr %l0, !tbaa !29
  %t460 = load ptr, ptr %l27, !tbaa !29
  %t461 = load %"compiler/source:Span", ptr %l1
  %t465 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueRef(ptr %v0, ptr %v0, ptr %v0, ptr %t459, ptr %t460, %"compiler/source:Span" %t461, i1 false, i1 true)
  store ptr %t465, ptr %l254
  br label %bb63
bb63:
  %t466 = load ptr, ptr %l254, !tbaa !29
  store ptr %t466, ptr %l249, !tbaa !29
  br label %bb64
bb64:
  %t467 = load ptr, ptr %l242, !tbaa !29
  %t468 = load %"compiler/source:Span", ptr %l243
  %t469 = load ptr, ptr %l244, !tbaa !29
  %t470 = load i64, ptr %l245, !tbaa !24
  %t471 = load ptr, ptr %l249, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelementLocals(ptr %v0, ptr %v1, ptr %v0, ptr %t467, %"compiler/source:Span" %t468, ptr %t469, i64 %t470, ptr %t471, i1 false)
  br label %bb65
bb65:
  %t472 = load ptr, ptr %l0, !tbaa !29
  store ptr %t472, ptr %l255, !tbaa !29
  %t473 = load ptr, ptr %l0, !tbaa !29
  %t474 = load ptr, ptr %l2, !tbaa !29
  %t476 = getelementptr %"compiler/ast:ForIn", ptr %t474, i32 0, i32 1
  %t477 = load i32, ptr %t476, !tbaa !23
  %t480 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %t473, i32 %t477)
  store i64 %t480, ptr %l259
  br label %bb66
bb66:
  %t481 = load ptr, ptr %l0, !tbaa !29
  %t483 = getelementptr %"compiler/check:Checker", ptr %t481, i32 0, i32 1
  %t484 = load ptr, ptr %t483, !tbaa !29
  %t486 = getelementptr %"compiler/generic:Program", ptr %t484, i32 0, i32 2
  %t487 = load i32, ptr %l25, !tbaa !23
  %t490 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t486, i32 %t487)
  store i32 %t490, ptr %l264
  br label %bb67
bb67:
  %t491 = load ptr, ptr %l255, !tbaa !29
  %t492 = load i64, ptr %l259, !tbaa !24
  %t493 = load i32, ptr %l264, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkWalkUnique(ptr %v0, ptr %t491, i64 %t492, i32 %t493)
  br label %bb68
bb68:
  %t494 = load ptr, ptr %l0, !tbaa !29
  %t495 = load ptr, ptr %l2, !tbaa !29
  %t496 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkBody(ptr %v0, ptr %v1, ptr %v3, ptr %t494, ptr %t495, ptr %t496, i32 %a6)
  br label %bb69
bb69:
  %t502 = load ptr, ptr %l0, !tbaa !29
  %t504 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t502)
  store ptr %t504, ptr %l271
  br label %bb70
bb70:
  %t505 = load ptr, ptr %l271, !tbaa !29
  %t507 = getelementptr %"compiler/check:frame", ptr %t505, i32 0, i32 10
  %t509 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t507)
  %t510 = extractvalue { i32, i64 } %t509, 1
  %t511 = extractvalue { i32, i64 } %t509, 0
  store i32 %t511, ptr %l275
  %t512 = icmp ne i32 %t511, 0
  br i1 %t512, label %bb72, label %ok.513, !prof !99
ok.513:
  store i64 %t510, ptr %l274
  br label %bb71
bb71:
  %t514 = load i64, ptr %l274, !tbaa !24
  store i64 %t514, ptr %l269, !tbaa !24
  br label %bb74
bb72:
  br label %bb73
bb73:
  br label %bb74
bb74:
  %t515 = load ptr, ptr %l0, !tbaa !29
  %t517 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t515)
  store ptr %t517, ptr %l278
  br label %bb75
bb75:
  %t518 = load ptr, ptr %l278, !tbaa !29
  %t520 = getelementptr %"compiler/check:frame", ptr %t518, i32 0, i32 11
  %t522 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t520)
  %t523 = extractvalue { i32, i64 } %t522, 1
  %t524 = extractvalue { i32, i64 } %t522, 0
  store i32 %t524, ptr %l282
  %t525 = icmp ne i32 %t524, 0
  br i1 %t525, label %bb77, label %ok.526, !prof !99
ok.526:
  store i64 %t523, ptr %l281
  br label %bb76
bb76:
  %t527 = load i64, ptr %l281, !tbaa !24
  store i64 %t527, ptr %l276, !tbaa !24
  br label %bb79
bb77:
  br label %bb78
bb78:
  br label %bb79
bb79:
  %t528 = load ptr, ptr %l0, !tbaa !29
  %t529 = load i64, ptr %l22, !tbaa !24
  %t530 = load i64, ptr %l23, !tbaa !24
  %t531 = load i64, ptr %l24, !tbaa !24
  %t532 = load i64, ptr %l20, !tbaa !24
  %t538 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v0, ptr %t528, i64 %t529, i64 %t530, i64 %t531, i64 %t532)
  store ptr %t538, ptr %l288
  br label %bb80
bb80:
  %t539 = load ptr, ptr %l288, !tbaa !29
  store ptr %t539, ptr %l28, !tbaa !29
  %t540 = load ptr, ptr %l0, !tbaa !29
  %t542 = getelementptr %"compiler/check:Checker", ptr %t540, i32 0, i32 48
  %t544 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t542)
  store i64 %t544, ptr %l291
  br label %bb81
bb81:
  %t545 = load i64, ptr %l291, !tbaa !24
  store i64 %t545, ptr %l29, !tbaa !24
  %t546 = load ptr, ptr %l0, !tbaa !29
  %t547 = load %"compiler/source:Span", ptr %l1
  %t551 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t546, i32 3, %"compiler/source:Span" %t547)
  store { i64, i64, i64 } %t551, ptr %l295
  br label %bb82
bb82:
  %t552 = load { i64, i64, i64 }, ptr %l295
  store { i64, i64, i64 } %t552, ptr %l30
  %t553 = getelementptr { i64, i64, i64 }, ptr %l30, i32 0, i32 0
  %t554 = load i64, ptr %t553, !tbaa !24
  store i64 %t554, ptr %l31, !tbaa !24
  %t556 = getelementptr { i64, i64, i64 }, ptr %l30, i32 0, i32 1
  %t557 = load i64, ptr %t556, !tbaa !24
  store i64 %t557, ptr %l32, !tbaa !24
  %t559 = getelementptr { i64, i64, i64 }, ptr %l30, i32 0, i32 2
  %t560 = load i64, ptr %t559, !tbaa !24
  store i64 %t560, ptr %l33, !tbaa !24
  %t562 = load ptr, ptr %l0, !tbaa !29
  store ptr %t562, ptr %l299, !tbaa !29
  %t563 = load ptr, ptr %l0, !tbaa !29
  store ptr %t563, ptr %l300, !tbaa !29
  %t564 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t564, ptr %l301
  %t565 = load i64, ptr %l19, !tbaa !24
  store i64 %t565, ptr %l302, !tbaa !24
  %t566 = load ptr, ptr %l0, !tbaa !29
  store ptr %t566, ptr %l303, !tbaa !29
  %t567 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t567, ptr %l304
  %t568 = load ptr, ptr %l0, !tbaa !29
  %t570 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t568)
  store i32 %t570, ptr %l306
  br label %bb83
bb83:
  %t571 = load ptr, ptr %l303, !tbaa !29
  %t572 = load %"compiler/source:Span", ptr %l304
  %t573 = load i32, ptr %l306, !tbaa !23
  %t574 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t571, %"compiler/source:Span" %t572, i32 %t573, i64 1)
  store ptr %t574, ptr %l307
  br label %bb84
bb84:
  %t575 = load ptr, ptr %l300, !tbaa !29
  %t576 = load %"compiler/source:Span", ptr %l301
  %t577 = load i64, ptr %l302, !tbaa !24
  %t578 = load ptr, ptr %l307, !tbaa !29
  %t579 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eaddTo(ptr %v0, ptr %v0, ptr %v0, ptr %t575, %"compiler/source:Span" %t576, i64 %t577, ptr %t578)
  store ptr %t579, ptr %l308
  br label %bb85
bb85:
  %t580 = load ptr, ptr %l299, !tbaa !29
  %t581 = load ptr, ptr %l308, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t580, ptr %t581)
  br label %bb86
bb86:
  %t582 = load i64, ptr %l9, !tbaa !24
  %t584 = icmp sge i64 %t582, 0
  br i1 %t584, label %bb87, label %bb88
bb87:
  %t586 = load ptr, ptr %l0, !tbaa !29
  store ptr %t586, ptr %l311, !tbaa !29
  %t587 = load ptr, ptr %l0, !tbaa !29
  store ptr %t587, ptr %l312, !tbaa !29
  %t588 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t588, ptr %l313
  %t589 = load i64, ptr %l9, !tbaa !24
  store i64 %t589, ptr %l314, !tbaa !24
  %t590 = load ptr, ptr %l0, !tbaa !29
  store ptr %t590, ptr %l315, !tbaa !29
  %t591 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t591, ptr %l316
  %t592 = load ptr, ptr %l0, !tbaa !29
  %t594 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t592)
  store i32 %t594, ptr %l318
  br label %bb89
bb88:
  br label %bb93
bb89:
  %t595 = load ptr, ptr %l315, !tbaa !29
  %t596 = load %"compiler/source:Span", ptr %l316
  %t597 = load i32, ptr %l318, !tbaa !23
  %t598 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t595, %"compiler/source:Span" %t596, i32 %t597, i64 1)
  store ptr %t598, ptr %l319
  br label %bb90
bb90:
  %t599 = load ptr, ptr %l312, !tbaa !29
  %t600 = load %"compiler/source:Span", ptr %l313
  %t601 = load i64, ptr %l314, !tbaa !24
  %t602 = load ptr, ptr %l319, !tbaa !29
  %t603 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eaddTo(ptr %v0, ptr %v0, ptr %v0, ptr %t599, %"compiler/source:Span" %t600, i64 %t601, ptr %t602)
  store ptr %t603, ptr %l320
  br label %bb91
bb91:
  %t604 = load ptr, ptr %l311, !tbaa !29
  %t605 = load ptr, ptr %l320, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t604, ptr %t605)
  br label %bb92
bb92:
  br label %bb93
bb93:
  %t606 = load ptr, ptr %l0, !tbaa !29
  %t607 = load i64, ptr %l31, !tbaa !24
  %t608 = load i64, ptr %l32, !tbaa !24
  %t609 = load i64, ptr %l33, !tbaa !24
  %t610 = load i64, ptr %l29, !tbaa !24
  %t616 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v0, ptr %t606, i64 %t607, i64 %t608, i64 %t609, i64 %t610)
  store ptr %t616, ptr %l326
  br label %bb94
bb94:
  %t617 = load ptr, ptr %l326, !tbaa !29
  %t618 = load ptr, ptr %l0, !tbaa !29
  %t619 = load %"compiler/source:Span", ptr %l1
  %t620 = load ptr, ptr %l28, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t623
  %t624 = getelementptr { i64, [3 x i64] }, ptr %t623, i32 0, i32 0
  store i64 4, ptr %t624
  %t626 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t619, 0
  %t628 = insertvalue { %"compiler/source:Span", ptr, ptr } %t626, ptr %t620, 1
  %t630 = insertvalue { %"compiler/source:Span", ptr, ptr } %t628, ptr %t617, 2
  %t631 = getelementptr { i64, [3 x i64] }, ptr %t623, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t630, ptr %t631
  %t632 = load { i64, [3 x i64] }, ptr %t623
  %t634 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t632, ptr %t634
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t618, ptr %t634)
  br label %bb95
bb95:
  %t637 = load ptr, ptr %l0, !tbaa !29
  store ptr %t637, ptr %l334, !tbaa !29
  %t638 = load ptr, ptr %l0, !tbaa !29
  store ptr %t638, ptr %l335, !tbaa !29
  %t639 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t639, ptr %l336
  %t640 = load i64, ptr %l8, !tbaa !24
  store i64 %t640, ptr %l337, !tbaa !24
  %t641 = load ptr, ptr %l0, !tbaa !29
  %t642 = load %"compiler/source:Span", ptr %l1
  %t643 = load i64, ptr %l18, !tbaa !24
  %t647 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t641, %"compiler/source:Span" %t642, i64 %t643)
  store ptr %t647, ptr %l341
  br label %bb96
bb96:
  %t648 = load ptr, ptr %l335, !tbaa !29
  %t649 = load %"compiler/source:Span", ptr %l336
  %t650 = load i64, ptr %l337, !tbaa !24
  %t651 = load ptr, ptr %l341, !tbaa !29
  %t652 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eaddTo(ptr %v0, ptr %v0, ptr %v0, ptr %t648, %"compiler/source:Span" %t649, i64 %t650, ptr %t651)
  store ptr %t652, ptr %l342
  br label %bb97
bb97:
  %t653 = load ptr, ptr %l334, !tbaa !29
  %t654 = load ptr, ptr %l342, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t653, ptr %t654)
  br label %bb98
bb98:
  %t655 = load ptr, ptr %l0, !tbaa !29
  %t656 = load i64, ptr %l12, !tbaa !24
  %t657 = load i64, ptr %l13, !tbaa !24
  %t658 = load i64, ptr %l14, !tbaa !24
  %t659 = load i64, ptr %l10, !tbaa !24
  %t665 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v0, ptr %t655, i64 %t656, i64 %t657, i64 %t658, i64 %t659)
  store ptr %t665, ptr %l348
  br label %bb99
bb99:
  %t666 = load ptr, ptr %l348, !tbaa !29
  %t667 = load ptr, ptr %l0, !tbaa !29
  %t668 = load %"compiler/source:Span", ptr %l1
  store { i64, [3 x i64] } zeroinitializer, ptr %t670
  %t671 = getelementptr { i64, [3 x i64] }, ptr %t670, i32 0, i32 0
  store i64 4, ptr %t671
  %t673 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t668, 0
  %t675 = insertvalue { %"compiler/source:Span", ptr, ptr } %t673, ptr %t666, 1
  %t676 = insertvalue { %"compiler/source:Span", ptr, ptr } %t675, ptr null, 2
  %t677 = getelementptr { i64, [3 x i64] }, ptr %t670, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t676, ptr %t677
  %t678 = load { i64, [3 x i64] }, ptr %t670
  %t680 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t678, ptr %t680
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t667, ptr %t680)
  br label %bb100
bb100:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/check:heldCand" @compiler_2fcheck_3aheldCand_2ector(ptr %v0, i64 %a0, i64 %a1, i64 %a2) #0 {
entry:
  %rv = alloca %"compiler/check:heldCand"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/check:heldCand" undef, i64 %a0, 0
  %t10 = insertvalue %"compiler/check:heldCand" %t8, i64 %a1, 1
  %t12 = insertvalue %"compiler/check:heldCand" %t10, i64 %a2, 2
  store %"compiler/check:heldCand" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:heldCand", ptr %rv
  ret %"compiler/check:heldCand" %rr
}

declare void @__olang_check_failed(ptr) cold noreturn
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2ecompiler_2fcheck_3aframe_2e4 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @__olang_region_or(ptr, ptr)
declare ptr @__olang_region_home(ptr)
declare void @__olang_region_settle_in(ptr, ptr)
declare void @__olang_region_drop(ptr) noinline
@olang_2esole_2ecompiler_2fgeneric_3aContext_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fgeneric_3aContext_2e3 = weak hidden constant i1 false
@olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e0 = weak hidden constant i1 false
declare void @__olang_region_release_part(ptr, i64) noinline
@olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e1 = weak hidden constant i1 false
@olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e2 = weak hidden constant i1 false
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@olang_2esole_2ecompiler_2fcheck_3aContractAsk_2e9 = weak hidden constant i1 false
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@.d0 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@__olang_empty_array = external constant [16 x i64]
declare ptr @llvm.coro.promise(ptr, i32, i1)
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0 = weak hidden constant i1 false
declare ptr @__olang_region_make_part(ptr) noinline
@.d1 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"is a struct or an enum" }>, align 8
@.d2 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d3 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"a builder" }>, align 8
@olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2ememberRules_2elocal_2e10 = weak hidden constant i1 false
declare void @__olang_region_release(ptr) noinline
@.d4 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d5 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2eownerWritten_2elocal_2e10 = weak hidden constant i1 false
@.d6 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" ? " }>, align 8
@.d7 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d8 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"<" }>, align 8
@.d9 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c">" }>, align 8
@.d10 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"<I64>" }>, align 8
@.d11 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"true" }>, align 8
@.d12 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Name" }>, align 8
@.d13 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Kind" }>, align 8
@.d14 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Size" }>, align 8
@.d15 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Align" }>, align 8
@.d16 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Length" }>, align 8
@.d17 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"Nullable" }>, align 8
@.d18 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Kind" }>, align 8
@.d19 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Length" }>, align 8
@.d20 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Size" }>, align 8
@.d21 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Align" }>, align 8
@.d22 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Type" }>, align 8
@.d23 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"Default" }>, align 8
@.d24 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"Name, Type, Offset, BitOffset, Bits and Of" }>, align 8
@.d25 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"Name, Value and Fields" }>, align 8
@.d26 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"Name, Type, HasDefault and Default" }>, align 8
@.d27 = private constant <{ i64, [108 x i8] }> <{ i64 0, [108 x i8] c"Name, Type, Params, Results, Errors, NoReturn, Exported, Extern, Commutes and G42's facts - and it is called" }>, align 8
@.d28 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Type" }>, align 8
@.d29 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"field" }>, align 8
@.d30 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"case" }>, align 8
@.d31 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"parameter" }>, align 8
@.d32 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"function" }>, align 8
@.d33 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"result" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d34 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Inc" }>, align 8
@.d35 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Dec" }>, align 8
@.d36 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Plus" }>, align 8
@.d37 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Minus" }>, align 8
@.d38 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Inc" }>, align 8
@.d39 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Dec" }>, align 8
@.d40 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"'++'" }>, align 8
@.d41 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"'--'" }>, align 8
@.d42 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"AtomicStore" }>, align 8
@.d43 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"AtomicAdd" }>, align 8
@.d44 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"AtomicSwap" }>, align 8
@.d45 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"AtomicCompareSwap" }>, align 8
@.d46 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"AtomicLoad" }>, align 8
@.d47 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d48 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
@.d49 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
define internal i1 @olang_lambda_50(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = icmp slt i64 %a0, %a1
  store i1 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1 = weak hidden constant i1 false
@.d51 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_9eb839b1731ec753_72a752a69f5cff = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eevalOnly(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2eclosedExpr(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5, i1 %a6, i32 %a7, i64 %a8)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i32 %a3, i32 %a4)
declare void @compiler_2fgeneric_3aContext_2ector(ptr %out, ptr %v0, i64 %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efitsTest(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v1, i32 %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %a0)
declare { { i64, [3 x i64] }, { i64, ptr } } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTopContext(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_3aContractAsk_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, i64 %a0, i64 %a1, %"compiler/source:Span" %a2, i64 %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5, { i64, ptr } %a6, { i64, [3 x i64] } %a7, { i64, ptr } %a8, { i64, ptr } %a9, i1 %a10, i64 %a11, i64 %a12)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aContractAsk_3e_2ePu_H286c5e5dcd81788bf1de6ef6fc9774a9(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_H06f4ae43b564aa38800728c5b9a6edfe(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_Hb04d670045d084ea2498d9030c4fbba9(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_26_3e_2ector(ptr %v0, i64 %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epatWild(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_fbe266e4ae717040_cab691a9684e8df4 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2epatTail(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_H19842cc3f9f17801919cd111c108caa0(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecoversRows(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, i64 %a3)
@olang_loc_ab02bd200d42d56d_7bb0032642cbe501 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCtorVarOfGeneric(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/diagmsg:Msg" %a2)
declare %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" @compiler_2fgeneric_2eFieldDecls.walk(ptr %v0, ptr %v1, ptr %a0)
declare { i32, ptr } @std_2fprelude_2fiterator_2estd_2fprelude_2fiterator_3aViewGenerator_3ccompiler_2fast_3aV_Hf179e857cb72c72900f4614cd5df5a25(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCtorGenericInferredField(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordIn(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCtorFieldNamesVar(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i64 @compiler_2ftyped_2eCalledBody(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eInst(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsGenerator(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_7aa3345d2beba7fc_151c01b23d5f0fc0 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
@olang_loc_a6a18c8586cf83c4_fafef84db4cc6ad8 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
declare i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %a0)
@G_2ecompiler_2ftypes_2eNullT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\0F\00\00\00" }>, align 8
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLambdaResultUninferable(ptr %v0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einferred(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i1 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eTuple(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, i64 %a1, { i64, ptr } %a2, ptr %a3, i32 %a4, i32 %a5, i1 %a6)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnyTable_3e_2eLen_H9daf28210c013890fd7cb07d1d61ba6e(ptr %v0, ptr %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v0, ptr %a0)
declare %"compiler/generic:AnyTable" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnyTable_3e_2eAt__He9601a52fe5cfa5abe1b41d520aed001(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ejudgeSlot(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberAt(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberOwnerRef(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMemberInPlaceKind(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ememberOwnerOk(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, { i64, ptr } %a3)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberName(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamespaceTaken(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflectedName(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBuilderOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i1 %a3)
declare %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %a0, i64 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMemberNameTaken(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberBefore(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMemberTwice(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_cc787edf2deeff46_6db42fab5d8ba9ba = external constant [0 x i8]
@olang_loc_ca5f636100c98fd4_9c6d5a533441f8c8 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_3e_2ePus_H7d1143c374f11cf9cab67f1e79e7bcb4(ptr %v0, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_3e_2eJoin(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuilderOwnerBare(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
@olang_loc_a6377e7673ccb83e_f00ca4f503dea522 = external constant [0 x i8]
@olang_loc_4543a2f38c43ab3f_a376b2729e3ac623 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamDefault(ptr %v0, ptr %v1, ptr %a0, %"compiler/generic:Desc" %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescName(ptr %v0, ptr %v1, ptr %a0, %"compiler/generic:Desc" %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflNoDefault(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare { i32, { i64, ptr } } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescType(ptr %v0, ptr %v1, ptr %a0, %"compiler/generic:Desc" %a1)
declare %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2fgeneric_2eDescFunc = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultArg(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i64 %a3, i1 %a4, i32 %a5, i32 %a6)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorDefault(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i32 %a3)
declare %"compiler/check:reflList" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflListValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflType(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eviaTypeVar(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasCase(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fgeneric_2eProjectsType(ptr %v0, { i64, ptr } %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflTypeNotValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflConst(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/check:reflVal" %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflNoKind(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflNoLength(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflNoLayout(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2eisLimitName(ptr %v0, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflNoMember(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescTypeOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2fgeneric_2eDescCase = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eDescParam = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eDescField = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@olang_loc_6fa12bf18c08968_7f63ef0109416d3c = external constant [0 x i8]
@olang_loc_366830190f407939_a82d5f1c611378ed = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflDescNoMember(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3)
@olang_loc_fe73ad2ef66395ad_6bb388f528f40629 = external constant [0 x i8]
@olang_loc_97840d8df2a94e80_8f65c6ae19d7bb5c = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3, ptr %a4, { i64, ptr } %a5, { i64, ptr } %a6, { i64, ptr } %a7)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3, { i64, ptr } %a4, i64 %a5, i1 %a6)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2efloatBits(i32 %a0, double %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3)
@olang_loc_729de81d3b051823_7dce08f61f50e4bf = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAtomicNotInteger(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAtomicWidth(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperandAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAtomicNotPlace(ptr %v0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elendsPacked(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteWrite(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceWritable(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAtomicNotWritable(ptr %v0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArgCount(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2eLen_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd1(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edrain(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclContext(ptr %out, ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTraitErrsUnwritten(ptr %v0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esigWritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_cc3b7a6e318210b6_464c855cb4a991aa = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0, i64 %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epatternNames(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i1 %a3)
declare %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Ha72624ba64524ee3315305b5d1bfb369(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20co_H6cf169b12565f300e9fe11f1c8d55061(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H943a9bb03970f71acf57214091669a7d(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eVar(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclParams(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_894a72349cd7ef67_30624e129d4b77a3 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstance(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/check:typeCase" @compiler_2fcheck_3atypeCase_2ector(ptr %v0, i1 %a0, i1 %a1, i32 %a2, i64 %a3)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypedHoleUntyped(ptr %v0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hda627d7755eecb5b938ca977110d67b2(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20I6_Hd1b8e91149b724287340e79c8c928444(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1c, ptr %a1e)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %a0)
declare %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalType(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H88f30ae03b1b7707751e39c47edff247(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypedHole(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2ePush_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aheldCand_3e_2ePush_3ccompiler_2fcheck_3aheldCand_3e(ptr %v0, ptr %a0, %"compiler/check:heldCand" %a1)
@olang_loc_b35f41bb006554d6_a1d87dcad76a5f72 = external constant [0 x i8]
@olang_loc_943678799cf3b8f7_240de00f13c53f3 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %a0)
declare { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
@olang_loc_dcf5b9aec39ad50b_4fa64d0de79beb7f = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloopCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, ptr %a3, { i64, ptr } %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexhaustedOrBreak(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueRef(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i1 %a3, i1 %a4)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelementLocals(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, ptr %a4, i1 %a5)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkBody(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecountPost(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i64 %a3)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eborrowedSource(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebreakUnless(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/typed:Elem" @compiler_2ftyped_3aElem_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkWalkUnique(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eaddTo(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, ptr %a3)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
