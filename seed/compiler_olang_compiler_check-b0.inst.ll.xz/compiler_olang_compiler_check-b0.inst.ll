; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78" = type { i64, ptr }
%"std/prelude/map:MapEntry.457163fdec6e9d9dd96e1de2e7dfe82b" = type { i64, { i64, [3 x i64] } }
%"std/prelude/map:MapEntry.9f40551e0d6019a8e678d8f53048b6ba" = type { i64, %"compiler/source:Span" }
%"compiler/source:Span" = type { i32, i32 }
%"std/prelude/map:MapEntry.30ce370d829aff239a34c06a62e67c2e" = type { i64, %"compiler/typed:ContractInfo" }
%"compiler/typed:ContractInfo" = type { { i64, ptr }, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406" = type { i64, { i64, ptr } }
%"std/prelude/map:MapEntry.886e108519677d9fd0a73cc9f7e545eb" = type { %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", i32 }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"std/prelude/map:MapEntry.c479befe3d340af6fb5e3e84080d9cfc" = type { %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", %"compiler/check:fixedInit" }
%"compiler/check:fixedInit" = type { ptr, i32 }
%"std/prelude/map:MapEntry.cae77de4d581cc3ff23f947d2513f613" = type { %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", %"compiler/check:roOrigin" }
%"compiler/check:roOrigin" = type { ptr, i1 }
%"std/prelude/map:MapEntry.39ab5235a9e7cc4d21ab272df52b187f" = type { %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/map:MapEntry.b139c4f75a6545712256427180a82a06" = type { %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" }
%"std/prelude/map:MapEntry.5c05261437902d544b32c18bccabd218" = type { %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", %"compiler/check:knownRange" }
%"compiler/check:knownRange" = type { i64, i64, i64 }
%"compiler/check:AssertAsk" = type { i64, i64, %"compiler/source:Span", %"compiler/source:Span", i64, i64, i1, { i64, ptr }, { i64, ptr }, { i64, [3 x i64] }, { i64, ptr }, { i64, [3 x i64] }, { i64, ptr } }
%"compiler/check:ContractAsk" = type { i64, i64, %"compiler/source:Span", i64, %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, i1, i64, i64 }
%"compiler/check:EmbedAsk" = type { i64, i64, i32 }
%"compiler/check:Gap" = type { i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/check:TopAssertAsk" = type { i64, %"compiler/source:Span", %"compiler/source:Span", i64, i64 }
%"compiler/check:UnrollAsk" = type { { i64, ptr }, { i64, ptr }, i64, i32 }
%"compiler/check:errBind" = type { i32, i64, i32, %"compiler/source:Span" }
%"compiler/check:factRead" = type { i64, i64, { i64, ptr }, i1, i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/check:fixedProof" = type { i64, { i64, ptr }, i64 }
%"compiler/check:heldCand" = type { i64, i64, i64 }
%"compiler/check:inPlaceRead" = type { { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"compiler/source:Span" }
%"compiler/check:landing" = type { i64, i64, %"compiler/source:Span", i32, i64 }
%"compiler/check:loopUse" = type { %"compiler/source:Span", i64, { i64, ptr } }
%"compiler/check:rangeIndex" = type { i64, %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i64, i64 }
%"compiler/check:tailAsk" = type { i64, i64, %"compiler/source:Span", i64 }
%"compiler/check:typeCase" = type { i1, i1, i32, i64, i64, i1 }
%"compiler/check:unsetCand" = type { i64, i64, i64, i1, i64, %"compiler/source:Span", i32, i1 }
%"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f" = type { %"compiler/generic:Origin", i64 }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa" = type { i32, i32 }
%"std/pair:Pair.b139c4f75a6545712256427180a82a06" = type { %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" }
define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fcheck_3arawTable_2_H45874b6529a9a628c7ab75c73feaa39a(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l38 = alloca i64
  %l44 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l72 = alloca i64
  %l78 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  store { i64, ptr } %t23, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_830b3f6bba02f612_9c6c608b7d8bc3c6)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_830b3f6bba02f612_9c6c608b7d8bc3c6)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  %t52 = call ptr @__olang_region_make_part(ptr %v0)
  %t53 = ptrtoint ptr %t52 to i64
  store i64 %t53, ptr %l31, !tbaa !24
  store i64 %t50, ptr %l32, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t57 = load i64, ptr %l32, !tbaa !24
  %t58 = extractvalue { i64, ptr } %t55, 0
  %t59 = mul i64 %t58, 16
  %t60 = mul i64 %t57, 16
  %t61 = extractvalue { i64, ptr } %t55, 1
  %t62 = call ptr @__olang_grow_in_place(ptr %t61, i64 %t59, i64 %t60, i64 %t57)
  %t63 = icmp ne ptr %t62, null
  %t64 = select i1 %t63, i64 %t57, i64 0
  %t65 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t62, 1
  store { i64, ptr } %t66, ptr %l35, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t67, 0
  %t70 = icmp ne i64 %t68, 0
  br i1 %t70, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_830b3f6bba02f612_9c6c608b7d8bc3c6)
  unreachable
bb10:
  %t72 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t72, ptr %l33, !tbaa !27
  br label %bb12
bb11:
  %t73 = load i64, ptr %l32, !tbaa !24
  %t74 = mul i64 %t73, 16
  %t75 = load i64, ptr %l31
  %t76 = inttoptr i64 %t75 to ptr
  %t77 = call ptr @__olang_held_alloc(ptr %t76, i64 %t74)
  %t78 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  store { i64, ptr } %t79, ptr %l33, !tbaa !27
  store i64 0, ptr %l38, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb13
bb12:
  %t80 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 0
  %t83 = icmp eq i64 %t81, 0
  br i1 %t83, label %bb19, label %bb20
bb13:
  %t85 = load i64, ptr %l5, !tbaa !24
  %t86 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t91 = icmp slt i64 %t85, %t88
  %t93 = xor i1 %t91, true
  br i1 %t93, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t95 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t95, ptr %l44, !tbaa !27
  %t96 = load i64, ptr %l5, !tbaa !24
  %t98 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78", ptr %t99, i64 %t96
  %t101 = load %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78", ptr %t100
  %t103 = load i64, ptr %l38, !tbaa !24
  %t104 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78", ptr %t105, i64 %t103
  store %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78" %t101, ptr %t106
  %t107 = load i64, ptr %l38, !tbaa !24
  %t108 = add i64 %t107, 1
  store i64 %t108, ptr %l38, !tbaa !24
  br label %bb17
bb17:
  %t109 = load i64, ptr %l5, !tbaa !24
  %t112 = add i64 %t109, 1
  store i64 %t112, ptr %l5, !tbaa !24
  br label %bb13
bb18:
  br label %bb12
bb19:
  store { i64, ptr } zeroinitializer, ptr %l33, !tbaa !27
  br label %bb20
bb20:
  %t114 = load i64, ptr %l31
  %t115 = inttoptr i64 %t114 to ptr
  %t116 = load { i64, ptr }, ptr %l33
  %t117 = extractvalue { i64, ptr } %t116, 1
  %t118 = call ptr @__olang_region_or(ptr %t117, ptr null)
  %t119 = icmp ne ptr %t118, null
  %t120 = select i1 %t119, ptr %t118, ptr null
  call void @__olang_region_settle_in(ptr %t115, ptr %t120)
  %t121 = load ptr, ptr %l21, !tbaa !29
  %t122 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t121, i32 0, i32 0
  %t123 = load { i64, ptr }, ptr %t122, !tbaa !27
  store { i64, ptr } %t123, ptr %l52, !tbaa !27
  %t124 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t125 = load ptr, ptr %l21, !tbaa !29
  %t126 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t125, i32 0, i32 0
  store { i64, ptr } %t124, ptr %t126, !tbaa !27
  %t127 = load { i64, ptr }, ptr %l52
  %t128 = extractvalue { i64, ptr } %t127, 0
  %t129 = extractvalue { i64, ptr } %t127, 1
  call void @__olang_region_release_part(ptr %t129, i64 %t128)
  store { i64, ptr } zeroinitializer, ptr %l52
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t130, i32 0, i32 1
  %t133 = load { i64, ptr }, ptr %t132, !tbaa !27
  %t135 = load ptr, ptr %l0, !tbaa !29
  store ptr %t135, ptr %l55, !tbaa !29
  store { i64, ptr } %t133, ptr %l56, !tbaa !27
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t137, i32 0, i32 3
  %t140 = load i64, ptr %t139, !tbaa !24
  store i64 %t140, ptr %l58, !tbaa !24
  %t141 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t141, 0
  store i64 %t142, ptr %l59, !tbaa !24
  %t143 = icmp sge i64 0, 0
  br i1 %t143, label %bb21, label %bb22
bb21:
  %t145 = load i64, ptr %l58, !tbaa !24
  %t146 = icmp sle i64 0, %t145
  br i1 %t146, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_8e2bf48a3c00500f_fc16ff27629f3ba3)
  unreachable
bb23:
  %t148 = load i64, ptr %l58, !tbaa !24
  %t149 = load i64, ptr %l59, !tbaa !24
  %t150 = icmp sle i64 %t148, %t149
  br i1 %t150, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_8e2bf48a3c00500f_fc16ff27629f3ba3)
  unreachable
bb25:
  %t152 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = load i64, ptr %l58, !tbaa !24
  %t155 = getelementptr i64, ptr %t153, i64 0
  %t156 = sub i64 %t154, 0
  %t157 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t155, 1
  store { i64, ptr } %t158, ptr %l7, !tbaa !27
  %t160 = load i64, ptr %l1, !tbaa !24
  %t162 = call ptr @__olang_region_make_part(ptr %v0)
  %t163 = ptrtoint ptr %t162 to i64
  store i64 %t163, ptr %l65, !tbaa !24
  store i64 %t160, ptr %l66, !tbaa !24
  %t165 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t167 = load i64, ptr %l66, !tbaa !24
  %t168 = extractvalue { i64, ptr } %t165, 0
  %t169 = mul i64 %t168, 8
  %t170 = mul i64 %t167, 8
  %t171 = extractvalue { i64, ptr } %t165, 1
  %t172 = call ptr @__olang_grow_in_place(ptr %t171, i64 %t169, i64 %t170, i64 %t167)
  %t173 = icmp ne ptr %t172, null
  %t174 = select i1 %t173, i64 %t167, i64 0
  %t175 = insertvalue { i64, ptr } undef, i64 %t174, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t172, 1
  store { i64, ptr } %t176, ptr %l69, !tbaa !27
  %t177 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t177, 0
  %t180 = icmp ne i64 %t178, 0
  br i1 %t180, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_8e2bf48a3c00500f_fc16ff27629f3ba3)
  unreachable
bb27:
  %t182 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t182, ptr %l67, !tbaa !27
  br label %bb29
bb28:
  %t183 = load i64, ptr %l66, !tbaa !24
  %t184 = mul i64 %t183, 8
  %t185 = load i64, ptr %l65
  %t186 = inttoptr i64 %t185 to ptr
  %t187 = call ptr @__olang_held_alloc(ptr %t186, i64 %t184)
  %t188 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t187, 1
  store { i64, ptr } %t189, ptr %l67, !tbaa !27
  store i64 0, ptr %l72, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb30
bb29:
  %t190 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t190, 0
  %t193 = icmp eq i64 %t191, 0
  br i1 %t193, label %bb36, label %bb37
bb30:
  %t195 = load i64, ptr %l9, !tbaa !24
  %t196 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t196, 0
  %t201 = icmp slt i64 %t195, %t198
  %t203 = xor i1 %t201, true
  br i1 %t203, label %bb31, label %bb32
bb31:
  br label %bb35
bb32:
  br label %bb33
bb33:
  %t205 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t205, ptr %l78, !tbaa !27
  %t206 = load i64, ptr %l9, !tbaa !24
  %t208 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr i64, ptr %t209, i64 %t206
  %t211 = load i64, ptr %t210, !tbaa !34
  %t213 = load i64, ptr %l72, !tbaa !24
  %t214 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = getelementptr i64, ptr %t215, i64 %t213
  store i64 %t211, ptr %t216, !tbaa !34
  %t217 = load i64, ptr %l72, !tbaa !24
  %t218 = add i64 %t217, 1
  store i64 %t218, ptr %l72, !tbaa !24
  br label %bb34
bb34:
  %t219 = load i64, ptr %l9, !tbaa !24
  %t222 = add i64 %t219, 1
  store i64 %t222, ptr %l9, !tbaa !24
  br label %bb30
bb35:
  br label %bb29
bb36:
  store { i64, ptr } zeroinitializer, ptr %l67, !tbaa !27
  br label %bb37
bb37:
  %t224 = load i64, ptr %l65
  %t225 = inttoptr i64 %t224 to ptr
  %t226 = load { i64, ptr }, ptr %l67
  %t227 = extractvalue { i64, ptr } %t226, 1
  %t228 = call ptr @__olang_region_or(ptr %t227, ptr null)
  %t229 = icmp ne ptr %t228, null
  %t230 = select i1 %t229, ptr %t228, ptr null
  call void @__olang_region_settle_in(ptr %t225, ptr %t230)
  %t231 = load ptr, ptr %l55, !tbaa !29
  %t232 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t231, i32 0, i32 1
  %t233 = load { i64, ptr }, ptr %t232, !tbaa !27
  store { i64, ptr } %t233, ptr %l86, !tbaa !27
  %t234 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t235 = load ptr, ptr %l55, !tbaa !29
  %t236 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t235, i32 0, i32 1
  store { i64, ptr } %t234, ptr %t236, !tbaa !27
  %t237 = load { i64, ptr }, ptr %l86
  %t238 = extractvalue { i64, ptr } %t237, 0
  %t239 = extractvalue { i64, ptr } %t237, 1
  call void @__olang_region_release_part(ptr %t239, i64 %t238)
  store { i64, ptr } zeroinitializer, ptr %l86
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2e_Hc3acba95df981494d81fa9c0f498e905(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l37 = alloca i64
  %l43 = alloca { i64, ptr }
  %l53 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca i64
  %l63 = alloca i64
  %l64 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l69 = alloca i64
  %l75 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  store { i64, ptr } %t23, ptr %l2, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t26, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_389970255ec35ca5_cc4215f820edb121)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_389970255ec35ca5_cc4215f820edb121)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.457163fdec6e9d9dd96e1de2e7dfe82b", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  store i64 %t50, ptr %l31, !tbaa !24
  %t53 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t55 = load i64, ptr %l31, !tbaa !24
  %t56 = extractvalue { i64, ptr } %t53, 0
  %t57 = mul i64 %t56, 40
  %t58 = mul i64 %t55, 40
  %t59 = extractvalue { i64, ptr } %t53, 1
  %t60 = call ptr @__olang_grow_in_place(ptr %t59, i64 %t57, i64 %t58, i64 %t55)
  %t61 = icmp ne ptr %t60, null
  %t62 = select i1 %t61, i64 %t55, i64 0
  %t63 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t60, 1
  store { i64, ptr } %t64, ptr %l34, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 0
  %t68 = icmp ne i64 %t66, 0
  br i1 %t68, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_389970255ec35ca5_cc4215f820edb121)
  unreachable
bb10:
  %t70 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t70, ptr %l32, !tbaa !27
  br label %bb12
bb11:
  %t71 = load i64, ptr %l31, !tbaa !24
  %t72 = mul i64 %t71, 40
  %t73 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t72)
  %t74 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  store { i64, ptr } %t75, ptr %l32, !tbaa !27
  store i64 0, ptr %l37, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb13
bb12:
  %t76 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t77 = load ptr, ptr %l21, !tbaa !29
  %t78 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t77, i32 0, i32 0
  store { i64, ptr } %t76, ptr %t78, !tbaa !27
  %t79 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t81, i32 0, i32 1
  %t84 = load { i64, ptr }, ptr %t83, !tbaa !27
  store { i64, ptr } %t84, ptr %l6, !tbaa !27
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l53, !tbaa !29
  %t87 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t87, ptr %l54, !tbaa !27
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t88, i32 0, i32 3
  %t91 = load i64, ptr %t90, !tbaa !24
  store i64 %t91, ptr %l56, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 0
  store i64 %t93, ptr %l57, !tbaa !24
  %t94 = icmp sge i64 0, 0
  br i1 %t94, label %bb19, label %bb20
bb13:
  %t96 = load i64, ptr %l5, !tbaa !24
  %t97 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t97, 0
  %t102 = icmp slt i64 %t96, %t99
  %t104 = xor i1 %t102, true
  br i1 %t104, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t106 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t106, ptr %l43, !tbaa !27
  %t107 = load i64, ptr %l5, !tbaa !24
  %t109 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr %"std/prelude/map:MapEntry.457163fdec6e9d9dd96e1de2e7dfe82b", ptr %t110, i64 %t107
  %t112 = load %"std/prelude/map:MapEntry.457163fdec6e9d9dd96e1de2e7dfe82b", ptr %t111
  %t114 = load i64, ptr %l37, !tbaa !24
  %t115 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr %"std/prelude/map:MapEntry.457163fdec6e9d9dd96e1de2e7dfe82b", ptr %t116, i64 %t114
  store %"std/prelude/map:MapEntry.457163fdec6e9d9dd96e1de2e7dfe82b" %t112, ptr %t117
  %t118 = load i64, ptr %l37, !tbaa !24
  %t119 = add i64 %t118, 1
  store i64 %t119, ptr %l37, !tbaa !24
  br label %bb17
bb17:
  %t120 = load i64, ptr %l5, !tbaa !24
  %t123 = add i64 %t120, 1
  store i64 %t123, ptr %l5, !tbaa !24
  br label %bb13
bb18:
  br label %bb12
bb19:
  %t125 = load i64, ptr %l56, !tbaa !24
  %t126 = icmp sle i64 0, %t125
  br i1 %t126, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_7fe7a6e47a8c2c48_bdbca8ceda542d34)
  unreachable
bb21:
  %t128 = load i64, ptr %l56, !tbaa !24
  %t129 = load i64, ptr %l57, !tbaa !24
  %t130 = icmp sle i64 %t128, %t129
  br i1 %t130, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_7fe7a6e47a8c2c48_bdbca8ceda542d34)
  unreachable
bb23:
  %t132 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = load i64, ptr %l56, !tbaa !24
  %t135 = getelementptr i64, ptr %t133, i64 0
  %t136 = sub i64 %t134, 0
  %t137 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t135, 1
  store { i64, ptr } %t138, ptr %l7, !tbaa !27
  %t140 = load i64, ptr %l1, !tbaa !24
  store i64 %t140, ptr %l63, !tbaa !24
  %t143 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t145 = load i64, ptr %l63, !tbaa !24
  %t146 = extractvalue { i64, ptr } %t143, 0
  %t147 = mul i64 %t146, 8
  %t148 = mul i64 %t145, 8
  %t149 = extractvalue { i64, ptr } %t143, 1
  %t150 = call ptr @__olang_grow_in_place(ptr %t149, i64 %t147, i64 %t148, i64 %t145)
  %t151 = icmp ne ptr %t150, null
  %t152 = select i1 %t151, i64 %t145, i64 0
  %t153 = insertvalue { i64, ptr } undef, i64 %t152, 0
  %t154 = insertvalue { i64, ptr } %t153, ptr %t150, 1
  store { i64, ptr } %t154, ptr %l66, !tbaa !27
  %t155 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t156 = extractvalue { i64, ptr } %t155, 0
  %t158 = icmp ne i64 %t156, 0
  br i1 %t158, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_7fe7a6e47a8c2c48_bdbca8ceda542d34)
  unreachable
bb25:
  %t160 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t160, ptr %l64, !tbaa !27
  br label %bb27
bb26:
  %t161 = load i64, ptr %l63, !tbaa !24
  %t162 = mul i64 %t161, 8
  %t163 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t162)
  %t164 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t165 = insertvalue { i64, ptr } %t164, ptr %t163, 1
  store { i64, ptr } %t165, ptr %l64, !tbaa !27
  store i64 0, ptr %l69, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb28
bb27:
  %t166 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t167 = load ptr, ptr %l53, !tbaa !29
  %t168 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t167, i32 0, i32 1
  store { i64, ptr } %t166, ptr %t168, !tbaa !27
  %t169 = load { i64, ptr }, ptr %l6, !tbaa !27
  br label %ret
bb28:
  %t171 = load i64, ptr %l9, !tbaa !24
  %t172 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t174 = extractvalue { i64, ptr } %t172, 0
  %t177 = icmp slt i64 %t171, %t174
  %t179 = xor i1 %t177, true
  br i1 %t179, label %bb29, label %bb30
bb29:
  br label %bb33
bb30:
  br label %bb31
bb31:
  %t181 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t181, ptr %l75, !tbaa !27
  %t182 = load i64, ptr %l9, !tbaa !24
  %t184 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !27
  %t186 = getelementptr i64, ptr %t185, i64 %t182
  %t187 = load i64, ptr %t186, !tbaa !34
  %t189 = load i64, ptr %l69, !tbaa !24
  %t190 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !27
  %t192 = getelementptr i64, ptr %t191, i64 %t189
  store i64 %t187, ptr %t192, !tbaa !34
  %t193 = load i64, ptr %l69, !tbaa !24
  %t194 = add i64 %t193, 1
  store i64 %t194, ptr %l69, !tbaa !24
  br label %bb32
bb32:
  %t195 = load i64, ptr %l9, !tbaa !24
  %t198 = add i64 %t195, 1
  store i64 %t198, ptr %l9, !tbaa !24
  br label %bb28
bb33:
  br label %bb27
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fsource_3aSpan_3e_2_H4fb1d809d31bc6a884f40d33bbfefe77(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l38 = alloca i64
  %l44 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l72 = alloca i64
  %l78 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  store { i64, ptr } %t23, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_117a680accd1bd6d_952794adcbbf04a9)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_117a680accd1bd6d_952794adcbbf04a9)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.9f40551e0d6019a8e678d8f53048b6ba", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  %t52 = call ptr @__olang_region_make_part(ptr %v0)
  %t53 = ptrtoint ptr %t52 to i64
  store i64 %t53, ptr %l31, !tbaa !24
  store i64 %t50, ptr %l32, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t57 = load i64, ptr %l32, !tbaa !24
  %t58 = extractvalue { i64, ptr } %t55, 0
  %t59 = mul i64 %t58, 16
  %t60 = mul i64 %t57, 16
  %t61 = extractvalue { i64, ptr } %t55, 1
  %t62 = call ptr @__olang_grow_in_place(ptr %t61, i64 %t59, i64 %t60, i64 %t57)
  %t63 = icmp ne ptr %t62, null
  %t64 = select i1 %t63, i64 %t57, i64 0
  %t65 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t62, 1
  store { i64, ptr } %t66, ptr %l35, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t67, 0
  %t70 = icmp ne i64 %t68, 0
  br i1 %t70, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_117a680accd1bd6d_952794adcbbf04a9)
  unreachable
bb10:
  %t72 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t72, ptr %l33, !tbaa !27
  br label %bb12
bb11:
  %t73 = load i64, ptr %l32, !tbaa !24
  %t74 = mul i64 %t73, 16
  %t75 = load i64, ptr %l31
  %t76 = inttoptr i64 %t75 to ptr
  %t77 = call ptr @__olang_held_alloc(ptr %t76, i64 %t74)
  %t78 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  store { i64, ptr } %t79, ptr %l33, !tbaa !27
  store i64 0, ptr %l38, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb13
bb12:
  %t80 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 0
  %t83 = icmp eq i64 %t81, 0
  br i1 %t83, label %bb19, label %bb20
bb13:
  %t85 = load i64, ptr %l5, !tbaa !24
  %t86 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t91 = icmp slt i64 %t85, %t88
  %t93 = xor i1 %t91, true
  br i1 %t93, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t95 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t95, ptr %l44, !tbaa !27
  %t96 = load i64, ptr %l5, !tbaa !24
  %t98 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr %"std/prelude/map:MapEntry.9f40551e0d6019a8e678d8f53048b6ba", ptr %t99, i64 %t96
  %t101 = load %"std/prelude/map:MapEntry.9f40551e0d6019a8e678d8f53048b6ba", ptr %t100
  %t103 = load i64, ptr %l38, !tbaa !24
  %t104 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr %"std/prelude/map:MapEntry.9f40551e0d6019a8e678d8f53048b6ba", ptr %t105, i64 %t103
  store %"std/prelude/map:MapEntry.9f40551e0d6019a8e678d8f53048b6ba" %t101, ptr %t106
  %t107 = load i64, ptr %l38, !tbaa !24
  %t108 = add i64 %t107, 1
  store i64 %t108, ptr %l38, !tbaa !24
  br label %bb17
bb17:
  %t109 = load i64, ptr %l5, !tbaa !24
  %t112 = add i64 %t109, 1
  store i64 %t112, ptr %l5, !tbaa !24
  br label %bb13
bb18:
  br label %bb12
bb19:
  store { i64, ptr } zeroinitializer, ptr %l33, !tbaa !27
  br label %bb20
bb20:
  %t114 = load i64, ptr %l31
  %t115 = inttoptr i64 %t114 to ptr
  %t116 = load { i64, ptr }, ptr %l33
  %t117 = extractvalue { i64, ptr } %t116, 1
  %t118 = call ptr @__olang_region_or(ptr %t117, ptr null)
  %t119 = icmp ne ptr %t118, null
  %t120 = select i1 %t119, ptr %t118, ptr null
  call void @__olang_region_settle_in(ptr %t115, ptr %t120)
  %t121 = load ptr, ptr %l21, !tbaa !29
  %t122 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t121, i32 0, i32 0
  %t123 = load { i64, ptr }, ptr %t122, !tbaa !27
  store { i64, ptr } %t123, ptr %l52, !tbaa !27
  %t124 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t125 = load ptr, ptr %l21, !tbaa !29
  %t126 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t125, i32 0, i32 0
  store { i64, ptr } %t124, ptr %t126, !tbaa !27
  %t127 = load { i64, ptr }, ptr %l52
  %t128 = extractvalue { i64, ptr } %t127, 0
  %t129 = extractvalue { i64, ptr } %t127, 1
  call void @__olang_region_release_part(ptr %t129, i64 %t128)
  store { i64, ptr } zeroinitializer, ptr %l52
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t130, i32 0, i32 1
  %t133 = load { i64, ptr }, ptr %t132, !tbaa !27
  %t135 = load ptr, ptr %l0, !tbaa !29
  store ptr %t135, ptr %l55, !tbaa !29
  store { i64, ptr } %t133, ptr %l56, !tbaa !27
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t137, i32 0, i32 3
  %t140 = load i64, ptr %t139, !tbaa !24
  store i64 %t140, ptr %l58, !tbaa !24
  %t141 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t141, 0
  store i64 %t142, ptr %l59, !tbaa !24
  %t143 = icmp sge i64 0, 0
  br i1 %t143, label %bb21, label %bb22
bb21:
  %t145 = load i64, ptr %l58, !tbaa !24
  %t146 = icmp sle i64 0, %t145
  br i1 %t146, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_4ebc64f2fa391f90_2dc94f9b6ff22cbc)
  unreachable
bb23:
  %t148 = load i64, ptr %l58, !tbaa !24
  %t149 = load i64, ptr %l59, !tbaa !24
  %t150 = icmp sle i64 %t148, %t149
  br i1 %t150, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_4ebc64f2fa391f90_2dc94f9b6ff22cbc)
  unreachable
bb25:
  %t152 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = load i64, ptr %l58, !tbaa !24
  %t155 = getelementptr i64, ptr %t153, i64 0
  %t156 = sub i64 %t154, 0
  %t157 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t155, 1
  store { i64, ptr } %t158, ptr %l7, !tbaa !27
  %t160 = load i64, ptr %l1, !tbaa !24
  %t162 = call ptr @__olang_region_make_part(ptr %v0)
  %t163 = ptrtoint ptr %t162 to i64
  store i64 %t163, ptr %l65, !tbaa !24
  store i64 %t160, ptr %l66, !tbaa !24
  %t165 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t167 = load i64, ptr %l66, !tbaa !24
  %t168 = extractvalue { i64, ptr } %t165, 0
  %t169 = mul i64 %t168, 8
  %t170 = mul i64 %t167, 8
  %t171 = extractvalue { i64, ptr } %t165, 1
  %t172 = call ptr @__olang_grow_in_place(ptr %t171, i64 %t169, i64 %t170, i64 %t167)
  %t173 = icmp ne ptr %t172, null
  %t174 = select i1 %t173, i64 %t167, i64 0
  %t175 = insertvalue { i64, ptr } undef, i64 %t174, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t172, 1
  store { i64, ptr } %t176, ptr %l69, !tbaa !27
  %t177 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t177, 0
  %t180 = icmp ne i64 %t178, 0
  br i1 %t180, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_4ebc64f2fa391f90_2dc94f9b6ff22cbc)
  unreachable
bb27:
  %t182 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t182, ptr %l67, !tbaa !27
  br label %bb29
bb28:
  %t183 = load i64, ptr %l66, !tbaa !24
  %t184 = mul i64 %t183, 8
  %t185 = load i64, ptr %l65
  %t186 = inttoptr i64 %t185 to ptr
  %t187 = call ptr @__olang_held_alloc(ptr %t186, i64 %t184)
  %t188 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t187, 1
  store { i64, ptr } %t189, ptr %l67, !tbaa !27
  store i64 0, ptr %l72, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb30
bb29:
  %t190 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t190, 0
  %t193 = icmp eq i64 %t191, 0
  br i1 %t193, label %bb36, label %bb37
bb30:
  %t195 = load i64, ptr %l9, !tbaa !24
  %t196 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t196, 0
  %t201 = icmp slt i64 %t195, %t198
  %t203 = xor i1 %t201, true
  br i1 %t203, label %bb31, label %bb32
bb31:
  br label %bb35
bb32:
  br label %bb33
bb33:
  %t205 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t205, ptr %l78, !tbaa !27
  %t206 = load i64, ptr %l9, !tbaa !24
  %t208 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr i64, ptr %t209, i64 %t206
  %t211 = load i64, ptr %t210, !tbaa !34
  %t213 = load i64, ptr %l72, !tbaa !24
  %t214 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = getelementptr i64, ptr %t215, i64 %t213
  store i64 %t211, ptr %t216, !tbaa !34
  %t217 = load i64, ptr %l72, !tbaa !24
  %t218 = add i64 %t217, 1
  store i64 %t218, ptr %l72, !tbaa !24
  br label %bb34
bb34:
  %t219 = load i64, ptr %l9, !tbaa !24
  %t222 = add i64 %t219, 1
  store i64 %t222, ptr %l9, !tbaa !24
  br label %bb30
bb35:
  br label %bb29
bb36:
  store { i64, ptr } zeroinitializer, ptr %l67, !tbaa !27
  br label %bb37
bb37:
  %t224 = load i64, ptr %l65
  %t225 = inttoptr i64 %t224 to ptr
  %t226 = load { i64, ptr }, ptr %l67
  %t227 = extractvalue { i64, ptr } %t226, 1
  %t228 = call ptr @__olang_region_or(ptr %t227, ptr null)
  %t229 = icmp ne ptr %t228, null
  %t230 = select i1 %t229, ptr %t228, ptr null
  call void @__olang_region_settle_in(ptr %t225, ptr %t230)
  %t231 = load ptr, ptr %l55, !tbaa !29
  %t232 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t231, i32 0, i32 1
  %t233 = load { i64, ptr }, ptr %t232, !tbaa !27
  store { i64, ptr } %t233, ptr %l86, !tbaa !27
  %t234 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t235 = load ptr, ptr %l55, !tbaa !29
  %t236 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t235, i32 0, i32 1
  store { i64, ptr } %t234, ptr %t236, !tbaa !27
  %t237 = load { i64, ptr }, ptr %l86
  %t238 = extractvalue { i64, ptr } %t237, 0
  %t239 = extractvalue { i64, ptr } %t237, 1
  call void @__olang_region_release_part(ptr %t239, i64 %t238)
  store { i64, ptr } zeroinitializer, ptr %l86
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aContractIn_H2f38706138ffae6457f9c274edee657c(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l31 = alloca i64
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l40 = alloca { i64, ptr }
  %l42 = alloca %"std/prelude/map:MapEntry.30ce370d829aff239a34c06a62e67c2e"
  %l48 = alloca { i64, ptr }
  %l51 = alloca ptr
  %l52 = alloca { i64, ptr }
  %l54 = alloca i64
  %l55 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l68 = alloca i64
  %l74 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  store { i64, ptr } %t23, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_3ce2cd7668277ea4_65102d81f57d5250)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_3ce2cd7668277ea4_65102d81f57d5250)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.30ce370d829aff239a34c06a62e67c2e", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  %t52 = call ptr @__olang_region_make_part(ptr %v0)
  %t53 = ptrtoint ptr %t52 to i64
  store i64 %t53, ptr %l31, !tbaa !24
  %t56 = mul i64 %t50, 160
  %t57 = load i64, ptr %l31
  %t58 = inttoptr i64 %t57 to ptr
  %t59 = call ptr @__olang_scope_alloc_zeroed(ptr %t58, i64 %t56)
  %t60 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  store { i64, ptr } %t61, ptr %l33, !tbaa !27
  store i64 0, ptr %l34, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_3ce2cd7668277ea4_65102d81f57d5250)
  unreachable
bb10:
  %t62 = load i64, ptr %l5, !tbaa !24
  %t63 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t63, 0
  %t68 = icmp slt i64 %t62, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  br label %bb13
bb13:
  %t72 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t72, ptr %l40, !tbaa !27
  %t73 = load i64, ptr %l5, !tbaa !24
  %t75 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr %"std/prelude/map:MapEntry.30ce370d829aff239a34c06a62e67c2e", ptr %t76, i64 %t73
  %t78 = load %"std/prelude/map:MapEntry.30ce370d829aff239a34c06a62e67c2e", ptr %t77
  store %"std/prelude/map:MapEntry.30ce370d829aff239a34c06a62e67c2e" zeroinitializer, ptr %t77
  store %"std/prelude/map:MapEntry.30ce370d829aff239a34c06a62e67c2e" %t78, ptr %l42
  %t79 = load i64, ptr %l34, !tbaa !24
  %t80 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr %"std/prelude/map:MapEntry.30ce370d829aff239a34c06a62e67c2e", ptr %t81, i64 %t79
  call void @llvm.memmove.p0.p0.i64(ptr %t82, ptr %l42, i64 160, i1 false)
  %t83 = load i64, ptr %l34, !tbaa !24
  %t84 = add i64 %t83, 1
  store i64 %t84, ptr %l34, !tbaa !24
  br label %bb14
bb14:
  %t85 = load i64, ptr %l5, !tbaa !24
  %t88 = add i64 %t85, 1
  store i64 %t88, ptr %l5, !tbaa !24
  br label %bb10
bb15:
  %t90 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 0
  %t93 = icmp eq i64 %t91, 0
  br i1 %t93, label %bb16, label %bb17
bb16:
  store { i64, ptr } zeroinitializer, ptr %l33, !tbaa !27
  br label %bb17
bb17:
  %t95 = load i64, ptr %l31
  %t96 = inttoptr i64 %t95 to ptr
  %t97 = load { i64, ptr }, ptr %l33
  %t98 = extractvalue { i64, ptr } %t97, 1
  %t99 = call ptr @__olang_region_or(ptr %t98, ptr null)
  %t100 = icmp ne ptr %t99, null
  %t101 = select i1 %t100, ptr %t99, ptr null
  call void @__olang_region_settle_in(ptr %t96, ptr %t101)
  %t102 = load ptr, ptr %l21, !tbaa !29
  %t103 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t102, i32 0, i32 0
  %t104 = load { i64, ptr }, ptr %t103, !tbaa !27
  store { i64, ptr } %t104, ptr %l48, !tbaa !27
  %t105 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t106 = load ptr, ptr %l21, !tbaa !29
  %t107 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t106, i32 0, i32 0
  store { i64, ptr } %t105, ptr %t107, !tbaa !27
  %t108 = load { i64, ptr }, ptr %l48
  %t109 = extractvalue { i64, ptr } %t108, 0
  %t110 = extractvalue { i64, ptr } %t108, 1
  call void @__olang_region_release_part(ptr %t110, i64 %t109)
  store { i64, ptr } zeroinitializer, ptr %l48
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t111, i32 0, i32 1
  %t114 = load { i64, ptr }, ptr %t113, !tbaa !27
  %t116 = load ptr, ptr %l0, !tbaa !29
  store ptr %t116, ptr %l51, !tbaa !29
  store { i64, ptr } %t114, ptr %l52, !tbaa !27
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t118, i32 0, i32 3
  %t121 = load i64, ptr %t120, !tbaa !24
  store i64 %t121, ptr %l54, !tbaa !24
  %t122 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t123 = extractvalue { i64, ptr } %t122, 0
  store i64 %t123, ptr %l55, !tbaa !24
  %t124 = icmp sge i64 0, 0
  br i1 %t124, label %bb18, label %bb19
bb18:
  %t126 = load i64, ptr %l54, !tbaa !24
  %t127 = icmp sle i64 0, %t126
  br i1 %t127, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_2cefd9bcafe1bf91_71cdc6677ab2692d)
  unreachable
bb20:
  %t129 = load i64, ptr %l54, !tbaa !24
  %t130 = load i64, ptr %l55, !tbaa !24
  %t131 = icmp sle i64 %t129, %t130
  br i1 %t131, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_2cefd9bcafe1bf91_71cdc6677ab2692d)
  unreachable
bb22:
  %t133 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = load i64, ptr %l54, !tbaa !24
  %t136 = getelementptr i64, ptr %t134, i64 0
  %t137 = sub i64 %t135, 0
  %t138 = insertvalue { i64, ptr } undef, i64 %t137, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t136, 1
  store { i64, ptr } %t139, ptr %l7, !tbaa !27
  %t141 = load i64, ptr %l1, !tbaa !24
  %t143 = call ptr @__olang_region_make_part(ptr %v0)
  %t144 = ptrtoint ptr %t143 to i64
  store i64 %t144, ptr %l61, !tbaa !24
  store i64 %t141, ptr %l62, !tbaa !24
  %t146 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t148 = load i64, ptr %l62, !tbaa !24
  %t149 = extractvalue { i64, ptr } %t146, 0
  %t150 = mul i64 %t149, 8
  %t151 = mul i64 %t148, 8
  %t152 = extractvalue { i64, ptr } %t146, 1
  %t153 = call ptr @__olang_grow_in_place(ptr %t152, i64 %t150, i64 %t151, i64 %t148)
  %t154 = icmp ne ptr %t153, null
  %t155 = select i1 %t154, i64 %t148, i64 0
  %t156 = insertvalue { i64, ptr } undef, i64 %t155, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr %t153, 1
  store { i64, ptr } %t157, ptr %l65, !tbaa !27
  %t158 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t159 = extractvalue { i64, ptr } %t158, 0
  %t161 = icmp ne i64 %t159, 0
  br i1 %t161, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_2cefd9bcafe1bf91_71cdc6677ab2692d)
  unreachable
bb24:
  %t163 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t163, ptr %l63, !tbaa !27
  br label %bb26
bb25:
  %t164 = load i64, ptr %l62, !tbaa !24
  %t165 = mul i64 %t164, 8
  %t166 = load i64, ptr %l61
  %t167 = inttoptr i64 %t166 to ptr
  %t168 = call ptr @__olang_held_alloc(ptr %t167, i64 %t165)
  %t169 = insertvalue { i64, ptr } undef, i64 %t164, 0
  %t170 = insertvalue { i64, ptr } %t169, ptr %t168, 1
  store { i64, ptr } %t170, ptr %l63, !tbaa !27
  store i64 0, ptr %l68, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb27
bb26:
  %t171 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t172 = extractvalue { i64, ptr } %t171, 0
  %t174 = icmp eq i64 %t172, 0
  br i1 %t174, label %bb33, label %bb34
bb27:
  %t176 = load i64, ptr %l9, !tbaa !24
  %t177 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t177, 0
  %t182 = icmp slt i64 %t176, %t179
  %t184 = xor i1 %t182, true
  br i1 %t184, label %bb28, label %bb29
bb28:
  br label %bb32
bb29:
  br label %bb30
bb30:
  %t186 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t186, ptr %l74, !tbaa !27
  %t187 = load i64, ptr %l9, !tbaa !24
  %t189 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !27
  %t191 = getelementptr i64, ptr %t190, i64 %t187
  %t192 = load i64, ptr %t191, !tbaa !34
  %t194 = load i64, ptr %l68, !tbaa !24
  %t195 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !27
  %t197 = getelementptr i64, ptr %t196, i64 %t194
  store i64 %t192, ptr %t197, !tbaa !34
  %t198 = load i64, ptr %l68, !tbaa !24
  %t199 = add i64 %t198, 1
  store i64 %t199, ptr %l68, !tbaa !24
  br label %bb31
bb31:
  %t200 = load i64, ptr %l9, !tbaa !24
  %t203 = add i64 %t200, 1
  store i64 %t203, ptr %l9, !tbaa !24
  br label %bb27
bb32:
  br label %bb26
bb33:
  store { i64, ptr } zeroinitializer, ptr %l63, !tbaa !27
  br label %bb34
bb34:
  %t205 = load i64, ptr %l61
  %t206 = inttoptr i64 %t205 to ptr
  %t207 = load { i64, ptr }, ptr %l63
  %t208 = extractvalue { i64, ptr } %t207, 1
  %t209 = call ptr @__olang_region_or(ptr %t208, ptr null)
  %t210 = icmp ne ptr %t209, null
  %t211 = select i1 %t210, ptr %t209, ptr null
  call void @__olang_region_settle_in(ptr %t206, ptr %t211)
  %t212 = load ptr, ptr %l51, !tbaa !29
  %t213 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t212, i32 0, i32 1
  %t214 = load { i64, ptr }, ptr %t213, !tbaa !27
  store { i64, ptr } %t214, ptr %l82, !tbaa !27
  %t215 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t216 = load ptr, ptr %l51, !tbaa !29
  %t217 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t216, i32 0, i32 1
  store { i64, ptr } %t215, ptr %t217, !tbaa !27
  %t218 = load { i64, ptr }, ptr %l82
  %t219 = extractvalue { i64, ptr } %t218, 0
  %t220 = extractvalue { i64, ptr } %t218, 1
  call void @__olang_region_release_part(ptr %t220, i64 %t219)
  store { i64, ptr } zeroinitializer, ptr %l82
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aContractIn_H9735389c66b65d66c88b8429345781ec(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/typed:ContractInfo"
  %l3 = alloca i64
  %l4 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l13 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l19 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca %"compiler/typed:ContractInfo"
  %l34 = alloca %"compiler/typed:ContractInfo"
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca { i64, ptr }
  %l50 = alloca %"compiler/typed:ContractInfo"
  %l54 = alloca ptr
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca %"compiler/typed:ContractInfo"
  %l59 = alloca %"compiler/typed:ContractInfo"
  %s0 = alloca %olang.scope
  %t21 = alloca i64
  %t221 = alloca %"compiler/typed:ContractInfo", align 8
  %t226 = alloca %"compiler/typed:ContractInfo", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  call void @llvm.memmove.p0.p0.i64(ptr %l2, ptr %a2, i64 152, i1 false)
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 2
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp eq i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l9, !tbaa !29
  %t11 = call ptr @__olang_region_make_part(ptr %v0)
  %t12 = ptrtoint ptr %t11 to i64
  store i64 %t12, ptr %l10, !tbaa !24
  %t13 = icmp sge i64 8, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  br label %bb9
bb3:
  %t15 = icmp sle i64 8, 1152921504606846975
  br i1 %t15, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_c376b69c1fb64831_2e5315ea59d0fc85)
  unreachable
bb5:
  %t17 = mul i64 8, 8
  %t18 = load i64, ptr %l10
  %t19 = inttoptr i64 %t18 to ptr
  %t20 = call ptr @__olang_held_alloc(ptr %t19, i64 %t17)
  store i64 0, ptr %t21
  br label %fill.22
fill.22:
  %t25 = load i64, ptr %t21
  %t26 = icmp slt i64 %t25, 8
  br i1 %t26, label %fillb.23, label %filld.24
fillb.23:
  %t27 = getelementptr i64, ptr %t20, i64 %t25
  store i64 -1, ptr %t27
  %t28 = add i64 %t25, 1
  store i64 %t28, ptr %t21
  br label %fill.22
filld.24:
  %t29 = insertvalue { i64, ptr } undef, i64 8, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t20, 1
  store { i64, ptr } %t30, ptr %l13, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  %t34 = icmp eq i64 %t32, 0
  br i1 %t34, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_c376b69c1fb64831_2e5315ea59d0fc85)
  unreachable
bb7:
  store { i64, ptr } zeroinitializer, ptr %l13, !tbaa !27
  br label %bb8
bb8:
  %t36 = load i64, ptr %l10
  %t37 = inttoptr i64 %t36 to ptr
  %t38 = load { i64, ptr }, ptr %l13
  %t39 = extractvalue { i64, ptr } %t38, 1
  %t40 = call ptr @__olang_region_or(ptr %t39, ptr null)
  %t41 = icmp ne ptr %t40, null
  %t42 = select i1 %t41, ptr %t40, ptr null
  call void @__olang_region_settle_in(ptr %t37, ptr %t42)
  %t43 = load ptr, ptr %l9, !tbaa !29
  %t44 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t43, i32 0, i32 2
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  store { i64, ptr } %t45, ptr %l16, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t47 = load ptr, ptr %l9, !tbaa !29
  %t48 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t47, i32 0, i32 2
  store { i64, ptr } %t46, ptr %t48, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l16
  %t50 = extractvalue { i64, ptr } %t49, 0
  %t51 = extractvalue { i64, ptr } %t49, 1
  call void @__olang_region_release_part(ptr %t51, i64 %t50)
  store { i64, ptr } zeroinitializer, ptr %l16
  br label %bb9
bb9:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i64, ptr %l1, !tbaa !24
  %t56 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3cI64_3e_3e_2ebucketOf_3cI64_2c_20Array_3cI64_3e_3e(ptr %v0, ptr %t52, i64 %t53)
  store i64 %t56, ptr %l19
  br label %bb10
bb10:
  %t57 = load i64, ptr %l19, !tbaa !24
  store i64 %t57, ptr %l3, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  %t61 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t58, i32 0, i32 2
  %t63 = getelementptr { i64, ptr }, ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr i64, ptr %t64, i64 %t59
  %t66 = load i64, ptr %t65, !tbaa !34
  store i64 %t66, ptr %l4, !tbaa !24
  br label %bb11
bb11:
  %t68 = load i64, ptr %l4, !tbaa !24
  %t70 = icmp sge i64 %t68, 0
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb12, label %bb13
bb12:
  br label %bb21
bb13:
  br label %bb14
bb14:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i64, ptr %l4, !tbaa !24
  %t77 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t74, i32 0, i32 0
  %t79 = getelementptr { i64, ptr }, ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr %"std/prelude/map:MapEntry.30ce370d829aff239a34c06a62e67c2e", ptr %t80, i64 %t75
  %t82 = getelementptr %"std/prelude/map:MapEntry.30ce370d829aff239a34c06a62e67c2e", ptr %t81, i32 0, i32 0
  %t83 = load i64, ptr %t82, !tbaa !24
  %t84 = load i64, ptr %l1, !tbaa !24
  %t87 = icmp eq i64 %t83, %t84
  br i1 %t87, label %bb15, label %bb16
bb15:
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l31, !tbaa !29
  %t90 = load i64, ptr %l4, !tbaa !24
  store i64 %t90, ptr %l32, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l33, ptr %l2, i64 152, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l34, ptr %l33, i64 152, i1 false)
  %t91 = getelementptr %"compiler/typed:ContractInfo", ptr %l34, i32 0, i32 2
  %t92 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t91, i32 0, i32 0
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !27
  store { i64, ptr } %t93, ptr %l35, !tbaa !27
  %t94 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 0
  store i64 %t95, ptr %l36, !tbaa !24
  %t96 = load i64, ptr %l36, !tbaa !24
  %t97 = mul i64 %t96, 8
  %t98 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t97)
  %t99 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  store { i64, ptr } %t100, ptr %l37, !tbaa !27
  %t101 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = load i64, ptr %l36, !tbaa !24
  %t106 = mul i64 %t105, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t102, ptr %t104, i64 %t106, i1 false)
  %t107 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t108 = getelementptr %"compiler/typed:ContractInfo", ptr %l34, i32 0, i32 2
  %t109 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t108, i32 0, i32 0
  store { i64, ptr } %t107, ptr %t109, !tbaa !27
  %t110 = call ptr @__olang_region_make_part(ptr %v0)
  %t111 = ptrtoint ptr %t110 to i64
  store i64 %t111, ptr %l38, !tbaa !24
  %t112 = getelementptr %"compiler/typed:ContractInfo", ptr %l34, i32 0, i32 3
  %t113 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t112, i32 0, i32 0
  %t114 = load { i64, ptr }, ptr %t113, !tbaa !27
  store { i64, ptr } %t114, ptr %l39, !tbaa !27
  %t115 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t115, 0
  store i64 %t116, ptr %l40, !tbaa !24
  %t117 = load i64, ptr %l40, !tbaa !24
  %t118 = mul i64 %t117, 8
  %t119 = load i64, ptr %l38
  %t120 = inttoptr i64 %t119 to ptr
  %t121 = call ptr @__olang_held_alloc(ptr %t120, i64 %t118)
  %t122 = insertvalue { i64, ptr } undef, i64 %t117, 0
  %t123 = insertvalue { i64, ptr } %t122, ptr %t121, 1
  store { i64, ptr } %t123, ptr %l41, !tbaa !27
  %t124 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = load i64, ptr %l40, !tbaa !24
  %t129 = mul i64 %t128, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t125, ptr %t127, i64 %t129, i1 false)
  %t130 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t131 = getelementptr %"compiler/typed:ContractInfo", ptr %l34, i32 0, i32 3
  %t132 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t131, i32 0, i32 0
  store { i64, ptr } %t130, ptr %t132, !tbaa !27
  %t133 = getelementptr %"compiler/typed:ContractInfo", ptr %l34, i32 0, i32 3
  %t134 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t133, i32 0, i32 0
  %t135 = load { i64, ptr }, ptr %t134, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t135, 0
  %t138 = icmp eq i64 %t136, 0
  br i1 %t138, label %bb17, label %bb18
bb16:
  br label %bb19
bb17:
  %t140 = getelementptr %"compiler/typed:ContractInfo", ptr %l34, i32 0, i32 3
  %t141 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t140, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t141, !tbaa !27
  br label %bb18
bb18:
  %t142 = getelementptr %"compiler/typed:ContractInfo", ptr %l34, i32 0, i32 3
  %t143 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t142, i32 0, i32 0
  %t144 = load i64, ptr %l38
  %t145 = inttoptr i64 %t144 to ptr
  %t146 = load { i64, ptr }, ptr %t143
  %t147 = extractvalue { i64, ptr } %t146, 1
  %t148 = call ptr @__olang_region_or(ptr %t147, ptr null)
  %t149 = icmp ne ptr %t148, null
  %t150 = select i1 %t149, ptr %t148, ptr null
  call void @__olang_region_settle_in(ptr %t145, ptr %t150)
  %t151 = getelementptr %"compiler/typed:ContractInfo", ptr %l34, i32 0, i32 4
  %t152 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t151, i32 0, i32 0
  %t153 = load { i64, ptr }, ptr %t152, !tbaa !27
  store { i64, ptr } %t153, ptr %l44, !tbaa !27
  %t154 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t154, 0
  store i64 %t155, ptr %l45, !tbaa !24
  %t156 = load i64, ptr %l45, !tbaa !24
  %t157 = mul i64 %t156, 16
  %t158 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t157)
  %t159 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t158, 1
  store { i64, ptr } %t160, ptr %l46, !tbaa !27
  %t161 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !27
  %t163 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !27
  %t165 = load i64, ptr %l45, !tbaa !24
  %t166 = mul i64 %t165, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t162, ptr %t164, i64 %t166, i1 false)
  %t167 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t168 = getelementptr %"compiler/typed:ContractInfo", ptr %l34, i32 0, i32 4
  %t169 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t168, i32 0, i32 0
  store { i64, ptr } %t167, ptr %t169, !tbaa !27
  %t170 = getelementptr %"compiler/typed:ContractInfo", ptr %l34, i32 0, i32 5
  %t171 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t170, i32 0, i32 0
  %t172 = load { i64, ptr }, ptr %t171, !tbaa !27
  store { i64, ptr } %t172, ptr %l47, !tbaa !27
  %t173 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t174 = extractvalue { i64, ptr } %t173, 0
  store i64 %t174, ptr %l48, !tbaa !24
  %t175 = load i64, ptr %l48, !tbaa !24
  %t176 = mul i64 %t175, 1
  %t177 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t176)
  %t178 = insertvalue { i64, ptr } undef, i64 %t175, 0
  %t179 = insertvalue { i64, ptr } %t178, ptr %t177, 1
  store { i64, ptr } %t179, ptr %l49, !tbaa !27
  %t180 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t181 = load ptr, ptr %t180, !tbaa !27
  %t182 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !27
  %t184 = load i64, ptr %l48, !tbaa !24
  %t185 = mul i64 %t184, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t181, ptr %t183, i64 %t185, i1 false)
  %t186 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t187 = getelementptr %"compiler/typed:ContractInfo", ptr %l34, i32 0, i32 5
  %t188 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t187, i32 0, i32 0
  store { i64, ptr } %t186, ptr %t188, !tbaa !27
  %t189 = load ptr, ptr %l31, !tbaa !29
  %t190 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t189, i32 0, i32 0
  %t191 = load i64, ptr %l32, !tbaa !24
  %t192 = getelementptr { i64, ptr }, ptr %t190, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t194 = getelementptr %"std/prelude/map:MapEntry.30ce370d829aff239a34c06a62e67c2e", ptr %t193, i64 %t191
  %t195 = getelementptr %"std/prelude/map:MapEntry.30ce370d829aff239a34c06a62e67c2e", ptr %t194, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %l50, ptr %t195, i64 152, i1 false)
  %t196 = load ptr, ptr %l31, !tbaa !29
  %t197 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t196, i32 0, i32 0
  %t198 = load i64, ptr %l32, !tbaa !24
  %t199 = getelementptr { i64, ptr }, ptr %t197, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !27
  %t201 = getelementptr %"std/prelude/map:MapEntry.30ce370d829aff239a34c06a62e67c2e", ptr %t200, i64 %t198
  %t202 = getelementptr %"std/prelude/map:MapEntry.30ce370d829aff239a34c06a62e67c2e", ptr %t201, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %t202, ptr %l34, i64 152, i1 false)
  %t203 = getelementptr %"compiler/typed:ContractInfo", ptr %l50, i32 0, i32 3
  %t204 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t203, i32 0, i32 0
  %t205 = load { i64, ptr }, ptr %t204
  %t206 = extractvalue { i64, ptr } %t205, 0
  %t207 = extractvalue { i64, ptr } %t205, 1
  call void @__olang_region_release_part(ptr %t207, i64 %t206)
  store { i64, ptr } zeroinitializer, ptr %t204
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb19:
  br label %bb20
bb20:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t209 = load i64, ptr %l4, !tbaa !24
  %t211 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t208, i32 0, i32 1
  %t213 = getelementptr { i64, ptr }, ptr %t211, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !27
  %t215 = getelementptr i64, ptr %t214, i64 %t209
  %t216 = load i64, ptr %t215, !tbaa !34
  store i64 %t216, ptr %l4, !tbaa !24
  br label %bb11
bb21:
  %t218 = load ptr, ptr %l0, !tbaa !29
  store ptr %t218, ptr %l54, !tbaa !29
  %t219 = load i64, ptr %l3, !tbaa !24
  store i64 %t219, ptr %l55, !tbaa !24
  %t220 = load i64, ptr %l1, !tbaa !24
  store i64 %t220, ptr %l56, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l57, ptr %l2, i64 152, i1 false)
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ftyped_3aContractInfo(ptr %t221, ptr %s0, ptr %l57)
  call void @llvm.memmove.p0.p0.i64(ptr %l59, ptr %t221, i64 152, i1 false)
  br label %bb22
bb22:
  %t223 = load ptr, ptr %l54, !tbaa !29
  %t224 = load i64, ptr %l55, !tbaa !24
  %t225 = load i64, ptr %l56, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %t226, ptr %l59, i64 152, i1 false)
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aContractIn_H05d6b752b522b82c68261770463330a4(ptr %v0, ptr %v0, ptr %t223, i64 %t224, i64 %t225, ptr %t226)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_H7dde68908c71339667eba96ae7e6565c(ptr %v0, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l13 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l19 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca i64
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %t21 = alloca i64
  %t91 = alloca %olang.slotscope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 2
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp eq i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l9, !tbaa !29
  %t11 = call ptr @__olang_region_make_part(ptr %v0)
  %t12 = ptrtoint ptr %t11 to i64
  store i64 %t12, ptr %l10, !tbaa !24
  %t13 = icmp sge i64 8, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  br label %bb9
bb3:
  %t15 = icmp sle i64 8, 1152921504606846975
  br i1 %t15, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_e21ed6667868d2e6_db2b0a2c7700ea32)
  unreachable
bb5:
  %t17 = mul i64 8, 8
  %t18 = load i64, ptr %l10
  %t19 = inttoptr i64 %t18 to ptr
  %t20 = call ptr @__olang_held_alloc(ptr %t19, i64 %t17)
  store i64 0, ptr %t21
  br label %fill.22
fill.22:
  %t25 = load i64, ptr %t21
  %t26 = icmp slt i64 %t25, 8
  br i1 %t26, label %fillb.23, label %filld.24
fillb.23:
  %t27 = getelementptr i64, ptr %t20, i64 %t25
  store i64 -1, ptr %t27
  %t28 = add i64 %t25, 1
  store i64 %t28, ptr %t21
  br label %fill.22
filld.24:
  %t29 = insertvalue { i64, ptr } undef, i64 8, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t20, 1
  store { i64, ptr } %t30, ptr %l13, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  %t34 = icmp eq i64 %t32, 0
  br i1 %t34, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_e21ed6667868d2e6_db2b0a2c7700ea32)
  unreachable
bb7:
  store { i64, ptr } zeroinitializer, ptr %l13, !tbaa !27
  br label %bb8
bb8:
  %t36 = load i64, ptr %l10
  %t37 = inttoptr i64 %t36 to ptr
  %t38 = load { i64, ptr }, ptr %l13
  %t39 = extractvalue { i64, ptr } %t38, 1
  %t40 = call ptr @__olang_region_or(ptr %t39, ptr null)
  %t41 = icmp ne ptr %t40, null
  %t42 = select i1 %t41, ptr %t40, ptr null
  call void @__olang_region_settle_in(ptr %t37, ptr %t42)
  %t43 = load ptr, ptr %l9, !tbaa !29
  %t44 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t43, i32 0, i32 2
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  store { i64, ptr } %t45, ptr %l16, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t47 = load ptr, ptr %l9, !tbaa !29
  %t48 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t47, i32 0, i32 2
  store { i64, ptr } %t46, ptr %t48, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l16
  %t50 = extractvalue { i64, ptr } %t49, 0
  %t51 = extractvalue { i64, ptr } %t49, 1
  call void @__olang_region_release_part(ptr %t51, i64 %t50)
  store { i64, ptr } zeroinitializer, ptr %l16
  br label %bb9
bb9:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i64, ptr %l1, !tbaa !24
  %t56 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3cI64_3e_3e_2ebucketOf_3cI64_2c_20Array_3cI64_3e_3e(ptr %v0, ptr %t52, i64 %t53)
  store i64 %t56, ptr %l19
  br label %bb10
bb10:
  %t57 = load i64, ptr %l19, !tbaa !24
  store i64 %t57, ptr %l3, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  %t61 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t58, i32 0, i32 2
  %t63 = getelementptr { i64, ptr }, ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr i64, ptr %t64, i64 %t59
  %t66 = load i64, ptr %t65, !tbaa !34
  store i64 %t66, ptr %l4, !tbaa !24
  br label %bb11
bb11:
  %t68 = load i64, ptr %l4, !tbaa !24
  %t70 = icmp sge i64 %t68, 0
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb12, label %bb13
bb12:
  br label %bb19
bb13:
  br label %bb14
bb14:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i64, ptr %l4, !tbaa !24
  %t77 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t74, i32 0, i32 0
  %t79 = getelementptr { i64, ptr }, ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406", ptr %t80, i64 %t75
  %t82 = getelementptr %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406", ptr %t81, i32 0, i32 0
  %t83 = load i64, ptr %t82, !tbaa !24
  %t84 = load i64, ptr %l1, !tbaa !24
  %t87 = icmp eq i64 %t83, %t84
  br i1 %t87, label %bb15, label %bb16
bb15:
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l31, !tbaa !29
  %t90 = load i64, ptr %l4, !tbaa !24
  store i64 %t90, ptr %l32, !tbaa !24
  %t92 = load ptr, ptr %v0
  %t93 = icmp eq ptr %t92, @__olang_slot_chunk
  %t94 = getelementptr %olang.scope, ptr %v0, i32 0, i32 2
  %t95 = load ptr, ptr %t94
  %t96 = select i1 %t93, ptr %t95, ptr %v0
  store %olang.scope zeroinitializer, ptr %t91
  store ptr @__olang_slot_chunk, ptr %t91
  %t97 = getelementptr %olang.scope, ptr %t91, i32 0, i32 2
  store ptr %t96, ptr %t97
  %t98 = getelementptr %olang.slotscope, ptr %t91, i32 0, i32 1
  store i64 0, ptr %t98
  %t99 = ptrtoint ptr %t91 to i64
  %t100 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t100, ptr %l34, !tbaa !27
  %t101 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 0
  store i64 %t102, ptr %l35, !tbaa !24
  %t103 = load i64, ptr %l35, !tbaa !24
  %t104 = mul i64 %t103, 1
  %t106 = inttoptr i64 %t99 to ptr
  %t107 = call ptr @__olang_held_alloc(ptr %t106, i64 %t104)
  %t108 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t107, 1
  store { i64, ptr } %t109, ptr %l36, !tbaa !27
  %t110 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = load i64, ptr %l35, !tbaa !24
  %t115 = mul i64 %t114, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t111, ptr %t113, i64 %t115, i1 false)
  %t116 = load ptr, ptr %l31, !tbaa !29
  %t117 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t116, i32 0, i32 0
  %t118 = load i64, ptr %l32, !tbaa !24
  %t119 = getelementptr { i64, ptr }, ptr %t117, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406", ptr %t120, i64 %t118
  %t122 = getelementptr %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406", ptr %t121, i32 0, i32 1
  %t123 = load { i64, ptr }, ptr %t122, !tbaa !27
  store { i64, ptr } %t123, ptr %l37, !tbaa !27
  %t124 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t125 = load ptr, ptr %l31, !tbaa !29
  %t126 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t125, i32 0, i32 0
  %t127 = load i64, ptr %l32, !tbaa !24
  %t128 = getelementptr { i64, ptr }, ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406", ptr %t129, i64 %t127
  %t131 = getelementptr %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406", ptr %t130, i32 0, i32 1
  store { i64, ptr } %t124, ptr %t131, !tbaa !27
  %t132 = load { i64, ptr }, ptr %l37
  %t133 = extractvalue { i64, ptr } %t132, 1
  call void @__olang_slot_release(ptr %t133)
  store { i64, ptr } zeroinitializer, ptr %l37
  br label %ret
bb16:
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load i64, ptr %l4, !tbaa !24
  %t137 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t134, i32 0, i32 1
  %t139 = getelementptr { i64, ptr }, ptr %t137, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !27
  %t141 = getelementptr i64, ptr %t140, i64 %t135
  %t142 = load i64, ptr %t141, !tbaa !34
  store i64 %t142, ptr %l4, !tbaa !24
  br label %bb11
bb19:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load i64, ptr %l3, !tbaa !24
  %t146 = load i64, ptr %l1, !tbaa !24
  %t147 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_H0ee4baf4a98f2f3ccbca9d2816c12cad(ptr %v0, ptr %t144, i64 %t145, i64 %t146, { i64, ptr } %t147)
  br label %bb20
bb20:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_H8a27ed9804b3bba4e283dd2811723706(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l31 = alloca i64
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l40 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l51 = alloca ptr
  %l52 = alloca { i64, ptr }
  %l54 = alloca i64
  %l55 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l68 = alloca i64
  %l74 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  store { i64, ptr } %t23, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_3ed90fca4b6dbcc1_e266804f8edbf6cd)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_3ed90fca4b6dbcc1_e266804f8edbf6cd)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  %t52 = call ptr @__olang_region_make_part(ptr %v0)
  %t53 = ptrtoint ptr %t52 to i64
  store i64 %t53, ptr %l31, !tbaa !24
  %t56 = mul i64 %t50, 24
  %t57 = load i64, ptr %l31
  %t58 = inttoptr i64 %t57 to ptr
  %t59 = call ptr @__olang_scope_alloc_zeroed(ptr %t58, i64 %t56)
  %t60 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  store { i64, ptr } %t61, ptr %l33, !tbaa !27
  store i64 0, ptr %l34, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_3ed90fca4b6dbcc1_e266804f8edbf6cd)
  unreachable
bb10:
  %t62 = load i64, ptr %l5, !tbaa !24
  %t63 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t63, 0
  %t68 = icmp slt i64 %t62, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  br label %bb13
bb13:
  %t72 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t72, ptr %l40, !tbaa !27
  %t73 = load i64, ptr %l5, !tbaa !24
  %t75 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406", ptr %t76, i64 %t73
  %t78 = load %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406", ptr %t77
  store %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406" zeroinitializer, ptr %t77
  %t80 = load i64, ptr %l34, !tbaa !24
  %t81 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406", ptr %t82, i64 %t80
  store %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406" %t78, ptr %t83
  %t84 = load i64, ptr %l34, !tbaa !24
  %t85 = add i64 %t84, 1
  store i64 %t85, ptr %l34, !tbaa !24
  br label %bb14
bb14:
  %t86 = load i64, ptr %l5, !tbaa !24
  %t89 = add i64 %t86, 1
  store i64 %t89, ptr %l5, !tbaa !24
  br label %bb10
bb15:
  %t91 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t91, 0
  %t94 = icmp eq i64 %t92, 0
  br i1 %t94, label %bb16, label %bb17
bb16:
  store { i64, ptr } zeroinitializer, ptr %l33, !tbaa !27
  br label %bb17
bb17:
  %t96 = load i64, ptr %l31
  %t97 = inttoptr i64 %t96 to ptr
  %t98 = load { i64, ptr }, ptr %l33
  %t99 = extractvalue { i64, ptr } %t98, 1
  %t100 = call ptr @__olang_region_or(ptr %t99, ptr null)
  %t101 = icmp ne ptr %t100, null
  %t102 = select i1 %t101, ptr %t100, ptr null
  call void @__olang_region_settle_in(ptr %t97, ptr %t102)
  %t103 = load ptr, ptr %l21, !tbaa !29
  %t104 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t103, i32 0, i32 0
  %t105 = load { i64, ptr }, ptr %t104, !tbaa !27
  store { i64, ptr } %t105, ptr %l48, !tbaa !27
  %t106 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t107 = load ptr, ptr %l21, !tbaa !29
  %t108 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t107, i32 0, i32 0
  store { i64, ptr } %t106, ptr %t108, !tbaa !27
  %t109 = load { i64, ptr }, ptr %l48
  %t110 = extractvalue { i64, ptr } %t109, 0
  %t111 = extractvalue { i64, ptr } %t109, 1
  call void @__olang_region_release_part(ptr %t111, i64 %t110)
  store { i64, ptr } zeroinitializer, ptr %l48
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t112, i32 0, i32 1
  %t115 = load { i64, ptr }, ptr %t114, !tbaa !27
  %t117 = load ptr, ptr %l0, !tbaa !29
  store ptr %t117, ptr %l51, !tbaa !29
  store { i64, ptr } %t115, ptr %l52, !tbaa !27
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t119, i32 0, i32 3
  %t122 = load i64, ptr %t121, !tbaa !24
  store i64 %t122, ptr %l54, !tbaa !24
  %t123 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 0
  store i64 %t124, ptr %l55, !tbaa !24
  %t125 = icmp sge i64 0, 0
  br i1 %t125, label %bb18, label %bb19
bb18:
  %t127 = load i64, ptr %l54, !tbaa !24
  %t128 = icmp sle i64 0, %t127
  br i1 %t128, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_38414063407efc54_cb5d7512ea6294f0)
  unreachable
bb20:
  %t130 = load i64, ptr %l54, !tbaa !24
  %t131 = load i64, ptr %l55, !tbaa !24
  %t132 = icmp sle i64 %t130, %t131
  br i1 %t132, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_38414063407efc54_cb5d7512ea6294f0)
  unreachable
bb22:
  %t134 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = load i64, ptr %l54, !tbaa !24
  %t137 = getelementptr i64, ptr %t135, i64 0
  %t138 = sub i64 %t136, 0
  %t139 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t140 = insertvalue { i64, ptr } %t139, ptr %t137, 1
  store { i64, ptr } %t140, ptr %l7, !tbaa !27
  %t142 = load i64, ptr %l1, !tbaa !24
  %t144 = call ptr @__olang_region_make_part(ptr %v0)
  %t145 = ptrtoint ptr %t144 to i64
  store i64 %t145, ptr %l61, !tbaa !24
  store i64 %t142, ptr %l62, !tbaa !24
  %t147 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t149 = load i64, ptr %l62, !tbaa !24
  %t150 = extractvalue { i64, ptr } %t147, 0
  %t151 = mul i64 %t150, 8
  %t152 = mul i64 %t149, 8
  %t153 = extractvalue { i64, ptr } %t147, 1
  %t154 = call ptr @__olang_grow_in_place(ptr %t153, i64 %t151, i64 %t152, i64 %t149)
  %t155 = icmp ne ptr %t154, null
  %t156 = select i1 %t155, i64 %t149, i64 0
  %t157 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t154, 1
  store { i64, ptr } %t158, ptr %l65, !tbaa !27
  %t159 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t159, 0
  %t162 = icmp ne i64 %t160, 0
  br i1 %t162, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_38414063407efc54_cb5d7512ea6294f0)
  unreachable
bb24:
  %t164 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t164, ptr %l63, !tbaa !27
  br label %bb26
bb25:
  %t165 = load i64, ptr %l62, !tbaa !24
  %t166 = mul i64 %t165, 8
  %t167 = load i64, ptr %l61
  %t168 = inttoptr i64 %t167 to ptr
  %t169 = call ptr @__olang_held_alloc(ptr %t168, i64 %t166)
  %t170 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr %t169, 1
  store { i64, ptr } %t171, ptr %l63, !tbaa !27
  store i64 0, ptr %l68, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb27
bb26:
  %t172 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t173 = extractvalue { i64, ptr } %t172, 0
  %t175 = icmp eq i64 %t173, 0
  br i1 %t175, label %bb33, label %bb34
bb27:
  %t177 = load i64, ptr %l9, !tbaa !24
  %t178 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t183 = icmp slt i64 %t177, %t180
  %t185 = xor i1 %t183, true
  br i1 %t185, label %bb28, label %bb29
bb28:
  br label %bb32
bb29:
  br label %bb30
bb30:
  %t187 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t187, ptr %l74, !tbaa !27
  %t188 = load i64, ptr %l9, !tbaa !24
  %t190 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !27
  %t192 = getelementptr i64, ptr %t191, i64 %t188
  %t193 = load i64, ptr %t192, !tbaa !34
  %t195 = load i64, ptr %l68, !tbaa !24
  %t196 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !27
  %t198 = getelementptr i64, ptr %t197, i64 %t195
  store i64 %t193, ptr %t198, !tbaa !34
  %t199 = load i64, ptr %l68, !tbaa !24
  %t200 = add i64 %t199, 1
  store i64 %t200, ptr %l68, !tbaa !24
  br label %bb31
bb31:
  %t201 = load i64, ptr %l9, !tbaa !24
  %t204 = add i64 %t201, 1
  store i64 %t204, ptr %l9, !tbaa !24
  br label %bb27
bb32:
  br label %bb26
bb33:
  store { i64, ptr } zeroinitializer, ptr %l63, !tbaa !27
  br label %bb34
bb34:
  %t206 = load i64, ptr %l61
  %t207 = inttoptr i64 %t206 to ptr
  %t208 = load { i64, ptr }, ptr %l63
  %t209 = extractvalue { i64, ptr } %t208, 1
  %t210 = call ptr @__olang_region_or(ptr %t209, ptr null)
  %t211 = icmp ne ptr %t210, null
  %t212 = select i1 %t211, ptr %t210, ptr null
  call void @__olang_region_settle_in(ptr %t207, ptr %t212)
  %t213 = load ptr, ptr %l51, !tbaa !29
  %t214 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t213, i32 0, i32 1
  %t215 = load { i64, ptr }, ptr %t214, !tbaa !27
  store { i64, ptr } %t215, ptr %l82, !tbaa !27
  %t216 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t217 = load ptr, ptr %l51, !tbaa !29
  %t218 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t217, i32 0, i32 1
  store { i64, ptr } %t216, ptr %t218, !tbaa !27
  %t219 = load { i64, ptr }, ptr %l82
  %t220 = extractvalue { i64, ptr } %t219, 0
  %t221 = extractvalue { i64, ptr } %t219, 1
  call void @__olang_region_release_part(ptr %t221, i64 %t220)
  store { i64, ptr } zeroinitializer, ptr %l82
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1ccda06d5ab6c53a2e1f1bbf64061ee6(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l38 = alloca i64
  %l44 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l72 = alloca i64
  %l78 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  store { i64, ptr } %t23, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_df19f69301cf0199_32dd59e57a27f72d)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_df19f69301cf0199_32dd59e57a27f72d)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.886e108519677d9fd0a73cc9f7e545eb", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  %t52 = call ptr @__olang_region_make_part(ptr %v0)
  %t53 = ptrtoint ptr %t52 to i64
  store i64 %t53, ptr %l31, !tbaa !24
  store i64 %t50, ptr %l32, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t57 = load i64, ptr %l32, !tbaa !24
  %t58 = extractvalue { i64, ptr } %t55, 0
  %t59 = mul i64 %t58, 24
  %t60 = mul i64 %t57, 24
  %t61 = extractvalue { i64, ptr } %t55, 1
  %t62 = call ptr @__olang_grow_in_place(ptr %t61, i64 %t59, i64 %t60, i64 %t57)
  %t63 = icmp ne ptr %t62, null
  %t64 = select i1 %t63, i64 %t57, i64 0
  %t65 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t62, 1
  store { i64, ptr } %t66, ptr %l35, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t67, 0
  %t70 = icmp ne i64 %t68, 0
  br i1 %t70, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_df19f69301cf0199_32dd59e57a27f72d)
  unreachable
bb10:
  %t72 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t72, ptr %l33, !tbaa !27
  br label %bb12
bb11:
  %t73 = load i64, ptr %l32, !tbaa !24
  %t74 = mul i64 %t73, 24
  %t75 = load i64, ptr %l31
  %t76 = inttoptr i64 %t75 to ptr
  %t77 = call ptr @__olang_held_alloc(ptr %t76, i64 %t74)
  %t78 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  store { i64, ptr } %t79, ptr %l33, !tbaa !27
  store i64 0, ptr %l38, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb13
bb12:
  %t80 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 0
  %t83 = icmp eq i64 %t81, 0
  br i1 %t83, label %bb19, label %bb20
bb13:
  %t85 = load i64, ptr %l5, !tbaa !24
  %t86 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t91 = icmp slt i64 %t85, %t88
  %t93 = xor i1 %t91, true
  br i1 %t93, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t95 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t95, ptr %l44, !tbaa !27
  %t96 = load i64, ptr %l5, !tbaa !24
  %t98 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr %"std/prelude/map:MapEntry.886e108519677d9fd0a73cc9f7e545eb", ptr %t99, i64 %t96
  %t101 = load %"std/prelude/map:MapEntry.886e108519677d9fd0a73cc9f7e545eb", ptr %t100
  %t103 = load i64, ptr %l38, !tbaa !24
  %t104 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr %"std/prelude/map:MapEntry.886e108519677d9fd0a73cc9f7e545eb", ptr %t105, i64 %t103
  store %"std/prelude/map:MapEntry.886e108519677d9fd0a73cc9f7e545eb" %t101, ptr %t106
  %t107 = load i64, ptr %l38, !tbaa !24
  %t108 = add i64 %t107, 1
  store i64 %t108, ptr %l38, !tbaa !24
  br label %bb17
bb17:
  %t109 = load i64, ptr %l5, !tbaa !24
  %t112 = add i64 %t109, 1
  store i64 %t112, ptr %l5, !tbaa !24
  br label %bb13
bb18:
  br label %bb12
bb19:
  store { i64, ptr } zeroinitializer, ptr %l33, !tbaa !27
  br label %bb20
bb20:
  %t114 = load i64, ptr %l31
  %t115 = inttoptr i64 %t114 to ptr
  %t116 = load { i64, ptr }, ptr %l33
  %t117 = extractvalue { i64, ptr } %t116, 1
  %t118 = call ptr @__olang_region_or(ptr %t117, ptr null)
  %t119 = icmp ne ptr %t118, null
  %t120 = select i1 %t119, ptr %t118, ptr null
  call void @__olang_region_settle_in(ptr %t115, ptr %t120)
  %t121 = load ptr, ptr %l21, !tbaa !29
  %t122 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t121, i32 0, i32 0
  %t123 = load { i64, ptr }, ptr %t122, !tbaa !27
  store { i64, ptr } %t123, ptr %l52, !tbaa !27
  %t124 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t125 = load ptr, ptr %l21, !tbaa !29
  %t126 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t125, i32 0, i32 0
  store { i64, ptr } %t124, ptr %t126, !tbaa !27
  %t127 = load { i64, ptr }, ptr %l52
  %t128 = extractvalue { i64, ptr } %t127, 0
  %t129 = extractvalue { i64, ptr } %t127, 1
  call void @__olang_region_release_part(ptr %t129, i64 %t128)
  store { i64, ptr } zeroinitializer, ptr %l52
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t130, i32 0, i32 1
  %t133 = load { i64, ptr }, ptr %t132, !tbaa !27
  %t135 = load ptr, ptr %l0, !tbaa !29
  store ptr %t135, ptr %l55, !tbaa !29
  store { i64, ptr } %t133, ptr %l56, !tbaa !27
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t137, i32 0, i32 3
  %t140 = load i64, ptr %t139, !tbaa !24
  store i64 %t140, ptr %l58, !tbaa !24
  %t141 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t141, 0
  store i64 %t142, ptr %l59, !tbaa !24
  %t143 = icmp sge i64 0, 0
  br i1 %t143, label %bb21, label %bb22
bb21:
  %t145 = load i64, ptr %l58, !tbaa !24
  %t146 = icmp sle i64 0, %t145
  br i1 %t146, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_8b28957638762ec_261fc0fff4f2e050)
  unreachable
bb23:
  %t148 = load i64, ptr %l58, !tbaa !24
  %t149 = load i64, ptr %l59, !tbaa !24
  %t150 = icmp sle i64 %t148, %t149
  br i1 %t150, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_8b28957638762ec_261fc0fff4f2e050)
  unreachable
bb25:
  %t152 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = load i64, ptr %l58, !tbaa !24
  %t155 = getelementptr i64, ptr %t153, i64 0
  %t156 = sub i64 %t154, 0
  %t157 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t155, 1
  store { i64, ptr } %t158, ptr %l7, !tbaa !27
  %t160 = load i64, ptr %l1, !tbaa !24
  %t162 = call ptr @__olang_region_make_part(ptr %v0)
  %t163 = ptrtoint ptr %t162 to i64
  store i64 %t163, ptr %l65, !tbaa !24
  store i64 %t160, ptr %l66, !tbaa !24
  %t165 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t167 = load i64, ptr %l66, !tbaa !24
  %t168 = extractvalue { i64, ptr } %t165, 0
  %t169 = mul i64 %t168, 8
  %t170 = mul i64 %t167, 8
  %t171 = extractvalue { i64, ptr } %t165, 1
  %t172 = call ptr @__olang_grow_in_place(ptr %t171, i64 %t169, i64 %t170, i64 %t167)
  %t173 = icmp ne ptr %t172, null
  %t174 = select i1 %t173, i64 %t167, i64 0
  %t175 = insertvalue { i64, ptr } undef, i64 %t174, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t172, 1
  store { i64, ptr } %t176, ptr %l69, !tbaa !27
  %t177 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t177, 0
  %t180 = icmp ne i64 %t178, 0
  br i1 %t180, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_8b28957638762ec_261fc0fff4f2e050)
  unreachable
bb27:
  %t182 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t182, ptr %l67, !tbaa !27
  br label %bb29
bb28:
  %t183 = load i64, ptr %l66, !tbaa !24
  %t184 = mul i64 %t183, 8
  %t185 = load i64, ptr %l65
  %t186 = inttoptr i64 %t185 to ptr
  %t187 = call ptr @__olang_held_alloc(ptr %t186, i64 %t184)
  %t188 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t187, 1
  store { i64, ptr } %t189, ptr %l67, !tbaa !27
  store i64 0, ptr %l72, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb30
bb29:
  %t190 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t190, 0
  %t193 = icmp eq i64 %t191, 0
  br i1 %t193, label %bb36, label %bb37
bb30:
  %t195 = load i64, ptr %l9, !tbaa !24
  %t196 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t196, 0
  %t201 = icmp slt i64 %t195, %t198
  %t203 = xor i1 %t201, true
  br i1 %t203, label %bb31, label %bb32
bb31:
  br label %bb35
bb32:
  br label %bb33
bb33:
  %t205 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t205, ptr %l78, !tbaa !27
  %t206 = load i64, ptr %l9, !tbaa !24
  %t208 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr i64, ptr %t209, i64 %t206
  %t211 = load i64, ptr %t210, !tbaa !34
  %t213 = load i64, ptr %l72, !tbaa !24
  %t214 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = getelementptr i64, ptr %t215, i64 %t213
  store i64 %t211, ptr %t216, !tbaa !34
  %t217 = load i64, ptr %l72, !tbaa !24
  %t218 = add i64 %t217, 1
  store i64 %t218, ptr %l72, !tbaa !24
  br label %bb34
bb34:
  %t219 = load i64, ptr %l9, !tbaa !24
  %t222 = add i64 %t219, 1
  store i64 %t222, ptr %l9, !tbaa !24
  br label %bb30
bb35:
  br label %bb29
bb36:
  store { i64, ptr } zeroinitializer, ptr %l67, !tbaa !27
  br label %bb37
bb37:
  %t224 = load i64, ptr %l65
  %t225 = inttoptr i64 %t224 to ptr
  %t226 = load { i64, ptr }, ptr %l67
  %t227 = extractvalue { i64, ptr } %t226, 1
  %t228 = call ptr @__olang_region_or(ptr %t227, ptr null)
  %t229 = icmp ne ptr %t228, null
  %t230 = select i1 %t229, ptr %t228, ptr null
  call void @__olang_region_settle_in(ptr %t225, ptr %t230)
  %t231 = load ptr, ptr %l55, !tbaa !29
  %t232 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t231, i32 0, i32 1
  %t233 = load { i64, ptr }, ptr %t232, !tbaa !27
  store { i64, ptr } %t233, ptr %l86, !tbaa !27
  %t234 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t235 = load ptr, ptr %l55, !tbaa !29
  %t236 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t235, i32 0, i32 1
  store { i64, ptr } %t234, ptr %t236, !tbaa !27
  %t237 = load { i64, ptr }, ptr %l86
  %t238 = extractvalue { i64, ptr } %t237, 0
  %t239 = extractvalue { i64, ptr } %t237, 1
  call void @__olang_region_release_part(ptr %t239, i64 %t238)
  store { i64, ptr } zeroinitializer, ptr %l86
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1eed1ebe67dae700c91accdbbc0e89b4(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l37 = alloca i64
  %l43 = alloca { i64, ptr }
  %l53 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca i64
  %l63 = alloca i64
  %l64 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l69 = alloca i64
  %l75 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  store { i64, ptr } %t23, ptr %l2, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t26, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_f6e80aaea291e936_bdd0ff292b082a4a)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_f6e80aaea291e936_bdd0ff292b082a4a)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.c479befe3d340af6fb5e3e84080d9cfc", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  store i64 %t50, ptr %l31, !tbaa !24
  %t53 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t55 = load i64, ptr %l31, !tbaa !24
  %t56 = extractvalue { i64, ptr } %t53, 0
  %t57 = mul i64 %t56, 32
  %t58 = mul i64 %t55, 32
  %t59 = extractvalue { i64, ptr } %t53, 1
  %t60 = call ptr @__olang_grow_in_place(ptr %t59, i64 %t57, i64 %t58, i64 %t55)
  %t61 = icmp ne ptr %t60, null
  %t62 = select i1 %t61, i64 %t55, i64 0
  %t63 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t60, 1
  store { i64, ptr } %t64, ptr %l34, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 0
  %t68 = icmp ne i64 %t66, 0
  br i1 %t68, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_f6e80aaea291e936_bdd0ff292b082a4a)
  unreachable
bb10:
  %t70 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t70, ptr %l32, !tbaa !27
  br label %bb12
bb11:
  %t71 = load i64, ptr %l31, !tbaa !24
  %t72 = mul i64 %t71, 32
  %t73 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t72)
  %t74 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  store { i64, ptr } %t75, ptr %l32, !tbaa !27
  store i64 0, ptr %l37, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb13
bb12:
  %t76 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t77 = load ptr, ptr %l21, !tbaa !29
  %t78 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t77, i32 0, i32 0
  store { i64, ptr } %t76, ptr %t78, !tbaa !27
  %t79 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t81, i32 0, i32 1
  %t84 = load { i64, ptr }, ptr %t83, !tbaa !27
  store { i64, ptr } %t84, ptr %l6, !tbaa !27
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l53, !tbaa !29
  %t87 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t87, ptr %l54, !tbaa !27
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t88, i32 0, i32 3
  %t91 = load i64, ptr %t90, !tbaa !24
  store i64 %t91, ptr %l56, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 0
  store i64 %t93, ptr %l57, !tbaa !24
  %t94 = icmp sge i64 0, 0
  br i1 %t94, label %bb19, label %bb20
bb13:
  %t96 = load i64, ptr %l5, !tbaa !24
  %t97 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t97, 0
  %t102 = icmp slt i64 %t96, %t99
  %t104 = xor i1 %t102, true
  br i1 %t104, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t106 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t106, ptr %l43, !tbaa !27
  %t107 = load i64, ptr %l5, !tbaa !24
  %t109 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr %"std/prelude/map:MapEntry.c479befe3d340af6fb5e3e84080d9cfc", ptr %t110, i64 %t107
  %t112 = load %"std/prelude/map:MapEntry.c479befe3d340af6fb5e3e84080d9cfc", ptr %t111
  %t114 = load i64, ptr %l37, !tbaa !24
  %t115 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr %"std/prelude/map:MapEntry.c479befe3d340af6fb5e3e84080d9cfc", ptr %t116, i64 %t114
  store %"std/prelude/map:MapEntry.c479befe3d340af6fb5e3e84080d9cfc" %t112, ptr %t117
  %t118 = load i64, ptr %l37, !tbaa !24
  %t119 = add i64 %t118, 1
  store i64 %t119, ptr %l37, !tbaa !24
  br label %bb17
bb17:
  %t120 = load i64, ptr %l5, !tbaa !24
  %t123 = add i64 %t120, 1
  store i64 %t123, ptr %l5, !tbaa !24
  br label %bb13
bb18:
  br label %bb12
bb19:
  %t125 = load i64, ptr %l56, !tbaa !24
  %t126 = icmp sle i64 0, %t125
  br i1 %t126, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_f6f900c9fb154d93_6e60d926358ead27)
  unreachable
bb21:
  %t128 = load i64, ptr %l56, !tbaa !24
  %t129 = load i64, ptr %l57, !tbaa !24
  %t130 = icmp sle i64 %t128, %t129
  br i1 %t130, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_f6f900c9fb154d93_6e60d926358ead27)
  unreachable
bb23:
  %t132 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = load i64, ptr %l56, !tbaa !24
  %t135 = getelementptr i64, ptr %t133, i64 0
  %t136 = sub i64 %t134, 0
  %t137 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t135, 1
  store { i64, ptr } %t138, ptr %l7, !tbaa !27
  %t140 = load i64, ptr %l1, !tbaa !24
  store i64 %t140, ptr %l63, !tbaa !24
  %t143 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t145 = load i64, ptr %l63, !tbaa !24
  %t146 = extractvalue { i64, ptr } %t143, 0
  %t147 = mul i64 %t146, 8
  %t148 = mul i64 %t145, 8
  %t149 = extractvalue { i64, ptr } %t143, 1
  %t150 = call ptr @__olang_grow_in_place(ptr %t149, i64 %t147, i64 %t148, i64 %t145)
  %t151 = icmp ne ptr %t150, null
  %t152 = select i1 %t151, i64 %t145, i64 0
  %t153 = insertvalue { i64, ptr } undef, i64 %t152, 0
  %t154 = insertvalue { i64, ptr } %t153, ptr %t150, 1
  store { i64, ptr } %t154, ptr %l66, !tbaa !27
  %t155 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t156 = extractvalue { i64, ptr } %t155, 0
  %t158 = icmp ne i64 %t156, 0
  br i1 %t158, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_f6f900c9fb154d93_6e60d926358ead27)
  unreachable
bb25:
  %t160 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t160, ptr %l64, !tbaa !27
  br label %bb27
bb26:
  %t161 = load i64, ptr %l63, !tbaa !24
  %t162 = mul i64 %t161, 8
  %t163 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t162)
  %t164 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t165 = insertvalue { i64, ptr } %t164, ptr %t163, 1
  store { i64, ptr } %t165, ptr %l64, !tbaa !27
  store i64 0, ptr %l69, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb28
bb27:
  %t166 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t167 = load ptr, ptr %l53, !tbaa !29
  %t168 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t167, i32 0, i32 1
  store { i64, ptr } %t166, ptr %t168, !tbaa !27
  %t169 = load { i64, ptr }, ptr %l6, !tbaa !27
  br label %ret
bb28:
  %t171 = load i64, ptr %l9, !tbaa !24
  %t172 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t174 = extractvalue { i64, ptr } %t172, 0
  %t177 = icmp slt i64 %t171, %t174
  %t179 = xor i1 %t177, true
  br i1 %t179, label %bb29, label %bb30
bb29:
  br label %bb33
bb30:
  br label %bb31
bb31:
  %t181 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t181, ptr %l75, !tbaa !27
  %t182 = load i64, ptr %l9, !tbaa !24
  %t184 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !27
  %t186 = getelementptr i64, ptr %t185, i64 %t182
  %t187 = load i64, ptr %t186, !tbaa !34
  %t189 = load i64, ptr %l69, !tbaa !24
  %t190 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !27
  %t192 = getelementptr i64, ptr %t191, i64 %t189
  store i64 %t187, ptr %t192, !tbaa !34
  %t193 = load i64, ptr %l69, !tbaa !24
  %t194 = add i64 %t193, 1
  store i64 %t194, ptr %l69, !tbaa !24
  br label %bb32
bb32:
  %t195 = load i64, ptr %l9, !tbaa !24
  %t198 = add i64 %t195, 1
  store i64 %t198, ptr %l9, !tbaa !24
  br label %bb28
bb33:
  br label %bb27
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2a52a15a776f7a243a1276f4bdd33edf(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l37 = alloca i64
  %l43 = alloca { i64, ptr }
  %l53 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca i64
  %l63 = alloca i64
  %l64 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l69 = alloca i64
  %l75 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  store { i64, ptr } %t23, ptr %l2, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t26, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_2c5412a51f90260e_61b8746bf353c102)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_2c5412a51f90260e_61b8746bf353c102)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.cae77de4d581cc3ff23f947d2513f613", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  store i64 %t50, ptr %l31, !tbaa !24
  %t53 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t55 = load i64, ptr %l31, !tbaa !24
  %t56 = extractvalue { i64, ptr } %t53, 0
  %t57 = mul i64 %t56, 32
  %t58 = mul i64 %t55, 32
  %t59 = extractvalue { i64, ptr } %t53, 1
  %t60 = call ptr @__olang_grow_in_place(ptr %t59, i64 %t57, i64 %t58, i64 %t55)
  %t61 = icmp ne ptr %t60, null
  %t62 = select i1 %t61, i64 %t55, i64 0
  %t63 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t60, 1
  store { i64, ptr } %t64, ptr %l34, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 0
  %t68 = icmp ne i64 %t66, 0
  br i1 %t68, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_2c5412a51f90260e_61b8746bf353c102)
  unreachable
bb10:
  %t70 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t70, ptr %l32, !tbaa !27
  br label %bb12
bb11:
  %t71 = load i64, ptr %l31, !tbaa !24
  %t72 = mul i64 %t71, 32
  %t73 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t72)
  %t74 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  store { i64, ptr } %t75, ptr %l32, !tbaa !27
  store i64 0, ptr %l37, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb13
bb12:
  %t76 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t77 = load ptr, ptr %l21, !tbaa !29
  %t78 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t77, i32 0, i32 0
  store { i64, ptr } %t76, ptr %t78, !tbaa !27
  %t79 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t81, i32 0, i32 1
  %t84 = load { i64, ptr }, ptr %t83, !tbaa !27
  store { i64, ptr } %t84, ptr %l6, !tbaa !27
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l53, !tbaa !29
  %t87 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t87, ptr %l54, !tbaa !27
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t88, i32 0, i32 3
  %t91 = load i64, ptr %t90, !tbaa !24
  store i64 %t91, ptr %l56, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 0
  store i64 %t93, ptr %l57, !tbaa !24
  %t94 = icmp sge i64 0, 0
  br i1 %t94, label %bb19, label %bb20
bb13:
  %t96 = load i64, ptr %l5, !tbaa !24
  %t97 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t97, 0
  %t102 = icmp slt i64 %t96, %t99
  %t104 = xor i1 %t102, true
  br i1 %t104, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t106 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t106, ptr %l43, !tbaa !27
  %t107 = load i64, ptr %l5, !tbaa !24
  %t109 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr %"std/prelude/map:MapEntry.cae77de4d581cc3ff23f947d2513f613", ptr %t110, i64 %t107
  %t112 = load %"std/prelude/map:MapEntry.cae77de4d581cc3ff23f947d2513f613", ptr %t111
  %t114 = load i64, ptr %l37, !tbaa !24
  %t115 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr %"std/prelude/map:MapEntry.cae77de4d581cc3ff23f947d2513f613", ptr %t116, i64 %t114
  store %"std/prelude/map:MapEntry.cae77de4d581cc3ff23f947d2513f613" %t112, ptr %t117
  %t118 = load i64, ptr %l37, !tbaa !24
  %t119 = add i64 %t118, 1
  store i64 %t119, ptr %l37, !tbaa !24
  br label %bb17
bb17:
  %t120 = load i64, ptr %l5, !tbaa !24
  %t123 = add i64 %t120, 1
  store i64 %t123, ptr %l5, !tbaa !24
  br label %bb13
bb18:
  br label %bb12
bb19:
  %t125 = load i64, ptr %l56, !tbaa !24
  %t126 = icmp sle i64 0, %t125
  br i1 %t126, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_b7c452d6898a720b_ae277c99aaa8cdff)
  unreachable
bb21:
  %t128 = load i64, ptr %l56, !tbaa !24
  %t129 = load i64, ptr %l57, !tbaa !24
  %t130 = icmp sle i64 %t128, %t129
  br i1 %t130, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_b7c452d6898a720b_ae277c99aaa8cdff)
  unreachable
bb23:
  %t132 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = load i64, ptr %l56, !tbaa !24
  %t135 = getelementptr i64, ptr %t133, i64 0
  %t136 = sub i64 %t134, 0
  %t137 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t135, 1
  store { i64, ptr } %t138, ptr %l7, !tbaa !27
  %t140 = load i64, ptr %l1, !tbaa !24
  store i64 %t140, ptr %l63, !tbaa !24
  %t143 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t145 = load i64, ptr %l63, !tbaa !24
  %t146 = extractvalue { i64, ptr } %t143, 0
  %t147 = mul i64 %t146, 8
  %t148 = mul i64 %t145, 8
  %t149 = extractvalue { i64, ptr } %t143, 1
  %t150 = call ptr @__olang_grow_in_place(ptr %t149, i64 %t147, i64 %t148, i64 %t145)
  %t151 = icmp ne ptr %t150, null
  %t152 = select i1 %t151, i64 %t145, i64 0
  %t153 = insertvalue { i64, ptr } undef, i64 %t152, 0
  %t154 = insertvalue { i64, ptr } %t153, ptr %t150, 1
  store { i64, ptr } %t154, ptr %l66, !tbaa !27
  %t155 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t156 = extractvalue { i64, ptr } %t155, 0
  %t158 = icmp ne i64 %t156, 0
  br i1 %t158, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_b7c452d6898a720b_ae277c99aaa8cdff)
  unreachable
bb25:
  %t160 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t160, ptr %l64, !tbaa !27
  br label %bb27
bb26:
  %t161 = load i64, ptr %l63, !tbaa !24
  %t162 = mul i64 %t161, 8
  %t163 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t162)
  %t164 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t165 = insertvalue { i64, ptr } %t164, ptr %t163, 1
  store { i64, ptr } %t165, ptr %l64, !tbaa !27
  store i64 0, ptr %l69, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb28
bb27:
  %t166 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t167 = load ptr, ptr %l53, !tbaa !29
  %t168 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t167, i32 0, i32 1
  store { i64, ptr } %t166, ptr %t168, !tbaa !27
  %t169 = load { i64, ptr }, ptr %l6, !tbaa !27
  br label %ret
bb28:
  %t171 = load i64, ptr %l9, !tbaa !24
  %t172 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t174 = extractvalue { i64, ptr } %t172, 0
  %t177 = icmp slt i64 %t171, %t174
  %t179 = xor i1 %t177, true
  br i1 %t179, label %bb29, label %bb30
bb29:
  br label %bb33
bb30:
  br label %bb31
bb31:
  %t181 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t181, ptr %l75, !tbaa !27
  %t182 = load i64, ptr %l9, !tbaa !24
  %t184 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !27
  %t186 = getelementptr i64, ptr %t185, i64 %t182
  %t187 = load i64, ptr %t186, !tbaa !34
  %t189 = load i64, ptr %l69, !tbaa !24
  %t190 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !27
  %t192 = getelementptr i64, ptr %t191, i64 %t189
  store i64 %t187, ptr %t192, !tbaa !34
  %t193 = load i64, ptr %l69, !tbaa !24
  %t194 = add i64 %t193, 1
  store i64 %t194, ptr %l69, !tbaa !24
  br label %bb32
bb32:
  %t195 = load i64, ptr %l9, !tbaa !24
  %t198 = add i64 %t195, 1
  store i64 %t198, ptr %l9, !tbaa !24
  br label %bb28
bb33:
  br label %bb27
ret:
  ret void
}

@std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H551f1ec336bccb86bfc3bba4b3431c37 = dso_local alias void (ptr, ptr), ptr @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1ccda06d5ab6c53a2e1f1bbf64061ee6
@std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H590c7ed7771f8804344ada833807182c = dso_local alias void (ptr, ptr), ptr @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1ccda06d5ab6c53a2e1f1bbf64061ee6
define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H6c7035c267fe4124c349f2423937cd21(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l39 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca i64
  %l59 = alloca i64
  %l60 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l65 = alloca i64
  %l71 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  store { i64, ptr } %t23, ptr %l2, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t26, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_79842d5ccdf22f4c_100582a00b153188)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_79842d5ccdf22f4c_100582a00b153188)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.39ab5235a9e7cc4d21ab272df52b187f", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  %t54 = mul i64 %t50, 48
  %t55 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l32, !tbaa !27
  store i64 0, ptr %l33, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_79842d5ccdf22f4c_100582a00b153188)
  unreachable
bb10:
  %t58 = load i64, ptr %l5, !tbaa !24
  %t59 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t59, 0
  %t64 = icmp slt i64 %t58, %t61
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  br label %bb13
bb13:
  %t68 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t68, ptr %l39, !tbaa !27
  %t69 = load i64, ptr %l5, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr %"std/prelude/map:MapEntry.39ab5235a9e7cc4d21ab272df52b187f", ptr %t72, i64 %t69
  %t74 = load %"std/prelude/map:MapEntry.39ab5235a9e7cc4d21ab272df52b187f", ptr %t73
  store %"std/prelude/map:MapEntry.39ab5235a9e7cc4d21ab272df52b187f" zeroinitializer, ptr %t73
  %t76 = load i64, ptr %l33, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr %"std/prelude/map:MapEntry.39ab5235a9e7cc4d21ab272df52b187f", ptr %t78, i64 %t76
  store %"std/prelude/map:MapEntry.39ab5235a9e7cc4d21ab272df52b187f" %t74, ptr %t79
  %t80 = load i64, ptr %l33, !tbaa !24
  %t81 = add i64 %t80, 1
  store i64 %t81, ptr %l33, !tbaa !24
  br label %bb14
bb14:
  %t82 = load i64, ptr %l5, !tbaa !24
  %t85 = add i64 %t82, 1
  store i64 %t85, ptr %l5, !tbaa !24
  br label %bb10
bb15:
  %t87 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t88 = load ptr, ptr %l21, !tbaa !29
  %t89 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t88, i32 0, i32 0
  store { i64, ptr } %t87, ptr %t89, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t92, i32 0, i32 1
  %t95 = load { i64, ptr }, ptr %t94, !tbaa !27
  store { i64, ptr } %t95, ptr %l6, !tbaa !27
  %t97 = load ptr, ptr %l0, !tbaa !29
  store ptr %t97, ptr %l49, !tbaa !29
  %t98 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t98, ptr %l50, !tbaa !27
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t99, i32 0, i32 3
  %t102 = load i64, ptr %t101, !tbaa !24
  store i64 %t102, ptr %l52, !tbaa !24
  %t103 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t103, 0
  store i64 %t104, ptr %l53, !tbaa !24
  %t105 = icmp sge i64 0, 0
  br i1 %t105, label %bb16, label %bb17
bb16:
  %t107 = load i64, ptr %l52, !tbaa !24
  %t108 = icmp sle i64 0, %t107
  br i1 %t108, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_2652fb2e976ac379_5ebf8f5e51b7b7e5)
  unreachable
bb18:
  %t110 = load i64, ptr %l52, !tbaa !24
  %t111 = load i64, ptr %l53, !tbaa !24
  %t112 = icmp sle i64 %t110, %t111
  br i1 %t112, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_2652fb2e976ac379_5ebf8f5e51b7b7e5)
  unreachable
bb20:
  %t114 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = load i64, ptr %l52, !tbaa !24
  %t117 = getelementptr i64, ptr %t115, i64 0
  %t118 = sub i64 %t116, 0
  %t119 = insertvalue { i64, ptr } undef, i64 %t118, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %t117, 1
  store { i64, ptr } %t120, ptr %l7, !tbaa !27
  %t122 = load i64, ptr %l1, !tbaa !24
  store i64 %t122, ptr %l59, !tbaa !24
  %t125 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t127 = load i64, ptr %l59, !tbaa !24
  %t128 = extractvalue { i64, ptr } %t125, 0
  %t129 = mul i64 %t128, 8
  %t130 = mul i64 %t127, 8
  %t131 = extractvalue { i64, ptr } %t125, 1
  %t132 = call ptr @__olang_grow_in_place(ptr %t131, i64 %t129, i64 %t130, i64 %t127)
  %t133 = icmp ne ptr %t132, null
  %t134 = select i1 %t133, i64 %t127, i64 0
  %t135 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t136 = insertvalue { i64, ptr } %t135, ptr %t132, 1
  store { i64, ptr } %t136, ptr %l62, !tbaa !27
  %t137 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 0
  %t140 = icmp ne i64 %t138, 0
  br i1 %t140, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_2652fb2e976ac379_5ebf8f5e51b7b7e5)
  unreachable
bb22:
  %t142 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t142, ptr %l60, !tbaa !27
  br label %bb24
bb23:
  %t143 = load i64, ptr %l59, !tbaa !24
  %t144 = mul i64 %t143, 8
  %t145 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t144)
  %t146 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t147 = insertvalue { i64, ptr } %t146, ptr %t145, 1
  store { i64, ptr } %t147, ptr %l60, !tbaa !27
  store i64 0, ptr %l65, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb25
bb24:
  %t148 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t149 = load ptr, ptr %l49, !tbaa !29
  %t150 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t149, i32 0, i32 1
  store { i64, ptr } %t148, ptr %t150, !tbaa !27
  %t151 = load { i64, ptr }, ptr %l6, !tbaa !27
  br label %ret
bb25:
  %t153 = load i64, ptr %l9, !tbaa !24
  %t154 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t156 = extractvalue { i64, ptr } %t154, 0
  %t159 = icmp slt i64 %t153, %t156
  %t161 = xor i1 %t159, true
  br i1 %t161, label %bb26, label %bb27
bb26:
  br label %bb30
bb27:
  br label %bb28
bb28:
  %t163 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t163, ptr %l71, !tbaa !27
  %t164 = load i64, ptr %l9, !tbaa !24
  %t166 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = getelementptr i64, ptr %t167, i64 %t164
  %t169 = load i64, ptr %t168, !tbaa !34
  %t171 = load i64, ptr %l65, !tbaa !24
  %t172 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !27
  %t174 = getelementptr i64, ptr %t173, i64 %t171
  store i64 %t169, ptr %t174, !tbaa !34
  %t175 = load i64, ptr %l65, !tbaa !24
  %t176 = add i64 %t175, 1
  store i64 %t176, ptr %l65, !tbaa !24
  br label %bb29
bb29:
  %t177 = load i64, ptr %l9, !tbaa !24
  %t180 = add i64 %t177, 1
  store i64 %t180, ptr %l9, !tbaa !24
  br label %bb25
bb30:
  br label %bb24
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H77729e245198d1d2bd2a646f82e19205(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l38 = alloca i64
  %l44 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l72 = alloca i64
  %l78 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  store { i64, ptr } %t23, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_8448838d2b3ab7a7_3ecc9b11324320fb)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_8448838d2b3ab7a7_3ecc9b11324320fb)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.b139c4f75a6545712256427180a82a06", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  %t52 = call ptr @__olang_region_make_part(ptr %v0)
  %t53 = ptrtoint ptr %t52 to i64
  store i64 %t53, ptr %l31, !tbaa !24
  store i64 %t50, ptr %l32, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t57 = load i64, ptr %l32, !tbaa !24
  %t58 = extractvalue { i64, ptr } %t55, 0
  %t59 = mul i64 %t58, 32
  %t60 = mul i64 %t57, 32
  %t61 = extractvalue { i64, ptr } %t55, 1
  %t62 = call ptr @__olang_grow_in_place(ptr %t61, i64 %t59, i64 %t60, i64 %t57)
  %t63 = icmp ne ptr %t62, null
  %t64 = select i1 %t63, i64 %t57, i64 0
  %t65 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t62, 1
  store { i64, ptr } %t66, ptr %l35, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t67, 0
  %t70 = icmp ne i64 %t68, 0
  br i1 %t70, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_8448838d2b3ab7a7_3ecc9b11324320fb)
  unreachable
bb10:
  %t72 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t72, ptr %l33, !tbaa !27
  br label %bb12
bb11:
  %t73 = load i64, ptr %l32, !tbaa !24
  %t74 = mul i64 %t73, 32
  %t75 = load i64, ptr %l31
  %t76 = inttoptr i64 %t75 to ptr
  %t77 = call ptr @__olang_held_alloc(ptr %t76, i64 %t74)
  %t78 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  store { i64, ptr } %t79, ptr %l33, !tbaa !27
  store i64 0, ptr %l38, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb13
bb12:
  %t80 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 0
  %t83 = icmp eq i64 %t81, 0
  br i1 %t83, label %bb19, label %bb20
bb13:
  %t85 = load i64, ptr %l5, !tbaa !24
  %t86 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t91 = icmp slt i64 %t85, %t88
  %t93 = xor i1 %t91, true
  br i1 %t93, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t95 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t95, ptr %l44, !tbaa !27
  %t96 = load i64, ptr %l5, !tbaa !24
  %t98 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr %"std/prelude/map:MapEntry.b139c4f75a6545712256427180a82a06", ptr %t99, i64 %t96
  %t101 = load %"std/prelude/map:MapEntry.b139c4f75a6545712256427180a82a06", ptr %t100
  %t103 = load i64, ptr %l38, !tbaa !24
  %t104 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr %"std/prelude/map:MapEntry.b139c4f75a6545712256427180a82a06", ptr %t105, i64 %t103
  store %"std/prelude/map:MapEntry.b139c4f75a6545712256427180a82a06" %t101, ptr %t106
  %t107 = load i64, ptr %l38, !tbaa !24
  %t108 = add i64 %t107, 1
  store i64 %t108, ptr %l38, !tbaa !24
  br label %bb17
bb17:
  %t109 = load i64, ptr %l5, !tbaa !24
  %t112 = add i64 %t109, 1
  store i64 %t112, ptr %l5, !tbaa !24
  br label %bb13
bb18:
  br label %bb12
bb19:
  store { i64, ptr } zeroinitializer, ptr %l33, !tbaa !27
  br label %bb20
bb20:
  %t114 = load i64, ptr %l31
  %t115 = inttoptr i64 %t114 to ptr
  %t116 = load { i64, ptr }, ptr %l33
  %t117 = extractvalue { i64, ptr } %t116, 1
  %t118 = call ptr @__olang_region_or(ptr %t117, ptr null)
  %t119 = icmp ne ptr %t118, null
  %t120 = select i1 %t119, ptr %t118, ptr null
  call void @__olang_region_settle_in(ptr %t115, ptr %t120)
  %t121 = load ptr, ptr %l21, !tbaa !29
  %t122 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t121, i32 0, i32 0
  %t123 = load { i64, ptr }, ptr %t122, !tbaa !27
  store { i64, ptr } %t123, ptr %l52, !tbaa !27
  %t124 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t125 = load ptr, ptr %l21, !tbaa !29
  %t126 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t125, i32 0, i32 0
  store { i64, ptr } %t124, ptr %t126, !tbaa !27
  %t127 = load { i64, ptr }, ptr %l52
  %t128 = extractvalue { i64, ptr } %t127, 0
  %t129 = extractvalue { i64, ptr } %t127, 1
  call void @__olang_region_release_part(ptr %t129, i64 %t128)
  store { i64, ptr } zeroinitializer, ptr %l52
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t130, i32 0, i32 1
  %t133 = load { i64, ptr }, ptr %t132, !tbaa !27
  %t135 = load ptr, ptr %l0, !tbaa !29
  store ptr %t135, ptr %l55, !tbaa !29
  store { i64, ptr } %t133, ptr %l56, !tbaa !27
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t137, i32 0, i32 3
  %t140 = load i64, ptr %t139, !tbaa !24
  store i64 %t140, ptr %l58, !tbaa !24
  %t141 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t141, 0
  store i64 %t142, ptr %l59, !tbaa !24
  %t143 = icmp sge i64 0, 0
  br i1 %t143, label %bb21, label %bb22
bb21:
  %t145 = load i64, ptr %l58, !tbaa !24
  %t146 = icmp sle i64 0, %t145
  br i1 %t146, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_d3b8a99020b434ca_99ad44d2842c9e7e)
  unreachable
bb23:
  %t148 = load i64, ptr %l58, !tbaa !24
  %t149 = load i64, ptr %l59, !tbaa !24
  %t150 = icmp sle i64 %t148, %t149
  br i1 %t150, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_d3b8a99020b434ca_99ad44d2842c9e7e)
  unreachable
bb25:
  %t152 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = load i64, ptr %l58, !tbaa !24
  %t155 = getelementptr i64, ptr %t153, i64 0
  %t156 = sub i64 %t154, 0
  %t157 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t155, 1
  store { i64, ptr } %t158, ptr %l7, !tbaa !27
  %t160 = load i64, ptr %l1, !tbaa !24
  %t162 = call ptr @__olang_region_make_part(ptr %v0)
  %t163 = ptrtoint ptr %t162 to i64
  store i64 %t163, ptr %l65, !tbaa !24
  store i64 %t160, ptr %l66, !tbaa !24
  %t165 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t167 = load i64, ptr %l66, !tbaa !24
  %t168 = extractvalue { i64, ptr } %t165, 0
  %t169 = mul i64 %t168, 8
  %t170 = mul i64 %t167, 8
  %t171 = extractvalue { i64, ptr } %t165, 1
  %t172 = call ptr @__olang_grow_in_place(ptr %t171, i64 %t169, i64 %t170, i64 %t167)
  %t173 = icmp ne ptr %t172, null
  %t174 = select i1 %t173, i64 %t167, i64 0
  %t175 = insertvalue { i64, ptr } undef, i64 %t174, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t172, 1
  store { i64, ptr } %t176, ptr %l69, !tbaa !27
  %t177 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t177, 0
  %t180 = icmp ne i64 %t178, 0
  br i1 %t180, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_d3b8a99020b434ca_99ad44d2842c9e7e)
  unreachable
bb27:
  %t182 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t182, ptr %l67, !tbaa !27
  br label %bb29
bb28:
  %t183 = load i64, ptr %l66, !tbaa !24
  %t184 = mul i64 %t183, 8
  %t185 = load i64, ptr %l65
  %t186 = inttoptr i64 %t185 to ptr
  %t187 = call ptr @__olang_held_alloc(ptr %t186, i64 %t184)
  %t188 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t187, 1
  store { i64, ptr } %t189, ptr %l67, !tbaa !27
  store i64 0, ptr %l72, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb30
bb29:
  %t190 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t190, 0
  %t193 = icmp eq i64 %t191, 0
  br i1 %t193, label %bb36, label %bb37
bb30:
  %t195 = load i64, ptr %l9, !tbaa !24
  %t196 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t196, 0
  %t201 = icmp slt i64 %t195, %t198
  %t203 = xor i1 %t201, true
  br i1 %t203, label %bb31, label %bb32
bb31:
  br label %bb35
bb32:
  br label %bb33
bb33:
  %t205 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t205, ptr %l78, !tbaa !27
  %t206 = load i64, ptr %l9, !tbaa !24
  %t208 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr i64, ptr %t209, i64 %t206
  %t211 = load i64, ptr %t210, !tbaa !34
  %t213 = load i64, ptr %l72, !tbaa !24
  %t214 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = getelementptr i64, ptr %t215, i64 %t213
  store i64 %t211, ptr %t216, !tbaa !34
  %t217 = load i64, ptr %l72, !tbaa !24
  %t218 = add i64 %t217, 1
  store i64 %t218, ptr %l72, !tbaa !24
  br label %bb34
bb34:
  %t219 = load i64, ptr %l9, !tbaa !24
  %t222 = add i64 %t219, 1
  store i64 %t222, ptr %l9, !tbaa !24
  br label %bb30
bb35:
  br label %bb29
bb36:
  store { i64, ptr } zeroinitializer, ptr %l67, !tbaa !27
  br label %bb37
bb37:
  %t224 = load i64, ptr %l65
  %t225 = inttoptr i64 %t224 to ptr
  %t226 = load { i64, ptr }, ptr %l67
  %t227 = extractvalue { i64, ptr } %t226, 1
  %t228 = call ptr @__olang_region_or(ptr %t227, ptr null)
  %t229 = icmp ne ptr %t228, null
  %t230 = select i1 %t229, ptr %t228, ptr null
  call void @__olang_region_settle_in(ptr %t225, ptr %t230)
  %t231 = load ptr, ptr %l55, !tbaa !29
  %t232 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t231, i32 0, i32 1
  %t233 = load { i64, ptr }, ptr %t232, !tbaa !27
  store { i64, ptr } %t233, ptr %l86, !tbaa !27
  %t234 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t235 = load ptr, ptr %l55, !tbaa !29
  %t236 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t235, i32 0, i32 1
  store { i64, ptr } %t234, ptr %t236, !tbaa !27
  %t237 = load { i64, ptr }, ptr %l86
  %t238 = extractvalue { i64, ptr } %t237, 0
  %t239 = extractvalue { i64, ptr } %t237, 1
  call void @__olang_region_release_part(ptr %t239, i64 %t238)
  store { i64, ptr } zeroinitializer, ptr %l86
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hb998f37ff6bac06e7987e0faa781f632(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l38 = alloca i64
  %l44 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l72 = alloca i64
  %l78 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  store { i64, ptr } %t23, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_1f883794dd6a792d_50e0eef0cca60dd9)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_1f883794dd6a792d_50e0eef0cca60dd9)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.5c05261437902d544b32c18bccabd218", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  %t52 = call ptr @__olang_region_make_part(ptr %v0)
  %t53 = ptrtoint ptr %t52 to i64
  store i64 %t53, ptr %l31, !tbaa !24
  store i64 %t50, ptr %l32, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t57 = load i64, ptr %l32, !tbaa !24
  %t58 = extractvalue { i64, ptr } %t55, 0
  %t59 = mul i64 %t58, 40
  %t60 = mul i64 %t57, 40
  %t61 = extractvalue { i64, ptr } %t55, 1
  %t62 = call ptr @__olang_grow_in_place(ptr %t61, i64 %t59, i64 %t60, i64 %t57)
  %t63 = icmp ne ptr %t62, null
  %t64 = select i1 %t63, i64 %t57, i64 0
  %t65 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t62, 1
  store { i64, ptr } %t66, ptr %l35, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t67, 0
  %t70 = icmp ne i64 %t68, 0
  br i1 %t70, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_1f883794dd6a792d_50e0eef0cca60dd9)
  unreachable
bb10:
  %t72 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t72, ptr %l33, !tbaa !27
  br label %bb12
bb11:
  %t73 = load i64, ptr %l32, !tbaa !24
  %t74 = mul i64 %t73, 40
  %t75 = load i64, ptr %l31
  %t76 = inttoptr i64 %t75 to ptr
  %t77 = call ptr @__olang_held_alloc(ptr %t76, i64 %t74)
  %t78 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  store { i64, ptr } %t79, ptr %l33, !tbaa !27
  store i64 0, ptr %l38, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb13
bb12:
  %t80 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 0
  %t83 = icmp eq i64 %t81, 0
  br i1 %t83, label %bb19, label %bb20
bb13:
  %t85 = load i64, ptr %l5, !tbaa !24
  %t86 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t91 = icmp slt i64 %t85, %t88
  %t93 = xor i1 %t91, true
  br i1 %t93, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t95 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t95, ptr %l44, !tbaa !27
  %t96 = load i64, ptr %l5, !tbaa !24
  %t98 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr %"std/prelude/map:MapEntry.5c05261437902d544b32c18bccabd218", ptr %t99, i64 %t96
  %t101 = load %"std/prelude/map:MapEntry.5c05261437902d544b32c18bccabd218", ptr %t100
  %t103 = load i64, ptr %l38, !tbaa !24
  %t104 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr %"std/prelude/map:MapEntry.5c05261437902d544b32c18bccabd218", ptr %t105, i64 %t103
  store %"std/prelude/map:MapEntry.5c05261437902d544b32c18bccabd218" %t101, ptr %t106
  %t107 = load i64, ptr %l38, !tbaa !24
  %t108 = add i64 %t107, 1
  store i64 %t108, ptr %l38, !tbaa !24
  br label %bb17
bb17:
  %t109 = load i64, ptr %l5, !tbaa !24
  %t112 = add i64 %t109, 1
  store i64 %t112, ptr %l5, !tbaa !24
  br label %bb13
bb18:
  br label %bb12
bb19:
  store { i64, ptr } zeroinitializer, ptr %l33, !tbaa !27
  br label %bb20
bb20:
  %t114 = load i64, ptr %l31
  %t115 = inttoptr i64 %t114 to ptr
  %t116 = load { i64, ptr }, ptr %l33
  %t117 = extractvalue { i64, ptr } %t116, 1
  %t118 = call ptr @__olang_region_or(ptr %t117, ptr null)
  %t119 = icmp ne ptr %t118, null
  %t120 = select i1 %t119, ptr %t118, ptr null
  call void @__olang_region_settle_in(ptr %t115, ptr %t120)
  %t121 = load ptr, ptr %l21, !tbaa !29
  %t122 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t121, i32 0, i32 0
  %t123 = load { i64, ptr }, ptr %t122, !tbaa !27
  store { i64, ptr } %t123, ptr %l52, !tbaa !27
  %t124 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t125 = load ptr, ptr %l21, !tbaa !29
  %t126 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t125, i32 0, i32 0
  store { i64, ptr } %t124, ptr %t126, !tbaa !27
  %t127 = load { i64, ptr }, ptr %l52
  %t128 = extractvalue { i64, ptr } %t127, 0
  %t129 = extractvalue { i64, ptr } %t127, 1
  call void @__olang_region_release_part(ptr %t129, i64 %t128)
  store { i64, ptr } zeroinitializer, ptr %l52
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t130, i32 0, i32 1
  %t133 = load { i64, ptr }, ptr %t132, !tbaa !27
  %t135 = load ptr, ptr %l0, !tbaa !29
  store ptr %t135, ptr %l55, !tbaa !29
  store { i64, ptr } %t133, ptr %l56, !tbaa !27
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t137, i32 0, i32 3
  %t140 = load i64, ptr %t139, !tbaa !24
  store i64 %t140, ptr %l58, !tbaa !24
  %t141 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t141, 0
  store i64 %t142, ptr %l59, !tbaa !24
  %t143 = icmp sge i64 0, 0
  br i1 %t143, label %bb21, label %bb22
bb21:
  %t145 = load i64, ptr %l58, !tbaa !24
  %t146 = icmp sle i64 0, %t145
  br i1 %t146, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_12ca9eaf58356250_8bd357473b286e2c)
  unreachable
bb23:
  %t148 = load i64, ptr %l58, !tbaa !24
  %t149 = load i64, ptr %l59, !tbaa !24
  %t150 = icmp sle i64 %t148, %t149
  br i1 %t150, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_12ca9eaf58356250_8bd357473b286e2c)
  unreachable
bb25:
  %t152 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = load i64, ptr %l58, !tbaa !24
  %t155 = getelementptr i64, ptr %t153, i64 0
  %t156 = sub i64 %t154, 0
  %t157 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t155, 1
  store { i64, ptr } %t158, ptr %l7, !tbaa !27
  %t160 = load i64, ptr %l1, !tbaa !24
  %t162 = call ptr @__olang_region_make_part(ptr %v0)
  %t163 = ptrtoint ptr %t162 to i64
  store i64 %t163, ptr %l65, !tbaa !24
  store i64 %t160, ptr %l66, !tbaa !24
  %t165 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t167 = load i64, ptr %l66, !tbaa !24
  %t168 = extractvalue { i64, ptr } %t165, 0
  %t169 = mul i64 %t168, 8
  %t170 = mul i64 %t167, 8
  %t171 = extractvalue { i64, ptr } %t165, 1
  %t172 = call ptr @__olang_grow_in_place(ptr %t171, i64 %t169, i64 %t170, i64 %t167)
  %t173 = icmp ne ptr %t172, null
  %t174 = select i1 %t173, i64 %t167, i64 0
  %t175 = insertvalue { i64, ptr } undef, i64 %t174, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t172, 1
  store { i64, ptr } %t176, ptr %l69, !tbaa !27
  %t177 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t177, 0
  %t180 = icmp ne i64 %t178, 0
  br i1 %t180, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_12ca9eaf58356250_8bd357473b286e2c)
  unreachable
bb27:
  %t182 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t182, ptr %l67, !tbaa !27
  br label %bb29
bb28:
  %t183 = load i64, ptr %l66, !tbaa !24
  %t184 = mul i64 %t183, 8
  %t185 = load i64, ptr %l65
  %t186 = inttoptr i64 %t185 to ptr
  %t187 = call ptr @__olang_held_alloc(ptr %t186, i64 %t184)
  %t188 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t187, 1
  store { i64, ptr } %t189, ptr %l67, !tbaa !27
  store i64 0, ptr %l72, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb30
bb29:
  %t190 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t190, 0
  %t193 = icmp eq i64 %t191, 0
  br i1 %t193, label %bb36, label %bb37
bb30:
  %t195 = load i64, ptr %l9, !tbaa !24
  %t196 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t196, 0
  %t201 = icmp slt i64 %t195, %t198
  %t203 = xor i1 %t201, true
  br i1 %t203, label %bb31, label %bb32
bb31:
  br label %bb35
bb32:
  br label %bb33
bb33:
  %t205 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t205, ptr %l78, !tbaa !27
  %t206 = load i64, ptr %l9, !tbaa !24
  %t208 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr i64, ptr %t209, i64 %t206
  %t211 = load i64, ptr %t210, !tbaa !34
  %t213 = load i64, ptr %l72, !tbaa !24
  %t214 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = getelementptr i64, ptr %t215, i64 %t213
  store i64 %t211, ptr %t216, !tbaa !34
  %t217 = load i64, ptr %l72, !tbaa !24
  %t218 = add i64 %t217, 1
  store i64 %t218, ptr %l72, !tbaa !24
  br label %bb34
bb34:
  %t219 = load i64, ptr %l9, !tbaa !24
  %t222 = add i64 %t219, 1
  store i64 %t222, ptr %l9, !tbaa !24
  br label %bb30
bb35:
  br label %bb29
bb36:
  store { i64, ptr } zeroinitializer, ptr %l67, !tbaa !27
  br label %bb37
bb37:
  %t224 = load i64, ptr %l65
  %t225 = inttoptr i64 %t224 to ptr
  %t226 = load { i64, ptr }, ptr %l67
  %t227 = extractvalue { i64, ptr } %t226, 1
  %t228 = call ptr @__olang_region_or(ptr %t227, ptr null)
  %t229 = icmp ne ptr %t228, null
  %t230 = select i1 %t229, ptr %t228, ptr null
  call void @__olang_region_settle_in(ptr %t225, ptr %t230)
  %t231 = load ptr, ptr %l55, !tbaa !29
  %t232 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t231, i32 0, i32 1
  %t233 = load { i64, ptr }, ptr %t232, !tbaa !27
  store { i64, ptr } %t233, ptr %l86, !tbaa !27
  %t234 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t235 = load ptr, ptr %l55, !tbaa !29
  %t236 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t235, i32 0, i32 1
  store { i64, ptr } %t234, ptr %t236, !tbaa !27
  %t237 = load { i64, ptr }, ptr %l86
  %t238 = extractvalue { i64, ptr } %t237, 0
  %t239 = extractvalue { i64, ptr } %t237, 1
  call void @__olang_region_release_part(ptr %t239, i64 %t238)
  store { i64, ptr } zeroinitializer, ptr %l86
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_3aMapEntry_3cI64_2c_20compiler_2ftyped_3aContractInfo_3e_2ector(ptr %out, ptr %v0, ptr %v1, i64 %a0, ptr %a1) #0 {
entry:
  %l1 = alloca %"compiler/typed:ContractInfo"
  %l2 = alloca i64
  %l3 = alloca %"compiler/typed:ContractInfo"
  %l5 = alloca %"compiler/typed:ContractInfo"
  %l6 = alloca %"compiler/typed:ContractInfo"
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca %"std/prelude/map:MapEntry.30ce370d829aff239a34c06a62e67c2e"
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a1, i64 152, i1 false)
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a0, ptr %l2, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l5, ptr %l1, i64 152, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %l5, i64 152, i1 false)
  %t3 = getelementptr %"compiler/typed:ContractInfo", ptr %l6, i32 0, i32 2
  %t4 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t3, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  store { i64, ptr } %t5, ptr %l7, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l8, !tbaa !24
  %t8 = load i64, ptr %l8, !tbaa !24
  %t9 = mul i64 %t8, 8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l9, !tbaa !27
  %t13 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = load i64, ptr %l8, !tbaa !24
  %t18 = mul i64 %t17, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t14, ptr %t16, i64 %t18, i1 false)
  %t19 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t20 = getelementptr %"compiler/typed:ContractInfo", ptr %l6, i32 0, i32 2
  %t21 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t20, i32 0, i32 0
  store { i64, ptr } %t19, ptr %t21, !tbaa !27
  %t22 = call ptr @__olang_region_make_part(ptr %v1)
  %t23 = ptrtoint ptr %t22 to i64
  store i64 %t23, ptr %l10, !tbaa !24
  %t24 = getelementptr %"compiler/typed:ContractInfo", ptr %l6, i32 0, i32 3
  %t25 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t24, i32 0, i32 0
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  store { i64, ptr } %t26, ptr %l11, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t27, 0
  store i64 %t28, ptr %l12, !tbaa !24
  %t29 = load i64, ptr %l12, !tbaa !24
  %t30 = mul i64 %t29, 8
  %t31 = load i64, ptr %l10
  %t32 = inttoptr i64 %t31 to ptr
  %t33 = call ptr @__olang_held_alloc(ptr %t32, i64 %t30)
  %t34 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t33, 1
  store { i64, ptr } %t35, ptr %l13, !tbaa !27
  %t36 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = load i64, ptr %l12, !tbaa !24
  %t41 = mul i64 %t40, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t37, ptr %t39, i64 %t41, i1 false)
  %t42 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t43 = getelementptr %"compiler/typed:ContractInfo", ptr %l6, i32 0, i32 3
  %t44 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t43, i32 0, i32 0
  store { i64, ptr } %t42, ptr %t44, !tbaa !27
  %t45 = getelementptr %"compiler/typed:ContractInfo", ptr %l6, i32 0, i32 3
  %t46 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t45, i32 0, i32 0
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t47, 0
  %t50 = icmp eq i64 %t48, 0
  br i1 %t50, label %bb1, label %bb2
bb1:
  %t52 = getelementptr %"compiler/typed:ContractInfo", ptr %l6, i32 0, i32 3
  %t53 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t52, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t53, !tbaa !27
  br label %bb2
bb2:
  %t54 = getelementptr %"compiler/typed:ContractInfo", ptr %l6, i32 0, i32 3
  %t55 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t54, i32 0, i32 0
  %t56 = load i64, ptr %l10
  %t57 = inttoptr i64 %t56 to ptr
  %t58 = load { i64, ptr }, ptr %t55
  %t59 = extractvalue { i64, ptr } %t58, 1
  %t60 = call ptr @__olang_region_or(ptr %t59, ptr null)
  %t61 = icmp ne ptr %t60, null
  %t62 = select i1 %t61, ptr %t60, ptr null
  call void @__olang_region_settle_in(ptr %t57, ptr %t62)
  %t63 = getelementptr %"compiler/typed:ContractInfo", ptr %l6, i32 0, i32 4
  %t64 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t63, i32 0, i32 0
  %t65 = load { i64, ptr }, ptr %t64, !tbaa !27
  store { i64, ptr } %t65, ptr %l16, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 0
  store i64 %t67, ptr %l17, !tbaa !24
  %t68 = load i64, ptr %l17, !tbaa !24
  %t69 = mul i64 %t68, 16
  %t70 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t69)
  %t71 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  store { i64, ptr } %t72, ptr %l18, !tbaa !27
  %t73 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l17, !tbaa !24
  %t78 = mul i64 %t77, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t74, ptr %t76, i64 %t78, i1 false)
  %t79 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t80 = getelementptr %"compiler/typed:ContractInfo", ptr %l6, i32 0, i32 4
  %t81 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t80, i32 0, i32 0
  store { i64, ptr } %t79, ptr %t81, !tbaa !27
  %t82 = getelementptr %"compiler/typed:ContractInfo", ptr %l6, i32 0, i32 5
  %t83 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t82, i32 0, i32 0
  %t84 = load { i64, ptr }, ptr %t83, !tbaa !27
  store { i64, ptr } %t84, ptr %l19, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 0
  store i64 %t86, ptr %l20, !tbaa !24
  %t87 = load i64, ptr %l20, !tbaa !24
  %t88 = mul i64 %t87, 1
  %t89 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t88)
  %t90 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  store { i64, ptr } %t91, ptr %l21, !tbaa !27
  %t92 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = load i64, ptr %l20, !tbaa !24
  %t97 = mul i64 %t96, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t93, ptr %t95, i64 %t97, i1 false)
  %t98 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t99 = getelementptr %"compiler/typed:ContractInfo", ptr %l6, i32 0, i32 5
  %t100 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t99, i32 0, i32 0
  store { i64, ptr } %t98, ptr %t100, !tbaa !27
  call void @llvm.memmove.p0.p0.i64(ptr %l3, ptr %l6, i64 152, i1 false)
  %t101 = getelementptr %"std/prelude/map:MapEntry.30ce370d829aff239a34c06a62e67c2e", ptr %l22, i32 0, i32 0
  %t102 = load i64, ptr %l2, !tbaa !24
  store i64 %t102, ptr %t101, !tbaa !24
  %t103 = getelementptr %"std/prelude/map:MapEntry.30ce370d829aff239a34c06a62e67c2e", ptr %l22, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %t103, ptr %l3, i64 152, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l22, i64 160, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local { i32, i128 } @std_2fprelude_2ftext_2eT_2eParse_3cU128_3e(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca i128
  %l6 = alloca i64
  %l7 = alloca i128
  %l8 = alloca i128
  %l9 = alloca i128
  %l10 = alloca i128
  %l11 = alloca i128
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i8
  %l17 = alloca i64
  %l18 = alloca i128
  %l23 = alloca { i64, ptr }
  %l27 = alloca i1
  %l28 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i64
  %l41 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca i64
  %l51 = alloca i1
  %l55 = alloca i1
  %l57 = alloca i1
  %l58 = alloca i128
  %l60 = alloca i128
  %l61 = alloca i32
  %l74 = alloca i1
  %l78 = alloca i1
  %l80 = alloca i1
  %l83 = alloca i64
  %l86 = alloca i64
  %l87 = alloca i32
  %l92 = alloca i1
  %l102 = alloca i64
  %l108 = alloca i128
  %l124 = alloca { i64, ptr }
  %l129 = alloca i1
  %l135 = alloca i1
  %l136 = alloca { i64, ptr }
  %l141 = alloca i1
  %l149 = alloca i64
  %l160 = alloca i1
  %l164 = alloca i1
  %l179 = alloca i1
  %l183 = alloca i1
  %rv = alloca { i32, i128 }
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t8 = insertvalue { i32, i128 } zeroinitializer, i32 65536, 0
  store { i32, i128 } %t8, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t9, ptr %l23, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr i8, ptr %t11, i64 0
  %t13 = load i8, ptr %t12, !tbaa !32
  %t15 = icmp eq i8 %t13, 45
  store i1 %t15, ptr %l2, !tbaa !21
  %t17 = load i1, ptr %l2, !tbaa !21
  br i1 %t17, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb6
bb5:
  %t19 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t19, ptr %l28, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i8, ptr %t21, i64 0
  %t23 = load i8, ptr %t22, !tbaa !32
  %t25 = icmp eq i8 %t23, 43
  store i1 %t25, ptr %l27, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l27, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t28 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t28, ptr %l32, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t29, 0
  store i64 %t32, ptr %l35, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  store i64 %t34, ptr %l36, !tbaa !24
  %t35 = icmp sge i64 1, 0
  br i1 %t35, label %bb9, label %bb10
bb8:
  %t37 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t37, ptr %l41, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t38, 0
  store i64 %t41, ptr %l44, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 0
  store i64 %t43, ptr %l45, !tbaa !24
  %t44 = icmp sge i64 0, 0
  br i1 %t44, label %bb15, label %bb16
bb9:
  %t46 = load i64, ptr %l35, !tbaa !24
  %t47 = icmp sle i64 1, %t46
  br i1 %t47, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_e967a788eb8e93f4_ddbe108b1142e638)
  unreachable
bb11:
  %t49 = load i64, ptr %l35, !tbaa !24
  %t50 = load i64, ptr %l36, !tbaa !24
  %t51 = icmp sle i64 %t49, %t50
  br i1 %t51, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_e967a788eb8e93f4_ddbe108b1142e638)
  unreachable
bb13:
  %t53 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = load i64, ptr %l35, !tbaa !24
  %t56 = getelementptr i8, ptr %t54, i64 1
  %t57 = sub i64 %t55, 1
  %t58 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t56, 1
  store { i64, ptr } %t59, ptr %l31, !tbaa !27
  br label %bb21
bb14:
  call void @__olang_check_failed(ptr @olang_loc_e967a788eb8e93f4_ddbe108b1142e638)
  unreachable
bb15:
  %t61 = load i64, ptr %l44, !tbaa !24
  %t62 = icmp sle i64 0, %t61
  br i1 %t62, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_e967a788eb8e93f4_ddbe108b1142e638)
  unreachable
bb17:
  %t64 = load i64, ptr %l44, !tbaa !24
  %t65 = load i64, ptr %l45, !tbaa !24
  %t66 = icmp sle i64 %t64, %t65
  br i1 %t66, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_e967a788eb8e93f4_ddbe108b1142e638)
  unreachable
bb19:
  %t68 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = load i64, ptr %l44, !tbaa !24
  %t71 = getelementptr i8, ptr %t69, i64 0
  %t72 = sub i64 %t70, 0
  %t73 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t71, 1
  store { i64, ptr } %t74, ptr %l31, !tbaa !27
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_e967a788eb8e93f4_ddbe108b1142e638)
  unreachable
bb21:
  %t76 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t76, ptr %l3, !tbaa !27
  %t77 = icmp sgt i64 16, 8
  br i1 %t77, label %bb22, label %bb23
bb22:
  %t79 = load i64, ptr %l1, !tbaa !24
  %t82 = icmp eq i64 %t79, 0
  store i1 %t82, ptr %l51, !tbaa !21
  br label %bb24
bb23:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb24
bb24:
  %t84 = load i1, ptr %l51, !tbaa !21
  br i1 %t84, label %bb25, label %bb26
bb25:
  %t85 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t87 = call i1 @std_2fprelude_2ftext_2eisPrefixed(ptr %v0, { i64, ptr } %t85)
  store i1 %t87, ptr %l57
  br label %bb27
bb26:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb28
bb27:
  %t88 = load i1, ptr %l57, !tbaa !21
  store i1 %t88, ptr %l55, !tbaa !21
  br label %bb28
bb28:
  %t89 = load i1, ptr %l55, !tbaa !21
  br i1 %t89, label %bb29, label %bb30
bb29:
  %t90 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t92 = call { i32, i128 } @std_2fprelude_2ftext_2ereadWide(ptr %v0, { i64, ptr } %t90)
  %t93 = extractvalue { i32, i128 } %t92, 1
  %t94 = extractvalue { i32, i128 } %t92, 0
  store i32 %t94, ptr %l61
  %t95 = icmp ne i32 %t94, 0
  br i1 %t95, label %bb32, label %ok.96, !prof !99
ok.96:
  store i128 %t93, ptr %l60
  br label %bb31
bb30:
  br label %bb43
bb31:
  %t97 = load i128, ptr %l60
  store i128 %t97, ptr %l58
  br label %bb33
bb32:
  %t98 = load i32, ptr %l61, !tbaa !23
  %t99 = lshr i32 %t98, 16
  %t100 = and i32 %t98, 65535
  %t101 = icmp eq i32 %t99, 1
  %t102 = select i1 %t101, i32 1, i32 0
  %t103 = icmp eq i32 %t98, 0
  %t104 = shl i32 %t102, 16
  %t105 = or i32 %t104, %t100
  %t106 = select i1 %t103, i32 0, i32 %t105
  %t108 = insertvalue { i32, i128 } zeroinitializer, i32 %t106, 0
  store { i32, i128 } %t108, ptr %rv
  br label %ret
bb33:
  %t109 = load i128, ptr %l58
  store i128 %t109, ptr %l4
  %t110 = load i128, ptr %l4
  %t111 = zext i64 -1 to i128
  %t114 = icmp ugt i128 %t110, %t111
  br i1 %t114, label %bb34, label %bb35
bb34:
  %t116 = load i1, ptr %l2, !tbaa !21
  br i1 %t116, label %bb36, label %bb37
bb35:
  br label %bb42
bb36:
  %t119 = insertvalue { i32, i128 } zeroinitializer, i32 65537, 0
  store { i32, i128 } %t119, ptr %rv
  br label %ret
bb37:
  br label %bb38
bb38:
  %t120 = load i128, ptr %l4
  %t121 = xor i128 0, -1
  %t124 = icmp ugt i128 %t120, %t121
  br i1 %t124, label %bb39, label %bb40
bb39:
  %t127 = insertvalue { i32, i128 } zeroinitializer, i32 65538, 0
  store { i32, i128 } %t127, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  %t128 = load i128, ptr %l4
  %t130 = insertvalue { i32, i128 } zeroinitializer, i128 %t128, 1
  store { i32, i128 } %t130, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  %t131 = icmp sle i64 16, 8
  br i1 %t131, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l74, !tbaa !21
  br label %bb50
bb45:
  %t133 = load i64, ptr %l1, !tbaa !24
  %t136 = icmp eq i64 %t133, 0
  br i1 %t136, label %bb46, label %bb47
bb46:
  %t138 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t140 = call i1 @std_2fprelude_2ftext_2eisPrefixed(ptr %v0, { i64, ptr } %t138)
  store i1 %t140, ptr %l80
  br label %bb48
bb47:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb49
bb48:
  %t141 = load i1, ptr %l80, !tbaa !21
  store i1 %t141, ptr %l78, !tbaa !21
  br label %bb49
bb49:
  %t142 = load i1, ptr %l78, !tbaa !21
  store i1 %t142, ptr %l74, !tbaa !21
  br label %bb50
bb50:
  %t143 = load i1, ptr %l74, !tbaa !21
  br i1 %t143, label %bb51, label %bb52
bb51:
  %t144 = load i1, ptr %l2, !tbaa !21
  br i1 %t144, label %bb53, label %bb54
bb52:
  br label %bb59
bb53:
  %t147 = insertvalue { i32, i128 } zeroinitializer, i32 65537, 0
  store { i32, i128 } %t147, ptr %rv
  br label %ret
bb54:
  br label %bb55
bb55:
  %t148 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t149 = load i64, ptr %l1, !tbaa !24
  %t152 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseUint(ptr %v0, { i64, ptr } %t148, i64 %t149)
  %t153 = extractvalue { i32, i64 } %t152, 1
  %t154 = extractvalue { i32, i64 } %t152, 0
  store i32 %t154, ptr %l87
  %t155 = icmp ne i32 %t154, 0
  br i1 %t155, label %bb57, label %ok.156, !prof !99
ok.156:
  store i64 %t153, ptr %l86
  br label %bb56
bb56:
  %t157 = load i64, ptr %l86, !tbaa !65
  store i64 %t157, ptr %l83, !tbaa !65
  br label %bb58
bb57:
  %t158 = load i32, ptr %l87, !tbaa !23
  %t159 = lshr i32 %t158, 16
  %t160 = and i32 %t158, 65535
  %t161 = icmp eq i32 %t159, 1
  %t162 = select i1 %t161, i32 1, i32 0
  %t163 = icmp eq i32 %t158, 0
  %t164 = shl i32 %t162, 16
  %t165 = or i32 %t164, %t160
  %t166 = select i1 %t163, i32 0, i32 %t165
  %t168 = insertvalue { i32, i128 } zeroinitializer, i32 %t166, 0
  store { i32, i128 } %t168, ptr %rv
  br label %ret
bb58:
  %t169 = load i64, ptr %l83, !tbaa !65
  %t172 = zext i64 %t169 to i128
  %t174 = insertvalue { i32, i128 } zeroinitializer, i128 %t172, 1
  store { i32, i128 } %t174, ptr %rv
  br label %ret
bb59:
  %t175 = load i1, ptr %l2, !tbaa !21
  br i1 %t175, label %bb60, label %bb61
bb60:
  %t177 = icmp eq i128 0, 0
  store i1 %t177, ptr %l92, !tbaa !21
  br label %bb62
bb61:
  store i1 false, ptr %l92, !tbaa !21
  br label %bb62
bb62:
  %t179 = load i1, ptr %l92, !tbaa !21
  br i1 %t179, label %bb63, label %bb64
bb63:
  %t181 = insertvalue { i32, i128 } zeroinitializer, i32 65537, 0
  store { i32, i128 } %t181, ptr %rv
  br label %ret
bb64:
  br label %bb65
bb65:
  %t182 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t184 = extractvalue { i64, ptr } %t182, 0
  %t186 = icmp eq i64 %t184, 0
  br i1 %t186, label %bb66, label %bb67
bb66:
  %t189 = insertvalue { i32, i128 } zeroinitializer, i32 65537, 0
  store { i32, i128 } %t189, ptr %rv
  br label %ret
bb67:
  br label %bb68
bb68:
  %t190 = load i64, ptr %l1, !tbaa !24
  %t193 = icmp eq i64 %t190, 0
  br i1 %t193, label %bb69, label %bb70
bb69:
  store i64 10, ptr %l102, !tbaa !24
  br label %bb71
bb70:
  %t195 = load i64, ptr %l1, !tbaa !24
  store i64 %t195, ptr %l102, !tbaa !24
  br label %bb71
bb71:
  %t198 = load i64, ptr %l102, !tbaa !24
  store i64 %t198, ptr %l6, !tbaa !24
  %t199 = load i64, ptr %l6, !tbaa !24
  %t201 = sext i64 %t199 to i128
  store i128 %t201, ptr %l7
  %t203 = load i1, ptr %l2, !tbaa !21
  br i1 %t203, label %bb72, label %bb73
bb72:
  store i128 0, ptr %l108
  br label %bb74
bb73:
  %t205 = xor i128 0, -1
  store i128 %t205, ptr %l108
  br label %bb74
bb74:
  %t207 = load i128, ptr %l108
  store i128 %t207, ptr %l8
  %t208 = load i128, ptr %l8
  %t209 = load i128, ptr %l7
  %t212 = udiv i128 %t208, %t209
  store i128 %t212, ptr %l9
  %t214 = load i128, ptr %l8
  %t215 = load i128, ptr %l7
  %t218 = urem i128 %t214, %t215
  store i128 %t218, ptr %l10
  store i128 0, ptr %l11
  %t220 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t220, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t222 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t224 = extractvalue { i64, ptr } %t222, 0
  store i64 %t224, ptr %l14, !tbaa !24
  br label %bb75
bb75:
  %t226 = load i64, ptr %l13, !tbaa !24
  %t227 = load i64, ptr %l14, !tbaa !24
  %t230 = icmp slt i64 %t226, %t227
  %t232 = xor i1 %t230, true
  br i1 %t232, label %bb76, label %bb77
bb76:
  br label %bb120
bb77:
  br label %bb78
bb78:
  %t234 = load i64, ptr %l13, !tbaa !24
  store i64 %t234, ptr %l15, !tbaa !24
  %t236 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t236, ptr %l124, !tbaa !27
  %t237 = load i64, ptr %l13, !tbaa !24
  %t239 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t240 = load ptr, ptr %t239, !tbaa !27
  %t241 = getelementptr i8, ptr %t240, i64 %t237
  %t242 = load i8, ptr %t241, !tbaa !32
  store i8 %t242, ptr %l16, !tbaa !22
  %t244 = load i8, ptr %l16, !tbaa !22
  %t246 = icmp eq i8 %t244, 95
  br i1 %t246, label %bb79, label %bb80
bb79:
  %t248 = load i64, ptr %l1, !tbaa !24
  %t251 = icmp eq i64 %t248, 0
  store i1 %t251, ptr %l129, !tbaa !21
  br label %bb81
bb80:
  store i1 false, ptr %l129, !tbaa !21
  br label %bb81
bb81:
  %t253 = load i1, ptr %l129, !tbaa !21
  br i1 %t253, label %bb82, label %bb83
bb82:
  %t254 = load i64, ptr %l15, !tbaa !24
  %t256 = icmp eq i64 %t254, 0
  br i1 %t256, label %bb84, label %bb85
bb83:
  br label %bb93
bb84:
  store i1 true, ptr %l135, !tbaa !21
  br label %bb86
bb85:
  %t258 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t258, ptr %l136, !tbaa !27
  %t259 = load i64, ptr %l15, !tbaa !24
  %t261 = sub i64 %t259, 1
  %t263 = getelementptr { i64, ptr }, ptr %l136, i32 0, i32 1
  %t264 = load ptr, ptr %t263, !tbaa !27
  %t265 = getelementptr i8, ptr %t264, i64 %t261
  %t266 = load i8, ptr %t265, !tbaa !32
  %t268 = icmp eq i8 %t266, 95
  store i1 %t268, ptr %l135, !tbaa !21
  br label %bb86
bb86:
  %t270 = load i1, ptr %l135, !tbaa !21
  br i1 %t270, label %bb87, label %bb88
bb87:
  store i1 true, ptr %l141, !tbaa !21
  br label %bb89
bb88:
  %t271 = load i64, ptr %l15, !tbaa !24
  %t273 = add i64 %t271, 1
  %t274 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t276 = extractvalue { i64, ptr } %t274, 0
  %t279 = icmp eq i64 %t273, %t276
  store i1 %t279, ptr %l141, !tbaa !21
  br label %bb89
bb89:
  %t281 = load i1, ptr %l141, !tbaa !21
  br i1 %t281, label %bb90, label %bb91
bb90:
  %t283 = insertvalue { i32, i128 } zeroinitializer, i32 65537, 0
  store { i32, i128 } %t283, ptr %rv
  br label %ret
bb91:
  br label %bb92
bb92:
  br label %bb119
bb93:
  %t284 = load i8, ptr %l16, !tbaa !22
  %t286 = call i64 @std_2fprelude_2ftext_2edigitWorth(i8 %t284)
  store i64 %t286, ptr %l149
  br label %bb94
bb94:
  %t287 = load i64, ptr %l149, !tbaa !24
  store i64 %t287, ptr %l17, !tbaa !24
  %t288 = load i64, ptr %l17, !tbaa !24
  %t289 = load i64, ptr %l6, !tbaa !24
  %t292 = icmp sge i64 %t288, %t289
  br i1 %t292, label %bb95, label %bb96
bb95:
  %t295 = insertvalue { i32, i128 } zeroinitializer, i32 65537, 0
  store { i32, i128 } %t295, ptr %rv
  br label %ret
bb96:
  br label %bb97
bb97:
  %t296 = load i64, ptr %l17, !tbaa !24
  %t298 = sext i64 %t296 to i128
  store i128 %t298, ptr %l18
  %t300 = load i1, ptr %l2, !tbaa !21
  br i1 %t300, label %bb98, label %bb99
bb98:
  %t302 = load i128, ptr %l11
  %t303 = load i128, ptr %l9
  %t306 = icmp ult i128 %t302, %t303
  br i1 %t306, label %bb100, label %bb101
bb99:
  %t308 = load i128, ptr %l11
  %t309 = load i128, ptr %l9
  %t312 = icmp ugt i128 %t308, %t309
  br i1 %t312, label %bb109, label %bb110
bb100:
  store i1 true, ptr %l160, !tbaa !21
  br label %bb105
bb101:
  %t314 = load i128, ptr %l11
  %t315 = load i128, ptr %l9
  %t318 = icmp eq i128 %t314, %t315
  br i1 %t318, label %bb102, label %bb103
bb102:
  %t320 = load i128, ptr %l18
  %t322 = sub i128 0, %t320
  %t323 = load i128, ptr %l10
  %t326 = icmp ult i128 %t322, %t323
  store i1 %t326, ptr %l164, !tbaa !21
  br label %bb104
bb103:
  store i1 false, ptr %l164, !tbaa !21
  br label %bb104
bb104:
  %t328 = load i1, ptr %l164, !tbaa !21
  store i1 %t328, ptr %l160, !tbaa !21
  br label %bb105
bb105:
  %t329 = load i1, ptr %l160, !tbaa !21
  br i1 %t329, label %bb106, label %bb107
bb106:
  %t331 = insertvalue { i32, i128 } zeroinitializer, i32 65538, 0
  store { i32, i128 } %t331, ptr %rv
  br label %ret
bb107:
  br label %bb108
bb108:
  %t332 = load i128, ptr %l11
  %t334 = load i128, ptr %l7
  %t337 = mul i128 %t332, %t334
  %t338 = load i128, ptr %l18
  %t341 = sub i128 %t337, %t338
  store i128 %t341, ptr %l11
  br label %bb118
bb109:
  store i1 true, ptr %l179, !tbaa !21
  br label %bb114
bb110:
  %t343 = load i128, ptr %l11
  %t344 = load i128, ptr %l9
  %t347 = icmp eq i128 %t343, %t344
  br i1 %t347, label %bb111, label %bb112
bb111:
  %t349 = load i128, ptr %l18
  %t350 = load i128, ptr %l10
  %t353 = icmp ugt i128 %t349, %t350
  store i1 %t353, ptr %l183, !tbaa !21
  br label %bb113
bb112:
  store i1 false, ptr %l183, !tbaa !21
  br label %bb113
bb113:
  %t355 = load i1, ptr %l183, !tbaa !21
  store i1 %t355, ptr %l179, !tbaa !21
  br label %bb114
bb114:
  %t356 = load i1, ptr %l179, !tbaa !21
  br i1 %t356, label %bb115, label %bb116
bb115:
  %t358 = insertvalue { i32, i128 } zeroinitializer, i32 65538, 0
  store { i32, i128 } %t358, ptr %rv
  br label %ret
bb116:
  br label %bb117
bb117:
  %t359 = load i128, ptr %l11
  %t361 = load i128, ptr %l7
  %t364 = mul i128 %t359, %t361
  %t365 = load i128, ptr %l18
  %t368 = add i128 %t364, %t365
  store i128 %t368, ptr %l11
  br label %bb118
bb118:
  br label %bb119
bb119:
  %t370 = load i64, ptr %l13, !tbaa !24
  %t373 = add i64 %t370, 1
  store i64 %t373, ptr %l13, !tbaa !24
  br label %bb75
bb120:
  %t375 = load i128, ptr %l11
  %t377 = insertvalue { i32, i128 } zeroinitializer, i128 %t375, 1
  store { i32, i128 } %t377, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i128 }, ptr %rv
  ret { i32, i128 } %rr
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAssertAsk_3e_2eroom_He41e0ed9c9860528220f26e5328cd366(ptr %v0, ptr %a0, i64 %a1) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l43 = alloca i64
  %l44 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l49 = alloca i64
  %l55 = alloca { i64, ptr }
  %l57 = alloca %"compiler/check:AssertAsk"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l3, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  %t59 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t59, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_889cedfb4be9c88_a847bb62cb5e3d5c)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_889cedfb4be9c88_a847bb62cb5e3d5c)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr %"compiler/check:AssertAsk", ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  store i64 %t83, ptr %l43, !tbaa !24
  %t86 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t88 = load i64, ptr %l43, !tbaa !24
  %t89 = extractvalue { i64, ptr } %t86, 0
  %t90 = mul i64 %t89, 184
  %t91 = mul i64 %t88, 184
  %t92 = extractvalue { i64, ptr } %t86, 1
  %t93 = call ptr @__olang_grow_in_place(ptr %t92, i64 %t90, i64 %t91, i64 %t88)
  %t94 = icmp ne ptr %t93, null
  %t95 = select i1 %t94, i64 %t88, i64 0
  %t96 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t93, 1
  store { i64, ptr } %t97, ptr %l46, !tbaa !27
  %t98 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t98, 0
  %t101 = icmp ne i64 %t99, 0
  br i1 %t101, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_889cedfb4be9c88_a847bb62cb5e3d5c)
  unreachable
bb19:
  %t103 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t103, ptr %l44, !tbaa !27
  br label %bb21
bb20:
  %t104 = load i64, ptr %l43, !tbaa !24
  %t105 = mul i64 %t104, 184
  %t106 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t105)
  %t107 = insertvalue { i64, ptr } undef, i64 %t104, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t106, 1
  store { i64, ptr } %t108, ptr %l44, !tbaa !27
  store i64 0, ptr %l49, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb22
bb21:
  %t109 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t110 = load ptr, ptr %l33, !tbaa !29
  %t111 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t110, i32 0, i32 0
  store { i64, ptr } %t109, ptr %t111, !tbaa !27
  %t112 = load { i64, ptr }, ptr %l3, !tbaa !27
  br label %ret
bb22:
  %t114 = load i64, ptr %l6, !tbaa !24
  %t115 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t115, 0
  %t120 = icmp slt i64 %t114, %t117
  %t122 = xor i1 %t120, true
  br i1 %t122, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t124 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t124, ptr %l55, !tbaa !27
  %t125 = load i64, ptr %l6, !tbaa !24
  %t127 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !27
  %t129 = getelementptr %"compiler/check:AssertAsk", ptr %t128, i64 %t125
  call void @llvm.memmove.p0.p0.i64(ptr %l57, ptr %t129, i64 184, i1 false)
  %t130 = load i64, ptr %l49, !tbaa !24
  %t131 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr %"compiler/check:AssertAsk", ptr %t132, i64 %t130
  call void @llvm.memmove.p0.p0.i64(ptr %t133, ptr %l57, i64 184, i1 false)
  %t134 = load i64, ptr %l49, !tbaa !24
  %t135 = add i64 %t134, 1
  store i64 %t135, ptr %l49, !tbaa !24
  br label %bb26
bb26:
  %t136 = load i64, ptr %l6, !tbaa !24
  %t139 = add i64 %t136, 1
  store i64 %t139, ptr %l6, !tbaa !24
  br label %bb22
bb27:
  br label %bb21
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aContractAsk_3e_2ero_Hfcaa2411078999d8b82264738ecb7667(ptr %v0, ptr %a0, i64 %a1) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l43 = alloca i64
  %l44 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l49 = alloca i64
  %l55 = alloca { i64, ptr }
  %l57 = alloca %"compiler/check:ContractAsk"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l3, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  %t59 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t59, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_2fcf5e58d82fe6ea_e31cfa2171027a4e)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_2fcf5e58d82fe6ea_e31cfa2171027a4e)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr %"compiler/check:ContractAsk", ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  store i64 %t83, ptr %l43, !tbaa !24
  %t86 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t88 = load i64, ptr %l43, !tbaa !24
  %t89 = extractvalue { i64, ptr } %t86, 0
  %t90 = mul i64 %t89, 160
  %t91 = mul i64 %t88, 160
  %t92 = extractvalue { i64, ptr } %t86, 1
  %t93 = call ptr @__olang_grow_in_place(ptr %t92, i64 %t90, i64 %t91, i64 %t88)
  %t94 = icmp ne ptr %t93, null
  %t95 = select i1 %t94, i64 %t88, i64 0
  %t96 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t93, 1
  store { i64, ptr } %t97, ptr %l46, !tbaa !27
  %t98 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t98, 0
  %t101 = icmp ne i64 %t99, 0
  br i1 %t101, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_2fcf5e58d82fe6ea_e31cfa2171027a4e)
  unreachable
bb19:
  %t103 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t103, ptr %l44, !tbaa !27
  br label %bb21
bb20:
  %t104 = load i64, ptr %l43, !tbaa !24
  %t105 = mul i64 %t104, 160
  %t106 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t105)
  %t107 = insertvalue { i64, ptr } undef, i64 %t104, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t106, 1
  store { i64, ptr } %t108, ptr %l44, !tbaa !27
  store i64 0, ptr %l49, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb22
bb21:
  %t109 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t110 = load ptr, ptr %l33, !tbaa !29
  %t111 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t110, i32 0, i32 0
  store { i64, ptr } %t109, ptr %t111, !tbaa !27
  %t112 = load { i64, ptr }, ptr %l3, !tbaa !27
  br label %ret
bb22:
  %t114 = load i64, ptr %l6, !tbaa !24
  %t115 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t115, 0
  %t120 = icmp slt i64 %t114, %t117
  %t122 = xor i1 %t120, true
  br i1 %t122, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t124 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t124, ptr %l55, !tbaa !27
  %t125 = load i64, ptr %l6, !tbaa !24
  %t127 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !27
  %t129 = getelementptr %"compiler/check:ContractAsk", ptr %t128, i64 %t125
  call void @llvm.memmove.p0.p0.i64(ptr %l57, ptr %t129, i64 160, i1 false)
  %t130 = load i64, ptr %l49, !tbaa !24
  %t131 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr %"compiler/check:ContractAsk", ptr %t132, i64 %t130
  call void @llvm.memmove.p0.p0.i64(ptr %t133, ptr %l57, i64 160, i1 false)
  %t134 = load i64, ptr %l49, !tbaa !24
  %t135 = add i64 %t134, 1
  store i64 %t135, ptr %l49, !tbaa !24
  br label %bb26
bb26:
  %t136 = load i64, ptr %l6, !tbaa !24
  %t139 = add i64 %t136, 1
  store i64 %t139, ptr %l6, !tbaa !24
  br label %bb22
bb27:
  br label %bb21
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aEmbedAsk_3e_2eroom_3ccompiler_2fcheck_3aEmbedAsk_3e(ptr %v0, ptr %a0, i64 %a1) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l50 = alloca i64
  %l56 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  store { i64, ptr } %t56, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_e9a8d74df752042e_6474c49741244292)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_e9a8d74df752042e_6474c49741244292)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr %"compiler/check:EmbedAsk", ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t85 = call ptr @__olang_region_make_part(ptr %v0)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l43, !tbaa !24
  store i64 %t83, ptr %l44, !tbaa !24
  %t88 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t90 = load i64, ptr %l44, !tbaa !24
  %t91 = extractvalue { i64, ptr } %t88, 0
  %t92 = mul i64 %t91, 24
  %t93 = mul i64 %t90, 24
  %t94 = extractvalue { i64, ptr } %t88, 1
  %t95 = call ptr @__olang_grow_in_place(ptr %t94, i64 %t92, i64 %t93, i64 %t90)
  %t96 = icmp ne ptr %t95, null
  %t97 = select i1 %t96, i64 %t90, i64 0
  %t98 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t95, 1
  store { i64, ptr } %t99, ptr %l47, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  %t103 = icmp ne i64 %t101, 0
  br i1 %t103, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_e9a8d74df752042e_6474c49741244292)
  unreachable
bb19:
  %t105 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t105, ptr %l45, !tbaa !27
  br label %bb21
bb20:
  %t106 = load i64, ptr %l44, !tbaa !24
  %t107 = mul i64 %t106, 24
  %t108 = load i64, ptr %l43
  %t109 = inttoptr i64 %t108 to ptr
  %t110 = call ptr @__olang_held_alloc(ptr %t109, i64 %t107)
  %t111 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l45, !tbaa !27
  store i64 0, ptr %l50, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb22
bb21:
  %t113 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  %t116 = icmp eq i64 %t114, 0
  br i1 %t116, label %bb28, label %bb29
bb22:
  %t118 = load i64, ptr %l6, !tbaa !24
  %t119 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t124 = icmp slt i64 %t118, %t121
  %t126 = xor i1 %t124, true
  br i1 %t126, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t128 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t128, ptr %l56, !tbaa !27
  %t129 = load i64, ptr %l6, !tbaa !24
  %t131 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr %"compiler/check:EmbedAsk", ptr %t132, i64 %t129
  %t134 = load %"compiler/check:EmbedAsk", ptr %t133
  %t136 = load i64, ptr %l50, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr %"compiler/check:EmbedAsk", ptr %t138, i64 %t136
  store %"compiler/check:EmbedAsk" %t134, ptr %t139
  %t140 = load i64, ptr %l50, !tbaa !24
  %t141 = add i64 %t140, 1
  store i64 %t141, ptr %l50, !tbaa !24
  br label %bb26
bb26:
  %t142 = load i64, ptr %l6, !tbaa !24
  %t145 = add i64 %t142, 1
  store i64 %t145, ptr %l6, !tbaa !24
  br label %bb22
bb27:
  br label %bb21
bb28:
  store { i64, ptr } zeroinitializer, ptr %l45, !tbaa !27
  br label %bb29
bb29:
  %t147 = load i64, ptr %l43
  %t148 = inttoptr i64 %t147 to ptr
  %t149 = load { i64, ptr }, ptr %l45
  %t150 = extractvalue { i64, ptr } %t149, 1
  %t151 = call ptr @__olang_region_or(ptr %t150, ptr null)
  %t152 = icmp ne ptr %t151, null
  %t153 = select i1 %t152, ptr %t151, ptr null
  call void @__olang_region_settle_in(ptr %t148, ptr %t153)
  %t154 = load ptr, ptr %l33, !tbaa !29
  %t155 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t154, i32 0, i32 0
  %t156 = load { i64, ptr }, ptr %t155, !tbaa !27
  store { i64, ptr } %t156, ptr %l64, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t158 = load ptr, ptr %l33, !tbaa !29
  %t159 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t158, i32 0, i32 0
  store { i64, ptr } %t157, ptr %t159, !tbaa !27
  %t160 = load { i64, ptr }, ptr %l64
  %t161 = extractvalue { i64, ptr } %t160, 0
  %t162 = extractvalue { i64, ptr } %t160, 1
  call void @__olang_region_release_part(ptr %t162, i64 %t161)
  store { i64, ptr } zeroinitializer, ptr %l64
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2eroom_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %a0, i64 %a1) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l50 = alloca i64
  %l56 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  store { i64, ptr } %t56, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_7273437a056ceb0e_13b0f87213b64be2)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_7273437a056ceb0e_13b0f87213b64be2)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr %"compiler/check:Gap", ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t85 = call ptr @__olang_region_make_part(ptr %v0)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l43, !tbaa !24
  store i64 %t83, ptr %l44, !tbaa !24
  %t88 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t90 = load i64, ptr %l44, !tbaa !24
  %t91 = extractvalue { i64, ptr } %t88, 0
  %t92 = mul i64 %t91, 32
  %t93 = mul i64 %t90, 32
  %t94 = extractvalue { i64, ptr } %t88, 1
  %t95 = call ptr @__olang_grow_in_place(ptr %t94, i64 %t92, i64 %t93, i64 %t90)
  %t96 = icmp ne ptr %t95, null
  %t97 = select i1 %t96, i64 %t90, i64 0
  %t98 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t95, 1
  store { i64, ptr } %t99, ptr %l47, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  %t103 = icmp ne i64 %t101, 0
  br i1 %t103, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_7273437a056ceb0e_13b0f87213b64be2)
  unreachable
bb19:
  %t105 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t105, ptr %l45, !tbaa !27
  br label %bb21
bb20:
  %t106 = load i64, ptr %l44, !tbaa !24
  %t107 = mul i64 %t106, 32
  %t108 = load i64, ptr %l43
  %t109 = inttoptr i64 %t108 to ptr
  %t110 = call ptr @__olang_held_alloc(ptr %t109, i64 %t107)
  %t111 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l45, !tbaa !27
  store i64 0, ptr %l50, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb22
bb21:
  %t113 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  %t116 = icmp eq i64 %t114, 0
  br i1 %t116, label %bb28, label %bb29
bb22:
  %t118 = load i64, ptr %l6, !tbaa !24
  %t119 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t124 = icmp slt i64 %t118, %t121
  %t126 = xor i1 %t124, true
  br i1 %t126, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t128 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t128, ptr %l56, !tbaa !27
  %t129 = load i64, ptr %l6, !tbaa !24
  %t131 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr %"compiler/check:Gap", ptr %t132, i64 %t129
  %t134 = load %"compiler/check:Gap", ptr %t133
  %t136 = load i64, ptr %l50, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr %"compiler/check:Gap", ptr %t138, i64 %t136
  store %"compiler/check:Gap" %t134, ptr %t139
  %t140 = load i64, ptr %l50, !tbaa !24
  %t141 = add i64 %t140, 1
  store i64 %t141, ptr %l50, !tbaa !24
  br label %bb26
bb26:
  %t142 = load i64, ptr %l6, !tbaa !24
  %t145 = add i64 %t142, 1
  store i64 %t145, ptr %l6, !tbaa !24
  br label %bb22
bb27:
  br label %bb21
bb28:
  store { i64, ptr } zeroinitializer, ptr %l45, !tbaa !27
  br label %bb29
bb29:
  %t147 = load i64, ptr %l43
  %t148 = inttoptr i64 %t147 to ptr
  %t149 = load { i64, ptr }, ptr %l45
  %t150 = extractvalue { i64, ptr } %t149, 1
  %t151 = call ptr @__olang_region_or(ptr %t150, ptr null)
  %t152 = icmp ne ptr %t151, null
  %t153 = select i1 %t152, ptr %t151, ptr null
  call void @__olang_region_settle_in(ptr %t148, ptr %t153)
  %t154 = load ptr, ptr %l33, !tbaa !29
  %t155 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t154, i32 0, i32 0
  %t156 = load { i64, ptr }, ptr %t155, !tbaa !27
  store { i64, ptr } %t156, ptr %l64, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t158 = load ptr, ptr %l33, !tbaa !29
  %t159 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t158, i32 0, i32 0
  store { i64, ptr } %t157, ptr %t159, !tbaa !27
  %t160 = load { i64, ptr }, ptr %l64
  %t161 = extractvalue { i64, ptr } %t160, 0
  %t162 = extractvalue { i64, ptr } %t160, 1
  call void @__olang_region_release_part(ptr %t162, i64 %t161)
  store { i64, ptr } zeroinitializer, ptr %l64
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aTopAssertAsk_3e_2er_H7ac9f96ca0d0a63cd6d3c17ad26719ca(ptr %v0, ptr %a0, i64 %a1) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l50 = alloca i64
  %l56 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  store { i64, ptr } %t56, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_196964b7e2e57a83_b433a9b2ae4a185f)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_196964b7e2e57a83_b433a9b2ae4a185f)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr %"compiler/check:TopAssertAsk", ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t85 = call ptr @__olang_region_make_part(ptr %v0)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l43, !tbaa !24
  store i64 %t83, ptr %l44, !tbaa !24
  %t88 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t90 = load i64, ptr %l44, !tbaa !24
  %t91 = extractvalue { i64, ptr } %t88, 0
  %t92 = mul i64 %t91, 40
  %t93 = mul i64 %t90, 40
  %t94 = extractvalue { i64, ptr } %t88, 1
  %t95 = call ptr @__olang_grow_in_place(ptr %t94, i64 %t92, i64 %t93, i64 %t90)
  %t96 = icmp ne ptr %t95, null
  %t97 = select i1 %t96, i64 %t90, i64 0
  %t98 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t95, 1
  store { i64, ptr } %t99, ptr %l47, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  %t103 = icmp ne i64 %t101, 0
  br i1 %t103, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_196964b7e2e57a83_b433a9b2ae4a185f)
  unreachable
bb19:
  %t105 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t105, ptr %l45, !tbaa !27
  br label %bb21
bb20:
  %t106 = load i64, ptr %l44, !tbaa !24
  %t107 = mul i64 %t106, 40
  %t108 = load i64, ptr %l43
  %t109 = inttoptr i64 %t108 to ptr
  %t110 = call ptr @__olang_held_alloc(ptr %t109, i64 %t107)
  %t111 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l45, !tbaa !27
  store i64 0, ptr %l50, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb22
bb21:
  %t113 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  %t116 = icmp eq i64 %t114, 0
  br i1 %t116, label %bb28, label %bb29
bb22:
  %t118 = load i64, ptr %l6, !tbaa !24
  %t119 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t124 = icmp slt i64 %t118, %t121
  %t126 = xor i1 %t124, true
  br i1 %t126, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t128 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t128, ptr %l56, !tbaa !27
  %t129 = load i64, ptr %l6, !tbaa !24
  %t131 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr %"compiler/check:TopAssertAsk", ptr %t132, i64 %t129
  %t134 = load %"compiler/check:TopAssertAsk", ptr %t133
  %t136 = load i64, ptr %l50, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr %"compiler/check:TopAssertAsk", ptr %t138, i64 %t136
  store %"compiler/check:TopAssertAsk" %t134, ptr %t139
  %t140 = load i64, ptr %l50, !tbaa !24
  %t141 = add i64 %t140, 1
  store i64 %t141, ptr %l50, !tbaa !24
  br label %bb26
bb26:
  %t142 = load i64, ptr %l6, !tbaa !24
  %t145 = add i64 %t142, 1
  store i64 %t145, ptr %l6, !tbaa !24
  br label %bb22
bb27:
  br label %bb21
bb28:
  store { i64, ptr } zeroinitializer, ptr %l45, !tbaa !27
  br label %bb29
bb29:
  %t147 = load i64, ptr %l43
  %t148 = inttoptr i64 %t147 to ptr
  %t149 = load { i64, ptr }, ptr %l45
  %t150 = extractvalue { i64, ptr } %t149, 1
  %t151 = call ptr @__olang_region_or(ptr %t150, ptr null)
  %t152 = icmp ne ptr %t151, null
  %t153 = select i1 %t152, ptr %t151, ptr null
  call void @__olang_region_settle_in(ptr %t148, ptr %t153)
  %t154 = load ptr, ptr %l33, !tbaa !29
  %t155 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t154, i32 0, i32 0
  %t156 = load { i64, ptr }, ptr %t155, !tbaa !27
  store { i64, ptr } %t156, ptr %l64, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t158 = load ptr, ptr %l33, !tbaa !29
  %t159 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t158, i32 0, i32 0
  store { i64, ptr } %t157, ptr %t159, !tbaa !27
  %t160 = load { i64, ptr }, ptr %l64
  %t161 = extractvalue { i64, ptr } %t160, 0
  %t162 = extractvalue { i64, ptr } %t160, 1
  call void @__olang_region_release_part(ptr %t162, i64 %t161)
  store { i64, ptr } zeroinitializer, ptr %l64
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aUnrollAsk_3e_2eroom_H9f350f849f285c00cd5b4b2cfea93ec5(ptr %v0, ptr %a0, i64 %a1) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l50 = alloca i64
  %l56 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  store { i64, ptr } %t56, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_225353c50a4292f7_c45573717a3acb3b)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_225353c50a4292f7_c45573717a3acb3b)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr %"compiler/check:UnrollAsk", ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t85 = call ptr @__olang_region_make_part(ptr %v0)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l43, !tbaa !24
  store i64 %t83, ptr %l44, !tbaa !24
  %t88 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t90 = load i64, ptr %l44, !tbaa !24
  %t91 = extractvalue { i64, ptr } %t88, 0
  %t92 = mul i64 %t91, 48
  %t93 = mul i64 %t90, 48
  %t94 = extractvalue { i64, ptr } %t88, 1
  %t95 = call ptr @__olang_grow_in_place(ptr %t94, i64 %t92, i64 %t93, i64 %t90)
  %t96 = icmp ne ptr %t95, null
  %t97 = select i1 %t96, i64 %t90, i64 0
  %t98 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t95, 1
  store { i64, ptr } %t99, ptr %l47, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  %t103 = icmp ne i64 %t101, 0
  br i1 %t103, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_225353c50a4292f7_c45573717a3acb3b)
  unreachable
bb19:
  %t105 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t105, ptr %l45, !tbaa !27
  br label %bb21
bb20:
  %t106 = load i64, ptr %l44, !tbaa !24
  %t107 = mul i64 %t106, 48
  %t108 = load i64, ptr %l43
  %t109 = inttoptr i64 %t108 to ptr
  %t110 = call ptr @__olang_held_alloc(ptr %t109, i64 %t107)
  %t111 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l45, !tbaa !27
  store i64 0, ptr %l50, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb22
bb21:
  %t113 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  %t116 = icmp eq i64 %t114, 0
  br i1 %t116, label %bb28, label %bb29
bb22:
  %t118 = load i64, ptr %l6, !tbaa !24
  %t119 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t124 = icmp slt i64 %t118, %t121
  %t126 = xor i1 %t124, true
  br i1 %t126, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t128 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t128, ptr %l56, !tbaa !27
  %t129 = load i64, ptr %l6, !tbaa !24
  %t131 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr %"compiler/check:UnrollAsk", ptr %t132, i64 %t129
  %t134 = load %"compiler/check:UnrollAsk", ptr %t133
  %t136 = load i64, ptr %l50, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr %"compiler/check:UnrollAsk", ptr %t138, i64 %t136
  store %"compiler/check:UnrollAsk" %t134, ptr %t139
  %t140 = load i64, ptr %l50, !tbaa !24
  %t141 = add i64 %t140, 1
  store i64 %t141, ptr %l50, !tbaa !24
  br label %bb26
bb26:
  %t142 = load i64, ptr %l6, !tbaa !24
  %t145 = add i64 %t142, 1
  store i64 %t145, ptr %l6, !tbaa !24
  br label %bb22
bb27:
  br label %bb21
bb28:
  store { i64, ptr } zeroinitializer, ptr %l45, !tbaa !27
  br label %bb29
bb29:
  %t147 = load i64, ptr %l43
  %t148 = inttoptr i64 %t147 to ptr
  %t149 = load { i64, ptr }, ptr %l45
  %t150 = extractvalue { i64, ptr } %t149, 1
  %t151 = call ptr @__olang_region_or(ptr %t150, ptr null)
  %t152 = icmp ne ptr %t151, null
  %t153 = select i1 %t152, ptr %t151, ptr null
  call void @__olang_region_settle_in(ptr %t148, ptr %t153)
  %t154 = load ptr, ptr %l33, !tbaa !29
  %t155 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t154, i32 0, i32 0
  %t156 = load { i64, ptr }, ptr %t155, !tbaa !27
  store { i64, ptr } %t156, ptr %l64, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t158 = load ptr, ptr %l33, !tbaa !29
  %t159 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t158, i32 0, i32 0
  store { i64, ptr } %t157, ptr %t159, !tbaa !27
  %t160 = load { i64, ptr }, ptr %l64
  %t161 = extractvalue { i64, ptr } %t160, 0
  %t162 = extractvalue { i64, ptr } %t160, 1
  call void @__olang_region_release_part(ptr %t162, i64 %t161)
  store { i64, ptr } zeroinitializer, ptr %l64
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrBind_3e_2eroom_3ccompiler_2fcheck_3aerrBind_3e(ptr %v0, ptr %a0, i64 %a1) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l50 = alloca i64
  %l56 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  store { i64, ptr } %t56, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_95debe88b8bc2782_9885fd785c2df526)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_95debe88b8bc2782_9885fd785c2df526)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr %"compiler/check:errBind", ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t85 = call ptr @__olang_region_make_part(ptr %v0)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l43, !tbaa !24
  store i64 %t83, ptr %l44, !tbaa !24
  %t88 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t90 = load i64, ptr %l44, !tbaa !24
  %t91 = extractvalue { i64, ptr } %t88, 0
  %t92 = mul i64 %t91, 32
  %t93 = mul i64 %t90, 32
  %t94 = extractvalue { i64, ptr } %t88, 1
  %t95 = call ptr @__olang_grow_in_place(ptr %t94, i64 %t92, i64 %t93, i64 %t90)
  %t96 = icmp ne ptr %t95, null
  %t97 = select i1 %t96, i64 %t90, i64 0
  %t98 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t95, 1
  store { i64, ptr } %t99, ptr %l47, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  %t103 = icmp ne i64 %t101, 0
  br i1 %t103, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_95debe88b8bc2782_9885fd785c2df526)
  unreachable
bb19:
  %t105 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t105, ptr %l45, !tbaa !27
  br label %bb21
bb20:
  %t106 = load i64, ptr %l44, !tbaa !24
  %t107 = mul i64 %t106, 32
  %t108 = load i64, ptr %l43
  %t109 = inttoptr i64 %t108 to ptr
  %t110 = call ptr @__olang_held_alloc(ptr %t109, i64 %t107)
  %t111 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l45, !tbaa !27
  store i64 0, ptr %l50, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb22
bb21:
  %t113 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  %t116 = icmp eq i64 %t114, 0
  br i1 %t116, label %bb28, label %bb29
bb22:
  %t118 = load i64, ptr %l6, !tbaa !24
  %t119 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t124 = icmp slt i64 %t118, %t121
  %t126 = xor i1 %t124, true
  br i1 %t126, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t128 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t128, ptr %l56, !tbaa !27
  %t129 = load i64, ptr %l6, !tbaa !24
  %t131 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr %"compiler/check:errBind", ptr %t132, i64 %t129
  %t134 = load %"compiler/check:errBind", ptr %t133
  %t136 = load i64, ptr %l50, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr %"compiler/check:errBind", ptr %t138, i64 %t136
  store %"compiler/check:errBind" %t134, ptr %t139
  %t140 = load i64, ptr %l50, !tbaa !24
  %t141 = add i64 %t140, 1
  store i64 %t141, ptr %l50, !tbaa !24
  br label %bb26
bb26:
  %t142 = load i64, ptr %l6, !tbaa !24
  %t145 = add i64 %t142, 1
  store i64 %t145, ptr %l6, !tbaa !24
  br label %bb22
bb27:
  br label %bb21
bb28:
  store { i64, ptr } zeroinitializer, ptr %l45, !tbaa !27
  br label %bb29
bb29:
  %t147 = load i64, ptr %l43
  %t148 = inttoptr i64 %t147 to ptr
  %t149 = load { i64, ptr }, ptr %l45
  %t150 = extractvalue { i64, ptr } %t149, 1
  %t151 = call ptr @__olang_region_or(ptr %t150, ptr null)
  %t152 = icmp ne ptr %t151, null
  %t153 = select i1 %t152, ptr %t151, ptr null
  call void @__olang_region_settle_in(ptr %t148, ptr %t153)
  %t154 = load ptr, ptr %l33, !tbaa !29
  %t155 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t154, i32 0, i32 0
  %t156 = load { i64, ptr }, ptr %t155, !tbaa !27
  store { i64, ptr } %t156, ptr %l64, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t158 = load ptr, ptr %l33, !tbaa !29
  %t159 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t158, i32 0, i32 0
  store { i64, ptr } %t157, ptr %t159, !tbaa !27
  %t160 = load { i64, ptr }, ptr %l64
  %t161 = extractvalue { i64, ptr } %t160, 0
  %t162 = extractvalue { i64, ptr } %t160, 1
  call void @__olang_region_release_part(ptr %t162, i64 %t161)
  store { i64, ptr } zeroinitializer, ptr %l64
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3afactRead_3e_2eroom_3ccompiler_2fcheck_3afactRead_3e(ptr %v0, ptr %a0, i64 %a1) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l50 = alloca i64
  %l56 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  store { i64, ptr } %t56, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_39bec683f355f06_6544abda65b44c0a)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_39bec683f355f06_6544abda65b44c0a)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr %"compiler/check:factRead", ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t85 = call ptr @__olang_region_make_part(ptr %v0)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l43, !tbaa !24
  store i64 %t83, ptr %l44, !tbaa !24
  %t88 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t90 = load i64, ptr %l44, !tbaa !24
  %t91 = extractvalue { i64, ptr } %t88, 0
  %t92 = mul i64 %t91, 72
  %t93 = mul i64 %t90, 72
  %t94 = extractvalue { i64, ptr } %t88, 1
  %t95 = call ptr @__olang_grow_in_place(ptr %t94, i64 %t92, i64 %t93, i64 %t90)
  %t96 = icmp ne ptr %t95, null
  %t97 = select i1 %t96, i64 %t90, i64 0
  %t98 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t95, 1
  store { i64, ptr } %t99, ptr %l47, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  %t103 = icmp ne i64 %t101, 0
  br i1 %t103, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_39bec683f355f06_6544abda65b44c0a)
  unreachable
bb19:
  %t105 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t105, ptr %l45, !tbaa !27
  br label %bb21
bb20:
  %t106 = load i64, ptr %l44, !tbaa !24
  %t107 = mul i64 %t106, 72
  %t108 = load i64, ptr %l43
  %t109 = inttoptr i64 %t108 to ptr
  %t110 = call ptr @__olang_held_alloc(ptr %t109, i64 %t107)
  %t111 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l45, !tbaa !27
  store i64 0, ptr %l50, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb22
bb21:
  %t113 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  %t116 = icmp eq i64 %t114, 0
  br i1 %t116, label %bb28, label %bb29
bb22:
  %t118 = load i64, ptr %l6, !tbaa !24
  %t119 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t124 = icmp slt i64 %t118, %t121
  %t126 = xor i1 %t124, true
  br i1 %t126, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t128 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t128, ptr %l56, !tbaa !27
  %t129 = load i64, ptr %l6, !tbaa !24
  %t131 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr %"compiler/check:factRead", ptr %t132, i64 %t129
  %t134 = load %"compiler/check:factRead", ptr %t133
  %t136 = load i64, ptr %l50, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr %"compiler/check:factRead", ptr %t138, i64 %t136
  store %"compiler/check:factRead" %t134, ptr %t139
  %t140 = load i64, ptr %l50, !tbaa !24
  %t141 = add i64 %t140, 1
  store i64 %t141, ptr %l50, !tbaa !24
  br label %bb26
bb26:
  %t142 = load i64, ptr %l6, !tbaa !24
  %t145 = add i64 %t142, 1
  store i64 %t145, ptr %l6, !tbaa !24
  br label %bb22
bb27:
  br label %bb21
bb28:
  store { i64, ptr } zeroinitializer, ptr %l45, !tbaa !27
  br label %bb29
bb29:
  %t147 = load i64, ptr %l43
  %t148 = inttoptr i64 %t147 to ptr
  %t149 = load { i64, ptr }, ptr %l45
  %t150 = extractvalue { i64, ptr } %t149, 1
  %t151 = call ptr @__olang_region_or(ptr %t150, ptr null)
  %t152 = icmp ne ptr %t151, null
  %t153 = select i1 %t152, ptr %t151, ptr null
  call void @__olang_region_settle_in(ptr %t148, ptr %t153)
  %t154 = load ptr, ptr %l33, !tbaa !29
  %t155 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t154, i32 0, i32 0
  %t156 = load { i64, ptr }, ptr %t155, !tbaa !27
  store { i64, ptr } %t156, ptr %l64, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t158 = load ptr, ptr %l33, !tbaa !29
  %t159 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t158, i32 0, i32 0
  store { i64, ptr } %t157, ptr %t159, !tbaa !27
  %t160 = load { i64, ptr }, ptr %l64
  %t161 = extractvalue { i64, ptr } %t160, 0
  %t162 = extractvalue { i64, ptr } %t160, 1
  call void @__olang_region_release_part(ptr %t162, i64 %t161)
  store { i64, ptr } zeroinitializer, ptr %l64
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3afixedProof_3e_2eroo_H86898f2ea34852b872a135a724a616cf(ptr %v0, ptr %a0, i64 %a1) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l50 = alloca i64
  %l56 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  store { i64, ptr } %t56, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_b7e1b3046b0c2a18_1d09df7918637084)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_b7e1b3046b0c2a18_1d09df7918637084)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr %"compiler/check:fixedProof", ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t85 = call ptr @__olang_region_make_part(ptr %v0)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l43, !tbaa !24
  store i64 %t83, ptr %l44, !tbaa !24
  %t88 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t90 = load i64, ptr %l44, !tbaa !24
  %t91 = extractvalue { i64, ptr } %t88, 0
  %t92 = mul i64 %t91, 32
  %t93 = mul i64 %t90, 32
  %t94 = extractvalue { i64, ptr } %t88, 1
  %t95 = call ptr @__olang_grow_in_place(ptr %t94, i64 %t92, i64 %t93, i64 %t90)
  %t96 = icmp ne ptr %t95, null
  %t97 = select i1 %t96, i64 %t90, i64 0
  %t98 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t95, 1
  store { i64, ptr } %t99, ptr %l47, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  %t103 = icmp ne i64 %t101, 0
  br i1 %t103, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_b7e1b3046b0c2a18_1d09df7918637084)
  unreachable
bb19:
  %t105 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t105, ptr %l45, !tbaa !27
  br label %bb21
bb20:
  %t106 = load i64, ptr %l44, !tbaa !24
  %t107 = mul i64 %t106, 32
  %t108 = load i64, ptr %l43
  %t109 = inttoptr i64 %t108 to ptr
  %t110 = call ptr @__olang_held_alloc(ptr %t109, i64 %t107)
  %t111 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l45, !tbaa !27
  store i64 0, ptr %l50, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb22
bb21:
  %t113 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  %t116 = icmp eq i64 %t114, 0
  br i1 %t116, label %bb28, label %bb29
bb22:
  %t118 = load i64, ptr %l6, !tbaa !24
  %t119 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t124 = icmp slt i64 %t118, %t121
  %t126 = xor i1 %t124, true
  br i1 %t126, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t128 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t128, ptr %l56, !tbaa !27
  %t129 = load i64, ptr %l6, !tbaa !24
  %t131 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr %"compiler/check:fixedProof", ptr %t132, i64 %t129
  %t134 = load %"compiler/check:fixedProof", ptr %t133
  %t136 = load i64, ptr %l50, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr %"compiler/check:fixedProof", ptr %t138, i64 %t136
  store %"compiler/check:fixedProof" %t134, ptr %t139
  %t140 = load i64, ptr %l50, !tbaa !24
  %t141 = add i64 %t140, 1
  store i64 %t141, ptr %l50, !tbaa !24
  br label %bb26
bb26:
  %t142 = load i64, ptr %l6, !tbaa !24
  %t145 = add i64 %t142, 1
  store i64 %t145, ptr %l6, !tbaa !24
  br label %bb22
bb27:
  br label %bb21
bb28:
  store { i64, ptr } zeroinitializer, ptr %l45, !tbaa !27
  br label %bb29
bb29:
  %t147 = load i64, ptr %l43
  %t148 = inttoptr i64 %t147 to ptr
  %t149 = load { i64, ptr }, ptr %l45
  %t150 = extractvalue { i64, ptr } %t149, 1
  %t151 = call ptr @__olang_region_or(ptr %t150, ptr null)
  %t152 = icmp ne ptr %t151, null
  %t153 = select i1 %t152, ptr %t151, ptr null
  call void @__olang_region_settle_in(ptr %t148, ptr %t153)
  %t154 = load ptr, ptr %l33, !tbaa !29
  %t155 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t154, i32 0, i32 0
  %t156 = load { i64, ptr }, ptr %t155, !tbaa !27
  store { i64, ptr } %t156, ptr %l64, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t158 = load ptr, ptr %l33, !tbaa !29
  %t159 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t158, i32 0, i32 0
  store { i64, ptr } %t157, ptr %t159, !tbaa !27
  %t160 = load { i64, ptr }, ptr %l64
  %t161 = extractvalue { i64, ptr } %t160, 0
  %t162 = extractvalue { i64, ptr } %t160, 1
  call void @__olang_region_release_part(ptr %t162, i64 %t161)
  store { i64, ptr } zeroinitializer, ptr %l64
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aheldCand_3e_2eroom_3ccompiler_2fcheck_3aheldCand_3e(ptr %v0, ptr %a0, i64 %a1) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l50 = alloca i64
  %l56 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  store { i64, ptr } %t56, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_4195eed94f8745a2_18603c53a82e31e6)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_4195eed94f8745a2_18603c53a82e31e6)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr %"compiler/check:heldCand", ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t85 = call ptr @__olang_region_make_part(ptr %v0)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l43, !tbaa !24
  store i64 %t83, ptr %l44, !tbaa !24
  %t88 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t90 = load i64, ptr %l44, !tbaa !24
  %t91 = extractvalue { i64, ptr } %t88, 0
  %t92 = mul i64 %t91, 24
  %t93 = mul i64 %t90, 24
  %t94 = extractvalue { i64, ptr } %t88, 1
  %t95 = call ptr @__olang_grow_in_place(ptr %t94, i64 %t92, i64 %t93, i64 %t90)
  %t96 = icmp ne ptr %t95, null
  %t97 = select i1 %t96, i64 %t90, i64 0
  %t98 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t95, 1
  store { i64, ptr } %t99, ptr %l47, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  %t103 = icmp ne i64 %t101, 0
  br i1 %t103, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_4195eed94f8745a2_18603c53a82e31e6)
  unreachable
bb19:
  %t105 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t105, ptr %l45, !tbaa !27
  br label %bb21
bb20:
  %t106 = load i64, ptr %l44, !tbaa !24
  %t107 = mul i64 %t106, 24
  %t108 = load i64, ptr %l43
  %t109 = inttoptr i64 %t108 to ptr
  %t110 = call ptr @__olang_held_alloc(ptr %t109, i64 %t107)
  %t111 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l45, !tbaa !27
  store i64 0, ptr %l50, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb22
bb21:
  %t113 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  %t116 = icmp eq i64 %t114, 0
  br i1 %t116, label %bb28, label %bb29
bb22:
  %t118 = load i64, ptr %l6, !tbaa !24
  %t119 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t124 = icmp slt i64 %t118, %t121
  %t126 = xor i1 %t124, true
  br i1 %t126, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t128 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t128, ptr %l56, !tbaa !27
  %t129 = load i64, ptr %l6, !tbaa !24
  %t131 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr %"compiler/check:heldCand", ptr %t132, i64 %t129
  %t134 = load %"compiler/check:heldCand", ptr %t133
  %t136 = load i64, ptr %l50, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr %"compiler/check:heldCand", ptr %t138, i64 %t136
  store %"compiler/check:heldCand" %t134, ptr %t139
  %t140 = load i64, ptr %l50, !tbaa !24
  %t141 = add i64 %t140, 1
  store i64 %t141, ptr %l50, !tbaa !24
  br label %bb26
bb26:
  %t142 = load i64, ptr %l6, !tbaa !24
  %t145 = add i64 %t142, 1
  store i64 %t145, ptr %l6, !tbaa !24
  br label %bb22
bb27:
  br label %bb21
bb28:
  store { i64, ptr } zeroinitializer, ptr %l45, !tbaa !27
  br label %bb29
bb29:
  %t147 = load i64, ptr %l43
  %t148 = inttoptr i64 %t147 to ptr
  %t149 = load { i64, ptr }, ptr %l45
  %t150 = extractvalue { i64, ptr } %t149, 1
  %t151 = call ptr @__olang_region_or(ptr %t150, ptr null)
  %t152 = icmp ne ptr %t151, null
  %t153 = select i1 %t152, ptr %t151, ptr null
  call void @__olang_region_settle_in(ptr %t148, ptr %t153)
  %t154 = load ptr, ptr %l33, !tbaa !29
  %t155 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t154, i32 0, i32 0
  %t156 = load { i64, ptr }, ptr %t155, !tbaa !27
  store { i64, ptr } %t156, ptr %l64, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t158 = load ptr, ptr %l33, !tbaa !29
  %t159 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t158, i32 0, i32 0
  store { i64, ptr } %t157, ptr %t159, !tbaa !27
  %t160 = load { i64, ptr }, ptr %l64
  %t161 = extractvalue { i64, ptr } %t160, 0
  %t162 = extractvalue { i64, ptr } %t160, 1
  call void @__olang_region_release_part(ptr %t162, i64 %t161)
  store { i64, ptr } zeroinitializer, ptr %l64
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3ainPlaceRead_3e_2ero_H27f130f051090eb2dc2e7f762221771d(ptr %v0, ptr %a0, i64 %a1) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l43 = alloca i64
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l52 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  store { i64, ptr } %t56, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_33565fc69cd567d5_99246efc5a0cf5f1)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_33565fc69cd567d5_99246efc5a0cf5f1)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr %"compiler/check:inPlaceRead", ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t85 = call ptr @__olang_region_make_part(ptr %v0)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l43, !tbaa !24
  %t89 = mul i64 %t83, 64
  %t90 = load i64, ptr %l43
  %t91 = inttoptr i64 %t90 to ptr
  %t92 = call ptr @__olang_scope_alloc_zeroed(ptr %t91, i64 %t89)
  %t93 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t92, 1
  store { i64, ptr } %t94, ptr %l45, !tbaa !27
  store i64 0, ptr %l46, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_33565fc69cd567d5_99246efc5a0cf5f1)
  unreachable
bb19:
  %t95 = load i64, ptr %l6, !tbaa !24
  %t96 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t96, 0
  %t101 = icmp slt i64 %t95, %t98
  %t103 = xor i1 %t101, true
  br i1 %t103, label %bb20, label %bb21
bb20:
  br label %bb24
bb21:
  br label %bb22
bb22:
  %t105 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t105, ptr %l52, !tbaa !27
  %t106 = load i64, ptr %l6, !tbaa !24
  %t108 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr %"compiler/check:inPlaceRead", ptr %t109, i64 %t106
  %t111 = load %"compiler/check:inPlaceRead", ptr %t110
  store %"compiler/check:inPlaceRead" zeroinitializer, ptr %t110
  %t113 = load i64, ptr %l46, !tbaa !24
  %t114 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr %"compiler/check:inPlaceRead", ptr %t115, i64 %t113
  store %"compiler/check:inPlaceRead" %t111, ptr %t116
  %t117 = load i64, ptr %l46, !tbaa !24
  %t118 = add i64 %t117, 1
  store i64 %t118, ptr %l46, !tbaa !24
  br label %bb23
bb23:
  %t119 = load i64, ptr %l6, !tbaa !24
  %t122 = add i64 %t119, 1
  store i64 %t122, ptr %l6, !tbaa !24
  br label %bb19
bb24:
  %t124 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t124, 0
  %t127 = icmp eq i64 %t125, 0
  br i1 %t127, label %bb25, label %bb26
bb25:
  store { i64, ptr } zeroinitializer, ptr %l45, !tbaa !27
  br label %bb26
bb26:
  %t129 = load i64, ptr %l43
  %t130 = inttoptr i64 %t129 to ptr
  %t131 = load { i64, ptr }, ptr %l45
  %t132 = extractvalue { i64, ptr } %t131, 1
  %t133 = call ptr @__olang_region_or(ptr %t132, ptr null)
  %t134 = icmp ne ptr %t133, null
  %t135 = select i1 %t134, ptr %t133, ptr null
  call void @__olang_region_settle_in(ptr %t130, ptr %t135)
  %t136 = load ptr, ptr %l33, !tbaa !29
  %t137 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t136, i32 0, i32 0
  %t138 = load { i64, ptr }, ptr %t137, !tbaa !27
  store { i64, ptr } %t138, ptr %l60, !tbaa !27
  %t139 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t140 = load ptr, ptr %l33, !tbaa !29
  %t141 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t140, i32 0, i32 0
  store { i64, ptr } %t139, ptr %t141, !tbaa !27
  %t142 = load { i64, ptr }, ptr %l60
  %t143 = extractvalue { i64, ptr } %t142, 0
  %t144 = extractvalue { i64, ptr } %t142, 1
  call void @__olang_region_release_part(ptr %t144, i64 %t143)
  store { i64, ptr } zeroinitializer, ptr %l60
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alanding_3e_2eroom_3ccompiler_2fcheck_3alanding_3e(ptr %v0, ptr %a0, i64 %a1) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l50 = alloca i64
  %l56 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  store { i64, ptr } %t56, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_4a34131d9c5c50a8_fcf917aa64a4d72c)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_4a34131d9c5c50a8_fcf917aa64a4d72c)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr %"compiler/check:landing", ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t85 = call ptr @__olang_region_make_part(ptr %v0)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l43, !tbaa !24
  store i64 %t83, ptr %l44, !tbaa !24
  %t88 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t90 = load i64, ptr %l44, !tbaa !24
  %t91 = extractvalue { i64, ptr } %t88, 0
  %t92 = mul i64 %t91, 40
  %t93 = mul i64 %t90, 40
  %t94 = extractvalue { i64, ptr } %t88, 1
  %t95 = call ptr @__olang_grow_in_place(ptr %t94, i64 %t92, i64 %t93, i64 %t90)
  %t96 = icmp ne ptr %t95, null
  %t97 = select i1 %t96, i64 %t90, i64 0
  %t98 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t95, 1
  store { i64, ptr } %t99, ptr %l47, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  %t103 = icmp ne i64 %t101, 0
  br i1 %t103, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_4a34131d9c5c50a8_fcf917aa64a4d72c)
  unreachable
bb19:
  %t105 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t105, ptr %l45, !tbaa !27
  br label %bb21
bb20:
  %t106 = load i64, ptr %l44, !tbaa !24
  %t107 = mul i64 %t106, 40
  %t108 = load i64, ptr %l43
  %t109 = inttoptr i64 %t108 to ptr
  %t110 = call ptr @__olang_held_alloc(ptr %t109, i64 %t107)
  %t111 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l45, !tbaa !27
  store i64 0, ptr %l50, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb22
bb21:
  %t113 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  %t116 = icmp eq i64 %t114, 0
  br i1 %t116, label %bb28, label %bb29
bb22:
  %t118 = load i64, ptr %l6, !tbaa !24
  %t119 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t124 = icmp slt i64 %t118, %t121
  %t126 = xor i1 %t124, true
  br i1 %t126, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t128 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t128, ptr %l56, !tbaa !27
  %t129 = load i64, ptr %l6, !tbaa !24
  %t131 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr %"compiler/check:landing", ptr %t132, i64 %t129
  %t134 = load %"compiler/check:landing", ptr %t133
  %t136 = load i64, ptr %l50, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr %"compiler/check:landing", ptr %t138, i64 %t136
  store %"compiler/check:landing" %t134, ptr %t139
  %t140 = load i64, ptr %l50, !tbaa !24
  %t141 = add i64 %t140, 1
  store i64 %t141, ptr %l50, !tbaa !24
  br label %bb26
bb26:
  %t142 = load i64, ptr %l6, !tbaa !24
  %t145 = add i64 %t142, 1
  store i64 %t145, ptr %l6, !tbaa !24
  br label %bb22
bb27:
  br label %bb21
bb28:
  store { i64, ptr } zeroinitializer, ptr %l45, !tbaa !27
  br label %bb29
bb29:
  %t147 = load i64, ptr %l43
  %t148 = inttoptr i64 %t147 to ptr
  %t149 = load { i64, ptr }, ptr %l45
  %t150 = extractvalue { i64, ptr } %t149, 1
  %t151 = call ptr @__olang_region_or(ptr %t150, ptr null)
  %t152 = icmp ne ptr %t151, null
  %t153 = select i1 %t152, ptr %t151, ptr null
  call void @__olang_region_settle_in(ptr %t148, ptr %t153)
  %t154 = load ptr, ptr %l33, !tbaa !29
  %t155 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t154, i32 0, i32 0
  %t156 = load { i64, ptr }, ptr %t155, !tbaa !27
  store { i64, ptr } %t156, ptr %l64, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t158 = load ptr, ptr %l33, !tbaa !29
  %t159 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t158, i32 0, i32 0
  store { i64, ptr } %t157, ptr %t159, !tbaa !27
  %t160 = load { i64, ptr }, ptr %l64
  %t161 = extractvalue { i64, ptr } %t160, 0
  %t162 = extractvalue { i64, ptr } %t160, 1
  call void @__olang_region_release_part(ptr %t162, i64 %t161)
  store { i64, ptr } zeroinitializer, ptr %l64
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aloopUse_3e_2eroom_3ccompiler_2fcheck_3aloopUse_3e(ptr %v0, ptr %a0, i64 %a1) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l43 = alloca i64
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l52 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l61 = alloca i64
  %l62 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  store { i64, ptr } %t56, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_a46688ee68c12b98_9d70ef7bc9829d2c)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_a46688ee68c12b98_9d70ef7bc9829d2c)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr %"compiler/check:loopUse", ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t85 = call ptr @__olang_region_make_part(ptr %v0)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l43, !tbaa !24
  %t89 = mul i64 %t83, 32
  %t90 = load i64, ptr %l43
  %t91 = inttoptr i64 %t90 to ptr
  %t92 = call ptr @__olang_scope_alloc_zeroed(ptr %t91, i64 %t89)
  %t93 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t92, 1
  store { i64, ptr } %t94, ptr %l45, !tbaa !27
  store i64 0, ptr %l46, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_a46688ee68c12b98_9d70ef7bc9829d2c)
  unreachable
bb19:
  %t95 = load i64, ptr %l6, !tbaa !24
  %t96 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t96, 0
  %t101 = icmp slt i64 %t95, %t98
  %t103 = xor i1 %t101, true
  br i1 %t103, label %bb20, label %bb21
bb20:
  br label %bb24
bb21:
  br label %bb22
bb22:
  %t105 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t105, ptr %l52, !tbaa !27
  %t106 = load i64, ptr %l6, !tbaa !24
  %t108 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr %"compiler/check:loopUse", ptr %t109, i64 %t106
  %t111 = load %"compiler/check:loopUse", ptr %t110
  store %"compiler/check:loopUse" zeroinitializer, ptr %t110
  %t113 = load i64, ptr %l46, !tbaa !24
  %t114 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr %"compiler/check:loopUse", ptr %t115, i64 %t113
  store %"compiler/check:loopUse" %t111, ptr %t116
  %t117 = load i64, ptr %l46, !tbaa !24
  %t118 = add i64 %t117, 1
  store i64 %t118, ptr %l46, !tbaa !24
  br label %bb23
bb23:
  %t119 = load i64, ptr %l6, !tbaa !24
  %t122 = add i64 %t119, 1
  store i64 %t122, ptr %l6, !tbaa !24
  br label %bb19
bb24:
  %t124 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t124, 0
  %t127 = icmp eq i64 %t125, 0
  br i1 %t127, label %bb25, label %bb26
bb25:
  store { i64, ptr } zeroinitializer, ptr %l45, !tbaa !27
  br label %bb26
bb26:
  %t129 = load i64, ptr %l43
  %t130 = inttoptr i64 %t129 to ptr
  %t131 = load { i64, ptr }, ptr %l45
  %t132 = extractvalue { i64, ptr } %t131, 1
  %t133 = call ptr @__olang_region_or(ptr %t132, ptr null)
  %t134 = icmp ne ptr %t133, null
  %t135 = select i1 %t134, ptr %t133, ptr null
  call void @__olang_region_settle_in(ptr %t130, ptr %t135)
  %t136 = load ptr, ptr %l33, !tbaa !29
  %t137 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t136, i32 0, i32 0
  %t138 = load { i64, ptr }, ptr %t137, !tbaa !27
  store { i64, ptr } %t138, ptr %l60, !tbaa !27
  %t139 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t140 = load ptr, ptr %l33, !tbaa !29
  %t141 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t140, i32 0, i32 0
  store { i64, ptr } %t139, ptr %t141, !tbaa !27
  %t142 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t142, 0
  store i64 %t143, ptr %l61, !tbaa !24
  store i64 0, ptr %l62, !tbaa !24
  br label %bb27
bb27:
  %t144 = load i64, ptr %l62, !tbaa !24
  %t145 = load i64, ptr %l61, !tbaa !24
  %t146 = icmp slt i64 %t144, %t145
  br i1 %t146, label %bb28, label %bb29
bb28:
  %t148 = load i64, ptr %l62, !tbaa !24
  %t149 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !27
  %t151 = getelementptr %"compiler/check:loopUse", ptr %t150, i64 %t148
  %t152 = getelementptr %"compiler/check:loopUse", ptr %t151, i32 0, i32 2
  %t153 = load { i64, ptr }, ptr %t152
  %t154 = extractvalue { i64, ptr } %t153, 0
  %t155 = extractvalue { i64, ptr } %t153, 1
  call void @__olang_region_release_part(ptr %t155, i64 %t154)
  store { i64, ptr } zeroinitializer, ptr %t152
  %t156 = load i64, ptr %l62, !tbaa !24
  %t157 = add i64 %t156, 1
  store i64 %t157, ptr %l62, !tbaa !24
  br label %bb27
bb29:
  %t158 = load { i64, ptr }, ptr %l60
  %t159 = extractvalue { i64, ptr } %t158, 0
  %t160 = extractvalue { i64, ptr } %t158, 1
  call void @__olang_region_release_part(ptr %t160, i64 %t159)
  store { i64, ptr } zeroinitializer, ptr %l60
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3arangeIndex_3e_2eroo_H1e639fe5e6847d38533db55cb50abb25(ptr %v0, ptr %a0, i64 %a1) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l43 = alloca i64
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l52 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  store { i64, ptr } %t56, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_272d8b19690cbcac_1110d090bfa6a438)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_272d8b19690cbcac_1110d090bfa6a438)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr %"compiler/check:rangeIndex", ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t85 = call ptr @__olang_region_make_part(ptr %v0)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l43, !tbaa !24
  %t89 = mul i64 %t83, 56
  %t90 = load i64, ptr %l43
  %t91 = inttoptr i64 %t90 to ptr
  %t92 = call ptr @__olang_scope_alloc_zeroed(ptr %t91, i64 %t89)
  %t93 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t92, 1
  store { i64, ptr } %t94, ptr %l45, !tbaa !27
  store i64 0, ptr %l46, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_272d8b19690cbcac_1110d090bfa6a438)
  unreachable
bb19:
  %t95 = load i64, ptr %l6, !tbaa !24
  %t96 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t96, 0
  %t101 = icmp slt i64 %t95, %t98
  %t103 = xor i1 %t101, true
  br i1 %t103, label %bb20, label %bb21
bb20:
  br label %bb24
bb21:
  br label %bb22
bb22:
  %t105 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t105, ptr %l52, !tbaa !27
  %t106 = load i64, ptr %l6, !tbaa !24
  %t108 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr %"compiler/check:rangeIndex", ptr %t109, i64 %t106
  %t111 = load %"compiler/check:rangeIndex", ptr %t110
  store %"compiler/check:rangeIndex" zeroinitializer, ptr %t110
  %t113 = load i64, ptr %l46, !tbaa !24
  %t114 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr %"compiler/check:rangeIndex", ptr %t115, i64 %t113
  store %"compiler/check:rangeIndex" %t111, ptr %t116
  %t117 = load i64, ptr %l46, !tbaa !24
  %t118 = add i64 %t117, 1
  store i64 %t118, ptr %l46, !tbaa !24
  br label %bb23
bb23:
  %t119 = load i64, ptr %l6, !tbaa !24
  %t122 = add i64 %t119, 1
  store i64 %t122, ptr %l6, !tbaa !24
  br label %bb19
bb24:
  %t124 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t124, 0
  %t127 = icmp eq i64 %t125, 0
  br i1 %t127, label %bb25, label %bb26
bb25:
  store { i64, ptr } zeroinitializer, ptr %l45, !tbaa !27
  br label %bb26
bb26:
  %t129 = load i64, ptr %l43
  %t130 = inttoptr i64 %t129 to ptr
  %t131 = load { i64, ptr }, ptr %l45
  %t132 = extractvalue { i64, ptr } %t131, 1
  %t133 = call ptr @__olang_region_or(ptr %t132, ptr null)
  %t134 = icmp ne ptr %t133, null
  %t135 = select i1 %t134, ptr %t133, ptr null
  call void @__olang_region_settle_in(ptr %t130, ptr %t135)
  %t136 = load ptr, ptr %l33, !tbaa !29
  %t137 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t136, i32 0, i32 0
  %t138 = load { i64, ptr }, ptr %t137, !tbaa !27
  store { i64, ptr } %t138, ptr %l60, !tbaa !27
  %t139 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t140 = load ptr, ptr %l33, !tbaa !29
  %t141 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t140, i32 0, i32 0
  store { i64, ptr } %t139, ptr %t141, !tbaa !27
  %t142 = load { i64, ptr }, ptr %l60
  %t143 = extractvalue { i64, ptr } %t142, 0
  %t144 = extractvalue { i64, ptr } %t142, 1
  call void @__olang_region_release_part(ptr %t144, i64 %t143)
  store { i64, ptr } zeroinitializer, ptr %l60
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3atailAsk_3e_2eroom_3ccompiler_2fcheck_3atailAsk_3e(ptr %v0, ptr %a0, i64 %a1) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l50 = alloca i64
  %l56 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  store { i64, ptr } %t56, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_ba624bda9d604dc4_4f7e174daad6f548)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_ba624bda9d604dc4_4f7e174daad6f548)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr %"compiler/check:tailAsk", ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t85 = call ptr @__olang_region_make_part(ptr %v0)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l43, !tbaa !24
  store i64 %t83, ptr %l44, !tbaa !24
  %t88 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t90 = load i64, ptr %l44, !tbaa !24
  %t91 = extractvalue { i64, ptr } %t88, 0
  %t92 = mul i64 %t91, 32
  %t93 = mul i64 %t90, 32
  %t94 = extractvalue { i64, ptr } %t88, 1
  %t95 = call ptr @__olang_grow_in_place(ptr %t94, i64 %t92, i64 %t93, i64 %t90)
  %t96 = icmp ne ptr %t95, null
  %t97 = select i1 %t96, i64 %t90, i64 0
  %t98 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t95, 1
  store { i64, ptr } %t99, ptr %l47, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  %t103 = icmp ne i64 %t101, 0
  br i1 %t103, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_ba624bda9d604dc4_4f7e174daad6f548)
  unreachable
bb19:
  %t105 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t105, ptr %l45, !tbaa !27
  br label %bb21
bb20:
  %t106 = load i64, ptr %l44, !tbaa !24
  %t107 = mul i64 %t106, 32
  %t108 = load i64, ptr %l43
  %t109 = inttoptr i64 %t108 to ptr
  %t110 = call ptr @__olang_held_alloc(ptr %t109, i64 %t107)
  %t111 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l45, !tbaa !27
  store i64 0, ptr %l50, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb22
bb21:
  %t113 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  %t116 = icmp eq i64 %t114, 0
  br i1 %t116, label %bb28, label %bb29
bb22:
  %t118 = load i64, ptr %l6, !tbaa !24
  %t119 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t124 = icmp slt i64 %t118, %t121
  %t126 = xor i1 %t124, true
  br i1 %t126, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t128 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t128, ptr %l56, !tbaa !27
  %t129 = load i64, ptr %l6, !tbaa !24
  %t131 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr %"compiler/check:tailAsk", ptr %t132, i64 %t129
  %t134 = load %"compiler/check:tailAsk", ptr %t133
  %t136 = load i64, ptr %l50, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr %"compiler/check:tailAsk", ptr %t138, i64 %t136
  store %"compiler/check:tailAsk" %t134, ptr %t139
  %t140 = load i64, ptr %l50, !tbaa !24
  %t141 = add i64 %t140, 1
  store i64 %t141, ptr %l50, !tbaa !24
  br label %bb26
bb26:
  %t142 = load i64, ptr %l6, !tbaa !24
  %t145 = add i64 %t142, 1
  store i64 %t145, ptr %l6, !tbaa !24
  br label %bb22
bb27:
  br label %bb21
bb28:
  store { i64, ptr } zeroinitializer, ptr %l45, !tbaa !27
  br label %bb29
bb29:
  %t147 = load i64, ptr %l43
  %t148 = inttoptr i64 %t147 to ptr
  %t149 = load { i64, ptr }, ptr %l45
  %t150 = extractvalue { i64, ptr } %t149, 1
  %t151 = call ptr @__olang_region_or(ptr %t150, ptr null)
  %t152 = icmp ne ptr %t151, null
  %t153 = select i1 %t152, ptr %t151, ptr null
  call void @__olang_region_settle_in(ptr %t148, ptr %t153)
  %t154 = load ptr, ptr %l33, !tbaa !29
  %t155 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t154, i32 0, i32 0
  %t156 = load { i64, ptr }, ptr %t155, !tbaa !27
  store { i64, ptr } %t156, ptr %l64, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t158 = load ptr, ptr %l33, !tbaa !29
  %t159 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t158, i32 0, i32 0
  store { i64, ptr } %t157, ptr %t159, !tbaa !27
  %t160 = load { i64, ptr }, ptr %l64
  %t161 = extractvalue { i64, ptr } %t160, 0
  %t162 = extractvalue { i64, ptr } %t160, 1
  call void @__olang_region_release_part(ptr %t162, i64 %t161)
  store { i64, ptr } zeroinitializer, ptr %l64
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3atypeCase_3e_2eroom_3ccompiler_2fcheck_3atypeCase_3e(ptr %v0, ptr %a0, i64 %a1) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l50 = alloca i64
  %l56 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  store { i64, ptr } %t56, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_af8acc0ba3137456_cd77df1b40ea06ea)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_af8acc0ba3137456_cd77df1b40ea06ea)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr %"compiler/check:typeCase", ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t85 = call ptr @__olang_region_make_part(ptr %v0)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l43, !tbaa !24
  store i64 %t83, ptr %l44, !tbaa !24
  %t88 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t90 = load i64, ptr %l44, !tbaa !24
  %t91 = extractvalue { i64, ptr } %t88, 0
  %t92 = mul i64 %t91, 32
  %t93 = mul i64 %t90, 32
  %t94 = extractvalue { i64, ptr } %t88, 1
  %t95 = call ptr @__olang_grow_in_place(ptr %t94, i64 %t92, i64 %t93, i64 %t90)
  %t96 = icmp ne ptr %t95, null
  %t97 = select i1 %t96, i64 %t90, i64 0
  %t98 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t95, 1
  store { i64, ptr } %t99, ptr %l47, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  %t103 = icmp ne i64 %t101, 0
  br i1 %t103, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_af8acc0ba3137456_cd77df1b40ea06ea)
  unreachable
bb19:
  %t105 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t105, ptr %l45, !tbaa !27
  br label %bb21
bb20:
  %t106 = load i64, ptr %l44, !tbaa !24
  %t107 = mul i64 %t106, 32
  %t108 = load i64, ptr %l43
  %t109 = inttoptr i64 %t108 to ptr
  %t110 = call ptr @__olang_held_alloc(ptr %t109, i64 %t107)
  %t111 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l45, !tbaa !27
  store i64 0, ptr %l50, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb22
bb21:
  %t113 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  %t116 = icmp eq i64 %t114, 0
  br i1 %t116, label %bb28, label %bb29
bb22:
  %t118 = load i64, ptr %l6, !tbaa !24
  %t119 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t124 = icmp slt i64 %t118, %t121
  %t126 = xor i1 %t124, true
  br i1 %t126, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t128 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t128, ptr %l56, !tbaa !27
  %t129 = load i64, ptr %l6, !tbaa !24
  %t131 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr %"compiler/check:typeCase", ptr %t132, i64 %t129
  %t134 = load %"compiler/check:typeCase", ptr %t133
  %t136 = load i64, ptr %l50, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr %"compiler/check:typeCase", ptr %t138, i64 %t136
  store %"compiler/check:typeCase" %t134, ptr %t139
  %t140 = load i64, ptr %l50, !tbaa !24
  %t141 = add i64 %t140, 1
  store i64 %t141, ptr %l50, !tbaa !24
  br label %bb26
bb26:
  %t142 = load i64, ptr %l6, !tbaa !24
  %t145 = add i64 %t142, 1
  store i64 %t145, ptr %l6, !tbaa !24
  br label %bb22
bb27:
  br label %bb21
bb28:
  store { i64, ptr } zeroinitializer, ptr %l45, !tbaa !27
  br label %bb29
bb29:
  %t147 = load i64, ptr %l43
  %t148 = inttoptr i64 %t147 to ptr
  %t149 = load { i64, ptr }, ptr %l45
  %t150 = extractvalue { i64, ptr } %t149, 1
  %t151 = call ptr @__olang_region_or(ptr %t150, ptr null)
  %t152 = icmp ne ptr %t151, null
  %t153 = select i1 %t152, ptr %t151, ptr null
  call void @__olang_region_settle_in(ptr %t148, ptr %t153)
  %t154 = load ptr, ptr %l33, !tbaa !29
  %t155 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t154, i32 0, i32 0
  %t156 = load { i64, ptr }, ptr %t155, !tbaa !27
  store { i64, ptr } %t156, ptr %l64, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t158 = load ptr, ptr %l33, !tbaa !29
  %t159 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t158, i32 0, i32 0
  store { i64, ptr } %t157, ptr %t159, !tbaa !27
  %t160 = load { i64, ptr }, ptr %l64
  %t161 = extractvalue { i64, ptr } %t160, 0
  %t162 = extractvalue { i64, ptr } %t160, 1
  call void @__olang_region_release_part(ptr %t162, i64 %t161)
  store { i64, ptr } zeroinitializer, ptr %l64
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aunsetCand_3e_2eroom_H2f153e4a7619996cdc8eb5906fa81b05(ptr %v0, ptr %a0, i64 %a1) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l50 = alloca i64
  %l56 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  store { i64, ptr } %t56, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_a0b4a09fb8c9f80b_755013603d945a97)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_a0b4a09fb8c9f80b_755013603d945a97)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr %"compiler/check:unsetCand", ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t85 = call ptr @__olang_region_make_part(ptr %v0)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l43, !tbaa !24
  store i64 %t83, ptr %l44, !tbaa !24
  %t88 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t90 = load i64, ptr %l44, !tbaa !24
  %t91 = extractvalue { i64, ptr } %t88, 0
  %t92 = mul i64 %t91, 56
  %t93 = mul i64 %t90, 56
  %t94 = extractvalue { i64, ptr } %t88, 1
  %t95 = call ptr @__olang_grow_in_place(ptr %t94, i64 %t92, i64 %t93, i64 %t90)
  %t96 = icmp ne ptr %t95, null
  %t97 = select i1 %t96, i64 %t90, i64 0
  %t98 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t95, 1
  store { i64, ptr } %t99, ptr %l47, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  %t103 = icmp ne i64 %t101, 0
  br i1 %t103, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_a0b4a09fb8c9f80b_755013603d945a97)
  unreachable
bb19:
  %t105 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t105, ptr %l45, !tbaa !27
  br label %bb21
bb20:
  %t106 = load i64, ptr %l44, !tbaa !24
  %t107 = mul i64 %t106, 56
  %t108 = load i64, ptr %l43
  %t109 = inttoptr i64 %t108 to ptr
  %t110 = call ptr @__olang_held_alloc(ptr %t109, i64 %t107)
  %t111 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l45, !tbaa !27
  store i64 0, ptr %l50, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb22
bb21:
  %t113 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  %t116 = icmp eq i64 %t114, 0
  br i1 %t116, label %bb28, label %bb29
bb22:
  %t118 = load i64, ptr %l6, !tbaa !24
  %t119 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t124 = icmp slt i64 %t118, %t121
  %t126 = xor i1 %t124, true
  br i1 %t126, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t128 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t128, ptr %l56, !tbaa !27
  %t129 = load i64, ptr %l6, !tbaa !24
  %t131 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr %"compiler/check:unsetCand", ptr %t132, i64 %t129
  %t134 = load %"compiler/check:unsetCand", ptr %t133
  %t136 = load i64, ptr %l50, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr %"compiler/check:unsetCand", ptr %t138, i64 %t136
  store %"compiler/check:unsetCand" %t134, ptr %t139
  %t140 = load i64, ptr %l50, !tbaa !24
  %t141 = add i64 %t140, 1
  store i64 %t141, ptr %l50, !tbaa !24
  br label %bb26
bb26:
  %t142 = load i64, ptr %l6, !tbaa !24
  %t145 = add i64 %t142, 1
  store i64 %t145, ptr %l6, !tbaa !24
  br label %bb22
bb27:
  br label %bb21
bb28:
  store { i64, ptr } zeroinitializer, ptr %l45, !tbaa !27
  br label %bb29
bb29:
  %t147 = load i64, ptr %l43
  %t148 = inttoptr i64 %t147 to ptr
  %t149 = load { i64, ptr }, ptr %l45
  %t150 = extractvalue { i64, ptr } %t149, 1
  %t151 = call ptr @__olang_region_or(ptr %t150, ptr null)
  %t152 = icmp ne ptr %t151, null
  %t153 = select i1 %t152, ptr %t151, ptr null
  call void @__olang_region_settle_in(ptr %t148, ptr %t153)
  %t154 = load ptr, ptr %l33, !tbaa !29
  %t155 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t154, i32 0, i32 0
  %t156 = load { i64, ptr }, ptr %t155, !tbaa !27
  store { i64, ptr } %t156, ptr %l64, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t158 = load ptr, ptr %l33, !tbaa !29
  %t159 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t158, i32 0, i32 0
  store { i64, ptr } %t157, ptr %t159, !tbaa !27
  %t160 = load { i64, ptr }, ptr %l64
  %t161 = extractvalue { i64, ptr } %t160, 0
  %t162 = extractvalue { i64, ptr } %t160, 1
  call void @__olang_region_release_part(ptr %t162, i64 %t161)
  store { i64, ptr } zeroinitializer, ptr %l64
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fgeneric_H261463e2d0c55a3c15aed78d28c50914(ptr %v0, ptr %a0, i64 %a1) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l50 = alloca i64
  %l56 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  store { i64, ptr } %t56, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_37d85e495f398b5e_b7b10bd71a22ca1a)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_37d85e495f398b5e_b7b10bd71a22ca1a)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f", ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t85 = call ptr @__olang_region_make_part(ptr %v0)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l43, !tbaa !24
  store i64 %t83, ptr %l44, !tbaa !24
  %t88 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t90 = load i64, ptr %l44, !tbaa !24
  %t91 = extractvalue { i64, ptr } %t88, 0
  %t92 = mul i64 %t91, 40
  %t93 = mul i64 %t90, 40
  %t94 = extractvalue { i64, ptr } %t88, 1
  %t95 = call ptr @__olang_grow_in_place(ptr %t94, i64 %t92, i64 %t93, i64 %t90)
  %t96 = icmp ne ptr %t95, null
  %t97 = select i1 %t96, i64 %t90, i64 0
  %t98 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t95, 1
  store { i64, ptr } %t99, ptr %l47, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  %t103 = icmp ne i64 %t101, 0
  br i1 %t103, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_37d85e495f398b5e_b7b10bd71a22ca1a)
  unreachable
bb19:
  %t105 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t105, ptr %l45, !tbaa !27
  br label %bb21
bb20:
  %t106 = load i64, ptr %l44, !tbaa !24
  %t107 = mul i64 %t106, 40
  %t108 = load i64, ptr %l43
  %t109 = inttoptr i64 %t108 to ptr
  %t110 = call ptr @__olang_held_alloc(ptr %t109, i64 %t107)
  %t111 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l45, !tbaa !27
  store i64 0, ptr %l50, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb22
bb21:
  %t113 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  %t116 = icmp eq i64 %t114, 0
  br i1 %t116, label %bb28, label %bb29
bb22:
  %t118 = load i64, ptr %l6, !tbaa !24
  %t119 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t124 = icmp slt i64 %t118, %t121
  %t126 = xor i1 %t124, true
  br i1 %t126, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t128 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t128, ptr %l56, !tbaa !27
  %t129 = load i64, ptr %l6, !tbaa !24
  %t131 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f", ptr %t132, i64 %t129
  %t134 = load %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f", ptr %t133
  %t136 = load i64, ptr %l50, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f", ptr %t138, i64 %t136
  store %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f" %t134, ptr %t139
  %t140 = load i64, ptr %l50, !tbaa !24
  %t141 = add i64 %t140, 1
  store i64 %t141, ptr %l50, !tbaa !24
  br label %bb26
bb26:
  %t142 = load i64, ptr %l6, !tbaa !24
  %t145 = add i64 %t142, 1
  store i64 %t145, ptr %l6, !tbaa !24
  br label %bb22
bb27:
  br label %bb21
bb28:
  store { i64, ptr } zeroinitializer, ptr %l45, !tbaa !27
  br label %bb29
bb29:
  %t147 = load i64, ptr %l43
  %t148 = inttoptr i64 %t147 to ptr
  %t149 = load { i64, ptr }, ptr %l45
  %t150 = extractvalue { i64, ptr } %t149, 1
  %t151 = call ptr @__olang_region_or(ptr %t150, ptr null)
  %t152 = icmp ne ptr %t151, null
  %t153 = select i1 %t152, ptr %t151, ptr null
  call void @__olang_region_settle_in(ptr %t148, ptr %t153)
  %t154 = load ptr, ptr %l33, !tbaa !29
  %t155 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t154, i32 0, i32 0
  %t156 = load { i64, ptr }, ptr %t155, !tbaa !27
  store { i64, ptr } %t156, ptr %l64, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t158 = load ptr, ptr %l33, !tbaa !29
  %t159 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t158, i32 0, i32 0
  store { i64, ptr } %t157, ptr %t159, !tbaa !27
  %t160 = load { i64, ptr }, ptr %l64
  %t161 = extractvalue { i64, ptr } %t160, 0
  %t162 = extractvalue { i64, ptr } %t160, 1
  call void @__olang_region_release_part(ptr %t162, i64 %t161)
  store { i64, ptr } zeroinitializer, ptr %l64
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__H35d739c0c21f80a02d68949df7182fa4(ptr %v0, ptr noalias dereferenceable(32) align 8 %a0, i64 %a1) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l50 = alloca i64
  %l56 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  store { i64, ptr } %t56, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_a0644e714153d85d_42888b09ab519db9)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_a0644e714153d85d_42888b09ab519db9)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa", ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t85 = call ptr @__olang_region_make_part(ptr %v0)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l43, !tbaa !24
  store i64 %t83, ptr %l44, !tbaa !24
  %t88 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t90 = load i64, ptr %l44, !tbaa !24
  %t91 = extractvalue { i64, ptr } %t88, 0
  %t92 = mul i64 %t91, 8
  %t93 = mul i64 %t90, 8
  %t94 = extractvalue { i64, ptr } %t88, 1
  %t95 = call ptr @__olang_grow_in_place(ptr %t94, i64 %t92, i64 %t93, i64 %t90)
  %t96 = icmp ne ptr %t95, null
  %t97 = select i1 %t96, i64 %t90, i64 0
  %t98 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t95, 1
  store { i64, ptr } %t99, ptr %l47, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  %t103 = icmp ne i64 %t101, 0
  br i1 %t103, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_a0644e714153d85d_42888b09ab519db9)
  unreachable
bb19:
  %t105 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t105, ptr %l45, !tbaa !27
  br label %bb21
bb20:
  %t106 = load i64, ptr %l44, !tbaa !24
  %t107 = mul i64 %t106, 8
  %t108 = load i64, ptr %l43
  %t109 = inttoptr i64 %t108 to ptr
  %t110 = call ptr @__olang_held_alloc(ptr %t109, i64 %t107)
  %t111 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l45, !tbaa !27
  store i64 0, ptr %l50, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb22
bb21:
  %t113 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  %t116 = icmp eq i64 %t114, 0
  br i1 %t116, label %bb28, label %bb29
bb22:
  %t118 = load i64, ptr %l6, !tbaa !24
  %t119 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t124 = icmp slt i64 %t118, %t121
  %t126 = xor i1 %t124, true
  br i1 %t126, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t128 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t128, ptr %l56, !tbaa !27
  %t129 = load i64, ptr %l6, !tbaa !24
  %t131 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa", ptr %t132, i64 %t129
  %t134 = load %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa", ptr %t133
  %t136 = load i64, ptr %l50, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa", ptr %t138, i64 %t136
  store %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa" %t134, ptr %t139
  %t140 = load i64, ptr %l50, !tbaa !24
  %t141 = add i64 %t140, 1
  store i64 %t141, ptr %l50, !tbaa !24
  br label %bb26
bb26:
  %t142 = load i64, ptr %l6, !tbaa !24
  %t145 = add i64 %t142, 1
  store i64 %t145, ptr %l6, !tbaa !24
  br label %bb22
bb27:
  br label %bb21
bb28:
  store { i64, ptr } zeroinitializer, ptr %l45, !tbaa !27
  br label %bb29
bb29:
  %t147 = load i64, ptr %l43
  %t148 = inttoptr i64 %t147 to ptr
  %t149 = load { i64, ptr }, ptr %l45
  %t150 = extractvalue { i64, ptr } %t149, 1
  %t151 = call ptr @__olang_region_or(ptr %t150, ptr null)
  %t152 = icmp ne ptr %t151, null
  %t153 = select i1 %t152, ptr %t151, ptr null
  call void @__olang_region_settle_in(ptr %t148, ptr %t153)
  %t154 = load ptr, ptr %l33, !tbaa !29
  %t155 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t154, i32 0, i32 0
  %t156 = load { i64, ptr }, ptr %t155, !tbaa !27
  store { i64, ptr } %t156, ptr %l64, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t158 = load ptr, ptr %l33, !tbaa !29
  %t159 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t158, i32 0, i32 0
  store { i64, ptr } %t157, ptr %t159, !tbaa !27
  %t160 = load { i64, ptr }, ptr %l64
  %t161 = extractvalue { i64, ptr } %t160, 0
  %t162 = extractvalue { i64, ptr } %t160, 1
  call void @__olang_region_release_part(ptr %t162, i64 %t161)
  store { i64, ptr } zeroinitializer, ptr %l64
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cstd_2fpair_3aPair__Hdde5963b819262c422f1fdc33c052881(ptr %v0, ptr %a0, i64 %a1) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l50 = alloca i64
  %l56 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  store { i64, ptr } %t56, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_da0eadc0b216b2d9_495a75bb35cff79d)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_da0eadc0b216b2d9_495a75bb35cff79d)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr %"std/pair:Pair.b139c4f75a6545712256427180a82a06", ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t85 = call ptr @__olang_region_make_part(ptr %v0)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l43, !tbaa !24
  store i64 %t83, ptr %l44, !tbaa !24
  %t88 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t90 = load i64, ptr %l44, !tbaa !24
  %t91 = extractvalue { i64, ptr } %t88, 0
  %t92 = mul i64 %t91, 32
  %t93 = mul i64 %t90, 32
  %t94 = extractvalue { i64, ptr } %t88, 1
  %t95 = call ptr @__olang_grow_in_place(ptr %t94, i64 %t92, i64 %t93, i64 %t90)
  %t96 = icmp ne ptr %t95, null
  %t97 = select i1 %t96, i64 %t90, i64 0
  %t98 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t95, 1
  store { i64, ptr } %t99, ptr %l47, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  %t103 = icmp ne i64 %t101, 0
  br i1 %t103, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_da0eadc0b216b2d9_495a75bb35cff79d)
  unreachable
bb19:
  %t105 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t105, ptr %l45, !tbaa !27
  br label %bb21
bb20:
  %t106 = load i64, ptr %l44, !tbaa !24
  %t107 = mul i64 %t106, 32
  %t108 = load i64, ptr %l43
  %t109 = inttoptr i64 %t108 to ptr
  %t110 = call ptr @__olang_held_alloc(ptr %t109, i64 %t107)
  %t111 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l45, !tbaa !27
  store i64 0, ptr %l50, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb22
bb21:
  %t113 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  %t116 = icmp eq i64 %t114, 0
  br i1 %t116, label %bb28, label %bb29
bb22:
  %t118 = load i64, ptr %l6, !tbaa !24
  %t119 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t124 = icmp slt i64 %t118, %t121
  %t126 = xor i1 %t124, true
  br i1 %t126, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t128 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t128, ptr %l56, !tbaa !27
  %t129 = load i64, ptr %l6, !tbaa !24
  %t131 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr %"std/pair:Pair.b139c4f75a6545712256427180a82a06", ptr %t132, i64 %t129
  %t134 = load %"std/pair:Pair.b139c4f75a6545712256427180a82a06", ptr %t133
  %t136 = load i64, ptr %l50, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr %"std/pair:Pair.b139c4f75a6545712256427180a82a06", ptr %t138, i64 %t136
  store %"std/pair:Pair.b139c4f75a6545712256427180a82a06" %t134, ptr %t139
  %t140 = load i64, ptr %l50, !tbaa !24
  %t141 = add i64 %t140, 1
  store i64 %t141, ptr %l50, !tbaa !24
  br label %bb26
bb26:
  %t142 = load i64, ptr %l6, !tbaa !24
  %t145 = add i64 %t142, 1
  store i64 %t145, ptr %l6, !tbaa !24
  br label %bb22
bb27:
  br label %bb21
bb28:
  store { i64, ptr } zeroinitializer, ptr %l45, !tbaa !27
  br label %bb29
bb29:
  %t147 = load i64, ptr %l43
  %t148 = inttoptr i64 %t147 to ptr
  %t149 = load { i64, ptr }, ptr %l45
  %t150 = extractvalue { i64, ptr } %t149, 1
  %t151 = call ptr @__olang_region_or(ptr %t150, ptr null)
  %t152 = icmp ne ptr %t151, null
  %t153 = select i1 %t152, ptr %t151, ptr null
  call void @__olang_region_settle_in(ptr %t148, ptr %t153)
  %t154 = load ptr, ptr %l33, !tbaa !29
  %t155 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t154, i32 0, i32 0
  %t156 = load { i64, ptr }, ptr %t155, !tbaa !27
  store { i64, ptr } %t156, ptr %l64, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t158 = load ptr, ptr %l33, !tbaa !29
  %t159 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t158, i32 0, i32 0
  store { i64, ptr } %t157, ptr %t159, !tbaa !27
  %t160 = load { i64, ptr }, ptr %l64
  %t161 = extractvalue { i64, ptr } %t160, 0
  %t162 = extractvalue { i64, ptr } %t160, 1
  call void @__olang_region_release_part(ptr %t162, i64 %t161)
  store { i64, ptr } zeroinitializer, ptr %l64
  br label %ret
ret:
  ret void
}

declare void @__olang_check_failed(ptr) cold noreturn
declare ptr @__olang_region_make_part(ptr) noinline
declare ptr @__olang_grow_in_place(ptr, i64, i64, i64) noinline
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare ptr @__olang_region_or(ptr, ptr)
declare void @__olang_region_settle_in(ptr, ptr)
declare void @__olang_region_release_part(ptr, i64) noinline
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define linkonce_odr void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ftyped_3aContractInfo(ptr %out, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/typed:ContractInfo"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a0, i64 152, i1 false)
  %t2 = getelementptr %"compiler/typed:ContractInfo", ptr %l1, i32 0, i32 2
  %t4 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t6 = getelementptr %"compiler/typed:ContractInfo", ptr %l1, i32 0, i32 2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %t6
  %t7 = getelementptr %"compiler/typed:ContractInfo", ptr %l1, i32 0, i32 3
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t7)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l5
  br label %bb2
bb2:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t11 = getelementptr %"compiler/typed:ContractInfo", ptr %l1, i32 0, i32 3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %t11
  %t12 = getelementptr %"compiler/typed:ContractInfo", ptr %l1, i32 0, i32 4
  %t14 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aGlobalAt_3e(ptr %v0, ptr %t12)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l7
  br label %bb3
bb3:
  %t15 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  %t16 = getelementptr %"compiler/typed:ContractInfo", ptr %l1, i32 0, i32 4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %t16
  %t17 = getelementptr %"compiler/typed:ContractInfo", ptr %l1, i32 0, i32 5
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cBool_3e(ptr %v0, ptr %t17)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l9
  br label %bb4
bb4:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  %t21 = getelementptr %"compiler/typed:ContractInfo", ptr %l1, i32 0, i32 5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %t21
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l1, i64 152, i1 false)
  br label %ret
ret:
  ret void
}

@__olang_slot_chunk = external global %olang.chunk
declare void @__olang_slot_release(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aGlobalAt_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cBool_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 1
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@olang_loc_830b3f6bba02f612_9c6c608b7d8bc3c6 = external constant [0 x i8]
@olang_loc_8e2bf48a3c00500f_fc16ff27629f3ba3 = external constant [0 x i8]
@olang_loc_389970255ec35ca5_cc4215f820edb121 = external constant [0 x i8]
@olang_loc_7fe7a6e47a8c2c48_bdbca8ceda542d34 = external constant [0 x i8]
@olang_loc_117a680accd1bd6d_952794adcbbf04a9 = external constant [0 x i8]
@olang_loc_4ebc64f2fa391f90_2dc94f9b6ff22cbc = external constant [0 x i8]
@olang_loc_3ce2cd7668277ea4_65102d81f57d5250 = external constant [0 x i8]
@olang_loc_2cefd9bcafe1bf91_71cdc6677ab2692d = external constant [0 x i8]
@olang_loc_c376b69c1fb64831_2e5315ea59d0fc85 = external constant [0 x i8]
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3cI64_3e_3e_2ebucketOf_3cI64_2c_20Array_3cI64_3e_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aContractIn_H05d6b752b522b82c68261770463330a4(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3)
@olang_loc_e21ed6667868d2e6_db2b0a2c7700ea32 = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_H0ee4baf4a98f2f3ccbca9d2816c12cad(ptr %v0, ptr %a0, i64 %a1, i64 %a2, { i64, ptr } %a3)
@olang_loc_3ed90fca4b6dbcc1_e266804f8edbf6cd = external constant [0 x i8]
@olang_loc_38414063407efc54_cb5d7512ea6294f0 = external constant [0 x i8]
@olang_loc_df19f69301cf0199_32dd59e57a27f72d = external constant [0 x i8]
@olang_loc_8b28957638762ec_261fc0fff4f2e050 = external constant [0 x i8]
@olang_loc_f6e80aaea291e936_bdd0ff292b082a4a = external constant [0 x i8]
@olang_loc_f6f900c9fb154d93_6e60d926358ead27 = external constant [0 x i8]
@olang_loc_2c5412a51f90260e_61b8746bf353c102 = external constant [0 x i8]
@olang_loc_b7c452d6898a720b_ae277c99aaa8cdff = external constant [0 x i8]
@olang_loc_79842d5ccdf22f4c_100582a00b153188 = external constant [0 x i8]
@olang_loc_2652fb2e976ac379_5ebf8f5e51b7b7e5 = external constant [0 x i8]
@olang_loc_8448838d2b3ab7a7_3ecc9b11324320fb = external constant [0 x i8]
@olang_loc_d3b8a99020b434ca_99ad44d2842c9e7e = external constant [0 x i8]
@olang_loc_1f883794dd6a792d_50e0eef0cca60dd9 = external constant [0 x i8]
@olang_loc_12ca9eaf58356250_8bd357473b286e2c = external constant [0 x i8]
@olang_loc_e967a788eb8e93f4_ddbe108b1142e638 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2eisPrefixed(ptr %v0, { i64, ptr } %a0)
declare { i32, i128 } @std_2fprelude_2ftext_2ereadWide(ptr %v0, { i64, ptr } %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseUint(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare i64 @std_2fprelude_2ftext_2edigitWorth(i8 %a0)
@olang_loc_889cedfb4be9c88_a847bb62cb5e3d5c = external constant [0 x i8]
@olang_loc_2fcf5e58d82fe6ea_e31cfa2171027a4e = external constant [0 x i8]
@olang_loc_e9a8d74df752042e_6474c49741244292 = external constant [0 x i8]
@olang_loc_7273437a056ceb0e_13b0f87213b64be2 = external constant [0 x i8]
@olang_loc_196964b7e2e57a83_b433a9b2ae4a185f = external constant [0 x i8]
@olang_loc_225353c50a4292f7_c45573717a3acb3b = external constant [0 x i8]
@olang_loc_95debe88b8bc2782_9885fd785c2df526 = external constant [0 x i8]
@olang_loc_39bec683f355f06_6544abda65b44c0a = external constant [0 x i8]
@olang_loc_b7e1b3046b0c2a18_1d09df7918637084 = external constant [0 x i8]
@olang_loc_4195eed94f8745a2_18603c53a82e31e6 = external constant [0 x i8]
@olang_loc_33565fc69cd567d5_99246efc5a0cf5f1 = external constant [0 x i8]
@olang_loc_4a34131d9c5c50a8_fcf917aa64a4d72c = external constant [0 x i8]
@olang_loc_a46688ee68c12b98_9d70ef7bc9829d2c = external constant [0 x i8]
@olang_loc_272d8b19690cbcac_1110d090bfa6a438 = external constant [0 x i8]
@olang_loc_ba624bda9d604dc4_4f7e174daad6f548 = external constant [0 x i8]
@olang_loc_af8acc0ba3137456_cd77df1b40ea06ea = external constant [0 x i8]
@olang_loc_a0b4a09fb8c9f80b_755013603d945a97 = external constant [0 x i8]
@olang_loc_37d85e495f398b5e_b7b10bd71a22ca1a = external constant [0 x i8]
@olang_loc_a0644e714153d85d_42888b09ab519db9 = external constant [0 x i8]
@olang_loc_da0eadc0b216b2d9_495a75bb35cff79d = external constant [0 x i8]

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
