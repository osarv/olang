; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/mir:Lvalue" = type { { i64, [2 x i64] }, %"compiler/mir:Range" }
%"compiler/mir:Range" = type { i32, i32 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/lower:Lowerer" = type { ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i32, i32, i64, i64, i64, i64, i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/mir:GenInfo", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/mir:GenInfo" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64 }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"compiler/facts:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/facts:Table" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64 }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, i32, i1, i1 }
%"compiler/typed:LocalUses" = type { ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i32 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/lower:lowering" = type { ptr, ptr, ptr, %"compiler/mir:Fn", i32, i32, i32, i64, { i64, [4 x i64] }, i32, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, i1, { i64, [1 x i64] }, i32, { i64, [1 x i64] }, %"compiler/typed:Plan", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/typed:DropHolding", i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/mir:Fn" = type { { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:DropHolding" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1, i1 }
%"compiler/lower:pl" = type { { i64, [2 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i32 }
%"compiler/mir:Local" = type { i32, %"compiler/source:Span", i32, i32, { i64, [1 x i64] } }
%"compiler/lower:level" = type { i32, i32, i32 }
%"compiler/typed:BlockInfo" = type { i32, i32, %"compiler/source:Span" }
%"compiler/mir:ScopeInfo" = type { i32, i32, i32, %"compiler/source:Span", i32 }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr, i1 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/lower:tryCtx" = type { i64, { i64, ptr }, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Join" = type { ptr, i1, { i64, ptr } }
%"compiler/lower:loopCtx" = type { i32, i64, i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Capture" = type { i32, ptr }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32, i1 }
%"compiler/mir:Call" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Lvalue", i1, i32, i32, i32 }
%"compiler/lower:Gap" = type { i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/typed:DerivedArg" = type { i64, i64, { i64, [2 x i64] } }
%"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" = type { i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
@G_2ecompiler_2flower_2eContract = constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2flower_2eEmpty = constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2flower_2eFailIds = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\11\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailIds.k1, [8 x i8] c"\12\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailIds.k2, [8 x i8] c"\12\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailIds.k3, [8 x i8] c"\11\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailIds.k4, [8 x i8] c"\14\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailIds.k5, [8 x i8] c"\11\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailIds.k6 }>, align 64
@G_2ecompiler_2flower_2eFailIds.k1 = internal constant <{ [17 x i8] }> <{ [17 x i8] c"\73\74\64\2F\70\72\65\6C\75\64\65\2F\61\72\72\61\79" }>, align 8
@G_2ecompiler_2flower_2eFailIds.k2 = internal constant <{ [18 x i8] }> <{ [18 x i8] c"\73\74\64\2F\70\72\65\6C\75\64\65\2F\6E\75\6D\62\65\72" }>, align 8
@G_2ecompiler_2flower_2eFailIds.k3 = internal constant <{ [18 x i8] }> <{ [18 x i8] c"\73\74\64\2F\70\72\65\6C\75\64\65\2F\6E\75\6D\62\65\72" }>, align 8
@G_2ecompiler_2flower_2eFailIds.k4 = internal constant <{ [17 x i8] }> <{ [17 x i8] c"\73\74\64\2F\70\72\65\6C\75\64\65\2F\65\6E\75\6D\73" }>, align 8
@G_2ecompiler_2flower_2eFailIds.k5 = internal constant <{ [20 x i8] }> <{ [20 x i8] c"\73\74\64\2F\70\72\65\6C\75\64\65\2F\61\72\67\75\6D\65\6E\74" }>, align 8
@G_2ecompiler_2flower_2eFailIds.k6 = internal constant <{ [17 x i8] }> <{ [17 x i8] c"\73\74\64\2F\70\72\65\6C\75\64\65\2F\61\72\72\61\79" }>, align 8
@G_2ecompiler_2flower_2eFailTypes = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\0A\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailTypes.k1, [8 x i8] c"\0B\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailTypes.k2, [8 x i8] c"\0B\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailTypes.k3, [8 x i8] c"\09\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailTypes.k4, [8 x i8] c"\0D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailTypes.k5, [8 x i8] c"\0A\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailTypes.k6 }>, align 64
@G_2ecompiler_2flower_2eFailTypes.k1 = internal constant <{ [10 x i8] }> <{ [10 x i8] c"\41\72\72\61\79\45\72\72\6F\72" }>, align 8
@G_2ecompiler_2flower_2eFailTypes.k2 = internal constant <{ [11 x i8] }> <{ [11 x i8] c"\4E\75\6D\62\65\72\45\72\72\6F\72" }>, align 8
@G_2ecompiler_2flower_2eFailTypes.k3 = internal constant <{ [11 x i8] }> <{ [11 x i8] c"\4E\75\6D\62\65\72\45\72\72\6F\72" }>, align 8
@G_2ecompiler_2flower_2eFailTypes.k4 = internal constant <{ [9 x i8] }> <{ [9 x i8] c"\43\61\73\65\45\72\72\6F\72" }>, align 8
@G_2ecompiler_2flower_2eFailTypes.k5 = internal constant <{ [13 x i8] }> <{ [13 x i8] c"\41\72\67\75\6D\65\6E\74\45\72\72\6F\72" }>, align 8
@G_2ecompiler_2flower_2eFailTypes.k6 = internal constant <{ [10 x i8] }> <{ [10 x i8] c"\41\72\72\61\79\45\72\72\6F\72" }>, align 8
@G_2ecompiler_2flower_2eFailWords = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\0A\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailWords.k1, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailWords.k2, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailWords.k3, [8 x i8] c"\09\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailWords.k4, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailWords.k5, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailWords.k6 }>, align 64
@G_2ecompiler_2flower_2eFailWords.k1 = internal constant <{ [10 x i8] }> <{ [10 x i8] c"\4F\75\74\4F\66\52\61\6E\67\65" }>, align 8
@G_2ecompiler_2flower_2eFailWords.k2 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\4F\76\65\72\66\6C\6F\77" }>, align 8
@G_2ecompiler_2flower_2eFailWords.k3 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\49\6E\76\61\6C\69\64" }>, align 8
@G_2ecompiler_2flower_2eFailWords.k4 = internal constant <{ [9 x i8] }> <{ [9 x i8] c"\57\72\6F\6E\67\43\61\73\65" }>, align 8
@G_2ecompiler_2flower_2eFailWords.k5 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\49\6E\76\61\6C\69\64" }>, align 8
@G_2ecompiler_2flower_2eFailWords.k6 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\45\6D\70\74\79" }>, align 8
@G_2ecompiler_2flower_2eInvalid = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2flower_2eOutOfBounds = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2flower_2eOverflow = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2flower_2eSlotMax = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\01\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2flower_2eWrongCase = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
define dso_local i64 @compiler_2flower_2ebaseLocal(%"compiler/mir:Lvalue" %a0) #0 {
entry:
  %l0 = alloca %"compiler/mir:Lvalue"
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i32
  %l4 = alloca i64
  %rv = alloca i64
  store %"compiler/mir:Lvalue" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/mir:Lvalue", ptr %l0, i32 0, i32 0
  %t2 = load { i64, [2 x i64] }, ptr %t1
  store { i64, [2 x i64] } %t2, ptr %l1
  %t4 = load { i64, [2 x i64] }, ptr %l1
  %t6 = extractvalue { i64, [2 x i64] } %t4, 0
  %t7 = icmp eq i64 %t6, 1
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t10 = getelementptr { i32 }, ptr %t9, i32 0, i32 0
  %t11 = load i32, ptr %t10
  store i32 %t11, ptr %l2, !tbaa !23
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t13 = load i32, ptr %l2, !tbaa !23
  %t15 = sext i32 %t13 to i64
  store i64 %t15, ptr %l4, !tbaa !24
  br label %bb9
bb4:
  br i1 true, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i64 -1, ptr %l4, !tbaa !24
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_e95d68e3d7cba01a_696ee7b39c9f410e)
  unreachable
bb9:
  %t17 = load i64, ptr %l4, !tbaa !24
  store i64 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2flower_2eborrowedPlace(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l2, !tbaa !29
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store ptr null, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_76ec7e11cc604d77_65dfbe8f138a0f63)
  unreachable
bb11:
  %t19 = load ptr, ptr %l2, !tbaa !29
  store ptr %t19, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eDecideDerived(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l10 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l37 = alloca { i64, ptr }
  %l39 = alloca i1
  %l43 = alloca ptr
  %l44 = alloca { i64, ptr }
  %l48 = alloca %"compiler/typed:Plan"
  %l50 = alloca %"compiler/typed:Plan"
  %l52 = alloca i64
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %t76 = alloca %"compiler/typed:Plan", align 8
  %t79 = alloca %"compiler/typed:Plan", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %t1, i32 0, i32 2
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eLen_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i64, ptr %l10, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load i64, ptr %l1, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l3, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l2, !tbaa !24
  %t18 = load i64, ptr %l1, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l17, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l17, !tbaa !24
  store i64 %t33, ptr %l14, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l14, !tbaa !24
  store i64 %t34, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i64, ptr %l5, !tbaa !24
  %t36 = load i64, ptr %l4, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l1, !tbaa !24
  %t44 = load i64, ptr %l5, !tbaa !24
  %t45 = load i64, ptr %l3, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l6, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load i64, ptr %l6, !tbaa !24
  %t57 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3aLowerer_2ederivedFact(ptr %v0, ptr %s2, ptr %t53, i64 %t54)
  store { i64, ptr } %t57, ptr %l37
  br label %bb12
bb12:
  %t58 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t58, ptr %l7, !tbaa !27
  %t59 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t61 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t59, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i1 %t61, ptr %l39
  br label %bb13
bb13:
  %t62 = load i1, ptr %l39, !tbaa !21
  %t63 = xor i1 %t62, true
  br i1 %t63, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/lower:Lowerer", ptr %t65, i32 0, i32 0
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = getelementptr %"compiler/generic:Program", ptr %t68, i32 0, i32 3
  store ptr %t70, ptr %l43, !tbaa !29
  %t71 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t71, ptr %l44, !tbaa !27
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/lower:Lowerer", ptr %t72, i32 0, i32 2
  %t75 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %t76, ptr %v0, ptr %v0, ptr %t74, i64 %t75)
  call void @llvm.memmove.p0.p0.i64(ptr %l48, ptr %t76, i64 536, i1 false)
  br label %bb16
bb15:
  br label %bb20
bb16:
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ftyped_3aPlan(ptr %t79, ptr %v0, ptr %l48)
  call void @llvm.memmove.p0.p0.i64(ptr %l50, ptr %t79, i64 536, i1 false)
  br label %bb17
bb17:
  %t81 = getelementptr %"compiler/typed:Plan", ptr %l50, i32 0, i32 15
  %t83 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t81)
  store i64 %t83, ptr %l52
  br label %bb18
bb18:
  %t84 = load i64, ptr %l52, !tbaa !24
  %t85 = call i64 @__olang_fmt_i64(ptr null, i64 %t84)
  %t86 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t85)
  %t87 = call i64 @__olang_fmt_i64(ptr %t86, i64 %t84)
  %t88 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t86, 1
  %t91 = extractvalue { i64, ptr } %t89, 0
  %t92 = extractvalue { i64, ptr } %t89, 1
  %t93 = mul i64 %t91, 1
  %t94 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t93)
  call void @llvm.memcpy.p0.p0.i64(ptr %t94, ptr %t92, i64 %t93, i1 false)
  %t95 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t94, 1
  %t97 = load ptr, ptr %l43, !tbaa !29
  %t98 = load { i64, ptr }, ptr %l44, !tbaa !27
  call void @compiler_2ffacts_2ecompiler_2ffacts_3aTable_2eDecide(ptr %v0, ptr %s2, ptr %s3, ptr %t97, { i64, ptr } %t98, { i64, ptr } %t96, i1 false)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb21:
  %t100 = load i64, ptr %l5, !tbaa !24
  %t102 = add i64 %t100, 1
  store i64 %t102, ptr %l5, !tbaa !24
  br label %bb8
bb22:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2flower_2ecompiler_2flower_3aLowerer_2eT(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i32, { { i64, ptr }, { i64, ptr } } } @compiler_2flower_2ecompiler_2flower_3aLowerer_2eVerified(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %lp4 = alloca ptr
  %l8 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l28 = alloca { { i64, ptr }, { i64, ptr } }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i32, { { i64, ptr }, { i64, ptr } } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call ptr @compiler_2flower_2ecompiler_2flower_3aLowerer_2eLower(ptr %v0, ptr %v0, ptr %t1, i64 %a1)
  store ptr %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l8, !tbaa !29
  store ptr %t6, ptr %l3, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/lower:Lowerer", ptr %t7, i32 0, i32 7
  %t10 = load i1, ptr %t9, !tbaa !21
  br i1 %t10, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t13 = insertvalue { i32, { { i64, ptr }, { i64, ptr } } } zeroinitializer, i32 65536, 0
  store { i32, { { i64, ptr }, { i64, ptr } } } %t13, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l3, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/lower:Lowerer", ptr %t15, i32 0, i32 0
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/generic:Program", ptr %t18, i32 0, i32 2
  %t23 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eVerify(ptr %v0, ptr %v0, ptr %v1, ptr %t14, ptr %t20)
  store { i64, ptr } %t23, ptr %l16
  br label %bb5
bb5:
  %t24 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t24, ptr %lp4
  %t25 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t26 = load ptr, ptr %lp4
  store { i64, ptr } %t25, ptr %t26, !tbaa !27
  br i1 %a2, label %bb6, label %bb7
bb6:
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/lower:Lowerer", ptr %t30, i32 0, i32 0
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/generic:Program", ptr %t33, i32 0, i32 2
  %t38 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eDump(ptr %v0, ptr %v0, ptr %s0, ptr %t29, ptr %t35)
  store { i64, ptr } %t38, ptr %l23
  br label %bb8
bb7:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l18, !tbaa !27
  br label %bb9
bb8:
  %t39 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  %t41 = extractvalue { i64, ptr } %t39, 1
  %t42 = mul i64 %t40, 1
  %t43 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t42)
  call void @llvm.memcpy.p0.p0.i64(ptr %t43, ptr %t41, i64 %t42, i1 false)
  %t44 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l18, !tbaa !27
  br label %bb9
bb9:
  %t47 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t48 = load ptr, ptr %lp4
  %t49 = load { i64, ptr }, ptr %t48, !tbaa !27
  %t53 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t49, 0
  %t55 = insertvalue { { i64, ptr }, { i64, ptr } } %t53, { i64, ptr } %t47, 1
  store { { i64, ptr }, { i64, ptr } } %t55, ptr %l28
  %t56 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l28, i32 0, i32 1
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  store { i64, ptr } %t57, ptr %l29, !tbaa !27
  %t58 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t58, 0
  store i64 %t59, ptr %l30, !tbaa !24
  %t60 = load i64, ptr %l30, !tbaa !24
  %t61 = mul i64 %t60, 1
  %t62 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t61)
  %t63 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  store { i64, ptr } %t64, ptr %l31, !tbaa !27
  %t65 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = load i64, ptr %l30, !tbaa !24
  %t70 = mul i64 %t69, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t66, ptr %t68, i64 %t70, i1 false)
  %t71 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t72 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l28, i32 0, i32 1
  store { i64, ptr } %t71, ptr %t72, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t73 = load { { i64, ptr }, { i64, ptr } }, ptr %l28
  %t74 = insertvalue { i32, { { i64, ptr }, { i64, ptr } } } zeroinitializer, { { i64, ptr }, { i64, ptr } } %t73, 1
  store { i32, { { i64, ptr }, { i64, ptr } } } %t74, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { { i64, ptr }, { i64, ptr } } }, ptr %rv
  ret { i32, { { i64, ptr }, { i64, ptr } } } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eWant(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l5 = alloca i1
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %t1, i32 0, i32 12
  %t4 = load { i64, [2 x i64] }, ptr %l1
  %t7 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_Hf0a5beca6f8aee4731a76bd327ae0a99(ptr %v0, ptr %t3, { i64, [2 x i64] } %t4)
  store i1 %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = load i1, ptr %l5, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/lower:Lowerer", ptr %t9, i32 0, i32 12
  %t12 = load { i64, [2 x i64] }, ptr %l1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_He6968003b8dd5762fa82ec44b4ee1fc9(ptr %v0, ptr %t11, { i64, [2 x i64] } %t12, i1 true)
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/lower:Lowerer", ptr %t15, i32 0, i32 11
  %t18 = load { i64, [2 x i64] }, ptr %l1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %t17, { i64, [2 x i64] } %t18)
  br label %bb6
bb6:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2flower_2ecompiler_2flower_3aLowerer_2edeclName(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l10 = alloca i64
  %l13 = alloca i1
  %l14 = alloca i64
  %l19 = alloca i64
  %l21 = alloca { i64, ptr }
  %l27 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l40 = alloca i32
  %l42 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i64, ptr %l1, !tbaa !24
  %t9 = trunc i64 %t7 to i32
  %t13 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t6, i32 %t9)
  store i64 %t13, ptr %l10
  br label %bb1
bb1:
  %t14 = load i64, ptr %l10, !tbaa !24
  store i64 %t14, ptr %l2, !tbaa !24
  %t15 = load i64, ptr %l2, !tbaa !24
  %t17 = icmp sge i64 %t15, 0
  br i1 %t17, label %bb2, label %bb3
bb2:
  %t19 = load i64, ptr %l2, !tbaa !24
  store i64 %t19, ptr %l14, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/lower:Lowerer", ptr %t20, i32 0, i32 0
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 0
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/load:Loader", ptr %t26, i32 0, i32 10
  %t30 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t28)
  store i64 %t30, ptr %l19
  br label %bb4
bb3:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb5
bb4:
  %t31 = load i64, ptr %l14, !tbaa !24
  %t32 = load i64, ptr %l19, !tbaa !24
  %t33 = icmp slt i64 %t31, %t32
  store i1 %t33, ptr %l13, !tbaa !21
  br label %bb5
bb5:
  %t35 = load i1, ptr %l13, !tbaa !21
  br i1 %t35, label %bb6, label %bb7
bb6:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/lower:Lowerer", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = getelementptr %"compiler/generic:Program", ptr %t39, i32 0, i32 0
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = getelementptr %"compiler/load:Loader", ptr %t42, i32 0, i32 10
  %t45 = load i64, ptr %l2, !tbaa !24
  %t48 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t44, i64 %t45)
  store ptr %t48, ptr %l27
  br label %bb8
bb7:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, ptr %l21, !tbaa !27
  br label %bb9
bb8:
  %t49 = load ptr, ptr %l27, !tbaa !29
  %t51 = getelementptr %"compiler/load:Module", ptr %t49, i32 0, i32 2
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  store { i64, ptr } %t52, ptr %l21, !tbaa !27
  br label %bb9
bb9:
  %t54 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t54, ptr %l30, !tbaa !27
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/lower:Lowerer", ptr %t56, i32 0, i32 0
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 2
  %t62 = getelementptr %"compiler/types:Table", ptr %t61, i32 0, i32 0
  %t63 = load ptr, ptr %t62, !tbaa !29
  store ptr %t63, ptr %l33, !tbaa !29
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/lower:Lowerer", ptr %t64, i32 0, i32 0
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  %t70 = load i64, ptr %l1, !tbaa !24
  %t72 = trunc i64 %t70 to i32
  %t76 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t69, i32 %t72)
  store i32 %t76, ptr %l40
  br label %bb10
bb10:
  %t77 = load ptr, ptr %l33, !tbaa !29
  %t78 = call ptr @__olang_scope_of(ptr %t77, ptr null)
  %t79 = ptrtoint ptr %t78 to i64
  %t81 = inttoptr i64 %t79 to ptr
  %t82 = load ptr, ptr %l33, !tbaa !29
  %t83 = load i32, ptr %l40, !tbaa !23
  %t84 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %t81, ptr %s0, ptr %t82, i32 %t83)
  store { i64, ptr } %t84, ptr %l42
  br label %bb11
bb11:
  %t85 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 1
  %t87 = extractvalue { i64, ptr } %t85, 0
  %t88 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t89 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t90 = add i64 %t87, %t89
  %t91 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t91, 1
  %t93 = extractvalue { i64, ptr } %t91, 0
  %t94 = add i64 %t90, %t93
  %t95 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t94)
  call void @olang_textcopy(ptr %t95, ptr %t86, i64 %t87)
  %t96 = getelementptr i8, ptr %t95, i64 %t87
  call void @olang_textcopy(ptr %t96, ptr %t88, i64 %t89)
  %t97 = getelementptr i8, ptr %t96, i64 %t89
  call void @olang_textcopy(ptr %t97, ptr %t92, i64 %t93)
  %t98 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t95, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t99, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2efreshRet(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l21 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l32 = alloca i1
  %l36 = alloca i1
  %l40 = alloca { i64, ptr }
  %l42 = alloca i1
  %l43 = alloca ptr
  %l44 = alloca i1
  %l53 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca i1
  %l65 = alloca i1
  %l66 = alloca ptr
  %l68 = alloca i64
  %l69 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca i1
  %l76 = alloca i1
  %l77 = alloca ptr
  %l78 = alloca i1
  %l88 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l3, !tbaa !29
  store ptr %t1, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t2 = load ptr, ptr %l12, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l12, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 5
  store i1 %t8, ptr %l13, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l13, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l4, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l4, !tbaa !29
  %t19 = getelementptr %"compiler/typed:Promote", ptr %t17, i32 0, i32 0
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t23 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2efreshMade(ptr %v0, ptr %v3, ptr %t16, ptr %t20)
  store i1 %t23, ptr %l21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l21, !tbaa !21
  store i1 %t24, ptr %l11, !tbaa !21
  br label %bb63
bb7:
  %t25 = load ptr, ptr %l3, !tbaa !29
  store ptr %t25, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t26 = load ptr, ptr %l22, !tbaa !29
  %t27 = icmp ne ptr %t26, null
  br i1 %t27, label %bb8, label %bb9
bb8:
  %t29 = load ptr, ptr %l22, !tbaa !29
  %t30 = load i64, ptr %t29, !range !{i64 0, i64 18}
  %t32 = icmp eq i64 %t30, 9
  store i1 %t32, ptr %l23, !tbaa !21
  br label %bb9
bb9:
  %t33 = load i1, ptr %l23, !tbaa !21
  br i1 %t33, label %bb10, label %bb11
bb10:
  %t34 = load ptr, ptr %l3, !tbaa !29
  %t36 = getelementptr { i64, [5 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t36, i32 0, i32 2
  %t38 = load i32, ptr %t37, !range !{i32 0, i32 52}
  store i32 %t38, ptr %l5
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t42 = getelementptr { i64, [5 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t42, i32 0, i32 4
  %t44 = load { i64, ptr }, ptr %t43
  store { i64, ptr } %t44, ptr %l6, !tbaa !27
  br label %bb12
bb11:
  br label %bb20
bb12:
  %t46 = load i32, ptr %l5, !range !{i32 0, i32 52}
  %t48 = trunc i64 20 to i32
  %t49 = icmp eq i32 %t46, %t48
  br i1 %t49, label %bb13, label %bb14
bb13:
  %t51 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t51, 0
  %t55 = icmp eq i64 %t53, 1
  store i1 %t55, ptr %l32, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb15
bb15:
  %t57 = load i1, ptr %l32, !tbaa !21
  br i1 %t57, label %bb16, label %bb17
bb16:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t60 = load ptr, ptr %l2, !tbaa !29
  %t61 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t61, ptr %l40, !tbaa !27
  %t62 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr ptr, ptr %t63, i64 0
  %t65 = load ptr, ptr %t64, !tbaa !39
  %t70 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2efreshRet(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t58, ptr %t59, ptr %t60, ptr %t65)
  store i1 %t70, ptr %l42
  br label %bb18
bb17:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb19
bb18:
  %t71 = load i1, ptr %l42, !tbaa !21
  store i1 %t71, ptr %l36, !tbaa !21
  br label %bb19
bb19:
  %t72 = load i1, ptr %l36, !tbaa !21
  store i1 %t72, ptr %l11, !tbaa !21
  br label %bb63
bb20:
  %t73 = load ptr, ptr %l3, !tbaa !29
  store ptr %t73, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t74 = load ptr, ptr %l43, !tbaa !29
  %t75 = icmp ne ptr %t74, null
  br i1 %t75, label %bb21, label %bb22
bb21:
  %t77 = load ptr, ptr %l43, !tbaa !29
  %t78 = load i64, ptr %t77, !range !{i64 0, i64 18}
  %t80 = icmp eq i64 %t78, 17
  store i1 %t80, ptr %l44, !tbaa !21
  br label %bb22
bb22:
  %t81 = load i1, ptr %l44, !tbaa !21
  br i1 %t81, label %bb23, label %bb24
bb23:
  %t82 = load ptr, ptr %l3, !tbaa !29
  %t84 = getelementptr { i64, [5 x i64] }, ptr %t82, i32 0, i32 1
  %t85 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t84, i32 0, i32 2
  %t86 = load ptr, ptr %t85
  store ptr %t86, ptr %l7, !tbaa !29
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load ptr, ptr %l1, !tbaa !29
  %t90 = load ptr, ptr %l2, !tbaa !29
  %t91 = load ptr, ptr %l7, !tbaa !29
  %t96 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2efreshRet(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t88, ptr %t89, ptr %t90, ptr %t91)
  store i1 %t96, ptr %l53
  br label %bb26
bb26:
  %t97 = load i1, ptr %l53, !tbaa !21
  store i1 %t97, ptr %l11, !tbaa !21
  br label %bb63
bb27:
  %t98 = load ptr, ptr %l3, !tbaa !29
  store ptr %t98, ptr %l54, !tbaa !29
  store i1 false, ptr %l55, !tbaa !21
  %t99 = load ptr, ptr %l54, !tbaa !29
  %t100 = icmp ne ptr %t99, null
  br i1 %t100, label %bb28, label %bb29
bb28:
  %t102 = load ptr, ptr %l54, !tbaa !29
  %t103 = load i64, ptr %t102, !range !{i64 0, i64 18}
  %t105 = icmp eq i64 %t103, 6
  store i1 %t105, ptr %l55, !tbaa !21
  br label %bb29
bb29:
  %t106 = load i1, ptr %l55, !tbaa !21
  br i1 %t106, label %bb30, label %bb31
bb30:
  %t107 = load ptr, ptr %l3, !tbaa !29
  %t109 = getelementptr { i64, [5 x i64] }, ptr %t107, i32 0, i32 1
  %t110 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t109, i32 0, i32 2
  %t111 = load ptr, ptr %t110
  store ptr %t111, ptr %l8, !tbaa !29
  br label %bb32
bb31:
  br label %bb40
bb32:
  %t113 = load ptr, ptr %l8, !tbaa !29
  %t115 = getelementptr %"compiler/typed:Call", ptr %t113, i32 0, i32 0
  %t116 = load ptr, ptr %t115, !tbaa !29
  store ptr %t116, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t117 = load ptr, ptr %l61, !tbaa !29
  %t118 = icmp ne ptr %t117, null
  br i1 %t118, label %bb33, label %bb34
bb33:
  %t120 = load ptr, ptr %l61, !tbaa !29
  %t121 = load i64, ptr %t120, !range !{i64 0, i64 5}
  %t123 = icmp eq i64 %t121, 0
  store i1 %t123, ptr %l62, !tbaa !21
  br label %bb34
bb34:
  %t124 = load i1, ptr %l62, !tbaa !21
  br i1 %t124, label %bb35, label %bb36
bb35:
  %t125 = load ptr, ptr %l0, !tbaa !29
  store ptr %t125, ptr %l66, !tbaa !29
  %t126 = load ptr, ptr %l8, !tbaa !29
  %t128 = call i64 @compiler_2ftyped_2eCalleeBody(ptr %v3, ptr %t126)
  store i64 %t128, ptr %l68
  br label %bb37
bb36:
  store i1 false, ptr %l65, !tbaa !21
  br label %bb39
bb37:
  %t129 = load ptr, ptr %l66, !tbaa !29
  %t130 = load i64, ptr %l68, !tbaa !24
  %t131 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2efreshResult(ptr %v0, ptr %t129, i64 %t130)
  store i1 %t131, ptr %l69
  br label %bb38
bb38:
  %t132 = load i1, ptr %l69, !tbaa !21
  store i1 %t132, ptr %l65, !tbaa !21
  br label %bb39
bb39:
  %t133 = load i1, ptr %l65, !tbaa !21
  store i1 %t133, ptr %l11, !tbaa !21
  br label %bb63
bb40:
  %t134 = load ptr, ptr %l3, !tbaa !29
  store ptr %t134, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t135 = load ptr, ptr %l70, !tbaa !29
  %t136 = icmp ne ptr %t135, null
  br i1 %t136, label %bb41, label %bb42
bb41:
  %t138 = load ptr, ptr %l70, !tbaa !29
  %t139 = load i64, ptr %t138, !range !{i64 0, i64 18}
  %t141 = icmp eq i64 %t139, 2
  store i1 %t141, ptr %l71, !tbaa !21
  br label %bb42
bb42:
  %t142 = load i1, ptr %l71, !tbaa !21
  br i1 %t142, label %bb43, label %bb44
bb43:
  %t143 = load ptr, ptr %l3, !tbaa !29
  %t145 = getelementptr { i64, [5 x i64] }, ptr %t143, i32 0, i32 1
  %t146 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t145, i32 0, i32 2
  %t147 = load ptr, ptr %t146
  store ptr %t147, ptr %l9, !tbaa !29
  br label %bb45
bb44:
  br label %bb58
bb45:
  %t149 = load ptr, ptr %l9, !tbaa !29
  store ptr %t149, ptr %l77, !tbaa !29
  store i1 false, ptr %l78, !tbaa !21
  %t150 = load ptr, ptr %l77, !tbaa !29
  %t151 = icmp ne ptr %t150, null
  br i1 %t151, label %bb46, label %bb47
bb46:
  %t153 = load ptr, ptr %l77, !tbaa !29
  %t154 = load i64, ptr %t153, !range !{i64 0, i64 8}
  %t156 = icmp eq i64 %t154, 0
  store i1 %t156, ptr %l78, !tbaa !21
  br label %bb47
bb47:
  %t157 = load i1, ptr %l78, !tbaa !21
  br i1 %t157, label %bb48, label %bb49
bb48:
  %t158 = load ptr, ptr %l9, !tbaa !29
  %t160 = getelementptr { i64, [4 x i64] }, ptr %t158, i32 0, i32 1
  %t161 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t160, i32 0, i32 2
  %t162 = load i32, ptr %t161
  store i32 %t162, ptr %l10, !tbaa !23
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load ptr, ptr %l1, !tbaa !29
  %t166 = load ptr, ptr %l2, !tbaa !29
  %t167 = load i32, ptr %l10, !tbaa !23
  %t169 = sext i32 %t167 to i64
  %t174 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2efreshLocal(ptr %v0, ptr %v1, ptr %v2, ptr %t164, ptr %t165, ptr %t166, i64 %t169)
  store i1 %t174, ptr %l88
  br label %bb51
bb51:
  %t175 = load i1, ptr %l88, !tbaa !21
  store i1 %t175, ptr %l76, !tbaa !21
  br label %bb57
bb52:
  br i1 true, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb56
bb55:
  store i1 false, ptr %l76, !tbaa !21
  br label %bb57
bb56:
  call void @__olang_check_failed(ptr @olang_loc_7e98ebbcfc7ae681_fbeaec9fd6de6485)
  unreachable
bb57:
  %t176 = load i1, ptr %l76, !tbaa !21
  store i1 %t176, ptr %l11, !tbaa !21
  br label %bb63
bb58:
  br i1 true, label %bb59, label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb62
bb61:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb63
bb62:
  call void @__olang_check_failed(ptr @olang_loc_80862e2151cf42f0_7c300e18841fcdd4)
  unreachable
bb63:
  %t177 = load i1, ptr %l11, !tbaa !21
  store i1 %t177, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ekeepsNothing(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/typed:LocalUses"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l20 = alloca i1
  %l21 = alloca i64
  %l24 = alloca i64
  %l31 = alloca %"compiler/typed:LocalUses"
  %l35 = alloca i32
  %l39 = alloca i1
  %l40 = alloca i1
  %l43 = alloca i1
  %l46 = alloca i64
  %l50 = alloca i64
  %l53 = alloca i64
  %l73 = alloca i64
  %l80 = alloca i64
  %l84 = alloca i64
  %l87 = alloca i64
  %l107 = alloca i64
  %l110 = alloca i1
  %l111 = alloca ptr
  %l114 = alloca i64
  %l117 = alloca i64
  %l118 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  %t27 = alloca %"compiler/typed:LocalUses", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Body", ptr %t1, i32 0, i32 11
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb4
bb2:
  %t8 = load i64, ptr %l2, !tbaa !24
  store i64 %t8, ptr %l21, !tbaa !24
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Body", ptr %t9, i32 0, i32 5
  %t13 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v1, ptr %t11)
  store i64 %t13, ptr %l24
  br label %bb3
bb3:
  %t14 = load i64, ptr %l21, !tbaa !24
  %t15 = load i64, ptr %l24, !tbaa !24
  %t16 = icmp sge i64 %t14, %t15
  store i1 %t16, ptr %l20, !tbaa !21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l20, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/lower:Lowerer", ptr %t20, i32 0, i32 0
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 2
  %t26 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ftyped_2eLocalUses_2eUses(ptr %t27, ptr %v0, ptr %v1, ptr %s0, ptr %t25, ptr %t26)
  call void @llvm.memmove.p0.p0.i64(ptr %l31, ptr %t27, i64 704, i1 false)
  br label %bb8
bb8:
  call void @llvm.memmove.p0.p0.i64(ptr %l3, ptr %l31, i64 704, i1 false)
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Body", ptr %t30, i32 0, i32 5
  %t33 = load i64, ptr %l2, !tbaa !24
  %t36 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v1, ptr %t32, i64 %t33)
  store i32 %t36, ptr %l35
  br label %bb9
bb9:
  %t37 = load i32, ptr %l35, !tbaa !23
  %t38 = sext i32 %t37 to i64
  store i64 %t38, ptr %l4, !tbaa !24
  %t40 = getelementptr %"compiler/typed:LocalUses", ptr %l3, i32 0, i32 5
  %t41 = load i64, ptr %l4, !tbaa !24
  %t44 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %s0, ptr %t40, i64 %t41)
  store i1 %t44, ptr %l39
  br label %bb10
bb10:
  %t45 = load i1, ptr %l39, !tbaa !21
  br i1 %t45, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb14
bb12:
  %t46 = getelementptr %"compiler/typed:LocalUses", ptr %l3, i32 0, i32 7
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %s0, ptr %t46, i64 %t47)
  store i1 %t50, ptr %l43
  br label %bb13
bb13:
  %t51 = load i1, ptr %l43, !tbaa !21
  store i1 %t51, ptr %l40, !tbaa !21
  br label %bb14
bb14:
  %t52 = load i1, ptr %l40, !tbaa !21
  br i1 %t52, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  store i64 0, ptr %l5, !tbaa !24
  %t54 = getelementptr %"compiler/typed:LocalUses", ptr %l3, i32 0, i32 8
  %t56 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t54)
  store i64 %t56, ptr %l46
  br label %bb18
bb18:
  %t57 = load i64, ptr %l46, !tbaa !24
  store i64 %t57, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t58 = load i64, ptr %l6, !tbaa !24
  %t59 = load i64, ptr %l5, !tbaa !24
  %t62 = icmp sgt i64 %t58, %t59
  br i1 %t62, label %bb19, label %bb20
bb19:
  %t64 = load i64, ptr %l7, !tbaa !24
  %t66 = icmp sgt i64 %t64, 0
  br i1 %t66, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l50, !tbaa !24
  br label %bb24
bb21:
  %t68 = load i64, ptr %l6, !tbaa !24
  %t69 = load i64, ptr %l5, !tbaa !24
  %t72 = sub i64 %t68, %t69
  %t73 = load i64, ptr %l7, !tbaa !24
  %t76 = add i64 %t72, %t73
  %t78 = sub i64 %t76, 1
  %t79 = load i64, ptr %l7, !tbaa !24
  %t82 = sdiv i64 %t78, %t79
  store i64 %t82, ptr %l53, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l53, !tbaa !24
  br label %bb23
bb23:
  %t84 = load i64, ptr %l53, !tbaa !24
  store i64 %t84, ptr %l50, !tbaa !24
  br label %bb24
bb24:
  %t85 = load i64, ptr %l50, !tbaa !24
  store i64 %t85, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb25
bb25:
  %t86 = load i64, ptr %l9, !tbaa !24
  %t87 = load i64, ptr %l8, !tbaa !24
  %t90 = icmp slt i64 %t86, %t87
  %t92 = xor i1 %t90, true
  br i1 %t92, label %bb26, label %bb27
bb26:
  br label %bb34
bb27:
  br label %bb28
bb28:
  %t94 = load i64, ptr %l5, !tbaa !24
  %t95 = load i64, ptr %l9, !tbaa !24
  %t96 = load i64, ptr %l7, !tbaa !24
  %t99 = mul i64 %t95, %t96
  %t102 = add i64 %t94, %t99
  %t104 = getelementptr %"compiler/typed:LocalUses", ptr %l3, i32 0, i32 8
  %t108 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t104, i64 %t102)
  store i64 %t108, ptr %l73
  br label %bb29
bb29:
  %t109 = load i64, ptr %l4, !tbaa !24
  %t110 = load i64, ptr %l73, !tbaa !24
  %t112 = icmp eq i64 %t110, %t109
  br i1 %t112, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t115 = load i64, ptr %l9, !tbaa !24
  %t117 = add i64 %t115, 1
  store i64 %t117, ptr %l9, !tbaa !24
  br label %bb25
bb34:
  store i64 0, ptr %l11, !tbaa !24
  %t119 = getelementptr %"compiler/typed:LocalUses", ptr %l3, i32 0, i32 12
  %t121 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t119)
  store i64 %t121, ptr %l80
  br label %bb35
bb35:
  %t122 = load i64, ptr %l80, !tbaa !24
  store i64 %t122, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t123 = load i64, ptr %l12, !tbaa !24
  %t124 = load i64, ptr %l11, !tbaa !24
  %t127 = icmp sgt i64 %t123, %t124
  br i1 %t127, label %bb36, label %bb37
bb36:
  %t129 = load i64, ptr %l13, !tbaa !24
  %t131 = icmp sgt i64 %t129, 0
  br i1 %t131, label %bb38, label %bb39
bb37:
  store i64 0, ptr %l84, !tbaa !24
  br label %bb41
bb38:
  %t133 = load i64, ptr %l12, !tbaa !24
  %t134 = load i64, ptr %l11, !tbaa !24
  %t137 = sub i64 %t133, %t134
  %t138 = load i64, ptr %l13, !tbaa !24
  %t141 = add i64 %t137, %t138
  %t143 = sub i64 %t141, 1
  %t144 = load i64, ptr %l13, !tbaa !24
  %t147 = sdiv i64 %t143, %t144
  store i64 %t147, ptr %l87, !tbaa !24
  br label %bb40
bb39:
  store i64 0, ptr %l87, !tbaa !24
  br label %bb40
bb40:
  %t149 = load i64, ptr %l87, !tbaa !24
  store i64 %t149, ptr %l84, !tbaa !24
  br label %bb41
bb41:
  %t150 = load i64, ptr %l84, !tbaa !24
  store i64 %t150, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb42
bb42:
  %t151 = load i64, ptr %l15, !tbaa !24
  %t152 = load i64, ptr %l14, !tbaa !24
  %t155 = icmp slt i64 %t151, %t152
  %t157 = xor i1 %t155, true
  br i1 %t157, label %bb43, label %bb44
bb43:
  br label %bb57
bb44:
  br label %bb45
bb45:
  %t159 = load i64, ptr %l11, !tbaa !24
  %t160 = load i64, ptr %l15, !tbaa !24
  %t161 = load i64, ptr %l13, !tbaa !24
  %t164 = mul i64 %t160, %t161
  %t167 = add i64 %t159, %t164
  store i64 %t167, ptr %l16, !tbaa !24
  %t169 = getelementptr %"compiler/typed:LocalUses", ptr %l3, i32 0, i32 12
  %t170 = load i64, ptr %l16, !tbaa !24
  %t173 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t169, i64 %t170)
  store i64 %t173, ptr %l107
  br label %bb46
bb46:
  %t174 = load i64, ptr %l4, !tbaa !24
  %t175 = load i64, ptr %l107, !tbaa !24
  %t177 = icmp eq i64 %t175, %t174
  br i1 %t177, label %bb47, label %bb48
bb47:
  %t179 = load ptr, ptr %l0, !tbaa !29
  store ptr %t179, ptr %l111, !tbaa !29
  %t180 = getelementptr %"compiler/typed:LocalUses", ptr %l3, i32 0, i32 13
  %t181 = load i64, ptr %l16, !tbaa !24
  %t184 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t180, i64 %t181)
  store i64 %t184, ptr %l114
  br label %bb49
bb48:
  store i1 false, ptr %l110, !tbaa !21
  br label %bb52
bb49:
  %t185 = getelementptr %"compiler/typed:LocalUses", ptr %l3, i32 0, i32 14
  %t186 = load i64, ptr %l16, !tbaa !24
  %t189 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t185, i64 %t186)
  store i64 %t189, ptr %l117
  br label %bb50
bb50:
  %t190 = load ptr, ptr %l111, !tbaa !29
  %t191 = load i64, ptr %l114, !tbaa !24
  %t192 = load i64, ptr %l117, !tbaa !24
  %t193 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2efreshParam(ptr %v0, ptr %t190, i64 %t191, i64 %t192)
  store i1 %t193, ptr %l118
  br label %bb51
bb51:
  %t194 = load i1, ptr %l118, !tbaa !21
  %t195 = xor i1 %t194, true
  store i1 %t195, ptr %l110, !tbaa !21
  br label %bb52
bb52:
  %t197 = load i1, ptr %l110, !tbaa !21
  br i1 %t197, label %bb53, label %bb54
bb53:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb54:
  br label %bb55
bb55:
  br label %bb56
bb56:
  %t199 = load i64, ptr %l15, !tbaa !24
  %t201 = add i64 %t199, 1
  store i64 %t201, ptr %l15, !tbaa !24
  br label %bb42
bb57:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2flower_2ecompiler_2flower_3aLowerer_2etext(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca i32
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %t1, i32 0, i32 21
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = icmp slt i32 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/lower:Lowerer", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %s1, ptr %s1, ptr %t12, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d4, i32 0, i32 1) }, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store i32 %t14, ptr %l7
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t15 = load i32, ptr %l7, !tbaa !23
  %t16 = load ptr, ptr %l4, !tbaa !29
  %t17 = getelementptr %"compiler/lower:Lowerer", ptr %t16, i32 0, i32 21
  store i32 %t15, ptr %t17, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  br label %bb4
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/lower:Lowerer", ptr %t18, i32 0, i32 21
  %t21 = load i32, ptr %t20, !tbaa !23
  store i32 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eassert(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca { i64, [4 x i64] }
  %l10 = alloca ptr
  %l17 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l18 = alloca i1
  %l22 = alloca { i64, [4 x i64] }
  %l27 = alloca i32
  %l30 = alloca i32
  %l45 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  %t55 = alloca { i64, [8 x i64] }, align 8
  %t71 = alloca { i64, [4 x i64] }, align 8
  %t91 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/lower:Lowerer", ptr %t4, i32 0, i32 10
  store ptr %t6, ptr %l10, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/lower:lowering", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Body", ptr %t10, i32 0, i32 0
  %t13 = load i32, ptr %t12, !tbaa !23
  %t15 = sext i32 %t13 to i64
  %t16 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t17 = load i32, ptr %t16, !tbaa !23
  %t19 = sext i32 %t17 to i64
  %t22 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t15, i64 %t19)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t22, ptr %l17
  br label %bb1
bb1:
  %t23 = load ptr, ptr %l10, !tbaa !29
  %t24 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l17
  %t25 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t23, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t24)
  store i1 %t25, ptr %l18
  br label %bb2
bb2:
  %t26 = load i1, ptr %l18, !tbaa !21
  br i1 %t26, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  br label %bb5
bb5:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t32 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t27, ptr %a2)
  store { i64, [4 x i64] } %t32, ptr %l22
  br label %bb6
bb6:
  %t33 = load { i64, [4 x i64] }, ptr %l22
  store { i64, [4 x i64] } %t33, ptr %l4
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/lower:lowering", ptr %t34, i32 0, i32 10
  %t37 = load i1, ptr %t36, !tbaa !21
  br i1 %t37, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb8:
  br label %bb9
bb9:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/lower:lowering", ptr %t39, i32 0, i32 3
  %t43 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t41)
  store i32 %t43, ptr %l27
  br label %bb10
bb10:
  %t44 = load i32, ptr %l27, !tbaa !23
  store i32 %t44, ptr %l5, !tbaa !23
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/lower:lowering", ptr %t45, i32 0, i32 3
  %t49 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t47)
  store i32 %t49, ptr %l30
  br label %bb11
bb11:
  %t50 = load i32, ptr %l30, !tbaa !23
  store i32 %t50, ptr %l6, !tbaa !23
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load { i64, [4 x i64] }, ptr %l4
  %t53 = load i32, ptr %l5, !tbaa !23
  %t54 = load i32, ptr %l6, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t55
  %t56 = getelementptr { i64, [8 x i64] }, ptr %t55, i32 0, i32 0
  store i64 2, ptr %t56
  %t58 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t52, 0
  %t60 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t58, i32 %t53, 1
  %t62 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t60, i32 %t54, 2
  %t63 = getelementptr { i64, [8 x i64] }, ptr %t55, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t62, ptr %t63
  %t64 = load { i64, [8 x i64] }, ptr %t55
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t51, { i64, [8 x i64] } %t64)
  br label %bb12
bb12:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t67, i32 %t68)
  br label %bb13
bb13:
  store { i64, [4 x i64] } zeroinitializer, ptr %t71
  %t72 = getelementptr { i64, [4 x i64] }, ptr %t71, i32 0, i32 0
  store i64 0, ptr %t72
  %t73 = load { i64, [4 x i64] }, ptr %t71
  store { i64, [4 x i64] } %t73, ptr %l7
  %t75 = load ptr, ptr %l3, !tbaa !29
  %t77 = icmp eq ptr %t75, null
  %t79 = xor i1 %t77, true
  br i1 %t79, label %bb14, label %bb15
bb14:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load ptr, ptr %l3, !tbaa !29
  %t86 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v2, ptr %t81, ptr %t82)
  store { i64, [4 x i64] } %t86, ptr %l45
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t87 = load { i64, [4 x i64] }, ptr %l45
  store { i64, [4 x i64] } %t87, ptr %l7
  br label %bb17
bb17:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load %"compiler/source:Span", ptr %l1
  %t90 = load { i64, [4 x i64] }, ptr %l7
  store { i64, [8 x i64] } zeroinitializer, ptr %t91
  %t92 = getelementptr { i64, [8 x i64] }, ptr %t91, i32 0, i32 0
  store i64 9, ptr %t92
  %t94 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t89, 0
  %t96 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t94, i32 7, 1
  %t98 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t96, { i64, [4 x i64] } %t90, 2
  %t99 = getelementptr { i64, [8 x i64] }, ptr %t91, i32 0, i32 1
  store { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t98, ptr %t99
  %t100 = load { i64, [8 x i64] }, ptr %t91
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t88, { i64, [8 x i64] } %t100)
  br label %bb18
bb18:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load i32, ptr %l5, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t103, i32 %t104)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eaway(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l12 = alloca { i64, [4 x i64] }
  %rv = alloca { i64, [4 x i64] }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 7
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l3, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 7
  store i64 %a1, ptr %t10, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t16 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t11, ptr %a2)
  store { i64, [4 x i64] } %t16, ptr %l12
  br label %bb1
bb1:
  %t17 = load { i64, [4 x i64] }, ptr %l12
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i64, ptr %l3, !tbaa !24
  %t22 = getelementptr %"compiler/lower:lowering", ptr %t18, i32 0, i32 7
  store i64 %t19, ptr %t22, !tbaa !24
  store { i64, [4 x i64] } %t17, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2ebangNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l27 = alloca { i64, ptr }
  %l28 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca i64
  %l38 = alloca i64
  %l57 = alloca { i64, ptr }
  %l60 = alloca i32
  %l63 = alloca i32
  %l69 = alloca i32
  %l72 = alloca i64
  %l79 = alloca ptr
  %l89 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l100 = alloca i64
  %l103 = alloca i64
  %l129 = alloca ptr
  %l130 = alloca ptr
  %l131 = alloca { i64, ptr }
  %l137 = alloca { i64, ptr }
  %l141 = alloca { i64, [4 x i64] }
  %l147 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t216 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t6, i32 %a1)
  store { i64, ptr } %t10, ptr %l27
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t12, ptr %l28
  br label %bb2
bb2:
  %t13 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l28
  %t14 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %t14
  store ptr %t14, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  store i64 %t18, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t20 = load i64, ptr %l7, !tbaa !24
  %t21 = load i64, ptr %l6, !tbaa !24
  %t24 = icmp sgt i64 %t20, %t21
  br i1 %t24, label %bb3, label %bb4
bb3:
  %t26 = load i64, ptr %l8, !tbaa !24
  %t28 = icmp sgt i64 %t26, 0
  br i1 %t28, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb8
bb5:
  %t30 = load i64, ptr %l7, !tbaa !24
  %t31 = load i64, ptr %l6, !tbaa !24
  %t34 = sub i64 %t30, %t31
  %t35 = load i64, ptr %l8, !tbaa !24
  %t38 = add i64 %t34, %t35
  %t40 = sub i64 %t38, 1
  %t41 = load i64, ptr %l8, !tbaa !24
  %t44 = sdiv i64 %t40, %t41
  store i64 %t44, ptr %l38, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l38, !tbaa !24
  br label %bb7
bb7:
  %t46 = load i64, ptr %l38, !tbaa !24
  store i64 %t46, ptr %l35, !tbaa !24
  br label %bb8
bb8:
  %t47 = load i64, ptr %l35, !tbaa !24
  store i64 %t47, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t48 = load i64, ptr %l10, !tbaa !24
  %t49 = load i64, ptr %l9, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb40
bb11:
  br label %bb12
bb12:
  %t56 = load i64, ptr %l6, !tbaa !24
  %t57 = load i64, ptr %l10, !tbaa !24
  %t58 = load i64, ptr %l8, !tbaa !24
  %t61 = mul i64 %t57, %t58
  %t64 = add i64 %t56, %t61
  store i64 %t64, ptr %l11, !tbaa !24
  %t66 = load ptr, ptr %l3, !tbaa !29
  %t67 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t67, ptr %l57, !tbaa !27
  %t68 = load i64, ptr %l11, !tbaa !24
  %t70 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr i32, ptr %t71, i64 %t68
  %t73 = load i32, ptr %t72, !tbaa !33
  %t76 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t66, i32 %t73)
  store i32 %t76, ptr %l60
  br label %bb13
bb13:
  %t77 = load i32, ptr %l60, !tbaa !23
  store i32 %t77, ptr %l12, !tbaa !23
  %t78 = load ptr, ptr %l3, !tbaa !29
  %t79 = load i32, ptr %l12, !tbaa !23
  %t82 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t78, i32 %t79)
  store i32 %t82, ptr %l63
  br label %bb14
bb14:
  %t83 = load i32, ptr %l63, !range !{i32 0, i32 33}
  %t85 = trunc i64 18 to i32
  %t86 = icmp eq i32 %t83, %t85
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb39
bb16:
  br label %bb17
bb17:
  %t90 = load ptr, ptr %l3, !tbaa !29
  %t91 = load i32, ptr %l12, !tbaa !23
  %t94 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t90, i32 %t91)
  store i32 %t94, ptr %l69
  br label %bb18
bb18:
  %t95 = load i32, ptr %l69, !tbaa !23
  store i32 %t95, ptr %l13, !tbaa !23
  %t96 = load ptr, ptr %l3, !tbaa !29
  %t97 = load i32, ptr %l13, !tbaa !23
  %t100 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t96, i32 %t97)
  store i64 %t100, ptr %l72
  br label %bb19
bb19:
  %t101 = load i64, ptr %l72, !tbaa !24
  store i64 %t101, ptr %l14, !tbaa !24
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/lower:lowering", ptr %t102, i32 0, i32 0
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t107 = getelementptr %"compiler/lower:Lowerer", ptr %t105, i32 0, i32 0
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t110 = getelementptr %"compiler/generic:Program", ptr %t108, i32 0, i32 0
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = getelementptr %"compiler/load:Loader", ptr %t111, i32 0, i32 10
  %t114 = load i64, ptr %l14, !tbaa !24
  %t117 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t113, i64 %t114)
  store ptr %t117, ptr %l79
  br label %bb20
bb20:
  %t118 = load ptr, ptr %l79, !tbaa !29
  %t120 = getelementptr %"compiler/load:Module", ptr %t118, i32 0, i32 2
  %t121 = load { i64, ptr }, ptr %t120, !tbaa !27
  %t122 = load i64, ptr %l14, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/lower:lowering", ptr %t123, i32 0, i32 0
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t128 = getelementptr %"compiler/lower:Lowerer", ptr %t126, i32 0, i32 0
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = getelementptr %"compiler/generic:Program", ptr %t129, i32 0, i32 0
  %t132 = load ptr, ptr %t131, !tbaa !29
  %t134 = getelementptr %"compiler/load:Loader", ptr %t132, i32 0, i32 12
  %t135 = load i64, ptr %t134, !tbaa !24
  %t138 = icmp eq i64 %t122, %t135
  %t141 = call { i64, ptr } @compiler_2fload_2eErrQualifier(ptr %v0, ptr %s2, { i64, ptr } %t121, i1 %t138)
  store { i64, ptr } %t141, ptr %l89
  br label %bb21
bb21:
  %t142 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t142, ptr %l15, !tbaa !27
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/lower:lowering", ptr %t143, i32 0, i32 0
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t148 = getelementptr %"compiler/lower:Lowerer", ptr %t146, i32 0, i32 0
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t150 = load i32, ptr %l13, !tbaa !23
  %t153 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %s2, ptr %t149, i32 %t150)
  store { i64, ptr } %t153, ptr %l94
  br label %bb22
bb22:
  %t154 = load { i64, ptr }, ptr %l94, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t157 = extractvalue { i64, ptr } %t154, 0
  store i64 %t157, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t159 = load i64, ptr %l18, !tbaa !24
  %t160 = load i64, ptr %l17, !tbaa !24
  %t163 = icmp sgt i64 %t159, %t160
  br i1 %t163, label %bb23, label %bb24
bb23:
  %t165 = load i64, ptr %l19, !tbaa !24
  %t167 = icmp sgt i64 %t165, 0
  br i1 %t167, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l100, !tbaa !24
  br label %bb28
bb25:
  %t169 = load i64, ptr %l18, !tbaa !24
  %t170 = load i64, ptr %l17, !tbaa !24
  %t173 = sub i64 %t169, %t170
  %t174 = load i64, ptr %l19, !tbaa !24
  %t177 = add i64 %t173, %t174
  %t179 = sub i64 %t177, 1
  %t180 = load i64, ptr %l19, !tbaa !24
  %t183 = sdiv i64 %t179, %t180
  store i64 %t183, ptr %l103, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l103, !tbaa !24
  br label %bb27
bb27:
  %t185 = load i64, ptr %l103, !tbaa !24
  store i64 %t185, ptr %l100, !tbaa !24
  br label %bb28
bb28:
  %t186 = load i64, ptr %l100, !tbaa !24
  store i64 %t186, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s5
  %t187 = load i64, ptr %l21, !tbaa !24
  %t188 = load i64, ptr %l20, !tbaa !24
  %t191 = icmp slt i64 %t187, %t188
  %t193 = xor i1 %t191, true
  br i1 %t193, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb38
bb31:
  br label %bb32
bb32:
  %t195 = load i64, ptr %l17, !tbaa !24
  %t196 = load i64, ptr %l21, !tbaa !24
  %t197 = load i64, ptr %l19, !tbaa !24
  %t200 = mul i64 %t196, %t197
  %t203 = add i64 %t195, %t200
  store i64 %t203, ptr %l22, !tbaa !24
  %t205 = load ptr, ptr %l5, !tbaa !29
  %t206 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t207 = load i64, ptr %l11, !tbaa !24
  %t209 = add i64 %t207, 1
  %t211 = shl i64 %t209, 16
  %t212 = load i64, ptr %l22, !tbaa !24
  %t215 = or i64 %t211, %t212
  store { i64, [4 x i64] } zeroinitializer, ptr %t216
  %t217 = getelementptr { i64, [4 x i64] }, ptr %t216, i32 0, i32 0
  store i64 2, ptr %t217
  %t219 = insertvalue { i32, i64 } undef, i32 %t206, 0
  %t221 = insertvalue { i32, i64 } %t219, i64 %t215, 1
  %t222 = getelementptr { i64, [4 x i64] }, ptr %t216, i32 0, i32 1
  store { i32, i64 } %t221, ptr %t222
  %t223 = load { i64, [4 x i64] }, ptr %t216
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2ePush_3ccompiler_2fmir_3aOperand_3e(ptr %s0, ptr %t205, { i64, [4 x i64] } %t223)
  br label %bb33
bb33:
  %t226 = load ptr, ptr %l5, !tbaa !29
  store ptr %t226, ptr %l129, !tbaa !29
  %t227 = load ptr, ptr %l0, !tbaa !29
  store ptr %t227, ptr %l130, !tbaa !29
  %t228 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t228, ptr %l131, !tbaa !27
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"compiler/lower:lowering", ptr %t229, i32 0, i32 0
  %t232 = load ptr, ptr %t231, !tbaa !29
  %t234 = getelementptr %"compiler/lower:Lowerer", ptr %t232, i32 0, i32 0
  %t235 = load ptr, ptr %t234, !tbaa !29
  %t236 = load i32, ptr %l13, !tbaa !23
  %t237 = load i64, ptr %l22, !tbaa !24
  %t241 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWordName(ptr %v0, ptr %s5, ptr %t235, i32 %t236, i64 %t237)
  store { i64, ptr } %t241, ptr %l137
  br label %bb34
bb34:
  %t242 = load { i64, ptr }, ptr %l131, !tbaa !27
  %t243 = extractvalue { i64, ptr } %t242, 1
  %t244 = extractvalue { i64, ptr } %t242, 0
  %t245 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t246 = extractvalue { i64, ptr } %t245, 1
  %t247 = extractvalue { i64, ptr } %t245, 0
  %t248 = add i64 %t244, %t247
  %t249 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t248)
  call void @olang_textcopy(ptr %t249, ptr %t243, i64 %t244)
  %t250 = getelementptr i8, ptr %t249, i64 %t244
  call void @olang_textcopy(ptr %t250, ptr %t246, i64 %t247)
  %t251 = insertvalue { i64, ptr } undef, i64 %t248, 0
  %t252 = insertvalue { i64, ptr } %t251, ptr %t249, 1
  %t254 = extractvalue { i64, ptr } %t252, 0
  %t255 = extractvalue { i64, ptr } %t252, 1
  %t256 = mul i64 %t254, 1
  %t257 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t256)
  call void @llvm.memcpy.p0.p0.i64(ptr %t257, ptr %t255, i64 %t256, i1 false)
  %t258 = insertvalue { i64, ptr } undef, i64 %t254, 0
  %t259 = insertvalue { i64, ptr } %t258, ptr %t257, 1
  %t261 = load ptr, ptr %l130, !tbaa !29
  %t264 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2etextData(ptr %v0, ptr %s5, ptr %t261, { i64, ptr } %t259, %"compiler/source:Span" %a2)
  store { i64, [4 x i64] } %t264, ptr %l141
  br label %bb35
bb35:
  %t265 = load ptr, ptr %l129, !tbaa !29
  %t266 = load { i64, [4 x i64] }, ptr %l141
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2ePush_3ccompiler_2fmir_3aOperand_3e(ptr %s0, ptr %t265, { i64, [4 x i64] } %t266)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s5)
  br label %bb37
bb37:
  %t267 = load i64, ptr %l21, !tbaa !24
  %t269 = add i64 %t267, 1
  store i64 %t269, ptr %l21, !tbaa !24
  br label %bb29
bb38:
  call void @__olang_scope_close(ptr %s2)
  br label %bb39
bb39:
  %t271 = load i64, ptr %l10, !tbaa !24
  %t273 = add i64 %t271, 1
  store i64 %t273, ptr %l10, !tbaa !24
  br label %bb9
bb40:
  %t275 = load ptr, ptr %l5, !tbaa !29
  %t277 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eToArray_3ccompiler_2fmir_3aOperand_3e(ptr %s0, ptr %v1, ptr %t275)
  store { i64, ptr } %t277, ptr %l147
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s0)
  %t278 = load { i64, ptr }, ptr %l147, !tbaa !27
  store { i64, ptr } %t278, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { { i64, [7 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2ecallee(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i64
  %l13 = alloca i32
  %l14 = alloca ptr
  %l15 = alloca i1
  %l22 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i1
  %l30 = alloca i64
  %l34 = alloca i64
  %l36 = alloca i1
  %l41 = alloca i1
  %l48 = alloca ptr
  %l60 = alloca { { i64, [7 x i64] }, i32 }
  %l61 = alloca ptr
  %l62 = alloca i1
  %l71 = alloca i32
  %l77 = alloca ptr
  %l78 = alloca i1
  %l85 = alloca { { i64, [7 x i64] }, i32 }
  %l86 = alloca ptr
  %l87 = alloca i1
  %l97 = alloca { { i64, [7 x i64] }, i32 }
  %l98 = alloca ptr
  %l99 = alloca i1
  %rv = alloca { { i64, [7 x i64] }, i32 }
  %t81 = alloca { i64, [2 x i64] }, align 8
  %t90 = alloca { i64, [7 x i64] }, align 8
  %t139 = alloca { i64, [7 x i64] }, align 8
  %t224 = alloca { i64, [4 x i64] }, align 8
  %t229 = alloca { i64, [7 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t2 = load ptr, ptr %l14, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l14, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 5}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l15, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l15, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { i32 }, ptr %t12, i32 0, i32 0
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l4, !tbaa !23
  br label %bb5
bb4:
  br label %bb23
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/lower:lowering", ptr %t16, i32 0, i32 24
  %t19 = load i1, ptr %t18, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/lower:lowering", ptr %t21, i32 0, i32 30
  %t27 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2eTwin(ptr %v0, ptr %t23, i32 %a3)
  store i64 %t27, ptr %l26
  br label %bb8
bb7:
  store i64 -1, ptr %l22, !tbaa !24
  br label %bb9
bb8:
  %t28 = load i64, ptr %l26, !tbaa !24
  store i64 %t28, ptr %l22, !tbaa !24
  br label %bb9
bb9:
  %t29 = load i64, ptr %l22, !tbaa !24
  store i64 %t29, ptr %l5, !tbaa !24
  %t30 = load i64, ptr %l5, !tbaa !24
  %t32 = icmp sge i64 %t30, 0
  br i1 %t32, label %bb10, label %bb11
bb10:
  %t34 = load i64, ptr %l5, !tbaa !24
  store i64 %t34, ptr %l30, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/lower:lowering", ptr %t35, i32 0, i32 0
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"compiler/lower:Lowerer", ptr %t38, i32 0, i32 4
  %t42 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t40)
  store i64 %t42, ptr %l34
  br label %bb12
bb11:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb13
bb12:
  %t43 = load i64, ptr %l30, !tbaa !24
  %t44 = load i64, ptr %l34, !tbaa !24
  %t45 = icmp slt i64 %t43, %t44
  store i1 %t45, ptr %l29, !tbaa !21
  br label %bb13
bb13:
  %t47 = load i1, ptr %l29, !tbaa !21
  br i1 %t47, label %bb14, label %bb15
bb14:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/lower:lowering", ptr %t48, i32 0, i32 0
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = getelementptr %"compiler/lower:Lowerer", ptr %t51, i32 0, i32 4
  %t54 = load i64, ptr %l5, !tbaa !24
  %t57 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t53, i64 %t54)
  store i1 %t57, ptr %l41
  br label %bb16
bb15:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb17
bb16:
  %t58 = load i1, ptr %l41, !tbaa !21
  store i1 %t58, ptr %l36, !tbaa !21
  br label %bb17
bb17:
  %t59 = load i1, ptr %l36, !tbaa !21
  br i1 %t59, label %bb18, label %bb19
bb18:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/lower:lowering", ptr %t60, i32 0, i32 0
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = getelementptr %"compiler/lower:Lowerer", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = load i32, ptr %l4, !tbaa !23
  %t70 = sext i32 %t68 to i64
  %t73 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t66, i64 %t70)
  store ptr %t73, ptr %l48
  br label %bb20
bb19:
  br label %bb21
bb20:
  %t74 = load ptr, ptr %l48, !tbaa !29
  %t76 = getelementptr %"compiler/typed:Body", ptr %t74, i32 0, i32 2
  %t77 = load i32, ptr %t76, !tbaa !23
  store i32 %t77, ptr %l6, !tbaa !23
  %t79 = load i32, ptr %l4, !tbaa !23
  %t80 = load i64, ptr %l5, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t81
  %t82 = getelementptr { i64, [2 x i64] }, ptr %t81, i32 0, i32 0
  store i64 6, ptr %t82
  %t84 = insertvalue { i32, i64 } undef, i32 %t79, 0
  %t86 = insertvalue { i32, i64 } %t84, i64 %t80, 1
  %t87 = getelementptr { i64, [2 x i64] }, ptr %t81, i32 0, i32 1
  store { i32, i64 } %t86, ptr %t87
  %t88 = load { i64, [2 x i64] }, ptr %t81
  %t89 = load i32, ptr %l6, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t90
  %t91 = getelementptr { i64, [7 x i64] }, ptr %t90, i32 0, i32 0
  store i64 0, ptr %t91
  %t93 = insertvalue { { i64, [2 x i64] }, i32 } undef, { i64, [2 x i64] } %t88, 0
  %t95 = insertvalue { { i64, [2 x i64] }, i32 } %t93, i32 %t89, 1
  %t96 = getelementptr { i64, [7 x i64] }, ptr %t90, i32 0, i32 1
  store { { i64, [2 x i64] }, i32 } %t95, ptr %t96
  %t97 = load { i64, [7 x i64] }, ptr %t90
  %t98 = load i32, ptr %l6, !tbaa !23
  %t100 = insertvalue { { i64, [7 x i64] }, i32 } undef, { i64, [7 x i64] } %t97, 0
  %t102 = insertvalue { { i64, [7 x i64] }, i32 } %t100, i32 %t98, 1
  store { { i64, [7 x i64] }, i32 } %t102, ptr %rv
  br label %ret
bb21:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load i32, ptr %l4, !tbaa !23
  %t108 = call { { i64, [7 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2ebodyCallee(ptr %v0, ptr %t104, i32 %t105)
  store { { i64, [7 x i64] }, i32 } %t108, ptr %l60
  br label %bb22
bb22:
  %t109 = load { { i64, [7 x i64] }, i32 }, ptr %l60
  store { { i64, [7 x i64] }, i32 } %t109, ptr %rv
  br label %ret
bb23:
  %t110 = load ptr, ptr %l1, !tbaa !29
  store ptr %t110, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t111 = load ptr, ptr %l61, !tbaa !29
  %t112 = icmp ne ptr %t111, null
  br i1 %t112, label %bb24, label %bb25
bb24:
  %t114 = load ptr, ptr %l61, !tbaa !29
  %t115 = load i64, ptr %t114, !range !{i64 0, i64 5}
  %t117 = icmp eq i64 %t115, 1
  store i1 %t117, ptr %l62, !tbaa !21
  br label %bb25
bb25:
  %t118 = load i1, ptr %l62, !tbaa !21
  br i1 %t118, label %bb26, label %bb27
bb26:
  %t119 = load ptr, ptr %l1, !tbaa !29
  %t121 = getelementptr { i64, [3 x i64] }, ptr %t119, i32 0, i32 1
  %t122 = getelementptr { i64 }, ptr %t121, i32 0, i32 0
  %t123 = load i64, ptr %t122
  store i64 %t123, ptr %l7, !tbaa !24
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/lower:lowering", ptr %t125, i32 0, i32 0
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t130 = getelementptr %"compiler/lower:Lowerer", ptr %t128, i32 0, i32 0
  %t131 = load ptr, ptr %t130, !tbaa !29
  %t132 = load i64, ptr %l7, !tbaa !24
  %t135 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t131, i64 %t132)
  store i32 %t135, ptr %l71
  br label %bb29
bb29:
  %t136 = load i32, ptr %l71, !tbaa !23
  store i32 %t136, ptr %l8, !tbaa !23
  %t137 = load i64, ptr %l7, !tbaa !24
  %t138 = load i32, ptr %l8, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t139
  %t140 = getelementptr { i64, [7 x i64] }, ptr %t139, i32 0, i32 0
  store i64 1, ptr %t140
  %t142 = insertvalue { i64, i32 } undef, i64 %t137, 0
  %t144 = insertvalue { i64, i32 } %t142, i32 %t138, 1
  %t145 = getelementptr { i64, [7 x i64] }, ptr %t139, i32 0, i32 1
  store { i64, i32 } %t144, ptr %t145
  %t146 = load { i64, [7 x i64] }, ptr %t139
  %t147 = load i32, ptr %l8, !tbaa !23
  %t149 = insertvalue { { i64, [7 x i64] }, i32 } undef, { i64, [7 x i64] } %t146, 0
  %t151 = insertvalue { { i64, [7 x i64] }, i32 } %t149, i32 %t147, 1
  store { { i64, [7 x i64] }, i32 } %t151, ptr %rv
  br label %ret
bb30:
  %t153 = load ptr, ptr %l1, !tbaa !29
  store ptr %t153, ptr %l77, !tbaa !29
  store i1 false, ptr %l78, !tbaa !21
  %t154 = load ptr, ptr %l77, !tbaa !29
  %t155 = icmp ne ptr %t154, null
  br i1 %t155, label %bb31, label %bb32
bb31:
  %t157 = load ptr, ptr %l77, !tbaa !29
  %t158 = load i64, ptr %t157, !range !{i64 0, i64 5}
  %t160 = icmp eq i64 %t158, 2
  store i1 %t160, ptr %l78, !tbaa !21
  br label %bb32
bb32:
  %t161 = load i1, ptr %l78, !tbaa !21
  br i1 %t161, label %bb33, label %bb34
bb33:
  %t162 = load ptr, ptr %l1, !tbaa !29
  %t164 = getelementptr { i64, [3 x i64] }, ptr %t162, i32 0, i32 1
  %t165 = getelementptr { ptr }, ptr %t164, i32 0, i32 0
  %t166 = load ptr, ptr %t165
  store ptr %t166, ptr %l9, !tbaa !29
  br label %bb35
bb34:
  br label %bb37
bb35:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t169 = load ptr, ptr %l9, !tbaa !29
  %t172 = call { { i64, [7 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2evalueCallee(ptr %v0, ptr %v1, ptr %t168, ptr %t169)
  store { { i64, [7 x i64] }, i32 } %t172, ptr %l85
  br label %bb36
bb36:
  %t173 = load { { i64, [7 x i64] }, i32 }, ptr %l85
  store { { i64, [7 x i64] }, i32 } %t173, ptr %rv
  br label %ret
bb37:
  %t174 = load ptr, ptr %l1, !tbaa !29
  store ptr %t174, ptr %l86, !tbaa !29
  store i1 false, ptr %l87, !tbaa !21
  %t175 = load ptr, ptr %l86, !tbaa !29
  %t176 = icmp ne ptr %t175, null
  br i1 %t176, label %bb38, label %bb39
bb38:
  %t178 = load ptr, ptr %l86, !tbaa !29
  %t179 = load i64, ptr %t178, !range !{i64 0, i64 5}
  %t181 = icmp eq i64 %t179, 4
  store i1 %t181, ptr %l87, !tbaa !21
  br label %bb39
bb39:
  %t182 = load i1, ptr %l87, !tbaa !21
  br i1 %t182, label %bb40, label %bb41
bb40:
  %t183 = load ptr, ptr %l1, !tbaa !29
  %t185 = getelementptr { i64, [3 x i64] }, ptr %t183, i32 0, i32 1
  %t186 = getelementptr { i32, i32 }, ptr %t185, i32 0, i32 0
  %t187 = load i32, ptr %t186, !range !{i32 0, i32 2}
  store i32 %t187, ptr %l10
  %t189 = load ptr, ptr %l1, !tbaa !29
  %t191 = getelementptr { i64, [3 x i64] }, ptr %t189, i32 0, i32 1
  %t192 = getelementptr { i32, i32 }, ptr %t191, i32 0, i32 1
  %t193 = load i32, ptr %t192
  store i32 %t193, ptr %l11, !tbaa !23
  br label %bb42
bb41:
  br label %bb44
bb42:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t196 = load i32, ptr %l10, !range !{i32 0, i32 2}
  %t197 = load i32, ptr %l11, !tbaa !23
  %t201 = call { { i64, [7 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2ehelperCallee(ptr %v0, ptr %t195, i32 %t196, i32 %t197)
  store { { i64, [7 x i64] }, i32 } %t201, ptr %l97
  br label %bb43
bb43:
  %t202 = load { { i64, [7 x i64] }, i32 }, ptr %l97
  store { { i64, [7 x i64] }, i32 } %t202, ptr %rv
  br label %ret
bb44:
  %t203 = load ptr, ptr %l1, !tbaa !29
  store ptr %t203, ptr %l98, !tbaa !29
  store i1 false, ptr %l99, !tbaa !21
  %t204 = load ptr, ptr %l98, !tbaa !29
  %t205 = icmp ne ptr %t204, null
  br i1 %t205, label %bb45, label %bb46
bb45:
  %t207 = load ptr, ptr %l98, !tbaa !29
  %t208 = load i64, ptr %t207, !range !{i64 0, i64 5}
  %t210 = icmp eq i64 %t208, 3
  store i1 %t210, ptr %l99, !tbaa !21
  br label %bb46
bb46:
  %t211 = load i1, ptr %l99, !tbaa !21
  br i1 %t211, label %bb47, label %bb48
bb47:
  %t212 = load ptr, ptr %l1, !tbaa !29
  %t214 = getelementptr { i64, [3 x i64] }, ptr %t212, i32 0, i32 1
  %t215 = getelementptr { i32, i64, i32 }, ptr %t214, i32 0, i32 1
  %t216 = load i64, ptr %t215
  store i64 %t216, ptr %l12, !tbaa !24
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t220 = getelementptr { i64, [3 x i64] }, ptr %t218, i32 0, i32 1
  %t221 = getelementptr { i32, i64, i32 }, ptr %t220, i32 0, i32 2
  %t222 = load i32, ptr %t221
  store i32 %t222, ptr %l13, !tbaa !23
  br label %bb49
bb48:
  br label %bb50
bb49:
  store { i64, [4 x i64] } zeroinitializer, ptr %t224
  %t225 = getelementptr { i64, [4 x i64] }, ptr %t224, i32 0, i32 0
  store i64 0, ptr %t225
  %t226 = load { i64, [4 x i64] }, ptr %t224
  %t227 = load i64, ptr %l12, !tbaa !24
  %t228 = load i32, ptr %l13, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t229
  %t230 = getelementptr { i64, [7 x i64] }, ptr %t229, i32 0, i32 0
  store i64 3, ptr %t230
  %t232 = insertvalue { { i64, [4 x i64] }, i64, i32 } undef, { i64, [4 x i64] } %t226, 0
  %t234 = insertvalue { { i64, [4 x i64] }, i64, i32 } %t232, i64 %t227, 1
  %t236 = insertvalue { { i64, [4 x i64] }, i64, i32 } %t234, i32 %t228, 2
  %t237 = getelementptr { i64, [7 x i64] }, ptr %t229, i32 0, i32 1
  store { { i64, [4 x i64] }, i64, i32 } %t236, ptr %t237
  %t238 = load { i64, [7 x i64] }, ptr %t229
  %t239 = load i32, ptr %l13, !tbaa !23
  %t241 = insertvalue { { i64, [7 x i64] }, i32 } undef, { i64, [7 x i64] } %t238, 0
  %t243 = insertvalue { { i64, [7 x i64] }, i32 } %t241, i32 %t239, 1
  store { { i64, [7 x i64] }, i32 } %t243, ptr %rv
  br label %ret
bb50:
  call void @__olang_check_failed(ptr @olang_loc_21e9da82ebd620c7_b6074e807b9f75fb)
  unreachable
ret:
  %rr = load { { i64, [7 x i64] }, i32 }, ptr %rv
  ret { { i64, [7 x i64] }, i32 } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ecleanup(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l11 = alloca i32
  %l14 = alloca i32
  %l28 = alloca ptr
  %l32 = alloca ptr
  %s0 = alloca %olang.scope
  %t24 = alloca { i64, [21 x i64] }, align 8
  %t73 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 10
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 16
  %t9 = load i64, ptr %l2, !tbaa !24
  %t12 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t8, i64 %t9)
  store i32 %t12, ptr %l11
  br label %bb4
bb4:
  %t13 = load i32, ptr %l11, !tbaa !23
  store i32 %t13, ptr %l3, !tbaa !23
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/lower:lowering", ptr %t14, i32 0, i32 3
  %t18 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t16)
  store i32 %t18, ptr %l14
  br label %bb5
bb5:
  %t19 = load i32, ptr %l14, !tbaa !23
  store i32 %t19, ptr %l4, !tbaa !23
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load %"compiler/source:Span", ptr %l1
  %t22 = load i32, ptr %l3, !tbaa !23
  %t23 = load i32, ptr %l4, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t24
  %t25 = getelementptr { i64, [21 x i64] }, ptr %t24, i32 0, i32 0
  store i64 15, ptr %t25
  %t27 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t21, 0
  %t29 = insertvalue { %"compiler/source:Span", i32, i32 } %t27, i32 %t22, 1
  %t31 = insertvalue { %"compiler/source:Span", i32, i32 } %t29, i32 %t23, 2
  %t32 = getelementptr { i64, [21 x i64] }, ptr %t24, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t31, ptr %t32
  %t33 = load { i64, [21 x i64] }, ptr %t24
  %t35 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t33, ptr %t35
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t20, ptr %t35)
  br label %bb6
bb6:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/lower:lowering", ptr %t38, i32 0, i32 9
  %t41 = load i32, ptr %t40, !tbaa !23
  store i32 %t41, ptr %l5, !tbaa !23
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t43, i32 %t44)
  br label %bb7
bb7:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/lower:lowering", ptr %t47, i32 0, i32 16
  %t50 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eSetAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t49, i64 %t50, i32 -1)
  br label %bb8
bb8:
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l28, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/lower:lowering", ptr %t54, i32 0, i32 15
  %t57 = load i64, ptr %l2, !tbaa !24
  %t60 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlock_26_3e_2eAt_3ccompiler_2ftyped_3aBlock_26_3e(ptr %v0, ptr %v0, ptr %t56, i64 %t57)
  store ptr %t60, ptr %l32
  br label %bb9
bb9:
  %t61 = load ptr, ptr %l28, !tbaa !29
  %t62 = load ptr, ptr %l32, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eblock(ptr %v0, ptr %v0, ptr %t61, ptr %t62)
  br label %bb10
bb10:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/lower:lowering", ptr %t63, i32 0, i32 16
  %t66 = load i64, ptr %l2, !tbaa !24
  %t67 = load i32, ptr %l3, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eSetAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t65, i64 %t66, i32 %t67)
  br label %bb11
bb11:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load %"compiler/source:Span", ptr %l1
  store { i64, [8 x i64] } zeroinitializer, ptr %t73
  %t74 = getelementptr { i64, [8 x i64] }, ptr %t73, i32 0, i32 0
  store i64 10, ptr %t74
  %t76 = insertvalue { %"compiler/source:Span" } undef, %"compiler/source:Span" %t72, 0
  %t77 = getelementptr { i64, [8 x i64] }, ptr %t73, i32 0, i32 1
  store { %"compiler/source:Span" } %t76, ptr %t77
  %t78 = load { i64, [8 x i64] }, ptr %t73
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t71, { i64, [8 x i64] } %t78)
  br label %bb12
bb12:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load i32, ptr %l5, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t81, i32 %t82)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ecombine(ptr %v0, ptr %a0, i32 %a1, { i64, [4 x i64] } %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l9 = alloca %"compiler/mir:Lvalue"
  %l10 = alloca { i64, [4 x i64] }
  %l12 = alloca { i64, [4 x i64] }
  %l13 = alloca { i64, ptr }
  %l15 = alloca { i64, [4 x i64] }
  %l16 = alloca ptr
  %l17 = alloca %"compiler/source:Span"
  %l19 = alloca %"compiler/mir:Lvalue"
  %l20 = alloca i32
  %l21 = alloca i32
  %l26 = alloca { i64, ptr }
  %l27 = alloca %"compiler/mir:Range"
  %s0 = alloca %olang.scope
  %t6 = alloca { i64, [4 x i64] }, align 8
  %t61 = alloca { i64, [15 x i64] }, align 8
  %t71 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i32 5, ptr %l6
  %t2 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t2, ptr %l7, !tbaa !23
  %t3 = load i32, ptr %l1, !tbaa !23
  %t5 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t3)
  store %"compiler/mir:Lvalue" %t5, ptr %l9
  br label %bb1
bb1:
  store { i64, [4 x i64] } zeroinitializer, ptr %t6
  %t7 = getelementptr { i64, [4 x i64] }, ptr %t6, i32 0, i32 0
  store i64 1, ptr %t7
  %t8 = load %"compiler/mir:Lvalue", ptr %l9
  %t9 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t8, 0
  %t10 = getelementptr { i64, [4 x i64] }, ptr %t6, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t9, ptr %t10
  %t11 = load { i64, [4 x i64] }, ptr %t6
  store { i64, [4 x i64] } %t11, ptr %l10
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t12, i64 1099511628211)
  store { i64, [4 x i64] } %t14, ptr %l12
  br label %bb2
bb2:
  %t15 = mul i64 2, 40
  %t16 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 2, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l13, !tbaa !27
  %t19 = load { i64, [4 x i64] }, ptr %l10
  %t20 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr { i64, [4 x i64] }, ptr %t21, i64 0
  store { i64, [4 x i64] } %t19, ptr %t22
  %t23 = load { i64, [4 x i64] }, ptr %l12
  %t24 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, [4 x i64] }, ptr %t25, i64 1
  store { i64, [4 x i64] } %t23, ptr %t26
  %t27 = load %"compiler/source:Span", ptr %l3
  %t28 = load ptr, ptr %l5, !tbaa !29
  %t29 = load i32, ptr %l6, !range !{i32 0, i32 52}
  %t30 = load i32, ptr %l7, !tbaa !23
  %t31 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t33 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %t28, i32 %t29, i32 %t30, { i64, ptr } %t31, %"compiler/source:Span" %t27)
  store { i64, [4 x i64] } %t33, ptr %l15
  br label %bb3
bb3:
  %t34 = load { i64, [4 x i64] }, ptr %l15
  store { i64, [4 x i64] } %t34, ptr %l4
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l16, !tbaa !29
  %t36 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t36, ptr %l17
  %t37 = load i32, ptr %l1, !tbaa !23
  %t39 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t37)
  store %"compiler/mir:Lvalue" %t39, ptr %l19
  br label %bb4
bb4:
  store i32 3, ptr %l20
  %t40 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t40, ptr %l21, !tbaa !23
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/lower:lowering", ptr %t41, i32 0, i32 3
  %t44 = load { i64, [4 x i64] }, ptr %l4
  %t46 = mul i64 2, 40
  %t47 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t46)
  %t48 = insertvalue { i64, ptr } undef, i64 2, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  store { i64, ptr } %t49, ptr %l26, !tbaa !27
  %t51 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr { i64, [4 x i64] }, ptr %t52, i64 0
  store { i64, [4 x i64] } %t44, ptr %t53
  %t55 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr { i64, [4 x i64] }, ptr %t56, i64 1
  store { i64, [4 x i64] } %a2, ptr %t57
  %t59 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t60 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %s0, ptr %t43, { i64, ptr } %t59)
  store %"compiler/mir:Range" %t60, ptr %l27
  br label %bb5
bb5:
  store { i64, [15 x i64] } zeroinitializer, ptr %t61
  %t62 = getelementptr { i64, [15 x i64] }, ptr %t61, i32 0, i32 0
  store i64 3, ptr %t62
  %t63 = load i32, ptr %l20, !range !{i32 0, i32 52}
  %t64 = insertvalue { i32, i32, %"compiler/mir:Range" } undef, i32 %t63, 0
  %t65 = load i32, ptr %l21, !tbaa !23
  %t66 = insertvalue { i32, i32, %"compiler/mir:Range" } %t64, i32 %t65, 1
  %t67 = load %"compiler/mir:Range", ptr %l27
  %t68 = insertvalue { i32, i32, %"compiler/mir:Range" } %t66, %"compiler/mir:Range" %t67, 2
  %t69 = getelementptr { i64, [15 x i64] }, ptr %t61, i32 0, i32 1
  store { i32, i32, %"compiler/mir:Range" } %t68, ptr %t69
  %t70 = load { i64, [15 x i64] }, ptr %t61
  store { i64, [21 x i64] } zeroinitializer, ptr %t71
  %t72 = getelementptr { i64, [21 x i64] }, ptr %t71, i32 0, i32 0
  store i64 0, ptr %t72
  %t73 = load %"compiler/source:Span", ptr %l17
  %t74 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t73, 0
  %t75 = load %"compiler/mir:Lvalue", ptr %l19
  %t76 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t74, %"compiler/mir:Lvalue" %t75, 1
  %t78 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t76, { i64, [15 x i64] } %t70, 2
  %t79 = getelementptr { i64, [21 x i64] }, ptr %t71, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t78, ptr %t79
  %t80 = load { i64, [21 x i64] }, ptr %t71
  %t82 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t80, ptr %t82
  %t83 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t83, ptr %t82)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ecopyParams(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca { i64, [1 x i64] }
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca { i64, [4 x i64] }
  %l13 = alloca i64
  %l15 = alloca i64
  %l20 = alloca i32
  %l21 = alloca i32
  %l26 = alloca i32
  %l27 = alloca i32
  %l28 = alloca { i64, [1 x i64] }
  %l33 = alloca { i64, [1 x i64] }
  %l34 = alloca i32
  %l43 = alloca %"compiler/typed:Local"
  %l50 = alloca %"compiler/typed:Local"
  %l60 = alloca ptr
  %l62 = alloca %"compiler/mir:Lvalue"
  %l67 = alloca { i64, [4 x i64] }
  %l68 = alloca ptr
  %l69 = alloca %"compiler/source:Span"
  %l71 = alloca %"compiler/mir:Lvalue"
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %t97 = alloca { i64, [21 x i64] }, align 8
  %t113 = alloca { i64, [4 x i64] }, align 8
  %t135 = alloca { i64, [15 x i64] }, align 8
  %t141 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Body", ptr %t4, i32 0, i32 5
  store ptr %t6, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = load i64, ptr %l2, !tbaa !24
  store i64 %t8, ptr %l13, !tbaa !24
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l15
  br label %bb2
bb2:
  %t12 = load i64, ptr %l13, !tbaa !24
  %t13 = load i64, ptr %l15, !tbaa !24
  %t14 = icmp slt i64 %t12, %t13
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb26
bb4:
  br label %bb5
bb5:
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t19 = load i64, ptr %l2, !tbaa !24
  %t22 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t18, i64 %t19)
  store i32 %t22, ptr %l20
  br label %bb6
bb6:
  %t23 = load i32, ptr %l20, !tbaa !23
  store i32 %t23, ptr %l3, !tbaa !23
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/lower:lowering", ptr %t24, i32 0, i32 14
  %t27 = load i32, ptr %l3, !tbaa !23
  %t29 = sext i32 %t27 to i64
  %t32 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fmir_3aLocalId_3e_2_H1e3bc46345ebb5614acbe688055fe55f(ptr %v0, ptr %t26, i64 %t29)
  %t33 = extractvalue { i32, i32 } %t32, 1
  %t34 = extractvalue { i32, i32 } %t32, 0
  store i32 %t34, ptr %l27
  %t35 = icmp ne i32 %t34, 0
  br i1 %t35, label %bb8, label %ok.36, !prof !99
ok.36:
  store i32 %t33, ptr %l26
  br label %bb7
bb7:
  %t37 = load i32, ptr %l26, !tbaa !23
  store i32 %t37, ptr %l21, !tbaa !23
  br label %bb10
bb8:
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb10:
  %t38 = load i32, ptr %l21, !tbaa !23
  store i32 %t38, ptr %l4, !tbaa !23
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/lower:lowering", ptr %t39, i32 0, i32 13
  %t42 = load i32, ptr %l3, !tbaa !23
  %t44 = sext i32 %t42 to i64
  %t47 = call { i32, { i64, [1 x i64] } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fmir_3aScopeRef_3e__H593d82357dc98d1f15fac9dd5b09c001(ptr %v0, ptr %t41, i64 %t44)
  %t48 = extractvalue { i32, { i64, [1 x i64] } } %t47, 1
  %t49 = extractvalue { i32, { i64, [1 x i64] } } %t47, 0
  store i32 %t49, ptr %l34
  %t50 = icmp ne i32 %t49, 0
  br i1 %t50, label %bb12, label %ok.51, !prof !99
ok.51:
  store { i64, [1 x i64] } %t48, ptr %l33
  br label %bb11
bb11:
  %t52 = load { i64, [1 x i64] }, ptr %l33
  store { i64, [1 x i64] } %t52, ptr %l28
  br label %bb14
bb12:
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb14:
  %t53 = load { i64, [1 x i64] }, ptr %l28
  store { i64, [1 x i64] } %t53, ptr %l5
  %t54 = load i32, ptr %l3, !tbaa !23
  store i32 %t54, ptr %l6, !tbaa !23
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/lower:lowering", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = getelementptr %"compiler/typed:Body", ptr %t61, i32 0, i32 7
  %t64 = load i32, ptr %l3, !tbaa !23
  %t66 = sext i32 %t64 to i64
  %t69 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t63, i64 %t66)
  store %"compiler/typed:Local" %t69, ptr %l43
  br label %bb15
bb15:
  %t70 = getelementptr %"compiler/typed:Local", ptr %l43, i32 0, i32 2
  %t71 = load i32, ptr %t70, !tbaa !23
  store i32 %t71, ptr %l7, !tbaa !23
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/lower:lowering", ptr %t73, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = getelementptr %"compiler/typed:Body", ptr %t76, i32 0, i32 7
  %t79 = load i32, ptr %l3, !tbaa !23
  %t81 = sext i32 %t79 to i64
  %t84 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t78, i64 %t81)
  store %"compiler/typed:Local" %t84, ptr %l50
  br label %bb16
bb16:
  %t85 = getelementptr %"compiler/typed:Local", ptr %l50, i32 0, i32 1
  %t86 = load %"compiler/source:Span", ptr %t85
  store %"compiler/source:Span" %t86, ptr %l8
  %t88 = load i32, ptr %l4, !tbaa !23
  %t89 = load i32, ptr %l6, !tbaa !23
  %t92 = icmp ne i32 %t88, %t89
  br i1 %t92, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s5
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load %"compiler/source:Span", ptr %l8
  %t96 = load i32, ptr %l6, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t97
  %t98 = getelementptr { i64, [21 x i64] }, ptr %t97, i32 0, i32 0
  store i64 1, ptr %t98
  %t100 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t95, 0
  %t102 = insertvalue { %"compiler/source:Span", i32 } %t100, i32 %t96, 1
  %t103 = getelementptr { i64, [21 x i64] }, ptr %t97, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t102, ptr %t103
  %t104 = load { i64, [21 x i64] }, ptr %t97
  %t106 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 176, i64 8)
  store { i64, [21 x i64] } %t104, ptr %t106
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s5, ptr %t94, ptr %t106)
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s5)
  br label %bb20
bb20:
  %t109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t109, ptr %l60, !tbaa !29
  %t110 = load i32, ptr %l4, !tbaa !23
  %t112 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t110)
  store %"compiler/mir:Lvalue" %t112, ptr %l62
  br label %bb21
bb21:
  store { i64, [4 x i64] } zeroinitializer, ptr %t113
  %t114 = getelementptr { i64, [4 x i64] }, ptr %t113, i32 0, i32 0
  store i64 1, ptr %t114
  %t115 = load %"compiler/mir:Lvalue", ptr %l62
  %t116 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t115, 0
  %t117 = getelementptr { i64, [4 x i64] }, ptr %t113, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t116, ptr %t117
  %t118 = load { i64, [4 x i64] }, ptr %t113
  %t119 = load i32, ptr %l7, !tbaa !23
  %t120 = load { i64, [1 x i64] }, ptr %l5
  %t121 = load %"compiler/source:Span", ptr %l8
  %t122 = load ptr, ptr %l60, !tbaa !29
  %t127 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eownCopyOf(ptr %v0, ptr %t122, { i64, [4 x i64] } %t118, i32 %t119, { i64, [1 x i64] } %t120, %"compiler/source:Span" %t121, i1 false)
  store { i64, [4 x i64] } %t127, ptr %l67
  br label %bb22
bb22:
  %t128 = load { i64, [4 x i64] }, ptr %l67
  store { i64, [4 x i64] } %t128, ptr %l9
  %t129 = load ptr, ptr %l0, !tbaa !29
  store ptr %t129, ptr %l68, !tbaa !29
  %t130 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t130, ptr %l69
  %t131 = load i32, ptr %l6, !tbaa !23
  %t133 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t131)
  store %"compiler/mir:Lvalue" %t133, ptr %l71
  br label %bb23
bb23:
  %t134 = load { i64, [4 x i64] }, ptr %l9
  store { i64, [15 x i64] } zeroinitializer, ptr %t135
  %t136 = getelementptr { i64, [15 x i64] }, ptr %t135, i32 0, i32 0
  store i64 0, ptr %t136
  %t138 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t134, 0
  %t139 = getelementptr { i64, [15 x i64] }, ptr %t135, i32 0, i32 1
  store { { i64, [4 x i64] } } %t138, ptr %t139
  %t140 = load { i64, [15 x i64] }, ptr %t135
  store { i64, [21 x i64] } zeroinitializer, ptr %t141
  %t142 = getelementptr { i64, [21 x i64] }, ptr %t141, i32 0, i32 0
  store i64 0, ptr %t142
  %t143 = load %"compiler/source:Span", ptr %l69
  %t144 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t143, 0
  %t145 = load %"compiler/mir:Lvalue", ptr %l71
  %t146 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t144, %"compiler/mir:Lvalue" %t145, 1
  %t148 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t146, { i64, [15 x i64] } %t140, 2
  %t149 = getelementptr { i64, [21 x i64] }, ptr %t141, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t148, ptr %t149
  %t150 = load { i64, [21 x i64] }, ptr %t141
  %t152 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 176, i64 8)
  store { i64, [21 x i64] } %t150, ptr %t152
  %t153 = load ptr, ptr %l68, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s2, ptr %t153, ptr %t152)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb25:
  %t155 = load i64, ptr %l2, !tbaa !24
  %t157 = add i64 %t155, 1
  store i64 %t157, ptr %l2, !tbaa !24
  br label %bb1
bb26:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ederef(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca { i64, [4 x i64] }
  %l8 = alloca { i64, [4 x i64] }
  %l12 = alloca %"compiler/lower:pl"
  %l13 = alloca ptr
  %l14 = alloca { i64, [4 x i64] }
  %l16 = alloca i32
  %l18 = alloca i32
  %l19 = alloca ptr
  %l22 = alloca %"compiler/lower:pl"
  %l24 = alloca %"compiler/lower:pl"
  %rv = alloca %"compiler/lower:pl"
  %t13 = alloca { i64, [2 x i64] }, align 8
  %t33 = alloca { i64, [2 x i64] }, align 8
  %t41 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t6 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store { i64, [4 x i64] } %t6, ptr %l8
  br label %bb1
bb1:
  %t7 = load { i64, [4 x i64] }, ptr %l8
  store { i64, [4 x i64] } %t7, ptr %l3
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/lower:lowering", ptr %t8, i32 0, i32 10
  %t11 = load i1, ptr %t10, !tbaa !21
  br i1 %t11, label %bb2, label %bb3
bb2:
  store { i64, [2 x i64] } zeroinitializer, ptr %t13
  %t14 = getelementptr { i64, [2 x i64] }, ptr %t13, i32 0, i32 0
  store i64 0, ptr %t14
  %t15 = load { i64, [2 x i64] }, ptr %t13
  %t17 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %v2, { i64, [2 x i64] } %t15)
  store %"compiler/lower:pl" %t17, ptr %l12
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t18 = load %"compiler/lower:pl", ptr %l12
  store %"compiler/lower:pl" %t18, ptr %rv
  br label %ret
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l13, !tbaa !29
  %t20 = load { i64, [4 x i64] }, ptr %l3
  store { i64, [4 x i64] } %t20, ptr %l14
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t21)
  store i32 %t23, ptr %l16
  br label %bb6
bb6:
  %t25 = load ptr, ptr %l13, !tbaa !29
  %t26 = load { i64, [4 x i64] }, ptr %l14
  %t27 = load i32, ptr %l16, !tbaa !23
  %t29 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %t25, { i64, [4 x i64] } %t26, i32 %t27, %"compiler/source:Span" %a2)
  store i32 %t29, ptr %l18
  br label %bb7
bb7:
  %t30 = load i32, ptr %l18, !tbaa !23
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l19, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t33
  %t34 = getelementptr { i64, [2 x i64] }, ptr %t33, i32 0, i32 0
  store i64 1, ptr %t34
  %t36 = insertvalue { i32 } undef, i32 %t30, 0
  %t37 = getelementptr { i64, [2 x i64] }, ptr %t33, i32 0, i32 1
  store { i32 } %t36, ptr %t37
  %t38 = load { i64, [2 x i64] }, ptr %t33
  %t40 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %v2, { i64, [2 x i64] } %t38)
  store %"compiler/lower:pl" %t40, ptr %l22
  br label %bb8
bb8:
  store { i64, [1 x i64] } zeroinitializer, ptr %t41
  %t42 = getelementptr { i64, [1 x i64] }, ptr %t41, i32 0, i32 0
  store i64 3, ptr %t42
  %t43 = load { i64, [1 x i64] }, ptr %t41
  %t44 = load ptr, ptr %l19, !tbaa !29
  %t45 = load %"compiler/lower:pl", ptr %l22
  %t47 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %v2, ptr %v2, ptr %t44, %"compiler/lower:pl" %t45, { i64, [1 x i64] } %t43)
  store %"compiler/lower:pl" %t47, ptr %l24
  br label %bb9
bb9:
  %t48 = load %"compiler/lower:pl", ptr %l24
  store %"compiler/lower:pl" %t48, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:pl", ptr %rv
  ret %"compiler/lower:pl" %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eeachIndex(ptr %v0, ptr %v1, ptr %a0, { i64, [4 x i64] } %a1, %"compiler/source:Span" %a2, ptr %a3c, ptr %a3e) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca %"compiler/source:Span"
  %l16 = alloca %"compiler/mir:Lvalue"
  %l18 = alloca { i64, [4 x i64] }
  %l24 = alloca i32
  %l27 = alloca i32
  %l30 = alloca i32
  %l35 = alloca ptr
  %l36 = alloca i32
  %l37 = alloca i32
  %l39 = alloca %"compiler/mir:Lvalue"
  %l42 = alloca { i64, ptr }
  %l44 = alloca { i64, [4 x i64] }
  %l54 = alloca ptr
  %l55 = alloca %"compiler/source:Span"
  %l57 = alloca %"compiler/mir:Lvalue"
  %l58 = alloca i32
  %l59 = alloca i32
  %l61 = alloca ptr
  %l63 = alloca %"compiler/mir:Lvalue"
  %l64 = alloca { i64, [4 x i64] }
  %l66 = alloca { i64, [4 x i64] }
  %l67 = alloca { i64, ptr }
  %l68 = alloca %"compiler/mir:Range"
  %s0 = alloca %olang.scope
  %t17 = alloca { i64, [15 x i64] }, align 8
  %t23 = alloca { i64, [21 x i64] }, align 8
  %t68 = alloca { i64, [4 x i64] }, align 8
  %t99 = alloca { i64, [8 x i64] }, align 8
  %t133 = alloca { i64, [4 x i64] }, align 8
  %t157 = alloca { i64, [15 x i64] }, align 8
  %t167 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a2, ptr %l2
  %pf3 = insertvalue { ptr, ptr } undef, ptr %a3c, 0
  %pg3 = insertvalue { ptr, ptr } %pf3, ptr %a3e, 1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t3 = load %"compiler/source:Span", ptr %l2
  %t7 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t1, i32 %t2, %"compiler/source:Span" %t3)
  store i32 %t7, ptr %l12
  br label %bb1
bb1:
  %t8 = load i32, ptr %l12, !tbaa !23
  store i32 %t8, ptr %l4, !tbaa !23
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l13, !tbaa !29
  %t10 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t10, ptr %l14
  %t11 = load i32, ptr %l4, !tbaa !23
  %t13 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t11)
  store %"compiler/mir:Lvalue" %t13, ptr %l16
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t14, i64 0)
  store { i64, [4 x i64] } %t16, ptr %l18
  br label %bb3
bb3:
  store { i64, [15 x i64] } zeroinitializer, ptr %t17
  %t18 = getelementptr { i64, [15 x i64] }, ptr %t17, i32 0, i32 0
  store i64 0, ptr %t18
  %t19 = load { i64, [4 x i64] }, ptr %l18
  %t20 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t19, 0
  %t21 = getelementptr { i64, [15 x i64] }, ptr %t17, i32 0, i32 1
  store { { i64, [4 x i64] } } %t20, ptr %t21
  %t22 = load { i64, [15 x i64] }, ptr %t17
  store { i64, [21 x i64] } zeroinitializer, ptr %t23
  %t24 = getelementptr { i64, [21 x i64] }, ptr %t23, i32 0, i32 0
  store i64 0, ptr %t24
  %t25 = load %"compiler/source:Span", ptr %l14
  %t26 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t25, 0
  %t27 = load %"compiler/mir:Lvalue", ptr %l16
  %t28 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t26, %"compiler/mir:Lvalue" %t27, 1
  %t30 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t28, { i64, [15 x i64] } %t22, 2
  %t31 = getelementptr { i64, [21 x i64] }, ptr %t23, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t30, ptr %t31
  %t32 = load { i64, [21 x i64] }, ptr %t23
  %t34 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t32, ptr %t34
  %t35 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t35, ptr %t34)
  br label %bb4
bb4:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/lower:lowering", ptr %t37, i32 0, i32 3
  %t41 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t39)
  store i32 %t41, ptr %l24
  br label %bb5
bb5:
  %t42 = load i32, ptr %l24, !tbaa !23
  store i32 %t42, ptr %l5, !tbaa !23
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/lower:lowering", ptr %t43, i32 0, i32 3
  %t47 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t45)
  store i32 %t47, ptr %l27
  br label %bb6
bb6:
  %t48 = load i32, ptr %l27, !tbaa !23
  store i32 %t48, ptr %l6, !tbaa !23
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/lower:lowering", ptr %t49, i32 0, i32 3
  %t53 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t51)
  store i32 %t53, ptr %l30
  br label %bb7
bb7:
  %t54 = load i32, ptr %l30, !tbaa !23
  store i32 %t54, ptr %l7, !tbaa !23
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load i32, ptr %l5, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t55, i32 %t56)
  br label %bb8
bb8:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load i32, ptr %l5, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t59, i32 %t60)
  br label %bb9
bb9:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l35, !tbaa !29
  store i32 15, ptr %l36
  %t64 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t64, ptr %l37, !tbaa !23
  %t65 = load i32, ptr %l4, !tbaa !23
  %t67 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t65)
  store %"compiler/mir:Lvalue" %t67, ptr %l39
  br label %bb10
bb10:
  store { i64, [4 x i64] } zeroinitializer, ptr %t68
  %t69 = getelementptr { i64, [4 x i64] }, ptr %t68, i32 0, i32 0
  store i64 1, ptr %t69
  %t70 = load %"compiler/mir:Lvalue", ptr %l39
  %t71 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t70, 0
  %t72 = getelementptr { i64, [4 x i64] }, ptr %t68, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t71, ptr %t72
  %t73 = load { i64, [4 x i64] }, ptr %t68
  %t75 = mul i64 2, 40
  %t76 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t75)
  %t77 = insertvalue { i64, ptr } undef, i64 2, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t76, 1
  store { i64, ptr } %t78, ptr %l42, !tbaa !27
  %t80 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr { i64, [4 x i64] }, ptr %t81, i64 0
  store { i64, [4 x i64] } %t73, ptr %t82
  %t84 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = getelementptr { i64, [4 x i64] }, ptr %t85, i64 1
  store { i64, [4 x i64] } %a1, ptr %t86
  %t87 = load %"compiler/source:Span", ptr %l2
  %t88 = load ptr, ptr %l35, !tbaa !29
  %t89 = load i32, ptr %l36, !range !{i32 0, i32 52}
  %t90 = load i32, ptr %l37, !tbaa !23
  %t91 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t93 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %t88, i32 %t89, i32 %t90, { i64, ptr } %t91, %"compiler/source:Span" %t87)
  store { i64, [4 x i64] } %t93, ptr %l44
  br label %bb11
bb11:
  %t94 = load { i64, [4 x i64] }, ptr %l44
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = load i32, ptr %l6, !tbaa !23
  %t98 = load i32, ptr %l7, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t99
  %t100 = getelementptr { i64, [8 x i64] }, ptr %t99, i32 0, i32 0
  store i64 2, ptr %t100
  %t102 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t94, 0
  %t104 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t102, i32 %t97, 1
  %t106 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t104, i32 %t98, 2
  %t107 = getelementptr { i64, [8 x i64] }, ptr %t99, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t106, ptr %t107
  %t108 = load { i64, [8 x i64] }, ptr %t99
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t95, { i64, [8 x i64] } %t108)
  br label %bb12
bb12:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t111, i32 %t112)
  br label %bb13
bb13:
  %t116 = load i32, ptr %l4, !tbaa !23
  %t118 = extractvalue { ptr, ptr } %pg3, 0
  %t119 = extractvalue { ptr, ptr } %pg3, 1
  call void %t118(ptr %t119, i32 %t116)
  br label %bb14
bb14:
  %t121 = load ptr, ptr %l0, !tbaa !29
  store ptr %t121, ptr %l54, !tbaa !29
  %t122 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t122, ptr %l55
  %t123 = load i32, ptr %l4, !tbaa !23
  %t125 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t123)
  store %"compiler/mir:Lvalue" %t125, ptr %l57
  br label %bb15
bb15:
  store i32 3, ptr %l58
  %t126 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t126, ptr %l59, !tbaa !23
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/lower:lowering", ptr %t127, i32 0, i32 3
  store ptr %t129, ptr %l61, !tbaa !29
  %t130 = load i32, ptr %l4, !tbaa !23
  %t132 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t130)
  store %"compiler/mir:Lvalue" %t132, ptr %l63
  br label %bb16
bb16:
  store { i64, [4 x i64] } zeroinitializer, ptr %t133
  %t134 = getelementptr { i64, [4 x i64] }, ptr %t133, i32 0, i32 0
  store i64 1, ptr %t134
  %t135 = load %"compiler/mir:Lvalue", ptr %l63
  %t136 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t135, 0
  %t137 = getelementptr { i64, [4 x i64] }, ptr %t133, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t136, ptr %t137
  %t138 = load { i64, [4 x i64] }, ptr %t133
  store { i64, [4 x i64] } %t138, ptr %l64
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t139, i64 1)
  store { i64, [4 x i64] } %t141, ptr %l66
  br label %bb17
bb17:
  %t142 = mul i64 2, 40
  %t143 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t142)
  %t144 = insertvalue { i64, ptr } undef, i64 2, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t143, 1
  store { i64, ptr } %t145, ptr %l67, !tbaa !27
  %t146 = load { i64, [4 x i64] }, ptr %l64
  %t147 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !27
  %t149 = getelementptr { i64, [4 x i64] }, ptr %t148, i64 0
  store { i64, [4 x i64] } %t146, ptr %t149
  %t150 = load { i64, [4 x i64] }, ptr %l66
  %t151 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr { i64, [4 x i64] }, ptr %t152, i64 1
  store { i64, [4 x i64] } %t150, ptr %t153
  %t154 = load ptr, ptr %l61, !tbaa !29
  %t155 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t156 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %s0, ptr %t154, { i64, ptr } %t155)
  store %"compiler/mir:Range" %t156, ptr %l68
  br label %bb18
bb18:
  store { i64, [15 x i64] } zeroinitializer, ptr %t157
  %t158 = getelementptr { i64, [15 x i64] }, ptr %t157, i32 0, i32 0
  store i64 3, ptr %t158
  %t159 = load i32, ptr %l58, !range !{i32 0, i32 52}
  %t160 = insertvalue { i32, i32, %"compiler/mir:Range" } undef, i32 %t159, 0
  %t161 = load i32, ptr %l59, !tbaa !23
  %t162 = insertvalue { i32, i32, %"compiler/mir:Range" } %t160, i32 %t161, 1
  %t163 = load %"compiler/mir:Range", ptr %l68
  %t164 = insertvalue { i32, i32, %"compiler/mir:Range" } %t162, %"compiler/mir:Range" %t163, 2
  %t165 = getelementptr { i64, [15 x i64] }, ptr %t157, i32 0, i32 1
  store { i32, i32, %"compiler/mir:Range" } %t164, ptr %t165
  %t166 = load { i64, [15 x i64] }, ptr %t157
  store { i64, [21 x i64] } zeroinitializer, ptr %t167
  %t168 = getelementptr { i64, [21 x i64] }, ptr %t167, i32 0, i32 0
  store i64 0, ptr %t168
  %t169 = load %"compiler/source:Span", ptr %l55
  %t170 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t169, 0
  %t171 = load %"compiler/mir:Lvalue", ptr %l57
  %t172 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t170, %"compiler/mir:Lvalue" %t171, 1
  %t174 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t172, { i64, [15 x i64] } %t166, 2
  %t175 = getelementptr { i64, [21 x i64] }, ptr %t167, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t174, ptr %t175
  %t176 = load { i64, [21 x i64] }, ptr %t167
  %t178 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t176, ptr %t178
  %t179 = load ptr, ptr %l54, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t179, ptr %t178)
  br label %bb19
bb19:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load i32, ptr %l5, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t181, i32 %t182)
  br label %bb20
bb20:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load i32, ptr %l7, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t185, i32 %t186)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eerrCaught(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca { i64, [4 x i64] }
  %l8 = alloca %"compiler/lower:pl"
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i32
  %l17 = alloca i64
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i32
  %l22 = alloca %"compiler/mir:Lvalue"
  %l29 = alloca i32
  %l33 = alloca i32
  %l34 = alloca ptr
  %l35 = alloca %"compiler/source:Span"
  %l37 = alloca %"compiler/mir:Lvalue"
  %l43 = alloca ptr
  %l44 = alloca i32
  %l48 = alloca { i64, [4 x i64] }
  %l51 = alloca { i64, [4 x i64] }
  %l54 = alloca %"compiler/lower:pl"
  %l55 = alloca ptr
  %l56 = alloca %"compiler/source:Span"
  %l57 = alloca ptr
  %l58 = alloca ptr
  %l59 = alloca %"compiler/lower:pl"
  %l61 = alloca %"compiler/lower:pl"
  %l63 = alloca %"compiler/lower:pl"
  %l64 = alloca %"compiler/mir:Lvalue"
  %l69 = alloca ptr
  %l72 = alloca i32
  %l73 = alloca { i64, ptr }
  %l79 = alloca i64
  %l82 = alloca i64
  %l102 = alloca ptr
  %l104 = alloca { i64, ptr }
  %l107 = alloca i32
  %l108 = alloca i32
  %l117 = alloca i64
  %l120 = alloca i32
  %l123 = alloca i32
  %l124 = alloca ptr
  %l129 = alloca { i64, [4 x i64] }
  %l138 = alloca i32
  %l139 = alloca ptr
  %l145 = alloca { i64, [4 x i64] }
  %l148 = alloca i32
  %l154 = alloca { i64, ptr }
  %l155 = alloca %"compiler/mir:Lvalue"
  %l156 = alloca ptr
  %l157 = alloca %"compiler/source:Span"
  %l158 = alloca ptr
  %l159 = alloca ptr
  %l160 = alloca %"compiler/lower:pl"
  %l162 = alloca %"compiler/lower:pl"
  %l165 = alloca %"compiler/lower:pl"
  %l166 = alloca %"compiler/mir:Lvalue"
  %l179 = alloca %"compiler/mir:Lvalue"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t30 = alloca { i64, [4 x i64] }, align 8
  %t37 = alloca { i64, [15 x i64] }, align 8
  %t43 = alloca { i64, [21 x i64] }, align 8
  %t66 = alloca { i64, [15 x i64] }, align 8
  %t80 = alloca { i64, [2 x i64] }, align 8
  %t96 = alloca { i64, [1 x i64] }, align 8
  %t109 = alloca { i64, [15 x i64] }, align 8
  %t115 = alloca { i64, [21 x i64] }, align 8
  %t255 = alloca { i64, [8 x i64] }, align 8
  %t283 = alloca { i64, [15 x i64] }, align 8
  %t307 = alloca { i64, [2 x i64] }, align 8
  %t313 = alloca { i64, [1 x i64] }, align 8
  %t337 = alloca { i64, [1 x i64] }, align 8
  %t351 = alloca { i64, [4 x i64] }, align 8
  %t357 = alloca { i64, [15 x i64] }, align 8
  %t363 = alloca { i64, [21 x i64] }, align 8
  %t392 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l2, !tbaa !23
  %t9 = load %"compiler/source:Span", ptr %l3
  %t14 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %t6, { i64, [4 x i64] } %a1, i32 %t8, %"compiler/source:Span" %t9)
  store i32 %t14, ptr %l29
  br label %bb1
bb1:
  %t15 = load i32, ptr %l29, !tbaa !23
  store i32 %t15, ptr %l5, !tbaa !23
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  %t18 = load %"compiler/source:Span", ptr %l3
  %t22 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t16, i32 %t17, %"compiler/source:Span" %t18)
  store i32 %t22, ptr %l33
  br label %bb2
bb2:
  %t23 = load i32, ptr %l33, !tbaa !23
  store i32 %t23, ptr %l6, !tbaa !23
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l34, !tbaa !29
  %t25 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t25, ptr %l35
  %t26 = load i32, ptr %l6, !tbaa !23
  %t28 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t26)
  store %"compiler/mir:Lvalue" %t28, ptr %l37
  br label %bb3
bb3:
  %t29 = load i32, ptr %l2, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t30
  %t31 = getelementptr { i64, [4 x i64] }, ptr %t30, i32 0, i32 0
  store i64 2, ptr %t31
  %t33 = insertvalue { i32, i64 } undef, i32 %t29, 0
  %t34 = insertvalue { i32, i64 } %t33, i64 0, 1
  %t35 = getelementptr { i64, [4 x i64] }, ptr %t30, i32 0, i32 1
  store { i32, i64 } %t34, ptr %t35
  %t36 = load { i64, [4 x i64] }, ptr %t30
  store { i64, [15 x i64] } zeroinitializer, ptr %t37
  %t38 = getelementptr { i64, [15 x i64] }, ptr %t37, i32 0, i32 0
  store i64 0, ptr %t38
  %t40 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t36, 0
  %t41 = getelementptr { i64, [15 x i64] }, ptr %t37, i32 0, i32 1
  store { { i64, [4 x i64] } } %t40, ptr %t41
  %t42 = load { i64, [15 x i64] }, ptr %t37
  store { i64, [21 x i64] } zeroinitializer, ptr %t43
  %t44 = getelementptr { i64, [21 x i64] }, ptr %t43, i32 0, i32 0
  store i64 0, ptr %t44
  %t45 = load %"compiler/source:Span", ptr %l35
  %t46 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t45, 0
  %t47 = load %"compiler/mir:Lvalue", ptr %l37
  %t48 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t46, %"compiler/mir:Lvalue" %t47, 1
  %t50 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t48, { i64, [15 x i64] } %t42, 2
  %t51 = getelementptr { i64, [21 x i64] }, ptr %t43, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t50, ptr %t51
  %t52 = load { i64, [21 x i64] }, ptr %t43
  %t54 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t52, ptr %t54
  %t55 = load ptr, ptr %l34, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t55, ptr %t54)
  br label %bb4
bb4:
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l43, !tbaa !29
  %t58 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  store i32 %t58, ptr %l44, !tbaa !23
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load i32, ptr %l5, !tbaa !23
  %t61 = load i32, ptr %l2, !tbaa !23
  %t65 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eerrCodeOf(ptr %v0, ptr %t59, i32 %t60, i32 %t61)
  store { i64, [4 x i64] } %t65, ptr %l48
  br label %bb5
bb5:
  store { i64, [15 x i64] } zeroinitializer, ptr %t66
  %t67 = getelementptr { i64, [15 x i64] }, ptr %t66, i32 0, i32 0
  store i64 0, ptr %t67
  %t68 = load { i64, [4 x i64] }, ptr %l48
  %t69 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t68, 0
  %t70 = getelementptr { i64, [15 x i64] }, ptr %t66, i32 0, i32 1
  store { { i64, [4 x i64] } } %t69, ptr %t70
  %t71 = load { i64, [15 x i64] }, ptr %t66
  %t72 = load %"compiler/source:Span", ptr %l3
  %t73 = load ptr, ptr %l43, !tbaa !29
  %t74 = load i32, ptr %l44, !tbaa !23
  %t77 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t73, i32 %t74, { i64, [15 x i64] } %t71, %"compiler/source:Span" %t72)
  store { i64, [4 x i64] } %t77, ptr %l51
  br label %bb6
bb6:
  %t78 = load { i64, [4 x i64] }, ptr %l51
  store { i64, [4 x i64] } %t78, ptr %l7
  %t79 = load i32, ptr %l6, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t80
  %t81 = getelementptr { i64, [2 x i64] }, ptr %t80, i32 0, i32 0
  store i64 1, ptr %t81
  %t83 = insertvalue { i32 } undef, i32 %t79, 0
  %t84 = getelementptr { i64, [2 x i64] }, ptr %t80, i32 0, i32 1
  store { i32 } %t83, ptr %t84
  %t85 = load { i64, [2 x i64] }, ptr %t80
  %t87 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %s0, { i64, [2 x i64] } %t85)
  store %"compiler/lower:pl" %t87, ptr %l54
  br label %bb7
bb7:
  %t88 = load %"compiler/lower:pl", ptr %l54
  store %"compiler/lower:pl" %t88, ptr %l8
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l55, !tbaa !29
  %t90 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t90, ptr %l56
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l57, !tbaa !29
  %t92 = load ptr, ptr %l0, !tbaa !29
  store ptr %t92, ptr %l58, !tbaa !29
  %t93 = load %"compiler/lower:pl", ptr %l8
  store %"compiler/lower:pl" %t93, ptr %l59
  %t95 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s0, ptr %l59)
  store %"compiler/lower:pl" %t95, ptr %l61
  br label %bb8
bb8:
  store { i64, [1 x i64] } zeroinitializer, ptr %t96
  %t97 = getelementptr { i64, [1 x i64] }, ptr %t96, i32 0, i32 0
  store i64 0, ptr %t97
  %t98 = insertvalue { i64 } undef, i64 0, 0
  %t99 = getelementptr { i64, [1 x i64] }, ptr %t96, i32 0, i32 1
  store { i64 } %t98, ptr %t99
  %t100 = load { i64, [1 x i64] }, ptr %t96
  %t101 = load ptr, ptr %l58, !tbaa !29
  %t102 = load %"compiler/lower:pl", ptr %l61
  %t104 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %s0, ptr %s0, ptr %t101, %"compiler/lower:pl" %t102, { i64, [1 x i64] } %t100)
  store %"compiler/lower:pl" %t104, ptr %l63
  br label %bb9
bb9:
  %t105 = load ptr, ptr %l57, !tbaa !29
  %t106 = load %"compiler/lower:pl", ptr %l63
  %t107 = call %"compiler/mir:Lvalue" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %s0, ptr %t105, %"compiler/lower:pl" %t106)
  store %"compiler/mir:Lvalue" %t107, ptr %l64
  br label %bb10
bb10:
  %t108 = load { i64, [4 x i64] }, ptr %l7
  store { i64, [15 x i64] } zeroinitializer, ptr %t109
  %t110 = getelementptr { i64, [15 x i64] }, ptr %t109, i32 0, i32 0
  store i64 0, ptr %t110
  %t112 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t108, 0
  %t113 = getelementptr { i64, [15 x i64] }, ptr %t109, i32 0, i32 1
  store { { i64, [4 x i64] } } %t112, ptr %t113
  %t114 = load { i64, [15 x i64] }, ptr %t109
  store { i64, [21 x i64] } zeroinitializer, ptr %t115
  %t116 = getelementptr { i64, [21 x i64] }, ptr %t115, i32 0, i32 0
  store i64 0, ptr %t116
  %t117 = load %"compiler/source:Span", ptr %l56
  %t118 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t117, 0
  %t119 = load %"compiler/mir:Lvalue", ptr %l64
  %t120 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t118, %"compiler/mir:Lvalue" %t119, 1
  %t122 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t120, { i64, [15 x i64] } %t114, 2
  %t123 = getelementptr { i64, [21 x i64] }, ptr %t115, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t122, ptr %t123
  %t124 = load { i64, [21 x i64] }, ptr %t115
  %t126 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t124, ptr %t126
  %t127 = load ptr, ptr %l55, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t127, ptr %t126)
  br label %bb11
bb11:
  %t129 = load ptr, ptr %l4, !tbaa !29
  store ptr %t129, ptr %l69, !tbaa !29
  %t130 = load ptr, ptr %l4, !tbaa !29
  %t131 = load i32, ptr %l2, !tbaa !23
  %t134 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %t130, i32 %t131)
  store i32 %t134, ptr %l72
  br label %bb12
bb12:
  %t135 = load ptr, ptr %l69, !tbaa !29
  %t136 = load i32, ptr %l72, !tbaa !23
  %t137 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t135, i32 %t136)
  store { i64, ptr } %t137, ptr %l73
  br label %bb13
bb13:
  %t138 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t138, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t139 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t139, 0
  store i64 %t141, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t143 = load i64, ptr %l11, !tbaa !24
  %t144 = load i64, ptr %l10, !tbaa !24
  %t147 = icmp sgt i64 %t143, %t144
  br i1 %t147, label %bb14, label %bb15
bb14:
  %t149 = load i64, ptr %l12, !tbaa !24
  %t151 = icmp sgt i64 %t149, 0
  br i1 %t151, label %bb16, label %bb17
bb15:
  store i64 0, ptr %l79, !tbaa !24
  br label %bb19
bb16:
  %t153 = load i64, ptr %l11, !tbaa !24
  %t154 = load i64, ptr %l10, !tbaa !24
  %t157 = sub i64 %t153, %t154
  %t158 = load i64, ptr %l12, !tbaa !24
  %t161 = add i64 %t157, %t158
  %t163 = sub i64 %t161, 1
  %t164 = load i64, ptr %l12, !tbaa !24
  %t167 = sdiv i64 %t163, %t164
  store i64 %t167, ptr %l82, !tbaa !24
  br label %bb18
bb17:
  store i64 0, ptr %l82, !tbaa !24
  br label %bb18
bb18:
  %t169 = load i64, ptr %l82, !tbaa !24
  store i64 %t169, ptr %l79, !tbaa !24
  br label %bb19
bb19:
  %t170 = load i64, ptr %l79, !tbaa !24
  store i64 %t170, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s2
  %t171 = load i64, ptr %l14, !tbaa !24
  %t172 = load i64, ptr %l13, !tbaa !24
  %t175 = icmp slt i64 %t171, %t172
  %t177 = xor i1 %t175, true
  br i1 %t177, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb46
bb22:
  br label %bb23
bb23:
  %t179 = load i64, ptr %l10, !tbaa !24
  %t180 = load i64, ptr %l14, !tbaa !24
  %t181 = load i64, ptr %l12, !tbaa !24
  %t184 = mul i64 %t180, %t181
  %t187 = add i64 %t179, %t184
  store i64 %t187, ptr %l15, !tbaa !24
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/lower:lowering", ptr %t189, i32 0, i32 0
  %t192 = load ptr, ptr %t191, !tbaa !29
  %t194 = getelementptr %"compiler/lower:Lowerer", ptr %t192, i32 0, i32 0
  %t195 = load ptr, ptr %t194, !tbaa !29
  store ptr %t195, ptr %l102, !tbaa !29
  %t196 = load ptr, ptr %l4, !tbaa !29
  %t197 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t197, ptr %l104, !tbaa !27
  %t198 = load i64, ptr %l15, !tbaa !24
  %t200 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !27
  %t202 = getelementptr i32, ptr %t201, i64 %t198
  %t203 = load i32, ptr %t202, !tbaa !33
  %t206 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t196, i32 %t203)
  store i32 %t206, ptr %l107
  br label %bb24
bb24:
  %t207 = load ptr, ptr %l102, !tbaa !29
  %t208 = load i32, ptr %l107, !tbaa !23
  %t209 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePayloadOf(ptr %v0, ptr %t207, i32 %t208)
  store i32 %t209, ptr %l108
  br label %bb25
bb25:
  %t210 = load i32, ptr %l108, !tbaa !23
  store i32 %t210, ptr %l16, !tbaa !23
  %t211 = load i32, ptr %l16, !tbaa !23
  %t212 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t215 = icmp eq i32 %t211, %t212
  br i1 %t215, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s2)
  br label %bb45
bb27:
  br label %bb28
bb28:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t219 = getelementptr %"compiler/lower:lowering", ptr %t217, i32 0, i32 0
  %t220 = load ptr, ptr %t219, !tbaa !29
  %t222 = getelementptr %"compiler/lower:Lowerer", ptr %t220, i32 0, i32 0
  %t223 = load ptr, ptr %t222, !tbaa !29
  %t224 = load i32, ptr %l2, !tbaa !23
  %t225 = load i64, ptr %l15, !tbaa !24
  %t229 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePayloadField(ptr %v0, ptr %t223, i32 %t224, i64 %t225)
  store i64 %t229, ptr %l117
  br label %bb29
bb29:
  %t230 = load i64, ptr %l117, !tbaa !24
  store i64 %t230, ptr %l17, !tbaa !24
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t233 = getelementptr %"compiler/lower:lowering", ptr %t231, i32 0, i32 3
  %t235 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t233)
  store i32 %t235, ptr %l120
  br label %bb30
bb30:
  %t236 = load i32, ptr %l120, !tbaa !23
  store i32 %t236, ptr %l18, !tbaa !23
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t239 = getelementptr %"compiler/lower:lowering", ptr %t237, i32 0, i32 3
  %t241 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t239)
  store i32 %t241, ptr %l123
  br label %bb31
bb31:
  %t242 = load i32, ptr %l123, !tbaa !23
  store i32 %t242, ptr %l19, !tbaa !23
  %t243 = load ptr, ptr %l0, !tbaa !29
  store ptr %t243, ptr %l124, !tbaa !29
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t245 = load { i64, [4 x i64] }, ptr %l7
  %t246 = load i64, ptr %l15, !tbaa !24
  %t247 = load %"compiler/source:Span", ptr %l3
  %t252 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2etypeIs(ptr %v0, ptr %t244, { i64, [4 x i64] } %t245, i64 %t246, %"compiler/source:Span" %t247)
  store { i64, [4 x i64] } %t252, ptr %l129
  br label %bb32
bb32:
  %t253 = load i32, ptr %l18, !tbaa !23
  %t254 = load i32, ptr %l19, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t255
  %t256 = getelementptr { i64, [8 x i64] }, ptr %t255, i32 0, i32 0
  store i64 2, ptr %t256
  %t257 = load { i64, [4 x i64] }, ptr %l129
  %t258 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t257, 0
  %t260 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t258, i32 %t253, 1
  %t262 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t260, i32 %t254, 2
  %t263 = getelementptr { i64, [8 x i64] }, ptr %t255, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t262, ptr %t263
  %t264 = load { i64, [8 x i64] }, ptr %t255
  %t265 = load ptr, ptr %l124, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t265, { i64, [8 x i64] } %t264)
  br label %bb33
bb33:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t268 = load i32, ptr %l18, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t267, i32 %t268)
  br label %bb34
bb34:
  %t271 = load ptr, ptr %l4, !tbaa !29
  %t272 = load i32, ptr %l16, !tbaa !23
  %t273 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t277 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t271, i32 %t272, i64 %t273)
  store i32 %t277, ptr %l138
  br label %bb35
bb35:
  %t278 = load i32, ptr %l138, !tbaa !23
  store i32 %t278, ptr %l20, !tbaa !23
  %t279 = load ptr, ptr %l0, !tbaa !29
  store ptr %t279, ptr %l139, !tbaa !29
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t281 = load i32, ptr %l20, !tbaa !23
  %t282 = load i32, ptr %l20, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t283
  %t284 = getelementptr { i64, [15 x i64] }, ptr %t283, i32 0, i32 0
  store i64 20, ptr %t284
  %t286 = insertvalue { i32 } undef, i32 %t282, 0
  %t287 = getelementptr { i64, [15 x i64] }, ptr %t283, i32 0, i32 1
  store { i32 } %t286, ptr %t287
  %t288 = load { i64, [15 x i64] }, ptr %t283
  %t289 = load %"compiler/source:Span", ptr %l3
  %t294 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t280, i32 %t281, { i64, [15 x i64] } %t288, %"compiler/source:Span" %t289)
  store { i64, [4 x i64] } %t294, ptr %l145
  br label %bb36
bb36:
  %t295 = load i32, ptr %l20, !tbaa !23
  %t296 = load %"compiler/source:Span", ptr %l3
  %t297 = load ptr, ptr %l139, !tbaa !29
  %t298 = load { i64, [4 x i64] }, ptr %l145
  %t301 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %t297, { i64, [4 x i64] } %t298, i32 %t295, %"compiler/source:Span" %t296)
  store i32 %t301, ptr %l148
  br label %bb37
bb37:
  %t302 = load i32, ptr %l148, !tbaa !23
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr %"compiler/lower:lowering", ptr %t303, i32 0, i32 3
  store { i64, [2 x i64] } zeroinitializer, ptr %t307
  %t308 = getelementptr { i64, [2 x i64] }, ptr %t307, i32 0, i32 0
  store i64 1, ptr %t308
  %t310 = insertvalue { i32 } undef, i32 %t302, 0
  %t311 = getelementptr { i64, [2 x i64] }, ptr %t307, i32 0, i32 1
  store { i32 } %t310, ptr %t311
  %t312 = load { i64, [2 x i64] }, ptr %t307
  store { i64, [1 x i64] } zeroinitializer, ptr %t313
  %t314 = getelementptr { i64, [1 x i64] }, ptr %t313, i32 0, i32 0
  store i64 3, ptr %t314
  %t315 = load { i64, [1 x i64] }, ptr %t313
  %t316 = mul i64 1, 16
  %t317 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t316)
  %t318 = insertvalue { i64, ptr } undef, i64 1, 0
  %t319 = insertvalue { i64, ptr } %t318, ptr %t317, 1
  store { i64, ptr } %t319, ptr %l154, !tbaa !27
  %t321 = getelementptr { i64, ptr }, ptr %l154, i32 0, i32 1
  %t322 = load ptr, ptr %t321, !tbaa !27
  %t323 = getelementptr { i64, [1 x i64] }, ptr %t322, i64 0
  store { i64, [1 x i64] } %t315, ptr %t323
  %t326 = load { i64, ptr }, ptr %l154, !tbaa !27
  %t327 = call %"compiler/mir:Lvalue" @compiler_2fmir_2ecompiler_2fmir_3aFn_2ePlace(ptr %v0, ptr %s2, ptr %t305, { i64, [2 x i64] } %t312, { i64, ptr } %t326)
  store %"compiler/mir:Lvalue" %t327, ptr %l155
  br label %bb38
bb38:
  %t328 = load %"compiler/mir:Lvalue", ptr %l155
  store %"compiler/mir:Lvalue" %t328, ptr %l22
  %t329 = load ptr, ptr %l0, !tbaa !29
  store ptr %t329, ptr %l156, !tbaa !29
  %t330 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t330, ptr %l157
  %t331 = load ptr, ptr %l0, !tbaa !29
  store ptr %t331, ptr %l158, !tbaa !29
  %t332 = load ptr, ptr %l0, !tbaa !29
  store ptr %t332, ptr %l159, !tbaa !29
  %t333 = load %"compiler/lower:pl", ptr %l8
  store %"compiler/lower:pl" %t333, ptr %l160
  %t335 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s2, ptr %l160)
  store %"compiler/lower:pl" %t335, ptr %l162
  br label %bb39
bb39:
  %t336 = load i64, ptr %l17, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t337
  %t338 = getelementptr { i64, [1 x i64] }, ptr %t337, i32 0, i32 0
  store i64 0, ptr %t338
  %t340 = insertvalue { i64 } undef, i64 %t336, 0
  %t341 = getelementptr { i64, [1 x i64] }, ptr %t337, i32 0, i32 1
  store { i64 } %t340, ptr %t341
  %t342 = load { i64, [1 x i64] }, ptr %t337
  %t343 = load ptr, ptr %l159, !tbaa !29
  %t344 = load %"compiler/lower:pl", ptr %l162
  %t346 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %s2, ptr %s2, ptr %t343, %"compiler/lower:pl" %t344, { i64, [1 x i64] } %t342)
  store %"compiler/lower:pl" %t346, ptr %l165
  br label %bb40
bb40:
  %t347 = load ptr, ptr %l158, !tbaa !29
  %t348 = load %"compiler/lower:pl", ptr %l165
  %t349 = call %"compiler/mir:Lvalue" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %s2, ptr %t347, %"compiler/lower:pl" %t348)
  store %"compiler/mir:Lvalue" %t349, ptr %l166
  br label %bb41
bb41:
  %t350 = load %"compiler/mir:Lvalue", ptr %l22
  store { i64, [4 x i64] } zeroinitializer, ptr %t351
  %t352 = getelementptr { i64, [4 x i64] }, ptr %t351, i32 0, i32 0
  store i64 1, ptr %t352
  %t354 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t350, 0
  %t355 = getelementptr { i64, [4 x i64] }, ptr %t351, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t354, ptr %t355
  %t356 = load { i64, [4 x i64] }, ptr %t351
  store { i64, [15 x i64] } zeroinitializer, ptr %t357
  %t358 = getelementptr { i64, [15 x i64] }, ptr %t357, i32 0, i32 0
  store i64 0, ptr %t358
  %t360 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t356, 0
  %t361 = getelementptr { i64, [15 x i64] }, ptr %t357, i32 0, i32 1
  store { { i64, [4 x i64] } } %t360, ptr %t361
  %t362 = load { i64, [15 x i64] }, ptr %t357
  store { i64, [21 x i64] } zeroinitializer, ptr %t363
  %t364 = getelementptr { i64, [21 x i64] }, ptr %t363, i32 0, i32 0
  store i64 0, ptr %t364
  %t365 = load %"compiler/source:Span", ptr %l157
  %t366 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t365, 0
  %t367 = load %"compiler/mir:Lvalue", ptr %l166
  %t368 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t366, %"compiler/mir:Lvalue" %t367, 1
  %t370 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t368, { i64, [15 x i64] } %t362, 2
  %t371 = getelementptr { i64, [21 x i64] }, ptr %t363, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t370, ptr %t371
  %t372 = load { i64, [21 x i64] }, ptr %t363
  %t374 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 176, i64 8)
  store { i64, [21 x i64] } %t372, ptr %t374
  %t375 = load ptr, ptr %l156, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s2, ptr %t375, ptr %t374)
  br label %bb42
bb42:
  %t377 = load ptr, ptr %l0, !tbaa !29
  %t378 = load i32, ptr %l19, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t377, i32 %t378)
  br label %bb43
bb43:
  %t381 = load ptr, ptr %l0, !tbaa !29
  %t382 = load i32, ptr %l19, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t381, i32 %t382)
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s2)
  br label %bb45
bb45:
  %t385 = load i64, ptr %l14, !tbaa !24
  %t387 = add i64 %t385, 1
  store i64 %t387, ptr %l14, !tbaa !24
  br label %bb20
bb46:
  %t389 = load i32, ptr %l6, !tbaa !23
  %t391 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t389)
  store %"compiler/mir:Lvalue" %t391, ptr %l179
  br label %bb47
bb47:
  store { i64, [4 x i64] } zeroinitializer, ptr %t392
  %t393 = getelementptr { i64, [4 x i64] }, ptr %t392, i32 0, i32 0
  store i64 1, ptr %t393
  %t394 = load %"compiler/mir:Lvalue", ptr %l179
  %t395 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t394, 0
  %t396 = getelementptr { i64, [4 x i64] }, ptr %t392, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t395, ptr %t396
  %t397 = load { i64, [4 x i64] }, ptr %t392
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t397, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eerrPush(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca { i64, [1 x i64] }
  %l6 = alloca { i64, [4 x i64] }
  %l7 = alloca i32
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca %"compiler/source:Span"
  %l16 = alloca %"compiler/mir:Lvalue"
  %l22 = alloca ptr
  %l23 = alloca { i64, [4 x i64] }
  %l24 = alloca i32
  %l25 = alloca { i64, [1 x i64] }
  %l29 = alloca %"compiler/source:Span"
  %l30 = alloca { i64, [4 x i64] }
  %l35 = alloca i32
  %l43 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  %t14 = alloca { i64, [15 x i64] }, align 8
  %t17 = alloca { i64, [21 x i64] }, align 8
  %t32 = alloca { i64, [1 x i64] }, align 8
  %t75 = alloca { i64, [15 x i64] }, align 8
  %t95 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t3 = load %"compiler/source:Span", ptr %l3
  %t7 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t1, i32 %t2, %"compiler/source:Span" %t3)
  store i32 %t7, ptr %l12
  br label %bb1
bb1:
  %t8 = load i32, ptr %l12, !tbaa !23
  store i32 %t8, ptr %l4, !tbaa !23
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l13, !tbaa !29
  %t10 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t10, ptr %l14
  %t11 = load i32, ptr %l4, !tbaa !23
  %t13 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t11)
  store %"compiler/mir:Lvalue" %t13, ptr %l16
  br label %bb2
bb2:
  store { i64, [15 x i64] } zeroinitializer, ptr %t14
  %t15 = getelementptr { i64, [15 x i64] }, ptr %t14, i32 0, i32 0
  store i64 19, ptr %t15
  %t16 = load { i64, [15 x i64] }, ptr %t14
  store { i64, [21 x i64] } zeroinitializer, ptr %t17
  %t18 = getelementptr { i64, [21 x i64] }, ptr %t17, i32 0, i32 0
  store i64 0, ptr %t18
  %t19 = load %"compiler/source:Span", ptr %l14
  %t20 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t19, 0
  %t21 = load %"compiler/mir:Lvalue", ptr %l16
  %t22 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t20, %"compiler/mir:Lvalue" %t21, 1
  %t24 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t22, { i64, [15 x i64] } %t16, 2
  %t25 = getelementptr { i64, [21 x i64] }, ptr %t17, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t24, ptr %t25
  %t26 = load { i64, [21 x i64] }, ptr %t17
  %t28 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t26, ptr %t28
  %t29 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t29, ptr %t28)
  br label %bb3
bb3:
  %t31 = load i32, ptr %l4, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t32
  %t33 = getelementptr { i64, [1 x i64] }, ptr %t32, i32 0, i32 0
  store i64 4, ptr %t33
  %t35 = insertvalue { i32 } undef, i32 %t31, 0
  %t36 = getelementptr { i64, [1 x i64] }, ptr %t32, i32 0, i32 1
  store { i32 } %t35, ptr %t36
  %t37 = load { i64, [1 x i64] }, ptr %t32
  store { i64, [1 x i64] } %t37, ptr %l5
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l22, !tbaa !29
  store { i64, [4 x i64] } %a1, ptr %l23
  %t41 = load i32, ptr %l2, !tbaa !23
  store i32 %t41, ptr %l24, !tbaa !23
  %t42 = load { i64, [1 x i64] }, ptr %l5
  store { i64, [1 x i64] } %t42, ptr %l25
  %t43 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t44 = load i32, ptr %t43, !tbaa !23
  %t46 = add i32 %t44, 1
  %t47 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 1
  %t48 = load i32, ptr %t47, !tbaa !23
  %t51 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t46, i32 %t48)
  store %"compiler/source:Span" %t51, ptr %l29
  br label %bb4
bb4:
  %t52 = load ptr, ptr %l22, !tbaa !29
  %t53 = load { i64, [4 x i64] }, ptr %l23
  %t54 = load i32, ptr %l24, !tbaa !23
  %t55 = load { i64, [1 x i64] }, ptr %l25
  %t56 = load %"compiler/source:Span", ptr %l29
  %t57 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eownCopyOf(ptr %v0, ptr %t52, { i64, [4 x i64] } %t53, i32 %t54, { i64, [1 x i64] } %t55, %"compiler/source:Span" %t56, i1 false)
  store { i64, [4 x i64] } %t57, ptr %l30
  br label %bb5
bb5:
  %t58 = load { i64, [4 x i64] }, ptr %l30
  store { i64, [4 x i64] } %t58, ptr %l6
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/lower:lowering", ptr %t59, i32 0, i32 2
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t63 = load i32, ptr %l2, !tbaa !23
  %t64 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t68 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t62, i32 %t63, i64 %t64)
  store i32 %t68, ptr %l35
  br label %bb6
bb6:
  %t69 = load i32, ptr %l35, !tbaa !23
  store i32 %t69, ptr %l7, !tbaa !23
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load i32, ptr %l7, !tbaa !23
  %t72 = load { i64, [1 x i64] }, ptr %l5
  %t73 = load { i64, [4 x i64] }, ptr %l6
  %t74 = load i32, ptr %l7, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t75
  %t76 = getelementptr { i64, [15 x i64] }, ptr %t75, i32 0, i32 0
  store i64 7, ptr %t76
  %t78 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } undef, { i64, [1 x i64] } %t72, 0
  %t80 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t78, { i64, [4 x i64] } %t73, 1
  %t82 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t80, i32 %t74, 2
  %t83 = getelementptr { i64, [15 x i64] }, ptr %t75, i32 0, i32 1
  store { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t82, ptr %t83
  %t84 = load { i64, [15 x i64] }, ptr %t75
  %t85 = load %"compiler/source:Span", ptr %l3
  %t90 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t70, i32 %t71, { i64, [15 x i64] } %t84, %"compiler/source:Span" %t85)
  store { i64, [4 x i64] } %t90, ptr %l43
  br label %bb7
bb7:
  %t91 = load { i64, [4 x i64] }, ptr %l43
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load %"compiler/source:Span", ptr %l3
  store { i64, [21 x i64] } zeroinitializer, ptr %t95
  %t96 = getelementptr { i64, [21 x i64] }, ptr %t95, i32 0, i32 0
  store i64 12, ptr %t96
  %t98 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t93, 0
  %t100 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t98, { i64, [4 x i64] } %t91, 1
  %t101 = getelementptr { i64, [21 x i64] }, ptr %t95, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t100, ptr %t101
  %t102 = load { i64, [21 x i64] }, ptr %t95
  %t104 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t102, ptr %t104
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t92, ptr %t104)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eescapedHome(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l5 = alloca i64
  %l6 = alloca { i64, [2 x i64] }
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca i1
  %l27 = alloca %"compiler/typed:Local"
  %l34 = alloca %"compiler/mir:Local"
  %l41 = alloca %"compiler/mir:Local"
  %l52 = alloca { i64, [2 x i64] }
  %l54 = alloca { i64, ptr }
  %l61 = alloca i1
  %l63 = alloca i32
  %l68 = alloca %"compiler/typed:Local"
  %l75 = alloca { i64, [1 x i64] }
  %rv = alloca { i64, [1 x i64] }
  %t12 = alloca { i64, [1 x i64] }, align 8
  %t54 = alloca { i64, [1 x i64] }, align 8
  %t92 = alloca { i64, [1 x i64] }, align 8
  %t120 = alloca { i64, [2 x i64] }, align 8
  %t154 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  %t10 = xor i1 %t9, true
  br i1 %t10, label %bb3, label %bb4
bb3:
  store { i64, [1 x i64] } zeroinitializer, ptr %t12
  %t13 = getelementptr { i64, [1 x i64] }, ptr %t12, i32 0, i32 0
  store i64 3, ptr %t13
  %t14 = load { i64, [1 x i64] }, ptr %t12
  store { i64, [1 x i64] } %t14, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t18, i32 0, i32 0
  %t20 = load %"compiler/source:Span", ptr %t19
  store %"compiler/source:Span" %t20, ptr %l2
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [4 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t24, i32 0, i32 1
  %t26 = load i32, ptr %t25
  store i32 %t26, ptr %l3, !tbaa !23
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr { i64, [4 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t30, i32 0, i32 2
  %t32 = load i32, ptr %t31
  %t36 = sext i32 %t32 to i64
  store i64 %t36, ptr %l5, !tbaa !24
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/lower:lowering", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/typed:Body", ptr %t41, i32 0, i32 7
  %t44 = load i64, ptr %l5, !tbaa !24
  %t47 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t43, i64 %t44)
  store %"compiler/typed:Local" %t47, ptr %l27
  br label %bb6
bb6:
  %t48 = getelementptr %"compiler/typed:Local", ptr %l27, i32 0, i32 4
  %t49 = load i32, ptr %t48, !range !{i32 0, i32 7}
  %t51 = trunc i64 6 to i32
  %t52 = icmp eq i32 %t49, %t51
  br i1 %t52, label %bb7, label %bb8
bb7:
  store { i64, [1 x i64] } zeroinitializer, ptr %t54
  %t55 = getelementptr { i64, [1 x i64] }, ptr %t54, i32 0, i32 0
  store i64 3, ptr %t55
  %t56 = load { i64, [1 x i64] }, ptr %t54
  store { i64, [1 x i64] } %t56, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/lower:lowering", ptr %t58, i32 0, i32 3
  %t61 = getelementptr %"compiler/mir:Fn", ptr %t60, i32 0, i32 7
  %t62 = load i64, ptr %l5, !tbaa !24
  %t65 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t61, i64 %t62)
  store %"compiler/mir:Local" %t65, ptr %l34
  br label %bb10
bb10:
  %t66 = getelementptr %"compiler/mir:Local", ptr %l34, i32 0, i32 4
  %t67 = load { i64, [1 x i64] }, ptr %t66
  %t69 = extractvalue { i64, [1 x i64] } %t67, 0
  %t70 = icmp eq i64 %t69, 3
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb11, label %bb12
bb11:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/lower:lowering", ptr %t74, i32 0, i32 3
  %t77 = getelementptr %"compiler/mir:Fn", ptr %t76, i32 0, i32 7
  %t78 = load i64, ptr %l5, !tbaa !24
  %t81 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t77, i64 %t78)
  store %"compiler/mir:Local" %t81, ptr %l41
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t82 = getelementptr %"compiler/mir:Local", ptr %l41, i32 0, i32 4
  %t83 = load { i64, [1 x i64] }, ptr %t82
  store { i64, [1 x i64] } %t83, ptr %rv
  br label %ret
bb14:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/lower:lowering", ptr %t85, i32 0, i32 24
  %t88 = load i1, ptr %t87, !tbaa !21
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb15, label %bb16
bb15:
  store { i64, [1 x i64] } zeroinitializer, ptr %t92
  %t93 = getelementptr { i64, [1 x i64] }, ptr %t92, i32 0, i32 0
  store i64 3, ptr %t93
  %t94 = load { i64, [1 x i64] }, ptr %t92
  store { i64, [1 x i64] } %t94, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t96 = load i64, ptr %l5, !tbaa !24
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/lower:lowering", ptr %t97, i32 0, i32 30
  %t100 = getelementptr %"compiler/typed:Plan", ptr %t99, i32 0, i32 1
  %t101 = load { i64, ptr }, ptr %t100, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t101, 0
  %t106 = icmp slt i64 %t96, %t103
  br i1 %t106, label %bb18, label %bb19
bb18:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/lower:lowering", ptr %t108, i32 0, i32 30
  %t111 = getelementptr %"compiler/typed:Plan", ptr %t110, i32 0, i32 1
  %t112 = load { i64, ptr }, ptr %t111, !tbaa !27
  store { i64, ptr } %t112, ptr %l54, !tbaa !27
  %t113 = load i64, ptr %l5, !tbaa !24
  %t115 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr { i64, [2 x i64] }, ptr %t116, i64 %t113
  %t118 = load { i64, [2 x i64] }, ptr %t117
  store { i64, [2 x i64] } %t118, ptr %l52
  br label %bb20
bb19:
  store { i64, [2 x i64] } zeroinitializer, ptr %t120
  %t121 = getelementptr { i64, [2 x i64] }, ptr %t120, i32 0, i32 0
  store i64 0, ptr %t121
  %t122 = load { i64, [2 x i64] }, ptr %t120
  store { i64, [2 x i64] } %t122, ptr %l52
  br label %bb20
bb20:
  %t124 = load { i64, [2 x i64] }, ptr %l52
  store { i64, [2 x i64] } %t124, ptr %l6
  %t125 = load { i64, [2 x i64] }, ptr %l6
  %t127 = extractvalue { i64, [2 x i64] } %t125, 0
  %t128 = icmp eq i64 %t127, 1
  %t130 = xor i1 %t128, true
  br i1 %t130, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l61, !tbaa !21
  br label %bb24
bb22:
  %t132 = getelementptr { i64, [2 x i64] }, ptr %l6, i32 0, i32 1
  %t133 = getelementptr { i32 }, ptr %t132, i32 0, i32 0
  %t134 = load i32, ptr %t133
  store i32 %t134, ptr %l63, !tbaa !23
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/lower:lowering", ptr %t137, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !29
  %t142 = getelementptr %"compiler/typed:Body", ptr %t140, i32 0, i32 7
  %t143 = load i64, ptr %l5, !tbaa !24
  %t146 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t142, i64 %t143)
  store %"compiler/typed:Local" %t146, ptr %l68
  br label %bb23
bb23:
  %t147 = getelementptr %"compiler/typed:Local", ptr %l68, i32 0, i32 3
  %t148 = load i32, ptr %t147, !tbaa !23
  %t149 = load i32, ptr %l63, !tbaa !23
  %t151 = icmp eq i32 %t149, %t148
  store i1 %t151, ptr %l61, !tbaa !21
  br label %bb24
bb24:
  %t153 = load i1, ptr %l61, !tbaa !21
  br i1 %t153, label %bb25, label %bb26
bb25:
  store { i64, [1 x i64] } zeroinitializer, ptr %t154
  %t155 = getelementptr { i64, [1 x i64] }, ptr %t154, i32 0, i32 0
  store i64 3, ptr %t155
  %t156 = load { i64, [1 x i64] }, ptr %t154
  store { i64, [1 x i64] } %t156, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t158 = getelementptr { i64, [2 x i64] }, ptr %l6, i32 0, i32 1
  %t159 = getelementptr { i32 }, ptr %t158, i32 0, i32 0
  %t160 = load i32, ptr %t159
  store i32 %t160, ptr %l8, !tbaa !23
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t163 = load { i64, [2 x i64] }, ptr %l6
  %t166 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2escopeRef(ptr %v0, ptr %t162, { i64, [2 x i64] } %t163)
  store { i64, [1 x i64] } %t166, ptr %l75
  br label %bb28
bb28:
  %t167 = load { i64, [1 x i64] }, ptr %l75
  store { i64, [1 x i64] } %t167, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eexitLevel(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/lower:level"
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l14 = alloca %"compiler/lower:level"
  %l22 = alloca %"compiler/source:Span"
  %l28 = alloca %"compiler/typed:BlockInfo"
  %l39 = alloca %"compiler/mir:ScopeInfo"
  %l43 = alloca i32
  %l47 = alloca { i64, ptr }
  %l62 = alloca i32
  %l73 = alloca i32
  %l76 = alloca i32
  %l94 = alloca ptr
  %l95 = alloca i64
  %l96 = alloca i32
  %l98 = alloca %"compiler/mir:Lvalue"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %t100 = alloca { i64, [8 x i64] }, align 8
  %t143 = alloca { i64, [8 x i64] }, align 8
  %t173 = alloca { i64, [8 x i64] }, align 8
  %t202 = alloca { i64, [21 x i64] }, align 8
  %t221 = alloca { i64, [4 x i64] }, align 8
  %t253 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 10
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 12
  %t9 = load i64, ptr %l1, !tbaa !24
  %t12 = call %"compiler/lower:level" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eAt_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t8, i64 %t9)
  store %"compiler/lower:level" %t12, ptr %l14
  br label %bb4
bb4:
  %t13 = load %"compiler/lower:level", ptr %l14
  store %"compiler/lower:level" %t13, ptr %l2
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2erunDefers(ptr %v0, ptr %t14, i64 %t15, i32 0)
  br label %bb5
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/lower:lowering", ptr %t19, i32 0, i32 10
  %t22 = load i1, ptr %t21, !tbaa !21
  br i1 %t22, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  br label %bb8
bb8:
  %t24 = getelementptr %"compiler/lower:level", ptr %l2, i32 0, i32 1
  %t25 = load i32, ptr %t24, !tbaa !23
  %t27 = icmp sge i32 %t25, 0
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/lower:lowering", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/typed:Body", ptr %t32, i32 0, i32 8
  %t35 = getelementptr %"compiler/lower:level", ptr %l2, i32 0, i32 1
  %t36 = load i32, ptr %t35, !tbaa !23
  %t38 = sext i32 %t36 to i64
  %t41 = call %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %v0, ptr %t34, i64 %t38)
  store %"compiler/typed:BlockInfo" %t41, ptr %l28
  br label %bb11
bb10:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/lower:lowering", ptr %t42, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = getelementptr %"compiler/typed:Body", ptr %t45, i32 0, i32 4
  %t48 = load %"compiler/source:Span", ptr %t47
  store %"compiler/source:Span" %t48, ptr %l22
  br label %bb12
bb11:
  %t50 = getelementptr %"compiler/typed:BlockInfo", ptr %l28, i32 0, i32 2
  %t51 = load %"compiler/source:Span", ptr %t50
  store %"compiler/source:Span" %t51, ptr %l22
  br label %bb12
bb12:
  %t53 = load %"compiler/source:Span", ptr %l22
  store %"compiler/source:Span" %t53, ptr %l3
  %t54 = getelementptr %"compiler/lower:level", ptr %l2, i32 0, i32 2
  %t55 = load i32, ptr %t54, !range !{i32 0, i32 7}
  %t57 = trunc i64 3 to i32
  %t58 = icmp eq i32 %t55, %t57
  br i1 %t58, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/lower:lowering", ptr %t60, i32 0, i32 3
  %t63 = getelementptr %"compiler/mir:Fn", ptr %t62, i32 0, i32 8
  %t64 = getelementptr %"compiler/lower:level", ptr %l2, i32 0, i32 0
  %t65 = load i32, ptr %t64, !tbaa !23
  %t67 = sext i32 %t65 to i64
  %t70 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t63, i64 %t67)
  store %"compiler/mir:ScopeInfo" %t70, ptr %l39
  br label %bb15
bb14:
  br label %bb40
bb15:
  %t71 = getelementptr %"compiler/mir:ScopeInfo", ptr %l39, i32 0, i32 4
  %t72 = load i32, ptr %t71, !tbaa !23
  store i32 %t72, ptr %l4, !tbaa !23
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/lower:lowering", ptr %t74, i32 0, i32 3
  %t78 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t76)
  store i32 %t78, ptr %l43
  br label %bb16
bb16:
  %t79 = load i32, ptr %l43, !tbaa !23
  store i32 %t79, ptr %l5, !tbaa !23
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/lower:lowering", ptr %t80, i32 0, i32 2
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t84 = load i32, ptr %l4, !tbaa !23
  %t87 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s3, ptr %t83, i32 %t84)
  store { i64, ptr } %t87, ptr %l47
  br label %bb17
bb17:
  %t88 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t88, 0
  %t91 = icmp eq i64 %t89, 0
  br i1 %t91, label %bb18, label %bb19
bb18:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load %"compiler/source:Span", ptr %l3
  %t95 = getelementptr %"compiler/lower:level", ptr %l2, i32 0, i32 0
  %t96 = load i32, ptr %t95, !tbaa !23
  %t97 = load i32, ptr %l5, !tbaa !23
  %t98 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t99 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t100
  %t101 = getelementptr { i64, [8 x i64] }, ptr %t100, i32 0, i32 0
  store i64 8, ptr %t101
  %t103 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } undef, %"compiler/source:Span" %t94, 0
  %t105 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } %t103, i32 %t96, 1
  %t107 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } %t105, i32 %t97, 2
  %t109 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } %t107, i32 %t98, 3
  %t111 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } %t109, i32 %t99, 4
  %t112 = getelementptr { i64, [8 x i64] }, ptr %t100, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, i32 } %t111, ptr %t112
  %t113 = load { i64, [8 x i64] }, ptr %t100
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t93, { i64, [8 x i64] } %t113)
  br label %bb20
bb19:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/lower:lowering", ptr %t116, i32 0, i32 23
  %t119 = load i1, ptr %t118, !tbaa !21
  br i1 %t119, label %bb21, label %bb22
bb20:
  br label %bb34
bb21:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t123 = load %"compiler/source:Span", ptr %l3
  %t127 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t121, i32 %t122, %"compiler/source:Span" %t123)
  store i32 %t127, ptr %l62
  br label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s7
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t130 = load %"compiler/source:Span", ptr %l3
  %t134 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t128, i32 %t129, %"compiler/source:Span" %t130)
  store i32 %t134, ptr %l73
  br label %bb25
bb23:
  %t135 = load i32, ptr %l62, !tbaa !23
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load %"compiler/source:Span", ptr %l3
  %t138 = getelementptr %"compiler/lower:level", ptr %l2, i32 0, i32 0
  %t139 = load i32, ptr %t138, !tbaa !23
  %t140 = load i32, ptr %l5, !tbaa !23
  %t142 = load i32, ptr %l5, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t143
  %t144 = getelementptr { i64, [8 x i64] }, ptr %t143, i32 0, i32 0
  store i64 8, ptr %t144
  %t146 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } undef, %"compiler/source:Span" %t137, 0
  %t148 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } %t146, i32 %t139, 1
  %t150 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } %t148, i32 %t140, 2
  %t152 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } %t150, i32 %t135, 3
  %t154 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } %t152, i32 %t142, 4
  %t155 = getelementptr { i64, [8 x i64] }, ptr %t143, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, i32 } %t154, ptr %t155
  %t156 = load { i64, [8 x i64] }, ptr %t143
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t136, { i64, [8 x i64] } %t156)
  br label %bb24
bb24:
  br label %bb33
bb25:
  %t159 = load i32, ptr %l73, !tbaa !23
  store i32 %t159, ptr %l7, !tbaa !23
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/lower:lowering", ptr %t160, i32 0, i32 3
  %t164 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t162)
  store i32 %t164, ptr %l76
  br label %bb26
bb26:
  %t165 = load i32, ptr %l76, !tbaa !23
  store i32 %t165, ptr %l8, !tbaa !23
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load %"compiler/source:Span", ptr %l3
  %t168 = getelementptr %"compiler/lower:level", ptr %l2, i32 0, i32 0
  %t169 = load i32, ptr %t168, !tbaa !23
  %t170 = load i32, ptr %l5, !tbaa !23
  %t171 = load i32, ptr %l7, !tbaa !23
  %t172 = load i32, ptr %l8, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t173
  %t174 = getelementptr { i64, [8 x i64] }, ptr %t173, i32 0, i32 0
  store i64 8, ptr %t174
  %t176 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } undef, %"compiler/source:Span" %t167, 0
  %t178 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } %t176, i32 %t169, 1
  %t180 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } %t178, i32 %t170, 2
  %t182 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } %t180, i32 %t171, 3
  %t184 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } %t182, i32 %t172, 4
  %t185 = getelementptr { i64, [8 x i64] }, ptr %t173, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, i32 } %t184, ptr %t185
  %t186 = load { i64, [8 x i64] }, ptr %t173
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t166, { i64, [8 x i64] } %t186)
  br label %bb27
bb27:
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load i32, ptr %l8, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t189, i32 %t190)
  br label %bb28
bb28:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2erunDefers(ptr %v0, ptr %t193, i64 %t194, i32 1)
  br label %bb29
bb29:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t199 = load %"compiler/source:Span", ptr %l3
  %t200 = getelementptr %"compiler/lower:level", ptr %l2, i32 0, i32 0
  %t201 = load i32, ptr %t200, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t202
  %t203 = getelementptr { i64, [21 x i64] }, ptr %t202, i32 0, i32 0
  store i64 4, ptr %t203
  %t205 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t199, 0
  %t207 = insertvalue { %"compiler/source:Span", i32 } %t205, i32 %t201, 1
  %t208 = getelementptr { i64, [21 x i64] }, ptr %t202, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t207, ptr %t208
  %t209 = load { i64, [21 x i64] }, ptr %t202
  %t211 = call ptr @__olang_scope_alloc_a(ptr %s7, i64 176, i64 8)
  store { i64, [21 x i64] } %t209, ptr %t211
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s7, ptr %t198, ptr %t211)
  br label %bb30
bb30:
  %t214 = load ptr, ptr %l0, !tbaa !29
  store ptr %t214, ptr %l94, !tbaa !29
  %t215 = load i64, ptr %l1, !tbaa !24
  store i64 %t215, ptr %l95, !tbaa !24
  %t216 = getelementptr %"compiler/lower:level", ptr %l2, i32 0, i32 0
  %t217 = load i32, ptr %t216, !tbaa !23
  store i32 %t217, ptr %l96, !tbaa !23
  %t218 = load i32, ptr %l7, !tbaa !23
  %t220 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t218)
  store %"compiler/mir:Lvalue" %t220, ptr %l98
  br label %bb31
bb31:
  store { i64, [4 x i64] } zeroinitializer, ptr %t221
  %t222 = getelementptr { i64, [4 x i64] }, ptr %t221, i32 0, i32 0
  store i64 1, ptr %t222
  %t223 = load %"compiler/mir:Lvalue", ptr %l98
  %t224 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t223, 0
  %t225 = getelementptr { i64, [4 x i64] }, ptr %t221, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t224, ptr %t225
  %t226 = load { i64, [4 x i64] }, ptr %t221
  %t227 = load i32, ptr %l4, !tbaa !23
  %t228 = load %"compiler/source:Span", ptr %l3
  %t229 = load ptr, ptr %l94, !tbaa !29
  %t230 = load i64, ptr %l95, !tbaa !24
  %t231 = load i32, ptr %l96, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ejoinFailed(ptr %v0, ptr %t229, i64 %t230, i32 %t231, { i64, [4 x i64] } %t226, i32 %t227, %"compiler/source:Span" %t228)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s7)
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t236 = load i32, ptr %l5, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t235, i32 %t236)
  br label %bb35
bb35:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t240 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2erunDefers(ptr %v0, ptr %t239, i64 %t240, i32 2)
  br label %bb36
bb36:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = getelementptr %"compiler/lower:lowering", ptr %t244, i32 0, i32 10
  %t247 = load i1, ptr %t246, !tbaa !21
  br i1 %t247, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb38:
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s3)
  br label %bb40
bb40:
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t250 = load %"compiler/source:Span", ptr %l3
  %t251 = getelementptr %"compiler/lower:level", ptr %l2, i32 0, i32 0
  %t252 = load i32, ptr %t251, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t253
  %t254 = getelementptr { i64, [21 x i64] }, ptr %t253, i32 0, i32 0
  store i64 4, ptr %t254
  %t256 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t250, 0
  %t258 = insertvalue { %"compiler/source:Span", i32 } %t256, i32 %t252, 1
  %t259 = getelementptr { i64, [21 x i64] }, ptr %t253, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t258, ptr %t259
  %t260 = load { i64, [21 x i64] }, ptr %t253
  %t262 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t260, ptr %t262
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t249, ptr %t262)
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2efitAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3, { i64, [1 x i64] } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, [1 x i64] }
  %l5 = alloca ptr
  %l6 = alloca { i64, [4 x i64] }
  %l7 = alloca { i64, [4 x i64] }
  %l11 = alloca i1
  %l13 = alloca ptr
  %l17 = alloca { i64, [4 x i64] }
  %l21 = alloca ptr
  %l22 = alloca { i64, [4 x i64] }
  %l24 = alloca i32
  %l28 = alloca { i64, [4 x i64] }
  %l32 = alloca { i64, [4 x i64] }
  %l35 = alloca i1
  %l40 = alloca i1
  %l43 = alloca ptr
  %l44 = alloca { i64, [4 x i64] }
  %l46 = alloca i32
  %l50 = alloca { i64, [4 x i64] }
  %rv = alloca { i64, [4 x i64] }
  %t25 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  store { i64, [1 x i64] } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = load i32, ptr %l2, !tbaa !23
  %t7 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ewidens(ptr %v0, ptr %v1, ptr %t1, ptr %t2, i32 %t3)
  store i1 %t7, ptr %l11
  br label %bb1
bb1:
  %t8 = load i1, ptr %l11, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = call ptr @compiler_2flower_2econvertArg(ptr %v1, ptr %v1, ptr %t9)
  store ptr %t11, ptr %l13
  br label %bb4
bb3:
  br label %bb11
bb4:
  %t12 = load ptr, ptr %l13, !tbaa !29
  store ptr %t12, ptr %l5, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load ptr, ptr %l5, !tbaa !29
  %t18 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t13, ptr %t14)
  store { i64, [4 x i64] } %t18, ptr %l17
  br label %bb5
bb5:
  %t19 = load { i64, [4 x i64] }, ptr %l17
  store { i64, [4 x i64] } %t19, ptr %l6
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/lower:lowering", ptr %t20, i32 0, i32 10
  %t23 = load i1, ptr %t22, !tbaa !21
  br i1 %t23, label %bb6, label %bb7
bb6:
  store { i64, [4 x i64] } zeroinitializer, ptr %t25
  %t26 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 0
  store i64 0, ptr %t26
  %t27 = load { i64, [4 x i64] }, ptr %t25
  store { i64, [4 x i64] } %t27, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l21, !tbaa !29
  %t30 = load { i64, [4 x i64] }, ptr %l6
  store { i64, [4 x i64] } %t30, ptr %l22
  %t31 = load ptr, ptr %l5, !tbaa !29
  %t33 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t31)
  store i32 %t33, ptr %l24
  br label %bb9
bb9:
  %t34 = load i32, ptr %l2, !tbaa !23
  %t35 = load %"compiler/source:Span", ptr %l3
  %t36 = load { i64, [1 x i64] }, ptr %l4
  %t37 = load ptr, ptr %l21, !tbaa !29
  %t38 = load { i64, [4 x i64] }, ptr %l22
  %t39 = load i32, ptr %l24, !tbaa !23
  %t43 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ewiden(ptr %v0, ptr %t37, { i64, [4 x i64] } %t38, i32 %t39, i32 %t34, %"compiler/source:Span" %t35, { i64, [1 x i64] } %t36)
  store { i64, [4 x i64] } %t43, ptr %l28
  br label %bb10
bb10:
  %t44 = load { i64, [4 x i64] }, ptr %l28
  store { i64, [4 x i64] } %t44, ptr %rv
  br label %ret
bb11:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t50 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t45, ptr %t46)
  store { i64, [4 x i64] } %t50, ptr %l32
  br label %bb12
bb12:
  %t51 = load { i64, [4 x i64] }, ptr %l32
  store { i64, [4 x i64] } %t51, ptr %l7
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/lower:lowering", ptr %t52, i32 0, i32 10
  %t55 = load i1, ptr %t54, !tbaa !21
  br i1 %t55, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb16
bb14:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = load i32, ptr %l2, !tbaa !23
  %t64 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2efits(ptr %v0, ptr %v1, ptr %t57, ptr %t58, i32 %t60)
  store i1 %t64, ptr %l40
  br label %bb15
bb15:
  %t65 = load i1, ptr %l40, !tbaa !21
  %t66 = xor i1 %t65, true
  store i1 %t66, ptr %l35, !tbaa !21
  br label %bb16
bb16:
  %t68 = load i1, ptr %l35, !tbaa !21
  br i1 %t68, label %bb17, label %bb18
bb17:
  %t69 = load { i64, [4 x i64] }, ptr %l7
  store { i64, [4 x i64] } %t69, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l43, !tbaa !29
  %t72 = load { i64, [4 x i64] }, ptr %l7
  store { i64, [4 x i64] } %t72, ptr %l44
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t73)
  store i32 %t75, ptr %l46
  br label %bb20
bb20:
  %t76 = load i32, ptr %l2, !tbaa !23
  %t77 = load %"compiler/source:Span", ptr %l3
  %t78 = load { i64, [1 x i64] }, ptr %l4
  %t79 = load ptr, ptr %l43, !tbaa !29
  %t80 = load { i64, [4 x i64] }, ptr %l44
  %t81 = load i32, ptr %l46, !tbaa !23
  %t85 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ewiden(ptr %v0, ptr %t79, { i64, [4 x i64] } %t80, i32 %t81, i32 %t76, %"compiler/source:Span" %t77, { i64, [1 x i64] } %t78)
  store { i64, [4 x i64] } %t85, ptr %l50
  br label %bb21
bb21:
  %t86 = load { i64, [4 x i64] }, ptr %l50
  store { i64, [4 x i64] } %t86, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2efoundOf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i64
  %l10 = alloca i64
  %l19 = alloca ptr
  %l23 = alloca i64
  %l27 = alloca i1
  %l34 = alloca ptr
  %l40 = alloca { i64, [4 x i64] }
  %l45 = alloca i1
  %l47 = alloca i1
  %l55 = alloca { i64, [4 x i64] }
  %l59 = alloca i32
  %l60 = alloca ptr
  %l61 = alloca %"compiler/source:Span"
  %l63 = alloca %"compiler/mir:Lvalue"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, [1 x i64] }
  %t12 = alloca { i64, [1 x i64] }, align 8
  %t33 = alloca { i64, [4 x i64] }, align 8
  %t93 = alloca { i64, [1 x i64] }, align 8
  %t123 = alloca { i64, [15 x i64] }, align 8
  %t129 = alloca { i64, [21 x i64] }, align 8
  %t144 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l7, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/lower:lowering", ptr %t2, i32 0, i32 30
  %t5 = getelementptr %"compiler/typed:Plan", ptr %t4, i32 0, i32 10
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t5)
  store i64 %t7, ptr %l10
  br label %bb1
bb1:
  %t8 = load i64, ptr %l7, !tbaa !24
  %t9 = load i64, ptr %l10, !tbaa !24
  %t10 = icmp sge i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  store { i64, [1 x i64] } zeroinitializer, ptr %t12
  %t13 = getelementptr { i64, [1 x i64] }, ptr %t12, i32 0, i32 0
  store i64 2, ptr %t13
  %t14 = load { i64, [1 x i64] }, ptr %t12
  call void @__olang_scope_close(ptr %s0)
  store { i64, [1 x i64] } %t14, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/lower:lowering", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/typed:Body", ptr %t19, i32 0, i32 4
  %t22 = load %"compiler/source:Span", ptr %t21
  store %"compiler/source:Span" %t22, ptr %l2
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/lower:lowering", ptr %t24, i32 0, i32 30
  %t27 = getelementptr %"compiler/typed:Plan", ptr %t26, i32 0, i32 10
  %t28 = load i64, ptr %l1, !tbaa !24
  %t31 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t27, i64 %t28)
  store ptr %t31, ptr %l19
  br label %bb5
bb5:
  %t32 = load ptr, ptr %l19, !tbaa !29
  store ptr %t32, ptr %l3, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t33
  %t34 = getelementptr { i64, [4 x i64] }, ptr %t33, i32 0, i32 0
  store i64 0, ptr %t34
  %t35 = load { i64, [4 x i64] }, ptr %t33
  store { i64, [4 x i64] } %t35, ptr %l4
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/lower:lowering", ptr %t37, i32 0, i32 35
  %t41 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t39)
  store i64 %t41, ptr %l23
  br label %bb6
bb6:
  %t42 = load i64, ptr %l23, !tbaa !24
  %t43 = sub i64 %t42, 1
  store i64 %t43, ptr %l5, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t45 = load i64, ptr %l5, !tbaa !24
  %t47 = icmp sge i64 %t45, 0
  br i1 %t47, label %bb8, label %bb9
bb8:
  %t49 = load { i64, [4 x i64] }, ptr %l4
  %t51 = extractvalue { i64, [4 x i64] } %t49, 0
  %t52 = icmp eq i64 %t51, 0
  store i1 %t52, ptr %l27, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb10
bb10:
  %t54 = load i1, ptr %l27, !tbaa !21
  %t55 = xor i1 %t54, true
  br i1 %t55, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb12:
  br label %bb13
bb13:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/lower:lowering", ptr %t57, i32 0, i32 35
  %t60 = load i64, ptr %l5, !tbaa !24
  %t63 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %s3, ptr %t59, i64 %t60)
  store ptr %t63, ptr %l34
  br label %bb14
bb14:
  %t64 = load ptr, ptr %l3, !tbaa !29
  %t65 = load ptr, ptr %l34, !tbaa !29
  %t67 = icmp eq ptr %t65, %t64
  br i1 %t67, label %bb15, label %bb16
bb15:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/lower:lowering", ptr %t69, i32 0, i32 36
  %t72 = load i64, ptr %l5, !tbaa !24
  %t75 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t71, i64 %t72)
  store { i64, [4 x i64] } %t75, ptr %l40
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t76 = load { i64, [4 x i64] }, ptr %l40
  store { i64, [4 x i64] } %t76, ptr %l4
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb19:
  %t77 = load i64, ptr %l5, !tbaa !24
  %t79 = sub i64 %t77, 1
  store i64 %t79, ptr %l5, !tbaa !24
  br label %bb7
bb20:
  %t81 = load { i64, [4 x i64] }, ptr %l4
  %t83 = extractvalue { i64, [4 x i64] } %t81, 0
  %t84 = icmp eq i64 %t83, 0
  br i1 %t84, label %bb21, label %bb22
bb21:
  %t86 = load ptr, ptr %l3, !tbaa !29
  %t88 = call i1 @compiler_2ftyped_2ePure(ptr %v0, ptr %t86)
  store i1 %t88, ptr %l47
  br label %bb23
bb22:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb24
bb23:
  %t89 = load i1, ptr %l47, !tbaa !21
  %t90 = xor i1 %t89, true
  store i1 %t90, ptr %l45, !tbaa !21
  br label %bb24
bb24:
  %t92 = load i1, ptr %l45, !tbaa !21
  br i1 %t92, label %bb25, label %bb26
bb25:
  store { i64, [1 x i64] } zeroinitializer, ptr %t93
  %t94 = getelementptr { i64, [1 x i64] }, ptr %t93, i32 0, i32 0
  store i64 2, ptr %t94
  %t95 = load { i64, [1 x i64] }, ptr %t93
  call void @__olang_scope_close(ptr %s0)
  store { i64, [1 x i64] } %t95, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t97 = load { i64, [4 x i64] }, ptr %l4
  %t99 = extractvalue { i64, [4 x i64] } %t97, 0
  %t100 = icmp eq i64 %t99, 0
  br i1 %t100, label %bb28, label %bb29
bb28:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load ptr, ptr %l3, !tbaa !29
  %t107 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v0, ptr %t102, ptr %t103)
  store { i64, [4 x i64] } %t107, ptr %l55
  br label %bb30
bb29:
  br label %bb31
bb30:
  %t108 = load { i64, [4 x i64] }, ptr %l55
  store { i64, [4 x i64] } %t108, ptr %l4
  br label %bb31
bb31:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t111 = load %"compiler/source:Span", ptr %l2
  %t115 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t109, i32 %t110, %"compiler/source:Span" %t111)
  store i32 %t115, ptr %l59
  br label %bb32
bb32:
  %t116 = load i32, ptr %l59, !tbaa !23
  store i32 %t116, ptr %l6, !tbaa !23
  %t117 = load ptr, ptr %l0, !tbaa !29
  store ptr %t117, ptr %l60, !tbaa !29
  %t118 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t118, ptr %l61
  %t119 = load i32, ptr %l6, !tbaa !23
  %t121 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t119)
  store %"compiler/mir:Lvalue" %t121, ptr %l63
  br label %bb33
bb33:
  %t122 = load { i64, [4 x i64] }, ptr %l4
  store { i64, [15 x i64] } zeroinitializer, ptr %t123
  %t124 = getelementptr { i64, [15 x i64] }, ptr %t123, i32 0, i32 0
  store i64 15, ptr %t124
  %t126 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t122, 0
  %t127 = getelementptr { i64, [15 x i64] }, ptr %t123, i32 0, i32 1
  store { { i64, [4 x i64] } } %t126, ptr %t127
  %t128 = load { i64, [15 x i64] }, ptr %t123
  store { i64, [21 x i64] } zeroinitializer, ptr %t129
  %t130 = getelementptr { i64, [21 x i64] }, ptr %t129, i32 0, i32 0
  store i64 0, ptr %t130
  %t131 = load %"compiler/source:Span", ptr %l61
  %t132 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t131, 0
  %t133 = load %"compiler/mir:Lvalue", ptr %l63
  %t134 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t132, %"compiler/mir:Lvalue" %t133, 1
  %t136 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t134, { i64, [15 x i64] } %t128, 2
  %t137 = getelementptr { i64, [21 x i64] }, ptr %t129, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t136, ptr %t137
  %t138 = load { i64, [21 x i64] }, ptr %t129
  %t140 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t138, ptr %t140
  %t141 = load ptr, ptr %l60, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t141, ptr %t140)
  br label %bb34
bb34:
  %t143 = load i32, ptr %l6, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t144
  %t145 = getelementptr { i64, [1 x i64] }, ptr %t144, i32 0, i32 0
  store i64 4, ptr %t145
  %t147 = insertvalue { i32 } undef, i32 %t143, 0
  %t148 = getelementptr { i64, [1 x i64] }, ptr %t144, i32 0, i32 1
  store { i32 } %t147, ptr %t148
  %t149 = load { i64, [1 x i64] }, ptr %t144
  call void @__olang_scope_close(ptr %s0)
  store { i64, [1 x i64] } %t149, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %t3 = alloca { i64, [8 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store { i64, [8 x i64] } zeroinitializer, ptr %t3
  %t4 = getelementptr { i64, [8 x i64] }, ptr %t3, i32 0, i32 0
  store i64 1, ptr %t4
  %t6 = insertvalue { i32 } undef, i32 %a1, 0
  %t7 = getelementptr { i64, [8 x i64] }, ptr %t3, i32 0, i32 1
  store { i32 } %t6, ptr %t7
  %t8 = load { i64, [8 x i64] }, ptr %t3
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %a0, { i64, [8 x i64] } %t8)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2flower_2ecompiler_2flower_3alowering_2ehandedOver(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i1
  %l17 = alloca i1
  %l30 = alloca { i64, ptr }
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 12
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb22
bb5:
  %t16 = load ptr, ptr %l3, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Seq", ptr %t16, i32 0, i32 2
  %t19 = load i1, ptr %t18, !tbaa !21
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb8
bb7:
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t25 = getelementptr %"compiler/typed:Seq", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = icmp eq ptr %t26, null
  store i1 %t28, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t30 = load i1, ptr %l17, !tbaa !21
  br i1 %t30, label %bb9, label %bb10
bb9:
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t33 = load ptr, ptr %l3, !tbaa !29
  %t35 = getelementptr %"compiler/typed:Seq", ptr %t33, i32 0, i32 0
  %t36 = load { i64, ptr }, ptr %t35, !tbaa !27
  store { i64, ptr } %t36, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t38, 0
  store i64 %t40, ptr %l6, !tbaa !24
  br label %bb12
bb12:
  %t42 = load i64, ptr %l5, !tbaa !24
  %t43 = load i64, ptr %l6, !tbaa !24
  %t46 = icmp slt i64 %t42, %t43
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb13, label %bb14
bb13:
  br label %bb18
bb14:
  br label %bb15
bb15:
  %t50 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t50, ptr %l30, !tbaa !27
  %t51 = load i64, ptr %l5, !tbaa !24
  %t53 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr ptr, ptr %t54, i64 %t51
  %t56 = load ptr, ptr %t55, !tbaa !39
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v2, ptr %v1, ptr %a2, ptr %t56)
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t62 = load i64, ptr %l5, !tbaa !24
  %t64 = add i64 %t62, 1
  store i64 %t64, ptr %l5, !tbaa !24
  br label %bb12
bb18:
  %t66 = load ptr, ptr %l3, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Seq", ptr %t66, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = icmp eq ptr %t69, null
  br i1 %t71, label %bb19, label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_58c3cf8c6fce78d4_23ae1924195b9e70)
  unreachable
bb20:
  br label %bb21
bb21:
  %t73 = load ptr, ptr %l3, !tbaa !29
  %t75 = getelementptr %"compiler/typed:Seq", ptr %t73, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !29
  store ptr %t76, ptr %rv
  br label %ret
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  %t78 = load ptr, ptr %l1, !tbaa !29
  store ptr %t78, ptr %rv
  br label %ret
bb26:
  call void @__olang_check_failed(ptr @olang_loc_3f94e1722b42397a_72ec18aae06ab796)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eheldLocal(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/typed:Local"
  %l4 = alloca i64
  %l9 = alloca %"compiler/typed:Local"
  %l13 = alloca i1
  %l20 = alloca i1
  %l22 = alloca i1
  %l25 = alloca i1
  %l26 = alloca i1
  %l30 = alloca i1
  %l35 = alloca i1
  %l41 = alloca i64
  %l44 = alloca i1
  %l48 = alloca i1
  %l53 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Body", ptr %t4, i32 0, i32 7
  %t7 = load i64, ptr %l2, !tbaa !24
  %t10 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t6, i64 %t7)
  store %"compiler/typed:Local" %t10, ptr %l9
  br label %bb1
bb1:
  %t11 = load %"compiler/typed:Local", ptr %l9
  store %"compiler/typed:Local" %t11, ptr %l3
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lower:lowering", ptr %t12, i32 0, i32 2
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t16 = getelementptr %"compiler/typed:Local", ptr %l3, i32 0, i32 2
  %t17 = load i32, ptr %t16, !tbaa !23
  %t20 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSharesRefs(ptr %v0, ptr %t15, i32 %t17)
  store i1 %t20, ptr %l13
  br label %bb2
bb2:
  %t21 = load i1, ptr %l13, !tbaa !21
  br i1 %t21, label %bb3, label %bb4
bb3:
  store i1 false, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t23 = getelementptr %"compiler/typed:Local", ptr %l3, i32 0, i32 4
  %t24 = load i32, ptr %t23, !range !{i32 0, i32 7}
  %t26 = trunc i64 0 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb6, label %bb7
bb6:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/lower:lowering", ptr %t29, i32 0, i32 2
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t33 = getelementptr %"compiler/typed:Local", ptr %l3, i32 0, i32 2
  %t34 = load i32, ptr %t33, !tbaa !23
  %t37 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t32, i32 %t34)
  store i1 %t37, ptr %l20
  br label %bb8
bb7:
  br label %bb17
bb8:
  %t38 = load i1, ptr %l20, !tbaa !21
  %t39 = xor i1 %t38, true
  br i1 %t39, label %bb9, label %bb10
bb9:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i64, ptr %l2, !tbaa !24
  %t45 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eparamElig(ptr %v0, ptr %t41, i64 %t42)
  store i1 %t45, ptr %l25
  br label %bb11
bb10:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb12
bb11:
  %t46 = load i1, ptr %l25, !tbaa !21
  store i1 %t46, ptr %l22, !tbaa !21
  br label %bb12
bb12:
  %t47 = load i1, ptr %l22, !tbaa !21
  br i1 %t47, label %bb13, label %bb14
bb13:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/lower:lowering", ptr %t48, i32 0, i32 2
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t52 = getelementptr %"compiler/typed:Local", ptr %l3, i32 0, i32 2
  %t53 = load i32, ptr %t52, !tbaa !23
  %t56 = call i1 @compiler_2flower_2erunArray(ptr %v0, ptr %t51, i32 %t53)
  store i1 %t56, ptr %l30
  br label %bb15
bb14:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb16
bb15:
  %t57 = load i1, ptr %l30, !tbaa !21
  %t58 = xor i1 %t57, true
  store i1 %t58, ptr %l26, !tbaa !21
  br label %bb16
bb16:
  %t60 = load i1, ptr %l26, !tbaa !21
  store i1 %t60, ptr %rv
  br label %ret
bb17:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t63 = load i64, ptr %l2, !tbaa !24
  %t67 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eheldUnchanged(ptr %v0, ptr %v1, ptr %t61, ptr %t62, i64 %t63)
  store i1 %t67, ptr %l35
  br label %bb18
bb18:
  %t68 = load i1, ptr %l35, !tbaa !21
  %t69 = xor i1 %t68, true
  br i1 %t69, label %bb19, label %bb20
bb19:
  store i1 false, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t74 = getelementptr %"compiler/typed:LocalUses", ptr %t72, i32 0, i32 8
  %t75 = load i64, ptr %l2, !tbaa !24
  %t78 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t74, i64 %t75)
  store i64 %t78, ptr %l41
  br label %bb22
bb22:
  %t79 = load i64, ptr %l41, !tbaa !24
  store i64 %t79, ptr %l4, !tbaa !24
  %t80 = load i64, ptr %l4, !tbaa !24
  %t82 = icmp sge i64 %t80, 0
  br i1 %t82, label %bb23, label %bb24
bb23:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/lower:lowering", ptr %t84, i32 0, i32 45
  %t87 = load i64, ptr %l2, !tbaa !24
  %t90 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t86, i64 %t87)
  store i1 %t90, ptr %l48
  br label %bb25
bb24:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb26
bb25:
  %t91 = load i1, ptr %l48, !tbaa !21
  %t92 = xor i1 %t91, true
  store i1 %t92, ptr %l44, !tbaa !21
  br label %bb26
bb26:
  %t94 = load i1, ptr %l44, !tbaa !21
  br i1 %t94, label %bb27, label %bb28
bb27:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t97 = load i64, ptr %l4, !tbaa !24
  %t101 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eheldLocal(ptr %v0, ptr %v1, ptr %t95, ptr %t96, i64 %t97)
  store i1 %t101, ptr %l53
  br label %bb29
bb28:
  br label %bb30
bb29:
  %t102 = load i1, ptr %l53, !tbaa !21
  store i1 %t102, ptr %rv
  br label %ret
bb30:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eheldParts(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l19 = alloca i1
  %l23 = alloca i1
  %l29 = alloca i32
  %l35 = alloca i32
  %l38 = alloca ptr
  %l41 = alloca i32
  %l49 = alloca ptr
  %l52 = alloca i32
  %l53 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %s9 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %l3, !tbaa !24
  %t8 = icmp sgt i64 %t6, 16
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb4
bb2:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t11 = load i32, ptr %l1, !tbaa !23
  %t13 = sext i32 %t11 to i64
  %t16 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v1, ptr %t10, i64 %t13)
  store i1 %t16, ptr %l23
  br label %bb3
bb3:
  %t17 = load i1, ptr %l23, !tbaa !21
  store i1 %t17, ptr %l19, !tbaa !21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l19, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  br label %ret
bb6:
  br label %bb7
bb7:
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t20 = load i32, ptr %l1, !tbaa !23
  %t22 = sext i32 %t20 to i64
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v1, ptr %t19, i64 %t22, i1 true)
  br label %bb8
bb8:
  %t25 = load ptr, ptr %l4, !tbaa !29
  %t26 = load i32, ptr %l1, !tbaa !23
  %t29 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t25, i32 %t26)
  store i32 %t29, ptr %l29
  br label %bb9
bb9:
  %t30 = load i32, ptr %l29, !tbaa !23
  store i32 %t30, ptr %l5, !tbaa !23
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t32 = load i32, ptr %l5, !tbaa !23
  %t34 = sext i32 %t32 to i64
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v1, ptr %t31, i64 %t34, i1 true)
  br label %bb10
bb10:
  %t37 = load ptr, ptr %l4, !tbaa !29
  %t38 = load i32, ptr %l5, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l35
  br label %bb11
bb11:
  %t42 = load i32, ptr %l35, !range !{i32 0, i32 33}
  store i32 %t42, ptr %l6
  %t43 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t45 = trunc i64 19 to i32
  %t46 = icmp eq i32 %t43, %t45
  br i1 %t46, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb17
bb14:
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l38, !tbaa !29
  %t49 = load ptr, ptr %l4, !tbaa !29
  %t50 = load i32, ptr %l5, !tbaa !23
  %t53 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t49, i32 %t50)
  store i32 %t53, ptr %l41
  br label %bb15
bb15:
  %t54 = load ptr, ptr %l2, !tbaa !29
  %t55 = load i64, ptr %l3, !tbaa !24
  %t57 = add i64 %t55, 1
  %t58 = load ptr, ptr %l38, !tbaa !29
  %t59 = load i32, ptr %l41, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eheldParts(ptr %v0, ptr %v1, ptr %t58, i32 %t59, ptr %t54, i64 %t57)
  br label %bb16
bb16:
  br label %bb52
bb17:
  %t62 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t64 = trunc i64 22 to i32
  %t65 = icmp eq i32 %t62, %t64
  br i1 %t65, label %bb18, label %bb19
bb18:
  br label %bb22
bb19:
  %t67 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t69 = trunc i64 23 to i32
  %t70 = icmp eq i32 %t67, %t69
  br i1 %t70, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb35
bb22:
  %t72 = load ptr, ptr %l4, !tbaa !29
  store ptr %t72, ptr %l49, !tbaa !29
  %t73 = load ptr, ptr %l4, !tbaa !29
  %t74 = load i32, ptr %l5, !tbaa !23
  %t77 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t73, i32 %t74)
  store i32 %t77, ptr %l52
  br label %bb23
bb23:
  %t78 = load ptr, ptr %l49, !tbaa !29
  %t79 = load i32, ptr %l52, !tbaa !23
  %t80 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t78, i32 %t79)
  store { i64, ptr } %t80, ptr %l53
  br label %bb24
bb24:
  %t81 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t81, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t82 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t82, 0
  store i64 %t84, ptr %l9, !tbaa !24
  br label %bb25
bb25:
  %t86 = load i64, ptr %l8, !tbaa !24
  %t87 = load i64, ptr %l9, !tbaa !24
  %t90 = icmp slt i64 %t86, %t87
  %t92 = xor i1 %t90, true
  br i1 %t92, label %bb26, label %bb27
bb26:
  br label %bb34
bb27:
  br label %bb28
bb28:
  %t94 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t94, ptr %l60, !tbaa !27
  %t95 = load i64, ptr %l8, !tbaa !24
  %t97 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr i32, ptr %t98, i64 %t95
  %t100 = load i32, ptr %t99, !tbaa !33
  store i32 %t100, ptr %l10, !tbaa !23
  %t102 = load i32, ptr %l10, !tbaa !23
  %t104 = icmp ne i32 %t102, 0
  br i1 %t104, label %bb29, label %bb30
bb29:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load i32, ptr %l10, !tbaa !23
  %t108 = load ptr, ptr %l2, !tbaa !29
  %t109 = load i64, ptr %l3, !tbaa !24
  %t111 = add i64 %t109, 1
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eheldParts(ptr %v0, ptr %v1, ptr %t106, i32 %t107, ptr %t108, i64 %t111)
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t116 = load i64, ptr %l8, !tbaa !24
  %t118 = add i64 %t116, 1
  store i64 %t118, ptr %l8, !tbaa !24
  br label %bb25
bb34:
  br label %bb52
bb35:
  %t120 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t122 = trunc i64 18 to i32
  %t123 = icmp eq i32 %t120, %t122
  br i1 %t123, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb47
bb38:
  store %olang.scope zeroinitializer, ptr %s9
  %t125 = load ptr, ptr %l4, !tbaa !29
  %t126 = load i32, ptr %l5, !tbaa !23
  %t129 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eEmbedded(ptr %v0, ptr %s9, ptr %t125, i32 %t126)
  store { i64, ptr } %t129, ptr %l76
  br label %bb39
bb39:
  %t130 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t130, 0
  %t132 = extractvalue { i64, ptr } %t130, 1
  %t133 = mul i64 %t131, 4
  %t134 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t133)
  call void @llvm.memcpy.p0.p0.i64(ptr %t134, ptr %t132, i64 %t133, i1 false)
  %t135 = insertvalue { i64, ptr } undef, i64 %t131, 0
  %t136 = insertvalue { i64, ptr } %t135, ptr %t134, 1
  store { i64, ptr } %t136, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t138 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t138, 0
  store i64 %t140, ptr %l13, !tbaa !24
  br label %bb40
bb40:
  %t142 = load i64, ptr %l12, !tbaa !24
  %t143 = load i64, ptr %l13, !tbaa !24
  %t146 = icmp slt i64 %t142, %t143
  %t148 = xor i1 %t146, true
  br i1 %t148, label %bb41, label %bb42
bb41:
  br label %bb46
bb42:
  br label %bb43
bb43:
  %t150 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t150, ptr %l84, !tbaa !27
  %t151 = load i64, ptr %l12, !tbaa !24
  %t153 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = getelementptr i32, ptr %t154, i64 %t151
  %t156 = load i32, ptr %t155, !tbaa !33
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = load ptr, ptr %l2, !tbaa !29
  %t161 = load i64, ptr %l3, !tbaa !24
  %t163 = add i64 %t161, 1
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eheldParts(ptr %v0, ptr %v1, ptr %t158, i32 %t156, ptr %t160, i64 %t163)
  br label %bb44
bb44:
  br label %bb45
bb45:
  %t168 = load i64, ptr %l12, !tbaa !24
  %t170 = add i64 %t168, 1
  store i64 %t170, ptr %l12, !tbaa !24
  br label %bb40
bb46:
  call void @__olang_scope_close(ptr %s9)
  br label %bb52
bb47:
  br i1 true, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_f8c813b846b58ae2_519e51a3f456354e)
  unreachable
bb52:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2flower_2ecompiler_2flower_3alowering_2eholderOf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i64
  %l7 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eisDrop(ptr %v0, ptr %t1, i64 %t2)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/lower:lowering", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l7, !tbaa !29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/lower:lowering", ptr %t11, i32 0, i32 15
  %t14 = load i64, ptr %l1, !tbaa !24
  %t17 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlock_26_3e_2eAt_3ccompiler_2ftyped_3aBlock_26_3e(ptr %v0, ptr %v0, ptr %t13, i64 %t14)
  store ptr %t17, ptr %l11
  br label %bb4
bb3:
  store i64 -1, ptr %l5, !tbaa !24
  br label %bb6
bb4:
  %t18 = load ptr, ptr %l7, !tbaa !29
  %t19 = load ptr, ptr %l11, !tbaa !29
  %t20 = call i64 @compiler_2ftyped_2eDropHolder(ptr %v0, ptr %v0, ptr %t18, ptr %t19)
  store i64 %t20, ptr %l12
  br label %bb5
bb5:
  %t21 = load i64, ptr %l12, !tbaa !24
  store i64 %t21, ptr %l5, !tbaa !24
  br label %bb6
bb6:
  %t22 = load i64, ptr %l5, !tbaa !24
  store i64 %t22, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eisDrop(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l8 = alloca ptr
  %l12 = alloca %"compiler/typed:BlockInfo"
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Body", ptr %t4, i32 0, i32 8
  store ptr %t6, ptr %l4, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/lower:lowering", ptr %t7, i32 0, i32 15
  %t13 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlock_26_3e_2eAt_3ccompiler_2ftyped_3aBlock_26_3e(ptr %v0, ptr %s0, ptr %t9, i64 %a1)
  store ptr %t13, ptr %l8
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t16 = getelementptr %"compiler/typed:Block", ptr %t14, i32 0, i32 0
  %t17 = load i32, ptr %t16, !tbaa !23
  %t19 = sext i32 %t17 to i64
  %t20 = load ptr, ptr %l4, !tbaa !29
  %t22 = call %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %v0, ptr %t20, i64 %t19)
  store %"compiler/typed:BlockInfo" %t22, ptr %l12
  br label %bb2
bb2:
  %t23 = getelementptr %"compiler/typed:BlockInfo", ptr %l12, i32 0, i32 1
  %t24 = load i32, ptr %t23, !range !{i32 0, i32 10}
  %t26 = trunc i64 8 to i32
  %t27 = icmp eq i32 %t24, %t26
  call void @__olang_scope_close(ptr %s0)
  store i1 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ejoin(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca %"compiler/lower:tryCtx"
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca i32
  %l21 = alloca i64
  %l24 = alloca %"compiler/lower:tryCtx"
  %l34 = alloca { i64, ptr }
  %l48 = alloca ptr
  %l50 = alloca %"compiler/lower:tryCtx"
  %l52 = alloca %"compiler/lower:tryCtx"
  %l54 = alloca ptr
  %l56 = alloca ptr
  %l68 = alloca { i64, ptr }
  %l76 = alloca %"compiler/lower:tryCtx"
  %l79 = alloca %"compiler/lower:tryCtx"
  %l80 = alloca i32
  %l81 = alloca i32
  %l84 = alloca i32
  %l85 = alloca i32
  %l86 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Join", ptr %t2, i32 0, i32 0
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t8 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2ejoinErrors(ptr %v0, ptr %v1, ptr %t1, ptr %t5)
  store i32 %t8, ptr %l18
  br label %bb1
bb1:
  %t9 = load i32, ptr %l18, !tbaa !23
  store i32 %t9, ptr %l3, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/lower:lowering", ptr %t10, i32 0, i32 12
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t12)
  store i64 %t14, ptr %l21
  br label %bb2
bb2:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Join", ptr %t15, i32 0, i32 2
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  %t19 = load i64, ptr %l21, !tbaa !24
  %t21 = call %"compiler/lower:tryCtx" @compiler_2flower_3atryCtx_2ector(ptr %v1, ptr %v0, i64 %t19, { i64, ptr } %t18, i1 false, i1 false)
  store %"compiler/lower:tryCtx" %t21, ptr %l24
  br label %bb3
bb3:
  %t22 = load %"compiler/lower:tryCtx", ptr %l24
  %t23 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 64, i64 8)
  store %"compiler/lower:tryCtx" %t22, ptr %t23
  store ptr %t23, ptr %l4, !tbaa !29
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Join", ptr %t25, i32 0, i32 2
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  store { i64, ptr } %t28, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t30 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t30, 0
  store i64 %t32, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  %t34 = load i64, ptr %l6, !tbaa !24
  %t35 = load i64, ptr %l7, !tbaa !24
  %t38 = icmp slt i64 %t34, %t35
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb5, label %bb6
bb5:
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t42 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t42, ptr %l34, !tbaa !27
  %t43 = load i64, ptr %l6, !tbaa !24
  %t45 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr ptr, ptr %t46, i64 %t43
  %t48 = load ptr, ptr %t47, !tbaa !39
  store ptr %t48, ptr %l8, !tbaa !29
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t52 = getelementptr %"compiler/lower:tryCtx", ptr %t50, i32 0, i32 4
  %t53 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ePush_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %t52, i32 %t53)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t56 = load i64, ptr %l6, !tbaa !24
  %t58 = add i64 %t56, 1
  store i64 %t58, ptr %l6, !tbaa !24
  br label %bb4
bb10:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l2, !tbaa !29
  %t63 = getelementptr %"compiler/typed:Join", ptr %t61, i32 0, i32 0
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t65 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eopenBlock(ptr %v0, ptr %v1, ptr %t60, ptr %t64, i32 3, i32 %t65)
  br label %bb11
bb11:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/lower:lowering", ptr %t70, i32 0, i32 21
  store ptr %t72, ptr %l48, !tbaa !29
  %t73 = load ptr, ptr %l4, !tbaa !29
  %t75 = load %"compiler/lower:tryCtx", ptr %t73
  store %"compiler/lower:tryCtx" %t75, ptr %l50
  %t77 = call %"compiler/lower:tryCtx" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3atryCtx(ptr %v0, ptr %l50)
  store %"compiler/lower:tryCtx" %t77, ptr %l52
  br label %bb12
bb12:
  %t78 = load ptr, ptr %l48, !tbaa !29
  %t79 = load %"compiler/lower:tryCtx", ptr %l52
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3atryCtx_3e_2ePush_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %v0, ptr %t78, %"compiler/lower:tryCtx" %t79)
  br label %bb13
bb13:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/lower:lowering", ptr %t80, i32 0, i32 22
  store ptr %t82, ptr %l54, !tbaa !29
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = call ptr @compiler_2flower_2ecompiler_2flower_3alowering_2etop(ptr %v0, ptr %s0, ptr %t83)
  store ptr %t85, ptr %l56
  br label %bb14
bb14:
  %t86 = load ptr, ptr %l56, !tbaa !29
  %t88 = getelementptr %"compiler/lower:level", ptr %t86, i32 0, i32 0
  %t89 = load i32, ptr %t88, !tbaa !23
  %t90 = load ptr, ptr %l54, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2ePush_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t90, i32 %t89)
  br label %bb15
bb15:
  %t92 = load ptr, ptr %l2, !tbaa !29
  %t94 = getelementptr %"compiler/typed:Join", ptr %t92, i32 0, i32 0
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = getelementptr %"compiler/typed:Block", ptr %t95, i32 0, i32 1
  %t98 = load { i64, ptr }, ptr %t97, !tbaa !27
  store { i64, ptr } %t98, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t100 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t100, 0
  store i64 %t102, ptr %l11, !tbaa !24
  br label %bb16
bb16:
  %t104 = load i64, ptr %l10, !tbaa !24
  %t105 = load i64, ptr %l11, !tbaa !24
  %t108 = icmp slt i64 %t104, %t105
  %t110 = xor i1 %t108, true
  br i1 %t110, label %bb17, label %bb18
bb17:
  br label %bb22
bb18:
  br label %bb19
bb19:
  %t112 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t112, ptr %l68, !tbaa !27
  %t113 = load i64, ptr %l10, !tbaa !24
  %t115 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr ptr, ptr %t116, i64 %t113
  %t118 = load ptr, ptr %t117, !tbaa !39
  %t120 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estmt(ptr %v0, ptr %v1, ptr %t120, ptr %t118)
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t124 = load i64, ptr %l10, !tbaa !24
  %t126 = add i64 %t124, 1
  store i64 %t126, ptr %l10, !tbaa !24
  br label %bb16
bb22:
  %t128 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ecloseBlock(ptr %v0, ptr %t128)
  br label %bb23
bb23:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/lower:lowering", ptr %t130, i32 0, i32 21
  %t134 = call { i32, %"compiler/lower:tryCtx" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3atryCtx_3e_2ePop_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %v0, ptr %t132)
  %t135 = extractvalue { i32, %"compiler/lower:tryCtx" } %t134, 1
  %t136 = extractvalue { i32, %"compiler/lower:tryCtx" } %t134, 0
  store i32 %t136, ptr %l80
  %t137 = icmp ne i32 %t136, 0
  br i1 %t137, label %bb25, label %ok.138, !prof !99
ok.138:
  store %"compiler/lower:tryCtx" %t135, ptr %l79
  br label %bb24
bb24:
  %t139 = load %"compiler/lower:tryCtx", ptr %l79
  store %"compiler/lower:tryCtx" %t139, ptr %l76
  br label %bb27
bb25:
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb27:
  %t140 = load %"compiler/lower:tryCtx", ptr %l76
  store %"compiler/lower:tryCtx" %t140, ptr %l13
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/lower:lowering", ptr %t141, i32 0, i32 22
  %t145 = call { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2ePop_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t143)
  %t146 = extractvalue { i32, i32 } %t145, 1
  %t147 = extractvalue { i32, i32 } %t145, 0
  store i32 %t147, ptr %l85
  %t148 = icmp ne i32 %t147, 0
  br i1 %t148, label %bb29, label %ok.149, !prof !99
ok.149:
  store i32 %t146, ptr %l84
  br label %bb28
bb28:
  %t150 = load i32, ptr %l84, !tbaa !23
  store i32 %t150, ptr %l81, !tbaa !23
  br label %bb31
bb29:
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t151 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t151, ptr %l86
  br label %bb32
bb32:
  %t152 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l86
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t152, ptr %l14
  %t153 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleaveOpen(ptr %v0, ptr %s0, ptr %t153, ptr %l14)
  br label %bb33
bb33:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load %"compiler/lower:tryCtx", ptr %l13
  %t158 = load ptr, ptr %l2, !tbaa !29
  %t160 = getelementptr %"compiler/typed:Join", ptr %t158, i32 0, i32 2
  %t161 = load { i64, ptr }, ptr %t160, !tbaa !27
  %t162 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t163 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eclauses(ptr %v0, ptr %s0, ptr %v1, ptr %s0, ptr %t156, %"compiler/lower:tryCtx" %t157, { i64, ptr } %t161, i32 %t162, i32 %t163, ptr %l14)
  br label %bb34
bb34:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2epatch(ptr %v0, ptr %s0, ptr %t170, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t171)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2flower_2ecompiler_2flower_3alowering_2ejoinErrors(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l3
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2espawnErrors(ptr %v0, ptr %v1, ptr %s0, ptr %t3, ptr %a1, ptr %l2)
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/lower:lowering", ptr %t9, i32 0, i32 2
  %t12 = load ptr, ptr %t11, !tbaa !29
  store ptr %t12, ptr %l9, !tbaa !29
  %t14 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %s0, ptr %l2)
  store { i64, ptr } %t14, ptr %l11
  br label %bb3
bb3:
  %t15 = load ptr, ptr %l9, !tbaa !29
  %t16 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t17 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t15, { i64, ptr } %t16)
  store i32 %t17, ptr %l12
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t18 = load i32, ptr %l12, !tbaa !23
  store i32 %t18, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ejump(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l8 = alloca i64
  %l16 = alloca ptr
  %l21 = alloca ptr
  %l25 = alloca ptr
  %l31 = alloca ptr
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 17
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aloopCtx_3e_2eLen_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  %t7 = sub i64 %t6, 1
  store i64 %t7, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp sge i64 %t9, 0
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/lower:lowering", ptr %t15, i32 0, i32 17
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aloopCtx_3e_2eRef_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, ptr %s2, ptr %t17, i64 %t18)
  store ptr %t21, ptr %l16
  br label %bb6
bb6:
  %t22 = load ptr, ptr %l16, !tbaa !29
  %t24 = getelementptr %"compiler/lower:loopCtx", ptr %t22, i32 0, i32 0
  %t25 = load i32, ptr %t24, !tbaa !23
  %t29 = icmp eq i32 %t25, %a3
  br i1 %t29, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l21, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/lower:lowering", ptr %t32, i32 0, i32 17
  %t35 = load i64, ptr %l4, !tbaa !24
  %t38 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aloopCtx_3e_2eRef_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, ptr %s3, ptr %t34, i64 %t35)
  store ptr %t38, ptr %l25
  br label %bb9
bb8:
  br label %bb17
bb9:
  %t39 = load ptr, ptr %l25, !tbaa !29
  %t41 = getelementptr %"compiler/lower:loopCtx", ptr %t39, i32 0, i32 1
  %t42 = load i64, ptr %t41, !tbaa !24
  %t43 = load ptr, ptr %l21, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleave(ptr %v0, ptr %t43, i64 %t42)
  br label %bb10
bb10:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/lower:lowering", ptr %t45, i32 0, i32 17
  %t48 = load i64, ptr %l4, !tbaa !24
  %t51 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aloopCtx_3e_2eRefMut_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, ptr %v0, ptr %t47, i64 %t48)
  store ptr %t51, ptr %l31
  br label %bb11
bb11:
  %t52 = load ptr, ptr %l31, !tbaa !29
  store ptr %t52, ptr %l5, !tbaa !29
  %t55 = trunc i64 0 to i32
  %t56 = icmp eq i32 %a2, %t55
  br i1 %t56, label %bb12, label %bb13
bb12:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load ptr, ptr %l5, !tbaa !29
  %t61 = getelementptr %"compiler/lower:loopCtx", ptr %t59, i32 0, i32 3
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleaveOpen(ptr %v0, ptr %v0, ptr %t58, ptr %t61)
  br label %bb14
bb13:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load ptr, ptr %l5, !tbaa !29
  %t67 = getelementptr %"compiler/lower:loopCtx", ptr %t65, i32 0, i32 4
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleaveOpen(ptr %v0, ptr %v0, ptr %t64, ptr %t67)
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  %t70 = load i64, ptr %l4, !tbaa !24
  %t72 = sub i64 %t70, 1
  store i64 %t72, ptr %l4, !tbaa !24
  br label %bb2
bb19:
  %t74 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egap(ptr %v0, ptr %s0, ptr %t74, %"compiler/source:Span" %a1, { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d6, i32 0, i32 1) })
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2elambda(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i32 %a3, i32 %a4, %"compiler/source:Span" %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i1
  %l7 = alloca { i64, [1 x i64] }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l22 = alloca ptr
  %l28 = alloca { i64, [1 x i64] }
  %l32 = alloca { i64, [1 x i64] }
  %l35 = alloca { i64, [1 x i64] }
  %l37 = alloca i64
  %l46 = alloca i64
  %l49 = alloca i64
  %l67 = alloca i64
  %l69 = alloca { i64, ptr }
  %l74 = alloca { i64, [4 x i64] }
  %l75 = alloca { i64, ptr }
  %l79 = alloca i32
  %l83 = alloca i1
  %l86 = alloca i1
  %l87 = alloca i64
  %l94 = alloca { i64, [4 x i64] }
  %l95 = alloca { i64, ptr }
  %l98 = alloca ptr
  %l99 = alloca i1
  %l102 = alloca i1
  %l106 = alloca i1
  %l108 = alloca i1
  %l112 = alloca i1
  %l113 = alloca i64
  %l114 = alloca ptr
  %l116 = alloca { i64, [4 x i64] }
  %l117 = alloca i32
  %l120 = alloca { i64, [1 x i64] }
  %l122 = alloca { i64, [4 x i64] }
  %l128 = alloca ptr
  %l129 = alloca i32
  %l131 = alloca { i64, [2 x i64] }
  %l132 = alloca i32
  %l133 = alloca { i64, [1 x i64] }
  %l137 = alloca %"compiler/mir:Range"
  %l140 = alloca %"compiler/mir:Range"
  %l143 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t26 = alloca { i64, [1 x i64] }, align 8
  %t253 = alloca { i64, [4 x i64] }, align 8
  %t260 = alloca { i64, [2 x i64] }, align 8
  %t280 = alloca { i64, [15 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i32 %a3, ptr %l3
  store i32 %a4, ptr %l4
  store %"compiler/source:Span" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/lower:Lowerer", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = load i32, ptr %l1, !tbaa !23
  %t11 = sext i32 %t9 to i64
  %t14 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t7, i64 %t11)
  store ptr %t14, ptr %l22
  br label %bb1
bb1:
  %t15 = load ptr, ptr %l22, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Body", ptr %t15, i32 0, i32 14
  %t18 = load i1, ptr %t17, !tbaa !21
  store i1 %t18, ptr %l6, !tbaa !21
  %t20 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 0
  %t24 = icmp eq i64 %t22, 0
  br i1 %t24, label %bb2, label %bb3
bb2:
  store { i64, [1 x i64] } zeroinitializer, ptr %t26
  %t27 = getelementptr { i64, [1 x i64] }, ptr %t26, i32 0, i32 0
  store i64 3, ptr %t27
  %t28 = load { i64, [1 x i64] }, ptr %t26
  store { i64, [1 x i64] } %t28, ptr %l28
  br label %bb5
bb3:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i32, ptr %l3, !tbaa !23
  %t34 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ebuilt(ptr %v0, ptr %t30, i32 %t31)
  store { i64, [1 x i64] } %t34, ptr %l32
  br label %bb4
bb4:
  %t35 = load { i64, [1 x i64] }, ptr %l32
  store { i64, [1 x i64] } %t35, ptr %l28
  br label %bb5
bb5:
  %t36 = load { i64, [1 x i64] }, ptr %l28
  store { i64, [1 x i64] } %t36, ptr %l7
  %t37 = load i1, ptr %l6, !tbaa !21
  br i1 %t37, label %bb6, label %bb7
bb6:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eresultScope(ptr %v0, ptr %t39)
  store { i64, [1 x i64] } %t41, ptr %l35
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t42 = load { i64, [1 x i64] }, ptr %l35
  store { i64, [1 x i64] } %t42, ptr %l7
  br label %bb9
bb9:
  %t43 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  store i64 %t45, ptr %l37, !tbaa !24
  %t46 = load i64, ptr %l37, !tbaa !24
  %t47 = icmp sge i64 %t46, 0
  br i1 %t47, label %bb10, label %bb11
bb10:
  %t49 = load i64, ptr %l37, !tbaa !24
  %t50 = icmp sle i64 %t49, 230584300921369395
  br i1 %t50, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_8dbdd81ef51b3d23_89b419ac5748f287)
  unreachable
bb12:
  %t52 = load i64, ptr %l37, !tbaa !24
  %t53 = mul i64 %t52, 40
  %t54 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t53)
  %t55 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t54, 1
  store { i64, ptr } %t56, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t58 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t58, 0
  store i64 %t60, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t62 = load i64, ptr %l10, !tbaa !24
  %t63 = load i64, ptr %l9, !tbaa !24
  %t66 = icmp sgt i64 %t62, %t63
  br i1 %t66, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_8dbdd81ef51b3d23_89b419ac5748f287)
  unreachable
bb14:
  %t68 = load i64, ptr %l11, !tbaa !24
  %t70 = icmp sgt i64 %t68, 0
  br i1 %t70, label %bb16, label %bb17
bb15:
  store i64 0, ptr %l46, !tbaa !24
  br label %bb19
bb16:
  %t72 = load i64, ptr %l10, !tbaa !24
  %t73 = load i64, ptr %l9, !tbaa !24
  %t76 = sub i64 %t72, %t73
  %t77 = load i64, ptr %l11, !tbaa !24
  %t80 = add i64 %t76, %t77
  %t82 = sub i64 %t80, 1
  %t83 = load i64, ptr %l11, !tbaa !24
  %t86 = sdiv i64 %t82, %t83
  store i64 %t86, ptr %l49, !tbaa !24
  br label %bb18
bb17:
  store i64 0, ptr %l49, !tbaa !24
  br label %bb18
bb18:
  %t88 = load i64, ptr %l49, !tbaa !24
  store i64 %t88, ptr %l46, !tbaa !24
  br label %bb19
bb19:
  %t89 = load i64, ptr %l46, !tbaa !24
  store i64 %t89, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb20
bb20:
  %t90 = load i64, ptr %l13, !tbaa !24
  %t91 = load i64, ptr %l12, !tbaa !24
  %t94 = icmp slt i64 %t90, %t91
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb21, label %bb22
bb21:
  br label %bb53
bb22:
  br label %bb23
bb23:
  %t98 = load i64, ptr %l9, !tbaa !24
  %t99 = load i64, ptr %l13, !tbaa !24
  %t100 = load i64, ptr %l11, !tbaa !24
  %t103 = mul i64 %t99, %t100
  %t106 = add i64 %t98, %t103
  store i64 %t106, ptr %l14, !tbaa !24
  %t108 = load i64, ptr %l14, !tbaa !24
  store i64 %t108, ptr %l67, !tbaa !24
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t110, ptr %l69, !tbaa !27
  %t111 = load i64, ptr %l14, !tbaa !24
  %t113 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr ptr, ptr %t114, i64 %t111
  %t116 = load ptr, ptr %t115, !tbaa !39
  %t118 = getelementptr %"compiler/typed:Capture", ptr %t116, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t123 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t109, ptr %t119)
  store { i64, [4 x i64] } %t123, ptr %l74
  br label %bb24
bb24:
  %t124 = load { i64, [4 x i64] }, ptr %l74
  %t125 = load i64, ptr %l67, !tbaa !24
  %t126 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr { i64, [4 x i64] }, ptr %t127, i64 %t125
  store { i64, [4 x i64] } %t124, ptr %t128
  %t129 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t129, ptr %l75, !tbaa !27
  %t130 = load i64, ptr %l14, !tbaa !24
  %t132 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr ptr, ptr %t133, i64 %t130
  %t135 = load ptr, ptr %t134, !tbaa !39
  %t137 = getelementptr %"compiler/typed:Capture", ptr %t135, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t140 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t138)
  store i32 %t140, ptr %l79
  br label %bb25
bb25:
  %t141 = load i32, ptr %l79, !tbaa !23
  store i32 %t141, ptr %l15, !tbaa !23
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/lower:lowering", ptr %t142, i32 0, i32 10
  %t145 = load i1, ptr %t144, !tbaa !21
  br i1 %t145, label %bb26, label %bb27
bb26:
  br label %bb52
bb27:
  br label %bb28
bb28:
  %t147 = load i1, ptr %l6, !tbaa !21
  br i1 %t147, label %bb29, label %bb30
bb29:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load i32, ptr %l15, !tbaa !23
  %t153 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2evalueArray(ptr %v0, ptr %t149, i32 %t150)
  store i1 %t153, ptr %l86
  br label %bb31
bb30:
  store i1 false, ptr %l83, !tbaa !21
  br label %bb32
bb31:
  %t154 = load i1, ptr %l86, !tbaa !21
  store i1 %t154, ptr %l83, !tbaa !21
  br label %bb32
bb32:
  %t155 = load i1, ptr %l83, !tbaa !21
  br i1 %t155, label %bb33, label %bb34
bb33:
  %t156 = load i64, ptr %l14, !tbaa !24
  store i64 %t156, ptr %l87, !tbaa !24
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load i64, ptr %l14, !tbaa !24
  %t160 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !27
  %t162 = getelementptr { i64, [4 x i64] }, ptr %t161, i64 %t158
  %t163 = load { i64, [4 x i64] }, ptr %t162
  %t164 = load i32, ptr %l15, !tbaa !23
  %t165 = load %"compiler/source:Span", ptr %l5
  %t166 = load { i64, [1 x i64] }, ptr %l7
  %t172 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2earrayCopy(ptr %v0, ptr %t157, { i64, [4 x i64] } %t163, i32 %t164, %"compiler/source:Span" %t165, { i64, [1 x i64] } %t166, i1 false)
  store { i64, [4 x i64] } %t172, ptr %l94
  br label %bb35
bb34:
  br label %bb36
bb35:
  %t173 = load { i64, [4 x i64] }, ptr %l94
  %t174 = load i64, ptr %l87, !tbaa !24
  %t175 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !27
  %t177 = getelementptr { i64, [4 x i64] }, ptr %t176, i64 %t174
  store { i64, [4 x i64] } %t173, ptr %t177
  br label %bb36
bb36:
  %t178 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t178, ptr %l95, !tbaa !27
  %t179 = load i64, ptr %l14, !tbaa !24
  %t181 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !27
  %t183 = getelementptr ptr, ptr %t182, i64 %t179
  %t184 = load ptr, ptr %t183, !tbaa !39
  %t186 = getelementptr %"compiler/typed:Capture", ptr %t184, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !29
  store ptr %t187, ptr %l98, !tbaa !29
  store i1 false, ptr %l99, !tbaa !21
  %t188 = load ptr, ptr %l98, !tbaa !29
  %t189 = icmp ne ptr %t188, null
  br i1 %t189, label %bb37, label %bb38
bb37:
  %t191 = load ptr, ptr %l98, !tbaa !29
  %t192 = load i64, ptr %t191, !range !{i64 0, i64 18}
  %t194 = icmp eq i64 %t192, 2
  store i1 %t194, ptr %l99, !tbaa !21
  br label %bb38
bb38:
  %t195 = load i1, ptr %l99, !tbaa !21
  br i1 %t195, label %bb39, label %bb40
bb39:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/lower:lowering", ptr %t196, i32 0, i32 2
  %t199 = load ptr, ptr %t198, !tbaa !29
  %t200 = load i32, ptr %l15, !tbaa !23
  %t203 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t199, i32 %t200)
  store i1 %t203, ptr %l106
  br label %bb41
bb40:
  store i1 false, ptr %l102, !tbaa !21
  br label %bb42
bb41:
  %t204 = load i1, ptr %l106, !tbaa !21
  %t205 = xor i1 %t204, true
  store i1 %t205, ptr %l102, !tbaa !21
  br label %bb42
bb42:
  %t207 = load i1, ptr %l102, !tbaa !21
  br i1 %t207, label %bb43, label %bb44
bb43:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/lower:lowering", ptr %t208, i32 0, i32 2
  %t211 = load ptr, ptr %t210, !tbaa !29
  %t212 = load i32, ptr %l15, !tbaa !23
  %t215 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %t211, i32 %t212)
  store i1 %t215, ptr %l112
  br label %bb45
bb44:
  store i1 false, ptr %l108, !tbaa !21
  br label %bb46
bb45:
  %t216 = load i1, ptr %l112, !tbaa !21
  store i1 %t216, ptr %l108, !tbaa !21
  br label %bb46
bb46:
  %t217 = load i1, ptr %l108, !tbaa !21
  br i1 %t217, label %bb47, label %bb48
bb47:
  %t218 = load i64, ptr %l14, !tbaa !24
  store i64 %t218, ptr %l113, !tbaa !24
  %t219 = load ptr, ptr %l0, !tbaa !29
  store ptr %t219, ptr %l114, !tbaa !29
  %t220 = load i64, ptr %l14, !tbaa !24
  %t222 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t223 = load ptr, ptr %t222, !tbaa !27
  %t224 = getelementptr { i64, [4 x i64] }, ptr %t223, i64 %t220
  %t225 = load { i64, [4 x i64] }, ptr %t224
  store { i64, [4 x i64] } %t225, ptr %l116
  %t226 = load i32, ptr %l15, !tbaa !23
  store i32 %t226, ptr %l117, !tbaa !23
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = load { i64, [1 x i64] }, ptr %l7
  %t231 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ecopyHome(ptr %v0, ptr %t227, { i64, [1 x i64] } %t228)
  store { i64, [1 x i64] } %t231, ptr %l120
  br label %bb49
bb48:
  br label %bb51
bb49:
  %t232 = load %"compiler/source:Span", ptr %l5
  %t233 = load ptr, ptr %l114, !tbaa !29
  %t234 = load { i64, [4 x i64] }, ptr %l116
  %t235 = load i32, ptr %l117, !tbaa !23
  %t236 = load { i64, [1 x i64] }, ptr %l120
  %t238 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eownCopyOf(ptr %v0, ptr %t233, { i64, [4 x i64] } %t234, i32 %t235, { i64, [1 x i64] } %t236, %"compiler/source:Span" %t232, i1 false)
  store { i64, [4 x i64] } %t238, ptr %l122
  br label %bb50
bb50:
  %t239 = load { i64, [4 x i64] }, ptr %l122
  %t240 = load i64, ptr %l113, !tbaa !24
  %t241 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t242 = load ptr, ptr %t241, !tbaa !27
  %t243 = getelementptr { i64, [4 x i64] }, ptr %t242, i64 %t240
  store { i64, [4 x i64] } %t239, ptr %t243
  br label %bb51
bb51:
  br label %bb52
bb52:
  %t244 = load i64, ptr %l13, !tbaa !24
  %t246 = add i64 %t244, 1
  store i64 %t246, ptr %l13, !tbaa !24
  br label %bb20
bb53:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t250 = getelementptr %"compiler/lower:lowering", ptr %t248, i32 0, i32 10
  %t251 = load i1, ptr %t250, !tbaa !21
  br i1 %t251, label %bb54, label %bb55
bb54:
  store { i64, [4 x i64] } zeroinitializer, ptr %t253
  %t254 = getelementptr { i64, [4 x i64] }, ptr %t253, i32 0, i32 0
  store i64 0, ptr %t254
  %t255 = load { i64, [4 x i64] }, ptr %t253
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t255, ptr %rv
  br label %ret
bb55:
  br label %bb56
bb56:
  %t257 = load ptr, ptr %l0, !tbaa !29
  store ptr %t257, ptr %l128, !tbaa !29
  %t258 = load i32, ptr %l4, !tbaa !23
  store i32 %t258, ptr %l129, !tbaa !23
  %t259 = load i32, ptr %l1, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t260
  %t261 = getelementptr { i64, [2 x i64] }, ptr %t260, i32 0, i32 0
  store i64 0, ptr %t261
  %t263 = insertvalue { i32 } undef, i32 %t259, 0
  %t264 = getelementptr { i64, [2 x i64] }, ptr %t260, i32 0, i32 1
  store { i32 } %t263, ptr %t264
  %t265 = load { i64, [2 x i64] }, ptr %t260
  store { i64, [2 x i64] } %t265, ptr %l131
  %t266 = load i32, ptr %l4, !tbaa !23
  store i32 %t266, ptr %l132, !tbaa !23
  %t267 = load { i64, [1 x i64] }, ptr %l7
  store { i64, [1 x i64] } %t267, ptr %l133
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t270 = getelementptr %"compiler/lower:lowering", ptr %t268, i32 0, i32 3
  %t271 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t274 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %s0, ptr %t270, { i64, ptr } %t271)
  store %"compiler/mir:Range" %t274, ptr %l137
  br label %bb57
bb57:
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t276 = load i32, ptr %l3, !tbaa !23
  %t279 = call %"compiler/mir:Range" @compiler_2flower_2ecompiler_2flower_3alowering_2ecapScopes(ptr %v0, ptr %t275, i32 %t276)
  store %"compiler/mir:Range" %t279, ptr %l140
  br label %bb58
bb58:
  store { i64, [15 x i64] } zeroinitializer, ptr %t280
  %t281 = getelementptr { i64, [15 x i64] }, ptr %t280, i32 0, i32 0
  store i64 10, ptr %t281
  %t282 = load { i64, [2 x i64] }, ptr %l131
  %t283 = insertvalue { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" } undef, { i64, [2 x i64] } %t282, 0
  %t284 = load i32, ptr %l132, !tbaa !23
  %t285 = insertvalue { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" } %t283, i32 %t284, 1
  %t286 = load { i64, [1 x i64] }, ptr %l133
  %t287 = insertvalue { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" } %t285, { i64, [1 x i64] } %t286, 2
  %t288 = load %"compiler/mir:Range", ptr %l137
  %t289 = insertvalue { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" } %t287, %"compiler/mir:Range" %t288, 3
  %t290 = load %"compiler/mir:Range", ptr %l140
  %t291 = insertvalue { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" } %t289, %"compiler/mir:Range" %t290, 4
  %t292 = getelementptr { i64, [15 x i64] }, ptr %t280, i32 0, i32 1
  store { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" } %t291, ptr %t292
  %t293 = load { i64, [15 x i64] }, ptr %t280
  %t294 = load %"compiler/source:Span", ptr %l5
  %t295 = load ptr, ptr %l128, !tbaa !29
  %t296 = load i32, ptr %l129, !tbaa !23
  %t299 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t295, i32 %t296, { i64, [15 x i64] } %t293, %"compiler/source:Span" %t294)
  store { i64, [4 x i64] } %t299, ptr %l143
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s0)
  %t300 = load { i64, [4 x i64] }, ptr %l143
  store { i64, [4 x i64] } %t300, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eonError(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l8 = alloca ptr
  %l12 = alloca %"compiler/typed:BlockInfo"
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Body", ptr %t4, i32 0, i32 8
  store ptr %t6, ptr %l4, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/lower:lowering", ptr %t7, i32 0, i32 15
  %t13 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlock_26_3e_2eAt_3ccompiler_2ftyped_3aBlock_26_3e(ptr %v0, ptr %s0, ptr %t9, i64 %a1)
  store ptr %t13, ptr %l8
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t16 = getelementptr %"compiler/typed:Block", ptr %t14, i32 0, i32 0
  %t17 = load i32, ptr %t16, !tbaa !23
  %t19 = sext i32 %t17 to i64
  %t20 = load ptr, ptr %l4, !tbaa !29
  %t22 = call %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %v0, ptr %t20, i64 %t19)
  store %"compiler/typed:BlockInfo" %t22, ptr %l12
  br label %bb2
bb2:
  %t23 = getelementptr %"compiler/typed:BlockInfo", ptr %l12, i32 0, i32 1
  %t24 = load i32, ptr %t23, !range !{i32 0, i32 10}
  %t26 = trunc i64 7 to i32
  %t27 = icmp eq i32 %t24, %t26
  call void @__olang_scope_close(ptr %s0)
  store i1 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2epackedTypes(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/lower:pl" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/lower:pl"
  %l2 = alloca i64
  %lp3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca { i64, [1 x i64] }
  %l12 = alloca i64
  %l14 = alloca i64
  %l18 = alloca i64
  %l27 = alloca i64
  %l30 = alloca i64
  %l52 = alloca i32
  %l54 = alloca i64
  %l59 = alloca { i64, [1 x i64] }
  %l60 = alloca i32
  %l65 = alloca ptr
  %l69 = alloca i32
  %l70 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l77 = alloca i32
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/lower:pl" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/lower:pl", ptr %l1, i32 0, i32 1
  %t3 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eLen_3ccompiler_2fmir_3aProj_3e(ptr %v1, ptr %t1)
  store i64 %t3, ptr %l14
  br label %bb1
bb1:
  %t4 = getelementptr %"compiler/lower:pl", ptr %l1, i32 0, i32 2
  %t5 = load i64, ptr %t4, !tbaa !24
  %t6 = load i64, ptr %l14, !tbaa !24
  %t8 = sub i64 %t6, %t5
  store i64 %t8, ptr %l2, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t12 = add i64 %t10, 1
  store i64 %t12, ptr %l18, !tbaa !24
  %t13 = load i64, ptr %l18, !tbaa !24
  %t14 = icmp sge i64 %t13, 0
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load i64, ptr %l18, !tbaa !24
  %t17 = icmp sle i64 %t16, 2305843009213693951
  br i1 %t17, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_60304de857474a3b_ccf0225621d3461f)
  unreachable
bb4:
  %t19 = load i64, ptr %l18, !tbaa !24
  %t20 = mul i64 %t19, 4
  %t21 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t20)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  %t24 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t24, ptr %lp3
  %t26 = load ptr, ptr %lp3
  store { i64, ptr } %t23, ptr %t26, !tbaa !27
  %t27 = getelementptr %"compiler/lower:pl", ptr %l1, i32 0, i32 3
  %t28 = load i32, ptr %t27, !tbaa !23
  %t30 = load ptr, ptr %lp3
  %t31 = getelementptr { i64, ptr }, ptr %t30, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr i32, ptr %t32, i64 0
  store i32 %t28, ptr %t33, !tbaa !33
  store i64 0, ptr %l4, !tbaa !24
  %t34 = load i64, ptr %l2, !tbaa !24
  store i64 %t34, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t37 = load i64, ptr %l4, !tbaa !24
  %t40 = icmp sgt i64 %t36, %t37
  br i1 %t40, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_60304de857474a3b_ccf0225621d3461f)
  unreachable
bb6:
  %t42 = load i64, ptr %l6, !tbaa !24
  %t44 = icmp sgt i64 %t42, 0
  br i1 %t44, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb11
bb8:
  %t46 = load i64, ptr %l5, !tbaa !24
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = sub i64 %t46, %t47
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = add i64 %t50, %t51
  %t56 = sub i64 %t54, 1
  %t57 = load i64, ptr %l6, !tbaa !24
  %t60 = sdiv i64 %t56, %t57
  store i64 %t60, ptr %l30, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb10
bb10:
  %t62 = load i64, ptr %l30, !tbaa !24
  store i64 %t62, ptr %l27, !tbaa !24
  br label %bb11
bb11:
  %t63 = load i64, ptr %l27, !tbaa !24
  store i64 %t63, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb12
bb12:
  %t64 = load i64, ptr %l8, !tbaa !24
  %t65 = load i64, ptr %l7, !tbaa !24
  %t68 = icmp slt i64 %t64, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb13, label %bb14
bb13:
  br label %bb31
bb14:
  br label %bb15
bb15:
  %t72 = load i64, ptr %l4, !tbaa !24
  %t73 = load i64, ptr %l8, !tbaa !24
  %t74 = load i64, ptr %l6, !tbaa !24
  %t77 = mul i64 %t73, %t74
  %t80 = add i64 %t72, %t77
  store i64 %t80, ptr %l9, !tbaa !24
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/lower:lowering", ptr %t82, i32 0, i32 2
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t86 = load i64, ptr %l9, !tbaa !24
  %t87 = load ptr, ptr %lp3
  %t89 = getelementptr { i64, ptr }, ptr %t87, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr i32, ptr %t90, i64 %t86
  %t92 = load i32, ptr %t91, !tbaa !33
  %t95 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t85, i32 %t92)
  store i32 %t95, ptr %l52
  br label %bb16
bb16:
  %t96 = load i32, ptr %l52, !tbaa !23
  store i32 %t96, ptr %l10, !tbaa !23
  %t97 = load i64, ptr %l9, !tbaa !24
  %t99 = add i64 %t97, 1
  store i64 %t99, ptr %l54, !tbaa !24
  %t100 = getelementptr %"compiler/lower:pl", ptr %l1, i32 0, i32 1
  %t101 = getelementptr %"compiler/lower:pl", ptr %l1, i32 0, i32 2
  %t102 = load i64, ptr %t101, !tbaa !24
  %t103 = load i64, ptr %l9, !tbaa !24
  %t106 = add i64 %t102, %t103
  %t109 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %v1, ptr %t100, i64 %t106)
  store { i64, [1 x i64] } %t109, ptr %l59
  br label %bb17
bb17:
  %t110 = load { i64, [1 x i64] }, ptr %l59
  store { i64, [1 x i64] } %t110, ptr %l11
  %t111 = load { i64, [1 x i64] }, ptr %l11
  %t113 = extractvalue { i64, [1 x i64] } %t111, 0
  %t114 = icmp eq i64 %t113, 0
  br i1 %t114, label %bb18, label %bb19
bb18:
  %t116 = getelementptr { i64, [1 x i64] }, ptr %l11, i32 0, i32 1
  %t117 = getelementptr { i64 }, ptr %t116, i32 0, i32 0
  %t118 = load i64, ptr %t117
  store i64 %t118, ptr %l12, !tbaa !24
  br label %bb20
bb19:
  br label %bb23
bb20:
  store %olang.scope zeroinitializer, ptr %s3
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/lower:lowering", ptr %t120, i32 0, i32 2
  %t123 = load ptr, ptr %t122, !tbaa !29
  store ptr %t123, ptr %l65, !tbaa !29
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/lower:lowering", ptr %t124, i32 0, i32 2
  %t127 = load ptr, ptr %t126, !tbaa !29
  %t128 = load i32, ptr %l10, !tbaa !23
  %t131 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t127, i32 %t128)
  store i32 %t131, ptr %l69
  br label %bb21
bb21:
  %t132 = load ptr, ptr %l65, !tbaa !29
  %t133 = load i32, ptr %l69, !tbaa !23
  %t134 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s3, ptr %t132, i32 %t133)
  store { i64, ptr } %t134, ptr %l70
  br label %bb22
bb22:
  %t135 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t135, ptr %l71, !tbaa !27
  %t136 = load i64, ptr %l12, !tbaa !24
  %t138 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !27
  %t140 = getelementptr i32, ptr %t139, i64 %t136
  %t141 = load i32, ptr %t140, !tbaa !33
  store i32 %t141, ptr %l60, !tbaa !23
  call void @__olang_scope_close(ptr %s3)
  br label %bb29
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/lower:lowering", ptr %t143, i32 0, i32 2
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t147 = load i32, ptr %l10, !tbaa !23
  %t150 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t146, i32 %t147)
  store i32 %t150, ptr %l77
  br label %bb27
bb27:
  %t151 = load i32, ptr %l77, !tbaa !23
  store i32 %t151, ptr %l60, !tbaa !23
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_1c96ed13cfc0c0dd_d1e1293130e6a149)
  unreachable
bb29:
  %t152 = load i32, ptr %l60, !tbaa !23
  %t153 = load ptr, ptr %lp3
  %t154 = load i64, ptr %l54, !tbaa !24
  %t155 = getelementptr { i64, ptr }, ptr %t153, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !27
  %t157 = getelementptr i32, ptr %t156, i64 %t154
  store i32 %t152, ptr %t157, !tbaa !33
  br label %bb30
bb30:
  %t158 = load i64, ptr %l8, !tbaa !24
  %t160 = add i64 %t158, 1
  store i64 %t160, ptr %l8, !tbaa !24
  br label %bb12
bb31:
  %t162 = load ptr, ptr %lp3
  %t163 = load { i64, ptr }, ptr %t162, !tbaa !27
  store { i64, ptr } %t163, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2epartsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/lower:lowering", ptr %t2, i32 0, i32 2
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t9 = call i32 @compiler_2fmir_2eFieldsOf(ptr %v0, ptr %t5, i32 %a1)
  store i32 %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t11 = load i32, ptr %l6, !tbaa !23
  %t12 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2eitems(ptr %v0, ptr %v1, ptr %t10, i32 %t11)
  store { i64, ptr } %t12, ptr %l7
  br label %bb2
bb2:
  %t13 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t13, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { { i64, [4 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2epiece(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca %"compiler/lower:pl"
  %l8 = alloca i32
  %l12 = alloca i32
  %l15 = alloca i32
  %l16 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca i1
  %l22 = alloca i1
  %l26 = alloca i1
  %l29 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca i1
  %l40 = alloca %"compiler/lower:pl"
  %l42 = alloca %"compiler/lower:pl"
  %l50 = alloca ptr
  %l51 = alloca %"compiler/lower:pl"
  %l53 = alloca %"compiler/lower:pl"
  %l56 = alloca { i64, [4 x i64] }
  %l62 = alloca i32
  %l63 = alloca ptr
  %l64 = alloca i32
  %l67 = alloca %"compiler/mir:Lvalue"
  %l71 = alloca { i64, [4 x i64] }
  %l77 = alloca { i64, [4 x i64] }
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { { i64, [4 x i64] }, i32 }
  %t73 = alloca { i64, [4 x i64] }, align 8
  %t120 = alloca { i64, [15 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t6)
  store i32 %t8, ptr %l12
  br label %bb1
bb1:
  %t9 = load i32, ptr %l12, !tbaa !23
  store i32 %t9, ptr %l4, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l4, !tbaa !23
  %t14 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %t10, i32 %t11)
  store i32 %t14, ptr %l15
  br label %bb2
bb2:
  %t15 = load i32, ptr %l15, !tbaa !23
  store i32 %t15, ptr %l5, !tbaa !23
  %t16 = load ptr, ptr %l3, !tbaa !29
  store ptr %t16, ptr %l16, !tbaa !29
  %t17 = load ptr, ptr %l3, !tbaa !29
  %t18 = load i32, ptr %l4, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l19
  br label %bb3
bb3:
  %t22 = load ptr, ptr %l16, !tbaa !29
  %t23 = load i32, ptr %l19, !tbaa !23
  %t24 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t22, i32 %t23)
  store i1 %t24, ptr %l20
  br label %bb4
bb4:
  %t25 = load i1, ptr %l20, !tbaa !21
  %t26 = xor i1 %t25, true
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t28 = load i32, ptr %l5, !tbaa !23
  %t29 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t32 = icmp ne i32 %t28, %t29
  store i1 %t32, ptr %l22, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb7
bb7:
  %t34 = load i1, ptr %l22, !tbaa !21
  br i1 %t34, label %bb8, label %bb9
bb8:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i32, ptr %l5, !tbaa !23
  %t39 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2efixedLen(ptr %v0, ptr %t35, i32 %t36)
  store i64 %t39, ptr %l29
  br label %bb10
bb9:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb11
bb10:
  %t40 = load i64, ptr %l29, !tbaa !24
  %t41 = icmp sge i64 %t40, 0
  store i1 %t41, ptr %l26, !tbaa !21
  br label %bb11
bb11:
  %t43 = load i1, ptr %l26, !tbaa !21
  br i1 %t43, label %bb12, label %bb13
bb12:
  %t44 = load ptr, ptr %l1, !tbaa !29
  store ptr %t44, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t45 = load ptr, ptr %l31, !tbaa !29
  %t46 = icmp ne ptr %t45, null
  br i1 %t46, label %bb14, label %bb15
bb13:
  br label %bb38
bb14:
  %t48 = load ptr, ptr %l31, !tbaa !29
  %t49 = load i64, ptr %t48, !range !{i64 0, i64 18}
  %t51 = icmp eq i64 %t49, 2
  store i1 %t51, ptr %l32, !tbaa !21
  br label %bb15
bb15:
  %t52 = load i1, ptr %l32, !tbaa !21
  br i1 %t52, label %bb16, label %bb17
bb16:
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t55 = getelementptr { i64, [5 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t55, i32 0, i32 2
  %t57 = load ptr, ptr %t56
  store ptr %t57, ptr %l6, !tbaa !29
  br label %bb18
bb17:
  br label %bb32
bb18:
  store %olang.scope zeroinitializer, ptr %s2
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load ptr, ptr %l6, !tbaa !29
  %t64 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eplace(ptr %v0, ptr %v1, ptr %s2, ptr %t59, ptr %t60)
  store %"compiler/lower:pl" %t64, ptr %l40
  br label %bb19
bb19:
  %t66 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s2, ptr %l40)
  store %"compiler/lower:pl" %t66, ptr %l42
  br label %bb20
bb20:
  %t67 = load %"compiler/lower:pl", ptr %l42
  store %"compiler/lower:pl" %t67, ptr %l7
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/lower:lowering", ptr %t68, i32 0, i32 10
  %t71 = load i1, ptr %t70, !tbaa !21
  br i1 %t71, label %bb21, label %bb22
bb21:
  store { i64, [4 x i64] } zeroinitializer, ptr %t73
  %t74 = getelementptr { i64, [4 x i64] }, ptr %t73, i32 0, i32 0
  store i64 0, ptr %t74
  %t75 = load { i64, [4 x i64] }, ptr %t73
  %t76 = load i32, ptr %l4, !tbaa !23
  %t78 = insertvalue { { i64, [4 x i64] }, i32 } undef, { i64, [4 x i64] } %t75, 0
  %t80 = insertvalue { { i64, [4 x i64] }, i32 } %t78, i32 %t76, 1
  call void @__olang_scope_close(ptr %s2)
  store { { i64, [4 x i64] }, i32 } %t80, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t82 = getelementptr %"compiler/lower:pl", ptr %l7, i32 0, i32 2
  %t83 = load i64, ptr %t82, !tbaa !24
  %t85 = icmp sge i64 %t83, 0
  br i1 %t85, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s4
  %t87 = load ptr, ptr %l0, !tbaa !29
  store ptr %t87, ptr %l50, !tbaa !29
  %t88 = load %"compiler/lower:pl", ptr %l7
  store %"compiler/lower:pl" %t88, ptr %l51
  %t90 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s4, ptr %l51)
  store %"compiler/lower:pl" %t90, ptr %l53
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t91 = load i32, ptr %l4, !tbaa !23
  %t92 = load %"compiler/source:Span", ptr %l2
  %t93 = load ptr, ptr %l50, !tbaa !29
  %t94 = load %"compiler/lower:pl", ptr %l53
  %t97 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2epackedRead(ptr %v0, ptr %s4, ptr %t93, %"compiler/lower:pl" %t94, i32 %t91, %"compiler/source:Span" %t92)
  store { i64, [4 x i64] } %t97, ptr %l56
  br label %bb27
bb27:
  %t98 = load i32, ptr %l4, !tbaa !23
  %t99 = load { i64, [4 x i64] }, ptr %l56
  %t100 = insertvalue { { i64, [4 x i64] }, i32 } undef, { i64, [4 x i64] } %t99, 0
  %t102 = insertvalue { { i64, [4 x i64] }, i32 } %t100, i32 %t98, 1
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  store { { i64, [4 x i64] }, i32 } %t102, ptr %rv
  br label %ret
bb28:
  %t104 = load ptr, ptr %l3, !tbaa !29
  %t105 = load i32, ptr %l4, !tbaa !23
  %t106 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t110 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t104, i32 %t105, i64 %t106)
  store i32 %t110, ptr %l62
  br label %bb29
bb29:
  %t111 = load i32, ptr %l62, !tbaa !23
  store i32 %t111, ptr %l8, !tbaa !23
  %t112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t112, ptr %l63, !tbaa !29
  %t113 = load i32, ptr %l8, !tbaa !23
  store i32 %t113, ptr %l64, !tbaa !23
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load %"compiler/lower:pl", ptr %l7
  %t118 = call %"compiler/mir:Lvalue" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %s2, ptr %t114, %"compiler/lower:pl" %t115)
  store %"compiler/mir:Lvalue" %t118, ptr %l67
  br label %bb30
bb30:
  %t119 = load i32, ptr %l8, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t120
  %t121 = getelementptr { i64, [15 x i64] }, ptr %t120, i32 0, i32 0
  store i64 1, ptr %t121
  %t122 = load %"compiler/mir:Lvalue", ptr %l67
  %t123 = insertvalue { %"compiler/mir:Lvalue", i32 } undef, %"compiler/mir:Lvalue" %t122, 0
  %t125 = insertvalue { %"compiler/mir:Lvalue", i32 } %t123, i32 %t119, 1
  %t126 = getelementptr { i64, [15 x i64] }, ptr %t120, i32 0, i32 1
  store { %"compiler/mir:Lvalue", i32 } %t125, ptr %t126
  %t127 = load { i64, [15 x i64] }, ptr %t120
  %t128 = load %"compiler/source:Span", ptr %l2
  %t129 = load ptr, ptr %l63, !tbaa !29
  %t130 = load i32, ptr %l64, !tbaa !23
  %t133 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t129, i32 %t130, { i64, [15 x i64] } %t127, %"compiler/source:Span" %t128)
  store { i64, [4 x i64] } %t133, ptr %l71
  br label %bb31
bb31:
  %t134 = load i32, ptr %l8, !tbaa !23
  %t135 = load { i64, [4 x i64] }, ptr %l71
  %t136 = insertvalue { { i64, [4 x i64] }, i32 } undef, { i64, [4 x i64] } %t135, 0
  %t138 = insertvalue { { i64, [4 x i64] }, i32 } %t136, i32 %t134, 1
  call void @__olang_scope_close(ptr %s2)
  store { { i64, [4 x i64] }, i32 } %t138, ptr %rv
  br label %ret
bb32:
  br i1 true, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_eff9370fb6cf39b1_ff4f9c232720af7d)
  unreachable
bb37:
  br label %bb38
bb38:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load ptr, ptr %l1, !tbaa !29
  %t145 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t140, ptr %t141)
  store { i64, [4 x i64] } %t145, ptr %l77
  br label %bb39
bb39:
  %t146 = load i32, ptr %l4, !tbaa !23
  %t147 = load { i64, [4 x i64] }, ptr %l77
  %t148 = insertvalue { { i64, [4 x i64] }, i32 } undef, { i64, [4 x i64] } %t147, 0
  %t150 = insertvalue { { i64, [4 x i64] }, i32 } %t148, i32 %t146, 1
  store { { i64, [4 x i64] }, i32 } %t150, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, [4 x i64] }, i32 }, ptr %rv
  ret { { i64, [4 x i64] }, i32 } %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eplaceRooted(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i1
  %l22 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i1
  %l32 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i1
  %l42 = alloca i1
  %l43 = alloca i1
  %l47 = alloca i1
  %l49 = alloca { i64, ptr }
  %l51 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i1
  %l60 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb9
bb4:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t17 = load ptr, ptr %l14, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l14, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 18}
  %t23 = icmp eq i64 %t21, 3
  store i1 %t23, ptr %l15, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l15, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t27, i32 0, i32 2
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l2, !tbaa !29
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t35 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2elocalRooted(ptr %v0, ptr %v1, ptr %t31, ptr %t32)
  store i1 %t35, ptr %l22
  br label %bb10
bb10:
  %t36 = load i1, ptr %l22, !tbaa !21
  store i1 %t36, ptr %l7, !tbaa !21
  br label %bb44
bb11:
  %t37 = load ptr, ptr %l1, !tbaa !29
  store ptr %t37, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t38 = load ptr, ptr %l23, !tbaa !29
  %t39 = icmp ne ptr %t38, null
  br i1 %t39, label %bb12, label %bb13
bb12:
  %t41 = load ptr, ptr %l23, !tbaa !29
  %t42 = load i64, ptr %t41, !range !{i64 0, i64 18}
  %t44 = icmp eq i64 %t42, 10
  store i1 %t44, ptr %l24, !tbaa !21
  br label %bb13
bb13:
  %t45 = load i1, ptr %l24, !tbaa !21
  br i1 %t45, label %bb14, label %bb15
bb14:
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t48 = getelementptr { i64, [5 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t48, i32 0, i32 2
  %t50 = load ptr, ptr %t49
  store ptr %t50, ptr %l3, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l3, !tbaa !29
  %t55 = getelementptr %"compiler/typed:Slice", ptr %t53, i32 0, i32 0
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t59 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2elocalRooted(ptr %v0, ptr %v1, ptr %t52, ptr %t56)
  store i1 %t59, ptr %l32
  br label %bb17
bb17:
  %t60 = load i1, ptr %l32, !tbaa !21
  store i1 %t60, ptr %l7, !tbaa !21
  br label %bb44
bb18:
  %t61 = load ptr, ptr %l1, !tbaa !29
  store ptr %t61, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t62 = load ptr, ptr %l33, !tbaa !29
  %t63 = icmp ne ptr %t62, null
  br i1 %t63, label %bb19, label %bb20
bb19:
  %t65 = load ptr, ptr %l33, !tbaa !29
  %t66 = load i64, ptr %t65, !range !{i64 0, i64 18}
  %t68 = icmp eq i64 %t66, 9
  store i1 %t68, ptr %l34, !tbaa !21
  br label %bb20
bb20:
  %t69 = load i1, ptr %l34, !tbaa !21
  br i1 %t69, label %bb21, label %bb22
bb21:
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t72 = getelementptr { i64, [5 x i64] }, ptr %t70, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t72, i32 0, i32 2
  %t74 = load i32, ptr %t73, !range !{i32 0, i32 52}
  store i32 %t74, ptr %l4
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr { i64, [5 x i64] }, ptr %t76, i32 0, i32 1
  %t79 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t78, i32 0, i32 4
  %t80 = load { i64, ptr }, ptr %t79
  store { i64, ptr } %t80, ptr %l5, !tbaa !27
  br label %bb23
bb22:
  br label %bb32
bb23:
  %t82 = load i32, ptr %l4, !range !{i32 0, i32 52}
  %t84 = call i1 @compiler_2ftyped_2ePassesRefs(i32 %t82)
  store i1 %t84, ptr %l42
  br label %bb24
bb24:
  %t85 = load i1, ptr %l42, !tbaa !21
  br i1 %t85, label %bb25, label %bb26
bb25:
  %t86 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t90 = icmp sgt i64 %t88, 0
  store i1 %t90, ptr %l43, !tbaa !21
  br label %bb27
bb26:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb27
bb27:
  %t92 = load i1, ptr %l43, !tbaa !21
  br i1 %t92, label %bb28, label %bb29
bb28:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t94, ptr %l49, !tbaa !27
  %t95 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr ptr, ptr %t96, i64 0
  %t98 = load ptr, ptr %t97, !tbaa !39
  %t101 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eplaceRooted(ptr %v0, ptr %v1, ptr %t93, ptr %t98)
  store i1 %t101, ptr %l51
  br label %bb30
bb29:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb31
bb30:
  %t102 = load i1, ptr %l51, !tbaa !21
  store i1 %t102, ptr %l47, !tbaa !21
  br label %bb31
bb31:
  %t103 = load i1, ptr %l47, !tbaa !21
  store i1 %t103, ptr %l7, !tbaa !21
  br label %bb44
bb32:
  %t104 = load ptr, ptr %l1, !tbaa !29
  store ptr %t104, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t105 = load ptr, ptr %l52, !tbaa !29
  %t106 = icmp ne ptr %t105, null
  br i1 %t106, label %bb33, label %bb34
bb33:
  %t108 = load ptr, ptr %l52, !tbaa !29
  %t109 = load i64, ptr %t108, !range !{i64 0, i64 18}
  %t111 = icmp eq i64 %t109, 17
  store i1 %t111, ptr %l53, !tbaa !21
  br label %bb34
bb34:
  %t112 = load i1, ptr %l53, !tbaa !21
  br i1 %t112, label %bb35, label %bb36
bb35:
  %t113 = load ptr, ptr %l1, !tbaa !29
  %t115 = getelementptr { i64, [5 x i64] }, ptr %t113, i32 0, i32 1
  %t116 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t115, i32 0, i32 2
  %t117 = load ptr, ptr %t116
  store ptr %t117, ptr %l6, !tbaa !29
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load ptr, ptr %l6, !tbaa !29
  %t123 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eplaceRooted(ptr %v0, ptr %v1, ptr %t119, ptr %t120)
  store i1 %t123, ptr %l60
  br label %bb38
bb38:
  %t124 = load i1, ptr %l60, !tbaa !21
  store i1 %t124, ptr %l7, !tbaa !21
  br label %bb44
bb39:
  br i1 true, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_c024ea3ffaf634ad_6315be653d232c01)
  unreachable
bb44:
  %t125 = load i1, ptr %l7, !tbaa !21
  store i1 %t125, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eprimChecks(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, i32 %a2, { i64, ptr } %a3, { i64, ptr } %a4, i32 %a5, %"compiler/source:Span" %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l18 = alloca { i64, [4 x i64] }
  %l20 = alloca { i64, [4 x i64] }
  %l25 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l28 = alloca i32
  %l29 = alloca i32
  %l32 = alloca i32
  %l38 = alloca i32
  %l39 = alloca ptr
  %l40 = alloca { i64, ptr }
  %l42 = alloca i32
  %l43 = alloca i32
  %l47 = alloca i1
  %l51 = alloca i1
  %l54 = alloca i64
  %l56 = alloca i1
  %l59 = alloca i64
  %l64 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l68 = alloca { i64, [4 x i64] }
  %l69 = alloca ptr
  %l70 = alloca i32
  %l71 = alloca i32
  %l72 = alloca { i64, [4 x i64] }
  %l73 = alloca i32
  %l76 = alloca i64
  %l78 = alloca { i64, ptr }
  %l80 = alloca { i64, [4 x i64] }
  %l89 = alloca i1
  %l90 = alloca i1
  %l93 = alloca i1
  %l94 = alloca i1
  %l97 = alloca i1
  %l100 = alloca i1
  %l101 = alloca ptr
  %l102 = alloca i32
  %l103 = alloca { i64, ptr }
  %l105 = alloca i32
  %l106 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l110 = alloca { i64, ptr }
  %l112 = alloca { i64, [4 x i64] }
  %l113 = alloca ptr
  %l114 = alloca i32
  %l115 = alloca i32
  %l116 = alloca { i64, [4 x i64] }
  %l117 = alloca { i64, ptr }
  %l119 = alloca i32
  %l121 = alloca { i64, ptr }
  %l123 = alloca { i64, [4 x i64] }
  %l130 = alloca ptr
  %l131 = alloca i32
  %l132 = alloca i32
  %l133 = alloca i32
  %l137 = alloca %"compiler/mir:Range"
  %l140 = alloca { i64, [4 x i64] }
  %l149 = alloca i1
  %l155 = alloca { i64, [4 x i64] }
  %l161 = alloca { i64, ptr }
  %l163 = alloca { i64, [4 x i64] }
  %l170 = alloca { i64, ptr }
  %l172 = alloca { i64, [4 x i64] }
  %l173 = alloca ptr
  %l174 = alloca i32
  %l175 = alloca i32
  %l176 = alloca { i64, [4 x i64] }
  %l182 = alloca { i64, ptr }
  %l184 = alloca { i64, [4 x i64] }
  %l185 = alloca { i64, ptr }
  %l187 = alloca { i64, [4 x i64] }
  %l190 = alloca i1
  %l191 = alloca ptr
  %l192 = alloca i32
  %l193 = alloca { i64, ptr }
  %l195 = alloca i32
  %l196 = alloca { i64, ptr }
  %l198 = alloca { i64, ptr }
  %l200 = alloca { i64, ptr }
  %l202 = alloca { i64, [4 x i64] }
  %l203 = alloca ptr
  %l204 = alloca i32
  %l205 = alloca i32
  %l206 = alloca { i64, [4 x i64] }
  %l207 = alloca { i64, ptr }
  %l209 = alloca i32
  %l211 = alloca { i64, ptr }
  %l213 = alloca { i64, [4 x i64] }
  %l214 = alloca ptr
  %l215 = alloca i32
  %l216 = alloca i32
  %l217 = alloca { i64, [4 x i64] }
  %l222 = alloca { i64, ptr }
  %l224 = alloca { i64, [4 x i64] }
  %l225 = alloca { i64, ptr }
  %l227 = alloca { i64, [4 x i64] }
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %t111 = alloca { i64, [4 x i64] }, align 8
  %t229 = alloca { i64, [4 x i64] }, align 8
  %t279 = alloca { i64, [15 x i64] }, align 8
  %t349 = alloca { i64, [4 x i64] }, align 8
  %t476 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  store i32 %a5, ptr %l5
  store %"compiler/source:Span" %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l7, !tbaa !29
  %t6 = load ptr, ptr %l7, !tbaa !29
  store ptr %t6, ptr %l25, !tbaa !29
  %t7 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t7, ptr %l26, !tbaa !27
  %t8 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !27
  %t10 = getelementptr ptr, ptr %t9, i64 0
  %t11 = load ptr, ptr %t10, !tbaa !39
  %t13 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v2, ptr %t11)
  store i32 %t13, ptr %l28
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l25, !tbaa !29
  %t15 = load i32, ptr %l28, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t14, i32 %t15)
  store i32 %t16, ptr %l29
  br label %bb2
bb2:
  %t17 = load i32, ptr %l29, !tbaa !23
  store i32 %t17, ptr %l8, !tbaa !23
  %t18 = load ptr, ptr %l7, !tbaa !29
  %t19 = load i32, ptr %l5, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l32
  br label %bb3
bb3:
  %t23 = load i32, ptr %l32, !tbaa !23
  store i32 %t23, ptr %l9, !tbaa !23
  store i32 2, ptr %l10
  %t25 = load i32, ptr %l1, !range !{i32 0, i32 52}
  %t27 = trunc i64 20 to i32
  %t28 = icmp eq i32 %t25, %t27
  br i1 %t28, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb72
bb6:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i32, ptr %l5, !tbaa !23
  %t34 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %t30, i32 %t31)
  store i32 %t34, ptr %l38
  br label %bb7
bb7:
  %t35 = load i32, ptr %l38, !tbaa !23
  store i32 %t35, ptr %l11, !tbaa !23
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l39, !tbaa !29
  %t37 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t37, ptr %l40, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr ptr, ptr %t39, i64 0
  %t41 = load ptr, ptr %t40, !tbaa !39
  %t43 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v2, ptr %t41)
  store i32 %t43, ptr %l42
  br label %bb8
bb8:
  %t44 = load ptr, ptr %l39, !tbaa !29
  %t45 = load i32, ptr %l42, !tbaa !23
  %t46 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %t44, i32 %t45)
  store i32 %t46, ptr %l43
  br label %bb9
bb9:
  %t47 = load i32, ptr %l43, !tbaa !23
  store i32 %t47, ptr %l12, !tbaa !23
  %t48 = load i32, ptr %l11, !tbaa !23
  %t49 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t52 = icmp ne i32 %t48, %t49
  br i1 %t52, label %bb10, label %bb11
bb10:
  %t54 = load i32, ptr %l12, !tbaa !23
  %t55 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t58 = icmp ne i32 %t54, %t55
  store i1 %t58, ptr %l47, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb12
bb12:
  %t60 = load i1, ptr %l47, !tbaa !21
  br i1 %t60, label %bb13, label %bb14
bb13:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load i32, ptr %l11, !tbaa !23
  %t65 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2efixedLen(ptr %v0, ptr %t61, i32 %t62)
  store i64 %t65, ptr %l54
  br label %bb15
bb14:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb16
bb15:
  %t66 = load i64, ptr %l54, !tbaa !24
  %t67 = icmp sge i64 %t66, 0
  store i1 %t67, ptr %l51, !tbaa !21
  br label %bb16
bb16:
  %t69 = load i1, ptr %l51, !tbaa !21
  br i1 %t69, label %bb17, label %bb18
bb17:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load i32, ptr %l12, !tbaa !23
  %t74 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2efixedLen(ptr %v0, ptr %t70, i32 %t71)
  store i64 %t74, ptr %l59
  br label %bb19
bb18:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb20
bb19:
  %t75 = load i64, ptr %l59, !tbaa !24
  %t76 = icmp slt i64 %t75, 0
  store i1 %t76, ptr %l56, !tbaa !21
  br label %bb20
bb20:
  %t78 = load i1, ptr %l56, !tbaa !21
  br i1 %t78, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s2
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t81 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t81, ptr %l64, !tbaa !27
  %t82 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr { i64, [4 x i64] }, ptr %t83, i64 0
  %t85 = load { i64, [4 x i64] }, ptr %t84
  %t86 = mul i64 1, 40
  %t87 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t86)
  %t88 = insertvalue { i64, ptr } undef, i64 1, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t87, 1
  store { i64, ptr } %t89, ptr %l66, !tbaa !27
  %t91 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = getelementptr { i64, [4 x i64] }, ptr %t92, i64 0
  store { i64, [4 x i64] } %t85, ptr %t93
  %t94 = load %"compiler/source:Span", ptr %l6
  %t98 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t100 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s2, ptr %t79, i32 22, i32 %t80, { i64, ptr } %t98, %"compiler/source:Span" %t94)
  store { i64, [4 x i64] } %t100, ptr %l68
  br label %bb23
bb22:
  br label %bb27
bb23:
  %t101 = load { i64, [4 x i64] }, ptr %l68
  %t102 = load ptr, ptr %l0, !tbaa !29
  store ptr %t102, ptr %l69, !tbaa !29
  store i32 13, ptr %l70
  %t103 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t103, ptr %l71, !tbaa !23
  store { i64, [4 x i64] } %t101, ptr %l72
  %t105 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t105, ptr %l73, !tbaa !23
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load i32, ptr %l11, !tbaa !23
  %t110 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2efixedLen(ptr %v0, ptr %t106, i32 %t107)
  store i64 %t110, ptr %l76
  br label %bb24
bb24:
  store { i64, [4 x i64] } zeroinitializer, ptr %t111
  %t112 = getelementptr { i64, [4 x i64] }, ptr %t111, i32 0, i32 0
  store i64 2, ptr %t112
  %t113 = load i32, ptr %l73, !tbaa !23
  %t114 = insertvalue { i32, i64 } undef, i32 %t113, 0
  %t115 = load i64, ptr %l76, !tbaa !24
  %t116 = insertvalue { i32, i64 } %t114, i64 %t115, 1
  %t117 = getelementptr { i64, [4 x i64] }, ptr %t111, i32 0, i32 1
  store { i32, i64 } %t116, ptr %t117
  %t118 = load { i64, [4 x i64] }, ptr %t111
  %t119 = mul i64 2, 40
  %t120 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t119)
  %t121 = insertvalue { i64, ptr } undef, i64 2, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t120, 1
  store { i64, ptr } %t122, ptr %l78, !tbaa !27
  %t123 = load { i64, [4 x i64] }, ptr %l72
  %t124 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr { i64, [4 x i64] }, ptr %t125, i64 0
  store { i64, [4 x i64] } %t123, ptr %t126
  %t128 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr { i64, [4 x i64] }, ptr %t129, i64 1
  store { i64, [4 x i64] } %t118, ptr %t130
  %t131 = load %"compiler/source:Span", ptr %l6
  %t132 = load ptr, ptr %l69, !tbaa !29
  %t133 = load i32, ptr %l70, !range !{i32 0, i32 52}
  %t134 = load i32, ptr %l71, !tbaa !23
  %t135 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t137 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s2, ptr %t132, i32 %t133, i32 %t134, { i64, ptr } %t135, %"compiler/source:Span" %t131)
  store { i64, [4 x i64] } %t137, ptr %l80
  br label %bb25
bb25:
  %t138 = load { i64, [4 x i64] }, ptr %l80
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = load i32, ptr %l2, !range !{i32 0, i32 3}
  %t142 = load i64, ptr @G_2ecompiler_2flower_2eOutOfBounds, !tbaa !24
  %t143 = load %"compiler/source:Span", ptr %l6
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2echeck(ptr %v0, ptr %t139, { i64, [4 x i64] } %t138, i32 %t141, i32 11, i64 %t142, %"compiler/source:Span" %t143)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb27:
  %t150 = load ptr, ptr %l7, !tbaa !29
  %t151 = load i32, ptr %l9, !tbaa !23
  %t154 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t150, i32 %t151)
  store i1 %t154, ptr %l89
  br label %bb28
bb28:
  %t155 = load i1, ptr %l89, !tbaa !21
  br i1 %t155, label %bb29, label %bb30
bb29:
  %t156 = load ptr, ptr %l7, !tbaa !29
  %t157 = load i32, ptr %l8, !tbaa !23
  %t160 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t156, i32 %t157)
  store i1 %t160, ptr %l93
  br label %bb31
bb30:
  store i1 false, ptr %l90, !tbaa !21
  br label %bb36
bb31:
  %t161 = load i1, ptr %l93, !tbaa !21
  br i1 %t161, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l94, !tbaa !21
  br label %bb35
bb33:
  %t162 = load ptr, ptr %l7, !tbaa !29
  %t163 = load i32, ptr %l8, !tbaa !23
  %t166 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t162, i32 %t163)
  store i1 %t166, ptr %l97
  br label %bb34
bb34:
  %t167 = load i1, ptr %l97, !tbaa !21
  store i1 %t167, ptr %l94, !tbaa !21
  br label %bb35
bb35:
  %t168 = load i1, ptr %l94, !tbaa !21
  store i1 %t168, ptr %l90, !tbaa !21
  br label %bb36
bb36:
  %t169 = load i1, ptr %l90, !tbaa !21
  br i1 %t169, label %bb37, label %bb38
bb37:
  %t170 = load ptr, ptr %l7, !tbaa !29
  %t171 = load i32, ptr %l8, !tbaa !23
  %t174 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t170, i32 %t171)
  store i1 %t174, ptr %l100
  br label %bb39
bb38:
  %t175 = load ptr, ptr %l7, !tbaa !29
  %t176 = load i32, ptr %l9, !tbaa !23
  %t179 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t175, i32 %t176)
  store i1 %t179, ptr %l149
  br label %bb51
bb39:
  %t180 = load i1, ptr %l100, !tbaa !21
  br i1 %t180, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s4
  %t181 = load ptr, ptr %l0, !tbaa !29
  store ptr %t181, ptr %l101, !tbaa !29
  store i32 4, ptr %l102
  %t182 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t182, ptr %l103, !tbaa !27
  %t183 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t184 = load ptr, ptr %t183, !tbaa !27
  %t185 = getelementptr ptr, ptr %t184, i64 0
  %t186 = load ptr, ptr %t185, !tbaa !39
  %t188 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v2, ptr %t186)
  store i32 %t188, ptr %l105
  br label %bb42
bb41:
  br label %bb47
bb42:
  %t189 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t189, ptr %l106, !tbaa !27
  %t190 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !27
  %t192 = getelementptr { i64, [4 x i64] }, ptr %t191, i64 0
  %t193 = load { i64, [4 x i64] }, ptr %t192
  %t194 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t194, ptr %l108, !tbaa !27
  %t195 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !27
  %t197 = getelementptr { i64, [4 x i64] }, ptr %t196, i64 0
  %t198 = load { i64, [4 x i64] }, ptr %t197
  %t199 = mul i64 2, 40
  %t200 = call ptr @__olang_scope_alloc_zeroed(ptr %s4, i64 %t199)
  %t201 = insertvalue { i64, ptr } undef, i64 2, 0
  %t202 = insertvalue { i64, ptr } %t201, ptr %t200, 1
  store { i64, ptr } %t202, ptr %l110, !tbaa !27
  %t204 = getelementptr { i64, ptr }, ptr %l110, i32 0, i32 1
  %t205 = load ptr, ptr %t204, !tbaa !27
  %t206 = getelementptr { i64, [4 x i64] }, ptr %t205, i64 0
  store { i64, [4 x i64] } %t193, ptr %t206
  %t208 = getelementptr { i64, ptr }, ptr %l110, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr { i64, [4 x i64] }, ptr %t209, i64 1
  store { i64, [4 x i64] } %t198, ptr %t210
  %t211 = load %"compiler/source:Span", ptr %l6
  %t212 = load ptr, ptr %l101, !tbaa !29
  %t213 = load i32, ptr %l102, !range !{i32 0, i32 52}
  %t214 = load i32, ptr %l105, !tbaa !23
  %t215 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t217 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s4, ptr %t212, i32 %t213, i32 %t214, { i64, ptr } %t215, %"compiler/source:Span" %t211)
  store { i64, [4 x i64] } %t217, ptr %l112
  br label %bb43
bb43:
  %t218 = load { i64, [4 x i64] }, ptr %l112
  %t219 = load ptr, ptr %l0, !tbaa !29
  store ptr %t219, ptr %l113, !tbaa !29
  store i32 13, ptr %l114
  %t220 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t220, ptr %l115, !tbaa !23
  store { i64, [4 x i64] } %t218, ptr %l116
  %t222 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t222, ptr %l117, !tbaa !27
  %t223 = getelementptr { i64, ptr }, ptr %l117, i32 0, i32 1
  %t224 = load ptr, ptr %t223, !tbaa !27
  %t225 = getelementptr ptr, ptr %t224, i64 0
  %t226 = load ptr, ptr %t225, !tbaa !39
  %t228 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v2, ptr %t226)
  store i32 %t228, ptr %l119
  br label %bb44
bb44:
  store { i64, [4 x i64] } zeroinitializer, ptr %t229
  %t230 = getelementptr { i64, [4 x i64] }, ptr %t229, i32 0, i32 0
  store i64 2, ptr %t230
  %t231 = load i32, ptr %l119, !tbaa !23
  %t232 = insertvalue { i32, i64 } undef, i32 %t231, 0
  %t233 = insertvalue { i32, i64 } %t232, i64 0, 1
  %t234 = getelementptr { i64, [4 x i64] }, ptr %t229, i32 0, i32 1
  store { i32, i64 } %t233, ptr %t234
  %t235 = load { i64, [4 x i64] }, ptr %t229
  %t236 = mul i64 2, 40
  %t237 = call ptr @__olang_scope_alloc_zeroed(ptr %s4, i64 %t236)
  %t238 = insertvalue { i64, ptr } undef, i64 2, 0
  %t239 = insertvalue { i64, ptr } %t238, ptr %t237, 1
  store { i64, ptr } %t239, ptr %l121, !tbaa !27
  %t240 = load { i64, [4 x i64] }, ptr %l116
  %t241 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t242 = load ptr, ptr %t241, !tbaa !27
  %t243 = getelementptr { i64, [4 x i64] }, ptr %t242, i64 0
  store { i64, [4 x i64] } %t240, ptr %t243
  %t245 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t246 = load ptr, ptr %t245, !tbaa !27
  %t247 = getelementptr { i64, [4 x i64] }, ptr %t246, i64 1
  store { i64, [4 x i64] } %t235, ptr %t247
  %t248 = load %"compiler/source:Span", ptr %l6
  %t249 = load ptr, ptr %l113, !tbaa !29
  %t250 = load i32, ptr %l114, !range !{i32 0, i32 52}
  %t251 = load i32, ptr %l115, !tbaa !23
  %t252 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t254 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s4, ptr %t249, i32 %t250, i32 %t251, { i64, ptr } %t252, %"compiler/source:Span" %t248)
  store { i64, [4 x i64] } %t254, ptr %l123
  br label %bb45
bb45:
  %t255 = load { i64, [4 x i64] }, ptr %l123
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = load i32, ptr %l2, !range !{i32 0, i32 3}
  %t259 = load i32, ptr %l10, !range !{i32 0, i32 16}
  %t260 = load i64, ptr @G_2ecompiler_2flower_2eInvalid, !tbaa !24
  %t261 = load %"compiler/source:Span", ptr %l6
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2echeck(ptr %v0, ptr %t256, { i64, [4 x i64] } %t255, i32 %t258, i32 %t259, i64 %t260, %"compiler/source:Span" %t261)
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s4)
  br label %bb47
bb47:
  %t268 = load ptr, ptr %l0, !tbaa !29
  store ptr %t268, ptr %l130, !tbaa !29
  %t269 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t269, ptr %l131, !tbaa !23
  %t270 = load i32, ptr %l1, !range !{i32 0, i32 52}
  store i32 %t270, ptr %l132
  %t271 = load i32, ptr %l5, !tbaa !23
  store i32 %t271, ptr %l133, !tbaa !23
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t274 = getelementptr %"compiler/lower:lowering", ptr %t272, i32 0, i32 3
  %t275 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t278 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %v1, ptr %t274, { i64, ptr } %t275)
  store %"compiler/mir:Range" %t278, ptr %l137
  br label %bb48
bb48:
  store { i64, [15 x i64] } zeroinitializer, ptr %t279
  %t280 = getelementptr { i64, [15 x i64] }, ptr %t279, i32 0, i32 0
  store i64 4, ptr %t280
  %t281 = load i32, ptr %l132, !range !{i32 0, i32 52}
  %t282 = insertvalue { i32, i32, %"compiler/mir:Range" } undef, i32 %t281, 0
  %t283 = load i32, ptr %l133, !tbaa !23
  %t284 = insertvalue { i32, i32, %"compiler/mir:Range" } %t282, i32 %t283, 1
  %t285 = load %"compiler/mir:Range", ptr %l137
  %t286 = insertvalue { i32, i32, %"compiler/mir:Range" } %t284, %"compiler/mir:Range" %t285, 2
  %t287 = getelementptr { i64, [15 x i64] }, ptr %t279, i32 0, i32 1
  store { i32, i32, %"compiler/mir:Range" } %t286, ptr %t287
  %t288 = load { i64, [15 x i64] }, ptr %t279
  %t289 = load %"compiler/source:Span", ptr %l6
  %t290 = load ptr, ptr %l130, !tbaa !29
  %t291 = load i32, ptr %l131, !tbaa !23
  %t294 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t290, i32 %t291, { i64, [15 x i64] } %t288, %"compiler/source:Span" %t289)
  store { i64, [4 x i64] } %t294, ptr %l140
  br label %bb49
bb49:
  %t295 = load { i64, [4 x i64] }, ptr %l140
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t298 = load i32, ptr %l2, !range !{i32 0, i32 3}
  %t299 = load i32, ptr %l10, !range !{i32 0, i32 16}
  %t300 = load i64, ptr @G_2ecompiler_2flower_2eOverflow, !tbaa !24
  %t301 = load %"compiler/source:Span", ptr %l6
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2efails(ptr %v0, ptr %t296, { i64, [4 x i64] } %t295, i32 %t298, i32 %t299, i64 %t300, %"compiler/source:Span" %t301)
  br label %bb50
bb50:
  br label %bb71
bb51:
  %t308 = load i1, ptr %l149, !tbaa !21
  br i1 %t308, label %bb52, label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s6
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t310 = load i32, ptr %l1, !range !{i32 0, i32 52}
  %t311 = load i32, ptr %l5, !tbaa !23
  %t312 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t313 = load %"compiler/source:Span", ptr %l6
  %t319 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %v1, ptr %t309, i32 %t310, i32 %t311, { i64, ptr } %t312, %"compiler/source:Span" %t313)
  store { i64, [4 x i64] } %t319, ptr %l155
  br label %bb54
bb53:
  br label %bb70
bb54:
  %t320 = load { i64, [4 x i64] }, ptr %l155
  store { i64, [4 x i64] } %t320, ptr %l18
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t322 = load i32, ptr %l5, !tbaa !23
  %t323 = load { i64, [4 x i64] }, ptr %l18
  %t324 = load { i64, [4 x i64] }, ptr %l18
  %t325 = mul i64 2, 40
  %t326 = call ptr @__olang_scope_alloc_zeroed(ptr %s6, i64 %t325)
  %t327 = insertvalue { i64, ptr } undef, i64 2, 0
  %t328 = insertvalue { i64, ptr } %t327, ptr %t326, 1
  store { i64, ptr } %t328, ptr %l161, !tbaa !27
  %t330 = getelementptr { i64, ptr }, ptr %l161, i32 0, i32 1
  %t331 = load ptr, ptr %t330, !tbaa !27
  %t332 = getelementptr { i64, [4 x i64] }, ptr %t331, i64 0
  store { i64, [4 x i64] } %t323, ptr %t332
  %t334 = getelementptr { i64, ptr }, ptr %l161, i32 0, i32 1
  %t335 = load ptr, ptr %t334, !tbaa !27
  %t336 = getelementptr { i64, [4 x i64] }, ptr %t335, i64 1
  store { i64, [4 x i64] } %t324, ptr %t336
  %t337 = load %"compiler/source:Span", ptr %l6
  %t341 = load { i64, ptr }, ptr %l161, !tbaa !27
  %t343 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s6, ptr %t321, i32 4, i32 %t322, { i64, ptr } %t341, %"compiler/source:Span" %t337)
  store { i64, [4 x i64] } %t343, ptr %l163
  br label %bb55
bb55:
  %t344 = load { i64, [4 x i64] }, ptr %l163
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t346 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t348 = load i32, ptr %l5, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t349
  %t350 = getelementptr { i64, [4 x i64] }, ptr %t349, i32 0, i32 0
  store i64 2, ptr %t350
  %t352 = insertvalue { i32, i64 } undef, i32 %t348, 0
  %t353 = insertvalue { i32, i64 } %t352, i64 0, 1
  %t354 = getelementptr { i64, [4 x i64] }, ptr %t349, i32 0, i32 1
  store { i32, i64 } %t353, ptr %t354
  %t355 = load { i64, [4 x i64] }, ptr %t349
  %t356 = mul i64 2, 40
  %t357 = call ptr @__olang_scope_alloc_zeroed(ptr %s6, i64 %t356)
  %t358 = insertvalue { i64, ptr } undef, i64 2, 0
  %t359 = insertvalue { i64, ptr } %t358, ptr %t357, 1
  store { i64, ptr } %t359, ptr %l170, !tbaa !27
  %t361 = getelementptr { i64, ptr }, ptr %l170, i32 0, i32 1
  %t362 = load ptr, ptr %t361, !tbaa !27
  %t363 = getelementptr { i64, [4 x i64] }, ptr %t362, i64 0
  store { i64, [4 x i64] } %t344, ptr %t363
  %t365 = getelementptr { i64, ptr }, ptr %l170, i32 0, i32 1
  %t366 = load ptr, ptr %t365, !tbaa !27
  %t367 = getelementptr { i64, [4 x i64] }, ptr %t366, i64 1
  store { i64, [4 x i64] } %t355, ptr %t367
  %t368 = load %"compiler/source:Span", ptr %l6
  %t372 = load { i64, ptr }, ptr %l170, !tbaa !27
  %t374 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s6, ptr %t345, i32 13, i32 %t346, { i64, ptr } %t372, %"compiler/source:Span" %t368)
  store { i64, [4 x i64] } %t374, ptr %l172
  br label %bb56
bb56:
  %t375 = load { i64, [4 x i64] }, ptr %l172
  store { i64, [4 x i64] } %t375, ptr %l20
  %t376 = load ptr, ptr %l0, !tbaa !29
  store ptr %t376, ptr %l173, !tbaa !29
  store i32 11, ptr %l174
  %t377 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t377, ptr %l175, !tbaa !23
  %t378 = load { i64, [4 x i64] }, ptr %l20
  store { i64, [4 x i64] } %t378, ptr %l176
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t380 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t381 = load { i64, [4 x i64] }, ptr %l18
  %t382 = load { i64, [4 x i64] }, ptr %l18
  %t383 = mul i64 2, 40
  %t384 = call ptr @__olang_scope_alloc_zeroed(ptr %s6, i64 %t383)
  %t385 = insertvalue { i64, ptr } undef, i64 2, 0
  %t386 = insertvalue { i64, ptr } %t385, ptr %t384, 1
  store { i64, ptr } %t386, ptr %l182, !tbaa !27
  %t388 = getelementptr { i64, ptr }, ptr %l182, i32 0, i32 1
  %t389 = load ptr, ptr %t388, !tbaa !27
  %t390 = getelementptr { i64, [4 x i64] }, ptr %t389, i64 0
  store { i64, [4 x i64] } %t381, ptr %t390
  %t392 = getelementptr { i64, ptr }, ptr %l182, i32 0, i32 1
  %t393 = load ptr, ptr %t392, !tbaa !27
  %t394 = getelementptr { i64, [4 x i64] }, ptr %t393, i64 1
  store { i64, [4 x i64] } %t382, ptr %t394
  %t395 = load %"compiler/source:Span", ptr %l6
  %t399 = load { i64, ptr }, ptr %l182, !tbaa !27
  %t401 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s6, ptr %t379, i32 14, i32 %t380, { i64, ptr } %t399, %"compiler/source:Span" %t395)
  store { i64, [4 x i64] } %t401, ptr %l184
  br label %bb57
bb57:
  %t402 = mul i64 2, 40
  %t403 = call ptr @__olang_scope_alloc_zeroed(ptr %s6, i64 %t402)
  %t404 = insertvalue { i64, ptr } undef, i64 2, 0
  %t405 = insertvalue { i64, ptr } %t404, ptr %t403, 1
  store { i64, ptr } %t405, ptr %l185, !tbaa !27
  %t406 = load { i64, [4 x i64] }, ptr %l176
  %t407 = getelementptr { i64, ptr }, ptr %l185, i32 0, i32 1
  %t408 = load ptr, ptr %t407, !tbaa !27
  %t409 = getelementptr { i64, [4 x i64] }, ptr %t408, i64 0
  store { i64, [4 x i64] } %t406, ptr %t409
  %t410 = load { i64, [4 x i64] }, ptr %l184
  %t411 = getelementptr { i64, ptr }, ptr %l185, i32 0, i32 1
  %t412 = load ptr, ptr %t411, !tbaa !27
  %t413 = getelementptr { i64, [4 x i64] }, ptr %t412, i64 1
  store { i64, [4 x i64] } %t410, ptr %t413
  %t414 = load %"compiler/source:Span", ptr %l6
  %t415 = load ptr, ptr %l173, !tbaa !29
  %t416 = load i32, ptr %l174, !range !{i32 0, i32 52}
  %t417 = load i32, ptr %l175, !tbaa !23
  %t418 = load { i64, ptr }, ptr %l185, !tbaa !27
  %t420 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s6, ptr %t415, i32 %t416, i32 %t417, { i64, ptr } %t418, %"compiler/source:Span" %t414)
  store { i64, [4 x i64] } %t420, ptr %l187
  br label %bb58
bb58:
  %t421 = load { i64, [4 x i64] }, ptr %l187
  store { i64, [4 x i64] } %t421, ptr %l20
  %t422 = load ptr, ptr %l7, !tbaa !29
  %t423 = load i32, ptr %l8, !tbaa !23
  %t426 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t422, i32 %t423)
  store i1 %t426, ptr %l190
  br label %bb59
bb59:
  %t427 = load i1, ptr %l190, !tbaa !21
  br i1 %t427, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s7
  %t428 = load ptr, ptr %l0, !tbaa !29
  store ptr %t428, ptr %l191, !tbaa !29
  store i32 4, ptr %l192
  %t429 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t429, ptr %l193, !tbaa !27
  %t430 = getelementptr { i64, ptr }, ptr %l193, i32 0, i32 1
  %t431 = load ptr, ptr %t430, !tbaa !27
  %t432 = getelementptr ptr, ptr %t431, i64 0
  %t433 = load ptr, ptr %t432, !tbaa !39
  %t435 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v2, ptr %t433)
  store i32 %t435, ptr %l195
  br label %bb62
bb61:
  br label %bb68
bb62:
  %t436 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t436, ptr %l196, !tbaa !27
  %t437 = getelementptr { i64, ptr }, ptr %l196, i32 0, i32 1
  %t438 = load ptr, ptr %t437, !tbaa !27
  %t439 = getelementptr { i64, [4 x i64] }, ptr %t438, i64 0
  %t440 = load { i64, [4 x i64] }, ptr %t439
  %t441 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t441, ptr %l198, !tbaa !27
  %t442 = getelementptr { i64, ptr }, ptr %l198, i32 0, i32 1
  %t443 = load ptr, ptr %t442, !tbaa !27
  %t444 = getelementptr { i64, [4 x i64] }, ptr %t443, i64 0
  %t445 = load { i64, [4 x i64] }, ptr %t444
  %t446 = mul i64 2, 40
  %t447 = call ptr @__olang_scope_alloc_zeroed(ptr %s7, i64 %t446)
  %t448 = insertvalue { i64, ptr } undef, i64 2, 0
  %t449 = insertvalue { i64, ptr } %t448, ptr %t447, 1
  store { i64, ptr } %t449, ptr %l200, !tbaa !27
  %t451 = getelementptr { i64, ptr }, ptr %l200, i32 0, i32 1
  %t452 = load ptr, ptr %t451, !tbaa !27
  %t453 = getelementptr { i64, [4 x i64] }, ptr %t452, i64 0
  store { i64, [4 x i64] } %t440, ptr %t453
  %t455 = getelementptr { i64, ptr }, ptr %l200, i32 0, i32 1
  %t456 = load ptr, ptr %t455, !tbaa !27
  %t457 = getelementptr { i64, [4 x i64] }, ptr %t456, i64 1
  store { i64, [4 x i64] } %t445, ptr %t457
  %t458 = load %"compiler/source:Span", ptr %l6
  %t459 = load ptr, ptr %l191, !tbaa !29
  %t460 = load i32, ptr %l192, !range !{i32 0, i32 52}
  %t461 = load i32, ptr %l195, !tbaa !23
  %t462 = load { i64, ptr }, ptr %l200, !tbaa !27
  %t464 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s7, ptr %t459, i32 %t460, i32 %t461, { i64, ptr } %t462, %"compiler/source:Span" %t458)
  store { i64, [4 x i64] } %t464, ptr %l202
  br label %bb63
bb63:
  %t465 = load { i64, [4 x i64] }, ptr %l202
  %t466 = load ptr, ptr %l0, !tbaa !29
  store ptr %t466, ptr %l203, !tbaa !29
  store i32 13, ptr %l204
  %t467 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t467, ptr %l205, !tbaa !23
  store { i64, [4 x i64] } %t465, ptr %l206
  %t469 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t469, ptr %l207, !tbaa !27
  %t470 = getelementptr { i64, ptr }, ptr %l207, i32 0, i32 1
  %t471 = load ptr, ptr %t470, !tbaa !27
  %t472 = getelementptr ptr, ptr %t471, i64 0
  %t473 = load ptr, ptr %t472, !tbaa !39
  %t475 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v2, ptr %t473)
  store i32 %t475, ptr %l209
  br label %bb64
bb64:
  store { i64, [4 x i64] } zeroinitializer, ptr %t476
  %t477 = getelementptr { i64, [4 x i64] }, ptr %t476, i32 0, i32 0
  store i64 2, ptr %t477
  %t478 = load i32, ptr %l209, !tbaa !23
  %t479 = insertvalue { i32, i64 } undef, i32 %t478, 0
  %t480 = insertvalue { i32, i64 } %t479, i64 0, 1
  %t481 = getelementptr { i64, [4 x i64] }, ptr %t476, i32 0, i32 1
  store { i32, i64 } %t480, ptr %t481
  %t482 = load { i64, [4 x i64] }, ptr %t476
  %t483 = mul i64 2, 40
  %t484 = call ptr @__olang_scope_alloc_zeroed(ptr %s7, i64 %t483)
  %t485 = insertvalue { i64, ptr } undef, i64 2, 0
  %t486 = insertvalue { i64, ptr } %t485, ptr %t484, 1
  store { i64, ptr } %t486, ptr %l211, !tbaa !27
  %t487 = load { i64, [4 x i64] }, ptr %l206
  %t488 = getelementptr { i64, ptr }, ptr %l211, i32 0, i32 1
  %t489 = load ptr, ptr %t488, !tbaa !27
  %t490 = getelementptr { i64, [4 x i64] }, ptr %t489, i64 0
  store { i64, [4 x i64] } %t487, ptr %t490
  %t492 = getelementptr { i64, ptr }, ptr %l211, i32 0, i32 1
  %t493 = load ptr, ptr %t492, !tbaa !27
  %t494 = getelementptr { i64, [4 x i64] }, ptr %t493, i64 1
  store { i64, [4 x i64] } %t482, ptr %t494
  %t495 = load %"compiler/source:Span", ptr %l6
  %t496 = load ptr, ptr %l203, !tbaa !29
  %t497 = load i32, ptr %l204, !range !{i32 0, i32 52}
  %t498 = load i32, ptr %l205, !tbaa !23
  %t499 = load { i64, ptr }, ptr %l211, !tbaa !27
  %t501 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s7, ptr %t496, i32 %t497, i32 %t498, { i64, ptr } %t499, %"compiler/source:Span" %t495)
  store { i64, [4 x i64] } %t501, ptr %l213
  br label %bb65
bb65:
  %t502 = load { i64, [4 x i64] }, ptr %l213
  %t503 = load ptr, ptr %l0, !tbaa !29
  store ptr %t503, ptr %l214, !tbaa !29
  store i32 11, ptr %l215
  %t504 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t504, ptr %l216, !tbaa !23
  %t505 = load { i64, [4 x i64] }, ptr %l20
  store { i64, [4 x i64] } %t505, ptr %l217
  %t506 = load ptr, ptr %l0, !tbaa !29
  %t507 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t509 = mul i64 1, 40
  %t510 = call ptr @__olang_scope_alloc_zeroed(ptr %s7, i64 %t509)
  %t511 = insertvalue { i64, ptr } undef, i64 1, 0
  %t512 = insertvalue { i64, ptr } %t511, ptr %t510, 1
  store { i64, ptr } %t512, ptr %l222, !tbaa !27
  %t514 = getelementptr { i64, ptr }, ptr %l222, i32 0, i32 1
  %t515 = load ptr, ptr %t514, !tbaa !27
  %t516 = getelementptr { i64, [4 x i64] }, ptr %t515, i64 0
  store { i64, [4 x i64] } %t502, ptr %t516
  %t517 = load %"compiler/source:Span", ptr %l6
  %t521 = load { i64, ptr }, ptr %l222, !tbaa !27
  %t523 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s7, ptr %t506, i32 2, i32 %t507, { i64, ptr } %t521, %"compiler/source:Span" %t517)
  store { i64, [4 x i64] } %t523, ptr %l224
  br label %bb66
bb66:
  %t524 = mul i64 2, 40
  %t525 = call ptr @__olang_scope_alloc_zeroed(ptr %s7, i64 %t524)
  %t526 = insertvalue { i64, ptr } undef, i64 2, 0
  %t527 = insertvalue { i64, ptr } %t526, ptr %t525, 1
  store { i64, ptr } %t527, ptr %l225, !tbaa !27
  %t528 = load { i64, [4 x i64] }, ptr %l217
  %t529 = getelementptr { i64, ptr }, ptr %l225, i32 0, i32 1
  %t530 = load ptr, ptr %t529, !tbaa !27
  %t531 = getelementptr { i64, [4 x i64] }, ptr %t530, i64 0
  store { i64, [4 x i64] } %t528, ptr %t531
  %t532 = load { i64, [4 x i64] }, ptr %l224
  %t533 = getelementptr { i64, ptr }, ptr %l225, i32 0, i32 1
  %t534 = load ptr, ptr %t533, !tbaa !27
  %t535 = getelementptr { i64, [4 x i64] }, ptr %t534, i64 1
  store { i64, [4 x i64] } %t532, ptr %t535
  %t536 = load %"compiler/source:Span", ptr %l6
  %t537 = load ptr, ptr %l214, !tbaa !29
  %t538 = load i32, ptr %l215, !range !{i32 0, i32 52}
  %t539 = load i32, ptr %l216, !tbaa !23
  %t540 = load { i64, ptr }, ptr %l225, !tbaa !27
  %t542 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s7, ptr %t537, i32 %t538, i32 %t539, { i64, ptr } %t540, %"compiler/source:Span" %t536)
  store { i64, [4 x i64] } %t542, ptr %l227
  br label %bb67
bb67:
  %t543 = load { i64, [4 x i64] }, ptr %l227
  store { i64, [4 x i64] } %t543, ptr %l20
  call void @__olang_scope_close(ptr %s7)
  br label %bb68
bb68:
  %t544 = load ptr, ptr %l0, !tbaa !29
  %t545 = load { i64, [4 x i64] }, ptr %l20
  %t546 = load i32, ptr %l2, !range !{i32 0, i32 3}
  %t547 = load i32, ptr %l10, !range !{i32 0, i32 16}
  %t548 = load i64, ptr @G_2ecompiler_2flower_2eOverflow, !tbaa !24
  %t549 = load %"compiler/source:Span", ptr %l6
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2echeck(ptr %v0, ptr %t544, { i64, [4 x i64] } %t545, i32 %t546, i32 %t547, i64 %t548, %"compiler/source:Span" %t549)
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s6)
  br label %bb70
bb70:
  br label %bb71
bb71:
  br label %bb77
bb72:
  br i1 true, label %bb73, label %bb74
bb73:
  br label %bb75
bb74:
  br label %bb76
bb75:
  br label %bb77
bb76:
  call void @__olang_check_failed(ptr @olang_loc_13d147f9f542fef2_ebbeb5a175072836)
  unreachable
bb77:
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2epromote(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i32
  %l10 = alloca i32
  %l11 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i1
  %l16 = alloca i1
  %l20 = alloca i1
  %l23 = alloca i64
  %l25 = alloca { i64, [4 x i64] }
  %l31 = alloca { i64, [4 x i64] }
  %l32 = alloca i32
  %l34 = alloca i1
  %l39 = alloca { i64, [4 x i64] }
  %l44 = alloca { i64, [4 x i64] }
  %rv = alloca { i64, [4 x i64] }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l10
  br label %bb1
bb1:
  %t11 = load i32, ptr %l10, !tbaa !23
  store i32 %t11, ptr %l5, !tbaa !23
  %t12 = load ptr, ptr %l4, !tbaa !29
  store ptr %t12, ptr %l11, !tbaa !29
  %t13 = load ptr, ptr %l4, !tbaa !29
  %t14 = load i32, ptr %l2, !tbaa !23
  %t17 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t13, i32 %t14)
  store i32 %t17, ptr %l14
  br label %bb2
bb2:
  %t18 = load ptr, ptr %l11, !tbaa !29
  %t19 = load i32, ptr %l14, !tbaa !23
  %t20 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t18, i32 %t19)
  store i1 %t20, ptr %l15
  br label %bb3
bb3:
  %t21 = load i1, ptr %l15, !tbaa !21
  br i1 %t21, label %bb4, label %bb5
bb4:
  %t22 = load i32, ptr %l5, !tbaa !23
  %t23 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t26 = icmp ne i32 %t22, %t23
  store i1 %t26, ptr %l16, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb6
bb6:
  %t28 = load i1, ptr %l16, !tbaa !21
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i32, ptr %l5, !tbaa !23
  %t33 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2efixedLen(ptr %v0, ptr %t29, i32 %t30)
  store i64 %t33, ptr %l23
  br label %bb9
bb8:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb10
bb9:
  %t34 = load i64, ptr %l23, !tbaa !24
  %t35 = icmp slt i64 %t34, 0
  store i1 %t35, ptr %l20, !tbaa !21
  br label %bb10
bb10:
  %t37 = load i1, ptr %l20, !tbaa !21
  br i1 %t37, label %bb11, label %bb12
bb11:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t40 = load i32, ptr %l2, !tbaa !23
  %t41 = load %"compiler/source:Span", ptr %l3
  %t42 = load i32, ptr %l5, !tbaa !23
  %t48 = call { i32, { i64, [4 x i64] } } @compiler_2flower_2ecompiler_2flower_3alowering_2epromotedInPlace(ptr %v0, ptr %v1, ptr %t38, ptr %t39, i32 %t40, %"compiler/source:Span" %t41, i32 %t42)
  %t49 = extractvalue { i32, { i64, [4 x i64] } } %t48, 1
  %t50 = extractvalue { i32, { i64, [4 x i64] } } %t48, 0
  store i32 %t50, ptr %l32
  %t51 = icmp ne i32 %t50, 0
  br i1 %t51, label %bb14, label %ok.52, !prof !99
ok.52:
  store { i64, [4 x i64] } %t49, ptr %l31
  br label %bb13
bb12:
  br label %bb18
bb13:
  %t53 = load { i64, [4 x i64] }, ptr %l31
  store { i64, [4 x i64] } %t53, ptr %l25
  br label %bb17
bb14:
  %t54 = load i32, ptr %l32, !tbaa !23
  %t55 = ashr i32 %t54, 16
  %t57 = icmp eq i32 %t55, 1
  store i1 %t57, ptr %l34, !tbaa !21
  br label %bb15
bb15:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t60 = load i32, ptr %l2, !tbaa !23
  %t61 = load %"compiler/source:Span", ptr %l3
  %t66 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2epromoteNew(ptr %v0, ptr %v1, ptr %t58, ptr %t59, i32 %t60, %"compiler/source:Span" %t61)
  store { i64, [4 x i64] } %t66, ptr %l39
  br label %bb16
bb16:
  %t67 = load { i64, [4 x i64] }, ptr %l39
  store { i64, [4 x i64] } %t67, ptr %l25
  br label %bb17
bb17:
  %t68 = load { i64, [4 x i64] }, ptr %l25
  store { i64, [4 x i64] } %t68, ptr %rv
  br label %ret
bb18:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t71 = load i32, ptr %l2, !tbaa !23
  %t72 = load %"compiler/source:Span", ptr %l3
  %t77 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2epromoteNew(ptr %v0, ptr %v1, ptr %t69, ptr %t70, i32 %t71, %"compiler/source:Span" %t72)
  store { i64, [4 x i64] } %t77, ptr %l44
  br label %bb19
bb19:
  %t78 = load { i64, [4 x i64] }, ptr %l44
  store { i64, [4 x i64] } %t78, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2epromotedCopy(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca { i64, [1 x i64] }
  %l9 = alloca { i64, [4 x i64] }
  %l16 = alloca ptr
  %l27 = alloca ptr
  %l31 = alloca { i64, [1 x i64] }
  %l35 = alloca { i64, [4 x i64] }
  %l45 = alloca ptr
  %l46 = alloca { i64, [4 x i64] }
  %l48 = alloca i32
  %l50 = alloca i32
  %l51 = alloca ptr
  %l52 = alloca i32
  %l54 = alloca %"compiler/mir:Lvalue"
  %l58 = alloca { i64, [4 x i64] }
  %rv = alloca { i64, [4 x i64] }
  %t72 = alloca { i64, [4 x i64] }, align 8
  %t94 = alloca { i64, [15 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Promote", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t8 = call ptr @compiler_2flower_2ecopyMade(ptr %v1, ptr %v1, ptr %t6)
  store ptr %t8, ptr %l16
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l16, !tbaa !29
  store ptr %t9, ptr %l5, !tbaa !29
  %t10 = load ptr, ptr %l5, !tbaa !29
  %t12 = icmp eq ptr %t10, null
  br i1 %t12, label %bb2, label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_23ead67d8f6e59cb_86ca0369ed971687)
  unreachable
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l5, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/lower:lowering", ptr %t16, i32 0, i32 28
  %t19 = load i32, ptr %t18, !tbaa !23
  store i32 %t19, ptr %l7, !tbaa !23
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/lower:lowering", ptr %t21, i32 0, i32 29
  %t24 = load { i64, [1 x i64] }, ptr %t23
  store { i64, [1 x i64] } %t24, ptr %l8
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/typed:Make", ptr %t14, i32 0, i32 4
  %t30 = load i32, ptr %t29, !tbaa !23
  %t33 = getelementptr %"compiler/lower:lowering", ptr %t26, i32 0, i32 28
  store i32 %t30, ptr %t33, !tbaa !23
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l27, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t38 = getelementptr %"compiler/typed:Promote", ptr %t36, i32 0, i32 1
  %t39 = load i32, ptr %t38, !tbaa !23
  %t42 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ebuilt(ptr %v0, ptr %t35, i32 %t39)
  store { i64, [1 x i64] } %t42, ptr %l31
  br label %bb5
bb5:
  %t43 = load { i64, [1 x i64] }, ptr %l31
  %t44 = load ptr, ptr %l27, !tbaa !29
  %t45 = getelementptr %"compiler/lower:lowering", ptr %t44, i32 0, i32 29
  store { i64, [1 x i64] } %t43, ptr %t45
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load ptr, ptr %l4, !tbaa !29
  %t51 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t46, ptr %t47)
  store { i64, [4 x i64] } %t51, ptr %l35
  br label %bb6
bb6:
  %t52 = load { i64, [4 x i64] }, ptr %l35
  store { i64, [4 x i64] } %t52, ptr %l9
  %t53 = load i32, ptr %l7, !tbaa !23
  %t55 = load { i64, [1 x i64] }, ptr %l8
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/lower:lowering", ptr %t57, i32 0, i32 28
  store i32 %t53, ptr %t61, !tbaa !23
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/lower:lowering", ptr %t62, i32 0, i32 29
  store { i64, [1 x i64] } %t55, ptr %t66
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/lower:lowering", ptr %t67, i32 0, i32 10
  %t70 = load i1, ptr %t69, !tbaa !21
  br i1 %t70, label %bb7, label %bb8
bb7:
  store { i64, [4 x i64] } zeroinitializer, ptr %t72
  %t73 = getelementptr { i64, [4 x i64] }, ptr %t72, i32 0, i32 0
  store i64 0, ptr %t73
  %t74 = load { i64, [4 x i64] }, ptr %t72
  store { i64, [4 x i64] } %t74, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t76 = load ptr, ptr %l0, !tbaa !29
  store ptr %t76, ptr %l45, !tbaa !29
  %t77 = load { i64, [4 x i64] }, ptr %l9
  store { i64, [4 x i64] } %t77, ptr %l46
  %t78 = load ptr, ptr %l4, !tbaa !29
  %t80 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t78)
  store i32 %t80, ptr %l48
  br label %bb10
bb10:
  %t81 = load %"compiler/source:Span", ptr %l3
  %t82 = load ptr, ptr %l45, !tbaa !29
  %t83 = load { i64, [4 x i64] }, ptr %l46
  %t84 = load i32, ptr %l48, !tbaa !23
  %t86 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %t82, { i64, [4 x i64] } %t83, i32 %t84, %"compiler/source:Span" %t81)
  store i32 %t86, ptr %l50
  br label %bb11
bb11:
  %t87 = load i32, ptr %l50, !tbaa !23
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l51, !tbaa !29
  %t89 = load i32, ptr %l2, !tbaa !23
  store i32 %t89, ptr %l52, !tbaa !23
  %t92 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t87)
  store %"compiler/mir:Lvalue" %t92, ptr %l54
  br label %bb12
bb12:
  %t93 = load i32, ptr %l2, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t94
  %t95 = getelementptr { i64, [15 x i64] }, ptr %t94, i32 0, i32 0
  store i64 1, ptr %t95
  %t96 = load %"compiler/mir:Lvalue", ptr %l54
  %t97 = insertvalue { %"compiler/mir:Lvalue", i32 } undef, %"compiler/mir:Lvalue" %t96, 0
  %t99 = insertvalue { %"compiler/mir:Lvalue", i32 } %t97, i32 %t93, 1
  %t100 = getelementptr { i64, [15 x i64] }, ptr %t94, i32 0, i32 1
  store { %"compiler/mir:Lvalue", i32 } %t99, ptr %t100
  %t101 = load { i64, [15 x i64] }, ptr %t94
  %t102 = load %"compiler/source:Span", ptr %l3
  %t103 = load ptr, ptr %l51, !tbaa !29
  %t104 = load i32, ptr %l52, !tbaa !23
  %t107 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t103, i32 %t104, { i64, [15 x i64] } %t101, %"compiler/source:Span" %t102)
  store { i64, [4 x i64] } %t107, ptr %l58
  br label %bb13
bb13:
  %t108 = load { i64, [4 x i64] }, ptr %l58
  store { i64, [4 x i64] } %t108, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietAll(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l13 = alloca { i64, ptr }
  %l19 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  %t28 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietX(ptr %v0, ptr %v1, ptr %a0, ptr %t21)
  store i1 %t28, ptr %l19
  br label %bb5
bb5:
  %t29 = load i1, ptr %l19, !tbaa !21
  %t30 = xor i1 %t29, true
  br i1 %t30, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t33 = load i64, ptr %l3, !tbaa !24
  %t35 = add i64 %t33, 1
  store i64 %t35, ptr %l3, !tbaa !24
  br label %bb1
bb10:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietClauses(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l21 = alloca i1
  %l25 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Try", ptr %a1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb13
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l14, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  store ptr %t24, ptr %l5, !tbaa !29
  %t26 = load ptr, ptr %l5, !tbaa !29
  %t28 = getelementptr %"compiler/typed:Clause", ptr %t26, i32 0, i32 3
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = icmp eq ptr %t29, null
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb8
bb6:
  %t36 = load ptr, ptr %l5, !tbaa !29
  %t38 = getelementptr %"compiler/typed:Clause", ptr %t36, i32 0, i32 4
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  %t42 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietAll(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %t39)
  store i1 %t42, ptr %l25
  br label %bb7
bb7:
  %t43 = load i1, ptr %l25, !tbaa !21
  %t44 = xor i1 %t43, true
  store i1 %t44, ptr %l21, !tbaa !21
  br label %bb8
bb8:
  %t46 = load i1, ptr %l21, !tbaa !21
  br i1 %t46, label %bb9, label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t48 = load i64, ptr %l3, !tbaa !24
  %t50 = add i64 %t48, 1
  store i64 %t50, ptr %l3, !tbaa !24
  br label %bb1
bb13:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietLife(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i64
  %l7 = alloca i32
  %l22 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca i64
  %l38 = alloca i64
  %l43 = alloca i64
  %l49 = alloca i1
  %l50 = alloca i1
  %l53 = alloca i1
  %l57 = alloca i1
  %l60 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Body", ptr %t4, i32 0, i32 11
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lower:lowering", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Body", ptr %t15, i32 0, i32 11
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = icmp eq ptr %t18, null
  br i1 %t20, label %bb4, label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_80847d650e26c632_64a1946959062bee)
  unreachable
bb5:
  br label %bb6
bb6:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/lower:lowering", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Body", ptr %t25, i32 0, i32 11
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/lower:lowering", ptr %t29, i32 0, i32 53
  %t32 = load i32, ptr %t31, !tbaa !23
  %t35 = call ptr @compiler_2flower_2efindBlock(ptr %v0, ptr %v0, ptr %t28, i32 %t32)
  store ptr %t35, ptr %l22
  br label %bb7
bb7:
  %t36 = load ptr, ptr %l22, !tbaa !29
  store ptr %t36, ptr %l2, !tbaa !29
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t39 = icmp eq ptr %t37, null
  br i1 %t39, label %bb8, label %bb9
bb8:
  store i1 false, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/lower:lowering", ptr %t42, i32 0, i32 47
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eClear_3cI64_2c_20Bool_3e(ptr %v0, ptr %t44)
  br label %bb11
bb11:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/lower:lowering", ptr %t46, i32 0, i32 50
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eClear_3cI64_2c_20Bool_3e(ptr %v0, ptr %t48)
  br label %bb12
bb12:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ecoverAdd(ptr %v0, ptr %t50, i32 %t51, i64 0)
  br label %bb13
bb13:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load i32, ptr %l1, !tbaa !23
  %t58 = getelementptr %"compiler/lower:lowering", ptr %t54, i32 0, i32 48
  store i32 %t55, ptr %t58, !tbaa !23
  store i1 true, ptr %l3, !tbaa !21
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = call ptr @compiler_2flower_2ecompiler_2flower_3alowering_2emutGlobals(ptr %v0, ptr %v0, ptr %t59)
  store ptr %t61, ptr %l35
  br label %bb14
bb14:
  %t62 = load ptr, ptr %l35, !tbaa !29
  store ptr %t62, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb15
bb15:
  %t63 = load i64, ptr %l5, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load ptr, ptr %l4, !tbaa !29
  %t66 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t64)
  store i64 %t66, ptr %l38
  br label %bb16
bb16:
  %t67 = load i64, ptr %l36, !tbaa !24
  %t68 = load i64, ptr %l38, !tbaa !24
  %t69 = icmp slt i64 %t67, %t68
  %t71 = xor i1 %t69, true
  br i1 %t71, label %bb17, label %bb18
bb17:
  br label %bb30
bb18:
  br label %bb19
bb19:
  %t73 = load ptr, ptr %l4, !tbaa !29
  %t74 = load i64, ptr %l5, !tbaa !24
  %t77 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t73, i64 %t74)
  store i64 %t77, ptr %l43
  br label %bb20
bb20:
  %t78 = load i64, ptr %l43, !tbaa !24
  %t81 = trunc i64 %t78 to i32
  store i32 %t81, ptr %l7, !tbaa !23
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load i32, ptr %l7, !tbaa !23
  %t88 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eobjHits(ptr %v0, ptr %t84, i32 %t85)
  store i1 %t88, ptr %l49
  br label %bb21
bb21:
  %t89 = load i1, ptr %l49, !tbaa !21
  br i1 %t89, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb25
bb23:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load i32, ptr %l7, !tbaa !23
  %t94 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ewritesCover(ptr %v0, ptr %t90, i32 %t91, i64 0)
  store i1 %t94, ptr %l53
  br label %bb24
bb24:
  %t95 = load i1, ptr %l53, !tbaa !21
  store i1 %t95, ptr %l50, !tbaa !21
  br label %bb25
bb25:
  %t96 = load i1, ptr %l50, !tbaa !21
  br i1 %t96, label %bb26, label %bb27
bb26:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb28
bb27:
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t97 = load i64, ptr %l5, !tbaa !24
  %t99 = add i64 %t97, 1
  store i64 %t99, ptr %l5, !tbaa !24
  br label %bb15
bb30:
  %t101 = load i1, ptr %l3, !tbaa !21
  br i1 %t101, label %bb31, label %bb32
bb31:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load ptr, ptr %l2, !tbaa !29
  %t107 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietBlock(ptr %v0, ptr %v0, ptr %t103, ptr %t104)
  store i1 %t107, ptr %l60
  br label %bb33
bb32:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb34
bb33:
  %t108 = load i1, ptr %l60, !tbaa !21
  store i1 %t108, ptr %l57, !tbaa !21
  br label %bb34
bb34:
  %t109 = load i1, ptr %l57, !tbaa !21
  store i1 %t109, ptr %l3, !tbaa !21
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/lower:lowering", ptr %t110, i32 0, i32 47
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eClear_3cI64_2c_20Bool_3e(ptr %v0, ptr %t112)
  br label %bb35
bb35:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/lower:lowering", ptr %t114, i32 0, i32 50
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eClear_3cI64_2c_20Bool_3e(ptr %v0, ptr %t116)
  br label %bb36
bb36:
  %t118 = load i1, ptr %l3, !tbaa !21
  store i1 %t118, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietStore(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca i1
  %l16 = alloca i1
  %l23 = alloca ptr
  %l25 = alloca i32
  %l26 = alloca i1
  %l27 = alloca i1
  %l29 = alloca i32
  %l32 = alloca i1
  %l33 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca i1
  %l46 = alloca i64
  %l51 = alloca i32
  %l55 = alloca i1
  %l58 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t7 = load ptr, ptr %l12, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l12, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 8}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l13, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l13, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [4 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t17, i32 0, i32 0
  %t19 = load %"compiler/source:Span", ptr %t18
  store %"compiler/source:Span" %t19, ptr %l3
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [4 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t23, i32 0, i32 1
  %t25 = load i32, ptr %t24
  store i32 %t25, ptr %l4, !tbaa !23
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr { i64, [4 x i64] }, ptr %t27, i32 0, i32 1
  %t30 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t29, i32 0, i32 2
  %t31 = load i32, ptr %t30
  store i32 %t31, ptr %l5, !tbaa !23
  %t33 = load ptr, ptr %l2, !tbaa !29
  store ptr %t33, ptr %l23, !tbaa !29
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t34)
  store i32 %t36, ptr %l25
  br label %bb5
bb4:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb16
bb5:
  %t37 = load ptr, ptr %l23, !tbaa !29
  %t38 = load i32, ptr %l25, !tbaa !23
  %t39 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t37, i32 %t38)
  store i1 %t39, ptr %l26
  br label %bb6
bb6:
  %t40 = load i1, ptr %l26, !tbaa !21
  br i1 %t40, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb10
bb8:
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t41)
  store i32 %t43, ptr %l29
  br label %bb9
bb9:
  %t44 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t45 = load i32, ptr %l29, !tbaa !23
  %t47 = icmp eq i32 %t45, %t44
  store i1 %t47, ptr %l27, !tbaa !21
  br label %bb10
bb10:
  %t49 = load i1, ptr %l27, !tbaa !21
  br i1 %t49, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb15
bb12:
  %t50 = load ptr, ptr %l2, !tbaa !29
  store ptr %t50, ptr %l33, !tbaa !29
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t51)
  store i32 %t53, ptr %l35
  br label %bb13
bb13:
  %t54 = load ptr, ptr %l33, !tbaa !29
  %t55 = load i32, ptr %l35, !tbaa !23
  %t56 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t54, i32 %t55)
  store i1 %t56, ptr %l36
  br label %bb14
bb14:
  %t57 = load i1, ptr %l36, !tbaa !21
  store i1 %t57, ptr %l32, !tbaa !21
  br label %bb15
bb15:
  %t58 = load i1, ptr %l32, !tbaa !21
  store i1 %t58, ptr %l16, !tbaa !21
  br label %bb16
bb16:
  %t59 = load i1, ptr %l16, !tbaa !21
  br i1 %t59, label %bb17, label %bb18
bb17:
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t62 = getelementptr { i64, [4 x i64] }, ptr %t60, i32 0, i32 1
  %t63 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t62, i32 0, i32 0
  %t64 = load %"compiler/source:Span", ptr %t63
  store %"compiler/source:Span" %t64, ptr %l6
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr { i64, [4 x i64] }, ptr %t66, i32 0, i32 1
  %t69 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t68, i32 0, i32 1
  %t70 = load i32, ptr %t69
  store i32 %t70, ptr %l7, !tbaa !23
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t74 = getelementptr { i64, [4 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t74, i32 0, i32 2
  %t76 = load i32, ptr %t75
  store i32 %t76, ptr %l8, !tbaa !23
  store i1 true, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/lower:lowering", ptr %t79, i32 0, i32 47
  %t83 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eLen_3cI64_2c_20Bool_3e(ptr %v0, ptr %t81)
  store i64 %t83, ptr %l46
  br label %bb20
bb20:
  %t84 = load i64, ptr %l46, !tbaa !24
  %t85 = icmp eq i64 %t84, 0
  br i1 %t85, label %bb21, label %bb22
bb21:
  store i1 false, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load ptr, ptr %l1, !tbaa !29
  %t92 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2eobjectOf(ptr %v0, ptr %v1, ptr %t88, ptr %t89)
  store i32 %t92, ptr %l51
  br label %bb24
bb24:
  %t93 = load i32, ptr %l51, !tbaa !23
  store i32 %t93, ptr %l9, !tbaa !23
  %t94 = load i32, ptr %l9, !tbaa !23
  %t95 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t98 = icmp ne i32 %t94, %t95
  br i1 %t98, label %bb25, label %bb26
bb25:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load i32, ptr %l9, !tbaa !23
  %t104 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eobjHits(ptr %v0, ptr %t100, i32 %t101)
  store i1 %t104, ptr %l58
  br label %bb27
bb26:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb28
bb27:
  %t105 = load i1, ptr %l58, !tbaa !21
  %t106 = xor i1 %t105, true
  store i1 %t106, ptr %l55, !tbaa !21
  br label %bb28
bb28:
  %t108 = load i1, ptr %l55, !tbaa !21
  store i1 %t108, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietX(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l16 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i1
  %l39 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca i1
  %l50 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i1
  %l59 = alloca i1
  %l60 = alloca ptr
  %l61 = alloca i1
  %l69 = alloca i1
  %l70 = alloca i1
  %l74 = alloca i1
  %l75 = alloca ptr
  %l76 = alloca i1
  %l83 = alloca i1
  %l84 = alloca ptr
  %l85 = alloca i1
  %l93 = alloca i1
  %l94 = alloca i1
  %l99 = alloca i1
  %l100 = alloca i1
  %l105 = alloca i1
  %l106 = alloca ptr
  %l107 = alloca i1
  %l116 = alloca i1
  %l117 = alloca i1
  %l121 = alloca i1
  %l122 = alloca i1
  %l127 = alloca i1
  %l128 = alloca ptr
  %l129 = alloca i1
  %l138 = alloca i1
  %l142 = alloca i1
  %l143 = alloca ptr
  %l144 = alloca i1
  %l152 = alloca i1
  %l153 = alloca i1
  %l156 = alloca i1
  %l157 = alloca i1
  %l160 = alloca i1
  %l161 = alloca ptr
  %l162 = alloca i1
  %l169 = alloca i1
  %l170 = alloca ptr
  %l171 = alloca i1
  %l179 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t7 = load ptr, ptr %l17, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l17, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l18, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l18, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  br label %bb12
bb7:
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t16 = load ptr, ptr %l21, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb8, label %bb9
bb8:
  %t19 = load ptr, ptr %l21, !tbaa !29
  %t20 = load i64, ptr %t19, !range !{i64 0, i64 18}
  %t22 = icmp eq i64 %t20, 1
  store i1 %t22, ptr %l22, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l22, !tbaa !21
  br i1 %t23, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb130
bb13:
  %t24 = load ptr, ptr %l1, !tbaa !29
  store ptr %t24, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t25 = load ptr, ptr %l25, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb14, label %bb15
bb14:
  %t28 = load ptr, ptr %l25, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 18}
  %t31 = icmp eq i64 %t29, 2
  store i1 %t31, ptr %l26, !tbaa !21
  br label %bb15
bb15:
  %t32 = load i1, ptr %l26, !tbaa !21
  br i1 %t32, label %bb16, label %bb17
bb16:
  %t33 = load ptr, ptr %l1, !tbaa !29
  %t35 = getelementptr { i64, [5 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t35, i32 0, i32 2
  %t37 = load ptr, ptr %t36
  store ptr %t37, ptr %l2, !tbaa !29
  br label %bb22
bb17:
  %t39 = load ptr, ptr %l1, !tbaa !29
  store ptr %t39, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t40 = load ptr, ptr %l31, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %bb18, label %bb19
bb18:
  %t43 = load ptr, ptr %l31, !tbaa !29
  %t44 = load i64, ptr %t43, !range !{i64 0, i64 18}
  %t46 = icmp eq i64 %t44, 3
  store i1 %t46, ptr %l32, !tbaa !21
  br label %bb19
bb19:
  %t47 = load i1, ptr %l32, !tbaa !21
  br i1 %t47, label %bb20, label %bb21
bb20:
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr { i64, [5 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t50, i32 0, i32 2
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l2, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l2, !tbaa !29
  %t58 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietPlace(ptr %v0, ptr %v1, ptr %t54, ptr %t55)
  store i1 %t58, ptr %l39
  br label %bb23
bb23:
  %t59 = load i1, ptr %l39, !tbaa !21
  store i1 %t59, ptr %l16, !tbaa !21
  br label %bb130
bb24:
  %t60 = load ptr, ptr %l1, !tbaa !29
  store ptr %t60, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t61 = load ptr, ptr %l40, !tbaa !29
  %t62 = icmp ne ptr %t61, null
  br i1 %t62, label %bb25, label %bb26
bb25:
  %t64 = load ptr, ptr %l40, !tbaa !29
  %t65 = load i64, ptr %t64, !range !{i64 0, i64 18}
  %t67 = icmp eq i64 %t65, 5
  store i1 %t67, ptr %l41, !tbaa !21
  br label %bb26
bb26:
  %t68 = load i1, ptr %l41, !tbaa !21
  br i1 %t68, label %bb27, label %bb28
bb27:
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t71 = getelementptr { i64, [5 x i64] }, ptr %t69, i32 0, i32 1
  %t72 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t71, i32 0, i32 2
  %t73 = load ptr, ptr %t72
  store ptr %t73, ptr %l3, !tbaa !29
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load ptr, ptr %l3, !tbaa !29
  %t78 = getelementptr %"compiler/typed:Promote", ptr %t76, i32 0, i32 0
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t83 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietX(ptr %v0, ptr %v1, ptr %t75, ptr %t79)
  store i1 %t83, ptr %l50
  br label %bb30
bb30:
  %t84 = load i1, ptr %l50, !tbaa !21
  store i1 %t84, ptr %l16, !tbaa !21
  br label %bb130
bb31:
  %t85 = load ptr, ptr %l1, !tbaa !29
  store ptr %t85, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t86 = load ptr, ptr %l51, !tbaa !29
  %t87 = icmp ne ptr %t86, null
  br i1 %t87, label %bb32, label %bb33
bb32:
  %t89 = load ptr, ptr %l51, !tbaa !29
  %t90 = load i64, ptr %t89, !range !{i64 0, i64 18}
  %t92 = icmp eq i64 %t90, 6
  store i1 %t92, ptr %l52, !tbaa !21
  br label %bb33
bb33:
  %t93 = load i1, ptr %l52, !tbaa !21
  br i1 %t93, label %bb34, label %bb35
bb34:
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t96 = getelementptr { i64, [5 x i64] }, ptr %t94, i32 0, i32 1
  %t97 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t96, i32 0, i32 2
  %t98 = load ptr, ptr %t97
  store ptr %t98, ptr %l4, !tbaa !29
  br label %bb36
bb35:
  br label %bb38
bb36:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load ptr, ptr %l4, !tbaa !29
  %t104 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietCall(ptr %v0, ptr %v1, ptr %t100, ptr %t101)
  store i1 %t104, ptr %l59
  br label %bb37
bb37:
  %t105 = load i1, ptr %l59, !tbaa !21
  store i1 %t105, ptr %l16, !tbaa !21
  br label %bb130
bb38:
  %t106 = load ptr, ptr %l1, !tbaa !29
  store ptr %t106, ptr %l60, !tbaa !29
  store i1 false, ptr %l61, !tbaa !21
  %t107 = load ptr, ptr %l60, !tbaa !29
  %t108 = icmp ne ptr %t107, null
  br i1 %t108, label %bb39, label %bb40
bb39:
  %t110 = load ptr, ptr %l60, !tbaa !29
  %t111 = load i64, ptr %t110, !range !{i64 0, i64 18}
  %t113 = icmp eq i64 %t111, 7
  store i1 %t113, ptr %l61, !tbaa !21
  br label %bb40
bb40:
  %t114 = load i1, ptr %l61, !tbaa !21
  br i1 %t114, label %bb41, label %bb42
bb41:
  %t115 = load ptr, ptr %l1, !tbaa !29
  %t117 = getelementptr { i64, [5 x i64] }, ptr %t115, i32 0, i32 1
  %t118 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t117, i32 0, i32 2
  %t119 = load ptr, ptr %t118
  store ptr %t119, ptr %l5, !tbaa !29
  br label %bb43
bb42:
  br label %bb49
bb43:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load ptr, ptr %l5, !tbaa !29
  %t124 = getelementptr %"compiler/typed:Make", ptr %t122, i32 0, i32 2
  %t125 = load { i64, ptr }, ptr %t124, !tbaa !27
  %t128 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietAll(ptr %v0, ptr %v1, ptr %t121, { i64, ptr } %t125)
  store i1 %t128, ptr %l69
  br label %bb44
bb44:
  %t129 = load i1, ptr %l69, !tbaa !21
  br i1 %t129, label %bb45, label %bb46
bb45:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t131 = load ptr, ptr %l5, !tbaa !29
  %t133 = getelementptr %"compiler/typed:Make", ptr %t131, i32 0, i32 3
  %t134 = load ptr, ptr %t133, !tbaa !29
  %t137 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietX(ptr %v0, ptr %v1, ptr %t130, ptr %t134)
  store i1 %t137, ptr %l74
  br label %bb47
bb46:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb48
bb47:
  %t138 = load i1, ptr %l74, !tbaa !21
  store i1 %t138, ptr %l70, !tbaa !21
  br label %bb48
bb48:
  %t139 = load i1, ptr %l70, !tbaa !21
  store i1 %t139, ptr %l16, !tbaa !21
  br label %bb130
bb49:
  %t140 = load ptr, ptr %l1, !tbaa !29
  store ptr %t140, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t141 = load ptr, ptr %l75, !tbaa !29
  %t142 = icmp ne ptr %t141, null
  br i1 %t142, label %bb50, label %bb51
bb50:
  %t144 = load ptr, ptr %l75, !tbaa !29
  %t145 = load i64, ptr %t144, !range !{i64 0, i64 18}
  %t147 = icmp eq i64 %t145, 9
  store i1 %t147, ptr %l76, !tbaa !21
  br label %bb51
bb51:
  %t148 = load i1, ptr %l76, !tbaa !21
  br i1 %t148, label %bb52, label %bb53
bb52:
  %t149 = load ptr, ptr %l1, !tbaa !29
  %t151 = getelementptr { i64, [5 x i64] }, ptr %t149, i32 0, i32 1
  %t152 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t151, i32 0, i32 4
  %t153 = load { i64, ptr }, ptr %t152
  store { i64, ptr } %t153, ptr %l6, !tbaa !27
  br label %bb54
bb53:
  br label %bb56
bb54:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t159 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietAll(ptr %v0, ptr %v1, ptr %t155, { i64, ptr } %t156)
  store i1 %t159, ptr %l83
  br label %bb55
bb55:
  %t160 = load i1, ptr %l83, !tbaa !21
  store i1 %t160, ptr %l16, !tbaa !21
  br label %bb130
bb56:
  %t161 = load ptr, ptr %l1, !tbaa !29
  store ptr %t161, ptr %l84, !tbaa !29
  store i1 false, ptr %l85, !tbaa !21
  %t162 = load ptr, ptr %l84, !tbaa !29
  %t163 = icmp ne ptr %t162, null
  br i1 %t163, label %bb57, label %bb58
bb57:
  %t165 = load ptr, ptr %l84, !tbaa !29
  %t166 = load i64, ptr %t165, !range !{i64 0, i64 18}
  %t168 = icmp eq i64 %t166, 10
  store i1 %t168, ptr %l85, !tbaa !21
  br label %bb58
bb58:
  %t169 = load i1, ptr %l85, !tbaa !21
  br i1 %t169, label %bb59, label %bb60
bb59:
  %t170 = load ptr, ptr %l1, !tbaa !29
  %t172 = getelementptr { i64, [5 x i64] }, ptr %t170, i32 0, i32 1
  %t173 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t172, i32 0, i32 2
  %t174 = load ptr, ptr %t173
  store ptr %t174, ptr %l7, !tbaa !29
  br label %bb61
bb60:
  br label %bb71
bb61:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load ptr, ptr %l7, !tbaa !29
  %t179 = getelementptr %"compiler/typed:Slice", ptr %t177, i32 0, i32 0
  %t180 = load ptr, ptr %t179, !tbaa !29
  %t183 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietPlace(ptr %v0, ptr %v1, ptr %t176, ptr %t180)
  store i1 %t183, ptr %l93
  br label %bb62
bb62:
  %t184 = load i1, ptr %l93, !tbaa !21
  br i1 %t184, label %bb63, label %bb64
bb63:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load ptr, ptr %l7, !tbaa !29
  %t188 = getelementptr %"compiler/typed:Slice", ptr %t186, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !29
  %t193 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietX(ptr %v0, ptr %v1, ptr %t185, ptr %t189)
  store i1 %t193, ptr %l99
  br label %bb65
bb64:
  store i1 false, ptr %l94, !tbaa !21
  br label %bb66
bb65:
  %t194 = load i1, ptr %l99, !tbaa !21
  store i1 %t194, ptr %l94, !tbaa !21
  br label %bb66
bb66:
  %t195 = load i1, ptr %l94, !tbaa !21
  br i1 %t195, label %bb67, label %bb68
bb67:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load ptr, ptr %l7, !tbaa !29
  %t199 = getelementptr %"compiler/typed:Slice", ptr %t197, i32 0, i32 2
  %t200 = load ptr, ptr %t199, !tbaa !29
  %t204 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietX(ptr %v0, ptr %v1, ptr %t196, ptr %t200)
  store i1 %t204, ptr %l105
  br label %bb69
bb68:
  store i1 false, ptr %l100, !tbaa !21
  br label %bb70
bb69:
  %t205 = load i1, ptr %l105, !tbaa !21
  store i1 %t205, ptr %l100, !tbaa !21
  br label %bb70
bb70:
  %t206 = load i1, ptr %l100, !tbaa !21
  store i1 %t206, ptr %l16, !tbaa !21
  br label %bb130
bb71:
  %t207 = load ptr, ptr %l1, !tbaa !29
  store ptr %t207, ptr %l106, !tbaa !29
  store i1 false, ptr %l107, !tbaa !21
  %t208 = load ptr, ptr %l106, !tbaa !29
  %t209 = icmp ne ptr %t208, null
  br i1 %t209, label %bb72, label %bb73
bb72:
  %t211 = load ptr, ptr %l106, !tbaa !29
  %t212 = load i64, ptr %t211, !range !{i64 0, i64 18}
  %t214 = icmp eq i64 %t212, 11
  store i1 %t214, ptr %l107, !tbaa !21
  br label %bb73
bb73:
  %t215 = load i1, ptr %l107, !tbaa !21
  br i1 %t215, label %bb74, label %bb75
bb74:
  %t216 = load ptr, ptr %l1, !tbaa !29
  %t218 = getelementptr { i64, [5 x i64] }, ptr %t216, i32 0, i32 1
  %t219 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t218, i32 0, i32 2
  %t220 = load ptr, ptr %t219
  store ptr %t220, ptr %l8, !tbaa !29
  br label %bb76
bb75:
  br label %bb86
bb76:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t223 = load ptr, ptr %l8, !tbaa !29
  %t225 = getelementptr %"compiler/typed:Cond", ptr %t223, i32 0, i32 0
  %t226 = load ptr, ptr %t225, !tbaa !29
  %t230 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietX(ptr %v0, ptr %v1, ptr %t222, ptr %t226)
  store i1 %t230, ptr %l116
  br label %bb77
bb77:
  %t231 = load i1, ptr %l116, !tbaa !21
  br i1 %t231, label %bb78, label %bb79
bb78:
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = load ptr, ptr %l8, !tbaa !29
  %t235 = getelementptr %"compiler/typed:Cond", ptr %t233, i32 0, i32 1
  %t236 = load ptr, ptr %t235, !tbaa !29
  %t239 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietX(ptr %v0, ptr %v1, ptr %t232, ptr %t236)
  store i1 %t239, ptr %l121
  br label %bb80
bb79:
  store i1 false, ptr %l117, !tbaa !21
  br label %bb81
bb80:
  %t240 = load i1, ptr %l121, !tbaa !21
  store i1 %t240, ptr %l117, !tbaa !21
  br label %bb81
bb81:
  %t241 = load i1, ptr %l117, !tbaa !21
  br i1 %t241, label %bb82, label %bb83
bb82:
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load ptr, ptr %l8, !tbaa !29
  %t245 = getelementptr %"compiler/typed:Cond", ptr %t243, i32 0, i32 2
  %t246 = load ptr, ptr %t245, !tbaa !29
  %t250 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietX(ptr %v0, ptr %v1, ptr %t242, ptr %t246)
  store i1 %t250, ptr %l127
  br label %bb84
bb83:
  store i1 false, ptr %l122, !tbaa !21
  br label %bb85
bb84:
  %t251 = load i1, ptr %l127, !tbaa !21
  store i1 %t251, ptr %l122, !tbaa !21
  br label %bb85
bb85:
  %t252 = load i1, ptr %l122, !tbaa !21
  store i1 %t252, ptr %l16, !tbaa !21
  br label %bb130
bb86:
  %t253 = load ptr, ptr %l1, !tbaa !29
  store ptr %t253, ptr %l128, !tbaa !29
  store i1 false, ptr %l129, !tbaa !21
  %t254 = load ptr, ptr %l128, !tbaa !29
  %t255 = icmp ne ptr %t254, null
  br i1 %t255, label %bb87, label %bb88
bb87:
  %t257 = load ptr, ptr %l128, !tbaa !29
  %t258 = load i64, ptr %t257, !range !{i64 0, i64 18}
  %t260 = icmp eq i64 %t258, 12
  store i1 %t260, ptr %l129, !tbaa !21
  br label %bb88
bb88:
  %t261 = load i1, ptr %l129, !tbaa !21
  br i1 %t261, label %bb89, label %bb90
bb89:
  %t262 = load ptr, ptr %l1, !tbaa !29
  %t264 = getelementptr { i64, [5 x i64] }, ptr %t262, i32 0, i32 1
  %t265 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t264, i32 0, i32 2
  %t266 = load ptr, ptr %t265
  store ptr %t266, ptr %l9, !tbaa !29
  br label %bb91
bb90:
  br label %bb96
bb91:
  %t268 = load ptr, ptr %l9, !tbaa !29
  %t270 = getelementptr %"compiler/typed:Seq", ptr %t268, i32 0, i32 0
  %t271 = load { i64, ptr }, ptr %t270, !tbaa !27
  %t273 = extractvalue { i64, ptr } %t271, 0
  %t275 = icmp eq i64 %t273, 0
  br i1 %t275, label %bb92, label %bb93
bb92:
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t278 = load ptr, ptr %l9, !tbaa !29
  %t280 = getelementptr %"compiler/typed:Seq", ptr %t278, i32 0, i32 1
  %t281 = load ptr, ptr %t280, !tbaa !29
  %t284 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietX(ptr %v0, ptr %v1, ptr %t277, ptr %t281)
  store i1 %t284, ptr %l142
  br label %bb94
bb93:
  store i1 false, ptr %l138, !tbaa !21
  br label %bb95
bb94:
  %t285 = load i1, ptr %l142, !tbaa !21
  store i1 %t285, ptr %l138, !tbaa !21
  br label %bb95
bb95:
  %t286 = load i1, ptr %l138, !tbaa !21
  store i1 %t286, ptr %l16, !tbaa !21
  br label %bb130
bb96:
  %t287 = load ptr, ptr %l1, !tbaa !29
  store ptr %t287, ptr %l143, !tbaa !29
  store i1 false, ptr %l144, !tbaa !21
  %t288 = load ptr, ptr %l143, !tbaa !29
  %t289 = icmp ne ptr %t288, null
  br i1 %t289, label %bb97, label %bb98
bb97:
  %t291 = load ptr, ptr %l143, !tbaa !29
  %t292 = load i64, ptr %t291, !range !{i64 0, i64 18}
  %t294 = icmp eq i64 %t292, 14
  store i1 %t294, ptr %l144, !tbaa !21
  br label %bb98
bb98:
  %t295 = load i1, ptr %l144, !tbaa !21
  br i1 %t295, label %bb99, label %bb100
bb99:
  %t296 = load ptr, ptr %l1, !tbaa !29
  %t298 = getelementptr { i64, [5 x i64] }, ptr %t296, i32 0, i32 1
  %t299 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t298, i32 0, i32 2
  %t300 = load ptr, ptr %t299
  store ptr %t300, ptr %l10, !tbaa !29
  br label %bb101
bb100:
  br label %bb111
bb101:
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t303 = load ptr, ptr %l10, !tbaa !29
  %t305 = getelementptr %"compiler/typed:Try", ptr %t303, i32 0, i32 0
  %t306 = load ptr, ptr %t305, !tbaa !29
  %t309 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietX(ptr %v0, ptr %v1, ptr %t302, ptr %t306)
  store i1 %t309, ptr %l152
  br label %bb102
bb102:
  %t310 = load i1, ptr %l152, !tbaa !21
  br i1 %t310, label %bb103, label %bb104
bb103:
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t312 = load ptr, ptr %l10, !tbaa !29
  %t315 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eselfTry(ptr %v0, ptr %v1, ptr %t311, ptr %t312)
  store i1 %t315, ptr %l156
  br label %bb105
bb104:
  store i1 false, ptr %l153, !tbaa !21
  br label %bb110
bb105:
  %t316 = load i1, ptr %l156, !tbaa !21
  br i1 %t316, label %bb106, label %bb107
bb106:
  store i1 true, ptr %l157, !tbaa !21
  br label %bb109
bb107:
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t318 = load ptr, ptr %l10, !tbaa !29
  %t321 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietClauses(ptr %v0, ptr %v1, ptr %t317, ptr %t318)
  store i1 %t321, ptr %l160
  br label %bb108
bb108:
  %t322 = load i1, ptr %l160, !tbaa !21
  store i1 %t322, ptr %l157, !tbaa !21
  br label %bb109
bb109:
  %t323 = load i1, ptr %l157, !tbaa !21
  store i1 %t323, ptr %l153, !tbaa !21
  br label %bb110
bb110:
  %t324 = load i1, ptr %l153, !tbaa !21
  store i1 %t324, ptr %l16, !tbaa !21
  br label %bb130
bb111:
  %t325 = load ptr, ptr %l1, !tbaa !29
  store ptr %t325, ptr %l161, !tbaa !29
  store i1 false, ptr %l162, !tbaa !21
  %t326 = load ptr, ptr %l161, !tbaa !29
  %t327 = icmp ne ptr %t326, null
  br i1 %t327, label %bb112, label %bb113
bb112:
  %t329 = load ptr, ptr %l161, !tbaa !29
  %t330 = load i64, ptr %t329, !range !{i64 0, i64 18}
  %t332 = icmp eq i64 %t330, 16
  store i1 %t332, ptr %l162, !tbaa !21
  br label %bb113
bb113:
  %t333 = load i1, ptr %l162, !tbaa !21
  br i1 %t333, label %bb114, label %bb115
bb114:
  %t334 = load ptr, ptr %l1, !tbaa !29
  %t336 = getelementptr { i64, [5 x i64] }, ptr %t334, i32 0, i32 1
  %t337 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t336, i32 0, i32 2
  %t338 = load ptr, ptr %t337
  store ptr %t338, ptr %l11, !tbaa !29
  br label %bb116
bb115:
  br label %bb118
bb116:
  %t340 = load ptr, ptr %l0, !tbaa !29
  %t341 = load ptr, ptr %l11, !tbaa !29
  %t344 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietPieces(ptr %v0, ptr %v1, ptr %t340, ptr %t341)
  store i1 %t344, ptr %l169
  br label %bb117
bb117:
  %t345 = load i1, ptr %l169, !tbaa !21
  store i1 %t345, ptr %l16, !tbaa !21
  br label %bb130
bb118:
  %t346 = load ptr, ptr %l1, !tbaa !29
  store ptr %t346, ptr %l170, !tbaa !29
  store i1 false, ptr %l171, !tbaa !21
  %t347 = load ptr, ptr %l170, !tbaa !29
  %t348 = icmp ne ptr %t347, null
  br i1 %t348, label %bb119, label %bb120
bb119:
  %t350 = load ptr, ptr %l170, !tbaa !29
  %t351 = load i64, ptr %t350, !range !{i64 0, i64 18}
  %t353 = icmp eq i64 %t351, 17
  store i1 %t353, ptr %l171, !tbaa !21
  br label %bb120
bb120:
  %t354 = load i1, ptr %l171, !tbaa !21
  br i1 %t354, label %bb121, label %bb122
bb121:
  %t355 = load ptr, ptr %l1, !tbaa !29
  %t357 = getelementptr { i64, [5 x i64] }, ptr %t355, i32 0, i32 1
  %t358 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t357, i32 0, i32 2
  %t359 = load ptr, ptr %t358
  store ptr %t359, ptr %l12, !tbaa !29
  br label %bb123
bb122:
  br label %bb125
bb123:
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t362 = load ptr, ptr %l12, !tbaa !29
  %t366 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietX(ptr %v0, ptr %v1, ptr %t361, ptr %t362)
  store i1 %t366, ptr %l179
  br label %bb124
bb124:
  %t367 = load i1, ptr %l179, !tbaa !21
  store i1 %t367, ptr %l16, !tbaa !21
  br label %bb130
bb125:
  br i1 true, label %bb126, label %bb127
bb126:
  br label %bb128
bb127:
  br label %bb129
bb128:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb130
bb129:
  call void @__olang_check_failed(ptr @olang_loc_3bbf6907cdc90559_48ef26e69e7376e5)
  unreachable
bb130:
  %t368 = load i1, ptr %l16, !tbaa !21
  store i1 %t368, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ereadPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l4, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l4, !tbaa !29
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t19 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ereadPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t16, ptr %t17, ptr %t18, ptr %t19)
  br label %bb6
bb6:
  br label %bb33
bb7:
  %t24 = load ptr, ptr %l1, !tbaa !29
  store ptr %t24, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t25 = load ptr, ptr %l18, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb8, label %bb9
bb8:
  %t28 = load ptr, ptr %l18, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 8}
  %t31 = icmp eq i64 %t29, 5
  store i1 %t31, ptr %l19, !tbaa !21
  br label %bb9
bb9:
  %t32 = load i1, ptr %l19, !tbaa !21
  br i1 %t32, label %bb10, label %bb11
bb10:
  %t33 = load ptr, ptr %l1, !tbaa !29
  %t35 = getelementptr { i64, [4 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t35, i32 0, i32 2
  %t37 = load ptr, ptr %t36
  store ptr %t37, ptr %l5, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load ptr, ptr %l5, !tbaa !29
  %t42 = getelementptr %"compiler/typed:Payload", ptr %t40, i32 0, i32 0
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t45 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ereadPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t39, ptr %t43, ptr %t44, ptr %t45)
  br label %bb13
bb13:
  br label %bb33
bb14:
  %t50 = load ptr, ptr %l1, !tbaa !29
  store ptr %t50, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t51 = load ptr, ptr %l29, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb15, label %bb16
bb15:
  %t54 = load ptr, ptr %l29, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 8}
  %t57 = icmp eq i64 %t55, 4
  store i1 %t57, ptr %l30, !tbaa !21
  br label %bb16
bb16:
  %t58 = load i1, ptr %l30, !tbaa !21
  br i1 %t58, label %bb17, label %bb18
bb17:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr { i64, [4 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t61, i32 0, i32 2
  %t63 = load ptr, ptr %t62
  store ptr %t63, ptr %l6, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l6, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Elem", ptr %t66, i32 0, i32 0
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t70 = load ptr, ptr %l2, !tbaa !29
  %t71 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ereadPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t65, ptr %t69, ptr %t70, ptr %t71)
  br label %bb20
bb20:
  br label %bb33
bb21:
  %t76 = load ptr, ptr %l1, !tbaa !29
  store ptr %t76, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t77 = load ptr, ptr %l40, !tbaa !29
  %t78 = icmp ne ptr %t77, null
  br i1 %t78, label %bb22, label %bb23
bb22:
  %t80 = load ptr, ptr %l40, !tbaa !29
  %t81 = load i64, ptr %t80, !range !{i64 0, i64 8}
  %t83 = icmp eq i64 %t81, 6
  store i1 %t83, ptr %l41, !tbaa !21
  br label %bb23
bb23:
  %t84 = load i1, ptr %l41, !tbaa !21
  br i1 %t84, label %bb24, label %bb25
bb24:
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr { i64, [4 x i64] }, ptr %t85, i32 0, i32 1
  %t88 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t87, i32 0, i32 2
  %t89 = load ptr, ptr %t88
  store ptr %t89, ptr %l7, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l7, !tbaa !29
  %t93 = load ptr, ptr %l2, !tbaa !29
  %t94 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ereadHere(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t91, ptr %t92, ptr %t93, ptr %t94)
  br label %bb27
bb27:
  br label %bb33
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_15f99fcbd43babda_53e78f535034c6)
  unreachable
bb33:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2flower_2ecompiler_2flower_3alowering_2eregionSite(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca i1
  %l60 = alloca i1
  %l66 = alloca i1
  %l68 = alloca { i64, ptr }
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 24
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i64 -1, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l1, !tbaa !29
  store ptr %t9, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t10 = load ptr, ptr %l13, !tbaa !29
  %t11 = icmp ne ptr %t10, null
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t13 = load ptr, ptr %l13, !tbaa !29
  %t14 = load i64, ptr %t13, !range !{i64 0, i64 18}
  %t16 = icmp eq i64 %t14, 5
  store i1 %t16, ptr %l14, !tbaa !21
  br label %bb5
bb5:
  %t17 = load i1, ptr %l14, !tbaa !21
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr { i64, [5 x i64] }, ptr %t18, i32 0, i32 1
  %t21 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t20, i32 0, i32 2
  %t22 = load ptr, ptr %t21
  store ptr %t22, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Promote", ptr %t24, i32 0, i32 1
  %t27 = load i32, ptr %t26, !tbaa !23
  %t29 = sext i32 %t27 to i64
  store i64 %t29, ptr %l12, !tbaa !24
  br label %bb38
bb9:
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t32 = load ptr, ptr %l22, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb10, label %bb11
bb10:
  %t35 = load ptr, ptr %l22, !tbaa !29
  %t36 = load i64, ptr %t35, !range !{i64 0, i64 18}
  %t38 = icmp eq i64 %t36, 7
  store i1 %t38, ptr %l23, !tbaa !21
  br label %bb11
bb11:
  %t39 = load i1, ptr %l23, !tbaa !21
  br i1 %t39, label %bb12, label %bb13
bb12:
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr { i64, [5 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t42, i32 0, i32 2
  %t44 = load ptr, ptr %t43
  store ptr %t44, ptr %l3, !tbaa !29
  br label %bb14
bb13:
  br label %bb15
bb14:
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t48 = getelementptr %"compiler/typed:Make", ptr %t46, i32 0, i32 4
  %t49 = load i32, ptr %t48, !tbaa !23
  %t51 = sext i32 %t49 to i64
  store i64 %t51, ptr %l12, !tbaa !24
  br label %bb38
bb15:
  %t53 = load ptr, ptr %l1, !tbaa !29
  store ptr %t53, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t54 = load ptr, ptr %l31, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb16, label %bb17
bb16:
  %t57 = load ptr, ptr %l31, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 18}
  %t60 = icmp eq i64 %t58, 16
  store i1 %t60, ptr %l32, !tbaa !21
  br label %bb17
bb17:
  %t61 = load i1, ptr %l32, !tbaa !21
  br i1 %t61, label %bb18, label %bb19
bb18:
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr { i64, [5 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t64, i32 0, i32 2
  %t66 = load ptr, ptr %t65
  store ptr %t66, ptr %l4, !tbaa !29
  br label %bb20
bb19:
  br label %bb21
bb20:
  %t68 = load ptr, ptr %l4, !tbaa !29
  %t70 = getelementptr %"compiler/typed:Text", ptr %t68, i32 0, i32 1
  %t71 = load i32, ptr %t70, !tbaa !23
  %t73 = sext i32 %t71 to i64
  store i64 %t73, ptr %l12, !tbaa !24
  br label %bb38
bb21:
  %t75 = load ptr, ptr %l1, !tbaa !29
  store ptr %t75, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t76 = load ptr, ptr %l40, !tbaa !29
  %t77 = icmp ne ptr %t76, null
  br i1 %t77, label %bb22, label %bb23
bb22:
  %t79 = load ptr, ptr %l40, !tbaa !29
  %t80 = load i64, ptr %t79, !range !{i64 0, i64 18}
  %t82 = icmp eq i64 %t80, 8
  store i1 %t82, ptr %l41, !tbaa !21
  br label %bb23
bb23:
  %t83 = load i1, ptr %l41, !tbaa !21
  br i1 %t83, label %bb24, label %bb25
bb24:
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t86 = getelementptr { i64, [5 x i64] }, ptr %t84, i32 0, i32 1
  %t87 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t86, i32 0, i32 2
  %t88 = load ptr, ptr %t87
  store ptr %t88, ptr %l5, !tbaa !29
  br label %bb26
bb25:
  br label %bb27
bb26:
  %t90 = load ptr, ptr %l5, !tbaa !29
  %t92 = getelementptr %"compiler/typed:Collect", ptr %t90, i32 0, i32 2
  %t93 = load i32, ptr %t92, !tbaa !23
  %t95 = sext i32 %t93 to i64
  store i64 %t95, ptr %l12, !tbaa !24
  br label %bb38
bb27:
  %t97 = load ptr, ptr %l1, !tbaa !29
  store ptr %t97, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t98 = load ptr, ptr %l49, !tbaa !29
  %t99 = icmp ne ptr %t98, null
  br i1 %t99, label %bb28, label %bb29
bb28:
  %t101 = load ptr, ptr %l49, !tbaa !29
  %t102 = load i64, ptr %t101, !range !{i64 0, i64 18}
  %t104 = icmp eq i64 %t102, 6
  store i1 %t104, ptr %l50, !tbaa !21
  br label %bb29
bb29:
  %t105 = load i1, ptr %l50, !tbaa !21
  br i1 %t105, label %bb30, label %bb31
bb30:
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr { i64, [5 x i64] }, ptr %t106, i32 0, i32 1
  %t109 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t108, i32 0, i32 2
  %t110 = load ptr, ptr %t109
  store ptr %t110, ptr %l6, !tbaa !29
  br label %bb32
bb31:
  br label %bb33
bb32:
  %t112 = load ptr, ptr %l6, !tbaa !29
  %t114 = getelementptr %"compiler/typed:Call", ptr %t112, i32 0, i32 2
  %t115 = load i32, ptr %t114, !tbaa !23
  %t117 = sext i32 %t115 to i64
  store i64 %t117, ptr %l12, !tbaa !24
  br label %bb38
bb33:
  br i1 true, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  store i64 -1, ptr %l12, !tbaa !24
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_5f06e436ba25f30_8078c3a4dcac4c4)
  unreachable
bb38:
  %t119 = load i64, ptr %l12, !tbaa !24
  store i64 %t119, ptr %l7, !tbaa !24
  %t120 = load i64, ptr %l7, !tbaa !24
  %t122 = icmp slt i64 %t120, 0
  br i1 %t122, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb41
bb40:
  %t124 = load i64, ptr %l7, !tbaa !24
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/lower:lowering", ptr %t125, i32 0, i32 30
  %t128 = getelementptr %"compiler/typed:Plan", ptr %t127, i32 0, i32 5
  %t129 = load { i64, ptr }, ptr %t128, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t129, 0
  %t134 = icmp sge i64 %t124, %t131
  store i1 %t134, ptr %l60, !tbaa !21
  br label %bb41
bb41:
  %t136 = load i1, ptr %l60, !tbaa !21
  br i1 %t136, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb44
bb43:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/lower:lowering", ptr %t137, i32 0, i32 30
  %t140 = getelementptr %"compiler/typed:Plan", ptr %t139, i32 0, i32 5
  %t141 = load { i64, ptr }, ptr %t140, !tbaa !27
  store { i64, ptr } %t141, ptr %l68, !tbaa !27
  %t142 = load i64, ptr %l7, !tbaa !24
  %t144 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = getelementptr i64, ptr %t145, i64 %t142
  %t147 = load i64, ptr %t146, !tbaa !34
  %t149 = icmp eq i64 %t147, 0
  store i1 %t149, ptr %l66, !tbaa !21
  br label %bb44
bb44:
  %t151 = load i1, ptr %l66, !tbaa !21
  br i1 %t151, label %bb45, label %bb46
bb45:
  store i64 -1, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  %t153 = load i64, ptr %l7, !tbaa !24
  store i64 %t153, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2erenderAny(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1, { i64, [4 x i64] } %a2, i32 %a3, i1 %a4, %"compiler/source:Span" %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [1 x i64] }
  %l3 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca { i64, [4 x i64] }
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca { i64, [4 x i64] }
  %l13 = alloca { i64, [4 x i64] }
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca { i64, [4 x i64] }
  %l17 = alloca i32
  %l18 = alloca { i64, [7 x i64] }
  %l19 = alloca i32
  %l27 = alloca i32
  %l30 = alloca i32
  %l31 = alloca ptr
  %l34 = alloca i32
  %l35 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i32
  %l38 = alloca i32
  %l40 = alloca %"compiler/mir:Lvalue"
  %l44 = alloca { i64, ptr }
  %l46 = alloca { i64, [4 x i64] }
  %l49 = alloca i32
  %l52 = alloca i32
  %l68 = alloca { i64, [4 x i64] }
  %l69 = alloca ptr
  %l70 = alloca i32
  %l71 = alloca i32
  %l72 = alloca { i64, [4 x i64] }
  %l74 = alloca { i64, [4 x i64] }
  %l75 = alloca { i64, ptr }
  %l77 = alloca { i64, [4 x i64] }
  %l80 = alloca i32
  %l83 = alloca i32
  %l98 = alloca ptr
  %l99 = alloca i32
  %l100 = alloca i32
  %l101 = alloca { i64, [4 x i64] }
  %l103 = alloca { i64, [4 x i64] }
  %l104 = alloca { i64, ptr }
  %l106 = alloca { i64, [4 x i64] }
  %l107 = alloca ptr
  %l108 = alloca i32
  %l109 = alloca ptr
  %l112 = alloca i32
  %l113 = alloca i32
  %l114 = alloca i32
  %l116 = alloca %"compiler/mir:Lvalue"
  %l117 = alloca { i64, [4 x i64] }
  %l119 = alloca i64
  %l124 = alloca i32
  %l126 = alloca ptr
  %l127 = alloca { i64, [7 x i64] }
  %l129 = alloca ptr
  %l131 = alloca %"compiler/mir:Lvalue"
  %l134 = alloca { i64, ptr }
  %l135 = alloca %"compiler/mir:Range"
  %l139 = alloca { i64, ptr }
  %l140 = alloca %"compiler/mir:Range"
  %l145 = alloca %"compiler/mir:Call"
  %l146 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %t37 = alloca { i64, [4 x i64] }, align 8
  %t44 = alloca { i64, [4 x i64] }, align 8
  %t87 = alloca { i64, [8 x i64] }, align 8
  %t163 = alloca { i64, [8 x i64] }, align 8
  %t237 = alloca { i64, [4 x i64] }, align 8
  %t246 = alloca { i64, [7 x i64] }, align 8
  %t273 = alloca { i64, [4 x i64] }, align 8
  %t329 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, [1 x i64] } %a1, ptr %l1
  store i32 %a3, ptr %l3
  store %"compiler/source:Span" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l6, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l3, !tbaa !23
  %t9 = load %"compiler/source:Span", ptr %l5
  %t14 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %t6, { i64, [4 x i64] } %a2, i32 %t8, %"compiler/source:Span" %t9)
  store i32 %t14, ptr %l27
  br label %bb1
bb1:
  %t15 = load i32, ptr %l27, !tbaa !23
  store i32 %t15, ptr %l7, !tbaa !23
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/lower:lowering", ptr %t16, i32 0, i32 3
  %t20 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t18)
  store i32 %t20, ptr %l30
  br label %bb2
bb2:
  %t21 = load i32, ptr %l30, !tbaa !23
  store i32 %t21, ptr %l8, !tbaa !23
  %t22 = load ptr, ptr %l6, !tbaa !29
  store ptr %t22, ptr %l31, !tbaa !29
  %t23 = load ptr, ptr %l6, !tbaa !29
  %t24 = load i32, ptr %l3, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l34
  br label %bb3
bb3:
  %t28 = load ptr, ptr %l31, !tbaa !29
  %t29 = load i32, ptr %l34, !tbaa !23
  %t30 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t28, i32 %t29)
  store i1 %t30, ptr %l35
  br label %bb4
bb4:
  %t31 = load i1, ptr %l35, !tbaa !21
  br i1 %t31, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l36, !tbaa !29
  store i32 14, ptr %l37
  %t33 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t33, ptr %l38, !tbaa !23
  %t34 = load i32, ptr %l7, !tbaa !23
  %t36 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t34)
  store %"compiler/mir:Lvalue" %t36, ptr %l40
  br label %bb7
bb6:
  br label %bb16
bb7:
  store { i64, [4 x i64] } zeroinitializer, ptr %t37
  %t38 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 0
  store i64 1, ptr %t38
  %t39 = load %"compiler/mir:Lvalue", ptr %l40
  %t40 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t39, 0
  %t41 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t40, ptr %t41
  %t42 = load { i64, [4 x i64] }, ptr %t37
  %t43 = load i32, ptr %l3, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t44
  %t45 = getelementptr { i64, [4 x i64] }, ptr %t44, i32 0, i32 0
  store i64 2, ptr %t45
  %t47 = insertvalue { i32, i64 } undef, i32 %t43, 0
  %t48 = insertvalue { i32, i64 } %t47, i64 0, 1
  %t49 = getelementptr { i64, [4 x i64] }, ptr %t44, i32 0, i32 1
  store { i32, i64 } %t48, ptr %t49
  %t50 = load { i64, [4 x i64] }, ptr %t44
  %t51 = mul i64 2, 40
  %t52 = call ptr @__olang_scope_alloc_zeroed(ptr %s1, i64 %t51)
  %t53 = insertvalue { i64, ptr } undef, i64 2, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  store { i64, ptr } %t54, ptr %l44, !tbaa !27
  %t56 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr { i64, [4 x i64] }, ptr %t57, i64 0
  store { i64, [4 x i64] } %t42, ptr %t58
  %t60 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr { i64, [4 x i64] }, ptr %t61, i64 1
  store { i64, [4 x i64] } %t50, ptr %t62
  %t63 = load %"compiler/source:Span", ptr %l5
  %t64 = load ptr, ptr %l36, !tbaa !29
  %t65 = load i32, ptr %l37, !range !{i32 0, i32 52}
  %t66 = load i32, ptr %l38, !tbaa !23
  %t67 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t69 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s1, ptr %t64, i32 %t65, i32 %t66, { i64, ptr } %t67, %"compiler/source:Span" %t63)
  store { i64, [4 x i64] } %t69, ptr %l46
  br label %bb8
bb8:
  %t70 = load { i64, [4 x i64] }, ptr %l46
  store { i64, [4 x i64] } %t70, ptr %l9
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/lower:lowering", ptr %t71, i32 0, i32 3
  %t75 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t73)
  store i32 %t75, ptr %l49
  br label %bb9
bb9:
  %t76 = load i32, ptr %l49, !tbaa !23
  store i32 %t76, ptr %l10, !tbaa !23
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/lower:lowering", ptr %t77, i32 0, i32 3
  %t81 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t79)
  store i32 %t81, ptr %l52
  br label %bb10
bb10:
  %t82 = load i32, ptr %l52, !tbaa !23
  store i32 %t82, ptr %l11, !tbaa !23
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load { i64, [4 x i64] }, ptr %l9
  %t85 = load i32, ptr %l10, !tbaa !23
  %t86 = load i32, ptr %l11, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t87
  %t88 = getelementptr { i64, [8 x i64] }, ptr %t87, i32 0, i32 0
  store i64 2, ptr %t88
  %t90 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t84, 0
  %t92 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t90, i32 %t85, 1
  %t94 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t92, i32 %t86, 2
  %t95 = getelementptr { i64, [8 x i64] }, ptr %t87, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t94, ptr %t95
  %t96 = load { i64, [8 x i64] }, ptr %t87
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t83, { i64, [8 x i64] } %t96)
  br label %bb11
bb11:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load i32, ptr %l11, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t99, i32 %t100)
  br label %bb12
bb12:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load { i64, [1 x i64] }, ptr %l1
  %t105 = load %"compiler/source:Span", ptr %l5
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eword(ptr %v0, ptr %s1, ptr %t103, { i64, [1 x i64] } %t104, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d7, i32 0, i32 1) }, %"compiler/source:Span" %t105)
  br label %bb13
bb13:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load i32, ptr %l8, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t109, i32 %t110)
  br label %bb14
bb14:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load i32, ptr %l10, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t113, i32 %t114)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s1)
  br label %bb16
bb16:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2edepth(ptr %v0, ptr %t117)
  store { i64, [4 x i64] } %t119, ptr %l68
  br label %bb17
bb17:
  %t120 = load { i64, [4 x i64] }, ptr %l68
  store { i64, [4 x i64] } %t120, ptr %l12
  %t121 = load ptr, ptr %l0, !tbaa !29
  store ptr %t121, ptr %l69, !tbaa !29
  store i32 18, ptr %l70
  %t122 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t122, ptr %l71, !tbaa !23
  %t123 = load { i64, [4 x i64] }, ptr %l12
  store { i64, [4 x i64] } %t123, ptr %l72
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t124, i64 8)
  store { i64, [4 x i64] } %t126, ptr %l74
  br label %bb18
bb18:
  %t127 = mul i64 2, 40
  %t128 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t127)
  %t129 = insertvalue { i64, ptr } undef, i64 2, 0
  %t130 = insertvalue { i64, ptr } %t129, ptr %t128, 1
  store { i64, ptr } %t130, ptr %l75, !tbaa !27
  %t131 = load { i64, [4 x i64] }, ptr %l72
  %t132 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr { i64, [4 x i64] }, ptr %t133, i64 0
  store { i64, [4 x i64] } %t131, ptr %t134
  %t135 = load { i64, [4 x i64] }, ptr %l74
  %t136 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !27
  %t138 = getelementptr { i64, [4 x i64] }, ptr %t137, i64 1
  store { i64, [4 x i64] } %t135, ptr %t138
  %t139 = load %"compiler/source:Span", ptr %l5
  %t140 = load ptr, ptr %l69, !tbaa !29
  %t141 = load i32, ptr %l70, !range !{i32 0, i32 52}
  %t142 = load i32, ptr %l71, !tbaa !23
  %t143 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t145 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %t140, i32 %t141, i32 %t142, { i64, ptr } %t143, %"compiler/source:Span" %t139)
  store { i64, [4 x i64] } %t145, ptr %l77
  br label %bb19
bb19:
  %t146 = load { i64, [4 x i64] }, ptr %l77
  store { i64, [4 x i64] } %t146, ptr %l13
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/lower:lowering", ptr %t147, i32 0, i32 3
  %t151 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t149)
  store i32 %t151, ptr %l80
  br label %bb20
bb20:
  %t152 = load i32, ptr %l80, !tbaa !23
  store i32 %t152, ptr %l14, !tbaa !23
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t155 = getelementptr %"compiler/lower:lowering", ptr %t153, i32 0, i32 3
  %t157 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t155)
  store i32 %t157, ptr %l83
  br label %bb21
bb21:
  %t158 = load i32, ptr %l83, !tbaa !23
  store i32 %t158, ptr %l15, !tbaa !23
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load { i64, [4 x i64] }, ptr %l13
  %t161 = load i32, ptr %l14, !tbaa !23
  %t162 = load i32, ptr %l15, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t163
  %t164 = getelementptr { i64, [8 x i64] }, ptr %t163, i32 0, i32 0
  store i64 2, ptr %t164
  %t166 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t160, 0
  %t168 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t166, i32 %t161, 1
  %t170 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t168, i32 %t162, 2
  %t171 = getelementptr { i64, [8 x i64] }, ptr %t163, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t170, ptr %t171
  %t172 = load { i64, [8 x i64] }, ptr %t163
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t159, { i64, [8 x i64] } %t172)
  br label %bb22
bb22:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = load i32, ptr %l14, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t175, i32 %t176)
  br label %bb23
bb23:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load { i64, [1 x i64] }, ptr %l1
  %t181 = load %"compiler/source:Span", ptr %l5
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eword(ptr %v0, ptr %s0, ptr %t179, { i64, [1 x i64] } %t180, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d8, i32 0, i32 1) }, %"compiler/source:Span" %t181)
  br label %bb24
bb24:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load i32, ptr %l8, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t185, i32 %t186)
  br label %bb25
bb25:
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load i32, ptr %l15, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t189, i32 %t190)
  br label %bb26
bb26:
  %t193 = load ptr, ptr %l0, !tbaa !29
  store ptr %t193, ptr %l98, !tbaa !29
  store i32 3, ptr %l99
  %t194 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t194, ptr %l100, !tbaa !23
  %t195 = load { i64, [4 x i64] }, ptr %l12
  store { i64, [4 x i64] } %t195, ptr %l101
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t196, i64 1)
  store { i64, [4 x i64] } %t198, ptr %l103
  br label %bb27
bb27:
  %t199 = mul i64 2, 40
  %t200 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t199)
  %t201 = insertvalue { i64, ptr } undef, i64 2, 0
  %t202 = insertvalue { i64, ptr } %t201, ptr %t200, 1
  store { i64, ptr } %t202, ptr %l104, !tbaa !27
  %t203 = load { i64, [4 x i64] }, ptr %l101
  %t204 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t205 = load ptr, ptr %t204, !tbaa !27
  %t206 = getelementptr { i64, [4 x i64] }, ptr %t205, i64 0
  store { i64, [4 x i64] } %t203, ptr %t206
  %t207 = load { i64, [4 x i64] }, ptr %l103
  %t208 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr { i64, [4 x i64] }, ptr %t209, i64 1
  store { i64, [4 x i64] } %t207, ptr %t210
  %t211 = load %"compiler/source:Span", ptr %l5
  %t212 = load ptr, ptr %l98, !tbaa !29
  %t213 = load i32, ptr %l99, !range !{i32 0, i32 52}
  %t214 = load i32, ptr %l100, !tbaa !23
  %t215 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t217 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %t212, i32 %t213, i32 %t214, { i64, ptr } %t215, %"compiler/source:Span" %t211)
  store { i64, [4 x i64] } %t217, ptr %l106
  br label %bb28
bb28:
  %t218 = load { i64, [4 x i64] }, ptr %l106
  store { i64, [4 x i64] } %t218, ptr %l16
  %t219 = load ptr, ptr %l6, !tbaa !29
  store ptr %t219, ptr %l107, !tbaa !29
  store i32 0, ptr %l108
  %t220 = load ptr, ptr %l6, !tbaa !29
  store ptr %t220, ptr %l109, !tbaa !29
  %t221 = load ptr, ptr %l6, !tbaa !29
  %t222 = load i32, ptr %l3, !tbaa !23
  %t225 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t221, i32 %t222)
  store i32 %t225, ptr %l112
  br label %bb29
bb29:
  %t226 = load ptr, ptr %l109, !tbaa !29
  %t227 = load i32, ptr %l112, !tbaa !23
  %t228 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t226, i32 %t227)
  store i32 %t228, ptr %l113
  br label %bb30
bb30:
  %t229 = load ptr, ptr %l107, !tbaa !29
  %t230 = load i32, ptr %l108, !range !{i32 0, i32 8}
  %t231 = load i32, ptr %l113, !tbaa !23
  %t232 = call i32 @compiler_2fmir_2eHelperType(ptr %v0, ptr %t229, i32 %t230, i32 %t231)
  store i32 %t232, ptr %l114
  br label %bb31
bb31:
  %t233 = load i32, ptr %l114, !tbaa !23
  store i32 %t233, ptr %l17, !tbaa !23
  %t234 = load i32, ptr %l7, !tbaa !23
  %t236 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t234)
  store %"compiler/mir:Lvalue" %t236, ptr %l116
  br label %bb32
bb32:
  store { i64, [4 x i64] } zeroinitializer, ptr %t237
  %t238 = getelementptr { i64, [4 x i64] }, ptr %t237, i32 0, i32 0
  store i64 1, ptr %t238
  %t239 = load %"compiler/mir:Lvalue", ptr %l116
  %t240 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t239, 0
  %t241 = getelementptr { i64, [4 x i64] }, ptr %t237, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t240, ptr %t241
  %t242 = load { i64, [4 x i64] }, ptr %t237
  store { i64, [4 x i64] } %t242, ptr %l117
  br i1 %a4, label %bb33, label %bb34
bb33:
  store i64 -1, ptr %l119, !tbaa !24
  br label %bb35
bb34:
  store i64 -2, ptr %l119, !tbaa !24
  br label %bb35
bb35:
  %t245 = load i32, ptr %l17, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t246
  %t247 = getelementptr { i64, [7 x i64] }, ptr %t246, i32 0, i32 0
  store i64 3, ptr %t247
  %t248 = load { i64, [4 x i64] }, ptr %l117
  %t249 = insertvalue { { i64, [4 x i64] }, i64, i32 } undef, { i64, [4 x i64] } %t248, 0
  %t250 = load i64, ptr %l119, !tbaa !24
  %t251 = insertvalue { { i64, [4 x i64] }, i64, i32 } %t249, i64 %t250, 1
  %t253 = insertvalue { { i64, [4 x i64] }, i64, i32 } %t251, i32 %t245, 2
  %t254 = getelementptr { i64, [7 x i64] }, ptr %t246, i32 0, i32 1
  store { { i64, [4 x i64] }, i64, i32 } %t253, ptr %t254
  %t255 = load { i64, [7 x i64] }, ptr %t246
  store { i64, [7 x i64] } %t255, ptr %l18
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = getelementptr %"compiler/lower:lowering", ptr %t257, i32 0, i32 3
  %t261 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t259)
  store i32 %t261, ptr %l124
  br label %bb36
bb36:
  %t262 = load i32, ptr %l124, !tbaa !23
  store i32 %t262, ptr %l19, !tbaa !23
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t265 = getelementptr %"compiler/lower:lowering", ptr %t263, i32 0, i32 3
  store ptr %t265, ptr %l126, !tbaa !29
  %t266 = load { i64, [7 x i64] }, ptr %l18
  store { i64, [7 x i64] } %t266, ptr %l127
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"compiler/lower:lowering", ptr %t267, i32 0, i32 3
  store ptr %t269, ptr %l129, !tbaa !29
  %t270 = load i32, ptr %l7, !tbaa !23
  %t272 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t270)
  store %"compiler/mir:Lvalue" %t272, ptr %l131
  br label %bb37
bb37:
  store { i64, [4 x i64] } zeroinitializer, ptr %t273
  %t274 = getelementptr { i64, [4 x i64] }, ptr %t273, i32 0, i32 0
  store i64 1, ptr %t274
  %t275 = load %"compiler/mir:Lvalue", ptr %l131
  %t276 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t275, 0
  %t277 = getelementptr { i64, [4 x i64] }, ptr %t273, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t276, ptr %t277
  %t278 = load { i64, [4 x i64] }, ptr %t273
  %t279 = load { i64, [4 x i64] }, ptr %l16
  %t280 = mul i64 2, 40
  %t281 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t280)
  %t282 = insertvalue { i64, ptr } undef, i64 2, 0
  %t283 = insertvalue { i64, ptr } %t282, ptr %t281, 1
  store { i64, ptr } %t283, ptr %l134, !tbaa !27
  %t285 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t286 = load ptr, ptr %t285, !tbaa !27
  %t287 = getelementptr { i64, [4 x i64] }, ptr %t286, i64 0
  store { i64, [4 x i64] } %t278, ptr %t287
  %t289 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t290 = load ptr, ptr %t289, !tbaa !27
  %t291 = getelementptr { i64, [4 x i64] }, ptr %t290, i64 1
  store { i64, [4 x i64] } %t279, ptr %t291
  %t292 = load ptr, ptr %l129, !tbaa !29
  %t293 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t294 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %s0, ptr %t292, { i64, ptr } %t293)
  store %"compiler/mir:Range" %t294, ptr %l135
  br label %bb38
bb38:
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t297 = getelementptr %"compiler/lower:lowering", ptr %t295, i32 0, i32 3
  %t298 = load { i64, [1 x i64] }, ptr %l1
  %t299 = mul i64 1, 16
  %t300 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t299)
  %t301 = insertvalue { i64, ptr } undef, i64 1, 0
  %t302 = insertvalue { i64, ptr } %t301, ptr %t300, 1
  store { i64, ptr } %t302, ptr %l139, !tbaa !27
  %t304 = getelementptr { i64, ptr }, ptr %l139, i32 0, i32 1
  %t305 = load ptr, ptr %t304, !tbaa !27
  %t306 = getelementptr { i64, [1 x i64] }, ptr %t305, i64 0
  store { i64, [1 x i64] } %t298, ptr %t306
  %t308 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t309 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eScopeRefs(ptr %v0, ptr %s0, ptr %t297, { i64, ptr } %t308)
  store %"compiler/mir:Range" %t309, ptr %l140
  br label %bb39
bb39:
  %t310 = load %"compiler/mir:Lvalue", ptr @G_2ecompiler_2fmir_2eNoPlace
  %t311 = load i32, ptr %l19, !tbaa !23
  %t312 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t313 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t314 = load { i64, [7 x i64] }, ptr %l127
  %t315 = load %"compiler/mir:Range", ptr %l135
  %t316 = load %"compiler/mir:Range", ptr %l140
  %t321 = call %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %s0, { i64, [7 x i64] } %t314, %"compiler/mir:Range" %t315, %"compiler/mir:Range" %t316, %"compiler/mir:Lvalue" %t310, i1 false, i32 %t311, i32 %t312, i32 %t313)
  store %"compiler/mir:Call" %t321, ptr %l145
  br label %bb40
bb40:
  %t322 = load ptr, ptr %l126, !tbaa !29
  %t323 = load %"compiler/mir:Call", ptr %l145
  %t324 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v0, ptr %t322, %"compiler/mir:Call" %t323)
  store i32 %t324, ptr %l146
  br label %bb41
bb41:
  %t325 = load i32, ptr %l146, !tbaa !23
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t327 = load %"compiler/source:Span", ptr %l5
  store { i64, [8 x i64] } zeroinitializer, ptr %t329
  %t330 = getelementptr { i64, [8 x i64] }, ptr %t329, i32 0, i32 0
  store i64 4, ptr %t330
  %t332 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t327, 0
  %t334 = insertvalue { %"compiler/source:Span", i32 } %t332, i32 %t325, 1
  %t335 = getelementptr { i64, [8 x i64] }, ptr %t329, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t334, ptr %t335
  %t336 = load { i64, [8 x i64] }, ptr %t329
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t326, { i64, [8 x i64] } %t336)
  br label %bb42
bb42:
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t340 = load i32, ptr %l19, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t339, i32 %t340)
  br label %bb43
bb43:
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t344 = load i32, ptr %l8, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t343, i32 %t344)
  br label %bb44
bb44:
  %t347 = load ptr, ptr %l0, !tbaa !29
  %t348 = load i32, ptr %l8, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t347, i32 %t348)
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2erenderPayload(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:pl" %a1, i64 %a2, i32 %a3, { i64, [1 x i64] } %a4, %"compiler/source:Span" %a5) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca { i64, [1 x i64] }
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca { i64, ptr }
  %l30 = alloca i64
  %l33 = alloca i64
  %l56 = alloca ptr
  %l57 = alloca ptr
  %l58 = alloca ptr
  %l59 = alloca %"compiler/lower:pl"
  %l61 = alloca %"compiler/lower:pl"
  %l64 = alloca %"compiler/lower:pl"
  %l67 = alloca %"compiler/lower:pl"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %t93 = alloca { i64, [1 x i64] }, align 8
  %t104 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, [1 x i64] } %a4, ptr %l4
  store %"compiler/source:Span" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l13, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/lower:lowering", ptr %t2, i32 0, i32 2
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t5, i32 %a3)
  store i32 %t9, ptr %l17
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l13, !tbaa !29
  %t11 = load i32, ptr %l17, !tbaa !23
  %t12 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2eitems(ptr %v0, ptr %s0, ptr %t10, i32 %t11)
  store { i64, ptr } %t12, ptr %l18
  br label %bb2
bb2:
  %t13 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t13, ptr %l6, !tbaa !27
  %t14 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  %t18 = icmp eq i64 %t16, 0
  br i1 %t18, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  br label %bb5
bb5:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load { i64, [1 x i64] }, ptr %l4
  %t22 = load %"compiler/source:Span", ptr %l5
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eword(ptr %v0, ptr %s0, ptr %t20, { i64, [1 x i64] } %t21, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, %"compiler/source:Span" %t22)
  br label %bb6
bb6:
  store i64 0, ptr %l7, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  store i64 %t28, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t30 = load i64, ptr %l8, !tbaa !24
  %t31 = load i64, ptr %l7, !tbaa !24
  %t34 = icmp sgt i64 %t30, %t31
  br i1 %t34, label %bb7, label %bb8
bb7:
  %t36 = load i64, ptr %l9, !tbaa !24
  %t38 = icmp sgt i64 %t36, 0
  br i1 %t38, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb12
bb9:
  %t40 = load i64, ptr %l8, !tbaa !24
  %t41 = load i64, ptr %l7, !tbaa !24
  %t44 = sub i64 %t40, %t41
  %t45 = load i64, ptr %l9, !tbaa !24
  %t48 = add i64 %t44, %t45
  %t50 = sub i64 %t48, 1
  %t51 = load i64, ptr %l9, !tbaa !24
  %t54 = sdiv i64 %t50, %t51
  store i64 %t54, ptr %l33, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb11
bb11:
  %t56 = load i64, ptr %l33, !tbaa !24
  store i64 %t56, ptr %l30, !tbaa !24
  br label %bb12
bb12:
  %t57 = load i64, ptr %l30, !tbaa !24
  store i64 %t57, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t58 = load i64, ptr %l11, !tbaa !24
  %t59 = load i64, ptr %l10, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb26
bb15:
  br label %bb16
bb16:
  %t66 = load i64, ptr %l7, !tbaa !24
  %t67 = load i64, ptr %l11, !tbaa !24
  %t68 = load i64, ptr %l9, !tbaa !24
  %t71 = mul i64 %t67, %t68
  %t74 = add i64 %t66, %t71
  store i64 %t74, ptr %l12, !tbaa !24
  %t76 = load i64, ptr %l12, !tbaa !24
  %t78 = icmp sgt i64 %t76, 0
  br i1 %t78, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s4
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load { i64, [1 x i64] }, ptr %l4
  %t82 = load %"compiler/source:Span", ptr %l5
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eword(ptr %v0, ptr %s4, ptr %t80, { i64, [1 x i64] } %t81, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d10, i32 0, i32 1) }, %"compiler/source:Span" %t82)
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s4)
  br label %bb20
bb20:
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l56, !tbaa !29
  %t87 = load ptr, ptr %l0, !tbaa !29
  store ptr %t87, ptr %l57, !tbaa !29
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l58, !tbaa !29
  store %"compiler/lower:pl" %a1, ptr %l59
  %t91 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s3, ptr %l59)
  store %"compiler/lower:pl" %t91, ptr %l61
  br label %bb21
bb21:
  store { i64, [1 x i64] } zeroinitializer, ptr %t93
  %t94 = getelementptr { i64, [1 x i64] }, ptr %t93, i32 0, i32 0
  store i64 4, ptr %t94
  %t96 = insertvalue { i64 } undef, i64 %a2, 0
  %t97 = getelementptr { i64, [1 x i64] }, ptr %t93, i32 0, i32 1
  store { i64 } %t96, ptr %t97
  %t98 = load { i64, [1 x i64] }, ptr %t93
  %t99 = load ptr, ptr %l58, !tbaa !29
  %t100 = load %"compiler/lower:pl", ptr %l61
  %t102 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %s3, ptr %s3, ptr %t99, %"compiler/lower:pl" %t100, { i64, [1 x i64] } %t98)
  store %"compiler/lower:pl" %t102, ptr %l64
  br label %bb22
bb22:
  %t103 = load i64, ptr %l12, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t104
  %t105 = getelementptr { i64, [1 x i64] }, ptr %t104, i32 0, i32 0
  store i64 0, ptr %t105
  %t107 = insertvalue { i64 } undef, i64 %t103, 0
  %t108 = getelementptr { i64, [1 x i64] }, ptr %t104, i32 0, i32 1
  store { i64 } %t107, ptr %t108
  %t109 = load { i64, [1 x i64] }, ptr %t104
  %t110 = load ptr, ptr %l57, !tbaa !29
  %t111 = load %"compiler/lower:pl", ptr %l64
  %t113 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %s3, ptr %s3, ptr %t110, %"compiler/lower:pl" %t111, { i64, [1 x i64] } %t109)
  store %"compiler/lower:pl" %t113, ptr %l67
  br label %bb23
bb23:
  %t114 = load i64, ptr %l12, !tbaa !24
  %t116 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = getelementptr i32, ptr %t117, i64 %t114
  %t119 = load i32, ptr %t118, !tbaa !33
  %t120 = load { i64, [1 x i64] }, ptr %l4
  %t121 = load %"compiler/source:Span", ptr %l5
  %t122 = load ptr, ptr %l56, !tbaa !29
  %t123 = load %"compiler/lower:pl", ptr %l67
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2einner(ptr %v0, ptr %s3, ptr %t122, %"compiler/lower:pl" %t123, i32 %t119, { i64, [1 x i64] } %t120, %"compiler/source:Span" %t121)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb25:
  %t127 = load i64, ptr %l11, !tbaa !24
  %t129 = add i64 %t127, 1
  store i64 %t129, ptr %l11, !tbaa !24
  br label %bb13
bb26:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load { i64, [1 x i64] }, ptr %l4
  %t133 = load %"compiler/source:Span", ptr %l5
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eword(ptr %v0, ptr %s0, ptr %t131, { i64, [1 x i64] } %t132, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, %"compiler/source:Span" %t133)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eresultScope(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l14 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i64
  %l43 = alloca { i64, [1 x i64] }
  %rv = alloca { i64, [1 x i64] }
  %t8 = alloca { i64, [1 x i64] }, align 8
  %t83 = alloca { i64, [1 x i64] }, align 8
  %t94 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 24
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store { i64, [1 x i64] } zeroinitializer, ptr %t8
  %t9 = getelementptr { i64, [1 x i64] }, ptr %t8, i32 0, i32 0
  store i64 2, ptr %t9
  %t10 = load { i64, [1 x i64] }, ptr %t8
  store { i64, [1 x i64] } %t10, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l1, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lower:lowering", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Body", ptr %t15, i32 0, i32 6
  %t19 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eLen_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t17)
  store i64 %t19, ptr %l14
  br label %bb4
bb4:
  %t20 = load i64, ptr %l14, !tbaa !24
  store i64 %t20, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t21 = load i64, ptr %l2, !tbaa !24
  %t22 = load i64, ptr %l1, !tbaa !24
  %t25 = icmp sgt i64 %t21, %t22
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t27 = load i64, ptr %l3, !tbaa !24
  %t29 = icmp sgt i64 %t27, 0
  br i1 %t29, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb10
bb7:
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = sub i64 %t31, %t32
  %t36 = load i64, ptr %l3, !tbaa !24
  %t39 = add i64 %t35, %t36
  %t41 = sub i64 %t39, 1
  %t42 = load i64, ptr %l3, !tbaa !24
  %t45 = sdiv i64 %t41, %t42
  store i64 %t45, ptr %l21, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb9
bb9:
  %t47 = load i64, ptr %l21, !tbaa !24
  store i64 %t47, ptr %l18, !tbaa !24
  br label %bb10
bb10:
  %t48 = load i64, ptr %l18, !tbaa !24
  store i64 %t48, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb11
bb11:
  %t49 = load i64, ptr %l5, !tbaa !24
  %t50 = load i64, ptr %l4, !tbaa !24
  %t53 = icmp slt i64 %t49, %t50
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb12, label %bb13
bb12:
  br label %bb20
bb13:
  br label %bb14
bb14:
  %t57 = load i64, ptr %l1, !tbaa !24
  %t58 = load i64, ptr %l5, !tbaa !24
  %t59 = load i64, ptr %l3, !tbaa !24
  %t62 = mul i64 %t58, %t59
  %t65 = add i64 %t57, %t62
  store i64 %t65, ptr %l6, !tbaa !24
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/lower:lowering", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = getelementptr %"compiler/typed:Body", ptr %t70, i32 0, i32 6
  %t73 = load i64, ptr %l6, !tbaa !24
  %t76 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t72, i64 %t73)
  store { i64, [1 x i64] } %t76, ptr %l43
  br label %bb15
bb15:
  %t77 = load { i64, [1 x i64] }, ptr %l43
  %t79 = extractvalue { i64, [1 x i64] } %t77, 0
  %t80 = icmp eq i64 %t79, 1
  br i1 %t80, label %bb16, label %bb17
bb16:
  %t82 = load i64, ptr %l6, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t83
  %t84 = getelementptr { i64, [1 x i64] }, ptr %t83, i32 0, i32 0
  store i64 1, ptr %t84
  %t86 = insertvalue { i64 } undef, i64 %t82, 0
  %t87 = getelementptr { i64, [1 x i64] }, ptr %t83, i32 0, i32 1
  store { i64 } %t86, ptr %t87
  %t88 = load { i64, [1 x i64] }, ptr %t83
  store { i64, [1 x i64] } %t88, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t90 = load i64, ptr %l5, !tbaa !24
  %t92 = add i64 %t90, 1
  store i64 %t92, ptr %l5, !tbaa !24
  br label %bb11
bb20:
  store { i64, [1 x i64] } zeroinitializer, ptr %t94
  %t95 = getelementptr { i64, [1 x i64] }, ptr %t94, i32 0, i32 0
  store i64 2, ptr %t95
  %t96 = load { i64, [1 x i64] }, ptr %t94
  store { i64, [1 x i64] } %t96, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2erun(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"compiler/typed:Local"
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca { i64, [1 x i64] }
  %l14 = alloca { i64, [2 x i64] }
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i64
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i64
  %l28 = alloca { i64, [1 x i64] }
  %l29 = alloca i32
  %l30 = alloca i32
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i32
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca i64
  %l45 = alloca i1
  %l46 = alloca i32
  %l52 = alloca { i64, ptr }
  %l55 = alloca i64
  %l59 = alloca i64
  %l62 = alloca i64
  %l83 = alloca %"compiler/typed:Local"
  %l85 = alloca i32
  %l100 = alloca i1
  %l107 = alloca { i64, ptr }
  %l124 = alloca i1
  %l128 = alloca i1
  %l131 = alloca i1
  %l134 = alloca i1
  %l143 = alloca i1
  %l152 = alloca i1
  %l162 = alloca ptr
  %l168 = alloca %"compiler/mir:Local"
  %l169 = alloca i32
  %l174 = alloca i64
  %l176 = alloca i64
  %l181 = alloca i32
  %l183 = alloca ptr
  %l186 = alloca i32
  %l189 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l192 = alloca i64
  %l196 = alloca i64
  %l199 = alloca i64
  %l220 = alloca %"compiler/typed:Local"
  %l236 = alloca i64
  %l238 = alloca i64
  %l243 = alloca { i64, [1 x i64] }
  %l244 = alloca { i64, [1 x i64] }
  %l249 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l251 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l253 = alloca i64
  %l267 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l269 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l271 = alloca i64
  %l282 = alloca i64
  %l286 = alloca i64
  %l289 = alloca i64
  %l323 = alloca ptr
  %l328 = alloca %"compiler/lower:Gap"
  %l331 = alloca i32
  %l335 = alloca ptr
  %l336 = alloca i32
  %l337 = alloca i32
  %l345 = alloca i32
  %l353 = alloca ptr
  %l354 = alloca i32
  %l361 = alloca %"compiler/lower:level"
  %l376 = alloca { i64, ptr }
  %l387 = alloca i1
  %l393 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %t102 = alloca { i64, [1 x i64] }, align 8
  %t146 = alloca { i64, [1 x i64] }, align 8
  %t158 = alloca { i64, [1 x i64] }, align 8
  %t169 = alloca { i64, [1 x i64] }, align 8
  %t213 = alloca { i64, [1 x i64] }, align 8
  %t258 = alloca { i64, [1 x i64] }, align 8
  %t447 = alloca { i64, [1 x i64] }, align 8
  %t459 = alloca { i64, [1 x i64] }, align 8
  %t468 = alloca { i64, [1 x i64] }, align 8
  %t477 = alloca { i64, [1 x i64] }, align 8
  %t497 = alloca { i64, [1 x i64] }, align 8
  %t579 = alloca { i64, [1 x i64] }, align 8
  %t671 = alloca { i64, [21 x i64] }, align 8
  %t790 = alloca { i64, [4 x i64] }, align 8
  %t793 = alloca { i64, [8 x i64] }, align 8
  %t810 = alloca { i64, [4 x i64] }, align 8
  %t813 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 2
  %t9 = load ptr, ptr %t8, !tbaa !29
  store ptr %t9, ptr %l2, !tbaa !29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2estandInAway(ptr %v0, ptr %s0, ptr %t11)
  store { i64, ptr } %t13, ptr %l52
  br label %bb1
bb1:
  %t14 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t14, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Body", ptr %t15, i32 0, i32 7
  %t19 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t17)
  store i64 %t19, ptr %l55
  br label %bb2
bb2:
  %t20 = load i64, ptr %l55, !tbaa !24
  store i64 %t20, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t21 = load i64, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = icmp sgt i64 %t21, %t22
  br i1 %t25, label %bb3, label %bb4
bb3:
  %t27 = load i64, ptr %l6, !tbaa !24
  %t29 = icmp sgt i64 %t27, 0
  br i1 %t29, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb8
bb5:
  %t31 = load i64, ptr %l5, !tbaa !24
  %t32 = load i64, ptr %l4, !tbaa !24
  %t35 = sub i64 %t31, %t32
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = add i64 %t35, %t36
  %t41 = sub i64 %t39, 1
  %t42 = load i64, ptr %l6, !tbaa !24
  %t45 = sdiv i64 %t41, %t42
  store i64 %t45, ptr %l62, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l62, !tbaa !24
  br label %bb7
bb7:
  %t47 = load i64, ptr %l62, !tbaa !24
  store i64 %t47, ptr %l59, !tbaa !24
  br label %bb8
bb8:
  %t48 = load i64, ptr %l59, !tbaa !24
  store i64 %t48, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t49 = load i64, ptr %l8, !tbaa !24
  %t50 = load i64, ptr %l7, !tbaa !24
  %t53 = icmp slt i64 %t49, %t50
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb81
bb11:
  br label %bb12
bb12:
  %t57 = load i64, ptr %l4, !tbaa !24
  %t58 = load i64, ptr %l8, !tbaa !24
  %t59 = load i64, ptr %l6, !tbaa !24
  %t62 = mul i64 %t58, %t59
  %t65 = add i64 %t57, %t62
  store i64 %t65, ptr %l9, !tbaa !24
  %t67 = load ptr, ptr %l1, !tbaa !29
  %t69 = getelementptr %"compiler/typed:Body", ptr %t67, i32 0, i32 7
  %t70 = load i64, ptr %l9, !tbaa !24
  %t73 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t69, i64 %t70)
  store %"compiler/typed:Local" %t73, ptr %l83
  br label %bb13
bb13:
  %t74 = load %"compiler/typed:Local", ptr %l83
  store %"compiler/typed:Local" %t74, ptr %l10
  %t75 = getelementptr %"compiler/typed:Local", ptr %l10, i32 0, i32 4
  %t76 = load i32, ptr %t75, !range !{i32 0, i32 7}
  store i32 %t76, ptr %l11
  %t78 = load i32, ptr %l11, !range !{i32 0, i32 7}
  %t80 = trunc i64 0 to i32
  %t81 = icmp eq i32 %t78, %t80
  br i1 %t81, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i32 0, ptr %l85
  br label %bb26
bb17:
  %t84 = load i32, ptr %l11, !range !{i32 0, i32 7}
  %t86 = trunc i64 5 to i32
  %t87 = icmp eq i32 %t84, %t86
  br i1 %t87, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store i32 1, ptr %l85
  br label %bb26
bb21:
  br i1 true, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  store i32 2, ptr %l85
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_a41c6179c77e6584_47cab6c73a638ed0)
  unreachable
bb26:
  %t91 = load i32, ptr %l85, !range !{i32 0, i32 4}
  store i32 %t91, ptr %l12
  %t92 = getelementptr %"compiler/typed:Local", ptr %l10, i32 0, i32 2
  %t93 = load i32, ptr %t92, !tbaa !23
  %t94 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t97 = icmp eq i32 %t93, %t94
  br i1 %t97, label %bb27, label %bb28
bb27:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/lower:lowering", ptr %t99, i32 0, i32 11
  store i1 true, ptr %t101, !tbaa !21
  br label %bb29
bb28:
  br label %bb29
bb29:
  store { i64, [1 x i64] } zeroinitializer, ptr %t102
  %t103 = getelementptr { i64, [1 x i64] }, ptr %t102, i32 0, i32 0
  store i64 3, ptr %t103
  %t104 = load { i64, [1 x i64] }, ptr %t102
  store { i64, [1 x i64] } %t104, ptr %l13
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/lower:lowering", ptr %t106, i32 0, i32 24
  %t109 = load i1, ptr %t108, !tbaa !21
  br i1 %t109, label %bb30, label %bb31
bb30:
  %t111 = load i64, ptr %l9, !tbaa !24
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/lower:lowering", ptr %t112, i32 0, i32 30
  %t115 = getelementptr %"compiler/typed:Plan", ptr %t114, i32 0, i32 1
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t116, 0
  %t121 = icmp slt i64 %t111, %t118
  store i1 %t121, ptr %l100, !tbaa !21
  br label %bb32
bb31:
  store i1 false, ptr %l100, !tbaa !21
  br label %bb32
bb32:
  %t123 = load i1, ptr %l100, !tbaa !21
  br i1 %t123, label %bb33, label %bb34
bb33:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/lower:lowering", ptr %t124, i32 0, i32 30
  %t127 = getelementptr %"compiler/typed:Plan", ptr %t126, i32 0, i32 1
  %t128 = load { i64, ptr }, ptr %t127, !tbaa !27
  store { i64, ptr } %t128, ptr %l107, !tbaa !27
  %t129 = load i64, ptr %l9, !tbaa !24
  %t131 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr { i64, [2 x i64] }, ptr %t132, i64 %t129
  %t134 = load { i64, [2 x i64] }, ptr %t133
  store { i64, [2 x i64] } %t134, ptr %l14
  %t136 = load { i64, [2 x i64] }, ptr %l14
  %t138 = extractvalue { i64, [2 x i64] } %t136, 0
  %t139 = icmp eq i64 %t138, 2
  br i1 %t139, label %bb35, label %bb36
bb34:
  br label %bb48
bb35:
  %t141 = getelementptr { i64, [2 x i64] }, ptr %l14, i32 0, i32 1
  %t142 = getelementptr { i64 }, ptr %t141, i32 0, i32 0
  %t143 = load i64, ptr %t142
  store i64 %t143, ptr %l15, !tbaa !24
  br label %bb37
bb36:
  br label %bb38
bb37:
  %t145 = load i64, ptr %l15, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t146
  %t147 = getelementptr { i64, [1 x i64] }, ptr %t146, i32 0, i32 0
  store i64 1, ptr %t147
  %t149 = insertvalue { i64 } undef, i64 %t145, 0
  %t150 = getelementptr { i64, [1 x i64] }, ptr %t146, i32 0, i32 1
  store { i64 } %t149, ptr %t150
  %t151 = load { i64, [1 x i64] }, ptr %t146
  store { i64, [1 x i64] } %t151, ptr %l13
  br label %bb47
bb38:
  %t153 = load { i64, [2 x i64] }, ptr %l14
  %t155 = extractvalue { i64, [2 x i64] } %t153, 0
  %t156 = icmp eq i64 %t155, 3
  br i1 %t156, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  store { i64, [1 x i64] } zeroinitializer, ptr %t158
  %t159 = getelementptr { i64, [1 x i64] }, ptr %t158, i32 0, i32 0
  store i64 2, ptr %t159
  %t160 = load { i64, [1 x i64] }, ptr %t158
  store { i64, [1 x i64] } %t160, ptr %l13
  br label %bb47
bb42:
  br i1 true, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_d5691da7c866d175_fd62f9716bce2461)
  unreachable
bb47:
  br label %bb48
bb48:
  %t162 = load i64, ptr %l9, !tbaa !24
  %t164 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !27
  %t166 = getelementptr i1, ptr %t165, i64 %t162
  %t167 = load i1, ptr %t166, !tbaa !31
  br i1 %t167, label %bb49, label %bb50
bb49:
  store { i64, [1 x i64] } zeroinitializer, ptr %t169
  %t170 = getelementptr { i64, [1 x i64] }, ptr %t169, i32 0, i32 0
  store i64 2, ptr %t170
  %t171 = load { i64, [1 x i64] }, ptr %t169
  store { i64, [1 x i64] } %t171, ptr %l13
  br label %bb51
bb50:
  br label %bb51
bb51:
  %t173 = load { i64, [1 x i64] }, ptr %l13
  %t175 = extractvalue { i64, [1 x i64] } %t173, 0
  %t176 = icmp eq i64 %t175, 3
  %t178 = xor i1 %t176, true
  br i1 %t178, label %bb52, label %bb53
bb52:
  %t180 = load i64, ptr %l9, !tbaa !24
  %t182 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !27
  %t184 = getelementptr i1, ptr %t183, i64 %t180
  %t185 = load i1, ptr %t184, !tbaa !31
  %t187 = xor i1 %t185, true
  store i1 %t187, ptr %l124, !tbaa !21
  br label %bb54
bb53:
  store i1 false, ptr %l124, !tbaa !21
  br label %bb54
bb54:
  %t189 = load i1, ptr %l124, !tbaa !21
  br i1 %t189, label %bb55, label %bb56
bb55:
  %t190 = getelementptr %"compiler/typed:Local", ptr %l10, i32 0, i32 4
  %t191 = load i32, ptr %t190, !range !{i32 0, i32 7}
  %t193 = trunc i64 6 to i32
  %t194 = icmp eq i32 %t191, %t193
  store i1 %t194, ptr %l128, !tbaa !21
  br label %bb57
bb56:
  store i1 false, ptr %l128, !tbaa !21
  br label %bb57
bb57:
  %t196 = load i1, ptr %l128, !tbaa !21
  br i1 %t196, label %bb58, label %bb59
bb58:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/typed:Local", ptr %l10, i32 0, i32 2
  %t199 = load i32, ptr %t198, !tbaa !23
  %t202 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2erunArrayLocal(ptr %v0, ptr %t197, i32 %t199)
  store i1 %t202, ptr %l134
  br label %bb60
bb59:
  store i1 false, ptr %l131, !tbaa !21
  br label %bb61
bb60:
  %t203 = load i1, ptr %l134, !tbaa !21
  store i1 %t203, ptr %l131, !tbaa !21
  br label %bb61
bb61:
  %t204 = load i1, ptr %l131, !tbaa !21
  br i1 %t204, label %bb62, label %bb63
bb62:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/lower:lowering", ptr %t205, i32 0, i32 13
  %t208 = load i64, ptr %l9, !tbaa !24
  %t209 = load { i64, [1 x i64] }, ptr %l13
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fmir_3aScopeRef_3e__Hfd0fb4fa500a8eead78ad1b6f9922652(ptr %v0, ptr %t207, i64 %t208, { i64, [1 x i64] } %t209)
  br label %bb64
bb63:
  br label %bb65
bb64:
  store { i64, [1 x i64] } zeroinitializer, ptr %t213
  %t214 = getelementptr { i64, [1 x i64] }, ptr %t213, i32 0, i32 0
  store i64 3, ptr %t214
  %t215 = load { i64, [1 x i64] }, ptr %t213
  store { i64, [1 x i64] } %t215, ptr %l13
  br label %bb65
bb65:
  %t217 = load { i64, [1 x i64] }, ptr %l13
  %t219 = extractvalue { i64, [1 x i64] } %t217, 0
  %t220 = icmp eq i64 %t219, 3
  %t222 = xor i1 %t220, true
  br i1 %t222, label %bb66, label %bb67
bb66:
  %t224 = getelementptr %"compiler/typed:Local", ptr %l10, i32 0, i32 4
  %t225 = load i32, ptr %t224, !range !{i32 0, i32 7}
  %t227 = trunc i64 0 to i32
  %t228 = icmp eq i32 %t225, %t227
  store i1 %t228, ptr %l143, !tbaa !21
  br label %bb68
bb67:
  store i1 false, ptr %l143, !tbaa !21
  br label %bb68
bb68:
  %t230 = load i1, ptr %l143, !tbaa !21
  br i1 %t230, label %bb69, label %bb70
bb69:
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t233 = getelementptr %"compiler/lower:lowering", ptr %t231, i32 0, i32 13
  %t234 = load i64, ptr %l9, !tbaa !24
  %t235 = load { i64, [1 x i64] }, ptr %l13
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fmir_3aScopeRef_3e__Hfd0fb4fa500a8eead78ad1b6f9922652(ptr %v0, ptr %t233, i64 %t234, { i64, [1 x i64] } %t235)
  br label %bb71
bb70:
  br label %bb77
bb71:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t240 = getelementptr %"compiler/typed:Local", ptr %l10, i32 0, i32 2
  %t241 = load i32, ptr %t240, !tbaa !23
  %t244 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2erunArrayLocal(ptr %v0, ptr %t239, i32 %t241)
  store i1 %t244, ptr %l152
  br label %bb72
bb72:
  %t245 = load i1, ptr %l152, !tbaa !21
  br i1 %t245, label %bb73, label %bb74
bb73:
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t248 = getelementptr %"compiler/lower:lowering", ptr %t246, i32 0, i32 14
  %t249 = load i64, ptr %l9, !tbaa !24
  %t250 = load i64, ptr %l9, !tbaa !24
  %t252 = trunc i64 %t250 to i32
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fmir_3aLocalId_3e_2_H6363fee5e3f1c076b4ec00933ab48c6c(ptr %v0, ptr %t248, i64 %t249, i32 %t252)
  br label %bb75
bb74:
  store i32 2, ptr %l12
  br label %bb76
bb75:
  store { i64, [1 x i64] } zeroinitializer, ptr %t258
  %t259 = getelementptr { i64, [1 x i64] }, ptr %t258, i32 0, i32 0
  store i64 3, ptr %t259
  %t260 = load { i64, [1 x i64] }, ptr %t258
  store { i64, [1 x i64] } %t260, ptr %l13
  br label %bb76
bb76:
  br label %bb77
bb77:
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t264 = getelementptr %"compiler/lower:lowering", ptr %t262, i32 0, i32 3
  store ptr %t264, ptr %l162, !tbaa !29
  %t265 = getelementptr %"compiler/typed:Local", ptr %l10, i32 0, i32 0
  %t266 = load i32, ptr %t265, !tbaa !23
  %t267 = getelementptr %"compiler/typed:Local", ptr %l10, i32 0, i32 1
  %t268 = load %"compiler/source:Span", ptr %t267
  %t269 = getelementptr %"compiler/typed:Local", ptr %l10, i32 0, i32 2
  %t270 = load i32, ptr %t269, !tbaa !23
  %t271 = load i32, ptr %l12, !range !{i32 0, i32 4}
  %t272 = load { i64, [1 x i64] }, ptr %l13
  %t278 = call %"compiler/mir:Local" @compiler_2fmir_3aLocal_2ector(ptr %s2, i32 %t266, %"compiler/source:Span" %t268, i32 %t270, i32 %t271, { i64, [1 x i64] } %t272)
  store %"compiler/mir:Local" %t278, ptr %l168
  br label %bb78
bb78:
  %t279 = load ptr, ptr %l162, !tbaa !29
  %t280 = load %"compiler/mir:Local", ptr %l168
  %t281 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddLocal(ptr %v0, ptr %t279, %"compiler/mir:Local" %t280)
  store i32 %t281, ptr %l169
  br label %bb79
bb79:
  call void @__olang_scope_close(ptr %s2)
  br label %bb80
bb80:
  %t282 = load i64, ptr %l8, !tbaa !24
  %t284 = add i64 %t282, 1
  store i64 %t284, ptr %l8, !tbaa !24
  br label %bb9
bb81:
  %t286 = load ptr, ptr %l1, !tbaa !29
  %t288 = getelementptr %"compiler/typed:Body", ptr %t286, i32 0, i32 5
  store ptr %t288, ptr %l16, !tbaa !29
  store i64 0, ptr %l17, !tbaa !24
  br label %bb82
bb82:
  %t290 = load i64, ptr %l17, !tbaa !24
  store i64 %t290, ptr %l174, !tbaa !24
  %t291 = load ptr, ptr %l16, !tbaa !29
  %t293 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t291)
  store i64 %t293, ptr %l176
  br label %bb83
bb83:
  %t294 = load i64, ptr %l174, !tbaa !24
  %t295 = load i64, ptr %l176, !tbaa !24
  %t296 = icmp slt i64 %t294, %t295
  %t298 = xor i1 %t296, true
  br i1 %t298, label %bb84, label %bb85
bb84:
  br label %bb91
bb85:
  br label %bb86
bb86:
  %t300 = load ptr, ptr %l16, !tbaa !29
  %t301 = load i64, ptr %l17, !tbaa !24
  %t304 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t300, i64 %t301)
  store i32 %t304, ptr %l181
  br label %bb87
bb87:
  %t305 = load i32, ptr %l181, !tbaa !23
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t308 = getelementptr %"compiler/lower:lowering", ptr %t306, i32 0, i32 3
  %t309 = getelementptr %"compiler/mir:Fn", ptr %t308, i32 0, i32 4
  store ptr %t309, ptr %l183, !tbaa !29
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t314 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2eparamIn(ptr %v0, ptr %t310, i32 %t305)
  store i32 %t314, ptr %l186
  br label %bb88
bb88:
  %t315 = load ptr, ptr %l183, !tbaa !29
  %t316 = load i32, ptr %l186, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2ePush_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t315, i32 %t316)
  br label %bb89
bb89:
  br label %bb90
bb90:
  %t317 = load i64, ptr %l17, !tbaa !24
  %t319 = add i64 %t317, 1
  store i64 %t319, ptr %l17, !tbaa !24
  br label %bb82
bb91:
  %t321 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t321, ptr %l189
  br label %bb92
bb92:
  %t322 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l189
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t322, ptr %l19
  store i64 0, ptr %l20, !tbaa !24
  %t323 = load ptr, ptr %l1, !tbaa !29
  %t325 = getelementptr %"compiler/typed:Body", ptr %t323, i32 0, i32 7
  %t327 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t325)
  store i64 %t327, ptr %l192
  br label %bb93
bb93:
  %t328 = load i64, ptr %l192, !tbaa !24
  store i64 %t328, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t329 = load i64, ptr %l21, !tbaa !24
  %t330 = load i64, ptr %l20, !tbaa !24
  %t333 = icmp sgt i64 %t329, %t330
  br i1 %t333, label %bb94, label %bb95
bb94:
  %t335 = load i64, ptr %l22, !tbaa !24
  %t337 = icmp sgt i64 %t335, 0
  br i1 %t337, label %bb96, label %bb97
bb95:
  store i64 0, ptr %l196, !tbaa !24
  br label %bb99
bb96:
  %t339 = load i64, ptr %l21, !tbaa !24
  %t340 = load i64, ptr %l20, !tbaa !24
  %t343 = sub i64 %t339, %t340
  %t344 = load i64, ptr %l22, !tbaa !24
  %t347 = add i64 %t343, %t344
  %t349 = sub i64 %t347, 1
  %t350 = load i64, ptr %l22, !tbaa !24
  %t353 = sdiv i64 %t349, %t350
  store i64 %t353, ptr %l199, !tbaa !24
  br label %bb98
bb97:
  store i64 0, ptr %l199, !tbaa !24
  br label %bb98
bb98:
  %t355 = load i64, ptr %l199, !tbaa !24
  store i64 %t355, ptr %l196, !tbaa !24
  br label %bb99
bb99:
  %t356 = load i64, ptr %l196, !tbaa !24
  store i64 %t356, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb100
bb100:
  %t357 = load i64, ptr %l24, !tbaa !24
  %t358 = load i64, ptr %l23, !tbaa !24
  %t361 = icmp slt i64 %t357, %t358
  %t363 = xor i1 %t361, true
  br i1 %t363, label %bb101, label %bb102
bb101:
  br label %bb111
bb102:
  br label %bb103
bb103:
  %t365 = load i64, ptr %l20, !tbaa !24
  %t366 = load i64, ptr %l24, !tbaa !24
  %t367 = load i64, ptr %l22, !tbaa !24
  %t370 = mul i64 %t366, %t367
  %t373 = add i64 %t365, %t370
  store i64 %t373, ptr %l25, !tbaa !24
  %t375 = load ptr, ptr %l1, !tbaa !29
  %t377 = getelementptr %"compiler/typed:Body", ptr %t375, i32 0, i32 7
  %t378 = load i64, ptr %l25, !tbaa !24
  %t381 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t377, i64 %t378)
  store %"compiler/typed:Local" %t381, ptr %l220
  br label %bb104
bb104:
  %t382 = getelementptr %"compiler/typed:Local", ptr %l220, i32 0, i32 4
  %t383 = load i32, ptr %t382, !range !{i32 0, i32 7}
  %t385 = trunc i64 5 to i32
  %t386 = icmp eq i32 %t383, %t385
  br i1 %t386, label %bb105, label %bb106
bb105:
  %t388 = load i64, ptr %l25, !tbaa !24
  %t390 = trunc i64 %t388 to i32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2ePush_3ccompiler_2ftyped_3aLocalId_3e(ptr %s0, ptr %l19, i32 %t390)
  br label %bb107
bb106:
  br label %bb109
bb107:
  %t394 = load ptr, ptr %l0, !tbaa !29
  %t396 = getelementptr %"compiler/lower:lowering", ptr %t394, i32 0, i32 3
  %t397 = getelementptr %"compiler/mir:Fn", ptr %t396, i32 0, i32 5
  %t398 = load i64, ptr %l25, !tbaa !24
  %t400 = trunc i64 %t398 to i32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2ePush_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t397, i32 %t400)
  br label %bb108
bb108:
  br label %bb109
bb109:
  br label %bb110
bb110:
  %t404 = load i64, ptr %l24, !tbaa !24
  %t406 = add i64 %t404, 1
  store i64 %t406, ptr %l24, !tbaa !24
  br label %bb100
bb111:
  %t408 = load ptr, ptr %l1, !tbaa !29
  %t410 = getelementptr %"compiler/typed:Body", ptr %t408, i32 0, i32 6
  store ptr %t410, ptr %l26, !tbaa !29
  store i64 0, ptr %l27, !tbaa !24
  br label %bb112
bb112:
  %t412 = load i64, ptr %l27, !tbaa !24
  store i64 %t412, ptr %l236, !tbaa !24
  %t413 = load ptr, ptr %l26, !tbaa !29
  %t415 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eLen_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t413)
  store i64 %t415, ptr %l238
  br label %bb113
bb113:
  %t416 = load i64, ptr %l236, !tbaa !24
  %t417 = load i64, ptr %l238, !tbaa !24
  %t418 = icmp slt i64 %t416, %t417
  %t420 = xor i1 %t418, true
  br i1 %t420, label %bb114, label %bb115
bb114:
  br label %bb145
bb115:
  br label %bb116
bb116:
  %t422 = load ptr, ptr %l26, !tbaa !29
  %t423 = load i64, ptr %l27, !tbaa !24
  %t426 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t422, i64 %t423)
  store { i64, [1 x i64] } %t426, ptr %l243
  br label %bb117
bb117:
  %t427 = load { i64, [1 x i64] }, ptr %l243
  store { i64, [1 x i64] } %t427, ptr %l28
  %t428 = load { i64, [1 x i64] }, ptr %l28
  %t430 = extractvalue { i64, [1 x i64] } %t428, 0
  %t431 = icmp eq i64 %t430, 0
  br i1 %t431, label %bb118, label %bb119
bb118:
  %t433 = getelementptr { i64, [1 x i64] }, ptr %l28, i32 0, i32 1
  %t434 = getelementptr { i32 }, ptr %t433, i32 0, i32 0
  %t435 = load i32, ptr %t434
  store i32 %t435, ptr %l29, !tbaa !23
  br label %bb120
bb119:
  br label %bb123
bb120:
  store %olang.scope zeroinitializer, ptr %s26
  %t437 = load ptr, ptr %l1, !tbaa !29
  %t439 = getelementptr %"compiler/typed:Body", ptr %t437, i32 0, i32 5
  %t440 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t439
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t440, ptr %l249
  %t442 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e(ptr %s26, ptr %l249)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t442, ptr %l251
  br label %bb121
bb121:
  %t443 = load i32, ptr %l29, !tbaa !23
  %t444 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l251
  %t446 = call i64 @compiler_2flower_2eindexOf(ptr %s26, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t444, i32 %t443)
  store i64 %t446, ptr %l253
  br label %bb122
bb122:
  store { i64, [1 x i64] } zeroinitializer, ptr %t447
  %t448 = getelementptr { i64, [1 x i64] }, ptr %t447, i32 0, i32 0
  store i64 0, ptr %t448
  %t449 = load i64, ptr %l253, !tbaa !24
  %t450 = insertvalue { i64 } undef, i64 %t449, 0
  %t451 = getelementptr { i64, [1 x i64] }, ptr %t447, i32 0, i32 1
  store { i64 } %t450, ptr %t451
  %t452 = load { i64, [1 x i64] }, ptr %t447
  store { i64, [1 x i64] } %t452, ptr %l244
  call void @__olang_scope_close(ptr %s26)
  br label %bb142
bb123:
  %t454 = load { i64, [1 x i64] }, ptr %l28
  %t456 = extractvalue { i64, [1 x i64] } %t454, 0
  %t457 = icmp eq i64 %t456, 1
  br i1 %t457, label %bb124, label %bb125
bb124:
  br label %bb126
bb125:
  br label %bb127
bb126:
  store { i64, [1 x i64] } zeroinitializer, ptr %t459
  %t460 = getelementptr { i64, [1 x i64] }, ptr %t459, i32 0, i32 0
  store i64 1, ptr %t460
  %t461 = load { i64, [1 x i64] }, ptr %t459
  store { i64, [1 x i64] } %t461, ptr %l244
  br label %bb142
bb127:
  %t463 = load { i64, [1 x i64] }, ptr %l28
  %t465 = extractvalue { i64, [1 x i64] } %t463, 0
  %t466 = icmp eq i64 %t465, 2
  br i1 %t466, label %bb128, label %bb129
bb128:
  br label %bb130
bb129:
  br label %bb131
bb130:
  store { i64, [1 x i64] } zeroinitializer, ptr %t468
  %t469 = getelementptr { i64, [1 x i64] }, ptr %t468, i32 0, i32 0
  store i64 2, ptr %t469
  %t470 = load { i64, [1 x i64] }, ptr %t468
  store { i64, [1 x i64] } %t470, ptr %l244
  br label %bb142
bb131:
  %t472 = load { i64, [1 x i64] }, ptr %l28
  %t474 = extractvalue { i64, [1 x i64] } %t472, 0
  %t475 = icmp eq i64 %t474, 3
  br i1 %t475, label %bb132, label %bb133
bb132:
  br label %bb134
bb133:
  br label %bb135
bb134:
  store { i64, [1 x i64] } zeroinitializer, ptr %t477
  %t478 = getelementptr { i64, [1 x i64] }, ptr %t477, i32 0, i32 0
  store i64 3, ptr %t478
  %t479 = load { i64, [1 x i64] }, ptr %t477
  store { i64, [1 x i64] } %t479, ptr %l244
  br label %bb142
bb135:
  %t481 = load { i64, [1 x i64] }, ptr %l28
  %t483 = extractvalue { i64, [1 x i64] } %t481, 0
  %t484 = icmp eq i64 %t483, 4
  br i1 %t484, label %bb136, label %bb137
bb136:
  %t486 = getelementptr { i64, [1 x i64] }, ptr %l28, i32 0, i32 1
  %t487 = getelementptr { i32 }, ptr %t486, i32 0, i32 0
  %t488 = load i32, ptr %t487
  store i32 %t488, ptr %l30, !tbaa !23
  br label %bb138
bb137:
  br label %bb141
bb138:
  store %olang.scope zeroinitializer, ptr %s30
  %t490 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t490, ptr %l267
  %t492 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e(ptr %s30, ptr %l267)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t492, ptr %l269
  br label %bb139
bb139:
  %t493 = load i32, ptr %l30, !tbaa !23
  %t494 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l269
  %t496 = call i64 @compiler_2flower_2eindexOf(ptr %s30, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t494, i32 %t493)
  store i64 %t496, ptr %l271
  br label %bb140
bb140:
  store { i64, [1 x i64] } zeroinitializer, ptr %t497
  %t498 = getelementptr { i64, [1 x i64] }, ptr %t497, i32 0, i32 0
  store i64 4, ptr %t498
  %t499 = load i64, ptr %l271, !tbaa !24
  %t500 = insertvalue { i64 } undef, i64 %t499, 0
  %t501 = getelementptr { i64, [1 x i64] }, ptr %t497, i32 0, i32 1
  store { i64 } %t500, ptr %t501
  %t502 = load { i64, [1 x i64] }, ptr %t497
  store { i64, [1 x i64] } %t502, ptr %l244
  call void @__olang_scope_close(ptr %s30)
  br label %bb142
bb141:
  call void @__olang_check_failed(ptr @olang_loc_9d64f8741da6e7be_5ae354e0f93b83ca)
  unreachable
bb142:
  %t504 = load { i64, [1 x i64] }, ptr %l244
  %t505 = load ptr, ptr %l0, !tbaa !29
  %t507 = getelementptr %"compiler/lower:lowering", ptr %t505, i32 0, i32 3
  %t508 = getelementptr %"compiler/mir:Fn", ptr %t507, i32 0, i32 6
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2ePush_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %t508, { i64, [1 x i64] } %t504)
  br label %bb143
bb143:
  br label %bb144
bb144:
  %t512 = load i64, ptr %l27, !tbaa !24
  %t514 = add i64 %t512, 1
  store i64 %t514, ptr %l27, !tbaa !24
  br label %bb112
bb145:
  %t516 = load ptr, ptr %l0, !tbaa !29
  %t518 = getelementptr %"compiler/lower:lowering", ptr %t516, i32 0, i32 24
  %t519 = load i1, ptr %t518, !tbaa !21
  br i1 %t519, label %bb146, label %bb147
bb146:
  store i64 0, ptr %l32, !tbaa !24
  %t521 = load ptr, ptr %l0, !tbaa !29
  %t523 = getelementptr %"compiler/lower:lowering", ptr %t521, i32 0, i32 30
  %t524 = getelementptr %"compiler/typed:Plan", ptr %t523, i32 0, i32 15
  %t526 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t524)
  store i64 %t526, ptr %l282
  br label %bb148
bb147:
  br label %bb162
bb148:
  %t527 = load i64, ptr %l282, !tbaa !24
  store i64 %t527, ptr %l33, !tbaa !24
  store i64 1, ptr %l34, !tbaa !24
  %t528 = load i64, ptr %l33, !tbaa !24
  %t529 = load i64, ptr %l32, !tbaa !24
  %t532 = icmp sgt i64 %t528, %t529
  br i1 %t532, label %bb149, label %bb150
bb149:
  %t534 = load i64, ptr %l34, !tbaa !24
  %t536 = icmp sgt i64 %t534, 0
  br i1 %t536, label %bb151, label %bb152
bb150:
  store i64 0, ptr %l286, !tbaa !24
  br label %bb154
bb151:
  %t538 = load i64, ptr %l33, !tbaa !24
  %t539 = load i64, ptr %l32, !tbaa !24
  %t542 = sub i64 %t538, %t539
  %t543 = load i64, ptr %l34, !tbaa !24
  %t546 = add i64 %t542, %t543
  %t548 = sub i64 %t546, 1
  %t549 = load i64, ptr %l34, !tbaa !24
  %t552 = sdiv i64 %t548, %t549
  store i64 %t552, ptr %l289, !tbaa !24
  br label %bb153
bb152:
  store i64 0, ptr %l289, !tbaa !24
  br label %bb153
bb153:
  %t554 = load i64, ptr %l289, !tbaa !24
  store i64 %t554, ptr %l286, !tbaa !24
  br label %bb154
bb154:
  %t555 = load i64, ptr %l286, !tbaa !24
  store i64 %t555, ptr %l35, !tbaa !24
  store i64 0, ptr %l36, !tbaa !24
  br label %bb155
bb155:
  %t556 = load i64, ptr %l36, !tbaa !24
  %t557 = load i64, ptr %l35, !tbaa !24
  %t560 = icmp slt i64 %t556, %t557
  %t562 = xor i1 %t560, true
  br i1 %t562, label %bb156, label %bb157
bb156:
  br label %bb161
bb157:
  br label %bb158
bb158:
  %t564 = load i64, ptr %l32, !tbaa !24
  %t565 = load i64, ptr %l36, !tbaa !24
  %t566 = load i64, ptr %l34, !tbaa !24
  %t569 = mul i64 %t565, %t566
  %t572 = add i64 %t564, %t569
  %t574 = load ptr, ptr %l0, !tbaa !29
  %t576 = getelementptr %"compiler/lower:lowering", ptr %t574, i32 0, i32 3
  %t577 = getelementptr %"compiler/mir:Fn", ptr %t576, i32 0, i32 6
  store { i64, [1 x i64] } zeroinitializer, ptr %t579
  %t580 = getelementptr { i64, [1 x i64] }, ptr %t579, i32 0, i32 0
  store i64 5, ptr %t580
  %t582 = insertvalue { i64 } undef, i64 %t572, 0
  %t583 = getelementptr { i64, [1 x i64] }, ptr %t579, i32 0, i32 1
  store { i64 } %t582, ptr %t583
  %t584 = load { i64, [1 x i64] }, ptr %t579
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2ePush_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %t577, { i64, [1 x i64] } %t584)
  br label %bb159
bb159:
  br label %bb160
bb160:
  %t587 = load i64, ptr %l36, !tbaa !24
  %t589 = add i64 %t587, 1
  store i64 %t589, ptr %l36, !tbaa !24
  br label %bb155
bb161:
  br label %bb162
bb162:
  %t591 = load ptr, ptr %l0, !tbaa !29
  %t593 = getelementptr %"compiler/lower:lowering", ptr %t591, i32 0, i32 0
  %t594 = load ptr, ptr %t593, !tbaa !29
  %t595 = load ptr, ptr %l1, !tbaa !29
  %t597 = getelementptr %"compiler/typed:Body", ptr %t595, i32 0, i32 3
  %t598 = load i64, ptr %t597, !tbaa !24
  %t599 = load ptr, ptr %l0, !tbaa !29
  %t601 = getelementptr %"compiler/lower:lowering", ptr %t599, i32 0, i32 3
  %t602 = getelementptr %"compiler/mir:Fn", ptr %t601, i32 0, i32 0
  %t603 = load { i64, [2 x i64] }, ptr %t602
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eReadDerived(ptr %v0, ptr %t594, i64 %t598, { i64, [2 x i64] } %t603)
  br label %bb163
bb163:
  %t607 = load ptr, ptr %l0, !tbaa !29
  %t609 = getelementptr %"compiler/lower:lowering", ptr %t607, i32 0, i32 11
  %t610 = load i1, ptr %t609, !tbaa !21
  br i1 %t610, label %bb164, label %bb165
bb164:
  %t612 = load ptr, ptr %l0, !tbaa !29
  %t614 = getelementptr %"compiler/lower:lowering", ptr %t612, i32 0, i32 0
  %t615 = load ptr, ptr %t614, !tbaa !29
  %t617 = getelementptr %"compiler/lower:Lowerer", ptr %t615, i32 0, i32 6
  store ptr %t617, ptr %l323, !tbaa !29
  %t618 = load ptr, ptr %l0, !tbaa !29
  %t620 = getelementptr %"compiler/lower:lowering", ptr %t618, i32 0, i32 7
  %t621 = load i64, ptr %t620, !tbaa !24
  %t622 = load ptr, ptr %l1, !tbaa !29
  %t624 = getelementptr %"compiler/typed:Body", ptr %t622, i32 0, i32 4
  %t625 = load %"compiler/source:Span", ptr %t624
  %t628 = call %"compiler/lower:Gap" @compiler_2flower_3aGap_2ector(ptr %v0, ptr %v0, i64 %t621, %"compiler/source:Span" %t625, { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store %"compiler/lower:Gap" %t628, ptr %l328
  br label %bb166
bb165:
  br label %bb168
bb166:
  %t629 = load ptr, ptr %l323, !tbaa !29
  %t630 = load %"compiler/lower:Gap", ptr %l328
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aGap_3e_2ePush_3ccompiler_2flower_3aGap_3e(ptr %v0, ptr %v0, ptr %t629, %"compiler/lower:Gap" %t630)
  br label %bb167
bb167:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb168:
  %t631 = load ptr, ptr %l0, !tbaa !29
  %t633 = getelementptr %"compiler/lower:lowering", ptr %t631, i32 0, i32 3
  %t635 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t633)
  store i32 %t635, ptr %l331
  br label %bb169
bb169:
  %t636 = load ptr, ptr %l1, !tbaa !29
  %t638 = getelementptr %"compiler/typed:Body", ptr %t636, i32 0, i32 11
  %t639 = load ptr, ptr %t638, !tbaa !29
  store ptr %t639, ptr %l38, !tbaa !29
  %t641 = load ptr, ptr %l0, !tbaa !29
  %t643 = getelementptr %"compiler/lower:lowering", ptr %t641, i32 0, i32 3
  store ptr %t643, ptr %l335, !tbaa !29
  store i32 0, ptr %l336
  %t644 = load i32, ptr @G_2ecompiler_2fmir_2eNoScope, !tbaa !23
  store i32 %t644, ptr %l337, !tbaa !23
  %t645 = load ptr, ptr %l38, !tbaa !29
  %t647 = icmp eq ptr %t645, null
  br i1 %t647, label %bb170, label %bb171
bb170:
  call void @__olang_check_failed(ptr @olang_loc_cce264ade2665388_2fe88b7b285cb164)
  unreachable
bb171:
  br label %bb172
bb172:
  %t649 = load ptr, ptr %l38, !tbaa !29
  %t652 = getelementptr %"compiler/typed:Block", ptr %t649, i32 0, i32 0
  %t653 = load i32, ptr %t652, !tbaa !23
  %t654 = load ptr, ptr %l1, !tbaa !29
  %t656 = getelementptr %"compiler/typed:Body", ptr %t654, i32 0, i32 4
  %t657 = load %"compiler/source:Span", ptr %t656
  %t658 = load ptr, ptr %l335, !tbaa !29
  %t659 = load i32, ptr %l336, !range !{i32 0, i32 7}
  %t660 = load i32, ptr %l337, !tbaa !23
  %t663 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddScope(ptr %v0, ptr %t658, i32 %t659, i32 %t660, i32 %t653, %"compiler/source:Span" %t657, i32 0)
  store i32 %t663, ptr %l345
  br label %bb173
bb173:
  %t664 = load i32, ptr %l345, !tbaa !23
  store i32 %t664, ptr %l39, !tbaa !23
  %t665 = load ptr, ptr %l0, !tbaa !29
  %t666 = load ptr, ptr %l1, !tbaa !29
  %t668 = getelementptr %"compiler/typed:Body", ptr %t666, i32 0, i32 4
  %t669 = load %"compiler/source:Span", ptr %t668
  %t670 = load i32, ptr %l39, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t671
  %t672 = getelementptr { i64, [21 x i64] }, ptr %t671, i32 0, i32 0
  store i64 3, ptr %t672
  %t674 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t669, 0
  %t676 = insertvalue { %"compiler/source:Span", i32 } %t674, i32 %t670, 1
  %t677 = getelementptr { i64, [21 x i64] }, ptr %t671, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t676, ptr %t677
  %t678 = load { i64, [21 x i64] }, ptr %t671
  %t680 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t678, ptr %t680
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t665, ptr %t680)
  br label %bb174
bb174:
  %t683 = load ptr, ptr %l0, !tbaa !29
  %t685 = getelementptr %"compiler/lower:lowering", ptr %t683, i32 0, i32 12
  store ptr %t685, ptr %l353, !tbaa !29
  %t686 = load i32, ptr %l39, !tbaa !23
  store i32 %t686, ptr %l354, !tbaa !23
  %t687 = load ptr, ptr %l38, !tbaa !29
  %t689 = icmp eq ptr %t687, null
  br i1 %t689, label %bb175, label %bb176
bb175:
  call void @__olang_check_failed(ptr @olang_loc_7968fd697afe6b41_fd4fb0e63a0f91b5)
  unreachable
bb176:
  br label %bb177
bb177:
  %t691 = load ptr, ptr %l38, !tbaa !29
  %t694 = getelementptr %"compiler/typed:Block", ptr %t691, i32 0, i32 0
  %t695 = load i32, ptr %t694, !tbaa !23
  %t696 = load i32, ptr %l354, !tbaa !23
  %t699 = call %"compiler/lower:level" @compiler_2flower_3alevel_2ector(ptr %s0, i32 %t696, i32 %t695, i32 0)
  store %"compiler/lower:level" %t699, ptr %l361
  br label %bb178
bb178:
  %t700 = load ptr, ptr %l353, !tbaa !29
  %t701 = load %"compiler/lower:level", ptr %l361
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2ePush_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t700, %"compiler/lower:level" %t701)
  br label %bb179
bb179:
  %t702 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ecopyParams(ptr %v0, ptr %t702)
  br label %bb180
bb180:
  %t704 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eholdParams(ptr %v0, ptr %t704)
  br label %bb181
bb181:
  %t706 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2esettleViews(ptr %v0, ptr %t706)
  br label %bb182
bb182:
  %t708 = load ptr, ptr %l38, !tbaa !29
  %t710 = icmp eq ptr %t708, null
  br i1 %t710, label %bb183, label %bb184
bb183:
  call void @__olang_check_failed(ptr @olang_loc_796d2b5c84af77ba_ecbdfcaab288560e)
  unreachable
bb184:
  br label %bb185
bb185:
  %t712 = load ptr, ptr %l38, !tbaa !29
  %t715 = getelementptr %"compiler/typed:Block", ptr %t712, i32 0, i32 1
  %t716 = load { i64, ptr }, ptr %t715, !tbaa !27
  store { i64, ptr } %t716, ptr %l40, !tbaa !27
  store i64 0, ptr %l41, !tbaa !24
  %t718 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t720 = extractvalue { i64, ptr } %t718, 0
  store i64 %t720, ptr %l42, !tbaa !24
  br label %bb186
bb186:
  %t722 = load i64, ptr %l41, !tbaa !24
  %t723 = load i64, ptr %l42, !tbaa !24
  %t726 = icmp slt i64 %t722, %t723
  %t728 = xor i1 %t726, true
  br i1 %t728, label %bb187, label %bb188
bb187:
  br label %bb192
bb188:
  br label %bb189
bb189:
  %t730 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t730, ptr %l376, !tbaa !27
  %t731 = load i64, ptr %l41, !tbaa !24
  %t733 = getelementptr { i64, ptr }, ptr %l376, i32 0, i32 1
  %t734 = load ptr, ptr %t733, !tbaa !27
  %t735 = getelementptr ptr, ptr %t734, i64 %t731
  %t736 = load ptr, ptr %t735, !tbaa !39
  %t738 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estmt(ptr %v0, ptr %v0, ptr %t738, ptr %t736)
  br label %bb190
bb190:
  br label %bb191
bb191:
  %t742 = load i64, ptr %l41, !tbaa !24
  %t744 = add i64 %t742, 1
  store i64 %t744, ptr %l41, !tbaa !24
  br label %bb186
bb192:
  %t746 = load ptr, ptr %l0, !tbaa !29
  %t748 = getelementptr %"compiler/lower:lowering", ptr %t746, i32 0, i32 10
  %t749 = load i1, ptr %t748, !tbaa !21
  br i1 %t749, label %bb193, label %bb194
bb193:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb194:
  br label %bb195
bb195:
  %t751 = load ptr, ptr %l1, !tbaa !29
  %t753 = getelementptr %"compiler/typed:Body", ptr %t751, i32 0, i32 1
  %t754 = load { i64, [2 x i64] }, ptr %t753
  %t758 = extractvalue { i64, [2 x i64] } %t754, 0
  %t759 = icmp eq i64 %t758, 1
  br i1 %t759, label %bb196, label %bb197
bb196:
  br label %bb198
bb197:
  br label %bb199
bb198:
  store i1 true, ptr %l387, !tbaa !21
  br label %bb204
bb199:
  br i1 true, label %bb200, label %bb201
bb200:
  br label %bb202
bb201:
  br label %bb203
bb202:
  store i1 false, ptr %l387, !tbaa !21
  br label %bb204
bb203:
  call void @__olang_check_failed(ptr @olang_loc_6ad9ce9fa5f3c6a2_cb74a58b871c8f06)
  unreachable
bb204:
  %t761 = load i1, ptr %l387, !tbaa !21
  store i1 %t761, ptr %l45, !tbaa !21
  %t762 = load ptr, ptr %l2, !tbaa !29
  %t763 = load ptr, ptr %l1, !tbaa !29
  %t765 = getelementptr %"compiler/typed:Body", ptr %t763, i32 0, i32 2
  %t766 = load i32, ptr %t765, !tbaa !23
  %t769 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t762, i32 %t766)
  store i32 %t769, ptr %l393
  br label %bb205
bb205:
  %t770 = load i32, ptr %l393, !tbaa !23
  store i32 %t770, ptr %l46, !tbaa !23
  %t771 = load i1, ptr %l45, !tbaa !21
  br i1 %t771, label %bb206, label %bb207
bb206:
  %t773 = load ptr, ptr %l0, !tbaa !29
  %t774 = load i32, ptr %l46, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eassemble(ptr %v0, ptr %t773, i32 %t774)
  br label %bb208
bb207:
  %t777 = load i32, ptr %l46, !tbaa !23
  %t778 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t781 = icmp eq i32 %t777, %t778
  br i1 %t781, label %bb209, label %bb210
bb208:
  br label %bb215
bb209:
  %t783 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleave(ptr %v0, ptr %t783, i64 0)
  br label %bb211
bb210:
  %t785 = load ptr, ptr %l0, !tbaa !29
  %t786 = load ptr, ptr %l1, !tbaa !29
  %t788 = getelementptr %"compiler/typed:Body", ptr %t786, i32 0, i32 4
  %t789 = load %"compiler/source:Span", ptr %t788
  store { i64, [4 x i64] } zeroinitializer, ptr %t790
  %t791 = getelementptr { i64, [4 x i64] }, ptr %t790, i32 0, i32 0
  store i64 0, ptr %t791
  %t792 = load { i64, [4 x i64] }, ptr %t790
  store { i64, [8 x i64] } zeroinitializer, ptr %t793
  %t794 = getelementptr { i64, [8 x i64] }, ptr %t793, i32 0, i32 0
  store i64 9, ptr %t794
  %t796 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t789, 0
  %t798 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t796, i32 3, 1
  %t800 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t798, { i64, [4 x i64] } %t792, 2
  %t801 = getelementptr { i64, [8 x i64] }, ptr %t793, i32 0, i32 1
  store { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t800, ptr %t801
  %t802 = load { i64, [8 x i64] }, ptr %t793
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t785, { i64, [8 x i64] } %t802)
  br label %bb213
bb211:
  %t805 = load ptr, ptr %l0, !tbaa !29
  %t806 = load ptr, ptr %l1, !tbaa !29
  %t808 = getelementptr %"compiler/typed:Body", ptr %t806, i32 0, i32 4
  %t809 = load %"compiler/source:Span", ptr %t808
  store { i64, [4 x i64] } zeroinitializer, ptr %t810
  %t811 = getelementptr { i64, [4 x i64] }, ptr %t810, i32 0, i32 0
  store i64 0, ptr %t811
  %t812 = load { i64, [4 x i64] }, ptr %t810
  store { i64, [8 x i64] } zeroinitializer, ptr %t813
  %t814 = getelementptr { i64, [8 x i64] }, ptr %t813, i32 0, i32 0
  store i64 5, ptr %t814
  %t816 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t809, 0
  %t818 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t816, { i64, [4 x i64] } %t812, 1
  %t819 = getelementptr { i64, [8 x i64] }, ptr %t813, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t818, ptr %t819
  %t820 = load { i64, [8 x i64] }, ptr %t813
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t805, { i64, [8 x i64] } %t820)
  br label %bb212
bb212:
  br label %bb214
bb213:
  br label %bb214
bb214:
  br label %bb215
bb215:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2escalar(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l6 = alloca i32
  %l10 = alloca i1
  %l14 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t4, i32 %a1)
  store i32 %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load i32, ptr %l6, !tbaa !23
  store i32 %t9, ptr %l2, !tbaa !23
  %t10 = load i32, ptr %l2, !tbaa !23
  %t11 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t14 = icmp eq i32 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb5
bb3:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/lower:lowering", ptr %t16, i32 0, i32 2
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t20 = load i32, ptr %l2, !tbaa !23
  %t23 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t19, i32 %t20)
  store i1 %t23, ptr %l14
  br label %bb4
bb4:
  %t24 = load i1, ptr %l14, !tbaa !21
  store i1 %t24, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t25 = load i1, ptr %l10, !tbaa !21
  store i1 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2esomeWrites(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l14 = alloca { i64, ptr }
  %l19 = alloca i1
  %l24 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb13
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t15, ptr %l14, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i32, ptr %t19, i64 %t16
  %t21 = load i32, ptr %t20, !tbaa !33
  store i32 %t21, ptr %l6, !tbaa !23
  %t23 = load i32, ptr %l6, !tbaa !23
  %t25 = icmp ne i32 %t23, 0
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t28 = load i32, ptr %l6, !tbaa !23
  %t31 = add i64 %a2, 1
  %t35 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ewritesCover(ptr %v0, ptr %a0, i32 %t28, i64 %t31)
  store i1 %t35, ptr %l24
  br label %bb7
bb6:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb8
bb7:
  %t36 = load i1, ptr %l24, !tbaa !21
  store i1 %t36, ptr %l19, !tbaa !21
  br label %bb8
bb8:
  %t37 = load i1, ptr %l19, !tbaa !21
  br i1 %t37, label %bb9, label %bb10
bb9:
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t39 = load i64, ptr %l4, !tbaa !24
  %t41 = add i64 %t39, 1
  store i64 %t41, ptr %l4, !tbaa !24
  br label %bb1
bb13:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2etail(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca { { i64, [7 x i64] }, i32 }
  %l6 = alloca { i64, [7 x i64] }
  %l7 = alloca i32
  %l8 = alloca %"compiler/mir:Range"
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca { i64, [4 x i64] }
  %l19 = alloca %"compiler/mir:Range"
  %l20 = alloca %"compiler/mir:Range"
  %l28 = alloca { { i64, [7 x i64] }, i32 }
  %l37 = alloca %"compiler/mir:Range"
  %l40 = alloca ptr
  %l43 = alloca i32
  %l44 = alloca { i64, ptr }
  %l47 = alloca i64
  %l55 = alloca i64
  %l58 = alloca i64
  %l82 = alloca { i64, [4 x i64] }
  %l83 = alloca i64
  %l88 = alloca { i64, [4 x i64] }
  %l90 = alloca { i64, ptr }
  %l96 = alloca { i64, [4 x i64] }
  %l103 = alloca %"compiler/mir:Range"
  %l109 = alloca %"compiler/mir:Range"
  %l112 = alloca ptr
  %l120 = alloca %"compiler/mir:Call"
  %l121 = alloca i32
  %s0 = alloca %olang.scope
  %t153 = alloca { i64, [15 x i64] }, align 8
  %t225 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = getelementptr %"compiler/typed:Call", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t11 = load %"compiler/source:Span", ptr %l1
  %t15 = call { { i64, [7 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2ecallee(ptr %v0, ptr %v1, ptr %t6, ptr %t10, %"compiler/source:Span" %t11, i32 -1)
  store { { i64, [7 x i64] }, i32 } %t15, ptr %l28
  br label %bb1
bb1:
  %t16 = load { { i64, [7 x i64] }, i32 }, ptr %l28
  store { { i64, [7 x i64] }, i32 } %t16, ptr %l5
  %t17 = getelementptr { { i64, [7 x i64] }, i32 }, ptr %l5, i32 0, i32 0
  %t18 = load { i64, [7 x i64] }, ptr %t17
  store { i64, [7 x i64] } %t18, ptr %l6
  %t20 = getelementptr { { i64, [7 x i64] }, i32 }, ptr %l5, i32 0, i32 1
  %t21 = load i32, ptr %t20, !tbaa !23
  store i32 %t21, ptr %l7, !tbaa !23
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/lower:lowering", ptr %t23, i32 0, i32 10
  %t26 = load i1, ptr %t25, !tbaa !21
  br i1 %t26, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t30 = load { i64, [7 x i64] }, ptr %l6
  %t31 = load i32, ptr %l7, !tbaa !23
  %t36 = call %"compiler/mir:Range" @compiler_2flower_2ecompiler_2flower_3alowering_2eargs(ptr %v0, ptr %v1, ptr %t28, ptr %t29, { i64, [7 x i64] } %t30, i32 %t31)
  store %"compiler/mir:Range" %t36, ptr %l37
  br label %bb5
bb5:
  %t37 = load %"compiler/mir:Range", ptr %l37
  store %"compiler/mir:Range" %t37, ptr %l8
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/lower:lowering", ptr %t38, i32 0, i32 10
  %t41 = load i1, ptr %t40, !tbaa !21
  br i1 %t41, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  br label %bb8
bb8:
  %t43 = load ptr, ptr %l4, !tbaa !29
  store ptr %t43, ptr %l40, !tbaa !29
  %t44 = load ptr, ptr %l4, !tbaa !29
  %t45 = load i32, ptr %l7, !tbaa !23
  %t48 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t44, i32 %t45)
  store i32 %t48, ptr %l43
  br label %bb9
bb9:
  %t49 = load ptr, ptr %l40, !tbaa !29
  %t50 = load i32, ptr %l43, !tbaa !23
  %t51 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t49, i32 %t50)
  store { i64, ptr } %t51, ptr %l44
  br label %bb10
bb10:
  %t52 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t52, ptr %l9, !tbaa !27
  %t53 = getelementptr %"compiler/mir:Range", ptr %l8, i32 0, i32 1
  %t54 = load i32, ptr %t53, !tbaa !23
  %t56 = sext i32 %t54 to i64
  store i64 %t56, ptr %l10, !tbaa !24
  %t58 = load i64, ptr %l10, !tbaa !24
  store i64 %t58, ptr %l47, !tbaa !24
  %t59 = load i64, ptr %l47, !tbaa !24
  %t60 = icmp sge i64 %t59, 0
  br i1 %t60, label %bb11, label %bb12
bb11:
  %t62 = load i64, ptr %l47, !tbaa !24
  %t63 = icmp sle i64 %t62, 230584300921369395
  br i1 %t63, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_16ceb3f79d83ba4c_75eb4aa6518e3548)
  unreachable
bb13:
  %t65 = load i64, ptr %l47, !tbaa !24
  %t66 = mul i64 %t65, 40
  %t67 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t66)
  %t68 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  store { i64, ptr } %t69, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t71 = load i64, ptr %l10, !tbaa !24
  store i64 %t71, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t73 = load i64, ptr %l13, !tbaa !24
  %t74 = load i64, ptr %l12, !tbaa !24
  %t77 = icmp sgt i64 %t73, %t74
  br i1 %t77, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_16ceb3f79d83ba4c_75eb4aa6518e3548)
  unreachable
bb15:
  %t79 = load i64, ptr %l14, !tbaa !24
  %t81 = icmp sgt i64 %t79, 0
  br i1 %t81, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l55, !tbaa !24
  br label %bb20
bb17:
  %t83 = load i64, ptr %l13, !tbaa !24
  %t84 = load i64, ptr %l12, !tbaa !24
  %t87 = sub i64 %t83, %t84
  %t88 = load i64, ptr %l14, !tbaa !24
  %t91 = add i64 %t87, %t88
  %t93 = sub i64 %t91, 1
  %t94 = load i64, ptr %l14, !tbaa !24
  %t97 = sdiv i64 %t93, %t94
  store i64 %t97, ptr %l58, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l58, !tbaa !24
  br label %bb19
bb19:
  %t99 = load i64, ptr %l58, !tbaa !24
  store i64 %t99, ptr %l55, !tbaa !24
  br label %bb20
bb20:
  %t100 = load i64, ptr %l55, !tbaa !24
  store i64 %t100, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb21
bb21:
  %t101 = load i64, ptr %l16, !tbaa !24
  %t102 = load i64, ptr %l15, !tbaa !24
  %t105 = icmp slt i64 %t101, %t102
  %t107 = xor i1 %t105, true
  br i1 %t107, label %bb22, label %bb23
bb22:
  br label %bb31
bb23:
  br label %bb24
bb24:
  %t109 = load i64, ptr %l12, !tbaa !24
  %t110 = load i64, ptr %l16, !tbaa !24
  %t111 = load i64, ptr %l14, !tbaa !24
  %t114 = mul i64 %t110, %t111
  %t117 = add i64 %t109, %t114
  store i64 %t117, ptr %l17, !tbaa !24
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/lower:lowering", ptr %t119, i32 0, i32 3
  %t122 = getelementptr %"compiler/mir:Fn", ptr %t121, i32 0, i32 11
  %t123 = getelementptr %"compiler/mir:Range", ptr %l8, i32 0, i32 0
  %t124 = load i32, ptr %t123, !tbaa !23
  %t126 = sext i32 %t124 to i64
  %t127 = load i64, ptr %l17, !tbaa !24
  %t130 = add i64 %t126, %t127
  %t133 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t122, i64 %t130)
  store { i64, [4 x i64] } %t133, ptr %l82
  br label %bb25
bb25:
  %t134 = load { i64, [4 x i64] }, ptr %l82
  store { i64, [4 x i64] } %t134, ptr %l18
  %t135 = load i64, ptr %l17, !tbaa !24
  store i64 %t135, ptr %l83, !tbaa !24
  %t136 = load i64, ptr %l17, !tbaa !24
  %t137 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t137, 0
  %t142 = icmp slt i64 %t136, %t139
  br i1 %t142, label %bb26, label %bb27
bb26:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t145, ptr %l90, !tbaa !27
  %t146 = load i64, ptr %l17, !tbaa !24
  %t148 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !27
  %t150 = getelementptr i32, ptr %t149, i64 %t146
  %t151 = load i32, ptr %t150, !tbaa !33
  %t152 = load { i64, [4 x i64] }, ptr %l18
  store { i64, [15 x i64] } zeroinitializer, ptr %t153
  %t154 = getelementptr { i64, [15 x i64] }, ptr %t153, i32 0, i32 0
  store i64 0, ptr %t154
  %t156 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t152, 0
  %t157 = getelementptr { i64, [15 x i64] }, ptr %t153, i32 0, i32 1
  store { { i64, [4 x i64] } } %t156, ptr %t157
  %t158 = load { i64, [15 x i64] }, ptr %t153
  %t159 = load %"compiler/source:Span", ptr %l1
  %t164 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t144, i32 %t151, { i64, [15 x i64] } %t158, %"compiler/source:Span" %t159)
  store { i64, [4 x i64] } %t164, ptr %l96
  br label %bb28
bb27:
  %t165 = load { i64, [4 x i64] }, ptr %l18
  store { i64, [4 x i64] } %t165, ptr %l88
  br label %bb29
bb28:
  %t167 = load { i64, [4 x i64] }, ptr %l96
  store { i64, [4 x i64] } %t167, ptr %l88
  br label %bb29
bb29:
  %t168 = load { i64, [4 x i64] }, ptr %l88
  %t169 = load i64, ptr %l83, !tbaa !24
  %t170 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !27
  %t172 = getelementptr { i64, [4 x i64] }, ptr %t171, i64 %t169
  store { i64, [4 x i64] } %t168, ptr %t172
  br label %bb30
bb30:
  %t173 = load i64, ptr %l16, !tbaa !24
  %t175 = add i64 %t173, 1
  store i64 %t175, ptr %l16, !tbaa !24
  br label %bb21
bb31:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/lower:lowering", ptr %t177, i32 0, i32 3
  %t180 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t183 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %s0, ptr %t179, { i64, ptr } %t180)
  store %"compiler/mir:Range" %t183, ptr %l103
  br label %bb32
bb32:
  %t184 = load %"compiler/mir:Range", ptr %l103
  store %"compiler/mir:Range" %t184, ptr %l19
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load { i64, [7 x i64] }, ptr %l6
  %t187 = load i32, ptr %l7, !tbaa !23
  %t188 = load ptr, ptr %l2, !tbaa !29
  %t190 = getelementptr %"compiler/typed:Call", ptr %t188, i32 0, i32 2
  %t191 = load i32, ptr %t190, !tbaa !23
  %t196 = call %"compiler/mir:Range" @compiler_2flower_2ecompiler_2flower_3alowering_2epassedFor(ptr %v0, ptr %t185, { i64, [7 x i64] } %t186, i32 %t187, i32 %t191)
  store %"compiler/mir:Range" %t196, ptr %l109
  br label %bb33
bb33:
  %t197 = load %"compiler/mir:Range", ptr %l109
  store %"compiler/mir:Range" %t197, ptr %l20
  %t198 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleave(ptr %v0, ptr %t198, i64 0)
  br label %bb34
bb34:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = getelementptr %"compiler/lower:lowering", ptr %t200, i32 0, i32 3
  store ptr %t202, ptr %l112, !tbaa !29
  %t203 = load { i64, [7 x i64] }, ptr %l6
  %t204 = load %"compiler/mir:Range", ptr %l19
  %t205 = load %"compiler/mir:Range", ptr %l20
  %t206 = load %"compiler/mir:Lvalue", ptr @G_2ecompiler_2fmir_2eNoPlace
  %t207 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t208 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t209 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t217 = call %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %s0, { i64, [7 x i64] } %t203, %"compiler/mir:Range" %t204, %"compiler/mir:Range" %t205, %"compiler/mir:Lvalue" %t206, i1 false, i32 %t207, i32 %t208, i32 %t209)
  store %"compiler/mir:Call" %t217, ptr %l120
  br label %bb35
bb35:
  %t218 = load ptr, ptr %l112, !tbaa !29
  %t219 = load %"compiler/mir:Call", ptr %l120
  %t220 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v0, ptr %t218, %"compiler/mir:Call" %t219)
  store i32 %t220, ptr %l121
  br label %bb36
bb36:
  %t221 = load i32, ptr %l121, !tbaa !23
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t223 = load %"compiler/source:Span", ptr %l1
  store { i64, [8 x i64] } zeroinitializer, ptr %t225
  %t226 = getelementptr { i64, [8 x i64] }, ptr %t225, i32 0, i32 0
  store i64 6, ptr %t226
  %t228 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t223, 0
  %t230 = insertvalue { %"compiler/source:Span", i32 } %t228, i32 %t221, 1
  %t231 = getelementptr { i64, [8 x i64] }, ptr %t225, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t230, ptr %t231
  %t232 = load { i64, [8 x i64] }, ptr %t225
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t222, { i64, [8 x i64] } %t232)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2etake(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/lower:pl"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca i64
  %l11 = alloca i1
  %l14 = alloca i1
  %l15 = alloca i1
  %l18 = alloca i1
  %l22 = alloca %"compiler/lower:pl"
  %l24 = alloca %"compiler/lower:pl"
  %l28 = alloca ptr
  %l29 = alloca i32
  %l32 = alloca %"compiler/mir:Lvalue"
  %l35 = alloca { i64, [4 x i64] }
  %l40 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t39 = alloca { i64, [4 x i64] }, align 8
  %t50 = alloca { i64, [15 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2flower_2ecompiler_2flower_3alowering_2ereleases(ptr %v0, ptr %v1, ptr %s0, ptr %t1, ptr %t2, i1 false)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l7
  br label %bb1
bb1:
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3arelPath_3e_2eLen_3ccompiler_2flower_3arelPath_3e(ptr %s0, ptr %l7)
  store i64 %t7, ptr %l9
  br label %bb2
bb2:
  %t8 = load i64, ptr %l9, !tbaa !24
  %t9 = icmp sgt i64 %t8, 0
  br i1 %t9, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb6
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l2, !tbaa !23
  %t15 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eownsStorage(ptr %v0, ptr %t11, i32 %t12)
  store i1 %t15, ptr %l14
  br label %bb5
bb5:
  %t16 = load i1, ptr %l14, !tbaa !21
  store i1 %t16, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l11, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb10
bb8:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l2, !tbaa !23
  %t22 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecounts(ptr %v0, ptr %t18, i32 %t19)
  store i1 %t22, ptr %l18
  br label %bb9
bb9:
  %t23 = load i1, ptr %l18, !tbaa !21
  store i1 %t23, ptr %l15, !tbaa !21
  br label %bb10
bb10:
  %t24 = load i1, ptr %l15, !tbaa !21
  br i1 %t24, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s1
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t30 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eplace(ptr %v0, ptr %v1, ptr %s1, ptr %t25, ptr %t26)
  store %"compiler/lower:pl" %t30, ptr %l22
  br label %bb13
bb12:
  br label %bb20
bb13:
  %t32 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s1, ptr %l22)
  store %"compiler/lower:pl" %t32, ptr %l24
  br label %bb14
bb14:
  %t33 = load %"compiler/lower:pl", ptr %l24
  store %"compiler/lower:pl" %t33, ptr %l4
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/lower:lowering", ptr %t34, i32 0, i32 10
  %t37 = load i1, ptr %t36, !tbaa !21
  br i1 %t37, label %bb15, label %bb16
bb15:
  store { i64, [4 x i64] } zeroinitializer, ptr %t39
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t39, i32 0, i32 0
  store i64 0, ptr %t40
  %t41 = load { i64, [4 x i64] }, ptr %t39
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t41, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l28, !tbaa !29
  %t44 = load i32, ptr %l2, !tbaa !23
  store i32 %t44, ptr %l29, !tbaa !23
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load %"compiler/lower:pl", ptr %l4
  %t49 = call %"compiler/mir:Lvalue" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %s1, ptr %t45, %"compiler/lower:pl" %t46)
  store %"compiler/mir:Lvalue" %t49, ptr %l32
  br label %bb18
bb18:
  store { i64, [15 x i64] } zeroinitializer, ptr %t50
  %t51 = getelementptr { i64, [15 x i64] }, ptr %t50, i32 0, i32 0
  store i64 2, ptr %t51
  %t52 = load %"compiler/mir:Lvalue", ptr %l32
  %t53 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t52, 0
  %t54 = getelementptr { i64, [15 x i64] }, ptr %t50, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t53, ptr %t54
  %t55 = load { i64, [15 x i64] }, ptr %t50
  %t56 = load %"compiler/source:Span", ptr %l3
  %t57 = load ptr, ptr %l28, !tbaa !29
  %t58 = load i32, ptr %l29, !tbaa !23
  %t61 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t57, i32 %t58, { i64, [15 x i64] } %t55, %"compiler/source:Span" %t56)
  store { i64, [4 x i64] } %t61, ptr %l35
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t62 = load { i64, [4 x i64] }, ptr %l35
  store { i64, [4 x i64] } %t62, ptr %rv
  br label %ret
bb20:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t65 = load i32, ptr %l2, !tbaa !23
  %t66 = load %"compiler/source:Span", ptr %l3
  %t71 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eread(ptr %v0, ptr %v1, ptr %t63, ptr %t64, i32 %t65, %"compiler/source:Span" %t66)
  store { i64, [4 x i64] } %t71, ptr %l40
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s0)
  %t72 = load { i64, [4 x i64] }, ptr %l40
  store { i64, [4 x i64] } %t72, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etaskType(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca { { i64, [7 x i64] }, i32 }
  %l11 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l32 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca i1
  %l45 = alloca i32
  %l46 = alloca ptr
  %l47 = alloca i1
  %l53 = alloca i32
  %l54 = alloca ptr
  %l55 = alloca i1
  %l65 = alloca { { i64, [7 x i64] }, i32 }
  %l68 = alloca ptr
  %l69 = alloca i1
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t2 = load ptr, ptr %l12, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l12, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l13, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l13, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb40
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Call", ptr %t16, i32 0, i32 0
  %t19 = load ptr, ptr %t18, !tbaa !29
  store ptr %t19, ptr %l3, !tbaa !29
  %t21 = load ptr, ptr %l3, !tbaa !29
  store ptr %t21, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t22 = load ptr, ptr %l20, !tbaa !29
  %t23 = icmp ne ptr %t22, null
  br i1 %t23, label %bb6, label %bb7
bb6:
  %t25 = load ptr, ptr %l20, !tbaa !29
  %t26 = load i64, ptr %t25, !range !{i64 0, i64 5}
  %t28 = icmp eq i64 %t26, 0
  store i1 %t28, ptr %l21, !tbaa !21
  br label %bb7
bb7:
  %t29 = load i1, ptr %l21, !tbaa !21
  br i1 %t29, label %bb8, label %bb9
bb8:
  %t30 = load ptr, ptr %l3, !tbaa !29
  %t32 = getelementptr { i64, [3 x i64] }, ptr %t30, i32 0, i32 1
  %t33 = getelementptr { i32 }, ptr %t32, i32 0, i32 0
  %t34 = load i32, ptr %t33
  store i32 %t34, ptr %l4, !tbaa !23
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/lower:lowering", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = getelementptr %"compiler/lower:Lowerer", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = load i32, ptr %l4, !tbaa !23
  %t46 = sext i32 %t44 to i64
  %t49 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t42, i64 %t46)
  store ptr %t49, ptr %l32
  br label %bb11
bb11:
  %t50 = load ptr, ptr %l32, !tbaa !29
  %t52 = getelementptr %"compiler/typed:Body", ptr %t50, i32 0, i32 2
  %t53 = load i32, ptr %t52, !tbaa !23
  store i32 %t53, ptr %rv
  br label %ret
bb12:
  %t55 = load ptr, ptr %l3, !tbaa !29
  store ptr %t55, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t56 = load ptr, ptr %l35, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb13, label %bb14
bb13:
  %t59 = load ptr, ptr %l35, !tbaa !29
  %t60 = load i64, ptr %t59, !range !{i64 0, i64 5}
  %t62 = icmp eq i64 %t60, 1
  store i1 %t62, ptr %l36, !tbaa !21
  br label %bb14
bb14:
  %t63 = load i1, ptr %l36, !tbaa !21
  br i1 %t63, label %bb15, label %bb16
bb15:
  %t64 = load ptr, ptr %l3, !tbaa !29
  %t66 = getelementptr { i64, [3 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { i64 }, ptr %t66, i32 0, i32 0
  %t68 = load i64, ptr %t67
  store i64 %t68, ptr %l5, !tbaa !24
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/lower:lowering", ptr %t70, i32 0, i32 0
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/lower:Lowerer", ptr %t73, i32 0, i32 0
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t77 = load i64, ptr %l5, !tbaa !24
  %t80 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t76, i64 %t77)
  store i32 %t80, ptr %l45
  br label %bb18
bb18:
  %t81 = load i32, ptr %l45, !tbaa !23
  store i32 %t81, ptr %rv
  br label %ret
bb19:
  %t82 = load ptr, ptr %l3, !tbaa !29
  store ptr %t82, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t83 = load ptr, ptr %l46, !tbaa !29
  %t84 = icmp ne ptr %t83, null
  br i1 %t84, label %bb20, label %bb21
bb20:
  %t86 = load ptr, ptr %l46, !tbaa !29
  %t87 = load i64, ptr %t86, !range !{i64 0, i64 5}
  %t89 = icmp eq i64 %t87, 2
  store i1 %t89, ptr %l47, !tbaa !21
  br label %bb21
bb21:
  %t90 = load i1, ptr %l47, !tbaa !21
  br i1 %t90, label %bb22, label %bb23
bb22:
  %t91 = load ptr, ptr %l3, !tbaa !29
  %t93 = getelementptr { i64, [3 x i64] }, ptr %t91, i32 0, i32 1
  %t94 = getelementptr { ptr }, ptr %t93, i32 0, i32 0
  %t95 = load ptr, ptr %t94
  store ptr %t95, ptr %l6, !tbaa !29
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t97 = load ptr, ptr %l6, !tbaa !29
  %t99 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t97)
  store i32 %t99, ptr %l53
  br label %bb25
bb25:
  %t100 = load i32, ptr %l53, !tbaa !23
  store i32 %t100, ptr %rv
  br label %ret
bb26:
  %t101 = load ptr, ptr %l3, !tbaa !29
  store ptr %t101, ptr %l54, !tbaa !29
  store i1 false, ptr %l55, !tbaa !21
  %t102 = load ptr, ptr %l54, !tbaa !29
  %t103 = icmp ne ptr %t102, null
  br i1 %t103, label %bb27, label %bb28
bb27:
  %t105 = load ptr, ptr %l54, !tbaa !29
  %t106 = load i64, ptr %t105, !range !{i64 0, i64 5}
  %t108 = icmp eq i64 %t106, 4
  store i1 %t108, ptr %l55, !tbaa !21
  br label %bb28
bb28:
  %t109 = load i1, ptr %l55, !tbaa !21
  br i1 %t109, label %bb29, label %bb30
bb29:
  %t110 = load ptr, ptr %l3, !tbaa !29
  %t112 = getelementptr { i64, [3 x i64] }, ptr %t110, i32 0, i32 1
  %t113 = getelementptr { i32, i32 }, ptr %t112, i32 0, i32 0
  %t114 = load i32, ptr %t113, !range !{i32 0, i32 2}
  store i32 %t114, ptr %l7
  %t116 = load ptr, ptr %l3, !tbaa !29
  %t118 = getelementptr { i64, [3 x i64] }, ptr %t116, i32 0, i32 1
  %t119 = getelementptr { i32, i32 }, ptr %t118, i32 0, i32 1
  %t120 = load i32, ptr %t119
  store i32 %t120, ptr %l8, !tbaa !23
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load i32, ptr %l7, !range !{i32 0, i32 2}
  %t124 = load i32, ptr %l8, !tbaa !23
  %t128 = call { { i64, [7 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2ehelperCallee(ptr %v0, ptr %t122, i32 %t123, i32 %t124)
  store { { i64, [7 x i64] }, i32 } %t128, ptr %l65
  br label %bb32
bb32:
  %t129 = load { { i64, [7 x i64] }, i32 }, ptr %l65
  store { { i64, [7 x i64] }, i32 } %t129, ptr %l9
  %t130 = getelementptr { { i64, [7 x i64] }, i32 }, ptr %l9, i32 0, i32 1
  %t131 = load i32, ptr %t130, !tbaa !23
  store i32 %t131, ptr %rv
  br label %ret
bb33:
  %t135 = load ptr, ptr %l3, !tbaa !29
  store ptr %t135, ptr %l68, !tbaa !29
  store i1 false, ptr %l69, !tbaa !21
  %t136 = load ptr, ptr %l68, !tbaa !29
  %t137 = icmp ne ptr %t136, null
  br i1 %t137, label %bb34, label %bb35
bb34:
  %t139 = load ptr, ptr %l68, !tbaa !29
  %t140 = load i64, ptr %t139, !range !{i64 0, i64 5}
  %t142 = icmp eq i64 %t140, 3
  store i1 %t142, ptr %l69, !tbaa !21
  br label %bb35
bb35:
  %t143 = load i1, ptr %l69, !tbaa !21
  br i1 %t143, label %bb36, label %bb37
bb36:
  %t144 = load ptr, ptr %l3, !tbaa !29
  %t146 = getelementptr { i64, [3 x i64] }, ptr %t144, i32 0, i32 1
  %t147 = getelementptr { i32, i64, i32 }, ptr %t146, i32 0, i32 2
  %t148 = load i32, ptr %t147
  store i32 %t148, ptr %l11, !tbaa !23
  br label %bb38
bb37:
  br label %bb39
bb38:
  %t150 = load i32, ptr %l11, !tbaa !23
  store i32 %t150, ptr %rv
  br label %ret
bb39:
  call void @__olang_check_failed(ptr @olang_loc_3b3f675a7fcfa09e_a6d8609e08455d8a)
  unreachable
bb40:
  br i1 true, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb45
bb44:
  call void @__olang_check_failed(ptr @olang_loc_a39e67f1cd7c0b1f_e499cc399c2ba1cb)
  unreachable
bb45:
  %t152 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t152, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2etempPart(ptr %v0, ptr %a0, %"compiler/mir:Lvalue" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Lvalue"
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca i64
  %l14 = alloca i1
  %l18 = alloca %"compiler/mir:Local"
  %l25 = alloca { i64, ptr }
  %l31 = alloca i64
  %l34 = alloca i64
  %l60 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca ptr
  %l70 = alloca i32
  %l71 = alloca i32
  %l72 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/mir:Lvalue" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load %"compiler/mir:Lvalue", ptr %l1
  %t3 = call i64 @compiler_2flower_2ebaseLocal(%"compiler/mir:Lvalue" %t1)
  store i64 %t3, ptr %l11
  br label %bb1
bb1:
  %t4 = load i64, ptr %l11, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t7 = icmp slt i64 %t5, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb5
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/lower:lowering", ptr %t9, i32 0, i32 3
  %t12 = getelementptr %"compiler/mir:Fn", ptr %t11, i32 0, i32 7
  %t13 = load i64, ptr %l2, !tbaa !24
  %t16 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t12, i64 %t13)
  store %"compiler/mir:Local" %t16, ptr %l18
  br label %bb4
bb4:
  %t17 = getelementptr %"compiler/mir:Local", ptr %l18, i32 0, i32 3
  %t18 = load i32, ptr %t17, !range !{i32 0, i32 4}
  %t20 = trunc i64 3 to i32
  %t21 = icmp eq i32 %t18, %t20
  %t23 = xor i1 %t21, true
  store i1 %t23, ptr %l14, !tbaa !21
  br label %bb5
bb5:
  %t25 = load i1, ptr %l14, !tbaa !21
  br i1 %t25, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load %"compiler/mir:Lvalue", ptr %l1
  %t31 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2eprojsOf(ptr %v0, ptr %s0, ptr %t27, %"compiler/mir:Lvalue" %t28)
  store { i64, ptr } %t31, ptr %l25
  br label %bb9
bb9:
  %t32 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t32, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  store i64 %t35, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t37 = load i64, ptr %l5, !tbaa !24
  %t38 = load i64, ptr %l4, !tbaa !24
  %t41 = icmp sgt i64 %t37, %t38
  br i1 %t41, label %bb10, label %bb11
bb10:
  %t43 = load i64, ptr %l6, !tbaa !24
  %t45 = icmp sgt i64 %t43, 0
  br i1 %t45, label %bb12, label %bb13
bb11:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb15
bb12:
  %t47 = load i64, ptr %l5, !tbaa !24
  %t48 = load i64, ptr %l4, !tbaa !24
  %t51 = sub i64 %t47, %t48
  %t52 = load i64, ptr %l6, !tbaa !24
  %t55 = add i64 %t51, %t52
  %t57 = sub i64 %t55, 1
  %t58 = load i64, ptr %l6, !tbaa !24
  %t61 = sdiv i64 %t57, %t58
  store i64 %t61, ptr %l34, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb14
bb14:
  %t63 = load i64, ptr %l34, !tbaa !24
  store i64 %t63, ptr %l31, !tbaa !24
  br label %bb15
bb15:
  %t64 = load i64, ptr %l31, !tbaa !24
  store i64 %t64, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb16
bb16:
  %t65 = load i64, ptr %l8, !tbaa !24
  %t66 = load i64, ptr %l7, !tbaa !24
  %t69 = icmp slt i64 %t65, %t66
  %t71 = xor i1 %t69, true
  br i1 %t71, label %bb17, label %bb18
bb17:
  br label %bb36
bb18:
  br label %bb19
bb19:
  %t73 = load i64, ptr %l4, !tbaa !24
  %t74 = load i64, ptr %l8, !tbaa !24
  %t75 = load i64, ptr %l6, !tbaa !24
  %t78 = mul i64 %t74, %t75
  %t81 = add i64 %t73, %t78
  store i64 %t81, ptr %l9, !tbaa !24
  %t83 = load i64, ptr %l9, !tbaa !24
  %t85 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = getelementptr { i64, [1 x i64] }, ptr %t86, i64 %t83
  %t88 = load { i64, [1 x i64] }, ptr %t87
  %t90 = extractvalue { i64, [1 x i64] } %t88, 0
  %t91 = icmp eq i64 %t90, 3
  br i1 %t91, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t94 = load i64, ptr %l9, !tbaa !24
  %t96 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr { i64, [1 x i64] }, ptr %t97, i64 %t94
  %t99 = load { i64, [1 x i64] }, ptr %t98
  %t101 = extractvalue { i64, [1 x i64] } %t99, 0
  %t102 = icmp eq i64 %t101, 1
  %t104 = xor i1 %t102, true
  br i1 %t104, label %bb23, label %bb24
bb23:
  %t106 = load i64, ptr %l9, !tbaa !24
  %t108 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr { i64, [1 x i64] }, ptr %t109, i64 %t106
  %t111 = load { i64, [1 x i64] }, ptr %t110
  %t113 = extractvalue { i64, [1 x i64] } %t111, 0
  %t114 = icmp eq i64 %t113, 2
  %t116 = xor i1 %t114, true
  store i1 %t116, ptr %l60, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb25
bb25:
  %t118 = load i1, ptr %l60, !tbaa !21
  br i1 %t118, label %bb26, label %bb27
bb26:
  br label %bb35
bb27:
  br label %bb28
bb28:
  %t119 = load ptr, ptr %l0, !tbaa !29
  store ptr %t119, ptr %l65, !tbaa !29
  %t120 = load ptr, ptr %l0, !tbaa !29
  store ptr %t120, ptr %l66, !tbaa !29
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load %"compiler/mir:Lvalue", ptr %l1
  %t123 = load i64, ptr %l9, !tbaa !24
  %t127 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2estepType(ptr %v0, ptr %t121, %"compiler/mir:Lvalue" %t122, i64 %t123)
  store i32 %t127, ptr %l70
  br label %bb29
bb29:
  %t128 = load ptr, ptr %l66, !tbaa !29
  %t129 = load i32, ptr %l70, !tbaa !23
  %t130 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %t128, i32 %t129)
  store i32 %t130, ptr %l71
  br label %bb30
bb30:
  %t131 = load ptr, ptr %l65, !tbaa !29
  %t132 = load i32, ptr %l71, !tbaa !23
  %t133 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2efixedLen(ptr %v0, ptr %t131, i32 %t132)
  store i64 %t133, ptr %l72
  br label %bb31
bb31:
  %t134 = load i64, ptr %l72, !tbaa !24
  %t135 = icmp slt i64 %t134, 0
  br i1 %t135, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb33:
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t138 = load i64, ptr %l8, !tbaa !24
  %t140 = add i64 %t138, 1
  store i64 %t140, ptr %l8, !tbaa !24
  br label %bb16
bb36:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2etext(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca { { i64, [4 x i64] }, i32 }
  %l16 = alloca i32
  %l17 = alloca { i64, [1 x i64] }
  %l19 = alloca i32
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l29 = alloca { i64, [4 x i64] }
  %l34 = alloca i64
  %l40 = alloca i64
  %l50 = alloca i64
  %l53 = alloca i64
  %l72 = alloca { i64, ptr }
  %l75 = alloca ptr
  %l76 = alloca i1
  %l88 = alloca { { i64, [4 x i64] }, i32 }
  %l99 = alloca ptr
  %l100 = alloca i32
  %l102 = alloca ptr
  %l106 = alloca i32
  %l115 = alloca i32
  %l116 = alloca ptr
  %l119 = alloca i32
  %l121 = alloca i32
  %l128 = alloca i64
  %l131 = alloca i64
  %l150 = alloca { i64, ptr }
  %l153 = alloca ptr
  %l154 = alloca i1
  %l164 = alloca i32
  %l177 = alloca ptr
  %l178 = alloca i1
  %l190 = alloca ptr
  %l191 = alloca i32
  %l192 = alloca { i64, [1 x i64] }
  %l196 = alloca { i64, [1 x i64] }
  %l200 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t162 = alloca { i64, [4 x i64] }, align 8
  %t186 = alloca { i64, [21 x i64] }, align 8
  %t199 = alloca { i64, [1 x i64] }, align 8
  %t305 = alloca { i64, [2 x i64] }, align 8
  %t327 = alloca { i64, [4 x i64] }, align 8
  %t339 = alloca { i64, [21 x i64] }, align 8
  %t400 = alloca { i64, [15 x i64] }, align 8
  %t420 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Text", ptr %t6, i32 0, i32 0
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l34, !tbaa !24
  %t12 = load i64, ptr %l34, !tbaa !24
  %t13 = icmp sge i64 %t12, 0
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load i64, ptr %l34, !tbaa !24
  %t16 = icmp sle i64 %t15, 230584300921369395
  br i1 %t16, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_77939bd7b34e0fa3_983f89b6cb89307)
  unreachable
bb3:
  %t18 = load i64, ptr %l34, !tbaa !24
  %t19 = mul i64 %t18, 40
  %t20 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  store { i64, ptr } %t22, ptr %l5, !tbaa !27
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Text", ptr %t24, i32 0, i32 0
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  store i64 %t29, ptr %l40, !tbaa !24
  %t30 = load i64, ptr %l40, !tbaa !24
  %t31 = icmp sge i64 %t30, 0
  br i1 %t31, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_77939bd7b34e0fa3_983f89b6cb89307)
  unreachable
bb5:
  %t33 = load i64, ptr %l40, !tbaa !24
  %t34 = icmp sle i64 %t33, 2305843009213693951
  br i1 %t34, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_cbdf5e9a9cabb32e_3680da0cabce8c12)
  unreachable
bb7:
  %t36 = load i64, ptr %l40, !tbaa !24
  %t37 = mul i64 %t36, 4
  %t38 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t37)
  %t39 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  store { i64, ptr } %t40, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t44 = getelementptr %"compiler/typed:Text", ptr %t42, i32 0, i32 0
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t45, 0
  store i64 %t47, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t49 = load i64, ptr %l8, !tbaa !24
  %t50 = load i64, ptr %l7, !tbaa !24
  %t53 = icmp sgt i64 %t49, %t50
  br i1 %t53, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_cbdf5e9a9cabb32e_3680da0cabce8c12)
  unreachable
bb9:
  %t55 = load i64, ptr %l9, !tbaa !24
  %t57 = icmp sgt i64 %t55, 0
  br i1 %t57, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l50, !tbaa !24
  br label %bb14
bb11:
  %t59 = load i64, ptr %l8, !tbaa !24
  %t60 = load i64, ptr %l7, !tbaa !24
  %t63 = sub i64 %t59, %t60
  %t64 = load i64, ptr %l9, !tbaa !24
  %t67 = add i64 %t63, %t64
  %t69 = sub i64 %t67, 1
  %t70 = load i64, ptr %l9, !tbaa !24
  %t73 = sdiv i64 %t69, %t70
  store i64 %t73, ptr %l53, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l53, !tbaa !24
  br label %bb13
bb13:
  %t75 = load i64, ptr %l53, !tbaa !24
  store i64 %t75, ptr %l50, !tbaa !24
  br label %bb14
bb14:
  %t76 = load i64, ptr %l50, !tbaa !24
  store i64 %t76, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb15
bb15:
  %t77 = load i64, ptr %l11, !tbaa !24
  %t78 = load i64, ptr %l10, !tbaa !24
  %t81 = icmp slt i64 %t77, %t78
  %t83 = xor i1 %t81, true
  br i1 %t83, label %bb16, label %bb17
bb16:
  br label %bb34
bb17:
  br label %bb18
bb18:
  %t85 = load i64, ptr %l7, !tbaa !24
  %t86 = load i64, ptr %l11, !tbaa !24
  %t87 = load i64, ptr %l9, !tbaa !24
  %t90 = mul i64 %t86, %t87
  %t93 = add i64 %t85, %t90
  store i64 %t93, ptr %l12, !tbaa !24
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr %"compiler/typed:Text", ptr %t95, i32 0, i32 0
  %t98 = load { i64, ptr }, ptr %t97, !tbaa !27
  store { i64, ptr } %t98, ptr %l72, !tbaa !27
  %t99 = load i64, ptr %l12, !tbaa !24
  %t101 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr ptr, ptr %t102, i64 %t99
  %t104 = load ptr, ptr %t103, !tbaa !39
  store ptr %t104, ptr %l13, !tbaa !29
  %t106 = load ptr, ptr %l13, !tbaa !29
  store ptr %t106, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t107 = load ptr, ptr %l75, !tbaa !29
  %t108 = icmp ne ptr %t107, null
  br i1 %t108, label %bb19, label %bb20
bb19:
  %t110 = load ptr, ptr %l75, !tbaa !29
  %t111 = load i64, ptr %t110, !range !{i64 0, i64 2}
  %t113 = icmp eq i64 %t111, 1
  store i1 %t113, ptr %l76, !tbaa !21
  br label %bb20
bb20:
  %t114 = load i1, ptr %l76, !tbaa !21
  br i1 %t114, label %bb21, label %bb22
bb21:
  %t115 = load ptr, ptr %l13, !tbaa !29
  %t117 = getelementptr { i64, [2 x i64] }, ptr %t115, i32 0, i32 1
  %t118 = getelementptr { ptr }, ptr %t117, i32 0, i32 0
  %t119 = load ptr, ptr %t118
  store ptr %t119, ptr %l14, !tbaa !29
  br label %bb23
bb22:
  br label %bb27
bb23:
  store %olang.scope zeroinitializer, ptr %s3
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load ptr, ptr %l14, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ereadHere(ptr %v0, ptr %v1, ptr %s3, ptr %s3, ptr %t121, ptr %t122, ptr null, ptr null)
  br label %bb24
bb24:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load ptr, ptr %l14, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2epieceView(ptr %v0, ptr %v1, ptr %t125, ptr %t126)
  br label %bb25
bb25:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load ptr, ptr %l14, !tbaa !29
  %t131 = load %"compiler/source:Span", ptr %l3
  %t135 = call { { i64, [4 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2epiece(ptr %v0, ptr %v1, ptr %t129, ptr %t130, %"compiler/source:Span" %t131)
  store { { i64, [4 x i64] }, i32 } %t135, ptr %l88
  br label %bb26
bb26:
  %t136 = load { { i64, [4 x i64] }, i32 }, ptr %l88
  store { { i64, [4 x i64] }, i32 } %t136, ptr %l15
  %t137 = load i64, ptr %l12, !tbaa !24
  %t138 = getelementptr { { i64, [4 x i64] }, i32 }, ptr %l15, i32 0, i32 0
  %t139 = load { i64, [4 x i64] }, ptr %t138
  %t142 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = getelementptr { i64, [4 x i64] }, ptr %t143, i64 %t137
  store { i64, [4 x i64] } %t139, ptr %t144
  %t145 = load i64, ptr %l12, !tbaa !24
  %t146 = getelementptr { { i64, [4 x i64] }, i32 }, ptr %l15, i32 0, i32 1
  %t147 = load i32, ptr %t146, !tbaa !23
  %t150 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = getelementptr i32, ptr %t151, i64 %t145
  store i32 %t147, ptr %t152, !tbaa !33
  call void @__olang_scope_close(ptr %s3)
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_459157e65df33c7e_1dfbf278634bff4a)
  unreachable
bb32:
  br label %bb33
bb33:
  %t153 = load i64, ptr %l11, !tbaa !24
  %t155 = add i64 %t153, 1
  store i64 %t155, ptr %l11, !tbaa !24
  br label %bb15
bb34:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/lower:lowering", ptr %t157, i32 0, i32 10
  %t160 = load i1, ptr %t159, !tbaa !21
  br i1 %t160, label %bb35, label %bb36
bb35:
  store { i64, [4 x i64] } zeroinitializer, ptr %t162
  %t163 = getelementptr { i64, [4 x i64] }, ptr %t162, i32 0, i32 0
  store i64 0, ptr %t163
  %t164 = load { i64, [4 x i64] }, ptr %t162
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t164, ptr %rv
  br label %ret
bb36:
  br label %bb37
bb37:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/lower:lowering", ptr %t166, i32 0, i32 3
  store ptr %t168, ptr %l99, !tbaa !29
  store i32 6, ptr %l100
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = call ptr @compiler_2flower_2ecompiler_2flower_3alowering_2etop(ptr %v0, ptr %s0, ptr %t169)
  store ptr %t171, ptr %l102
  br label %bb38
bb38:
  %t172 = load ptr, ptr %l102, !tbaa !29
  %t174 = getelementptr %"compiler/lower:level", ptr %t172, i32 0, i32 0
  %t175 = load i32, ptr %t174, !tbaa !23
  %t176 = load %"compiler/source:Span", ptr %l3
  %t177 = load ptr, ptr %l99, !tbaa !29
  %t178 = load i32, ptr %l100, !range !{i32 0, i32 7}
  %t181 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddScope(ptr %v0, ptr %t177, i32 %t178, i32 %t175, i32 -1, %"compiler/source:Span" %t176, i32 0)
  store i32 %t181, ptr %l106
  br label %bb39
bb39:
  %t182 = load i32, ptr %l106, !tbaa !23
  store i32 %t182, ptr %l16, !tbaa !23
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = load %"compiler/source:Span", ptr %l3
  %t185 = load i32, ptr %l16, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t186
  %t187 = getelementptr { i64, [21 x i64] }, ptr %t186, i32 0, i32 0
  store i64 3, ptr %t187
  %t189 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t184, 0
  %t191 = insertvalue { %"compiler/source:Span", i32 } %t189, i32 %t185, 1
  %t192 = getelementptr { i64, [21 x i64] }, ptr %t186, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t191, ptr %t192
  %t193 = load { i64, [21 x i64] }, ptr %t186
  %t195 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t193, ptr %t195
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t183, ptr %t195)
  br label %bb40
bb40:
  %t198 = load i32, ptr %l16, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t199
  %t200 = getelementptr { i64, [1 x i64] }, ptr %t199, i32 0, i32 0
  store i64 0, ptr %t200
  %t202 = insertvalue { i32 } undef, i32 %t198, 0
  %t203 = getelementptr { i64, [1 x i64] }, ptr %t199, i32 0, i32 1
  store { i32 } %t202, ptr %t203
  %t204 = load { i64, [1 x i64] }, ptr %t199
  store { i64, [1 x i64] } %t204, ptr %l17
  %t206 = load ptr, ptr %l4, !tbaa !29
  %t208 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t206, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store i32 %t208, ptr %l115
  br label %bb41
bb41:
  %t209 = load i32, ptr %l115, !tbaa !23
  %t210 = load ptr, ptr %l4, !tbaa !29
  store ptr %t210, ptr %l116, !tbaa !29
  %t211 = load ptr, ptr %l4, !tbaa !29
  %t215 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t211, i32 %t209, i32 0)
  store i32 %t215, ptr %l119
  br label %bb42
bb42:
  %t216 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t217 = load ptr, ptr %l116, !tbaa !29
  %t218 = load i32, ptr %l119, !tbaa !23
  %t220 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t217, i32 %t218, i64 %t216)
  store i32 %t220, ptr %l121
  br label %bb43
bb43:
  %t221 = load i32, ptr %l121, !tbaa !23
  store i32 %t221, ptr %l19, !tbaa !23
  store i64 0, ptr %l20, !tbaa !24
  %t222 = load ptr, ptr %l1, !tbaa !29
  %t224 = getelementptr %"compiler/typed:Text", ptr %t222, i32 0, i32 0
  %t225 = load { i64, ptr }, ptr %t224, !tbaa !27
  %t227 = extractvalue { i64, ptr } %t225, 0
  store i64 %t227, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t229 = load i64, ptr %l21, !tbaa !24
  %t230 = load i64, ptr %l20, !tbaa !24
  %t233 = icmp sgt i64 %t229, %t230
  br i1 %t233, label %bb44, label %bb45
bb44:
  %t235 = load i64, ptr %l22, !tbaa !24
  %t237 = icmp sgt i64 %t235, 0
  br i1 %t237, label %bb46, label %bb47
bb45:
  store i64 0, ptr %l128, !tbaa !24
  br label %bb49
bb46:
  %t239 = load i64, ptr %l21, !tbaa !24
  %t240 = load i64, ptr %l20, !tbaa !24
  %t243 = sub i64 %t239, %t240
  %t244 = load i64, ptr %l22, !tbaa !24
  %t247 = add i64 %t243, %t244
  %t249 = sub i64 %t247, 1
  %t250 = load i64, ptr %l22, !tbaa !24
  %t253 = sdiv i64 %t249, %t250
  store i64 %t253, ptr %l131, !tbaa !24
  br label %bb48
bb47:
  store i64 0, ptr %l131, !tbaa !24
  br label %bb48
bb48:
  %t255 = load i64, ptr %l131, !tbaa !24
  store i64 %t255, ptr %l128, !tbaa !24
  br label %bb49
bb49:
  %t256 = load i64, ptr %l128, !tbaa !24
  store i64 %t256, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb50
bb50:
  %t257 = load i64, ptr %l24, !tbaa !24
  %t258 = load i64, ptr %l23, !tbaa !24
  %t261 = icmp slt i64 %t257, %t258
  %t263 = xor i1 %t261, true
  br i1 %t263, label %bb51, label %bb52
bb51:
  br label %bb71
bb52:
  br label %bb53
bb53:
  %t265 = load i64, ptr %l20, !tbaa !24
  %t266 = load i64, ptr %l24, !tbaa !24
  %t267 = load i64, ptr %l22, !tbaa !24
  %t270 = mul i64 %t266, %t267
  %t273 = add i64 %t265, %t270
  store i64 %t273, ptr %l25, !tbaa !24
  %t275 = load ptr, ptr %l1, !tbaa !29
  %t277 = getelementptr %"compiler/typed:Text", ptr %t275, i32 0, i32 0
  %t278 = load { i64, ptr }, ptr %t277, !tbaa !27
  store { i64, ptr } %t278, ptr %l150, !tbaa !27
  %t279 = load i64, ptr %l25, !tbaa !24
  %t281 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t282 = load ptr, ptr %t281, !tbaa !27
  %t283 = getelementptr ptr, ptr %t282, i64 %t279
  %t284 = load ptr, ptr %t283, !tbaa !39
  store ptr %t284, ptr %l26, !tbaa !29
  %t286 = load ptr, ptr %l26, !tbaa !29
  store ptr %t286, ptr %l153, !tbaa !29
  store i1 false, ptr %l154, !tbaa !21
  %t287 = load ptr, ptr %l153, !tbaa !29
  %t288 = icmp ne ptr %t287, null
  br i1 %t288, label %bb54, label %bb55
bb54:
  %t290 = load ptr, ptr %l153, !tbaa !29
  %t291 = load i64, ptr %t290, !range !{i64 0, i64 2}
  %t293 = icmp eq i64 %t291, 0
  store i1 %t293, ptr %l154, !tbaa !21
  br label %bb55
bb55:
  %t294 = load i1, ptr %l154, !tbaa !21
  br i1 %t294, label %bb56, label %bb57
bb56:
  %t295 = load ptr, ptr %l26, !tbaa !29
  %t297 = getelementptr { i64, [2 x i64] }, ptr %t295, i32 0, i32 1
  %t298 = getelementptr { { i64, ptr } }, ptr %t297, i32 0, i32 0
  %t299 = load { i64, ptr }, ptr %t298
  store { i64, ptr } %t299, ptr %l27, !tbaa !27
  br label %bb58
bb57:
  br label %bb61
bb58:
  store %olang.scope zeroinitializer, ptr %s9
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t303 = getelementptr %"compiler/lower:lowering", ptr %t301, i32 0, i32 3
  %t304 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, [2 x i64] } zeroinitializer, ptr %t305
  %t306 = getelementptr { i64, [2 x i64] }, ptr %t305, i32 0, i32 0
  store i64 1, ptr %t306
  %t308 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t304, 0
  %t309 = getelementptr { i64, [2 x i64] }, ptr %t305, i32 0, i32 1
  store { { i64, ptr } } %t308, ptr %t309
  %t310 = load { i64, [2 x i64] }, ptr %t305
  %t312 = call ptr @__olang_scope_alloc_a(ptr %s9, i64 24, i64 8)
  store { i64, [2 x i64] } %t310, ptr %t312
  %t315 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddConst(ptr %v0, ptr %s9, ptr %t303, ptr %t312)
  store i32 %t315, ptr %l164
  br label %bb59
bb59:
  %t316 = load i32, ptr %l164, !tbaa !23
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t318 = load %"compiler/source:Span", ptr %l3
  %t319 = load { i64, [1 x i64] }, ptr %l17
  %t320 = load i32, ptr %l19, !tbaa !23
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t324 = getelementptr %"compiler/lower:lowering", ptr %t322, i32 0, i32 7
  %t325 = load i64, ptr %t324, !tbaa !24
  %t326 = load %"compiler/source:Span", ptr %l3
  store { i64, [4 x i64] } zeroinitializer, ptr %t327
  %t328 = getelementptr { i64, [4 x i64] }, ptr %t327, i32 0, i32 0
  store i64 3, ptr %t328
  %t330 = insertvalue { i32, i32, i64, %"compiler/source:Span" } undef, i32 %t320, 0
  %t332 = insertvalue { i32, i32, i64, %"compiler/source:Span" } %t330, i32 %t316, 1
  %t334 = insertvalue { i32, i32, i64, %"compiler/source:Span" } %t332, i64 %t325, 2
  %t336 = insertvalue { i32, i32, i64, %"compiler/source:Span" } %t334, %"compiler/source:Span" %t326, 3
  %t337 = getelementptr { i64, [4 x i64] }, ptr %t327, i32 0, i32 1
  store { i32, i32, i64, %"compiler/source:Span" } %t336, ptr %t337
  %t338 = load { i64, [4 x i64] }, ptr %t327
  store { i64, [21 x i64] } zeroinitializer, ptr %t339
  %t340 = getelementptr { i64, [21 x i64] }, ptr %t339, i32 0, i32 0
  store i64 8, ptr %t340
  %t342 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t318, 0
  %t344 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t342, { i64, [1 x i64] } %t319, 1
  %t346 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t344, i32 0, 2
  %t348 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t346, { i64, [4 x i64] } %t338, 3
  %t349 = getelementptr { i64, [21 x i64] }, ptr %t339, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t348, ptr %t349
  %t350 = load { i64, [21 x i64] }, ptr %t339
  %t352 = call ptr @__olang_scope_alloc_a(ptr %s9, i64 176, i64 8)
  store { i64, [21 x i64] } %t350, ptr %t352
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s9, ptr %t317, ptr %t352)
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s9)
  br label %bb69
bb61:
  %t355 = load ptr, ptr %l26, !tbaa !29
  store ptr %t355, ptr %l177, !tbaa !29
  store i1 false, ptr %l178, !tbaa !21
  %t356 = load ptr, ptr %l177, !tbaa !29
  %t357 = icmp ne ptr %t356, null
  br i1 %t357, label %bb62, label %bb63
bb62:
  %t359 = load ptr, ptr %l177, !tbaa !29
  %t360 = load i64, ptr %t359, !range !{i64 0, i64 2}
  %t362 = icmp eq i64 %t360, 1
  store i1 %t362, ptr %l178, !tbaa !21
  br label %bb63
bb63:
  %t363 = load i1, ptr %l178, !tbaa !21
  br i1 %t363, label %bb64, label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb68
bb66:
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t365 = load { i64, [1 x i64] }, ptr %l17
  %t366 = load i64, ptr %l25, !tbaa !24
  %t368 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t369 = load ptr, ptr %t368, !tbaa !27
  %t370 = getelementptr { i64, [4 x i64] }, ptr %t369, i64 %t366
  %t371 = load { i64, [4 x i64] }, ptr %t370
  %t372 = load i64, ptr %l25, !tbaa !24
  %t374 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t375 = load ptr, ptr %t374, !tbaa !27
  %t376 = getelementptr i32, ptr %t375, i64 %t372
  %t377 = load i32, ptr %t376, !tbaa !33
  %t378 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2erender(ptr %v0, ptr %t364, { i64, [1 x i64] } %t365, { i64, [4 x i64] } %t371, i32 %t377, %"compiler/source:Span" %t378)
  br label %bb67
bb67:
  br label %bb69
bb68:
  call void @__olang_check_failed(ptr @olang_loc_3db4c7c32145727f_d6a525f06b7a698b)
  unreachable
bb69:
  br label %bb70
bb70:
  %t384 = load i64, ptr %l24, !tbaa !24
  %t386 = add i64 %t384, 1
  store i64 %t386, ptr %l24, !tbaa !24
  br label %bb50
bb71:
  %t388 = load ptr, ptr %l0, !tbaa !29
  store ptr %t388, ptr %l190, !tbaa !29
  %t389 = load i32, ptr %l2, !tbaa !23
  store i32 %t389, ptr %l191, !tbaa !23
  %t390 = load { i64, [1 x i64] }, ptr %l17
  store { i64, [1 x i64] } %t390, ptr %l192
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t392 = load ptr, ptr %l1, !tbaa !29
  %t394 = getelementptr %"compiler/typed:Text", ptr %t392, i32 0, i32 1
  %t395 = load i32, ptr %t394, !tbaa !23
  %t398 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ebuilt(ptr %v0, ptr %t391, i32 %t395)
  store { i64, [1 x i64] } %t398, ptr %l196
  br label %bb72
bb72:
  %t399 = load i32, ptr %l2, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t400
  %t401 = getelementptr { i64, [15 x i64] }, ptr %t400, i32 0, i32 0
  store i64 12, ptr %t401
  %t402 = load { i64, [1 x i64] }, ptr %l192
  %t403 = insertvalue { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 } undef, { i64, [1 x i64] } %t402, 0
  %t404 = load { i64, [1 x i64] }, ptr %l196
  %t405 = insertvalue { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 } %t403, { i64, [1 x i64] } %t404, 1
  %t407 = insertvalue { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 } %t405, i32 %t399, 2
  %t408 = getelementptr { i64, [15 x i64] }, ptr %t400, i32 0, i32 1
  store { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 } %t407, ptr %t408
  %t409 = load { i64, [15 x i64] }, ptr %t400
  %t410 = load %"compiler/source:Span", ptr %l3
  %t411 = load ptr, ptr %l190, !tbaa !29
  %t412 = load i32, ptr %l191, !tbaa !23
  %t415 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t411, i32 %t412, { i64, [15 x i64] } %t409, %"compiler/source:Span" %t410)
  store { i64, [4 x i64] } %t415, ptr %l200
  br label %bb73
bb73:
  %t416 = load { i64, [4 x i64] }, ptr %l200
  store { i64, [4 x i64] } %t416, ptr %l29
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t418 = load %"compiler/source:Span", ptr %l3
  %t419 = load i32, ptr %l16, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t420
  %t421 = getelementptr { i64, [21 x i64] }, ptr %t420, i32 0, i32 0
  store i64 4, ptr %t421
  %t423 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t418, 0
  %t425 = insertvalue { %"compiler/source:Span", i32 } %t423, i32 %t419, 1
  %t426 = getelementptr { i64, [21 x i64] }, ptr %t420, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t425, ptr %t426
  %t427 = load { i64, [21 x i64] }, ptr %t420
  %t429 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t427, ptr %t429
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t417, ptr %t429)
  br label %bb74
bb74:
  %t432 = load { i64, [4 x i64] }, ptr %l29
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t432, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2evalue(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca %"compiler/source:Span"
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca %"compiler/source:Span"
  %l18 = alloca i32
  %l19 = alloca ptr
  %l20 = alloca %"compiler/source:Span"
  %l21 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca %"compiler/source:Span"
  %l24 = alloca i32
  %l25 = alloca ptr
  %l26 = alloca %"compiler/source:Span"
  %l27 = alloca i32
  %l28 = alloca ptr
  %l29 = alloca %"compiler/source:Span"
  %l30 = alloca i32
  %l31 = alloca i32
  %l32 = alloca i32
  %l33 = alloca { i64, ptr }
  %l34 = alloca %"compiler/source:Span"
  %l35 = alloca i32
  %l36 = alloca ptr
  %l37 = alloca %"compiler/source:Span"
  %l38 = alloca i32
  %l39 = alloca ptr
  %l40 = alloca ptr
  %l41 = alloca %"compiler/source:Span"
  %l42 = alloca i32
  %l43 = alloca ptr
  %l44 = alloca %"compiler/source:Span"
  %l45 = alloca ptr
  %l46 = alloca %"compiler/source:Span"
  %l47 = alloca i32
  %l48 = alloca ptr
  %l49 = alloca %"compiler/source:Span"
  %l50 = alloca i32
  %l51 = alloca ptr
  %l52 = alloca i64
  %l53 = alloca ptr
  %l55 = alloca i32
  %l59 = alloca ptr
  %l61 = alloca %"compiler/source:Span"
  %l63 = alloca { i64, [4 x i64] }
  %l64 = alloca ptr
  %l65 = alloca i1
  %l75 = alloca ptr
  %l76 = alloca i1
  %l85 = alloca i32
  %l89 = alloca i32
  %l94 = alloca ptr
  %l95 = alloca i1
  %l108 = alloca { i64, [4 x i64] }
  %l109 = alloca ptr
  %l110 = alloca i1
  %l123 = alloca { i64, [4 x i64] }
  %l124 = alloca ptr
  %l125 = alloca i1
  %l138 = alloca { i64, [4 x i64] }
  %l139 = alloca ptr
  %l140 = alloca i1
  %l153 = alloca { i64, [4 x i64] }
  %l154 = alloca ptr
  %l155 = alloca i1
  %l168 = alloca { i64, [4 x i64] }
  %l169 = alloca ptr
  %l170 = alloca i1
  %l183 = alloca { i64, [4 x i64] }
  %l184 = alloca ptr
  %l185 = alloca i1
  %l198 = alloca { i64, [4 x i64] }
  %l199 = alloca ptr
  %l200 = alloca i1
  %l219 = alloca { i64, [4 x i64] }
  %l220 = alloca ptr
  %l221 = alloca i1
  %l234 = alloca { i64, [4 x i64] }
  %l235 = alloca ptr
  %l236 = alloca i1
  %l249 = alloca { i64, [4 x i64] }
  %l250 = alloca ptr
  %l251 = alloca i1
  %l258 = alloca { i64, [4 x i64] }
  %l259 = alloca ptr
  %l260 = alloca i1
  %l273 = alloca { i64, [4 x i64] }
  %l274 = alloca ptr
  %l275 = alloca i1
  %l286 = alloca { i64, [4 x i64] }
  %l287 = alloca ptr
  %l288 = alloca i1
  %l301 = alloca { i64, [4 x i64] }
  %l302 = alloca ptr
  %l303 = alloca i1
  %l316 = alloca { i64, [4 x i64] }
  %l317 = alloca ptr
  %l318 = alloca i1
  %l328 = alloca { i64, [4 x i64] }
  %s1 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t17 = alloca { i64, [4 x i64] }, align 8
  %t44 = alloca { i64, [4 x i64] }, align 8
  %t93 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t1)
  store i32 %t3, ptr %l55
  br label %bb1
bb1:
  %t4 = load i32, ptr %l55, !tbaa !23
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t9 = icmp eq i32 %t4, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l59, !tbaa !29
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t12)
  store %"compiler/source:Span" %t14, ptr %l61
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t15 = load ptr, ptr %l59, !tbaa !29
  %t16 = load %"compiler/source:Span", ptr %l61
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egap(ptr %v0, ptr %s1, ptr %t15, %"compiler/source:Span" %t16, { i64, ptr } { i64 53, ptr getelementptr inbounds (<{ i64, [53 x i8] }>, ptr @.d14, i32 0, i32 1) })
  br label %bb5
bb5:
  store { i64, [4 x i64] } zeroinitializer, ptr %t17
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t17, i32 0, i32 0
  store i64 0, ptr %t18
  %t19 = load { i64, [4 x i64] }, ptr %t17
  call void @__olang_scope_close(ptr %s1)
  store { i64, [4 x i64] } %t19, ptr %rv
  br label %ret
bb6:
  %t21 = load ptr, ptr %l1, !tbaa !29
  store ptr %t21, ptr %l64, !tbaa !29
  store i1 false, ptr %l65, !tbaa !21
  %t22 = load ptr, ptr %l64, !tbaa !29
  %t23 = icmp ne ptr %t22, null
  br i1 %t23, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l64, !tbaa !29
  %t26 = load i64, ptr %t25, !range !{i64 0, i64 18}
  %t28 = icmp eq i64 %t26, 0
  store i1 %t28, ptr %l65, !tbaa !21
  br label %bb8
bb8:
  %t29 = load i1, ptr %l65, !tbaa !21
  br i1 %t29, label %bb9, label %bb10
bb9:
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t32 = getelementptr { i64, [5 x i64] }, ptr %t30, i32 0, i32 1
  %t33 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t32, i32 0, i32 1
  %t34 = load i32, ptr %t33
  store i32 %t34, ptr %l3, !tbaa !23
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t38 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t38, i32 0, i32 2
  %t40 = load i64, ptr %t39
  store i64 %t40, ptr %l4, !tbaa !24
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t42 = load i32, ptr %l3, !tbaa !23
  %t43 = load i64, ptr %l4, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t44
  %t45 = getelementptr { i64, [4 x i64] }, ptr %t44, i32 0, i32 0
  store i64 2, ptr %t45
  %t47 = insertvalue { i32, i64 } undef, i32 %t42, 0
  %t49 = insertvalue { i32, i64 } %t47, i64 %t43, 1
  %t50 = getelementptr { i64, [4 x i64] }, ptr %t44, i32 0, i32 1
  store { i32, i64 } %t49, ptr %t50
  %t51 = load { i64, [4 x i64] }, ptr %t44
  store { i64, [4 x i64] } %t51, ptr %l63
  br label %bb132
bb12:
  %t53 = load ptr, ptr %l1, !tbaa !29
  store ptr %t53, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t54 = load ptr, ptr %l75, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb13, label %bb14
bb13:
  %t57 = load ptr, ptr %l75, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 18}
  %t60 = icmp eq i64 %t58, 1
  store i1 %t60, ptr %l76, !tbaa !21
  br label %bb14
bb14:
  %t61 = load i1, ptr %l76, !tbaa !21
  br i1 %t61, label %bb15, label %bb16
bb15:
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr { i64, [5 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t64, i32 0, i32 0
  %t66 = load %"compiler/source:Span", ptr %t65
  store %"compiler/source:Span" %t66, ptr %l5
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr { i64, [5 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t70, i32 0, i32 1
  %t72 = load i32, ptr %t71
  store i32 %t72, ptr %l6, !tbaa !23
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [5 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t76, i32 0, i32 3
  %t78 = load ptr, ptr %t77
  store ptr %t78, ptr %l7, !tbaa !29
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t80 = load i32, ptr %l6, !tbaa !23
  store i32 %t80, ptr %l85, !tbaa !23
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/lower:lowering", ptr %t81, i32 0, i32 3
  %t84 = load ptr, ptr %l7, !tbaa !29
  %t87 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddConst(ptr %v0, ptr %v1, ptr %t83, ptr %t84)
  store i32 %t87, ptr %l89
  br label %bb18
bb18:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/lower:lowering", ptr %t88, i32 0, i32 7
  %t91 = load i64, ptr %t90, !tbaa !24
  %t92 = load %"compiler/source:Span", ptr %l5
  store { i64, [4 x i64] } zeroinitializer, ptr %t93
  %t94 = getelementptr { i64, [4 x i64] }, ptr %t93, i32 0, i32 0
  store i64 3, ptr %t94
  %t95 = load i32, ptr %l85, !tbaa !23
  %t96 = insertvalue { i32, i32, i64, %"compiler/source:Span" } undef, i32 %t95, 0
  %t97 = load i32, ptr %l89, !tbaa !23
  %t98 = insertvalue { i32, i32, i64, %"compiler/source:Span" } %t96, i32 %t97, 1
  %t100 = insertvalue { i32, i32, i64, %"compiler/source:Span" } %t98, i64 %t91, 2
  %t102 = insertvalue { i32, i32, i64, %"compiler/source:Span" } %t100, %"compiler/source:Span" %t92, 3
  %t103 = getelementptr { i64, [4 x i64] }, ptr %t93, i32 0, i32 1
  store { i32, i32, i64, %"compiler/source:Span" } %t102, ptr %t103
  %t104 = load { i64, [4 x i64] }, ptr %t93
  store { i64, [4 x i64] } %t104, ptr %l63
  br label %bb132
bb19:
  %t106 = load ptr, ptr %l1, !tbaa !29
  store ptr %t106, ptr %l94, !tbaa !29
  store i1 false, ptr %l95, !tbaa !21
  %t107 = load ptr, ptr %l94, !tbaa !29
  %t108 = icmp ne ptr %t107, null
  br i1 %t108, label %bb20, label %bb21
bb20:
  %t110 = load ptr, ptr %l94, !tbaa !29
  %t111 = load i64, ptr %t110, !range !{i64 0, i64 18}
  %t113 = icmp eq i64 %t111, 2
  store i1 %t113, ptr %l95, !tbaa !21
  br label %bb21
bb21:
  %t114 = load i1, ptr %l95, !tbaa !21
  br i1 %t114, label %bb22, label %bb23
bb22:
  %t115 = load ptr, ptr %l1, !tbaa !29
  %t117 = getelementptr { i64, [5 x i64] }, ptr %t115, i32 0, i32 1
  %t118 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t117, i32 0, i32 0
  %t119 = load %"compiler/source:Span", ptr %t118
  store %"compiler/source:Span" %t119, ptr %l8
  %t121 = load ptr, ptr %l1, !tbaa !29
  %t123 = getelementptr { i64, [5 x i64] }, ptr %t121, i32 0, i32 1
  %t124 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t123, i32 0, i32 1
  %t125 = load i32, ptr %t124
  store i32 %t125, ptr %l9, !tbaa !23
  %t127 = load ptr, ptr %l1, !tbaa !29
  %t129 = getelementptr { i64, [5 x i64] }, ptr %t127, i32 0, i32 1
  %t130 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t129, i32 0, i32 2
  %t131 = load ptr, ptr %t130
  store ptr %t131, ptr %l10, !tbaa !29
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load ptr, ptr %l10, !tbaa !29
  %t135 = load i32, ptr %l9, !tbaa !23
  %t136 = load %"compiler/source:Span", ptr %l8
  %t141 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eread(ptr %v0, ptr %v1, ptr %t133, ptr %t134, i32 %t135, %"compiler/source:Span" %t136)
  store { i64, [4 x i64] } %t141, ptr %l108
  br label %bb25
bb25:
  %t142 = load { i64, [4 x i64] }, ptr %l108
  store { i64, [4 x i64] } %t142, ptr %l63
  br label %bb132
bb26:
  %t143 = load ptr, ptr %l1, !tbaa !29
  store ptr %t143, ptr %l109, !tbaa !29
  store i1 false, ptr %l110, !tbaa !21
  %t144 = load ptr, ptr %l109, !tbaa !29
  %t145 = icmp ne ptr %t144, null
  br i1 %t145, label %bb27, label %bb28
bb27:
  %t147 = load ptr, ptr %l109, !tbaa !29
  %t148 = load i64, ptr %t147, !range !{i64 0, i64 18}
  %t150 = icmp eq i64 %t148, 3
  store i1 %t150, ptr %l110, !tbaa !21
  br label %bb28
bb28:
  %t151 = load i1, ptr %l110, !tbaa !21
  br i1 %t151, label %bb29, label %bb30
bb29:
  %t152 = load ptr, ptr %l1, !tbaa !29
  %t154 = getelementptr { i64, [5 x i64] }, ptr %t152, i32 0, i32 1
  %t155 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t154, i32 0, i32 0
  %t156 = load %"compiler/source:Span", ptr %t155
  store %"compiler/source:Span" %t156, ptr %l11
  %t158 = load ptr, ptr %l1, !tbaa !29
  %t160 = getelementptr { i64, [5 x i64] }, ptr %t158, i32 0, i32 1
  %t161 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t160, i32 0, i32 1
  %t162 = load i32, ptr %t161
  store i32 %t162, ptr %l12, !tbaa !23
  %t164 = load ptr, ptr %l1, !tbaa !29
  %t166 = getelementptr { i64, [5 x i64] }, ptr %t164, i32 0, i32 1
  %t167 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t166, i32 0, i32 2
  %t168 = load ptr, ptr %t167
  store ptr %t168, ptr %l13, !tbaa !29
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load ptr, ptr %l13, !tbaa !29
  %t172 = load i32, ptr %l12, !tbaa !23
  %t173 = load %"compiler/source:Span", ptr %l11
  %t178 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eborrow(ptr %v0, ptr %v1, ptr %t170, ptr %t171, i32 %t172, %"compiler/source:Span" %t173)
  store { i64, [4 x i64] } %t178, ptr %l123
  br label %bb32
bb32:
  %t179 = load { i64, [4 x i64] }, ptr %l123
  store { i64, [4 x i64] } %t179, ptr %l63
  br label %bb132
bb33:
  %t180 = load ptr, ptr %l1, !tbaa !29
  store ptr %t180, ptr %l124, !tbaa !29
  store i1 false, ptr %l125, !tbaa !21
  %t181 = load ptr, ptr %l124, !tbaa !29
  %t182 = icmp ne ptr %t181, null
  br i1 %t182, label %bb34, label %bb35
bb34:
  %t184 = load ptr, ptr %l124, !tbaa !29
  %t185 = load i64, ptr %t184, !range !{i64 0, i64 18}
  %t187 = icmp eq i64 %t185, 4
  store i1 %t187, ptr %l125, !tbaa !21
  br label %bb35
bb35:
  %t188 = load i1, ptr %l125, !tbaa !21
  br i1 %t188, label %bb36, label %bb37
bb36:
  %t189 = load ptr, ptr %l1, !tbaa !29
  %t191 = getelementptr { i64, [5 x i64] }, ptr %t189, i32 0, i32 1
  %t192 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t191, i32 0, i32 0
  %t193 = load %"compiler/source:Span", ptr %t192
  store %"compiler/source:Span" %t193, ptr %l14
  %t195 = load ptr, ptr %l1, !tbaa !29
  %t197 = getelementptr { i64, [5 x i64] }, ptr %t195, i32 0, i32 1
  %t198 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t197, i32 0, i32 1
  %t199 = load i32, ptr %t198
  store i32 %t199, ptr %l15, !tbaa !23
  %t201 = load ptr, ptr %l1, !tbaa !29
  %t203 = getelementptr { i64, [5 x i64] }, ptr %t201, i32 0, i32 1
  %t204 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t203, i32 0, i32 2
  %t205 = load ptr, ptr %t204
  store ptr %t205, ptr %l16, !tbaa !29
  br label %bb38
bb37:
  br label %bb40
bb38:
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load ptr, ptr %l16, !tbaa !29
  %t209 = load i32, ptr %l15, !tbaa !23
  %t210 = load %"compiler/source:Span", ptr %l14
  %t215 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2etake(ptr %v0, ptr %v1, ptr %t207, ptr %t208, i32 %t209, %"compiler/source:Span" %t210)
  store { i64, [4 x i64] } %t215, ptr %l138
  br label %bb39
bb39:
  %t216 = load { i64, [4 x i64] }, ptr %l138
  store { i64, [4 x i64] } %t216, ptr %l63
  br label %bb132
bb40:
  %t217 = load ptr, ptr %l1, !tbaa !29
  store ptr %t217, ptr %l139, !tbaa !29
  store i1 false, ptr %l140, !tbaa !21
  %t218 = load ptr, ptr %l139, !tbaa !29
  %t219 = icmp ne ptr %t218, null
  br i1 %t219, label %bb41, label %bb42
bb41:
  %t221 = load ptr, ptr %l139, !tbaa !29
  %t222 = load i64, ptr %t221, !range !{i64 0, i64 18}
  %t224 = icmp eq i64 %t222, 5
  store i1 %t224, ptr %l140, !tbaa !21
  br label %bb42
bb42:
  %t225 = load i1, ptr %l140, !tbaa !21
  br i1 %t225, label %bb43, label %bb44
bb43:
  %t226 = load ptr, ptr %l1, !tbaa !29
  %t228 = getelementptr { i64, [5 x i64] }, ptr %t226, i32 0, i32 1
  %t229 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t228, i32 0, i32 0
  %t230 = load %"compiler/source:Span", ptr %t229
  store %"compiler/source:Span" %t230, ptr %l17
  %t232 = load ptr, ptr %l1, !tbaa !29
  %t234 = getelementptr { i64, [5 x i64] }, ptr %t232, i32 0, i32 1
  %t235 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t234, i32 0, i32 1
  %t236 = load i32, ptr %t235
  store i32 %t236, ptr %l18, !tbaa !23
  %t238 = load ptr, ptr %l1, !tbaa !29
  %t240 = getelementptr { i64, [5 x i64] }, ptr %t238, i32 0, i32 1
  %t241 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t240, i32 0, i32 2
  %t242 = load ptr, ptr %t241
  store ptr %t242, ptr %l19, !tbaa !29
  br label %bb45
bb44:
  br label %bb47
bb45:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t245 = load ptr, ptr %l19, !tbaa !29
  %t246 = load i32, ptr %l18, !tbaa !23
  %t247 = load %"compiler/source:Span", ptr %l17
  %t252 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2epromote(ptr %v0, ptr %v1, ptr %t244, ptr %t245, i32 %t246, %"compiler/source:Span" %t247)
  store { i64, [4 x i64] } %t252, ptr %l153
  br label %bb46
bb46:
  %t253 = load { i64, [4 x i64] }, ptr %l153
  store { i64, [4 x i64] } %t253, ptr %l63
  br label %bb132
bb47:
  %t254 = load ptr, ptr %l1, !tbaa !29
  store ptr %t254, ptr %l154, !tbaa !29
  store i1 false, ptr %l155, !tbaa !21
  %t255 = load ptr, ptr %l154, !tbaa !29
  %t256 = icmp ne ptr %t255, null
  br i1 %t256, label %bb48, label %bb49
bb48:
  %t258 = load ptr, ptr %l154, !tbaa !29
  %t259 = load i64, ptr %t258, !range !{i64 0, i64 18}
  %t261 = icmp eq i64 %t259, 6
  store i1 %t261, ptr %l155, !tbaa !21
  br label %bb49
bb49:
  %t262 = load i1, ptr %l155, !tbaa !21
  br i1 %t262, label %bb50, label %bb51
bb50:
  %t263 = load ptr, ptr %l1, !tbaa !29
  %t265 = getelementptr { i64, [5 x i64] }, ptr %t263, i32 0, i32 1
  %t266 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t265, i32 0, i32 0
  %t267 = load %"compiler/source:Span", ptr %t266
  store %"compiler/source:Span" %t267, ptr %l20
  %t269 = load ptr, ptr %l1, !tbaa !29
  %t271 = getelementptr { i64, [5 x i64] }, ptr %t269, i32 0, i32 1
  %t272 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t271, i32 0, i32 1
  %t273 = load i32, ptr %t272
  store i32 %t273, ptr %l21, !tbaa !23
  %t275 = load ptr, ptr %l1, !tbaa !29
  %t277 = getelementptr { i64, [5 x i64] }, ptr %t275, i32 0, i32 1
  %t278 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t277, i32 0, i32 2
  %t279 = load ptr, ptr %t278
  store ptr %t279, ptr %l22, !tbaa !29
  br label %bb52
bb51:
  br label %bb54
bb52:
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t282 = load ptr, ptr %l22, !tbaa !29
  %t283 = load i32, ptr %l21, !tbaa !23
  %t284 = load %"compiler/source:Span", ptr %l20
  %t289 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ecall(ptr %v0, ptr %v1, ptr %t281, ptr %t282, i32 %t283, %"compiler/source:Span" %t284)
  store { i64, [4 x i64] } %t289, ptr %l168
  br label %bb53
bb53:
  %t290 = load { i64, [4 x i64] }, ptr %l168
  store { i64, [4 x i64] } %t290, ptr %l63
  br label %bb132
bb54:
  %t291 = load ptr, ptr %l1, !tbaa !29
  store ptr %t291, ptr %l169, !tbaa !29
  store i1 false, ptr %l170, !tbaa !21
  %t292 = load ptr, ptr %l169, !tbaa !29
  %t293 = icmp ne ptr %t292, null
  br i1 %t293, label %bb55, label %bb56
bb55:
  %t295 = load ptr, ptr %l169, !tbaa !29
  %t296 = load i64, ptr %t295, !range !{i64 0, i64 18}
  %t298 = icmp eq i64 %t296, 7
  store i1 %t298, ptr %l170, !tbaa !21
  br label %bb56
bb56:
  %t299 = load i1, ptr %l170, !tbaa !21
  br i1 %t299, label %bb57, label %bb58
bb57:
  %t300 = load ptr, ptr %l1, !tbaa !29
  %t302 = getelementptr { i64, [5 x i64] }, ptr %t300, i32 0, i32 1
  %t303 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t302, i32 0, i32 0
  %t304 = load %"compiler/source:Span", ptr %t303
  store %"compiler/source:Span" %t304, ptr %l23
  %t306 = load ptr, ptr %l1, !tbaa !29
  %t308 = getelementptr { i64, [5 x i64] }, ptr %t306, i32 0, i32 1
  %t309 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t308, i32 0, i32 1
  %t310 = load i32, ptr %t309
  store i32 %t310, ptr %l24, !tbaa !23
  %t312 = load ptr, ptr %l1, !tbaa !29
  %t314 = getelementptr { i64, [5 x i64] }, ptr %t312, i32 0, i32 1
  %t315 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t314, i32 0, i32 2
  %t316 = load ptr, ptr %t315
  store ptr %t316, ptr %l25, !tbaa !29
  br label %bb59
bb58:
  br label %bb61
bb59:
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t319 = load ptr, ptr %l25, !tbaa !29
  %t320 = load i32, ptr %l24, !tbaa !23
  %t321 = load %"compiler/source:Span", ptr %l23
  %t326 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2emake(ptr %v0, ptr %v1, ptr %t318, ptr %t319, i32 %t320, %"compiler/source:Span" %t321)
  store { i64, [4 x i64] } %t326, ptr %l183
  br label %bb60
bb60:
  %t327 = load { i64, [4 x i64] }, ptr %l183
  store { i64, [4 x i64] } %t327, ptr %l63
  br label %bb132
bb61:
  %t328 = load ptr, ptr %l1, !tbaa !29
  store ptr %t328, ptr %l184, !tbaa !29
  store i1 false, ptr %l185, !tbaa !21
  %t329 = load ptr, ptr %l184, !tbaa !29
  %t330 = icmp ne ptr %t329, null
  br i1 %t330, label %bb62, label %bb63
bb62:
  %t332 = load ptr, ptr %l184, !tbaa !29
  %t333 = load i64, ptr %t332, !range !{i64 0, i64 18}
  %t335 = icmp eq i64 %t333, 8
  store i1 %t335, ptr %l185, !tbaa !21
  br label %bb63
bb63:
  %t336 = load i1, ptr %l185, !tbaa !21
  br i1 %t336, label %bb64, label %bb65
bb64:
  %t337 = load ptr, ptr %l1, !tbaa !29
  %t339 = getelementptr { i64, [5 x i64] }, ptr %t337, i32 0, i32 1
  %t340 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t339, i32 0, i32 0
  %t341 = load %"compiler/source:Span", ptr %t340
  store %"compiler/source:Span" %t341, ptr %l26
  %t343 = load ptr, ptr %l1, !tbaa !29
  %t345 = getelementptr { i64, [5 x i64] }, ptr %t343, i32 0, i32 1
  %t346 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t345, i32 0, i32 1
  %t347 = load i32, ptr %t346
  store i32 %t347, ptr %l27, !tbaa !23
  %t349 = load ptr, ptr %l1, !tbaa !29
  %t351 = getelementptr { i64, [5 x i64] }, ptr %t349, i32 0, i32 1
  %t352 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t351, i32 0, i32 2
  %t353 = load ptr, ptr %t352
  store ptr %t353, ptr %l28, !tbaa !29
  br label %bb66
bb65:
  br label %bb68
bb66:
  %t355 = load ptr, ptr %l0, !tbaa !29
  %t356 = load ptr, ptr %l28, !tbaa !29
  %t357 = load i32, ptr %l27, !tbaa !23
  %t358 = load %"compiler/source:Span", ptr %l26
  %t363 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ecollect(ptr %v0, ptr %v1, ptr %t355, ptr %t356, i32 %t357, %"compiler/source:Span" %t358)
  store { i64, [4 x i64] } %t363, ptr %l198
  br label %bb67
bb67:
  %t364 = load { i64, [4 x i64] }, ptr %l198
  store { i64, [4 x i64] } %t364, ptr %l63
  br label %bb132
bb68:
  %t365 = load ptr, ptr %l1, !tbaa !29
  store ptr %t365, ptr %l199, !tbaa !29
  store i1 false, ptr %l200, !tbaa !21
  %t366 = load ptr, ptr %l199, !tbaa !29
  %t367 = icmp ne ptr %t366, null
  br i1 %t367, label %bb69, label %bb70
bb69:
  %t369 = load ptr, ptr %l199, !tbaa !29
  %t370 = load i64, ptr %t369, !range !{i64 0, i64 18}
  %t372 = icmp eq i64 %t370, 9
  store i1 %t372, ptr %l200, !tbaa !21
  br label %bb70
bb70:
  %t373 = load i1, ptr %l200, !tbaa !21
  br i1 %t373, label %bb71, label %bb72
bb71:
  %t374 = load ptr, ptr %l1, !tbaa !29
  %t376 = getelementptr { i64, [5 x i64] }, ptr %t374, i32 0, i32 1
  %t377 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t376, i32 0, i32 0
  %t378 = load %"compiler/source:Span", ptr %t377
  store %"compiler/source:Span" %t378, ptr %l29
  %t380 = load ptr, ptr %l1, !tbaa !29
  %t382 = getelementptr { i64, [5 x i64] }, ptr %t380, i32 0, i32 1
  %t383 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t382, i32 0, i32 1
  %t384 = load i32, ptr %t383
  store i32 %t384, ptr %l30, !tbaa !23
  %t386 = load ptr, ptr %l1, !tbaa !29
  %t388 = getelementptr { i64, [5 x i64] }, ptr %t386, i32 0, i32 1
  %t389 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t388, i32 0, i32 2
  %t390 = load i32, ptr %t389, !range !{i32 0, i32 52}
  store i32 %t390, ptr %l31
  %t392 = load ptr, ptr %l1, !tbaa !29
  %t394 = getelementptr { i64, [5 x i64] }, ptr %t392, i32 0, i32 1
  %t395 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t394, i32 0, i32 3
  %t396 = load i32, ptr %t395, !range !{i32 0, i32 3}
  store i32 %t396, ptr %l32
  %t398 = load ptr, ptr %l1, !tbaa !29
  %t400 = getelementptr { i64, [5 x i64] }, ptr %t398, i32 0, i32 1
  %t401 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t400, i32 0, i32 4
  %t402 = load { i64, ptr }, ptr %t401
  store { i64, ptr } %t402, ptr %l33, !tbaa !27
  br label %bb73
bb72:
  br label %bb75
bb73:
  %t404 = load ptr, ptr %l0, !tbaa !29
  %t405 = load i32, ptr %l31, !range !{i32 0, i32 52}
  %t406 = load i32, ptr %l32, !range !{i32 0, i32 3}
  %t407 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t408 = load i32, ptr %l30, !tbaa !23
  %t409 = load %"compiler/source:Span", ptr %l29
  %t416 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprimExpr(ptr %v0, ptr %v1, ptr %t404, i32 %t405, i32 %t406, { i64, ptr } %t407, i32 %t408, %"compiler/source:Span" %t409)
  store { i64, [4 x i64] } %t416, ptr %l219
  br label %bb74
bb74:
  %t417 = load { i64, [4 x i64] }, ptr %l219
  store { i64, [4 x i64] } %t417, ptr %l63
  br label %bb132
bb75:
  %t418 = load ptr, ptr %l1, !tbaa !29
  store ptr %t418, ptr %l220, !tbaa !29
  store i1 false, ptr %l221, !tbaa !21
  %t419 = load ptr, ptr %l220, !tbaa !29
  %t420 = icmp ne ptr %t419, null
  br i1 %t420, label %bb76, label %bb77
bb76:
  %t422 = load ptr, ptr %l220, !tbaa !29
  %t423 = load i64, ptr %t422, !range !{i64 0, i64 18}
  %t425 = icmp eq i64 %t423, 10
  store i1 %t425, ptr %l221, !tbaa !21
  br label %bb77
bb77:
  %t426 = load i1, ptr %l221, !tbaa !21
  br i1 %t426, label %bb78, label %bb79
bb78:
  %t427 = load ptr, ptr %l1, !tbaa !29
  %t429 = getelementptr { i64, [5 x i64] }, ptr %t427, i32 0, i32 1
  %t430 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t429, i32 0, i32 0
  %t431 = load %"compiler/source:Span", ptr %t430
  store %"compiler/source:Span" %t431, ptr %l34
  %t433 = load ptr, ptr %l1, !tbaa !29
  %t435 = getelementptr { i64, [5 x i64] }, ptr %t433, i32 0, i32 1
  %t436 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t435, i32 0, i32 1
  %t437 = load i32, ptr %t436
  store i32 %t437, ptr %l35, !tbaa !23
  %t439 = load ptr, ptr %l1, !tbaa !29
  %t441 = getelementptr { i64, [5 x i64] }, ptr %t439, i32 0, i32 1
  %t442 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t441, i32 0, i32 2
  %t443 = load ptr, ptr %t442
  store ptr %t443, ptr %l36, !tbaa !29
  br label %bb80
bb79:
  br label %bb82
bb80:
  %t445 = load ptr, ptr %l0, !tbaa !29
  %t446 = load ptr, ptr %l36, !tbaa !29
  %t447 = load i32, ptr %l35, !tbaa !23
  %t448 = load %"compiler/source:Span", ptr %l34
  %t453 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eslice(ptr %v0, ptr %v1, ptr %t445, ptr %t446, i32 %t447, %"compiler/source:Span" %t448)
  store { i64, [4 x i64] } %t453, ptr %l234
  br label %bb81
bb81:
  %t454 = load { i64, [4 x i64] }, ptr %l234
  store { i64, [4 x i64] } %t454, ptr %l63
  br label %bb132
bb82:
  %t455 = load ptr, ptr %l1, !tbaa !29
  store ptr %t455, ptr %l235, !tbaa !29
  store i1 false, ptr %l236, !tbaa !21
  %t456 = load ptr, ptr %l235, !tbaa !29
  %t457 = icmp ne ptr %t456, null
  br i1 %t457, label %bb83, label %bb84
bb83:
  %t459 = load ptr, ptr %l235, !tbaa !29
  %t460 = load i64, ptr %t459, !range !{i64 0, i64 18}
  %t462 = icmp eq i64 %t460, 11
  store i1 %t462, ptr %l236, !tbaa !21
  br label %bb84
bb84:
  %t463 = load i1, ptr %l236, !tbaa !21
  br i1 %t463, label %bb85, label %bb86
bb85:
  %t464 = load ptr, ptr %l1, !tbaa !29
  %t466 = getelementptr { i64, [5 x i64] }, ptr %t464, i32 0, i32 1
  %t467 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t466, i32 0, i32 0
  %t468 = load %"compiler/source:Span", ptr %t467
  store %"compiler/source:Span" %t468, ptr %l37
  %t470 = load ptr, ptr %l1, !tbaa !29
  %t472 = getelementptr { i64, [5 x i64] }, ptr %t470, i32 0, i32 1
  %t473 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t472, i32 0, i32 1
  %t474 = load i32, ptr %t473
  store i32 %t474, ptr %l38, !tbaa !23
  %t476 = load ptr, ptr %l1, !tbaa !29
  %t478 = getelementptr { i64, [5 x i64] }, ptr %t476, i32 0, i32 1
  %t479 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t478, i32 0, i32 2
  %t480 = load ptr, ptr %t479
  store ptr %t480, ptr %l39, !tbaa !29
  br label %bb87
bb86:
  br label %bb89
bb87:
  %t482 = load ptr, ptr %l0, !tbaa !29
  %t483 = load ptr, ptr %l39, !tbaa !29
  %t484 = load i32, ptr %l38, !tbaa !23
  %t485 = load %"compiler/source:Span", ptr %l37
  %t490 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econd(ptr %v0, ptr %v1, ptr %t482, ptr %t483, i32 %t484, %"compiler/source:Span" %t485)
  store { i64, [4 x i64] } %t490, ptr %l249
  br label %bb88
bb88:
  %t491 = load { i64, [4 x i64] }, ptr %l249
  store { i64, [4 x i64] } %t491, ptr %l63
  br label %bb132
bb89:
  %t492 = load ptr, ptr %l1, !tbaa !29
  store ptr %t492, ptr %l250, !tbaa !29
  store i1 false, ptr %l251, !tbaa !21
  %t493 = load ptr, ptr %l250, !tbaa !29
  %t494 = icmp ne ptr %t493, null
  br i1 %t494, label %bb90, label %bb91
bb90:
  %t496 = load ptr, ptr %l250, !tbaa !29
  %t497 = load i64, ptr %t496, !range !{i64 0, i64 18}
  %t499 = icmp eq i64 %t497, 12
  store i1 %t499, ptr %l251, !tbaa !21
  br label %bb91
bb91:
  %t500 = load i1, ptr %l251, !tbaa !21
  br i1 %t500, label %bb92, label %bb93
bb92:
  %t501 = load ptr, ptr %l1, !tbaa !29
  %t503 = getelementptr { i64, [5 x i64] }, ptr %t501, i32 0, i32 1
  %t504 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t503, i32 0, i32 2
  %t505 = load ptr, ptr %t504
  store ptr %t505, ptr %l40, !tbaa !29
  br label %bb94
bb93:
  br label %bb96
bb94:
  %t507 = load ptr, ptr %l0, !tbaa !29
  %t508 = load ptr, ptr %l40, !tbaa !29
  %t511 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eseq(ptr %v0, ptr %v1, ptr %t507, ptr %t508)
  store { i64, [4 x i64] } %t511, ptr %l258
  br label %bb95
bb95:
  %t512 = load { i64, [4 x i64] }, ptr %l258
  store { i64, [4 x i64] } %t512, ptr %l63
  br label %bb132
bb96:
  %t513 = load ptr, ptr %l1, !tbaa !29
  store ptr %t513, ptr %l259, !tbaa !29
  store i1 false, ptr %l260, !tbaa !21
  %t514 = load ptr, ptr %l259, !tbaa !29
  %t515 = icmp ne ptr %t514, null
  br i1 %t515, label %bb97, label %bb98
bb97:
  %t517 = load ptr, ptr %l259, !tbaa !29
  %t518 = load i64, ptr %t517, !range !{i64 0, i64 18}
  %t520 = icmp eq i64 %t518, 13
  store i1 %t520, ptr %l260, !tbaa !21
  br label %bb98
bb98:
  %t521 = load i1, ptr %l260, !tbaa !21
  br i1 %t521, label %bb99, label %bb100
bb99:
  %t522 = load ptr, ptr %l1, !tbaa !29
  %t524 = getelementptr { i64, [5 x i64] }, ptr %t522, i32 0, i32 1
  %t525 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t524, i32 0, i32 0
  %t526 = load %"compiler/source:Span", ptr %t525
  store %"compiler/source:Span" %t526, ptr %l41
  %t528 = load ptr, ptr %l1, !tbaa !29
  %t530 = getelementptr { i64, [5 x i64] }, ptr %t528, i32 0, i32 1
  %t531 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t530, i32 0, i32 1
  %t532 = load i32, ptr %t531
  store i32 %t532, ptr %l42, !tbaa !23
  %t534 = load ptr, ptr %l1, !tbaa !29
  %t536 = getelementptr { i64, [5 x i64] }, ptr %t534, i32 0, i32 1
  %t537 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t536, i32 0, i32 2
  %t538 = load ptr, ptr %t537
  store ptr %t538, ptr %l43, !tbaa !29
  br label %bb101
bb100:
  br label %bb103
bb101:
  %t540 = load ptr, ptr %l0, !tbaa !29
  %t541 = load ptr, ptr %l43, !tbaa !29
  %t542 = load i32, ptr %l42, !tbaa !23
  %t543 = load %"compiler/source:Span", ptr %l41
  %t548 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ematch(ptr %v0, ptr %v1, ptr %t540, ptr %t541, i32 %t542, %"compiler/source:Span" %t543)
  store { i64, [4 x i64] } %t548, ptr %l273
  br label %bb102
bb102:
  %t549 = load { i64, [4 x i64] }, ptr %l273
  store { i64, [4 x i64] } %t549, ptr %l63
  br label %bb132
bb103:
  %t550 = load ptr, ptr %l1, !tbaa !29
  store ptr %t550, ptr %l274, !tbaa !29
  store i1 false, ptr %l275, !tbaa !21
  %t551 = load ptr, ptr %l274, !tbaa !29
  %t552 = icmp ne ptr %t551, null
  br i1 %t552, label %bb104, label %bb105
bb104:
  %t554 = load ptr, ptr %l274, !tbaa !29
  %t555 = load i64, ptr %t554, !range !{i64 0, i64 18}
  %t557 = icmp eq i64 %t555, 14
  store i1 %t557, ptr %l275, !tbaa !21
  br label %bb105
bb105:
  %t558 = load i1, ptr %l275, !tbaa !21
  br i1 %t558, label %bb106, label %bb107
bb106:
  %t559 = load ptr, ptr %l1, !tbaa !29
  %t561 = getelementptr { i64, [5 x i64] }, ptr %t559, i32 0, i32 1
  %t562 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t561, i32 0, i32 0
  %t563 = load %"compiler/source:Span", ptr %t562
  store %"compiler/source:Span" %t563, ptr %l44
  %t565 = load ptr, ptr %l1, !tbaa !29
  %t567 = getelementptr { i64, [5 x i64] }, ptr %t565, i32 0, i32 1
  %t568 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t567, i32 0, i32 2
  %t569 = load ptr, ptr %t568
  store ptr %t569, ptr %l45, !tbaa !29
  br label %bb108
bb107:
  br label %bb110
bb108:
  %t571 = load ptr, ptr %l0, !tbaa !29
  %t572 = load ptr, ptr %l1, !tbaa !29
  %t573 = load ptr, ptr %l45, !tbaa !29
  %t574 = load %"compiler/source:Span", ptr %l44
  %t579 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2etry(ptr %v0, ptr %v1, ptr %v1, ptr %t571, ptr %t572, ptr %t573, %"compiler/source:Span" %t574)
  store { i64, [4 x i64] } %t579, ptr %l286
  br label %bb109
bb109:
  %t580 = load { i64, [4 x i64] }, ptr %l286
  store { i64, [4 x i64] } %t580, ptr %l63
  br label %bb132
bb110:
  %t581 = load ptr, ptr %l1, !tbaa !29
  store ptr %t581, ptr %l287, !tbaa !29
  store i1 false, ptr %l288, !tbaa !21
  %t582 = load ptr, ptr %l287, !tbaa !29
  %t583 = icmp ne ptr %t582, null
  br i1 %t583, label %bb111, label %bb112
bb111:
  %t585 = load ptr, ptr %l287, !tbaa !29
  %t586 = load i64, ptr %t585, !range !{i64 0, i64 18}
  %t588 = icmp eq i64 %t586, 15
  store i1 %t588, ptr %l288, !tbaa !21
  br label %bb112
bb112:
  %t589 = load i1, ptr %l288, !tbaa !21
  br i1 %t589, label %bb113, label %bb114
bb113:
  %t590 = load ptr, ptr %l1, !tbaa !29
  %t592 = getelementptr { i64, [5 x i64] }, ptr %t590, i32 0, i32 1
  %t593 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t592, i32 0, i32 0
  %t594 = load %"compiler/source:Span", ptr %t593
  store %"compiler/source:Span" %t594, ptr %l46
  %t596 = load ptr, ptr %l1, !tbaa !29
  %t598 = getelementptr { i64, [5 x i64] }, ptr %t596, i32 0, i32 1
  %t599 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t598, i32 0, i32 1
  %t600 = load i32, ptr %t599
  store i32 %t600, ptr %l47, !tbaa !23
  %t602 = load ptr, ptr %l1, !tbaa !29
  %t604 = getelementptr { i64, [5 x i64] }, ptr %t602, i32 0, i32 1
  %t605 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t604, i32 0, i32 2
  %t606 = load ptr, ptr %t605
  store ptr %t606, ptr %l48, !tbaa !29
  br label %bb115
bb114:
  br label %bb117
bb115:
  %t608 = load ptr, ptr %l0, !tbaa !29
  %t609 = load ptr, ptr %l48, !tbaa !29
  %t610 = load i32, ptr %l47, !tbaa !23
  %t611 = load %"compiler/source:Span", ptr %l46
  %t616 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2efnVal(ptr %v0, ptr %v1, ptr %t608, ptr %t609, i32 %t610, %"compiler/source:Span" %t611)
  store { i64, [4 x i64] } %t616, ptr %l301
  br label %bb116
bb116:
  %t617 = load { i64, [4 x i64] }, ptr %l301
  store { i64, [4 x i64] } %t617, ptr %l63
  br label %bb132
bb117:
  %t618 = load ptr, ptr %l1, !tbaa !29
  store ptr %t618, ptr %l302, !tbaa !29
  store i1 false, ptr %l303, !tbaa !21
  %t619 = load ptr, ptr %l302, !tbaa !29
  %t620 = icmp ne ptr %t619, null
  br i1 %t620, label %bb118, label %bb119
bb118:
  %t622 = load ptr, ptr %l302, !tbaa !29
  %t623 = load i64, ptr %t622, !range !{i64 0, i64 18}
  %t625 = icmp eq i64 %t623, 16
  store i1 %t625, ptr %l303, !tbaa !21
  br label %bb119
bb119:
  %t626 = load i1, ptr %l303, !tbaa !21
  br i1 %t626, label %bb120, label %bb121
bb120:
  %t627 = load ptr, ptr %l1, !tbaa !29
  %t629 = getelementptr { i64, [5 x i64] }, ptr %t627, i32 0, i32 1
  %t630 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t629, i32 0, i32 0
  %t631 = load %"compiler/source:Span", ptr %t630
  store %"compiler/source:Span" %t631, ptr %l49
  %t633 = load ptr, ptr %l1, !tbaa !29
  %t635 = getelementptr { i64, [5 x i64] }, ptr %t633, i32 0, i32 1
  %t636 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t635, i32 0, i32 1
  %t637 = load i32, ptr %t636
  store i32 %t637, ptr %l50, !tbaa !23
  %t639 = load ptr, ptr %l1, !tbaa !29
  %t641 = getelementptr { i64, [5 x i64] }, ptr %t639, i32 0, i32 1
  %t642 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t641, i32 0, i32 2
  %t643 = load ptr, ptr %t642
  store ptr %t643, ptr %l51, !tbaa !29
  br label %bb122
bb121:
  br label %bb124
bb122:
  %t645 = load ptr, ptr %l0, !tbaa !29
  %t646 = load ptr, ptr %l51, !tbaa !29
  %t647 = load i32, ptr %l50, !tbaa !23
  %t648 = load %"compiler/source:Span", ptr %l49
  %t653 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2etext(ptr %v0, ptr %v1, ptr %t645, ptr %t646, i32 %t647, %"compiler/source:Span" %t648)
  store { i64, [4 x i64] } %t653, ptr %l316
  br label %bb123
bb123:
  %t654 = load { i64, [4 x i64] }, ptr %l316
  store { i64, [4 x i64] } %t654, ptr %l63
  br label %bb132
bb124:
  %t655 = load ptr, ptr %l1, !tbaa !29
  store ptr %t655, ptr %l317, !tbaa !29
  store i1 false, ptr %l318, !tbaa !21
  %t656 = load ptr, ptr %l317, !tbaa !29
  %t657 = icmp ne ptr %t656, null
  br i1 %t657, label %bb125, label %bb126
bb125:
  %t659 = load ptr, ptr %l317, !tbaa !29
  %t660 = load i64, ptr %t659, !range !{i64 0, i64 18}
  %t662 = icmp eq i64 %t660, 17
  store i1 %t662, ptr %l318, !tbaa !21
  br label %bb126
bb126:
  %t663 = load i1, ptr %l318, !tbaa !21
  br i1 %t663, label %bb127, label %bb128
bb127:
  %t664 = load ptr, ptr %l1, !tbaa !29
  %t666 = getelementptr { i64, [5 x i64] }, ptr %t664, i32 0, i32 1
  %t667 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t666, i32 0, i32 1
  %t668 = load i64, ptr %t667
  store i64 %t668, ptr %l52, !tbaa !24
  %t670 = load ptr, ptr %l1, !tbaa !29
  %t672 = getelementptr { i64, [5 x i64] }, ptr %t670, i32 0, i32 1
  %t673 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t672, i32 0, i32 2
  %t674 = load ptr, ptr %t673
  store ptr %t674, ptr %l53, !tbaa !29
  br label %bb129
bb128:
  br label %bb131
bb129:
  %t676 = load ptr, ptr %l0, !tbaa !29
  %t677 = load i64, ptr %l52, !tbaa !24
  %t678 = load ptr, ptr %l53, !tbaa !29
  %t682 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eaway(ptr %v0, ptr %v1, ptr %t676, i64 %t677, ptr %t678)
  store { i64, [4 x i64] } %t682, ptr %l328
  br label %bb130
bb130:
  %t683 = load { i64, [4 x i64] }, ptr %l328
  store { i64, [4 x i64] } %t683, ptr %l63
  br label %bb132
bb131:
  call void @__olang_check_failed(ptr @olang_loc_c62658d3c5a83b98_5474a5965e06e124)
  unreachable
bb132:
  %t684 = load { i64, [4 x i64] }, ptr %l63
  store { i64, [4 x i64] } %t684, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eviewCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca i1
  %l18 = alloca i1
  %l22 = alloca i64
  %l24 = alloca i1
  %l27 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Call", ptr %a1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  store ptr %t6, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t7 = load ptr, ptr %l9, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l9, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 5}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l10, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l3, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { i32 }, ptr %t17, i32 0, i32 0
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l4, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t21 = load i32, ptr %l4, !tbaa !23
  store i32 %t21, ptr %l8, !tbaa !23
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i32 -1, ptr %l8, !tbaa !23
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_8878eb20a40721c6_39b06fa96ecc3992)
  unreachable
bb11:
  %t23 = load i32, ptr %l8, !tbaa !23
  store i32 %t23, ptr %l5, !tbaa !23
  %t24 = load i32, ptr %l5, !tbaa !23
  %t26 = icmp sge i32 %t24, 0
  br i1 %t26, label %bb12, label %bb13
bb12:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/lower:lowering", ptr %t28, i32 0, i32 0
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t32 = load i32, ptr %l5, !tbaa !23
  %t35 = call i64 @compiler_2flower_2ecompiler_2flower_3aLowerer_2eViewsOf(ptr %v0, ptr %t31, i32 %t32)
  store i64 %t35, ptr %l22
  br label %bb14
bb13:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb15
bb14:
  %t36 = load i64, ptr %l22, !tbaa !24
  %t37 = icmp sgt i64 %t36, 0
  store i1 %t37, ptr %l18, !tbaa !21
  br label %bb15
bb15:
  %t39 = load i1, ptr %l18, !tbaa !21
  br i1 %t39, label %bb16, label %bb17
bb16:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t44 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eviewValue(ptr %v0, ptr %t40, i32 %a2)
  store i1 %t44, ptr %l27
  br label %bb18
bb17:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb19
bb18:
  %t45 = load i1, ptr %l27, !tbaa !21
  store i1 %t45, ptr %l24, !tbaa !21
  br label %bb19
bb19:
  %t46 = load i1, ptr %l24, !tbaa !21
  store i1 %t46, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eviewInit(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l15 = alloca %"compiler/typed:Local"
  %l20 = alloca i1
  %l22 = alloca ptr
  %l27 = alloca ptr
  %l34 = alloca i1
  %l37 = alloca ptr
  %l47 = alloca i1
  %l49 = alloca ptr
  %l56 = alloca i1
  %l60 = alloca ptr
  %l63 = alloca i1
  %l67 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca i1
  %l84 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Body", ptr %t4, i32 0, i32 7
  %t7 = load i64, ptr %l3, !tbaa !24
  %t10 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t6, i64 %t7)
  store %"compiler/typed:Local" %t10, ptr %l15
  br label %bb1
bb1:
  %t11 = getelementptr %"compiler/typed:Local", ptr %l15, i32 0, i32 2
  %t12 = load i32, ptr %t11, !tbaa !23
  store i32 %t12, ptr %l4, !tbaa !23
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/lower:lowering", ptr %t14, i32 0, i32 2
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t18 = load i32, ptr %l4, !tbaa !23
  %t21 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t17, i32 %t18)
  store i1 %t21, ptr %l20
  br label %bb2
bb2:
  %t22 = load i1, ptr %l20, !tbaa !21
  br i1 %t22, label %bb3, label %bb4
bb3:
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t25 = call ptr @compiler_2flower_2epromoted(ptr %v2, ptr %v2, ptr %t23)
  store ptr %t25, ptr %l22
  br label %bb5
bb4:
  br label %bb20
bb5:
  %t26 = load ptr, ptr %l22, !tbaa !29
  store ptr %t26, ptr %l5, !tbaa !29
  %t27 = load ptr, ptr %l5, !tbaa !29
  %t29 = icmp eq ptr %t27, null
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb6, label %bb7
bb6:
  %t33 = load ptr, ptr %l5, !tbaa !29
  %t35 = call ptr @compiler_2flower_2eviewCallIn(ptr %v2, ptr %v2, ptr %t33)
  store ptr %t35, ptr %l27
  br label %bb8
bb7:
  br label %bb13
bb8:
  %t36 = load ptr, ptr %l27, !tbaa !29
  store ptr %t36, ptr %l6, !tbaa !29
  %t37 = load ptr, ptr %l6, !tbaa !29
  %t39 = icmp eq ptr %t37, null
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t45 = load ptr, ptr %l6, !tbaa !29
  %t49 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eheldViews(ptr %v0, ptr %v1, ptr %v2, ptr %t43, ptr %t44, ptr %t45)
  store i1 %t49, ptr %l34
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t50 = load i1, ptr %l34, !tbaa !21
  store i1 %t50, ptr %rv
  br label %ret
bb12:
  store i1 true, ptr %rv
  br label %ret
bb13:
  %t52 = load ptr, ptr %l2, !tbaa !29
  %t54 = call ptr @compiler_2flower_2eviewCallIn(ptr %v2, ptr %v2, ptr %t52)
  store ptr %t54, ptr %l37
  br label %bb14
bb14:
  %t55 = load ptr, ptr %l37, !tbaa !29
  store ptr %t55, ptr %l7, !tbaa !29
  %t56 = load ptr, ptr %l7, !tbaa !29
  %t58 = icmp eq ptr %t56, null
  %t60 = xor i1 %t58, true
  br i1 %t60, label %bb15, label %bb16
bb15:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t64 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eheldThroughTemps(ptr %v0, ptr %v1, ptr %v2, ptr %t62, ptr %t63, ptr %t64)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t70 = load ptr, ptr %l2, !tbaa !29
  %t74 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eheldSrc(ptr %v0, ptr %v1, ptr %v2, ptr %t68, ptr %t69, ptr %t70)
  store i1 %t74, ptr %l47
  br label %bb19
bb19:
  %t75 = load i1, ptr %l47, !tbaa !21
  store i1 %t75, ptr %rv
  br label %ret
bb20:
  %t76 = load ptr, ptr %l2, !tbaa !29
  %t78 = call ptr @compiler_2flower_2eviewCallIn(ptr %v2, ptr %v2, ptr %t76)
  store ptr %t78, ptr %l49
  br label %bb21
bb21:
  %t79 = load ptr, ptr %l49, !tbaa !29
  store ptr %t79, ptr %l8, !tbaa !29
  %t80 = load ptr, ptr %l8, !tbaa !29
  %t82 = icmp eq ptr %t80, null
  %t84 = xor i1 %t82, true
  br i1 %t84, label %bb22, label %bb23
bb22:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load ptr, ptr %l1, !tbaa !29
  %t88 = load ptr, ptr %l8, !tbaa !29
  %t92 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eheldViews(ptr %v0, ptr %v1, ptr %v2, ptr %t86, ptr %t87, ptr %t88)
  store i1 %t92, ptr %l56
  br label %bb24
bb23:
  br label %bb25
bb24:
  %t93 = load i1, ptr %l56, !tbaa !21
  store i1 %t93, ptr %rv
  br label %ret
bb25:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/lower:lowering", ptr %t94, i32 0, i32 2
  %t97 = load ptr, ptr %t96, !tbaa !29
  %t98 = load ptr, ptr %l2, !tbaa !29
  %t101 = call ptr @compiler_2ftyped_2eCopiedOf(ptr %v0, ptr %v2, ptr %v2, ptr %t97, ptr %t98)
  store ptr %t101, ptr %l60
  br label %bb26
bb26:
  %t102 = load ptr, ptr %l60, !tbaa !29
  store ptr %t102, ptr %l9, !tbaa !29
  %t103 = load ptr, ptr %l9, !tbaa !29
  %t105 = icmp eq ptr %t103, null
  br i1 %t105, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l63, !tbaa !21
  br label %bb30
bb28:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load ptr, ptr %l1, !tbaa !29
  %t109 = load ptr, ptr %l9, !tbaa !29
  %t113 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eheldSrc(ptr %v0, ptr %v1, ptr %v2, ptr %t107, ptr %t108, ptr %t109)
  store i1 %t113, ptr %l67
  br label %bb29
bb29:
  %t114 = load i1, ptr %l67, !tbaa !21
  %t115 = xor i1 %t114, true
  store i1 %t115, ptr %l63, !tbaa !21
  br label %bb30
bb30:
  %t117 = load i1, ptr %l63, !tbaa !21
  br i1 %t117, label %bb31, label %bb32
bb31:
  store i1 false, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  %t119 = load ptr, ptr %l2, !tbaa !29
  store ptr %t119, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t120 = load ptr, ptr %l70, !tbaa !29
  %t121 = icmp ne ptr %t120, null
  br i1 %t121, label %bb34, label %bb35
bb34:
  %t123 = load ptr, ptr %l70, !tbaa !29
  %t124 = load i64, ptr %t123, !range !{i64 0, i64 18}
  %t126 = icmp eq i64 %t124, 7
  store i1 %t126, ptr %l71, !tbaa !21
  br label %bb35
bb35:
  %t127 = load i1, ptr %l71, !tbaa !21
  br i1 %t127, label %bb36, label %bb37
bb36:
  %t128 = load ptr, ptr %l2, !tbaa !29
  %t130 = getelementptr { i64, [5 x i64] }, ptr %t128, i32 0, i32 1
  %t131 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t130, i32 0, i32 2
  %t132 = load ptr, ptr %t131
  store ptr %t132, ptr %l10, !tbaa !29
  br label %bb38
bb37:
  br label %bb40
bb38:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/lower:lowering", ptr %t134, i32 0, i32 46
  %t137 = load ptr, ptr %l10, !tbaa !29
  %t139 = getelementptr %"compiler/typed:Make", ptr %t137, i32 0, i32 4
  %t140 = load i32, ptr %t139, !tbaa !23
  %t142 = sext i32 %t140 to i64
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t136, i64 %t142, i1 true)
  br label %bb39
bb39:
  br label %bb50
bb40:
  br i1 true, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb49
bb43:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load ptr, ptr %l2, !tbaa !29
  %t147 = load i32, ptr %l4, !tbaa !23
  %t151 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopiesArray(ptr %v0, ptr %v2, ptr %t145, ptr %t146, i32 %t147)
  store i1 %t151, ptr %l84
  br label %bb44
bb44:
  %t152 = load i1, ptr %l84, !tbaa !21
  br i1 %t152, label %bb45, label %bb46
bb45:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t155 = getelementptr %"compiler/lower:lowering", ptr %t153, i32 0, i32 51
  %t156 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t155, i64 %t156, i1 true)
  br label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb48
bb48:
  br label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_f886b4a7a2309fc_ac18d7305f75b0d8)
  unreachable
bb50:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ewaits(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l11 = alloca i64
  %l16 = alloca i64
  %l18 = alloca i64
  %l23 = alloca i64
  %l27 = alloca i1
  %l30 = alloca i1
  %l33 = alloca i64
  %l36 = alloca i1
  %l38 = alloca ptr
  %l41 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2eholderOf(ptr %v0, ptr %t1, i64 %t2)
  store i64 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i64, ptr %l11, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store ptr %a2, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb5
bb5:
  %t14 = load i64, ptr %l6, !tbaa !24
  store i64 %t14, ptr %l16, !tbaa !24
  %t15 = load ptr, ptr %l5, !tbaa !29
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t15)
  store i64 %t17, ptr %l18
  br label %bb6
bb6:
  %t18 = load i64, ptr %l16, !tbaa !24
  %t19 = load i64, ptr %l18, !tbaa !24
  %t20 = icmp slt i64 %t18, %t19
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb7, label %bb8
bb7:
  br label %bb28
bb8:
  br label %bb9
bb9:
  %t24 = load ptr, ptr %l5, !tbaa !29
  %t25 = load i64, ptr %l6, !tbaa !24
  %t28 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t24, i64 %t25)
  store i64 %t28, ptr %l23
  br label %bb10
bb10:
  %t29 = load i64, ptr %l23, !tbaa !24
  store i64 %t29, ptr %l7, !tbaa !24
  %t30 = load i64, ptr %l7, !tbaa !24
  %t31 = load i64, ptr %l1, !tbaa !24
  %t34 = icmp eq i64 %t30, %t31
  br i1 %t34, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb14
bb12:
  %t37 = load i64, ptr %l7, !tbaa !24
  %t40 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v2, ptr %a3, i64 %t37)
  store i1 %t40, ptr %l30
  br label %bb13
bb13:
  %t41 = load i1, ptr %l30, !tbaa !21
  store i1 %t41, ptr %l27, !tbaa !21
  br label %bb14
bb14:
  %t42 = load i1, ptr %l27, !tbaa !21
  br i1 %t42, label %bb15, label %bb16
bb15:
  br label %bb27
bb16:
  br label %bb17
bb17:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load i64, ptr %l7, !tbaa !24
  %t47 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2eholderOf(ptr %v0, ptr %t43, i64 %t44)
  store i64 %t47, ptr %l33
  br label %bb18
bb18:
  %t48 = load i64, ptr %l33, !tbaa !24
  store i64 %t48, ptr %l8, !tbaa !24
  %t49 = load i64, ptr %l8, !tbaa !24
  %t51 = icmp sge i64 %t49, 0
  br i1 %t51, label %bb19, label %bb20
bb19:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = call ptr @compiler_2flower_2ecompiler_2flower_3alowering_2eholds(ptr %v0, ptr %v0, ptr %t53)
  store ptr %t55, ptr %l38
  br label %bb21
bb20:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb23
bb21:
  %t56 = load i64, ptr %l8, !tbaa !24
  %t57 = load i64, ptr %l4, !tbaa !24
  %t58 = load ptr, ptr %l38, !tbaa !29
  %t61 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aDropHolding_2eHolds(ptr %v0, ptr %t58, i64 %t56, i64 %t57)
  store i1 %t61, ptr %l41
  br label %bb22
bb22:
  %t62 = load i1, ptr %l41, !tbaa !21
  store i1 %t62, ptr %l36, !tbaa !21
  br label %bb23
bb23:
  %t63 = load i1, ptr %l36, !tbaa !21
  br i1 %t63, label %bb24, label %bb25
bb24:
  store i1 true, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  br label %bb27
bb27:
  %t65 = load i64, ptr %l6, !tbaa !24
  %t67 = add i64 %t65, 1
  store i64 %t67, ptr %l6, !tbaa !24
  br label %bb5
bb28:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eweakPlace(ptr %v0, ptr %a0, %"compiler/mir:Lvalue" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Lvalue"
  %l2 = alloca i64
  %l3 = alloca { i64, [1 x i64] }
  %l4 = alloca i64
  %l17 = alloca { i64, [1 x i64] }
  %l25 = alloca ptr
  %l27 = alloca ptr
  %l32 = alloca i32
  %l34 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/mir:Lvalue" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/mir:Lvalue", ptr %l1, i32 0, i32 1
  %t2 = getelementptr %"compiler/mir:Range", ptr %t1, i32 0, i32 1
  %t3 = load i32, ptr %t2, !tbaa !23
  %t5 = sext i32 %t3 to i64
  store i64 %t5, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp eq i64 %t7, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lower:lowering", ptr %t12, i32 0, i32 3
  %t15 = getelementptr %"compiler/mir:Fn", ptr %t14, i32 0, i32 10
  %t16 = getelementptr %"compiler/mir:Lvalue", ptr %l1, i32 0, i32 1
  %t17 = getelementptr %"compiler/mir:Range", ptr %t16, i32 0, i32 0
  %t18 = load i32, ptr %t17, !tbaa !23
  %t20 = sext i32 %t18 to i64
  %t21 = load i64, ptr %l2, !tbaa !24
  %t24 = add i64 %t20, %t21
  %t26 = sub i64 %t24, 1
  %t29 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %t15, i64 %t26)
  store { i64, [1 x i64] } %t29, ptr %l17
  br label %bb4
bb4:
  %t30 = load { i64, [1 x i64] }, ptr %l17
  store { i64, [1 x i64] } %t30, ptr %l3
  %t31 = load { i64, [1 x i64] }, ptr %l3
  %t33 = extractvalue { i64, [1 x i64] } %t31, 0
  %t34 = icmp eq i64 %t33, 0
  %t36 = xor i1 %t34, true
  br i1 %t36, label %bb5, label %bb6
bb5:
  store i1 false, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t39 = getelementptr { i64, [1 x i64] }, ptr %l3, i32 0, i32 1
  %t40 = getelementptr { i64 }, ptr %t39, i32 0, i32 0
  %t41 = load i64, ptr %t40
  store i64 %t41, ptr %l4, !tbaa !24
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/lower:lowering", ptr %t43, i32 0, i32 0
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = call ptr @compiler_2flower_2ecompiler_2flower_3aLowerer_2eGen(ptr %v0, ptr %v0, ptr %t46)
  store ptr %t48, ptr %l25
  br label %bb8
bb8:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/lower:lowering", ptr %t49, i32 0, i32 2
  %t52 = load ptr, ptr %t51, !tbaa !29
  store ptr %t52, ptr %l27, !tbaa !29
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load %"compiler/mir:Lvalue", ptr %l1
  %t55 = load i64, ptr %l2, !tbaa !24
  %t57 = sub i64 %t55, 1
  %t61 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2estepType(ptr %v0, ptr %t53, %"compiler/mir:Lvalue" %t54, i64 %t57)
  store i32 %t61, ptr %l32
  br label %bb9
bb9:
  %t62 = load i64, ptr %l4, !tbaa !24
  %t63 = load ptr, ptr %l25, !tbaa !29
  %t64 = load ptr, ptr %l27, !tbaa !29
  %t65 = load i32, ptr %l32, !tbaa !23
  %t67 = call i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eWeakField(ptr %v0, ptr %v0, ptr %t63, ptr %t64, i32 %t65, i64 %t62)
  store i1 %t67, ptr %l34
  br label %bb10
bb10:
  %t68 = load i1, ptr %l34, !tbaa !21
  store i1 %t68, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ewiden(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, i32 %a3, %"compiler/source:Span" %a4, { i64, [1 x i64] } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca { i64, [1 x i64] }
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca { i64, [4 x i64] }
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l19 = alloca { i64, [4 x i64] }
  %l24 = alloca i32
  %l25 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca i64
  %l36 = alloca i32
  %l38 = alloca ptr
  %l42 = alloca i32
  %l43 = alloca i32
  %l45 = alloca ptr
  %l49 = alloca i32
  %l50 = alloca i32
  %l54 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca %"compiler/source:Span"
  %l58 = alloca %"compiler/mir:Lvalue"
  %l70 = alloca i64
  %l73 = alloca i64
  %l91 = alloca ptr
  %l92 = alloca i32
  %l99 = alloca { i64, ptr }
  %l100 = alloca %"compiler/mir:Lvalue"
  %l104 = alloca { i64, [4 x i64] }
  %l111 = alloca { i64, [4 x i64] }
  %l112 = alloca ptr
  %l113 = alloca %"compiler/source:Span"
  %l120 = alloca { i64, ptr }
  %l121 = alloca %"compiler/mir:Lvalue"
  %l129 = alloca %"compiler/mir:Lvalue"
  %l131 = alloca ptr
  %l132 = alloca %"compiler/source:Span"
  %l134 = alloca %"compiler/mir:Lvalue"
  %l142 = alloca ptr
  %l143 = alloca %"compiler/source:Span"
  %l145 = alloca %"compiler/mir:Lvalue"
  %l147 = alloca %"compiler/mir:Lvalue"
  %l152 = alloca %"compiler/mir:Lvalue"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t23 = alloca { i64, [4 x i64] }, align 8
  %t88 = alloca { i64, [4 x i64] }, align 8
  %t91 = alloca { i64, [15 x i64] }, align 8
  %t103 = alloca { i64, [21 x i64] }, align 8
  %t171 = alloca { i64, [2 x i64] }, align 8
  %t178 = alloca { i64, [1 x i64] }, align 8
  %t196 = alloca { i64, [4 x i64] }, align 8
  %t202 = alloca { i64, [15 x i64] }, align 8
  %t235 = alloca { i64, [2 x i64] }, align 8
  %t242 = alloca { i64, [1 x i64] }, align 8
  %t261 = alloca { i64, [15 x i64] }, align 8
  %t267 = alloca { i64, [21 x i64] }, align 8
  %t288 = alloca { i64, [4 x i64] }, align 8
  %t303 = alloca { i64, [4 x i64] }, align 8
  %t306 = alloca { i64, [15 x i64] }, align 8
  %t318 = alloca { i64, [21 x i64] }, align 8
  %t341 = alloca { i64, [21 x i64] }, align 8
  %t360 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  store { i64, [1 x i64] } %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = load i32, ptr %l2, !tbaa !23
  %t4 = load %"compiler/source:Span", ptr %l4
  %t9 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %t1, { i64, [4 x i64] } %a1, i32 %t3, %"compiler/source:Span" %t4)
  store i32 %t9, ptr %l24
  br label %bb1
bb1:
  %t10 = load i32, ptr %l24, !tbaa !23
  store i32 %t10, ptr %l6, !tbaa !23
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l25, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l2, !tbaa !23
  %t16 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l28
  br label %bb2
bb2:
  %t17 = load ptr, ptr %l25, !tbaa !29
  %t18 = load i32, ptr %l28, !tbaa !23
  %t19 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2efixedLen(ptr %v0, ptr %t17, i32 %t18)
  store i64 %t19, ptr %l29
  br label %bb3
bb3:
  %t20 = load i64, ptr %l29, !tbaa !24
  store i64 %t20, ptr %l7, !tbaa !24
  %t21 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t22 = load i64, ptr %l7, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t23
  %t24 = getelementptr { i64, [4 x i64] }, ptr %t23, i32 0, i32 0
  store i64 2, ptr %t24
  %t26 = insertvalue { i32, i64 } undef, i32 %t21, 0
  %t28 = insertvalue { i32, i64 } %t26, i64 %t22, 1
  %t29 = getelementptr { i64, [4 x i64] }, ptr %t23, i32 0, i32 1
  store { i32, i64 } %t28, ptr %t29
  %t30 = load { i64, [4 x i64] }, ptr %t23
  store { i64, [4 x i64] } %t30, ptr %l8
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l3, !tbaa !23
  %t34 = load %"compiler/source:Span", ptr %l4
  %t38 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t32, i32 %t33, %"compiler/source:Span" %t34)
  store i32 %t38, ptr %l36
  br label %bb4
bb4:
  %t39 = load i32, ptr %l36, !tbaa !23
  store i32 %t39, ptr %l9, !tbaa !23
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/lower:lowering", ptr %t40, i32 0, i32 2
  %t43 = load ptr, ptr %t42, !tbaa !29
  store ptr %t43, ptr %l38, !tbaa !29
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/lower:lowering", ptr %t44, i32 0, i32 2
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t48 = load i32, ptr %l2, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t47, i32 %t48)
  store i32 %t51, ptr %l42
  br label %bb5
bb5:
  %t52 = load ptr, ptr %l38, !tbaa !29
  %t53 = load i32, ptr %l42, !tbaa !23
  %t54 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t52, i32 %t53)
  store i32 %t54, ptr %l43
  br label %bb6
bb6:
  %t55 = load i32, ptr %l43, !tbaa !23
  store i32 %t55, ptr %l10, !tbaa !23
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/lower:lowering", ptr %t56, i32 0, i32 2
  %t59 = load ptr, ptr %t58, !tbaa !29
  store ptr %t59, ptr %l45, !tbaa !29
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/lower:lowering", ptr %t60, i32 0, i32 2
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t64 = load i32, ptr %l3, !tbaa !23
  %t67 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t63, i32 %t64)
  store i32 %t67, ptr %l49
  br label %bb7
bb7:
  %t68 = load ptr, ptr %l45, !tbaa !29
  %t69 = load i32, ptr %l49, !tbaa !23
  %t70 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t68, i32 %t69)
  store i32 %t70, ptr %l50
  br label %bb8
bb8:
  %t71 = load i32, ptr %l50, !tbaa !23
  store i32 %t71, ptr %l11, !tbaa !23
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load i32, ptr %l10, !tbaa !23
  %t74 = load i32, ptr %l11, !tbaa !23
  %t78 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2elaidApart(ptr %v0, ptr %t72, i32 %t73, i32 %t74)
  store i1 %t78, ptr %l54
  br label %bb9
bb9:
  %t79 = load i1, ptr %l54, !tbaa !21
  br i1 %t79, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s1
  %t80 = load ptr, ptr %l0, !tbaa !29
  store ptr %t80, ptr %l55, !tbaa !29
  %t81 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t81, ptr %l56
  %t82 = load i32, ptr %l9, !tbaa !23
  %t84 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t82)
  store %"compiler/mir:Lvalue" %t84, ptr %l58
  br label %bb12
bb11:
  br label %bb32
bb12:
  %t85 = load { i64, [1 x i64] }, ptr %l5
  %t86 = load i32, ptr %l3, !tbaa !23
  %t87 = load { i64, [4 x i64] }, ptr %l8
  store { i64, [4 x i64] } zeroinitializer, ptr %t88
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t88, i32 0, i32 0
  store i64 0, ptr %t89
  %t90 = load { i64, [4 x i64] }, ptr %t88
  store { i64, [15 x i64] } zeroinitializer, ptr %t91
  %t92 = getelementptr { i64, [15 x i64] }, ptr %t91, i32 0, i32 0
  store i64 8, ptr %t92
  %t94 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } undef, { i64, [1 x i64] } %t85, 0
  %t96 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t94, i32 %t86, 1
  %t98 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t96, { i64, [4 x i64] } %t87, 2
  %t100 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t98, { i64, [4 x i64] } %t90, 3
  %t101 = getelementptr { i64, [15 x i64] }, ptr %t91, i32 0, i32 1
  store { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t100, ptr %t101
  %t102 = load { i64, [15 x i64] }, ptr %t91
  store { i64, [21 x i64] } zeroinitializer, ptr %t103
  %t104 = getelementptr { i64, [21 x i64] }, ptr %t103, i32 0, i32 0
  store i64 0, ptr %t104
  %t105 = load %"compiler/source:Span", ptr %l56
  %t106 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t105, 0
  %t107 = load %"compiler/mir:Lvalue", ptr %l58
  %t108 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t106, %"compiler/mir:Lvalue" %t107, 1
  %t110 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t108, { i64, [15 x i64] } %t102, 2
  %t111 = getelementptr { i64, [21 x i64] }, ptr %t103, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t110, ptr %t111
  %t112 = load { i64, [21 x i64] }, ptr %t103
  %t114 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 176, i64 8)
  store { i64, [21 x i64] } %t112, ptr %t114
  %t115 = load ptr, ptr %l55, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s1, ptr %t115, ptr %t114)
  br label %bb13
bb13:
  store i64 0, ptr %l12, !tbaa !24
  %t117 = load i64, ptr %l7, !tbaa !24
  store i64 %t117, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t119 = load i64, ptr %l13, !tbaa !24
  %t120 = load i64, ptr %l12, !tbaa !24
  %t123 = icmp sgt i64 %t119, %t120
  br i1 %t123, label %bb14, label %bb15
bb14:
  %t125 = load i64, ptr %l14, !tbaa !24
  %t127 = icmp sgt i64 %t125, 0
  br i1 %t127, label %bb16, label %bb17
bb15:
  store i64 0, ptr %l70, !tbaa !24
  br label %bb19
bb16:
  %t129 = load i64, ptr %l13, !tbaa !24
  %t130 = load i64, ptr %l12, !tbaa !24
  %t133 = sub i64 %t129, %t130
  %t134 = load i64, ptr %l14, !tbaa !24
  %t137 = add i64 %t133, %t134
  %t139 = sub i64 %t137, 1
  %t140 = load i64, ptr %l14, !tbaa !24
  %t143 = sdiv i64 %t139, %t140
  store i64 %t143, ptr %l73, !tbaa !24
  br label %bb18
bb17:
  store i64 0, ptr %l73, !tbaa !24
  br label %bb18
bb18:
  %t145 = load i64, ptr %l73, !tbaa !24
  store i64 %t145, ptr %l70, !tbaa !24
  br label %bb19
bb19:
  %t146 = load i64, ptr %l70, !tbaa !24
  store i64 %t146, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s3
  %t147 = load i64, ptr %l16, !tbaa !24
  %t148 = load i64, ptr %l15, !tbaa !24
  %t151 = icmp slt i64 %t147, %t148
  %t153 = xor i1 %t151, true
  br i1 %t153, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb22:
  br label %bb23
bb23:
  %t155 = load i64, ptr %l12, !tbaa !24
  %t156 = load i64, ptr %l16, !tbaa !24
  %t157 = load i64, ptr %l14, !tbaa !24
  %t160 = mul i64 %t156, %t157
  %t163 = add i64 %t155, %t160
  store i64 %t163, ptr %l17, !tbaa !24
  %t165 = load ptr, ptr %l0, !tbaa !29
  store ptr %t165, ptr %l91, !tbaa !29
  %t166 = load i32, ptr %l10, !tbaa !23
  store i32 %t166, ptr %l92, !tbaa !23
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/lower:lowering", ptr %t167, i32 0, i32 3
  %t170 = load i32, ptr %l6, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t171
  %t172 = getelementptr { i64, [2 x i64] }, ptr %t171, i32 0, i32 0
  store i64 1, ptr %t172
  %t174 = insertvalue { i32 } undef, i32 %t170, 0
  %t175 = getelementptr { i64, [2 x i64] }, ptr %t171, i32 0, i32 1
  store { i32 } %t174, ptr %t175
  %t176 = load { i64, [2 x i64] }, ptr %t171
  %t177 = load i64, ptr %l17, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t178
  %t179 = getelementptr { i64, [1 x i64] }, ptr %t178, i32 0, i32 0
  store i64 2, ptr %t179
  %t181 = insertvalue { i64 } undef, i64 %t177, 0
  %t182 = getelementptr { i64, [1 x i64] }, ptr %t178, i32 0, i32 1
  store { i64 } %t181, ptr %t182
  %t183 = load { i64, [1 x i64] }, ptr %t178
  %t184 = mul i64 1, 16
  %t185 = call ptr @__olang_scope_alloc_zeroed(ptr %s3, i64 %t184)
  %t186 = insertvalue { i64, ptr } undef, i64 1, 0
  %t187 = insertvalue { i64, ptr } %t186, ptr %t185, 1
  store { i64, ptr } %t187, ptr %l99, !tbaa !27
  %t189 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !27
  %t191 = getelementptr { i64, [1 x i64] }, ptr %t190, i64 0
  store { i64, [1 x i64] } %t183, ptr %t191
  %t194 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t195 = call %"compiler/mir:Lvalue" @compiler_2fmir_2ecompiler_2fmir_3aFn_2ePlace(ptr %v0, ptr %s3, ptr %t169, { i64, [2 x i64] } %t176, { i64, ptr } %t194)
  store %"compiler/mir:Lvalue" %t195, ptr %l100
  br label %bb24
bb24:
  store { i64, [4 x i64] } zeroinitializer, ptr %t196
  %t197 = getelementptr { i64, [4 x i64] }, ptr %t196, i32 0, i32 0
  store i64 1, ptr %t197
  %t198 = load %"compiler/mir:Lvalue", ptr %l100
  %t199 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t198, 0
  %t200 = getelementptr { i64, [4 x i64] }, ptr %t196, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t199, ptr %t200
  %t201 = load { i64, [4 x i64] }, ptr %t196
  store { i64, [15 x i64] } zeroinitializer, ptr %t202
  %t203 = getelementptr { i64, [15 x i64] }, ptr %t202, i32 0, i32 0
  store i64 0, ptr %t203
  %t205 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t201, 0
  %t206 = getelementptr { i64, [15 x i64] }, ptr %t202, i32 0, i32 1
  store { { i64, [4 x i64] } } %t205, ptr %t206
  %t207 = load { i64, [15 x i64] }, ptr %t202
  %t208 = load %"compiler/source:Span", ptr %l4
  %t209 = load ptr, ptr %l91, !tbaa !29
  %t210 = load i32, ptr %l92, !tbaa !23
  %t213 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t209, i32 %t210, { i64, [15 x i64] } %t207, %"compiler/source:Span" %t208)
  store { i64, [4 x i64] } %t213, ptr %l104
  br label %bb25
bb25:
  %t214 = load { i64, [4 x i64] }, ptr %l104
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t217 = load i32, ptr %l10, !tbaa !23
  %t218 = load i32, ptr %l11, !tbaa !23
  %t219 = load %"compiler/source:Span", ptr %l4
  %t220 = load { i64, [1 x i64] }, ptr %l5
  %t227 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ewiden(ptr %v0, ptr %t215, { i64, [4 x i64] } %t214, i32 %t217, i32 %t218, %"compiler/source:Span" %t219, { i64, [1 x i64] } %t220)
  store { i64, [4 x i64] } %t227, ptr %l111
  br label %bb26
bb26:
  %t228 = load { i64, [4 x i64] }, ptr %l111
  store { i64, [4 x i64] } %t228, ptr %l19
  %t229 = load ptr, ptr %l0, !tbaa !29
  store ptr %t229, ptr %l112, !tbaa !29
  %t230 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t230, ptr %l113
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t233 = getelementptr %"compiler/lower:lowering", ptr %t231, i32 0, i32 3
  %t234 = load i32, ptr %l9, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t235
  %t236 = getelementptr { i64, [2 x i64] }, ptr %t235, i32 0, i32 0
  store i64 1, ptr %t236
  %t238 = insertvalue { i32 } undef, i32 %t234, 0
  %t239 = getelementptr { i64, [2 x i64] }, ptr %t235, i32 0, i32 1
  store { i32 } %t238, ptr %t239
  %t240 = load { i64, [2 x i64] }, ptr %t235
  %t241 = load i64, ptr %l17, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t242
  %t243 = getelementptr { i64, [1 x i64] }, ptr %t242, i32 0, i32 0
  store i64 2, ptr %t243
  %t245 = insertvalue { i64 } undef, i64 %t241, 0
  %t246 = getelementptr { i64, [1 x i64] }, ptr %t242, i32 0, i32 1
  store { i64 } %t245, ptr %t246
  %t247 = load { i64, [1 x i64] }, ptr %t242
  %t248 = mul i64 1, 16
  %t249 = call ptr @__olang_scope_alloc_zeroed(ptr %s3, i64 %t248)
  %t250 = insertvalue { i64, ptr } undef, i64 1, 0
  %t251 = insertvalue { i64, ptr } %t250, ptr %t249, 1
  store { i64, ptr } %t251, ptr %l120, !tbaa !27
  %t253 = getelementptr { i64, ptr }, ptr %l120, i32 0, i32 1
  %t254 = load ptr, ptr %t253, !tbaa !27
  %t255 = getelementptr { i64, [1 x i64] }, ptr %t254, i64 0
  store { i64, [1 x i64] } %t247, ptr %t255
  %t258 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t259 = call %"compiler/mir:Lvalue" @compiler_2fmir_2ecompiler_2fmir_3aFn_2ePlace(ptr %v0, ptr %s3, ptr %t233, { i64, [2 x i64] } %t240, { i64, ptr } %t258)
  store %"compiler/mir:Lvalue" %t259, ptr %l121
  br label %bb27
bb27:
  %t260 = load { i64, [4 x i64] }, ptr %l19
  store { i64, [15 x i64] } zeroinitializer, ptr %t261
  %t262 = getelementptr { i64, [15 x i64] }, ptr %t261, i32 0, i32 0
  store i64 0, ptr %t262
  %t264 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t260, 0
  %t265 = getelementptr { i64, [15 x i64] }, ptr %t261, i32 0, i32 1
  store { { i64, [4 x i64] } } %t264, ptr %t265
  %t266 = load { i64, [15 x i64] }, ptr %t261
  store { i64, [21 x i64] } zeroinitializer, ptr %t267
  %t268 = getelementptr { i64, [21 x i64] }, ptr %t267, i32 0, i32 0
  store i64 0, ptr %t268
  %t269 = load %"compiler/source:Span", ptr %l113
  %t270 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t269, 0
  %t271 = load %"compiler/mir:Lvalue", ptr %l121
  %t272 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t270, %"compiler/mir:Lvalue" %t271, 1
  %t274 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t272, { i64, [15 x i64] } %t266, 2
  %t275 = getelementptr { i64, [21 x i64] }, ptr %t267, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t274, ptr %t275
  %t276 = load { i64, [21 x i64] }, ptr %t267
  %t278 = call ptr @__olang_scope_alloc_a(ptr %s3, i64 176, i64 8)
  store { i64, [21 x i64] } %t276, ptr %t278
  %t279 = load ptr, ptr %l112, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s3, ptr %t279, ptr %t278)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s3)
  br label %bb29
bb29:
  %t281 = load i64, ptr %l16, !tbaa !24
  %t283 = add i64 %t281, 1
  store i64 %t283, ptr %l16, !tbaa !24
  br label %bb20
bb30:
  %t285 = load i32, ptr %l9, !tbaa !23
  %t287 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t285)
  store %"compiler/mir:Lvalue" %t287, ptr %l129
  br label %bb31
bb31:
  store { i64, [4 x i64] } zeroinitializer, ptr %t288
  %t289 = getelementptr { i64, [4 x i64] }, ptr %t288, i32 0, i32 0
  store i64 1, ptr %t289
  %t290 = load %"compiler/mir:Lvalue", ptr %l129
  %t291 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t290, 0
  %t292 = getelementptr { i64, [4 x i64] }, ptr %t288, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t291, ptr %t292
  %t293 = load { i64, [4 x i64] }, ptr %t288
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t293, ptr %rv
  br label %ret
bb32:
  %t295 = load ptr, ptr %l0, !tbaa !29
  store ptr %t295, ptr %l131, !tbaa !29
  %t296 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t296, ptr %l132
  %t297 = load i32, ptr %l9, !tbaa !23
  %t299 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t297)
  store %"compiler/mir:Lvalue" %t299, ptr %l134
  br label %bb33
bb33:
  %t300 = load { i64, [1 x i64] }, ptr %l5
  %t301 = load i32, ptr %l3, !tbaa !23
  %t302 = load { i64, [4 x i64] }, ptr %l8
  store { i64, [4 x i64] } zeroinitializer, ptr %t303
  %t304 = getelementptr { i64, [4 x i64] }, ptr %t303, i32 0, i32 0
  store i64 0, ptr %t304
  %t305 = load { i64, [4 x i64] }, ptr %t303
  store { i64, [15 x i64] } zeroinitializer, ptr %t306
  %t307 = getelementptr { i64, [15 x i64] }, ptr %t306, i32 0, i32 0
  store i64 8, ptr %t307
  %t309 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } undef, { i64, [1 x i64] } %t300, 0
  %t311 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t309, i32 %t301, 1
  %t313 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t311, { i64, [4 x i64] } %t302, 2
  %t315 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t313, { i64, [4 x i64] } %t305, 3
  %t316 = getelementptr { i64, [15 x i64] }, ptr %t306, i32 0, i32 1
  store { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t315, ptr %t316
  %t317 = load { i64, [15 x i64] }, ptr %t306
  store { i64, [21 x i64] } zeroinitializer, ptr %t318
  %t319 = getelementptr { i64, [21 x i64] }, ptr %t318, i32 0, i32 0
  store i64 0, ptr %t319
  %t320 = load %"compiler/source:Span", ptr %l132
  %t321 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t320, 0
  %t322 = load %"compiler/mir:Lvalue", ptr %l134
  %t323 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t321, %"compiler/mir:Lvalue" %t322, 1
  %t325 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t323, { i64, [15 x i64] } %t317, 2
  %t326 = getelementptr { i64, [21 x i64] }, ptr %t318, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t325, ptr %t326
  %t327 = load { i64, [21 x i64] }, ptr %t318
  %t329 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t327, ptr %t329
  %t330 = load ptr, ptr %l131, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t330, ptr %t329)
  br label %bb34
bb34:
  %t332 = load ptr, ptr %l0, !tbaa !29
  store ptr %t332, ptr %l142, !tbaa !29
  %t333 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t333, ptr %l143
  %t334 = load i32, ptr %l9, !tbaa !23
  %t336 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t334)
  store %"compiler/mir:Lvalue" %t336, ptr %l145
  br label %bb35
bb35:
  %t337 = load i32, ptr %l6, !tbaa !23
  %t339 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t337)
  store %"compiler/mir:Lvalue" %t339, ptr %l147
  br label %bb36
bb36:
  %t340 = load { i64, [4 x i64] }, ptr %l8
  store { i64, [21 x i64] } zeroinitializer, ptr %t341
  %t342 = getelementptr { i64, [21 x i64] }, ptr %t341, i32 0, i32 0
  store i64 9, ptr %t342
  %t343 = load %"compiler/source:Span", ptr %l143
  %t344 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t343, 0
  %t345 = load %"compiler/mir:Lvalue", ptr %l145
  %t346 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } } %t344, %"compiler/mir:Lvalue" %t345, 1
  %t347 = load %"compiler/mir:Lvalue", ptr %l147
  %t348 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } } %t346, %"compiler/mir:Lvalue" %t347, 2
  %t350 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } } %t348, { i64, [4 x i64] } %t340, 3
  %t351 = getelementptr { i64, [21 x i64] }, ptr %t341, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } } %t350, ptr %t351
  %t352 = load { i64, [21 x i64] }, ptr %t341
  %t354 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t352, ptr %t354
  %t355 = load ptr, ptr %l142, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t355, ptr %t354)
  br label %bb37
bb37:
  %t357 = load i32, ptr %l9, !tbaa !23
  %t359 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t357)
  store %"compiler/mir:Lvalue" %t359, ptr %l152
  br label %bb38
bb38:
  store { i64, [4 x i64] } zeroinitializer, ptr %t360
  %t361 = getelementptr { i64, [4 x i64] }, ptr %t360, i32 0, i32 0
  store i64 1, ptr %t361
  %t362 = load %"compiler/mir:Lvalue", ptr %l152
  %t363 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t362, 0
  %t364 = getelementptr { i64, [4 x i64] }, ptr %t360, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t363, ptr %t364
  %t365 = load { i64, [4 x i64] }, ptr %t360
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t365, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ewindowFor(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i64
  %l8 = alloca i32
  %l18 = alloca ptr
  %l19 = alloca i64
  %l21 = alloca i64
  %l26 = alloca i64
  %l32 = alloca i1
  %l33 = alloca i1
  %l36 = alloca i1
  %l40 = alloca i1
  %l46 = alloca i1
  %l48 = alloca i1
  %l54 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 47
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eClear_3cI64_2c_20Bool_3e(ptr %v0, ptr %t3)
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/lower:lowering", ptr %t5, i32 0, i32 50
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eClear_3cI64_2c_20Bool_3e(ptr %v0, ptr %t7)
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ecoverAdd(ptr %v0, ptr %t9, i32 %t10, i64 0)
  br label %bb3
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = getelementptr %"compiler/lower:lowering", ptr %t13, i32 0, i32 48
  store i32 %t14, ptr %t17, !tbaa !23
  store i1 true, ptr %l4, !tbaa !21
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = call ptr @compiler_2flower_2ecompiler_2flower_3alowering_2emutGlobals(ptr %v0, ptr %v0, ptr %t18)
  store ptr %t20, ptr %l18
  br label %bb4
bb4:
  %t21 = load ptr, ptr %l18, !tbaa !29
  store ptr %t21, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb5
bb5:
  %t22 = load i64, ptr %l6, !tbaa !24
  store i64 %t22, ptr %l19, !tbaa !24
  %t23 = load ptr, ptr %l5, !tbaa !29
  %t25 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t23)
  store i64 %t25, ptr %l21
  br label %bb6
bb6:
  %t26 = load i64, ptr %l19, !tbaa !24
  %t27 = load i64, ptr %l21, !tbaa !24
  %t28 = icmp slt i64 %t26, %t27
  %t30 = xor i1 %t28, true
  br i1 %t30, label %bb7, label %bb8
bb7:
  br label %bb20
bb8:
  br label %bb9
bb9:
  %t32 = load ptr, ptr %l5, !tbaa !29
  %t33 = load i64, ptr %l6, !tbaa !24
  %t36 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t32, i64 %t33)
  store i64 %t36, ptr %l26
  br label %bb10
bb10:
  %t37 = load i64, ptr %l26, !tbaa !24
  %t40 = trunc i64 %t37 to i32
  store i32 %t40, ptr %l8, !tbaa !23
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load i32, ptr %l8, !tbaa !23
  %t47 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eobjHits(ptr %v0, ptr %t43, i32 %t44)
  store i1 %t47, ptr %l32
  br label %bb11
bb11:
  %t48 = load i1, ptr %l32, !tbaa !21
  br i1 %t48, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb15
bb13:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i32, ptr %l8, !tbaa !23
  %t53 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ewritesCover(ptr %v0, ptr %t49, i32 %t50, i64 0)
  store i1 %t53, ptr %l36
  br label %bb14
bb14:
  %t54 = load i1, ptr %l36, !tbaa !21
  store i1 %t54, ptr %l33, !tbaa !21
  br label %bb15
bb15:
  %t55 = load i1, ptr %l33, !tbaa !21
  br i1 %t55, label %bb16, label %bb17
bb16:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb18
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t56 = load i64, ptr %l6, !tbaa !24
  %t58 = add i64 %t56, 1
  store i64 %t58, ptr %l6, !tbaa !24
  br label %bb5
bb20:
  %t60 = load i1, ptr %l4, !tbaa !21
  br i1 %t60, label %bb21, label %bb22
bb21:
  %t62 = load ptr, ptr %l2, !tbaa !29
  %t64 = icmp eq ptr %t62, null
  %t66 = xor i1 %t64, true
  store i1 %t66, ptr %l40, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb23
bb23:
  %t68 = load i1, ptr %l40, !tbaa !21
  br i1 %t68, label %bb24, label %bb25
bb24:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load ptr, ptr %l2, !tbaa !29
  %t73 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietCall(ptr %v0, ptr %v1, ptr %t69, ptr %t70)
  store i1 %t73, ptr %l46
  br label %bb26
bb25:
  br label %bb27
bb26:
  %t74 = load i1, ptr %l46, !tbaa !21
  store i1 %t74, ptr %l4, !tbaa !21
  br label %bb27
bb27:
  %t75 = load i1, ptr %l4, !tbaa !21
  br i1 %t75, label %bb28, label %bb29
bb28:
  %t77 = load ptr, ptr %l3, !tbaa !29
  %t79 = icmp eq ptr %t77, null
  %t81 = xor i1 %t79, true
  store i1 %t81, ptr %l48, !tbaa !21
  br label %bb30
bb29:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb30
bb30:
  %t83 = load i1, ptr %l48, !tbaa !21
  br i1 %t83, label %bb31, label %bb32
bb31:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load ptr, ptr %l3, !tbaa !29
  %t88 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietPlace(ptr %v0, ptr %v2, ptr %t84, ptr %t85)
  store i1 %t88, ptr %l54
  br label %bb33
bb32:
  br label %bb34
bb33:
  %t89 = load i1, ptr %l54, !tbaa !21
  store i1 %t89, ptr %l4, !tbaa !21
  br label %bb34
bb34:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/lower:lowering", ptr %t90, i32 0, i32 47
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eClear_3cI64_2c_20Bool_3e(ptr %v0, ptr %t92)
  br label %bb35
bb35:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/lower:lowering", ptr %t94, i32 0, i32 50
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eClear_3cI64_2c_20Bool_3e(ptr %v0, ptr %t96)
  br label %bb36
bb36:
  %t98 = load i1, ptr %l4, !tbaa !21
  store i1 %t98, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ewindowQuiet(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  %l13 = alloca ptr
  %l15 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i1
  %l35 = alloca i64
  %l39 = alloca i64
  %l42 = alloca i64
  %l61 = alloca i64
  %l66 = alloca { i64, ptr }
  %l69 = alloca i32
  %l70 = alloca ptr
  %l74 = alloca i1
  %l75 = alloca i32
  %l79 = alloca i32
  %l83 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l13, !tbaa !29
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = call i64 @compiler_2ftyped_2eCalleeBody(ptr %v1, ptr %t5)
  store i64 %t7, ptr %l15
  br label %bb1
bb1:
  %t8 = load i64, ptr %l15, !tbaa !24
  %t9 = trunc i64 %t8 to i32
  %t11 = load ptr, ptr %l13, !tbaa !29
  %t13 = call i64 @compiler_2flower_2ecompiler_2flower_3aLowerer_2eViewsOf(ptr %v0, ptr %t11, i32 %t9)
  store i64 %t13, ptr %l18
  br label %bb2
bb2:
  %t14 = load i64, ptr %l18, !tbaa !24
  store i64 %t14, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp sle i64 %t15, 0
  br i1 %t17, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb5
bb4:
  %t19 = load i64, ptr %l4, !tbaa !24
  %t20 = load i64, ptr @G_2ecompiler_2ftyped_2eViewOther, !tbaa !24
  %t23 = and i64 %t19, %t20
  %t25 = icmp ne i64 %t23, 0
  store i1 %t25, ptr %l21, !tbaa !21
  br label %bb5
bb5:
  %t27 = load i1, ptr %l21, !tbaa !21
  br i1 %t27, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Call", ptr %t30, i32 0, i32 2
  %t33 = load i32, ptr %t32, !tbaa !23
  %t35 = sext i32 %t33 to i64
  %t38 = getelementptr %"compiler/lower:lowering", ptr %t29, i32 0, i32 49
  store i64 %t35, ptr %t38, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Call", ptr %t39, i32 0, i32 1
  %t42 = load { i64, ptr }, ptr %t41, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t45 = load i64, ptr @G_2ecompiler_2ftyped_2eViewBits, !tbaa !24
  %t48 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t44, i64 %t45)
  store i64 %t48, ptr %l35
  br label %bb9
bb9:
  %t49 = load i64, ptr %l35, !tbaa !24
  store i64 %t49, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t50 = load i64, ptr %l6, !tbaa !24
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = icmp sgt i64 %t50, %t51
  br i1 %t54, label %bb10, label %bb11
bb10:
  %t56 = load i64, ptr %l7, !tbaa !24
  %t58 = icmp sgt i64 %t56, 0
  br i1 %t58, label %bb12, label %bb13
bb11:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb15
bb12:
  %t60 = load i64, ptr %l6, !tbaa !24
  %t61 = load i64, ptr %l5, !tbaa !24
  %t64 = sub i64 %t60, %t61
  %t65 = load i64, ptr %l7, !tbaa !24
  %t68 = add i64 %t64, %t65
  %t70 = sub i64 %t68, 1
  %t71 = load i64, ptr %l7, !tbaa !24
  %t74 = sdiv i64 %t70, %t71
  store i64 %t74, ptr %l42, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb14
bb14:
  %t76 = load i64, ptr %l42, !tbaa !24
  store i64 %t76, ptr %l39, !tbaa !24
  br label %bb15
bb15:
  %t77 = load i64, ptr %l39, !tbaa !24
  store i64 %t77, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb16
bb16:
  %t78 = load i64, ptr %l9, !tbaa !24
  %t79 = load i64, ptr %l8, !tbaa !24
  %t82 = icmp slt i64 %t78, %t79
  %t84 = xor i1 %t82, true
  br i1 %t84, label %bb17, label %bb18
bb17:
  br label %bb34
bb18:
  br label %bb19
bb19:
  %t86 = load i64, ptr %l5, !tbaa !24
  %t87 = load i64, ptr %l9, !tbaa !24
  %t88 = load i64, ptr %l7, !tbaa !24
  %t91 = mul i64 %t87, %t88
  %t94 = add i64 %t86, %t91
  store i64 %t94, ptr %l10, !tbaa !24
  %t96 = load i64, ptr %l4, !tbaa !24
  %t97 = load i64, ptr %l10, !tbaa !24
  store i64 %t97, ptr %l61, !tbaa !24
  %t98 = load i64, ptr %l61, !tbaa !24
  %t99 = load i64, ptr %l61, !tbaa !24
  %t100 = shl i64 1, %t99
  %t103 = and i64 %t96, %t100
  %t105 = icmp eq i64 %t103, 0
  br i1 %t105, label %bb20, label %bb21
bb20:
  br label %bb33
bb21:
  br label %bb22
bb22:
  %t107 = load ptr, ptr %l1, !tbaa !29
  %t109 = getelementptr %"compiler/typed:Call", ptr %t107, i32 0, i32 1
  %t110 = load { i64, ptr }, ptr %t109, !tbaa !27
  store { i64, ptr } %t110, ptr %l66, !tbaa !27
  %t111 = load i64, ptr %l10, !tbaa !24
  %t113 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr ptr, ptr %t114, i64 %t111
  %t116 = load ptr, ptr %t115, !tbaa !39
  %t118 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t116)
  store i32 %t118, ptr %l69
  br label %bb23
bb23:
  %t119 = load i32, ptr %l69, !tbaa !23
  store i32 %t119, ptr %l11, !tbaa !23
  %t120 = load ptr, ptr %l0, !tbaa !29
  store ptr %t120, ptr %l70, !tbaa !29
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/lower:lowering", ptr %t121, i32 0, i32 2
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t125 = load i32, ptr %l11, !tbaa !23
  %t128 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t124, i32 %t125)
  store i1 %t128, ptr %l74
  br label %bb24
bb24:
  %t129 = load i1, ptr %l74, !tbaa !21
  br i1 %t129, label %bb25, label %bb26
bb25:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/lower:lowering", ptr %t130, i32 0, i32 2
  %t133 = load ptr, ptr %t132, !tbaa !29
  %t134 = load i32, ptr %l11, !tbaa !23
  %t137 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t133, i32 %t134)
  store i32 %t137, ptr %l79
  br label %bb27
bb26:
  %t138 = load i32, ptr %l11, !tbaa !23
  store i32 %t138, ptr %l75, !tbaa !23
  br label %bb28
bb27:
  %t140 = load i32, ptr %l79, !tbaa !23
  store i32 %t140, ptr %l75, !tbaa !23
  br label %bb28
bb28:
  %t143 = load ptr, ptr %l70, !tbaa !29
  %t144 = load i32, ptr %l75, !tbaa !23
  %t147 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ewindowFor(ptr %v0, ptr %v2, ptr %v3, ptr %t143, i32 %t144, ptr %a2, ptr %a3)
  store i1 %t147, ptr %l83
  br label %bb29
bb29:
  %t148 = load i1, ptr %l83, !tbaa !21
  %t149 = xor i1 %t148, true
  br i1 %t149, label %bb30, label %bb31
bb30:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/lower:lowering", ptr %t151, i32 0, i32 49
  store i64 -1, ptr %t153, !tbaa !24
  store i1 false, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t155 = load i64, ptr %l9, !tbaa !24
  %t157 = add i64 %t155, 1
  store i64 %t157, ptr %l9, !tbaa !24
  br label %bb16
bb34:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/lower:lowering", ptr %t159, i32 0, i32 49
  store i64 -1, ptr %t161, !tbaa !24
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2flower_2ecopyMade(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca %"compiler/source:Span"
  %l18 = alloca i32
  %l20 = alloca %"compiler/source:Span"
  %l21 = alloca i32
  %l23 = alloca ptr
  %l24 = alloca i1
  %l27 = alloca i1
  %l40 = alloca i1
  %l54 = alloca ptr
  %l66 = alloca { i64, ptr }
  %l69 = alloca ptr
  %l70 = alloca i1
  %l74 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t2 = load ptr, ptr %l23, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l23, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 9
  store i1 %t8, ptr %l24, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l24, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l1
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l2, !tbaa !23
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr { i64, [5 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t24, i32 0, i32 2
  %t26 = load i32, ptr %t25, !range !{i32 0, i32 52}
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t30, i32 0, i32 3
  %t32 = load i32, ptr %t31, !range !{i32 0, i32 3}
  store i32 %t32, ptr %l4
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr { i64, [5 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t36, i32 0, i32 4
  %t38 = load { i64, ptr }, ptr %t37
  store { i64, ptr } %t38, ptr %l5, !tbaa !27
  %t42 = trunc i64 20 to i32
  %t43 = icmp eq i32 %t26, %t42
  store i1 %t43, ptr %l27, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb5
bb5:
  %t45 = load i1, ptr %l27, !tbaa !21
  br i1 %t45, label %bb6, label %bb7
bb6:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr { i64, [5 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t48, i32 0, i32 0
  %t50 = load %"compiler/source:Span", ptr %t49
  store %"compiler/source:Span" %t50, ptr %l6
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr { i64, [5 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t54, i32 0, i32 1
  %t56 = load i32, ptr %t55
  store i32 %t56, ptr %l7, !tbaa !23
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr { i64, [5 x i64] }, ptr %t58, i32 0, i32 1
  %t61 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t60, i32 0, i32 2
  %t62 = load i32, ptr %t61, !range !{i32 0, i32 52}
  store i32 %t62, ptr %l8
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr { i64, [5 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t66, i32 0, i32 3
  %t68 = load i32, ptr %t67, !range !{i32 0, i32 3}
  store i32 %t68, ptr %l9
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr { i64, [5 x i64] }, ptr %t70, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t72, i32 0, i32 4
  %t74 = load { i64, ptr }, ptr %t73
  %t78 = extractvalue { i64, ptr } %t74, 0
  %t80 = icmp eq i64 %t78, 1
  store i1 %t80, ptr %l40, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb8
bb8:
  %t82 = load i1, ptr %l40, !tbaa !21
  br i1 %t82, label %bb9, label %bb10
bb9:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr { i64, [5 x i64] }, ptr %t83, i32 0, i32 1
  %t86 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t85, i32 0, i32 0
  %t87 = load %"compiler/source:Span", ptr %t86
  store %"compiler/source:Span" %t87, ptr %l11
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr { i64, [5 x i64] }, ptr %t89, i32 0, i32 1
  %t92 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t91, i32 0, i32 1
  %t93 = load i32, ptr %t92
  store i32 %t93, ptr %l12, !tbaa !23
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr { i64, [5 x i64] }, ptr %t95, i32 0, i32 1
  %t98 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t97, i32 0, i32 2
  %t99 = load i32, ptr %t98, !range !{i32 0, i32 52}
  store i32 %t99, ptr %l13
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr { i64, [5 x i64] }, ptr %t101, i32 0, i32 1
  %t104 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t103, i32 0, i32 3
  %t105 = load i32, ptr %t104, !range !{i32 0, i32 3}
  store i32 %t105, ptr %l14
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr { i64, [5 x i64] }, ptr %t107, i32 0, i32 1
  %t110 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t109, i32 0, i32 4
  %t111 = load { i64, ptr }, ptr %t110
  store { i64, ptr } %t111, ptr %l66, !tbaa !27
  %t115 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr ptr, ptr %t116, i64 0
  %t118 = load ptr, ptr %t117, !tbaa !39
  store ptr %t118, ptr %l54, !tbaa !29
  br label %bb11
bb10:
  %t120 = load ptr, ptr %l0, !tbaa !29
  store ptr %t120, ptr %l54, !tbaa !29
  br label %bb11
bb11:
  %t122 = load ptr, ptr %l54, !tbaa !29
  store ptr %t122, ptr %l16, !tbaa !29
  %t123 = load ptr, ptr %l16, !tbaa !29
  store ptr %t123, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t124 = load ptr, ptr %l69, !tbaa !29
  %t125 = icmp ne ptr %t124, null
  br i1 %t125, label %bb12, label %bb13
bb12:
  %t127 = load ptr, ptr %l69, !tbaa !29
  %t128 = load i64, ptr %t127, !range !{i64 0, i64 18}
  %t130 = icmp eq i64 %t128, 7
  store i1 %t130, ptr %l70, !tbaa !21
  br label %bb13
bb13:
  %t131 = load i1, ptr %l70, !tbaa !21
  %t132 = xor i1 %t131, true
  br i1 %t132, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l74, !tbaa !21
  br label %bb16
bb15:
  %t134 = load ptr, ptr %l16, !tbaa !29
  %t136 = getelementptr { i64, [5 x i64] }, ptr %t134, i32 0, i32 1
  %t137 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t136, i32 0, i32 0
  %t138 = load %"compiler/source:Span", ptr %t137
  store %"compiler/source:Span" %t138, ptr %l17
  %t140 = load ptr, ptr %l16, !tbaa !29
  %t142 = getelementptr { i64, [5 x i64] }, ptr %t140, i32 0, i32 1
  %t143 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t142, i32 0, i32 1
  %t144 = load i32, ptr %t143
  store i32 %t144, ptr %l18, !tbaa !23
  %t146 = load ptr, ptr %l16, !tbaa !29
  %t148 = getelementptr { i64, [5 x i64] }, ptr %t146, i32 0, i32 1
  %t149 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t148, i32 0, i32 2
  %t150 = load ptr, ptr %t149
  %t155 = getelementptr %"compiler/typed:Make", ptr %t150, i32 0, i32 0
  %t156 = load i32, ptr %t155, !range !{i32 0, i32 5}
  %t158 = trunc i64 4 to i32
  %t159 = icmp eq i32 %t156, %t158
  %t161 = xor i1 %t159, true
  store i1 %t161, ptr %l74, !tbaa !21
  br label %bb16
bb16:
  %t163 = load i1, ptr %l74, !tbaa !21
  br i1 %t163, label %bb17, label %bb18
bb17:
  store ptr null, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t165 = load ptr, ptr %l16, !tbaa !29
  %t167 = getelementptr { i64, [5 x i64] }, ptr %t165, i32 0, i32 1
  %t168 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t167, i32 0, i32 0
  %t169 = load %"compiler/source:Span", ptr %t168
  store %"compiler/source:Span" %t169, ptr %l20
  %t171 = load ptr, ptr %l16, !tbaa !29
  %t173 = getelementptr { i64, [5 x i64] }, ptr %t171, i32 0, i32 1
  %t174 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t173, i32 0, i32 1
  %t175 = load i32, ptr %t174
  store i32 %t175, ptr %l21, !tbaa !23
  %t177 = load ptr, ptr %l16, !tbaa !29
  %t179 = getelementptr { i64, [5 x i64] }, ptr %t177, i32 0, i32 1
  %t180 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t179, i32 0, i32 2
  %t181 = load ptr, ptr %t180
  store ptr %t181, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, [2 x i64] } @compiler_2flower_2edropArgAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/typed:DerivedArg"
  %l7 = alloca i64
  %l9 = alloca i64
  %l14 = alloca %"compiler/typed:DerivedArg"
  %l18 = alloca i1
  %rv = alloca { i64, [2 x i64] }
  %t41 = alloca { i64, [2 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l4, !tbaa !24
  store i64 %t3, ptr %l7, !tbaa !24
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e_2eLen_H205a9438cb31641857cd9c1e93810664(ptr %v0, ptr %t4)
  store i64 %t6, ptr %l9
  br label %bb2
bb2:
  %t7 = load i64, ptr %l7, !tbaa !24
  %t8 = load i64, ptr %l9, !tbaa !24
  %t9 = icmp slt i64 %t7, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  br label %bb14
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l3, !tbaa !29
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = call %"compiler/typed:DerivedArg" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e_2eAt__H3d322c834b4b1582ab12028f5b0f20b9(ptr %v0, ptr %t13, i64 %t14)
  store %"compiler/typed:DerivedArg" %t17, ptr %l14
  br label %bb6
bb6:
  %t18 = load %"compiler/typed:DerivedArg", ptr %l14
  store %"compiler/typed:DerivedArg" %t18, ptr %l5
  %t19 = getelementptr %"compiler/typed:DerivedArg", ptr %l5, i32 0, i32 0
  %t20 = load i64, ptr %t19, !tbaa !24
  %t24 = icmp eq i64 %t20, %a1
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t26 = getelementptr %"compiler/typed:DerivedArg", ptr %l5, i32 0, i32 1
  %t27 = load i64, ptr %t26, !tbaa !24
  %t31 = icmp eq i64 %t27, %a2
  store i1 %t31, ptr %l18, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb9
bb9:
  %t33 = load i1, ptr %l18, !tbaa !21
  br i1 %t33, label %bb10, label %bb11
bb10:
  %t34 = getelementptr %"compiler/typed:DerivedArg", ptr %l5, i32 0, i32 2
  %t35 = load { i64, [2 x i64] }, ptr %t34
  store { i64, [2 x i64] } %t35, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t37 = load i64, ptr %l4, !tbaa !24
  %t39 = add i64 %t37, 1
  store i64 %t39, ptr %l4, !tbaa !24
  br label %bb1
bb14:
  store { i64, [2 x i64] } zeroinitializer, ptr %t41
  %t42 = getelementptr { i64, [2 x i64] }, ptr %t41, i32 0, i32 0
  store i64 0, ptr %t42
  %t43 = load { i64, [2 x i64] }, ptr %t41
  store { i64, [2 x i64] } %t43, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local i64 @compiler_2flower_2eindexOf(ptr %v0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a0, i32 %a1) #0 {
entry:
  %l0 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i64
  %l36 = alloca i32
  %rv = alloca i64
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t2 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %l0)
  store i64 %t2, ptr %l9
  br label %bb1
bb1:
  %t3 = load i64, ptr %l9, !tbaa !24
  store i64 %t3, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t4 = load i64, ptr %l3, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t8 = icmp sgt i64 %t4, %t5
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t10 = load i64, ptr %l4, !tbaa !24
  %t12 = icmp sgt i64 %t10, 0
  br i1 %t12, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l13, !tbaa !24
  br label %bb7
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l2, !tbaa !24
  %t18 = sub i64 %t14, %t15
  %t19 = load i64, ptr %l4, !tbaa !24
  %t22 = add i64 %t18, %t19
  %t24 = sub i64 %t22, 1
  %t25 = load i64, ptr %l4, !tbaa !24
  %t28 = sdiv i64 %t24, %t25
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l13, !tbaa !24
  br label %bb7
bb7:
  %t31 = load i64, ptr %l13, !tbaa !24
  store i64 %t31, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t32 = load i64, ptr %l6, !tbaa !24
  %t33 = load i64, ptr %l5, !tbaa !24
  %t36 = icmp slt i64 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb9, label %bb10
bb9:
  br label %bb17
bb10:
  br label %bb11
bb11:
  %t40 = load i64, ptr %l2, !tbaa !24
  %t41 = load i64, ptr %l6, !tbaa !24
  %t42 = load i64, ptr %l4, !tbaa !24
  %t45 = mul i64 %t41, %t42
  %t48 = add i64 %t40, %t45
  store i64 %t48, ptr %l7, !tbaa !24
  %t50 = load i64, ptr %l7, !tbaa !24
  %t53 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %l0, i64 %t50)
  store i32 %t53, ptr %l36
  br label %bb12
bb12:
  %t55 = load i32, ptr %l36, !tbaa !23
  %t57 = icmp eq i32 %t55, %a1
  br i1 %t57, label %bb13, label %bb14
bb13:
  %t59 = load i64, ptr %l7, !tbaa !24
  store i64 %t59, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t61 = load i64, ptr %l6, !tbaa !24
  %t63 = add i64 %t61, 1
  store i64 %t63, ptr %l6, !tbaa !24
  br label %bb8
bb17:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2flower_2eplaceRootLocal(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i1
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i1
  %l30 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca i1
  %l39 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l1, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l1, !tbaa !23
  %t18 = sext i32 %t16 to i64
  store i64 %t18, ptr %l5, !tbaa !24
  br label %bb32
bb6:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t21 = load ptr, ptr %l14, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb7, label %bb8
bb7:
  %t24 = load ptr, ptr %l14, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 8}
  %t27 = icmp eq i64 %t25, 3
  store i1 %t27, ptr %l15, !tbaa !21
  br label %bb8
bb8:
  %t28 = load i1, ptr %l15, !tbaa !21
  br i1 %t28, label %bb9, label %bb10
bb9:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = call i64 @compiler_2flower_2eplaceRootLocal(ptr %v0, ptr %t35)
  store i64 %t37, ptr %l21
  br label %bb12
bb12:
  %t38 = load i64, ptr %l21, !tbaa !24
  store i64 %t38, ptr %l5, !tbaa !24
  br label %bb32
bb13:
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t40 = load ptr, ptr %l22, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %bb14, label %bb15
bb14:
  %t43 = load ptr, ptr %l22, !tbaa !29
  %t44 = load i64, ptr %t43, !range !{i64 0, i64 8}
  %t46 = icmp eq i64 %t44, 4
  store i1 %t46, ptr %l23, !tbaa !21
  br label %bb15
bb15:
  %t47 = load i1, ptr %l23, !tbaa !21
  br i1 %t47, label %bb16, label %bb17
bb16:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr { i64, [4 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t50, i32 0, i32 2
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l3, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t54 = load ptr, ptr %l3, !tbaa !29
  %t56 = getelementptr %"compiler/typed:Elem", ptr %t54, i32 0, i32 0
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = call i64 @compiler_2flower_2eplaceRootLocal(ptr %v0, ptr %t57)
  store i64 %t59, ptr %l30
  br label %bb19
bb19:
  %t60 = load i64, ptr %l30, !tbaa !24
  store i64 %t60, ptr %l5, !tbaa !24
  br label %bb32
bb20:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t62 = load ptr, ptr %l31, !tbaa !29
  %t63 = icmp ne ptr %t62, null
  br i1 %t63, label %bb21, label %bb22
bb21:
  %t65 = load ptr, ptr %l31, !tbaa !29
  %t66 = load i64, ptr %t65, !range !{i64 0, i64 8}
  %t68 = icmp eq i64 %t66, 5
  store i1 %t68, ptr %l32, !tbaa !21
  br label %bb22
bb22:
  %t69 = load i1, ptr %l32, !tbaa !21
  br i1 %t69, label %bb23, label %bb24
bb23:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr { i64, [4 x i64] }, ptr %t70, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t72, i32 0, i32 2
  %t74 = load ptr, ptr %t73
  store ptr %t74, ptr %l4, !tbaa !29
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t76 = load ptr, ptr %l4, !tbaa !29
  %t78 = getelementptr %"compiler/typed:Payload", ptr %t76, i32 0, i32 0
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = call i64 @compiler_2flower_2eplaceRootLocal(ptr %v0, ptr %t79)
  store i64 %t81, ptr %l39
  br label %bb26
bb26:
  %t82 = load i64, ptr %l39, !tbaa !24
  store i64 %t82, ptr %l5, !tbaa !24
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  store i64 -1, ptr %l5, !tbaa !24
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_de502b4556e13d28_d48b9fb731677334)
  unreachable
bb32:
  %t83 = load i64, ptr %l5, !tbaa !24
  store i64 %t83, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2flower_2epromoted(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l20 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 5
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Promote", ptr %t16, i32 0, i32 0
  %t19 = load ptr, ptr %t18, !tbaa !29
  store ptr %t19, ptr %l3, !tbaa !29
  br label %bb18
bb6:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t23 = load ptr, ptr %l13, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t26 = load ptr, ptr %l13, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 18}
  %t29 = icmp eq i64 %t27, 17
  store i1 %t29, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t30 = load i1, ptr %l14, !tbaa !21
  br i1 %t30, label %bb9, label %bb10
bb9:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr { i64, [5 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t39 = call ptr @compiler_2flower_2epromoted(ptr %v0, ptr %v1, ptr %t37)
  store ptr %t39, ptr %l20
  br label %bb12
bb12:
  %t40 = load ptr, ptr %l20, !tbaa !29
  store ptr %t40, ptr %l3, !tbaa !29
  br label %bb18
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store ptr null, ptr %l3, !tbaa !29
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_73fe6e02ce2153fa_3dee06b9132f2046)
  unreachable
bb18:
  %t41 = load ptr, ptr %l3, !tbaa !29
  store ptr %t41, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2flower_2ereadLocalPlace(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l16 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb11
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t17 = load ptr, ptr %l12, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 8}
  %t23 = icmp eq i64 %t21, 0
  store i1 %t23, ptr %l13, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l13, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t27, i32 0, i32 0
  %t29 = load %"compiler/source:Span", ptr %t28
  store %"compiler/source:Span" %t29, ptr %l2
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t33, i32 0, i32 1
  %t35 = load i32, ptr %t34
  store i32 %t35, ptr %l3, !tbaa !23
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t39, i32 0, i32 2
  %t41 = load i32, ptr %t40
  store i32 %t41, ptr %l4, !tbaa !23
  %t43 = load ptr, ptr %l1, !tbaa !29
  store ptr %t43, ptr %l16, !tbaa !29
  br label %bb10
bb9:
  store ptr null, ptr %l16, !tbaa !29
  br label %bb10
bb10:
  %t46 = load ptr, ptr %l16, !tbaa !29
  store ptr %t46, ptr %l5, !tbaa !29
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store ptr null, ptr %l5, !tbaa !29
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_88a52b04082b7f90_f09bd19366efa7b4)
  unreachable
bb16:
  %t47 = load ptr, ptr %l5, !tbaa !29
  store ptr %t47, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2flower_2estableKey(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l13 = alloca { i64, ptr }
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 -3750763034362895579, ptr %l1, !tbaa !65
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb6
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i8, ptr %t19, i64 %t16
  %t21 = load i8, ptr %t20, !tbaa !32
  %t23 = load i64, ptr %l1, !tbaa !65
  %t26 = zext i8 %t21 to i64
  %t29 = xor i64 %t23, %t26
  %t31 = mul i64 %t29, 1099511628211
  store i64 %t31, ptr %l1, !tbaa !65
  br label %bb5
bb5:
  %t33 = load i64, ptr %l3, !tbaa !24
  %t35 = add i64 %t33, 1
  store i64 %t35, ptr %l3, !tbaa !24
  br label %bb1
bb6:
  %t37 = load i64, ptr %l1, !tbaa !65
  store i64 %t37, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/lower:level" @compiler_2flower_3alevel_2ector(ptr %v0, i32 %a0, i32 %a1, i32 %a2) #0 {
entry:
  %rv = alloca %"compiler/lower:level"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/lower:level" undef, i32 %a0, 0
  %t10 = insertvalue %"compiler/lower:level" %t8, i32 %a1, 1
  %t12 = insertvalue %"compiler/lower:level" %t10, i32 %a2, 2
  store %"compiler/lower:level" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:level", ptr %rv
  ret %"compiler/lower:level" %rr
}

define dso_local %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %v0, { i64, [2 x i64] } %a0) #0 {
entry:
  %l1 = alloca { i64, [2 x i64] }
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/lower:pl"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, [2 x i64] } %a0, ptr %l1
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  %t5 = load { i64, [2 x i64] }, ptr %l1
  %t6 = insertvalue %"compiler/lower:pl" undef, { i64, [2 x i64] } %t5, 0
  %t8 = insertvalue %"compiler/lower:pl" %t6, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, 1
  %t10 = insertvalue %"compiler/lower:pl" %t8, i64 -1, 2
  %t12 = insertvalue %"compiler/lower:pl" %t10, i32 0, 3
  store %"compiler/lower:pl" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:pl", ptr %rv
  ret %"compiler/lower:pl" %rr
}

declare void @__olang_check_failed(ptr) cold noreturn
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d0 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define linkonce_odr void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ftyped_3aPlan(ptr %out, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/typed:Plan"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a0, i64 536, i1 false)
  %t2 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 10
  %t4 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t6 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %t6
  %t7 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 14
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %t7)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l5
  br label %bb2
bb2:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t11 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %t11
  %t12 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 15
  %t14 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t12)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l7
  br label %bb3
bb3:
  %t15 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  %t16 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %t16
  %t17 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 16
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t17)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l9
  br label %bb4
bb4:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  %t21 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %t21
  %t22 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 17
  %t24 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fv_H37dabf8663d733dfb3cf8a6ba127be58(ptr %v0, ptr %t22)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t24, ptr %l11
  br label %bb5
bb5:
  %t25 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l11
  %t26 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 17
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t25, ptr %t26
  %t27 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 18
  %t29 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t27)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t29, ptr %l13
  br label %bb6
bb6:
  %t30 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  %t31 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t30, ptr %t31
  %t32 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 19
  %t34 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec__Hdbcf217951d8a5e6be477b9bbf1b3074(ptr %v0, ptr %t32)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t34, ptr %l15
  br label %bb7
bb7:
  %t35 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  %t36 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t35, ptr %t36
  %t37 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 20
  %t39 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t37)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t39, ptr %l17
  br label %bb8
bb8:
  %t40 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  %t41 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t40, ptr %t41
  %t42 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 21
  %t44 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %t42)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t44, ptr %l19
  br label %bb9
bb9:
  %t45 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  %t46 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 21
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t45, ptr %t46
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l1, i64 536, i1 false)
  br label %ret
ret:
  ret void
}

declare i64 @__olang_fmt_i64(ptr, i64)
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@.d1 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d2 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"?" }>, align 8
declare ptr @__olang_scope_of(ptr, ptr) noinline
@.d3 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d4 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"std/prelude/text" }>, align 8
@.d5 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"String" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
define linkonce_odr %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/lower:pl"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/lower:pl"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/lower:pl", ptr %a0
  store %"compiler/lower:pl" %t2, ptr %l1
  %t3 = getelementptr %"compiler/lower:pl", ptr %l1, i32 0, i32 1
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"compiler/lower:pl", ptr %l1, i32 0, i32 1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = load %"compiler/lower:pl", ptr %l1
  store %"compiler/lower:pl" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:pl", ptr %rv
  ret %"compiler/lower:pl" %rr
}

define linkonce_odr %"compiler/lower:tryCtx" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3atryCtx(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/lower:tryCtx"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/lower:tryCtx"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/lower:tryCtx", ptr %a0
  store %"compiler/lower:tryCtx" %t2, ptr %l1
  %t3 = getelementptr %"compiler/lower:tryCtx", ptr %l1, i32 0, i32 4
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"compiler/lower:tryCtx", ptr %l1, i32 0, i32 4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = load %"compiler/lower:tryCtx", ptr %l1
  store %"compiler/lower:tryCtx" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:tryCtx", ptr %rv
  ret %"compiler/lower:tryCtx" %rr
}

@.d6 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c"a jump out of a loop not being lowered" }>, align 8
@.d7 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d8 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"..." }>, align 8
@.d9 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d10 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d11 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 4
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d12 = private constant <{ i64, [47 x i8] }> <{ i64 0, [47 x i8] c"an unknown type (a check error or gap): a local" }>, align 8
@.d13 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"U8" }>, align 8
@.d14 = private constant <{ i64, [53 x i8] }> <{ i64 0, [53 x i8] c"an unknown type (a check error or gap): an expression" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 24
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 24
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fv_H37dabf8663d733dfb3cf8a6ba127be58(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %a0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3cstd_2fprelude_2fmap_3aMapEntry_3cI64_2c_20std__Hc31c075a081277beb11a6149e950d3c3(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  store { i64, ptr } %t10, ptr %l4, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 0
  store i64 %t12, ptr %l5, !tbaa !24
  %t13 = load i64, ptr %l5, !tbaa !24
  %t14 = mul i64 %t13, 8
  %t15 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t14)
  %t16 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  store { i64, ptr } %t17, ptr %l6, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = load i64, ptr %l5, !tbaa !24
  %t23 = mul i64 %t22, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t19, ptr %t21, i64 %t23, i1 false)
  %t24 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t25 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t24, ptr %t25, !tbaa !27
  %t26 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %l7, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  store i64 %t29, ptr %l8, !tbaa !24
  %t30 = load i64, ptr %l8, !tbaa !24
  %t31 = mul i64 %t30, 8
  %t32 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t31)
  %t33 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  store { i64, ptr } %t34, ptr %l9, !tbaa !27
  %t35 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = load i64, ptr %l8, !tbaa !24
  %t40 = mul i64 %t39, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t36, ptr %t38, i64 %t40, i1 false)
  %t41 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t42 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  store { i64, ptr } %t41, ptr %t42, !tbaa !27
  %t43 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t43, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec__Hdbcf217951d8a5e6be477b9bbf1b3074(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e_3e(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 4
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3cstd_2fprelude_2fmap_3aMapEntry_3cI64_2c_20std__Hc31c075a081277beb11a6149e950d3c3(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613"
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 40
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %t14, i64 %t12
  %t17 = call %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMapEntry_3cI64_2c_20std_2fprelud_Hc8a994261b444ea12c5b83da9413a98f(ptr %v0, ptr %t15)
  store %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" %t17, ptr %l6
  br label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %l6
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %t22, i64 %t20
  store %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" %t19, ptr %t23
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t24, 1
  store i64 %t25, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define linkonce_odr { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 32
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t14, i64 %t12
  %t17 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e(ptr %v0, ptr %t15)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %l6
  br label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t22, i64 %t20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %t23
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t24, 1
  store i64 %t25, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define linkonce_odr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMapEntry_3cI64_2c_20std_2fprelud_Hc8a994261b444ea12c5b83da9413a98f(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %a0
  store %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %l1, i32 0, i32 1
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %l1, i32 0, i32 1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = load %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %l1
  store %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %rv
  ret %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 40
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 40
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@olang_loc_e95d68e3d7cba01a_696ee7b39c9f410e = external constant [0 x i8]
@olang_loc_76ec7e11cc604d77_65dfbe8f138a0f63 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eLen_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2flower_2ecompiler_2flower_3aLowerer_2ederivedFact(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare void @compiler_2ffacts_2ecompiler_2ffacts_3aTable_2eDecide(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3)
declare ptr @compiler_2flower_2ecompiler_2flower_3aLowerer_2eLower(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eVerify(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eDump(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_Hf0a5beca6f8aee4731a76bd327ae0a99(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_He6968003b8dd5762fa82ec44b4ee1fc9(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i1 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2efreshMade(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ftyped_2eCalleeBody(ptr %v0, ptr %a0)
declare i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2efreshResult(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2efreshLocal(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3)
@olang_loc_7e98ebbcfc7ae681_fbeaec9fd6de6485 = external constant [0 x i8]
@olang_loc_80862e2151cf42f0_7c300e18841fcdd4 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare void @compiler_2ftyped_2eLocalUses_2eUses(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2efreshParam(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %a0)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %a0, { i64, [8 x i64] } %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2ector(ptr %v0, i64 %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fload_2eErrQualifier(ptr %v0, ptr %v1, { i64, ptr } %a0, i1 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@G_2ecompiler_2fmir_2eI32T = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\05\00\00\00" }>, align 8
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2ePush_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWordName(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2etextData(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, %"compiler/source:Span" %a2)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eToArray_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %v1, ptr %a0)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2eTwin(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { { i64, [7 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2ebodyCallee(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare { { i64, [7 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2evalueCallee(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { { i64, [7 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2ehelperCallee(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@olang_loc_21e9da82ebd620c7_b6074e807b9f75fb = external constant [0 x i8]
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eSetAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlock_26_3e_2eAt_3ccompiler_2ftyped_3aBlock_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2fmir_2eI64T = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\06\00\00\00" }>, align 8
declare %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %a0)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, { i64, ptr } %a3, %"compiler/source:Span" %a4)
declare %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fmir_3aLocalId_3e_2_H1e3bc46345ebb5614acbe688055fe55f(ptr %v0, ptr %a0, i64 %a1)
declare { i32, { i64, [1 x i64] } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fmir_3aScopeRef_3e__H593d82357dc98d1f15fac9dd5b09c001(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eownCopyOf(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, { i64, [1 x i64] } %a3, %"compiler/source:Span" %a4, i1 %a5)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
declare i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %a3)
declare %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/lower:pl" %a1, { i64, [1 x i64] } %a2)
declare i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eerrCodeOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %a0, i32 %a1, { i64, [15 x i64] } %a2, %"compiler/source:Span" %a3)
declare %"compiler/mir:Lvalue" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:pl" %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePayloadOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePayloadField(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2etypeIs(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i64 %a2, %"compiler/source:Span" %a3)
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare %"compiler/mir:Lvalue" @compiler_2fmir_2ecompiler_2fmir_3aFn_2ePlace(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1, { i64, ptr } %a2)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2escopeRef(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare %"compiler/lower:level" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eAt_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2erunDefers(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2fmir_2eNoLocal = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2fmir_2eNoBlock = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2ejoinFailed(ptr %v0, ptr %a0, i64 %a1, i32 %a2, { i64, [4 x i64] } %a3, i32 %a4, %"compiler/source:Span" %a5)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ewidens(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare ptr @compiler_2flower_2econvertArg(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2efits(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ftyped_2ePure(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_58c3cf8c6fce78d4_23ae1924195b9e70 = external constant [0 x i8]
@olang_loc_3f94e1722b42397a_72ec18aae06ab796 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSharesRefs(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eparamElig(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2flower_2erunArray(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eheldUnchanged(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eEmbedded(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_f8c813b846b58ae2_519e51a3f456354e = external constant [0 x i8]
declare i64 @compiler_2ftyped_2eDropHolder(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %a0)
declare %"compiler/lower:tryCtx" @compiler_2flower_3atryCtx_2ector(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1, i1 %a2, i1 %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ePush_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eopenBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i32 %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3atryCtx_3e_2ePush_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:tryCtx" %a1)
declare ptr @compiler_2flower_2ecompiler_2flower_3alowering_2etop(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2ePush_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2ecloseBlock(ptr %v0, ptr %a0)
declare { i32, %"compiler/lower:tryCtx" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3atryCtx_3e_2ePop_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2ePop_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ector(ptr %v0, i64 %a0)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eleaveOpen(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eclauses(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/lower:tryCtx" %a1, { i64, ptr } %a2, i32 %a3, i32 %a4, ptr %a5)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2epatch(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 %a0)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2espawnErrors(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aloopCtx_3e_2eLen_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aloopCtx_3e_2eRef_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eleave(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aloopCtx_3e_2eRefMut_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2egap(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ebuilt(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_8dbdd81ef51b3d23_89b419ac5748f287 = external constant [0 x i8]
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2evalueArray(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2earrayCopy(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %a3, { i64, [1 x i64] } %a4, i1 %a5)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ecopyHome(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare %"compiler/mir:Range" @compiler_2flower_2ecompiler_2flower_3alowering_2ecapScopes(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eLen_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %a0)
@olang_loc_60304de857474a3b_ccf0225621d3461f = external constant [0 x i8]
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_1c96ed13cfc0c0dd_d1e1293130e6a149 = external constant [0 x i8]
declare i32 @compiler_2fmir_2eFieldsOf(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2eitems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2flower_2ecompiler_2flower_3alowering_2efixedLen(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eplace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2epackedRead(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, %"compiler/source:Span" %a3)
@olang_loc_eff9370fb6cf39b1_ff4f9c232720af7d = external constant [0 x i8]
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2elocalRooted(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ftyped_2ePassesRefs(i32 %a0)
@olang_loc_c024ea3ffaf634ad_6315be653d232c01 = external constant [0 x i8]
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2echeck(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, i32 %a3, i64 %a4, %"compiler/source:Span" %a5)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2efails(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, i32 %a3, i64 %a4, %"compiler/source:Span" %a5)
@olang_loc_13d147f9f542fef2_ebbeb5a175072836 = external constant [0 x i8]
declare { i32, { i64, [4 x i64] } } @compiler_2flower_2ecompiler_2flower_3alowering_2epromotedInPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3, i32 %a4)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2epromoteNew(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
@olang_loc_23ead67d8f6e59cb_86ca0369ed971687 = external constant [0 x i8]
@olang_loc_80847d650e26c632_64a1946959062bee = external constant [0 x i8]
declare ptr @compiler_2flower_2efindBlock(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eClear_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2ecoverAdd(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare ptr @compiler_2flower_2ecompiler_2flower_3alowering_2emutGlobals(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eobjHits(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ewritesCover(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eLen_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0)
declare i32 @compiler_2flower_2ecompiler_2flower_3alowering_2eobjectOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eselfTry(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietPieces(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_3bbf6907cdc90559_48ef26e69e7376e5 = external constant [0 x i8]
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2ereadHere(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3)
@olang_loc_15f99fcbd43babda_53e78f535034c6 = external constant [0 x i8]
@olang_loc_5f06e436ba25f30_8078c3a4dcac4c4 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eword(ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2edepth(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fmir_2eHelperType(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eScopeRefs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2fmir_2eNoPlace = available_externally constant <{ [32 x i8] }> <{ [32 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
declare %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %v0, { i64, [7 x i64] } %a0, %"compiler/mir:Range" %a1, %"compiler/mir:Range" %a2, %"compiler/mir:Lvalue" %a3, i1 %a4, i32 %a5, i32 %a6, i32 %a7)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v0, ptr %a0, %"compiler/mir:Call" %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2einner(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, { i64, [1 x i64] } %a3, %"compiler/source:Span" %a4)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eLen_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %a0)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2estandInAway(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0)
@olang_loc_a41c6179c77e6584_47cab6c73a638ed0 = external constant [0 x i8]
@olang_loc_d5691da7c866d175_fd62f9716bce2461 = external constant [0 x i8]
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2erunArrayLocal(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fmir_3aScopeRef_3e__Hfd0fb4fa500a8eead78ad1b6f9922652(ptr %v0, ptr %a0, i64 %a1, { i64, [1 x i64] } %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fmir_3aLocalId_3e_2_H6363fee5e3f1c076b4ec00933ab48c6c(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"compiler/mir:Local" @compiler_2fmir_3aLocal_2ector(ptr %v0, i32 %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, { i64, [1 x i64] } %a4)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddLocal(ptr %v0, ptr %a0, %"compiler/mir:Local" %a1)
declare i32 @compiler_2flower_2ecompiler_2flower_3alowering_2eparamIn(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2ePush_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2ePush_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_9d64f8741da6e7be_5ae354e0f93b83ca = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2ePush_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eReadDerived(ptr %v0, ptr %a0, i64 %a1, { i64, [2 x i64] } %a2)
declare %"compiler/lower:Gap" @compiler_2flower_3aGap_2ector(ptr %v0, ptr %v1, i64 %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aGap_3e_2ePush_3ccompiler_2flower_3aGap_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:Gap" %a1)
@G_2ecompiler_2fmir_2eNoScope = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
@olang_loc_cce264ade2665388_2fe88b7b285cb164 = external constant [0 x i8]
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddScope(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, %"compiler/source:Span" %a4, i32 %a5)
@olang_loc_7968fd697afe6b41_fd4fb0e63a0f91b5 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2ePush_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %a0, %"compiler/lower:level" %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eholdParams(ptr %v0, ptr %a0)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2esettleViews(ptr %v0, ptr %a0)
@olang_loc_796d2b5c84af77ba_ecbdfcaab288560e = external constant [0 x i8]
@olang_loc_6ad9ce9fa5f3c6a2_cb74a58b871c8f06 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eassemble(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/mir:Range" @compiler_2flower_2ecompiler_2flower_3alowering_2eargs(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [7 x i64] } %a2, i32 %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_16ceb3f79d83ba4c_75eb4aa6518e3548 = external constant [0 x i8]
declare %"compiler/mir:Range" @compiler_2flower_2ecompiler_2flower_3alowering_2epassedFor(ptr %v0, ptr %a0, { i64, [7 x i64] } %a1, i32 %a2, i32 %a3)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2flower_2ecompiler_2flower_3alowering_2ereleases(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i1 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3arelPath_3e_2eLen_3ccompiler_2flower_3arelPath_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eownsStorage(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecounts(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eread(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
@olang_loc_3b3f675a7fcfa09e_a6d8609e08455d8a = external constant [0 x i8]
@olang_loc_a39e67f1cd7c0b1f_e499cc399c2ba1cb = external constant [0 x i8]
declare { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2eprojsOf(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Lvalue" %a1)
declare i32 @compiler_2flower_2ecompiler_2flower_3alowering_2estepType(ptr %v0, ptr %a0, %"compiler/mir:Lvalue" %a1, i64 %a2)
@olang_loc_77939bd7b34e0fa3_983f89b6cb89307 = external constant [0 x i8]
@olang_loc_cbdf5e9a9cabb32e_3680da0cabce8c12 = external constant [0 x i8]
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2epieceView(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_459157e65df33c7e_1dfbf278634bff4a = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddConst(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2erender(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1, { i64, [4 x i64] } %a2, i32 %a3, %"compiler/source:Span" %a4)
@olang_loc_3db4c7c32145727f_d6a525f06b7a698b = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eborrow(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ecall(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2emake(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ecollect(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprimExpr(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, { i64, ptr } %a3, i32 %a4, %"compiler/source:Span" %a5)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eslice(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econd(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eseq(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ematch(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2etry(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, %"compiler/source:Span" %a3)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2efnVal(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
@olang_loc_c62658d3c5a83b98_5474a5965e06e124 = external constant [0 x i8]
@olang_loc_8878eb20a40721c6_39b06fa96ecc3992 = external constant [0 x i8]
declare i64 @compiler_2flower_2ecompiler_2flower_3aLowerer_2eViewsOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eviewValue(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2flower_2eviewCallIn(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eheldViews(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eheldThroughTemps(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eheldSrc(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare ptr @compiler_2ftyped_2eCopiedOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopiesArray(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
@olang_loc_f886b4a7a2309fc_ac18d7305f75b0d8 = external constant [0 x i8]
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2flower_2ecompiler_2flower_3alowering_2eholds(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aDropHolding_2eHolds(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare ptr @compiler_2flower_2ecompiler_2flower_3aLowerer_2eGen(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eWeakField(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i64 %a3)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2elaidApart(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@G_2ecompiler_2ftyped_2eViewOther = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\40" }>, align 8
@G_2ecompiler_2ftyped_2eViewBits = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\3E\00\00\00\00\00\00\00" }>, align 8
declare i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e_2eLen_H205a9438cb31641857cd9c1e93810664(ptr %v0, ptr %a0)
declare %"compiler/typed:DerivedArg" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e_2eAt__H3d322c834b4b1582ab12028f5b0f20b9(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_de502b4556e13d28_d48b9fb731677334 = external constant [0 x i8]
@olang_loc_73fe6e02ce2153fa_3dee06b9132f2046 = external constant [0 x i8]
@olang_loc_88a52b04082b7f90_f09bd19366efa7b4 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2ector(ptr %v0, i64 %a0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
