; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/mir:Lvalue" = type { { i64, [2 x i64] }, %"compiler/mir:Range" }
%"compiler/mir:Range" = type { i32, i32 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, i32, i1, i1 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/lower:Lowerer" = type { ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/typed:Plan", ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i32, i32, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/typed:RefsKept", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/mir:GenInfo", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64 }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/typed:RefsKept" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/mir:GenInfo" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" = type { ptr, i64 }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"compiler/facts:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/facts:Table" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64 }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, i1, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/mir:Fn" = type { { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:LocalUses" = type { ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, i64, i32, i1, i1 }
%"compiler/lower:CloneSum" = type { i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/lower:lowering" = type { ptr, ptr, ptr, %"compiler/mir:Fn", i32, i32, i32, i64, i64, %"compiler/source:Span", { i64, [4 x i64] }, i32, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, i1, i64, i64, i64, i32, i32, { i64, [1 x i64] }, ptr, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/typed:DropHolding", i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:DropHolding" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, i32, i1, ptr, i32 }
%"compiler/ast:TopIf" = type { ptr, ptr, ptr, ptr }
%"compiler/ast:TopBranch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/effects:Effects" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"compiler/effects:Facts", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, { i64, ptr }, i1, %"compiler/source:Span", { i64, ptr }, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, %"compiler/typed:RefsKept", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/effects:Facts" = type { i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i64, [6 x i64], i64, i64 }
%"compiler/lower:pl" = type { { i64, [2 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i32 }
%"compiler/typed:BlockInfo" = type { i32, i32, %"compiler/source:Span" }
%"compiler/lower:level" = type { i32, i32, i32 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr, i1 }
%"compiler/mir:Local" = type { i32, %"compiler/source:Span", i32, i32, { i64, [1 x i64] } }
%"compiler/mir:Call" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Lvalue", i1, i32, i32, i32 }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1, i1 }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/lower:hoistWalk" = type { i64, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, [4 x i64] }, { i64, [4 x i64] }, { i64, [4 x i64] } }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/mir:BasicBlock" = type { %"compiler/mir:StmtList", { i64, [8 x i64] } }
%"compiler/mir:StmtList" = type { { i64, ptr }, i64 }
%"compiler/lower:liveness" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/map:MapValueIter.bf5835bb10600fe6a7fc1da14a6360d9" = type { ptr, i64 }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32, i1, ptr }
@G_2ecompiler_2flower_2eCloneBlocks = constant <{ [8 x i8] }> <{ [8 x i8] c"\A0\0F\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2flower_2eCloneBytes = constant <{ [8 x i8] }> <{ [8 x i8] c"\40\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2flower_2eCloneDepth = constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2flower_2eCloneFloor = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\04\00\00\00\00\00" }>, align 8
@G_2ecompiler_2flower_2eCloneMax = constant <{ [8 x i8] }> <{ [8 x i8] c"\08\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2flower_2eClonePct = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2flower_2eCloneSmall = constant <{ [8 x i8] }> <{ [8 x i8] c"\20\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2flower_2eEmpty = constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2flower_2eFailIds = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\11\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailIds.k1, [8 x i8] c"\12\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailIds.k2, [8 x i8] c"\12\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailIds.k3, [8 x i8] c"\11\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailIds.k4, [8 x i8] c"\11\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailIds.k5 }>, align 64
@G_2ecompiler_2flower_2eFailIds.k1 = internal constant <{ [17 x i8] }> <{ [17 x i8] c"\73\74\64\2F\70\72\65\6C\75\64\65\2F\61\72\72\61\79" }>, align 8
@G_2ecompiler_2flower_2eFailIds.k2 = internal constant <{ [18 x i8] }> <{ [18 x i8] c"\73\74\64\2F\70\72\65\6C\75\64\65\2F\6E\75\6D\62\65\72" }>, align 8
@G_2ecompiler_2flower_2eFailIds.k3 = internal constant <{ [18 x i8] }> <{ [18 x i8] c"\73\74\64\2F\70\72\65\6C\75\64\65\2F\6E\75\6D\62\65\72" }>, align 8
@G_2ecompiler_2flower_2eFailIds.k4 = internal constant <{ [17 x i8] }> <{ [17 x i8] c"\73\74\64\2F\70\72\65\6C\75\64\65\2F\65\6E\75\6D\73" }>, align 8
@G_2ecompiler_2flower_2eFailIds.k5 = internal constant <{ [17 x i8] }> <{ [17 x i8] c"\73\74\64\2F\70\72\65\6C\75\64\65\2F\61\72\72\61\79" }>, align 8
@G_2ecompiler_2flower_2eFailTypes = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\0A\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailTypes.k1, [8 x i8] c"\0B\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailTypes.k2, [8 x i8] c"\0B\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailTypes.k3, [8 x i8] c"\09\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailTypes.k4, [8 x i8] c"\0A\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailTypes.k5 }>, align 64
@G_2ecompiler_2flower_2eFailTypes.k1 = internal constant <{ [10 x i8] }> <{ [10 x i8] c"\41\72\72\61\79\45\72\72\6F\72" }>, align 8
@G_2ecompiler_2flower_2eFailTypes.k2 = internal constant <{ [11 x i8] }> <{ [11 x i8] c"\4E\75\6D\62\65\72\45\72\72\6F\72" }>, align 8
@G_2ecompiler_2flower_2eFailTypes.k3 = internal constant <{ [11 x i8] }> <{ [11 x i8] c"\4E\75\6D\62\65\72\45\72\72\6F\72" }>, align 8
@G_2ecompiler_2flower_2eFailTypes.k4 = internal constant <{ [9 x i8] }> <{ [9 x i8] c"\43\61\73\65\45\72\72\6F\72" }>, align 8
@G_2ecompiler_2flower_2eFailTypes.k5 = internal constant <{ [10 x i8] }> <{ [10 x i8] c"\41\72\72\61\79\45\72\72\6F\72" }>, align 8
@G_2ecompiler_2flower_2eFailWords = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\0A\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailWords.k1, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailWords.k2, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailWords.k3, [8 x i8] c"\09\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailWords.k4, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailWords.k5 }>, align 64
@G_2ecompiler_2flower_2eFailWords.k1 = internal constant <{ [10 x i8] }> <{ [10 x i8] c"\4F\75\74\4F\66\52\61\6E\67\65" }>, align 8
@G_2ecompiler_2flower_2eFailWords.k2 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\4F\76\65\72\66\6C\6F\77" }>, align 8
@G_2ecompiler_2flower_2eFailWords.k3 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\49\6E\76\61\6C\69\64" }>, align 8
@G_2ecompiler_2flower_2eFailWords.k4 = internal constant <{ [9 x i8] }> <{ [9 x i8] c"\57\72\6F\6E\67\43\61\73\65" }>, align 8
@G_2ecompiler_2flower_2eFailWords.k5 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\45\6D\70\74\79" }>, align 8
@G_2ecompiler_2flower_2eInvalid = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2flower_2eOutOfBounds = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2flower_2eOverflow = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2flower_2eReachView = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2flower_2eSlotMax = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\01\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2flower_2eWrongCase = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
define dso_local { i64, [4 x i64] } @compiler_2flower_2eKnownOf(ptr %v0, { i64, [4 x i64] } %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca i64
  %l4 = alloca i64
  %l7 = alloca { i64, [4 x i64] }
  %l8 = alloca { i64, ptr }
  %rv = alloca { i64, [4 x i64] }
  %t17 = alloca { i64, [4 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i64 @compiler_2flower_2ewholeLocal({ i64, [4 x i64] } %a0)
  store i64 %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load i64, ptr %l4, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t7 = icmp sge i64 %t5, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  store { i64, ptr } %a1, ptr %l8, !tbaa !27
  %t10 = load i64, ptr %l2, !tbaa !24
  %t12 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, [4 x i64] }, ptr %t13, i64 %t10
  %t15 = load { i64, [4 x i64] }, ptr %t14
  store { i64, [4 x i64] } %t15, ptr %l7
  br label %bb4
bb3:
  store { i64, [4 x i64] } zeroinitializer, ptr %t17
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t17, i32 0, i32 0
  store i64 0, ptr %t18
  %t19 = load { i64, [4 x i64] }, ptr %t17
  store { i64, [4 x i64] } %t19, ptr %l7
  br label %bb4
bb4:
  %t21 = load { i64, [4 x i64] }, ptr %l7
  store { i64, [4 x i64] } %t21, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local i64 @compiler_2flower_2ebaseLocal(%"compiler/mir:Lvalue" %a0) #0 {
entry:
  %l0 = alloca %"compiler/mir:Lvalue"
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i32
  %l4 = alloca i64
  %rv = alloca i64
  store %"compiler/mir:Lvalue" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/mir:Lvalue", ptr %l0, i32 0, i32 0
  %t2 = load { i64, [2 x i64] }, ptr %t1
  store { i64, [2 x i64] } %t2, ptr %l1
  %t4 = load { i64, [2 x i64] }, ptr %l1
  %t6 = extractvalue { i64, [2 x i64] } %t4, 0
  %t7 = icmp eq i64 %t6, 1
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t10 = getelementptr { i32 }, ptr %t9, i32 0, i32 0
  %t11 = load i32, ptr %t10
  store i32 %t11, ptr %l2, !tbaa !23
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t13 = load i32, ptr %l2, !tbaa !23
  %t15 = sext i32 %t13 to i64
  store i64 %t15, ptr %l4, !tbaa !24
  br label %bb9
bb4:
  br i1 true, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i64 -1, ptr %l4, !tbaa !24
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_e95d68e3d7cba01a_696ee7b39c9f410e)
  unreachable
bb9:
  %t17 = load i64, ptr %l4, !tbaa !24
  store i64 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2flower_2ecallSiteOf(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i1
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i1
  %l32 = alloca i64
  %l38 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Call", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %t18, !tbaa !23
  %t21 = sext i32 %t19 to i64
  store i64 %t21, ptr %l4, !tbaa !24
  br label %bb31
bb6:
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t24 = load ptr, ptr %l14, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb7, label %bb8
bb7:
  %t27 = load ptr, ptr %l14, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 18}
  %t30 = icmp eq i64 %t28, 17
  store i1 %t30, ptr %l15, !tbaa !21
  br label %bb8
bb8:
  %t31 = load i1, ptr %l15, !tbaa !21
  br i1 %t31, label %bb9, label %bb10
bb9:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr { i64, [5 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t34, i32 0, i32 2
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t38 = load ptr, ptr %l2, !tbaa !29
  %t40 = call i64 @compiler_2flower_2ecallSiteOf(ptr %v0, ptr %t38)
  store i64 %t40, ptr %l21
  br label %bb12
bb12:
  %t41 = load i64, ptr %l21, !tbaa !24
  store i64 %t41, ptr %l4, !tbaa !24
  br label %bb31
bb13:
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t43 = load ptr, ptr %l22, !tbaa !29
  %t44 = icmp ne ptr %t43, null
  br i1 %t44, label %bb14, label %bb15
bb14:
  %t46 = load ptr, ptr %l22, !tbaa !29
  %t47 = load i64, ptr %t46, !range !{i64 0, i64 18}
  %t49 = icmp eq i64 %t47, 14
  store i1 %t49, ptr %l23, !tbaa !21
  br label %bb15
bb15:
  %t50 = load i1, ptr %l23, !tbaa !21
  br i1 %t50, label %bb16, label %bb17
bb16:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr { i64, [5 x i64] }, ptr %t51, i32 0, i32 1
  %t54 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t53, i32 0, i32 2
  %t55 = load ptr, ptr %t54
  store ptr %t55, ptr %l3, !tbaa !29
  br label %bb18
bb17:
  br label %bb26
bb18:
  %t57 = load ptr, ptr %l3, !tbaa !29
  %t59 = getelementptr %"compiler/typed:Try", ptr %t57, i32 0, i32 0
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = icmp eq ptr %t60, null
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb19, label %bb20
bb19:
  %t66 = load ptr, ptr %l3, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Try", ptr %t66, i32 0, i32 0
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = icmp eq ptr %t69, null
  br i1 %t71, label %bb21, label %bb22
bb20:
  store i64 -1, ptr %l32, !tbaa !24
  br label %bb25
bb21:
  call void @__olang_check_failed(ptr @olang_loc_4ca96ca743817bc9_2683ea67216c5235)
  unreachable
bb22:
  br label %bb23
bb23:
  %t73 = load ptr, ptr %l3, !tbaa !29
  %t75 = getelementptr %"compiler/typed:Try", ptr %t73, i32 0, i32 0
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = call i64 @compiler_2flower_2ecallSiteOf(ptr %v0, ptr %t76)
  store i64 %t78, ptr %l38
  br label %bb24
bb24:
  %t79 = load i64, ptr %l38, !tbaa !24
  store i64 %t79, ptr %l32, !tbaa !24
  br label %bb25
bb25:
  %t80 = load i64, ptr %l32, !tbaa !24
  store i64 %t80, ptr %l4, !tbaa !24
  br label %bb31
bb26:
  br i1 true, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  store i64 -1, ptr %l4, !tbaa !24
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_43f32b3576b8b411_d6dff2521676819d)
  unreachable
bb31:
  %t81 = load i64, ptr %l4, !tbaa !24
  store i64 %t81, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2flower_2ecloneKey(ptr %v0, { i64, [2 x i64] } %a0, i64 %a1, { i64, [2 x i64] } %a2, i32 %a3) #0 {
entry:
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca i64
  %l6 = alloca { i64, [2 x i64] }
  %l7 = alloca i32
  %l10 = alloca { i64, ptr }
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store { i64, [2 x i64] } %a0, ptr %l4
  store i64 %a1, ptr %l5, !tbaa !24
  store { i64, [2 x i64] } %a2, ptr %l6
  store i32 %a3, ptr %l7, !tbaa !23
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2fmir_3aFnKey(ptr %s1, ptr %l4, i64 0)
  br label %bb1
bb1:
  %t6 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = load i64, ptr %l5, !tbaa !24
  %t9 = call ptr @__olang_sb_room(ptr %s1, i64 24)
  %t10 = call i64 @__olang_fmt_i64(ptr %t9, i64 %t8)
  call void @__olang_sb_add(ptr %s1, i64 %t10)
  %t11 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2fmir_3aFnKey(ptr %s1, ptr %l6, i64 0)
  br label %bb2
bb2:
  %t14 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t14, i64 %t15)
  %t16 = load i32, ptr %l7, !tbaa !23
  %t17 = sext i32 %t16 to i64
  %t18 = call ptr @__olang_sb_room(ptr %s1, i64 24)
  %t19 = call i64 @__olang_fmt_i64(ptr %t18, i64 %t17)
  call void @__olang_sb_add(ptr %s1, i64 %t19)
  %t20 = load ptr, ptr %s1
  %t21 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t22 = load i64, ptr %t21
  %t23 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t22)
  call void @olang_textcopy(ptr %t23, ptr %t20, i64 %t22)
  %t24 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l10, !tbaa !27
  %t26 = getelementptr %olang.builder, ptr %s1, i32 0, i32 3
  %t27 = load ptr, ptr %t26
  %t28 = icmp ne ptr %t27, null
  br i1 %t28, label %sbgrew.29, label %sbdone.30
sbgrew.29:
  call void @__olang_sb_done(ptr %s1)
  br label %sbdone.30
sbdone.30:
  %t31 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t31, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2eClonable(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca i64
  %l6 = alloca i64
  %l14 = alloca i1
  %l17 = alloca i1
  %l24 = alloca ptr
  %l27 = alloca i1
  %l32 = alloca ptr
  %l36 = alloca i64
  %l37 = alloca i1
  %l39 = alloca i1
  %l44 = alloca ptr
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l2, !tbaa !23
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t10 = load i32, ptr %l2, !tbaa !23
  %t12 = sext i32 %t10 to i64
  store i64 %t12, ptr %l6, !tbaa !24
  br label %bb9
bb4:
  br i1 true, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i64 -1, ptr %l6, !tbaa !24
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_5e1828c4865d22a_113428759accc96)
  unreachable
bb9:
  %t14 = load i64, ptr %l6, !tbaa !24
  store i64 %t14, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l3, !tbaa !24
  %t17 = icmp slt i64 %t15, 0
  br i1 %t17, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb13
bb11:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load i64, ptr %l3, !tbaa !24
  %t23 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2eHasCode(ptr %v0, ptr %t19, i64 %t20)
  store i1 %t23, ptr %l17
  br label %bb12
bb12:
  %t24 = load i1, ptr %l17, !tbaa !21
  %t25 = xor i1 %t24, true
  store i1 %t25, ptr %l14, !tbaa !21
  br label %bb13
bb13:
  %t27 = load i1, ptr %l14, !tbaa !21
  br i1 %t27, label %bb14, label %bb15
bb14:
  store i1 false, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/lower:Lowerer", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = load i64, ptr %l3, !tbaa !24
  %t37 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t32, i64 %t34)
  store ptr %t37, ptr %l24
  br label %bb17
bb17:
  %t38 = load ptr, ptr %l24, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Body", ptr %t38, i32 0, i32 1
  %t41 = load { i64, [2 x i64] }, ptr %t40
  store { i64, [2 x i64] } %t41, ptr %l4
  %t43 = load { i64, [2 x i64] }, ptr %l4
  %t45 = extractvalue { i64, [2 x i64] } %t43, 0
  %t46 = icmp eq i64 %t45, 0
  br i1 %t46, label %bb18, label %bb19
bb18:
  %t48 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t49 = getelementptr { i64 }, ptr %t48, i32 0, i32 0
  %t50 = load i64, ptr %t49
  store i64 %t50, ptr %l5, !tbaa !24
  br label %bb20
bb19:
  br label %bb27
bb20:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/lower:Lowerer", ptr %t52, i32 0, i32 0
  %t55 = load ptr, ptr %t54, !tbaa !29
  store ptr %t55, ptr %l32, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/lower:Lowerer", ptr %t56, i32 0, i32 0
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t60 = load i64, ptr %l5, !tbaa !24
  %t63 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t59, i64 %t60)
  store i64 %t63, ptr %l36
  br label %bb21
bb21:
  %t64 = load ptr, ptr %l32, !tbaa !29
  %t65 = load i64, ptr %l36, !tbaa !24
  %t66 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsGenerator(ptr %v0, ptr %t64, i64 %t65)
  store i1 %t66, ptr %l37
  br label %bb22
bb22:
  %t67 = load i1, ptr %l37, !tbaa !21
  %t68 = xor i1 %t67, true
  br i1 %t68, label %bb23, label %bb24
bb23:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/lower:Lowerer", ptr %t70, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = load i64, ptr %l3, !tbaa !24
  %t78 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t73, i64 %t75)
  store ptr %t78, ptr %l44
  br label %bb25
bb24:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb26
bb25:
  %t79 = load ptr, ptr %l44, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Body", ptr %t79, i32 0, i32 14
  %t82 = load i1, ptr %t81, !tbaa !21
  %t84 = xor i1 %t82, true
  store i1 %t84, ptr %l39, !tbaa !21
  br label %bb26
bb26:
  %t86 = load i1, ptr %l39, !tbaa !21
  store i1 %t86, ptr %l27, !tbaa !21
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_6b9a8a26a5fa00eb_10c4e92198635bb7)
  unreachable
bb32:
  %t87 = load i1, ptr %l27, !tbaa !21
  store i1 %t87, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2flower_2ecompiler_2flower_3aLowerer_2eCloneOf(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i64 %a2, { i64, [2 x i64] } %a3, i32 %a4) #0 {
entry:
  %l5 = alloca i64
  %l7 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %a0, i32 0, i32 53
  store ptr %t3, ptr %l7, !tbaa !29
  %t12 = call { i64, ptr } @compiler_2flower_2ecloneKey(ptr %s0, { i64, [2 x i64] } %a1, i64 %a2, { i64, [2 x i64] } %a3, i32 %a4)
  store { i64, ptr } %t12, ptr %l12
  br label %bb1
bb1:
  %t13 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t14 = load ptr, ptr %l7, !tbaa !29
  %t16 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %s0, ptr %t14, { i64, ptr } %t13)
  %t17 = extractvalue { i32, i64 } %t16, 1
  %t18 = extractvalue { i32, i64 } %t16, 0
  store i32 %t18, ptr %l15
  %t19 = icmp ne i32 %t18, 0
  br i1 %t19, label %bb3, label %ok.20, !prof !99
ok.20:
  store i64 %t17, ptr %l14
  br label %bb2
bb2:
  %t21 = load i64, ptr %l14, !tbaa !24
  store i64 %t21, ptr %l5, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  store i64 -1, ptr %l5, !tbaa !24
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t22 = load i64, ptr %l5, !tbaa !24
  store i64 %t22, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2flower_2ecompiler_2flower_3aLowerer_2eCloneSumKeys(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l8 = alloca { i64, [2 x i64] }
  %l10 = alloca { i64, [2 x i64] }
  %l11 = alloca i32
  %l13 = alloca i1
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l4
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t5 = getelementptr %"compiler/lower:Lowerer", ptr %a0, i32 0, i32 56
  %t7 = call %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20I64_3e_2eK_H93b9e30c66e0d3e1f5b32cd94e4351ed(ptr %v0, ptr %v0, ptr %t5)
  store %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" %t7, ptr %l7
  br label %bb2
bb2:
  %t8 = load %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l7
  store %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" %t8, ptr %l2
  br label %bb3
bb3:
  %t10 = call { i32, { i64, [2 x i64] } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapKeyIter_3ccompiler_2fmir_3aFnKey_2c_20I64_H71b42e541b2116ff991c89abd32c4a9f(ptr %v0, ptr %l2)
  %t11 = extractvalue { i32, { i64, [2 x i64] } } %t10, 1
  %t12 = extractvalue { i32, { i64, [2 x i64] } } %t10, 0
  store i32 %t12, ptr %l11
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb5, label %ok.14, !prof !99
ok.14:
  store { i64, [2 x i64] } %t11, ptr %l10
  br label %bb4
bb4:
  %t15 = load { i64, [2 x i64] }, ptr %l10
  store { i64, [2 x i64] } %t15, ptr %l8
  br label %bb7
bb5:
  %t16 = load i32, ptr %l11, !tbaa !23
  %t17 = ashr i32 %t16, 16
  %t19 = icmp eq i32 %t17, 1
  store i1 %t19, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  br label %bb10
bb7:
  %t20 = load { i64, [2 x i64] }, ptr %l8
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v1, ptr %l1, { i64, [2 x i64] } %t20)
  br label %bb8
bb8:
  br label %bb9
bb9:
  br label %bb3
bb10:
  %t24 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local { i64, [2 x i64] } @compiler_2flower_2ecompiler_2flower_3aLowerer_2eCodeOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l1 = alloca i32
  %l4 = alloca i64
  %l6 = alloca { i64, [2 x i64] }
  %rv = alloca { i64, [2 x i64] }
  %t10 = alloca { i64, [2 x i64] }, align 8
  %t18 = alloca { i64, [2 x i64] }, align 8
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i64 @compiler_2flower_2ecompiler_2flower_3aLowerer_2eViewsOf(ptr %v0, ptr %a0, i32 %t2)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = icmp sgt i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load i32, ptr %l1, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t10
  %t11 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 0
  store i64 2, ptr %t11
  %t13 = insertvalue { i32 } undef, i32 %t9, 0
  %t14 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  store { i32 } %t13, ptr %t14
  %t15 = load { i64, [2 x i64] }, ptr %t10
  store { i64, [2 x i64] } %t15, ptr %l6
  br label %bb4
bb3:
  %t17 = load i32, ptr %l1, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t18
  %t19 = getelementptr { i64, [2 x i64] }, ptr %t18, i32 0, i32 0
  store i64 0, ptr %t19
  %t21 = insertvalue { i32 } undef, i32 %t17, 0
  %t22 = getelementptr { i64, [2 x i64] }, ptr %t18, i32 0, i32 1
  store { i32 } %t21, ptr %t22
  %t23 = load { i64, [2 x i64] }, ptr %t18
  store { i64, [2 x i64] } %t23, ptr %l6
  br label %bb4
bb4:
  %t25 = load { i64, [2 x i64] }, ptr %l6
  store { i64, [2 x i64] } %t25, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eDecideGen(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l11 = alloca i64
  %l15 = alloca i64
  %l18 = alloca i64
  %l36 = alloca ptr
  %l37 = alloca i64
  %l43 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 10
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l11
  br label %bb1
bb1:
  %t12 = load i64, ptr %l11, !tbaa !24
  store i64 %t12, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t13 = load i64, ptr %l2, !tbaa !24
  %t14 = load i64, ptr %l1, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb2, label %bb3
bb2:
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb7
bb4:
  %t23 = load i64, ptr %l2, !tbaa !24
  %t24 = load i64, ptr %l1, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l3, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l18, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb6
bb6:
  %t39 = load i64, ptr %l18, !tbaa !24
  store i64 %t39, ptr %l15, !tbaa !24
  br label %bb7
bb7:
  %t40 = load i64, ptr %l15, !tbaa !24
  store i64 %t40, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  %t41 = load i64, ptr %l5, !tbaa !24
  %t42 = load i64, ptr %l4, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb9, label %bb10
bb9:
  br label %bb15
bb10:
  br label %bb11
bb11:
  %t49 = load i64, ptr %l1, !tbaa !24
  %t50 = load i64, ptr %l5, !tbaa !24
  %t51 = load i64, ptr %l3, !tbaa !24
  %t54 = mul i64 %t50, %t51
  %t57 = add i64 %t49, %t54
  store i64 %t57, ptr %l6, !tbaa !24
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l36, !tbaa !29
  %t60 = load i64, ptr %l6, !tbaa !24
  store i64 %t60, ptr %l37, !tbaa !24
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/lower:Lowerer", ptr %t61, i32 0, i32 0
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t66 = getelementptr %"compiler/generic:Program", ptr %t64, i32 0, i32 0
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/load:Loader", ptr %t67, i32 0, i32 10
  %t70 = load i64, ptr %l6, !tbaa !24
  %t73 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t69, i64 %t70)
  store ptr %t73, ptr %l43
  br label %bb12
bb12:
  %t74 = load ptr, ptr %l43, !tbaa !29
  %t76 = getelementptr %"compiler/load:Module", ptr %t74, i32 0, i32 8
  %t77 = load { i64, ptr }, ptr %t76, !tbaa !27
  %t78 = load ptr, ptr %l36, !tbaa !29
  %t79 = load i64, ptr %l37, !tbaa !24
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2edecideGen(ptr %v0, ptr %v0, ptr %t78, i64 %t79, { i64, ptr } %t77)
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t81 = load i64, ptr %l5, !tbaa !24
  %t84 = add i64 %t81, 1
  store i64 %t84, ptr %l5, !tbaa !24
  br label %bb8
bb15:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eDecideWrites(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l11 = alloca i64
  %l15 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l42 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 9
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l11
  br label %bb1
bb1:
  %t12 = load i64, ptr %l11, !tbaa !24
  %t13 = icmp eq i64 %t12, 0
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  store i64 0, ptr %l1, !tbaa !24
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/lower:Lowerer", ptr %t15, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t18)
  store i64 %t20, ptr %l15
  br label %bb5
bb5:
  %t21 = load i64, ptr %l15, !tbaa !24
  store i64 %t21, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t22 = load i64, ptr %l2, !tbaa !24
  %t23 = load i64, ptr %l1, !tbaa !24
  %t26 = icmp sgt i64 %t22, %t23
  br i1 %t26, label %bb6, label %bb7
bb6:
  %t28 = load i64, ptr %l3, !tbaa !24
  %t30 = icmp sgt i64 %t28, 0
  br i1 %t30, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb11
bb8:
  %t32 = load i64, ptr %l2, !tbaa !24
  %t33 = load i64, ptr %l1, !tbaa !24
  %t36 = sub i64 %t32, %t33
  %t37 = load i64, ptr %l3, !tbaa !24
  %t40 = add i64 %t36, %t37
  %t42 = sub i64 %t40, 1
  %t43 = load i64, ptr %l3, !tbaa !24
  %t46 = sdiv i64 %t42, %t43
  store i64 %t46, ptr %l22, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb10
bb10:
  %t48 = load i64, ptr %l22, !tbaa !24
  store i64 %t48, ptr %l19, !tbaa !24
  br label %bb11
bb11:
  %t49 = load i64, ptr %l19, !tbaa !24
  store i64 %t49, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t50 = load i64, ptr %l5, !tbaa !24
  %t51 = load i64, ptr %l4, !tbaa !24
  %t54 = icmp slt i64 %t50, %t51
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb14:
  br label %bb15
bb15:
  %t58 = load i64, ptr %l1, !tbaa !24
  %t59 = load i64, ptr %l5, !tbaa !24
  %t60 = load i64, ptr %l3, !tbaa !24
  %t63 = mul i64 %t59, %t60
  %t66 = add i64 %t58, %t63
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t72 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3aLowerer_2ewritesFact(ptr %v0, ptr %s3, ptr %t68, i64 %t66)
  store { i64, ptr } %t72, ptr %l42
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb17:
  %t73 = load i64, ptr %l5, !tbaa !24
  %t76 = add i64 %t73, 1
  store i64 %t76, ptr %l5, !tbaa !24
  br label %bb12
bb18:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2flower_2ecompiler_2flower_3aLowerer_2eGen(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l3 = alloca %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l7 = alloca i1
  %l11 = alloca i64
  %l19 = alloca %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l20 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i32
  %l25 = alloca i1
  %l32 = alloca %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l33 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca i32
  %l38 = alloca i1
  %l39 = alloca i64
  %l40 = alloca { i64, ptr }
  %s5 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %t1, i32 0, i32 50
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb4
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:Lowerer", ptr %t6, i32 0, i32 0
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 5
  %t13 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_Ha270003b2266a12c55eea6eacf9a4be1(ptr %v0, ptr %t11)
  store i64 %t13, ptr %l11
  br label %bb3
bb3:
  %t14 = load i64, ptr %l11, !tbaa !24
  %t15 = icmp eq i64 %t14, 0
  store i1 %t15, ptr %l7, !tbaa !21
  br label %bb4
bb4:
  %t17 = load i1, ptr %l7, !tbaa !21
  br i1 %t17, label %bb5, label %bb6
bb5:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/lower:Lowerer", ptr %t18, i32 0, i32 49
  store ptr %t20, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/lower:Lowerer", ptr %t22, i32 0, i32 50
  store i1 true, ptr %t24, !tbaa !21
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/lower:Lowerer", ptr %t25, i32 0, i32 0
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/generic:Program", ptr %t28, i32 0, i32 5
  %t32 = call %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_H3054d603499f3fef5e3f6df62ca84cee(ptr %v0, ptr %v0, ptr %t30)
  store %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" %t32, ptr %l19
  br label %bb8
bb8:
  %t33 = load %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l19
  store %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" %t33, ptr %l1
  br label %bb9
bb9:
  %t35 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapKeyIter_3cI64_2c_20std_2fprelude_2ftext_3_H9d7da39dd81a932fb2b877accbcd070c(ptr %v0, ptr %l1)
  %t36 = extractvalue { i32, i64 } %t35, 1
  %t37 = extractvalue { i32, i64 } %t35, 0
  store i32 %t37, ptr %l23
  %t38 = icmp ne i32 %t37, 0
  br i1 %t38, label %bb11, label %ok.39, !prof !99
ok.39:
  store i64 %t36, ptr %l22
  br label %bb10
bb10:
  %t40 = load i64, ptr %l22, !tbaa !24
  store i64 %t40, ptr %l20, !tbaa !24
  br label %bb13
bb11:
  %t41 = load i32, ptr %l23, !tbaa !23
  %t42 = ashr i32 %t41, 16
  %t44 = icmp eq i32 %t42, 1
  store i1 %t44, ptr %l25, !tbaa !21
  br label %bb12
bb12:
  br label %bb16
bb13:
  %t45 = load i64, ptr %l20, !tbaa !24
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/lower:Lowerer", ptr %t46, i32 0, i32 49
  %t49 = getelementptr %"compiler/mir:GenInfo", ptr %t48, i32 0, i32 0
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t49, i64 %t45, i1 true)
  br label %bb14
bb14:
  br label %bb15
bb15:
  br label %bb9
bb16:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/lower:Lowerer", ptr %t53, i32 0, i32 0
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = getelementptr %"compiler/generic:Program", ptr %t56, i32 0, i32 7
  %t60 = call %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20Boo_Hc20348a7e3f4966d079d7d53957fcef1(ptr %v0, ptr %v0, ptr %t58)
  store %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" %t60, ptr %l32
  br label %bb17
bb17:
  %t61 = load %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l32
  store %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" %t61, ptr %l3
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s5
  %t63 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapKeyIter_3cstd_2fprelude_2ftext_3aString_2_H25a1fa74df5469e35efe3ff4130517ef(ptr %v0, ptr %s5, ptr %l3)
  %t64 = extractvalue { i32, { i64, ptr } } %t63, 1
  %t65 = extractvalue { i32, { i64, ptr } } %t63, 0
  store i32 %t65, ptr %l36
  %t66 = icmp ne i32 %t65, 0
  br i1 %t66, label %bb20, label %ok.67, !prof !99
ok.67:
  store { i64, ptr } %t64, ptr %l35
  br label %bb19
bb19:
  %t68 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  store i64 %t69, ptr %l39, !tbaa !24
  %t70 = load i64, ptr %l39, !tbaa !24
  %t71 = mul i64 %t70, 1
  %t72 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t71)
  %t73 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  store { i64, ptr } %t74, ptr %l40, !tbaa !27
  %t75 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = load i64, ptr %l39, !tbaa !24
  %t80 = mul i64 %t79, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t76, ptr %t78, i64 %t80, i1 false)
  %t81 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t81, ptr %l33, !tbaa !27
  br label %bb22
bb20:
  %t82 = load i32, ptr %l36, !tbaa !23
  %t83 = ashr i32 %t82, 16
  %t85 = icmp eq i32 %t83, 1
  store i1 %t85, ptr %l38, !tbaa !21
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s5)
  br label %bb25
bb22:
  %t86 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/lower:Lowerer", ptr %t87, i32 0, i32 49
  %t90 = getelementptr %"compiler/mir:GenInfo", ptr %t89, i32 0, i32 1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20Boo_H6b1fa5c8028973ecd947936aac3caef3(ptr %v0, ptr %t90, { i64, ptr } %t86, i1 true)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s5)
  br label %bb24
bb24:
  br label %bb18
bb25:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/lower:Lowerer", ptr %t94, i32 0, i32 49
  store ptr %t96, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2eHandsOnly(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %l8 = alloca i1
  %l9 = alloca i64
  %l12 = alloca i64
  %l14 = alloca i1
  %l22 = alloca i1
  %l26 = alloca i1
  %l27 = alloca i32
  %l31 = alloca ptr
  %l35 = alloca ptr
  %l37 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l9, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:Lowerer", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l12
  br label %bb3
bb3:
  %t12 = load i64, ptr %l9, !tbaa !24
  %t13 = load i64, ptr %l12, !tbaa !24
  %t14 = icmp sge i64 %t12, %t13
  store i1 %t14, ptr %l8, !tbaa !21
  br label %bb4
bb4:
  %t16 = load i1, ptr %l8, !tbaa !21
  br i1 %t16, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb7
bb6:
  %t17 = load i64, ptr %l2, !tbaa !24
  %t19 = icmp sge i64 %t17, 64
  store i1 %t19, ptr %l14, !tbaa !21
  br label %bb7
bb7:
  %t21 = load i1, ptr %l14, !tbaa !21
  br i1 %t21, label %bb8, label %bb9
bb8:
  store i1 false, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t23 = load i64, ptr %l1, !tbaa !24
  %t25 = mul i64 %t23, 64
  %t26 = load i64, ptr %l2, !tbaa !24
  %t29 = add i64 %t25, %t26
  store i64 %t29, ptr %l3, !tbaa !24
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/lower:Lowerer", ptr %t31, i32 0, i32 41
  %t34 = load i64, ptr %l3, !tbaa !24
  %t37 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %t33, i64 %t34)
  %t38 = extractvalue { i32, i1 } %t37, 1
  %t39 = extractvalue { i32, i1 } %t37, 0
  store i32 %t39, ptr %l27
  %t40 = icmp ne i32 %t39, 0
  br i1 %t40, label %bb12, label %ok.41, !prof !99
ok.41:
  store i1 %t38, ptr %l26
  br label %bb11
bb11:
  %t42 = load i1, ptr %l26, !tbaa !21
  store i1 %t42, ptr %l22, !tbaa !21
  br label %bb18
bb12:
  br label %bb13
bb13:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/lower:Lowerer", ptr %t43, i32 0, i32 41
  %t46 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t45, i64 %t46, i1 false)
  br label %bb14
bb14:
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l31, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/lower:Lowerer", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t54 = load i64, ptr %l1, !tbaa !24
  %t57 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t53, i64 %t54)
  store ptr %t57, ptr %l35
  br label %bb15
bb15:
  %t58 = load i64, ptr %l2, !tbaa !24
  %t59 = load ptr, ptr %l31, !tbaa !29
  %t60 = load ptr, ptr %l35, !tbaa !29
  %t62 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ehandsBack(ptr %v0, ptr %v0, ptr %t59, ptr %t60, i64 %t58)
  store i1 %t62, ptr %l37
  br label %bb16
bb16:
  %t63 = load i1, ptr %l37, !tbaa !21
  store i1 %t63, ptr %l4, !tbaa !21
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/lower:Lowerer", ptr %t64, i32 0, i32 41
  %t67 = load i64, ptr %l3, !tbaa !24
  %t68 = load i1, ptr %l4, !tbaa !21
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t66, i64 %t67, i1 %t68)
  br label %bb17
bb17:
  %t72 = load i1, ptr %l4, !tbaa !21
  store i1 %t72, ptr %rv
  br label %ret
bb18:
  %t74 = load i1, ptr %l22, !tbaa !21
  store i1 %t74, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2flower_2ecompiler_2flower_3aLowerer_2eLowerKey(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i1
  %l18 = alloca ptr
  %l26 = alloca %"compiler/mir:Fn"
  %l33 = alloca %"compiler/mir:Fn"
  %l40 = alloca %"compiler/mir:Fn"
  %l50 = alloca ptr
  %l56 = alloca %"compiler/mir:Fn"
  %l65 = alloca %"compiler/mir:Fn"
  %rv = alloca ptr
  %t34 = alloca %"compiler/mir:Fn", align 8
  %t51 = alloca %"compiler/mir:Fn", align 8
  %t67 = alloca %"compiler/mir:Fn", align 8
  %t106 = alloca %"compiler/mir:Fn", align 8
  %t127 = alloca %"compiler/mir:Fn", align 8
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l2, !tbaa !23
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l2, !tbaa !23
  %t13 = sext i32 %t11 to i64
  %t16 = call ptr @compiler_2flower_2ecompiler_2flower_3aLowerer_2eLower(ptr %v0, ptr %v1, ptr %t10, i64 %t13)
  store ptr %t16, ptr %l18
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l18, !tbaa !29
  store ptr %t17, ptr %rv
  br label %ret
bb5:
  %t18 = load { i64, [2 x i64] }, ptr %l1
  %t20 = extractvalue { i64, [2 x i64] } %t18, 0
  %t21 = icmp eq i64 %t20, 3
  br i1 %t21, label %bb6, label %bb7
bb6:
  %t23 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t24 = getelementptr { i32, i32 }, ptr %t23, i32 0, i32 0
  %t25 = load i32, ptr %t24, !range !{i32 0, i32 10}
  store i32 %t25, ptr %l3
  %t27 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t28 = getelementptr { i32, i32 }, ptr %t27, i32 0, i32 1
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l4, !tbaa !23
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l3, !range !{i32 0, i32 10}
  %t33 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2ehelper(ptr %t34, ptr %v0, ptr %v1, ptr %t31, i32 %t32, i32 %t33)
  call void @llvm.memmove.p0.p0.i64(ptr %l26, ptr %t34, i64 808, i1 false)
  br label %bb9
bb9:
  %t38 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 808, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t38, ptr %l26, i64 808, i1 false)
  store ptr %t38, ptr %rv
  br label %ret
bb10:
  %t40 = load { i64, [2 x i64] }, ptr %l1
  %t42 = extractvalue { i64, [2 x i64] } %t40, 0
  %t43 = icmp eq i64 %t42, 1
  br i1 %t43, label %bb11, label %bb12
bb11:
  %t45 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t46 = getelementptr { i32 }, ptr %t45, i32 0, i32 0
  %t47 = load i32, ptr %t46
  store i32 %t47, ptr %l5, !tbaa !23
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i32, ptr %l5, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eadapterFn(ptr %t51, ptr %v0, ptr %v1, ptr %t49, i32 %t50)
  call void @llvm.memmove.p0.p0.i64(ptr %l33, ptr %t51, i64 808, i1 false)
  br label %bb14
bb14:
  %t54 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 808, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t54, ptr %l33, i64 808, i1 false)
  store ptr %t54, ptr %rv
  br label %ret
bb15:
  %t56 = load { i64, [2 x i64] }, ptr %l1
  %t58 = extractvalue { i64, [2 x i64] } %t56, 0
  %t59 = icmp eq i64 %t58, 2
  br i1 %t59, label %bb16, label %bb17
bb16:
  %t61 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t62 = getelementptr { i32 }, ptr %t61, i32 0, i32 0
  %t63 = load i32, ptr %t62
  store i32 %t63, ptr %l6, !tbaa !23
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2ecopiedFn(ptr %t67, ptr %v0, ptr %v1, ptr %t65, i32 %t66)
  call void @llvm.memmove.p0.p0.i64(ptr %l40, ptr %t67, i64 808, i1 false)
  br label %bb19
bb19:
  %t70 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 808, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t70, ptr %l40, i64 808, i1 false)
  store ptr %t70, ptr %rv
  br label %ret
bb20:
  %t72 = load { i64, [2 x i64] }, ptr %l1
  %t74 = extractvalue { i64, [2 x i64] } %t72, 0
  %t75 = icmp eq i64 %t74, 6
  br i1 %t75, label %bb21, label %bb22
bb21:
  %t77 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t78 = getelementptr { i32, i64 }, ptr %t77, i32 0, i32 0
  %t79 = load i32, ptr %t78
  store i32 %t79, ptr %l7, !tbaa !23
  %t81 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t82 = getelementptr { i32, i64 }, ptr %t81, i32 0, i32 1
  %t83 = load i64, ptr %t82
  store i64 %t83, ptr %l8, !tbaa !24
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i32, ptr %l7, !tbaa !23
  %t88 = sext i32 %t86 to i64
  %t89 = load i64, ptr %l8, !tbaa !24
  %t93 = call ptr @compiler_2flower_2ecompiler_2flower_3aLowerer_2elowerAs(ptr %v0, ptr %v1, ptr %t85, i64 %t88, i64 %t89)
  store ptr %t93, ptr %l50
  br label %bb24
bb24:
  %t94 = load ptr, ptr %l50, !tbaa !29
  store ptr %t94, ptr %rv
  br label %ret
bb25:
  %t95 = load { i64, [2 x i64] }, ptr %l1
  %t97 = extractvalue { i64, [2 x i64] } %t95, 0
  %t98 = icmp eq i64 %t97, 4
  br i1 %t98, label %bb26, label %bb27
bb26:
  %t100 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t101 = getelementptr { i64 }, ptr %t100, i32 0, i32 0
  %t102 = load i64, ptr %t101
  store i64 %t102, ptr %l9, !tbaa !24
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load i64, ptr %l9, !tbaa !24
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2einitFn(ptr %t106, ptr %v0, ptr %v1, ptr %t104, i64 %t105)
  call void @llvm.memmove.p0.p0.i64(ptr %l56, ptr %t106, i64 808, i1 false)
  br label %bb29
bb29:
  %t109 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 808, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t109, ptr %l56, i64 808, i1 false)
  store ptr %t109, ptr %rv
  br label %ret
bb30:
  %t111 = load { i64, [2 x i64] }, ptr %l1
  %t113 = extractvalue { i64, [2 x i64] } %t111, 0
  %t114 = icmp eq i64 %t113, 5
  br i1 %t114, label %bb31, label %bb32
bb31:
  %t116 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t117 = getelementptr { i64, i1 }, ptr %t116, i32 0, i32 0
  %t118 = load i64, ptr %t117
  store i64 %t118, ptr %l10, !tbaa !24
  %t120 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t121 = getelementptr { i64, i1 }, ptr %t120, i32 0, i32 1
  %t122 = load i1, ptr %t121
  store i1 %t122, ptr %l11, !tbaa !21
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load i64, ptr %l10, !tbaa !24
  %t126 = load i1, ptr %l11, !tbaa !21
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eanyRender(ptr %t127, ptr %v0, ptr %v1, ptr %t124, i64 %t125, i1 %t126)
  call void @llvm.memmove.p0.p0.i64(ptr %l65, ptr %t127, i64 808, i1 false)
  br label %bb34
bb34:
  %t131 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 808, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t131, ptr %l65, i64 808, i1 false)
  store ptr %t131, ptr %rv
  br label %ret
bb35:
  call void @__olang_check_failed(ptr @olang_loc_3c213ca88cac8ac4_ee776128d38d19e0)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2eStartsAlloc(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca %"compiler/typed:LocalUses"
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca ptr
  %l13 = alloca i1
  %l14 = alloca i64
  %l17 = alloca i64
  %l19 = alloca i1
  %l24 = alloca i64
  %l27 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i32
  %l40 = alloca ptr
  %l45 = alloca i1
  %l61 = alloca %"compiler/typed:LocalUses"
  %l63 = alloca i64
  %l66 = alloca i64
  %l68 = alloca i64
  %l73 = alloca ptr
  %l75 = alloca i1
  %l79 = alloca i1
  %l85 = alloca ptr
  %l86 = alloca i64
  %l88 = alloca i64
  %rv = alloca i1
  %t106 = alloca %"compiler/typed:LocalUses", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l14, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:Lowerer", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l17
  br label %bb3
bb3:
  %t12 = load i64, ptr %l14, !tbaa !24
  %t13 = load i64, ptr %l17, !tbaa !24
  %t14 = icmp sge i64 %t12, %t13
  store i1 %t14, ptr %l13, !tbaa !21
  br label %bb4
bb4:
  %t16 = load i1, ptr %l13, !tbaa !21
  br i1 %t16, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb8
bb6:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i64, ptr %l1, !tbaa !24
  %t20 = trunc i64 %t18 to i32
  %t24 = call i64 @compiler_2flower_2ecompiler_2flower_3aLowerer_2eViewsOf(ptr %v0, ptr %t17, i32 %t20)
  store i64 %t24, ptr %l24
  br label %bb7
bb7:
  %t25 = load i64, ptr %l24, !tbaa !24
  %t26 = icmp ne i64 %t25, 0
  store i1 %t26, ptr %l19, !tbaa !21
  br label %bb8
bb8:
  %t28 = load i1, ptr %l19, !tbaa !21
  br i1 %t28, label %bb9, label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/lower:Lowerer", ptr %t30, i32 0, i32 33
  %t33 = load i64, ptr %l1, !tbaa !24
  %t36 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t32, i64 %t33)
  %t37 = extractvalue { i32, i64 } %t36, 1
  %t38 = extractvalue { i32, i64 } %t36, 0
  store i32 %t38, ptr %l32
  %t39 = icmp ne i32 %t38, 0
  br i1 %t39, label %bb13, label %ok.40, !prof !99
ok.40:
  store i64 %t37, ptr %l31
  br label %bb12
bb12:
  %t41 = load i64, ptr %l31, !tbaa !24
  store i64 %t41, ptr %l27, !tbaa !24
  br label %bb15
bb13:
  br label %bb14
bb14:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb15
bb15:
  %t42 = load i64, ptr %l27, !tbaa !24
  store i64 %t42, ptr %l2, !tbaa !24
  %t43 = load i64, ptr %l2, !tbaa !24
  %t45 = icmp ne i64 %t43, 0
  br i1 %t45, label %bb16, label %bb17
bb16:
  %t47 = load i64, ptr %l2, !tbaa !24
  %t49 = icmp eq i64 %t47, 1
  store i1 %t49, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/lower:Lowerer", ptr %t51, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t55 = load i64, ptr %l1, !tbaa !24
  %t58 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t54, i64 %t55)
  store ptr %t58, ptr %l40
  br label %bb19
bb19:
  %t59 = load ptr, ptr %l40, !tbaa !29
  store ptr %t59, ptr %l3, !tbaa !29
  %t60 = load ptr, ptr %l3, !tbaa !29
  %t62 = getelementptr %"compiler/typed:Body", ptr %t60, i32 0, i32 1
  %t63 = load { i64, [2 x i64] }, ptr %t62
  %t65 = extractvalue { i64, [2 x i64] } %t63, 0
  %t66 = icmp eq i64 %t65, 0
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb22
bb21:
  %t70 = load ptr, ptr %l3, !tbaa !29
  %t72 = getelementptr %"compiler/typed:Body", ptr %t70, i32 0, i32 1
  %t73 = getelementptr { i64, [2 x i64] }, ptr %t72, i32 0, i32 1
  %t74 = getelementptr { i64 }, ptr %t73, i32 0, i32 0
  %t75 = load i64, ptr %t74
  store i64 %t75, ptr %l4, !tbaa !24
  %t77 = load ptr, ptr %l3, !tbaa !29
  %t79 = getelementptr %"compiler/typed:Body", ptr %t77, i32 0, i32 11
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = icmp eq ptr %t80, null
  store i1 %t82, ptr %l45, !tbaa !21
  br label %bb22
bb22:
  %t84 = load i1, ptr %l45, !tbaa !21
  br i1 %t84, label %bb23, label %bb24
bb23:
  store i1 false, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t86 = load ptr, ptr %l3, !tbaa !29
  %t88 = getelementptr %"compiler/typed:Body", ptr %t86, i32 0, i32 1
  %t89 = getelementptr { i64, [2 x i64] }, ptr %t88, i32 0, i32 1
  %t90 = getelementptr { i64 }, ptr %t89, i32 0, i32 0
  %t91 = load i64, ptr %t90
  store i64 %t91, ptr %l5, !tbaa !24
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/lower:Lowerer", ptr %t93, i32 0, i32 33
  %t96 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t95, i64 %t96, i64 3)
  br label %bb26
bb26:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/lower:Lowerer", ptr %t99, i32 0, i32 0
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t104 = getelementptr %"compiler/generic:Program", ptr %t102, i32 0, i32 2
  %t105 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ftyped_2eLocalUses_2eUses(ptr %t106, ptr %v0, ptr %v0, ptr %v0, ptr %t104, ptr %t105)
  call void @llvm.memmove.p0.p0.i64(ptr %l61, ptr %t106, i64 1640, i1 false)
  br label %bb27
bb27:
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %l61, i64 1640, i1 false)
  %t109 = getelementptr %"compiler/typed:LocalUses", ptr %l6, i32 0, i32 31
  %t111 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t109)
  store i64 %t111, ptr %l63
  br label %bb28
bb28:
  %t112 = load i64, ptr %l63, !tbaa !24
  %t113 = icmp sgt i64 %t112, 0
  store i1 %t113, ptr %l7, !tbaa !21
  %t115 = getelementptr %"compiler/typed:LocalUses", ptr %l6, i32 0, i32 31
  store ptr %t115, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb29
bb29:
  %t117 = load i64, ptr %l9, !tbaa !24
  store i64 %t117, ptr %l66, !tbaa !24
  %t118 = load ptr, ptr %l8, !tbaa !29
  %t120 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t118)
  store i64 %t120, ptr %l68
  br label %bb30
bb30:
  %t121 = load i64, ptr %l66, !tbaa !24
  %t122 = load i64, ptr %l68, !tbaa !24
  %t123 = icmp slt i64 %t121, %t122
  %t125 = xor i1 %t123, true
  br i1 %t125, label %bb31, label %bb32
bb31:
  br label %bb43
bb32:
  br label %bb33
bb33:
  %t127 = load ptr, ptr %l8, !tbaa !29
  %t128 = load i64, ptr %l9, !tbaa !24
  %t131 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t127, i64 %t128)
  store ptr %t131, ptr %l73
  br label %bb34
bb34:
  %t132 = load ptr, ptr %l73, !tbaa !29
  store ptr %t132, ptr %l10, !tbaa !29
  %t133 = load i1, ptr %l7, !tbaa !21
  br i1 %t133, label %bb35, label %bb36
bb35:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load ptr, ptr %l10, !tbaa !29
  %t140 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2estartOf(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t135, ptr %l6, ptr %t136)
  store i1 %t140, ptr %l79
  br label %bb37
bb36:
  store i1 false, ptr %l75, !tbaa !21
  br label %bb38
bb37:
  %t141 = load i1, ptr %l79, !tbaa !21
  %t142 = xor i1 %t141, true
  store i1 %t142, ptr %l75, !tbaa !21
  br label %bb38
bb38:
  %t144 = load i1, ptr %l75, !tbaa !21
  br i1 %t144, label %bb39, label %bb40
bb39:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb41
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t145 = load i64, ptr %l9, !tbaa !24
  %t148 = add i64 %t145, 1
  store i64 %t148, ptr %l9, !tbaa !24
  br label %bb29
bb43:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/lower:Lowerer", ptr %t150, i32 0, i32 33
  store ptr %t152, ptr %l85, !tbaa !29
  %t153 = load i64, ptr %l1, !tbaa !24
  store i64 %t153, ptr %l86, !tbaa !24
  %t154 = load i1, ptr %l7, !tbaa !21
  br i1 %t154, label %bb44, label %bb45
bb44:
  store i64 1, ptr %l88, !tbaa !24
  br label %bb46
bb45:
  store i64 2, ptr %l88, !tbaa !24
  br label %bb46
bb46:
  %t156 = load ptr, ptr %l85, !tbaa !29
  %t157 = load i64, ptr %l86, !tbaa !24
  %t158 = load i64, ptr %l88, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t156, i64 %t157, i64 %t158)
  br label %bb47
bb47:
  %t159 = load i1, ptr %l7, !tbaa !21
  store i1 %t159, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2flower_2ecompiler_2flower_3aLowerer_2eT(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eWant(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l5 = alloca i1
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %t1, i32 0, i32 22
  %t4 = load { i64, [2 x i64] }, ptr %l1
  %t7 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_Hf0a5beca6f8aee4731a76bd327ae0a99(ptr %v0, ptr %t3, { i64, [2 x i64] } %t4)
  store i1 %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = load i1, ptr %l5, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/lower:Lowerer", ptr %t9, i32 0, i32 22
  %t12 = load { i64, [2 x i64] }, ptr %l1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_He6968003b8dd5762fa82ec44b4ee1fc9(ptr %v0, ptr %t11, { i64, [2 x i64] } %t12, i1 true)
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/lower:Lowerer", ptr %t15, i32 0, i32 21
  %t18 = load { i64, [2 x i64] }, ptr %l1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %t17, { i64, [2 x i64] } %t18)
  br label %bb6
bb6:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3aLowerer_2ebare(ptr %out, ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca %"compiler/mir:Fn"
  %s0 = alloca %olang.scope
  %t4 = alloca %"compiler/mir:Fn", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, [2 x i64] } %a1, ptr %l3
  store i32 %a2, ptr %l4, !tbaa !23
  %t3 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t3, ptr %l5
  br label %bb1
bb1:
  %t5 = load { i64, [2 x i64] }, ptr %l3
  %t6 = load i32, ptr %l4, !tbaa !23
  %t7 = load %"compiler/source:Span", ptr %l5
  call void @compiler_2fmir_3aFn_2ector(ptr %t4, ptr %v1, { i64, [2 x i64] } %t5, i32 %t6, i64 0, %"compiler/source:Span" %t7)
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %t4, i64 808, i1 false)
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l6, i64 808, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2flower_2ecompiler_2flower_3aLowerer_2echar(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca i32
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %t1, i32 0, i32 30
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = icmp slt i32 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/lower:Lowerer", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %s1, ptr %s1, ptr %t12, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d1, i32 0, i32 1) }, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i32 %t14, ptr %l7
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t15 = load i32, ptr %l7, !tbaa !23
  %t16 = load ptr, ptr %l4, !tbaa !29
  %t17 = getelementptr %"compiler/lower:Lowerer", ptr %t16, i32 0, i32 30
  store i32 %t15, ptr %t17, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  br label %bb4
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/lower:Lowerer", ptr %t18, i32 0, i32 30
  %t21 = load i32, ptr %t20, !tbaa !23
  store i32 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ecloneSize(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/lower:CloneSum"
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %t1, i32 0, i32 55
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i64 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ecloneSum(ptr %v0, ptr %t4, { i64, [2 x i64] } %a1)
  store i64 %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t10 = load i64, ptr %l6, !tbaa !24
  %t11 = call %"compiler/lower:CloneSum" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aCloneSum_3e_2eAt_3ccompiler_2flower_3aCloneSum_3e(ptr %v0, ptr %s0, ptr %t9, i64 %t10)
  store %"compiler/lower:CloneSum" %t11, ptr %l7
  br label %bb2
bb2:
  %t12 = getelementptr %"compiler/lower:CloneSum", ptr %l7, i32 0, i32 1
  %t13 = load i64, ptr %t12, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ecloneSum(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i64
  %l3 = alloca %"compiler/lower:CloneSum"
  %l4 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  %l15 = alloca %"compiler/lower:CloneSum"
  %l17 = alloca ptr
  %l18 = alloca { i64, [2 x i64] }
  %l21 = alloca i64
  %l27 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %t1, i32 0, i32 56
  %t4 = load { i64, [2 x i64] }, ptr %l1
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20I64_3e_2eG_H6ffe2eb17daa971b2c9d564ad72358b1(ptr %v0, ptr %t3, { i64, [2 x i64] } %t4)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l9
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i64 %t8, ptr %l8
  br label %bb1
bb1:
  %t12 = load i64, ptr %l8, !tbaa !24
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l4, !tbaa !24
  store i64 %t13, ptr %l2, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = icmp sge i64 %t14, 0
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load i64, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t18, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load { i64, [2 x i64] }, ptr %l1
  %t24 = call %"compiler/lower:CloneSum" @compiler_2flower_2ecompiler_2flower_3aLowerer_2ereadSum(ptr %v0, ptr %s0, ptr %t20, { i64, [2 x i64] } %t21)
  store %"compiler/lower:CloneSum" %t24, ptr %l15
  br label %bb8
bb8:
  %t25 = load %"compiler/lower:CloneSum", ptr %l15
  store %"compiler/lower:CloneSum" %t25, ptr %l3
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/lower:Lowerer", ptr %t26, i32 0, i32 56
  store ptr %t28, ptr %l17, !tbaa !29
  %t29 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t29, ptr %l18
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/lower:Lowerer", ptr %t30, i32 0, i32 55
  %t34 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aCloneSum_3e_2eLen_3ccompiler_2flower_3aCloneSum_3e(ptr %v0, ptr %t32)
  store i64 %t34, ptr %l21
  br label %bb9
bb9:
  %t35 = load ptr, ptr %l17, !tbaa !29
  %t36 = load { i64, [2 x i64] }, ptr %l18
  %t37 = load i64, ptr %l21, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20I64_3e_2eP_H79a97b7337c7adf08bdd37311af7e171(ptr %v0, ptr %t35, { i64, [2 x i64] } %t36, i64 %t37)
  br label %bb10
bb10:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/lower:Lowerer", ptr %t38, i32 0, i32 55
  %t41 = load %"compiler/lower:CloneSum", ptr %l3
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aCloneSum_3e_2ePush_3ccompiler_2flower_3aCloneSum_3e(ptr %v0, ptr %s0, ptr %t40, %"compiler/lower:CloneSum" %t41)
  br label %bb11
bb11:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/lower:Lowerer", ptr %t44, i32 0, i32 55
  %t48 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aCloneSum_3e_2eLen_3ccompiler_2flower_3aCloneSum_3e(ptr %v0, ptr %t46)
  store i64 %t48, ptr %l27
  br label %bb12
bb12:
  %t49 = load i64, ptr %l27, !tbaa !24
  %t50 = sub i64 %t49, 1
  call void @__olang_scope_close(ptr %s0)
  store i64 %t50, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3aLowerer_2ecopiedFn(ptr %out, ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %lp3 = alloca ptr
  %lp4 = alloca ptr
  %l10 = alloca ptr
  %l14 = alloca %"compiler/typed:Body"
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l19 = alloca ptr
  %l24 = alloca %"compiler/mir:Fn"
  %l28 = alloca %"compiler/lower:lowering"
  %l34 = alloca %"compiler/mir:Fn"
  %l36 = alloca %"compiler/mir:Fn"
  %t18 = alloca %"compiler/typed:Body", align 8
  %t32 = alloca { i64, [2 x i64] }, align 8
  %t39 = alloca %"compiler/mir:Fn", align 8
  %t47 = alloca %"compiler/lower:lowering", align 8
  %t70 = alloca %"compiler/mir:Fn", align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = load i32, ptr %l1, !tbaa !23
  %t8 = sext i32 %t6 to i64
  %t11 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t4, i64 %t8)
  store ptr %t11, ptr %l10
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l10, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t12, i32 0, i32 2
  %t15 = load i32, ptr %t14, !tbaa !23
  store i32 %t15, ptr %l2, !tbaa !23
  %t17 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2flower_2estandIn(ptr %t18, ptr %v1, i32 %t17)
  call void @llvm.memmove.p0.p0.i64(ptr %l14, ptr %t18, i64 440, i1 false)
  br label %bb2
bb2:
  %t20 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 440, i64 8)
  store ptr %t20, ptr %lp3
  %t21 = load ptr, ptr %lp3
  call void @llvm.memmove.p0.p0.i64(ptr %t21, ptr %l14, i64 440, i1 false)
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l15, !tbaa !29
  %t23 = load ptr, ptr %lp3
  store ptr %t23, ptr %l16, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/lower:Lowerer", ptr %t24, i32 0, i32 0
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Program", ptr %t27, i32 0, i32 2
  store ptr %t29, ptr %l19, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i32, ptr %l1, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t32
  %t33 = getelementptr { i64, [2 x i64] }, ptr %t32, i32 0, i32 0
  store i64 2, ptr %t33
  %t35 = insertvalue { i32 } undef, i32 %t31, 0
  %t36 = getelementptr { i64, [2 x i64] }, ptr %t32, i32 0, i32 1
  store { i32 } %t35, ptr %t36
  %t37 = load { i64, [2 x i64] }, ptr %t32
  %t38 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2ebare(ptr %t39, ptr %v0, ptr %v1, ptr %t30, { i64, [2 x i64] } %t37, i32 %t38)
  call void @llvm.memmove.p0.p0.i64(ptr %l24, ptr %t39, i64 808, i1 false)
  br label %bb3
bb3:
  %t43 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 808, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t43, ptr %l24, i64 808, i1 false)
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/lower:Lowerer", ptr %t44, i32 0, i32 3
  %t48 = load ptr, ptr %l15, !tbaa !29
  %t49 = load ptr, ptr %l16, !tbaa !29
  %t50 = load ptr, ptr %l19, !tbaa !29
  call void @compiler_2flower_3alowering_2ector(ptr %t47, ptr %v0, ptr %v1, ptr %v0, ptr %v1, ptr %v0, ptr %v1, ptr %t48, ptr %t49, ptr %t50, ptr %t43, ptr %t46)
  call void @llvm.memmove.p0.p0.i64(ptr %l28, ptr %t47, i64 4104, i1 false)
  br label %bb4
bb4:
  %t53 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 4104, i64 8)
  store ptr %t53, ptr %lp4
  %t54 = load ptr, ptr %lp4
  call void @llvm.memmove.p0.p0.i64(ptr %t54, ptr %l28, i64 4104, i1 false)
  %t55 = load ptr, ptr %lp4
  %t56 = load i32, ptr %l1, !tbaa !23
  %t57 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ecopiedBody(ptr %v1, ptr %v0, ptr %v0, ptr %v1, ptr %v1, ptr %t55, i32 %t56, i32 %t57)
  br label %bb5
bb5:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load ptr, ptr %lp4
  %t63 = getelementptr %"compiler/lower:lowering", ptr %t62, i32 0, i32 13
  %t64 = load i1, ptr %t63, !tbaa !21
  %t67 = getelementptr %"compiler/lower:Lowerer", ptr %t61, i32 0, i32 14
  store i1 %t64, ptr %t67, !tbaa !21
  %t68 = load ptr, ptr %lp4
  %t69 = getelementptr %"compiler/lower:lowering", ptr %t68, i32 0, i32 3
  call void @llvm.memmove.p0.p0.i64(ptr %l34, ptr %t69, i64 808, i1 false)
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fmir_3aFn(ptr %t70, ptr %v1, ptr %l34)
  call void @llvm.memmove.p0.p0.i64(ptr %l36, ptr %t70, i64 808, i1 false)
  br label %bb6
bb6:
  call void @llvm.memmove.p0.p0.i64(ptr %l34, ptr %l36, i64 808, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l34, i64 808, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3aLowerer_2edecideGen(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l21 = alloca ptr
  %l22 = alloca i1
  %l32 = alloca i64
  %l39 = alloca i32
  %l46 = alloca ptr
  %l49 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l56 = alloca ptr
  %l57 = alloca i1
  %l66 = alloca ptr
  %l67 = alloca i64
  %l79 = alloca ptr
  %l80 = alloca i64
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a2, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb46
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t15, ptr %l18, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l6, !tbaa !29
  %t23 = load ptr, ptr %l6, !tbaa !29
  store ptr %t23, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t24 = load ptr, ptr %l21, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t27 = load ptr, ptr %l21, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 12}
  %t30 = icmp eq i64 %t28, 2
  store i1 %t30, ptr %l22, !tbaa !21
  br label %bb6
bb6:
  %t31 = load i1, ptr %l22, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t32 = load ptr, ptr %l6, !tbaa !29
  %t34 = getelementptr { i64, [8 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", ptr }, ptr %t34, i32 0, i32 1
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l7, !tbaa !29
  br label %bb9
bb8:
  br label %bb19
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/lower:Lowerer", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t42 = load i64, ptr %l1, !tbaa !24
  %t43 = load ptr, ptr %l7, !tbaa !29
  %t45 = getelementptr %"compiler/ast:TypeDecl", ptr %t43, i32 0, i32 0
  %t46 = load i32, ptr %t45, !tbaa !23
  %t50 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %t41, i64 %t42, i32 %t46)
  store i64 %t50, ptr %l32
  br label %bb10
bb10:
  %t51 = load i64, ptr %l32, !tbaa !24
  store i64 %t51, ptr %l8, !tbaa !24
  %t52 = load i64, ptr %l8, !tbaa !24
  %t54 = icmp slt i64 %t52, 0
  br i1 %t54, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb45
bb12:
  br label %bb13
bb13:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/lower:Lowerer", ptr %t56, i32 0, i32 0
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t60 = load i64, ptr %l1, !tbaa !24
  %t61 = load i64, ptr %l8, !tbaa !24
  %t65 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t59, i64 %t60, i64 %t61)
  store i32 %t65, ptr %l39
  br label %bb14
bb14:
  %t66 = load i32, ptr %l39, !tbaa !23
  %t67 = sext i32 %t66 to i64
  store i64 %t67, ptr %l9, !tbaa !24
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/lower:Lowerer", ptr %t69, i32 0, i32 51
  %t72 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t71, i64 %t72, i1 true)
  br label %bb15
bb15:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/lower:Lowerer", ptr %t75, i32 0, i32 0
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = getelementptr %"compiler/generic:Program", ptr %t78, i32 0, i32 3
  store ptr %t80, ptr %l46, !tbaa !29
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load i64, ptr %l9, !tbaa !24
  %t85 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3aLowerer_2edeclName(ptr %v0, ptr %s3, ptr %t81, i64 %t82)
  store { i64, ptr } %t85, ptr %l49
  br label %bb16
bb16:
  %t86 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t87 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t88 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t88, 1
  %t90 = extractvalue { i64, ptr } %t88, 0
  %t91 = add i64 %t87, %t90
  %t92 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t91)
  call void @olang_textcopy(ptr %t92, ptr %t86, i64 %t87)
  %t93 = getelementptr i8, ptr %t92, i64 %t87
  call void @olang_textcopy(ptr %t93, ptr %t89, i64 %t90)
  %t94 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t92, 1
  store { i64, ptr } %t95, ptr %l51, !tbaa !27
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load i64, ptr %l9, !tbaa !24
  %t101 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3aLowerer_2egenValue(ptr %v0, ptr %s3, ptr %t97, i64 %t98)
  store { i64, ptr } %t101, ptr %l54
  br label %bb17
bb17:
  %t102 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t103 = load ptr, ptr %l46, !tbaa !29
  %t104 = load { i64, ptr }, ptr %l51, !tbaa !27
  call void @compiler_2ffacts_2ecompiler_2ffacts_3aTable_2eDecide(ptr %v0, ptr %s3, ptr %s3, ptr %t103, { i64, ptr } %t104, { i64, ptr } %t102, i1 true)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb44
bb19:
  %t106 = load ptr, ptr %l6, !tbaa !29
  store ptr %t106, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t107 = load ptr, ptr %l56, !tbaa !29
  %t108 = icmp ne ptr %t107, null
  br i1 %t108, label %bb20, label %bb21
bb20:
  %t110 = load ptr, ptr %l56, !tbaa !29
  %t111 = load i64, ptr %t110, !range !{i64 0, i64 12}
  %t113 = icmp eq i64 %t111, 8
  store i1 %t113, ptr %l57, !tbaa !21
  br label %bb21
bb21:
  %t114 = load i1, ptr %l57, !tbaa !21
  br i1 %t114, label %bb22, label %bb23
bb22:
  %t115 = load ptr, ptr %l6, !tbaa !29
  %t117 = getelementptr { i64, [8 x i64] }, ptr %t115, i32 0, i32 1
  %t118 = getelementptr { %"compiler/source:Span", ptr }, ptr %t117, i32 0, i32 1
  %t119 = load ptr, ptr %t118
  store ptr %t119, ptr %l10, !tbaa !29
  br label %bb24
bb23:
  br label %bb39
bb24:
  %t121 = load ptr, ptr %l10, !tbaa !29
  %t123 = getelementptr %"compiler/ast:TopIf", ptr %t121, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t126 = icmp eq ptr %t124, null
  %t128 = xor i1 %t126, true
  br i1 %t128, label %bb25, label %bb26
bb25:
  %t130 = load ptr, ptr %l0, !tbaa !29
  store ptr %t130, ptr %l66, !tbaa !29
  %t131 = load i64, ptr %l1, !tbaa !24
  store i64 %t131, ptr %l67, !tbaa !24
  %t132 = load ptr, ptr %l10, !tbaa !29
  %t134 = getelementptr %"compiler/ast:TopIf", ptr %t132, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !29
  %t137 = icmp eq ptr %t135, null
  br i1 %t137, label %bb27, label %bb28
bb26:
  br label %bb31
bb27:
  call void @__olang_check_failed(ptr @olang_loc_1382960bfc70c50f_447f2e6bbefa4703)
  unreachable
bb28:
  br label %bb29
bb29:
  %t139 = load ptr, ptr %l10, !tbaa !29
  %t141 = getelementptr %"compiler/ast:TopIf", ptr %t139, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t145 = getelementptr %"compiler/ast:TopBranch", ptr %t142, i32 0, i32 1
  %t146 = load { i64, ptr }, ptr %t145, !tbaa !27
  %t147 = load ptr, ptr %l66, !tbaa !29
  %t148 = load i64, ptr %l67, !tbaa !24
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2edecideGen(ptr %v0, ptr %v1, ptr %t147, i64 %t148, { i64, ptr } %t146)
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t150 = load ptr, ptr %l10, !tbaa !29
  %t152 = getelementptr %"compiler/ast:TopIf", ptr %t150, i32 0, i32 3
  %t153 = load ptr, ptr %t152, !tbaa !29
  %t155 = icmp eq ptr %t153, null
  %t157 = xor i1 %t155, true
  br i1 %t157, label %bb32, label %bb33
bb32:
  %t159 = load ptr, ptr %l0, !tbaa !29
  store ptr %t159, ptr %l79, !tbaa !29
  %t160 = load i64, ptr %l1, !tbaa !24
  store i64 %t160, ptr %l80, !tbaa !24
  %t161 = load ptr, ptr %l10, !tbaa !29
  %t163 = getelementptr %"compiler/ast:TopIf", ptr %t161, i32 0, i32 3
  %t164 = load ptr, ptr %t163, !tbaa !29
  %t166 = icmp eq ptr %t164, null
  br i1 %t166, label %bb34, label %bb35
bb33:
  br label %bb38
bb34:
  call void @__olang_check_failed(ptr @olang_loc_543552ccedba0a30_34b88e2195dff774)
  unreachable
bb35:
  br label %bb36
bb36:
  %t168 = load ptr, ptr %l10, !tbaa !29
  %t170 = getelementptr %"compiler/ast:TopIf", ptr %t168, i32 0, i32 3
  %t171 = load ptr, ptr %t170, !tbaa !29
  %t174 = getelementptr %"compiler/ast:TopBranch", ptr %t171, i32 0, i32 1
  %t175 = load { i64, ptr }, ptr %t174, !tbaa !27
  %t176 = load ptr, ptr %l79, !tbaa !29
  %t177 = load i64, ptr %l80, !tbaa !24
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2edecideGen(ptr %v0, ptr %v1, ptr %t176, i64 %t177, { i64, ptr } %t175)
  br label %bb37
bb37:
  br label %bb38
bb38:
  br label %bb44
bb39:
  br i1 true, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_c10f234bff0405bc_197db79cf1a1a0)
  unreachable
bb44:
  br label %bb45
bb45:
  %t179 = load i64, ptr %l4, !tbaa !24
  %t182 = add i64 %t179, 1
  store i64 %t182, ptr %l4, !tbaa !24
  br label %bb1
bb46:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2flower_2ecompiler_2flower_3aLowerer_2eexclusiveFact(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l7 = alloca i1
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %t1, i32 0, i32 7
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t3, i64 %t4)
  store i1 %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load i1, ptr %l7, !tbaa !21
  %t9 = xor i1 %t8, true
  br i1 %t9, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d4, i32 0, i32 1) }, ptr %l9, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t11, ptr %l10, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  store i64 %t13, ptr %l11, !tbaa !24
  %t14 = load i64, ptr %l11, !tbaa !24
  %t15 = mul i64 %t14, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l12, !tbaa !27
  %t19 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = load i64, ptr %l11, !tbaa !24
  %t24 = mul i64 %t23, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t20, ptr %t22, i64 %t24, i1 false)
  %t25 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t25, ptr %l10, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t26, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/lower:Lowerer", ptr %t27, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t30, i64 %t32)
  store ptr %t35, ptr %l17
  br label %bb5
bb5:
  %t36 = load ptr, ptr %l17, !tbaa !29
  %t38 = getelementptr %"compiler/typed:Body", ptr %t36, i32 0, i32 1
  %t39 = load { i64, [2 x i64] }, ptr %t38
  store { i64, [2 x i64] } %t39, ptr %l2
  %t41 = load { i64, [2 x i64] }, ptr %l2
  %t43 = extractvalue { i64, [2 x i64] } %t41, 0
  %t44 = icmp eq i64 %t43, 0
  br i1 %t44, label %bb6, label %bb7
bb6:
  %t46 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t47 = getelementptr { i64 }, ptr %t46, i32 0, i32 0
  %t48 = load i64, ptr %t47
  store i64 %t48, ptr %l3, !tbaa !24
  br label %bb8
bb7:
  br label %bb10
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/lower:Lowerer", ptr %t50, i32 0, i32 0
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t54 = load i64, ptr %l3, !tbaa !24
  %t57 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceName(ptr %v0, ptr %s2, ptr %t53, i64 %t54)
  store { i64, ptr } %t57, ptr %l27
  br label %bb9
bb9:
  %t58 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t59 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t60 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t60, 1
  %t62 = extractvalue { i64, ptr } %t60, 0
  %t63 = add i64 %t59, %t62
  %t64 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t63)
  call void @olang_textcopy(ptr %t64, ptr %t58, i64 %t59)
  %t65 = getelementptr i8, ptr %t64, i64 %t59
  call void @olang_textcopy(ptr %t65, ptr %t61, i64 %t62)
  %t66 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t64, 1
  store { i64, ptr } %t67, ptr %l20, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb10:
  br i1 true, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d6, i32 0, i32 1) }, ptr %l29, !tbaa !27
  %t69 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t69, ptr %l20, !tbaa !27
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_9633c21bdf8638fa_782e8f05e482835e)
  unreachable
bb15:
  %t71 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t71, 0
  store i64 %t72, ptr %l31, !tbaa !24
  %t73 = load i64, ptr %l31, !tbaa !24
  %t74 = mul i64 %t73, 1
  %t75 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t74)
  %t76 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t75, 1
  store { i64, ptr } %t77, ptr %l32, !tbaa !27
  %t78 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = load i64, ptr %l31, !tbaa !24
  %t83 = mul i64 %t82, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t79, ptr %t81, i64 %t83, i1 false)
  %t84 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t84, ptr %l20, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t85, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3aLowerer_2ehelper(ptr %out, ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %lp4 = alloca ptr
  %lp5 = alloca ptr
  %l11 = alloca i32
  %l13 = alloca %"compiler/typed:Body"
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l18 = alloca ptr
  %l24 = alloca %"compiler/mir:Fn"
  %l28 = alloca %"compiler/lower:lowering"
  %l34 = alloca %"compiler/mir:Fn"
  %l36 = alloca %"compiler/mir:Fn"
  %t15 = alloca %"compiler/typed:Body", align 8
  %t30 = alloca { i64, [2 x i64] }, align 8
  %t39 = alloca %"compiler/mir:Fn", align 8
  %t47 = alloca %"compiler/lower:lowering", align 8
  %t70 = alloca %"compiler/mir:Fn", align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !range !{i32 0, i32 10}
  %t8 = load i32, ptr %l2, !tbaa !23
  %t12 = call i32 @compiler_2fmir_2eHelperType(ptr %v0, ptr %t6, i32 %t7, i32 %t8)
  store i32 %t12, ptr %l11
  br label %bb1
bb1:
  %t13 = load i32, ptr %l11, !tbaa !23
  store i32 %t13, ptr %l3, !tbaa !23
  %t14 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2flower_2estandIn(ptr %t15, ptr %v1, i32 %t14)
  call void @llvm.memmove.p0.p0.i64(ptr %l13, ptr %t15, i64 440, i1 false)
  br label %bb2
bb2:
  %t17 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 440, i64 8)
  store ptr %t17, ptr %lp4
  %t18 = load ptr, ptr %lp4
  call void @llvm.memmove.p0.p0.i64(ptr %t18, ptr %l13, i64 440, i1 false)
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l14, !tbaa !29
  %t20 = load ptr, ptr %lp4
  store ptr %t20, ptr %l15, !tbaa !29
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/lower:Lowerer", ptr %t21, i32 0, i32 0
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Program", ptr %t24, i32 0, i32 2
  store ptr %t26, ptr %l18, !tbaa !29
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i32, ptr %l1, !range !{i32 0, i32 10}
  %t29 = load i32, ptr %l2, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t30
  %t31 = getelementptr { i64, [2 x i64] }, ptr %t30, i32 0, i32 0
  store i64 3, ptr %t31
  %t33 = insertvalue { i32, i32 } undef, i32 %t28, 0
  %t35 = insertvalue { i32, i32 } %t33, i32 %t29, 1
  %t36 = getelementptr { i64, [2 x i64] }, ptr %t30, i32 0, i32 1
  store { i32, i32 } %t35, ptr %t36
  %t37 = load { i64, [2 x i64] }, ptr %t30
  %t38 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2ebare(ptr %t39, ptr %v0, ptr %v1, ptr %t27, { i64, [2 x i64] } %t37, i32 %t38)
  call void @llvm.memmove.p0.p0.i64(ptr %l24, ptr %t39, i64 808, i1 false)
  br label %bb3
bb3:
  %t43 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 808, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t43, ptr %l24, i64 808, i1 false)
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/lower:Lowerer", ptr %t44, i32 0, i32 3
  %t48 = load ptr, ptr %l14, !tbaa !29
  %t49 = load ptr, ptr %l15, !tbaa !29
  %t50 = load ptr, ptr %l18, !tbaa !29
  call void @compiler_2flower_3alowering_2ector(ptr %t47, ptr %v0, ptr %v1, ptr %v0, ptr %v1, ptr %v0, ptr %v1, ptr %t48, ptr %t49, ptr %t50, ptr %t43, ptr %t46)
  call void @llvm.memmove.p0.p0.i64(ptr %l28, ptr %t47, i64 4104, i1 false)
  br label %bb4
bb4:
  %t53 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 4104, i64 8)
  store ptr %t53, ptr %lp5
  %t54 = load ptr, ptr %lp5
  call void @llvm.memmove.p0.p0.i64(ptr %t54, ptr %l28, i64 4104, i1 false)
  %t55 = load ptr, ptr %lp5
  %t56 = load i32, ptr %l1, !range !{i32 0, i32 10}
  %t57 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ehelper(ptr %v1, ptr %v0, ptr %v0, ptr %v1, ptr %v1, ptr %t55, i32 %t56, i32 %t57)
  br label %bb5
bb5:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load ptr, ptr %lp5
  %t63 = getelementptr %"compiler/lower:lowering", ptr %t62, i32 0, i32 13
  %t64 = load i1, ptr %t63, !tbaa !21
  %t67 = getelementptr %"compiler/lower:Lowerer", ptr %t61, i32 0, i32 14
  store i1 %t64, ptr %t67, !tbaa !21
  %t68 = load ptr, ptr %lp5
  %t69 = getelementptr %"compiler/lower:lowering", ptr %t68, i32 0, i32 3
  call void @llvm.memmove.p0.p0.i64(ptr %l34, ptr %t69, i64 808, i1 false)
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fmir_3aFn(ptr %t70, ptr %v1, ptr %l34)
  call void @llvm.memmove.p0.p0.i64(ptr %l36, ptr %t70, i64 808, i1 false)
  br label %bb6
bb6:
  call void @llvm.memmove.p0.p0.i64(ptr %l34, ptr %l36, i64 808, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l34, i64 808, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eindex(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, [2 x i64] }
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l16 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l45 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %t1, i32 0, i32 27
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:Lowerer", ptr %t6, i32 0, i32 27
  store i1 true, ptr %t8, !tbaa !21
  store i64 0, ptr %l1, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/lower:Lowerer", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t12)
  store i64 %t14, ptr %l16
  br label %bb4
bb4:
  %t15 = load i64, ptr %l16, !tbaa !24
  store i64 %t15, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t17 = load i64, ptr %l1, !tbaa !24
  %t20 = icmp sgt i64 %t16, %t17
  br i1 %t20, label %bb5, label %bb6
bb5:
  %t22 = load i64, ptr %l3, !tbaa !24
  %t24 = icmp sgt i64 %t22, 0
  br i1 %t24, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb10
bb7:
  %t26 = load i64, ptr %l2, !tbaa !24
  %t27 = load i64, ptr %l1, !tbaa !24
  %t30 = sub i64 %t26, %t27
  %t31 = load i64, ptr %l3, !tbaa !24
  %t34 = add i64 %t30, %t31
  %t36 = sub i64 %t34, 1
  %t37 = load i64, ptr %l3, !tbaa !24
  %t40 = sdiv i64 %t36, %t37
  store i64 %t40, ptr %l23, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb9
bb9:
  %t42 = load i64, ptr %l23, !tbaa !24
  store i64 %t42, ptr %l20, !tbaa !24
  br label %bb10
bb10:
  %t43 = load i64, ptr %l20, !tbaa !24
  store i64 %t43, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb11
bb11:
  %t44 = load i64, ptr %l5, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb12, label %bb13
bb12:
  br label %bb35
bb13:
  br label %bb14
bb14:
  %t52 = load i64, ptr %l1, !tbaa !24
  %t53 = load i64, ptr %l5, !tbaa !24
  %t54 = load i64, ptr %l3, !tbaa !24
  %t57 = mul i64 %t53, %t54
  %t60 = add i64 %t52, %t57
  store i64 %t60, ptr %l6, !tbaa !24
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/lower:Lowerer", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = load i64, ptr %l6, !tbaa !24
  %t70 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t65, i64 %t67)
  store ptr %t70, ptr %l45
  br label %bb15
bb15:
  %t71 = load ptr, ptr %l45, !tbaa !29
  %t73 = getelementptr %"compiler/typed:Body", ptr %t71, i32 0, i32 1
  %t74 = load { i64, [2 x i64] }, ptr %t73
  store { i64, [2 x i64] } %t74, ptr %l7
  %t76 = load { i64, [2 x i64] }, ptr %l7
  %t78 = extractvalue { i64, [2 x i64] } %t76, 0
  %t79 = icmp eq i64 %t78, 1
  br i1 %t79, label %bb16, label %bb17
bb16:
  %t81 = getelementptr { i64, [2 x i64] }, ptr %l7, i32 0, i32 1
  %t82 = getelementptr { i32, i32 }, ptr %t81, i32 0, i32 0
  %t83 = load i32, ptr %t82
  store i32 %t83, ptr %l8, !tbaa !23
  %t85 = getelementptr { i64, [2 x i64] }, ptr %l7, i32 0, i32 1
  %t86 = getelementptr { i32, i32 }, ptr %t85, i32 0, i32 1
  %t87 = load i32, ptr %t86
  store i32 %t87, ptr %l9, !tbaa !23
  br label %bb18
bb17:
  br label %bb23
bb18:
  %t89 = load i32, ptr %l9, !tbaa !23
  %t91 = icmp eq i32 %t89, 0
  br i1 %t91, label %bb19, label %bb20
bb19:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/lower:Lowerer", ptr %t93, i32 0, i32 23
  %t96 = load i32, ptr %l8, !tbaa !23
  %t97 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__Hccd9659a44f570da1fa06b019882a84d(ptr %v0, ptr %t95, i32 %t96, i64 %t97)
  br label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb22
bb22:
  br label %bb33
bb23:
  %t101 = load { i64, [2 x i64] }, ptr %l7
  %t103 = extractvalue { i64, [2 x i64] } %t101, 0
  %t104 = icmp eq i64 %t103, 3
  br i1 %t104, label %bb24, label %bb25
bb24:
  %t106 = getelementptr { i64, [2 x i64] }, ptr %l7, i32 0, i32 1
  %t107 = getelementptr { i32 }, ptr %t106, i32 0, i32 0
  %t108 = load i32, ptr %t107
  store i32 %t108, ptr %l10, !tbaa !23
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/lower:Lowerer", ptr %t110, i32 0, i32 26
  %t113 = load i32, ptr %l10, !tbaa !23
  %t114 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__Hccd9659a44f570da1fa06b019882a84d(ptr %v0, ptr %t112, i32 %t113, i64 %t114)
  br label %bb27
bb27:
  br label %bb33
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_3aca88f8a70b165c_61af268fc3dc2410)
  unreachable
bb33:
  br label %bb34
bb34:
  %t118 = load i64, ptr %l5, !tbaa !24
  %t121 = add i64 %t118, 1
  store i64 %t121, ptr %l5, !tbaa !24
  br label %bb11
bb35:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ekeepsNoRef(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l12 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %t1, i32 0, i32 43
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/lower:Lowerer", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 2
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/lower:Lowerer", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t21 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2eNone(ptr %v0, ptr %v0, ptr %v0, ptr %t3, ptr %t9, ptr %t13, i64 %a1, i64 %a2)
  store i1 %t21, ptr %l12
  br label %bb1
bb1:
  %t22 = load i1, ptr %l12, !tbaa !21
  store i1 %t22, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2flower_2ecompiler_2flower_3aLowerer_2eplanOf(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i32
  %l3 = alloca i64
  %l8 = alloca i64
  %l11 = alloca i64
  %l17 = alloca ptr
  %l21 = alloca i64
  %l24 = alloca i64
  %l29 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l2, !tbaa !23
  br label %bb3
bb2:
  br label %bb9
bb3:
  %t10 = load i32, ptr %l2, !tbaa !23
  %t12 = sext i32 %t10 to i64
  store i64 %t12, ptr %l8, !tbaa !24
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/lower:Lowerer", ptr %t13, i32 0, i32 2
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eLen_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %t15)
  store i64 %t17, ptr %l11
  br label %bb4
bb4:
  %t18 = load i64, ptr %l8, !tbaa !24
  %t19 = load i64, ptr %l11, !tbaa !24
  %t20 = icmp slt i64 %t18, %t19
  br i1 %t20, label %bb5, label %bb6
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/lower:Lowerer", ptr %t22, i32 0, i32 2
  %t25 = load i32, ptr %l2, !tbaa !23
  %t27 = sext i32 %t25 to i64
  %t30 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eRef_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v0, ptr %t24, i64 %t27)
  store ptr %t30, ptr %l17
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t31 = load ptr, ptr %l17, !tbaa !29
  store ptr %t31, ptr %rv
  br label %ret
bb8:
  br label %bb23
bb9:
  %t32 = load { i64, [2 x i64] }, ptr %l1
  %t34 = extractvalue { i64, [2 x i64] } %t32, 0
  %t35 = icmp eq i64 %t34, 6
  br i1 %t35, label %bb10, label %bb11
bb10:
  %t37 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t38 = getelementptr { i32, i64 }, ptr %t37, i32 0, i32 1
  %t39 = load i64, ptr %t38
  store i64 %t39, ptr %l3, !tbaa !24
  br label %bb12
bb11:
  br label %bb18
bb12:
  %t41 = load i64, ptr %l3, !tbaa !24
  store i64 %t41, ptr %l21, !tbaa !24
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/lower:Lowerer", ptr %t42, i32 0, i32 8
  %t46 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eLen_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %t44)
  store i64 %t46, ptr %l24
  br label %bb13
bb13:
  %t47 = load i64, ptr %l21, !tbaa !24
  %t48 = load i64, ptr %l24, !tbaa !24
  %t49 = icmp slt i64 %t47, %t48
  br i1 %t49, label %bb14, label %bb15
bb14:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/lower:Lowerer", ptr %t51, i32 0, i32 8
  %t54 = load i64, ptr %l3, !tbaa !24
  %t57 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eRef_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v1, ptr %t53, i64 %t54)
  store ptr %t57, ptr %l29
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t58 = load ptr, ptr %l29, !tbaa !29
  store ptr %t58, ptr %rv
  br label %ret
bb17:
  br label %bb23
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_22c39d86763bef1a_78a4012252e46bde)
  unreachable
bb23:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/lower:Lowerer", ptr %t59, i32 0, i32 3
  store ptr %t61, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2estartCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i1
  %l13 = alloca i1
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = call i64 @compiler_2ftyped_2eCalleeBody(ptr %v1, ptr %t6)
  store i64 %t8, ptr %l7
  br label %bb4
bb4:
  %t9 = load i64, ptr %l7, !tbaa !24
  store i64 %t9, ptr %l2, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp sge i64 %t10, 0
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t15 = load i64, ptr %l2, !tbaa !24
  %t18 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2eStartsAlloc(ptr %v0, ptr %a0, i64 %t15)
  store i1 %t18, ptr %l13
  br label %bb7
bb6:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb8
bb7:
  %t19 = load i1, ptr %l13, !tbaa !21
  store i1 %t19, ptr %l10, !tbaa !21
  br label %bb8
bb8:
  %t20 = load i1, ptr %l10, !tbaa !21
  store i1 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2flower_2ecompiler_2flower_3aLowerer_2ewritesFact(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %l26 = alloca i1
  %l27 = alloca i1
  %l31 = alloca i1
  %l39 = alloca ptr
  %l41 = alloca ptr
  %l44 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l46 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l47 = alloca %"compiler/effects:Effects"
  %l51 = alloca ptr
  %l52 = alloca { i64, ptr }
  %l59 = alloca %"compiler/effects:Facts"
  %l62 = alloca i1
  %l63 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t100 = alloca %"compiler/effects:Effects", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = load i64, ptr %l1, !tbaa !24
  %t9 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t4, i64 %t6)
  store ptr %t9, ptr %l9
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l9, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Body", ptr %t10, i32 0, i32 1
  %t13 = load { i64, [2 x i64] }, ptr %t12
  store { i64, [2 x i64] } %t13, ptr %l2
  %t15 = load { i64, [2 x i64] }, ptr %l2
  %t17 = extractvalue { i64, [2 x i64] } %t15, 0
  %t18 = icmp eq i64 %t17, 0
  br i1 %t18, label %bb2, label %bb3
bb2:
  %t20 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t21 = getelementptr { i64 }, ptr %t20, i32 0, i32 0
  %t22 = load i64, ptr %t21
  store i64 %t22, ptr %l3, !tbaa !24
  br label %bb4
bb3:
  br label %bb6
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/lower:Lowerer", ptr %t24, i32 0, i32 0
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceName(ptr %v0, ptr %s1, ptr %t27, i64 %t28)
  store { i64, ptr } %t31, ptr %l19
  br label %bb5
bb5:
  %t32 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t34 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 1
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t37 = add i64 %t33, %t36
  %t38 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t37)
  call void @olang_textcopy(ptr %t38, ptr %t32, i64 %t33)
  %t39 = getelementptr i8, ptr %t38, i64 %t33
  call void @olang_textcopy(ptr %t39, ptr %t35, i64 %t36)
  %t40 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t38, 1
  store { i64, ptr } %t41, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %l21, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t43, ptr %l12, !tbaa !27
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_6caa27e9a9bd9cb6_8b0a4ad242181fa2)
  unreachable
bb11:
  %t45 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t45, 0
  store i64 %t46, ptr %l23, !tbaa !24
  %t47 = load i64, ptr %l23, !tbaa !24
  %t48 = mul i64 %t47, 1
  %t49 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t48)
  %t50 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  store { i64, ptr } %t51, ptr %l24, !tbaa !27
  %t52 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = load i64, ptr %l23, !tbaa !24
  %t57 = mul i64 %t56, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t53, ptr %t55, i64 %t57, i1 false)
  %t58 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t58, ptr %l4, !tbaa !27
  %t59 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t61 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t59, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d9, i32 0, i32 1) })
  store i1 %t61, ptr %l26
  br label %bb12
bb12:
  %t62 = load i1, ptr %l26, !tbaa !21
  br i1 %t62, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb16
bb14:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/lower:Lowerer", ptr %t63, i32 0, i32 6
  %t66 = load i64, ptr %l1, !tbaa !24
  %t69 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t65, i64 %t66)
  store i1 %t69, ptr %l31
  br label %bb15
bb15:
  %t70 = load i1, ptr %l31, !tbaa !21
  store i1 %t70, ptr %l27, !tbaa !21
  br label %bb16
bb16:
  %t71 = load i1, ptr %l27, !tbaa !21
  br i1 %t71, label %bb17, label %bb18
bb17:
  %t72 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t72, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/lower:Lowerer", ptr %t74, i32 0, i32 6
  %t77 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t76, i64 %t77, i1 true)
  br label %bb20
bb20:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/lower:Lowerer", ptr %t80, i32 0, i32 4
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t85 = icmp eq ptr %t83, null
  br i1 %t85, label %bb21, label %bb22
bb21:
  %t87 = load ptr, ptr %l0, !tbaa !29
  store ptr %t87, ptr %l39, !tbaa !29
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/lower:Lowerer", ptr %t88, i32 0, i32 0
  %t91 = load ptr, ptr %t90, !tbaa !29
  store ptr %t91, ptr %l41, !tbaa !29
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/lower:Lowerer", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t95
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t97, ptr %l44
  %t99 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e(ptr %v0, ptr %l44)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t99, ptr %l46
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t101 = load ptr, ptr %l41, !tbaa !29
  %t102 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l46
  call void @compiler_2feffects_3aEffects_2ector(ptr %t100, ptr %v0, ptr %v0, ptr %v0, ptr %t101, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t102)
  call void @llvm.memmove.p0.p0.i64(ptr %l47, ptr %t100, i64 3136, i1 false)
  br label %bb24
bb24:
  %t103 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 3136, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t103, ptr %l47, i64 3136, i1 false)
  %t105 = load ptr, ptr %l39, !tbaa !29
  %t106 = getelementptr %"compiler/lower:Lowerer", ptr %t105, i32 0, i32 4
  store ptr %t103, ptr %t106, !tbaa !29
  br label %bb25
bb25:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/lower:Lowerer", ptr %t107, i32 0, i32 0
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = getelementptr %"compiler/generic:Program", ptr %t110, i32 0, i32 3
  store ptr %t112, ptr %l51, !tbaa !29
  %t113 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t113, ptr %l52, !tbaa !27
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/lower:Lowerer", ptr %t114, i32 0, i32 4
  %t117 = load ptr, ptr %t116, !tbaa !29
  %t119 = icmp eq ptr %t117, null
  br i1 %t119, label %bb26, label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_1d7b43c09c8ad210_c11cfffd5d5a2d0c)
  unreachable
bb27:
  br label %bb28
bb28:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/lower:Lowerer", ptr %t121, i32 0, i32 4
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t125 = load i64, ptr %l1, !tbaa !24
  %t128 = call %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eOf(ptr %v0, ptr %t124, i64 %t125)
  store %"compiler/effects:Facts" %t128, ptr %l59
  br label %bb29
bb29:
  %t131 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2eHolds(ptr %s0, ptr %l59, i32 3)
  store i1 %t131, ptr %l62
  br label %bb30
bb30:
  %t132 = load i1, ptr %l62, !tbaa !21
  br i1 %t132, label %bb31, label %bb32
bb31:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d10, i32 0, i32 1) }, ptr %l63, !tbaa !27
  br label %bb33
bb32:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d11, i32 0, i32 1) }, ptr %l63, !tbaa !27
  br label %bb33
bb33:
  %t133 = load ptr, ptr %l51, !tbaa !29
  %t134 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t135 = load { i64, ptr }, ptr %l63, !tbaa !27
  call void @compiler_2ffacts_2ecompiler_2ffacts_3aTable_2eDecide(ptr %v0, ptr %v1, ptr %s0, ptr %t133, { i64, ptr } %t134, { i64, ptr } %t135, i1 false)
  br label %bb34
bb34:
  %t136 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t136, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2earraysCopy(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, [4 x i64] } %a2, i32 %a3, { i64, [1 x i64] } %a4, %"compiler/source:Span" %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i32
  %l4 = alloca { i64, [1 x i64] }
  %l5 = alloca %"compiler/source:Span"
  %l7 = alloca %"compiler/lower:pl"
  %l11 = alloca i1
  %l14 = alloca i1
  %l21 = alloca ptr
  %l28 = alloca i1
  %l30 = alloca i1
  %l32 = alloca ptr
  %l35 = alloca i1
  %l37 = alloca ptr
  %l43 = alloca { i64, [4 x i64] }
  %l46 = alloca i32
  %l49 = alloca %"compiler/lower:pl"
  %l50 = alloca ptr
  %l51 = alloca %"compiler/lower:pl"
  %l53 = alloca %"compiler/lower:pl"
  %l54 = alloca i32
  %l55 = alloca { i64, [1 x i64] }
  %l56 = alloca { i64, [1 x i64] }
  %l57 = alloca { i64, [4 x i64] }
  %l58 = alloca %"compiler/source:Span"
  %l59 = alloca %"compiler/lower:pl"
  %l61 = alloca %"compiler/lower:pl"
  %l62 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t70 = alloca { i64, [4 x i64] }, align 8
  %t78 = alloca { i64, [15 x i64] }, align 8
  %t99 = alloca { i64, [2 x i64] }, align 8
  %t115 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a3, ptr %l3
  store { i64, [1 x i64] } %a4, ptr %l4
  store %"compiler/source:Span" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 39
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb3
bb2:
  %t8 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, 0
  store i1 %t10, ptr %l11, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l11, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb10
bb5:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/lower:lowering", ptr %t13, i32 0, i32 0
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/lower:Lowerer", ptr %t16, i32 0, i32 12
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = icmp eq ptr %t19, null
  br i1 %t21, label %bb6, label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_74a3aff541c96529_c7a7326cf0c27875)
  unreachable
bb7:
  br label %bb8
bb8:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/lower:lowering", ptr %t23, i32 0, i32 0
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/lower:Lowerer", ptr %t26, i32 0, i32 12
  %t29 = load ptr, ptr %t28, !tbaa !29
  store ptr %t29, ptr %l21, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/lower:lowering", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/typed:Body", ptr %t33, i32 0, i32 0
  %t36 = load i32, ptr %t35, !tbaa !23
  %t38 = sext i32 %t36 to i64
  %t39 = load i64, ptr %l1, !tbaa !24
  %t40 = load ptr, ptr %l21, !tbaa !29
  %t41 = call ptr @__olang_scope_or(ptr %v1, ptr %t40)
  %t42 = call ptr @__olang_scope_hold(ptr %t41)
  %t43 = ptrtoint ptr %t42 to i64
  %t45 = inttoptr i64 %t43 to ptr
  %t46 = load ptr, ptr %l21, !tbaa !29
  %t49 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eArraysSite(ptr %t45, ptr %t46, i64 %t38, i64 %t39)
  store i1 %t49, ptr %l28
  br label %bb9
bb9:
  %t50 = load i1, ptr %l28, !tbaa !21
  %t51 = xor i1 %t50, true
  store i1 %t51, ptr %l14, !tbaa !21
  br label %bb10
bb10:
  %t53 = load i1, ptr %l14, !tbaa !21
  br i1 %t53, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb14
bb12:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/lower:lowering", ptr %t54, i32 0, i32 2
  %t57 = load ptr, ptr %t56, !tbaa !29
  store ptr %t57, ptr %l32, !tbaa !29
  %t58 = load i32, ptr %l3, !tbaa !23
  %t59 = load ptr, ptr %l32, !tbaa !29
  %t60 = call ptr @__olang_scope_or(ptr %v2, ptr %t59)
  %t61 = call ptr @__olang_scope_hold(ptr %t60)
  %t62 = ptrtoint ptr %t61 to i64
  %t64 = inttoptr i64 %t62 to ptr
  %t65 = load ptr, ptr %l32, !tbaa !29
  %t67 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRunsCopy(ptr %t64, ptr %t65, i32 %t58)
  store i1 %t67, ptr %l35
  br label %bb13
bb13:
  %t68 = load i1, ptr %l35, !tbaa !21
  store i1 %t68, ptr %l30, !tbaa !21
  br label %bb14
bb14:
  %t69 = load i1, ptr %l30, !tbaa !21
  br i1 %t69, label %bb15, label %bb16
bb15:
  store { i64, [4 x i64] } zeroinitializer, ptr %t70
  %t71 = getelementptr { i64, [4 x i64] }, ptr %t70, i32 0, i32 0
  store i64 0, ptr %t71
  %t72 = load { i64, [4 x i64] }, ptr %t70
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t72, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l37, !tbaa !29
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i32, ptr %l3, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t78
  %t79 = getelementptr { i64, [15 x i64] }, ptr %t78, i32 0, i32 0
  store i64 0, ptr %t79
  %t81 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %a2, 0
  %t82 = getelementptr { i64, [15 x i64] }, ptr %t78, i32 0, i32 1
  store { { i64, [4 x i64] } } %t81, ptr %t82
  %t83 = load { i64, [15 x i64] }, ptr %t78
  %t84 = load %"compiler/source:Span", ptr %l5
  %t89 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %v2, ptr %v1, ptr %t75, i32 %t76, { i64, [15 x i64] } %t83, %"compiler/source:Span" %t84)
  store { i64, [4 x i64] } %t89, ptr %l43
  br label %bb18
bb18:
  %t90 = load i32, ptr %l3, !tbaa !23
  %t91 = load %"compiler/source:Span", ptr %l5
  %t92 = load ptr, ptr %l37, !tbaa !29
  %t93 = load { i64, [4 x i64] }, ptr %l43
  %t96 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %v2, ptr %v1, ptr %t92, { i64, [4 x i64] } %t93, i32 %t90, %"compiler/source:Span" %t91)
  store i32 %t96, ptr %l46
  br label %bb19
bb19:
  %t97 = load i32, ptr %l46, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t99
  %t100 = getelementptr { i64, [2 x i64] }, ptr %t99, i32 0, i32 0
  store i64 1, ptr %t100
  %t102 = insertvalue { i32 } undef, i32 %t97, 0
  %t103 = getelementptr { i64, [2 x i64] }, ptr %t99, i32 0, i32 1
  store { i32 } %t102, ptr %t103
  %t104 = load { i64, [2 x i64] }, ptr %t99
  %t106 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %s0, { i64, [2 x i64] } %t104)
  store %"compiler/lower:pl" %t106, ptr %l49
  br label %bb20
bb20:
  %t107 = load %"compiler/lower:pl", ptr %l49
  store %"compiler/lower:pl" %t107, ptr %l7
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l50, !tbaa !29
  %t109 = load %"compiler/lower:pl", ptr %l7
  store %"compiler/lower:pl" %t109, ptr %l51
  %t111 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s0, ptr %l51)
  store %"compiler/lower:pl" %t111, ptr %l53
  br label %bb21
bb21:
  %t112 = load i32, ptr %l3, !tbaa !23
  store i32 %t112, ptr %l54, !tbaa !23
  %t113 = load { i64, [1 x i64] }, ptr %l4
  store { i64, [1 x i64] } %t113, ptr %l55
  %t114 = load { i64, [1 x i64] }, ptr %l4
  store { i64, [1 x i64] } %t114, ptr %l56
  store { i64, [4 x i64] } zeroinitializer, ptr %t115
  %t116 = getelementptr { i64, [4 x i64] }, ptr %t115, i32 0, i32 0
  store i64 0, ptr %t116
  %t117 = load { i64, [4 x i64] }, ptr %t115
  store { i64, [4 x i64] } %t117, ptr %l57
  %t118 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t118, ptr %l58
  %t119 = load %"compiler/lower:pl", ptr %l7
  store %"compiler/lower:pl" %t119, ptr %l59
  %t121 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s0, ptr %l59)
  store %"compiler/lower:pl" %t121, ptr %l61
  br label %bb22
bb22:
  %t122 = load ptr, ptr %l50, !tbaa !29
  %t123 = load %"compiler/lower:pl", ptr %l53
  %t124 = load i32, ptr %l54, !tbaa !23
  %t125 = load { i64, [1 x i64] }, ptr %l55
  %t126 = load { i64, [1 x i64] }, ptr %l56
  %t127 = load { i64, [4 x i64] }, ptr %l57
  %t128 = load %"compiler/source:Span", ptr %l58
  %t129 = load %"compiler/lower:pl", ptr %l61
  %t130 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2esplitArray(ptr %v0, ptr %s0, ptr %s0, ptr %v2, ptr %v1, ptr %t122, %"compiler/lower:pl" %t123, i32 %t124, { i64, [1 x i64] } %t125, { i64, [1 x i64] } %t126, { i64, [4 x i64] } %t127, %"compiler/source:Span" %t128, %"compiler/lower:pl" %t129, i1 false)
  store { i64, [4 x i64] } %t130, ptr %l62
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  %t131 = load { i64, [4 x i64] }, ptr %l62
  store { i64, [4 x i64] } %t131, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2easI64(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [4 x i64] }
  %l5 = alloca ptr
  %l8 = alloca i32
  %l16 = alloca { i64, ptr }
  %l18 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  store ptr %a0, ptr %l0
  store { i64, [4 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l5, !tbaa !29
  %t7 = call ptr @__olang_scope_or(ptr %v1, ptr %t6)
  %t8 = call ptr @__olang_scope_hold(ptr %t7)
  %t9 = ptrtoint ptr %t8 to i64
  %t11 = inttoptr i64 %t9 to ptr
  %t12 = load ptr, ptr %l5, !tbaa !29
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t11, ptr %t12, i32 %a2)
  store i32 %t14, ptr %l8
  br label %bb1
bb1:
  %t15 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t16 = load i32, ptr %l8, !tbaa !23
  %t18 = icmp eq i32 %t16, %t15
  br i1 %t18, label %bb2, label %bb3
bb2:
  %t20 = load { i64, [4 x i64] }, ptr %l1
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t20, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t24 = load { i64, [4 x i64] }, ptr %l1
  %t25 = mul i64 1, 40
  %t26 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 1, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l16, !tbaa !27
  %t30 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr { i64, [4 x i64] }, ptr %t31, i64 0
  store { i64, [4 x i64] } %t24, ptr %t32
  %t37 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t39 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %v1, ptr %v2, ptr %t22, i32 20, i32 %t23, { i64, ptr } %t37, %"compiler/source:Span" %a3)
  store { i64, [4 x i64] } %t39, ptr %l18
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t40 = load { i64, [4 x i64] }, ptr %l18
  store { i64, [4 x i64] } %t40, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eat(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l5 = alloca %"compiler/lower:pl"
  %l7 = alloca %"compiler/lower:pl"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/lower:pl"
  %t3 = alloca { i64, [2 x i64] }, align 8
  %t11 = alloca { i64, [1 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store ptr %a0, ptr %l2, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t3
  %t4 = getelementptr { i64, [2 x i64] }, ptr %t3, i32 0, i32 0
  store i64 1, ptr %t4
  %t6 = insertvalue { i32 } undef, i32 %a1, 0
  %t7 = getelementptr { i64, [2 x i64] }, ptr %t3, i32 0, i32 1
  store { i32 } %t6, ptr %t7
  %t8 = load { i64, [2 x i64] }, ptr %t3
  %t10 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %s0, { i64, [2 x i64] } %t8)
  store %"compiler/lower:pl" %t10, ptr %l5
  br label %bb1
bb1:
  store { i64, [1 x i64] } zeroinitializer, ptr %t11
  %t12 = getelementptr { i64, [1 x i64] }, ptr %t11, i32 0, i32 0
  store i64 3, ptr %t12
  %t13 = load { i64, [1 x i64] }, ptr %t11
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t15 = load %"compiler/lower:pl", ptr %l5
  %t17 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %s0, ptr %v1, ptr %t14, %"compiler/lower:pl" %t15, { i64, [1 x i64] } %t13)
  store %"compiler/lower:pl" %t17, ptr %l7
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t18 = load %"compiler/lower:pl", ptr %l7
  store %"compiler/lower:pl" %t18, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:pl", ptr %rv
  ret %"compiler/lower:pl" %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l16 = alloca i64
  %l18 = alloca i1
  %l20 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l46 = alloca ptr
  %l51 = alloca %"compiler/typed:BlockInfo"
  %l53 = alloca i32
  %l72 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 12
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 14
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l16
  br label %bb4
bb4:
  %t11 = load i64, ptr %l16, !tbaa !24
  %t12 = icmp sgt i64 %t11, 0
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = call ptr @compiler_2flower_2ecompiler_2flower_3alowering_2etop(ptr %v0, ptr %s0, ptr %t14)
  store ptr %t16, ptr %l20
  br label %bb7
bb6:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb8
bb7:
  %t17 = load ptr, ptr %l20, !tbaa !29
  %t19 = getelementptr %"compiler/lower:level", ptr %t17, i32 0, i32 1
  %t20 = load i32, ptr %t19, !tbaa !23
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Block", ptr %t21, i32 0, i32 0
  %t24 = load i32, ptr %t23, !tbaa !23
  %t27 = icmp eq i32 %t20, %t24
  store i1 %t27, ptr %l18, !tbaa !21
  br label %bb8
bb8:
  %t29 = load i1, ptr %l18, !tbaa !21
  br i1 %t29, label %bb9, label %bb10
bb9:
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Block", ptr %t30, i32 0, i32 1
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  store i64 %t37, ptr %l4, !tbaa !24
  br label %bb11
bb10:
  br label %bb19
bb11:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb12, label %bb13
bb12:
  br label %bb17
bb13:
  br label %bb14
bb14:
  %t47 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t47, ptr %l34, !tbaa !27
  %t48 = load i64, ptr %l3, !tbaa !24
  %t50 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr ptr, ptr %t51, i64 %t48
  %t53 = load ptr, ptr %t52, !tbaa !39
  %t55 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estmt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %t55, ptr %t53)
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t59 = load i64, ptr %l3, !tbaa !24
  %t62 = add i64 %t59, 1
  store i64 %t62, ptr %l3, !tbaa !24
  br label %bb11
bb17:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eendMoved(ptr %v0, ptr %v1, ptr %v3, ptr %v2, ptr %v4, ptr %t64, ptr %t65)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb19:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/lower:lowering", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = getelementptr %"compiler/typed:Body", ptr %t71, i32 0, i32 8
  store ptr %t73, ptr %l46, !tbaa !29
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr %"compiler/typed:Block", ptr %t74, i32 0, i32 0
  %t77 = load i32, ptr %t76, !tbaa !23
  %t79 = sext i32 %t77 to i64
  %t80 = load ptr, ptr %l46, !tbaa !29
  %t81 = call ptr @__olang_scope_or(ptr %v2, ptr %t80)
  %t82 = call ptr @__olang_scope_hold(ptr %t81)
  %t83 = ptrtoint ptr %t82 to i64
  %t85 = inttoptr i64 %t83 to ptr
  %t86 = load ptr, ptr %l46, !tbaa !29
  %t88 = call %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %t85, ptr %t86, i64 %t79)
  store %"compiler/typed:BlockInfo" %t88, ptr %l51
  br label %bb20
bb20:
  %t89 = getelementptr %"compiler/typed:BlockInfo", ptr %l51, i32 0, i32 1
  %t90 = load i32, ptr %t89, !range !{i32 0, i32 10}
  store i32 %t90, ptr %l6
  %t92 = load i32, ptr %l6, !range !{i32 0, i32 10}
  %t94 = trunc i64 2 to i32
  %t95 = icmp eq i32 %t92, %t94
  br i1 %t95, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store i32 2, ptr %l53
  br label %bb33
bb24:
  %t98 = load i32, ptr %l6, !range !{i32 0, i32 10}
  %t100 = trunc i64 5 to i32
  %t101 = icmp eq i32 %t98, %t100
  br i1 %t101, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store i32 3, ptr %l53
  br label %bb33
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store i32 1, ptr %l53
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_97232cd54c6d63ec_e5d7df8d53aaa998)
  unreachable
bb33:
  %t105 = load i32, ptr %l53, !range !{i32 0, i32 7}
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eopenBlock(ptr %v0, ptr %v1, ptr %v2, ptr %v4, ptr %v3, ptr %t106, ptr %t107, i32 %t105, i32 0)
  br label %bb34
bb34:
  %t112 = load ptr, ptr %l1, !tbaa !29
  %t114 = getelementptr %"compiler/typed:Block", ptr %t112, i32 0, i32 1
  %t115 = load { i64, ptr }, ptr %t114, !tbaa !27
  store { i64, ptr } %t115, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t117 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t117, 0
  store i64 %t119, ptr %l10, !tbaa !24
  br label %bb35
bb35:
  %t121 = load i64, ptr %l9, !tbaa !24
  %t122 = load i64, ptr %l10, !tbaa !24
  %t125 = icmp slt i64 %t121, %t122
  %t127 = xor i1 %t125, true
  br i1 %t127, label %bb36, label %bb37
bb36:
  br label %bb41
bb37:
  br label %bb38
bb38:
  %t129 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t129, ptr %l72, !tbaa !27
  %t130 = load i64, ptr %l9, !tbaa !24
  %t132 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr ptr, ptr %t133, i64 %t130
  %t135 = load ptr, ptr %t134, !tbaa !39
  %t137 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estmt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %t137, ptr %t135)
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t141 = load i64, ptr %l9, !tbaa !24
  %t144 = add i64 %t141, 1
  store i64 %t144, ptr %l9, !tbaa !24
  br label %bb35
bb41:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eendMoved(ptr %v0, ptr %v1, ptr %v3, ptr %v2, ptr %v4, ptr %t146, ptr %t147)
  br label %bb42
bb42:
  %t150 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ecloseBlock(ptr %v0, ptr %v2, ptr %v4, ptr %v3, ptr %v5, ptr %t150)
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ebranchesCopy(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i1
  %l25 = alloca i1
  %l26 = alloca i1
  %l32 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i1
  %l47 = alloca { i64, ptr }
  %l54 = alloca i1
  %l63 = alloca i1
  %l64 = alloca ptr
  %l73 = alloca i1
  %l74 = alloca ptr
  %l75 = alloca i1
  %l84 = alloca i1
  %l94 = alloca { i64, ptr }
  %l101 = alloca i1
  %l107 = alloca ptr
  %l108 = alloca i1
  %l117 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t2 = load ptr, ptr %l15, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l15, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 11
  store i1 %t8, ptr %l16, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l16, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb11
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l3, !tbaa !29
  %t19 = getelementptr %"compiler/typed:Cond", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t21 = load i32, ptr %l2, !tbaa !23
  %t25 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eretCopies(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t16, ptr %t20, i32 %t21)
  store i1 %t25, ptr %l25
  br label %bb6
bb6:
  %t26 = load i1, ptr %l25, !tbaa !21
  br i1 %t26, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb10
bb8:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load ptr, ptr %l3, !tbaa !29
  %t30 = getelementptr %"compiler/typed:Cond", ptr %t28, i32 0, i32 2
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = load i32, ptr %l2, !tbaa !23
  %t37 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eretCopies(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t27, ptr %t31, i32 %t33)
  store i1 %t37, ptr %l32
  br label %bb9
bb9:
  %t38 = load i1, ptr %l32, !tbaa !21
  store i1 %t38, ptr %l26, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l26, !tbaa !21
  store i1 %t39, ptr %rv
  br label %ret
bb11:
  %t40 = load ptr, ptr %l1, !tbaa !29
  store ptr %t40, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t41 = load ptr, ptr %l33, !tbaa !29
  %t42 = icmp ne ptr %t41, null
  br i1 %t42, label %bb12, label %bb13
bb12:
  %t44 = load ptr, ptr %l33, !tbaa !29
  %t45 = load i64, ptr %t44, !range !{i64 0, i64 18}
  %t47 = icmp eq i64 %t45, 13
  store i1 %t47, ptr %l34, !tbaa !21
  br label %bb13
bb13:
  %t48 = load i1, ptr %l34, !tbaa !21
  br i1 %t48, label %bb14, label %bb15
bb14:
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [5 x i64] }, ptr %t49, i32 0, i32 1
  %t52 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t51, i32 0, i32 2
  %t53 = load ptr, ptr %t52
  store ptr %t53, ptr %l4, !tbaa !29
  br label %bb16
bb15:
  br label %bb34
bb16:
  %t55 = load ptr, ptr %l4, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Match", ptr %t55, i32 0, i32 1
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  store { i64, ptr } %t58, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t60 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t60, 0
  store i64 %t62, ptr %l7, !tbaa !24
  br label %bb17
bb17:
  %t64 = load i64, ptr %l6, !tbaa !24
  %t65 = load i64, ptr %l7, !tbaa !24
  %t68 = icmp slt i64 %t64, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb18, label %bb19
bb18:
  br label %bb26
bb19:
  br label %bb20
bb20:
  %t72 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t72, ptr %l47, !tbaa !27
  %t73 = load i64, ptr %l6, !tbaa !24
  %t75 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr ptr, ptr %t76, i64 %t73
  %t78 = load ptr, ptr %t77, !tbaa !39
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/typed:Arm", ptr %t78, i32 0, i32 4
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t85 = load i32, ptr %l2, !tbaa !23
  %t89 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eretCopies(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t80, ptr %t84, i32 %t85)
  store i1 %t89, ptr %l54
  br label %bb21
bb21:
  %t90 = load i1, ptr %l54, !tbaa !21
  br i1 %t90, label %bb22, label %bb23
bb22:
  store i1 true, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t92 = load i64, ptr %l6, !tbaa !24
  %t95 = add i64 %t92, 1
  store i64 %t95, ptr %l6, !tbaa !24
  br label %bb17
bb26:
  %t97 = load ptr, ptr %l4, !tbaa !29
  %t99 = getelementptr %"compiler/typed:Match", ptr %t97, i32 0, i32 2
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = icmp eq ptr %t100, null
  %t104 = xor i1 %t102, true
  br i1 %t104, label %bb27, label %bb28
bb27:
  %t106 = load ptr, ptr %l0, !tbaa !29
  store ptr %t106, ptr %l64, !tbaa !29
  %t107 = load ptr, ptr %l4, !tbaa !29
  %t109 = getelementptr %"compiler/typed:Match", ptr %t107, i32 0, i32 2
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = icmp eq ptr %t110, null
  br i1 %t112, label %bb29, label %bb30
bb28:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb33
bb29:
  call void @__olang_check_failed(ptr @olang_loc_2e84a967a4a5e807_2fb41ab57d921c93)
  unreachable
bb30:
  br label %bb31
bb31:
  %t114 = load ptr, ptr %l4, !tbaa !29
  %t116 = getelementptr %"compiler/typed:Match", ptr %t114, i32 0, i32 2
  %t117 = load ptr, ptr %t116, !tbaa !29
  %t120 = getelementptr %"compiler/typed:Arm", ptr %t117, i32 0, i32 4
  %t121 = load ptr, ptr %t120, !tbaa !29
  %t122 = load i32, ptr %l2, !tbaa !23
  %t123 = load ptr, ptr %l64, !tbaa !29
  %t126 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eretCopies(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t123, ptr %t121, i32 %t122)
  store i1 %t126, ptr %l73
  br label %bb32
bb32:
  %t127 = load i1, ptr %l73, !tbaa !21
  store i1 %t127, ptr %l63, !tbaa !21
  br label %bb33
bb33:
  %t128 = load i1, ptr %l63, !tbaa !21
  store i1 %t128, ptr %rv
  br label %ret
bb34:
  %t129 = load ptr, ptr %l1, !tbaa !29
  store ptr %t129, ptr %l74, !tbaa !29
  store i1 false, ptr %l75, !tbaa !21
  %t130 = load ptr, ptr %l74, !tbaa !29
  %t131 = icmp ne ptr %t130, null
  br i1 %t131, label %bb35, label %bb36
bb35:
  %t133 = load ptr, ptr %l74, !tbaa !29
  %t134 = load i64, ptr %t133, !range !{i64 0, i64 18}
  %t136 = icmp eq i64 %t134, 14
  store i1 %t136, ptr %l75, !tbaa !21
  br label %bb36
bb36:
  %t137 = load i1, ptr %l75, !tbaa !21
  br i1 %t137, label %bb37, label %bb38
bb37:
  %t138 = load ptr, ptr %l1, !tbaa !29
  %t140 = getelementptr { i64, [5 x i64] }, ptr %t138, i32 0, i32 1
  %t141 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t140, i32 0, i32 2
  %t142 = load ptr, ptr %t141
  store ptr %t142, ptr %l9, !tbaa !29
  br label %bb39
bb38:
  br label %bb54
bb39:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load ptr, ptr %l9, !tbaa !29
  %t147 = getelementptr %"compiler/typed:Try", ptr %t145, i32 0, i32 0
  %t148 = load ptr, ptr %t147, !tbaa !29
  %t149 = load i32, ptr %l2, !tbaa !23
  %t153 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eretCopies(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t144, ptr %t148, i32 %t149)
  store i1 %t153, ptr %l84
  br label %bb40
bb40:
  %t154 = load i1, ptr %l84, !tbaa !21
  br i1 %t154, label %bb41, label %bb42
bb41:
  store i1 true, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  %t156 = load ptr, ptr %l9, !tbaa !29
  %t158 = getelementptr %"compiler/typed:Try", ptr %t156, i32 0, i32 1
  %t159 = load { i64, ptr }, ptr %t158, !tbaa !27
  store { i64, ptr } %t159, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t161 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t163 = extractvalue { i64, ptr } %t161, 0
  store i64 %t163, ptr %l12, !tbaa !24
  br label %bb44
bb44:
  %t165 = load i64, ptr %l11, !tbaa !24
  %t166 = load i64, ptr %l12, !tbaa !24
  %t169 = icmp slt i64 %t165, %t166
  %t171 = xor i1 %t169, true
  br i1 %t171, label %bb45, label %bb46
bb45:
  br label %bb53
bb46:
  br label %bb47
bb47:
  %t173 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t173, ptr %l94, !tbaa !27
  %t174 = load i64, ptr %l11, !tbaa !24
  %t176 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr ptr, ptr %t177, i64 %t174
  %t179 = load ptr, ptr %t178, !tbaa !39
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/typed:Clause", ptr %t179, i32 0, i32 4
  %t185 = load { i64, ptr }, ptr %t184, !tbaa !27
  %t186 = load i32, ptr %l2, !tbaa !23
  %t190 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2esomeCopies(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t181, { i64, ptr } %t185, i32 %t186)
  store i1 %t190, ptr %l101
  br label %bb48
bb48:
  %t191 = load i1, ptr %l101, !tbaa !21
  br i1 %t191, label %bb49, label %bb50
bb49:
  store i1 true, ptr %rv
  br label %ret
bb50:
  br label %bb51
bb51:
  br label %bb52
bb52:
  %t193 = load i64, ptr %l11, !tbaa !24
  %t196 = add i64 %t193, 1
  store i64 %t196, ptr %l11, !tbaa !24
  br label %bb44
bb53:
  store i1 false, ptr %rv
  br label %ret
bb54:
  %t199 = load ptr, ptr %l1, !tbaa !29
  store ptr %t199, ptr %l107, !tbaa !29
  store i1 false, ptr %l108, !tbaa !21
  %t200 = load ptr, ptr %l107, !tbaa !29
  %t201 = icmp ne ptr %t200, null
  br i1 %t201, label %bb55, label %bb56
bb55:
  %t203 = load ptr, ptr %l107, !tbaa !29
  %t204 = load i64, ptr %t203, !range !{i64 0, i64 18}
  %t206 = icmp eq i64 %t204, 12
  store i1 %t206, ptr %l108, !tbaa !21
  br label %bb56
bb56:
  %t207 = load i1, ptr %l108, !tbaa !21
  br i1 %t207, label %bb57, label %bb58
bb57:
  %t208 = load ptr, ptr %l1, !tbaa !29
  %t210 = getelementptr { i64, [5 x i64] }, ptr %t208, i32 0, i32 1
  %t211 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t210, i32 0, i32 2
  %t212 = load ptr, ptr %t211
  store ptr %t212, ptr %l14, !tbaa !29
  br label %bb59
bb58:
  br label %bb61
bb59:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t215 = load ptr, ptr %l14, !tbaa !29
  %t217 = getelementptr %"compiler/typed:Seq", ptr %t215, i32 0, i32 1
  %t218 = load ptr, ptr %t217, !tbaa !29
  %t219 = load i32, ptr %l2, !tbaa !23
  %t223 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eretCopies(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t214, ptr %t218, i32 %t219)
  store i1 %t223, ptr %l117
  br label %bb60
bb60:
  %t224 = load i1, ptr %l117, !tbaa !21
  store i1 %t224, ptr %rv
  br label %ret
bb61:
  br i1 true, label %bb62, label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb65
bb64:
  store i1 false, ptr %rv
  br label %ret
bb65:
  call void @__olang_check_failed(ptr @olang_loc_bfe3cde0698f801f_d318aea8cb38d3eb)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/mir:Range" @compiler_2flower_2ecompiler_2flower_3alowering_2ecapScopes(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca i64
  %l7 = alloca i1
  %l10 = alloca i1
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca ptr
  %l25 = alloca { i64, [2 x i64] }
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l33 = alloca ptr
  %l37 = alloca { i64, [2 x i64] }
  %l38 = alloca { i64, [1 x i64] }
  %l43 = alloca ptr
  %l45 = alloca { i64, ptr }
  %l46 = alloca %"compiler/mir:Range"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/mir:Range"
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 29
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb3
bb2:
  %t8 = load i32, ptr %l1, !tbaa !23
  %t10 = icmp slt i32 %t8, 0
  store i1 %t10, ptr %l7, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l7, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb6
bb5:
  %t13 = load i32, ptr %l1, !tbaa !23
  %t15 = sext i32 %t13 to i64
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/lower:lowering", ptr %t16, i32 0, i32 38
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/typed:Plan", ptr %t19, i32 0, i32 0
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t27 = icmp sge i64 %t15, %t24
  store i1 %t27, ptr %l10, !tbaa !21
  br label %bb6
bb6:
  %t29 = load i1, ptr %l10, !tbaa !21
  br i1 %t29, label %bb7, label %bb8
bb7:
  %t30 = load %"compiler/mir:Range", ptr @G_2ecompiler_2fmir_2eEmpty
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/mir:Range" %t30, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t32 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t32, ptr %l19
  br label %bb10
bb10:
  %t33 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t33, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  br label %bb11
bb11:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/lower:lowering", ptr %t34, i32 0, i32 38
  %t37 = load ptr, ptr %t36, !tbaa !29
  store ptr %t37, ptr %l21, !tbaa !29
  %t38 = load i32, ptr %l1, !tbaa !23
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = load ptr, ptr %l21, !tbaa !29
  %t41 = call ptr @__olang_scope_or(ptr %v1, ptr %t40)
  %t42 = call ptr @__olang_scope_hold(ptr %t41)
  %t43 = ptrtoint ptr %t42 to i64
  %t45 = inttoptr i64 %t43 to ptr
  %t46 = load ptr, ptr %l21, !tbaa !29
  %t49 = call { i64, [2 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %t45, ptr %t46, i32 %t38, i64 %t39)
  store { i64, [2 x i64] } %t49, ptr %l25
  br label %bb12
bb12:
  %t50 = load { i64, [2 x i64] }, ptr %l25
  %t52 = extractvalue { i64, [2 x i64] } %t50, 0
  %t53 = icmp eq i64 %t52, 0
  %t55 = xor i1 %t53, true
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb13, label %bb14
bb13:
  br label %bb20
bb14:
  br label %bb15
bb15:
  store ptr %l2, ptr %l30, !tbaa !29
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l31, !tbaa !29
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/lower:lowering", ptr %t60, i32 0, i32 38
  %t63 = load ptr, ptr %t62, !tbaa !29
  store ptr %t63, ptr %l33, !tbaa !29
  %t64 = load i32, ptr %l1, !tbaa !23
  %t65 = load i64, ptr %l3, !tbaa !24
  %t66 = load ptr, ptr %l33, !tbaa !29
  %t67 = call ptr @__olang_scope_or(ptr %v1, ptr %t66)
  %t68 = call ptr @__olang_scope_hold(ptr %t67)
  %t69 = ptrtoint ptr %t68 to i64
  %t71 = inttoptr i64 %t69 to ptr
  %t72 = load ptr, ptr %l33, !tbaa !29
  %t75 = call { i64, [2 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %t71, ptr %t72, i32 %t64, i64 %t65)
  store { i64, [2 x i64] } %t75, ptr %l37
  br label %bb16
bb16:
  %t76 = load ptr, ptr %l31, !tbaa !29
  %t77 = load { i64, [2 x i64] }, ptr %l37
  %t78 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2escopeRef(ptr %v0, ptr %v2, ptr %v1, ptr %v3, ptr %v4, ptr %t76, { i64, [2 x i64] } %t77)
  store { i64, [1 x i64] } %t78, ptr %l38
  br label %bb17
bb17:
  %t79 = load ptr, ptr %l30, !tbaa !29
  %t80 = load { i64, [1 x i64] }, ptr %l38
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2ePush_3ccompiler_2fmir_3aScopeRef_3e(ptr %s0, ptr %t79, { i64, [1 x i64] } %t80)
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t81 = load i64, ptr %l3, !tbaa !24
  %t84 = add i64 %t81, 1
  store i64 %t84, ptr %l3, !tbaa !24
  br label %bb11
bb20:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/lower:lowering", ptr %t86, i32 0, i32 3
  store ptr %t88, ptr %l43, !tbaa !29
  %t90 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eToArray_3ccompiler_2fmir_3aScopeRef_3e(ptr %s0, ptr %s0, ptr %l2)
  store { i64, ptr } %t90, ptr %l45
  br label %bb21
bb21:
  %t91 = load ptr, ptr %l43, !tbaa !29
  %t92 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t93 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eScopeRefs(ptr %v0, ptr %s0, ptr %t91, { i64, ptr } %t92)
  store %"compiler/mir:Range" %t93, ptr %l46
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t94 = load %"compiler/mir:Range", ptr %l46
  store %"compiler/mir:Range" %t94, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Range", ptr %rv
  ret %"compiler/mir:Range" %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ecarries(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca ptr
  %l6 = alloca i64
  %l8 = alloca { i64, [4 x i64] }
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca i64
  %l16 = alloca i64
  %l21 = alloca i64
  %l26 = alloca { i64, [4 x i64] }
  %l29 = alloca { i64, [4 x i64] }
  %l36 = alloca { i64, ptr }
  %l38 = alloca { i64, [4 x i64] }
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t1 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store { i64, [4 x i64] } zeroinitializer, ptr %t1
  %t2 = getelementptr { i64, [4 x i64] }, ptr %t1, i32 0, i32 0
  store i64 0, ptr %t2
  %t3 = load { i64, [4 x i64] }, ptr %t1
  store { i64, [4 x i64] } %t3, ptr %l4
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2flower_2ecompiler_2flower_3alowering_2ecarrying(ptr %v0, ptr %s1, ptr %v1, ptr %v2, ptr %t5, i32 %a2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l12
  br label %bb1
bb1:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  %t11 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %t11
  store ptr %t11, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t13 = load i64, ptr %l6, !tbaa !24
  store i64 %t13, ptr %l14, !tbaa !24
  %t14 = load ptr, ptr %l5, !tbaa !29
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s1, ptr %t14)
  store i64 %t16, ptr %l16
  br label %bb3
bb3:
  %t17 = load i64, ptr %l14, !tbaa !24
  %t18 = load i64, ptr %l16, !tbaa !24
  %t19 = icmp slt i64 %t17, %t18
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb5:
  br label %bb6
bb6:
  %t23 = load ptr, ptr %l5, !tbaa !29
  %t24 = load i64, ptr %l6, !tbaa !24
  %t27 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s1, ptr %t23, i64 %t24)
  store i64 %t27, ptr %l21
  br label %bb7
bb7:
  %t28 = load i64, ptr %l21, !tbaa !24
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t32 = load %"compiler/source:Span", ptr %l3
  %t37 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2etypeIs(ptr %v0, ptr %v1, ptr %v2, ptr %t29, { i64, [4 x i64] } %a1, i64 %t28, %"compiler/source:Span" %t32)
  store { i64, [4 x i64] } %t37, ptr %l26
  br label %bb8
bb8:
  %t38 = load { i64, [4 x i64] }, ptr %l26
  store { i64, [4 x i64] } %t38, ptr %l8
  %t39 = load { i64, [4 x i64] }, ptr %l4
  %t41 = extractvalue { i64, [4 x i64] } %t39, 0
  %t42 = icmp eq i64 %t41, 0
  br i1 %t42, label %bb9, label %bb10
bb9:
  %t44 = load { i64, [4 x i64] }, ptr %l8
  store { i64, [4 x i64] } %t44, ptr %l29
  br label %bb12
bb10:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t48 = load { i64, [4 x i64] }, ptr %l4
  %t49 = load { i64, [4 x i64] }, ptr %l8
  %t50 = mul i64 2, 40
  %t51 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t50)
  %t52 = insertvalue { i64, ptr } undef, i64 2, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t51, 1
  store { i64, ptr } %t53, ptr %l36, !tbaa !27
  %t55 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr { i64, [4 x i64] }, ptr %t56, i64 0
  store { i64, [4 x i64] } %t48, ptr %t57
  %t59 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr { i64, [4 x i64] }, ptr %t60, i64 1
  store { i64, [4 x i64] } %t49, ptr %t61
  %t62 = load %"compiler/source:Span", ptr %l3
  %t66 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t68 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s2, ptr %v1, ptr %v2, ptr %t46, i32 11, i32 %t47, { i64, ptr } %t66, %"compiler/source:Span" %t62)
  store { i64, [4 x i64] } %t68, ptr %l38
  br label %bb11
bb11:
  %t69 = load { i64, [4 x i64] }, ptr %l38
  store { i64, [4 x i64] } %t69, ptr %l29
  br label %bb12
bb12:
  %t70 = load { i64, [4 x i64] }, ptr %l29
  store { i64, [4 x i64] } %t70, ptr %l4
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  %t71 = load i64, ptr %l6, !tbaa !24
  %t74 = add i64 %t71, 1
  store i64 %t74, ptr %l6, !tbaa !24
  br label %bb2
bb14:
  call void @__olang_scope_close(ptr %s1)
  %t76 = load { i64, [4 x i64] }, ptr %l4
  store { i64, [4 x i64] } %t76, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2flower_2ecompiler_2flower_3alowering_2ecarrying(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l24 = alloca i64
  %l27 = alloca i64
  %l47 = alloca ptr
  %l49 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l54 = alloca i32
  %l56 = alloca i32
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/lower:lowering", ptr %t3, i32 0, i32 2
  %t6 = load ptr, ptr %t5, !tbaa !29
  store ptr %t6, ptr %l12, !tbaa !29
  %t8 = load ptr, ptr %l12, !tbaa !29
  %t9 = call ptr @__olang_scope_or(ptr %v2, ptr %t8)
  %t10 = call ptr @__olang_scope_hold(ptr %t9)
  %t11 = ptrtoint ptr %t10 to i64
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lower:lowering", ptr %t12, i32 0, i32 2
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = call ptr @__olang_scope_or(ptr %v2, ptr %t15)
  %t18 = call ptr @__olang_scope_hold(ptr %t17)
  %t19 = ptrtoint ptr %t18 to i64
  %t21 = inttoptr i64 %t11 to ptr
  %t23 = inttoptr i64 %t19 to ptr
  %t24 = load ptr, ptr %l12, !tbaa !29
  %t26 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t21, ptr %t23, ptr %t24, i32 %a1)
  store { i64, ptr } %t26, ptr %l18
  br label %bb2
bb2:
  %t27 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t27, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t28 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  store i64 %t30, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t32 = load i64, ptr %l5, !tbaa !24
  %t33 = load i64, ptr %l4, !tbaa !24
  %t36 = icmp sgt i64 %t32, %t33
  br i1 %t36, label %bb3, label %bb4
bb3:
  %t38 = load i64, ptr %l6, !tbaa !24
  %t40 = icmp sgt i64 %t38, 0
  br i1 %t40, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb8
bb5:
  %t42 = load i64, ptr %l5, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = sub i64 %t42, %t43
  %t47 = load i64, ptr %l6, !tbaa !24
  %t50 = add i64 %t46, %t47
  %t52 = sub i64 %t50, 1
  %t53 = load i64, ptr %l6, !tbaa !24
  %t56 = sdiv i64 %t52, %t53
  store i64 %t56, ptr %l27, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb7
bb7:
  %t58 = load i64, ptr %l27, !tbaa !24
  store i64 %t58, ptr %l24, !tbaa !24
  br label %bb8
bb8:
  %t59 = load i64, ptr %l24, !tbaa !24
  store i64 %t59, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  %t60 = load i64, ptr %l8, !tbaa !24
  %t61 = load i64, ptr %l7, !tbaa !24
  %t64 = icmp slt i64 %t60, %t61
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb10, label %bb11
bb10:
  br label %bb20
bb11:
  br label %bb12
bb12:
  %t68 = load i64, ptr %l4, !tbaa !24
  %t69 = load i64, ptr %l8, !tbaa !24
  %t70 = load i64, ptr %l6, !tbaa !24
  %t73 = mul i64 %t69, %t70
  %t76 = add i64 %t68, %t73
  store i64 %t76, ptr %l9, !tbaa !24
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/lower:lowering", ptr %t78, i32 0, i32 0
  %t81 = load ptr, ptr %t80, !tbaa !29
  %t83 = getelementptr %"compiler/lower:Lowerer", ptr %t81, i32 0, i32 0
  %t84 = load ptr, ptr %t83, !tbaa !29
  store ptr %t84, ptr %l47, !tbaa !29
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/lower:lowering", ptr %t85, i32 0, i32 2
  %t88 = load ptr, ptr %t87, !tbaa !29
  store ptr %t88, ptr %l49, !tbaa !29
  %t89 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t89, ptr %l50, !tbaa !27
  %t90 = load i64, ptr %l9, !tbaa !24
  %t92 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr i32, ptr %t93, i64 %t90
  %t95 = load i32, ptr %t94, !tbaa !33
  %t96 = load ptr, ptr %l49, !tbaa !29
  %t97 = call ptr @__olang_scope_or(ptr %v2, ptr %t96)
  %t98 = call ptr @__olang_scope_hold(ptr %t97)
  %t99 = ptrtoint ptr %t98 to i64
  %t101 = inttoptr i64 %t99 to ptr
  %t102 = load ptr, ptr %l49, !tbaa !29
  %t104 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %t101, ptr %t102, i32 %t95)
  store i32 %t104, ptr %l54
  br label %bb13
bb13:
  %t105 = load ptr, ptr %l47, !tbaa !29
  %t106 = call ptr @__olang_scope_or(ptr %v3, ptr %t105)
  %t107 = call ptr @__olang_scope_hold(ptr %t106)
  %t108 = ptrtoint ptr %t107 to i64
  %t110 = inttoptr i64 %t108 to ptr
  %t111 = load ptr, ptr %l47, !tbaa !29
  %t112 = load i32, ptr %l54, !tbaa !23
  %t113 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePayloadOf(ptr %t110, ptr %t111, i32 %t112)
  store i32 %t113, ptr %l56
  br label %bb14
bb14:
  %t114 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t115 = load i32, ptr %l56, !tbaa !23
  %t117 = icmp ne i32 %t115, %t114
  br i1 %t117, label %bb15, label %bb16
bb15:
  %t119 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %l2, i64 %t119)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t122 = load i64, ptr %l8, !tbaa !24
  %t125 = add i64 %t122, 1
  store i64 %t125, ptr %l8, !tbaa !24
  br label %bb9
bb20:
  %t127 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t127, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ecloseBlock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 14
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = sub i64 %t6, 1
  store i64 %t7, ptr %l1, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/lower:lowering", ptr %t9, i32 0, i32 12
  %t12 = load i1, ptr %t11, !tbaa !21
  %t14 = xor i1 %t12, true
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eexitLevel(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t16, i64 %t17)
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb5
bb5:
  %t20 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2epopLevel(ptr %v0, ptr %t20)
  br label %bb6
bb6:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ecombine(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, [4 x i64] } %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l9 = alloca %"compiler/mir:Lvalue"
  %l10 = alloca { i64, [4 x i64] }
  %l12 = alloca { i64, [4 x i64] }
  %l13 = alloca { i64, ptr }
  %l15 = alloca { i64, [4 x i64] }
  %l16 = alloca ptr
  %l17 = alloca %"compiler/source:Span"
  %l19 = alloca %"compiler/mir:Lvalue"
  %l20 = alloca i32
  %l21 = alloca i32
  %l26 = alloca { i64, ptr }
  %l27 = alloca %"compiler/mir:Range"
  %s0 = alloca %olang.scope
  %t6 = alloca { i64, [4 x i64] }, align 8
  %t61 = alloca { i64, [15 x i64] }, align 8
  %t71 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i32 5, ptr %l6
  %t2 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t2, ptr %l7, !tbaa !23
  %t3 = load i32, ptr %l1, !tbaa !23
  %t5 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t3)
  store %"compiler/mir:Lvalue" %t5, ptr %l9
  br label %bb1
bb1:
  store { i64, [4 x i64] } zeroinitializer, ptr %t6
  %t7 = getelementptr { i64, [4 x i64] }, ptr %t6, i32 0, i32 0
  store i64 1, ptr %t7
  %t8 = load %"compiler/mir:Lvalue", ptr %l9
  %t9 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t8, 0
  %t10 = getelementptr { i64, [4 x i64] }, ptr %t6, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t9, ptr %t10
  %t11 = load { i64, [4 x i64] }, ptr %t6
  store { i64, [4 x i64] } %t11, ptr %l10
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t12, i64 1099511628211)
  store { i64, [4 x i64] } %t14, ptr %l12
  br label %bb2
bb2:
  %t15 = mul i64 2, 40
  %t16 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 2, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l13, !tbaa !27
  %t19 = load { i64, [4 x i64] }, ptr %l10
  %t20 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr { i64, [4 x i64] }, ptr %t21, i64 0
  store { i64, [4 x i64] } %t19, ptr %t22
  %t23 = load { i64, [4 x i64] }, ptr %l12
  %t24 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, [4 x i64] }, ptr %t25, i64 1
  store { i64, [4 x i64] } %t23, ptr %t26
  %t27 = load %"compiler/source:Span", ptr %l3
  %t28 = load ptr, ptr %l5, !tbaa !29
  %t29 = load i32, ptr %l6, !range !{i32 0, i32 54}
  %t30 = load i32, ptr %l7, !tbaa !23
  %t31 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t33 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %v1, ptr %v2, ptr %t28, i32 %t29, i32 %t30, { i64, ptr } %t31, %"compiler/source:Span" %t27)
  store { i64, [4 x i64] } %t33, ptr %l15
  br label %bb3
bb3:
  %t34 = load { i64, [4 x i64] }, ptr %l15
  store { i64, [4 x i64] } %t34, ptr %l4
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l16, !tbaa !29
  %t36 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t36, ptr %l17
  %t37 = load i32, ptr %l1, !tbaa !23
  %t39 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t37)
  store %"compiler/mir:Lvalue" %t39, ptr %l19
  br label %bb4
bb4:
  store i32 3, ptr %l20
  %t40 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t40, ptr %l21, !tbaa !23
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/lower:lowering", ptr %t41, i32 0, i32 3
  %t44 = load { i64, [4 x i64] }, ptr %l4
  %t46 = mul i64 2, 40
  %t47 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t46)
  %t48 = insertvalue { i64, ptr } undef, i64 2, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  store { i64, ptr } %t49, ptr %l26, !tbaa !27
  %t51 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr { i64, [4 x i64] }, ptr %t52, i64 0
  store { i64, [4 x i64] } %t44, ptr %t53
  %t55 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr { i64, [4 x i64] }, ptr %t56, i64 1
  store { i64, [4 x i64] } %a2, ptr %t57
  %t59 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t60 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %s0, ptr %t43, { i64, ptr } %t59)
  store %"compiler/mir:Range" %t60, ptr %l27
  br label %bb5
bb5:
  store { i64, [15 x i64] } zeroinitializer, ptr %t61
  %t62 = getelementptr { i64, [15 x i64] }, ptr %t61, i32 0, i32 0
  store i64 3, ptr %t62
  %t63 = load i32, ptr %l20, !range !{i32 0, i32 54}
  %t64 = insertvalue { i32, i32, %"compiler/mir:Range" } undef, i32 %t63, 0
  %t65 = load i32, ptr %l21, !tbaa !23
  %t66 = insertvalue { i32, i32, %"compiler/mir:Range" } %t64, i32 %t65, 1
  %t67 = load %"compiler/mir:Range", ptr %l27
  %t68 = insertvalue { i32, i32, %"compiler/mir:Range" } %t66, %"compiler/mir:Range" %t67, 2
  %t69 = getelementptr { i64, [15 x i64] }, ptr %t61, i32 0, i32 1
  store { i32, i32, %"compiler/mir:Range" } %t68, ptr %t69
  %t70 = load { i64, [15 x i64] }, ptr %t61
  store { i64, [21 x i64] } zeroinitializer, ptr %t71
  %t72 = getelementptr { i64, [21 x i64] }, ptr %t71, i32 0, i32 0
  store i64 0, ptr %t72
  %t73 = load %"compiler/source:Span", ptr %l17
  %t74 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t73, 0
  %t75 = load %"compiler/mir:Lvalue", ptr %l19
  %t76 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t74, %"compiler/mir:Lvalue" %t75, 1
  %t78 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t76, { i64, [15 x i64] } %t70, 2
  %t79 = getelementptr { i64, [21 x i64] }, ptr %t71, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t78, ptr %t79
  %t80 = load { i64, [21 x i64] }, ptr %t71
  %t82 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t80, ptr %t82
  %t83 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %v1, ptr %v2, ptr %t83, ptr %t82)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstBool(ptr %v0, ptr %a0, i1 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l5 = alloca i64
  %rv = alloca { i64, [4 x i64] }
  %t4 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t1, ptr %l3, !tbaa !23
  br i1 %a1, label %bb1, label %bb2
bb1:
  store i64 1, ptr %l5, !tbaa !24
  br label %bb3
bb2:
  store i64 0, ptr %l5, !tbaa !24
  br label %bb3
bb3:
  store { i64, [4 x i64] } zeroinitializer, ptr %t4
  %t5 = getelementptr { i64, [4 x i64] }, ptr %t4, i32 0, i32 0
  store i64 2, ptr %t5
  %t6 = load i32, ptr %l3, !tbaa !23
  %t7 = insertvalue { i32, i64 } undef, i32 %t6, 0
  %t8 = load i64, ptr %l5, !tbaa !24
  %t9 = insertvalue { i32, i64 } %t7, i64 %t8, 1
  %t10 = getelementptr { i64, [4 x i64] }, ptr %t4, i32 0, i32 1
  store { i32, i64 } %t9, ptr %t10
  %t11 = load { i64, [4 x i64] }, ptr %t4
  store { i64, [4 x i64] } %t11, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecountedLocal(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/mir:Local"
  %l6 = alloca %"compiler/mir:Local"
  %l9 = alloca i1
  %l11 = alloca ptr
  %l13 = alloca ptr
  %l16 = alloca i32
  %l18 = alloca i1
  %l20 = alloca i1
  %l23 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 3
  %t4 = getelementptr %"compiler/mir:Fn", ptr %t3, i32 0, i32 7
  %t8 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t4, i64 %a1)
  store %"compiler/mir:Local" %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load %"compiler/mir:Local", ptr %l6
  store %"compiler/mir:Local" %t9, ptr %l2
  %t10 = getelementptr %"compiler/mir:Local", ptr %l2, i32 0, i32 3
  %t11 = load i32, ptr %t10, !range !{i32 0, i32 4}
  %t13 = trunc i64 2 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/lower:lowering", ptr %t16, i32 0, i32 2
  %t19 = load ptr, ptr %t18, !tbaa !29
  store ptr %t19, ptr %l11, !tbaa !29
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/lower:lowering", ptr %t20, i32 0, i32 2
  %t23 = load ptr, ptr %t22, !tbaa !29
  store ptr %t23, ptr %l13, !tbaa !29
  %t24 = getelementptr %"compiler/mir:Local", ptr %l2, i32 0, i32 2
  %t25 = load i32, ptr %t24, !tbaa !23
  %t26 = load ptr, ptr %l13, !tbaa !29
  %t27 = call ptr @__olang_scope_or(ptr %v1, ptr %t26)
  %t28 = call ptr @__olang_scope_hold(ptr %t27)
  %t29 = ptrtoint ptr %t28 to i64
  %t31 = inttoptr i64 %t29 to ptr
  %t32 = load ptr, ptr %l13, !tbaa !29
  %t34 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t31, ptr %t32, i32 %t25)
  store i32 %t34, ptr %l16
  br label %bb4
bb3:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb6
bb4:
  %t35 = load ptr, ptr %l11, !tbaa !29
  %t36 = call ptr @__olang_scope_or(ptr %v1, ptr %t35)
  %t37 = call ptr @__olang_scope_hold(ptr %t36)
  %t38 = ptrtoint ptr %t37 to i64
  %t40 = inttoptr i64 %t38 to ptr
  %t41 = load ptr, ptr %l11, !tbaa !29
  %t42 = load i32, ptr %l16, !tbaa !23
  %t43 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t40, ptr %t41, i32 %t42)
  store i1 %t43, ptr %l18
  br label %bb5
bb5:
  %t44 = load i1, ptr %l18, !tbaa !21
  %t45 = xor i1 %t44, true
  store i1 %t45, ptr %l9, !tbaa !21
  br label %bb6
bb6:
  %t47 = load i1, ptr %l9, !tbaa !21
  br i1 %t47, label %bb7, label %bb8
bb7:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/mir:Local", ptr %l2, i32 0, i32 2
  %t50 = load i32, ptr %t49, !tbaa !23
  %t53 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecounts(ptr %v0, ptr %v1, ptr %v2, ptr %t48, i32 %t50)
  store i1 %t53, ptr %l23
  br label %bb9
bb8:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb10
bb9:
  %t54 = load i1, ptr %l23, !tbaa !21
  store i1 %t54, ptr %l20, !tbaa !21
  br label %bb10
bb10:
  %t55 = load i1, ptr %l20, !tbaa !21
  store i1 %t55, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2edeferred(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i1
  %l6 = alloca ptr
  %l10 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 61
  %t4 = load i1, ptr %t3, !tbaa !21
  store i1 %t4, ptr %l2, !tbaa !21
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 61
  store i1 false, ptr %t8, !tbaa !21
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l6, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/lower:lowering", ptr %t10, i32 0, i32 18
  %t16 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlock_26_3e_2eAt_3ccompiler_2ftyped_3aBlock_26_3e(ptr %v0, ptr %v0, ptr %t12, i64 %a1)
  store ptr %t16, ptr %l10
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l6, !tbaa !29
  %t18 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eblock(ptr %v0, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t17, ptr %t18)
  br label %bb2
bb2:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load i1, ptr %l2, !tbaa !21
  %t23 = getelementptr %"compiler/lower:lowering", ptr %t19, i32 0, i32 61
  store i1 %t20, ptr %t23, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2edepth(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca { i64, [4 x i64] }
  %l6 = alloca { i64, [4 x i64] }
  %rv = alloca { i64, [4 x i64] }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 10
  %t4 = load { i64, [4 x i64] }, ptr %t3
  %t6 = extractvalue { i64, [4 x i64] } %t4, 0
  %t7 = icmp eq i64 %t6, 0
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t9, i64 0)
  store { i64, [4 x i64] } %t11, ptr %l6
  br label %bb3
bb2:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lower:lowering", ptr %t12, i32 0, i32 10
  %t15 = load { i64, [4 x i64] }, ptr %t14
  store { i64, [4 x i64] } %t15, ptr %l4
  br label %bb4
bb3:
  %t17 = load { i64, [4 x i64] }, ptr %l6
  store { i64, [4 x i64] } %t17, ptr %l4
  br label %bb4
bb4:
  %t18 = load { i64, [4 x i64] }, ptr %l4
  store { i64, [4 x i64] } %t18, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2flower_2ecompiler_2flower_3alowering_2eelemReleases(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i32 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i1
  %l5 = alloca i1
  %l12 = alloca ptr
  %l15 = alloca i1
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i1, ptr %l2, !tbaa !21
  %t3 = xor i1 %t1, true
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/lower:lowering", ptr %t5, i32 0, i32 0
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/lower:Lowerer", ptr %t8, i32 0, i32 12
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = icmp eq ptr %t11, null
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb7
bb3:
  call void @__olang_check_failed(ptr @olang_loc_7a0393f255601317_fab53ece13dc18eb)
  unreachable
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/lower:lowering", ptr %t15, i32 0, i32 0
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/lower:Lowerer", ptr %t18, i32 0, i32 12
  %t21 = load ptr, ptr %t20, !tbaa !29
  store ptr %t21, ptr %l12, !tbaa !29
  %t22 = load i32, ptr %l1, !tbaa !23
  %t23 = load ptr, ptr %l12, !tbaa !29
  %t24 = call ptr @__olang_scope_or(ptr %v2, ptr %t23)
  %t25 = call ptr @__olang_scope_hold(ptr %t24)
  %t26 = ptrtoint ptr %t25 to i64
  %t28 = inttoptr i64 %t26 to ptr
  %t29 = load ptr, ptr %l12, !tbaa !29
  %t31 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eSelfHolding(ptr %t28, ptr %t29, i32 %t22)
  store i1 %t31, ptr %l15
  br label %bb6
bb6:
  %t32 = load i1, ptr %l15, !tbaa !21
  store i1 %t32, ptr %l5, !tbaa !21
  br label %bb7
bb7:
  %t33 = load i1, ptr %l5, !tbaa !21
  br i1 %t33, label %bb8, label %bb9
bb8:
  %t34 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2flower_3arelPath_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t34, ptr %l16
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t35 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t35, ptr %rv
  br label %ret
bb11:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i32, ptr %l1, !tbaa !23
  %t38 = load i1, ptr %l2, !tbaa !21
  %t42 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2flower_2ecompiler_2flower_3alowering_2epartReleases(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t36, i32 %t37, i64 0, i1 %t38)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t42, ptr %l20
  br label %bb12
bb12:
  %t43 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t43, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, [1 x i64] }
  %l5 = alloca { i64, [4 x i64] }
  %l10 = alloca i1
  %l12 = alloca ptr
  %l14 = alloca i32
  %l18 = alloca ptr
  %l20 = alloca { i64, [21 x i64] }
  %l23 = alloca { i64, [21 x i64] }
  %l26 = alloca ptr
  %l27 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 12
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t10 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecounted(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t6, ptr %t7)
  store i1 %t10, ptr %l10
  br label %bb4
bb4:
  %t11 = load i1, ptr %l10, !tbaa !21
  br i1 %t11, label %bb5, label %bb6
bb5:
  br label %ret
bb6:
  br label %bb7
bb7:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lower:lowering", ptr %t12, i32 0, i32 3
  store ptr %t14, ptr %l12, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/lower:lowering", ptr %t15, i32 0, i32 11
  %t18 = load i32, ptr %t17, !tbaa !23
  store i32 %t18, ptr %l14, !tbaa !23
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/lower:lowering", ptr %t19, i32 0, i32 8
  %t22 = load i64, ptr %t21, !tbaa !24
  %t24 = icmp sgt i64 %t22, 0
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l1, !tbaa !29
  call void @llvm.memmove.p0.p0.i64(ptr %l20, ptr %t26, i64 176, i1 false)
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/lower:lowering", ptr %t28, i32 0, i32 9
  %t31 = load %"compiler/source:Span", ptr %t30
  %t32 = load { i64, [21 x i64] }, ptr %l20
  %t34 = call { i64, [21 x i64] } @compiler_2fmir_2eStmtAt({ i64, [21 x i64] } %t32, %"compiler/source:Span" %t31)
  store { i64, [21 x i64] } %t34, ptr %l23
  br label %bb10
bb9:
  %t35 = load ptr, ptr %l1, !tbaa !29
  store ptr %t35, ptr %l18, !tbaa !29
  br label %bb11
bb10:
  %t37 = load { i64, [21 x i64] }, ptr %l23
  %t38 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 176, i64 8)
  store { i64, [21 x i64] } %t37, ptr %t38
  store ptr %t38, ptr %l18, !tbaa !29
  br label %bb11
bb11:
  %t40 = load ptr, ptr %l12, !tbaa !29
  %t41 = load i32, ptr %l14, !tbaa !23
  %t42 = load ptr, ptr %l18, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v0, ptr %v1, ptr %t40, i32 %t41, ptr %t42)
  br label %bb12
bb12:
  %t43 = load ptr, ptr %l1, !tbaa !29
  store ptr %t43, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t44 = load ptr, ptr %l26, !tbaa !29
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %bb13, label %bb14
bb13:
  %t47 = load ptr, ptr %l26, !tbaa !29
  %t48 = load i64, ptr %t47, !range !{i64 0, i64 20}
  %t50 = icmp eq i64 %t48, 5
  store i1 %t50, ptr %l27, !tbaa !21
  br label %bb14
bb14:
  %t51 = load i1, ptr %l27, !tbaa !21
  br i1 %t51, label %bb15, label %bb16
bb15:
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = getelementptr { i64, [21 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t54, i32 0, i32 0
  %t56 = load %"compiler/source:Span", ptr %t55
  store %"compiler/source:Span" %t56, ptr %l2
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr { i64, [21 x i64] }, ptr %t58, i32 0, i32 1
  %t61 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t60, i32 0, i32 1
  %t62 = load { i64, [1 x i64] }, ptr %t61
  store { i64, [1 x i64] } %t62, ptr %l3
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr { i64, [21 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t66, i32 0, i32 2
  %t68 = load i32, ptr %t67
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t72 = getelementptr { i64, [21 x i64] }, ptr %t70, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t72, i32 0, i32 3
  %t74 = load { i64, [4 x i64] }, ptr %t73
  store { i64, [4 x i64] } %t74, ptr %l5
  %t76 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ereadDtor(ptr %v0, ptr %v3, ptr %v2, ptr %t76, i32 %t68)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [8 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [8 x i64] }
  %l2 = alloca i32
  %l8 = alloca ptr
  %l13 = alloca %"compiler/mir:Call"
  %l15 = alloca ptr
  %l17 = alloca i32
  %l21 = alloca { i64, [8 x i64] }
  %l25 = alloca { i64, [8 x i64] }
  store ptr %a0, ptr %l0
  store { i64, [8 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 12
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load { i64, [8 x i64] }, ptr %l1
  %t8 = extractvalue { i64, [8 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 4
  br i1 %t9, label %bb4, label %bb5
bb4:
  %t11 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t12 = getelementptr { %"compiler/source:Span", i32 }, ptr %t11, i32 0, i32 1
  %t13 = load i32, ptr %t12
  store i32 %t13, ptr %l2, !tbaa !23
  br label %bb6
bb5:
  br label %bb9
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l8, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/lower:lowering", ptr %t16, i32 0, i32 3
  %t19 = getelementptr %"compiler/mir:Fn", ptr %t18, i32 0, i32 14
  %t20 = load i32, ptr %l2, !tbaa !23
  %t22 = sext i32 %t20 to i64
  %t25 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %t19, i64 %t22)
  store %"compiler/mir:Call" %t25, ptr %l13
  br label %bb7
bb7:
  %t26 = load ptr, ptr %l8, !tbaa !29
  %t27 = load %"compiler/mir:Call", ptr %l13
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eholdResult(ptr %v0, ptr %v1, ptr %v2, ptr %t26, %"compiler/mir:Call" %t27)
  br label %bb8
bb8:
  br label %bb14
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_73d6eb0a01355de0_3ee3de28efd59654)
  unreachable
bb14:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/lower:lowering", ptr %t28, i32 0, i32 3
  store ptr %t30, ptr %l15, !tbaa !29
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/lower:lowering", ptr %t31, i32 0, i32 11
  %t34 = load i32, ptr %t33, !tbaa !23
  store i32 %t34, ptr %l17, !tbaa !23
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/lower:lowering", ptr %t35, i32 0, i32 8
  %t38 = load i64, ptr %t37, !tbaa !24
  %t40 = icmp sgt i64 %t38, 0
  br i1 %t40, label %bb15, label %bb16
bb15:
  %t42 = load { i64, [8 x i64] }, ptr %l1
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/lower:lowering", ptr %t43, i32 0, i32 9
  %t46 = load %"compiler/source:Span", ptr %t45
  %t49 = call { i64, [8 x i64] } @compiler_2fmir_2eTermAt({ i64, [8 x i64] } %t42, %"compiler/source:Span" %t46)
  store { i64, [8 x i64] } %t49, ptr %l25
  br label %bb17
bb16:
  %t50 = load { i64, [8 x i64] }, ptr %l1
  store { i64, [8 x i64] } %t50, ptr %l21
  br label %bb18
bb17:
  %t52 = load { i64, [8 x i64] }, ptr %l25
  store { i64, [8 x i64] } %t52, ptr %l21
  br label %bb18
bb18:
  %t53 = load ptr, ptr %l15, !tbaa !29
  %t54 = load i32, ptr %l17, !tbaa !23
  %t55 = load { i64, [8 x i64] }, ptr %l21
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v0, ptr %t53, i32 %t54, { i64, [8 x i64] } %t55)
  br label %bb19
bb19:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/lower:lowering", ptr %t56, i32 0, i32 12
  store i1 true, ptr %t58, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eerrCodeOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca ptr
  %l7 = alloca i1
  %l10 = alloca %"compiler/mir:Lvalue"
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l16 = alloca %"compiler/lower:pl"
  %l18 = alloca %"compiler/lower:pl"
  %l19 = alloca %"compiler/mir:Lvalue"
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t21 = alloca { i64, [4 x i64] }, align 8
  %t31 = alloca { i64, [2 x i64] }, align 8
  %t39 = alloca { i64, [1 x i64] }, align 8
  %t51 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t7 = call ptr @__olang_scope_or(ptr %v1, ptr %t6)
  %t8 = call ptr @__olang_scope_hold(ptr %t7)
  %t9 = ptrtoint ptr %t8 to i64
  %t11 = inttoptr i64 %t9 to ptr
  %t12 = load ptr, ptr %l4, !tbaa !29
  %t14 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrCarries(ptr %t11, ptr %t12, i32 %a2)
  store i1 %t14, ptr %l7
  br label %bb1
bb1:
  %t15 = load i1, ptr %l7, !tbaa !21
  %t16 = xor i1 %t15, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = load i32, ptr %l1, !tbaa !23
  %t20 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t18)
  store %"compiler/mir:Lvalue" %t20, ptr %l10
  br label %bb4
bb3:
  br label %bb5
bb4:
  store { i64, [4 x i64] } zeroinitializer, ptr %t21
  %t22 = getelementptr { i64, [4 x i64] }, ptr %t21, i32 0, i32 0
  store i64 1, ptr %t22
  %t23 = load %"compiler/mir:Lvalue", ptr %l10
  %t24 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t23, 0
  %t25 = getelementptr { i64, [4 x i64] }, ptr %t21, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t24, ptr %t25
  %t26 = load { i64, [4 x i64] }, ptr %t21
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t26, ptr %rv
  br label %ret
bb5:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l12, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l13, !tbaa !29
  %t30 = load i32, ptr %l1, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t31
  %t32 = getelementptr { i64, [2 x i64] }, ptr %t31, i32 0, i32 0
  store i64 1, ptr %t32
  %t34 = insertvalue { i32 } undef, i32 %t30, 0
  %t35 = getelementptr { i64, [2 x i64] }, ptr %t31, i32 0, i32 1
  store { i32 } %t34, ptr %t35
  %t36 = load { i64, [2 x i64] }, ptr %t31
  %t38 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %s0, { i64, [2 x i64] } %t36)
  store %"compiler/lower:pl" %t38, ptr %l16
  br label %bb6
bb6:
  store { i64, [1 x i64] } zeroinitializer, ptr %t39
  %t40 = getelementptr { i64, [1 x i64] }, ptr %t39, i32 0, i32 0
  store i64 0, ptr %t40
  %t41 = insertvalue { i64 } undef, i64 0, 0
  %t42 = getelementptr { i64, [1 x i64] }, ptr %t39, i32 0, i32 1
  store { i64 } %t41, ptr %t42
  %t43 = load { i64, [1 x i64] }, ptr %t39
  %t44 = load ptr, ptr %l13, !tbaa !29
  %t45 = load %"compiler/lower:pl", ptr %l16
  %t47 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %s0, ptr %s0, ptr %t44, %"compiler/lower:pl" %t45, { i64, [1 x i64] } %t43)
  store %"compiler/lower:pl" %t47, ptr %l18
  br label %bb7
bb7:
  %t48 = load ptr, ptr %l12, !tbaa !29
  %t49 = load %"compiler/lower:pl", ptr %l18
  %t50 = call %"compiler/mir:Lvalue" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %s0, ptr %v2, ptr %t48, %"compiler/lower:pl" %t49)
  store %"compiler/mir:Lvalue" %t50, ptr %l19
  br label %bb8
bb8:
  store { i64, [4 x i64] } zeroinitializer, ptr %t51
  %t52 = getelementptr { i64, [4 x i64] }, ptr %t51, i32 0, i32 0
  store i64 1, ptr %t52
  %t53 = load %"compiler/mir:Lvalue", ptr %l19
  %t54 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t53, 0
  %t55 = getelementptr { i64, [4 x i64] }, ptr %t51, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t54, ptr %t55
  %t56 = load { i64, [4 x i64] }, ptr %t51
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t56, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eerrPush(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca { i64, [1 x i64] }
  %l6 = alloca { i64, [4 x i64] }
  %l7 = alloca i32
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca %"compiler/source:Span"
  %l16 = alloca %"compiler/mir:Lvalue"
  %l22 = alloca ptr
  %l23 = alloca { i64, [4 x i64] }
  %l24 = alloca i32
  %l25 = alloca { i64, [1 x i64] }
  %l29 = alloca %"compiler/source:Span"
  %l30 = alloca { i64, [4 x i64] }
  %l32 = alloca ptr
  %l36 = alloca i32
  %l44 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  %t14 = alloca { i64, [15 x i64] }, align 8
  %t17 = alloca { i64, [21 x i64] }, align 8
  %t32 = alloca { i64, [1 x i64] }, align 8
  %t81 = alloca { i64, [15 x i64] }, align 8
  %t101 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t3 = load %"compiler/source:Span", ptr %l3
  %t7 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t1, i32 %t2, %"compiler/source:Span" %t3)
  store i32 %t7, ptr %l12
  br label %bb1
bb1:
  %t8 = load i32, ptr %l12, !tbaa !23
  store i32 %t8, ptr %l4, !tbaa !23
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l13, !tbaa !29
  %t10 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t10, ptr %l14
  %t11 = load i32, ptr %l4, !tbaa !23
  %t13 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t11)
  store %"compiler/mir:Lvalue" %t13, ptr %l16
  br label %bb2
bb2:
  store { i64, [15 x i64] } zeroinitializer, ptr %t14
  %t15 = getelementptr { i64, [15 x i64] }, ptr %t14, i32 0, i32 0
  store i64 21, ptr %t15
  %t16 = load { i64, [15 x i64] }, ptr %t14
  store { i64, [21 x i64] } zeroinitializer, ptr %t17
  %t18 = getelementptr { i64, [21 x i64] }, ptr %t17, i32 0, i32 0
  store i64 0, ptr %t18
  %t19 = load %"compiler/source:Span", ptr %l14
  %t20 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t19, 0
  %t21 = load %"compiler/mir:Lvalue", ptr %l16
  %t22 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t20, %"compiler/mir:Lvalue" %t21, 1
  %t24 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t22, { i64, [15 x i64] } %t16, 2
  %t25 = getelementptr { i64, [21 x i64] }, ptr %t17, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t24, ptr %t25
  %t26 = load { i64, [21 x i64] }, ptr %t17
  %t28 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t26, ptr %t28
  %t29 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %v1, ptr %v2, ptr %t29, ptr %t28)
  br label %bb3
bb3:
  %t31 = load i32, ptr %l4, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t32
  %t33 = getelementptr { i64, [1 x i64] }, ptr %t32, i32 0, i32 0
  store i64 4, ptr %t33
  %t35 = insertvalue { i32 } undef, i32 %t31, 0
  %t36 = getelementptr { i64, [1 x i64] }, ptr %t32, i32 0, i32 1
  store { i32 } %t35, ptr %t36
  %t37 = load { i64, [1 x i64] }, ptr %t32
  store { i64, [1 x i64] } %t37, ptr %l5
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l22, !tbaa !29
  store { i64, [4 x i64] } %a1, ptr %l23
  %t41 = load i32, ptr %l2, !tbaa !23
  store i32 %t41, ptr %l24, !tbaa !23
  %t42 = load { i64, [1 x i64] }, ptr %l5
  store { i64, [1 x i64] } %t42, ptr %l25
  %t43 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t44 = load i32, ptr %t43, !tbaa !23
  %t46 = add i32 %t44, 1
  %t47 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 1
  %t48 = load i32, ptr %t47, !tbaa !23
  %t51 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t46, i32 %t48)
  store %"compiler/source:Span" %t51, ptr %l29
  br label %bb4
bb4:
  %t52 = load ptr, ptr %l22, !tbaa !29
  %t53 = load { i64, [4 x i64] }, ptr %l23
  %t54 = load i32, ptr %l24, !tbaa !23
  %t55 = load { i64, [1 x i64] }, ptr %l25
  %t56 = load %"compiler/source:Span", ptr %l29
  %t57 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eownCopyOf(ptr %v0, ptr %v1, ptr %v2, ptr %t52, { i64, [4 x i64] } %t53, i32 %t54, { i64, [1 x i64] } %t55, %"compiler/source:Span" %t56, i1 false)
  store { i64, [4 x i64] } %t57, ptr %l30
  br label %bb5
bb5:
  %t58 = load { i64, [4 x i64] }, ptr %l30
  store { i64, [4 x i64] } %t58, ptr %l6
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/lower:lowering", ptr %t59, i32 0, i32 2
  %t62 = load ptr, ptr %t61, !tbaa !29
  store ptr %t62, ptr %l32, !tbaa !29
  %t63 = load i32, ptr %l2, !tbaa !23
  %t64 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t65 = load ptr, ptr %l32, !tbaa !29
  %t66 = call ptr @__olang_scope_or(ptr %v1, ptr %t65)
  %t67 = call ptr @__olang_scope_hold(ptr %t66)
  %t68 = ptrtoint ptr %t67 to i64
  %t70 = inttoptr i64 %t68 to ptr
  %t71 = load ptr, ptr %l32, !tbaa !29
  %t74 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %t70, ptr %t71, i32 %t63, i64 %t64)
  store i32 %t74, ptr %l36
  br label %bb6
bb6:
  %t75 = load i32, ptr %l36, !tbaa !23
  store i32 %t75, ptr %l7, !tbaa !23
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load i32, ptr %l7, !tbaa !23
  %t78 = load { i64, [1 x i64] }, ptr %l5
  %t79 = load { i64, [4 x i64] }, ptr %l6
  %t80 = load i32, ptr %l7, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t81
  %t82 = getelementptr { i64, [15 x i64] }, ptr %t81, i32 0, i32 0
  store i64 7, ptr %t82
  %t84 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } undef, { i64, [1 x i64] } %t78, 0
  %t86 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t84, { i64, [4 x i64] } %t79, 1
  %t88 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t86, i32 %t80, 2
  %t89 = getelementptr { i64, [15 x i64] }, ptr %t81, i32 0, i32 1
  store { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t88, ptr %t89
  %t90 = load { i64, [15 x i64] }, ptr %t81
  %t91 = load %"compiler/source:Span", ptr %l3
  %t96 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %v1, ptr %v2, ptr %t76, i32 %t77, { i64, [15 x i64] } %t90, %"compiler/source:Span" %t91)
  store { i64, [4 x i64] } %t96, ptr %l44
  br label %bb7
bb7:
  %t97 = load { i64, [4 x i64] }, ptr %l44
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load %"compiler/source:Span", ptr %l3
  store { i64, [21 x i64] } zeroinitializer, ptr %t101
  %t102 = getelementptr { i64, [21 x i64] }, ptr %t101, i32 0, i32 0
  store i64 15, ptr %t102
  %t104 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t99, 0
  %t106 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t104, { i64, [4 x i64] } %t97, 1
  %t107 = getelementptr { i64, [21 x i64] }, ptr %t101, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t106, ptr %t107
  %t108 = load { i64, [21 x i64] }, ptr %t101
  %t110 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t108, ptr %t110
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %v1, ptr %v2, ptr %t98, ptr %t110)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/mir:Lvalue" @compiler_2flower_2ecompiler_2flower_3alowering_2eextended(ptr %v0, ptr %a0, %"compiler/mir:Lvalue" %a1, { i64, [1 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Lvalue"
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca { i64, ptr }
  %l16 = alloca i64
  %l25 = alloca i64
  %l28 = alloca i64
  %l59 = alloca %"compiler/mir:Lvalue"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/mir:Lvalue"
  store ptr %a0, ptr %l0
  store %"compiler/mir:Lvalue" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load %"compiler/mir:Lvalue", ptr %l1
  %t5 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2eprojsOf(ptr %v0, ptr %s0, ptr %t1, %"compiler/mir:Lvalue" %t2)
  store { i64, ptr } %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t11 = add i64 %t9, 1
  store i64 %t11, ptr %l16, !tbaa !24
  %t12 = load i64, ptr %l16, !tbaa !24
  %t13 = icmp sge i64 %t12, 0
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = load i64, ptr %l16, !tbaa !24
  %t16 = icmp sle i64 %t15, 576460752303423487
  br i1 %t16, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_f1bdf5287cd948f5_22d23fd045556b79)
  unreachable
bb4:
  %t18 = load i64, ptr %l16, !tbaa !24
  %t19 = mul i64 %t18, 16
  %t20 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  store { i64, ptr } %t22, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  store i64 %t26, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t28 = load i64, ptr %l6, !tbaa !24
  %t29 = load i64, ptr %l5, !tbaa !24
  %t32 = icmp sgt i64 %t28, %t29
  br i1 %t32, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_f1bdf5287cd948f5_22d23fd045556b79)
  unreachable
bb6:
  %t34 = load i64, ptr %l7, !tbaa !24
  %t36 = icmp sgt i64 %t34, 0
  br i1 %t36, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb11
bb8:
  %t38 = load i64, ptr %l6, !tbaa !24
  %t39 = load i64, ptr %l5, !tbaa !24
  %t42 = sub i64 %t38, %t39
  %t43 = load i64, ptr %l7, !tbaa !24
  %t46 = add i64 %t42, %t43
  %t48 = sub i64 %t46, 1
  %t49 = load i64, ptr %l7, !tbaa !24
  %t52 = sdiv i64 %t48, %t49
  store i64 %t52, ptr %l28, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb10
bb10:
  %t54 = load i64, ptr %l28, !tbaa !24
  store i64 %t54, ptr %l25, !tbaa !24
  br label %bb11
bb11:
  %t55 = load i64, ptr %l25, !tbaa !24
  store i64 %t55, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb12
bb12:
  %t56 = load i64, ptr %l9, !tbaa !24
  %t57 = load i64, ptr %l8, !tbaa !24
  %t60 = icmp slt i64 %t56, %t57
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb13, label %bb14
bb13:
  br label %bb17
bb14:
  br label %bb15
bb15:
  %t64 = load i64, ptr %l5, !tbaa !24
  %t65 = load i64, ptr %l9, !tbaa !24
  %t66 = load i64, ptr %l7, !tbaa !24
  %t69 = mul i64 %t65, %t66
  %t72 = add i64 %t64, %t69
  store i64 %t72, ptr %l10, !tbaa !24
  %t74 = load i64, ptr %l10, !tbaa !24
  %t75 = load i64, ptr %l10, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr { i64, [1 x i64] }, ptr %t78, i64 %t75
  %t80 = load { i64, [1 x i64] }, ptr %t79
  %t83 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = getelementptr { i64, [1 x i64] }, ptr %t84, i64 %t74
  store { i64, [1 x i64] } %t80, ptr %t85
  br label %bb16
bb16:
  %t86 = load i64, ptr %l9, !tbaa !24
  %t89 = add i64 %t86, 1
  store i64 %t89, ptr %l9, !tbaa !24
  br label %bb12
bb17:
  %t91 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t91, 0
  %t97 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr { i64, [1 x i64] }, ptr %t98, i64 %t93
  store { i64, [1 x i64] } %a2, ptr %t99
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/lower:lowering", ptr %t100, i32 0, i32 3
  %t103 = getelementptr %"compiler/mir:Lvalue", ptr %l1, i32 0, i32 0
  %t104 = load { i64, [2 x i64] }, ptr %t103
  %t105 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t109 = call %"compiler/mir:Lvalue" @compiler_2fmir_2ecompiler_2fmir_3aFn_2ePlace(ptr %v0, ptr %s0, ptr %t102, { i64, [2 x i64] } %t104, { i64, ptr } %t105)
  store %"compiler/mir:Lvalue" %t109, ptr %l59
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s0)
  %t110 = load %"compiler/mir:Lvalue", ptr %l59
  store %"compiler/mir:Lvalue" %t110, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Lvalue", ptr %rv
  ret %"compiler/mir:Lvalue" %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2efails(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, i32 %a3, i64 %a4, %"compiler/source:Span" %a5) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l9 = alloca i1
  %l16 = alloca { i64, ptr }
  %l18 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 12
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l2, !range !{i32 0, i32 4}
  %t8 = trunc i64 0 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l9, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l9, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  br label %bb6
bb6:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t15 = mul i64 1, 40
  %t16 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 1, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l16, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr { i64, [4 x i64] }, ptr %t21, i64 0
  store { i64, [4 x i64] } %a1, ptr %t22
  %t23 = load %"compiler/source:Span", ptr %l5
  %t27 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t29 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %v1, ptr %v2, ptr %t12, i32 2, i32 %t13, { i64, ptr } %t27, %"compiler/source:Span" %t23)
  store { i64, [4 x i64] } %t29, ptr %l18
  br label %bb7
bb7:
  %t30 = load { i64, [4 x i64] }, ptr %l18
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l2, !range !{i32 0, i32 4}
  %t36 = load %"compiler/source:Span", ptr %l5
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2echeck(ptr %v0, ptr %v2, ptr %v1, ptr %v3, ptr %v4, ptr %t31, { i64, [4 x i64] } %t30, i32 %t33, i32 %a3, i64 %a4, %"compiler/source:Span" %t36)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2efit(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, [4 x i64] } %a1, ptr %a2, i32 %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [4 x i64] }
  %l2 = alloca ptr
  %l3 = alloca i32
  %l7 = alloca i1
  %l15 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca { i64, [4 x i64] }
  %l19 = alloca i32
  %l20 = alloca i32
  %l21 = alloca %"compiler/source:Span"
  %l23 = alloca { i64, [1 x i64] }
  %l24 = alloca { i64, [4 x i64] }
  %rv = alloca { i64, [4 x i64] }
  store ptr %a0, ptr %l0
  store { i64, [4 x i64] } %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 12
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb3
bb2:
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = icmp eq ptr %t6, null
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb3
bb3:
  %t10 = load i1, ptr %l7, !tbaa !21
  br i1 %t10, label %bb4, label %bb5
bb4:
  %t11 = load { i64, [4 x i64] }, ptr %l1
  store { i64, [4 x i64] } %t11, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t16 = load i32, ptr %l3, !tbaa !23
  %t20 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2efits(ptr %v0, ptr %v1, ptr %v2, ptr %t13, ptr %t14, i32 %t16)
  store i1 %t20, ptr %l15
  br label %bb7
bb7:
  %t21 = load i1, ptr %l15, !tbaa !21
  br i1 %t21, label %bb8, label %bb9
bb8:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l16, !tbaa !29
  %t23 = load { i64, [4 x i64] }, ptr %l1
  store { i64, [4 x i64] } %t23, ptr %l17
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t26 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t24)
  store i32 %t26, ptr %l19
  br label %bb10
bb9:
  br label %bb13
bb10:
  %t27 = load i32, ptr %l3, !tbaa !23
  store i32 %t27, ptr %l20, !tbaa !23
  store %"compiler/source:Span" %a4, ptr %l21
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einnermost(ptr %v0, ptr %t29)
  store { i64, [1 x i64] } %t31, ptr %l23
  br label %bb11
bb11:
  %t32 = load ptr, ptr %l16, !tbaa !29
  %t33 = load { i64, [4 x i64] }, ptr %l17
  %t34 = load i32, ptr %l19, !tbaa !23
  %t35 = load i32, ptr %l20, !tbaa !23
  %t36 = load %"compiler/source:Span", ptr %l21
  %t37 = load { i64, [1 x i64] }, ptr %l23
  %t38 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ewiden(ptr %v0, ptr %v2, ptr %v3, ptr %t32, { i64, [4 x i64] } %t33, i32 %t34, i32 %t35, %"compiler/source:Span" %t36, { i64, [1 x i64] } %t37)
  store { i64, [4 x i64] } %t38, ptr %l24
  br label %bb12
bb12:
  %t39 = load { i64, [4 x i64] }, ptr %l24
  store { i64, [4 x i64] } %t39, ptr %rv
  br label %ret
bb13:
  %t40 = load { i64, [4 x i64] }, ptr %l1
  store { i64, [4 x i64] } %t40, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local i64 @compiler_2flower_2ecompiler_2flower_3alowering_2efixedLen(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l4 = alloca ptr
  %l7 = alloca i32
  %l10 = alloca i1
  %l12 = alloca ptr
  %l15 = alloca i32
  %l21 = alloca ptr
  %l24 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t7 = call ptr @__olang_scope_or(ptr %v1, ptr %t6)
  %t8 = call ptr @__olang_scope_hold(ptr %t7)
  %t9 = ptrtoint ptr %t8 to i64
  %t11 = inttoptr i64 %t9 to ptr
  %t12 = load ptr, ptr %l4, !tbaa !29
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %t11, ptr %t12, i32 %a1)
  store i32 %t14, ptr %l7
  br label %bb1
bb1:
  %t15 = load i32, ptr %l7, !tbaa !23
  store i32 %t15, ptr %l2, !tbaa !23
  %t16 = load i32, ptr %l2, !tbaa !23
  %t18 = icmp eq i32 %t16, 0
  br i1 %t18, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb5
bb3:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/lower:lowering", ptr %t20, i32 0, i32 2
  %t23 = load ptr, ptr %t22, !tbaa !29
  store ptr %t23, ptr %l12, !tbaa !29
  %t24 = load i32, ptr %l2, !tbaa !23
  %t25 = load ptr, ptr %l12, !tbaa !29
  %t26 = call ptr @__olang_scope_or(ptr %v1, ptr %t25)
  %t27 = call ptr @__olang_scope_hold(ptr %t26)
  %t28 = ptrtoint ptr %t27 to i64
  %t30 = inttoptr i64 %t28 to ptr
  %t31 = load ptr, ptr %l12, !tbaa !29
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t30, ptr %t31, i32 %t24)
  store i32 %t33, ptr %l15
  br label %bb4
bb4:
  %t34 = load i32, ptr %l15, !range !{i32 0, i32 33}
  %t36 = trunc i64 26 to i32
  %t37 = icmp eq i32 %t34, %t36
  %t39 = xor i1 %t37, true
  store i1 %t39, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t41 = load i1, ptr %l10, !tbaa !21
  br i1 %t41, label %bb6, label %bb7
bb6:
  store i64 -1, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/lower:lowering", ptr %t43, i32 0, i32 2
  %t46 = load ptr, ptr %t45, !tbaa !29
  store ptr %t46, ptr %l21, !tbaa !29
  %t47 = load i32, ptr %l2, !tbaa !23
  %t48 = load ptr, ptr %l21, !tbaa !29
  %t49 = call ptr @__olang_scope_or(ptr %v1, ptr %t48)
  %t50 = call ptr @__olang_scope_hold(ptr %t49)
  %t51 = ptrtoint ptr %t50 to i64
  %t53 = inttoptr i64 %t51 to ptr
  %t54 = load ptr, ptr %l21, !tbaa !29
  %t56 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %t53, ptr %t54, i32 %t47)
  store i64 %t56, ptr %l24
  br label %bb9
bb9:
  %t57 = load i64, ptr %l24, !tbaa !24
  store i64 %t57, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eglobalHits(ptr %v0, ptr %v1, ptr %v2, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i64
  %l9 = alloca i64
  %l14 = alloca i64
  %l20 = alloca i1
  %l21 = alloca i1
  %l24 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2flower_2ecompiler_2flower_3alowering_2emutGlobals(ptr %v0, ptr %v0, ptr %v1, ptr %t1)
  store ptr %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l6, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  br label %bb2
bb2:
  %t5 = load i64, ptr %l2, !tbaa !24
  store i64 %t5, ptr %l7, !tbaa !24
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l9
  br label %bb3
bb3:
  %t9 = load i64, ptr %l7, !tbaa !24
  %t10 = load i64, ptr %l9, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb4, label %bb5
bb4:
  br label %bb17
bb5:
  br label %bb6
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t15, i64 %t16)
  store i64 %t19, ptr %l14
  br label %bb7
bb7:
  %t20 = load i64, ptr %l14, !tbaa !24
  %t23 = trunc i64 %t20 to i32
  store i32 %t23, ptr %l4, !tbaa !23
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load i32, ptr %l4, !tbaa !23
  %t30 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eobjHits(ptr %v0, ptr %v2, ptr %t26, i32 %t27)
  store i1 %t30, ptr %l20
  br label %bb8
bb8:
  %t31 = load i1, ptr %l20, !tbaa !21
  br i1 %t31, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb12
bb10:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l4, !tbaa !23
  %t36 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ewritesCover(ptr %v0, ptr %v2, ptr %t32, i32 %t33, i64 0)
  store i1 %t36, ptr %l24
  br label %bb11
bb11:
  %t37 = load i1, ptr %l24, !tbaa !21
  store i1 %t37, ptr %l21, !tbaa !21
  br label %bb12
bb12:
  %t38 = load i1, ptr %l21, !tbaa !21
  br i1 %t38, label %bb13, label %bb14
bb13:
  store i1 true, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t40 = load i64, ptr %l2, !tbaa !24
  %t43 = add i64 %t40, 1
  store i64 %t43, ptr %l2, !tbaa !24
  br label %bb2
bb17:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1) #0 {
entry:
  %t3 = alloca { i64, [8 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store { i64, [8 x i64] } zeroinitializer, ptr %t3
  %t4 = getelementptr { i64, [8 x i64] }, ptr %t3, i32 0, i32 0
  store i64 1, ptr %t4
  %t6 = insertvalue { i32 } undef, i32 %a1, 0
  %t7 = getelementptr { i64, [8 x i64] }, ptr %t3, i32 0, i32 1
  store { i32 } %t6, ptr %t7
  %t8 = load { i64, [8 x i64] }, ptr %t3
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [8 x i64] } %t8)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eguardHolder(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l9 = alloca i1
  %l15 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l18 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/lower:Lowerer", ptr %t4, i32 0, i32 16
  %t7 = load i1, ptr %t6, !tbaa !21
  %t9 = xor i1 %t7, true
  br i1 %t9, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb3
bb2:
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t13 = getelementptr %"compiler/typed:Block", ptr %t11, i32 0, i32 1
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  %t18 = icmp ne i64 %t16, 1
  store i1 %t18, ptr %l9, !tbaa !21
  br label %bb3
bb3:
  %t20 = load i1, ptr %l9, !tbaa !21
  br i1 %t20, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Block", ptr %t21, i32 0, i32 1
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  store { i64, ptr } %t24, ptr %l15, !tbaa !27
  %t25 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 0
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l3, !tbaa !29
  %t30 = load ptr, ptr %l3, !tbaa !29
  store ptr %t30, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t31 = load ptr, ptr %l17, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb7, label %bb8
bb7:
  %t34 = load ptr, ptr %l17, !tbaa !29
  %t35 = load i64, ptr %t34, !range !{i64 0, i64 17}
  %t37 = icmp eq i64 %t35, 3
  store i1 %t37, ptr %l18, !tbaa !21
  br label %bb8
bb8:
  %t38 = load i1, ptr %l18, !tbaa !21
  br i1 %t38, label %bb9, label %bb10
bb9:
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = getelementptr { i64, [3 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", ptr }, ptr %t41, i32 0, i32 1
  %t43 = load ptr, ptr %t42
  store ptr %t43, ptr %l4, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eguardIf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %t45, %"compiler/source:Span" %a1, ptr %t47)
  br label %bb12
bb12:
  br label %bb18
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_59bbbec53ff2140a_aa19bd361a96e2fe)
  unreachable
bb18:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ehasStr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2estrBody(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = icmp sge i64 %t6, 0
  store i1 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eheldMadeOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i1
  %l21 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l32 = alloca i1
  %l36 = alloca i1
  %l39 = alloca { i64, ptr }
  %l41 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb13
bb4:
  %t10 = load ptr, ptr %l2, !tbaa !29
  store ptr %t10, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t11 = load ptr, ptr %l10, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l10, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 18}
  %t17 = icmp eq i64 %t15, 10
  store i1 %t17, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l11, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  %t19 = load ptr, ptr %l2, !tbaa !29
  store ptr %t19, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t20 = load ptr, ptr %l14, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb9, label %bb10
bb9:
  %t23 = load ptr, ptr %l14, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 18}
  %t26 = icmp eq i64 %t24, 1
  store i1 %t26, ptr %l15, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l15, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t30 = load ptr, ptr %l2, !tbaa !29
  %t34 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eheldSrc(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %t28, ptr %t29, ptr %t30)
  store i1 %t34, ptr %l21
  br label %bb14
bb14:
  %t35 = load i1, ptr %l21, !tbaa !21
  store i1 %t35, ptr %l5, !tbaa !21
  br label %bb33
bb15:
  %t36 = load ptr, ptr %l2, !tbaa !29
  store ptr %t36, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t37 = load ptr, ptr %l22, !tbaa !29
  %t38 = icmp ne ptr %t37, null
  br i1 %t38, label %bb16, label %bb17
bb16:
  %t40 = load ptr, ptr %l22, !tbaa !29
  %t41 = load i64, ptr %t40, !range !{i64 0, i64 18}
  %t43 = icmp eq i64 %t41, 9
  store i1 %t43, ptr %l23, !tbaa !21
  br label %bb17
bb17:
  %t44 = load i1, ptr %l23, !tbaa !21
  br i1 %t44, label %bb18, label %bb19
bb18:
  %t45 = load ptr, ptr %l2, !tbaa !29
  %t47 = getelementptr { i64, [5 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t47, i32 0, i32 2
  %t49 = load i32, ptr %t48, !range !{i32 0, i32 54}
  store i32 %t49, ptr %l3
  %t51 = load ptr, ptr %l2, !tbaa !29
  %t53 = getelementptr { i64, [5 x i64] }, ptr %t51, i32 0, i32 1
  %t54 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t53, i32 0, i32 4
  %t55 = load { i64, ptr }, ptr %t54
  store { i64, ptr } %t55, ptr %l4, !tbaa !27
  br label %bb20
bb19:
  br label %bb28
bb20:
  %t57 = load i32, ptr %l3, !range !{i32 0, i32 54}
  %t59 = trunc i64 20 to i32
  %t60 = icmp eq i32 %t57, %t59
  br i1 %t60, label %bb21, label %bb22
bb21:
  %t62 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t62, 0
  %t66 = icmp eq i64 %t64, 1
  store i1 %t66, ptr %l32, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb23
bb23:
  %t68 = load i1, ptr %l32, !tbaa !21
  br i1 %t68, label %bb24, label %bb25
bb24:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t71 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t71, ptr %l39, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr ptr, ptr %t73, i64 0
  %t75 = load ptr, ptr %t74, !tbaa !39
  %t79 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eheldMadeOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %t69, ptr %t70, ptr %t75)
  store i1 %t79, ptr %l41
  br label %bb26
bb25:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb27
bb26:
  %t80 = load i1, ptr %l41, !tbaa !21
  store i1 %t80, ptr %l36, !tbaa !21
  br label %bb27
bb27:
  %t81 = load i1, ptr %l36, !tbaa !21
  store i1 %t81, ptr %l5, !tbaa !21
  br label %bb33
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_48d1beea25ddfa94_a3fe957274d91168)
  unreachable
bb33:
  %t82 = load i1, ptr %l5, !tbaa !21
  store i1 %t82, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eheldRefPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i1
  %l12 = alloca ptr
  %l15 = alloca ptr
  %l19 = alloca %"compiler/typed:Local"
  %l22 = alloca i1
  %l23 = alloca i1
  %l28 = alloca i1
  %l33 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb13
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/lower:lowering", ptr %t16, i32 0, i32 2
  %t19 = load ptr, ptr %t18, !tbaa !29
  store ptr %t19, ptr %l12, !tbaa !29
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/lower:lowering", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/typed:Body", ptr %t23, i32 0, i32 7
  store ptr %t25, ptr %l15, !tbaa !29
  %t26 = load i32, ptr %l3, !tbaa !23
  %t28 = sext i32 %t26 to i64
  %t29 = load ptr, ptr %l15, !tbaa !29
  %t30 = call ptr @__olang_scope_or(ptr %v3, ptr %t29)
  %t31 = call ptr @__olang_scope_hold(ptr %t30)
  %t32 = ptrtoint ptr %t31 to i64
  %t34 = inttoptr i64 %t32 to ptr
  %t35 = load ptr, ptr %l15, !tbaa !29
  %t37 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %t34, ptr %t35, i64 %t28)
  store %"compiler/typed:Local" %t37, ptr %l19
  br label %bb6
bb6:
  %t38 = getelementptr %"compiler/typed:Local", ptr %l19, i32 0, i32 2
  %t39 = load i32, ptr %t38, !tbaa !23
  %t40 = load ptr, ptr %l12, !tbaa !29
  %t41 = call ptr @__olang_scope_or(ptr %v4, ptr %t40)
  %t42 = call ptr @__olang_scope_hold(ptr %t41)
  %t43 = ptrtoint ptr %t42 to i64
  %t45 = inttoptr i64 %t43 to ptr
  %t46 = load ptr, ptr %l12, !tbaa !29
  %t48 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t45, ptr %t46, i32 %t39)
  store i1 %t48, ptr %l22
  br label %bb7
bb7:
  %t49 = load i1, ptr %l22, !tbaa !21
  br i1 %t49, label %bb8, label %bb9
bb8:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t52 = load i32, ptr %l3, !tbaa !23
  %t54 = sext i32 %t52 to i64
  %t58 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eheldReferent(ptr %v0, ptr %v1, ptr %v3, ptr %v4, ptr %v5, ptr %t50, ptr %t51, i64 %t54)
  store i1 %t58, ptr %l28
  br label %bb10
bb9:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t61 = load i32, ptr %l3, !tbaa !23
  %t63 = sext i32 %t61 to i64
  %t67 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eheldLocal(ptr %v0, ptr %v1, ptr %v3, ptr %v4, ptr %v5, ptr %t59, ptr %t60, i64 %t63)
  store i1 %t67, ptr %l33
  br label %bb11
bb10:
  %t68 = load i1, ptr %l28, !tbaa !21
  store i1 %t68, ptr %l23, !tbaa !21
  br label %bb12
bb11:
  %t69 = load i1, ptr %l33, !tbaa !21
  store i1 %t69, ptr %l23, !tbaa !21
  br label %bb12
bb12:
  %t70 = load i1, ptr %l23, !tbaa !21
  store i1 %t70, ptr %l4, !tbaa !21
  br label %bb18
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_7eb84e3ee2221218_b4c673b45eee5a74)
  unreachable
bb18:
  %t71 = load i1, ptr %l4, !tbaa !21
  store i1 %t71, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eheldSrc(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l25 = alloca ptr
  %l28 = alloca i1
  %l29 = alloca i1
  %l33 = alloca i1
  %l37 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l47 = alloca i1
  %l48 = alloca ptr
  %l49 = alloca i1
  %l58 = alloca i1
  %l59 = alloca ptr
  %l60 = alloca i1
  %l69 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca i1
  %l80 = alloca i1
  %l84 = alloca i1
  %l87 = alloca { i64, ptr }
  %l89 = alloca i1
  %l90 = alloca ptr
  %l91 = alloca i1
  %l99 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t2 = load ptr, ptr %l12, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l12, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l13, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l13, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb64
bb6:
  %t10 = load ptr, ptr %l2, !tbaa !29
  store ptr %t10, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t11 = load ptr, ptr %l16, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l16, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 18}
  %t17 = icmp eq i64 %t15, 2
  store i1 %t17, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l17, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = getelementptr { i64, [5 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t21, i32 0, i32 1
  %t23 = load i32, ptr %t22
  store i32 %t23, ptr %l3, !tbaa !23
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t27, i32 0, i32 2
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l4, !tbaa !29
  br label %bb11
bb10:
  br label %bb18
bb11:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/lower:lowering", ptr %t31, i32 0, i32 2
  %t34 = load ptr, ptr %t33, !tbaa !29
  store ptr %t34, ptr %l25, !tbaa !29
  %t35 = load i32, ptr %l3, !tbaa !23
  %t36 = load ptr, ptr %l25, !tbaa !29
  %t37 = call ptr @__olang_scope_or(ptr %v3, ptr %t36)
  %t38 = call ptr @__olang_scope_hold(ptr %t37)
  %t39 = ptrtoint ptr %t38 to i64
  %t41 = inttoptr i64 %t39 to ptr
  %t42 = load ptr, ptr %l25, !tbaa !29
  %t44 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t41, ptr %t42, i32 %t35)
  store i1 %t44, ptr %l28
  br label %bb12
bb12:
  %t45 = load i1, ptr %l28, !tbaa !21
  br i1 %t45, label %bb13, label %bb14
bb13:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t48 = load ptr, ptr %l4, !tbaa !29
  %t52 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eheldRefPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v4, ptr %v3, ptr %v5, ptr %t46, ptr %t47, ptr %t48)
  store i1 %t52, ptr %l33
  br label %bb15
bb14:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t55 = load ptr, ptr %l4, !tbaa !29
  %t59 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eheldPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v4, ptr %v3, ptr %v5, ptr %t53, ptr %t54, ptr %t55)
  store i1 %t59, ptr %l37
  br label %bb16
bb15:
  %t60 = load i1, ptr %l33, !tbaa !21
  store i1 %t60, ptr %l29, !tbaa !21
  br label %bb17
bb16:
  %t61 = load i1, ptr %l37, !tbaa !21
  store i1 %t61, ptr %l29, !tbaa !21
  br label %bb17
bb17:
  %t62 = load i1, ptr %l29, !tbaa !21
  store i1 %t62, ptr %l11, !tbaa !21
  br label %bb64
bb18:
  %t63 = load ptr, ptr %l2, !tbaa !29
  store ptr %t63, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t64 = load ptr, ptr %l38, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb19, label %bb20
bb19:
  %t67 = load ptr, ptr %l38, !tbaa !29
  %t68 = load i64, ptr %t67, !range !{i64 0, i64 18}
  %t70 = icmp eq i64 %t68, 3
  store i1 %t70, ptr %l39, !tbaa !21
  br label %bb20
bb20:
  %t71 = load i1, ptr %l39, !tbaa !21
  br i1 %t71, label %bb21, label %bb22
bb21:
  %t72 = load ptr, ptr %l2, !tbaa !29
  %t74 = getelementptr { i64, [5 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t74, i32 0, i32 2
  %t76 = load ptr, ptr %t75
  store ptr %t76, ptr %l5, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t80 = load ptr, ptr %l5, !tbaa !29
  %t84 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eheldPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v4, ptr %v3, ptr %v5, ptr %t78, ptr %t79, ptr %t80)
  store i1 %t84, ptr %l47
  br label %bb24
bb24:
  %t85 = load i1, ptr %l47, !tbaa !21
  store i1 %t85, ptr %l11, !tbaa !21
  br label %bb64
bb25:
  %t86 = load ptr, ptr %l2, !tbaa !29
  store ptr %t86, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t87 = load ptr, ptr %l48, !tbaa !29
  %t88 = icmp ne ptr %t87, null
  br i1 %t88, label %bb26, label %bb27
bb26:
  %t90 = load ptr, ptr %l48, !tbaa !29
  %t91 = load i64, ptr %t90, !range !{i64 0, i64 18}
  %t93 = icmp eq i64 %t91, 10
  store i1 %t93, ptr %l49, !tbaa !21
  br label %bb27
bb27:
  %t94 = load i1, ptr %l49, !tbaa !21
  br i1 %t94, label %bb28, label %bb29
bb28:
  %t95 = load ptr, ptr %l2, !tbaa !29
  %t97 = getelementptr { i64, [5 x i64] }, ptr %t95, i32 0, i32 1
  %t98 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t97, i32 0, i32 2
  %t99 = load ptr, ptr %t98
  store ptr %t99, ptr %l6, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load ptr, ptr %l1, !tbaa !29
  %t103 = load ptr, ptr %l6, !tbaa !29
  %t105 = getelementptr %"compiler/typed:Slice", ptr %t103, i32 0, i32 0
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t110 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eheldPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v4, ptr %v3, ptr %v5, ptr %t101, ptr %t102, ptr %t106)
  store i1 %t110, ptr %l58
  br label %bb31
bb31:
  %t111 = load i1, ptr %l58, !tbaa !21
  store i1 %t111, ptr %l11, !tbaa !21
  br label %bb64
bb32:
  %t112 = load ptr, ptr %l2, !tbaa !29
  store ptr %t112, ptr %l59, !tbaa !29
  store i1 false, ptr %l60, !tbaa !21
  %t113 = load ptr, ptr %l59, !tbaa !29
  %t114 = icmp ne ptr %t113, null
  br i1 %t114, label %bb33, label %bb34
bb33:
  %t116 = load ptr, ptr %l59, !tbaa !29
  %t117 = load i64, ptr %t116, !range !{i64 0, i64 18}
  %t119 = icmp eq i64 %t117, 5
  store i1 %t119, ptr %l60, !tbaa !21
  br label %bb34
bb34:
  %t120 = load i1, ptr %l60, !tbaa !21
  br i1 %t120, label %bb35, label %bb36
bb35:
  %t121 = load ptr, ptr %l2, !tbaa !29
  %t123 = getelementptr { i64, [5 x i64] }, ptr %t121, i32 0, i32 1
  %t124 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t123, i32 0, i32 2
  %t125 = load ptr, ptr %t124
  store ptr %t125, ptr %l7, !tbaa !29
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load ptr, ptr %l1, !tbaa !29
  %t129 = load ptr, ptr %l7, !tbaa !29
  %t131 = getelementptr %"compiler/typed:Promote", ptr %t129, i32 0, i32 0
  %t132 = load ptr, ptr %t131, !tbaa !29
  %t136 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eheldMadeOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %t127, ptr %t128, ptr %t132)
  store i1 %t136, ptr %l69
  br label %bb38
bb38:
  %t137 = load i1, ptr %l69, !tbaa !21
  store i1 %t137, ptr %l11, !tbaa !21
  br label %bb64
bb39:
  %t138 = load ptr, ptr %l2, !tbaa !29
  store ptr %t138, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t139 = load ptr, ptr %l70, !tbaa !29
  %t140 = icmp ne ptr %t139, null
  br i1 %t140, label %bb40, label %bb41
bb40:
  %t142 = load ptr, ptr %l70, !tbaa !29
  %t143 = load i64, ptr %t142, !range !{i64 0, i64 18}
  %t145 = icmp eq i64 %t143, 9
  store i1 %t145, ptr %l71, !tbaa !21
  br label %bb41
bb41:
  %t146 = load i1, ptr %l71, !tbaa !21
  br i1 %t146, label %bb42, label %bb43
bb42:
  %t147 = load ptr, ptr %l2, !tbaa !29
  %t149 = getelementptr { i64, [5 x i64] }, ptr %t147, i32 0, i32 1
  %t150 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t149, i32 0, i32 2
  %t151 = load i32, ptr %t150, !range !{i32 0, i32 54}
  store i32 %t151, ptr %l8
  %t153 = load ptr, ptr %l2, !tbaa !29
  %t155 = getelementptr { i64, [5 x i64] }, ptr %t153, i32 0, i32 1
  %t156 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t155, i32 0, i32 4
  %t157 = load { i64, ptr }, ptr %t156
  store { i64, ptr } %t157, ptr %l9, !tbaa !27
  br label %bb44
bb43:
  br label %bb52
bb44:
  %t159 = load i32, ptr %l8, !range !{i32 0, i32 54}
  %t161 = trunc i64 20 to i32
  %t162 = icmp eq i32 %t159, %t161
  br i1 %t162, label %bb45, label %bb46
bb45:
  %t164 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t166 = extractvalue { i64, ptr } %t164, 0
  %t168 = icmp eq i64 %t166, 1
  store i1 %t168, ptr %l80, !tbaa !21
  br label %bb47
bb46:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb47
bb47:
  %t170 = load i1, ptr %l80, !tbaa !21
  br i1 %t170, label %bb48, label %bb49
bb48:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load ptr, ptr %l1, !tbaa !29
  %t173 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t173, ptr %l87, !tbaa !27
  %t174 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t175 = load ptr, ptr %t174, !tbaa !27
  %t176 = getelementptr ptr, ptr %t175, i64 0
  %t177 = load ptr, ptr %t176, !tbaa !39
  %t181 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eheldSrc(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %t171, ptr %t172, ptr %t177)
  store i1 %t181, ptr %l89
  br label %bb50
bb49:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb51
bb50:
  %t182 = load i1, ptr %l89, !tbaa !21
  store i1 %t182, ptr %l84, !tbaa !21
  br label %bb51
bb51:
  %t183 = load i1, ptr %l84, !tbaa !21
  store i1 %t183, ptr %l11, !tbaa !21
  br label %bb64
bb52:
  %t184 = load ptr, ptr %l2, !tbaa !29
  store ptr %t184, ptr %l90, !tbaa !29
  store i1 false, ptr %l91, !tbaa !21
  %t185 = load ptr, ptr %l90, !tbaa !29
  %t186 = icmp ne ptr %t185, null
  br i1 %t186, label %bb53, label %bb54
bb53:
  %t188 = load ptr, ptr %l90, !tbaa !29
  %t189 = load i64, ptr %t188, !range !{i64 0, i64 18}
  %t191 = icmp eq i64 %t189, 17
  store i1 %t191, ptr %l91, !tbaa !21
  br label %bb54
bb54:
  %t192 = load i1, ptr %l91, !tbaa !21
  br i1 %t192, label %bb55, label %bb56
bb55:
  %t193 = load ptr, ptr %l2, !tbaa !29
  %t195 = getelementptr { i64, [5 x i64] }, ptr %t193, i32 0, i32 1
  %t196 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t195, i32 0, i32 2
  %t197 = load ptr, ptr %t196
  store ptr %t197, ptr %l10, !tbaa !29
  br label %bb57
bb56:
  br label %bb59
bb57:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = load ptr, ptr %l1, !tbaa !29
  %t201 = load ptr, ptr %l10, !tbaa !29
  %t205 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eheldSrc(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %t199, ptr %t200, ptr %t201)
  store i1 %t205, ptr %l99
  br label %bb58
bb58:
  %t206 = load i1, ptr %l99, !tbaa !21
  store i1 %t206, ptr %l11, !tbaa !21
  br label %bb64
bb59:
  br i1 true, label %bb60, label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb63
bb62:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb64
bb63:
  call void @__olang_check_failed(ptr @olang_loc_7afd5d1ad8925abe_46fef9b6d0280482)
  unreachable
bb64:
  %t207 = load i1, ptr %l11, !tbaa !21
  store i1 %t207, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eheldViews(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca i1
  %l24 = alloca ptr
  %l27 = alloca i64
  %l30 = alloca i1
  %l40 = alloca i64
  %l44 = alloca i64
  %l47 = alloca i64
  %l66 = alloca i64
  %l70 = alloca i1
  %l74 = alloca { i64, ptr }
  %l77 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Call", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  store ptr %t6, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t7 = load ptr, ptr %l16, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l16, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 5}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l17, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l17, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l3, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { i32 }, ptr %t17, i32 0, i32 0
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l4, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t21 = load i32, ptr %l4, !tbaa !23
  store i32 %t21, ptr %l15, !tbaa !23
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i32 -1, ptr %l15, !tbaa !23
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_3e618b7a6832a44e_dc583ba968d0a99a)
  unreachable
bb11:
  %t23 = load i32, ptr %l15, !tbaa !23
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/lower:lowering", ptr %t24, i32 0, i32 0
  %t27 = load ptr, ptr %t26, !tbaa !29
  store ptr %t27, ptr %l24, !tbaa !29
  %t29 = load ptr, ptr %l24, !tbaa !29
  %t30 = call ptr @__olang_scope_or(ptr %v3, ptr %t29)
  %t31 = call ptr @__olang_scope_hold(ptr %t30)
  %t32 = ptrtoint ptr %t31 to i64
  %t34 = inttoptr i64 %t32 to ptr
  %t35 = load ptr, ptr %l24, !tbaa !29
  %t37 = call i64 @compiler_2flower_2ecompiler_2flower_3aLowerer_2eViewsOf(ptr %t34, ptr %t35, i32 %t23)
  store i64 %t37, ptr %l27
  br label %bb12
bb12:
  %t38 = load i64, ptr %l27, !tbaa !24
  store i64 %t38, ptr %l6, !tbaa !24
  %t39 = load i64, ptr %l6, !tbaa !24
  %t41 = icmp sle i64 %t39, 0
  br i1 %t41, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb15
bb14:
  %t43 = load i64, ptr %l6, !tbaa !24
  %t44 = load i64, ptr @G_2ecompiler_2ftyped_2eViewOther, !tbaa !24
  %t47 = and i64 %t43, %t44
  %t49 = icmp ne i64 %t47, 0
  store i1 %t49, ptr %l30, !tbaa !21
  br label %bb15
bb15:
  %t51 = load i1, ptr %l30, !tbaa !21
  br i1 %t51, label %bb16, label %bb17
bb16:
  store i1 false, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  store i64 0, ptr %l7, !tbaa !24
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t55 = getelementptr %"compiler/typed:Call", ptr %t53, i32 0, i32 1
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t56, 0
  %t59 = load i64, ptr @G_2ecompiler_2ftyped_2eViewBits, !tbaa !24
  %t62 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t58, i64 %t59)
  store i64 %t62, ptr %l40
  br label %bb19
bb19:
  %t63 = load i64, ptr %l40, !tbaa !24
  store i64 %t63, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t64 = load i64, ptr %l8, !tbaa !24
  %t65 = load i64, ptr %l7, !tbaa !24
  %t68 = icmp sgt i64 %t64, %t65
  br i1 %t68, label %bb20, label %bb21
bb20:
  %t70 = load i64, ptr %l9, !tbaa !24
  %t72 = icmp sgt i64 %t70, 0
  br i1 %t72, label %bb22, label %bb23
bb21:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb25
bb22:
  %t74 = load i64, ptr %l8, !tbaa !24
  %t75 = load i64, ptr %l7, !tbaa !24
  %t78 = sub i64 %t74, %t75
  %t79 = load i64, ptr %l9, !tbaa !24
  %t82 = add i64 %t78, %t79
  %t84 = sub i64 %t82, 1
  %t85 = load i64, ptr %l9, !tbaa !24
  %t88 = sdiv i64 %t84, %t85
  store i64 %t88, ptr %l47, !tbaa !24
  br label %bb24
bb23:
  store i64 0, ptr %l47, !tbaa !24
  br label %bb24
bb24:
  %t90 = load i64, ptr %l47, !tbaa !24
  store i64 %t90, ptr %l44, !tbaa !24
  br label %bb25
bb25:
  %t91 = load i64, ptr %l44, !tbaa !24
  store i64 %t91, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb26
bb26:
  %t92 = load i64, ptr %l11, !tbaa !24
  %t93 = load i64, ptr %l10, !tbaa !24
  %t96 = icmp slt i64 %t92, %t93
  %t98 = xor i1 %t96, true
  br i1 %t98, label %bb27, label %bb28
bb27:
  br label %bb38
bb28:
  br label %bb29
bb29:
  %t100 = load i64, ptr %l7, !tbaa !24
  %t101 = load i64, ptr %l11, !tbaa !24
  %t102 = load i64, ptr %l9, !tbaa !24
  %t105 = mul i64 %t101, %t102
  %t108 = add i64 %t100, %t105
  store i64 %t108, ptr %l12, !tbaa !24
  %t110 = load i64, ptr %l6, !tbaa !24
  %t111 = load i64, ptr %l12, !tbaa !24
  store i64 %t111, ptr %l66, !tbaa !24
  %t112 = load i64, ptr %l66, !tbaa !24
  %t113 = load i64, ptr %l66, !tbaa !24
  %t114 = shl i64 1, %t113
  %t117 = and i64 %t110, %t114
  %t119 = icmp ne i64 %t117, 0
  br i1 %t119, label %bb30, label %bb31
bb30:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = load ptr, ptr %l2, !tbaa !29
  %t125 = getelementptr %"compiler/typed:Call", ptr %t123, i32 0, i32 1
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  store { i64, ptr } %t126, ptr %l74, !tbaa !27
  %t127 = load i64, ptr %l12, !tbaa !24
  %t129 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr ptr, ptr %t130, i64 %t127
  %t132 = load ptr, ptr %t131, !tbaa !39
  %t136 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eheldSrc(ptr %v0, ptr %v1, ptr %v2, ptr %v4, ptr %v5, ptr %v3, ptr %t121, ptr %a1, ptr %t132)
  store i1 %t136, ptr %l77
  br label %bb32
bb31:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb33
bb32:
  %t137 = load i1, ptr %l77, !tbaa !21
  %t138 = xor i1 %t137, true
  store i1 %t138, ptr %l70, !tbaa !21
  br label %bb33
bb33:
  %t140 = load i1, ptr %l70, !tbaa !21
  br i1 %t140, label %bb34, label %bb35
bb34:
  store i1 false, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  br label %bb37
bb37:
  %t142 = load i64, ptr %l11, !tbaa !24
  %t145 = add i64 %t142, 1
  store i64 %t145, ptr %l11, !tbaa !24
  br label %bb26
bb38:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/lower:lowering", ptr %t147, i32 0, i32 78
  %t150 = load ptr, ptr %l2, !tbaa !29
  %t152 = getelementptr %"compiler/typed:Call", ptr %t150, i32 0, i32 2
  %t153 = load i32, ptr %t152, !tbaa !23
  %t155 = sext i32 %t153 to i64
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t149, i64 %t155, i1 true)
  br label %bb39
bb39:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ehoistStmt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l43 = alloca ptr
  %l44 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca i1
  %l58 = alloca ptr
  %l59 = alloca i1
  %l77 = alloca ptr
  %l78 = alloca ptr
  %l86 = alloca ptr
  %l87 = alloca i1
  %l96 = alloca ptr
  %l97 = alloca i1
  %l115 = alloca ptr
  %l116 = alloca i1
  %l127 = alloca ptr
  %l128 = alloca i1
  %l131 = alloca ptr
  %l132 = alloca i1
  %l135 = alloca ptr
  %l136 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t2 = load ptr, ptr %l13, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l13, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l14, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l14, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3, !tbaa !23
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr { i64, [3 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l4, !tbaa !29
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t24 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ehoistExpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %t22, ptr %t23, ptr %t24)
  br label %bb6
bb6:
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr %"compiler/lower:hoistWalk", ptr %t28, i32 0, i32 4
  %t31 = load i32, ptr %l3, !tbaa !23
  %t33 = sext i32 %t31 to i64
  %t34 = load ptr, ptr %l4, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_He8fa2eab054d0b98ccbd3d6295fac885(ptr %v1, ptr %v2, ptr %t30, i64 %t33, ptr %t34)
  br label %bb7
bb7:
  br label %bb89
bb8:
  %t38 = load ptr, ptr %l2, !tbaa !29
  store ptr %t38, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t39 = load ptr, ptr %l29, !tbaa !29
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %bb9, label %bb10
bb9:
  %t42 = load ptr, ptr %l29, !tbaa !29
  %t43 = load i64, ptr %t42, !range !{i64 0, i64 17}
  %t45 = icmp eq i64 %t43, 1
  store i1 %t45, ptr %l30, !tbaa !21
  br label %bb10
bb10:
  %t46 = load i1, ptr %l30, !tbaa !21
  br i1 %t46, label %bb11, label %bb12
bb11:
  %t47 = load ptr, ptr %l2, !tbaa !29
  %t49 = getelementptr { i64, [3 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t49, i32 0, i32 1
  %t51 = load ptr, ptr %t50
  store ptr %t51, ptr %l5, !tbaa !29
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t55 = getelementptr { i64, [3 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t55, i32 0, i32 2
  %t57 = load ptr, ptr %t56
  store ptr %t57, ptr %l6, !tbaa !29
  br label %bb13
bb12:
  br label %bb16
bb13:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t61 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ehoistTarget(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %t59, ptr %t60, ptr %t61)
  br label %bb14
bb14:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t67 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ehoistExpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %t65, ptr %t66, ptr %t67)
  br label %bb15
bb15:
  br label %bb89
bb16:
  %t71 = load ptr, ptr %l2, !tbaa !29
  store ptr %t71, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t72 = load ptr, ptr %l43, !tbaa !29
  %t73 = icmp ne ptr %t72, null
  br i1 %t73, label %bb17, label %bb18
bb17:
  %t75 = load ptr, ptr %l43, !tbaa !29
  %t76 = load i64, ptr %t75, !range !{i64 0, i64 17}
  %t78 = icmp eq i64 %t76, 2
  store i1 %t78, ptr %l44, !tbaa !21
  br label %bb18
bb18:
  %t79 = load i1, ptr %l44, !tbaa !21
  br i1 %t79, label %bb19, label %bb20
bb19:
  %t80 = load ptr, ptr %l2, !tbaa !29
  %t82 = getelementptr { i64, [3 x i64] }, ptr %t80, i32 0, i32 1
  %t83 = getelementptr { %"compiler/source:Span", ptr }, ptr %t82, i32 0, i32 1
  %t84 = load ptr, ptr %t83
  store ptr %t84, ptr %l7, !tbaa !29
  br label %bb25
bb20:
  %t86 = load ptr, ptr %l2, !tbaa !29
  store ptr %t86, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t87 = load ptr, ptr %l49, !tbaa !29
  %t88 = icmp ne ptr %t87, null
  br i1 %t88, label %bb21, label %bb22
bb21:
  %t90 = load ptr, ptr %l49, !tbaa !29
  %t91 = load i64, ptr %t90, !range !{i64 0, i64 17}
  %t93 = icmp eq i64 %t91, 10
  store i1 %t93, ptr %l50, !tbaa !21
  br label %bb22
bb22:
  %t94 = load i1, ptr %l50, !tbaa !21
  br i1 %t94, label %bb23, label %bb24
bb23:
  %t95 = load ptr, ptr %l2, !tbaa !29
  %t97 = getelementptr { i64, [3 x i64] }, ptr %t95, i32 0, i32 1
  %t98 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t97, i32 0, i32 1
  %t99 = load ptr, ptr %t98
  store ptr %t99, ptr %l7, !tbaa !29
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load ptr, ptr %l1, !tbaa !29
  %t103 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ehoistExpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %t101, ptr %t102, ptr %t103)
  br label %bb26
bb26:
  br label %bb89
bb27:
  %t107 = load ptr, ptr %l2, !tbaa !29
  store ptr %t107, ptr %l58, !tbaa !29
  store i1 false, ptr %l59, !tbaa !21
  %t108 = load ptr, ptr %l58, !tbaa !29
  %t109 = icmp ne ptr %t108, null
  br i1 %t109, label %bb28, label %bb29
bb28:
  %t111 = load ptr, ptr %l58, !tbaa !29
  %t112 = load i64, ptr %t111, !range !{i64 0, i64 17}
  %t114 = icmp eq i64 %t112, 3
  store i1 %t114, ptr %l59, !tbaa !21
  br label %bb29
bb29:
  %t115 = load i1, ptr %l59, !tbaa !21
  br i1 %t115, label %bb30, label %bb31
bb30:
  %t116 = load ptr, ptr %l2, !tbaa !29
  %t118 = getelementptr { i64, [3 x i64] }, ptr %t116, i32 0, i32 1
  %t119 = getelementptr { %"compiler/source:Span", ptr }, ptr %t118, i32 0, i32 1
  %t120 = load ptr, ptr %t119
  store ptr %t120, ptr %l8, !tbaa !29
  br label %bb32
bb31:
  br label %bb42
bb32:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load ptr, ptr %l1, !tbaa !29
  %t124 = load ptr, ptr %l8, !tbaa !29
  %t126 = getelementptr %"compiler/typed:If", ptr %t124, i32 0, i32 0
  %t127 = load ptr, ptr %t126, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ehoistExpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %t122, ptr %t123, ptr %t127)
  br label %bb33
bb33:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load ptr, ptr %l1, !tbaa !29
  %t133 = load ptr, ptr %l8, !tbaa !29
  %t135 = getelementptr %"compiler/typed:If", ptr %t133, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !29
  %t138 = getelementptr %"compiler/typed:Block", ptr %t136, i32 0, i32 1
  %t139 = load { i64, ptr }, ptr %t138, !tbaa !27
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ehoistStmts(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %t131, ptr %t132, { i64, ptr } %t139)
  br label %bb34
bb34:
  %t143 = load ptr, ptr %l8, !tbaa !29
  %t145 = getelementptr %"compiler/typed:If", ptr %t143, i32 0, i32 2
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t148 = icmp eq ptr %t146, null
  %t150 = xor i1 %t148, true
  br i1 %t150, label %bb35, label %bb36
bb35:
  %t152 = load ptr, ptr %l0, !tbaa !29
  store ptr %t152, ptr %l77, !tbaa !29
  %t153 = load ptr, ptr %l1, !tbaa !29
  store ptr %t153, ptr %l78, !tbaa !29
  %t154 = load ptr, ptr %l8, !tbaa !29
  %t156 = getelementptr %"compiler/typed:If", ptr %t154, i32 0, i32 2
  %t157 = load ptr, ptr %t156, !tbaa !29
  %t159 = icmp eq ptr %t157, null
  br i1 %t159, label %bb37, label %bb38
bb36:
  br label %bb41
bb37:
  call void @__olang_check_failed(ptr @olang_loc_e71bb0512ed49da1_8a89b347fae8a8c5)
  unreachable
bb38:
  br label %bb39
bb39:
  %t161 = load ptr, ptr %l8, !tbaa !29
  %t163 = getelementptr %"compiler/typed:If", ptr %t161, i32 0, i32 2
  %t164 = load ptr, ptr %t163, !tbaa !29
  %t167 = getelementptr %"compiler/typed:Block", ptr %t164, i32 0, i32 1
  %t168 = load { i64, ptr }, ptr %t167, !tbaa !27
  %t169 = load ptr, ptr %l77, !tbaa !29
  %t170 = load ptr, ptr %l78, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ehoistStmts(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %t169, ptr %t170, { i64, ptr } %t168)
  br label %bb40
bb40:
  br label %bb41
bb41:
  br label %bb89
bb42:
  %t172 = load ptr, ptr %l2, !tbaa !29
  store ptr %t172, ptr %l86, !tbaa !29
  store i1 false, ptr %l87, !tbaa !21
  %t173 = load ptr, ptr %l86, !tbaa !29
  %t174 = icmp ne ptr %t173, null
  br i1 %t174, label %bb43, label %bb44
bb43:
  %t176 = load ptr, ptr %l86, !tbaa !29
  %t177 = load i64, ptr %t176, !range !{i64 0, i64 17}
  %t179 = icmp eq i64 %t177, 11
  store i1 %t179, ptr %l87, !tbaa !21
  br label %bb44
bb44:
  %t180 = load i1, ptr %l87, !tbaa !21
  br i1 %t180, label %bb45, label %bb46
bb45:
  %t181 = load ptr, ptr %l2, !tbaa !29
  %t183 = getelementptr { i64, [3 x i64] }, ptr %t181, i32 0, i32 1
  %t184 = getelementptr { %"compiler/source:Span", ptr }, ptr %t183, i32 0, i32 1
  %t185 = load ptr, ptr %t184
  store ptr %t185, ptr %l9, !tbaa !29
  br label %bb47
bb46:
  br label %bb49
bb47:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load ptr, ptr %l1, !tbaa !29
  %t189 = load ptr, ptr %l9, !tbaa !29
  %t191 = getelementptr %"compiler/typed:Block", ptr %t189, i32 0, i32 1
  %t192 = load { i64, ptr }, ptr %t191, !tbaa !27
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ehoistStmts(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %t187, ptr %t188, { i64, ptr } %t192)
  br label %bb48
bb48:
  br label %bb89
bb49:
  %t196 = load ptr, ptr %l2, !tbaa !29
  store ptr %t196, ptr %l96, !tbaa !29
  store i1 false, ptr %l97, !tbaa !21
  %t197 = load ptr, ptr %l96, !tbaa !29
  %t198 = icmp ne ptr %t197, null
  br i1 %t198, label %bb50, label %bb51
bb50:
  %t200 = load ptr, ptr %l96, !tbaa !29
  %t201 = load i64, ptr %t200, !range !{i64 0, i64 17}
  %t203 = icmp eq i64 %t201, 4
  store i1 %t203, ptr %l97, !tbaa !21
  br label %bb51
bb51:
  %t204 = load i1, ptr %l97, !tbaa !21
  br i1 %t204, label %bb52, label %bb53
bb52:
  %t205 = load ptr, ptr %l2, !tbaa !29
  %t207 = getelementptr { i64, [3 x i64] }, ptr %t205, i32 0, i32 1
  %t208 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t207, i32 0, i32 1
  %t209 = load ptr, ptr %t208
  store ptr %t209, ptr %l10, !tbaa !29
  %t211 = load ptr, ptr %l2, !tbaa !29
  %t213 = getelementptr { i64, [3 x i64] }, ptr %t211, i32 0, i32 1
  %t214 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t213, i32 0, i32 2
  %t215 = load ptr, ptr %t214
  store ptr %t215, ptr %l11, !tbaa !29
  br label %bb54
bb53:
  br label %bb60
bb54:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t219 = load ptr, ptr %l10, !tbaa !29
  %t221 = getelementptr %"compiler/typed:Block", ptr %t219, i32 0, i32 1
  %t222 = load { i64, ptr }, ptr %t221, !tbaa !27
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ehoistStmts(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %t217, ptr %t218, { i64, ptr } %t222)
  br label %bb55
bb55:
  %t226 = load ptr, ptr %l11, !tbaa !29
  %t228 = icmp eq ptr %t226, null
  %t230 = xor i1 %t228, true
  br i1 %t230, label %bb56, label %bb57
bb56:
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = load ptr, ptr %l1, !tbaa !29
  %t234 = load ptr, ptr %l11, !tbaa !29
  %t236 = getelementptr %"compiler/typed:Block", ptr %t234, i32 0, i32 1
  %t237 = load { i64, ptr }, ptr %t236, !tbaa !27
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ehoistStmts(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %t232, ptr %t233, { i64, ptr } %t237)
  br label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb59
bb59:
  br label %bb89
bb60:
  %t241 = load ptr, ptr %l2, !tbaa !29
  store ptr %t241, ptr %l115, !tbaa !29
  store i1 false, ptr %l116, !tbaa !21
  %t242 = load ptr, ptr %l115, !tbaa !29
  %t243 = icmp ne ptr %t242, null
  br i1 %t243, label %bb61, label %bb62
bb61:
  %t245 = load ptr, ptr %l115, !tbaa !29
  %t246 = load i64, ptr %t245, !range !{i64 0, i64 17}
  %t248 = icmp eq i64 %t246, 6
  store i1 %t248, ptr %l116, !tbaa !21
  br label %bb62
bb62:
  %t249 = load i1, ptr %l116, !tbaa !21
  br i1 %t249, label %bb63, label %bb64
bb63:
  %t250 = load ptr, ptr %l2, !tbaa !29
  %t252 = getelementptr { i64, [3 x i64] }, ptr %t250, i32 0, i32 1
  %t253 = getelementptr { %"compiler/source:Span", ptr }, ptr %t252, i32 0, i32 1
  %t254 = load ptr, ptr %t253
  store ptr %t254, ptr %l12, !tbaa !29
  br label %bb65
bb64:
  br label %bb70
bb65:
  %t256 = load ptr, ptr %l12, !tbaa !29
  %t258 = icmp eq ptr %t256, null
  %t260 = xor i1 %t258, true
  br i1 %t260, label %bb66, label %bb67
bb66:
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t263 = load ptr, ptr %l1, !tbaa !29
  %t264 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ehoistExpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %t262, ptr %t263, ptr %t264)
  br label %bb68
bb67:
  br label %bb69
bb68:
  br label %bb69
bb69:
  br label %bb89
bb70:
  %t268 = load ptr, ptr %l2, !tbaa !29
  store ptr %t268, ptr %l127, !tbaa !29
  store i1 false, ptr %l128, !tbaa !21
  %t269 = load ptr, ptr %l127, !tbaa !29
  %t270 = icmp ne ptr %t269, null
  br i1 %t270, label %bb71, label %bb72
bb71:
  %t272 = load ptr, ptr %l127, !tbaa !29
  %t273 = load i64, ptr %t272, !range !{i64 0, i64 17}
  %t275 = icmp eq i64 %t273, 5
  store i1 %t275, ptr %l128, !tbaa !21
  br label %bb72
bb72:
  %t276 = load i1, ptr %l128, !tbaa !21
  br i1 %t276, label %bb73, label %bb74
bb73:
  br label %bb83
bb74:
  %t277 = load ptr, ptr %l2, !tbaa !29
  store ptr %t277, ptr %l131, !tbaa !29
  store i1 false, ptr %l132, !tbaa !21
  %t278 = load ptr, ptr %l131, !tbaa !29
  %t279 = icmp ne ptr %t278, null
  br i1 %t279, label %bb75, label %bb76
bb75:
  %t281 = load ptr, ptr %l131, !tbaa !29
  %t282 = load i64, ptr %t281, !range !{i64 0, i64 17}
  %t284 = icmp eq i64 %t282, 7
  store i1 %t284, ptr %l132, !tbaa !21
  br label %bb76
bb76:
  %t285 = load i1, ptr %l132, !tbaa !21
  br i1 %t285, label %bb77, label %bb78
bb77:
  br label %bb83
bb78:
  %t286 = load ptr, ptr %l2, !tbaa !29
  store ptr %t286, ptr %l135, !tbaa !29
  store i1 false, ptr %l136, !tbaa !21
  %t287 = load ptr, ptr %l135, !tbaa !29
  %t288 = icmp ne ptr %t287, null
  br i1 %t288, label %bb79, label %bb80
bb79:
  %t290 = load ptr, ptr %l135, !tbaa !29
  %t291 = load i64, ptr %t290, !range !{i64 0, i64 17}
  %t293 = icmp eq i64 %t291, 9
  store i1 %t293, ptr %l136, !tbaa !21
  br label %bb80
bb80:
  %t294 = load i1, ptr %l136, !tbaa !21
  br i1 %t294, label %bb81, label %bb82
bb81:
  br label %bb83
bb82:
  br label %bb84
bb83:
  br label %bb89
bb84:
  br i1 true, label %bb85, label %bb86
bb85:
  br label %bb87
bb86:
  br label %bb88
bb87:
  %t295 = load ptr, ptr %l1, !tbaa !29
  %t297 = getelementptr %"compiler/lower:hoistWalk", ptr %t295, i32 0, i32 2
  store i1 false, ptr %t297, !tbaa !21
  br label %bb89
bb88:
  call void @__olang_check_failed(ptr @olang_loc_4e221d20bbb57f79_e7403e65d23ba1ad)
  unreachable
bb89:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2flower_2ecompiler_2flower_3alowering_2eholderOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i64
  %l7 = alloca ptr
  %l11 = alloca ptr
  %l13 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eisDrop(ptr %v0, ptr %v1, ptr %t1, i64 %t2)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/lower:lowering", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l7, !tbaa !29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/lower:lowering", ptr %t11, i32 0, i32 18
  %t14 = load i64, ptr %l1, !tbaa !24
  %t17 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlock_26_3e_2eAt_3ccompiler_2ftyped_3aBlock_26_3e(ptr %v0, ptr %v0, ptr %t13, i64 %t14)
  store ptr %t17, ptr %l11
  br label %bb4
bb3:
  store i64 -1, ptr %l5, !tbaa !24
  br label %bb6
bb4:
  %t18 = load ptr, ptr %l7, !tbaa !29
  %t19 = call ptr @__olang_scope_or(ptr %v1, ptr %t18)
  %t20 = call ptr @__olang_scope_hold(ptr %t19)
  %t21 = ptrtoint ptr %t20 to i64
  %t23 = inttoptr i64 %t21 to ptr
  %t24 = load ptr, ptr %l7, !tbaa !29
  %t25 = load ptr, ptr %l11, !tbaa !29
  %t26 = call i64 @compiler_2ftyped_2eDropHolder(ptr %t23, ptr %v0, ptr %t24, ptr %t25)
  store i64 %t26, ptr %l13
  br label %bb5
bb5:
  %t27 = load i64, ptr %l13, !tbaa !24
  store i64 %t27, ptr %l5, !tbaa !24
  br label %bb6
bb6:
  %t28 = load i64, ptr %l5, !tbaa !24
  store i64 %t28, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eholders(ptr %v0, ptr %a0, %"compiler/mir:Lvalue" %a1, i64 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca %"compiler/source:Span"
  %l10 = alloca { i64, [4 x i64] }
  %l13 = alloca { i64, [4 x i64] }
  %l14 = alloca { i64, [21 x i64] }
  %s0 = alloca %olang.scope
  %t10 = alloca { i64, [4 x i64] }, align 8
  %t21 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 3
  store ptr %t3, ptr %l5, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/lower:lowering", ptr %t4, i32 0, i32 11
  %t7 = load i32, ptr %t6, !tbaa !23
  store i32 %t7, ptr %l7, !tbaa !23
  store %"compiler/source:Span" %a3, ptr %l8
  store { i64, [4 x i64] } zeroinitializer, ptr %t10
  %t11 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 0
  store i64 1, ptr %t11
  %t13 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %a1, 0
  %t14 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t13, ptr %t14
  %t15 = load { i64, [4 x i64] }, ptr %t10
  store { i64, [4 x i64] } %t15, ptr %l10
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t20 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t16, i64 %a2)
  store { i64, [4 x i64] } %t20, ptr %l13
  br label %bb1
bb1:
  store { i64, [21 x i64] } zeroinitializer, ptr %t21
  %t22 = getelementptr { i64, [21 x i64] }, ptr %t21, i32 0, i32 0
  store i64 17, ptr %t22
  %t23 = load %"compiler/source:Span", ptr %l8
  %t24 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] }, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t23, 0
  %t25 = load { i64, [4 x i64] }, ptr %l10
  %t26 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] }, { i64, [4 x i64] } } %t24, { i64, [4 x i64] } %t25, 1
  %t27 = load { i64, [4 x i64] }, ptr %l13
  %t28 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] }, { i64, [4 x i64] } } %t26, { i64, [4 x i64] } %t27, 2
  %t29 = getelementptr { i64, [21 x i64] }, ptr %t21, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] }, { i64, [4 x i64] } } %t28, ptr %t29
  %t30 = load { i64, [21 x i64] }, ptr %t21
  store { i64, [21 x i64] } %t30, ptr %l14
  %t31 = load ptr, ptr %l5, !tbaa !29
  %t32 = load i32, ptr %l7, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v0, ptr %s0, ptr %t31, i32 %t32, ptr %l14)
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2flower_2ecompiler_2flower_3alowering_2ei64(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eimmutableGlobal(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l6 = alloca ptr
  %l13 = alloca ptr
  %l17 = alloca i1
  %l19 = alloca ptr
  %l21 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/lower:Lowerer", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l6, !tbaa !29
  %t10 = load ptr, ptr %l6, !tbaa !29
  %t11 = call ptr @__olang_scope_or(ptr %v1, ptr %t10)
  %t12 = call ptr @__olang_scope_hold(ptr %t11)
  %t13 = ptrtoint ptr %t12 to i64
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/lower:lowering", ptr %t14, i32 0, i32 0
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = call ptr @__olang_scope_or(ptr %v1, ptr %t17)
  %t20 = call ptr @__olang_scope_hold(ptr %t19)
  %t21 = ptrtoint ptr %t20 to i64
  %t23 = inttoptr i64 %t13 to ptr
  %t25 = inttoptr i64 %t21 to ptr
  %t26 = load ptr, ptr %l6, !tbaa !29
  %t29 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %t23, ptr %t25, ptr %t26, i64 %a1, i32 %a2)
  store ptr %t29, ptr %l13
  br label %bb1
bb1:
  %t30 = load ptr, ptr %l13, !tbaa !29
  store ptr %t30, ptr %l3, !tbaa !29
  %t31 = load ptr, ptr %l3, !tbaa !29
  %t33 = icmp eq ptr %t31, null
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb2, label %bb3
bb2:
  %t37 = load ptr, ptr %l3, !tbaa !29
  %t39 = getelementptr %"compiler/ast:VarDecl", ptr %t37, i32 0, i32 2
  %t40 = load ptr, ptr %t39, !tbaa !29
  store ptr %t40, ptr %l19, !tbaa !29
  %t41 = load ptr, ptr %l19, !tbaa !29
  %t42 = call ptr @__olang_scope_or(ptr %v1, ptr %t41)
  %t43 = call ptr @__olang_scope_hold(ptr %t42)
  %t44 = ptrtoint ptr %t43 to i64
  %t46 = inttoptr i64 %t44 to ptr
  %t47 = load ptr, ptr %l19, !tbaa !29
  %t48 = call i1 @compiler_2fgeneric_2eWrittenMut(ptr %t46, ptr %t47)
  store i1 %t48, ptr %l21
  br label %bb4
bb3:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb5
bb4:
  %t49 = load i1, ptr %l21, !tbaa !21
  %t50 = xor i1 %t49, true
  store i1 %t50, ptr %l17, !tbaa !21
  br label %bb5
bb5:
  %t52 = load i1, ptr %l17, !tbaa !21
  store i1 %t52, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einnermost(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l9 = alloca i64
  %l17 = alloca %"compiler/lower:level"
  %l21 = alloca i1
  %l24 = alloca i1
  %l27 = alloca i1
  %l33 = alloca %"compiler/lower:level"
  %rv = alloca { i64, [1 x i64] }
  %t8 = alloca { i64, [1 x i64] }, align 8
  %t68 = alloca { i64, [1 x i64] }, align 8
  %t80 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 29
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store { i64, [1 x i64] } zeroinitializer, ptr %t8
  %t9 = getelementptr { i64, [1 x i64] }, ptr %t8, i32 0, i32 0
  store i64 2, ptr %t9
  %t10 = load { i64, [1 x i64] }, ptr %t8
  store { i64, [1 x i64] } %t10, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lower:lowering", ptr %t12, i32 0, i32 14
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l9
  br label %bb4
bb4:
  %t17 = load i64, ptr %l9, !tbaa !24
  %t18 = sub i64 %t17, 1
  store i64 %t18, ptr %l1, !tbaa !24
  br label %bb5
bb5:
  %t20 = load i64, ptr %l1, !tbaa !24
  %t22 = icmp sge i64 %t20, 0
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb6, label %bb7
bb6:
  br label %bb24
bb7:
  br label %bb8
bb8:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/lower:lowering", ptr %t26, i32 0, i32 14
  %t29 = load i64, ptr %l1, !tbaa !24
  %t32 = call %"compiler/lower:level" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eAt_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t28, i64 %t29)
  store %"compiler/lower:level" %t32, ptr %l17
  br label %bb9
bb9:
  %t33 = getelementptr %"compiler/lower:level", ptr %l17, i32 0, i32 2
  %t34 = load i32, ptr %t33, !range !{i32 0, i32 7}
  store i32 %t34, ptr %l2
  %t36 = load i32, ptr %l2, !range !{i32 0, i32 7}
  %t38 = trunc i64 1 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb12
bb11:
  %t41 = load i32, ptr %l2, !range !{i32 0, i32 7}
  %t43 = trunc i64 2 to i32
  %t44 = icmp eq i32 %t41, %t43
  store i1 %t44, ptr %l21, !tbaa !21
  br label %bb12
bb12:
  %t46 = load i1, ptr %l21, !tbaa !21
  br i1 %t46, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb15
bb14:
  %t47 = load i32, ptr %l2, !range !{i32 0, i32 7}
  %t49 = trunc i64 3 to i32
  %t50 = icmp eq i32 %t47, %t49
  store i1 %t50, ptr %l24, !tbaa !21
  br label %bb15
bb15:
  %t52 = load i1, ptr %l24, !tbaa !21
  br i1 %t52, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb18
bb17:
  %t53 = load i32, ptr %l2, !range !{i32 0, i32 7}
  %t55 = trunc i64 0 to i32
  %t56 = icmp eq i32 %t53, %t55
  store i1 %t56, ptr %l27, !tbaa !21
  br label %bb18
bb18:
  %t58 = load i1, ptr %l27, !tbaa !21
  br i1 %t58, label %bb19, label %bb20
bb19:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/lower:lowering", ptr %t59, i32 0, i32 14
  %t62 = load i64, ptr %l1, !tbaa !24
  %t65 = call %"compiler/lower:level" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eAt_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t61, i64 %t62)
  store %"compiler/lower:level" %t65, ptr %l33
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t66 = getelementptr %"compiler/lower:level", ptr %l33, i32 0, i32 0
  %t67 = load i32, ptr %t66, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t68
  %t69 = getelementptr { i64, [1 x i64] }, ptr %t68, i32 0, i32 0
  store i64 0, ptr %t69
  %t71 = insertvalue { i32 } undef, i32 %t67, 0
  %t72 = getelementptr { i64, [1 x i64] }, ptr %t68, i32 0, i32 1
  store { i32 } %t71, ptr %t72
  %t73 = load { i64, [1 x i64] }, ptr %t68
  store { i64, [1 x i64] } %t73, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t75 = load i64, ptr %l1, !tbaa !24
  %t78 = sub i64 %t75, 1
  store i64 %t78, ptr %l1, !tbaa !24
  br label %bb5
bb24:
  store { i64, [1 x i64] } zeroinitializer, ptr %t80
  %t81 = getelementptr { i64, [1 x i64] }, ptr %t80, i32 0, i32 0
  store i64 2, ptr %t81
  %t82 = load { i64, [1 x i64] }, ptr %t80
  store { i64, [1 x i64] } %t82, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eisDrop(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l8 = alloca ptr
  %l13 = alloca %"compiler/typed:BlockInfo"
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Body", ptr %t4, i32 0, i32 8
  store ptr %t6, ptr %l4, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/lower:lowering", ptr %t7, i32 0, i32 18
  %t13 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlock_26_3e_2eAt_3ccompiler_2ftyped_3aBlock_26_3e(ptr %v0, ptr %s0, ptr %t9, i64 %a1)
  store ptr %t13, ptr %l8
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t16 = getelementptr %"compiler/typed:Block", ptr %t14, i32 0, i32 0
  %t17 = load i32, ptr %t16, !tbaa !23
  %t19 = sext i32 %t17 to i64
  %t20 = load ptr, ptr %l4, !tbaa !29
  %t21 = call ptr @__olang_scope_or(ptr %v1, ptr %t20)
  %t22 = call ptr @__olang_scope_hold(ptr %t21)
  %t23 = ptrtoint ptr %t22 to i64
  %t25 = inttoptr i64 %t23 to ptr
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t28 = call %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %t25, ptr %t26, i64 %t19)
  store %"compiler/typed:BlockInfo" %t28, ptr %l13
  br label %bb2
bb2:
  %t29 = getelementptr %"compiler/typed:BlockInfo", ptr %l13, i32 0, i32 1
  %t30 = load i32, ptr %t29, !range !{i32 0, i32 10}
  %t32 = trunc i64 8 to i32
  %t33 = icmp eq i32 %t30, %t32
  call void @__olang_scope_close(ptr %s0)
  store i1 %t33, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eisI64(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l5 = alloca ptr
  %l8 = alloca i32
  %l10 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/lower:lowering", ptr %t5, i32 0, i32 2
  %t8 = load ptr, ptr %t7, !tbaa !29
  store ptr %t8, ptr %l5, !tbaa !29
  %t10 = load ptr, ptr %l5, !tbaa !29
  %t11 = call ptr @__olang_scope_or(ptr %v1, ptr %t10)
  %t12 = call ptr @__olang_scope_hold(ptr %t11)
  %t13 = ptrtoint ptr %t12 to i64
  %t15 = inttoptr i64 %t13 to ptr
  %t16 = load ptr, ptr %l5, !tbaa !29
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t15, ptr %t16, i32 %a1)
  store i32 %t18, ptr %l8
  br label %bb1
bb1:
  %t19 = load ptr, ptr %l3, !tbaa !29
  %t20 = call ptr @__olang_scope_or(ptr %v1, ptr %t19)
  %t21 = call ptr @__olang_scope_hold(ptr %t20)
  %t22 = ptrtoint ptr %t21 to i64
  %t24 = inttoptr i64 %t22 to ptr
  %t25 = load ptr, ptr %l3, !tbaa !29
  %t26 = load i32, ptr %l8, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t24, ptr %t25, i32 %t26)
  store i32 %t27, ptr %l10
  br label %bb2
bb2:
  %t28 = load i32, ptr %l10, !range !{i32 0, i32 33}
  %t30 = trunc i64 6 to i32
  %t31 = icmp eq i32 %t28, %t30
  store i1 %t31, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eisMain(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l17 = alloca i64
  %l19 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/lower:Lowerer", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l1, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/lower:lowering", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t12, i32 0, i32 1
  %t15 = load { i64, [2 x i64] }, ptr %t14
  store { i64, [2 x i64] } %t15, ptr %l2
  %t17 = load { i64, [2 x i64] }, ptr %l2
  %t19 = extractvalue { i64, [2 x i64] } %t17, 0
  %t20 = icmp eq i64 %t19, 0
  br i1 %t20, label %bb1, label %bb2
bb1:
  %t22 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t23 = getelementptr { i64 }, ptr %t22, i32 0, i32 0
  %t24 = load i64, ptr %t23
  store i64 %t24, ptr %l3, !tbaa !24
  br label %bb3
bb2:
  br label %bb6
bb3:
  %t26 = load ptr, ptr %l1, !tbaa !29
  store ptr %t26, ptr %l13, !tbaa !29
  %t27 = load ptr, ptr %l1, !tbaa !29
  store ptr %t27, ptr %l14, !tbaa !29
  %t28 = load i64, ptr %l3, !tbaa !24
  %t29 = load ptr, ptr %l14, !tbaa !29
  %t30 = call ptr @__olang_scope_or(ptr %v1, ptr %t29)
  %t31 = call ptr @__olang_scope_hold(ptr %t30)
  %t32 = ptrtoint ptr %t31 to i64
  %t34 = inttoptr i64 %t32 to ptr
  %t35 = load ptr, ptr %l14, !tbaa !29
  %t37 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %t34, ptr %t35, i64 %t28)
  store i64 %t37, ptr %l17
  br label %bb4
bb4:
  %t38 = load ptr, ptr %l13, !tbaa !29
  %t39 = call ptr @__olang_scope_or(ptr %v1, ptr %t38)
  %t40 = call ptr @__olang_scope_hold(ptr %t39)
  %t41 = ptrtoint ptr %t40 to i64
  %t43 = inttoptr i64 %t41 to ptr
  %t44 = load ptr, ptr %l13, !tbaa !29
  %t45 = load i64, ptr %l17, !tbaa !24
  %t46 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsEntry(ptr %t43, ptr %t44, i64 %t45)
  store i1 %t46, ptr %l19
  br label %bb5
bb5:
  %t47 = load i1, ptr %l19, !tbaa !21
  store i1 %t47, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_563c1466c1100e02_3d75491115d3396)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ejoinAt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 12
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %v1, ptr %v2, ptr %t8, i32 %t9)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t12, i32 %t13)
  br label %bb5
bb5:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eleave(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 14
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  %t7 = sub i64 %t6, 1
  store i64 %t7, ptr %l2, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l2, !tbaa !24
  %t13 = icmp sge i64 %t9, %a1
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eexitLevel(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t17, i64 %t18)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t21 = load i64, ptr %l2, !tbaa !24
  %t24 = sub i64 %t21, 1
  store i64 %t24, ptr %l2, !tbaa !24
  br label %bb2
bb8:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eleaveOpen(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 12
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/lower:lowering", ptr %t7, i32 0, i32 11
  %t10 = load i32, ptr %t9, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ePush_3ccompiler_2fmir_3aBlockId_3e(ptr %v1, ptr %a1, i32 %t10)
  br label %bb4
bb4:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/lower:lowering", ptr %t13, i32 0, i32 12
  store i1 true, ptr %t15, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2elendsKeep(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l11 = alloca i64
  %l15 = alloca i64
  %l18 = alloca i64
  %l39 = alloca i64
  %l42 = alloca i1
  %l44 = alloca ptr
  %l48 = alloca i64
  %l52 = alloca i64
  %l54 = alloca i1
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:LocalUses", ptr %t1, i32 0, i32 24
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t3)
  store i64 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i64, ptr %l11, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l18, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l18, !tbaa !24
  store i64 %t33, ptr %l15, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l15, !tbaa !24
  store i64 %t34, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l7, !tbaa !24
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb23
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l3, !tbaa !24
  %t44 = load i64, ptr %l7, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l8, !tbaa !24
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t55 = getelementptr %"compiler/typed:LocalUses", ptr %t53, i32 0, i32 24
  %t56 = load i64, ptr %l8, !tbaa !24
  %t59 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t55, i64 %t56)
  store i64 %t59, ptr %l39
  br label %bb12
bb12:
  %t61 = load i64, ptr %l39, !tbaa !24
  %t63 = icmp eq i64 %t61, %a2
  br i1 %t63, label %bb13, label %bb14
bb13:
  %t67 = getelementptr %"compiler/lower:lowering", ptr %a0, i32 0, i32 0
  %t68 = load ptr, ptr %t67, !tbaa !29
  store ptr %t68, ptr %l44, !tbaa !29
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t71 = getelementptr %"compiler/typed:LocalUses", ptr %t69, i32 0, i32 25
  %t72 = load i64, ptr %l8, !tbaa !24
  %t75 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t71, i64 %t72)
  store i64 %t75, ptr %l48
  br label %bb15
bb14:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb18
bb15:
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr %"compiler/typed:LocalUses", ptr %t76, i32 0, i32 26
  %t79 = load i64, ptr %l8, !tbaa !24
  %t82 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t78, i64 %t79)
  store i64 %t82, ptr %l52
  br label %bb16
bb16:
  %t83 = load ptr, ptr %l44, !tbaa !29
  %t84 = call ptr @__olang_scope_or(ptr %v2, ptr %t83)
  %t85 = call ptr @__olang_scope_hold(ptr %t84)
  %t86 = ptrtoint ptr %t85 to i64
  %t88 = inttoptr i64 %t86 to ptr
  %t89 = load ptr, ptr %l44, !tbaa !29
  %t90 = load i64, ptr %l48, !tbaa !24
  %t91 = load i64, ptr %l52, !tbaa !24
  %t92 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2epreserves(ptr %t88, ptr %t89, i64 %t90, i64 %t91)
  store i1 %t92, ptr %l54
  br label %bb17
bb17:
  %t93 = load i1, ptr %l54, !tbaa !21
  %t94 = xor i1 %t93, true
  store i1 %t94, ptr %l42, !tbaa !21
  br label %bb18
bb18:
  %t96 = load i1, ptr %l42, !tbaa !21
  br i1 %t96, label %bb19, label %bb20
bb19:
  store i1 false, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t98 = load i64, ptr %l7, !tbaa !24
  %t101 = add i64 %t98, 1
  store i64 %t101, ptr %l7, !tbaa !24
  br label %bb8
bb23:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2flower_2ecompiler_2flower_3alowering_2elevelOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l38 = alloca %"compiler/lower:level"
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 14
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i64, ptr %l10, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l3, !tbaa !24
  %t18 = load i64, ptr %l2, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l17, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l17, !tbaa !24
  store i64 %t33, ptr %l14, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l14, !tbaa !24
  store i64 %t34, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l6, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb17
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l2, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l7, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/lower:lowering", ptr %t53, i32 0, i32 14
  %t56 = load i64, ptr %l7, !tbaa !24
  %t59 = call %"compiler/lower:level" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eAt_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t55, i64 %t56)
  store %"compiler/lower:level" %t59, ptr %l38
  br label %bb12
bb12:
  %t60 = getelementptr %"compiler/lower:level", ptr %l38, i32 0, i32 0
  %t61 = load i32, ptr %t60, !tbaa !23
  %t65 = icmp eq i32 %t61, %a1
  br i1 %t65, label %bb13, label %bb14
bb13:
  %t67 = load i64, ptr %l7, !tbaa !24
  store i64 %t67, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t69 = load i64, ptr %l6, !tbaa !24
  %t72 = add i64 %t69, 1
  store i64 %t72, ptr %l6, !tbaa !24
  br label %bb8
bb17:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [4 x i64] }
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i64
  %l5 = alloca i32
  %l7 = alloca i64
  %l16 = alloca i32
  %l17 = alloca ptr
  %l18 = alloca %"compiler/source:Span"
  %l20 = alloca %"compiler/mir:Lvalue"
  %s0 = alloca %olang.scope
  %rv = alloca i32
  %t28 = alloca { i64, [15 x i64] }, align 8
  %t34 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, [4 x i64] } %a1, ptr %l1
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, [4 x i64] }, ptr %l1
  %t3 = call i64 @compiler_2flower_2ewholeLocal({ i64, [4 x i64] } %t1)
  store i64 %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load i64, ptr %l7, !tbaa !24
  store i64 %t4, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l4, !tbaa !24
  %t7 = icmp sge i64 %t5, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load i64, ptr %l4, !tbaa !24
  %t11 = trunc i64 %t9 to i32
  call void @__olang_scope_close(ptr %s0)
  store i32 %t11, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = load %"compiler/source:Span", ptr %l3
  %t20 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t14, i32 %a2, %"compiler/source:Span" %t16)
  store i32 %t20, ptr %l16
  br label %bb5
bb5:
  %t21 = load i32, ptr %l16, !tbaa !23
  store i32 %t21, ptr %l5, !tbaa !23
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l17, !tbaa !29
  %t23 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t23, ptr %l18
  %t24 = load i32, ptr %l5, !tbaa !23
  %t26 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t24)
  store %"compiler/mir:Lvalue" %t26, ptr %l20
  br label %bb6
bb6:
  %t27 = load { i64, [4 x i64] }, ptr %l1
  store { i64, [15 x i64] } zeroinitializer, ptr %t28
  %t29 = getelementptr { i64, [15 x i64] }, ptr %t28, i32 0, i32 0
  store i64 0, ptr %t29
  %t31 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t27, 0
  %t32 = getelementptr { i64, [15 x i64] }, ptr %t28, i32 0, i32 1
  store { { i64, [4 x i64] } } %t31, ptr %t32
  %t33 = load { i64, [15 x i64] }, ptr %t28
  store { i64, [21 x i64] } zeroinitializer, ptr %t34
  %t35 = getelementptr { i64, [21 x i64] }, ptr %t34, i32 0, i32 0
  store i64 0, ptr %t35
  %t36 = load %"compiler/source:Span", ptr %l18
  %t37 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t36, 0
  %t38 = load %"compiler/mir:Lvalue", ptr %l20
  %t39 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t37, %"compiler/mir:Lvalue" %t38, 1
  %t41 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t39, { i64, [15 x i64] } %t33, 2
  %t42 = getelementptr { i64, [21 x i64] }, ptr %t34, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t41, ptr %t42
  %t43 = load { i64, [21 x i64] }, ptr %t34
  %t45 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t43, ptr %t45
  %t46 = load ptr, ptr %l17, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %v1, ptr %v2, ptr %t46, ptr %t45)
  br label %bb7
bb7:
  %t48 = load i32, ptr %l5, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t48, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ementions(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l11 = alloca ptr
  %l15 = alloca %"compiler/mir:BasicBlock"
  %l21 = alloca ptr
  %l25 = alloca %"compiler/mir:BasicBlock"
  %l28 = alloca { i64, [21 x i64] }
  %l30 = alloca i1
  %l33 = alloca ptr
  %l37 = alloca %"compiler/mir:BasicBlock"
  %l40 = alloca { i64, [21 x i64] }
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/lower:liveness", ptr %t1, i32 0, i32 8
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eClear_3ccompiler_2fmir_3aLocalId_3e(ptr %v1, ptr %t3)
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/lower:liveness", ptr %t5, i32 0, i32 9
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eClear_3ccompiler_2fmir_3aLocalId_3e(ptr %v1, ptr %t7)
  br label %bb2
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp slt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/lower:lowering", ptr %t13, i32 0, i32 3
  store ptr %t15, ptr %l11, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/lower:lowering", ptr %t16, i32 0, i32 3
  %t19 = getelementptr %"compiler/mir:Fn", ptr %t18, i32 0, i32 9
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = call %"compiler/mir:BasicBlock" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %s1, ptr %t19, i64 %t20)
  store %"compiler/mir:BasicBlock" %t23, ptr %l15
  br label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l21, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/lower:lowering", ptr %t25, i32 0, i32 3
  %t28 = getelementptr %"compiler/mir:Fn", ptr %t27, i32 0, i32 9
  %t29 = load i64, ptr %l2, !tbaa !24
  %t32 = call %"compiler/mir:BasicBlock" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %v0, ptr %t28, i64 %t29)
  store %"compiler/mir:BasicBlock" %t32, ptr %l25
  br label %bb7
bb5:
  %t33 = getelementptr %"compiler/mir:BasicBlock", ptr %l15, i32 0, i32 1
  %t34 = load { i64, [8 x i64] }, ptr %t33
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr %"compiler/lower:liveness", ptr %t35, i32 0, i32 8
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr %"compiler/lower:liveness", ptr %t38, i32 0, i32 9
  %t41 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eTermMentions(ptr %v0, ptr %v1, ptr %v1, ptr %t41, { i64, [8 x i64] } %t34, ptr %t37, ptr %t40)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb16
bb7:
  %t45 = getelementptr %"compiler/mir:BasicBlock", ptr %l25, i32 0, i32 0
  %t46 = load i64, ptr %l3, !tbaa !24
  %t49 = call { i64, [21 x i64] } @compiler_2fmir_2ecompiler_2fmir_3aStmtList_2eAt(ptr %v0, ptr %t45, i64 %t46)
  store { i64, [21 x i64] } %t49, ptr %l28
  br label %bb8
bb8:
  %t50 = load { i64, [21 x i64] }, ptr %l28
  %t51 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 176, i64 8)
  store { i64, [21 x i64] } %t50, ptr %t51
  %t52 = load ptr, ptr %l21, !tbaa !29
  %t54 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eownRelease(ptr %v0, ptr %s2, ptr %t52, ptr %t51)
  store i1 %t54, ptr %l30
  br label %bb9
bb9:
  %t55 = load i1, ptr %l30, !tbaa !21
  %t56 = xor i1 %t55, true
  br i1 %t56, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/lower:lowering", ptr %t58, i32 0, i32 3
  store ptr %t60, ptr %l33, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/lower:lowering", ptr %t61, i32 0, i32 3
  %t64 = getelementptr %"compiler/mir:Fn", ptr %t63, i32 0, i32 9
  %t65 = load i64, ptr %l2, !tbaa !24
  %t68 = call %"compiler/mir:BasicBlock" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %v0, ptr %t64, i64 %t65)
  store %"compiler/mir:BasicBlock" %t68, ptr %l37
  br label %bb12
bb11:
  br label %bb15
bb12:
  %t69 = getelementptr %"compiler/mir:BasicBlock", ptr %l37, i32 0, i32 0
  %t70 = load i64, ptr %l3, !tbaa !24
  %t73 = call { i64, [21 x i64] } @compiler_2fmir_2ecompiler_2fmir_3aStmtList_2eAt(ptr %v0, ptr %t69, i64 %t70)
  store { i64, [21 x i64] } %t73, ptr %l40
  br label %bb13
bb13:
  %t74 = load { i64, [21 x i64] }, ptr %l40
  %t75 = call ptr @__olang_scope_alloc_a(ptr %s3, i64 176, i64 8)
  store { i64, [21 x i64] } %t74, ptr %t75
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr %"compiler/lower:liveness", ptr %t76, i32 0, i32 8
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr %"compiler/lower:liveness", ptr %t79, i32 0, i32 9
  %t82 = load ptr, ptr %l33, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eMentions(ptr %v0, ptr %s3, ptr %v1, ptr %v1, ptr %t82, ptr %t75, ptr %t78, ptr %t81)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2flower_2ecompiler_2flower_3alowering_2emethodBody(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, i32 %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i64
  %l17 = alloca ptr
  %l20 = alloca i32
  %l23 = alloca i32
  %l25 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca ptr
  %l32 = alloca i32
  %l51 = alloca ptr
  %l52 = alloca i32
  %l54 = alloca ptr
  %l57 = alloca i32
  %l59 = alloca i64
  %l62 = alloca i1
  %l68 = alloca i64
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 2
  %t9 = load ptr, ptr %t8, !tbaa !29
  store ptr %t9, ptr %l5, !tbaa !29
  %t11 = load ptr, ptr %l5, !tbaa !29
  store ptr %t11, ptr %l17, !tbaa !29
  %t12 = load i32, ptr %l1, !tbaa !23
  %t13 = load ptr, ptr %l17, !tbaa !29
  %t14 = call ptr @__olang_scope_or(ptr %v3, ptr %t13)
  %t15 = call ptr @__olang_scope_hold(ptr %t14)
  %t16 = ptrtoint ptr %t15 to i64
  %t18 = inttoptr i64 %t16 to ptr
  %t19 = load ptr, ptr %l17, !tbaa !29
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t18, ptr %t19, i32 %t12)
  store i32 %t21, ptr %l20
  br label %bb1
bb1:
  %t22 = load i32, ptr %l20, !range !{i32 0, i32 33}
  %t24 = trunc i64 18 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb2, label %bb3
bb2:
  %t27 = load i32, ptr %l1, !tbaa !23
  store i32 %t27, ptr %l23, !tbaa !23
  br label %bb5
bb3:
  %t29 = load ptr, ptr %l5, !tbaa !29
  store ptr %t29, ptr %l25, !tbaa !29
  %t30 = load i32, ptr %l1, !tbaa !23
  %t31 = load ptr, ptr %l25, !tbaa !29
  %t32 = call ptr @__olang_scope_or(ptr %v3, ptr %t31)
  %t33 = call ptr @__olang_scope_hold(ptr %t32)
  %t34 = ptrtoint ptr %t33 to i64
  %t36 = inttoptr i64 %t34 to ptr
  %t37 = load ptr, ptr %l25, !tbaa !29
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t36, ptr %t37, i32 %t30)
  store i32 %t39, ptr %l28
  br label %bb4
bb4:
  %t40 = load i32, ptr %l28, !tbaa !23
  store i32 %t40, ptr %l23, !tbaa !23
  br label %bb5
bb5:
  %t41 = load i32, ptr %l23, !tbaa !23
  store i32 %t41, ptr %l6, !tbaa !23
  %t42 = load ptr, ptr %l5, !tbaa !29
  store ptr %t42, ptr %l29, !tbaa !29
  %t43 = load i32, ptr %l6, !tbaa !23
  %t44 = load ptr, ptr %l29, !tbaa !29
  %t45 = call ptr @__olang_scope_or(ptr %v3, ptr %t44)
  %t46 = call ptr @__olang_scope_hold(ptr %t45)
  %t47 = ptrtoint ptr %t46 to i64
  %t49 = inttoptr i64 %t47 to ptr
  %t50 = load ptr, ptr %l29, !tbaa !29
  %t52 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t49, ptr %t50, i32 %t43)
  store i32 %t52, ptr %l32
  br label %bb6
bb6:
  %t53 = load i32, ptr %l32, !range !{i32 0, i32 33}
  %t55 = trunc i64 18 to i32
  %t56 = icmp eq i32 %t53, %t55
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb7, label %bb8
bb7:
  store i64 -1, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  store i64 -1, ptr %l7, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s2
  %t64 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %a2, 0
  %t66 = insertvalue [2 x { i64, ptr }] %t64, { i64, ptr } %a3, 1
  %t68 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 32, i64 8)
  store [2 x { i64, ptr }] %t66, ptr %t68
  store ptr %t68, ptr %l8
  store i64 0, ptr %l9, !tbaa !24
  %t70 = load ptr, ptr %l8
  store i64 2, ptr %l10, !tbaa !24
  br label %bb10
bb10:
  %t73 = load i64, ptr %l9, !tbaa !24
  %t74 = load i64, ptr %l10, !tbaa !24
  %t77 = icmp slt i64 %t73, %t74
  %t79 = xor i1 %t77, true
  br i1 %t79, label %bb11, label %bb12
bb11:
  br label %bb24
bb12:
  br label %bb13
bb13:
  %t81 = load ptr, ptr %l8
  %t82 = load i64, ptr %l9, !tbaa !24
  %t85 = getelementptr [2 x { i64, ptr }], ptr %t81, i64 0, i64 %t82
  %t86 = load { i64, ptr }, ptr %t85, !tbaa !37
  %t88 = load ptr, ptr %l4, !tbaa !29
  %t90 = getelementptr %"compiler/lower:Lowerer", ptr %t88, i32 0, i32 0
  %t91 = load ptr, ptr %t90, !tbaa !29
  store ptr %t91, ptr %l51, !tbaa !29
  %t92 = load i32, ptr %l6, !tbaa !23
  store i32 %t92, ptr %l52, !tbaa !23
  %t93 = load ptr, ptr %l5, !tbaa !29
  %t95 = getelementptr %"compiler/types:Table", ptr %t93, i32 0, i32 0
  %t96 = load ptr, ptr %t95, !tbaa !29
  store ptr %t96, ptr %l54, !tbaa !29
  %t98 = load ptr, ptr %l54, !tbaa !29
  %t99 = call ptr @__olang_scope_of(ptr %t98, ptr null)
  %t100 = call ptr @__olang_scope_hold(ptr %t99)
  %t101 = ptrtoint ptr %t100 to i64
  %t103 = inttoptr i64 %t101 to ptr
  %t104 = load ptr, ptr %l54, !tbaa !29
  %t106 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %t103, ptr %s2, ptr %t104, { i64, ptr } %t86)
  store i32 %t106, ptr %l57
  br label %bb14
bb14:
  %t107 = load ptr, ptr %l51, !tbaa !29
  %t108 = call ptr @__olang_scope_or(ptr %v4, ptr %t107)
  %t109 = call ptr @__olang_scope_hold(ptr %t108)
  %t110 = ptrtoint ptr %t109 to i64
  %t112 = inttoptr i64 %t110 to ptr
  %t113 = load ptr, ptr %l51, !tbaa !29
  %t114 = load i32, ptr %l52, !tbaa !23
  %t115 = load i32, ptr %l57, !tbaa !23
  %t116 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %t112, ptr %t113, i32 %t114, i32 %t115)
  store i64 %t116, ptr %l59
  br label %bb15
bb15:
  %t117 = load i64, ptr %l59, !tbaa !24
  store i64 %t117, ptr %l12, !tbaa !24
  %t118 = load i64, ptr %l12, !tbaa !24
  %t120 = icmp sge i64 %t118, 0
  br i1 %t120, label %bb16, label %bb17
bb16:
  %t122 = load i64, ptr %l7, !tbaa !24
  %t124 = icmp slt i64 %t122, 0
  store i1 %t124, ptr %l62, !tbaa !21
  br label %bb18
bb17:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb18
bb18:
  %t126 = load i1, ptr %l62, !tbaa !21
  br i1 %t126, label %bb19, label %bb20
bb19:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load i32, ptr %l6, !tbaa !23
  %t129 = load i64, ptr %l12, !tbaa !24
  %t133 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2ereceiverBody(ptr %v0, ptr %v4, ptr %v3, ptr %t127, i32 %t128, i64 %t129)
  store i64 %t133, ptr %l68
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t134 = load i64, ptr %l68, !tbaa !24
  store i64 %t134, ptr %l7, !tbaa !24
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t135 = load i64, ptr %l9, !tbaa !24
  %t138 = add i64 %t135, 1
  store i64 %t138, ptr %l9, !tbaa !24
  br label %bb10
bb24:
  call void @__olang_scope_close(ptr %s2)
  %t140 = load i64, ptr %l7, !tbaa !24
  store i64 %t140, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2emovedAway(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca %"std/prelude/map:MapValueIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l6 = alloca %"std/prelude/map:MapValueIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l7 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l12 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/lower:lowering", ptr %a0, i32 0, i32 84
  %t5 = call %"std/prelude/map:MapValueIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eValues_3cI64_2c_20I64_3e(ptr %v0, ptr %v0, ptr %t3)
  store %"std/prelude/map:MapValueIter.bf5835bb10600fe6a7fc1da14a6360d9" %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load %"std/prelude/map:MapValueIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l6
  store %"std/prelude/map:MapValueIter.bf5835bb10600fe6a7fc1da14a6360d9" %t6, ptr %l2
  br label %bb2
bb2:
  %t8 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapValueIter_3cI64_2c_20I64_3e_2eNext_3cI64_2c_20I64_3e(ptr %v0, ptr %l2)
  %t9 = extractvalue { i32, i64 } %t8, 1
  %t10 = extractvalue { i32, i64 } %t8, 0
  store i32 %t10, ptr %l10
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb4, label %ok.12, !prof !99
ok.12:
  store i64 %t9, ptr %l9
  br label %bb3
bb3:
  %t13 = load i64, ptr %l9, !tbaa !24
  store i64 %t13, ptr %l7, !tbaa !24
  br label %bb6
bb4:
  %t14 = load i32, ptr %l10, !tbaa !23
  %t15 = ashr i32 %t14, 16
  %t17 = icmp eq i32 %t15, 1
  store i1 %t17, ptr %l12, !tbaa !21
  br label %bb5
bb5:
  br label %bb11
bb6:
  %t18 = load i64, ptr %l7, !tbaa !24
  %t23 = icmp eq i64 %t18, %a1
  br i1 %t23, label %bb7, label %bb8
bb7:
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  br label %bb2
bb11:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2emutStorage(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l10 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/lower:Lowerer", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 3
  store ptr %t9, ptr %l4, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/lower:lowering", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/typed:Body", ptr %t13, i32 0, i32 3
  %t16 = load i64, ptr %t15, !tbaa !24
  %t17 = load { i64, ptr }, ptr @G_2ecompiler_2ftyped_2eMutGlobalsFact, !tbaa !27
  %t18 = load ptr, ptr %l4, !tbaa !29
  %t19 = call ptr @__olang_scope_or(ptr %v1, ptr %t18)
  %t20 = call ptr @__olang_scope_hold(ptr %t19)
  %t21 = ptrtoint ptr %t20 to i64
  %t23 = inttoptr i64 %t21 to ptr
  %t24 = load ptr, ptr @__olang_prog_scope
  %t25 = load ptr, ptr %l4, !tbaa !29
  %t28 = call i32 @compiler_2ffacts_2ecompiler_2ffacts_3aTable_2eNote(ptr %t23, ptr %t24, ptr %t25, i64 %t16, { i64, ptr } %t17)
  store i32 %t28, ptr %l10
  %t29 = icmp ne i32 %t28, 0
  br i1 %t29, label %bb2, label %ok.30, !prof !99
ok.30:
  br label %bb1
bb1:
  br label %bb4
bb2:
  br label %bb3
bb3:
  br label %bb4
bb4:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/lower:lowering", ptr %t31, i32 0, i32 0
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = getelementptr %"compiler/lower:Lowerer", ptr %t34, i32 0, i32 0
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 0
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/load:Loader", ptr %t40, i32 0, i32 8
  %t43 = load i1, ptr %t42, !tbaa !21
  store i1 %t43, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2enullScope(ptr %v0, ptr %v1, ptr %v2, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l7 = alloca i32
  %l8 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l13 = alloca %"compiler/mir:Lvalue"
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [1 x i64] }
  %t27 = alloca { i64, [4 x i64] }, align 8
  %t34 = alloca { i64, [15 x i64] }, align 8
  %t40 = alloca { i64, [21 x i64] }, align 8
  %t55 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/lower:lowering", ptr %t3, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Body", ptr %t6, i32 0, i32 4
  %t9 = load %"compiler/source:Span", ptr %t8
  %t13 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t1, i32 %t2, %"compiler/source:Span" %t9)
  store i32 %t13, ptr %l7
  br label %bb1
bb1:
  %t14 = load i32, ptr %l7, !tbaa !23
  store i32 %t14, ptr %l1, !tbaa !23
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l8, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/lower:lowering", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/typed:Body", ptr %t19, i32 0, i32 4
  %t22 = load %"compiler/source:Span", ptr %t21
  store %"compiler/source:Span" %t22, ptr %l11
  %t23 = load i32, ptr %l1, !tbaa !23
  %t25 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t23)
  store %"compiler/mir:Lvalue" %t25, ptr %l13
  br label %bb2
bb2:
  %t26 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t27
  %t28 = getelementptr { i64, [4 x i64] }, ptr %t27, i32 0, i32 0
  store i64 2, ptr %t28
  %t30 = insertvalue { i32, i64 } undef, i32 %t26, 0
  %t31 = insertvalue { i32, i64 } %t30, i64 0, 1
  %t32 = getelementptr { i64, [4 x i64] }, ptr %t27, i32 0, i32 1
  store { i32, i64 } %t31, ptr %t32
  %t33 = load { i64, [4 x i64] }, ptr %t27
  store { i64, [15 x i64] } zeroinitializer, ptr %t34
  %t35 = getelementptr { i64, [15 x i64] }, ptr %t34, i32 0, i32 0
  store i64 0, ptr %t35
  %t37 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t33, 0
  %t38 = getelementptr { i64, [15 x i64] }, ptr %t34, i32 0, i32 1
  store { { i64, [4 x i64] } } %t37, ptr %t38
  %t39 = load { i64, [15 x i64] }, ptr %t34
  store { i64, [21 x i64] } zeroinitializer, ptr %t40
  %t41 = getelementptr { i64, [21 x i64] }, ptr %t40, i32 0, i32 0
  store i64 0, ptr %t41
  %t42 = load %"compiler/source:Span", ptr %l11
  %t43 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t42, 0
  %t44 = load %"compiler/mir:Lvalue", ptr %l13
  %t45 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t43, %"compiler/mir:Lvalue" %t44, 1
  %t47 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t45, { i64, [15 x i64] } %t39, 2
  %t48 = getelementptr { i64, [21 x i64] }, ptr %t40, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t47, ptr %t48
  %t49 = load { i64, [21 x i64] }, ptr %t40
  %t51 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t49, ptr %t51
  %t52 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %v1, ptr %v2, ptr %t52, ptr %t51)
  br label %bb3
bb3:
  %t54 = load i32, ptr %l1, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t55
  %t56 = getelementptr { i64, [1 x i64] }, ptr %t55, i32 0, i32 0
  store i64 4, ptr %t56
  %t58 = insertvalue { i32 } undef, i32 %t54, 0
  %t59 = getelementptr { i64, [1 x i64] }, ptr %t55, i32 0, i32 1
  store { i32 } %t58, ptr %t59
  %t60 = load { i64, [1 x i64] }, ptr %t55
  call void @__olang_scope_close(ptr %s0)
  store { i64, [1 x i64] } %t60, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eobjHits(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l10 = alloca i1
  %l11 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l17 = alloca i32
  %l19 = alloca i1
  %l21 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l29 = alloca i1
  %l30 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l36 = alloca i32
  %l38 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 71
  %t9 = load i32, ptr %l1, !tbaa !23
  %t11 = sext i32 %t9 to i64
  %t14 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t8, i64 %t11)
  store i1 %t14, ptr %l10
  br label %bb1
bb1:
  %t15 = load i1, ptr %l10, !tbaa !21
  br i1 %t15, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb6
bb3:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/lower:lowering", ptr %t16, i32 0, i32 71
  store ptr %t18, ptr %l13, !tbaa !29
  %t19 = load ptr, ptr %l2, !tbaa !29
  store ptr %t19, ptr %l14, !tbaa !29
  %t20 = load i32, ptr %l1, !tbaa !23
  %t21 = load ptr, ptr %l14, !tbaa !29
  %t22 = call ptr @__olang_scope_or(ptr %v1, ptr %t21)
  %t23 = call ptr @__olang_scope_hold(ptr %t22)
  %t24 = ptrtoint ptr %t23 to i64
  %t26 = inttoptr i64 %t24 to ptr
  %t27 = load ptr, ptr %l14, !tbaa !29
  %t29 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t26, ptr %t27, i32 %t20)
  store i32 %t29, ptr %l17
  br label %bb4
bb4:
  %t30 = load i32, ptr %l17, !tbaa !23
  %t31 = sext i32 %t30 to i64
  %t32 = load ptr, ptr %l13, !tbaa !29
  %t34 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t32, i64 %t31)
  store i1 %t34, ptr %l19
  br label %bb5
bb5:
  %t35 = load i1, ptr %l19, !tbaa !21
  store i1 %t35, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t36 = load i1, ptr %l11, !tbaa !21
  br i1 %t36, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t38 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t38, ptr %l21
  br label %bb10
bb10:
  %t39 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l21
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t39, ptr %l3
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eheldParts(ptr %v0, ptr %s0, ptr %v1, ptr %t40, i32 %t41, ptr %l3, i64 0)
  br label %bb11
bb11:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/lower:lowering", ptr %t45, i32 0, i32 72
  %t48 = load i32, ptr %t47, !tbaa !23
  %t50 = sext i32 %t48 to i64
  %t53 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %s0, ptr %l3, i64 %t50)
  store i1 %t53, ptr %l29
  br label %bb12
bb12:
  %t54 = load i1, ptr %l29, !tbaa !21
  br i1 %t54, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb17
bb14:
  store ptr %l3, ptr %l31, !tbaa !29
  %t55 = load ptr, ptr %l2, !tbaa !29
  store ptr %t55, ptr %l32, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/lower:lowering", ptr %t56, i32 0, i32 72
  %t59 = load i32, ptr %t58, !tbaa !23
  %t60 = load ptr, ptr %l32, !tbaa !29
  %t61 = call ptr @__olang_scope_or(ptr %v1, ptr %t60)
  %t62 = call ptr @__olang_scope_hold(ptr %t61)
  %t63 = ptrtoint ptr %t62 to i64
  %t65 = inttoptr i64 %t63 to ptr
  %t66 = load ptr, ptr %l32, !tbaa !29
  %t68 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t65, ptr %t66, i32 %t59)
  store i32 %t68, ptr %l36
  br label %bb15
bb15:
  %t69 = load i32, ptr %l36, !tbaa !23
  %t70 = sext i32 %t69 to i64
  %t71 = load ptr, ptr %l31, !tbaa !29
  %t73 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %s0, ptr %t71, i64 %t70)
  store i1 %t73, ptr %l38
  br label %bb16
bb16:
  %t74 = load i1, ptr %l38, !tbaa !21
  store i1 %t74, ptr %l30, !tbaa !21
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  %t75 = load i1, ptr %l30, !tbaa !21
  store i1 %t75, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eonError(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l8 = alloca ptr
  %l13 = alloca %"compiler/typed:BlockInfo"
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Body", ptr %t4, i32 0, i32 8
  store ptr %t6, ptr %l4, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/lower:lowering", ptr %t7, i32 0, i32 18
  %t13 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlock_26_3e_2eAt_3ccompiler_2ftyped_3aBlock_26_3e(ptr %v0, ptr %s0, ptr %t9, i64 %a1)
  store ptr %t13, ptr %l8
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t16 = getelementptr %"compiler/typed:Block", ptr %t14, i32 0, i32 0
  %t17 = load i32, ptr %t16, !tbaa !23
  %t19 = sext i32 %t17 to i64
  %t20 = load ptr, ptr %l4, !tbaa !29
  %t21 = call ptr @__olang_scope_or(ptr %v1, ptr %t20)
  %t22 = call ptr @__olang_scope_hold(ptr %t21)
  %t23 = ptrtoint ptr %t22 to i64
  %t25 = inttoptr i64 %t23 to ptr
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t28 = call %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %t25, ptr %t26, i64 %t19)
  store %"compiler/typed:BlockInfo" %t28, ptr %l13
  br label %bb2
bb2:
  %t29 = getelementptr %"compiler/typed:BlockInfo", ptr %l13, i32 0, i32 1
  %t30 = load i32, ptr %t29, !range !{i32 0, i32 10}
  %t32 = trunc i64 7 to i32
  %t33 = icmp eq i32 %t30, %t32
  call void @__olang_scope_close(ptr %s0)
  store i1 %t33, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eopenBlock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l4 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i32
  %l9 = alloca ptr
  %l11 = alloca i32
  %l13 = alloca i32
  %l16 = alloca ptr
  %l21 = alloca %"compiler/typed:BlockInfo"
  %l24 = alloca i32
  %l25 = alloca ptr
  %l28 = alloca ptr
  %l33 = alloca %"compiler/typed:BlockInfo"
  %l39 = alloca ptr
  %l44 = alloca %"compiler/lower:level"
  %s0 = alloca %olang.scope
  %t73 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 3
  store ptr %t3, ptr %l6, !tbaa !29
  %t4 = load i32, ptr %l2, !range !{i32 0, i32 7}
  store i32 %t4, ptr %l7
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call ptr @compiler_2flower_2ecompiler_2flower_3alowering_2etop(ptr %v0, ptr %s0, ptr %t5)
  store ptr %t7, ptr %l9
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l9, !tbaa !29
  %t10 = getelementptr %"compiler/lower:level", ptr %t8, i32 0, i32 0
  %t11 = load i32, ptr %t10, !tbaa !23
  store i32 %t11, ptr %l11, !tbaa !23
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Block", ptr %t12, i32 0, i32 0
  %t15 = load i32, ptr %t14, !tbaa !23
  store i32 %t15, ptr %l13, !tbaa !23
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/lower:lowering", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/typed:Body", ptr %t19, i32 0, i32 8
  store ptr %t21, ptr %l16, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Block", ptr %t22, i32 0, i32 0
  %t25 = load i32, ptr %t24, !tbaa !23
  %t27 = sext i32 %t25 to i64
  %t28 = load ptr, ptr %l16, !tbaa !29
  %t29 = call ptr @__olang_scope_or(ptr %v2, ptr %t28)
  %t30 = call ptr @__olang_scope_hold(ptr %t29)
  %t31 = ptrtoint ptr %t30 to i64
  %t33 = inttoptr i64 %t31 to ptr
  %t34 = load ptr, ptr %l16, !tbaa !29
  %t36 = call %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %t33, ptr %t34, i64 %t27)
  store %"compiler/typed:BlockInfo" %t36, ptr %l21
  br label %bb2
bb2:
  %t37 = getelementptr %"compiler/typed:BlockInfo", ptr %l21, i32 0, i32 2
  %t38 = load %"compiler/source:Span", ptr %t37
  %t40 = load ptr, ptr %l6, !tbaa !29
  %t41 = load i32, ptr %l7, !range !{i32 0, i32 7}
  %t42 = load i32, ptr %l11, !tbaa !23
  %t43 = load i32, ptr %l13, !tbaa !23
  %t46 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddScope(ptr %v0, ptr %t40, i32 %t41, i32 %t42, i32 %t43, %"compiler/source:Span" %t38, i32 %a3)
  store i32 %t46, ptr %l24
  br label %bb3
bb3:
  %t47 = load i32, ptr %l24, !tbaa !23
  store i32 %t47, ptr %l4, !tbaa !23
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l25, !tbaa !29
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/lower:lowering", ptr %t49, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = getelementptr %"compiler/typed:Body", ptr %t52, i32 0, i32 8
  store ptr %t54, ptr %l28, !tbaa !29
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Block", ptr %t55, i32 0, i32 0
  %t58 = load i32, ptr %t57, !tbaa !23
  %t60 = sext i32 %t58 to i64
  %t61 = load ptr, ptr %l28, !tbaa !29
  %t62 = call ptr @__olang_scope_or(ptr %v2, ptr %t61)
  %t63 = call ptr @__olang_scope_hold(ptr %t62)
  %t64 = ptrtoint ptr %t63 to i64
  %t66 = inttoptr i64 %t64 to ptr
  %t67 = load ptr, ptr %l28, !tbaa !29
  %t69 = call %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %t66, ptr %t67, i64 %t60)
  store %"compiler/typed:BlockInfo" %t69, ptr %l33
  br label %bb4
bb4:
  %t70 = getelementptr %"compiler/typed:BlockInfo", ptr %l33, i32 0, i32 2
  %t71 = load %"compiler/source:Span", ptr %t70
  %t72 = load i32, ptr %l4, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t73
  %t74 = getelementptr { i64, [21 x i64] }, ptr %t73, i32 0, i32 0
  store i64 3, ptr %t74
  %t76 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t71, 0
  %t78 = insertvalue { %"compiler/source:Span", i32 } %t76, i32 %t72, 1
  %t79 = getelementptr { i64, [21 x i64] }, ptr %t73, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t78, ptr %t79
  %t80 = load { i64, [21 x i64] }, ptr %t73
  %t82 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t80, ptr %t82
  %t83 = load ptr, ptr %l25, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %v3, ptr %v4, ptr %t83, ptr %t82)
  br label %bb5
bb5:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/lower:lowering", ptr %t85, i32 0, i32 14
  store ptr %t87, ptr %l39, !tbaa !29
  %t88 = load i32, ptr %l4, !tbaa !23
  %t89 = load ptr, ptr %l1, !tbaa !29
  %t91 = getelementptr %"compiler/typed:Block", ptr %t89, i32 0, i32 0
  %t92 = load i32, ptr %t91, !tbaa !23
  %t93 = load i32, ptr %l2, !range !{i32 0, i32 7}
  %t97 = call %"compiler/lower:level" @compiler_2flower_3alevel_2ector(ptr %s0, i32 %t88, i32 %t92, i32 %t93)
  store %"compiler/lower:level" %t97, ptr %l44
  br label %bb6
bb6:
  %t98 = load ptr, ptr %l39, !tbaa !29
  %t99 = load %"compiler/lower:level", ptr %l44
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2ePush_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t98, %"compiler/lower:level" %t99)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eownRelease(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca %"compiler/mir:Lvalue"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, [1 x i64] }
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l27 = alloca i64
  %l32 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 20}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [21 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue" }, ptr %t12, i32 0, i32 1
  %t14 = load %"compiler/mir:Lvalue", ptr %t13
  store %"compiler/mir:Lvalue" %t14, ptr %l2
  br label %bb13
bb4:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t17 = load ptr, ptr %l14, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l14, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 20}
  %t23 = icmp eq i64 %t21, 7
  store i1 %t23, ptr %l15, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l15, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [21 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue" }, ptr %t27, i32 0, i32 1
  %t29 = load %"compiler/mir:Lvalue", ptr %t28
  store %"compiler/mir:Lvalue" %t29, ptr %l2
  br label %bb13
bb8:
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t32 = load ptr, ptr %l20, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l20, !tbaa !29
  %t36 = load i64, ptr %t35, !range !{i64 0, i64 20}
  %t38 = icmp eq i64 %t36, 8
  store i1 %t38, ptr %l21, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l21, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr { i64, [21 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue" }, ptr %t42, i32 0, i32 1
  %t44 = load %"compiler/mir:Lvalue", ptr %t43
  store %"compiler/mir:Lvalue" %t44, ptr %l2
  br label %bb13
bb12:
  br label %bb28
bb13:
  %t46 = load %"compiler/mir:Lvalue", ptr %l2
  %t48 = call i64 @compiler_2flower_2ebaseLocal(%"compiler/mir:Lvalue" %t46)
  store i64 %t48, ptr %l27
  br label %bb14
bb14:
  %t49 = load i64, ptr %l27, !tbaa !24
  %t50 = icmp slt i64 %t49, 0
  br i1 %t50, label %bb15, label %bb16
bb15:
  store i1 false, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t54 = load %"compiler/mir:Lvalue", ptr %l2
  %t57 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2eprojsOf(ptr %v0, ptr %s3, ptr %a0, %"compiler/mir:Lvalue" %t54)
  store { i64, ptr } %t57, ptr %l32
  br label %bb18
bb18:
  %t58 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t58, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t60 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t60, 0
  store i64 %t62, ptr %l5, !tbaa !24
  br label %bb19
bb19:
  %t64 = load i64, ptr %l4, !tbaa !24
  %t65 = load i64, ptr %l5, !tbaa !24
  %t68 = icmp slt i64 %t64, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb20, label %bb21
bb20:
  br label %bb27
bb21:
  br label %bb22
bb22:
  %t72 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t72, ptr %l40, !tbaa !27
  %t73 = load i64, ptr %l4, !tbaa !24
  %t75 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr { i64, [1 x i64] }, ptr %t76, i64 %t73
  %t78 = load { i64, [1 x i64] }, ptr %t77
  store { i64, [1 x i64] } %t78, ptr %l6
  %t80 = load { i64, [1 x i64] }, ptr %l6
  %t82 = extractvalue { i64, [1 x i64] } %t80, 0
  %t83 = icmp eq i64 %t82, 0
  %t85 = xor i1 %t83, true
  br i1 %t85, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s3)
  store i1 false, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t88 = getelementptr { i64, [1 x i64] }, ptr %l6, i32 0, i32 1
  %t89 = getelementptr { i64 }, ptr %t88, i32 0, i32 0
  %t90 = load i64, ptr %t89
  store i64 %t90, ptr %l7, !tbaa !24
  br label %bb26
bb26:
  %t92 = load i64, ptr %l4, !tbaa !24
  %t95 = add i64 %t92, 1
  store i64 %t95, ptr %l4, !tbaa !24
  br label %bb19
bb27:
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store i1 false, ptr %rv
  br label %ret
bb32:
  call void @__olang_check_failed(ptr @olang_loc_b4c093d89ac06ab2_da68d45f20141fee)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eownersCopy(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, [4 x i64] } %a2, i32 %a3, { i64, [1 x i64] } %a4, %"compiler/source:Span" %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca i32
  %l11 = alloca i1
  %l22 = alloca ptr
  %l29 = alloca i1
  %l31 = alloca i1
  %l32 = alloca ptr
  %l35 = alloca i1
  %l37 = alloca i1
  %l39 = alloca ptr
  %l42 = alloca i1
  %l44 = alloca ptr
  %l50 = alloca { i64, [4 x i64] }
  %l53 = alloca i32
  %l54 = alloca ptr
  %l57 = alloca %"compiler/lower:pl"
  %l62 = alloca %"compiler/mir:Lvalue"
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t13 = alloca { i64, [4 x i64] }, align 8
  %t90 = alloca { i64, [4 x i64] }, align 8
  %t98 = alloca { i64, [15 x i64] }, align 8
  %t120 = alloca { i64, [2 x i64] }, align 8
  %t139 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a3, ptr %l3
  store %"compiler/source:Span" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 39
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb3
bb2:
  %t8 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, 0
  store i1 %t10, ptr %l11, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l11, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  store { i64, [4 x i64] } zeroinitializer, ptr %t13
  %t14 = getelementptr { i64, [4 x i64] }, ptr %t13, i32 0, i32 0
  store i64 0, ptr %t14
  %t15 = load { i64, [4 x i64] }, ptr %t13
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t15, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/lower:lowering", ptr %t17, i32 0, i32 0
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = getelementptr %"compiler/lower:Lowerer", ptr %t20, i32 0, i32 12
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = icmp eq ptr %t23, null
  br i1 %t25, label %bb7, label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_e95d2ace38390eeb_6a79953ce794a4e7)
  unreachable
bb8:
  br label %bb9
bb9:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/lower:lowering", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"compiler/lower:Lowerer", ptr %t30, i32 0, i32 12
  %t33 = load ptr, ptr %t32, !tbaa !29
  store ptr %t33, ptr %l6, !tbaa !29
  %t35 = load ptr, ptr %l6, !tbaa !29
  store ptr %t35, ptr %l22, !tbaa !29
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/lower:lowering", ptr %t36, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Body", ptr %t39, i32 0, i32 0
  %t42 = load i32, ptr %t41, !tbaa !23
  %t44 = sext i32 %t42 to i64
  %t45 = load i64, ptr %l1, !tbaa !24
  %t46 = load ptr, ptr %l22, !tbaa !29
  %t47 = call ptr @__olang_scope_or(ptr %v1, ptr %t46)
  %t48 = call ptr @__olang_scope_hold(ptr %t47)
  %t49 = ptrtoint ptr %t48 to i64
  %t51 = inttoptr i64 %t49 to ptr
  %t52 = load ptr, ptr %l22, !tbaa !29
  %t55 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eOwnersSite(ptr %t51, ptr %t52, i64 %t44, i64 %t45)
  store i1 %t55, ptr %l29
  br label %bb10
bb10:
  %t56 = load i1, ptr %l29, !tbaa !21
  %t57 = xor i1 %t56, true
  br i1 %t57, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb14
bb12:
  %t59 = load ptr, ptr %l6, !tbaa !29
  store ptr %t59, ptr %l32, !tbaa !29
  %t60 = load i32, ptr %l3, !tbaa !23
  %t61 = load ptr, ptr %l32, !tbaa !29
  %t62 = call ptr @__olang_scope_or(ptr %v1, ptr %t61)
  %t63 = call ptr @__olang_scope_hold(ptr %t62)
  %t64 = ptrtoint ptr %t63 to i64
  %t66 = inttoptr i64 %t64 to ptr
  %t67 = load ptr, ptr %l32, !tbaa !29
  %t69 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ePartsOnly(ptr %t66, ptr %t67, i32 %t60)
  store i1 %t69, ptr %l35
  br label %bb13
bb13:
  %t70 = load i1, ptr %l35, !tbaa !21
  %t71 = xor i1 %t70, true
  store i1 %t71, ptr %l31, !tbaa !21
  br label %bb14
bb14:
  %t73 = load i1, ptr %l31, !tbaa !21
  br i1 %t73, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb18
bb16:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/lower:lowering", ptr %t74, i32 0, i32 2
  %t77 = load ptr, ptr %t76, !tbaa !29
  store ptr %t77, ptr %l39, !tbaa !29
  %t78 = load i32, ptr %l3, !tbaa !23
  %t79 = load ptr, ptr %l39, !tbaa !29
  %t80 = call ptr @__olang_scope_or(ptr %v2, ptr %t79)
  %t81 = call ptr @__olang_scope_hold(ptr %t80)
  %t82 = ptrtoint ptr %t81 to i64
  %t84 = inttoptr i64 %t82 to ptr
  %t85 = load ptr, ptr %l39, !tbaa !29
  %t87 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRunsCopy(ptr %t84, ptr %t85, i32 %t78)
  store i1 %t87, ptr %l42
  br label %bb17
bb17:
  %t88 = load i1, ptr %l42, !tbaa !21
  store i1 %t88, ptr %l37, !tbaa !21
  br label %bb18
bb18:
  %t89 = load i1, ptr %l37, !tbaa !21
  br i1 %t89, label %bb19, label %bb20
bb19:
  store { i64, [4 x i64] } zeroinitializer, ptr %t90
  %t91 = getelementptr { i64, [4 x i64] }, ptr %t90, i32 0, i32 0
  store i64 0, ptr %t91
  %t92 = load { i64, [4 x i64] }, ptr %t90
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t92, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l44, !tbaa !29
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load i32, ptr %l3, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t98
  %t99 = getelementptr { i64, [15 x i64] }, ptr %t98, i32 0, i32 0
  store i64 0, ptr %t99
  %t101 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %a2, 0
  %t102 = getelementptr { i64, [15 x i64] }, ptr %t98, i32 0, i32 1
  store { { i64, [4 x i64] } } %t101, ptr %t102
  %t103 = load { i64, [15 x i64] }, ptr %t98
  %t104 = load %"compiler/source:Span", ptr %l5
  %t109 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %v2, ptr %v1, ptr %t95, i32 %t96, { i64, [15 x i64] } %t103, %"compiler/source:Span" %t104)
  store { i64, [4 x i64] } %t109, ptr %l50
  br label %bb22
bb22:
  %t110 = load i32, ptr %l3, !tbaa !23
  %t111 = load %"compiler/source:Span", ptr %l5
  %t112 = load ptr, ptr %l44, !tbaa !29
  %t113 = load { i64, [4 x i64] }, ptr %l50
  %t116 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %v2, ptr %v1, ptr %t112, { i64, [4 x i64] } %t113, i32 %t110, %"compiler/source:Span" %t111)
  store i32 %t116, ptr %l53
  br label %bb23
bb23:
  %t117 = load i32, ptr %l53, !tbaa !23
  store i32 %t117, ptr %l7, !tbaa !23
  %t118 = load ptr, ptr %l0, !tbaa !29
  store ptr %t118, ptr %l54, !tbaa !29
  %t119 = load i32, ptr %l7, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t120
  %t121 = getelementptr { i64, [2 x i64] }, ptr %t120, i32 0, i32 0
  store i64 1, ptr %t121
  %t123 = insertvalue { i32 } undef, i32 %t119, 0
  %t124 = getelementptr { i64, [2 x i64] }, ptr %t120, i32 0, i32 1
  store { i32 } %t123, ptr %t124
  %t125 = load { i64, [2 x i64] }, ptr %t120
  %t127 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %s0, { i64, [2 x i64] } %t125)
  store %"compiler/lower:pl" %t127, ptr %l57
  br label %bb24
bb24:
  %t128 = load i32, ptr %l3, !tbaa !23
  %t130 = load %"compiler/source:Span", ptr %l5
  %t131 = load ptr, ptr %l54, !tbaa !29
  %t132 = load %"compiler/lower:pl", ptr %l57
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2epartsCopied(ptr %v0, ptr %s0, ptr %v2, ptr %v1, ptr %t131, %"compiler/lower:pl" %t132, i32 %t128, { i64, [1 x i64] } %a4, %"compiler/source:Span" %t130)
  br label %bb25
bb25:
  %t136 = load i32, ptr %l7, !tbaa !23
  %t138 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t136)
  store %"compiler/mir:Lvalue" %t138, ptr %l62
  br label %bb26
bb26:
  store { i64, [4 x i64] } zeroinitializer, ptr %t139
  %t140 = getelementptr { i64, [4 x i64] }, ptr %t139, i32 0, i32 0
  store i64 1, ptr %t140
  %t141 = load %"compiler/mir:Lvalue", ptr %l62
  %t142 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t141, 0
  %t143 = getelementptr { i64, [4 x i64] }, ptr %t139, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t142, ptr %t143
  %t144 = load { i64, [4 x i64] }, ptr %t139
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t144, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2epartsOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/lower:lowering", ptr %t2, i32 0, i32 2
  %t5 = load ptr, ptr %t4, !tbaa !29
  store ptr %t5, ptr %l4, !tbaa !29
  %t7 = load ptr, ptr %l4, !tbaa !29
  %t8 = call ptr @__olang_scope_or(ptr %v2, ptr %t7)
  %t9 = call ptr @__olang_scope_hold(ptr %t8)
  %t10 = ptrtoint ptr %t9 to i64
  %t12 = inttoptr i64 %t10 to ptr
  %t13 = load ptr, ptr %l4, !tbaa !29
  %t15 = call i32 @compiler_2fmir_2eFieldsOf(ptr %t12, ptr %t13, i32 %a1)
  store i32 %t15, ptr %l7
  br label %bb1
bb1:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t17 = load i32, ptr %l7, !tbaa !23
  %t18 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2eitems(ptr %v0, ptr %v1, ptr %v2, ptr %t16, i32 %t17)
  store { i64, ptr } %t18, ptr %l8
  br label %bb2
bb2:
  %t19 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t19, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eplace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca ptr
  %l12 = alloca %"compiler/source:Span"
  %l13 = alloca ptr
  %l14 = alloca %"compiler/source:Span"
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca %"compiler/source:Span"
  %l22 = alloca %"compiler/lower:pl"
  %l30 = alloca %"compiler/lower:pl"
  %l31 = alloca %"compiler/lower:pl"
  %l32 = alloca ptr
  %l33 = alloca i1
  %l42 = alloca %"compiler/lower:pl"
  %l43 = alloca ptr
  %l44 = alloca i1
  %l57 = alloca %"compiler/lower:pl"
  %l58 = alloca ptr
  %l59 = alloca i1
  %l69 = alloca %"compiler/lower:pl"
  %l70 = alloca ptr
  %l71 = alloca i1
  %l78 = alloca ptr
  %l82 = alloca %"compiler/lower:pl"
  %l84 = alloca i32
  %l86 = alloca %"compiler/lower:pl"
  %l87 = alloca ptr
  %l88 = alloca i1
  %l98 = alloca %"compiler/lower:pl"
  %l99 = alloca ptr
  %l100 = alloca i1
  %l110 = alloca %"compiler/lower:pl"
  %l111 = alloca ptr
  %l112 = alloca i1
  %l128 = alloca i32
  %l130 = alloca %"compiler/lower:pl"
  %l131 = alloca ptr
  %l132 = alloca i1
  %l139 = alloca %"compiler/lower:pl"
  %s2 = alloca %olang.scope
  %rv = alloca %"compiler/lower:pl"
  %t6 = alloca { i64, [2 x i64] }, align 8
  %t26 = alloca { i64, [2 x i64] }, align 8
  %t50 = alloca { i64, [2 x i64] }, align 8
  %t89 = alloca { i64, [2 x i64] }, align 8
  %t271 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 12
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store { i64, [2 x i64] } zeroinitializer, ptr %t6
  %t7 = getelementptr { i64, [2 x i64] }, ptr %t6, i32 0, i32 0
  store i64 0, ptr %t7
  %t8 = load { i64, [2 x i64] }, ptr %t6
  %t10 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %v2, { i64, [2 x i64] } %t8)
  store %"compiler/lower:pl" %t10, ptr %l22
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t11 = load %"compiler/lower:pl", ptr %l22
  store %"compiler/lower:pl" %t11, ptr %rv
  br label %ret
bb4:
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = icmp eq ptr %t12, null
  br i1 %t14, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/lower:lowering", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = getelementptr %"compiler/typed:Body", ptr %t20, i32 0, i32 4
  %t23 = load %"compiler/source:Span", ptr %t22
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egap(ptr %v0, ptr %s2, ptr %v3, ptr %t16, %"compiler/source:Span" %t23, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d12, i32 0, i32 1) })
  br label %bb7
bb6:
  br label %bb9
bb7:
  store { i64, [2 x i64] } zeroinitializer, ptr %t26
  %t27 = getelementptr { i64, [2 x i64] }, ptr %t26, i32 0, i32 0
  store i64 0, ptr %t27
  %t28 = load { i64, [2 x i64] }, ptr %t26
  %t30 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %v2, { i64, [2 x i64] } %t28)
  store %"compiler/lower:pl" %t30, ptr %l30
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s2)
  %t31 = load %"compiler/lower:pl", ptr %l30
  store %"compiler/lower:pl" %t31, ptr %rv
  br label %ret
bb9:
  %t32 = load ptr, ptr %l1, !tbaa !29
  store ptr %t32, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t33 = load ptr, ptr %l32, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb10, label %bb11
bb10:
  %t36 = load ptr, ptr %l32, !tbaa !29
  %t37 = load i64, ptr %t36, !range !{i64 0, i64 8}
  %t39 = icmp eq i64 %t37, 0
  store i1 %t39, ptr %l33, !tbaa !21
  br label %bb11
bb11:
  %t40 = load i1, ptr %l33, !tbaa !21
  br i1 %t40, label %bb12, label %bb13
bb12:
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr { i64, [4 x i64] }, ptr %t41, i32 0, i32 1
  %t44 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t43, i32 0, i32 2
  %t45 = load i32, ptr %t44
  store i32 %t45, ptr %l2, !tbaa !23
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t47 = load i32, ptr %l2, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t50
  %t51 = getelementptr { i64, [2 x i64] }, ptr %t50, i32 0, i32 0
  store i64 1, ptr %t51
  %t53 = insertvalue { i32 } undef, i32 %t47, 0
  %t54 = getelementptr { i64, [2 x i64] }, ptr %t50, i32 0, i32 1
  store { i32 } %t53, ptr %t54
  %t55 = load { i64, [2 x i64] }, ptr %t50
  %t57 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %v2, { i64, [2 x i64] } %t55)
  store %"compiler/lower:pl" %t57, ptr %l42
  br label %bb15
bb15:
  %t58 = load %"compiler/lower:pl", ptr %l42
  store %"compiler/lower:pl" %t58, ptr %l31
  br label %bb69
bb16:
  %t59 = load ptr, ptr %l1, !tbaa !29
  store ptr %t59, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t60 = load ptr, ptr %l43, !tbaa !29
  %t61 = icmp ne ptr %t60, null
  br i1 %t61, label %bb17, label %bb18
bb17:
  %t63 = load ptr, ptr %l43, !tbaa !29
  %t64 = load i64, ptr %t63, !range !{i64 0, i64 8}
  %t66 = icmp eq i64 %t64, 1
  store i1 %t66, ptr %l44, !tbaa !21
  br label %bb18
bb18:
  %t67 = load i1, ptr %l44, !tbaa !21
  br i1 %t67, label %bb19, label %bb20
bb19:
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr { i64, [4 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t70, i32 0, i32 1
  %t72 = load i32, ptr %t71
  store i32 %t72, ptr %l3, !tbaa !23
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t76, i32 0, i32 2
  %t78 = load i64, ptr %t77
  store i64 %t78, ptr %l4, !tbaa !24
  %t80 = load ptr, ptr %l1, !tbaa !29
  %t82 = getelementptr { i64, [4 x i64] }, ptr %t80, i32 0, i32 1
  %t83 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t82, i32 0, i32 3
  %t84 = load i32, ptr %t83
  store i32 %t84, ptr %l5, !tbaa !23
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t86 = load i64, ptr %l4, !tbaa !24
  %t87 = load i32, ptr %l5, !tbaa !23
  %t88 = load i32, ptr %l3, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t89
  %t90 = getelementptr { i64, [2 x i64] }, ptr %t89, i32 0, i32 0
  store i64 2, ptr %t90
  %t92 = insertvalue { i64, i32, i32 } undef, i64 %t86, 0
  %t94 = insertvalue { i64, i32, i32 } %t92, i32 %t87, 1
  %t96 = insertvalue { i64, i32, i32 } %t94, i32 %t88, 2
  %t97 = getelementptr { i64, [2 x i64] }, ptr %t89, i32 0, i32 1
  store { i64, i32, i32 } %t96, ptr %t97
  %t98 = load { i64, [2 x i64] }, ptr %t89
  %t100 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %v2, { i64, [2 x i64] } %t98)
  store %"compiler/lower:pl" %t100, ptr %l57
  br label %bb22
bb22:
  %t101 = load %"compiler/lower:pl", ptr %l57
  store %"compiler/lower:pl" %t101, ptr %l31
  br label %bb69
bb23:
  %t102 = load ptr, ptr %l1, !tbaa !29
  store ptr %t102, ptr %l58, !tbaa !29
  store i1 false, ptr %l59, !tbaa !21
  %t103 = load ptr, ptr %l58, !tbaa !29
  %t104 = icmp ne ptr %t103, null
  br i1 %t104, label %bb24, label %bb25
bb24:
  %t106 = load ptr, ptr %l58, !tbaa !29
  %t107 = load i64, ptr %t106, !range !{i64 0, i64 8}
  %t109 = icmp eq i64 %t107, 2
  store i1 %t109, ptr %l59, !tbaa !21
  br label %bb25
bb25:
  %t110 = load i1, ptr %l59, !tbaa !21
  br i1 %t110, label %bb26, label %bb27
bb26:
  %t111 = load ptr, ptr %l1, !tbaa !29
  %t113 = getelementptr { i64, [4 x i64] }, ptr %t111, i32 0, i32 1
  %t114 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t113, i32 0, i32 0
  %t115 = load %"compiler/source:Span", ptr %t114
  store %"compiler/source:Span" %t115, ptr %l6
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t119 = getelementptr { i64, [4 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t119, i32 0, i32 2
  %t121 = load ptr, ptr %t120
  store ptr %t121, ptr %l7, !tbaa !29
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load ptr, ptr %l7, !tbaa !29
  %t125 = load %"compiler/source:Span", ptr %l6
  %t129 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ederef(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %t123, ptr %t124, %"compiler/source:Span" %t125)
  store %"compiler/lower:pl" %t129, ptr %l69
  br label %bb29
bb29:
  %t130 = load %"compiler/lower:pl", ptr %l69
  store %"compiler/lower:pl" %t130, ptr %l31
  br label %bb69
bb30:
  %t131 = load ptr, ptr %l1, !tbaa !29
  store ptr %t131, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t132 = load ptr, ptr %l70, !tbaa !29
  %t133 = icmp ne ptr %t132, null
  br i1 %t133, label %bb31, label %bb32
bb31:
  %t135 = load ptr, ptr %l70, !tbaa !29
  %t136 = load i64, ptr %t135, !range !{i64 0, i64 8}
  %t138 = icmp eq i64 %t136, 3
  store i1 %t138, ptr %l71, !tbaa !21
  br label %bb32
bb32:
  %t139 = load i1, ptr %l71, !tbaa !21
  br i1 %t139, label %bb33, label %bb34
bb33:
  %t140 = load ptr, ptr %l1, !tbaa !29
  %t142 = getelementptr { i64, [4 x i64] }, ptr %t140, i32 0, i32 1
  %t143 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t142, i32 0, i32 2
  %t144 = load ptr, ptr %t143
  store ptr %t144, ptr %l8, !tbaa !29
  %t146 = load ptr, ptr %l1, !tbaa !29
  %t148 = getelementptr { i64, [4 x i64] }, ptr %t146, i32 0, i32 1
  %t149 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t148, i32 0, i32 3
  %t150 = load i64, ptr %t149
  store i64 %t150, ptr %l9, !tbaa !24
  br label %bb35
bb34:
  br label %bb39
bb35:
  %t152 = load ptr, ptr %l0, !tbaa !29
  store ptr %t152, ptr %l78, !tbaa !29
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load ptr, ptr %l8, !tbaa !29
  %t158 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eplace(ptr %v0, ptr %v1, ptr %v0, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %t153, ptr %t154)
  store %"compiler/lower:pl" %t158, ptr %l82
  br label %bb36
bb36:
  %t159 = load ptr, ptr %l8, !tbaa !29
  %t161 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t159)
  store i32 %t161, ptr %l84
  br label %bb37
bb37:
  %t162 = load i64, ptr %l9, !tbaa !24
  %t163 = load ptr, ptr %l78, !tbaa !29
  %t164 = load %"compiler/lower:pl", ptr %l82
  %t165 = load i32, ptr %l84, !tbaa !23
  %t167 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2epackedField(ptr %v0, ptr %v0, ptr %v2, ptr %v4, ptr %t163, %"compiler/lower:pl" %t164, i32 %t165, i64 %t162)
  store %"compiler/lower:pl" %t167, ptr %l86
  br label %bb38
bb38:
  %t168 = load %"compiler/lower:pl", ptr %l86
  store %"compiler/lower:pl" %t168, ptr %l31
  br label %bb69
bb39:
  %t169 = load ptr, ptr %l1, !tbaa !29
  store ptr %t169, ptr %l87, !tbaa !29
  store i1 false, ptr %l88, !tbaa !21
  %t170 = load ptr, ptr %l87, !tbaa !29
  %t171 = icmp ne ptr %t170, null
  br i1 %t171, label %bb40, label %bb41
bb40:
  %t173 = load ptr, ptr %l87, !tbaa !29
  %t174 = load i64, ptr %t173, !range !{i64 0, i64 8}
  %t176 = icmp eq i64 %t174, 4
  store i1 %t176, ptr %l88, !tbaa !21
  br label %bb41
bb41:
  %t177 = load i1, ptr %l88, !tbaa !21
  br i1 %t177, label %bb42, label %bb43
bb42:
  %t178 = load ptr, ptr %l1, !tbaa !29
  %t180 = getelementptr { i64, [4 x i64] }, ptr %t178, i32 0, i32 1
  %t181 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t180, i32 0, i32 0
  %t182 = load %"compiler/source:Span", ptr %t181
  store %"compiler/source:Span" %t182, ptr %l10
  %t184 = load ptr, ptr %l1, !tbaa !29
  %t186 = getelementptr { i64, [4 x i64] }, ptr %t184, i32 0, i32 1
  %t187 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t186, i32 0, i32 2
  %t188 = load ptr, ptr %t187
  store ptr %t188, ptr %l11, !tbaa !29
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load ptr, ptr %l11, !tbaa !29
  %t192 = load %"compiler/source:Span", ptr %l10
  %t196 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eelem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %t190, ptr %t191, %"compiler/source:Span" %t192)
  store %"compiler/lower:pl" %t196, ptr %l98
  br label %bb45
bb45:
  %t197 = load %"compiler/lower:pl", ptr %l98
  store %"compiler/lower:pl" %t197, ptr %l31
  br label %bb69
bb46:
  %t198 = load ptr, ptr %l1, !tbaa !29
  store ptr %t198, ptr %l99, !tbaa !29
  store i1 false, ptr %l100, !tbaa !21
  %t199 = load ptr, ptr %l99, !tbaa !29
  %t200 = icmp ne ptr %t199, null
  br i1 %t200, label %bb47, label %bb48
bb47:
  %t202 = load ptr, ptr %l99, !tbaa !29
  %t203 = load i64, ptr %t202, !range !{i64 0, i64 8}
  %t205 = icmp eq i64 %t203, 5
  store i1 %t205, ptr %l100, !tbaa !21
  br label %bb48
bb48:
  %t206 = load i1, ptr %l100, !tbaa !21
  br i1 %t206, label %bb49, label %bb50
bb49:
  %t207 = load ptr, ptr %l1, !tbaa !29
  %t209 = getelementptr { i64, [4 x i64] }, ptr %t207, i32 0, i32 1
  %t210 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t209, i32 0, i32 0
  %t211 = load %"compiler/source:Span", ptr %t210
  store %"compiler/source:Span" %t211, ptr %l12
  %t213 = load ptr, ptr %l1, !tbaa !29
  %t215 = getelementptr { i64, [4 x i64] }, ptr %t213, i32 0, i32 1
  %t216 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t215, i32 0, i32 2
  %t217 = load ptr, ptr %t216
  store ptr %t217, ptr %l13, !tbaa !29
  br label %bb51
bb50:
  br label %bb53
bb51:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load ptr, ptr %l13, !tbaa !29
  %t221 = load %"compiler/source:Span", ptr %l12
  %t225 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2epayload(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %t219, ptr %t220, %"compiler/source:Span" %t221)
  store %"compiler/lower:pl" %t225, ptr %l110
  br label %bb52
bb52:
  %t226 = load %"compiler/lower:pl", ptr %l110
  store %"compiler/lower:pl" %t226, ptr %l31
  br label %bb69
bb53:
  %t227 = load ptr, ptr %l1, !tbaa !29
  store ptr %t227, ptr %l111, !tbaa !29
  store i1 false, ptr %l112, !tbaa !21
  %t228 = load ptr, ptr %l111, !tbaa !29
  %t229 = icmp ne ptr %t228, null
  br i1 %t229, label %bb54, label %bb55
bb54:
  %t231 = load ptr, ptr %l111, !tbaa !29
  %t232 = load i64, ptr %t231, !range !{i64 0, i64 8}
  %t234 = icmp eq i64 %t232, 6
  store i1 %t234, ptr %l112, !tbaa !21
  br label %bb55
bb55:
  %t235 = load i1, ptr %l112, !tbaa !21
  br i1 %t235, label %bb56, label %bb57
bb56:
  %t236 = load ptr, ptr %l1, !tbaa !29
  %t238 = getelementptr { i64, [4 x i64] }, ptr %t236, i32 0, i32 1
  %t239 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t238, i32 0, i32 0
  %t240 = load %"compiler/source:Span", ptr %t239
  store %"compiler/source:Span" %t240, ptr %l14
  %t242 = load ptr, ptr %l1, !tbaa !29
  %t244 = getelementptr { i64, [4 x i64] }, ptr %t242, i32 0, i32 1
  %t245 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t244, i32 0, i32 1
  %t246 = load i32, ptr %t245
  store i32 %t246, ptr %l15, !tbaa !23
  %t248 = load ptr, ptr %l1, !tbaa !29
  %t250 = getelementptr { i64, [4 x i64] }, ptr %t248, i32 0, i32 1
  %t251 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t250, i32 0, i32 2
  %t252 = load ptr, ptr %t251
  store ptr %t252, ptr %l16, !tbaa !29
  %t254 = load ptr, ptr %l1, !tbaa !29
  %t256 = getelementptr { i64, [4 x i64] }, ptr %t254, i32 0, i32 1
  %t257 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t256, i32 0, i32 3
  %t258 = load i32, ptr %t257
  store i32 %t258, ptr %l17, !tbaa !23
  br label %bb58
bb57:
  br label %bb61
bb58:
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t261 = load ptr, ptr %l16, !tbaa !29
  %t262 = load i32, ptr %l15, !tbaa !23
  %t263 = load %"compiler/source:Span", ptr %l14
  %t264 = load i32, ptr %l17, !tbaa !23
  %t270 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etempLocal(ptr %v0, ptr %v1, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %t260, ptr %t261, i32 %t262, %"compiler/source:Span" %t263, i32 %t264)
  store i32 %t270, ptr %l128
  br label %bb59
bb59:
  store { i64, [2 x i64] } zeroinitializer, ptr %t271
  %t272 = getelementptr { i64, [2 x i64] }, ptr %t271, i32 0, i32 0
  store i64 1, ptr %t272
  %t273 = load i32, ptr %l128, !tbaa !23
  %t274 = insertvalue { i32 } undef, i32 %t273, 0
  %t275 = getelementptr { i64, [2 x i64] }, ptr %t271, i32 0, i32 1
  store { i32 } %t274, ptr %t275
  %t276 = load { i64, [2 x i64] }, ptr %t271
  %t278 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %v2, { i64, [2 x i64] } %t276)
  store %"compiler/lower:pl" %t278, ptr %l130
  br label %bb60
bb60:
  %t279 = load %"compiler/lower:pl", ptr %l130
  store %"compiler/lower:pl" %t279, ptr %l31
  br label %bb69
bb61:
  %t280 = load ptr, ptr %l1, !tbaa !29
  store ptr %t280, ptr %l131, !tbaa !29
  store i1 false, ptr %l132, !tbaa !21
  %t281 = load ptr, ptr %l131, !tbaa !29
  %t282 = icmp ne ptr %t281, null
  br i1 %t282, label %bb62, label %bb63
bb62:
  %t284 = load ptr, ptr %l131, !tbaa !29
  %t285 = load i64, ptr %t284, !range !{i64 0, i64 8}
  %t287 = icmp eq i64 %t285, 7
  store i1 %t287, ptr %l132, !tbaa !21
  br label %bb63
bb63:
  %t288 = load i1, ptr %l132, !tbaa !21
  br i1 %t288, label %bb64, label %bb65
bb64:
  %t289 = load ptr, ptr %l1, !tbaa !29
  %t291 = getelementptr { i64, [4 x i64] }, ptr %t289, i32 0, i32 1
  %t292 = getelementptr { %"compiler/source:Span", i32 }, ptr %t291, i32 0, i32 0
  %t293 = load %"compiler/source:Span", ptr %t292
  store %"compiler/source:Span" %t293, ptr %l18
  br label %bb66
bb65:
  br label %bb68
bb66:
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t296 = load %"compiler/source:Span", ptr %l18
  %t299 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2etarget(ptr %v0, ptr %v2, ptr %v3, ptr %t295, %"compiler/source:Span" %t296)
  store %"compiler/lower:pl" %t299, ptr %l139
  br label %bb67
bb67:
  %t300 = load %"compiler/lower:pl", ptr %l139
  store %"compiler/lower:pl" %t300, ptr %l31
  br label %bb69
bb68:
  call void @__olang_check_failed(ptr @olang_loc_25aa1fca937793b6_1bfa8a59c48f3aa2)
  unreachable
bb69:
  %t301 = load %"compiler/lower:pl", ptr %l31
  store %"compiler/lower:pl" %t301, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:pl", ptr %rv
  ret %"compiler/lower:pl" %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2epopLevel(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca ptr
  %l8 = alloca i64
  %l10 = alloca i1
  %l12 = alloca ptr
  %l15 = alloca i64
  %l17 = alloca i32
  %l21 = alloca i32
  %l24 = alloca i32
  %l25 = alloca i32
  %l26 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca i32
  %l31 = alloca %"compiler/lower:level"
  %l34 = alloca %"compiler/lower:level"
  %l35 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2flower_2ecompiler_2flower_3alowering_2etop(ptr %v0, ptr %s0, ptr %t1)
  store ptr %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t6 = getelementptr %"compiler/lower:level", ptr %t4, i32 0, i32 0
  %t7 = load i32, ptr %t6, !tbaa !23
  store i32 %t7, ptr %l1, !tbaa !23
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/lower:lowering", ptr %t9, i32 0, i32 19
  %t13 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t11)
  store i64 %t13, ptr %l8
  br label %bb3
bb3:
  %t14 = load i64, ptr %l8, !tbaa !24
  %t15 = icmp sgt i64 %t14, 0
  br i1 %t15, label %bb4, label %bb5
bb4:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/lower:lowering", ptr %t17, i32 0, i32 19
  store ptr %t19, ptr %l12, !tbaa !29
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/lower:lowering", ptr %t20, i32 0, i32 19
  %t24 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t22)
  store i64 %t24, ptr %l15
  br label %bb6
bb5:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb8
bb6:
  %t25 = load i64, ptr %l15, !tbaa !24
  %t26 = sub i64 %t25, 1
  %t27 = load ptr, ptr %l12, !tbaa !29
  %t29 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t27, i64 %t26)
  store i32 %t29, ptr %l17
  br label %bb7
bb7:
  %t30 = load i32, ptr %l1, !tbaa !23
  %t31 = load i32, ptr %l17, !tbaa !23
  %t33 = icmp eq i32 %t31, %t30
  store i1 %t33, ptr %l10, !tbaa !21
  br label %bb8
bb8:
  %t35 = load i1, ptr %l10, !tbaa !21
  %t36 = xor i1 %t35, true
  br i1 %t36, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s1)
  br label %bb21
bb10:
  br label %bb11
bb11:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/lower:lowering", ptr %t38, i32 0, i32 19
  %t42 = call { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2ePop_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t40)
  %t43 = extractvalue { i32, i32 } %t42, 1
  %t44 = extractvalue { i32, i32 } %t42, 0
  store i32 %t44, ptr %l25
  %t45 = icmp ne i32 %t44, 0
  br i1 %t45, label %bb13, label %ok.46, !prof !99
ok.46:
  store i32 %t43, ptr %l24
  br label %bb12
bb12:
  %t47 = load i32, ptr %l24, !tbaa !23
  store i32 %t47, ptr %l21, !tbaa !23
  br label %bb15
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/lower:lowering", ptr %t48, i32 0, i32 18
  %t52 = call { i32, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlock_26_3e_2ePop_3ccompiler_2ftyped_3aBlock_26_3e(ptr %v0, ptr %s1, ptr %t50)
  %t53 = extractvalue { i32, ptr } %t52, 1
  %t54 = extractvalue { i32, ptr } %t52, 0
  store i32 %t54, ptr %l30
  %t55 = icmp ne i32 %t54, 0
  br i1 %t55, label %bb17, label %ok.56, !prof !99
ok.56:
  store ptr %t53, ptr %l29
  br label %bb16
bb16:
  %t57 = load ptr, ptr %l29, !tbaa !29
  store ptr %t57, ptr %l26, !tbaa !29
  br label %bb19
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s1)
  br label %bb20
bb20:
  br label %bb2
bb21:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/lower:lowering", ptr %t58, i32 0, i32 14
  %t62 = call { i32, %"compiler/lower:level" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2ePop_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t60)
  %t63 = extractvalue { i32, %"compiler/lower:level" } %t62, 1
  %t64 = extractvalue { i32, %"compiler/lower:level" } %t62, 0
  store i32 %t64, ptr %l35
  %t65 = icmp ne i32 %t64, 0
  br i1 %t65, label %bb23, label %ok.66, !prof !99
ok.66:
  store %"compiler/lower:level" %t63, ptr %l34
  br label %bb22
bb22:
  %t67 = load %"compiler/lower:level", ptr %l34
  store %"compiler/lower:level" %t67, ptr %l31
  br label %bb25
bb23:
  br label %bb24
bb24:
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2eprojsOf(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Lvalue" %a1) #0 {
entry:
  %l1 = alloca %"compiler/mir:Lvalue"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l40 = alloca i64
  %l47 = alloca { i64, [1 x i64] }
  %rv = alloca { i64, ptr }
  store %"compiler/mir:Lvalue" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/mir:Lvalue", ptr %l1, i32 0, i32 1
  %t2 = getelementptr %"compiler/mir:Range", ptr %t1, i32 0, i32 1
  %t3 = load i32, ptr %t2, !tbaa !23
  %t5 = sext i32 %t3 to i64
  store i64 %t5, ptr %l10, !tbaa !24
  %t6 = load i64, ptr %l10, !tbaa !24
  %t7 = icmp sge i64 %t6, 0
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l10, !tbaa !24
  %t10 = icmp sle i64 %t9, 576460752303423487
  br i1 %t10, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_65caa10a9ab9ec93_4c004a47da8c19bf)
  unreachable
bb3:
  %t12 = load i64, ptr %l10, !tbaa !24
  %t13 = mul i64 %t12, 16
  %t14 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t13)
  %t15 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  store i64 %t20, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t23 = load i64, ptr %l3, !tbaa !24
  %t26 = icmp sgt i64 %t22, %t23
  br i1 %t26, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_65caa10a9ab9ec93_4c004a47da8c19bf)
  unreachable
bb5:
  %t28 = load i64, ptr %l5, !tbaa !24
  %t30 = icmp sgt i64 %t28, 0
  br i1 %t30, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb10
bb7:
  %t32 = load i64, ptr %l4, !tbaa !24
  %t33 = load i64, ptr %l3, !tbaa !24
  %t36 = sub i64 %t32, %t33
  %t37 = load i64, ptr %l5, !tbaa !24
  %t40 = add i64 %t36, %t37
  %t42 = sub i64 %t40, 1
  %t43 = load i64, ptr %l5, !tbaa !24
  %t46 = sdiv i64 %t42, %t43
  store i64 %t46, ptr %l22, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb9
bb9:
  %t48 = load i64, ptr %l22, !tbaa !24
  store i64 %t48, ptr %l19, !tbaa !24
  br label %bb10
bb10:
  %t49 = load i64, ptr %l19, !tbaa !24
  store i64 %t49, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb11
bb11:
  %t50 = load i64, ptr %l7, !tbaa !24
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = icmp slt i64 %t50, %t51
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb12, label %bb13
bb12:
  br label %bb17
bb13:
  br label %bb14
bb14:
  %t58 = load i64, ptr %l3, !tbaa !24
  %t59 = load i64, ptr %l7, !tbaa !24
  %t60 = load i64, ptr %l5, !tbaa !24
  %t63 = mul i64 %t59, %t60
  %t66 = add i64 %t58, %t63
  store i64 %t66, ptr %l8, !tbaa !24
  %t68 = load i64, ptr %l8, !tbaa !24
  store i64 %t68, ptr %l40, !tbaa !24
  %t71 = getelementptr %"compiler/lower:lowering", ptr %a0, i32 0, i32 3
  %t72 = getelementptr %"compiler/mir:Fn", ptr %t71, i32 0, i32 10
  %t73 = getelementptr %"compiler/mir:Lvalue", ptr %l1, i32 0, i32 1
  %t74 = getelementptr %"compiler/mir:Range", ptr %t73, i32 0, i32 0
  %t75 = load i32, ptr %t74, !tbaa !23
  %t77 = sext i32 %t75 to i64
  %t78 = load i64, ptr %l8, !tbaa !24
  %t81 = add i64 %t77, %t78
  %t84 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %t72, i64 %t81)
  store { i64, [1 x i64] } %t84, ptr %l47
  br label %bb15
bb15:
  %t85 = load { i64, [1 x i64] }, ptr %l47
  %t86 = load i64, ptr %l40, !tbaa !24
  %t87 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = getelementptr { i64, [1 x i64] }, ptr %t88, i64 %t86
  store { i64, [1 x i64] } %t85, ptr %t89
  br label %bb16
bb16:
  %t90 = load i64, ptr %l7, !tbaa !24
  %t93 = add i64 %t90, 1
  store i64 %t93, ptr %l7, !tbaa !24
  br label %bb11
bb17:
  %t95 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t95, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eprologue(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca i32
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l19 = alloca i32
  %l24 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l40 = alloca i32
  %l51 = alloca { i64, ptr }
  %l62 = alloca i32
  %l70 = alloca i32
  %l79 = alloca ptr
  %l82 = alloca %"compiler/lower:level"
  %s0 = alloca %olang.scope
  %t147 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l14, !tbaa !29
  %t7 = load ptr, ptr %l2, !tbaa !29
  store ptr %t7, ptr %l15, !tbaa !29
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/lower:lowering", ptr %t8, i32 0, i32 3
  %t11 = getelementptr %"compiler/mir:Fn", ptr %t10, i32 0, i32 1
  %t12 = load i32, ptr %t11, !tbaa !23
  %t13 = load ptr, ptr %l15, !tbaa !29
  %t14 = call ptr @__olang_scope_or(ptr %v2, ptr %t13)
  %t15 = call ptr @__olang_scope_hold(ptr %t14)
  %t16 = ptrtoint ptr %t15 to i64
  %t18 = inttoptr i64 %t16 to ptr
  %t19 = load ptr, ptr %l15, !tbaa !29
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %t18, ptr %t19, i32 %t12)
  store i32 %t21, ptr %l19
  br label %bb1
bb1:
  %t22 = load ptr, ptr %l14, !tbaa !29
  %t23 = call ptr @__olang_scope_or(ptr %v2, ptr %t22)
  %t24 = call ptr @__olang_scope_hold(ptr %t23)
  %t25 = ptrtoint ptr %t24 to i64
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/lower:lowering", ptr %t26, i32 0, i32 2
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = call ptr @__olang_scope_or(ptr %v2, ptr %t29)
  %t32 = call ptr @__olang_scope_hold(ptr %t31)
  %t33 = ptrtoint ptr %t32 to i64
  %t35 = inttoptr i64 %t25 to ptr
  %t37 = inttoptr i64 %t33 to ptr
  %t38 = load ptr, ptr %l14, !tbaa !29
  %t39 = load i32, ptr %l19, !tbaa !23
  %t40 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t35, ptr %t37, ptr %t38, i32 %t39)
  store { i64, ptr } %t40, ptr %l24
  br label %bb2
bb2:
  %t41 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t41, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  store i64 %t44, ptr %l5, !tbaa !24
  br label %bb3
bb3:
  %t46 = load i64, ptr %l4, !tbaa !24
  %t47 = load i64, ptr %l5, !tbaa !24
  %t50 = icmp slt i64 %t46, %t47
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb4, label %bb5
bb4:
  br label %bb9
bb5:
  br label %bb6
bb6:
  %t54 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t54, ptr %l31, !tbaa !27
  %t55 = load i64, ptr %l4, !tbaa !24
  %t57 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr i32, ptr %t58, i64 %t55
  %t60 = load i32, ptr %t59, !tbaa !33
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/lower:lowering", ptr %t62, i32 0, i32 3
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/lower:lowering", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = getelementptr %"compiler/typed:Body", ptr %t68, i32 0, i32 4
  %t71 = load %"compiler/source:Span", ptr %t70
  %t76 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddParam(ptr %v0, ptr %t64, i32 0, %"compiler/source:Span" %t71, i32 %t60)
  store i32 %t76, ptr %l40
  br label %bb7
bb7:
  br label %bb8
bb8:
  %t77 = load i64, ptr %l4, !tbaa !24
  %t80 = add i64 %t77, 1
  store i64 %t80, ptr %l4, !tbaa !24
  br label %bb3
bb9:
  store { i64, ptr } %a1, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t84 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t84, 0
  store i64 %t86, ptr %l9, !tbaa !24
  br label %bb10
bb10:
  %t88 = load i64, ptr %l8, !tbaa !24
  %t89 = load i64, ptr %l9, !tbaa !24
  %t92 = icmp slt i64 %t88, %t89
  %t94 = xor i1 %t92, true
  br i1 %t94, label %bb11, label %bb12
bb11:
  br label %bb16
bb12:
  br label %bb13
bb13:
  %t96 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t96, ptr %l51, !tbaa !27
  %t97 = load i64, ptr %l8, !tbaa !24
  %t99 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr { i64, [1 x i64] }, ptr %t100, i64 %t97
  %t102 = load { i64, [1 x i64] }, ptr %t101
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/lower:lowering", ptr %t104, i32 0, i32 3
  %t107 = getelementptr %"compiler/mir:Fn", ptr %t106, i32 0, i32 6
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2ePush_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %t107, { i64, [1 x i64] } %t102)
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t111 = load i64, ptr %l8, !tbaa !24
  %t114 = add i64 %t111, 1
  store i64 %t114, ptr %l8, !tbaa !24
  br label %bb10
bb16:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/lower:lowering", ptr %t116, i32 0, i32 3
  %t120 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t118)
  store i32 %t120, ptr %l62
  br label %bb17
bb17:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/lower:lowering", ptr %t121, i32 0, i32 3
  %t124 = load i32, ptr @G_2ecompiler_2fmir_2eNoScope, !tbaa !23
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/lower:lowering", ptr %t125, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t130 = getelementptr %"compiler/typed:Body", ptr %t128, i32 0, i32 4
  %t131 = load %"compiler/source:Span", ptr %t130
  %t136 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddScope(ptr %v0, ptr %t123, i32 0, i32 %t124, i32 -1, %"compiler/source:Span" %t131, i32 0)
  store i32 %t136, ptr %l70
  br label %bb18
bb18:
  %t137 = load i32, ptr %l70, !tbaa !23
  store i32 %t137, ptr %l11, !tbaa !23
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/lower:lowering", ptr %t139, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t144 = getelementptr %"compiler/typed:Body", ptr %t142, i32 0, i32 4
  %t145 = load %"compiler/source:Span", ptr %t144
  %t146 = load i32, ptr %l11, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t147
  %t148 = getelementptr { i64, [21 x i64] }, ptr %t147, i32 0, i32 0
  store i64 3, ptr %t148
  %t150 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t145, 0
  %t152 = insertvalue { %"compiler/source:Span", i32 } %t150, i32 %t146, 1
  %t153 = getelementptr { i64, [21 x i64] }, ptr %t147, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t152, ptr %t153
  %t154 = load { i64, [21 x i64] }, ptr %t147
  %t156 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t154, ptr %t156
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %v2, ptr %v3, ptr %t138, ptr %t156)
  br label %bb19
bb19:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/lower:lowering", ptr %t159, i32 0, i32 14
  store ptr %t161, ptr %l79, !tbaa !29
  %t162 = load i32, ptr %l11, !tbaa !23
  %t165 = call %"compiler/lower:level" @compiler_2flower_3alevel_2ector(ptr %s0, i32 %t162, i32 -1, i32 0)
  store %"compiler/lower:level" %t165, ptr %l82
  br label %bb20
bb20:
  %t166 = load ptr, ptr %l79, !tbaa !29
  %t167 = load %"compiler/lower:level", ptr %l82
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2ePush_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t166, %"compiler/lower:level" %t167)
  br label %bb21
bb21:
  %t168 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eholdParams(ptr %v0, ptr %v3, ptr %v2, ptr %t168)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietAll(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l13 = alloca { i64, ptr }
  %l19 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  %t28 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietX(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %t21)
  store i1 %t28, ptr %l19
  br label %bb5
bb5:
  %t29 = load i1, ptr %l19, !tbaa !21
  %t30 = xor i1 %t29, true
  br i1 %t30, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t33 = load i64, ptr %l3, !tbaa !24
  %t36 = add i64 %t33, 1
  store i64 %t36, ptr %l3, !tbaa !24
  br label %bb1
bb10:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietBlock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l14 = alloca { i64, ptr }
  %l19 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Block", ptr %a1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l14, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  %t30 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietNested(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %t24)
  store i1 %t30, ptr %l19
  br label %bb5
bb5:
  %t31 = load i1, ptr %l19, !tbaa !21
  %t32 = xor i1 %t31, true
  br i1 %t32, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t35 = load i64, ptr %l3, !tbaa !24
  %t38 = add i64 %t35, 1
  store i64 %t38, ptr %l3, !tbaa !24
  br label %bb1
bb10:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietNested(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l26 = alloca i1
  %l27 = alloca i1
  %l30 = alloca i1
  %l32 = alloca ptr
  %l35 = alloca ptr
  %l39 = alloca %"compiler/typed:Local"
  %l42 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l53 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca i1
  %l64 = alloca i1
  %l65 = alloca i1
  %l68 = alloca i1
  %l69 = alloca i1
  %l73 = alloca i1
  %l74 = alloca ptr
  %l75 = alloca i1
  %l84 = alloca i1
  %l85 = alloca i1
  %l89 = alloca i1
  %l90 = alloca i1
  %l94 = alloca i1
  %l95 = alloca ptr
  %l101 = alloca i1
  %l102 = alloca ptr
  %l103 = alloca i1
  %l110 = alloca i1
  %l111 = alloca ptr
  %l112 = alloca i1
  %l121 = alloca i1
  %l122 = alloca i1
  %l125 = alloca i1
  %l128 = alloca i1
  %l129 = alloca ptr
  %l130 = alloca i1
  %l133 = alloca ptr
  %l134 = alloca i1
  %l137 = alloca ptr
  %l138 = alloca i1
  %l145 = alloca i1
  %l146 = alloca ptr
  %l147 = alloca i1
  %l157 = alloca i1
  %l158 = alloca i1
  %l161 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t2 = load ptr, ptr %l15, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l15, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l16, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l16, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [3 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb15
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t27 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietX(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t22, ptr %t23)
  store i1 %t27, ptr %l26
  br label %bb6
bb6:
  %t28 = load i1, ptr %l26, !tbaa !21
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/lower:lowering", ptr %t29, i32 0, i32 74
  %t32 = load i1, ptr %t31, !tbaa !21
  br i1 %t32, label %bb9, label %bb10
bb8:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb14
bb9:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/lower:lowering", ptr %t34, i32 0, i32 2
  %t37 = load ptr, ptr %t36, !tbaa !29
  store ptr %t37, ptr %l32, !tbaa !29
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/lower:lowering", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/typed:Body", ptr %t41, i32 0, i32 7
  store ptr %t43, ptr %l35, !tbaa !29
  %t44 = load i32, ptr %l2, !tbaa !23
  %t46 = sext i32 %t44 to i64
  %t47 = load ptr, ptr %l35, !tbaa !29
  %t48 = call ptr @__olang_scope_or(ptr %v4, ptr %t47)
  %t49 = call ptr @__olang_scope_hold(ptr %t48)
  %t50 = ptrtoint ptr %t49 to i64
  %t52 = inttoptr i64 %t50 to ptr
  %t53 = load ptr, ptr %l35, !tbaa !29
  %t55 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %t52, ptr %t53, i64 %t46)
  store %"compiler/typed:Local" %t55, ptr %l39
  br label %bb11
bb10:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb13
bb11:
  %t56 = getelementptr %"compiler/typed:Local", ptr %l39, i32 0, i32 2
  %t57 = load i32, ptr %t56, !tbaa !23
  %t58 = load ptr, ptr %l32, !tbaa !29
  %t59 = call ptr @__olang_scope_or(ptr %v3, ptr %t58)
  %t60 = call ptr @__olang_scope_hold(ptr %t59)
  %t61 = ptrtoint ptr %t60 to i64
  %t63 = inttoptr i64 %t61 to ptr
  %t64 = load ptr, ptr %l32, !tbaa !29
  %t66 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %t63, ptr %t64, i32 %t57)
  store i1 %t66, ptr %l42
  br label %bb12
bb12:
  %t67 = load i1, ptr %l42, !tbaa !21
  store i1 %t67, ptr %l30, !tbaa !21
  br label %bb13
bb13:
  %t68 = load i1, ptr %l30, !tbaa !21
  %t69 = xor i1 %t68, true
  store i1 %t69, ptr %l27, !tbaa !21
  br label %bb14
bb14:
  %t71 = load i1, ptr %l27, !tbaa !21
  store i1 %t71, ptr %l14, !tbaa !21
  br label %bb112
bb15:
  %t72 = load ptr, ptr %l1, !tbaa !29
  store ptr %t72, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t73 = load ptr, ptr %l44, !tbaa !29
  %t74 = icmp ne ptr %t73, null
  br i1 %t74, label %bb16, label %bb17
bb16:
  %t76 = load ptr, ptr %l44, !tbaa !29
  %t77 = load i64, ptr %t76, !range !{i64 0, i64 17}
  %t79 = icmp eq i64 %t77, 2
  store i1 %t79, ptr %l45, !tbaa !21
  br label %bb17
bb17:
  %t80 = load i1, ptr %l45, !tbaa !21
  br i1 %t80, label %bb18, label %bb19
bb18:
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = getelementptr { i64, [3 x i64] }, ptr %t81, i32 0, i32 1
  %t84 = getelementptr { %"compiler/source:Span", ptr }, ptr %t83, i32 0, i32 1
  %t85 = load ptr, ptr %t84
  store ptr %t85, ptr %l4, !tbaa !29
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load ptr, ptr %l4, !tbaa !29
  %t92 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietX(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t87, ptr %t88)
  store i1 %t92, ptr %l53
  br label %bb21
bb21:
  %t93 = load i1, ptr %l53, !tbaa !21
  store i1 %t93, ptr %l14, !tbaa !21
  br label %bb112
bb22:
  %t94 = load ptr, ptr %l1, !tbaa !29
  store ptr %t94, ptr %l54, !tbaa !29
  store i1 false, ptr %l55, !tbaa !21
  %t95 = load ptr, ptr %l54, !tbaa !29
  %t96 = icmp ne ptr %t95, null
  br i1 %t96, label %bb23, label %bb24
bb23:
  %t98 = load ptr, ptr %l54, !tbaa !29
  %t99 = load i64, ptr %t98, !range !{i64 0, i64 17}
  %t101 = icmp eq i64 %t99, 1
  store i1 %t101, ptr %l55, !tbaa !21
  br label %bb24
bb24:
  %t102 = load i1, ptr %l55, !tbaa !21
  br i1 %t102, label %bb25, label %bb26
bb25:
  %t103 = load ptr, ptr %l1, !tbaa !29
  %t105 = getelementptr { i64, [3 x i64] }, ptr %t103, i32 0, i32 1
  %t106 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t105, i32 0, i32 1
  %t107 = load ptr, ptr %t106
  store ptr %t107, ptr %l5, !tbaa !29
  %t109 = load ptr, ptr %l1, !tbaa !29
  %t111 = getelementptr { i64, [3 x i64] }, ptr %t109, i32 0, i32 1
  %t112 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t111, i32 0, i32 2
  %t113 = load ptr, ptr %t112
  store ptr %t113, ptr %l6, !tbaa !29
  br label %bb27
bb26:
  br label %bb37
bb27:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load ptr, ptr %l5, !tbaa !29
  %t119 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietStore(ptr %v0, ptr %v1, ptr %v3, ptr %t115, ptr %t116)
  store i1 %t119, ptr %l64
  br label %bb28
bb28:
  %t120 = load i1, ptr %l64, !tbaa !21
  br i1 %t120, label %bb29, label %bb30
bb29:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load ptr, ptr %l5, !tbaa !29
  %t125 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t121, ptr %t122)
  store i1 %t125, ptr %l68
  br label %bb31
bb30:
  store i1 false, ptr %l65, !tbaa !21
  br label %bb32
bb31:
  %t126 = load i1, ptr %l68, !tbaa !21
  store i1 %t126, ptr %l65, !tbaa !21
  br label %bb32
bb32:
  %t127 = load i1, ptr %l65, !tbaa !21
  br i1 %t127, label %bb33, label %bb34
bb33:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load ptr, ptr %l6, !tbaa !29
  %t133 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietX(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t128, ptr %t129)
  store i1 %t133, ptr %l73
  br label %bb35
bb34:
  store i1 false, ptr %l69, !tbaa !21
  br label %bb36
bb35:
  %t134 = load i1, ptr %l73, !tbaa !21
  store i1 %t134, ptr %l69, !tbaa !21
  br label %bb36
bb36:
  %t135 = load i1, ptr %l69, !tbaa !21
  store i1 %t135, ptr %l14, !tbaa !21
  br label %bb112
bb37:
  %t136 = load ptr, ptr %l1, !tbaa !29
  store ptr %t136, ptr %l74, !tbaa !29
  store i1 false, ptr %l75, !tbaa !21
  %t137 = load ptr, ptr %l74, !tbaa !29
  %t138 = icmp ne ptr %t137, null
  br i1 %t138, label %bb38, label %bb39
bb38:
  %t140 = load ptr, ptr %l74, !tbaa !29
  %t141 = load i64, ptr %t140, !range !{i64 0, i64 17}
  %t143 = icmp eq i64 %t141, 3
  store i1 %t143, ptr %l75, !tbaa !21
  br label %bb39
bb39:
  %t144 = load i1, ptr %l75, !tbaa !21
  br i1 %t144, label %bb40, label %bb41
bb40:
  %t145 = load ptr, ptr %l1, !tbaa !29
  %t147 = getelementptr { i64, [3 x i64] }, ptr %t145, i32 0, i32 1
  %t148 = getelementptr { %"compiler/source:Span", ptr }, ptr %t147, i32 0, i32 1
  %t149 = load ptr, ptr %t148
  store ptr %t149, ptr %l7, !tbaa !29
  br label %bb42
bb41:
  br label %bb58
bb42:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load ptr, ptr %l7, !tbaa !29
  %t154 = getelementptr %"compiler/typed:If", ptr %t152, i32 0, i32 0
  %t155 = load ptr, ptr %t154, !tbaa !29
  %t159 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietX(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t151, ptr %t155)
  store i1 %t159, ptr %l84
  br label %bb43
bb43:
  %t160 = load i1, ptr %l84, !tbaa !21
  br i1 %t160, label %bb44, label %bb45
bb44:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load ptr, ptr %l7, !tbaa !29
  %t164 = getelementptr %"compiler/typed:If", ptr %t162, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !29
  %t168 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietBlock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t161, ptr %t165)
  store i1 %t168, ptr %l89
  br label %bb46
bb45:
  store i1 false, ptr %l85, !tbaa !21
  br label %bb47
bb46:
  %t169 = load i1, ptr %l89, !tbaa !21
  store i1 %t169, ptr %l85, !tbaa !21
  br label %bb47
bb47:
  %t170 = load i1, ptr %l85, !tbaa !21
  br i1 %t170, label %bb48, label %bb49
bb48:
  %t171 = load ptr, ptr %l7, !tbaa !29
  %t173 = getelementptr %"compiler/typed:If", ptr %t171, i32 0, i32 2
  %t174 = load ptr, ptr %t173, !tbaa !29
  %t176 = icmp eq ptr %t174, null
  br i1 %t176, label %bb50, label %bb51
bb49:
  store i1 false, ptr %l90, !tbaa !21
  br label %bb57
bb50:
  store i1 true, ptr %l94, !tbaa !21
  br label %bb56
bb51:
  %t178 = load ptr, ptr %l0, !tbaa !29
  store ptr %t178, ptr %l95, !tbaa !29
  %t179 = load ptr, ptr %l7, !tbaa !29
  %t181 = getelementptr %"compiler/typed:If", ptr %t179, i32 0, i32 2
  %t182 = load ptr, ptr %t181, !tbaa !29
  %t184 = icmp eq ptr %t182, null
  br i1 %t184, label %bb52, label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_ea72cddf05e42cbb_238677819f048e67)
  unreachable
bb53:
  br label %bb54
bb54:
  %t186 = load ptr, ptr %l7, !tbaa !29
  %t188 = getelementptr %"compiler/typed:If", ptr %t186, i32 0, i32 2
  %t189 = load ptr, ptr %t188, !tbaa !29
  %t190 = load ptr, ptr %l95, !tbaa !29
  %t192 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietBlock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t190, ptr %t189)
  store i1 %t192, ptr %l101
  br label %bb55
bb55:
  %t193 = load i1, ptr %l101, !tbaa !21
  store i1 %t193, ptr %l94, !tbaa !21
  br label %bb56
bb56:
  %t194 = load i1, ptr %l94, !tbaa !21
  store i1 %t194, ptr %l90, !tbaa !21
  br label %bb57
bb57:
  %t195 = load i1, ptr %l90, !tbaa !21
  store i1 %t195, ptr %l14, !tbaa !21
  br label %bb112
bb58:
  %t196 = load ptr, ptr %l1, !tbaa !29
  store ptr %t196, ptr %l102, !tbaa !29
  store i1 false, ptr %l103, !tbaa !21
  %t197 = load ptr, ptr %l102, !tbaa !29
  %t198 = icmp ne ptr %t197, null
  br i1 %t198, label %bb59, label %bb60
bb59:
  %t200 = load ptr, ptr %l102, !tbaa !29
  %t201 = load i64, ptr %t200, !range !{i64 0, i64 17}
  %t203 = icmp eq i64 %t201, 11
  store i1 %t203, ptr %l103, !tbaa !21
  br label %bb60
bb60:
  %t204 = load i1, ptr %l103, !tbaa !21
  br i1 %t204, label %bb61, label %bb62
bb61:
  %t205 = load ptr, ptr %l1, !tbaa !29
  %t207 = getelementptr { i64, [3 x i64] }, ptr %t205, i32 0, i32 1
  %t208 = getelementptr { %"compiler/source:Span", ptr }, ptr %t207, i32 0, i32 1
  %t209 = load ptr, ptr %t208
  store ptr %t209, ptr %l8, !tbaa !29
  br label %bb63
bb62:
  br label %bb65
bb63:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t212 = load ptr, ptr %l8, !tbaa !29
  %t215 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietBlock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t211, ptr %t212)
  store i1 %t215, ptr %l110
  br label %bb64
bb64:
  %t216 = load i1, ptr %l110, !tbaa !21
  store i1 %t216, ptr %l14, !tbaa !21
  br label %bb112
bb65:
  %t217 = load ptr, ptr %l1, !tbaa !29
  store ptr %t217, ptr %l111, !tbaa !29
  store i1 false, ptr %l112, !tbaa !21
  %t218 = load ptr, ptr %l111, !tbaa !29
  %t219 = icmp ne ptr %t218, null
  br i1 %t219, label %bb66, label %bb67
bb66:
  %t221 = load ptr, ptr %l111, !tbaa !29
  %t222 = load i64, ptr %t221, !range !{i64 0, i64 17}
  %t224 = icmp eq i64 %t222, 4
  store i1 %t224, ptr %l112, !tbaa !21
  br label %bb67
bb67:
  %t225 = load i1, ptr %l112, !tbaa !21
  br i1 %t225, label %bb68, label %bb69
bb68:
  %t226 = load ptr, ptr %l1, !tbaa !29
  %t228 = getelementptr { i64, [3 x i64] }, ptr %t226, i32 0, i32 1
  %t229 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t228, i32 0, i32 1
  %t230 = load ptr, ptr %t229
  store ptr %t230, ptr %l9, !tbaa !29
  %t232 = load ptr, ptr %l1, !tbaa !29
  %t234 = getelementptr { i64, [3 x i64] }, ptr %t232, i32 0, i32 1
  %t235 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t234, i32 0, i32 2
  %t236 = load ptr, ptr %t235
  store ptr %t236, ptr %l10, !tbaa !29
  br label %bb70
bb69:
  br label %bb79
bb70:
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t239 = load ptr, ptr %l9, !tbaa !29
  %t242 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietBlock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t238, ptr %t239)
  store i1 %t242, ptr %l121
  br label %bb71
bb71:
  %t243 = load i1, ptr %l121, !tbaa !21
  br i1 %t243, label %bb72, label %bb73
bb72:
  %t244 = load ptr, ptr %l10, !tbaa !29
  %t246 = icmp eq ptr %t244, null
  br i1 %t246, label %bb74, label %bb75
bb73:
  store i1 false, ptr %l122, !tbaa !21
  br label %bb78
bb74:
  store i1 true, ptr %l125, !tbaa !21
  br label %bb77
bb75:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load ptr, ptr %l10, !tbaa !29
  %t252 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietBlock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t248, ptr %t249)
  store i1 %t252, ptr %l128
  br label %bb76
bb76:
  %t253 = load i1, ptr %l128, !tbaa !21
  store i1 %t253, ptr %l125, !tbaa !21
  br label %bb77
bb77:
  %t254 = load i1, ptr %l125, !tbaa !21
  store i1 %t254, ptr %l122, !tbaa !21
  br label %bb78
bb78:
  %t255 = load i1, ptr %l122, !tbaa !21
  store i1 %t255, ptr %l14, !tbaa !21
  br label %bb112
bb79:
  %t256 = load ptr, ptr %l1, !tbaa !29
  store ptr %t256, ptr %l129, !tbaa !29
  store i1 false, ptr %l130, !tbaa !21
  %t257 = load ptr, ptr %l129, !tbaa !29
  %t258 = icmp ne ptr %t257, null
  br i1 %t258, label %bb80, label %bb81
bb80:
  %t260 = load ptr, ptr %l129, !tbaa !29
  %t261 = load i64, ptr %t260, !range !{i64 0, i64 17}
  %t263 = icmp eq i64 %t261, 5
  store i1 %t263, ptr %l130, !tbaa !21
  br label %bb81
bb81:
  %t264 = load i1, ptr %l130, !tbaa !21
  br i1 %t264, label %bb82, label %bb83
bb82:
  br label %bb88
bb83:
  %t265 = load ptr, ptr %l1, !tbaa !29
  store ptr %t265, ptr %l133, !tbaa !29
  store i1 false, ptr %l134, !tbaa !21
  %t266 = load ptr, ptr %l133, !tbaa !29
  %t267 = icmp ne ptr %t266, null
  br i1 %t267, label %bb84, label %bb85
bb84:
  %t269 = load ptr, ptr %l133, !tbaa !29
  %t270 = load i64, ptr %t269, !range !{i64 0, i64 17}
  %t272 = icmp eq i64 %t270, 7
  store i1 %t272, ptr %l134, !tbaa !21
  br label %bb85
bb85:
  %t273 = load i1, ptr %l134, !tbaa !21
  br i1 %t273, label %bb86, label %bb87
bb86:
  br label %bb88
bb87:
  br label %bb89
bb88:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb112
bb89:
  %t274 = load ptr, ptr %l1, !tbaa !29
  store ptr %t274, ptr %l137, !tbaa !29
  store i1 false, ptr %l138, !tbaa !21
  %t275 = load ptr, ptr %l137, !tbaa !29
  %t276 = icmp ne ptr %t275, null
  br i1 %t276, label %bb90, label %bb91
bb90:
  %t278 = load ptr, ptr %l137, !tbaa !29
  %t279 = load i64, ptr %t278, !range !{i64 0, i64 17}
  %t281 = icmp eq i64 %t279, 6
  store i1 %t281, ptr %l138, !tbaa !21
  br label %bb91
bb91:
  %t282 = load i1, ptr %l138, !tbaa !21
  br i1 %t282, label %bb92, label %bb93
bb92:
  %t283 = load ptr, ptr %l1, !tbaa !29
  %t285 = getelementptr { i64, [3 x i64] }, ptr %t283, i32 0, i32 1
  %t286 = getelementptr { %"compiler/source:Span", ptr }, ptr %t285, i32 0, i32 1
  %t287 = load ptr, ptr %t286
  store ptr %t287, ptr %l11, !tbaa !29
  br label %bb94
bb93:
  br label %bb96
bb94:
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t290 = load ptr, ptr %l11, !tbaa !29
  %t293 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietX(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t289, ptr %t290)
  store i1 %t293, ptr %l145
  br label %bb95
bb95:
  %t294 = load i1, ptr %l145, !tbaa !21
  store i1 %t294, ptr %l14, !tbaa !21
  br label %bb112
bb96:
  %t295 = load ptr, ptr %l1, !tbaa !29
  store ptr %t295, ptr %l146, !tbaa !29
  store i1 false, ptr %l147, !tbaa !21
  %t296 = load ptr, ptr %l146, !tbaa !29
  %t297 = icmp ne ptr %t296, null
  br i1 %t297, label %bb97, label %bb98
bb97:
  %t299 = load ptr, ptr %l146, !tbaa !29
  %t300 = load i64, ptr %t299, !range !{i64 0, i64 17}
  %t302 = icmp eq i64 %t300, 10
  store i1 %t302, ptr %l147, !tbaa !21
  br label %bb98
bb98:
  %t303 = load i1, ptr %l147, !tbaa !21
  br i1 %t303, label %bb99, label %bb100
bb99:
  %t304 = load ptr, ptr %l1, !tbaa !29
  %t306 = getelementptr { i64, [3 x i64] }, ptr %t304, i32 0, i32 1
  %t307 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t306, i32 0, i32 1
  %t308 = load ptr, ptr %t307
  store ptr %t308, ptr %l12, !tbaa !29
  %t310 = load ptr, ptr %l1, !tbaa !29
  %t312 = getelementptr { i64, [3 x i64] }, ptr %t310, i32 0, i32 1
  %t313 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t312, i32 0, i32 2
  %t314 = load ptr, ptr %t313
  store ptr %t314, ptr %l13, !tbaa !29
  br label %bb101
bb100:
  br label %bb107
bb101:
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t317 = load ptr, ptr %l12, !tbaa !29
  %t321 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietX(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t316, ptr %t317)
  store i1 %t321, ptr %l157
  br label %bb102
bb102:
  %t322 = load i1, ptr %l157, !tbaa !21
  br i1 %t322, label %bb103, label %bb104
bb103:
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t324 = load ptr, ptr %l13, !tbaa !29
  %t327 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietX(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t323, ptr %t324)
  store i1 %t327, ptr %l161
  br label %bb105
bb104:
  store i1 false, ptr %l158, !tbaa !21
  br label %bb106
bb105:
  %t328 = load i1, ptr %l161, !tbaa !21
  store i1 %t328, ptr %l158, !tbaa !21
  br label %bb106
bb106:
  %t329 = load i1, ptr %l158, !tbaa !21
  store i1 %t329, ptr %l14, !tbaa !21
  br label %bb112
bb107:
  br i1 true, label %bb108, label %bb109
bb108:
  br label %bb110
bb109:
  br label %bb111
bb110:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb112
bb111:
  call void @__olang_check_failed(ptr @olang_loc_fe1d0d15a7f0c4e3_7c1e48fedf91487f)
  unreachable
bb112:
  %t330 = load i1, ptr %l14, !tbaa !21
  store i1 %t330, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietPieces(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l7 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l20 = alloca i1
  %l23 = alloca i1
  %l29 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Text", ptr %a1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb15
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l16, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  store ptr %t24, ptr %l5, !tbaa !29
  %t26 = load ptr, ptr %l5, !tbaa !29
  store ptr %t26, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t27 = load ptr, ptr %l19, !tbaa !29
  %t28 = icmp ne ptr %t27, null
  br i1 %t28, label %bb5, label %bb6
bb5:
  %t30 = load ptr, ptr %l19, !tbaa !29
  %t31 = load i64, ptr %t30, !range !{i64 0, i64 2}
  %t33 = icmp eq i64 %t31, 1
  store i1 %t33, ptr %l20, !tbaa !21
  br label %bb6
bb6:
  %t34 = load i1, ptr %l20, !tbaa !21
  br i1 %t34, label %bb7, label %bb8
bb7:
  %t35 = load ptr, ptr %l5, !tbaa !29
  %t37 = getelementptr { i64, [2 x i64] }, ptr %t35, i32 0, i32 1
  %t38 = getelementptr { ptr }, ptr %t37, i32 0, i32 0
  %t39 = load ptr, ptr %t38
  %t46 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietX(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %t39)
  store i1 %t46, ptr %l29
  br label %bb9
bb8:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb10
bb9:
  %t47 = load i1, ptr %l29, !tbaa !21
  %t48 = xor i1 %t47, true
  store i1 %t48, ptr %l23, !tbaa !21
  br label %bb10
bb10:
  %t50 = load i1, ptr %l23, !tbaa !21
  br i1 %t50, label %bb11, label %bb12
bb11:
  %t51 = load ptr, ptr %l5, !tbaa !29
  %t53 = getelementptr { i64, [2 x i64] }, ptr %t51, i32 0, i32 1
  %t54 = getelementptr { ptr }, ptr %t53, i32 0, i32 0
  %t55 = load ptr, ptr %t54
  store ptr %t55, ptr %l7, !tbaa !29
  store i1 false, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t58 = load i64, ptr %l3, !tbaa !24
  %t61 = add i64 %t58, 1
  store i64 %t61, ptr %l3, !tbaa !24
  br label %bb1
bb15:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l29 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l38 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l48 = alloca i1
  %l49 = alloca i1
  %l54 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i1
  %l64 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca i1
  %l74 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb13
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t11 = load ptr, ptr %l12, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l12, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 8}
  %t17 = icmp eq i64 %t15, 1
  store i1 %t17, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l13, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  %t19 = load ptr, ptr %l1, !tbaa !29
  store ptr %t19, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t20 = load ptr, ptr %l16, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb9, label %bb10
bb9:
  %t23 = load ptr, ptr %l16, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 8}
  %t26 = icmp eq i64 %t24, 7
  store i1 %t26, ptr %l17, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l17, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb54
bb14:
  %t28 = load ptr, ptr %l1, !tbaa !29
  store ptr %t28, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t29 = load ptr, ptr %l20, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb15, label %bb16
bb15:
  %t32 = load ptr, ptr %l20, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 8}
  %t35 = icmp eq i64 %t33, 2
  store i1 %t35, ptr %l21, !tbaa !21
  br label %bb16
bb16:
  %t36 = load i1, ptr %l21, !tbaa !21
  br i1 %t36, label %bb17, label %bb18
bb17:
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t39, i32 0, i32 2
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l2, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t48 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietX(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t43, ptr %t44)
  store i1 %t48, ptr %l29
  br label %bb20
bb20:
  %t49 = load i1, ptr %l29, !tbaa !21
  store i1 %t49, ptr %l7, !tbaa !21
  br label %bb54
bb21:
  %t50 = load ptr, ptr %l1, !tbaa !29
  store ptr %t50, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t51 = load ptr, ptr %l30, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb22, label %bb23
bb22:
  %t54 = load ptr, ptr %l30, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 8}
  %t57 = icmp eq i64 %t55, 3
  store i1 %t57, ptr %l31, !tbaa !21
  br label %bb23
bb23:
  %t58 = load i1, ptr %l31, !tbaa !21
  br i1 %t58, label %bb24, label %bb25
bb24:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr { i64, [4 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t61, i32 0, i32 2
  %t63 = load ptr, ptr %t62
  store ptr %t63, ptr %l3, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l3, !tbaa !29
  %t69 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t65, ptr %t66)
  store i1 %t69, ptr %l38
  br label %bb27
bb27:
  %t70 = load i1, ptr %l38, !tbaa !21
  store i1 %t70, ptr %l7, !tbaa !21
  br label %bb54
bb28:
  %t71 = load ptr, ptr %l1, !tbaa !29
  store ptr %t71, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t72 = load ptr, ptr %l39, !tbaa !29
  %t73 = icmp ne ptr %t72, null
  br i1 %t73, label %bb29, label %bb30
bb29:
  %t75 = load ptr, ptr %l39, !tbaa !29
  %t76 = load i64, ptr %t75, !range !{i64 0, i64 8}
  %t78 = icmp eq i64 %t76, 4
  store i1 %t78, ptr %l40, !tbaa !21
  br label %bb30
bb30:
  %t79 = load i1, ptr %l40, !tbaa !21
  br i1 %t79, label %bb31, label %bb32
bb31:
  %t80 = load ptr, ptr %l1, !tbaa !29
  %t82 = getelementptr { i64, [4 x i64] }, ptr %t80, i32 0, i32 1
  %t83 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t82, i32 0, i32 2
  %t84 = load ptr, ptr %t83
  store ptr %t84, ptr %l4, !tbaa !29
  br label %bb33
bb32:
  br label %bb39
bb33:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load ptr, ptr %l4, !tbaa !29
  %t89 = getelementptr %"compiler/typed:Elem", ptr %t87, i32 0, i32 0
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t93 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t86, ptr %t90)
  store i1 %t93, ptr %l48
  br label %bb34
bb34:
  %t94 = load i1, ptr %l48, !tbaa !21
  br i1 %t94, label %bb35, label %bb36
bb35:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load ptr, ptr %l4, !tbaa !29
  %t98 = getelementptr %"compiler/typed:Elem", ptr %t96, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t103 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietX(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t95, ptr %t99)
  store i1 %t103, ptr %l54
  br label %bb37
bb36:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb38
bb37:
  %t104 = load i1, ptr %l54, !tbaa !21
  store i1 %t104, ptr %l49, !tbaa !21
  br label %bb38
bb38:
  %t105 = load i1, ptr %l49, !tbaa !21
  store i1 %t105, ptr %l7, !tbaa !21
  br label %bb54
bb39:
  %t106 = load ptr, ptr %l1, !tbaa !29
  store ptr %t106, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t107 = load ptr, ptr %l55, !tbaa !29
  %t108 = icmp ne ptr %t107, null
  br i1 %t108, label %bb40, label %bb41
bb40:
  %t110 = load ptr, ptr %l55, !tbaa !29
  %t111 = load i64, ptr %t110, !range !{i64 0, i64 8}
  %t113 = icmp eq i64 %t111, 5
  store i1 %t113, ptr %l56, !tbaa !21
  br label %bb41
bb41:
  %t114 = load i1, ptr %l56, !tbaa !21
  br i1 %t114, label %bb42, label %bb43
bb42:
  %t115 = load ptr, ptr %l1, !tbaa !29
  %t117 = getelementptr { i64, [4 x i64] }, ptr %t115, i32 0, i32 1
  %t118 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t117, i32 0, i32 2
  %t119 = load ptr, ptr %t118
  store ptr %t119, ptr %l5, !tbaa !29
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load ptr, ptr %l5, !tbaa !29
  %t124 = getelementptr %"compiler/typed:Payload", ptr %t122, i32 0, i32 0
  %t125 = load ptr, ptr %t124, !tbaa !29
  %t128 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t121, ptr %t125)
  store i1 %t128, ptr %l64
  br label %bb45
bb45:
  %t129 = load i1, ptr %l64, !tbaa !21
  store i1 %t129, ptr %l7, !tbaa !21
  br label %bb54
bb46:
  %t130 = load ptr, ptr %l1, !tbaa !29
  store ptr %t130, ptr %l65, !tbaa !29
  store i1 false, ptr %l66, !tbaa !21
  %t131 = load ptr, ptr %l65, !tbaa !29
  %t132 = icmp ne ptr %t131, null
  br i1 %t132, label %bb47, label %bb48
bb47:
  %t134 = load ptr, ptr %l65, !tbaa !29
  %t135 = load i64, ptr %t134, !range !{i64 0, i64 8}
  %t137 = icmp eq i64 %t135, 6
  store i1 %t137, ptr %l66, !tbaa !21
  br label %bb48
bb48:
  %t138 = load i1, ptr %l66, !tbaa !21
  br i1 %t138, label %bb49, label %bb50
bb49:
  %t139 = load ptr, ptr %l1, !tbaa !29
  %t141 = getelementptr { i64, [4 x i64] }, ptr %t139, i32 0, i32 1
  %t142 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t141, i32 0, i32 2
  %t143 = load ptr, ptr %t142
  store ptr %t143, ptr %l6, !tbaa !29
  br label %bb51
bb50:
  br label %bb53
bb51:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load ptr, ptr %l6, !tbaa !29
  %t150 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietX(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t145, ptr %t146)
  store i1 %t150, ptr %l74
  br label %bb52
bb52:
  %t151 = load i1, ptr %l74, !tbaa !21
  store i1 %t151, ptr %l7, !tbaa !21
  br label %bb54
bb53:
  call void @__olang_check_failed(ptr @olang_loc_43c562ec71e00848_102dc0f053e29474)
  unreachable
bb54:
  %t152 = load i1, ptr %l7, !tbaa !21
  store i1 %t152, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietStore(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca i1
  %l16 = alloca i1
  %l23 = alloca ptr
  %l25 = alloca i32
  %l27 = alloca i1
  %l28 = alloca i1
  %l30 = alloca i32
  %l33 = alloca i1
  %l34 = alloca ptr
  %l36 = alloca i32
  %l38 = alloca i1
  %l48 = alloca i64
  %l53 = alloca i32
  %l57 = alloca i1
  %l60 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t7 = load ptr, ptr %l12, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l12, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 8}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l13, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l13, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [4 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t17, i32 0, i32 0
  %t19 = load %"compiler/source:Span", ptr %t18
  store %"compiler/source:Span" %t19, ptr %l3
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [4 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t23, i32 0, i32 1
  %t25 = load i32, ptr %t24
  store i32 %t25, ptr %l4, !tbaa !23
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr { i64, [4 x i64] }, ptr %t27, i32 0, i32 1
  %t30 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t29, i32 0, i32 2
  %t31 = load i32, ptr %t30
  store i32 %t31, ptr %l5, !tbaa !23
  %t33 = load ptr, ptr %l2, !tbaa !29
  store ptr %t33, ptr %l23, !tbaa !29
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t34)
  store i32 %t36, ptr %l25
  br label %bb5
bb4:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb16
bb5:
  %t37 = load ptr, ptr %l23, !tbaa !29
  %t38 = call ptr @__olang_scope_or(ptr %v2, ptr %t37)
  %t39 = call ptr @__olang_scope_hold(ptr %t38)
  %t40 = ptrtoint ptr %t39 to i64
  %t42 = inttoptr i64 %t40 to ptr
  %t43 = load ptr, ptr %l23, !tbaa !29
  %t44 = load i32, ptr %l25, !tbaa !23
  %t45 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %t42, ptr %t43, i32 %t44)
  store i1 %t45, ptr %l27
  br label %bb6
bb6:
  %t46 = load i1, ptr %l27, !tbaa !21
  br i1 %t46, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb10
bb8:
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t47)
  store i32 %t49, ptr %l30
  br label %bb9
bb9:
  %t50 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t51 = load i32, ptr %l30, !tbaa !23
  %t53 = icmp eq i32 %t51, %t50
  store i1 %t53, ptr %l28, !tbaa !21
  br label %bb10
bb10:
  %t55 = load i1, ptr %l28, !tbaa !21
  br i1 %t55, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb15
bb12:
  %t56 = load ptr, ptr %l2, !tbaa !29
  store ptr %t56, ptr %l34, !tbaa !29
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t57)
  store i32 %t59, ptr %l36
  br label %bb13
bb13:
  %t60 = load ptr, ptr %l34, !tbaa !29
  %t61 = call ptr @__olang_scope_or(ptr %v2, ptr %t60)
  %t62 = call ptr @__olang_scope_hold(ptr %t61)
  %t63 = ptrtoint ptr %t62 to i64
  %t65 = inttoptr i64 %t63 to ptr
  %t66 = load ptr, ptr %l34, !tbaa !29
  %t67 = load i32, ptr %l36, !tbaa !23
  %t68 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t65, ptr %t66, i32 %t67)
  store i1 %t68, ptr %l38
  br label %bb14
bb14:
  %t69 = load i1, ptr %l38, !tbaa !21
  store i1 %t69, ptr %l33, !tbaa !21
  br label %bb15
bb15:
  %t70 = load i1, ptr %l33, !tbaa !21
  store i1 %t70, ptr %l16, !tbaa !21
  br label %bb16
bb16:
  %t71 = load i1, ptr %l16, !tbaa !21
  br i1 %t71, label %bb17, label %bb18
bb17:
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t74 = getelementptr { i64, [4 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t74, i32 0, i32 0
  %t76 = load %"compiler/source:Span", ptr %t75
  store %"compiler/source:Span" %t76, ptr %l6
  %t78 = load ptr, ptr %l1, !tbaa !29
  %t80 = getelementptr { i64, [4 x i64] }, ptr %t78, i32 0, i32 1
  %t81 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t80, i32 0, i32 1
  %t82 = load i32, ptr %t81
  store i32 %t82, ptr %l7, !tbaa !23
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t86 = getelementptr { i64, [4 x i64] }, ptr %t84, i32 0, i32 1
  %t87 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t86, i32 0, i32 2
  %t88 = load i32, ptr %t87
  store i32 %t88, ptr %l8, !tbaa !23
  store i1 true, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/lower:lowering", ptr %t91, i32 0, i32 71
  %t95 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eLen_3cI64_2c_20Bool_3e(ptr %v0, ptr %t93)
  store i64 %t95, ptr %l48
  br label %bb20
bb20:
  %t96 = load i64, ptr %l48, !tbaa !24
  %t97 = icmp eq i64 %t96, 0
  br i1 %t97, label %bb21, label %bb22
bb21:
  store i1 false, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t104 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2eobjectOf(ptr %v0, ptr %v1, ptr %t100, ptr %t101)
  store i32 %t104, ptr %l53
  br label %bb24
bb24:
  %t105 = load i32, ptr %l53, !tbaa !23
  store i32 %t105, ptr %l9, !tbaa !23
  %t106 = load i32, ptr %l9, !tbaa !23
  %t107 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t110 = icmp ne i32 %t106, %t107
  br i1 %t110, label %bb25, label %bb26
bb25:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load i32, ptr %l9, !tbaa !23
  %t116 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eobjHits(ptr %v0, ptr %v2, ptr %t112, i32 %t113)
  store i1 %t116, ptr %l60
  br label %bb27
bb26:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb28
bb27:
  %t117 = load i1, ptr %l60, !tbaa !21
  %t118 = xor i1 %t117, true
  store i1 %t118, ptr %l57, !tbaa !21
  br label %bb28
bb28:
  %t120 = load i1, ptr %l57, !tbaa !21
  store i1 %t120, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ereadDtor(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca ptr
  %l6 = alloca i64
  %l9 = alloca ptr
  %l11 = alloca ptr
  %l14 = alloca i32
  %l16 = alloca i64
  %l17 = alloca i32
  %l21 = alloca ptr
  %t66 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = call ptr @__olang_scope_or(ptr %v1, ptr %t5)
  %t7 = call ptr @__olang_scope_hold(ptr %t6)
  %t8 = ptrtoint ptr %t7 to i64
  %t10 = inttoptr i64 %t8 to ptr
  %t11 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eindex(ptr %t10, ptr %t11)
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lower:lowering", ptr %t12, i32 0, i32 0
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/lower:Lowerer", ptr %t15, i32 0, i32 26
  store ptr %t17, ptr %l9, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/lower:lowering", ptr %t18, i32 0, i32 2
  %t21 = load ptr, ptr %t20, !tbaa !29
  store ptr %t21, ptr %l11, !tbaa !29
  %t23 = load ptr, ptr %l11, !tbaa !29
  %t24 = call ptr @__olang_scope_or(ptr %v2, ptr %t23)
  %t25 = call ptr @__olang_scope_hold(ptr %t24)
  %t26 = ptrtoint ptr %t25 to i64
  %t28 = inttoptr i64 %t26 to ptr
  %t29 = load ptr, ptr %l11, !tbaa !29
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t28, ptr %t29, i32 %a1)
  store i32 %t31, ptr %l14
  br label %bb2
bb2:
  %t32 = load ptr, ptr %l9, !tbaa !29
  %t33 = call ptr @__olang_scope_or(ptr %v1, ptr %t32)
  %t34 = call ptr @__olang_scope_hold(ptr %t33)
  %t35 = ptrtoint ptr %t34 to i64
  %t37 = inttoptr i64 %t35 to ptr
  %t38 = load ptr, ptr %l9, !tbaa !29
  %t39 = load i32, ptr %l14, !tbaa !23
  %t40 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %t37, ptr %t38, i32 %t39)
  %t41 = extractvalue { i32, i64 } %t40, 1
  %t42 = extractvalue { i32, i64 } %t40, 0
  store i32 %t42, ptr %l17
  %t43 = icmp ne i32 %t42, 0
  br i1 %t43, label %bb4, label %ok.44, !prof !99
ok.44:
  store i64 %t41, ptr %l16
  br label %bb3
bb3:
  %t45 = load i64, ptr %l16, !tbaa !24
  store i64 %t45, ptr %l6, !tbaa !24
  br label %bb6
bb4:
  br label %bb5
bb5:
  store i64 -1, ptr %l6, !tbaa !24
  br label %bb6
bb6:
  %t46 = load i64, ptr %l6, !tbaa !24
  store i64 %t46, ptr %l2, !tbaa !24
  %t47 = load i64, ptr %l2, !tbaa !24
  %t49 = icmp sge i64 %t47, 0
  br i1 %t49, label %bb7, label %bb8
bb7:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/lower:lowering", ptr %t51, i32 0, i32 0
  %t54 = load ptr, ptr %t53, !tbaa !29
  store ptr %t54, ptr %l21, !tbaa !29
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/lower:lowering", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Body", ptr %t58, i32 0, i32 3
  %t61 = load i64, ptr %t60, !tbaa !24
  %t62 = load i64, ptr %l2, !tbaa !24
  %t64 = trunc i64 %t62 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t66
  %t67 = getelementptr { i64, [2 x i64] }, ptr %t66, i32 0, i32 0
  store i64 0, ptr %t67
  %t69 = insertvalue { i32 } undef, i32 %t64, 0
  %t70 = getelementptr { i64, [2 x i64] }, ptr %t66, i32 0, i32 1
  store { i32 } %t69, ptr %t70
  %t71 = load { i64, [2 x i64] }, ptr %t66
  %t72 = load ptr, ptr %l21, !tbaa !29
  %t73 = call ptr @__olang_scope_or(ptr %v1, ptr %t72)
  %t74 = call ptr @__olang_scope_hold(ptr %t73)
  %t75 = ptrtoint ptr %t74 to i64
  %t77 = inttoptr i64 %t75 to ptr
  %t78 = load ptr, ptr %l21, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eReadDerived(ptr %t77, ptr %t78, i64 %t61, { i64, [2 x i64] } %t71)
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ereadPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l4, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l4, !tbaa !29
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t19 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ereadPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %t16, ptr %t17, ptr %t18, ptr %t19)
  br label %bb6
bb6:
  br label %bb33
bb7:
  %t24 = load ptr, ptr %l1, !tbaa !29
  store ptr %t24, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t25 = load ptr, ptr %l18, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb8, label %bb9
bb8:
  %t28 = load ptr, ptr %l18, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 8}
  %t31 = icmp eq i64 %t29, 5
  store i1 %t31, ptr %l19, !tbaa !21
  br label %bb9
bb9:
  %t32 = load i1, ptr %l19, !tbaa !21
  br i1 %t32, label %bb10, label %bb11
bb10:
  %t33 = load ptr, ptr %l1, !tbaa !29
  %t35 = getelementptr { i64, [4 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t35, i32 0, i32 2
  %t37 = load ptr, ptr %t36
  store ptr %t37, ptr %l5, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load ptr, ptr %l5, !tbaa !29
  %t42 = getelementptr %"compiler/typed:Payload", ptr %t40, i32 0, i32 0
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t45 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ereadPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %t39, ptr %t43, ptr %t44, ptr %t45)
  br label %bb13
bb13:
  br label %bb33
bb14:
  %t50 = load ptr, ptr %l1, !tbaa !29
  store ptr %t50, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t51 = load ptr, ptr %l29, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb15, label %bb16
bb15:
  %t54 = load ptr, ptr %l29, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 8}
  %t57 = icmp eq i64 %t55, 4
  store i1 %t57, ptr %l30, !tbaa !21
  br label %bb16
bb16:
  %t58 = load i1, ptr %l30, !tbaa !21
  br i1 %t58, label %bb17, label %bb18
bb17:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr { i64, [4 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t61, i32 0, i32 2
  %t63 = load ptr, ptr %t62
  store ptr %t63, ptr %l6, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l6, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Elem", ptr %t66, i32 0, i32 0
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t70 = load ptr, ptr %l2, !tbaa !29
  %t71 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ereadPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %t65, ptr %t69, ptr %t70, ptr %t71)
  br label %bb20
bb20:
  br label %bb33
bb21:
  %t76 = load ptr, ptr %l1, !tbaa !29
  store ptr %t76, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t77 = load ptr, ptr %l40, !tbaa !29
  %t78 = icmp ne ptr %t77, null
  br i1 %t78, label %bb22, label %bb23
bb22:
  %t80 = load ptr, ptr %l40, !tbaa !29
  %t81 = load i64, ptr %t80, !range !{i64 0, i64 8}
  %t83 = icmp eq i64 %t81, 6
  store i1 %t83, ptr %l41, !tbaa !21
  br label %bb23
bb23:
  %t84 = load i1, ptr %l41, !tbaa !21
  br i1 %t84, label %bb24, label %bb25
bb24:
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr { i64, [4 x i64] }, ptr %t85, i32 0, i32 1
  %t88 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t87, i32 0, i32 2
  %t89 = load ptr, ptr %t88
  store ptr %t89, ptr %l7, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l7, !tbaa !29
  %t93 = load ptr, ptr %l2, !tbaa !29
  %t94 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ereadHere(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %t91, ptr %t92, ptr %t93, ptr %t94)
  br label %bb27
bb27:
  br label %bb33
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_15f99fcbd43babda_53e78f535034c6)
  unreachable
bb33:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eregionCopy(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, i64 %a3, { i64, [1 x i64] } %a4, %"compiler/source:Span" %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/lower:pl"
  %l2 = alloca i32
  %l4 = alloca { i64, [1 x i64] }
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca i32
  %l11 = alloca i64
  %l21 = alloca ptr
  %l24 = alloca i1
  %l25 = alloca i1
  %l27 = alloca ptr
  %l30 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca %"compiler/lower:pl"
  %l35 = alloca %"compiler/lower:pl"
  %l39 = alloca ptr
  %l40 = alloca %"compiler/lower:pl"
  %l42 = alloca %"compiler/lower:pl"
  %l49 = alloca i32
  %l57 = alloca ptr
  %l58 = alloca %"compiler/lower:pl"
  %l60 = alloca %"compiler/lower:pl"
  %l67 = alloca i32
  %l71 = alloca i32
  %l73 = alloca ptr
  %l74 = alloca %"compiler/source:Span"
  %l75 = alloca i32
  %l76 = alloca ptr
  %l77 = alloca %"compiler/lower:pl"
  %l79 = alloca %"compiler/lower:pl"
  %l80 = alloca %"compiler/mir:Lvalue"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %t95 = alloca { i64, [15 x i64] }, align 8
  %t115 = alloca { i64, [1 x i64] }, align 8
  %t152 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/lower:pl" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, [1 x i64] } %a4, ptr %l4
  store %"compiler/source:Span" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2eguardOf(ptr %v0, ptr %v2, ptr %v3, ptr %t1, i64 %a3)
  store i64 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i64, ptr %l11, !tbaa !24
  store i64 %t6, ptr %l6, !tbaa !24
  %t7 = load i64, ptr %l6, !tbaa !24
  %t8 = load i64, ptr @G_2ecompiler_2ffree_2eNotSole, !tbaa !24
  %t11 = icmp eq i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/lower:lowering", ptr %t13, i32 0, i32 0
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/lower:Lowerer", ptr %t16, i32 0, i32 12
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = icmp eq ptr %t19, null
  br i1 %t21, label %bb4, label %bb5
bb3:
  br label %bb19
bb4:
  call void @__olang_check_failed(ptr @olang_loc_47d4f023ba03b097_5ff9e48511238993)
  unreachable
bb5:
  br label %bb6
bb6:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/lower:lowering", ptr %t23, i32 0, i32 0
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/lower:Lowerer", ptr %t26, i32 0, i32 12
  %t29 = load ptr, ptr %t28, !tbaa !29
  store ptr %t29, ptr %l21, !tbaa !29
  %t30 = load i32, ptr %l2, !tbaa !23
  %t31 = load ptr, ptr %l21, !tbaa !29
  %t32 = call ptr @__olang_scope_or(ptr %v2, ptr %t31)
  %t33 = call ptr @__olang_scope_hold(ptr %t32)
  %t34 = ptrtoint ptr %t33 to i64
  %t36 = inttoptr i64 %t34 to ptr
  %t37 = load ptr, ptr %l21, !tbaa !29
  %t39 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ePartsOnly(ptr %t36, ptr %t37, i32 %t30)
  store i1 %t39, ptr %l24
  br label %bb7
bb7:
  %t40 = load i1, ptr %l24, !tbaa !21
  br i1 %t40, label %bb8, label %bb9
bb8:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/lower:lowering", ptr %t41, i32 0, i32 2
  %t44 = load ptr, ptr %t43, !tbaa !29
  store ptr %t44, ptr %l27, !tbaa !29
  %t45 = load i32, ptr %l2, !tbaa !23
  %t46 = load ptr, ptr %l27, !tbaa !29
  %t47 = call ptr @__olang_scope_or(ptr %v3, ptr %t46)
  %t48 = call ptr @__olang_scope_hold(ptr %t47)
  %t49 = ptrtoint ptr %t48 to i64
  %t51 = inttoptr i64 %t49 to ptr
  %t52 = load ptr, ptr %l27, !tbaa !29
  %t54 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRunsCopy(ptr %t51, ptr %t52, i32 %t45)
  store i1 %t54, ptr %l30
  br label %bb10
bb9:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb11
bb10:
  %t55 = load i1, ptr %l30, !tbaa !21
  %t56 = xor i1 %t55, true
  store i1 %t56, ptr %l25, !tbaa !21
  br label %bb11
bb11:
  %t58 = load i1, ptr %l25, !tbaa !21
  br i1 %t58, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l32, !tbaa !29
  %t60 = load %"compiler/lower:pl", ptr %l1
  store %"compiler/lower:pl" %t60, ptr %l33
  %t62 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s2, ptr %l33)
  store %"compiler/lower:pl" %t62, ptr %l35
  br label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l39, !tbaa !29
  %t64 = load %"compiler/lower:pl", ptr %l1
  store %"compiler/lower:pl" %t64, ptr %l40
  %t66 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s3, ptr %l40)
  store %"compiler/lower:pl" %t66, ptr %l42
  br label %bb16
bb14:
  %t67 = load i32, ptr %l2, !tbaa !23
  %t68 = load { i64, [1 x i64] }, ptr %l4
  %t69 = load %"compiler/source:Span", ptr %l5
  %t70 = load ptr, ptr %l32, !tbaa !29
  %t71 = load %"compiler/lower:pl", ptr %l35
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2epartsCopied(ptr %v0, ptr %s2, ptr %v3, ptr %v2, ptr %t70, %"compiler/lower:pl" %t71, i32 %t67, { i64, [1 x i64] } %t68, %"compiler/source:Span" %t69)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb16:
  %t75 = load i32, ptr %l2, !tbaa !23
  %t76 = load { i64, [1 x i64] }, ptr %l4
  %t77 = load %"compiler/source:Span", ptr %l5
  %t78 = load ptr, ptr %l39, !tbaa !29
  %t79 = load %"compiler/lower:pl", ptr %l42
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ecopyPart(ptr %v0, ptr %s3, ptr %v3, ptr %v2, ptr %t78, %"compiler/lower:pl" %t79, i32 %t75, { i64, [1 x i64] } %t76, %"compiler/source:Span" %t77)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb19:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t85 = load %"compiler/source:Span", ptr %l5
  %t89 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t83, i32 %t84, %"compiler/source:Span" %t85)
  store i32 %t89, ptr %l49
  br label %bb20
bb20:
  %t90 = load i32, ptr %l49, !tbaa !23
  store i32 %t90, ptr %l7, !tbaa !23
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load i32, ptr %l7, !tbaa !23
  %t93 = load i64, ptr %l6, !tbaa !24
  %t94 = load { i64, [1 x i64] }, ptr %l4
  store { i64, [15 x i64] } zeroinitializer, ptr %t95
  %t96 = getelementptr { i64, [15 x i64] }, ptr %t95, i32 0, i32 0
  store i64 13, ptr %t96
  %t98 = insertvalue { { i64, [1 x i64] } } undef, { i64, [1 x i64] } %t94, 0
  %t99 = getelementptr { i64, [15 x i64] }, ptr %t95, i32 0, i32 1
  store { { i64, [1 x i64] } } %t98, ptr %t99
  %t100 = load { i64, [15 x i64] }, ptr %t95
  %t101 = load { i64, [1 x i64] }, ptr %l4
  %t102 = load %"compiler/source:Span", ptr %l5
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eguarded(ptr %v0, ptr %v3, ptr %v2, ptr %t91, i32 %t92, i64 %t93, { i64, [15 x i64] } %t100, { i64, [1 x i64] } %t101, %"compiler/source:Span" %t102)
  br label %bb21
bb21:
  %t109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t109, ptr %l57, !tbaa !29
  %t110 = load %"compiler/lower:pl", ptr %l1
  store %"compiler/lower:pl" %t110, ptr %l58
  %t112 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s0, ptr %l58)
  store %"compiler/lower:pl" %t112, ptr %l60
  br label %bb22
bb22:
  %t113 = load i32, ptr %l2, !tbaa !23
  %t114 = load i32, ptr %l7, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t115
  %t116 = getelementptr { i64, [1 x i64] }, ptr %t115, i32 0, i32 0
  store i64 4, ptr %t116
  %t118 = insertvalue { i32 } undef, i32 %t114, 0
  %t119 = getelementptr { i64, [1 x i64] }, ptr %t115, i32 0, i32 1
  store { i32 } %t118, ptr %t119
  %t120 = load { i64, [1 x i64] }, ptr %t115
  %t121 = load %"compiler/source:Span", ptr %l5
  %t122 = load ptr, ptr %l57, !tbaa !29
  %t123 = load %"compiler/lower:pl", ptr %l60
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ecopyPart(ptr %v0, ptr %s0, ptr %v3, ptr %v2, ptr %t122, %"compiler/lower:pl" %t123, i32 %t113, { i64, [1 x i64] } %t120, %"compiler/source:Span" %t121)
  br label %bb23
bb23:
  %t127 = load i64, ptr %l6, !tbaa !24
  %t129 = icmp sge i64 %t127, 0
  br i1 %t129, label %bb24, label %bb25
bb24:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load i64, ptr %l6, !tbaa !24
  %t133 = load %"compiler/source:Span", ptr %l5
  %t137 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2ewhenSole(ptr %v0, ptr %v3, ptr %v2, ptr %t131, i64 %t132, i1 true, %"compiler/source:Span" %t133)
  store i32 %t137, ptr %l71
  br label %bb26
bb25:
  %t138 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  store i32 %t138, ptr %l67, !tbaa !23
  br label %bb27
bb26:
  %t140 = load i32, ptr %l71, !tbaa !23
  store i32 %t140, ptr %l67, !tbaa !23
  br label %bb27
bb27:
  %t141 = load i32, ptr %l67, !tbaa !23
  store i32 %t141, ptr %l8, !tbaa !23
  %t142 = load ptr, ptr %l0, !tbaa !29
  store ptr %t142, ptr %l73, !tbaa !29
  %t143 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t143, ptr %l74
  %t144 = load i32, ptr %l7, !tbaa !23
  store i32 %t144, ptr %l75, !tbaa !23
  %t145 = load ptr, ptr %l0, !tbaa !29
  store ptr %t145, ptr %l76, !tbaa !29
  %t146 = load %"compiler/lower:pl", ptr %l1
  store %"compiler/lower:pl" %t146, ptr %l77
  %t148 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s0, ptr %l77)
  store %"compiler/lower:pl" %t148, ptr %l79
  br label %bb28
bb28:
  %t149 = load ptr, ptr %l76, !tbaa !29
  %t150 = load %"compiler/lower:pl", ptr %l79
  %t151 = call %"compiler/mir:Lvalue" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %s0, ptr %v2, ptr %t149, %"compiler/lower:pl" %t150)
  store %"compiler/mir:Lvalue" %t151, ptr %l80
  br label %bb29
bb29:
  store { i64, [21 x i64] } zeroinitializer, ptr %t152
  %t153 = getelementptr { i64, [21 x i64] }, ptr %t152, i32 0, i32 0
  store i64 9, ptr %t153
  %t154 = load %"compiler/source:Span", ptr %l74
  %t155 = insertvalue { %"compiler/source:Span", i32, %"compiler/mir:Lvalue" } undef, %"compiler/source:Span" %t154, 0
  %t156 = load i32, ptr %l75, !tbaa !23
  %t157 = insertvalue { %"compiler/source:Span", i32, %"compiler/mir:Lvalue" } %t155, i32 %t156, 1
  %t158 = load %"compiler/mir:Lvalue", ptr %l80
  %t159 = insertvalue { %"compiler/source:Span", i32, %"compiler/mir:Lvalue" } %t157, %"compiler/mir:Lvalue" %t158, 2
  %t160 = getelementptr { i64, [21 x i64] }, ptr %t152, i32 0, i32 1
  store { %"compiler/source:Span", i32, %"compiler/mir:Lvalue" } %t159, ptr %t160
  %t161 = load { i64, [21 x i64] }, ptr %t152
  %t163 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t161, ptr %t163
  %t164 = load ptr, ptr %l73, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %v3, ptr %v2, ptr %t164, ptr %t163)
  br label %bb30
bb30:
  %t166 = load i32, ptr %l8, !tbaa !23
  %t167 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t170 = icmp ne i32 %t166, %t167
  br i1 %t170, label %bb31, label %bb32
bb31:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load i32, ptr %l8, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ejoinAt(ptr %v0, ptr %v2, ptr %v3, ptr %t172, i32 %t173)
  br label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eregionMade(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l8 = alloca i64
  %l12 = alloca i1
  %l16 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l22 = alloca i1
  %l46 = alloca i1
  %l53 = alloca i1
  %l56 = alloca { i64, ptr }
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 39
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb3
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/lower:lowering", ptr %t8, i32 0, i32 29
  %t11 = load i1, ptr %t10, !tbaa !21
  %t13 = xor i1 %t11, true
  store i1 %t13, ptr %l12, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l12, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb8
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t17 = load ptr, ptr %l17, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l17, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 18}
  %t23 = icmp eq i64 %t21, 7
  store i1 %t23, ptr %l18, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l18, !tbaa !21
  %t25 = xor i1 %t24, true
  store i1 %t25, ptr %l16, !tbaa !21
  br label %bb8
bb8:
  %t27 = load i1, ptr %l16, !tbaa !21
  br i1 %t27, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb11
bb10:
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t30, i32 0, i32 0
  %t32 = load %"compiler/source:Span", ptr %t31
  store %"compiler/source:Span" %t32, ptr %l2
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr { i64, [5 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t36, i32 0, i32 1
  %t38 = load i32, ptr %t37
  store i32 %t38, ptr %l3, !tbaa !23
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr { i64, [5 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t42, i32 0, i32 2
  %t44 = load ptr, ptr %t43
  store ptr %t44, ptr %l4, !tbaa !29
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/lower:lowering", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/typed:Body", ptr %t49, i32 0, i32 1
  %t52 = load { i64, [2 x i64] }, ptr %t51
  %t54 = extractvalue { i64, [2 x i64] } %t52, 0
  %t55 = icmp eq i64 %t54, 6
  store i1 %t55, ptr %l22, !tbaa !21
  br label %bb11
bb11:
  %t57 = load i1, ptr %l22, !tbaa !21
  br i1 %t57, label %bb12, label %bb13
bb12:
  store i1 false, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr { i64, [5 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t61, i32 0, i32 0
  %t63 = load %"compiler/source:Span", ptr %t62
  store %"compiler/source:Span" %t63, ptr %l5
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = getelementptr { i64, [5 x i64] }, ptr %t65, i32 0, i32 1
  %t68 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t67, i32 0, i32 1
  %t69 = load i32, ptr %t68
  store i32 %t69, ptr %l6, !tbaa !23
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t73 = getelementptr { i64, [5 x i64] }, ptr %t71, i32 0, i32 1
  %t74 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t73, i32 0, i32 2
  %t75 = load ptr, ptr %t74
  %t80 = getelementptr %"compiler/typed:Make", ptr %t75, i32 0, i32 4
  %t81 = load i32, ptr %t80, !tbaa !23
  %t83 = sext i32 %t81 to i64
  store i64 %t83, ptr %l8, !tbaa !24
  %t85 = load i64, ptr %l8, !tbaa !24
  %t87 = icmp sge i64 %t85, 0
  br i1 %t87, label %bb15, label %bb16
bb15:
  %t89 = load i64, ptr %l8, !tbaa !24
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/lower:lowering", ptr %t90, i32 0, i32 38
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t95 = getelementptr %"compiler/typed:Plan", ptr %t93, i32 0, i32 0
  %t96 = load { i64, ptr }, ptr %t95, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t96, 0
  %t101 = icmp slt i64 %t89, %t98
  store i1 %t101, ptr %l46, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb17
bb17:
  %t103 = load i1, ptr %l46, !tbaa !21
  br i1 %t103, label %bb18, label %bb19
bb18:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/lower:lowering", ptr %t104, i32 0, i32 38
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t109 = getelementptr %"compiler/typed:Plan", ptr %t107, i32 0, i32 0
  %t110 = load { i64, ptr }, ptr %t109, !tbaa !27
  store { i64, ptr } %t110, ptr %l56, !tbaa !27
  %t111 = load i64, ptr %l8, !tbaa !24
  %t113 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr { i64, [2 x i64] }, ptr %t114, i64 %t111
  %t116 = load { i64, [2 x i64] }, ptr %t115
  %t118 = extractvalue { i64, [2 x i64] } %t116, 0
  %t119 = icmp eq i64 %t118, 4
  store i1 %t119, ptr %l53, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb20
bb20:
  %t121 = load i1, ptr %l53, !tbaa !21
  store i1 %t121, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2flower_2ecompiler_2flower_3alowering_2eregionSite(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca i1
  %l60 = alloca i1
  %l67 = alloca i1
  %l70 = alloca { i64, ptr }
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 29
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i64 -1, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l1, !tbaa !29
  store ptr %t9, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t10 = load ptr, ptr %l13, !tbaa !29
  %t11 = icmp ne ptr %t10, null
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t13 = load ptr, ptr %l13, !tbaa !29
  %t14 = load i64, ptr %t13, !range !{i64 0, i64 18}
  %t16 = icmp eq i64 %t14, 5
  store i1 %t16, ptr %l14, !tbaa !21
  br label %bb5
bb5:
  %t17 = load i1, ptr %l14, !tbaa !21
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr { i64, [5 x i64] }, ptr %t18, i32 0, i32 1
  %t21 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t20, i32 0, i32 2
  %t22 = load ptr, ptr %t21
  store ptr %t22, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Promote", ptr %t24, i32 0, i32 1
  %t27 = load i32, ptr %t26, !tbaa !23
  %t29 = sext i32 %t27 to i64
  store i64 %t29, ptr %l12, !tbaa !24
  br label %bb38
bb9:
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t32 = load ptr, ptr %l22, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb10, label %bb11
bb10:
  %t35 = load ptr, ptr %l22, !tbaa !29
  %t36 = load i64, ptr %t35, !range !{i64 0, i64 18}
  %t38 = icmp eq i64 %t36, 7
  store i1 %t38, ptr %l23, !tbaa !21
  br label %bb11
bb11:
  %t39 = load i1, ptr %l23, !tbaa !21
  br i1 %t39, label %bb12, label %bb13
bb12:
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr { i64, [5 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t42, i32 0, i32 2
  %t44 = load ptr, ptr %t43
  store ptr %t44, ptr %l3, !tbaa !29
  br label %bb14
bb13:
  br label %bb15
bb14:
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t48 = getelementptr %"compiler/typed:Make", ptr %t46, i32 0, i32 4
  %t49 = load i32, ptr %t48, !tbaa !23
  %t51 = sext i32 %t49 to i64
  store i64 %t51, ptr %l12, !tbaa !24
  br label %bb38
bb15:
  %t53 = load ptr, ptr %l1, !tbaa !29
  store ptr %t53, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t54 = load ptr, ptr %l31, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb16, label %bb17
bb16:
  %t57 = load ptr, ptr %l31, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 18}
  %t60 = icmp eq i64 %t58, 16
  store i1 %t60, ptr %l32, !tbaa !21
  br label %bb17
bb17:
  %t61 = load i1, ptr %l32, !tbaa !21
  br i1 %t61, label %bb18, label %bb19
bb18:
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr { i64, [5 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t64, i32 0, i32 2
  %t66 = load ptr, ptr %t65
  store ptr %t66, ptr %l4, !tbaa !29
  br label %bb20
bb19:
  br label %bb21
bb20:
  %t68 = load ptr, ptr %l4, !tbaa !29
  %t70 = getelementptr %"compiler/typed:Text", ptr %t68, i32 0, i32 1
  %t71 = load i32, ptr %t70, !tbaa !23
  %t73 = sext i32 %t71 to i64
  store i64 %t73, ptr %l12, !tbaa !24
  br label %bb38
bb21:
  %t75 = load ptr, ptr %l1, !tbaa !29
  store ptr %t75, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t76 = load ptr, ptr %l40, !tbaa !29
  %t77 = icmp ne ptr %t76, null
  br i1 %t77, label %bb22, label %bb23
bb22:
  %t79 = load ptr, ptr %l40, !tbaa !29
  %t80 = load i64, ptr %t79, !range !{i64 0, i64 18}
  %t82 = icmp eq i64 %t80, 8
  store i1 %t82, ptr %l41, !tbaa !21
  br label %bb23
bb23:
  %t83 = load i1, ptr %l41, !tbaa !21
  br i1 %t83, label %bb24, label %bb25
bb24:
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t86 = getelementptr { i64, [5 x i64] }, ptr %t84, i32 0, i32 1
  %t87 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t86, i32 0, i32 2
  %t88 = load ptr, ptr %t87
  store ptr %t88, ptr %l5, !tbaa !29
  br label %bb26
bb25:
  br label %bb27
bb26:
  %t90 = load ptr, ptr %l5, !tbaa !29
  %t92 = getelementptr %"compiler/typed:Collect", ptr %t90, i32 0, i32 2
  %t93 = load i32, ptr %t92, !tbaa !23
  %t95 = sext i32 %t93 to i64
  store i64 %t95, ptr %l12, !tbaa !24
  br label %bb38
bb27:
  %t97 = load ptr, ptr %l1, !tbaa !29
  store ptr %t97, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t98 = load ptr, ptr %l49, !tbaa !29
  %t99 = icmp ne ptr %t98, null
  br i1 %t99, label %bb28, label %bb29
bb28:
  %t101 = load ptr, ptr %l49, !tbaa !29
  %t102 = load i64, ptr %t101, !range !{i64 0, i64 18}
  %t104 = icmp eq i64 %t102, 6
  store i1 %t104, ptr %l50, !tbaa !21
  br label %bb29
bb29:
  %t105 = load i1, ptr %l50, !tbaa !21
  br i1 %t105, label %bb30, label %bb31
bb30:
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr { i64, [5 x i64] }, ptr %t106, i32 0, i32 1
  %t109 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t108, i32 0, i32 2
  %t110 = load ptr, ptr %t109
  store ptr %t110, ptr %l6, !tbaa !29
  br label %bb32
bb31:
  br label %bb33
bb32:
  %t112 = load ptr, ptr %l6, !tbaa !29
  %t114 = getelementptr %"compiler/typed:Call", ptr %t112, i32 0, i32 2
  %t115 = load i32, ptr %t114, !tbaa !23
  %t117 = sext i32 %t115 to i64
  store i64 %t117, ptr %l12, !tbaa !24
  br label %bb38
bb33:
  br i1 true, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  store i64 -1, ptr %l12, !tbaa !24
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_5f06e436ba25f30_8078c3a4dcac4c4)
  unreachable
bb38:
  %t119 = load i64, ptr %l12, !tbaa !24
  store i64 %t119, ptr %l7, !tbaa !24
  %t120 = load i64, ptr %l7, !tbaa !24
  %t122 = icmp slt i64 %t120, 0
  br i1 %t122, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb41
bb40:
  %t124 = load i64, ptr %l7, !tbaa !24
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/lower:lowering", ptr %t125, i32 0, i32 38
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t130 = getelementptr %"compiler/typed:Plan", ptr %t128, i32 0, i32 6
  %t131 = load { i64, ptr }, ptr %t130, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t131, 0
  %t136 = icmp sge i64 %t124, %t133
  store i1 %t136, ptr %l60, !tbaa !21
  br label %bb41
bb41:
  %t138 = load i1, ptr %l60, !tbaa !21
  br i1 %t138, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb44
bb43:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/lower:lowering", ptr %t139, i32 0, i32 38
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t144 = getelementptr %"compiler/typed:Plan", ptr %t142, i32 0, i32 6
  %t145 = load { i64, ptr }, ptr %t144, !tbaa !27
  store { i64, ptr } %t145, ptr %l70, !tbaa !27
  %t146 = load i64, ptr %l7, !tbaa !24
  %t148 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !27
  %t150 = getelementptr i64, ptr %t149, i64 %t146
  %t151 = load i64, ptr %t150, !tbaa !34
  %t153 = icmp eq i64 %t151, 0
  store i1 %t153, ptr %l67, !tbaa !21
  br label %bb44
bb44:
  %t155 = load i1, ptr %l67, !tbaa !21
  br i1 %t155, label %bb45, label %bb46
bb45:
  store i64 -1, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  %t157 = load i64, ptr %l7, !tbaa !24
  store i64 %t157, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2erelease(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l37 = alloca ptr
  %l40 = alloca i64
  %l43 = alloca i1
  %l51 = alloca ptr
  %l54 = alloca i64
  %l57 = alloca i32
  store ptr %a1, ptr %l1
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  br label %bb1
bb1:
  store i64 -1, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t1)
  store i64 %t3, ptr %l12
  br label %bb2
bb2:
  %t4 = load i64, ptr %l12, !tbaa !24
  store i64 %t4, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t5 = load i64, ptr %l6, !tbaa !24
  %t6 = load i64, ptr %l5, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t11 = load i64, ptr %l7, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb8
bb5:
  %t15 = load i64, ptr %l6, !tbaa !24
  %t16 = load i64, ptr %l5, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l7, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l7, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l19, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb7
bb7:
  %t31 = load i64, ptr %l19, !tbaa !24
  store i64 %t31, ptr %l16, !tbaa !24
  br label %bb8
bb8:
  %t32 = load i64, ptr %l16, !tbaa !24
  store i64 %t32, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  %t33 = load i64, ptr %l9, !tbaa !24
  %t34 = load i64, ptr %l8, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb10, label %bb11
bb10:
  br label %bb19
bb11:
  br label %bb12
bb12:
  %t41 = load i64, ptr %l5, !tbaa !24
  %t42 = load i64, ptr %l9, !tbaa !24
  %t43 = load i64, ptr %l7, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l10, !tbaa !24
  store ptr %a0, ptr %l37, !tbaa !29
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t53 = load i64, ptr %l10, !tbaa !24
  %t56 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t52, i64 %t53)
  store i64 %t56, ptr %l40
  br label %bb13
bb13:
  %t58 = load ptr, ptr %l3, !tbaa !29
  %t59 = load ptr, ptr %l37, !tbaa !29
  %t60 = load i64, ptr %l40, !tbaa !24
  %t63 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ewaits(ptr %v0, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %t59, i64 %t60, ptr %a2, ptr %t58)
  store i1 %t63, ptr %l43
  br label %bb14
bb14:
  %t64 = load i1, ptr %l43, !tbaa !21
  %t65 = xor i1 %t64, true
  br i1 %t65, label %bb15, label %bb16
bb15:
  %t67 = load i64, ptr %l10, !tbaa !24
  store i64 %t67, ptr %l4, !tbaa !24
  br label %bb19
bb16:
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t69 = load i64, ptr %l9, !tbaa !24
  %t72 = add i64 %t69, 1
  store i64 %t72, ptr %l9, !tbaa !24
  br label %bb9
bb19:
  %t74 = load i64, ptr %l4, !tbaa !24
  %t76 = icmp slt i64 %t74, 0
  br i1 %t76, label %bb20, label %bb21
bb20:
  br label %ret
bb21:
  br label %bb22
bb22:
  %t78 = load ptr, ptr %l3, !tbaa !29
  store ptr %t78, ptr %l51, !tbaa !29
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t80 = load i64, ptr %l4, !tbaa !24
  %t83 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t79, i64 %t80)
  store i64 %t83, ptr %l54
  br label %bb23
bb23:
  %t84 = load ptr, ptr %l51, !tbaa !29
  %t85 = load i64, ptr %l54, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v3, ptr %t84, i64 %t85)
  br label %bb24
bb24:
  %t86 = load ptr, ptr %l1, !tbaa !29
  %t87 = load i64, ptr %l4, !tbaa !24
  %t90 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eRemoveAt_3cI64_3e(ptr %v1, ptr %t86, i64 %t87)
  store i32 %t90, ptr %l57
  %t91 = icmp ne i32 %t90, 0
  br i1 %t91, label %bb26, label %ok.92, !prof !99
ok.92:
  br label %bb25
bb25:
  br label %bb33
bb26:
  %t93 = load i32, ptr %l57, !tbaa !23
  %t94 = icmp eq i32 %t93, 65536
  br i1 %t94, label %bb27, label %bb28
bb27:
  call void @__olang_bang_failed_plain(ptr @olang_loc_a61cfa4a479d7a25_9400c4278bb1e539)
  unreachable
bb28:
  %t96 = load i32, ptr %l57, !tbaa !23
  %t97 = icmp eq i32 %t96, 65537
  br i1 %t97, label %bb29, label %bb30
bb29:
  call void @__olang_bang_failed_plain(ptr @olang_loc_57b94e28dfb9b502_11fd69472c69d516)
  unreachable
bb30:
  %t99 = load i32, ptr %l57, !tbaa !23
  %t100 = icmp eq i32 %t99, 65538
  br i1 %t100, label %bb31, label %bb32
bb31:
  call void @__olang_bang_failed_plain(ptr @olang_loc_76519f2a5446c8c2_195fd4b9f9cd3b36)
  unreachable
bb32:
  call void @__olang_bang_failed_plain(ptr @olang_loc_babafd94d84db46c_e9d5138a9339dba0)
  unreachable
bb33:
  br label %bb34
bb34:
  br label %bb1
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2erenderMaybeText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [1 x i64] } %a1, { i64, [4 x i64] } %a2, i32 %a3, %"compiler/source:Span" %a4, i32 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [1 x i64] }
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l7 = alloca { i64, [4 x i64] }
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca i32
  %l20 = alloca %"compiler/mir:Lvalue"
  %l24 = alloca { i64, ptr }
  %l26 = alloca { i64, [4 x i64] }
  %l29 = alloca i32
  %l32 = alloca i32
  %l35 = alloca i32
  %l50 = alloca ptr
  %l51 = alloca %"compiler/source:Span"
  %l52 = alloca { i64, [1 x i64] }
  %l53 = alloca i32
  %l55 = alloca %"compiler/mir:Lvalue"
  %s0 = alloca %olang.scope
  %t16 = alloca { i64, [4 x i64] }, align 8
  %t23 = alloca { i64, [4 x i64] }, align 8
  %t72 = alloca { i64, [8 x i64] }, align 8
  %t109 = alloca { i64, [4 x i64] }, align 8
  %t115 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, [1 x i64] } %a1, ptr %l1
  store i32 %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = load i32, ptr %l3, !tbaa !23
  %t4 = load %"compiler/source:Span", ptr %l4
  %t9 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %v1, ptr %v2, ptr %t1, { i64, [4 x i64] } %a2, i32 %t3, %"compiler/source:Span" %t4)
  store i32 %t9, ptr %l15
  br label %bb1
bb1:
  %t10 = load i32, ptr %l15, !tbaa !23
  store i32 %t10, ptr %l6, !tbaa !23
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l16, !tbaa !29
  store i32 19, ptr %l17
  %t12 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t12, ptr %l18, !tbaa !23
  %t13 = load i32, ptr %l6, !tbaa !23
  %t15 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t13)
  store %"compiler/mir:Lvalue" %t15, ptr %l20
  br label %bb2
bb2:
  store { i64, [4 x i64] } zeroinitializer, ptr %t16
  %t17 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 0
  store i64 1, ptr %t17
  %t18 = load %"compiler/mir:Lvalue", ptr %l20
  %t19 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t18, 0
  %t20 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t19, ptr %t20
  %t21 = load { i64, [4 x i64] }, ptr %t16
  %t22 = load i32, ptr %l3, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t23
  %t24 = getelementptr { i64, [4 x i64] }, ptr %t23, i32 0, i32 0
  store i64 2, ptr %t24
  %t26 = insertvalue { i32, i64 } undef, i32 %t22, 0
  %t27 = insertvalue { i32, i64 } %t26, i64 -1, 1
  %t28 = getelementptr { i64, [4 x i64] }, ptr %t23, i32 0, i32 1
  store { i32, i64 } %t27, ptr %t28
  %t29 = load { i64, [4 x i64] }, ptr %t23
  %t30 = mul i64 2, 40
  %t31 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t30)
  %t32 = insertvalue { i64, ptr } undef, i64 2, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  store { i64, ptr } %t33, ptr %l24, !tbaa !27
  %t35 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr { i64, [4 x i64] }, ptr %t36, i64 0
  store { i64, [4 x i64] } %t21, ptr %t37
  %t39 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr { i64, [4 x i64] }, ptr %t40, i64 1
  store { i64, [4 x i64] } %t29, ptr %t41
  %t42 = load %"compiler/source:Span", ptr %l4
  %t43 = load ptr, ptr %l16, !tbaa !29
  %t44 = load i32, ptr %l17, !range !{i32 0, i32 54}
  %t45 = load i32, ptr %l18, !tbaa !23
  %t46 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t48 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %v1, ptr %v2, ptr %t43, i32 %t44, i32 %t45, { i64, ptr } %t46, %"compiler/source:Span" %t42)
  store { i64, [4 x i64] } %t48, ptr %l26
  br label %bb3
bb3:
  %t49 = load { i64, [4 x i64] }, ptr %l26
  store { i64, [4 x i64] } %t49, ptr %l7
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/lower:lowering", ptr %t50, i32 0, i32 3
  %t54 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t52)
  store i32 %t54, ptr %l29
  br label %bb4
bb4:
  %t55 = load i32, ptr %l29, !tbaa !23
  store i32 %t55, ptr %l8, !tbaa !23
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/lower:lowering", ptr %t56, i32 0, i32 3
  %t60 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t58)
  store i32 %t60, ptr %l32
  br label %bb5
bb5:
  %t61 = load i32, ptr %l32, !tbaa !23
  store i32 %t61, ptr %l9, !tbaa !23
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/lower:lowering", ptr %t62, i32 0, i32 3
  %t66 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t64)
  store i32 %t66, ptr %l35
  br label %bb6
bb6:
  %t67 = load i32, ptr %l35, !tbaa !23
  store i32 %t67, ptr %l10, !tbaa !23
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load { i64, [4 x i64] }, ptr %l7
  %t70 = load i32, ptr %l8, !tbaa !23
  %t71 = load i32, ptr %l9, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t72
  %t73 = getelementptr { i64, [8 x i64] }, ptr %t72, i32 0, i32 0
  store i64 2, ptr %t73
  %t75 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t69, 0
  %t77 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t75, i32 %t70, 1
  %t79 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t77, i32 %t71, 2
  %t80 = getelementptr { i64, [8 x i64] }, ptr %t72, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t79, ptr %t80
  %t81 = load { i64, [8 x i64] }, ptr %t72
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %v2, ptr %v1, ptr %t68, { i64, [8 x i64] } %t81)
  br label %bb7
bb7:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load i32, ptr %l8, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t84, i32 %t85)
  br label %bb8
bb8:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load { i64, [1 x i64] }, ptr %l1
  %t90 = load %"compiler/source:Span", ptr %l4
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eword(ptr %v0, ptr %s0, ptr %v1, ptr %v2, ptr %t88, { i64, [1 x i64] } %t89, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d13, i32 0, i32 1) }, %"compiler/source:Span" %t90)
  br label %bb9
bb9:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load i32, ptr %l10, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %v2, ptr %v1, ptr %t94, i32 %t95)
  br label %bb10
bb10:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load i32, ptr %l9, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t98, i32 %t99)
  br label %bb11
bb11:
  %t102 = load ptr, ptr %l0, !tbaa !29
  store ptr %t102, ptr %l50, !tbaa !29
  %t103 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t103, ptr %l51
  %t104 = load { i64, [1 x i64] }, ptr %l1
  store { i64, [1 x i64] } %t104, ptr %l52
  store i32 %a5, ptr %l53
  %t106 = load i32, ptr %l6, !tbaa !23
  %t108 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t106)
  store %"compiler/mir:Lvalue" %t108, ptr %l55
  br label %bb12
bb12:
  store { i64, [4 x i64] } zeroinitializer, ptr %t109
  %t110 = getelementptr { i64, [4 x i64] }, ptr %t109, i32 0, i32 0
  store i64 1, ptr %t110
  %t111 = load %"compiler/mir:Lvalue", ptr %l55
  %t112 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t111, 0
  %t113 = getelementptr { i64, [4 x i64] }, ptr %t109, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t112, ptr %t113
  %t114 = load { i64, [4 x i64] }, ptr %t109
  store { i64, [21 x i64] } zeroinitializer, ptr %t115
  %t116 = getelementptr { i64, [21 x i64] }, ptr %t115, i32 0, i32 0
  store i64 11, ptr %t116
  %t117 = load %"compiler/source:Span", ptr %l51
  %t118 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t117, 0
  %t119 = load { i64, [1 x i64] }, ptr %l52
  %t120 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t118, { i64, [1 x i64] } %t119, 1
  %t121 = load i32, ptr %l53, !range !{i32 0, i32 8}
  %t122 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t120, i32 %t121, 2
  %t124 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t122, { i64, [4 x i64] } %t114, 3
  %t125 = getelementptr { i64, [21 x i64] }, ptr %t115, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t124, ptr %t125
  %t126 = load { i64, [21 x i64] }, ptr %t115
  %t128 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t126, ptr %t128
  %t129 = load ptr, ptr %l50, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %v1, ptr %v2, ptr %t129, ptr %t128)
  br label %bb13
bb13:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load i32, ptr %l10, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %v2, ptr %v1, ptr %t131, i32 %t132)
  br label %bb14
bb14:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load i32, ptr %l10, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t135, i32 %t136)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eresultScope(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l13 = alloca ptr
  %l15 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l42 = alloca ptr
  %l45 = alloca { i64, [1 x i64] }
  %rv = alloca { i64, [1 x i64] }
  %t8 = alloca { i64, [1 x i64] }, align 8
  %t95 = alloca { i64, [1 x i64] }, align 8
  %t107 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 29
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store { i64, [1 x i64] } zeroinitializer, ptr %t8
  %t9 = getelementptr { i64, [1 x i64] }, ptr %t8, i32 0, i32 0
  store i64 2, ptr %t9
  %t10 = load { i64, [1 x i64] }, ptr %t8
  store { i64, [1 x i64] } %t10, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l1, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lower:lowering", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Body", ptr %t15, i32 0, i32 6
  store ptr %t17, ptr %l13, !tbaa !29
  %t18 = load ptr, ptr %l13, !tbaa !29
  %t19 = call ptr @__olang_scope_or(ptr %v1, ptr %t18)
  %t20 = call ptr @__olang_scope_hold(ptr %t19)
  %t21 = ptrtoint ptr %t20 to i64
  %t23 = inttoptr i64 %t21 to ptr
  %t24 = load ptr, ptr %l13, !tbaa !29
  %t25 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eLen_3ccompiler_2ftyped_3aScopeVar_3e(ptr %t23, ptr %t24)
  store i64 %t25, ptr %l15
  br label %bb4
bb4:
  %t26 = load i64, ptr %l15, !tbaa !24
  store i64 %t26, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t27 = load i64, ptr %l2, !tbaa !24
  %t28 = load i64, ptr %l1, !tbaa !24
  %t31 = icmp sgt i64 %t27, %t28
  br i1 %t31, label %bb5, label %bb6
bb5:
  %t33 = load i64, ptr %l3, !tbaa !24
  %t35 = icmp sgt i64 %t33, 0
  br i1 %t35, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb10
bb7:
  %t37 = load i64, ptr %l2, !tbaa !24
  %t38 = load i64, ptr %l1, !tbaa !24
  %t41 = sub i64 %t37, %t38
  %t42 = load i64, ptr %l3, !tbaa !24
  %t45 = add i64 %t41, %t42
  %t47 = sub i64 %t45, 1
  %t48 = load i64, ptr %l3, !tbaa !24
  %t51 = sdiv i64 %t47, %t48
  store i64 %t51, ptr %l22, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb9
bb9:
  %t53 = load i64, ptr %l22, !tbaa !24
  store i64 %t53, ptr %l19, !tbaa !24
  br label %bb10
bb10:
  %t54 = load i64, ptr %l19, !tbaa !24
  store i64 %t54, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb11
bb11:
  %t55 = load i64, ptr %l5, !tbaa !24
  %t56 = load i64, ptr %l4, !tbaa !24
  %t59 = icmp slt i64 %t55, %t56
  %t61 = xor i1 %t59, true
  br i1 %t61, label %bb12, label %bb13
bb12:
  br label %bb20
bb13:
  br label %bb14
bb14:
  %t63 = load i64, ptr %l1, !tbaa !24
  %t64 = load i64, ptr %l5, !tbaa !24
  %t65 = load i64, ptr %l3, !tbaa !24
  %t68 = mul i64 %t64, %t65
  %t71 = add i64 %t63, %t68
  store i64 %t71, ptr %l6, !tbaa !24
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/lower:lowering", ptr %t73, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = getelementptr %"compiler/typed:Body", ptr %t76, i32 0, i32 6
  store ptr %t78, ptr %l42, !tbaa !29
  %t79 = load i64, ptr %l6, !tbaa !24
  %t80 = load ptr, ptr %l42, !tbaa !29
  %t81 = call ptr @__olang_scope_or(ptr %v1, ptr %t80)
  %t82 = call ptr @__olang_scope_hold(ptr %t81)
  %t83 = ptrtoint ptr %t82 to i64
  %t85 = inttoptr i64 %t83 to ptr
  %t86 = load ptr, ptr %l42, !tbaa !29
  %t88 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_3ccompiler_2ftyped_3aScopeVar_3e(ptr %t85, ptr %t86, i64 %t79)
  store { i64, [1 x i64] } %t88, ptr %l45
  br label %bb15
bb15:
  %t89 = load { i64, [1 x i64] }, ptr %l45
  %t91 = extractvalue { i64, [1 x i64] } %t89, 0
  %t92 = icmp eq i64 %t91, 1
  br i1 %t92, label %bb16, label %bb17
bb16:
  %t94 = load i64, ptr %l6, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t95
  %t96 = getelementptr { i64, [1 x i64] }, ptr %t95, i32 0, i32 0
  store i64 1, ptr %t96
  %t98 = insertvalue { i64 } undef, i64 %t94, 0
  %t99 = getelementptr { i64, [1 x i64] }, ptr %t95, i32 0, i32 1
  store { i64 } %t98, ptr %t99
  %t100 = load { i64, [1 x i64] }, ptr %t95
  store { i64, [1 x i64] } %t100, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t102 = load i64, ptr %l5, !tbaa !24
  %t105 = add i64 %t102, 1
  store i64 %t105, ptr %l5, !tbaa !24
  br label %bb11
bb20:
  store { i64, [1 x i64] } zeroinitializer, ptr %t107
  %t108 = getelementptr { i64, [1 x i64] }, ptr %t107, i32 0, i32 0
  store i64 2, ptr %t108
  %t109 = load { i64, [1 x i64] }, ptr %t107
  store { i64, [1 x i64] } %t109, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2erunArrayLocal(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l4 = alloca ptr
  %l7 = alloca i1
  %l11 = alloca i32
  %l15 = alloca i1
  %l18 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t7 = call ptr @__olang_scope_or(ptr %v1, ptr %t6)
  %t8 = call ptr @__olang_scope_hold(ptr %t7)
  %t9 = ptrtoint ptr %t8 to i64
  %t11 = inttoptr i64 %t9 to ptr
  %t12 = load ptr, ptr %l4, !tbaa !29
  %t14 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t11, ptr %t12, i32 %t5)
  store i1 %t14, ptr %l7
  br label %bb1
bb1:
  %t15 = load i1, ptr %l7, !tbaa !21
  br i1 %t15, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i32, ptr %l1, !tbaa !23
  %t21 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %v1, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l11
  br label %bb5
bb5:
  %t22 = load i32, ptr %l11, !tbaa !23
  store i32 %t22, ptr %l2, !tbaa !23
  %t23 = load i32, ptr %l2, !tbaa !23
  %t24 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t27 = icmp ne i32 %t23, %t24
  br i1 %t27, label %bb6, label %bb7
bb6:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i32, ptr %l2, !tbaa !23
  %t33 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2efixedLen(ptr %v0, ptr %v1, ptr %t29, i32 %t30)
  store i64 %t33, ptr %l18
  br label %bb8
bb7:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb9
bb8:
  %t34 = load i64, ptr %l18, !tbaa !24
  %t35 = icmp slt i64 %t34, 0
  store i1 %t35, ptr %l15, !tbaa !21
  br label %bb9
bb9:
  %t37 = load i1, ptr %l15, !tbaa !21
  store i1 %t37, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2flower_2ecompiler_2flower_3alowering_2erunOrder(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca i64
  %l19 = alloca i64
  %l24 = alloca i1
  %l37 = alloca i64
  %l39 = alloca i64
  %l44 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l10
  br label %bb2
bb2:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l3
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t5)
  store i64 %t7, ptr %l12
  br label %bb3
bb3:
  %t8 = load i64, ptr %l12, !tbaa !24
  %t9 = sub i64 %t8, 1
  store i64 %t9, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t11 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sge i64 %t11, 0
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb5, label %bb6
bb5:
  br label %bb17
bb6:
  br label %bb7
bb7:
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t17, i64 %t18)
  store i64 %t21, ptr %l19
  br label %bb8
bb8:
  %t22 = load i64, ptr %l19, !tbaa !24
  store i64 %t22, ptr %l5, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i64, ptr %l5, !tbaa !24
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t30 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ewaits(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t23, i64 %t24, ptr %t25, ptr %l2)
  store i1 %t30, ptr %l24
  br label %bb9
bb9:
  %t31 = load i1, ptr %l24, !tbaa !21
  br i1 %t31, label %bb10, label %bb11
bb10:
  %t32 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t32)
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb16
bb13:
  %t35 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %l2, i64 %t35)
  br label %bb14
bb14:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2erelease(ptr %v0, ptr %s0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t38, ptr %l3, ptr %t39, ptr %l2)
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t44 = load i64, ptr %l4, !tbaa !24
  %t47 = sub i64 %t44, 1
  store i64 %t47, ptr %l4, !tbaa !24
  br label %bb4
bb17:
  store ptr %l3, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb18
bb18:
  %t50 = load i64, ptr %l7, !tbaa !24
  store i64 %t50, ptr %l37, !tbaa !24
  %t51 = load ptr, ptr %l6, !tbaa !29
  %t53 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t51)
  store i64 %t53, ptr %l39
  br label %bb19
bb19:
  %t54 = load i64, ptr %l37, !tbaa !24
  %t55 = load i64, ptr %l39, !tbaa !24
  %t56 = icmp slt i64 %t54, %t55
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb20, label %bb21
bb20:
  br label %bb26
bb21:
  br label %bb22
bb22:
  %t60 = load ptr, ptr %l6, !tbaa !29
  %t61 = load i64, ptr %l7, !tbaa !24
  %t64 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t60, i64 %t61)
  store i64 %t64, ptr %l44
  br label %bb23
bb23:
  %t65 = load i64, ptr %l44, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %l2, i64 %t65)
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t69 = load i64, ptr %l7, !tbaa !24
  %t72 = add i64 %t69, 1
  store i64 %t72, ptr %l7, !tbaa !24
  br label %bb18
bb26:
  %t74 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t74, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eselfTry(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l6 = alloca i1
  %l16 = alloca ptr
  %l20 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 73
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp slt i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb3
bb2:
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Try", ptr %t8, i32 0, i32 0
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = icmp eq ptr %t11, null
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l6, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t19 = getelementptr %"compiler/typed:Try", ptr %t17, i32 0, i32 0
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = icmp eq ptr %t20, null
  br i1 %t22, label %bb7, label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_3de6741a678ec223_687ea1dcbf00b0ef)
  unreachable
bb8:
  br label %bb9
bb9:
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Try", ptr %t24, i32 0, i32 0
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = call ptr @compiler_2flower_2eviewCallIn(ptr %v1, ptr %v1, ptr %t27)
  store ptr %t29, ptr %l16
  br label %bb10
bb10:
  %t30 = load ptr, ptr %l16, !tbaa !29
  store ptr %t30, ptr %l2, !tbaa !29
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = icmp eq ptr %t31, null
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb11, label %bb12
bb11:
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t39 = getelementptr %"compiler/typed:Call", ptr %t37, i32 0, i32 2
  %t40 = load i32, ptr %t39, !tbaa !23
  %t42 = sext i32 %t40 to i64
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/lower:lowering", ptr %t43, i32 0, i32 73
  %t46 = load i64, ptr %t45, !tbaa !24
  %t49 = icmp eq i64 %t42, %t46
  store i1 %t49, ptr %l20, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb13
bb13:
  %t51 = load i1, ptr %l20, !tbaa !21
  store i1 %t51, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2esolid(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/lower:pl"
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l6 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca %"compiler/lower:pl"
  %l14 = alloca %"compiler/lower:pl"
  %l17 = alloca { i64, [4 x i64] }
  %l20 = alloca i32
  %l22 = alloca %"compiler/lower:pl"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/lower:pl"
  %t33 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/lower:pl" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/lower:pl", ptr %l1, i32 0, i32 2
  %t2 = load i64, ptr %t1, !tbaa !24
  %t4 = icmp slt i64 %t2, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 12
  %t9 = load i1, ptr %t8, !tbaa !21
  store i1 %t9, ptr %l6, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l6, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t12 = load %"compiler/lower:pl", ptr %l1
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/lower:pl" %t12, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l10, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l11, !tbaa !29
  %t16 = load %"compiler/lower:pl", ptr %l1
  store %"compiler/lower:pl" %t16, ptr %l12
  %t18 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s0, ptr %l12)
  store %"compiler/lower:pl" %t18, ptr %l14
  br label %bb7
bb7:
  %t19 = load i32, ptr %l2, !tbaa !23
  %t20 = load %"compiler/source:Span", ptr %l3
  %t21 = load ptr, ptr %l11, !tbaa !29
  %t22 = load %"compiler/lower:pl", ptr %l14
  %t25 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2epackedRead(ptr %v0, ptr %s0, ptr %v3, ptr %v4, ptr %t21, %"compiler/lower:pl" %t22, i32 %t19, %"compiler/source:Span" %t20)
  store { i64, [4 x i64] } %t25, ptr %l17
  br label %bb8
bb8:
  %t26 = load i32, ptr %l2, !tbaa !23
  %t27 = load %"compiler/source:Span", ptr %l3
  %t28 = load ptr, ptr %l10, !tbaa !29
  %t29 = load { i64, [4 x i64] }, ptr %l17
  %t32 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %v3, ptr %v4, ptr %t28, { i64, [4 x i64] } %t29, i32 %t26, %"compiler/source:Span" %t27)
  store i32 %t32, ptr %l20
  br label %bb9
bb9:
  store { i64, [2 x i64] } zeroinitializer, ptr %t33
  %t34 = getelementptr { i64, [2 x i64] }, ptr %t33, i32 0, i32 0
  store i64 1, ptr %t34
  %t35 = load i32, ptr %l20, !tbaa !23
  %t36 = insertvalue { i32 } undef, i32 %t35, 0
  %t37 = getelementptr { i64, [2 x i64] }, ptr %t33, i32 0, i32 1
  store { i32 } %t36, ptr %t37
  %t38 = load { i64, [2 x i64] }, ptr %t33
  %t40 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %v2, { i64, [2 x i64] } %t38)
  store %"compiler/lower:pl" %t40, ptr %l22
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t41 = load %"compiler/lower:pl", ptr %l22
  store %"compiler/lower:pl" %t41, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:pl", ptr %rv
  ret %"compiler/lower:pl" %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2esomeCopies(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, i32 %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l14 = alloca { i64, ptr }
  %l21 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t15, ptr %l14, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  %t30 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eretCopies(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %t21, i32 %a2)
  store i1 %t30, ptr %l21
  br label %bb5
bb5:
  %t31 = load i1, ptr %l21, !tbaa !21
  br i1 %t31, label %bb6, label %bb7
bb6:
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t33 = load i64, ptr %l4, !tbaa !24
  %t36 = add i64 %t33, 1
  store i64 %t36, ptr %l4, !tbaa !24
  br label %bb1
bb10:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2estableHolder(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i1
  %l15 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l25 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i1
  %l35 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i1
  %l44 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2estableHolder(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t16, ptr %t17)
  store i1 %t20, ptr %l15
  br label %bb6
bb6:
  %t21 = load i1, ptr %l15, !tbaa !21
  store i1 %t21, ptr %l6, !tbaa !21
  br label %bb33
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t23 = load ptr, ptr %l16, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l16, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 8}
  %t29 = icmp eq i64 %t27, 4
  store i1 %t29, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l17, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Elem", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t44 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2estableHolder(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t37, ptr %t41)
  store i1 %t44, ptr %l25
  br label %bb13
bb13:
  %t45 = load i1, ptr %l25, !tbaa !21
  store i1 %t45, ptr %l6, !tbaa !21
  br label %bb33
bb14:
  %t46 = load ptr, ptr %l1, !tbaa !29
  store ptr %t46, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t47 = load ptr, ptr %l26, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb15, label %bb16
bb15:
  %t50 = load ptr, ptr %l26, !tbaa !29
  %t51 = load i64, ptr %t50, !range !{i64 0, i64 8}
  %t53 = icmp eq i64 %t51, 5
  store i1 %t53, ptr %l27, !tbaa !21
  br label %bb16
bb16:
  %t54 = load i1, ptr %l27, !tbaa !21
  br i1 %t54, label %bb17, label %bb18
bb17:
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr { i64, [4 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t57, i32 0, i32 2
  %t59 = load ptr, ptr %t58
  store ptr %t59, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t64 = getelementptr %"compiler/typed:Payload", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t68 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2estableHolder(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t61, ptr %t65)
  store i1 %t68, ptr %l35
  br label %bb20
bb20:
  %t69 = load i1, ptr %l35, !tbaa !21
  store i1 %t69, ptr %l6, !tbaa !21
  br label %bb33
bb21:
  %t70 = load ptr, ptr %l1, !tbaa !29
  store ptr %t70, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t71 = load ptr, ptr %l36, !tbaa !29
  %t72 = icmp ne ptr %t71, null
  br i1 %t72, label %bb22, label %bb23
bb22:
  %t74 = load ptr, ptr %l36, !tbaa !29
  %t75 = load i64, ptr %t74, !range !{i64 0, i64 8}
  %t77 = icmp eq i64 %t75, 2
  store i1 %t77, ptr %l37, !tbaa !21
  br label %bb23
bb23:
  %t78 = load i1, ptr %l37, !tbaa !21
  br i1 %t78, label %bb24, label %bb25
bb24:
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr { i64, [4 x i64] }, ptr %t79, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t81, i32 0, i32 2
  %t83 = load ptr, ptr %t82
  store ptr %t83, ptr %l5, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load ptr, ptr %l5, !tbaa !29
  %t89 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2estableRef(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t85, ptr %t86)
  store i1 %t89, ptr %l44
  br label %bb27
bb27:
  %t90 = load i1, ptr %l44, !tbaa !21
  store i1 %t90, ptr %l6, !tbaa !21
  br label %bb33
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_27604e529e9a5bde_d86cf7c50ff5ec3a)
  unreachable
bb33:
  %t91 = load i1, ptr %l6, !tbaa !21
  store i1 %t91, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2estableViews(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l14 = alloca i32
  %l15 = alloca ptr
  %l16 = alloca i1
  %l23 = alloca ptr
  %l26 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca i1
  %l39 = alloca i1
  %l40 = alloca i32
  %l45 = alloca i64
  %l49 = alloca i64
  %l52 = alloca i64
  %l71 = alloca i64
  %l75 = alloca i1
  %l78 = alloca { i64, ptr }
  %l81 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Call", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t7 = load ptr, ptr %l15, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l15, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 5}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l16, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l16, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { i32 }, ptr %t17, i32 0, i32 0
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t21 = load i32, ptr %l3, !tbaa !23
  store i32 %t21, ptr %l14, !tbaa !23
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i32 -1, ptr %l14, !tbaa !23
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_8c91a6d7a61b2df6_ddcf23b133d92f82)
  unreachable
bb11:
  %t23 = load i32, ptr %l14, !tbaa !23
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/lower:lowering", ptr %t24, i32 0, i32 0
  %t27 = load ptr, ptr %t26, !tbaa !29
  store ptr %t27, ptr %l23, !tbaa !29
  %t29 = load ptr, ptr %l23, !tbaa !29
  %t30 = call ptr @__olang_scope_or(ptr %v2, ptr %t29)
  %t31 = call ptr @__olang_scope_hold(ptr %t30)
  %t32 = ptrtoint ptr %t31 to i64
  %t34 = inttoptr i64 %t32 to ptr
  %t35 = load ptr, ptr %l23, !tbaa !29
  %t37 = call i64 @compiler_2flower_2ecompiler_2flower_3aLowerer_2eViewsOf(ptr %t34, ptr %t35, i32 %t23)
  store i64 %t37, ptr %l26
  br label %bb12
bb12:
  %t38 = load i64, ptr %l26, !tbaa !24
  store i64 %t38, ptr %l5, !tbaa !24
  %t39 = load i64, ptr %l5, !tbaa !24
  %t40 = load i64, ptr @G_2ecompiler_2ftyped_2eViewOther, !tbaa !24
  %t43 = and i64 %t39, %t40
  %t45 = icmp ne i64 %t43, 0
  br i1 %t45, label %bb13, label %bb14
bb13:
  store i1 false, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l32, !tbaa !29
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/lower:lowering", ptr %t49, i32 0, i32 82
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = getelementptr %"compiler/typed:Call", ptr %t52, i32 0, i32 2
  %t55 = load i32, ptr %t54, !tbaa !23
  %t57 = sext i32 %t55 to i64
  %t60 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %t51, i64 %t57)
  %t61 = extractvalue { i32, i1 } %t60, 1
  %t62 = extractvalue { i32, i1 } %t60, 0
  store i32 %t62, ptr %l40
  %t63 = icmp ne i32 %t62, 0
  br i1 %t63, label %bb17, label %ok.64, !prof !99
ok.64:
  store i1 %t61, ptr %l39
  br label %bb16
bb16:
  %t65 = load i1, ptr %l39, !tbaa !21
  store i1 %t65, ptr %l33, !tbaa !21
  br label %bb19
bb17:
  br label %bb18
bb18:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb19
bb19:
  %t66 = load i1, ptr %l33, !tbaa !21
  %t67 = load ptr, ptr %l32, !tbaa !29
  %t68 = getelementptr %"compiler/lower:lowering", ptr %t67, i32 0, i32 83
  store i1 %t66, ptr %t68, !tbaa !21
  store i64 0, ptr %l6, !tbaa !24
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t71 = getelementptr %"compiler/typed:Call", ptr %t69, i32 0, i32 1
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t72, 0
  %t75 = load i64, ptr @G_2ecompiler_2ftyped_2eViewBits, !tbaa !24
  %t78 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t74, i64 %t75)
  store i64 %t78, ptr %l45
  br label %bb20
bb20:
  %t79 = load i64, ptr %l45, !tbaa !24
  store i64 %t79, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t80 = load i64, ptr %l7, !tbaa !24
  %t81 = load i64, ptr %l6, !tbaa !24
  %t84 = icmp sgt i64 %t80, %t81
  br i1 %t84, label %bb21, label %bb22
bb21:
  %t86 = load i64, ptr %l8, !tbaa !24
  %t88 = icmp sgt i64 %t86, 0
  br i1 %t88, label %bb23, label %bb24
bb22:
  store i64 0, ptr %l49, !tbaa !24
  br label %bb26
bb23:
  %t90 = load i64, ptr %l7, !tbaa !24
  %t91 = load i64, ptr %l6, !tbaa !24
  %t94 = sub i64 %t90, %t91
  %t95 = load i64, ptr %l8, !tbaa !24
  %t98 = add i64 %t94, %t95
  %t100 = sub i64 %t98, 1
  %t101 = load i64, ptr %l8, !tbaa !24
  %t104 = sdiv i64 %t100, %t101
  store i64 %t104, ptr %l52, !tbaa !24
  br label %bb25
bb24:
  store i64 0, ptr %l52, !tbaa !24
  br label %bb25
bb25:
  %t106 = load i64, ptr %l52, !tbaa !24
  store i64 %t106, ptr %l49, !tbaa !24
  br label %bb26
bb26:
  %t107 = load i64, ptr %l49, !tbaa !24
  store i64 %t107, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb27
bb27:
  %t108 = load i64, ptr %l10, !tbaa !24
  %t109 = load i64, ptr %l9, !tbaa !24
  %t112 = icmp slt i64 %t108, %t109
  %t114 = xor i1 %t112, true
  br i1 %t114, label %bb28, label %bb29
bb28:
  br label %bb39
bb29:
  br label %bb30
bb30:
  %t116 = load i64, ptr %l6, !tbaa !24
  %t117 = load i64, ptr %l10, !tbaa !24
  %t118 = load i64, ptr %l8, !tbaa !24
  %t121 = mul i64 %t117, %t118
  %t124 = add i64 %t116, %t121
  store i64 %t124, ptr %l11, !tbaa !24
  %t126 = load i64, ptr %l5, !tbaa !24
  %t127 = load i64, ptr %l11, !tbaa !24
  store i64 %t127, ptr %l71, !tbaa !24
  %t128 = load i64, ptr %l71, !tbaa !24
  %t129 = load i64, ptr %l71, !tbaa !24
  %t130 = shl i64 1, %t129
  %t133 = and i64 %t126, %t130
  %t135 = icmp ne i64 %t133, 0
  br i1 %t135, label %bb31, label %bb32
bb31:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load ptr, ptr %l1, !tbaa !29
  %t140 = getelementptr %"compiler/typed:Call", ptr %t138, i32 0, i32 1
  %t141 = load { i64, ptr }, ptr %t140, !tbaa !27
  store { i64, ptr } %t141, ptr %l78, !tbaa !27
  %t142 = load i64, ptr %l11, !tbaa !24
  %t144 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = getelementptr ptr, ptr %t145, i64 %t142
  %t147 = load ptr, ptr %t146, !tbaa !39
  %t150 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2estableRef(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t137, ptr %t147)
  store i1 %t150, ptr %l81
  br label %bb33
bb32:
  store i1 false, ptr %l75, !tbaa !21
  br label %bb34
bb33:
  %t151 = load i1, ptr %l81, !tbaa !21
  %t152 = xor i1 %t151, true
  store i1 %t152, ptr %l75, !tbaa !21
  br label %bb34
bb34:
  %t154 = load i1, ptr %l75, !tbaa !21
  br i1 %t154, label %bb35, label %bb36
bb35:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/lower:lowering", ptr %t155, i32 0, i32 83
  store i1 false, ptr %t157, !tbaa !21
  store i1 false, ptr %rv
  br label %ret
bb36:
  br label %bb37
bb37:
  br label %bb38
bb38:
  %t159 = load i64, ptr %l10, !tbaa !24
  %t162 = add i64 %t159, 1
  store i64 %t162, ptr %l10, !tbaa !24
  br label %bb27
bb39:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/lower:lowering", ptr %t164, i32 0, i32 83
  store i1 false, ptr %t166, !tbaa !21
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2flower_2ecompiler_2flower_3alowering_2estrBody(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i64
  %l11 = alloca ptr
  %l14 = alloca i32
  %l17 = alloca i32
  %l19 = alloca ptr
  %l22 = alloca i32
  %l23 = alloca ptr
  %l26 = alloca i32
  %l31 = alloca i64
  %l33 = alloca ptr
  %l36 = alloca i64
  %l37 = alloca i32
  %l43 = alloca i64
  %l45 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 2
  %t9 = load ptr, ptr %t8, !tbaa !29
  store ptr %t9, ptr %l3, !tbaa !29
  %t11 = load ptr, ptr %l3, !tbaa !29
  store ptr %t11, ptr %l11, !tbaa !29
  %t12 = load i32, ptr %l1, !tbaa !23
  %t13 = load ptr, ptr %l11, !tbaa !29
  %t14 = call ptr @__olang_scope_or(ptr %v1, ptr %t13)
  %t15 = call ptr @__olang_scope_hold(ptr %t14)
  %t16 = ptrtoint ptr %t15 to i64
  %t18 = inttoptr i64 %t16 to ptr
  %t19 = load ptr, ptr %l11, !tbaa !29
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t18, ptr %t19, i32 %t12)
  store i32 %t21, ptr %l14
  br label %bb1
bb1:
  %t22 = load i32, ptr %l14, !range !{i32 0, i32 33}
  %t24 = trunc i64 18 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb2, label %bb3
bb2:
  %t27 = load i32, ptr %l1, !tbaa !23
  store i32 %t27, ptr %l17, !tbaa !23
  br label %bb5
bb3:
  %t29 = load ptr, ptr %l3, !tbaa !29
  store ptr %t29, ptr %l19, !tbaa !29
  %t30 = load i32, ptr %l1, !tbaa !23
  %t31 = load ptr, ptr %l19, !tbaa !29
  %t32 = call ptr @__olang_scope_or(ptr %v1, ptr %t31)
  %t33 = call ptr @__olang_scope_hold(ptr %t32)
  %t34 = ptrtoint ptr %t33 to i64
  %t36 = inttoptr i64 %t34 to ptr
  %t37 = load ptr, ptr %l19, !tbaa !29
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t36, ptr %t37, i32 %t30)
  store i32 %t39, ptr %l22
  br label %bb4
bb4:
  %t40 = load i32, ptr %l22, !tbaa !23
  store i32 %t40, ptr %l17, !tbaa !23
  br label %bb5
bb5:
  %t41 = load i32, ptr %l17, !tbaa !23
  store i32 %t41, ptr %l4, !tbaa !23
  %t42 = load ptr, ptr %l3, !tbaa !29
  store ptr %t42, ptr %l23, !tbaa !29
  %t43 = load i32, ptr %l4, !tbaa !23
  %t44 = load ptr, ptr %l23, !tbaa !29
  %t45 = call ptr @__olang_scope_or(ptr %v1, ptr %t44)
  %t46 = call ptr @__olang_scope_hold(ptr %t45)
  %t47 = ptrtoint ptr %t46 to i64
  %t49 = inttoptr i64 %t47 to ptr
  %t50 = load ptr, ptr %l23, !tbaa !29
  %t52 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t49, ptr %t50, i32 %t43)
  store i32 %t52, ptr %l26
  br label %bb6
bb6:
  %t53 = load i32, ptr %l26, !range !{i32 0, i32 33}
  %t55 = trunc i64 18 to i32
  %t56 = icmp eq i32 %t53, %t55
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t61 = load ptr, ptr %l2, !tbaa !29
  %t63 = getelementptr %"compiler/lower:Lowerer", ptr %t61, i32 0, i32 24
  store ptr %t63, ptr %l33, !tbaa !29
  %t64 = load i32, ptr %l4, !tbaa !23
  %t65 = load ptr, ptr %l33, !tbaa !29
  %t66 = call ptr @__olang_scope_or(ptr %v2, ptr %t65)
  %t67 = call ptr @__olang_scope_hold(ptr %t66)
  %t68 = ptrtoint ptr %t67 to i64
  %t70 = inttoptr i64 %t68 to ptr
  %t71 = load ptr, ptr %l33, !tbaa !29
  %t73 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %t70, ptr %t71, i32 %t64)
  %t74 = extractvalue { i32, i64 } %t73, 1
  %t75 = extractvalue { i32, i64 } %t73, 0
  store i32 %t75, ptr %l37
  %t76 = icmp ne i32 %t75, 0
  br i1 %t76, label %bb11, label %ok.77, !prof !99
ok.77:
  store i64 %t74, ptr %l36
  br label %bb10
bb10:
  %t78 = load i64, ptr %l36, !tbaa !24
  store i64 %t78, ptr %l31, !tbaa !24
  br label %bb13
bb11:
  br label %bb12
bb12:
  store i64 -2, ptr %l31, !tbaa !24
  br label %bb13
bb13:
  %t79 = load i64, ptr %l31, !tbaa !24
  store i64 %t79, ptr %l5, !tbaa !24
  %t80 = load i64, ptr %l5, !tbaa !24
  %t82 = icmp ne i64 %t80, -2
  br i1 %t82, label %bb14, label %bb15
bb14:
  %t84 = load i64, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t84, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load i32, ptr %l1, !tbaa !23
  %t90 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2emethodBody(ptr %v0, ptr %s0, ptr %s0, ptr %v1, ptr %v2, ptr %t86, i32 %t87, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d14, i32 0, i32 1) }, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i64 %t90, ptr %l43
  br label %bb17
bb17:
  %t91 = load i64, ptr %l43, !tbaa !24
  store i64 %t91, ptr %l6, !tbaa !24
  %t92 = load ptr, ptr %l2, !tbaa !29
  %t94 = getelementptr %"compiler/lower:Lowerer", ptr %t92, i32 0, i32 24
  store ptr %t94, ptr %l45, !tbaa !29
  %t95 = load i32, ptr %l4, !tbaa !23
  %t96 = load i64, ptr %l6, !tbaa !24
  %t97 = load ptr, ptr %l45, !tbaa !29
  %t98 = call ptr @__olang_scope_or(ptr %v2, ptr %t97)
  %t99 = call ptr @__olang_scope_hold(ptr %t98)
  %t100 = ptrtoint ptr %t99 to i64
  %t102 = inttoptr i64 %t100 to ptr
  %t103 = load ptr, ptr %l45, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__Hccd9659a44f570da1fa06b019882a84d(ptr %t102, ptr %t103, i32 %t95, i64 %t96)
  br label %bb18
bb18:
  %t106 = load i64, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t106, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2etarget(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i64
  %l9 = alloca %"compiler/lower:pl"
  %l11 = alloca ptr
  %l14 = alloca i64
  %l16 = alloca %"compiler/lower:pl"
  %l18 = alloca %"compiler/lower:pl"
  %s1 = alloca %olang.scope
  %rv = alloca %"compiler/lower:pl"
  %t13 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 23
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3apl_3e_2eLen_3ccompiler_2flower_3apl_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t9 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egap(ptr %v0, ptr %s1, ptr %v2, ptr %t9, %"compiler/source:Span" %a1, { i64, ptr } { i64 55, ptr getelementptr inbounds (<{ i64, [55 x i8] }>, ptr @.d16, i32 0, i32 1) })
  br label %bb4
bb3:
  br label %bb6
bb4:
  store { i64, [2 x i64] } zeroinitializer, ptr %t13
  %t14 = getelementptr { i64, [2 x i64] }, ptr %t13, i32 0, i32 0
  store i64 0, ptr %t14
  %t15 = load { i64, [2 x i64] }, ptr %t13
  %t17 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %v1, { i64, [2 x i64] } %t15)
  store %"compiler/lower:pl" %t17, ptr %l9
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  %t18 = load %"compiler/lower:pl", ptr %l9
  store %"compiler/lower:pl" %t18, ptr %rv
  br label %ret
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/lower:lowering", ptr %t19, i32 0, i32 23
  store ptr %t21, ptr %l11, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/lower:lowering", ptr %t22, i32 0, i32 23
  %t26 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3apl_3e_2eLen_3ccompiler_2flower_3apl_3e(ptr %v0, ptr %t24)
  store i64 %t26, ptr %l14
  br label %bb7
bb7:
  %t27 = load i64, ptr %l14, !tbaa !24
  %t28 = sub i64 %t27, 1
  %t29 = load ptr, ptr %l11, !tbaa !29
  %t31 = call %"compiler/lower:pl" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3apl_3e_2eAt_3ccompiler_2flower_3apl_3e(ptr %v0, ptr %v1, ptr %t29, i64 %t28)
  store %"compiler/lower:pl" %t31, ptr %l16
  br label %bb8
bb8:
  %t33 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %v1, ptr %l16)
  store %"compiler/lower:pl" %t33, ptr %l18
  br label %bb9
bb9:
  %t34 = load %"compiler/lower:pl", ptr %l18
  store %"compiler/lower:pl" %t34, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:pl", ptr %rv
  ret %"compiler/lower:pl" %rr
}

define dso_local i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etaskType(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca { { i64, [7 x i64] }, i32 }
  %l11 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l29 = alloca ptr
  %l36 = alloca ptr
  %l39 = alloca ptr
  %l40 = alloca i1
  %l47 = alloca ptr
  %l50 = alloca i32
  %l51 = alloca ptr
  %l52 = alloca i1
  %l58 = alloca i32
  %l59 = alloca ptr
  %l60 = alloca i1
  %l70 = alloca { { i64, [7 x i64] }, i32 }
  %l73 = alloca ptr
  %l74 = alloca i1
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t2 = load ptr, ptr %l12, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l12, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l13, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l13, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb40
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Call", ptr %t16, i32 0, i32 0
  %t19 = load ptr, ptr %t18, !tbaa !29
  store ptr %t19, ptr %l3, !tbaa !29
  %t21 = load ptr, ptr %l3, !tbaa !29
  store ptr %t21, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t22 = load ptr, ptr %l20, !tbaa !29
  %t23 = icmp ne ptr %t22, null
  br i1 %t23, label %bb6, label %bb7
bb6:
  %t25 = load ptr, ptr %l20, !tbaa !29
  %t26 = load i64, ptr %t25, !range !{i64 0, i64 5}
  %t28 = icmp eq i64 %t26, 0
  store i1 %t28, ptr %l21, !tbaa !21
  br label %bb7
bb7:
  %t29 = load i1, ptr %l21, !tbaa !21
  br i1 %t29, label %bb8, label %bb9
bb8:
  %t30 = load ptr, ptr %l3, !tbaa !29
  %t32 = getelementptr { i64, [3 x i64] }, ptr %t30, i32 0, i32 1
  %t33 = getelementptr { i32 }, ptr %t32, i32 0, i32 0
  %t34 = load i32, ptr %t33
  store i32 %t34, ptr %l4, !tbaa !23
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/lower:lowering", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = getelementptr %"compiler/lower:Lowerer", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  store ptr %t42, ptr %l29, !tbaa !29
  %t44 = load i32, ptr %l4, !tbaa !23
  %t46 = sext i32 %t44 to i64
  %t47 = load ptr, ptr %l29, !tbaa !29
  %t48 = call ptr @__olang_scope_or(ptr %v2, ptr %t47)
  %t49 = call ptr @__olang_scope_hold(ptr %t48)
  %t50 = ptrtoint ptr %t49 to i64
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/lower:lowering", ptr %t51, i32 0, i32 0
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = call ptr @__olang_scope_or(ptr %v2, ptr %t54)
  %t57 = call ptr @__olang_scope_hold(ptr %t56)
  %t58 = ptrtoint ptr %t57 to i64
  %t60 = inttoptr i64 %t50 to ptr
  %t62 = inttoptr i64 %t58 to ptr
  %t63 = load ptr, ptr %l29, !tbaa !29
  %t65 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %t60, ptr %t62, ptr %t63, i64 %t46)
  store ptr %t65, ptr %l36
  br label %bb11
bb11:
  %t66 = load ptr, ptr %l36, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Body", ptr %t66, i32 0, i32 2
  %t69 = load i32, ptr %t68, !tbaa !23
  store i32 %t69, ptr %rv
  br label %ret
bb12:
  %t71 = load ptr, ptr %l3, !tbaa !29
  store ptr %t71, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t72 = load ptr, ptr %l39, !tbaa !29
  %t73 = icmp ne ptr %t72, null
  br i1 %t73, label %bb13, label %bb14
bb13:
  %t75 = load ptr, ptr %l39, !tbaa !29
  %t76 = load i64, ptr %t75, !range !{i64 0, i64 5}
  %t78 = icmp eq i64 %t76, 1
  store i1 %t78, ptr %l40, !tbaa !21
  br label %bb14
bb14:
  %t79 = load i1, ptr %l40, !tbaa !21
  br i1 %t79, label %bb15, label %bb16
bb15:
  %t80 = load ptr, ptr %l3, !tbaa !29
  %t82 = getelementptr { i64, [3 x i64] }, ptr %t80, i32 0, i32 1
  %t83 = getelementptr { i64 }, ptr %t82, i32 0, i32 0
  %t84 = load i64, ptr %t83
  store i64 %t84, ptr %l5, !tbaa !24
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/lower:lowering", ptr %t86, i32 0, i32 0
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = getelementptr %"compiler/lower:Lowerer", ptr %t89, i32 0, i32 0
  %t92 = load ptr, ptr %t91, !tbaa !29
  store ptr %t92, ptr %l47, !tbaa !29
  %t93 = load i64, ptr %l5, !tbaa !24
  %t94 = load ptr, ptr %l47, !tbaa !29
  %t95 = call ptr @__olang_scope_or(ptr %v2, ptr %t94)
  %t96 = call ptr @__olang_scope_hold(ptr %t95)
  %t97 = ptrtoint ptr %t96 to i64
  %t99 = inttoptr i64 %t97 to ptr
  %t100 = load ptr, ptr %l47, !tbaa !29
  %t102 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %t99, ptr %t100, i64 %t93)
  store i32 %t102, ptr %l50
  br label %bb18
bb18:
  %t103 = load i32, ptr %l50, !tbaa !23
  store i32 %t103, ptr %rv
  br label %ret
bb19:
  %t104 = load ptr, ptr %l3, !tbaa !29
  store ptr %t104, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t105 = load ptr, ptr %l51, !tbaa !29
  %t106 = icmp ne ptr %t105, null
  br i1 %t106, label %bb20, label %bb21
bb20:
  %t108 = load ptr, ptr %l51, !tbaa !29
  %t109 = load i64, ptr %t108, !range !{i64 0, i64 5}
  %t111 = icmp eq i64 %t109, 2
  store i1 %t111, ptr %l52, !tbaa !21
  br label %bb21
bb21:
  %t112 = load i1, ptr %l52, !tbaa !21
  br i1 %t112, label %bb22, label %bb23
bb22:
  %t113 = load ptr, ptr %l3, !tbaa !29
  %t115 = getelementptr { i64, [3 x i64] }, ptr %t113, i32 0, i32 1
  %t116 = getelementptr { ptr }, ptr %t115, i32 0, i32 0
  %t117 = load ptr, ptr %t116
  store ptr %t117, ptr %l6, !tbaa !29
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t119 = load ptr, ptr %l6, !tbaa !29
  %t121 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t119)
  store i32 %t121, ptr %l58
  br label %bb25
bb25:
  %t122 = load i32, ptr %l58, !tbaa !23
  store i32 %t122, ptr %rv
  br label %ret
bb26:
  %t123 = load ptr, ptr %l3, !tbaa !29
  store ptr %t123, ptr %l59, !tbaa !29
  store i1 false, ptr %l60, !tbaa !21
  %t124 = load ptr, ptr %l59, !tbaa !29
  %t125 = icmp ne ptr %t124, null
  br i1 %t125, label %bb27, label %bb28
bb27:
  %t127 = load ptr, ptr %l59, !tbaa !29
  %t128 = load i64, ptr %t127, !range !{i64 0, i64 5}
  %t130 = icmp eq i64 %t128, 4
  store i1 %t130, ptr %l60, !tbaa !21
  br label %bb28
bb28:
  %t131 = load i1, ptr %l60, !tbaa !21
  br i1 %t131, label %bb29, label %bb30
bb29:
  %t132 = load ptr, ptr %l3, !tbaa !29
  %t134 = getelementptr { i64, [3 x i64] }, ptr %t132, i32 0, i32 1
  %t135 = getelementptr { i32, i32 }, ptr %t134, i32 0, i32 0
  %t136 = load i32, ptr %t135, !range !{i32 0, i32 2}
  store i32 %t136, ptr %l7
  %t138 = load ptr, ptr %l3, !tbaa !29
  %t140 = getelementptr { i64, [3 x i64] }, ptr %t138, i32 0, i32 1
  %t141 = getelementptr { i32, i32 }, ptr %t140, i32 0, i32 1
  %t142 = load i32, ptr %t141
  store i32 %t142, ptr %l8, !tbaa !23
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load i32, ptr %l7, !range !{i32 0, i32 2}
  %t146 = load i32, ptr %l8, !tbaa !23
  %t150 = call { { i64, [7 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2ehelperCallee(ptr %v0, ptr %v2, ptr %v3, ptr %t144, i32 %t145, i32 %t146)
  store { { i64, [7 x i64] }, i32 } %t150, ptr %l70
  br label %bb32
bb32:
  %t151 = load { { i64, [7 x i64] }, i32 }, ptr %l70
  store { { i64, [7 x i64] }, i32 } %t151, ptr %l9
  %t152 = getelementptr { { i64, [7 x i64] }, i32 }, ptr %l9, i32 0, i32 1
  %t153 = load i32, ptr %t152, !tbaa !23
  store i32 %t153, ptr %rv
  br label %ret
bb33:
  %t157 = load ptr, ptr %l3, !tbaa !29
  store ptr %t157, ptr %l73, !tbaa !29
  store i1 false, ptr %l74, !tbaa !21
  %t158 = load ptr, ptr %l73, !tbaa !29
  %t159 = icmp ne ptr %t158, null
  br i1 %t159, label %bb34, label %bb35
bb34:
  %t161 = load ptr, ptr %l73, !tbaa !29
  %t162 = load i64, ptr %t161, !range !{i64 0, i64 5}
  %t164 = icmp eq i64 %t162, 3
  store i1 %t164, ptr %l74, !tbaa !21
  br label %bb35
bb35:
  %t165 = load i1, ptr %l74, !tbaa !21
  br i1 %t165, label %bb36, label %bb37
bb36:
  %t166 = load ptr, ptr %l3, !tbaa !29
  %t168 = getelementptr { i64, [3 x i64] }, ptr %t166, i32 0, i32 1
  %t169 = getelementptr { i32, i64, i32 }, ptr %t168, i32 0, i32 2
  %t170 = load i32, ptr %t169
  store i32 %t170, ptr %l11, !tbaa !23
  br label %bb38
bb37:
  br label %bb39
bb38:
  %t172 = load i32, ptr %l11, !tbaa !23
  store i32 %t172, ptr %rv
  br label %ret
bb39:
  call void @__olang_check_failed(ptr @olang_loc_3b3f675a7fcfa09e_a6d8609e08455d8a)
  unreachable
bb40:
  br i1 true, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb45
bb44:
  call void @__olang_check_failed(ptr @olang_loc_a39e67f1cd7c0b1f_e499cc399c2ba1cb)
  unreachable
bb45:
  %t174 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t174, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etempLocal(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca i1
  %l8 = alloca { i64, [4 x i64] }
  %l9 = alloca i32
  %l10 = alloca i64
  %l11 = alloca { i64, [1 x i64] }
  %l17 = alloca i1
  %l20 = alloca i1
  %l27 = alloca i1
  %l30 = alloca { i64, ptr }
  %l36 = alloca i1
  %l42 = alloca i1
  %l45 = alloca ptr
  %l49 = alloca { i64, [4 x i64] }
  %l52 = alloca i32
  %l56 = alloca { i64, [4 x i64] }
  %l60 = alloca i32
  %l64 = alloca { i64, [1 x i64] }
  %l68 = alloca { i64, ptr }
  %l71 = alloca { i64, [1 x i64] }
  %l76 = alloca ptr
  %l84 = alloca ptr
  %l85 = alloca %"compiler/source:Span"
  %l87 = alloca %"compiler/mir:Lvalue"
  %s0 = alloca %olang.scope
  %rv = alloca i32
  %t123 = alloca { i64, [1 x i64] }, align 8
  %t146 = alloca { i64, [21 x i64] }, align 8
  %t164 = alloca { i64, [15 x i64] }, align 8
  %t170 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = sext i32 %a4 to i64
  store i64 %t3, ptr %l5, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/lower:lowering", ptr %t5, i32 0, i32 29
  %t8 = load i1, ptr %t7, !tbaa !21
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load i64, ptr %l5, !tbaa !24
  %t12 = icmp sge i64 %t10, 0
  store i1 %t12, ptr %l17, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb3
bb3:
  %t14 = load i1, ptr %l17, !tbaa !21
  br i1 %t14, label %bb4, label %bb5
bb4:
  %t15 = load i64, ptr %l5, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/lower:lowering", ptr %t16, i32 0, i32 38
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/typed:Plan", ptr %t19, i32 0, i32 5
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t27 = icmp slt i64 %t15, %t24
  store i1 %t27, ptr %l20, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb6
bb6:
  %t29 = load i1, ptr %l20, !tbaa !21
  br i1 %t29, label %bb7, label %bb8
bb7:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/lower:lowering", ptr %t30, i32 0, i32 38
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/typed:Plan", ptr %t33, i32 0, i32 5
  %t36 = load { i64, ptr }, ptr %t35, !tbaa !27
  store { i64, ptr } %t36, ptr %l30, !tbaa !27
  %t37 = load i64, ptr %l5, !tbaa !24
  %t39 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr i1, ptr %t40, i64 %t37
  %t42 = load i1, ptr %t41, !tbaa !31
  store i1 %t42, ptr %l27, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb9
bb9:
  %t44 = load i1, ptr %l27, !tbaa !21
  store i1 %t44, ptr %l6, !tbaa !21
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/lower:lowering", ptr %t45, i32 0, i32 29
  %t48 = load i1, ptr %t47, !tbaa !21
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb10, label %bb11
bb10:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/lower:lowering", ptr %t52, i32 0, i32 30
  %t55 = load i1, ptr %t54, !tbaa !21
  store i1 %t55, ptr %l36, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb12
bb12:
  %t57 = load i1, ptr %l36, !tbaa !21
  store i1 %t57, ptr %l7, !tbaa !21
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/lower:lowering", ptr %t58, i32 0, i32 30
  store i1 false, ptr %t60, !tbaa !21
  %t61 = load i1, ptr %l6, !tbaa !21
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb13, label %bb14
bb13:
  %t65 = load i1, ptr %l7, !tbaa !21
  %t67 = xor i1 %t65, true
  store i1 %t67, ptr %l42, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb15
bb15:
  %t69 = load i1, ptr %l42, !tbaa !21
  br i1 %t69, label %bb16, label %bb17
bb16:
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l45, !tbaa !29
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t76 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %t71, ptr %t72)
  store { i64, [4 x i64] } %t76, ptr %l49
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t77 = load i32, ptr %l2, !tbaa !23
  %t78 = load %"compiler/source:Span", ptr %l3
  %t79 = load ptr, ptr %l45, !tbaa !29
  %t80 = load { i64, [4 x i64] }, ptr %l49
  %t83 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %v3, ptr %v2, ptr %t79, { i64, [4 x i64] } %t80, i32 %t77, %"compiler/source:Span" %t78)
  store i32 %t83, ptr %l52
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  %t84 = load i32, ptr %l52, !tbaa !23
  store i32 %t84, ptr %rv
  br label %ret
bb20:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load ptr, ptr %l1, !tbaa !29
  %t90 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %t85, ptr %t86)
  store { i64, [4 x i64] } %t90, ptr %l56
  br label %bb21
bb21:
  %t91 = load { i64, [4 x i64] }, ptr %l56
  store { i64, [4 x i64] } %t91, ptr %l8
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load i32, ptr %l2, !tbaa !23
  %t94 = load %"compiler/source:Span", ptr %l3
  %t98 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t92, i32 %t93, %"compiler/source:Span" %t94)
  store i32 %t98, ptr %l60
  br label %bb22
bb22:
  %t99 = load i32, ptr %l60, !tbaa !23
  store i32 %t99, ptr %l9, !tbaa !23
  %t100 = load i32, ptr %l9, !tbaa !23
  %t102 = sext i32 %t100 to i64
  store i64 %t102, ptr %l10, !tbaa !24
  %t104 = load i1, ptr %l6, !tbaa !21
  br i1 %t104, label %bb23, label %bb24
bb23:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/lower:lowering", ptr %t107, i32 0, i32 38
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = getelementptr %"compiler/typed:Plan", ptr %t110, i32 0, i32 0
  %t113 = load { i64, ptr }, ptr %t112, !tbaa !27
  store { i64, ptr } %t113, ptr %l68, !tbaa !27
  %t114 = load i64, ptr %l5, !tbaa !24
  %t116 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = getelementptr { i64, [2 x i64] }, ptr %t117, i64 %t114
  %t119 = load { i64, [2 x i64] }, ptr %t118
  %t122 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2escopeRef(ptr %v0, ptr %v4, ptr %v5, ptr %v3, ptr %v2, ptr %t106, { i64, [2 x i64] } %t119)
  store { i64, [1 x i64] } %t122, ptr %l71
  br label %bb25
bb24:
  store { i64, [1 x i64] } zeroinitializer, ptr %t123
  %t124 = getelementptr { i64, [1 x i64] }, ptr %t123, i32 0, i32 0
  store i64 2, ptr %t124
  %t125 = load { i64, [1 x i64] }, ptr %t123
  store { i64, [1 x i64] } %t125, ptr %l64
  br label %bb26
bb25:
  %t127 = load { i64, [1 x i64] }, ptr %l71
  store { i64, [1 x i64] } %t127, ptr %l64
  br label %bb26
bb26:
  %t128 = load { i64, [1 x i64] }, ptr %l64
  store { i64, [1 x i64] } %t128, ptr %l11
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/lower:lowering", ptr %t129, i32 0, i32 3
  %t132 = getelementptr %"compiler/mir:Fn", ptr %t131, i32 0, i32 7
  %t133 = load i64, ptr %l10, !tbaa !24
  %t136 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eRefMut_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %v0, ptr %t132, i64 %t133)
  store ptr %t136, ptr %l76
  br label %bb27
bb27:
  %t137 = load ptr, ptr %l76, !tbaa !29
  %t139 = load { i64, [1 x i64] }, ptr %l11
  %t142 = getelementptr %"compiler/mir:Local", ptr %t137, i32 0, i32 4
  store { i64, [1 x i64] } %t139, ptr %t142
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load %"compiler/source:Span", ptr %l3
  %t145 = load i32, ptr %l9, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t146
  %t147 = getelementptr { i64, [21 x i64] }, ptr %t146, i32 0, i32 0
  store i64 1, ptr %t147
  %t149 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t144, 0
  %t151 = insertvalue { %"compiler/source:Span", i32 } %t149, i32 %t145, 1
  %t152 = getelementptr { i64, [21 x i64] }, ptr %t146, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t151, ptr %t152
  %t153 = load { i64, [21 x i64] }, ptr %t146
  %t155 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t153, ptr %t155
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %v3, ptr %v2, ptr %t143, ptr %t155)
  br label %bb28
bb28:
  %t158 = load ptr, ptr %l0, !tbaa !29
  store ptr %t158, ptr %l84, !tbaa !29
  %t159 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t159, ptr %l85
  %t160 = load i32, ptr %l9, !tbaa !23
  %t162 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t160)
  store %"compiler/mir:Lvalue" %t162, ptr %l87
  br label %bb29
bb29:
  %t163 = load { i64, [4 x i64] }, ptr %l8
  store { i64, [15 x i64] } zeroinitializer, ptr %t164
  %t165 = getelementptr { i64, [15 x i64] }, ptr %t164, i32 0, i32 0
  store i64 0, ptr %t165
  %t167 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t163, 0
  %t168 = getelementptr { i64, [15 x i64] }, ptr %t164, i32 0, i32 1
  store { { i64, [4 x i64] } } %t167, ptr %t168
  %t169 = load { i64, [15 x i64] }, ptr %t164
  store { i64, [21 x i64] } zeroinitializer, ptr %t170
  %t171 = getelementptr { i64, [21 x i64] }, ptr %t170, i32 0, i32 0
  store i64 0, ptr %t171
  %t172 = load %"compiler/source:Span", ptr %l85
  %t173 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t172, 0
  %t174 = load %"compiler/mir:Lvalue", ptr %l87
  %t175 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t173, %"compiler/mir:Lvalue" %t174, 1
  %t177 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t175, { i64, [15 x i64] } %t169, 2
  %t178 = getelementptr { i64, [21 x i64] }, ptr %t170, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t177, ptr %t178
  %t179 = load { i64, [21 x i64] }, ptr %t170
  %t181 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t179, ptr %t181
  %t182 = load ptr, ptr %l84, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %v3, ptr %v2, ptr %t182, ptr %t181)
  br label %bb30
bb30:
  %t184 = load i32, ptr %l9, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t184, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2etempPart(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Lvalue" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Lvalue"
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca i64
  %l14 = alloca i1
  %l18 = alloca %"compiler/mir:Local"
  %l25 = alloca { i64, ptr }
  %l31 = alloca i64
  %l34 = alloca i64
  %l60 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca ptr
  %l70 = alloca i32
  %l71 = alloca i32
  %l72 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/mir:Lvalue" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load %"compiler/mir:Lvalue", ptr %l1
  %t3 = call i64 @compiler_2flower_2ebaseLocal(%"compiler/mir:Lvalue" %t1)
  store i64 %t3, ptr %l11
  br label %bb1
bb1:
  %t4 = load i64, ptr %l11, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t7 = icmp slt i64 %t5, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb5
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/lower:lowering", ptr %t9, i32 0, i32 3
  %t12 = getelementptr %"compiler/mir:Fn", ptr %t11, i32 0, i32 7
  %t13 = load i64, ptr %l2, !tbaa !24
  %t16 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t12, i64 %t13)
  store %"compiler/mir:Local" %t16, ptr %l18
  br label %bb4
bb4:
  %t17 = getelementptr %"compiler/mir:Local", ptr %l18, i32 0, i32 3
  %t18 = load i32, ptr %t17, !range !{i32 0, i32 4}
  %t20 = trunc i64 3 to i32
  %t21 = icmp eq i32 %t18, %t20
  %t23 = xor i1 %t21, true
  store i1 %t23, ptr %l14, !tbaa !21
  br label %bb5
bb5:
  %t25 = load i1, ptr %l14, !tbaa !21
  br i1 %t25, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load %"compiler/mir:Lvalue", ptr %l1
  %t31 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2eprojsOf(ptr %v0, ptr %s0, ptr %t27, %"compiler/mir:Lvalue" %t28)
  store { i64, ptr } %t31, ptr %l25
  br label %bb9
bb9:
  %t32 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t32, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  store i64 %t35, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t37 = load i64, ptr %l5, !tbaa !24
  %t38 = load i64, ptr %l4, !tbaa !24
  %t41 = icmp sgt i64 %t37, %t38
  br i1 %t41, label %bb10, label %bb11
bb10:
  %t43 = load i64, ptr %l6, !tbaa !24
  %t45 = icmp sgt i64 %t43, 0
  br i1 %t45, label %bb12, label %bb13
bb11:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb15
bb12:
  %t47 = load i64, ptr %l5, !tbaa !24
  %t48 = load i64, ptr %l4, !tbaa !24
  %t51 = sub i64 %t47, %t48
  %t52 = load i64, ptr %l6, !tbaa !24
  %t55 = add i64 %t51, %t52
  %t57 = sub i64 %t55, 1
  %t58 = load i64, ptr %l6, !tbaa !24
  %t61 = sdiv i64 %t57, %t58
  store i64 %t61, ptr %l34, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb14
bb14:
  %t63 = load i64, ptr %l34, !tbaa !24
  store i64 %t63, ptr %l31, !tbaa !24
  br label %bb15
bb15:
  %t64 = load i64, ptr %l31, !tbaa !24
  store i64 %t64, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb16
bb16:
  %t65 = load i64, ptr %l8, !tbaa !24
  %t66 = load i64, ptr %l7, !tbaa !24
  %t69 = icmp slt i64 %t65, %t66
  %t71 = xor i1 %t69, true
  br i1 %t71, label %bb17, label %bb18
bb17:
  br label %bb36
bb18:
  br label %bb19
bb19:
  %t73 = load i64, ptr %l4, !tbaa !24
  %t74 = load i64, ptr %l8, !tbaa !24
  %t75 = load i64, ptr %l6, !tbaa !24
  %t78 = mul i64 %t74, %t75
  %t81 = add i64 %t73, %t78
  store i64 %t81, ptr %l9, !tbaa !24
  %t83 = load i64, ptr %l9, !tbaa !24
  %t85 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = getelementptr { i64, [1 x i64] }, ptr %t86, i64 %t83
  %t88 = load { i64, [1 x i64] }, ptr %t87
  %t90 = extractvalue { i64, [1 x i64] } %t88, 0
  %t91 = icmp eq i64 %t90, 3
  br i1 %t91, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t94 = load i64, ptr %l9, !tbaa !24
  %t96 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr { i64, [1 x i64] }, ptr %t97, i64 %t94
  %t99 = load { i64, [1 x i64] }, ptr %t98
  %t101 = extractvalue { i64, [1 x i64] } %t99, 0
  %t102 = icmp eq i64 %t101, 1
  %t104 = xor i1 %t102, true
  br i1 %t104, label %bb23, label %bb24
bb23:
  %t106 = load i64, ptr %l9, !tbaa !24
  %t108 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr { i64, [1 x i64] }, ptr %t109, i64 %t106
  %t111 = load { i64, [1 x i64] }, ptr %t110
  %t113 = extractvalue { i64, [1 x i64] } %t111, 0
  %t114 = icmp eq i64 %t113, 2
  %t116 = xor i1 %t114, true
  store i1 %t116, ptr %l60, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb25
bb25:
  %t118 = load i1, ptr %l60, !tbaa !21
  br i1 %t118, label %bb26, label %bb27
bb26:
  br label %bb35
bb27:
  br label %bb28
bb28:
  %t119 = load ptr, ptr %l0, !tbaa !29
  store ptr %t119, ptr %l65, !tbaa !29
  %t120 = load ptr, ptr %l0, !tbaa !29
  store ptr %t120, ptr %l66, !tbaa !29
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load %"compiler/mir:Lvalue", ptr %l1
  %t123 = load i64, ptr %l9, !tbaa !24
  %t127 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2estepType(ptr %v0, ptr %v1, ptr %t121, %"compiler/mir:Lvalue" %t122, i64 %t123)
  store i32 %t127, ptr %l70
  br label %bb29
bb29:
  %t128 = load ptr, ptr %l66, !tbaa !29
  %t129 = load i32, ptr %l70, !tbaa !23
  %t130 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %v1, ptr %t128, i32 %t129)
  store i32 %t130, ptr %l71
  br label %bb30
bb30:
  %t131 = load ptr, ptr %l65, !tbaa !29
  %t132 = load i32, ptr %l71, !tbaa !23
  %t133 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2efixedLen(ptr %v0, ptr %v1, ptr %t131, i32 %t132)
  store i64 %t133, ptr %l72
  br label %bb31
bb31:
  %t134 = load i64, ptr %l72, !tbaa !24
  %t135 = icmp slt i64 %t134, 0
  br i1 %t135, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb33:
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t138 = load i64, ptr %l8, !tbaa !24
  %t141 = add i64 %t138, 1
  store i64 %t141, ptr %l8, !tbaa !24
  br label %bb16
bb36:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2etextData(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l10 = alloca i32
  %l12 = alloca ptr
  %l14 = alloca ptr
  %l16 = alloca i32
  %l19 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t6 = alloca { i64, [2 x i64] }, align 8
  %t51 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 3
  store { i64, [2 x i64] } zeroinitializer, ptr %t6
  %t7 = getelementptr { i64, [2 x i64] }, ptr %t6, i32 0, i32 0
  store i64 1, ptr %t7
  %t9 = insertvalue { { i64, ptr } } undef, { i64, ptr } %a1, 0
  %t10 = getelementptr { i64, [2 x i64] }, ptr %t6, i32 0, i32 1
  store { { i64, ptr } } %t9, ptr %t10
  %t11 = load { i64, [2 x i64] }, ptr %t6
  %t13 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 24, i64 8)
  store { i64, [2 x i64] } %t11, ptr %t13
  %t16 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddConst(ptr %v0, ptr %s0, ptr %t3, ptr %t13)
  store i32 %t16, ptr %l10
  br label %bb1
bb1:
  %t17 = load i32, ptr %l10, !tbaa !23
  store i32 %t17, ptr %l3, !tbaa !23
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/lower:lowering", ptr %t18, i32 0, i32 2
  %t21 = load ptr, ptr %t20, !tbaa !29
  store ptr %t21, ptr %l12, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/lower:lowering", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  store ptr %t25, ptr %l14, !tbaa !29
  %t26 = load ptr, ptr %l14, !tbaa !29
  %t27 = call ptr @__olang_scope_or(ptr %v2, ptr %t26)
  %t28 = call ptr @__olang_scope_hold(ptr %t27)
  %t29 = ptrtoint ptr %t28 to i64
  %t31 = inttoptr i64 %t29 to ptr
  %t32 = load ptr, ptr %l14, !tbaa !29
  %t33 = call i32 @compiler_2flower_2ecompiler_2flower_3aLowerer_2etext(ptr %t31, ptr %t32)
  store i32 %t33, ptr %l16
  br label %bb2
bb2:
  %t34 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t35 = load ptr, ptr %l12, !tbaa !29
  %t36 = call ptr @__olang_scope_or(ptr %v3, ptr %t35)
  %t37 = call ptr @__olang_scope_hold(ptr %t36)
  %t38 = ptrtoint ptr %t37 to i64
  %t40 = inttoptr i64 %t38 to ptr
  %t41 = load ptr, ptr %l12, !tbaa !29
  %t42 = load i32, ptr %l16, !tbaa !23
  %t44 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %t40, ptr %t41, i32 %t42, i64 %t34)
  store i32 %t44, ptr %l19
  br label %bb3
bb3:
  %t45 = load i32, ptr %l3, !tbaa !23
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/lower:lowering", ptr %t46, i32 0, i32 7
  %t49 = load i64, ptr %t48, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t51
  %t52 = getelementptr { i64, [4 x i64] }, ptr %t51, i32 0, i32 0
  store i64 3, ptr %t52
  %t53 = load i32, ptr %l19, !tbaa !23
  %t54 = insertvalue { i32, i32, i64, %"compiler/source:Span" } undef, i32 %t53, 0
  %t56 = insertvalue { i32, i32, i64, %"compiler/source:Span" } %t54, i32 %t45, 1
  %t58 = insertvalue { i32, i32, i64, %"compiler/source:Span" } %t56, i64 %t49, 2
  %t60 = insertvalue { i32, i32, i64, %"compiler/source:Span" } %t58, %"compiler/source:Span" %a2, 3
  %t61 = getelementptr { i64, [4 x i64] }, ptr %t51, i32 0, i32 1
  store { i32, i32, i64, %"compiler/source:Span" } %t60, ptr %t61
  %t62 = load { i64, [4 x i64] }, ptr %t51
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t62, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2etextInto(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, { i64, [1 x i64] } %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/lower:pl"
  %l2 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l11 = alloca i32
  %l14 = alloca i32
  %l17 = alloca i32
  %l18 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca i32
  %l21 = alloca ptr
  %l22 = alloca %"compiler/lower:pl"
  %l24 = alloca %"compiler/lower:pl"
  %l25 = alloca %"compiler/mir:Lvalue"
  %l27 = alloca { i64, ptr }
  %l29 = alloca { i64, [4 x i64] }
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca i32
  %l33 = alloca i32
  %l34 = alloca { i64, [4 x i64] }
  %l36 = alloca { i64, [4 x i64] }
  %l37 = alloca { i64, ptr }
  %l39 = alloca { i64, [4 x i64] }
  %l45 = alloca ptr
  %l46 = alloca %"compiler/source:Span"
  %l47 = alloca ptr
  %l48 = alloca %"compiler/lower:pl"
  %l50 = alloca %"compiler/lower:pl"
  %l51 = alloca %"compiler/mir:Lvalue"
  %l61 = alloca ptr
  %l62 = alloca %"compiler/lower:pl"
  %l64 = alloca %"compiler/lower:pl"
  %s0 = alloca %olang.scope
  %t28 = alloca { i64, [4 x i64] }, align 8
  %t78 = alloca { i64, [8 x i64] }, align 8
  %t104 = alloca { i64, [4 x i64] }, align 8
  %t111 = alloca { i64, [15 x i64] }, align 8
  %t117 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/lower:pl" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 3
  %t5 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t3)
  store i32 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i32, ptr %l11, !tbaa !23
  store i32 %t6, ptr %l5, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/lower:lowering", ptr %t7, i32 0, i32 3
  %t11 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t9)
  store i32 %t11, ptr %l14
  br label %bb2
bb2:
  %t12 = load i32, ptr %l14, !tbaa !23
  store i32 %t12, ptr %l6, !tbaa !23
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/lower:lowering", ptr %t13, i32 0, i32 3
  %t17 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t15)
  store i32 %t17, ptr %l17
  br label %bb3
bb3:
  %t18 = load i32, ptr %l17, !tbaa !23
  store i32 %t18, ptr %l7, !tbaa !23
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l18, !tbaa !29
  store i32 22, ptr %l19
  %t20 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t20, ptr %l20, !tbaa !23
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l21, !tbaa !29
  %t22 = load %"compiler/lower:pl", ptr %l1
  store %"compiler/lower:pl" %t22, ptr %l22
  %t24 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s0, ptr %l22)
  store %"compiler/lower:pl" %t24, ptr %l24
  br label %bb4
bb4:
  %t25 = load ptr, ptr %l21, !tbaa !29
  %t26 = load %"compiler/lower:pl", ptr %l24
  %t27 = call %"compiler/mir:Lvalue" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %s0, ptr %v2, ptr %t25, %"compiler/lower:pl" %t26)
  store %"compiler/mir:Lvalue" %t27, ptr %l25
  br label %bb5
bb5:
  store { i64, [4 x i64] } zeroinitializer, ptr %t28
  %t29 = getelementptr { i64, [4 x i64] }, ptr %t28, i32 0, i32 0
  store i64 1, ptr %t29
  %t30 = load %"compiler/mir:Lvalue", ptr %l25
  %t31 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t30, 0
  %t32 = getelementptr { i64, [4 x i64] }, ptr %t28, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t31, ptr %t32
  %t33 = load { i64, [4 x i64] }, ptr %t28
  %t34 = mul i64 1, 40
  %t35 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t34)
  %t36 = insertvalue { i64, ptr } undef, i64 1, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  store { i64, ptr } %t37, ptr %l27, !tbaa !27
  %t39 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr { i64, [4 x i64] }, ptr %t40, i64 0
  store { i64, [4 x i64] } %t33, ptr %t41
  %t42 = load %"compiler/source:Span", ptr %l4
  %t43 = load ptr, ptr %l18, !tbaa !29
  %t44 = load i32, ptr %l19, !range !{i32 0, i32 54}
  %t45 = load i32, ptr %l20, !tbaa !23
  %t46 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t48 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %v3, ptr %v2, ptr %t43, i32 %t44, i32 %t45, { i64, ptr } %t46, %"compiler/source:Span" %t42)
  store { i64, [4 x i64] } %t48, ptr %l29
  br label %bb6
bb6:
  %t49 = load { i64, [4 x i64] }, ptr %l29
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l30, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l31, !tbaa !29
  store i32 17, ptr %l32
  %t52 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t52, ptr %l33, !tbaa !23
  store { i64, [4 x i64] } %t49, ptr %l34
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t54, i64 0)
  store { i64, [4 x i64] } %t56, ptr %l36
  br label %bb7
bb7:
  %t57 = mul i64 2, 40
  %t58 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t57)
  %t59 = insertvalue { i64, ptr } undef, i64 2, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  store { i64, ptr } %t60, ptr %l37, !tbaa !27
  %t61 = load { i64, [4 x i64] }, ptr %l34
  %t62 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr { i64, [4 x i64] }, ptr %t63, i64 0
  store { i64, [4 x i64] } %t61, ptr %t64
  %t65 = load { i64, [4 x i64] }, ptr %l36
  %t66 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = getelementptr { i64, [4 x i64] }, ptr %t67, i64 1
  store { i64, [4 x i64] } %t65, ptr %t68
  %t69 = load %"compiler/source:Span", ptr %l4
  %t70 = load ptr, ptr %l31, !tbaa !29
  %t71 = load i32, ptr %l32, !range !{i32 0, i32 54}
  %t72 = load i32, ptr %l33, !tbaa !23
  %t73 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t75 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %v3, ptr %v2, ptr %t70, i32 %t71, i32 %t72, { i64, ptr } %t73, %"compiler/source:Span" %t69)
  store { i64, [4 x i64] } %t75, ptr %l39
  br label %bb8
bb8:
  %t76 = load i32, ptr %l5, !tbaa !23
  %t77 = load i32, ptr %l6, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t78
  %t79 = getelementptr { i64, [8 x i64] }, ptr %t78, i32 0, i32 0
  store i64 2, ptr %t79
  %t80 = load { i64, [4 x i64] }, ptr %l39
  %t81 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t80, 0
  %t83 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t81, i32 %t76, 1
  %t85 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t83, i32 %t77, 2
  %t86 = getelementptr { i64, [8 x i64] }, ptr %t78, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t85, ptr %t86
  %t87 = load { i64, [8 x i64] }, ptr %t78
  %t88 = load ptr, ptr %l30, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %v2, ptr %v3, ptr %t88, { i64, [8 x i64] } %t87)
  br label %bb9
bb9:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t90, i32 %t91)
  br label %bb10
bb10:
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l45, !tbaa !29
  %t95 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t95, ptr %l46
  %t96 = load ptr, ptr %l0, !tbaa !29
  store ptr %t96, ptr %l47, !tbaa !29
  %t97 = load %"compiler/lower:pl", ptr %l1
  store %"compiler/lower:pl" %t97, ptr %l48
  %t99 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s0, ptr %l48)
  store %"compiler/lower:pl" %t99, ptr %l50
  br label %bb11
bb11:
  %t100 = load ptr, ptr %l47, !tbaa !29
  %t101 = load %"compiler/lower:pl", ptr %l50
  %t102 = call %"compiler/mir:Lvalue" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %s0, ptr %v2, ptr %t100, %"compiler/lower:pl" %t101)
  store %"compiler/mir:Lvalue" %t102, ptr %l51
  br label %bb12
bb12:
  %t103 = load i32, ptr %l2, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t104
  %t105 = getelementptr { i64, [4 x i64] }, ptr %t104, i32 0, i32 0
  store i64 2, ptr %t105
  %t107 = insertvalue { i32, i64 } undef, i32 %t103, 0
  %t108 = insertvalue { i32, i64 } %t107, i64 0, 1
  %t109 = getelementptr { i64, [4 x i64] }, ptr %t104, i32 0, i32 1
  store { i32, i64 } %t108, ptr %t109
  %t110 = load { i64, [4 x i64] }, ptr %t104
  store { i64, [15 x i64] } zeroinitializer, ptr %t111
  %t112 = getelementptr { i64, [15 x i64] }, ptr %t111, i32 0, i32 0
  store i64 0, ptr %t112
  %t114 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t110, 0
  %t115 = getelementptr { i64, [15 x i64] }, ptr %t111, i32 0, i32 1
  store { { i64, [4 x i64] } } %t114, ptr %t115
  %t116 = load { i64, [15 x i64] }, ptr %t111
  store { i64, [21 x i64] } zeroinitializer, ptr %t117
  %t118 = getelementptr { i64, [21 x i64] }, ptr %t117, i32 0, i32 0
  store i64 0, ptr %t118
  %t119 = load %"compiler/source:Span", ptr %l46
  %t120 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t119, 0
  %t121 = load %"compiler/mir:Lvalue", ptr %l51
  %t122 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t120, %"compiler/mir:Lvalue" %t121, 1
  %t124 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t122, { i64, [15 x i64] } %t116, 2
  %t125 = getelementptr { i64, [21 x i64] }, ptr %t117, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t124, ptr %t125
  %t126 = load { i64, [21 x i64] }, ptr %t117
  %t128 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t126, ptr %t128
  %t129 = load ptr, ptr %l45, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %v3, ptr %v2, ptr %t129, ptr %t128)
  br label %bb13
bb13:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load i32, ptr %l7, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %v2, ptr %v3, ptr %t131, i32 %t132)
  br label %bb14
bb14:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load i32, ptr %l5, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t135, i32 %t136)
  br label %bb15
bb15:
  %t139 = load ptr, ptr %l0, !tbaa !29
  store ptr %t139, ptr %l61, !tbaa !29
  %t140 = load %"compiler/lower:pl", ptr %l1
  store %"compiler/lower:pl" %t140, ptr %l62
  %t142 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s0, ptr %l62)
  store %"compiler/lower:pl" %t142, ptr %l64
  br label %bb16
bb16:
  %t143 = load i32, ptr %l2, !tbaa !23
  %t145 = load %"compiler/source:Span", ptr %l4
  %t146 = load ptr, ptr %l61, !tbaa !29
  %t147 = load %"compiler/lower:pl", ptr %l64
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ecopyPart(ptr %v0, ptr %s0, ptr %v3, ptr %v2, ptr %t146, %"compiler/lower:pl" %t147, i32 %t143, { i64, [1 x i64] } %a3, %"compiler/source:Span" %t145)
  br label %bb17
bb17:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load i32, ptr %l7, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ejoinAt(ptr %v0, ptr %v2, ptr %v3, ptr %t151, i32 %t152)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2flower_2ecompiler_2flower_3alowering_2etop(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l5 = alloca i64
  %l7 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 14
  store ptr %t3, ptr %l2, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/lower:lowering", ptr %t4, i32 0, i32 14
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l5
  br label %bb1
bb1:
  %t9 = load i64, ptr %l5, !tbaa !24
  %t10 = sub i64 %t9, 1
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t13 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eRef_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %v1, ptr %t11, i64 %t10)
  store ptr %t13, ptr %l7
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l7, !tbaa !29
  store ptr %t14, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, [1 x i64] }
  %l4 = alloca { i64, [4 x i64] }
  %l7 = alloca i1
  %l13 = alloca i64
  %l16 = alloca i1
  %l20 = alloca i1
  %l23 = alloca { i64, [4 x i64] }
  %l26 = alloca { i64, [1 x i64] }
  %l29 = alloca { i64, [4 x i64] }
  %l33 = alloca i1
  %l38 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i64
  %l41 = alloca { i64, [1 x i64] }
  %l42 = alloca { i64, [4 x i64] }
  %l44 = alloca i32
  %l46 = alloca %"compiler/source:Span"
  %l47 = alloca { i64, [4 x i64] }
  %rv = alloca { i64, [4 x i64] }
  %t11 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 12
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb3
bb2:
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = icmp eq ptr %t6, null
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb3
bb3:
  %t10 = load i1, ptr %l7, !tbaa !21
  br i1 %t10, label %bb4, label %bb5
bb4:
  store { i64, [4 x i64] } zeroinitializer, ptr %t11
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t11, i32 0, i32 0
  store i64 0, ptr %t12
  %t13 = load { i64, [4 x i64] }, ptr %t11
  store { i64, [4 x i64] } %t13, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t19 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2eregionSite(ptr %v0, ptr %v1, ptr %t15, ptr %t16)
  store i64 %t19, ptr %l13
  br label %bb7
bb7:
  %t20 = load i64, ptr %l13, !tbaa !24
  store i64 %t20, ptr %l2, !tbaa !24
  %t21 = load i64, ptr %l2, !tbaa !24
  %t23 = icmp slt i64 %t21, 0
  br i1 %t23, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb11
bb9:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/lower:lowering", ptr %t25, i32 0, i32 69
  %t28 = load i64, ptr %l2, !tbaa !24
  %t31 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t27, i64 %t28)
  store i1 %t31, ptr %l20
  br label %bb10
bb10:
  %t32 = load i1, ptr %l20, !tbaa !21
  store i1 %t32, ptr %l16, !tbaa !21
  br label %bb11
bb11:
  %t33 = load i1, ptr %l16, !tbaa !21
  br i1 %t33, label %bb12, label %bb13
bb12:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t38 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2evalue(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %t34, ptr %t35)
  store { i64, [4 x i64] } %t38, ptr %l23
  br label %bb14
bb13:
  br label %bb15
bb14:
  %t39 = load { i64, [4 x i64] }, ptr %l23
  store { i64, [4 x i64] } %t39, ptr %rv
  br label %ret
bb15:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i64, ptr %l2, !tbaa !24
  %t44 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eregionOf(ptr %v0, ptr %v4, ptr %v5, ptr %v3, ptr %v2, ptr %t40, i64 %t41)
  store { i64, [1 x i64] } %t44, ptr %l26
  br label %bb16
bb16:
  %t45 = load { i64, [1 x i64] }, ptr %l26
  store { i64, [1 x i64] } %t45, ptr %l3
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t50 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2evalue(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %t46, ptr %t47)
  store { i64, [4 x i64] } %t50, ptr %l29
  br label %bb17
bb17:
  %t51 = load { i64, [4 x i64] }, ptr %l29
  store { i64, [4 x i64] } %t51, ptr %l4
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/lower:lowering", ptr %t52, i32 0, i32 54
  %t55 = load i64, ptr %l2, !tbaa !24
  %t58 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t54, i64 %t55)
  store i1 %t58, ptr %l33
  br label %bb18
bb18:
  %t59 = load i1, ptr %l33, !tbaa !21
  %t60 = xor i1 %t59, true
  br i1 %t60, label %bb19, label %bb20
bb19:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/lower:lowering", ptr %t62, i32 0, i32 40
  %t65 = load i64, ptr %l2, !tbaa !24
  %t68 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fmir_3aLocalId_3e_2_Hf0fb0e232c68e27195d0770621b0035a(ptr %v0, ptr %t64, i64 %t65)
  store i1 %t68, ptr %l38
  br label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb22
bb22:
  %t69 = load ptr, ptr %l0, !tbaa !29
  store ptr %t69, ptr %l39, !tbaa !29
  %t70 = load i64, ptr %l2, !tbaa !24
  store i64 %t70, ptr %l40, !tbaa !24
  %t71 = load { i64, [1 x i64] }, ptr %l3
  store { i64, [1 x i64] } %t71, ptr %l41
  %t72 = load { i64, [4 x i64] }, ptr %l4
  store { i64, [4 x i64] } %t72, ptr %l42
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t73)
  store i32 %t75, ptr %l44
  br label %bb23
bb23:
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t76)
  store %"compiler/source:Span" %t78, ptr %l46
  br label %bb24
bb24:
  %t79 = load ptr, ptr %l39, !tbaa !29
  %t80 = load i64, ptr %l40, !tbaa !24
  %t81 = load { i64, [1 x i64] }, ptr %l41
  %t82 = load { i64, [4 x i64] }, ptr %l42
  %t83 = load i32, ptr %l44, !tbaa !23
  %t84 = load %"compiler/source:Span", ptr %l46
  %t85 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2esettled(ptr %v0, ptr %v3, ptr %v2, ptr %t79, i64 %t80, { i64, [1 x i64] } %t81, { i64, [4 x i64] } %t82, i32 %t83, %"compiler/source:Span" %t84)
  store { i64, [4 x i64] } %t85, ptr %l47
  br label %bb25
bb25:
  %t86 = load { i64, [4 x i64] }, ptr %l47
  store { i64, [4 x i64] } %t86, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eviewCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca i1
  %l18 = alloca i1
  %l20 = alloca ptr
  %l23 = alloca i64
  %l25 = alloca i1
  %l28 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Call", ptr %a1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  store ptr %t6, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t7 = load ptr, ptr %l9, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l9, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 5}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l10, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l3, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { i32 }, ptr %t17, i32 0, i32 0
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l4, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t21 = load i32, ptr %l4, !tbaa !23
  store i32 %t21, ptr %l8, !tbaa !23
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i32 -1, ptr %l8, !tbaa !23
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_8878eb20a40721c6_39b06fa96ecc3992)
  unreachable
bb11:
  %t23 = load i32, ptr %l8, !tbaa !23
  store i32 %t23, ptr %l5, !tbaa !23
  %t24 = load i32, ptr %l5, !tbaa !23
  %t26 = icmp sge i32 %t24, 0
  br i1 %t26, label %bb12, label %bb13
bb12:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/lower:lowering", ptr %t28, i32 0, i32 0
  %t31 = load ptr, ptr %t30, !tbaa !29
  store ptr %t31, ptr %l20, !tbaa !29
  %t32 = load i32, ptr %l5, !tbaa !23
  %t33 = load ptr, ptr %l20, !tbaa !29
  %t34 = call ptr @__olang_scope_or(ptr %v2, ptr %t33)
  %t35 = call ptr @__olang_scope_hold(ptr %t34)
  %t36 = ptrtoint ptr %t35 to i64
  %t38 = inttoptr i64 %t36 to ptr
  %t39 = load ptr, ptr %l20, !tbaa !29
  %t41 = call i64 @compiler_2flower_2ecompiler_2flower_3aLowerer_2eViewsOf(ptr %t38, ptr %t39, i32 %t32)
  store i64 %t41, ptr %l23
  br label %bb14
bb13:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb15
bb14:
  %t42 = load i64, ptr %l23, !tbaa !24
  %t43 = icmp sgt i64 %t42, 0
  store i1 %t43, ptr %l18, !tbaa !21
  br label %bb15
bb15:
  %t45 = load i1, ptr %l18, !tbaa !21
  br i1 %t45, label %bb16, label %bb17
bb16:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t50 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eviewValue(ptr %v0, ptr %v3, ptr %t46, i32 %a2)
  store i1 %t50, ptr %l28
  br label %bb18
bb17:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb19
bb18:
  %t51 = load i1, ptr %l28, !tbaa !21
  store i1 %t51, ptr %l25, !tbaa !21
  br label %bb19
bb19:
  %t52 = load i1, ptr %l25, !tbaa !21
  store i1 %t52, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eviewCopied(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, [4 x i64] } %a2, i32 %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [4 x i64] }
  %l3 = alloca i32
  %l5 = alloca { i64, [1 x i64] }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca ptr
  %l16 = alloca i64
  %l18 = alloca i1
  %l21 = alloca i1
  %l27 = alloca i64
  %l31 = alloca i64
  %l34 = alloca i64
  %l55 = alloca { i64, [1 x i64] }
  %l68 = alloca { i64, [4 x i64] }
  %rv = alloca { i64, [4 x i64] }
  %t29 = alloca { i64, [1 x i64] }, align 8
  %t100 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, [4 x i64] } %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l13, !tbaa !29
  %t6 = load ptr, ptr %l13, !tbaa !29
  %t7 = call ptr @__olang_scope_or(ptr %v1, ptr %t6)
  %t8 = call ptr @__olang_scope_hold(ptr %t7)
  %t9 = ptrtoint ptr %t8 to i64
  %t11 = inttoptr i64 %t9 to ptr
  %t12 = load ptr, ptr %l13, !tbaa !29
  %t14 = call i64 @compiler_2flower_2ecompiler_2flower_3aLowerer_2eViewsOf(ptr %t11, ptr %t12, i32 %a1)
  store i64 %t14, ptr %l16
  br label %bb1
bb1:
  %t15 = load i64, ptr %l16, !tbaa !24
  %t16 = icmp sle i64 %t15, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb5
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l3, !tbaa !23
  %t22 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2evalueArray(ptr %v0, ptr %v2, ptr %t18, i32 %t19)
  store i1 %t22, ptr %l21
  br label %bb4
bb4:
  %t23 = load i1, ptr %l21, !tbaa !21
  %t24 = xor i1 %t23, true
  store i1 %t24, ptr %l18, !tbaa !21
  br label %bb5
bb5:
  %t26 = load i1, ptr %l18, !tbaa !21
  br i1 %t26, label %bb6, label %bb7
bb6:
  %t27 = load { i64, [4 x i64] }, ptr %l2
  store { i64, [4 x i64] } %t27, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  store { i64, [1 x i64] } zeroinitializer, ptr %t29
  %t30 = getelementptr { i64, [1 x i64] }, ptr %t29, i32 0, i32 0
  store i64 2, ptr %t30
  %t31 = load { i64, [1 x i64] }, ptr %t29
  store { i64, [1 x i64] } %t31, ptr %l5
  store i64 0, ptr %l6, !tbaa !24
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/lower:lowering", ptr %t33, i32 0, i32 3
  %t36 = getelementptr %"compiler/mir:Fn", ptr %t35, i32 0, i32 6
  %t38 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eLen_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %t36)
  store i64 %t38, ptr %l27
  br label %bb9
bb9:
  %t39 = load i64, ptr %l27, !tbaa !24
  store i64 %t39, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t40 = load i64, ptr %l7, !tbaa !24
  %t41 = load i64, ptr %l6, !tbaa !24
  %t44 = icmp sgt i64 %t40, %t41
  br i1 %t44, label %bb10, label %bb11
bb10:
  %t46 = load i64, ptr %l8, !tbaa !24
  %t48 = icmp sgt i64 %t46, 0
  br i1 %t48, label %bb12, label %bb13
bb11:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb15
bb12:
  %t50 = load i64, ptr %l7, !tbaa !24
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = sub i64 %t50, %t51
  %t55 = load i64, ptr %l8, !tbaa !24
  %t58 = add i64 %t54, %t55
  %t60 = sub i64 %t58, 1
  %t61 = load i64, ptr %l8, !tbaa !24
  %t64 = sdiv i64 %t60, %t61
  store i64 %t64, ptr %l34, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb14
bb14:
  %t66 = load i64, ptr %l34, !tbaa !24
  store i64 %t66, ptr %l31, !tbaa !24
  br label %bb15
bb15:
  %t67 = load i64, ptr %l31, !tbaa !24
  store i64 %t67, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb16
bb16:
  %t68 = load i64, ptr %l10, !tbaa !24
  %t69 = load i64, ptr %l9, !tbaa !24
  %t72 = icmp slt i64 %t68, %t69
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb17, label %bb18
bb17:
  br label %bb25
bb18:
  br label %bb19
bb19:
  %t76 = load i64, ptr %l6, !tbaa !24
  %t77 = load i64, ptr %l10, !tbaa !24
  %t78 = load i64, ptr %l8, !tbaa !24
  %t81 = mul i64 %t77, %t78
  %t84 = add i64 %t76, %t81
  store i64 %t84, ptr %l11, !tbaa !24
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/lower:lowering", ptr %t86, i32 0, i32 3
  %t89 = getelementptr %"compiler/mir:Fn", ptr %t88, i32 0, i32 6
  %t90 = load i64, ptr %l11, !tbaa !24
  %t93 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eAt_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %t89, i64 %t90)
  store { i64, [1 x i64] } %t93, ptr %l55
  br label %bb20
bb20:
  %t94 = load { i64, [1 x i64] }, ptr %l55
  %t96 = extractvalue { i64, [1 x i64] } %t94, 0
  %t97 = icmp eq i64 %t96, 1
  br i1 %t97, label %bb21, label %bb22
bb21:
  %t99 = load i64, ptr %l11, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t100
  %t101 = getelementptr { i64, [1 x i64] }, ptr %t100, i32 0, i32 0
  store i64 1, ptr %t101
  %t103 = insertvalue { i64 } undef, i64 %t99, 0
  %t104 = getelementptr { i64, [1 x i64] }, ptr %t100, i32 0, i32 1
  store { i64 } %t103, ptr %t104
  %t105 = load { i64, [1 x i64] }, ptr %t100
  store { i64, [1 x i64] } %t105, ptr %l5
  br label %bb23
bb22:
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t107 = load i64, ptr %l10, !tbaa !24
  %t110 = add i64 %t107, 1
  store i64 %t110, ptr %l10, !tbaa !24
  br label %bb16
bb25:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load { i64, [4 x i64] }, ptr %l2
  %t114 = load i32, ptr %l3, !tbaa !23
  %t116 = load { i64, [1 x i64] }, ptr %l5
  %t122 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2earrayCopy(ptr %v0, ptr %v2, ptr %v1, ptr %t112, { i64, [4 x i64] } %t113, i32 %t114, %"compiler/source:Span" %a4, { i64, [1 x i64] } %t116, i1 false)
  store { i64, [4 x i64] } %t122, ptr %l68
  br label %bb26
bb26:
  %t123 = load { i64, [4 x i64] }, ptr %l68
  store { i64, [4 x i64] } %t123, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local i32 @compiler_2flower_2ecompiler_2flower_3alowering_2ewhenSole(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, i1 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca { i64, [4 x i64] }
  %l11 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca %"compiler/source:Span"
  %l15 = alloca %"compiler/mir:Lvalue"
  %l22 = alloca i32
  %l25 = alloca i32
  %l27 = alloca %"compiler/mir:Lvalue"
  %l29 = alloca ptr
  %l31 = alloca { i64, [8 x i64] }
  %s0 = alloca %olang.scope
  %rv = alloca i32
  %t15 = alloca { i64, [15 x i64] }, align 8
  %t21 = alloca { i64, [21 x i64] }, align 8
  %t50 = alloca { i64, [4 x i64] }, align 8
  %t63 = alloca { i64, [8 x i64] }, align 8
  %t77 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t3 = load %"compiler/source:Span", ptr %l3
  %t7 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t1, i32 %t2, %"compiler/source:Span" %t3)
  store i32 %t7, ptr %l11
  br label %bb1
bb1:
  %t8 = load i32, ptr %l11, !tbaa !23
  store i32 %t8, ptr %l4, !tbaa !23
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l12, !tbaa !29
  %t10 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t10, ptr %l13
  %t11 = load i32, ptr %l4, !tbaa !23
  %t13 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t11)
  store %"compiler/mir:Lvalue" %t13, ptr %l15
  br label %bb2
bb2:
  store { i64, [15 x i64] } zeroinitializer, ptr %t15
  %t16 = getelementptr { i64, [15 x i64] }, ptr %t15, i32 0, i32 0
  store i64 19, ptr %t16
  %t18 = insertvalue { i64 } undef, i64 %a1, 0
  %t19 = getelementptr { i64, [15 x i64] }, ptr %t15, i32 0, i32 1
  store { i64 } %t18, ptr %t19
  %t20 = load { i64, [15 x i64] }, ptr %t15
  store { i64, [21 x i64] } zeroinitializer, ptr %t21
  %t22 = getelementptr { i64, [21 x i64] }, ptr %t21, i32 0, i32 0
  store i64 0, ptr %t22
  %t23 = load %"compiler/source:Span", ptr %l13
  %t24 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t23, 0
  %t25 = load %"compiler/mir:Lvalue", ptr %l15
  %t26 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t24, %"compiler/mir:Lvalue" %t25, 1
  %t28 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t26, { i64, [15 x i64] } %t20, 2
  %t29 = getelementptr { i64, [21 x i64] }, ptr %t21, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t28, ptr %t29
  %t30 = load { i64, [21 x i64] }, ptr %t21
  %t32 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t30, ptr %t32
  %t33 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %v1, ptr %v2, ptr %t33, ptr %t32)
  br label %bb3
bb3:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/lower:lowering", ptr %t35, i32 0, i32 3
  %t39 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t37)
  store i32 %t39, ptr %l22
  br label %bb4
bb4:
  %t40 = load i32, ptr %l22, !tbaa !23
  store i32 %t40, ptr %l5, !tbaa !23
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/lower:lowering", ptr %t41, i32 0, i32 3
  %t45 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t43)
  store i32 %t45, ptr %l25
  br label %bb5
bb5:
  %t46 = load i32, ptr %l25, !tbaa !23
  store i32 %t46, ptr %l6, !tbaa !23
  %t47 = load i32, ptr %l4, !tbaa !23
  %t49 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t47)
  store %"compiler/mir:Lvalue" %t49, ptr %l27
  br label %bb6
bb6:
  store { i64, [4 x i64] } zeroinitializer, ptr %t50
  %t51 = getelementptr { i64, [4 x i64] }, ptr %t50, i32 0, i32 0
  store i64 1, ptr %t51
  %t52 = load %"compiler/mir:Lvalue", ptr %l27
  %t53 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t52, 0
  %t54 = getelementptr { i64, [4 x i64] }, ptr %t50, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t53, ptr %t54
  %t55 = load { i64, [4 x i64] }, ptr %t50
  store { i64, [4 x i64] } %t55, ptr %l7
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l29, !tbaa !29
  br i1 %a2, label %bb7, label %bb8
bb7:
  %t60 = load { i64, [4 x i64] }, ptr %l7
  %t61 = load i32, ptr %l5, !tbaa !23
  %t62 = load i32, ptr %l6, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t63
  %t64 = getelementptr { i64, [8 x i64] }, ptr %t63, i32 0, i32 0
  store i64 2, ptr %t64
  %t66 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t60, 0
  %t68 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t66, i32 %t61, 1
  %t70 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t68, i32 %t62, 2
  %t71 = getelementptr { i64, [8 x i64] }, ptr %t63, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t70, ptr %t71
  %t72 = load { i64, [8 x i64] }, ptr %t63
  store { i64, [8 x i64] } %t72, ptr %l31
  br label %bb9
bb8:
  %t74 = load { i64, [4 x i64] }, ptr %l7
  %t75 = load i32, ptr %l6, !tbaa !23
  %t76 = load i32, ptr %l5, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t77
  %t78 = getelementptr { i64, [8 x i64] }, ptr %t77, i32 0, i32 0
  store i64 2, ptr %t78
  %t80 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t74, 0
  %t82 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t80, i32 %t75, 1
  %t84 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t82, i32 %t76, 2
  %t85 = getelementptr { i64, [8 x i64] }, ptr %t77, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t84, ptr %t85
  %t86 = load { i64, [8 x i64] }, ptr %t77
  store { i64, [8 x i64] } %t86, ptr %l31
  br label %bb9
bb9:
  %t88 = load ptr, ptr %l29, !tbaa !29
  %t89 = load { i64, [8 x i64] }, ptr %l31
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %v2, ptr %v1, ptr %t88, { i64, [8 x i64] } %t89)
  br label %bb10
bb10:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load i32, ptr %l5, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t90, i32 %t91)
  br label %bb11
bb11:
  %t94 = load i32, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t94, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ewidening(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca ptr
  %l9 = alloca i1
  %l13 = alloca i1
  %l16 = alloca i1
  %l17 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l22 = alloca i32
  %l24 = alloca i32
  %l26 = alloca i1
  %l28 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l32 = alloca i32
  %l33 = alloca i32
  %l36 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca ptr
  %l39 = alloca { i64, ptr }
  %l41 = alloca i32
  %l42 = alloca i32
  %l43 = alloca i64
  %l45 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca { i64, ptr }
  %l49 = alloca i32
  %l51 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t8 = trunc i64 20 to i32
  %t9 = icmp eq i32 %a1, %t8
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t15 = icmp eq i64 %t13, 1
  store i1 %t15, ptr %l9, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb3
bb3:
  %t17 = load i1, ptr %l9, !tbaa !21
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l3, !tbaa !23
  %t22 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2evalueArray(ptr %v0, ptr %v2, ptr %t18, i32 %t19)
  store i1 %t22, ptr %l16
  br label %bb6
bb5:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb7
bb6:
  %t23 = load i1, ptr %l16, !tbaa !21
  store i1 %t23, ptr %l13, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l13, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l4, !tbaa !29
  store ptr %t25, ptr %l18, !tbaa !29
  %t26 = load ptr, ptr %l4, !tbaa !29
  store ptr %t26, ptr %l19, !tbaa !29
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t27, ptr %l20, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr ptr, ptr %t29, i64 0
  %t31 = load ptr, ptr %t30, !tbaa !39
  %t33 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t31)
  store i32 %t33, ptr %l22
  br label %bb10
bb9:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb13
bb10:
  %t34 = load ptr, ptr %l19, !tbaa !29
  %t35 = call ptr @__olang_scope_or(ptr %v2, ptr %t34)
  %t36 = call ptr @__olang_scope_hold(ptr %t35)
  %t37 = ptrtoint ptr %t36 to i64
  %t39 = inttoptr i64 %t37 to ptr
  %t40 = load ptr, ptr %l19, !tbaa !29
  %t41 = load i32, ptr %l22, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t39, ptr %t40, i32 %t41)
  store i32 %t42, ptr %l24
  br label %bb11
bb11:
  %t43 = load ptr, ptr %l18, !tbaa !29
  %t44 = call ptr @__olang_scope_or(ptr %v2, ptr %t43)
  %t45 = call ptr @__olang_scope_hold(ptr %t44)
  %t46 = ptrtoint ptr %t45 to i64
  %t48 = inttoptr i64 %t46 to ptr
  %t49 = load ptr, ptr %l18, !tbaa !29
  %t50 = load i32, ptr %l24, !tbaa !23
  %t51 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t48, ptr %t49, i32 %t50)
  store i1 %t51, ptr %l26
  br label %bb12
bb12:
  %t52 = load i1, ptr %l26, !tbaa !21
  %t53 = xor i1 %t52, true
  store i1 %t53, ptr %l17, !tbaa !21
  br label %bb13
bb13:
  %t55 = load i1, ptr %l17, !tbaa !21
  br i1 %t55, label %bb14, label %bb15
bb14:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l29, !tbaa !29
  %t57 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t57, ptr %l30, !tbaa !27
  %t58 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr ptr, ptr %t59, i64 0
  %t61 = load ptr, ptr %t60, !tbaa !39
  %t63 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t61)
  store i32 %t63, ptr %l32
  br label %bb16
bb15:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb18
bb16:
  %t64 = load ptr, ptr %l29, !tbaa !29
  %t65 = load i32, ptr %l32, !tbaa !23
  %t66 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %v2, ptr %t64, i32 %t65)
  store i32 %t66, ptr %l33
  br label %bb17
bb17:
  %t67 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t68 = load i32, ptr %l33, !tbaa !23
  %t70 = icmp ne i32 %t68, %t67
  store i1 %t70, ptr %l28, !tbaa !21
  br label %bb18
bb18:
  %t72 = load i1, ptr %l28, !tbaa !21
  br i1 %t72, label %bb19, label %bb20
bb19:
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l37, !tbaa !29
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l38, !tbaa !29
  %t75 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t75, ptr %l39, !tbaa !27
  %t76 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr ptr, ptr %t77, i64 0
  %t79 = load ptr, ptr %t78, !tbaa !39
  %t81 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t79)
  store i32 %t81, ptr %l41
  br label %bb21
bb20:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb29
bb21:
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = load i32, ptr %l41, !tbaa !23
  %t84 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %v2, ptr %t82, i32 %t83)
  store i32 %t84, ptr %l42
  br label %bb22
bb22:
  %t85 = load ptr, ptr %l37, !tbaa !29
  %t86 = load i32, ptr %l42, !tbaa !23
  %t87 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2efixedLen(ptr %v0, ptr %v2, ptr %t85, i32 %t86)
  store i64 %t87, ptr %l43
  br label %bb23
bb23:
  %t88 = load i64, ptr %l43, !tbaa !24
  %t89 = icmp sge i64 %t88, 0
  br i1 %t89, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb28
bb25:
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l46, !tbaa !29
  %t92 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t92, ptr %l47, !tbaa !27
  %t93 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr ptr, ptr %t94, i64 0
  %t96 = load ptr, ptr %t95, !tbaa !39
  %t98 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t96)
  store i32 %t98, ptr %l49
  br label %bb26
bb26:
  %t99 = load i32, ptr %l3, !tbaa !23
  %t100 = load ptr, ptr %l46, !tbaa !29
  %t101 = load i32, ptr %l49, !tbaa !23
  %t103 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2econvertsApart(ptr %v0, ptr %v2, ptr %t100, i32 %t101, i32 %t99)
  store i1 %t103, ptr %l51
  br label %bb27
bb27:
  %t104 = load i1, ptr %l51, !tbaa !21
  store i1 %t104, ptr %l45, !tbaa !21
  br label %bb28
bb28:
  %t105 = load i1, ptr %l45, !tbaa !21
  store i1 %t105, ptr %l36, !tbaa !21
  br label %bb29
bb29:
  %t106 = load i1, ptr %l36, !tbaa !21
  store i1 %t106, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ewritesCover(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i1
  %l12 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca i1
  %l21 = alloca i1
  %l22 = alloca i32
  %l30 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %l2, !tbaa !24
  %t8 = icmp sgt i64 %t6, 16
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t11 = load ptr, ptr %l3, !tbaa !29
  store ptr %t11, ptr %l12, !tbaa !29
  %t13 = load ptr, ptr %l12, !tbaa !29
  %t14 = call ptr @__olang_scope_or(ptr %v1, ptr %t13)
  %t15 = call ptr @__olang_scope_hold(ptr %t14)
  %t16 = ptrtoint ptr %t15 to i64
  %t18 = inttoptr i64 %t16 to ptr
  %t19 = load ptr, ptr %l12, !tbaa !29
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t18, ptr %t19, i32 %a1)
  store i32 %t21, ptr %l15
  br label %bb4
bb4:
  %t22 = load i32, ptr %l15, !tbaa !23
  store i32 %t22, ptr %l4, !tbaa !23
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/lower:lowering", ptr %t23, i32 0, i32 75
  %t26 = load i32, ptr %l4, !tbaa !23
  %t28 = sext i32 %t26 to i64
  %t31 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %t25, i64 %t28)
  %t32 = extractvalue { i32, i1 } %t31, 1
  %t33 = extractvalue { i32, i1 } %t31, 0
  store i32 %t33, ptr %l22
  %t34 = icmp ne i32 %t33, 0
  br i1 %t34, label %bb6, label %ok.35, !prof !99
ok.35:
  store i1 %t32, ptr %l21
  br label %bb5
bb5:
  %t36 = load i1, ptr %l21, !tbaa !21
  store i1 %t36, ptr %l16, !tbaa !21
  br label %bb11
bb6:
  br label %bb7
bb7:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/lower:lowering", ptr %t37, i32 0, i32 75
  %t40 = load i32, ptr %l4, !tbaa !23
  %t42 = sext i32 %t40 to i64
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t39, i64 %t42, i1 false)
  br label %bb8
bb8:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load i32, ptr %l4, !tbaa !23
  %t47 = load i64, ptr %l2, !tbaa !24
  %t51 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ewritesOf(ptr %v0, ptr %v1, ptr %t45, i32 %t46, i64 %t47)
  store i1 %t51, ptr %l30
  br label %bb9
bb9:
  %t52 = load i1, ptr %l30, !tbaa !21
  store i1 %t52, ptr %l5, !tbaa !21
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/lower:lowering", ptr %t53, i32 0, i32 75
  %t56 = load i32, ptr %l4, !tbaa !23
  %t58 = sext i32 %t56 to i64
  %t59 = load i1, ptr %l5, !tbaa !21
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t55, i64 %t58, i1 %t59)
  br label %bb10
bb10:
  %t63 = load i1, ptr %l5, !tbaa !21
  store i1 %t63, ptr %rv
  br label %ret
bb11:
  %t65 = load i1, ptr %l16, !tbaa !21
  store i1 %t65, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ezeroEmpty(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/mir:Lvalue" %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Lvalue"
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca i32
  %l6 = alloca i32
  %l8 = alloca ptr
  %l11 = alloca i1
  %l13 = alloca i1
  %l21 = alloca { i64, ptr }
  %l23 = alloca { i64, [4 x i64] }
  %l26 = alloca i32
  %l29 = alloca i32
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca i32
  %l33 = alloca i32
  %l34 = alloca { i64, [4 x i64] }
  %l36 = alloca { i64, [4 x i64] }
  %l37 = alloca { i64, ptr }
  %l39 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  %t27 = alloca { i64, [4 x i64] }, align 8
  %t89 = alloca { i64, [8 x i64] }, align 8
  %t109 = alloca { i64, [4 x i64] }, align 8
  %t116 = alloca { i64, [15 x i64] }, align 8
  %t122 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/mir:Lvalue" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l8, !tbaa !29
  %t5 = load i32, ptr %l2, !tbaa !23
  %t6 = load ptr, ptr %l8, !tbaa !29
  %t7 = call ptr @__olang_scope_or(ptr %v1, ptr %t6)
  %t8 = call ptr @__olang_scope_hold(ptr %t7)
  %t9 = ptrtoint ptr %t8 to i64
  %t11 = inttoptr i64 %t9 to ptr
  %t12 = load ptr, ptr %l8, !tbaa !29
  %t14 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %t11, ptr %t12, i32 %t5)
  store i1 %t14, ptr %l11
  br label %bb1
bb1:
  %t15 = load i1, ptr %l11, !tbaa !21
  %t16 = xor i1 %t15, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb4
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/lower:lowering", ptr %t18, i32 0, i32 12
  %t21 = load i1, ptr %t20, !tbaa !21
  store i1 %t21, ptr %l13, !tbaa !21
  br label %bb4
bb4:
  %t23 = load i1, ptr %l13, !tbaa !21
  br i1 %t23, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  br label %bb7
bb7:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t26 = load %"compiler/mir:Lvalue", ptr %l1
  store { i64, [4 x i64] } zeroinitializer, ptr %t27
  %t28 = getelementptr { i64, [4 x i64] }, ptr %t27, i32 0, i32 0
  store i64 1, ptr %t28
  %t30 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t26, 0
  %t31 = getelementptr { i64, [4 x i64] }, ptr %t27, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t30, ptr %t31
  %t32 = load { i64, [4 x i64] }, ptr %t27
  %t33 = mul i64 1, 40
  %t34 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t33)
  %t35 = insertvalue { i64, ptr } undef, i64 1, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  store { i64, ptr } %t36, ptr %l21, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t39, i64 0
  store { i64, [4 x i64] } %t32, ptr %t40
  %t41 = load %"compiler/source:Span", ptr %l3
  %t45 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t47 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %v1, ptr %v2, ptr %t24, i32 22, i32 %t25, { i64, ptr } %t45, %"compiler/source:Span" %t41)
  store { i64, [4 x i64] } %t47, ptr %l23
  br label %bb8
bb8:
  %t48 = load { i64, [4 x i64] }, ptr %l23
  store { i64, [4 x i64] } %t48, ptr %l4
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/lower:lowering", ptr %t49, i32 0, i32 3
  %t53 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t51)
  store i32 %t53, ptr %l26
  br label %bb9
bb9:
  %t54 = load i32, ptr %l26, !tbaa !23
  store i32 %t54, ptr %l5, !tbaa !23
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/lower:lowering", ptr %t55, i32 0, i32 3
  %t59 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t57)
  store i32 %t59, ptr %l29
  br label %bb10
bb10:
  %t60 = load i32, ptr %l29, !tbaa !23
  store i32 %t60, ptr %l6, !tbaa !23
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l30, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  store ptr %t62, ptr %l31, !tbaa !29
  store i32 13, ptr %l32
  %t63 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t63, ptr %l33, !tbaa !23
  %t64 = load { i64, [4 x i64] }, ptr %l4
  store { i64, [4 x i64] } %t64, ptr %l34
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t65, i64 0)
  store { i64, [4 x i64] } %t67, ptr %l36
  br label %bb11
bb11:
  %t68 = mul i64 2, 40
  %t69 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t68)
  %t70 = insertvalue { i64, ptr } undef, i64 2, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t69, 1
  store { i64, ptr } %t71, ptr %l37, !tbaa !27
  %t72 = load { i64, [4 x i64] }, ptr %l34
  %t73 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr { i64, [4 x i64] }, ptr %t74, i64 0
  store { i64, [4 x i64] } %t72, ptr %t75
  %t76 = load { i64, [4 x i64] }, ptr %l36
  %t77 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr { i64, [4 x i64] }, ptr %t78, i64 1
  store { i64, [4 x i64] } %t76, ptr %t79
  %t80 = load %"compiler/source:Span", ptr %l3
  %t81 = load ptr, ptr %l31, !tbaa !29
  %t82 = load i32, ptr %l32, !range !{i32 0, i32 54}
  %t83 = load i32, ptr %l33, !tbaa !23
  %t84 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t86 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %v1, ptr %v2, ptr %t81, i32 %t82, i32 %t83, { i64, ptr } %t84, %"compiler/source:Span" %t80)
  store { i64, [4 x i64] } %t86, ptr %l39
  br label %bb12
bb12:
  %t87 = load i32, ptr %l5, !tbaa !23
  %t88 = load i32, ptr %l6, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t89
  %t90 = getelementptr { i64, [8 x i64] }, ptr %t89, i32 0, i32 0
  store i64 2, ptr %t90
  %t91 = load { i64, [4 x i64] }, ptr %l39
  %t92 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t91, 0
  %t94 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t92, i32 %t87, 1
  %t96 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t94, i32 %t88, 2
  %t97 = getelementptr { i64, [8 x i64] }, ptr %t89, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t96, ptr %t97
  %t98 = load { i64, [8 x i64] }, ptr %t89
  %t99 = load ptr, ptr %l30, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %v2, ptr %v1, ptr %t99, { i64, [8 x i64] } %t98)
  br label %bb13
bb13:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load i32, ptr %l5, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t101, i32 %t102)
  br label %bb14
bb14:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load %"compiler/source:Span", ptr %l3
  %t107 = load %"compiler/mir:Lvalue", ptr %l1
  %t108 = load i32, ptr %l2, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t109
  %t110 = getelementptr { i64, [4 x i64] }, ptr %t109, i32 0, i32 0
  store i64 2, ptr %t110
  %t112 = insertvalue { i32, i64 } undef, i32 %t108, 0
  %t113 = insertvalue { i32, i64 } %t112, i64 0, 1
  %t114 = getelementptr { i64, [4 x i64] }, ptr %t109, i32 0, i32 1
  store { i32, i64 } %t113, ptr %t114
  %t115 = load { i64, [4 x i64] }, ptr %t109
  store { i64, [15 x i64] } zeroinitializer, ptr %t116
  %t117 = getelementptr { i64, [15 x i64] }, ptr %t116, i32 0, i32 0
  store i64 0, ptr %t117
  %t119 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t115, 0
  %t120 = getelementptr { i64, [15 x i64] }, ptr %t116, i32 0, i32 1
  store { { i64, [4 x i64] } } %t119, ptr %t120
  %t121 = load { i64, [15 x i64] }, ptr %t116
  store { i64, [21 x i64] } zeroinitializer, ptr %t122
  %t123 = getelementptr { i64, [21 x i64] }, ptr %t122, i32 0, i32 0
  store i64 0, ptr %t123
  %t125 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t106, 0
  %t127 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t125, %"compiler/mir:Lvalue" %t107, 1
  %t129 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t127, { i64, [15 x i64] } %t121, 2
  %t130 = getelementptr { i64, [21 x i64] }, ptr %t122, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t129, ptr %t130
  %t131 = load { i64, [21 x i64] }, ptr %t122
  %t133 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t131, ptr %t133
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %v1, ptr %v2, ptr %t105, ptr %t133)
  br label %bb15
bb15:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ejoinAt(ptr %v0, ptr %v2, ptr %v1, ptr %t136, i32 %t137)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ezeroLocal(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i32
  %l7 = alloca %"compiler/mir:Local"
  %l10 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca %"compiler/source:Span"
  %l17 = alloca %"compiler/mir:Lvalue"
  %l21 = alloca { i64, [21 x i64] }
  %s0 = alloca %olang.scope
  %t27 = alloca { i64, [4 x i64] }, align 8
  %t34 = alloca { i64, [15 x i64] }, align 8
  %t40 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 3
  %t4 = getelementptr %"compiler/mir:Fn", ptr %t3, i32 0, i32 7
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t4, i64 %t5)
  store %"compiler/mir:Local" %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = getelementptr %"compiler/mir:Local", ptr %l7, i32 0, i32 2
  %t10 = load i32, ptr %t9, !tbaa !23
  store i32 %t10, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lower:lowering", ptr %t12, i32 0, i32 3
  store ptr %t14, ptr %l10, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/lower:lowering", ptr %t15, i32 0, i32 11
  %t18 = load i32, ptr %t17, !tbaa !23
  store i32 %t18, ptr %l12, !tbaa !23
  store %"compiler/source:Span" %a2, ptr %l13
  %t20 = load i64, ptr %l1, !tbaa !24
  %t22 = trunc i64 %t20 to i32
  %t25 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t22)
  store %"compiler/mir:Lvalue" %t25, ptr %l17
  br label %bb2
bb2:
  %t26 = load i32, ptr %l3, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t27
  %t28 = getelementptr { i64, [4 x i64] }, ptr %t27, i32 0, i32 0
  store i64 2, ptr %t28
  %t30 = insertvalue { i32, i64 } undef, i32 %t26, 0
  %t31 = insertvalue { i32, i64 } %t30, i64 0, 1
  %t32 = getelementptr { i64, [4 x i64] }, ptr %t27, i32 0, i32 1
  store { i32, i64 } %t31, ptr %t32
  %t33 = load { i64, [4 x i64] }, ptr %t27
  store { i64, [15 x i64] } zeroinitializer, ptr %t34
  %t35 = getelementptr { i64, [15 x i64] }, ptr %t34, i32 0, i32 0
  store i64 0, ptr %t35
  %t37 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t33, 0
  %t38 = getelementptr { i64, [15 x i64] }, ptr %t34, i32 0, i32 1
  store { { i64, [4 x i64] } } %t37, ptr %t38
  %t39 = load { i64, [15 x i64] }, ptr %t34
  store { i64, [21 x i64] } zeroinitializer, ptr %t40
  %t41 = getelementptr { i64, [21 x i64] }, ptr %t40, i32 0, i32 0
  store i64 0, ptr %t41
  %t42 = load %"compiler/source:Span", ptr %l13
  %t43 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t42, 0
  %t44 = load %"compiler/mir:Lvalue", ptr %l17
  %t45 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t43, %"compiler/mir:Lvalue" %t44, 1
  %t47 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t45, { i64, [15 x i64] } %t39, 2
  %t48 = getelementptr { i64, [21 x i64] }, ptr %t40, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t47, ptr %t48
  %t49 = load { i64, [21 x i64] }, ptr %t40
  store { i64, [21 x i64] } %t49, ptr %l21
  %t50 = load ptr, ptr %l10, !tbaa !29
  %t51 = load i32, ptr %l12, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v0, ptr %s0, ptr %t50, i32 %t51, ptr %l21)
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2flower_2ecopyMade(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca %"compiler/source:Span"
  %l18 = alloca i32
  %l20 = alloca %"compiler/source:Span"
  %l21 = alloca i32
  %l23 = alloca ptr
  %l24 = alloca i1
  %l27 = alloca i1
  %l40 = alloca i1
  %l54 = alloca ptr
  %l66 = alloca { i64, ptr }
  %l69 = alloca ptr
  %l70 = alloca i1
  %l74 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t2 = load ptr, ptr %l23, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l23, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 9
  store i1 %t8, ptr %l24, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l24, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l1
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l2, !tbaa !23
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr { i64, [5 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t24, i32 0, i32 2
  %t26 = load i32, ptr %t25, !range !{i32 0, i32 54}
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t30, i32 0, i32 3
  %t32 = load i32, ptr %t31, !range !{i32 0, i32 4}
  store i32 %t32, ptr %l4
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr { i64, [5 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t36, i32 0, i32 4
  %t38 = load { i64, ptr }, ptr %t37
  store { i64, ptr } %t38, ptr %l5, !tbaa !27
  %t42 = trunc i64 20 to i32
  %t43 = icmp eq i32 %t26, %t42
  store i1 %t43, ptr %l27, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb5
bb5:
  %t45 = load i1, ptr %l27, !tbaa !21
  br i1 %t45, label %bb6, label %bb7
bb6:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr { i64, [5 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t48, i32 0, i32 0
  %t50 = load %"compiler/source:Span", ptr %t49
  store %"compiler/source:Span" %t50, ptr %l6
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr { i64, [5 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t54, i32 0, i32 1
  %t56 = load i32, ptr %t55
  store i32 %t56, ptr %l7, !tbaa !23
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr { i64, [5 x i64] }, ptr %t58, i32 0, i32 1
  %t61 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t60, i32 0, i32 2
  %t62 = load i32, ptr %t61, !range !{i32 0, i32 54}
  store i32 %t62, ptr %l8
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr { i64, [5 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t66, i32 0, i32 3
  %t68 = load i32, ptr %t67, !range !{i32 0, i32 4}
  store i32 %t68, ptr %l9
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr { i64, [5 x i64] }, ptr %t70, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t72, i32 0, i32 4
  %t74 = load { i64, ptr }, ptr %t73
  %t78 = extractvalue { i64, ptr } %t74, 0
  %t80 = icmp eq i64 %t78, 1
  store i1 %t80, ptr %l40, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb8
bb8:
  %t82 = load i1, ptr %l40, !tbaa !21
  br i1 %t82, label %bb9, label %bb10
bb9:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr { i64, [5 x i64] }, ptr %t83, i32 0, i32 1
  %t86 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t85, i32 0, i32 0
  %t87 = load %"compiler/source:Span", ptr %t86
  store %"compiler/source:Span" %t87, ptr %l11
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr { i64, [5 x i64] }, ptr %t89, i32 0, i32 1
  %t92 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t91, i32 0, i32 1
  %t93 = load i32, ptr %t92
  store i32 %t93, ptr %l12, !tbaa !23
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr { i64, [5 x i64] }, ptr %t95, i32 0, i32 1
  %t98 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t97, i32 0, i32 2
  %t99 = load i32, ptr %t98, !range !{i32 0, i32 54}
  store i32 %t99, ptr %l13
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr { i64, [5 x i64] }, ptr %t101, i32 0, i32 1
  %t104 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t103, i32 0, i32 3
  %t105 = load i32, ptr %t104, !range !{i32 0, i32 4}
  store i32 %t105, ptr %l14
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr { i64, [5 x i64] }, ptr %t107, i32 0, i32 1
  %t110 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t109, i32 0, i32 4
  %t111 = load { i64, ptr }, ptr %t110
  store { i64, ptr } %t111, ptr %l66, !tbaa !27
  %t115 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr ptr, ptr %t116, i64 0
  %t118 = load ptr, ptr %t117, !tbaa !39
  store ptr %t118, ptr %l54, !tbaa !29
  br label %bb11
bb10:
  %t120 = load ptr, ptr %l0, !tbaa !29
  store ptr %t120, ptr %l54, !tbaa !29
  br label %bb11
bb11:
  %t122 = load ptr, ptr %l54, !tbaa !29
  store ptr %t122, ptr %l16, !tbaa !29
  %t123 = load ptr, ptr %l16, !tbaa !29
  store ptr %t123, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t124 = load ptr, ptr %l69, !tbaa !29
  %t125 = icmp ne ptr %t124, null
  br i1 %t125, label %bb12, label %bb13
bb12:
  %t127 = load ptr, ptr %l69, !tbaa !29
  %t128 = load i64, ptr %t127, !range !{i64 0, i64 18}
  %t130 = icmp eq i64 %t128, 7
  store i1 %t130, ptr %l70, !tbaa !21
  br label %bb13
bb13:
  %t131 = load i1, ptr %l70, !tbaa !21
  %t132 = xor i1 %t131, true
  br i1 %t132, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l74, !tbaa !21
  br label %bb16
bb15:
  %t134 = load ptr, ptr %l16, !tbaa !29
  %t136 = getelementptr { i64, [5 x i64] }, ptr %t134, i32 0, i32 1
  %t137 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t136, i32 0, i32 0
  %t138 = load %"compiler/source:Span", ptr %t137
  store %"compiler/source:Span" %t138, ptr %l17
  %t140 = load ptr, ptr %l16, !tbaa !29
  %t142 = getelementptr { i64, [5 x i64] }, ptr %t140, i32 0, i32 1
  %t143 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t142, i32 0, i32 1
  %t144 = load i32, ptr %t143
  store i32 %t144, ptr %l18, !tbaa !23
  %t146 = load ptr, ptr %l16, !tbaa !29
  %t148 = getelementptr { i64, [5 x i64] }, ptr %t146, i32 0, i32 1
  %t149 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t148, i32 0, i32 2
  %t150 = load ptr, ptr %t149
  %t155 = getelementptr %"compiler/typed:Make", ptr %t150, i32 0, i32 0
  %t156 = load i32, ptr %t155, !range !{i32 0, i32 5}
  %t158 = trunc i64 4 to i32
  %t159 = icmp eq i32 %t156, %t158
  %t161 = xor i1 %t159, true
  store i1 %t161, ptr %l74, !tbaa !21
  br label %bb16
bb16:
  %t163 = load i1, ptr %l74, !tbaa !21
  br i1 %t163, label %bb17, label %bb18
bb17:
  store ptr null, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t165 = load ptr, ptr %l16, !tbaa !29
  %t167 = getelementptr { i64, [5 x i64] }, ptr %t165, i32 0, i32 1
  %t168 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t167, i32 0, i32 0
  %t169 = load %"compiler/source:Span", ptr %t168
  store %"compiler/source:Span" %t169, ptr %l20
  %t171 = load ptr, ptr %l16, !tbaa !29
  %t173 = getelementptr { i64, [5 x i64] }, ptr %t171, i32 0, i32 1
  %t174 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t173, i32 0, i32 1
  %t175 = load i32, ptr %t174
  store i32 %t175, ptr %l21, !tbaa !23
  %t177 = load ptr, ptr %l16, !tbaa !29
  %t179 = getelementptr { i64, [5 x i64] }, ptr %t177, i32 0, i32 1
  %t180 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t179, i32 0, i32 2
  %t181 = load ptr, ptr %t180
  store ptr %t181, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2flower_2ecountWrite(ptr %v0, %"compiler/mir:Lvalue" %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca i64
  %l4 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i64 @compiler_2flower_2ebaseLocal(%"compiler/mir:Lvalue" %a0)
  store i64 %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load i64, ptr %l4, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t7 = icmp sge i64 %t5, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  store { i64, ptr } %a1, ptr %l7, !tbaa !27
  %t10 = load i64, ptr %l2, !tbaa !24
  store i64 %t10, ptr %l8, !tbaa !24
  %t11 = load i64, ptr %l8, !tbaa !24
  %t12 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr i64, ptr %t13, i64 %t11
  %t15 = load i64, ptr %t14, !tbaa !34
  %t18 = add i64 %t15, 1
  %t20 = load i64, ptr %l8, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr i64, ptr %t22, i64 %t20
  store i64 %t18, ptr %t23, !tbaa !34
  br label %bb4
bb3:
  br label %bb4
bb4:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2flower_2edefaultTry(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i1
  %l26 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l42 = alloca i64
  %l45 = alloca i1
  %l50 = alloca { i64, ptr }
  %l66 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t2 = load ptr, ptr %l10, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l10, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 14
  store i1 %t8, ptr %l11, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l11, !tbaa !21
  %t10 = xor i1 %t9, true
  br i1 %t10, label %bb3, label %bb4
bb3:
  store ptr null, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr { i64, [5 x i64] }, ptr %t13, i32 0, i32 1
  %t16 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t15, i32 0, i32 0
  %t17 = load %"compiler/source:Span", ptr %t16
  store %"compiler/source:Span" %t17, ptr %l1
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr { i64, [5 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t21, i32 0, i32 1
  %t23 = load i32, ptr %t22
  store i32 %t23, ptr %l2, !tbaa !23
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t27, i32 0, i32 2
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l4, !tbaa !29
  %t33 = load ptr, ptr %l4, !tbaa !29
  %t35 = getelementptr %"compiler/typed:Try", ptr %t33, i32 0, i32 0
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = icmp eq ptr %t36, null
  br i1 %t38, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb13
bb7:
  %t40 = load ptr, ptr %l4, !tbaa !29
  %t42 = getelementptr %"compiler/typed:Try", ptr %t40, i32 0, i32 0
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = icmp eq ptr %t43, null
  br i1 %t45, label %bb8, label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_61b48c347dd7ae79_910b37d8abe9da8d)
  unreachable
bb9:
  br label %bb10
bb10:
  %t47 = load ptr, ptr %l4, !tbaa !29
  %t49 = getelementptr %"compiler/typed:Try", ptr %t47, i32 0, i32 0
  %t50 = load ptr, ptr %t49, !tbaa !29
  store ptr %t50, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t52 = load ptr, ptr %l32, !tbaa !29
  %t53 = icmp ne ptr %t52, null
  br i1 %t53, label %bb11, label %bb12
bb11:
  %t55 = load ptr, ptr %l32, !tbaa !29
  %t56 = load i64, ptr %t55, !range !{i64 0, i64 18}
  %t58 = icmp eq i64 %t56, 6
  store i1 %t58, ptr %l33, !tbaa !21
  br label %bb12
bb12:
  %t59 = load i1, ptr %l33, !tbaa !21
  %t60 = xor i1 %t59, true
  store i1 %t60, ptr %l26, !tbaa !21
  br label %bb13
bb13:
  %t62 = load i1, ptr %l26, !tbaa !21
  br i1 %t62, label %bb14, label %bb15
bb14:
  store ptr null, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  store i1 false, ptr %l5, !tbaa !21
  %t64 = load ptr, ptr %l4, !tbaa !29
  %t66 = getelementptr %"compiler/typed:Try", ptr %t64, i32 0, i32 1
  %t67 = load { i64, ptr }, ptr %t66, !tbaa !27
  store { i64, ptr } %t67, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t69 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t69, 0
  store i64 %t71, ptr %l8, !tbaa !24
  %t73 = load i64, ptr %l8, !tbaa !24
  %t74 = sub i64 %t73, 1
  store i64 %t74, ptr %l42, !tbaa !24
  %t75 = load i64, ptr %l8, !tbaa !24
  %t76 = icmp slt i64 %t75, 2147483648
  %t77 = load i64, ptr %l7, !tbaa !24
  %t78 = icmp sge i64 %t77, 0
  %t81 = and i1 %t76, %t78
  store i1 %t81, ptr %l45, !tbaa !21
  br label %bb17
bb17:
  %t82 = load i64, ptr %l7, !tbaa !24
  %t83 = load i64, ptr %l8, !tbaa !24
  %t86 = icmp slt i64 %t82, %t83
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb18, label %bb19
bb18:
  br label %bb28
bb19:
  br label %bb20
bb20:
  %t90 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t90, ptr %l50, !tbaa !27
  %t91 = load i64, ptr %l7, !tbaa !24
  %t93 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr ptr, ptr %t94, i64 %t91
  %t96 = load ptr, ptr %t95, !tbaa !39
  store ptr %t96, ptr %l9, !tbaa !29
  %t98 = load ptr, ptr %l9, !tbaa !29
  %t100 = getelementptr %"compiler/typed:Clause", ptr %t98, i32 0, i32 4
  %t101 = load { i64, ptr }, ptr %t100, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t101, 0
  %t105 = icmp sgt i64 %t103, 1
  br i1 %t105, label %bb21, label %bb22
bb21:
  store ptr null, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t108 = load ptr, ptr %l9, !tbaa !29
  %t110 = getelementptr %"compiler/typed:Clause", ptr %t108, i32 0, i32 4
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t111, 0
  %t115 = icmp eq i64 %t113, 1
  br i1 %t115, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb26
bb25:
  br label %bb26
bb26:
  br label %bb27
bb27:
  %t117 = load i64, ptr %l7, !tbaa !24
  %t120 = add i64 %t117, 1
  store i64 %t120, ptr %l7, !tbaa !24
  br label %bb17
bb28:
  %t122 = load i1, ptr %l5, !tbaa !21
  br i1 %t122, label %bb29, label %bb30
bb29:
  %t124 = load ptr, ptr %l4, !tbaa !29
  store ptr %t124, ptr %l66, !tbaa !29
  br label %bb31
bb30:
  store ptr null, ptr %l66, !tbaa !29
  br label %bb31
bb31:
  %t127 = load ptr, ptr %l66, !tbaa !29
  store ptr %t127, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2flower_2efindBlock(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l43 = alloca i1
  %l53 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Block", ptr %t1, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  %t5 = load i32, ptr %l1, !tbaa !23
  %t8 = icmp eq i32 %t4, %t5
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/typed:Block", ptr %t13, i32 0, i32 1
  %t16 = load { i64, ptr }, ptr %t15, !tbaa !27
  store { i64, ptr } %t16, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  store i64 %t20, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t22 = load i64, ptr %l3, !tbaa !24
  %t23 = load i64, ptr %l4, !tbaa !24
  %t26 = icmp slt i64 %t22, %t23
  %t28 = xor i1 %t26, true
  br i1 %t28, label %bb5, label %bb6
bb5:
  br label %bb35
bb6:
  br label %bb7
bb7:
  %t30 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t30, ptr %l23, !tbaa !27
  %t31 = load i64, ptr %l3, !tbaa !24
  %t33 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr ptr, ptr %t34, i64 %t31
  %t36 = load ptr, ptr %t35, !tbaa !39
  store ptr %t36, ptr %l5, !tbaa !29
  %t38 = load ptr, ptr %l5, !tbaa !29
  store ptr %t38, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t39 = load ptr, ptr %l27, !tbaa !29
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %bb8, label %bb9
bb8:
  %t42 = load ptr, ptr %l27, !tbaa !29
  %t43 = load i64, ptr %t42, !range !{i64 0, i64 17}
  %t45 = icmp eq i64 %t43, 11
  store i1 %t45, ptr %l28, !tbaa !21
  br label %bb9
bb9:
  %t46 = load i1, ptr %l28, !tbaa !21
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t47 = load ptr, ptr %l5, !tbaa !29
  %t49 = getelementptr { i64, [3 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", ptr }, ptr %t49, i32 0, i32 1
  %t51 = load ptr, ptr %t50
  store ptr %t51, ptr %l6, !tbaa !29
  br label %bb16
bb11:
  %t53 = load ptr, ptr %l5, !tbaa !29
  store ptr %t53, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t54 = load ptr, ptr %l33, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb12, label %bb13
bb12:
  %t57 = load ptr, ptr %l33, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 17}
  %t60 = icmp eq i64 %t58, 4
  store i1 %t60, ptr %l34, !tbaa !21
  br label %bb13
bb13:
  %t61 = load i1, ptr %l34, !tbaa !21
  br i1 %t61, label %bb14, label %bb15
bb14:
  %t62 = load ptr, ptr %l5, !tbaa !29
  %t64 = getelementptr { i64, [3 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t64, i32 0, i32 1
  %t66 = load ptr, ptr %t65
  store ptr %t66, ptr %l6, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t68 = load ptr, ptr %l6, !tbaa !29
  %t69 = load i32, ptr %l1, !tbaa !23
  %t72 = call ptr @compiler_2flower_2efindBlock(ptr %v0, ptr %v1, ptr %t68, i32 %t69)
  store ptr %t72, ptr %l41
  br label %bb17
bb17:
  %t73 = load ptr, ptr %l41, !tbaa !29
  store ptr %t73, ptr %l26, !tbaa !29
  br label %bb30
bb18:
  %t74 = load ptr, ptr %l5, !tbaa !29
  store ptr %t74, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t75 = load ptr, ptr %l42, !tbaa !29
  %t76 = icmp ne ptr %t75, null
  br i1 %t76, label %bb19, label %bb20
bb19:
  %t78 = load ptr, ptr %l42, !tbaa !29
  %t79 = load i64, ptr %t78, !range !{i64 0, i64 17}
  %t81 = icmp eq i64 %t79, 3
  store i1 %t81, ptr %l43, !tbaa !21
  br label %bb20
bb20:
  %t82 = load i1, ptr %l43, !tbaa !21
  br i1 %t82, label %bb21, label %bb22
bb21:
  %t83 = load ptr, ptr %l5, !tbaa !29
  %t85 = getelementptr { i64, [3 x i64] }, ptr %t83, i32 0, i32 1
  %t86 = getelementptr { %"compiler/source:Span", ptr }, ptr %t85, i32 0, i32 1
  %t87 = load ptr, ptr %t86
  store ptr %t87, ptr %l7, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t89 = load ptr, ptr %l7, !tbaa !29
  %t91 = getelementptr %"compiler/typed:If", ptr %t89, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t93 = load ptr, ptr %l7, !tbaa !29
  %t95 = getelementptr %"compiler/typed:If", ptr %t93, i32 0, i32 2
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t97 = load i32, ptr %l1, !tbaa !23
  %t101 = call ptr @compiler_2flower_2efindIn(ptr %v0, ptr %v0, ptr %v1, ptr %t92, ptr %t96, i32 %t97)
  store ptr %t101, ptr %l53
  br label %bb24
bb24:
  %t102 = load ptr, ptr %l53, !tbaa !29
  store ptr %t102, ptr %l26, !tbaa !29
  br label %bb30
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  store ptr null, ptr %l26, !tbaa !29
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_3762df0b7916f10e_cd67f341de4e403a)
  unreachable
bb30:
  %t103 = load ptr, ptr %l26, !tbaa !29
  store ptr %t103, ptr %l8, !tbaa !29
  %t104 = load ptr, ptr %l8, !tbaa !29
  %t106 = icmp eq ptr %t104, null
  %t108 = xor i1 %t106, true
  br i1 %t108, label %bb31, label %bb32
bb31:
  %t110 = load ptr, ptr %l8, !tbaa !29
  store ptr %t110, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t113 = load i64, ptr %l3, !tbaa !24
  %t116 = add i64 %t113, 1
  store i64 %t116, ptr %l3, !tbaa !24
  br label %bb4
bb35:
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2flower_2efindIn(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l6 = alloca ptr
  %l10 = alloca i1
  %l16 = alloca ptr
  %rv = alloca ptr
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call ptr @compiler_2flower_2efindBlock(ptr %v0, ptr %v2, ptr %a0, i32 %t2)
  store ptr %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l6, !tbaa !29
  store ptr %t6, ptr %l3, !tbaa !29
  %t7 = load ptr, ptr %l3, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb4
bb3:
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = icmp eq ptr %t13, null
  store i1 %t15, ptr %l10, !tbaa !21
  br label %bb4
bb4:
  %t17 = load i1, ptr %l10, !tbaa !21
  br i1 %t17, label %bb5, label %bb6
bb5:
  %t18 = load ptr, ptr %l3, !tbaa !29
  store ptr %t18, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t21 = load i32, ptr %l2, !tbaa !23
  %t24 = call ptr @compiler_2flower_2efindBlock(ptr %v1, ptr %v2, ptr %t20, i32 %t21)
  store ptr %t24, ptr %l16
  br label %bb8
bb8:
  %t25 = load ptr, ptr %l16, !tbaa !29
  store ptr %t25, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2flower_2efreshCall(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l27 = alloca i64
  %l30 = alloca i1
  %l35 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l56 = alloca ptr
  %l57 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %rv
  br label %ret
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t20 = load ptr, ptr %l17, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t23 = load ptr, ptr %l17, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 18}
  %t26 = icmp eq i64 %t24, 14
  store i1 %t26, ptr %l18, !tbaa !21
  br label %bb8
bb8:
  %t27 = load i1, ptr %l18, !tbaa !21
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t30, i32 0, i32 2
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb38
bb11:
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Try", ptr %t34, i32 0, i32 1
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  store { i64, ptr } %t37, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t39 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  store i64 %t41, ptr %l5, !tbaa !24
  %t43 = load i64, ptr %l5, !tbaa !24
  %t44 = sub i64 %t43, 1
  store i64 %t44, ptr %l27, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t46 = icmp slt i64 %t45, 2147483648
  %t47 = load i64, ptr %l4, !tbaa !24
  %t48 = icmp sge i64 %t47, 0
  %t51 = and i1 %t46, %t48
  store i1 %t51, ptr %l30, !tbaa !21
  br label %bb12
bb12:
  %t52 = load i64, ptr %l4, !tbaa !24
  %t53 = load i64, ptr %l5, !tbaa !24
  %t56 = icmp slt i64 %t52, %t53
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb13, label %bb14
bb13:
  br label %bb20
bb14:
  br label %bb15
bb15:
  %t60 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t60, ptr %l35, !tbaa !27
  %t61 = load i64, ptr %l4, !tbaa !24
  %t63 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr ptr, ptr %t64, i64 %t61
  %t66 = load ptr, ptr %t65, !tbaa !39
  %t70 = getelementptr %"compiler/typed:Clause", ptr %t66, i32 0, i32 4
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t71, 0
  %t75 = icmp sgt i64 %t73, 0
  br i1 %t75, label %bb16, label %bb17
bb16:
  store ptr null, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t78 = load i64, ptr %l4, !tbaa !24
  %t81 = add i64 %t78, 1
  store i64 %t81, ptr %l4, !tbaa !24
  br label %bb12
bb20:
  %t83 = load ptr, ptr %l2, !tbaa !29
  %t85 = getelementptr %"compiler/typed:Try", ptr %t83, i32 0, i32 0
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = icmp eq ptr %t86, null
  br i1 %t88, label %bb21, label %bb22
bb21:
  store ptr null, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t91 = load ptr, ptr %l2, !tbaa !29
  %t93 = getelementptr %"compiler/typed:Try", ptr %t91, i32 0, i32 0
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t96 = icmp eq ptr %t94, null
  br i1 %t96, label %bb24, label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_361db8f3f305ba57_fe8cdfd51e5f0a7b)
  unreachable
bb25:
  br label %bb26
bb26:
  %t98 = load ptr, ptr %l2, !tbaa !29
  %t100 = getelementptr %"compiler/typed:Try", ptr %t98, i32 0, i32 0
  %t101 = load ptr, ptr %t100, !tbaa !29
  store ptr %t101, ptr %l7, !tbaa !29
  %t103 = load ptr, ptr %l7, !tbaa !29
  store ptr %t103, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t104 = load ptr, ptr %l56, !tbaa !29
  %t105 = icmp ne ptr %t104, null
  br i1 %t105, label %bb27, label %bb28
bb27:
  %t107 = load ptr, ptr %l56, !tbaa !29
  %t108 = load i64, ptr %t107, !range !{i64 0, i64 18}
  %t110 = icmp eq i64 %t108, 6
  store i1 %t110, ptr %l57, !tbaa !21
  br label %bb28
bb28:
  %t111 = load i1, ptr %l57, !tbaa !21
  br i1 %t111, label %bb29, label %bb30
bb29:
  %t112 = load ptr, ptr %l7, !tbaa !29
  %t114 = getelementptr { i64, [5 x i64] }, ptr %t112, i32 0, i32 1
  %t115 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t114, i32 0, i32 2
  %t116 = load ptr, ptr %t115
  store ptr %t116, ptr %l8, !tbaa !29
  br label %bb31
bb30:
  br label %bb32
bb31:
  %t118 = load ptr, ptr %l8, !tbaa !29
  store ptr %t118, ptr %l55, !tbaa !29
  br label %bb37
bb32:
  br i1 true, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store ptr null, ptr %l55, !tbaa !29
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_b6f2e844e897222f_f7ec98089a0619a3)
  unreachable
bb37:
  %t121 = load ptr, ptr %l55, !tbaa !29
  store ptr %t121, ptr %rv
  br label %ret
bb38:
  br i1 true, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  store ptr null, ptr %rv
  br label %ret
bb42:
  call void @__olang_check_failed(ptr @olang_loc_7f4c2cd212f442f4_5795b97329564c8)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2flower_2eglobalWrite(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !range !{i32 0, i32 54}
  %t3 = trunc i64 31 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb9
bb2:
  %t6 = load i32, ptr %l0, !range !{i32 0, i32 54}
  %t8 = trunc i64 25 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  %t11 = load i32, ptr %l0, !range !{i32 0, i32 54}
  %t13 = trunc i64 26 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb5, label %bb6
bb5:
  br label %bb9
bb6:
  %t16 = load i32, ptr %l0, !range !{i32 0, i32 54}
  %t18 = trunc i64 27 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb21
bb10:
  %t21 = load i32, ptr %l0, !range !{i32 0, i32 54}
  %t23 = trunc i64 28 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  %t26 = load i32, ptr %l0, !range !{i32 0, i32 54}
  %t28 = trunc i64 41 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb21
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_3240793a95d68ec4_8a2d542020d48ba0)
  unreachable
bb21:
  %t31 = load i1, ptr %l1, !tbaa !21
  store i1 %t31, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ehas(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l13 = alloca i64
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l3, !tbaa !24
  store i64 %t3, ptr %l6, !tbaa !24
  %t4 = load ptr, ptr %l2, !tbaa !29
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t4)
  store i64 %t6, ptr %l8
  br label %bb2
bb2:
  %t7 = load i64, ptr %l6, !tbaa !24
  %t8 = load i64, ptr %l8, !tbaa !24
  %t9 = icmp slt i64 %t7, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t13, i64 %t14)
  store i64 %t17, ptr %l13
  br label %bb6
bb6:
  %t18 = load i64, ptr %l13, !tbaa !24
  %t23 = icmp eq i64 %t18, %a1
  br i1 %t23, label %bb7, label %bb8
bb7:
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t26 = load i64, ptr %l3, !tbaa !24
  %t29 = add i64 %t26, 1
  store i64 %t29, ptr %l3, !tbaa !24
  br label %bb1
bb11:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2eheldRef({ i64, [1 x i64] } %a0) #0 {
entry:
  %l1 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, [1 x i64] } %a0, 0
  %t4 = icmp eq i64 %t3, 4
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb9
bb4:
  br i1 true, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_732ec0ad79d18ec2_8d6ce076927c710e)
  unreachable
bb9:
  %t6 = load i1, ptr %l1, !tbaa !21
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2flower_2eplaceRootLocal(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i1
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i1
  %l30 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca i1
  %l39 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l1, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l1, !tbaa !23
  %t18 = sext i32 %t16 to i64
  store i64 %t18, ptr %l5, !tbaa !24
  br label %bb32
bb6:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t21 = load ptr, ptr %l14, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb7, label %bb8
bb7:
  %t24 = load ptr, ptr %l14, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 8}
  %t27 = icmp eq i64 %t25, 3
  store i1 %t27, ptr %l15, !tbaa !21
  br label %bb8
bb8:
  %t28 = load i1, ptr %l15, !tbaa !21
  br i1 %t28, label %bb9, label %bb10
bb9:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = call i64 @compiler_2flower_2eplaceRootLocal(ptr %v0, ptr %t35)
  store i64 %t37, ptr %l21
  br label %bb12
bb12:
  %t38 = load i64, ptr %l21, !tbaa !24
  store i64 %t38, ptr %l5, !tbaa !24
  br label %bb32
bb13:
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t40 = load ptr, ptr %l22, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %bb14, label %bb15
bb14:
  %t43 = load ptr, ptr %l22, !tbaa !29
  %t44 = load i64, ptr %t43, !range !{i64 0, i64 8}
  %t46 = icmp eq i64 %t44, 4
  store i1 %t46, ptr %l23, !tbaa !21
  br label %bb15
bb15:
  %t47 = load i1, ptr %l23, !tbaa !21
  br i1 %t47, label %bb16, label %bb17
bb16:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr { i64, [4 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t50, i32 0, i32 2
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l3, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t54 = load ptr, ptr %l3, !tbaa !29
  %t56 = getelementptr %"compiler/typed:Elem", ptr %t54, i32 0, i32 0
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = call i64 @compiler_2flower_2eplaceRootLocal(ptr %v0, ptr %t57)
  store i64 %t59, ptr %l30
  br label %bb19
bb19:
  %t60 = load i64, ptr %l30, !tbaa !24
  store i64 %t60, ptr %l5, !tbaa !24
  br label %bb32
bb20:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t62 = load ptr, ptr %l31, !tbaa !29
  %t63 = icmp ne ptr %t62, null
  br i1 %t63, label %bb21, label %bb22
bb21:
  %t65 = load ptr, ptr %l31, !tbaa !29
  %t66 = load i64, ptr %t65, !range !{i64 0, i64 8}
  %t68 = icmp eq i64 %t66, 5
  store i1 %t68, ptr %l32, !tbaa !21
  br label %bb22
bb22:
  %t69 = load i1, ptr %l32, !tbaa !21
  br i1 %t69, label %bb23, label %bb24
bb23:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr { i64, [4 x i64] }, ptr %t70, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t72, i32 0, i32 2
  %t74 = load ptr, ptr %t73
  store ptr %t74, ptr %l4, !tbaa !29
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t76 = load ptr, ptr %l4, !tbaa !29
  %t78 = getelementptr %"compiler/typed:Payload", ptr %t76, i32 0, i32 0
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = call i64 @compiler_2flower_2eplaceRootLocal(ptr %v0, ptr %t79)
  store i64 %t81, ptr %l39
  br label %bb26
bb26:
  %t82 = load i64, ptr %l39, !tbaa !24
  store i64 %t82, ptr %l5, !tbaa !24
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  store i64 -1, ptr %l5, !tbaa !24
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_de502b4556e13d28_d48b9fb731677334)
  unreachable
bb32:
  %t83 = load i64, ptr %l5, !tbaa !24
  store i64 %t83, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2flower_2equietArg(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l20 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %l30 = alloca i1
  %l35 = alloca i1
  %l37 = alloca { i64, ptr }
  %l39 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca i1
  %l47 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t11 = load ptr, ptr %l9, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l9, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 18}
  %t17 = icmp eq i64 %t15, 1
  store i1 %t17, ptr %l10, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l10, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb42
bb10:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb11, label %bb12
bb11:
  %t23 = load ptr, ptr %l13, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 18}
  %t26 = icmp eq i64 %t24, 2
  store i1 %t26, ptr %l14, !tbaa !21
  br label %bb12
bb12:
  %t27 = load i1, ptr %l14, !tbaa !21
  br i1 %t27, label %bb13, label %bb14
bb13:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t30, i32 0, i32 2
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l1, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = call i1 @compiler_2flower_2eplainPlace(ptr %v0, ptr %t34)
  store i1 %t36, ptr %l20
  br label %bb16
bb16:
  %t37 = load i1, ptr %l20, !tbaa !21
  store i1 %t37, ptr %l4, !tbaa !21
  br label %bb42
bb17:
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t39 = load ptr, ptr %l21, !tbaa !29
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %bb18, label %bb19
bb18:
  %t42 = load ptr, ptr %l21, !tbaa !29
  %t43 = load i64, ptr %t42, !range !{i64 0, i64 18}
  %t45 = icmp eq i64 %t43, 7
  store i1 %t45, ptr %l22, !tbaa !21
  br label %bb19
bb19:
  %t46 = load i1, ptr %l22, !tbaa !21
  br i1 %t46, label %bb20, label %bb21
bb20:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr { i64, [5 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t49, i32 0, i32 2
  %t51 = load ptr, ptr %t50
  store ptr %t51, ptr %l2, !tbaa !29
  br label %bb22
bb21:
  br label %bb30
bb22:
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t55 = getelementptr %"compiler/typed:Make", ptr %t53, i32 0, i32 0
  %t56 = load i32, ptr %t55, !range !{i32 0, i32 5}
  %t58 = trunc i64 4 to i32
  %t59 = icmp eq i32 %t56, %t58
  br i1 %t59, label %bb23, label %bb24
bb23:
  %t61 = load ptr, ptr %l2, !tbaa !29
  %t63 = getelementptr %"compiler/typed:Make", ptr %t61, i32 0, i32 2
  %t64 = load { i64, ptr }, ptr %t63, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t64, 0
  %t68 = icmp eq i64 %t66, 1
  store i1 %t68, ptr %l30, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb25
bb25:
  %t70 = load i1, ptr %l30, !tbaa !21
  br i1 %t70, label %bb26, label %bb27
bb26:
  %t71 = load ptr, ptr %l2, !tbaa !29
  %t73 = getelementptr %"compiler/typed:Make", ptr %t71, i32 0, i32 2
  %t74 = load { i64, ptr }, ptr %t73, !tbaa !27
  store { i64, ptr } %t74, ptr %l37, !tbaa !27
  %t75 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr ptr, ptr %t76, i64 0
  %t78 = load ptr, ptr %t77, !tbaa !39
  %t80 = call i1 @compiler_2flower_2equietArg(ptr %v0, ptr %t78)
  store i1 %t80, ptr %l39
  br label %bb28
bb27:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb29
bb28:
  %t81 = load i1, ptr %l39, !tbaa !21
  store i1 %t81, ptr %l35, !tbaa !21
  br label %bb29
bb29:
  %t82 = load i1, ptr %l35, !tbaa !21
  store i1 %t82, ptr %l4, !tbaa !21
  br label %bb42
bb30:
  %t83 = load ptr, ptr %l0, !tbaa !29
  store ptr %t83, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t84 = load ptr, ptr %l40, !tbaa !29
  %t85 = icmp ne ptr %t84, null
  br i1 %t85, label %bb31, label %bb32
bb31:
  %t87 = load ptr, ptr %l40, !tbaa !29
  %t88 = load i64, ptr %t87, !range !{i64 0, i64 18}
  %t90 = icmp eq i64 %t88, 17
  store i1 %t90, ptr %l41, !tbaa !21
  br label %bb32
bb32:
  %t91 = load i1, ptr %l41, !tbaa !21
  br i1 %t91, label %bb33, label %bb34
bb33:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr { i64, [5 x i64] }, ptr %t92, i32 0, i32 1
  %t95 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t94, i32 0, i32 2
  %t96 = load ptr, ptr %t95
  store ptr %t96, ptr %l3, !tbaa !29
  br label %bb35
bb34:
  br label %bb37
bb35:
  %t98 = load ptr, ptr %l3, !tbaa !29
  %t100 = call i1 @compiler_2flower_2equietArg(ptr %v0, ptr %t98)
  store i1 %t100, ptr %l47
  br label %bb36
bb36:
  %t101 = load i1, ptr %l47, !tbaa !21
  store i1 %t101, ptr %l4, !tbaa !21
  br label %bb42
bb37:
  br i1 true, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_ff6916793e63751a_93fd2eadd0fa4b86)
  unreachable
bb42:
  %t102 = load i1, ptr %l4, !tbaa !21
  store i1 %t102, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2flower_2ereadLocalId(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i1
  %l10 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 -1, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t7 = load ptr, ptr %l6, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l6, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 2
  store i1 %t13, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l7, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t17, i32 0, i32 2
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb8, label %bb9
bb7:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb10
bb8:
  %t23 = load ptr, ptr %l12, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 8}
  %t26 = icmp eq i64 %t24, 0
  store i1 %t26, ptr %l13, !tbaa !21
  br label %bb9
bb9:
  %t27 = load i1, ptr %l13, !tbaa !21
  store i1 %t27, ptr %l10, !tbaa !21
  br label %bb10
bb10:
  %t28 = load i1, ptr %l10, !tbaa !21
  br i1 %t28, label %bb11, label %bb12
bb11:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr { i64, [5 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  %t35 = getelementptr { i64, [4 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t35, i32 0, i32 2
  %t37 = load i32, ptr %t36
  store i32 %t37, ptr %l1, !tbaa !23
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t39 = load i32, ptr %l1, !tbaa !23
  %t41 = sext i32 %t39 to i64
  store i64 %t41, ptr %l5, !tbaa !24
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i64 -1, ptr %l5, !tbaa !24
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_2409226a81d50f6c_b1d0e1d8308455a0)
  unreachable
bb19:
  %t43 = load i64, ptr %l5, !tbaa !24
  store i64 %t43, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2flower_2ereadsPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i1
  %l17 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l26 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i1
  %l37 = alloca i1
  %l38 = alloca i1
  %l42 = alloca i1
  %l43 = alloca i1
  %l48 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t7 = load ptr, ptr %l9, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l9, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 2
  store i1 %t13, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l10, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t17, i32 0, i32 2
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t25 = call i1 @compiler_2flower_2esamePlace(ptr %v0, ptr %v1, ptr %t21, ptr %t22)
  store i1 %t25, ptr %l17
  br label %bb9
bb9:
  %t26 = load i1, ptr %l17, !tbaa !21
  store i1 %t26, ptr %l8, !tbaa !21
  br label %bb37
bb10:
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t28 = load ptr, ptr %l18, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb11, label %bb12
bb11:
  %t31 = load ptr, ptr %l18, !tbaa !29
  %t32 = load i64, ptr %t31, !range !{i64 0, i64 18}
  %t34 = icmp eq i64 %t32, 9
  store i1 %t34, ptr %l19, !tbaa !21
  br label %bb12
bb12:
  %t35 = load i1, ptr %l19, !tbaa !21
  br i1 %t35, label %bb13, label %bb14
bb13:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t38, i32 0, i32 4
  %t40 = load { i64, ptr }, ptr %t39
  store { i64, ptr } %t40, ptr %l3, !tbaa !27
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t42 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t46 = call i1 @compiler_2flower_2ereadsAny(ptr %v0, ptr %v1, { i64, ptr } %t42, ptr %t43)
  store i1 %t46, ptr %l26
  br label %bb16
bb16:
  %t47 = load i1, ptr %l26, !tbaa !21
  store i1 %t47, ptr %l8, !tbaa !21
  br label %bb37
bb17:
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t49 = load ptr, ptr %l27, !tbaa !29
  %t50 = icmp ne ptr %t49, null
  br i1 %t50, label %bb18, label %bb19
bb18:
  %t52 = load ptr, ptr %l27, !tbaa !29
  %t53 = load i64, ptr %t52, !range !{i64 0, i64 18}
  %t55 = icmp eq i64 %t53, 11
  store i1 %t55, ptr %l28, !tbaa !21
  br label %bb19
bb19:
  %t56 = load i1, ptr %l28, !tbaa !21
  br i1 %t56, label %bb20, label %bb21
bb20:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr { i64, [5 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t59, i32 0, i32 2
  %t61 = load ptr, ptr %t60
  store ptr %t61, ptr %l4, !tbaa !29
  br label %bb22
bb21:
  br label %bb32
bb22:
  %t63 = load ptr, ptr %l4, !tbaa !29
  %t65 = getelementptr %"compiler/typed:Cond", ptr %t63, i32 0, i32 0
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t71 = call i1 @compiler_2flower_2ereadsPlace(ptr %v0, ptr %v1, ptr %t66, ptr %t68)
  store i1 %t71, ptr %l37
  br label %bb23
bb23:
  %t72 = load i1, ptr %l37, !tbaa !21
  br i1 %t72, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb27
bb25:
  %t73 = load ptr, ptr %l4, !tbaa !29
  %t75 = getelementptr %"compiler/typed:Cond", ptr %t73, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t77 = load ptr, ptr %l1, !tbaa !29
  %t80 = call i1 @compiler_2flower_2ereadsPlace(ptr %v0, ptr %v1, ptr %t76, ptr %t77)
  store i1 %t80, ptr %l42
  br label %bb26
bb26:
  %t81 = load i1, ptr %l42, !tbaa !21
  store i1 %t81, ptr %l38, !tbaa !21
  br label %bb27
bb27:
  %t82 = load i1, ptr %l38, !tbaa !21
  br i1 %t82, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb31
bb29:
  %t83 = load ptr, ptr %l4, !tbaa !29
  %t85 = getelementptr %"compiler/typed:Cond", ptr %t83, i32 0, i32 2
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t91 = call i1 @compiler_2flower_2ereadsPlace(ptr %v0, ptr %v1, ptr %t86, ptr %t88)
  store i1 %t91, ptr %l48
  br label %bb30
bb30:
  %t92 = load i1, ptr %l48, !tbaa !21
  store i1 %t92, ptr %l43, !tbaa !21
  br label %bb31
bb31:
  %t93 = load i1, ptr %l43, !tbaa !21
  store i1 %t93, ptr %l8, !tbaa !21
  br label %bb37
bb32:
  br i1 true, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_4dc0cdceec1901ae_7c3defc5bc60c3ca)
  unreachable
bb37:
  %t94 = load i1, ptr %l8, !tbaa !21
  store i1 %t94, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2erunArray(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca i32
  %l8 = alloca i32
  %l11 = alloca i1
  %l14 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i32, ptr %l5, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l2, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l8
  br label %bb2
bb2:
  %t12 = load i32, ptr %l8, !range !{i32 0, i32 33}
  %t14 = trunc i64 19 to i32
  %t15 = icmp eq i32 %t12, %t14
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i32, ptr %l2, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l14
  br label %bb5
bb4:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb6
bb5:
  %t22 = load i32, ptr %l14, !tbaa !23
  %t23 = icmp eq i32 %t22, 0
  store i1 %t23, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t25 = load i1, ptr %l11, !tbaa !21
  store i1 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2flower_2evalueRootLocal(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i1
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i1
  %l30 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca i1
  %l39 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca i1
  %l47 = alloca i64
  %l48 = alloca ptr
  %l49 = alloca i1
  %l58 = alloca i1
  %l62 = alloca i64
  %l63 = alloca { i64, ptr }
  %l65 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb9
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t17 = load ptr, ptr %l14, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l14, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 18}
  %t23 = icmp eq i64 %t21, 3
  store i1 %t23, ptr %l15, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l15, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t27, i32 0, i32 2
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l1, !tbaa !29
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = call i64 @compiler_2flower_2eplaceRootLocal(ptr %v0, ptr %t31)
  store i64 %t33, ptr %l21
  br label %bb10
bb10:
  %t34 = load i64, ptr %l21, !tbaa !24
  store i64 %t34, ptr %l7, !tbaa !24
  br label %bb50
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t36 = load ptr, ptr %l22, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb12, label %bb13
bb12:
  %t39 = load ptr, ptr %l22, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 18}
  %t42 = icmp eq i64 %t40, 10
  store i1 %t42, ptr %l23, !tbaa !21
  br label %bb13
bb13:
  %t43 = load i1, ptr %l23, !tbaa !21
  br i1 %t43, label %bb14, label %bb15
bb14:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr { i64, [5 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t46, i32 0, i32 2
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l2, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t52 = getelementptr %"compiler/typed:Slice", ptr %t50, i32 0, i32 0
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = call i64 @compiler_2flower_2eplaceRootLocal(ptr %v0, ptr %t53)
  store i64 %t55, ptr %l30
  br label %bb17
bb17:
  %t56 = load i64, ptr %l30, !tbaa !24
  store i64 %t56, ptr %l7, !tbaa !24
  br label %bb50
bb18:
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t58 = load ptr, ptr %l31, !tbaa !29
  %t59 = icmp ne ptr %t58, null
  br i1 %t59, label %bb19, label %bb20
bb19:
  %t61 = load ptr, ptr %l31, !tbaa !29
  %t62 = load i64, ptr %t61, !range !{i64 0, i64 18}
  %t64 = icmp eq i64 %t62, 5
  store i1 %t64, ptr %l32, !tbaa !21
  br label %bb20
bb20:
  %t65 = load i1, ptr %l32, !tbaa !21
  br i1 %t65, label %bb21, label %bb22
bb21:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr { i64, [5 x i64] }, ptr %t66, i32 0, i32 1
  %t69 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t68, i32 0, i32 2
  %t70 = load ptr, ptr %t69
  store ptr %t70, ptr %l3, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t72 = load ptr, ptr %l3, !tbaa !29
  %t74 = getelementptr %"compiler/typed:Promote", ptr %t72, i32 0, i32 0
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t77 = call i64 @compiler_2flower_2evalueRootLocal(ptr %v0, ptr %t75)
  store i64 %t77, ptr %l39
  br label %bb24
bb24:
  %t78 = load i64, ptr %l39, !tbaa !24
  store i64 %t78, ptr %l7, !tbaa !24
  br label %bb50
bb25:
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t80 = load ptr, ptr %l40, !tbaa !29
  %t81 = icmp ne ptr %t80, null
  br i1 %t81, label %bb26, label %bb27
bb26:
  %t83 = load ptr, ptr %l40, !tbaa !29
  %t84 = load i64, ptr %t83, !range !{i64 0, i64 18}
  %t86 = icmp eq i64 %t84, 17
  store i1 %t86, ptr %l41, !tbaa !21
  br label %bb27
bb27:
  %t87 = load i1, ptr %l41, !tbaa !21
  br i1 %t87, label %bb28, label %bb29
bb28:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr { i64, [5 x i64] }, ptr %t88, i32 0, i32 1
  %t91 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t90, i32 0, i32 2
  %t92 = load ptr, ptr %t91
  store ptr %t92, ptr %l4, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t94 = load ptr, ptr %l4, !tbaa !29
  %t96 = call i64 @compiler_2flower_2evalueRootLocal(ptr %v0, ptr %t94)
  store i64 %t96, ptr %l47
  br label %bb31
bb31:
  %t97 = load i64, ptr %l47, !tbaa !24
  store i64 %t97, ptr %l7, !tbaa !24
  br label %bb50
bb32:
  %t98 = load ptr, ptr %l0, !tbaa !29
  store ptr %t98, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t99 = load ptr, ptr %l48, !tbaa !29
  %t100 = icmp ne ptr %t99, null
  br i1 %t100, label %bb33, label %bb34
bb33:
  %t102 = load ptr, ptr %l48, !tbaa !29
  %t103 = load i64, ptr %t102, !range !{i64 0, i64 18}
  %t105 = icmp eq i64 %t103, 9
  store i1 %t105, ptr %l49, !tbaa !21
  br label %bb34
bb34:
  %t106 = load i1, ptr %l49, !tbaa !21
  br i1 %t106, label %bb35, label %bb36
bb35:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr { i64, [5 x i64] }, ptr %t107, i32 0, i32 1
  %t110 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t109, i32 0, i32 2
  %t111 = load i32, ptr %t110, !range !{i32 0, i32 54}
  store i32 %t111, ptr %l5
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr { i64, [5 x i64] }, ptr %t113, i32 0, i32 1
  %t116 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t115, i32 0, i32 4
  %t117 = load { i64, ptr }, ptr %t116
  store { i64, ptr } %t117, ptr %l6, !tbaa !27
  br label %bb37
bb36:
  br label %bb45
bb37:
  %t119 = load i32, ptr %l5, !range !{i32 0, i32 54}
  %t121 = trunc i64 20 to i32
  %t122 = icmp eq i32 %t119, %t121
  br i1 %t122, label %bb38, label %bb39
bb38:
  %t124 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t124, 0
  %t128 = icmp eq i64 %t126, 1
  store i1 %t128, ptr %l58, !tbaa !21
  br label %bb40
bb39:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb40
bb40:
  %t130 = load i1, ptr %l58, !tbaa !21
  br i1 %t130, label %bb41, label %bb42
bb41:
  %t131 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t131, ptr %l63, !tbaa !27
  %t132 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr ptr, ptr %t133, i64 0
  %t135 = load ptr, ptr %t134, !tbaa !39
  %t137 = call i64 @compiler_2flower_2evalueRootLocal(ptr %v0, ptr %t135)
  store i64 %t137, ptr %l65
  br label %bb43
bb42:
  store i64 -1, ptr %l62, !tbaa !24
  br label %bb44
bb43:
  %t138 = load i64, ptr %l65, !tbaa !24
  store i64 %t138, ptr %l62, !tbaa !24
  br label %bb44
bb44:
  %t139 = load i64, ptr %l62, !tbaa !24
  store i64 %t139, ptr %l7, !tbaa !24
  br label %bb50
bb45:
  br i1 true, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  store i64 -1, ptr %l7, !tbaa !24
  br label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_2d407f0f8b220e9a_96a1481a89b32b26)
  unreachable
bb50:
  %t140 = load i64, ptr %l7, !tbaa !24
  store i64 %t140, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2flower_2eviewCallIn(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l26 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca ptr
  %l34 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca ptr
  %l42 = alloca i1
  %l51 = alloca i1
  %l56 = alloca ptr
  %l62 = alloca ptr
  %l63 = alloca ptr
  %l64 = alloca i1
  %l73 = alloca i1
  %l77 = alloca ptr
  %l78 = alloca { i64, ptr }
  %l80 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l7, !tbaa !29
  br label %bb60
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t20 = load ptr, ptr %l16, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t23 = load ptr, ptr %l16, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 18}
  %t26 = icmp eq i64 %t24, 14
  store i1 %t26, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t27 = load i1, ptr %l17, !tbaa !21
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t30, i32 0, i32 2
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb19
bb11:
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Try", ptr %t34, i32 0, i32 0
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = icmp eq ptr %t37, null
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb12, label %bb13
bb12:
  %t43 = load ptr, ptr %l2, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Try", ptr %t43, i32 0, i32 0
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = icmp eq ptr %t46, null
  br i1 %t48, label %bb14, label %bb15
bb13:
  store ptr null, ptr %l26, !tbaa !29
  br label %bb18
bb14:
  call void @__olang_check_failed(ptr @olang_loc_507be9c6ca1ca599_d80eabfba6b49be5)
  unreachable
bb15:
  br label %bb16
bb16:
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t52 = getelementptr %"compiler/typed:Try", ptr %t50, i32 0, i32 0
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = call ptr @compiler_2flower_2eviewCallIn(ptr %v0, ptr %v1, ptr %t53)
  store ptr %t55, ptr %l32
  br label %bb17
bb17:
  %t56 = load ptr, ptr %l32, !tbaa !29
  store ptr %t56, ptr %l26, !tbaa !29
  br label %bb18
bb18:
  %t57 = load ptr, ptr %l26, !tbaa !29
  store ptr %t57, ptr %l7, !tbaa !29
  br label %bb60
bb19:
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t59 = load ptr, ptr %l33, !tbaa !29
  %t60 = icmp ne ptr %t59, null
  br i1 %t60, label %bb20, label %bb21
bb20:
  %t62 = load ptr, ptr %l33, !tbaa !29
  %t63 = load i64, ptr %t62, !range !{i64 0, i64 18}
  %t65 = icmp eq i64 %t63, 17
  store i1 %t65, ptr %l34, !tbaa !21
  br label %bb21
bb21:
  %t66 = load i1, ptr %l34, !tbaa !21
  br i1 %t66, label %bb22, label %bb23
bb22:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr { i64, [5 x i64] }, ptr %t67, i32 0, i32 1
  %t70 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t69, i32 0, i32 2
  %t71 = load ptr, ptr %t70
  store ptr %t71, ptr %l3, !tbaa !29
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t73 = load ptr, ptr %l3, !tbaa !29
  %t75 = call ptr @compiler_2flower_2eviewCallIn(ptr %v0, ptr %v1, ptr %t73)
  store ptr %t75, ptr %l40
  br label %bb25
bb25:
  %t76 = load ptr, ptr %l40, !tbaa !29
  store ptr %t76, ptr %l7, !tbaa !29
  br label %bb60
bb26:
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t78 = load ptr, ptr %l41, !tbaa !29
  %t79 = icmp ne ptr %t78, null
  br i1 %t79, label %bb27, label %bb28
bb27:
  %t81 = load ptr, ptr %l41, !tbaa !29
  %t82 = load i64, ptr %t81, !range !{i64 0, i64 18}
  %t84 = icmp eq i64 %t82, 12
  store i1 %t84, ptr %l42, !tbaa !21
  br label %bb28
bb28:
  %t85 = load i1, ptr %l42, !tbaa !21
  br i1 %t85, label %bb29, label %bb30
bb29:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr { i64, [5 x i64] }, ptr %t86, i32 0, i32 1
  %t89 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t88, i32 0, i32 2
  %t90 = load ptr, ptr %t89
  store ptr %t90, ptr %l4, !tbaa !29
  br label %bb31
bb30:
  br label %bb42
bb31:
  %t92 = load ptr, ptr %l4, !tbaa !29
  %t94 = getelementptr %"compiler/typed:Seq", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = icmp eq ptr %t95, null
  %t99 = xor i1 %t97, true
  br i1 %t99, label %bb32, label %bb33
bb32:
  %t101 = load ptr, ptr %l4, !tbaa !29
  %t103 = getelementptr %"compiler/typed:Seq", ptr %t101, i32 0, i32 0
  %t104 = load { i64, ptr }, ptr %t103, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t104, 0
  %t108 = icmp eq i64 %t106, 0
  store i1 %t108, ptr %l51, !tbaa !21
  br label %bb34
bb33:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb34
bb34:
  %t110 = load i1, ptr %l51, !tbaa !21
  br i1 %t110, label %bb35, label %bb36
bb35:
  %t111 = load ptr, ptr %l4, !tbaa !29
  %t113 = getelementptr %"compiler/typed:Seq", ptr %t111, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = icmp eq ptr %t114, null
  br i1 %t116, label %bb37, label %bb38
bb36:
  store ptr null, ptr %l56, !tbaa !29
  br label %bb41
bb37:
  call void @__olang_check_failed(ptr @olang_loc_ef2d75aaca2b0e72_154891bbf0c2fa3e)
  unreachable
bb38:
  br label %bb39
bb39:
  %t118 = load ptr, ptr %l4, !tbaa !29
  %t120 = getelementptr %"compiler/typed:Seq", ptr %t118, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !29
  %t123 = call ptr @compiler_2flower_2eviewCallIn(ptr %v0, ptr %v1, ptr %t121)
  store ptr %t123, ptr %l62
  br label %bb40
bb40:
  %t124 = load ptr, ptr %l62, !tbaa !29
  store ptr %t124, ptr %l56, !tbaa !29
  br label %bb41
bb41:
  %t125 = load ptr, ptr %l56, !tbaa !29
  store ptr %t125, ptr %l7, !tbaa !29
  br label %bb60
bb42:
  %t126 = load ptr, ptr %l0, !tbaa !29
  store ptr %t126, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t127 = load ptr, ptr %l63, !tbaa !29
  %t128 = icmp ne ptr %t127, null
  br i1 %t128, label %bb43, label %bb44
bb43:
  %t130 = load ptr, ptr %l63, !tbaa !29
  %t131 = load i64, ptr %t130, !range !{i64 0, i64 18}
  %t133 = icmp eq i64 %t131, 9
  store i1 %t133, ptr %l64, !tbaa !21
  br label %bb44
bb44:
  %t134 = load i1, ptr %l64, !tbaa !21
  br i1 %t134, label %bb45, label %bb46
bb45:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr { i64, [5 x i64] }, ptr %t135, i32 0, i32 1
  %t138 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t137, i32 0, i32 2
  %t139 = load i32, ptr %t138, !range !{i32 0, i32 54}
  store i32 %t139, ptr %l5
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr { i64, [5 x i64] }, ptr %t141, i32 0, i32 1
  %t144 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t143, i32 0, i32 4
  %t145 = load { i64, ptr }, ptr %t144
  store { i64, ptr } %t145, ptr %l6, !tbaa !27
  br label %bb47
bb46:
  br label %bb55
bb47:
  %t147 = load i32, ptr %l5, !range !{i32 0, i32 54}
  %t149 = trunc i64 20 to i32
  %t150 = icmp eq i32 %t147, %t149
  br i1 %t150, label %bb48, label %bb49
bb48:
  %t152 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t154 = extractvalue { i64, ptr } %t152, 0
  %t156 = icmp eq i64 %t154, 1
  store i1 %t156, ptr %l73, !tbaa !21
  br label %bb50
bb49:
  store i1 false, ptr %l73, !tbaa !21
  br label %bb50
bb50:
  %t158 = load i1, ptr %l73, !tbaa !21
  br i1 %t158, label %bb51, label %bb52
bb51:
  %t159 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t159, ptr %l78, !tbaa !27
  %t160 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !27
  %t162 = getelementptr ptr, ptr %t161, i64 0
  %t163 = load ptr, ptr %t162, !tbaa !39
  %t165 = call ptr @compiler_2flower_2eviewCallIn(ptr %v0, ptr %v1, ptr %t163)
  store ptr %t165, ptr %l80
  br label %bb53
bb52:
  store ptr null, ptr %l77, !tbaa !29
  br label %bb54
bb53:
  %t166 = load ptr, ptr %l80, !tbaa !29
  store ptr %t166, ptr %l77, !tbaa !29
  br label %bb54
bb54:
  %t167 = load ptr, ptr %l77, !tbaa !29
  store ptr %t167, ptr %l7, !tbaa !29
  br label %bb60
bb55:
  br i1 true, label %bb56, label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb59
bb58:
  store ptr null, ptr %l7, !tbaa !29
  br label %bb60
bb59:
  call void @__olang_check_failed(ptr @olang_loc_131c31ba2e03204a_ed00d1201b990436)
  unreachable
bb60:
  %t168 = load ptr, ptr %l7, !tbaa !29
  store ptr %t168, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2flower_2ewholeLocal({ i64, [4 x i64] } %a0) #0 {
entry:
  %l0 = alloca { i64, [4 x i64] }
  %l1 = alloca %"compiler/mir:Lvalue"
  %l2 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i64
  %rv = alloca i64
  store { i64, [4 x i64] } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [4 x i64] }, ptr %l0
  %t3 = extractvalue { i64, [4 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 1
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [4 x i64] }, ptr %l0, i32 0, i32 1
  %t7 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t6, i32 0, i32 0
  %t8 = load %"compiler/mir:Lvalue", ptr %t7
  store %"compiler/mir:Lvalue" %t8, ptr %l1
  br label %bb3
bb2:
  br label %bb8
bb3:
  %t10 = getelementptr %"compiler/mir:Lvalue", ptr %l1, i32 0, i32 1
  %t11 = getelementptr %"compiler/mir:Range", ptr %t10, i32 0, i32 1
  %t12 = load i32, ptr %t11, !tbaa !23
  %t14 = icmp eq i32 %t12, 0
  br i1 %t14, label %bb4, label %bb5
bb4:
  %t16 = load %"compiler/mir:Lvalue", ptr %l1
  %t18 = call i64 @compiler_2flower_2ebaseLocal(%"compiler/mir:Lvalue" %t16)
  store i64 %t18, ptr %l10
  br label %bb6
bb5:
  store i64 -1, ptr %l8, !tbaa !24
  br label %bb7
bb6:
  %t19 = load i64, ptr %l10, !tbaa !24
  store i64 %t19, ptr %l8, !tbaa !24
  br label %bb7
bb7:
  %t20 = load i64, ptr %l8, !tbaa !24
  store i64 %t20, ptr %l2, !tbaa !24
  br label %bb13
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i64 -1, ptr %l2, !tbaa !24
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_30f94c519aa44d4_7617c9da302fd0b8)
  unreachable
bb13:
  %t21 = load i64, ptr %l2, !tbaa !24
  store i64 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

declare void @__olang_check_failed(ptr) cold noreturn
define linkonce_odr void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2fmir_3aFnKey(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1, !range !{i64 0, i64 7}
  switch i64 %t2, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 ]
bb1:
  br label %ret
bb2:
  %t4 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t4, i64 %t5)
  %t6 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t6, i64 %t7)
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr { i64, [2 x i64] }, ptr %t8, i32 0, i32 1
  %t10 = getelementptr { i32 }, ptr %t9, i32 0, i32 0
  %t11 = load i32, ptr %t10
  %t13 = sext i32 %t11 to i64
  %t14 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t15 = call i64 @__olang_fmt_i64(ptr %t14, i64 %t13)
  call void @__olang_sb_add(ptr %v0, i64 %t15)
  %t16 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t16, i64 %t17)
  br label %bb1
bb3:
  %t18 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t19 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t18, i64 %t19)
  %t20 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t20, i64 %t21)
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr { i64, [2 x i64] }, ptr %t22, i32 0, i32 1
  %t24 = getelementptr { i32 }, ptr %t23, i32 0, i32 0
  %t25 = load i32, ptr %t24
  %t27 = sext i32 %t25 to i64
  %t28 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t29 = call i64 @__olang_fmt_i64(ptr %t28, i64 %t27)
  call void @__olang_sb_add(ptr %v0, i64 %t29)
  %t30 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t31 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t30, i64 %t31)
  br label %bb1
bb4:
  %t32 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t32, i64 %t33)
  %t34 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t35 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t34, i64 %t35)
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr { i64, [2 x i64] }, ptr %t36, i32 0, i32 1
  %t38 = getelementptr { i32 }, ptr %t37, i32 0, i32 0
  %t39 = load i32, ptr %t38
  %t41 = sext i32 %t39 to i64
  %t42 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t43 = call i64 @__olang_fmt_i64(ptr %t42, i64 %t41)
  call void @__olang_sb_add(ptr %v0, i64 %t43)
  %t44 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t45 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t44, i64 %t45)
  br label %bb1
bb5:
  %t46 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t47 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t46, i64 %t47)
  %t48 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t49 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t48, i64 %t49)
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr { i64, [2 x i64] }, ptr %t50, i32 0, i32 1
  %t52 = getelementptr { i32, i32 }, ptr %t51, i32 0, i32 0
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2fmir_3aHelperKind(ptr %v0, ptr %t52, i64 %a1)
  br label %bb9
bb6:
  %t55 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t56 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t55, i64 %t56)
  %t57 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t58 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t57, i64 %t58)
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr { i64, [2 x i64] }, ptr %t59, i32 0, i32 1
  %t61 = getelementptr { i64 }, ptr %t60, i32 0, i32 0
  %t62 = load i64, ptr %t61
  %t64 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t65 = call i64 @__olang_fmt_i64(ptr %t64, i64 %t62)
  call void @__olang_sb_add(ptr %v0, i64 %t65)
  %t66 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t67 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t66, i64 %t67)
  br label %bb1
bb7:
  %t68 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t69 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t68, i64 %t69)
  %t70 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t71 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t70, i64 %t71)
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr { i64, [2 x i64] }, ptr %t72, i32 0, i32 1
  %t74 = getelementptr { i64, i1 }, ptr %t73, i32 0, i32 0
  %t75 = load i64, ptr %t74
  %t77 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t78 = call i64 @__olang_fmt_i64(ptr %t77, i64 %t75)
  call void @__olang_sb_add(ptr %v0, i64 %t78)
  %t79 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t80 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t79, i64 %t80)
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr { i64, [2 x i64] }, ptr %t81, i32 0, i32 1
  %t83 = getelementptr { i64, i1 }, ptr %t82, i32 0, i32 1
  %t84 = load i1, ptr %t83
  %t86 = select i1 %t84, ptr @.c26, ptr @.c27
  %t87 = select i1 %t84, i64 4, i64 5
  call void @__olang_sb_put(ptr %v0, ptr %t86, i64 %t87)
  %t88 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t89 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t88, i64 %t89)
  br label %bb1
bb8:
  %t90 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t91 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t90, i64 %t91)
  %t92 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t93 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t92, i64 %t93)
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr { i64, [2 x i64] }, ptr %t94, i32 0, i32 1
  %t96 = getelementptr { i32, i64 }, ptr %t95, i32 0, i32 0
  %t97 = load i32, ptr %t96
  %t99 = sext i32 %t97 to i64
  %t100 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t101 = call i64 @__olang_fmt_i64(ptr %t100, i64 %t99)
  call void @__olang_sb_add(ptr %v0, i64 %t101)
  %t102 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t103 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t102, i64 %t103)
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr { i64, [2 x i64] }, ptr %t104, i32 0, i32 1
  %t106 = getelementptr { i32, i64 }, ptr %t105, i32 0, i32 1
  %t107 = load i64, ptr %t106
  %t109 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t110 = call i64 @__olang_fmt_i64(ptr %t109, i64 %t107)
  call void @__olang_sb_add(ptr %v0, i64 %t110)
  %t111 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t112 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t111, i64 %t112)
  br label %bb1
bb9:
  %t113 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t114 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t113, i64 %t114)
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr { i64, [2 x i64] }, ptr %t115, i32 0, i32 1
  %t117 = getelementptr { i32, i32 }, ptr %t116, i32 0, i32 1
  %t118 = load i32, ptr %t117
  %t120 = sext i32 %t118 to i64
  %t121 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t122 = call i64 @__olang_fmt_i64(ptr %t121, i64 %t120)
  call void @__olang_sb_add(ptr %v0, i64 %t122)
  %t123 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t124 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t123, i64 %t124)
  br label %bb1
ret:
  ret void
}

@.d0 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
declare void @__olang_sb_put(ptr, ptr, i64)
define available_externally ptr @__olang_sb_room(ptr %sb, i64 %need) alwaysinline {
entry:
  %lenp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 1
  %capp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 2
  %len = load i64, ptr %lenp
  %cap = load i64, ptr %capp
  %want = add i64 %len, %need
  %fits = icmp ule i64 %want, %cap
  br i1 %fits, label %ok, label %grow
ok:
  %data = load ptr, ptr %sb
  %p = getelementptr i8, ptr %data, i64 %len
  ret ptr %p
grow:
  %g = call ptr @__olang_sb_grow(ptr %sb, i64 %need)
  ret ptr %g
}
declare i64 @__olang_fmt_i64(ptr, i64)
declare void @__olang_sb_add(ptr, i64)
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @__olang_sb_done(ptr)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@.d1 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"std/prelude/text" }>, align 8
@.d2 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Char" }>, align 8
define linkonce_odr void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fmir_3aFn(ptr %out, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/mir:Fn"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l31 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l37 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l39 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l41 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l43 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l45 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l47 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a0, i64 808, i1 false)
  %t2 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 4
  %t4 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t6 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %t6
  %t7 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 5
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t7)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l5
  br label %bb2
bb2:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t11 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %t11
  %t12 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 6
  %t14 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %t12)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l7
  br label %bb3
bb3:
  %t15 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  %t16 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %t16
  %t17 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 7
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t17)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l9
  br label %bb4
bb4:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  %t21 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %t21
  %t22 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 8
  %t24 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t22)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l11
  br label %bb5
bb5:
  %t25 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  %t26 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %t26
  %t27 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 9
  %t29 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %t27)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t29, ptr %l13
  br label %bb6
bb6:
  %t30 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  %t31 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t30, ptr %t31
  %t32 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 10
  %t34 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %t32)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t34, ptr %l15
  br label %bb7
bb7:
  %t35 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  %t36 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t35, ptr %t36
  %t37 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 11
  %t39 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t37)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t39, ptr %l17
  br label %bb8
bb8:
  %t40 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  %t41 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t40, ptr %t41
  %t42 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 12
  %t44 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t42)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t44, ptr %l19
  br label %bb9
bb9:
  %t45 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  %t46 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t45, ptr %t46
  %t47 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 13
  %t49 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLvalue_3e(ptr %v0, ptr %t47)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t49, ptr %l21
  br label %bb10
bb10:
  %t50 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21
  %t51 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t50, ptr %t51
  %t52 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 14
  %t54 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %t52)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t54, ptr %l23
  br label %bb11
bb11:
  %t55 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  %t56 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t55, ptr %t56
  %t57 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 15
  %t59 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %t57)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t59, ptr %l25
  br label %bb12
bb12:
  %t60 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25
  %t61 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t60, ptr %t61
  %t62 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 16
  %t64 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %t62)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t64, ptr %l27
  br label %bb13
bb13:
  %t65 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27
  %t66 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t65, ptr %t66
  %t67 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 17
  %t69 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTaskClause_3e(ptr %v0, ptr %t67)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t69, ptr %l29
  br label %bb14
bb14:
  %t70 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l29
  %t71 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t70, ptr %t71
  %t72 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 18
  %t74 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %t72)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t74, ptr %l31
  br label %bb15
bb15:
  %t75 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l31
  %t76 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t75, ptr %t76
  %t77 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 19
  %t79 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %t77)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t79, ptr %l33
  br label %bb16
bb16:
  %t80 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33
  %t81 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t80, ptr %t81
  %t82 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 20
  %t84 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI32_3e(ptr %v0, ptr %t82)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t84, ptr %l35
  br label %bb17
bb17:
  %t85 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l35
  %t86 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t85, ptr %t86
  %t87 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 21
  %t89 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cU8_3e(ptr %v0, ptr %t87)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t89, ptr %l37
  br label %bb18
bb18:
  %t90 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l37
  %t91 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 21
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t90, ptr %t91
  %t92 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 22
  %t94 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %t92)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t94, ptr %l39
  br label %bb19
bb19:
  %t95 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l39
  %t96 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t95, ptr %t96
  %t97 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 23
  %t99 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI32_3e(ptr %v0, ptr %t97)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t99, ptr %l41
  br label %bb20
bb20:
  %t100 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l41
  %t101 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t100, ptr %t101
  %t102 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 24
  %t104 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %t102)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t104, ptr %l43
  br label %bb21
bb21:
  %t105 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43
  %t106 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t105, ptr %t106
  %t107 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 28
  %t109 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI32_3e(ptr %v0, ptr %t107)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t109, ptr %l45
  br label %bb22
bb22:
  %t110 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l45
  %t111 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 28
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t110, ptr %t111
  %t112 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 29
  %t114 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t112)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t114, ptr %l47
  br label %bb23
bb23:
  %t115 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l47
  %t116 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 29
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t115, ptr %t116
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l1, i64 808, i1 false)
  br label %ret
ret:
  ret void
}

@.d3 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"T13d " }>, align 8
@.d4 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d5 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"O43 " }>, align 8
@.d6 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d7 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"D9h " }>, align 8
@.d8 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d9 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d10 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"writes" }>, align 8
@.d11 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"none" }>, align 8
declare ptr @__olang_scope_or(ptr, ptr)
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
define linkonce_odr %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/lower:pl"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/lower:pl"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/lower:pl", ptr %a0
  store %"compiler/lower:pl" %t2, ptr %l1
  %t3 = getelementptr %"compiler/lower:pl", ptr %l1, i32 0, i32 1
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"compiler/lower:pl", ptr %l1, i32 0, i32 1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = load %"compiler/lower:pl", ptr %l1
  store %"compiler/lower:pl" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:pl", ptr %rv
  ret %"compiler/lower:pl" %rr
}

declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare ptr @__olang_scope_of(ptr, ptr) noinline
@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d12 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"a place that is none" }>, align 8
declare void @__olang_bang_failed_plain(ptr) cold noreturn
@.d13 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d14 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Str" }>, align 8
@.d15 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"str" }>, align 8
@.d16 = private constant <{ i64, [55 x i8] }> <{ i64 0, [55 x i8] c"a compound assignment's old value outside an assignment" }>, align 8
@.d17 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"mir.FnKey.Body" }>, align 8
@.d18 = private unnamed_addr constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d19 = private unnamed_addr constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d20 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"mir.FnKey.Adapter" }>, align 8
@.d21 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"mir.FnKey.Copied" }>, align 8
@.d22 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"mir.FnKey.Helper" }>, align 8
define linkonce_odr void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2fmir_3aHelperKind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0, !range !{i32 0, i32 10}
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 i64 7, label %bb9 i64 8, label %bb10 i64 9, label %bb11 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
bb5:
  %t11 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb1
bb6:
  %t13 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t13, i64 %t14)
  br label %bb1
bb7:
  %t15 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t15, i64 %t16)
  br label %bb1
bb8:
  %t17 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t17, i64 %t18)
  br label %bb1
bb9:
  %t19 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t19, i64 %t20)
  br label %bb1
bb10:
  %t21 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t21, i64 %t22)
  br label %bb1
bb11:
  %t23 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t23, i64 %t24)
  br label %bb1
ret:
  ret void
}

@.d23 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"mir.FnKey.Init" }>, align 8
@.d24 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"mir.FnKey.AnyRender" }>, align 8
@.d25 = private unnamed_addr constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.c26 = private unnamed_addr constant [5 x i8] c"true\00"
@.c27 = private unnamed_addr constant [6 x i8] c"false\00"
@.d28 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"mir.FnKey.Twin" }>, align 8
declare ptr @__olang_sb_grow(ptr, i64) noinline
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 4
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 40
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 40
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 24
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 24
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 40
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 40
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLvalue_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 32
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 32
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 128
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 128
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 144
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 144
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTaskClause_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 56
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 56
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI32_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 4
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cU8_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 1
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 4
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 4
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
@.d29 = private unnamed_addr constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"mir.HelperKind.Render" }>, align 8
@.d30 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"mir.HelperKind.Equal" }>, align 8
@.d31 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"mir.HelperKind.Hash" }>, align 8
@.d32 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"mir.HelperKind.Zero" }>, align 8
@.d33 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"mir.HelperKind.Copy" }>, align 8
@.d34 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"mir.HelperKind.Parts" }>, align 8
@.d35 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"mir.HelperKind.Drop" }>, align 8
@.d36 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"mir.HelperKind.Guard" }>, align 8
@.d37 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"mir.HelperKind.Split" }>, align 8
@.d38 = private unnamed_addr constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"mir.HelperKind.Release" }>, align 8
define linkonce_odr { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca %"compiler/mir:BasicBlock"
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 96
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr %"compiler/mir:BasicBlock", ptr %t14, i64 %t12
  %t17 = call %"compiler/mir:BasicBlock" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fmir_3aBasicBlock(ptr %v0, ptr %t15)
  store %"compiler/mir:BasicBlock" %t17, ptr %l6
  br label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load %"compiler/mir:BasicBlock", ptr %l6
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr %"compiler/mir:BasicBlock", ptr %t22, i64 %t20
  store %"compiler/mir:BasicBlock" %t19, ptr %t23
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t24, 1
  store i64 %t25, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define linkonce_odr %"compiler/mir:BasicBlock" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fmir_3aBasicBlock(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/mir:BasicBlock"
  %l3 = alloca %"compiler/mir:StmtList"
  %rv = alloca %"compiler/mir:BasicBlock"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/mir:BasicBlock", ptr %a0
  store %"compiler/mir:BasicBlock" %t2, ptr %l1
  %t3 = getelementptr %"compiler/mir:BasicBlock", ptr %l1, i32 0, i32 0
  %t5 = call %"compiler/mir:StmtList" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fmir_3aStmtList(ptr %v0, ptr %t3)
  store %"compiler/mir:StmtList" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"compiler/mir:StmtList", ptr %l3
  %t7 = getelementptr %"compiler/mir:BasicBlock", ptr %l1, i32 0, i32 0
  store %"compiler/mir:StmtList" %t6, ptr %t7
  %t8 = load %"compiler/mir:BasicBlock", ptr %l1
  store %"compiler/mir:BasicBlock" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:BasicBlock", ptr %rv
  ret %"compiler/mir:BasicBlock" %rr
}

define linkonce_odr %"compiler/mir:StmtList" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fmir_3aStmtList(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/mir:StmtList"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"compiler/mir:StmtList"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/mir:StmtList", ptr %a0
  store %"compiler/mir:StmtList" %t2, ptr %l1
  %t3 = getelementptr %"compiler/mir:StmtList", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 176
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 176
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"compiler/mir:StmtList", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"compiler/mir:StmtList", ptr %l1
  store %"compiler/mir:StmtList" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:StmtList", ptr %rv
  ret %"compiler/mir:StmtList" %rr
}

@olang_loc_e95d68e3d7cba01a_696ee7b39c9f410e = external constant [0 x i8]
@olang_loc_4ca96ca743817bc9_2683ea67216c5235 = external constant [0 x i8]
@olang_loc_43f32b3576b8b411_d6dff2521676819d = external constant [0 x i8]
@olang_loc_5e1828c4865d22a_113428759accc96 = external constant [0 x i8]
declare i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2eHasCode(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsGenerator(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_6b9a8a26a5fa00eb_10c4e92198635bb7 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20I64_3e_2eK_H93b9e30c66e0d3e1f5b32cd94e4351ed(ptr %v0, ptr %v1, ptr %a0)
declare { i32, { i64, [2 x i64] } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapKeyIter_3ccompiler_2fmir_3aFnKey_2c_20I64_H71b42e541b2116ff991c89abd32c4a9f(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare i64 @compiler_2flower_2ecompiler_2flower_3aLowerer_2eViewsOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_Ha270003b2266a12c55eea6eacf9a4be1(ptr %v0, ptr %a0)
declare %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_H3054d603499f3fef5e3f6df62ca84cee(ptr %v0, ptr %v1, ptr %a0)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapKeyIter_3cI64_2c_20std_2fprelude_2ftext_3_H9d7da39dd81a932fb2b877accbcd070c(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20Boo_Hc20348a7e3f4966d079d7d53957fcef1(ptr %v0, ptr %v1, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapKeyIter_3cstd_2fprelude_2ftext_3aString_2_H25a1fa74df5469e35efe3ff4130517ef(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20Boo_H6b1fa5c8028973ecd947936aac3caef3(ptr %v0, ptr %a0, { i64, ptr } %a1, i1 %a2)
declare { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ehandsBack(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare ptr @compiler_2flower_2ecompiler_2flower_3aLowerer_2eLower(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eadapterFn(ptr %out, ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare ptr @compiler_2flower_2ecompiler_2flower_3aLowerer_2elowerAs(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
declare void @compiler_2flower_2ecompiler_2flower_3aLowerer_2einitFn(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eanyRender(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1, i1 %a2)
@olang_loc_3c213ca88cac8ac4_ee776128d38d19e0 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @compiler_2ftyped_2eLocalUses_2eUses(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2estartOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_Hf0a5beca6f8aee4731a76bd327ae0a99(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_He6968003b8dd5762fa82ec44b4ee1fc9(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i1 %a2)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare void @compiler_2fmir_3aFn_2ector(ptr %out, ptr %v0, { i64, [2 x i64] } %a0, i32 %a1, i64 %a2, %"compiler/source:Span" %a3)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"compiler/lower:CloneSum" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aCloneSum_3e_2eAt_3ccompiler_2flower_3aCloneSum_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20I64_3e_2eG_H6ffe2eb17daa971b2c9d564ad72358b1(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare %"compiler/lower:CloneSum" @compiler_2flower_2ecompiler_2flower_3aLowerer_2ereadSum(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aCloneSum_3e_2eLen_3ccompiler_2flower_3aCloneSum_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20I64_3e_2eP_H79a97b7337c7adf08bdd37311af7e171(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aCloneSum_3e_2ePush_3ccompiler_2flower_3aCloneSum_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:CloneSum" %a1)
declare void @compiler_2flower_2estandIn(ptr %out, ptr %v0, i32 %a0)
declare void @compiler_2flower_3alowering_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2ecopiedBody(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare { i64, ptr } @compiler_2flower_2ecompiler_2flower_3aLowerer_2edeclName(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2flower_2ecompiler_2flower_3aLowerer_2egenValue(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2ffacts_2ecompiler_2ffacts_3aTable_2eDecide(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3)
@olang_loc_1382960bfc70c50f_447f2e6bbefa4703 = external constant [0 x i8]
@olang_loc_543552ccedba0a30_34b88e2195dff774 = external constant [0 x i8]
@olang_loc_c10f234bff0405bc_197db79cf1a1a0 = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceName(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_9633c21bdf8638fa_782e8f05e482835e = external constant [0 x i8]
declare i32 @compiler_2fmir_2eHelperType(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2ehelper(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, i32 %a1, i32 %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__Hccd9659a44f570da1fa06b019882a84d(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_3aca88f8a70b165c_61af268fc3dc2410 = external constant [0 x i8]
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2eNone(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3, i64 %a4)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eLen_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eRef_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_22c39d86763bef1a_78a4012252e46bde = external constant [0 x i8]
declare i64 @compiler_2ftyped_2eCalleeBody(ptr %v0, ptr %a0)
@olang_loc_6caa27e9a9bd9cb6_8b0a4ad242181fa2 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2feffects_3aEffects_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1)
@olang_loc_1d7b43c09c8ad210_c11cfffd5d5a2d0c = external constant [0 x i8]
declare %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eOf(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2eHolds(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_74a3aff541c96529_c7a7326cf0c27875 = external constant [0 x i8]
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eArraysSite(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRunsCopy(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, [15 x i64] } %a2, %"compiler/source:Span" %a3)
declare %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %v0, { i64, [2 x i64] } %a0)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2esplitArray(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, { i64, [1 x i64] } %a3, { i64, [1 x i64] } %a4, { i64, [4 x i64] } %a5, %"compiler/source:Span" %a6, %"compiler/lower:pl" %a7, i1 %a8)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2fmir_2eI64T = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\06\00\00\00" }>, align 8
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i32 %a1, i32 %a2, { i64, ptr } %a3, %"compiler/source:Span" %a4)
declare %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/lower:pl" %a1, { i64, [1 x i64] } %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %a0)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2estmt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eendMoved(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1)
declare %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_97232cd54c6d63ec_e5d7df8d53aaa998 = external constant [0 x i8]
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eretCopies(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, i32 %a2)
@olang_loc_2e84a967a4a5e807_2fb41ab57d921c93 = external constant [0 x i8]
@olang_loc_bfe3cde0698f801f_d318aea8cb38d3eb = external constant [0 x i8]
@G_2ecompiler_2fmir_2eEmpty = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2ector(ptr %v0, i64 %a0)
declare { i64, [2 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2escopeRef(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, [2 x i64] } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2ePush_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eToArray_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eScopeRefs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2etypeIs(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [4 x i64] } %a1, i64 %a2, %"compiler/source:Span" %a3)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePayloadOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eexitLevel(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, i64 %a1)
declare %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %a0)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecounts(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlock_26_3e_2eAt_3ccompiler_2ftyped_3aBlock_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_7a0393f255601317_fab53ece13dc18eb = external constant [0 x i8]
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eSelfHolding(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2flower_3arelPath_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2flower_2ecompiler_2flower_3alowering_2epartReleases(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i32 %a1, i64 %a2, i1 %a3)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecounted(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1)
declare { i64, [21 x i64] } @compiler_2fmir_2eStmtAt({ i64, [21 x i64] } %a0, %"compiler/source:Span" %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eholdResult(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/mir:Call" %a1)
@olang_loc_73d6eb0a01355de0_3ee3de28efd59654 = external constant [0 x i8]
declare { i64, [8 x i64] } @compiler_2fmir_2eTermAt({ i64, [8 x i64] } %a0, %"compiler/source:Span" %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v0, ptr %a0, i32 %a1, { i64, [8 x i64] } %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrCarries(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/mir:Lvalue" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/lower:pl" %a1)
declare i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eownCopyOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, { i64, [1 x i64] } %a3, %"compiler/source:Span" %a4, i1 %a5)
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_f1bdf5287cd948f5_22d23fd045556b79 = external constant [0 x i8]
declare %"compiler/mir:Lvalue" @compiler_2fmir_2ecompiler_2fmir_3aFn_2ePlace(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1, { i64, ptr } %a2)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2echeck(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, i32 %a3, i64 %a4, %"compiler/source:Span" %a5)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2efits(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ewiden(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, i32 %a3, %"compiler/source:Span" %a4, { i64, [1 x i64] } %a5)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2flower_2ecompiler_2flower_3alowering_2emutGlobals(ptr %v0, ptr %v1, ptr %v2, ptr %a0)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eguardIf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
@olang_loc_59bbbec53ff2140a_aa19bd361a96e2fe = external constant [0 x i8]
@olang_loc_48d1beea25ddfa94_a3fe957274d91168 = external constant [0 x i8]
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eheldReferent(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, i64 %a2)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eheldLocal(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, i64 %a2)
@olang_loc_7eb84e3ee2221218_b4c673b45eee5a74 = external constant [0 x i8]
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eheldPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, ptr %a2)
@olang_loc_7afd5d1ad8925abe_46fef9b6d0280482 = external constant [0 x i8]
@olang_loc_3e618b7a6832a44e_dc583ba968d0a99a = external constant [0 x i8]
@G_2ecompiler_2ftyped_2eViewOther = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\40" }>, align 8
@G_2ecompiler_2ftyped_2eViewBits = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\3E\00\00\00\00\00\00\00" }>, align 8
declare i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2ehoistExpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %a0, ptr %a1, ptr %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_He8fa2eab054d0b98ccbd3d6295fac885(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2ehoistTarget(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2ehoistStmts(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %a0, ptr %a1, { i64, ptr } %a2)
@olang_loc_e71bb0512ed49da1_8a89b347fae8a8c5 = external constant [0 x i8]
@olang_loc_4e221d20bbb57f79_e7403e65d23ba1ad = external constant [0 x i8]
declare i64 @compiler_2ftyped_2eDropHolder(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
declare i1 @compiler_2fgeneric_2eWrittenMut(ptr %v0, ptr %a0)
declare %"compiler/lower:level" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eAt_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsEntry(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_563c1466c1100e02_3d75491115d3396 = external constant [0 x i8]
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ePush_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2epreserves(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eClear_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0)
declare %"compiler/mir:BasicBlock" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eTermMentions(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [8 x i64] } %a1, ptr %a2, ptr %a3)
declare { i64, [21 x i64] } @compiler_2fmir_2ecompiler_2fmir_3aStmtList_2eAt(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eMentions(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2flower_2ecompiler_2flower_3alowering_2ereceiverBody(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, i64 %a2)
declare %"std/prelude/map:MapValueIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eValues_3cI64_2c_20I64_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapValueIter_3cI64_2c_20I64_3e_2eNext_3cI64_2c_20I64_3e(ptr %v0, ptr %a0)
@G_2ecompiler_2ftyped_2eMutGlobalsFact = external constant <{ [8 x i8], ptr }>
declare i32 @compiler_2ffacts_2ecompiler_2ffacts_3aTable_2eNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eheldParts(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2, i64 %a3)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddScope(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, %"compiler/source:Span" %a4, i32 %a5)
declare %"compiler/lower:level" @compiler_2flower_3alevel_2ector(ptr %v0, i32 %a0, i32 %a1, i32 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2ePush_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %a0, %"compiler/lower:level" %a1)
@olang_loc_b4c093d89ac06ab2_da68d45f20141fee = external constant [0 x i8]
@olang_loc_e95d2ace38390eeb_6a79953ce794a4e7 = external constant [0 x i8]
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eOwnersSite(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ePartsOnly(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2epartsCopied(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, { i64, [1 x i64] } %a3, %"compiler/source:Span" %a4)
declare i32 @compiler_2fmir_2eFieldsOf(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2eitems(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2egap(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ederef(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
declare %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2epackedField(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, i64 %a3)
declare %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eelem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
declare %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2epayload(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
@olang_loc_25aa1fca937793b6_1bfa8a59c48f3aa2 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2ePop_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0)
declare { i32, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlock_26_3e_2ePop_3ccompiler_2ftyped_3aBlock_26_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"compiler/lower:level" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2ePop_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %a0)
@olang_loc_65caa10a9ab9ec93_4c004a47da8c19bf = external constant [0 x i8]
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddParam(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2ePush_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %a0)
@G_2ecompiler_2fmir_2eNoScope = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eholdParams(ptr %v0, ptr %v1, ptr %v2, ptr %a0)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2equietX(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_ea72cddf05e42cbb_238677819f048e67 = external constant [0 x i8]
@olang_loc_fe1d0d15a7f0c4e3_7c1e48fedf91487f = external constant [0 x i8]
@olang_loc_43c562ec71e00848_102dc0f053e29474 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eLen_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0)
declare i32 @compiler_2flower_2ecompiler_2flower_3alowering_2eobjectOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eReadDerived(ptr %v0, ptr %a0, i64 %a1, { i64, [2 x i64] } %a2)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2ereadHere(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, ptr %a2, ptr %a3)
@olang_loc_15f99fcbd43babda_53e78f535034c6 = external constant [0 x i8]
declare i64 @compiler_2flower_2ecompiler_2flower_3alowering_2eguardOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1)
@G_2ecompiler_2ffree_2eNotSole = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@olang_loc_47d4f023ba03b097_5ff9e48511238993 = external constant [0 x i8]
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2ecopyPart(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, { i64, [1 x i64] } %a3, %"compiler/source:Span" %a4)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eguarded(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, i64 %a2, { i64, [15 x i64] } %a3, { i64, [1 x i64] } %a4, %"compiler/source:Span" %a5)
@G_2ecompiler_2fmir_2eNoBlock = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
@olang_loc_5f06e436ba25f30_8078c3a4dcac4c4 = external constant [0 x i8]
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ewaits(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, i64 %a1, ptr %a2, ptr %a3)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eRemoveAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_a61cfa4a479d7a25_9400c4278bb1e539 = external constant [0 x i8]
@olang_loc_57b94e28dfb9b502_11fd69472c69d516 = external constant [0 x i8]
@olang_loc_76519f2a5446c8c2_195fd4b9f9cd3b36 = external constant [0 x i8]
@olang_loc_babafd94d84db46c_e9d5138a9339dba0 = external constant [0 x i8]
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eword(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, [1 x i64] } %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eLen_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %a0)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_3de6741a678ec223_687ea1dcbf00b0ef = external constant [0 x i8]
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2epackedRead(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, %"compiler/source:Span" %a3)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2estableRef(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1)
@olang_loc_27604e529e9a5bde_d86cf7c50ff5ec3a = external constant [0 x i8]
@olang_loc_8c91a6d7a61b2df6_ddcf23b133d92f82 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3apl_3e_2eLen_3ccompiler_2flower_3apl_3e(ptr %v0, ptr %a0)
declare %"compiler/lower:pl" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3apl_3e_2eAt_3ccompiler_2flower_3apl_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare { { i64, [7 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2ehelperCallee(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, i32 %a2)
@olang_loc_3b3f675a7fcfa09e_a6d8609e08455d8a = external constant [0 x i8]
@olang_loc_a39e67f1cd7c0b1f_e499cc399c2ba1cb = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eRefMut_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2flower_2ecompiler_2flower_3alowering_2estepType(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Lvalue" %a1, i64 %a2)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddConst(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2flower_2ecompiler_2flower_3aLowerer_2etext(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eRef_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2evalue(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1)
declare { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eregionOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fmir_3aLocalId_3e_2_Hf0fb0e232c68e27195d0770621b0035a(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2esettled(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, [1 x i64] } %a2, { i64, [4 x i64] } %a3, i32 %a4, %"compiler/source:Span" %a5)
@olang_loc_8878eb20a40721c6_39b06fa96ecc3992 = external constant [0 x i8]
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eviewValue(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2evalueArray(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eLen_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %a0)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eAt_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2earrayCopy(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %a3, { i64, [1 x i64] } %a4, i1 %a5)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2econvertsApart(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ewritesOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_61b48c347dd7ae79_910b37d8abe9da8d = external constant [0 x i8]
@olang_loc_3762df0b7916f10e_cd67f341de4e403a = external constant [0 x i8]
@olang_loc_361db8f3f305ba57_fe8cdfd51e5f0a7b = external constant [0 x i8]
@olang_loc_b6f2e844e897222f_f7ec98089a0619a3 = external constant [0 x i8]
@olang_loc_7f4c2cd212f442f4_5795b97329564c8 = external constant [0 x i8]
@olang_loc_3240793a95d68ec4_8a2d542020d48ba0 = external constant [0 x i8]
@olang_loc_732ec0ad79d18ec2_8d6ce076927c710e = external constant [0 x i8]
@olang_loc_de502b4556e13d28_d48b9fb731677334 = external constant [0 x i8]
declare i1 @compiler_2flower_2eplainPlace(ptr %v0, ptr %a0)
@olang_loc_ff6916793e63751a_93fd2eadd0fa4b86 = external constant [0 x i8]
@olang_loc_2409226a81d50f6c_b1d0e1d8308455a0 = external constant [0 x i8]
declare i1 @compiler_2flower_2esamePlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2flower_2ereadsAny(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
@olang_loc_4dc0cdceec1901ae_7c3defc5bc60c3ca = external constant [0 x i8]
@olang_loc_2d407f0f8b220e9a_96a1481a89b32b26 = external constant [0 x i8]
@olang_loc_507be9c6ca1ca599_d80eabfba6b49be5 = external constant [0 x i8]
@olang_loc_ef2d75aaca2b0e72_154891bbf0c2fa3e = external constant [0 x i8]
@olang_loc_131c31ba2e03204a_ed00d1201b990436 = external constant [0 x i8]
@olang_loc_30f94c519aa44d4_7617c9da302fd0b8 = external constant [0 x i8]
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
