; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/mir:Fn" = type { { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/lower:lowering" = type { ptr, ptr, ptr, %"compiler/mir:Fn", i64, { i64, [4 x i64] }, i32, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i32, { i64, [1 x i64] }, %"compiler/typed:Plan", i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i32 }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/lower:Lowerer" = type { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i32, i32 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i32, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/mir:Call" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Lvalue", i1, i32, i32, i32 }
%"compiler/mir:Range" = type { i32, i32 }
%"compiler/mir:Lvalue" = type { { i64, [2 x i64] }, %"compiler/mir:Range" }
%"compiler/mir:Local" = type { i32, %"compiler/source:Span", i32, i32, { i64, [1 x i64] } }
%"compiler/lower:level" = type { i32, i32, i32 }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/lower:pl" = type { { i64, [2 x i64] }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:BlockInfo" = type { i32, i32, %"compiler/source:Span" }
%"compiler/mir:ScopeInfo" = type { i32, i32, i32, %"compiler/source:Span", i32 }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:Capture" = type { i32, ptr }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/mir:Case" = type { i64, i32 }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32, i1 }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr }
%"compiler/free:leaf" = type { { i64, ptr }, i64 }
%"compiler/mir:TaskClause" = type { %"compiler/mir:Range", i1, { i64, [4 x i64] } }
%"compiler/typed:Spawn" = type { { i64, ptr }, ptr, { i64, ptr }, i32 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, { i64, [2 x i64] }, i32, i1, i1 }
%"compiler/typed:TaskClause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/lower:tryCtx" = type { i64, { i64, ptr }, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/lower:loopCtx" = type { i32, i64, i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
@G_2ecompiler_2flower_2eContract = constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2flower_2eEmpty = constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2flower_2eFailIds = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\11\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailIds.k1, [8 x i8] c"\12\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailIds.k2, [8 x i8] c"\12\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailIds.k3, [8 x i8] c"\11\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailIds.k4, [8 x i8] c"\14\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailIds.k5, [8 x i8] c"\11\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailIds.k6 }>, align 64
@G_2ecompiler_2flower_2eFailIds.k1 = internal constant <{ [17 x i8] }> <{ [17 x i8] c"\73\74\64\2F\70\72\65\6C\75\64\65\2F\61\72\72\61\79" }>, align 8
@G_2ecompiler_2flower_2eFailIds.k2 = internal constant <{ [18 x i8] }> <{ [18 x i8] c"\73\74\64\2F\70\72\65\6C\75\64\65\2F\6E\75\6D\62\65\72" }>, align 8
@G_2ecompiler_2flower_2eFailIds.k3 = internal constant <{ [18 x i8] }> <{ [18 x i8] c"\73\74\64\2F\70\72\65\6C\75\64\65\2F\6E\75\6D\62\65\72" }>, align 8
@G_2ecompiler_2flower_2eFailIds.k4 = internal constant <{ [17 x i8] }> <{ [17 x i8] c"\73\74\64\2F\70\72\65\6C\75\64\65\2F\65\6E\75\6D\73" }>, align 8
@G_2ecompiler_2flower_2eFailIds.k5 = internal constant <{ [20 x i8] }> <{ [20 x i8] c"\73\74\64\2F\70\72\65\6C\75\64\65\2F\61\72\67\75\6D\65\6E\74" }>, align 8
@G_2ecompiler_2flower_2eFailIds.k6 = internal constant <{ [17 x i8] }> <{ [17 x i8] c"\73\74\64\2F\70\72\65\6C\75\64\65\2F\61\72\72\61\79" }>, align 8
@G_2ecompiler_2flower_2eFailTypes = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\0A\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailTypes.k1, [8 x i8] c"\0B\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailTypes.k2, [8 x i8] c"\0B\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailTypes.k3, [8 x i8] c"\09\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailTypes.k4, [8 x i8] c"\0D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailTypes.k5, [8 x i8] c"\0A\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailTypes.k6 }>, align 64
@G_2ecompiler_2flower_2eFailTypes.k1 = internal constant <{ [10 x i8] }> <{ [10 x i8] c"\41\72\72\61\79\45\72\72\6F\72" }>, align 8
@G_2ecompiler_2flower_2eFailTypes.k2 = internal constant <{ [11 x i8] }> <{ [11 x i8] c"\4E\75\6D\62\65\72\45\72\72\6F\72" }>, align 8
@G_2ecompiler_2flower_2eFailTypes.k3 = internal constant <{ [11 x i8] }> <{ [11 x i8] c"\4E\75\6D\62\65\72\45\72\72\6F\72" }>, align 8
@G_2ecompiler_2flower_2eFailTypes.k4 = internal constant <{ [9 x i8] }> <{ [9 x i8] c"\43\61\73\65\45\72\72\6F\72" }>, align 8
@G_2ecompiler_2flower_2eFailTypes.k5 = internal constant <{ [13 x i8] }> <{ [13 x i8] c"\41\72\67\75\6D\65\6E\74\45\72\72\6F\72" }>, align 8
@G_2ecompiler_2flower_2eFailTypes.k6 = internal constant <{ [10 x i8] }> <{ [10 x i8] c"\41\72\72\61\79\45\72\72\6F\72" }>, align 8
@G_2ecompiler_2flower_2eFailWords = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\0C\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailWords.k1, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailWords.k2, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailWords.k3, [8 x i8] c"\0A\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailWords.k4, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailWords.k5, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flower_2eFailWords.k6 }>, align 64
@G_2ecompiler_2flower_2eFailWords.k1 = internal constant <{ [12 x i8] }> <{ [12 x i8] c"\4F\55\54\5F\4F\46\5F\52\41\4E\47\45" }>, align 8
@G_2ecompiler_2flower_2eFailWords.k2 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\4F\56\45\52\46\4C\4F\57" }>, align 8
@G_2ecompiler_2flower_2eFailWords.k3 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\49\4E\56\41\4C\49\44" }>, align 8
@G_2ecompiler_2flower_2eFailWords.k4 = internal constant <{ [10 x i8] }> <{ [10 x i8] c"\57\52\4F\4E\47\5F\43\41\53\45" }>, align 8
@G_2ecompiler_2flower_2eFailWords.k5 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\49\4E\56\41\4C\49\44" }>, align 8
@G_2ecompiler_2flower_2eFailWords.k6 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\45\4D\50\54\59" }>, align 8
@G_2ecompiler_2flower_2eInvalid = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2flower_2eOutOfBounds = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2flower_2eOverflow = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2flower_2eWrongCase = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
define dso_local void @compiler_2flower_2eFailWords_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [6 x { i64, ptr }] undef, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t2 = insertvalue [6 x { i64, ptr }] %t1, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t3 = insertvalue [6 x { i64, ptr }] %t2, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d2, i32 0, i32 1) }, 2
  %t4 = insertvalue [6 x { i64, ptr }] %t3, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d3, i32 0, i32 1) }, 3
  %t5 = insertvalue [6 x { i64, ptr }] %t4, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d4, i32 0, i32 1) }, 4
  %t6 = insertvalue [6 x { i64, ptr }] %t5, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d5, i32 0, i32 1) }, 5
  store [6 x { i64, ptr }] %t6, ptr @G_2ecompiler_2flower_2eFailWords
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2eWrongCase_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 3, ptr @G_2ecompiler_2flower_2eWrongCase, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2flower_2ecallOfExpr(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l23 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca i1
  %l37 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l4, !tbaa !29
  br label %bb31
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t23 = load ptr, ptr %l13, !tbaa !29
  %t24 = load i64, ptr %t23
  %t26 = icmp eq i64 %t24, 14
  store i1 %t26, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t27 = load i1, ptr %l14, !tbaa !21
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t30, i32 0, i32 2
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb19
bb11:
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Try", ptr %t34, i32 0, i32 0
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = icmp eq ptr %t37, null
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb12, label %bb13
bb12:
  %t43 = load ptr, ptr %l2, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Try", ptr %t43, i32 0, i32 0
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = icmp eq ptr %t46, null
  br i1 %t48, label %bb14, label %bb15
bb13:
  store ptr null, ptr %l23, !tbaa !29
  br label %bb18
bb14:
  call void @__olang_check_failed(ptr @olang_loc_9dd6f9307adcfcd5_1dbcb3e322355069)
  unreachable
bb15:
  br label %bb16
bb16:
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t52 = getelementptr %"compiler/typed:Try", ptr %t50, i32 0, i32 0
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = call ptr @compiler_2flower_2ecallOfExpr(ptr %v0, ptr %t53)
  store ptr %t55, ptr %l29
  br label %bb17
bb17:
  %t56 = load ptr, ptr %l29, !tbaa !29
  store ptr %t56, ptr %l23, !tbaa !29
  br label %bb18
bb18:
  %t57 = load ptr, ptr %l23, !tbaa !29
  store ptr %t57, ptr %l4, !tbaa !29
  br label %bb31
bb19:
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t59 = load ptr, ptr %l30, !tbaa !29
  %t60 = icmp ne ptr %t59, null
  br i1 %t60, label %bb20, label %bb21
bb20:
  %t62 = load ptr, ptr %l30, !tbaa !29
  %t63 = load i64, ptr %t62
  %t65 = icmp eq i64 %t63, 17
  store i1 %t65, ptr %l31, !tbaa !21
  br label %bb21
bb21:
  %t66 = load i1, ptr %l31, !tbaa !21
  br i1 %t66, label %bb22, label %bb23
bb22:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr { i64, [5 x i64] }, ptr %t67, i32 0, i32 1
  %t70 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t69, i32 0, i32 2
  %t71 = load ptr, ptr %t70
  store ptr %t71, ptr %l3, !tbaa !29
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t73 = load ptr, ptr %l3, !tbaa !29
  %t75 = call ptr @compiler_2flower_2ecallOfExpr(ptr %v0, ptr %t73)
  store ptr %t75, ptr %l37
  br label %bb25
bb25:
  %t76 = load ptr, ptr %l37, !tbaa !29
  store ptr %t76, ptr %l4, !tbaa !29
  br label %bb31
bb26:
  br i1 true, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  store ptr null, ptr %l4, !tbaa !29
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_7df9a24eda8a923d_42e903e9e9d8e7b1)
  unreachable
bb31:
  %t77 = load ptr, ptr %l4, !tbaa !29
  store ptr %t77, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eLower(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %lp2 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %lp11 = alloca ptr
  %l15 = alloca ptr
  %l26 = alloca %"compiler/mir:Fn"
  %l29 = alloca i64
  %l33 = alloca i64
  %l36 = alloca i64
  %l54 = alloca ptr
  %l58 = alloca i32
  %l59 = alloca ptr
  %l63 = alloca { i64, ptr }
  %l70 = alloca i32
  %l76 = alloca ptr
  %l82 = alloca i32
  %l84 = alloca i64
  %l91 = alloca %"compiler/lower:lowering"
  %l94 = alloca i64
  %l97 = alloca i64
  %l102 = alloca %"compiler/typed:Plan"
  %l107 = alloca i1
  %l114 = alloca i1
  %l118 = alloca %"compiler/mir:Fn"
  %s4 = alloca %olang.scope
  %t15 = alloca { i64, [2 x i64] }, align 8
  %t36 = alloca %"compiler/mir:Fn", align 8
  %t183 = alloca %"compiler/lower:lowering", align 8
  %t214 = alloca %"compiler/typed:Plan", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l15
  br label %bb1
bb1:
  %t8 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t8, ptr %lp2
  %t9 = load ptr, ptr %l15, !tbaa !29
  %t10 = load ptr, ptr %lp2
  store ptr %t9, ptr %t10, !tbaa !29
  %t11 = load i64, ptr %l1, !tbaa !24
  %t13 = trunc i64 %t11 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t15
  %t16 = getelementptr { i64, [2 x i64] }, ptr %t15, i32 0, i32 0
  store i64 0, ptr %t16
  %t18 = insertvalue { i32 } undef, i32 %t13, 0
  %t19 = getelementptr { i64, [2 x i64] }, ptr %t15, i32 0, i32 1
  store { i32 } %t18, ptr %t19
  %t20 = load { i64, [2 x i64] }, ptr %t15
  %t21 = load ptr, ptr %lp2
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Body", ptr %t22, i32 0, i32 2
  %t25 = load i32, ptr %t24, !tbaa !23
  %t26 = load ptr, ptr %lp2
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/typed:Body", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  %t31 = load ptr, ptr %lp2
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/typed:Body", ptr %t32, i32 0, i32 4
  %t35 = load %"compiler/source:Span", ptr %t34
  call void @compiler_2fmir_3aFn_2ector(ptr %t36, ptr %v1, { i64, [2 x i64] } %t20, i32 %t25, i64 %t30, %"compiler/source:Span" %t35)
  call void @llvm.memmove.p0.p0.i64(ptr %l26, ptr %t36, i64 248, i1 false)
  br label %bb2
bb2:
  %t41 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 248, i64 8)
  store ptr %t41, ptr %lp3
  %t42 = load ptr, ptr %lp3
  call void @llvm.memmove.p0.p0.i64(ptr %t42, ptr %l26, i64 248, i1 false)
  store i64 0, ptr %l4, !tbaa !24
  %t43 = load ptr, ptr %lp2
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/typed:Body", ptr %t44, i32 0, i32 13
  %t48 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eLen_3cI32_3e(ptr %v1, ptr %t46)
  store i64 %t48, ptr %l29
  br label %bb3
bb3:
  %t49 = load i64, ptr %l29, !tbaa !24
  store i64 %t49, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l5, !tbaa !24
  %t51 = load i64, ptr %l4, !tbaa !24
  %t54 = icmp sgt i64 %t50, %t51
  br i1 %t54, label %bb4, label %bb5
bb4:
  %t56 = load i64, ptr %l6, !tbaa !24
  %t58 = icmp sgt i64 %t56, 0
  br i1 %t58, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb9
bb6:
  %t60 = load i64, ptr %l5, !tbaa !24
  %t61 = load i64, ptr %l4, !tbaa !24
  %t64 = sub i64 %t60, %t61
  %t65 = load i64, ptr %l6, !tbaa !24
  %t68 = add i64 %t64, %t65
  %t70 = sub i64 %t68, 1
  %t71 = load i64, ptr %l6, !tbaa !24
  %t74 = sdiv i64 %t70, %t71
  store i64 %t74, ptr %l36, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb8
bb8:
  %t76 = load i64, ptr %l36, !tbaa !24
  store i64 %t76, ptr %l33, !tbaa !24
  br label %bb9
bb9:
  %t77 = load i64, ptr %l33, !tbaa !24
  store i64 %t77, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb10
bb10:
  %t78 = load i64, ptr %l8, !tbaa !24
  %t79 = load i64, ptr %l7, !tbaa !24
  %t82 = icmp slt i64 %t78, %t79
  %t84 = xor i1 %t82, true
  br i1 %t84, label %bb11, label %bb12
bb11:
  br label %bb19
bb12:
  br label %bb13
bb13:
  %t86 = load i64, ptr %l4, !tbaa !24
  %t87 = load i64, ptr %l8, !tbaa !24
  %t88 = load i64, ptr %l6, !tbaa !24
  %t91 = mul i64 %t87, %t88
  %t94 = add i64 %t86, %t91
  store i64 %t94, ptr %l9, !tbaa !24
  %t96 = load ptr, ptr %lp3
  %t97 = getelementptr %"compiler/mir:Fn", ptr %t96, i32 0, i32 23
  store ptr %t97, ptr %l54, !tbaa !29
  %t98 = load ptr, ptr %lp2
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = getelementptr %"compiler/typed:Body", ptr %t99, i32 0, i32 13
  %t102 = load i64, ptr %l9, !tbaa !24
  %t105 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eAt_3cI32_3e(ptr %v1, ptr %t101, i64 %t102)
  store i32 %t105, ptr %l58
  br label %bb14
bb14:
  %t106 = load ptr, ptr %l54, !tbaa !29
  %t107 = load i32, ptr %l58, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2ePush_3cI32_3e(ptr %v1, ptr %t106, i32 %t107)
  br label %bb15
bb15:
  %t108 = load ptr, ptr %lp3
  %t109 = getelementptr %"compiler/mir:Fn", ptr %t108, i32 0, i32 24
  store ptr %t109, ptr %l59, !tbaa !29
  %t110 = load ptr, ptr %lp2
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = getelementptr %"compiler/typed:Body", ptr %t111, i32 0, i32 14
  %t114 = load i64, ptr %l9, !tbaa !24
  %t117 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t113, i64 %t114)
  store { i64, ptr } %t117, ptr %l63
  br label %bb16
bb16:
  %t118 = load ptr, ptr %l59, !tbaa !29
  %t119 = load { i64, ptr }, ptr %l63, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t118, { i64, ptr } %t119)
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t120 = load i64, ptr %l8, !tbaa !24
  %t122 = add i64 %t120, 1
  store i64 %t122, ptr %l8, !tbaa !24
  br label %bb10
bb19:
  %t124 = load ptr, ptr %lp2
  %t125 = load ptr, ptr %t124, !tbaa !29
  %t127 = getelementptr %"compiler/typed:Body", ptr %t125, i32 0, i32 15
  %t128 = load i1, ptr %t127, !tbaa !21
  br i1 %t128, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s4
  %t130 = load ptr, ptr %lp3
  %t131 = getelementptr %"compiler/mir:Fn", ptr %t130, i32 0, i32 25
  store i1 true, ptr %t131, !tbaa !21
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/lower:Lowerer", ptr %t132, i32 0, i32 0
  %t135 = load ptr, ptr %t134, !tbaa !29
  %t137 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %s4, ptr %s4, ptr %t135, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d6, i32 0, i32 1) }, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store i32 %t137, ptr %l70
  br label %bb22
bb21:
  br label %bb28
bb22:
  %t138 = load i32, ptr %l70, !tbaa !23
  store i32 %t138, ptr %l10, !tbaa !23
  %t139 = load i32, ptr %l10, !tbaa !23
  %t140 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t143 = icmp ne i32 %t139, %t140
  br i1 %t143, label %bb23, label %bb24
bb23:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/lower:Lowerer", ptr %t145, i32 0, i32 0
  %t148 = load ptr, ptr %t147, !tbaa !29
  %t150 = getelementptr %"compiler/generic:Program", ptr %t148, i32 0, i32 2
  store ptr %t150, ptr %l76, !tbaa !29
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/lower:Lowerer", ptr %t151, i32 0, i32 0
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t156 = getelementptr %"compiler/generic:Program", ptr %t154, i32 0, i32 2
  %t157 = load ptr, ptr %lp2
  %t158 = load ptr, ptr %t157, !tbaa !29
  %t160 = getelementptr %"compiler/typed:Body", ptr %t158, i32 0, i32 2
  %t161 = load i32, ptr %t160, !tbaa !23
  %t164 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t156, i32 %t161)
  store i32 %t164, ptr %l82
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t165 = load i32, ptr %l10, !tbaa !23
  %t166 = load ptr, ptr %l76, !tbaa !29
  %t167 = load i32, ptr %l82, !tbaa !23
  %t169 = call i64 @compiler_2fmir_2eErrorCode(ptr %v0, ptr %t166, i32 %t167, i32 %t165, i64 0)
  store i64 %t169, ptr %l84
  br label %bb26
bb26:
  %t170 = load i64, ptr %l84, !tbaa !24
  %t171 = load ptr, ptr %lp3
  %t172 = getelementptr %"compiler/mir:Fn", ptr %t171, i32 0, i32 26
  store i64 %t170, ptr %t172, !tbaa !24
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s4)
  br label %bb28
bb28:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load ptr, ptr %lp2
  %t175 = load ptr, ptr %t174, !tbaa !29
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr %"compiler/lower:Lowerer", ptr %t176, i32 0, i32 0
  %t179 = load ptr, ptr %t178, !tbaa !29
  %t181 = getelementptr %"compiler/generic:Program", ptr %t179, i32 0, i32 2
  %t182 = load ptr, ptr %lp3
  call void @compiler_2flower_3alowering_2ector(ptr %t183, ptr %v0, ptr %v1, ptr %v0, ptr %v1, ptr %v1, ptr %t173, ptr %t175, ptr %t181, ptr %t182)
  call void @llvm.memmove.p0.p0.i64(ptr %l91, ptr %t183, i64 608, i1 false)
  br label %bb29
bb29:
  %t188 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 608, i64 8)
  store ptr %t188, ptr %lp11
  %t189 = load ptr, ptr %lp11
  call void @llvm.memmove.p0.p0.i64(ptr %t189, ptr %l91, i64 608, i1 false)
  %t190 = load ptr, ptr %lp2
  %t191 = load ptr, ptr %t190, !tbaa !29
  %t193 = getelementptr %"compiler/typed:Body", ptr %t191, i32 0, i32 3
  %t194 = load i64, ptr %t193, !tbaa !24
  %t196 = load ptr, ptr %lp11
  %t197 = getelementptr %"compiler/lower:lowering", ptr %t196, i32 0, i32 4
  store i64 %t194, ptr %t197, !tbaa !24
  %t198 = load i64, ptr %l1, !tbaa !24
  store i64 %t198, ptr %l94, !tbaa !24
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t201 = getelementptr %"compiler/lower:Lowerer", ptr %t199, i32 0, i32 2
  %t203 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eLen_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %t201)
  store i64 %t203, ptr %l97
  br label %bb30
bb30:
  %t204 = load i64, ptr %l94, !tbaa !24
  %t205 = load i64, ptr %l97, !tbaa !24
  %t206 = icmp slt i64 %t204, %t205
  br i1 %t206, label %bb31, label %bb32
bb31:
  %t208 = load ptr, ptr %lp11
  %t209 = getelementptr %"compiler/lower:lowering", ptr %t208, i32 0, i32 19
  store i1 true, ptr %t209, !tbaa !21
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t212 = getelementptr %"compiler/lower:Lowerer", ptr %t210, i32 0, i32 2
  %t213 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %t214, ptr %v0, ptr %v1, ptr %t212, i64 %t213)
  call void @llvm.memmove.p0.p0.i64(ptr %l102, ptr %t214, i64 152, i1 false)
  br label %bb33
bb32:
  br label %bb34
bb33:
  %t217 = load ptr, ptr %lp11
  %t218 = getelementptr %"compiler/lower:lowering", ptr %t217, i32 0, i32 22
  call void @llvm.memmove.p0.p0.i64(ptr %t218, ptr %l102, i64 152, i1 false)
  br label %bb34
bb34:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t221 = getelementptr %"compiler/lower:Lowerer", ptr %t219, i32 0, i32 3
  %t222 = load ptr, ptr %t221, !tbaa !29
  %t224 = icmp eq ptr %t222, null
  %t226 = xor i1 %t224, true
  br i1 %t226, label %bb35, label %bb36
bb35:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = getelementptr %"compiler/lower:Lowerer", ptr %t228, i32 0, i32 3
  %t231 = load ptr, ptr %t230, !tbaa !29
  %t233 = icmp eq ptr %t231, null
  br i1 %t233, label %bb37, label %bb38
bb36:
  store i1 false, ptr %l107, !tbaa !21
  br label %bb41
bb37:
  call void @__olang_check_failed(ptr @olang_loc_f8b3706059fec8c0_d163f284ba6a3ccc)
  unreachable
bb38:
  br label %bb39
bb39:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = getelementptr %"compiler/lower:Lowerer", ptr %t235, i32 0, i32 3
  %t238 = load ptr, ptr %t237, !tbaa !29
  %t239 = load i64, ptr %l1, !tbaa !24
  %t242 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eFrees(ptr %v0, ptr %t238, i64 %t239)
  store i1 %t242, ptr %l114
  br label %bb40
bb40:
  %t243 = load i1, ptr %l114, !tbaa !21
  store i1 %t243, ptr %l107, !tbaa !21
  br label %bb41
bb41:
  %t244 = load i1, ptr %l107, !tbaa !21
  %t245 = load ptr, ptr %lp11
  %t246 = getelementptr %"compiler/lower:lowering", ptr %t245, i32 0, i32 23
  store i1 %t244, ptr %t246, !tbaa !21
  %t247 = load ptr, ptr %lp11
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2erun(ptr %v1, ptr %t247)
  br label %bb42
bb42:
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t250 = load ptr, ptr %lp11
  %t251 = getelementptr %"compiler/lower:lowering", ptr %t250, i32 0, i32 8
  %t252 = load i1, ptr %t251, !tbaa !21
  %t255 = getelementptr %"compiler/lower:Lowerer", ptr %t249, i32 0, i32 5
  store i1 %t252, ptr %t255, !tbaa !21
  %t256 = load ptr, ptr %lp11
  %t257 = getelementptr %"compiler/lower:lowering", ptr %t256, i32 0, i32 3
  call void @llvm.memmove.p0.p0.i64(ptr %l118, ptr %t257, i64 248, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l118, i64 248, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eLowerKey(ptr %out, ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i1
  %l15 = alloca %"compiler/mir:Fn"
  %l23 = alloca %"compiler/mir:Fn"
  %l29 = alloca %"compiler/mir:Fn"
  %l35 = alloca %"compiler/mir:Fn"
  %l43 = alloca %"compiler/mir:Fn"
  %t14 = alloca %"compiler/mir:Fn", align 8
  %t33 = alloca %"compiler/mir:Fn", align 8
  %t48 = alloca %"compiler/mir:Fn", align 8
  %t62 = alloca %"compiler/mir:Fn", align 8
  %t81 = alloca %"compiler/mir:Fn", align 8
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l2, !tbaa !23
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l2, !tbaa !23
  %t13 = sext i32 %t11 to i64
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eLower(ptr %t14, ptr %v0, ptr %v1, ptr %t10, i64 %t13)
  call void @llvm.memmove.p0.p0.i64(ptr %l15, ptr %t14, i64 248, i1 false)
  br label %bb4
bb4:
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l15, i64 248, i1 false)
  br label %ret
bb5:
  %t17 = load { i64, [2 x i64] }, ptr %l1
  %t19 = extractvalue { i64, [2 x i64] } %t17, 0
  %t20 = icmp eq i64 %t19, 2
  br i1 %t20, label %bb6, label %bb7
bb6:
  %t22 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t23 = getelementptr { i32, i32 }, ptr %t22, i32 0, i32 0
  %t24 = load i32, ptr %t23
  store i32 %t24, ptr %l3
  %t26 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t27 = getelementptr { i32, i32 }, ptr %t26, i32 0, i32 1
  %t28 = load i32, ptr %t27
  store i32 %t28, ptr %l4, !tbaa !23
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i32, ptr %l3
  %t32 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2ehelper(ptr %t33, ptr %v0, ptr %v1, ptr %t30, i32 %t31, i32 %t32)
  call void @llvm.memmove.p0.p0.i64(ptr %l23, ptr %t33, i64 248, i1 false)
  br label %bb9
bb9:
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l23, i64 248, i1 false)
  br label %ret
bb10:
  %t37 = load { i64, [2 x i64] }, ptr %l1
  %t39 = extractvalue { i64, [2 x i64] } %t37, 0
  %t40 = icmp eq i64 %t39, 1
  br i1 %t40, label %bb11, label %bb12
bb11:
  %t42 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t43 = getelementptr { i32 }, ptr %t42, i32 0, i32 0
  %t44 = load i32, ptr %t43
  store i32 %t44, ptr %l5, !tbaa !23
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load i32, ptr %l5, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eadapterFn(ptr %t48, ptr %v0, ptr %v1, ptr %t46, i32 %t47)
  call void @llvm.memmove.p0.p0.i64(ptr %l29, ptr %t48, i64 248, i1 false)
  br label %bb14
bb14:
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l29, i64 248, i1 false)
  br label %ret
bb15:
  %t51 = load { i64, [2 x i64] }, ptr %l1
  %t53 = extractvalue { i64, [2 x i64] } %t51, 0
  %t54 = icmp eq i64 %t53, 3
  br i1 %t54, label %bb16, label %bb17
bb16:
  %t56 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t57 = getelementptr { i64 }, ptr %t56, i32 0, i32 0
  %t58 = load i64, ptr %t57
  store i64 %t58, ptr %l6, !tbaa !24
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2einitFn(ptr %t62, ptr %v0, ptr %v1, ptr %t60, i64 %t61)
  call void @llvm.memmove.p0.p0.i64(ptr %l35, ptr %t62, i64 248, i1 false)
  br label %bb19
bb19:
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l35, i64 248, i1 false)
  br label %ret
bb20:
  %t65 = load { i64, [2 x i64] }, ptr %l1
  %t67 = extractvalue { i64, [2 x i64] } %t65, 0
  %t68 = icmp eq i64 %t67, 4
  br i1 %t68, label %bb21, label %bb22
bb21:
  %t70 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t71 = getelementptr { i64, i1 }, ptr %t70, i32 0, i32 0
  %t72 = load i64, ptr %t71
  store i64 %t72, ptr %l7, !tbaa !24
  %t74 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t75 = getelementptr { i64, i1 }, ptr %t74, i32 0, i32 1
  %t76 = load i1, ptr %t75
  store i1 %t76, ptr %l8, !tbaa !21
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load i64, ptr %l7, !tbaa !24
  %t80 = load i1, ptr %l8, !tbaa !21
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eanyRender(ptr %t81, ptr %v0, ptr %v1, ptr %t78, i64 %t79, i1 %t80)
  call void @llvm.memmove.p0.p0.i64(ptr %l43, ptr %t81, i64 248, i1 false)
  br label %bb24
bb24:
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l43, i64 248, i1 false)
  br label %ret
bb25:
  call void @__olang_check_failed(ptr @olang_loc_3c213ca88cac8ac4_ee776128d38d19e0)
  unreachable
ret:
  ret void
}

define dso_local { i1, { i64, ptr }, { i64, ptr } } @compiler_2flower_2ecompiler_2flower_3aLowerer_2eVerifiedKey(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %lp4 = alloca ptr
  %l8 = alloca %"compiler/mir:Fn"
  %l12 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l16 = alloca { i1, { i64, ptr }, { i64, ptr } }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l39 = alloca { i1, { i64, ptr }, { i64, ptr } }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i1, { i64, ptr }, { i64, ptr } }
  %t3 = alloca %"compiler/mir:Fn", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eLowerKey(ptr %t3, ptr %v0, ptr %v0, ptr %t1, { i64, [2 x i64] } %a1)
  call void @llvm.memmove.p0.p0.i64(ptr %l8, ptr %t3, i64 248, i1 false)
  br label %bb1
bb1:
  %t6 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 248, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t6, ptr %l8, i64 248, i1 false)
  store ptr %t6, ptr %l3, !tbaa !29
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/lower:Lowerer", ptr %t8, i32 0, i32 5
  %t11 = load i1, ptr %t10, !tbaa !21
  br i1 %t11, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %l12, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr %l14, !tbaa !27
  %t14 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t15 = insertvalue { i1, { i64, ptr }, { i64, ptr } } undef, i1 true, 0
  %t17 = insertvalue { i1, { i64, ptr }, { i64, ptr } } %t15, { i64, ptr } %t13, 1
  %t19 = insertvalue { i1, { i64, ptr }, { i64, ptr } } %t17, { i64, ptr } %t14, 2
  store { i1, { i64, ptr }, { i64, ptr } } %t19, ptr %l16
  %t20 = getelementptr { i1, { i64, ptr }, { i64, ptr } }, ptr %l16, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l17, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l18, !tbaa !24
  %t24 = load i64, ptr %l18, !tbaa !24
  %t25 = mul i64 %t24, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l19, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l18, !tbaa !24
  %t34 = mul i64 %t33, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t36 = getelementptr { i1, { i64, ptr }, { i64, ptr } }, ptr %l16, i32 0, i32 1
  store { i64, ptr } %t35, ptr %t36, !tbaa !27
  %t37 = getelementptr { i1, { i64, ptr }, { i64, ptr } }, ptr %l16, i32 0, i32 2
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l20, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l21, !tbaa !24
  %t41 = load i64, ptr %l21, !tbaa !24
  %t42 = mul i64 %t41, 1
  %t43 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l22, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l21, !tbaa !24
  %t51 = mul i64 %t50, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %t49, i64 %t51, i1 false)
  %t52 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t53 = getelementptr { i1, { i64, ptr }, { i64, ptr } }, ptr %l16, i32 0, i32 2
  store { i64, ptr } %t52, ptr %t53, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t54 = load { i1, { i64, ptr }, { i64, ptr } }, ptr %l16
  store { i1, { i64, ptr }, { i64, ptr } } %t54, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t55 = load ptr, ptr %l3, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/lower:Lowerer", ptr %t56, i32 0, i32 0
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 2
  %t64 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eVerify(ptr %v0, ptr %v0, ptr %v1, ptr %t55, ptr %t61)
  store { i64, ptr } %t64, ptr %l27
  br label %bb5
bb5:
  %t65 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t65, ptr %lp4
  %t66 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t67 = load ptr, ptr %lp4
  store { i64, ptr } %t66, ptr %t67, !tbaa !27
  br i1 %a2, label %bb6, label %bb7
bb6:
  %t70 = load ptr, ptr %l3, !tbaa !29
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/lower:Lowerer", ptr %t71, i32 0, i32 0
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = getelementptr %"compiler/generic:Program", ptr %t74, i32 0, i32 2
  %t79 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eDump(ptr %v0, ptr %v0, ptr %s0, ptr %t70, ptr %t76)
  store { i64, ptr } %t79, ptr %l34
  br label %bb8
bb7:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d10, i32 0, i32 1) }, ptr %l29, !tbaa !27
  br label %bb9
bb8:
  %t80 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 0
  %t82 = extractvalue { i64, ptr } %t80, 1
  %t83 = mul i64 %t81, 1
  %t84 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t83)
  call void @llvm.memcpy.p0.p0.i64(ptr %t84, ptr %t82, i64 %t83, i1 false)
  %t85 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t84, 1
  store { i64, ptr } %t86, ptr %l29, !tbaa !27
  br label %bb9
bb9:
  %t88 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t89 = load ptr, ptr %lp4
  %t90 = load { i64, ptr }, ptr %t89, !tbaa !27
  %t93 = insertvalue { i1, { i64, ptr }, { i64, ptr } } undef, i1 false, 0
  %t95 = insertvalue { i1, { i64, ptr }, { i64, ptr } } %t93, { i64, ptr } %t90, 1
  %t97 = insertvalue { i1, { i64, ptr }, { i64, ptr } } %t95, { i64, ptr } %t88, 2
  store { i1, { i64, ptr }, { i64, ptr } } %t97, ptr %l39
  %t98 = getelementptr { i1, { i64, ptr }, { i64, ptr } }, ptr %l39, i32 0, i32 2
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  store { i64, ptr } %t99, ptr %l40, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  store i64 %t101, ptr %l41, !tbaa !24
  %t102 = load i64, ptr %l41, !tbaa !24
  %t103 = mul i64 %t102, 1
  %t104 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t103)
  %t105 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t104, 1
  store { i64, ptr } %t106, ptr %l42, !tbaa !27
  %t107 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = load i64, ptr %l41, !tbaa !24
  %t112 = mul i64 %t111, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t108, ptr %t110, i64 %t112, i1 false)
  %t113 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t114 = getelementptr { i1, { i64, ptr }, { i64, ptr } }, ptr %l39, i32 0, i32 2
  store { i64, ptr } %t113, ptr %t114, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t115 = load { i1, { i64, ptr }, { i64, ptr } }, ptr %l39
  store { i1, { i64, ptr }, { i64, ptr } } %t115, ptr %rv
  br label %ret
ret:
  %rr = load { i1, { i64, ptr }, { i64, ptr } }, ptr %rv
  ret { i1, { i64, ptr }, { i64, ptr } } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3aLowerer_2ebare(ptr %out, ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca %"compiler/mir:Fn"
  %s0 = alloca %olang.scope
  %t4 = alloca %"compiler/mir:Fn", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, [2 x i64] } %a1, ptr %l3
  store i32 %a2, ptr %l4, !tbaa !23
  %t3 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t3, ptr %l5
  br label %bb1
bb1:
  %t5 = load { i64, [2 x i64] }, ptr %l3
  %t6 = load i32, ptr %l4, !tbaa !23
  %t7 = load %"compiler/source:Span", ptr %l5
  call void @compiler_2fmir_3aFn_2ector(ptr %t4, ptr %v1, { i64, [2 x i64] } %t5, i32 %t6, i64 0, %"compiler/source:Span" %t7)
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %t4, i64 248, i1 false)
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l6, i64 248, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2flower_2ecompiler_2flower_3aLowerer_2eerrQualifier(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l7 = alloca i64
  %l13 = alloca ptr
  %l22 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t6, i32 %a1)
  store i64 %t10, ptr %l7
  br label %bb1
bb1:
  %t11 = load i64, ptr %l7, !tbaa !24
  store i64 %t11, ptr %l2, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lower:Lowerer", ptr %t12, i32 0, i32 0
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 0
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/load:Loader", ptr %t18, i32 0, i32 5
  %t21 = load i64, ptr %l2, !tbaa !24
  %t24 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t20, i64 %t21)
  store ptr %t24, ptr %l13
  br label %bb2
bb2:
  %t25 = load ptr, ptr %l13, !tbaa !29
  %t27 = getelementptr %"compiler/load:Module", ptr %t25, i32 0, i32 2
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  %t29 = load i64, ptr %l2, !tbaa !24
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/lower:Lowerer", ptr %t30, i32 0, i32 0
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/generic:Program", ptr %t33, i32 0, i32 0
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/load:Loader", ptr %t36, i32 0, i32 7
  %t39 = load i64, ptr %t38, !tbaa !24
  %t42 = icmp eq i64 %t29, %t39
  %t45 = call { i64, ptr } @compiler_2fload_2eErrQualifier(ptr %v0, ptr %v1, { i64, ptr } %t28, i1 %t42)
  store { i64, ptr } %t45, ptr %l22
  br label %bb3
bb3:
  %t46 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t46, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ehelperTy(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l2 = alloca i32
  %l5 = alloca i32
  %l11 = alloca i32
  %rv = alloca i32
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = trunc i64 0 to i32
  %t4 = icmp eq i32 %a1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load i32, ptr %l2, !tbaa !23
  store i32 %t6, ptr %l5, !tbaa !23
  br label %bb4
bb2:
  %t10 = getelementptr %"compiler/lower:Lowerer", ptr %a0, i32 0, i32 0
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/generic:Program", ptr %t11, i32 0, i32 2
  %t14 = load i32, ptr %l2, !tbaa !23
  %t17 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnnamed(ptr %v0, ptr %t13, i32 %t14)
  store i32 %t17, ptr %l11
  br label %bb3
bb3:
  %t18 = load i32, ptr %l11, !tbaa !23
  store i32 %t18, ptr %l5, !tbaa !23
  br label %bb4
bb4:
  %t19 = load i32, ptr %l5, !tbaa !23
  store i32 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3aLowerer_2einitFn(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %lp3 = alloca ptr
  %lp4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, [2 x i64] }
  %l9 = alloca i64
  %l10 = alloca i32
  %l12 = alloca i32
  %l17 = alloca i32
  %l19 = alloca %"compiler/typed:Body"
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l24 = alloca ptr
  %l29 = alloca %"compiler/mir:Fn"
  %l31 = alloca %"compiler/lower:lowering"
  %l37 = alloca i64
  %l39 = alloca i64
  %l44 = alloca i64
  %l48 = alloca ptr
  %l57 = alloca i1
  %l61 = alloca ptr
  %l67 = alloca i32
  %l71 = alloca { i64, [2 x i64] }
  %l75 = alloca ptr
  %l79 = alloca ptr
  %l87 = alloca %"compiler/mir:Call"
  %l88 = alloca i32
  %l89 = alloca ptr
  %l93 = alloca ptr
  %l106 = alloca %"compiler/mir:Fn"
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %t13 = alloca %"compiler/typed:Body", align 8
  %t27 = alloca { i64, [2 x i64] }, align 8
  %t34 = alloca %"compiler/mir:Fn", align 8
  %t39 = alloca %"compiler/lower:lowering", align 8
  %t129 = alloca { i64, [2 x i64] }, align 8
  %t146 = alloca { i64, [7 x i64] }, align 8
  %t189 = alloca { i64, [8 x i64] }, align 8
  %t208 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t6, i32 0, i32 %t7, i32 0, i32 0, i64 0)
  store i32 %t10, ptr %l17
  br label %bb1
bb1:
  %t11 = load i32, ptr %l17, !tbaa !23
  store i32 %t11, ptr %l2, !tbaa !23
  %t12 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2flower_2estandIn(ptr %t13, ptr %v1, i32 %t12)
  call void @llvm.memmove.p0.p0.i64(ptr %l19, ptr %t13, i64 160, i1 false)
  br label %bb2
bb2:
  %t15 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 160, i64 8)
  store ptr %t15, ptr %lp3
  %t16 = load ptr, ptr %lp3
  call void @llvm.memmove.p0.p0.i64(ptr %t16, ptr %l19, i64 160, i1 false)
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l20, !tbaa !29
  %t18 = load ptr, ptr %lp3
  store ptr %t18, ptr %l21, !tbaa !29
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/lower:Lowerer", ptr %t19, i32 0, i32 0
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 2
  store ptr %t24, ptr %l24, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i64, ptr %l1, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t27
  %t28 = getelementptr { i64, [2 x i64] }, ptr %t27, i32 0, i32 0
  store i64 3, ptr %t28
  %t30 = insertvalue { i64 } undef, i64 %t26, 0
  %t31 = getelementptr { i64, [2 x i64] }, ptr %t27, i32 0, i32 1
  store { i64 } %t30, ptr %t31
  %t32 = load { i64, [2 x i64] }, ptr %t27
  %t33 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2ebare(ptr %t34, ptr %v0, ptr %v1, ptr %t25, { i64, [2 x i64] } %t32, i32 %t33)
  call void @llvm.memmove.p0.p0.i64(ptr %l29, ptr %t34, i64 248, i1 false)
  br label %bb3
bb3:
  %t38 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 248, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t38, ptr %l29, i64 248, i1 false)
  %t40 = load ptr, ptr %l20, !tbaa !29
  %t41 = load ptr, ptr %l21, !tbaa !29
  %t42 = load ptr, ptr %l24, !tbaa !29
  call void @compiler_2flower_3alowering_2ector(ptr %t39, ptr %v0, ptr %v1, ptr %v0, ptr %v1, ptr %v1, ptr %t40, ptr %t41, ptr %t42, ptr %t38)
  call void @llvm.memmove.p0.p0.i64(ptr %l31, ptr %t39, i64 608, i1 false)
  br label %bb4
bb4:
  %t44 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 608, i64 8)
  store ptr %t44, ptr %lp4
  %t45 = load ptr, ptr %lp4
  call void @llvm.memmove.p0.p0.i64(ptr %t45, ptr %l31, i64 608, i1 false)
  %t46 = load ptr, ptr %lp4
  %t47 = mul i64 0, 16
  %t48 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t47)
  %t49 = insertvalue { i64, ptr } undef, i64 0, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eprologue(ptr %v1, ptr %s0, ptr %t46, { i64, ptr } %t50)
  br label %bb5
bb5:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/lower:Lowerer", ptr %t53, i32 0, i32 0
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = getelementptr %"compiler/generic:Program", ptr %t56, i32 0, i32 46
  store ptr %t58, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb6
bb6:
  %t60 = load i64, ptr %l6, !tbaa !24
  store i64 %t60, ptr %l37, !tbaa !24
  %t61 = load ptr, ptr %l5, !tbaa !29
  %t63 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t61)
  store i64 %t63, ptr %l39
  br label %bb7
bb7:
  %t64 = load i64, ptr %l37, !tbaa !24
  %t65 = load i64, ptr %l39, !tbaa !24
  %t66 = icmp slt i64 %t64, %t65
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb8, label %bb9
bb8:
  br label %bb37
bb9:
  br label %bb10
bb10:
  %t70 = load ptr, ptr %l5, !tbaa !29
  %t71 = load i64, ptr %l6, !tbaa !24
  %t74 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t70, i64 %t71)
  store i64 %t74, ptr %l44
  br label %bb11
bb11:
  %t75 = load i64, ptr %l44, !tbaa !24
  store i64 %t75, ptr %l7, !tbaa !24
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/lower:Lowerer", ptr %t76, i32 0, i32 1
  %t79 = load i64, ptr %l7, !tbaa !24
  %t82 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t78, i64 %t79)
  store ptr %t82, ptr %l48
  br label %bb12
bb12:
  %t83 = load ptr, ptr %l48, !tbaa !29
  %t85 = getelementptr %"compiler/typed:Body", ptr %t83, i32 0, i32 1
  %t86 = load { i64, [2 x i64] }, ptr %t85
  store { i64, [2 x i64] } %t86, ptr %l8
  %t88 = load { i64, [2 x i64] }, ptr %l8
  %t90 = extractvalue { i64, [2 x i64] } %t88, 0
  %t91 = icmp eq i64 %t90, 6
  br i1 %t91, label %bb13, label %bb14
bb13:
  %t93 = getelementptr { i64, [2 x i64] }, ptr %l8, i32 0, i32 1
  %t94 = getelementptr { i64, i32 }, ptr %t93, i32 0, i32 0
  %t95 = load i64, ptr %t94
  store i64 %t95, ptr %l9, !tbaa !24
  br label %bb15
bb14:
  br label %bb30
bb15:
  %t97 = load i64, ptr %l9, !tbaa !24
  %t98 = load i64, ptr %l1, !tbaa !24
  %t101 = icmp eq i64 %t97, %t98
  br i1 %t101, label %bb16, label %bb17
bb16:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/lower:Lowerer", ptr %t103, i32 0, i32 1
  %t106 = load i64, ptr %l7, !tbaa !24
  %t109 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t105, i64 %t106)
  store ptr %t109, ptr %l61
  br label %bb18
bb17:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb19
bb18:
  %t110 = load ptr, ptr %l61, !tbaa !29
  %t112 = getelementptr %"compiler/typed:Body", ptr %t110, i32 0, i32 11
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t115 = icmp eq ptr %t113, null
  %t117 = xor i1 %t115, true
  store i1 %t117, ptr %l57, !tbaa !21
  br label %bb19
bb19:
  %t119 = load i1, ptr %l57, !tbaa !21
  br i1 %t119, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s4
  %t120 = load ptr, ptr %lp4
  %t121 = getelementptr %"compiler/lower:lowering", ptr %t120, i32 0, i32 3
  %t123 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v1, ptr %t121)
  store i32 %t123, ptr %l67
  br label %bb22
bb21:
  br label %bb29
bb22:
  %t124 = load i32, ptr %l67, !tbaa !23
  store i32 %t124, ptr %l10, !tbaa !23
  %t125 = load i64, ptr %l7, !tbaa !24
  %t127 = trunc i64 %t125 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t129
  %t130 = getelementptr { i64, [2 x i64] }, ptr %t129, i32 0, i32 0
  store i64 0, ptr %t130
  %t132 = insertvalue { i32 } undef, i32 %t127, 0
  %t133 = getelementptr { i64, [2 x i64] }, ptr %t129, i32 0, i32 1
  store { i32 } %t132, ptr %t133
  %t134 = load { i64, [2 x i64] }, ptr %t129
  store { i64, [2 x i64] } %t134, ptr %l71
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/lower:Lowerer", ptr %t135, i32 0, i32 1
  %t138 = load i64, ptr %l7, !tbaa !24
  %t141 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t137, i64 %t138)
  store ptr %t141, ptr %l75
  br label %bb23
bb23:
  %t142 = load ptr, ptr %l75, !tbaa !29
  %t144 = getelementptr %"compiler/typed:Body", ptr %t142, i32 0, i32 2
  %t145 = load i32, ptr %t144, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t146
  %t147 = getelementptr { i64, [7 x i64] }, ptr %t146, i32 0, i32 0
  store i64 0, ptr %t147
  %t148 = load { i64, [2 x i64] }, ptr %l71
  %t149 = insertvalue { { i64, [2 x i64] }, i32 } undef, { i64, [2 x i64] } %t148, 0
  %t151 = insertvalue { { i64, [2 x i64] }, i32 } %t149, i32 %t145, 1
  %t152 = getelementptr { i64, [7 x i64] }, ptr %t146, i32 0, i32 1
  store { { i64, [2 x i64] }, i32 } %t151, ptr %t152
  %t153 = load { i64, [7 x i64] }, ptr %t146
  %t155 = load ptr, ptr %lp4
  %t156 = getelementptr %"compiler/lower:lowering", ptr %t155, i32 0, i32 3
  store ptr %t156, ptr %l79, !tbaa !29
  %t158 = load %"compiler/mir:Range", ptr @G_2ecompiler_2fmir_2eEmpty
  %t159 = load %"compiler/mir:Range", ptr @G_2ecompiler_2fmir_2eEmpty
  %t160 = load %"compiler/mir:Lvalue", ptr @G_2ecompiler_2fmir_2eNoPlace
  %t161 = load i32, ptr %l10, !tbaa !23
  %t162 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t163 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t171 = call %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %s4, { i64, [7 x i64] } %t153, %"compiler/mir:Range" %t158, %"compiler/mir:Range" %t159, %"compiler/mir:Lvalue" %t160, i1 false, i32 %t161, i32 %t162, i32 %t163)
  store %"compiler/mir:Call" %t171, ptr %l87
  br label %bb24
bb24:
  %t172 = load ptr, ptr %l79, !tbaa !29
  %t173 = load %"compiler/mir:Call", ptr %l87
  %t174 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v1, ptr %t172, %"compiler/mir:Call" %t173)
  store i32 %t174, ptr %l88
  br label %bb25
bb25:
  %t175 = load i32, ptr %l88, !tbaa !23
  store i32 %t175, ptr %l12, !tbaa !23
  %t176 = load ptr, ptr %lp4
  store ptr %t176, ptr %l89, !tbaa !29
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/lower:Lowerer", ptr %t177, i32 0, i32 1
  %t180 = load i64, ptr %l7, !tbaa !24
  %t183 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t179, i64 %t180)
  store ptr %t183, ptr %l93
  br label %bb26
bb26:
  %t184 = load ptr, ptr %l93, !tbaa !29
  %t186 = getelementptr %"compiler/typed:Body", ptr %t184, i32 0, i32 4
  %t187 = load %"compiler/source:Span", ptr %t186
  %t188 = load i32, ptr %l12, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t189
  %t190 = getelementptr { i64, [8 x i64] }, ptr %t189, i32 0, i32 0
  store i64 4, ptr %t190
  %t192 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t187, 0
  %t194 = insertvalue { %"compiler/source:Span", i32 } %t192, i32 %t188, 1
  %t195 = getelementptr { i64, [8 x i64] }, ptr %t189, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t194, ptr %t195
  %t196 = load { i64, [8 x i64] }, ptr %t189
  %t197 = load ptr, ptr %l89, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v1, ptr %t197, { i64, [8 x i64] } %t196)
  br label %bb27
bb27:
  %t199 = load ptr, ptr %lp4
  %t200 = load i32, ptr %l10, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v1, ptr %t199, i32 %t200)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s4)
  br label %bb29
bb29:
  br label %bb35
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_6409d1aa34b20bea_1e68de4bb2ab27de)
  unreachable
bb35:
  br label %bb36
bb36:
  %t203 = load i64, ptr %l6, !tbaa !24
  %t205 = add i64 %t203, 1
  store i64 %t205, ptr %l6, !tbaa !24
  br label %bb6
bb37:
  %t207 = load ptr, ptr %lp4
  store { i64, [4 x i64] } zeroinitializer, ptr %t208
  %t209 = getelementptr { i64, [4 x i64] }, ptr %t208, i32 0, i32 0
  store i64 0, ptr %t209
  %t210 = load { i64, [4 x i64] }, ptr %t208
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eepilogue(ptr %v1, ptr %t207, { i64, [4 x i64] } %t210)
  br label %bb38
bb38:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t214 = load ptr, ptr %lp4
  %t215 = getelementptr %"compiler/lower:lowering", ptr %t214, i32 0, i32 8
  %t216 = load i1, ptr %t215, !tbaa !21
  %t219 = getelementptr %"compiler/lower:Lowerer", ptr %t213, i32 0, i32 5
  store i1 %t216, ptr %t219, !tbaa !21
  %t220 = load ptr, ptr %lp4
  %t221 = getelementptr %"compiler/lower:lowering", ptr %t220, i32 0, i32 3
  call void @llvm.memmove.p0.p0.i64(ptr %l106, ptr %t221, i64 248, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l106, i64 248, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2flower_2ecompiler_2flower_3aLowerer_2etext(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca i32
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %t1, i32 0, i32 16
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = icmp slt i32 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/lower:Lowerer", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %s1, ptr %s1, ptr %t12, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d11, i32 0, i32 1) }, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i32 %t14, ptr %l7
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t15 = load i32, ptr %l7, !tbaa !23
  %t16 = load ptr, ptr %l4, !tbaa !29
  %t17 = getelementptr %"compiler/lower:Lowerer", ptr %t16, i32 0, i32 16
  store i32 %t15, ptr %t17, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  br label %bb4
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/lower:Lowerer", ptr %t18, i32 0, i32 16
  %t21 = load i32, ptr %t20, !tbaa !23
  store i32 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eadapterBody(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i32
  %l24 = alloca i32
  %l25 = alloca i32
  %l26 = alloca i32
  %l27 = alloca i32
  %l35 = alloca ptr
  %l39 = alloca i32
  %l40 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l54 = alloca i32
  %l58 = alloca ptr
  %l63 = alloca %"compiler/mir:Local"
  %l64 = alloca i32
  %l71 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l83 = alloca ptr
  %l86 = alloca { i64, [1 x i64] }
  %l94 = alloca i1
  %l100 = alloca i32
  %l106 = alloca i32
  %l113 = alloca ptr
  %l116 = alloca %"compiler/lower:level"
  %l119 = alloca i64
  %l120 = alloca i64
  %l125 = alloca %"compiler/mir:Lvalue"
  %l129 = alloca i64
  %l133 = alloca i64
  %l136 = alloca i64
  %l155 = alloca i64
  %l159 = alloca i32
  %l160 = alloca %"compiler/mir:Lvalue"
  %l166 = alloca i32
  %l169 = alloca i32
  %l174 = alloca i1
  %l181 = alloca i32
  %l184 = alloca ptr
  %l187 = alloca i32
  %l188 = alloca { i64, ptr }
  %l194 = alloca i32
  %l197 = alloca i32
  %l203 = alloca ptr
  %l204 = alloca { i64, [7 x i64] }
  %l208 = alloca %"compiler/mir:Range"
  %l212 = alloca %"compiler/mir:Range"
  %l216 = alloca %"compiler/mir:Lvalue"
  %l218 = alloca %"compiler/mir:Lvalue"
  %l226 = alloca %"compiler/mir:Call"
  %l227 = alloca i32
  %l238 = alloca ptr
  %l239 = alloca %"compiler/source:Span"
  %l241 = alloca %"compiler/mir:Lvalue"
  %l254 = alloca ptr
  %l258 = alloca { i64, [4 x i64] }
  %l261 = alloca %"compiler/mir:Lvalue"
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %t66 = alloca { i64, [1 x i64] }, align 8
  %t130 = alloca { i64, [1 x i64] }, align 8
  %t135 = alloca { i64, [1 x i64] }, align 8
  %t158 = alloca { i64, [1 x i64] }, align 8
  %t184 = alloca { i64, [21 x i64] }, align 8
  %t228 = alloca { i64, [4 x i64] }, align 8
  %t304 = alloca { i64, [4 x i64] }, align 8
  %t387 = alloca { i64, [2 x i64] }, align 8
  %t394 = alloca { i64, [7 x i64] }, align 8
  %t457 = alloca { i64, [8 x i64] }, align 8
  %t484 = alloca { i64, [4 x i64] }, align 8
  %t490 = alloca { i64, [8 x i64] }, align 8
  %t512 = alloca { i64, [4 x i64] }, align 8
  %t515 = alloca { i64, [8 x i64] }, align 8
  %t534 = alloca { i64, [4 x i64] }, align 8
  %t541 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Body", ptr %t9, i32 0, i32 4
  %t12 = load %"compiler/source:Span", ptr %t11
  store %"compiler/source:Span" %t12, ptr %l5
  %t14 = load ptr, ptr %l4, !tbaa !29
  store ptr %t14, ptr %l35, !tbaa !29
  %t15 = load ptr, ptr %l4, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/lower:lowering", ptr %t16, i32 0, i32 3
  %t19 = getelementptr %"compiler/mir:Fn", ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t15, i32 %t20)
  store i32 %t23, ptr %l39
  br label %bb1
bb1:
  %t24 = load ptr, ptr %l35, !tbaa !29
  %t25 = load i32, ptr %l39, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t24, i32 %t25)
  store { i64, ptr } %t26, ptr %l40
  br label %bb2
bb2:
  %t27 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t27, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t28 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  store i64 %t30, ptr %l8, !tbaa !24
  br label %bb3
bb3:
  %t32 = load i64, ptr %l7, !tbaa !24
  %t33 = load i64, ptr %l8, !tbaa !24
  %t36 = icmp slt i64 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb4, label %bb5
bb4:
  br label %bb9
bb5:
  br label %bb6
bb6:
  %t40 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t40, ptr %l47, !tbaa !27
  %t41 = load i64, ptr %l7, !tbaa !24
  %t43 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr i32, ptr %t44, i64 %t41
  %t46 = load i32, ptr %t45, !tbaa !33
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/lower:lowering", ptr %t48, i32 0, i32 3
  %t51 = load %"compiler/source:Span", ptr %l5
  %t56 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddParam(ptr %v0, ptr %t50, i32 0, %"compiler/source:Span" %t51, i32 %t46)
  store i32 %t56, ptr %l54
  br label %bb7
bb7:
  br label %bb8
bb8:
  %t57 = load i64, ptr %l7, !tbaa !24
  %t59 = add i64 %t57, 1
  store i64 %t59, ptr %l7, !tbaa !24
  br label %bb3
bb9:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/lower:lowering", ptr %t61, i32 0, i32 3
  store ptr %t63, ptr %l58, !tbaa !29
  %t64 = load %"compiler/source:Span", ptr %l5
  %t65 = load i32, ptr %l3, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t66
  %t67 = getelementptr { i64, [1 x i64] }, ptr %t66, i32 0, i32 0
  store i64 3, ptr %t67
  %t68 = load { i64, [1 x i64] }, ptr %t66
  %t73 = call %"compiler/mir:Local" @compiler_2fmir_3aLocal_2ector(ptr %s0, i32 0, %"compiler/source:Span" %t64, i32 %t65, i32 1, { i64, [1 x i64] } %t68)
  store %"compiler/mir:Local" %t73, ptr %l63
  br label %bb10
bb10:
  %t74 = load ptr, ptr %l58, !tbaa !29
  %t75 = load %"compiler/mir:Local", ptr %l63
  %t76 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddLocal(ptr %v0, ptr %t74, %"compiler/mir:Local" %t75)
  store i32 %t76, ptr %l64
  br label %bb11
bb11:
  %t77 = load i32, ptr %l64, !tbaa !23
  store i32 %t77, ptr %l10, !tbaa !23
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/lower:lowering", ptr %t78, i32 0, i32 3
  %t81 = getelementptr %"compiler/mir:Fn", ptr %t80, i32 0, i32 5
  %t82 = load i32, ptr %l10, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2ePush_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t81, i32 %t82)
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t85 = load ptr, ptr %l4, !tbaa !29
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/lower:lowering", ptr %t86, i32 0, i32 3
  %t89 = getelementptr %"compiler/mir:Fn", ptr %t88, i32 0, i32 1
  %t90 = load i32, ptr %t89, !tbaa !23
  %t93 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %s4, ptr %t85, i32 %t90)
  store { i64, ptr } %t93, ptr %l71
  br label %bb13
bb13:
  %t94 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 0
  %t96 = extractvalue { i64, ptr } %t94, 1
  %t97 = mul i64 %t95, 8
  %t98 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t97)
  call void @llvm.memcpy.p0.p0.i64(ptr %t98, ptr %t96, i64 %t97, i1 false)
  %t99 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  store { i64, ptr } %t100, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t102 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t102, 0
  store i64 %t104, ptr %l13, !tbaa !24
  br label %bb14
bb14:
  %t106 = load i64, ptr %l12, !tbaa !24
  %t107 = load i64, ptr %l13, !tbaa !24
  %t110 = icmp slt i64 %t106, %t107
  %t112 = xor i1 %t110, true
  br i1 %t112, label %bb15, label %bb16
bb15:
  br label %bb23
bb16:
  br label %bb17
bb17:
  %t114 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t114, ptr %l79, !tbaa !27
  %t115 = load i64, ptr %l12, !tbaa !24
  %t117 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !27
  %t119 = getelementptr i64, ptr %t118, i64 %t115
  %t120 = load i64, ptr %t119, !tbaa !34
  store i64 %t120, ptr %l14, !tbaa !24
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/lower:lowering", ptr %t122, i32 0, i32 3
  %t125 = getelementptr %"compiler/mir:Fn", ptr %t124, i32 0, i32 6
  store ptr %t125, ptr %l83, !tbaa !29
  %t126 = load i64, ptr %l14, !tbaa !24
  %t128 = icmp slt i64 %t126, 0
  br i1 %t128, label %bb18, label %bb19
bb18:
  store { i64, [1 x i64] } zeroinitializer, ptr %t130
  %t131 = getelementptr { i64, [1 x i64] }, ptr %t130, i32 0, i32 0
  store i64 1, ptr %t131
  %t132 = load { i64, [1 x i64] }, ptr %t130
  store { i64, [1 x i64] } %t132, ptr %l86
  br label %bb20
bb19:
  %t134 = load i64, ptr %l14, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t135
  %t136 = getelementptr { i64, [1 x i64] }, ptr %t135, i32 0, i32 0
  store i64 0, ptr %t136
  %t138 = insertvalue { i64 } undef, i64 %t134, 0
  %t139 = getelementptr { i64, [1 x i64] }, ptr %t135, i32 0, i32 1
  store { i64 } %t138, ptr %t139
  %t140 = load { i64, [1 x i64] }, ptr %t135
  store { i64, [1 x i64] } %t140, ptr %l86
  br label %bb20
bb20:
  %t142 = load ptr, ptr %l83, !tbaa !29
  %t143 = load { i64, [1 x i64] }, ptr %l86
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2ePush_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %t142, { i64, [1 x i64] } %t143)
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t144 = load i64, ptr %l12, !tbaa !24
  %t146 = add i64 %t144, 1
  store i64 %t146, ptr %l12, !tbaa !24
  br label %bb14
bb23:
  call void @__olang_scope_close(ptr %s4)
  %t148 = load ptr, ptr %l4, !tbaa !29
  %t149 = load i32, ptr %l3, !tbaa !23
  %t152 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t148, i32 %t149)
  store i1 %t152, ptr %l94
  br label %bb24
bb24:
  %t153 = load i1, ptr %l94, !tbaa !21
  br i1 %t153, label %bb25, label %bb26
bb25:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/lower:lowering", ptr %t154, i32 0, i32 3
  %t157 = getelementptr %"compiler/mir:Fn", ptr %t156, i32 0, i32 6
  store { i64, [1 x i64] } zeroinitializer, ptr %t158
  %t159 = getelementptr { i64, [1 x i64] }, ptr %t158, i32 0, i32 0
  store i64 4, ptr %t159
  %t160 = insertvalue { i64 } undef, i64 0, 0
  %t161 = getelementptr { i64, [1 x i64] }, ptr %t158, i32 0, i32 1
  store { i64 } %t160, ptr %t161
  %t162 = load { i64, [1 x i64] }, ptr %t158
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2ePush_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %t157, { i64, [1 x i64] } %t162)
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb28
bb28:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/lower:lowering", ptr %t165, i32 0, i32 3
  %t169 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t167)
  store i32 %t169, ptr %l100
  br label %bb29
bb29:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/lower:lowering", ptr %t170, i32 0, i32 3
  %t173 = load i32, ptr @G_2ecompiler_2fmir_2eNoScope, !tbaa !23
  %t174 = load %"compiler/source:Span", ptr %l5
  %t179 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddScope(ptr %v0, ptr %t172, i32 0, i32 %t173, i32 -1, %"compiler/source:Span" %t174, i32 0)
  store i32 %t179, ptr %l106
  br label %bb30
bb30:
  %t180 = load i32, ptr %l106, !tbaa !23
  store i32 %t180, ptr %l15, !tbaa !23
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load %"compiler/source:Span", ptr %l5
  %t183 = load i32, ptr %l15, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t184
  %t185 = getelementptr { i64, [21 x i64] }, ptr %t184, i32 0, i32 0
  store i64 3, ptr %t185
  %t187 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t182, 0
  %t189 = insertvalue { %"compiler/source:Span", i32 } %t187, i32 %t183, 1
  %t190 = getelementptr { i64, [21 x i64] }, ptr %t184, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t189, ptr %t190
  %t191 = load { i64, [21 x i64] }, ptr %t184
  %t193 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t191, ptr %t193
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t181, ptr %t193)
  br label %bb31
bb31:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/lower:lowering", ptr %t196, i32 0, i32 9
  store ptr %t198, ptr %l113, !tbaa !29
  %t199 = load i32, ptr %l15, !tbaa !23
  %t202 = call %"compiler/lower:level" @compiler_2flower_3alevel_2ector(ptr %s0, i32 %t199, i32 -1, i32 0)
  store %"compiler/lower:level" %t202, ptr %l116
  br label %bb32
bb32:
  %t203 = load ptr, ptr %l113, !tbaa !29
  %t204 = load %"compiler/lower:level", ptr %l116
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2ePush_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t203, %"compiler/lower:level" %t204)
  br label %bb33
bb33:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/lower:lowering", ptr %t205, i32 0, i32 3
  %t208 = getelementptr %"compiler/mir:Fn", ptr %t207, i32 0, i32 4
  %t210 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t208)
  store i64 %t210, ptr %l119
  br label %bb34
bb34:
  %t211 = load i64, ptr %l119, !tbaa !24
  %t212 = add i64 %t211, 1
  store i64 %t212, ptr %l120, !tbaa !24
  %t213 = load i64, ptr %l120, !tbaa !24
  %t214 = icmp sge i64 %t213, 0
  br i1 %t214, label %bb35, label %bb36
bb35:
  %t216 = load i64, ptr %l120, !tbaa !24
  %t217 = icmp sle i64 %t216, 230584300921369395
  br i1 %t217, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @olang_loc_f03a362eaee136d1_c4ccf5bb34eed07d)
  unreachable
bb37:
  %t219 = load i64, ptr %l120, !tbaa !24
  %t220 = mul i64 %t219, 40
  %t221 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t220)
  %t222 = insertvalue { i64, ptr } undef, i64 %t219, 0
  %t223 = insertvalue { i64, ptr } %t222, ptr %t221, 1
  store { i64, ptr } %t223, ptr %l16, !tbaa !27
  %t225 = load i32, ptr %l10, !tbaa !23
  %t227 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t225)
  store %"compiler/mir:Lvalue" %t227, ptr %l125
  br label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_f03a362eaee136d1_c4ccf5bb34eed07d)
  unreachable
bb39:
  store { i64, [4 x i64] } zeroinitializer, ptr %t228
  %t229 = getelementptr { i64, [4 x i64] }, ptr %t228, i32 0, i32 0
  store i64 1, ptr %t229
  %t230 = load %"compiler/mir:Lvalue", ptr %l125
  %t231 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t230, 0
  %t232 = getelementptr { i64, [4 x i64] }, ptr %t228, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t231, ptr %t232
  %t233 = load { i64, [4 x i64] }, ptr %t228
  %t235 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t236 = load ptr, ptr %t235, !tbaa !27
  %t237 = getelementptr { i64, [4 x i64] }, ptr %t236, i64 0
  store { i64, [4 x i64] } %t233, ptr %t237
  store i64 0, ptr %l17, !tbaa !24
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = getelementptr %"compiler/lower:lowering", ptr %t238, i32 0, i32 3
  %t241 = getelementptr %"compiler/mir:Fn", ptr %t240, i32 0, i32 4
  %t243 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t241)
  store i64 %t243, ptr %l129
  br label %bb40
bb40:
  %t244 = load i64, ptr %l129, !tbaa !24
  store i64 %t244, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t245 = load i64, ptr %l18, !tbaa !24
  %t246 = load i64, ptr %l17, !tbaa !24
  %t249 = icmp sgt i64 %t245, %t246
  br i1 %t249, label %bb41, label %bb42
bb41:
  %t251 = load i64, ptr %l19, !tbaa !24
  %t253 = icmp sgt i64 %t251, 0
  br i1 %t253, label %bb43, label %bb44
bb42:
  store i64 0, ptr %l133, !tbaa !24
  br label %bb46
bb43:
  %t255 = load i64, ptr %l18, !tbaa !24
  %t256 = load i64, ptr %l17, !tbaa !24
  %t259 = sub i64 %t255, %t256
  %t260 = load i64, ptr %l19, !tbaa !24
  %t263 = add i64 %t259, %t260
  %t265 = sub i64 %t263, 1
  %t266 = load i64, ptr %l19, !tbaa !24
  %t269 = sdiv i64 %t265, %t266
  store i64 %t269, ptr %l136, !tbaa !24
  br label %bb45
bb44:
  store i64 0, ptr %l136, !tbaa !24
  br label %bb45
bb45:
  %t271 = load i64, ptr %l136, !tbaa !24
  store i64 %t271, ptr %l133, !tbaa !24
  br label %bb46
bb46:
  %t272 = load i64, ptr %l133, !tbaa !24
  store i64 %t272, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb47
bb47:
  %t273 = load i64, ptr %l21, !tbaa !24
  %t274 = load i64, ptr %l20, !tbaa !24
  %t277 = icmp slt i64 %t273, %t274
  %t279 = xor i1 %t277, true
  br i1 %t279, label %bb48, label %bb49
bb48:
  br label %bb54
bb49:
  br label %bb50
bb50:
  %t281 = load i64, ptr %l17, !tbaa !24
  %t282 = load i64, ptr %l21, !tbaa !24
  %t283 = load i64, ptr %l19, !tbaa !24
  %t286 = mul i64 %t282, %t283
  %t289 = add i64 %t281, %t286
  store i64 %t289, ptr %l22, !tbaa !24
  %t291 = load i64, ptr %l22, !tbaa !24
  %t293 = add i64 %t291, 1
  store i64 %t293, ptr %l155, !tbaa !24
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t296 = getelementptr %"compiler/lower:lowering", ptr %t294, i32 0, i32 3
  %t297 = getelementptr %"compiler/mir:Fn", ptr %t296, i32 0, i32 4
  %t298 = load i64, ptr %l22, !tbaa !24
  %t301 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t297, i64 %t298)
  store i32 %t301, ptr %l159
  br label %bb51
bb51:
  %t302 = load i32, ptr %l159, !tbaa !23
  %t303 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t302)
  store %"compiler/mir:Lvalue" %t303, ptr %l160
  br label %bb52
bb52:
  store { i64, [4 x i64] } zeroinitializer, ptr %t304
  %t305 = getelementptr { i64, [4 x i64] }, ptr %t304, i32 0, i32 0
  store i64 1, ptr %t305
  %t306 = load %"compiler/mir:Lvalue", ptr %l160
  %t307 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t306, 0
  %t308 = getelementptr { i64, [4 x i64] }, ptr %t304, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t307, ptr %t308
  %t309 = load { i64, [4 x i64] }, ptr %t304
  %t311 = load i64, ptr %l155, !tbaa !24
  %t312 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t313 = load ptr, ptr %t312, !tbaa !27
  %t314 = getelementptr { i64, [4 x i64] }, ptr %t313, i64 %t311
  store { i64, [4 x i64] } %t309, ptr %t314
  br label %bb53
bb53:
  %t315 = load i64, ptr %l21, !tbaa !24
  %t317 = add i64 %t315, 1
  store i64 %t317, ptr %l21, !tbaa !24
  br label %bb47
bb54:
  %t319 = load ptr, ptr %l4, !tbaa !29
  %t320 = load i32, ptr %l2, !tbaa !23
  %t323 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t319, i32 %t320)
  store i32 %t323, ptr %l166
  br label %bb55
bb55:
  %t324 = load i32, ptr %l166, !tbaa !23
  store i32 %t324, ptr %l23, !tbaa !23
  %t325 = load ptr, ptr %l0, !tbaa !29
  %t327 = getelementptr %"compiler/lower:lowering", ptr %t325, i32 0, i32 3
  %t329 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t327)
  store i32 %t329, ptr %l169
  br label %bb56
bb56:
  %t330 = load i32, ptr %l169, !tbaa !23
  store i32 %t330, ptr %l24, !tbaa !23
  %t331 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  store i32 %t331, ptr %l25, !tbaa !23
  %t333 = load i32, ptr %l23, !tbaa !23
  %t334 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t337 = icmp ne i32 %t333, %t334
  br i1 %t337, label %bb57, label %bb58
bb57:
  %t339 = load i32, ptr %l23, !tbaa !23
  %t340 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t343 = icmp ne i32 %t339, %t340
  store i1 %t343, ptr %l174, !tbaa !21
  br label %bb59
bb58:
  store i1 false, ptr %l174, !tbaa !21
  br label %bb59
bb59:
  %t345 = load i1, ptr %l174, !tbaa !21
  br i1 %t345, label %bb60, label %bb61
bb60:
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t347 = load i32, ptr %l23, !tbaa !23
  %t348 = load %"compiler/source:Span", ptr %l5
  %t352 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t346, i32 %t347, %"compiler/source:Span" %t348)
  store i32 %t352, ptr %l181
  br label %bb62
bb61:
  br label %bb63
bb62:
  %t353 = load i32, ptr %l181, !tbaa !23
  store i32 %t353, ptr %l25, !tbaa !23
  br label %bb63
bb63:
  %t354 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  store i32 %t354, ptr %l26, !tbaa !23
  %t356 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  store i32 %t356, ptr %l27, !tbaa !23
  %t358 = load ptr, ptr %l4, !tbaa !29
  store ptr %t358, ptr %l184, !tbaa !29
  %t359 = load ptr, ptr %l4, !tbaa !29
  %t360 = load i32, ptr %l2, !tbaa !23
  %t363 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t359, i32 %t360)
  store i32 %t363, ptr %l187
  br label %bb64
bb64:
  %t364 = load ptr, ptr %l184, !tbaa !29
  %t365 = load i32, ptr %l187, !tbaa !23
  %t366 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t364, i32 %t365)
  store { i64, ptr } %t366, ptr %l188
  br label %bb65
bb65:
  %t367 = load { i64, ptr }, ptr %l188, !tbaa !27
  %t368 = extractvalue { i64, ptr } %t367, 0
  %t370 = icmp sgt i64 %t368, 0
  br i1 %t370, label %bb66, label %bb67
bb66:
  %t372 = load ptr, ptr %l0, !tbaa !29
  %t373 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t374 = load %"compiler/source:Span", ptr %l5
  %t378 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t372, i32 %t373, %"compiler/source:Span" %t374)
  store i32 %t378, ptr %l194
  br label %bb68
bb67:
  br label %bb70
bb68:
  %t379 = load i32, ptr %l194, !tbaa !23
  store i32 %t379, ptr %l26, !tbaa !23
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t382 = getelementptr %"compiler/lower:lowering", ptr %t380, i32 0, i32 3
  %t384 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t382)
  store i32 %t384, ptr %l197
  br label %bb69
bb69:
  %t385 = load i32, ptr %l197, !tbaa !23
  store i32 %t385, ptr %l27, !tbaa !23
  br label %bb70
bb70:
  store { i64, [2 x i64] } zeroinitializer, ptr %t387
  %t388 = getelementptr { i64, [2 x i64] }, ptr %t387, i32 0, i32 0
  store i64 0, ptr %t388
  %t390 = insertvalue { i32 } undef, i32 %a1, 0
  %t391 = getelementptr { i64, [2 x i64] }, ptr %t387, i32 0, i32 1
  store { i32 } %t390, ptr %t391
  %t392 = load { i64, [2 x i64] }, ptr %t387
  %t393 = load i32, ptr %l2, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t394
  %t395 = getelementptr { i64, [7 x i64] }, ptr %t394, i32 0, i32 0
  store i64 0, ptr %t395
  %t397 = insertvalue { { i64, [2 x i64] }, i32 } undef, { i64, [2 x i64] } %t392, 0
  %t399 = insertvalue { { i64, [2 x i64] }, i32 } %t397, i32 %t393, 1
  %t400 = getelementptr { i64, [7 x i64] }, ptr %t394, i32 0, i32 1
  store { { i64, [2 x i64] }, i32 } %t399, ptr %t400
  %t401 = load { i64, [7 x i64] }, ptr %t394
  %t403 = load ptr, ptr %l0, !tbaa !29
  %t405 = getelementptr %"compiler/lower:lowering", ptr %t403, i32 0, i32 3
  store ptr %t405, ptr %l203, !tbaa !29
  store { i64, [7 x i64] } %t401, ptr %l204
  %t407 = load ptr, ptr %l0, !tbaa !29
  %t409 = getelementptr %"compiler/lower:lowering", ptr %t407, i32 0, i32 3
  %t410 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t413 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %s0, ptr %t409, { i64, ptr } %t410)
  store %"compiler/mir:Range" %t413, ptr %l208
  br label %bb71
bb71:
  %t414 = load ptr, ptr %l0, !tbaa !29
  %t415 = load i32, ptr %l2, !tbaa !23
  %t416 = load i32, ptr %l3, !tbaa !23
  %t420 = call %"compiler/mir:Range" @compiler_2flower_2ecompiler_2flower_3alowering_2eadapterPassed(ptr %v0, ptr %t414, i32 %t415, i32 %t416)
  store %"compiler/mir:Range" %t420, ptr %l212
  br label %bb72
bb72:
  %t421 = load i32, ptr %l25, !tbaa !23
  %t422 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t425 = icmp ne i32 %t421, %t422
  br i1 %t425, label %bb73, label %bb74
bb73:
  %t427 = load i32, ptr %l25, !tbaa !23
  %t429 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t427)
  store %"compiler/mir:Lvalue" %t429, ptr %l218
  br label %bb75
bb74:
  %t430 = load %"compiler/mir:Lvalue", ptr @G_2ecompiler_2fmir_2eNoPlace
  store %"compiler/mir:Lvalue" %t430, ptr %l216
  br label %bb76
bb75:
  %t432 = load %"compiler/mir:Lvalue", ptr %l218
  store %"compiler/mir:Lvalue" %t432, ptr %l216
  br label %bb76
bb76:
  %t433 = load i32, ptr %l25, !tbaa !23
  %t434 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t437 = icmp ne i32 %t433, %t434
  %t438 = load i32, ptr %l24, !tbaa !23
  %t439 = load i32, ptr %l26, !tbaa !23
  %t440 = load i32, ptr %l27, !tbaa !23
  %t441 = load { i64, [7 x i64] }, ptr %l204
  %t442 = load %"compiler/mir:Range", ptr %l208
  %t443 = load %"compiler/mir:Range", ptr %l212
  %t444 = load %"compiler/mir:Lvalue", ptr %l216
  %t449 = call %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %s0, { i64, [7 x i64] } %t441, %"compiler/mir:Range" %t442, %"compiler/mir:Range" %t443, %"compiler/mir:Lvalue" %t444, i1 %t437, i32 %t438, i32 %t439, i32 %t440)
  store %"compiler/mir:Call" %t449, ptr %l226
  br label %bb77
bb77:
  %t450 = load ptr, ptr %l203, !tbaa !29
  %t451 = load %"compiler/mir:Call", ptr %l226
  %t452 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v0, ptr %t450, %"compiler/mir:Call" %t451)
  store i32 %t452, ptr %l227
  br label %bb78
bb78:
  %t453 = load i32, ptr %l227, !tbaa !23
  %t454 = load ptr, ptr %l0, !tbaa !29
  %t455 = load %"compiler/source:Span", ptr %l5
  store { i64, [8 x i64] } zeroinitializer, ptr %t457
  %t458 = getelementptr { i64, [8 x i64] }, ptr %t457, i32 0, i32 0
  store i64 4, ptr %t458
  %t460 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t455, 0
  %t462 = insertvalue { %"compiler/source:Span", i32 } %t460, i32 %t453, 1
  %t463 = getelementptr { i64, [8 x i64] }, ptr %t457, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t462, ptr %t463
  %t464 = load { i64, [8 x i64] }, ptr %t457
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t454, { i64, [8 x i64] } %t464)
  br label %bb79
bb79:
  %t467 = load i32, ptr %l27, !tbaa !23
  %t468 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t471 = icmp ne i32 %t467, %t468
  br i1 %t471, label %bb80, label %bb81
bb80:
  %t473 = load ptr, ptr %l0, !tbaa !29
  %t474 = load i32, ptr %l27, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t473, i32 %t474)
  br label %bb82
bb81:
  br label %bb86
bb82:
  %t477 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleave(ptr %v0, ptr %t477, i64 0)
  br label %bb83
bb83:
  %t479 = load ptr, ptr %l0, !tbaa !29
  store ptr %t479, ptr %l238, !tbaa !29
  %t480 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t480, ptr %l239
  %t481 = load i32, ptr %l26, !tbaa !23
  %t483 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t481)
  store %"compiler/mir:Lvalue" %t483, ptr %l241
  br label %bb84
bb84:
  store { i64, [4 x i64] } zeroinitializer, ptr %t484
  %t485 = getelementptr { i64, [4 x i64] }, ptr %t484, i32 0, i32 0
  store i64 1, ptr %t485
  %t486 = load %"compiler/mir:Lvalue", ptr %l241
  %t487 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t486, 0
  %t488 = getelementptr { i64, [4 x i64] }, ptr %t484, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t487, ptr %t488
  %t489 = load { i64, [4 x i64] }, ptr %t484
  store { i64, [8 x i64] } zeroinitializer, ptr %t490
  %t491 = getelementptr { i64, [8 x i64] }, ptr %t490, i32 0, i32 0
  store i64 7, ptr %t491
  %t492 = load %"compiler/source:Span", ptr %l239
  %t493 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t492, 0
  %t495 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t493, { i64, [4 x i64] } %t489, 1
  %t496 = getelementptr { i64, [8 x i64] }, ptr %t490, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t495, ptr %t496
  %t497 = load { i64, [8 x i64] }, ptr %t490
  %t498 = load ptr, ptr %l238, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t498, { i64, [8 x i64] } %t497)
  br label %bb85
bb85:
  br label %bb86
bb86:
  %t500 = load ptr, ptr %l0, !tbaa !29
  %t501 = load i32, ptr %l24, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t500, i32 %t501)
  br label %bb87
bb87:
  %t504 = load i32, ptr %l23, !tbaa !23
  %t505 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t508 = icmp eq i32 %t504, %t505
  br i1 %t508, label %bb88, label %bb89
bb88:
  %t510 = load ptr, ptr %l0, !tbaa !29
  %t511 = load %"compiler/source:Span", ptr %l5
  store { i64, [4 x i64] } zeroinitializer, ptr %t512
  %t513 = getelementptr { i64, [4 x i64] }, ptr %t512, i32 0, i32 0
  store i64 0, ptr %t513
  %t514 = load { i64, [4 x i64] }, ptr %t512
  store { i64, [8 x i64] } zeroinitializer, ptr %t515
  %t516 = getelementptr { i64, [8 x i64] }, ptr %t515, i32 0, i32 0
  store i64 9, ptr %t516
  %t518 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t511, 0
  %t520 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t518, i32 3, 1
  %t522 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t520, { i64, [4 x i64] } %t514, 2
  %t523 = getelementptr { i64, [8 x i64] }, ptr %t515, i32 0, i32 1
  store { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t522, ptr %t523
  %t524 = load { i64, [8 x i64] }, ptr %t515
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t510, { i64, [8 x i64] } %t524)
  br label %bb90
bb89:
  br label %bb91
bb90:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb91:
  %t527 = load ptr, ptr %l0, !tbaa !29
  store ptr %t527, ptr %l254, !tbaa !29
  %t528 = load i32, ptr %l25, !tbaa !23
  %t529 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t532 = icmp eq i32 %t528, %t529
  br i1 %t532, label %bb92, label %bb93
bb92:
  store { i64, [4 x i64] } zeroinitializer, ptr %t534
  %t535 = getelementptr { i64, [4 x i64] }, ptr %t534, i32 0, i32 0
  store i64 0, ptr %t535
  %t536 = load { i64, [4 x i64] }, ptr %t534
  store { i64, [4 x i64] } %t536, ptr %l258
  br label %bb95
bb93:
  %t538 = load i32, ptr %l25, !tbaa !23
  %t540 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t538)
  store %"compiler/mir:Lvalue" %t540, ptr %l261
  br label %bb94
bb94:
  store { i64, [4 x i64] } zeroinitializer, ptr %t541
  %t542 = getelementptr { i64, [4 x i64] }, ptr %t541, i32 0, i32 0
  store i64 1, ptr %t542
  %t543 = load %"compiler/mir:Lvalue", ptr %l261
  %t544 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t543, 0
  %t545 = getelementptr { i64, [4 x i64] }, ptr %t541, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t544, ptr %t545
  %t546 = load { i64, [4 x i64] }, ptr %t541
  store { i64, [4 x i64] } %t546, ptr %l258
  br label %bb95
bb95:
  %t548 = load ptr, ptr %l254, !tbaa !29
  %t549 = load { i64, [4 x i64] }, ptr %l258
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eepilogue(ptr %v0, ptr %t548, { i64, [4 x i64] } %t549)
  br label %bb96
bb96:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/mir:Range" @compiler_2flower_2ecompiler_2flower_3alowering_2eadapterPassed(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l25 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l31 = alloca i64
  %l40 = alloca i64
  %l43 = alloca i64
  %l67 = alloca i1
  %l70 = alloca i1
  %l77 = alloca i64
  %l86 = alloca i64
  %l89 = alloca i64
  %l121 = alloca %"compiler/mir:Range"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/mir:Range"
  %t88 = alloca { i64, [1 x i64] }, align 8
  %t118 = alloca { i64, [1 x i64] }, align 8
  %t203 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t6, i32 %a1)
  store { i64, ptr } %t10, ptr %l25
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/lower:lowering", ptr %t13, i32 0, i32 3
  %t16 = getelementptr %"compiler/mir:Fn", ptr %t15, i32 0, i32 1
  %t17 = load i32, ptr %t16, !tbaa !23
  %t20 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t12, i32 %t17)
  store { i64, ptr } %t20, ptr %l29
  br label %bb2
bb2:
  %t21 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t21, ptr %l5, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  store i64 %t24, ptr %l31, !tbaa !24
  %t25 = load i64, ptr %l31, !tbaa !24
  %t26 = icmp sge i64 %t25, 0
  br i1 %t26, label %bb3, label %bb4
bb3:
  %t28 = load i64, ptr %l31, !tbaa !24
  %t29 = icmp sle i64 %t28, 576460752303423487
  br i1 %t29, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_8a5ba3d76fdc22ed_b870bfe3eff73029)
  unreachable
bb5:
  %t31 = load i64, ptr %l31, !tbaa !24
  %t32 = mul i64 %t31, 16
  %t33 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t32)
  %t34 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t33, 1
  store { i64, ptr } %t35, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t37 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  store i64 %t39, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l8, !tbaa !24
  %t42 = load i64, ptr %l7, !tbaa !24
  %t45 = icmp sgt i64 %t41, %t42
  br i1 %t45, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_8a5ba3d76fdc22ed_b870bfe3eff73029)
  unreachable
bb7:
  %t47 = load i64, ptr %l9, !tbaa !24
  %t49 = icmp sgt i64 %t47, 0
  br i1 %t49, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb12
bb9:
  %t51 = load i64, ptr %l8, !tbaa !24
  %t52 = load i64, ptr %l7, !tbaa !24
  %t55 = sub i64 %t51, %t52
  %t56 = load i64, ptr %l9, !tbaa !24
  %t59 = add i64 %t55, %t56
  %t61 = sub i64 %t59, 1
  %t62 = load i64, ptr %l9, !tbaa !24
  %t65 = sdiv i64 %t61, %t62
  store i64 %t65, ptr %l43, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb11
bb11:
  %t67 = load i64, ptr %l43, !tbaa !24
  store i64 %t67, ptr %l40, !tbaa !24
  br label %bb12
bb12:
  %t68 = load i64, ptr %l40, !tbaa !24
  store i64 %t68, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb13
bb13:
  %t69 = load i64, ptr %l11, !tbaa !24
  %t70 = load i64, ptr %l10, !tbaa !24
  %t73 = icmp slt i64 %t69, %t70
  %t75 = xor i1 %t73, true
  br i1 %t75, label %bb14, label %bb15
bb14:
  br label %bb43
bb15:
  br label %bb16
bb16:
  %t77 = load i64, ptr %l7, !tbaa !24
  %t78 = load i64, ptr %l11, !tbaa !24
  %t79 = load i64, ptr %l9, !tbaa !24
  %t82 = mul i64 %t78, %t79
  %t85 = add i64 %t77, %t82
  store i64 %t85, ptr %l12, !tbaa !24
  %t87 = load i64, ptr %l12, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t88
  %t89 = getelementptr { i64, [1 x i64] }, ptr %t88, i32 0, i32 0
  store i64 2, ptr %t89
  %t90 = load { i64, [1 x i64] }, ptr %t88
  %t93 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr { i64, [1 x i64] }, ptr %t94, i64 %t87
  store { i64, [1 x i64] } %t90, ptr %t95
  %t96 = load i64, ptr %l12, !tbaa !24
  %t98 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr i64, ptr %t99, i64 %t96
  %t101 = load i64, ptr %t100, !tbaa !34
  store i64 %t101, ptr %l13, !tbaa !24
  %t103 = load i64, ptr %l13, !tbaa !24
  %t105 = icmp eq i64 %t103, 0
  br i1 %t105, label %bb17, label %bb18
bb17:
  %t107 = load ptr, ptr %l3, !tbaa !29
  %t111 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t107, i32 %a2)
  store i1 %t111, ptr %l70
  br label %bb19
bb18:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb20
bb19:
  %t112 = load i1, ptr %l70, !tbaa !21
  store i1 %t112, ptr %l67, !tbaa !21
  br label %bb20
bb20:
  %t113 = load i1, ptr %l67, !tbaa !21
  br i1 %t113, label %bb21, label %bb22
bb21:
  %t114 = load i64, ptr %l12, !tbaa !24
  %t115 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t115, 0
  store { i64, [1 x i64] } zeroinitializer, ptr %t118
  %t119 = getelementptr { i64, [1 x i64] }, ptr %t118, i32 0, i32 0
  store i64 1, ptr %t119
  %t121 = insertvalue { i64 } undef, i64 %t117, 0
  %t122 = getelementptr { i64, [1 x i64] }, ptr %t118, i32 0, i32 1
  store { i64 } %t121, ptr %t122
  %t123 = load { i64, [1 x i64] }, ptr %t118
  %t126 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr { i64, [1 x i64] }, ptr %t127, i64 %t114
  store { i64, [1 x i64] } %t123, ptr %t128
  br label %bb42
bb22:
  br label %bb23
bb23:
  %t129 = load i64, ptr %l13, !tbaa !24
  %t131 = icmp sgt i64 %t129, 0
  br i1 %t131, label %bb24, label %bb25
bb24:
  %t133 = load i64, ptr %l13, !tbaa !24
  %t135 = sub i64 %t133, 1
  store i64 %t135, ptr %l77, !tbaa !24
  br label %bb26
bb25:
  %t137 = load i64, ptr %l13, !tbaa !24
  store i64 %t137, ptr %l77, !tbaa !24
  br label %bb26
bb26:
  %t139 = load i64, ptr %l77, !tbaa !24
  store i64 %t139, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t140, 0
  store i64 %t142, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t144 = load i64, ptr %l16, !tbaa !24
  %t145 = load i64, ptr %l15, !tbaa !24
  %t148 = icmp sgt i64 %t144, %t145
  br i1 %t148, label %bb27, label %bb28
bb27:
  %t150 = load i64, ptr %l17, !tbaa !24
  %t152 = icmp sgt i64 %t150, 0
  br i1 %t152, label %bb29, label %bb30
bb28:
  store i64 0, ptr %l86, !tbaa !24
  br label %bb32
bb29:
  %t154 = load i64, ptr %l16, !tbaa !24
  %t155 = load i64, ptr %l15, !tbaa !24
  %t158 = sub i64 %t154, %t155
  %t159 = load i64, ptr %l17, !tbaa !24
  %t162 = add i64 %t158, %t159
  %t164 = sub i64 %t162, 1
  %t165 = load i64, ptr %l17, !tbaa !24
  %t168 = sdiv i64 %t164, %t165
  store i64 %t168, ptr %l89, !tbaa !24
  br label %bb31
bb30:
  store i64 0, ptr %l89, !tbaa !24
  br label %bb31
bb31:
  %t170 = load i64, ptr %l89, !tbaa !24
  store i64 %t170, ptr %l86, !tbaa !24
  br label %bb32
bb32:
  %t171 = load i64, ptr %l86, !tbaa !24
  store i64 %t171, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb33
bb33:
  %t172 = load i64, ptr %l19, !tbaa !24
  %t173 = load i64, ptr %l18, !tbaa !24
  %t176 = icmp slt i64 %t172, %t173
  %t178 = xor i1 %t176, true
  br i1 %t178, label %bb34, label %bb35
bb34:
  br label %bb41
bb35:
  br label %bb36
bb36:
  %t180 = load i64, ptr %l15, !tbaa !24
  %t181 = load i64, ptr %l19, !tbaa !24
  %t182 = load i64, ptr %l17, !tbaa !24
  %t185 = mul i64 %t181, %t182
  %t188 = add i64 %t180, %t185
  store i64 %t188, ptr %l20, !tbaa !24
  %t190 = load i64, ptr %l20, !tbaa !24
  %t192 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t194 = getelementptr i64, ptr %t193, i64 %t190
  %t195 = load i64, ptr %t194, !tbaa !34
  %t196 = load i64, ptr %l14, !tbaa !24
  %t199 = icmp eq i64 %t195, %t196
  br i1 %t199, label %bb37, label %bb38
bb37:
  %t201 = load i64, ptr %l12, !tbaa !24
  %t202 = load i64, ptr %l20, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t203
  %t204 = getelementptr { i64, [1 x i64] }, ptr %t203, i32 0, i32 0
  store i64 1, ptr %t204
  %t206 = insertvalue { i64 } undef, i64 %t202, 0
  %t207 = getelementptr { i64, [1 x i64] }, ptr %t203, i32 0, i32 1
  store { i64 } %t206, ptr %t207
  %t208 = load { i64, [1 x i64] }, ptr %t203
  %t211 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t212 = load ptr, ptr %t211, !tbaa !27
  %t213 = getelementptr { i64, [1 x i64] }, ptr %t212, i64 %t201
  store { i64, [1 x i64] } %t208, ptr %t213
  br label %bb39
bb38:
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t214 = load i64, ptr %l19, !tbaa !24
  %t216 = add i64 %t214, 1
  store i64 %t216, ptr %l19, !tbaa !24
  br label %bb33
bb41:
  br label %bb42
bb42:
  %t218 = load i64, ptr %l11, !tbaa !24
  %t220 = add i64 %t218, 1
  store i64 %t220, ptr %l11, !tbaa !24
  br label %bb13
bb43:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/lower:lowering", ptr %t222, i32 0, i32 3
  %t225 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t228 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eScopeRefs(ptr %v0, ptr %s0, ptr %t224, { i64, ptr } %t225)
  store %"compiler/mir:Range" %t228, ptr %l121
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s0)
  %t229 = load %"compiler/mir:Range", ptr %l121
  store %"compiler/mir:Range" %t229, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Range", ptr %rv
  ret %"compiler/mir:Range" %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eassert(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca { i64, [4 x i64] }
  %l10 = alloca ptr
  %l17 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l18 = alloca i1
  %l22 = alloca { i64, [4 x i64] }
  %l27 = alloca i32
  %l30 = alloca i32
  %l45 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  %t55 = alloca { i64, [8 x i64] }, align 8
  %t71 = alloca { i64, [4 x i64] }, align 8
  %t91 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/lower:Lowerer", ptr %t4, i32 0, i32 7
  store ptr %t6, ptr %l10, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/lower:lowering", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Body", ptr %t10, i32 0, i32 0
  %t13 = load i32, ptr %t12, !tbaa !23
  %t15 = sext i32 %t13 to i64
  %t16 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t17 = load i32, ptr %t16, !tbaa !23
  %t19 = sext i32 %t17 to i64
  %t22 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t15, i64 %t19)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t22, ptr %l17
  br label %bb1
bb1:
  %t23 = load ptr, ptr %l10, !tbaa !29
  %t24 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l17
  %t25 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t23, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t24)
  store i1 %t25, ptr %l18
  br label %bb2
bb2:
  %t26 = load i1, ptr %l18, !tbaa !21
  br i1 %t26, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  br label %bb5
bb5:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t32 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t27, ptr %a2)
  store { i64, [4 x i64] } %t32, ptr %l22
  br label %bb6
bb6:
  %t33 = load { i64, [4 x i64] }, ptr %l22
  store { i64, [4 x i64] } %t33, ptr %l4
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/lower:lowering", ptr %t34, i32 0, i32 7
  %t37 = load i1, ptr %t36, !tbaa !21
  br i1 %t37, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb8:
  br label %bb9
bb9:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/lower:lowering", ptr %t39, i32 0, i32 3
  %t43 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t41)
  store i32 %t43, ptr %l27
  br label %bb10
bb10:
  %t44 = load i32, ptr %l27, !tbaa !23
  store i32 %t44, ptr %l5, !tbaa !23
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/lower:lowering", ptr %t45, i32 0, i32 3
  %t49 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t47)
  store i32 %t49, ptr %l30
  br label %bb11
bb11:
  %t50 = load i32, ptr %l30, !tbaa !23
  store i32 %t50, ptr %l6, !tbaa !23
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load { i64, [4 x i64] }, ptr %l4
  %t53 = load i32, ptr %l5, !tbaa !23
  %t54 = load i32, ptr %l6, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t55
  %t56 = getelementptr { i64, [8 x i64] }, ptr %t55, i32 0, i32 0
  store i64 2, ptr %t56
  %t58 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t52, 0
  %t60 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t58, i32 %t53, 1
  %t62 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t60, i32 %t54, 2
  %t63 = getelementptr { i64, [8 x i64] }, ptr %t55, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t62, ptr %t63
  %t64 = load { i64, [8 x i64] }, ptr %t55
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t51, { i64, [8 x i64] } %t64)
  br label %bb12
bb12:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t67, i32 %t68)
  br label %bb13
bb13:
  store { i64, [4 x i64] } zeroinitializer, ptr %t71
  %t72 = getelementptr { i64, [4 x i64] }, ptr %t71, i32 0, i32 0
  store i64 0, ptr %t72
  %t73 = load { i64, [4 x i64] }, ptr %t71
  store { i64, [4 x i64] } %t73, ptr %l7
  %t75 = load ptr, ptr %l3, !tbaa !29
  %t77 = icmp eq ptr %t75, null
  %t79 = xor i1 %t77, true
  br i1 %t79, label %bb14, label %bb15
bb14:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load ptr, ptr %l3, !tbaa !29
  %t86 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v2, ptr %t81, ptr %t82)
  store { i64, [4 x i64] } %t86, ptr %l45
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t87 = load { i64, [4 x i64] }, ptr %l45
  store { i64, [4 x i64] } %t87, ptr %l7
  br label %bb17
bb17:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load %"compiler/source:Span", ptr %l1
  %t90 = load { i64, [4 x i64] }, ptr %l7
  store { i64, [8 x i64] } zeroinitializer, ptr %t91
  %t92 = getelementptr { i64, [8 x i64] }, ptr %t91, i32 0, i32 0
  store i64 9, ptr %t92
  %t94 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t89, 0
  %t96 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t94, i32 6, 1
  %t98 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t96, { i64, [4 x i64] } %t90, 2
  %t99 = getelementptr { i64, [8 x i64] }, ptr %t91, i32 0, i32 1
  store { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t98, ptr %t99
  %t100 = load { i64, [8 x i64] }, ptr %t91
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t88, { i64, [8 x i64] } %t100)
  br label %bb18
bb18:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load i32, ptr %l5, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t103, i32 %t104)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eat(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l5 = alloca %"compiler/lower:pl"
  %l7 = alloca %"compiler/lower:pl"
  %rv = alloca %"compiler/lower:pl"
  %t3 = alloca { i64, [2 x i64] }, align 8
  %t11 = alloca { i64, [1 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t3
  %t4 = getelementptr { i64, [2 x i64] }, ptr %t3, i32 0, i32 0
  store i64 1, ptr %t4
  %t6 = insertvalue { i32 } undef, i32 %a1, 0
  %t7 = getelementptr { i64, [2 x i64] }, ptr %t3, i32 0, i32 1
  store { i32 } %t6, ptr %t7
  %t8 = load { i64, [2 x i64] }, ptr %t3
  %t10 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %v1, { i64, [2 x i64] } %t8)
  store %"compiler/lower:pl" %t10, ptr %l5
  br label %bb1
bb1:
  store { i64, [1 x i64] } zeroinitializer, ptr %t11
  %t12 = getelementptr { i64, [1 x i64] }, ptr %t11, i32 0, i32 0
  store i64 3, ptr %t12
  %t13 = load { i64, [1 x i64] }, ptr %t11
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t15 = load %"compiler/lower:pl", ptr %l5
  %t17 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %v1, ptr %v1, ptr %t14, %"compiler/lower:pl" %t15, { i64, [1 x i64] } %t13)
  store %"compiler/lower:pl" %t17, ptr %l7
  br label %bb2
bb2:
  %t18 = load %"compiler/lower:pl", ptr %l7
  store %"compiler/lower:pl" %t18, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:pl", ptr %rv
  ret %"compiler/lower:pl" %rr
}

define dso_local { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2ebangNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l27 = alloca { i64, ptr }
  %l28 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l35 = alloca i64
  %l38 = alloca i64
  %l57 = alloca { i64, ptr }
  %l60 = alloca i32
  %l63 = alloca i32
  %l69 = alloca i32
  %l72 = alloca i64
  %l79 = alloca ptr
  %l89 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l100 = alloca i64
  %l103 = alloca i64
  %l129 = alloca ptr
  %l130 = alloca ptr
  %l131 = alloca { i64, ptr }
  %l133 = alloca ptr
  %l136 = alloca i32
  %l137 = alloca { i64, ptr }
  %l140 = alloca { i64, ptr }
  %l143 = alloca { i64, ptr }
  %l147 = alloca { i64, [4 x i64] }
  %l153 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t216 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t6, i32 %a1)
  store { i64, ptr } %t10, ptr %l27
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %l28
  br label %bb2
bb2:
  %t13 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l28
  %t14 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %t14
  store ptr %t14, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  store i64 %t18, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t20 = load i64, ptr %l7, !tbaa !24
  %t21 = load i64, ptr %l6, !tbaa !24
  %t24 = icmp sgt i64 %t20, %t21
  br i1 %t24, label %bb3, label %bb4
bb3:
  %t26 = load i64, ptr %l8, !tbaa !24
  %t28 = icmp sgt i64 %t26, 0
  br i1 %t28, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb8
bb5:
  %t30 = load i64, ptr %l7, !tbaa !24
  %t31 = load i64, ptr %l6, !tbaa !24
  %t34 = sub i64 %t30, %t31
  %t35 = load i64, ptr %l8, !tbaa !24
  %t38 = add i64 %t34, %t35
  %t40 = sub i64 %t38, 1
  %t41 = load i64, ptr %l8, !tbaa !24
  %t44 = sdiv i64 %t40, %t41
  store i64 %t44, ptr %l38, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l38, !tbaa !24
  br label %bb7
bb7:
  %t46 = load i64, ptr %l38, !tbaa !24
  store i64 %t46, ptr %l35, !tbaa !24
  br label %bb8
bb8:
  %t47 = load i64, ptr %l35, !tbaa !24
  store i64 %t47, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t48 = load i64, ptr %l10, !tbaa !24
  %t49 = load i64, ptr %l9, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb42
bb11:
  br label %bb12
bb12:
  %t56 = load i64, ptr %l6, !tbaa !24
  %t57 = load i64, ptr %l10, !tbaa !24
  %t58 = load i64, ptr %l8, !tbaa !24
  %t61 = mul i64 %t57, %t58
  %t64 = add i64 %t56, %t61
  store i64 %t64, ptr %l11, !tbaa !24
  %t66 = load ptr, ptr %l3, !tbaa !29
  %t67 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t67, ptr %l57, !tbaa !27
  %t68 = load i64, ptr %l11, !tbaa !24
  %t70 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr i32, ptr %t71, i64 %t68
  %t73 = load i32, ptr %t72, !tbaa !33
  %t76 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t66, i32 %t73)
  store i32 %t76, ptr %l60
  br label %bb13
bb13:
  %t77 = load i32, ptr %l60, !tbaa !23
  store i32 %t77, ptr %l12, !tbaa !23
  %t78 = load ptr, ptr %l3, !tbaa !29
  %t79 = load i32, ptr %l12, !tbaa !23
  %t82 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t78, i32 %t79)
  store i32 %t82, ptr %l63
  br label %bb14
bb14:
  %t83 = load i32, ptr %l63
  %t85 = trunc i64 18 to i32
  %t86 = icmp eq i32 %t83, %t85
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb41
bb16:
  br label %bb17
bb17:
  %t90 = load ptr, ptr %l3, !tbaa !29
  %t91 = load i32, ptr %l12, !tbaa !23
  %t94 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t90, i32 %t91)
  store i32 %t94, ptr %l69
  br label %bb18
bb18:
  %t95 = load i32, ptr %l69, !tbaa !23
  store i32 %t95, ptr %l13, !tbaa !23
  %t96 = load ptr, ptr %l3, !tbaa !29
  %t97 = load i32, ptr %l13, !tbaa !23
  %t100 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t96, i32 %t97)
  store i64 %t100, ptr %l72
  br label %bb19
bb19:
  %t101 = load i64, ptr %l72, !tbaa !24
  store i64 %t101, ptr %l14, !tbaa !24
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/lower:lowering", ptr %t102, i32 0, i32 0
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t107 = getelementptr %"compiler/lower:Lowerer", ptr %t105, i32 0, i32 0
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t110 = getelementptr %"compiler/generic:Program", ptr %t108, i32 0, i32 0
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = getelementptr %"compiler/load:Loader", ptr %t111, i32 0, i32 5
  %t114 = load i64, ptr %l14, !tbaa !24
  %t117 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t113, i64 %t114)
  store ptr %t117, ptr %l79
  br label %bb20
bb20:
  %t118 = load ptr, ptr %l79, !tbaa !29
  %t120 = getelementptr %"compiler/load:Module", ptr %t118, i32 0, i32 2
  %t121 = load { i64, ptr }, ptr %t120, !tbaa !27
  %t122 = load i64, ptr %l14, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/lower:lowering", ptr %t123, i32 0, i32 0
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t128 = getelementptr %"compiler/lower:Lowerer", ptr %t126, i32 0, i32 0
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = getelementptr %"compiler/generic:Program", ptr %t129, i32 0, i32 0
  %t132 = load ptr, ptr %t131, !tbaa !29
  %t134 = getelementptr %"compiler/load:Loader", ptr %t132, i32 0, i32 7
  %t135 = load i64, ptr %t134, !tbaa !24
  %t138 = icmp eq i64 %t122, %t135
  %t141 = call { i64, ptr } @compiler_2fload_2eErrQualifier(ptr %v0, ptr %s2, { i64, ptr } %t121, i1 %t138)
  store { i64, ptr } %t141, ptr %l89
  br label %bb21
bb21:
  %t142 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t142, ptr %l15, !tbaa !27
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/lower:lowering", ptr %t143, i32 0, i32 0
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t148 = getelementptr %"compiler/lower:Lowerer", ptr %t146, i32 0, i32 0
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t150 = load i32, ptr %l13, !tbaa !23
  %t153 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %t149, i32 %t150)
  store { i64, ptr } %t153, ptr %l94
  br label %bb22
bb22:
  %t154 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t154, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t155 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t157 = extractvalue { i64, ptr } %t155, 0
  store i64 %t157, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t159 = load i64, ptr %l18, !tbaa !24
  %t160 = load i64, ptr %l17, !tbaa !24
  %t163 = icmp sgt i64 %t159, %t160
  br i1 %t163, label %bb23, label %bb24
bb23:
  %t165 = load i64, ptr %l19, !tbaa !24
  %t167 = icmp sgt i64 %t165, 0
  br i1 %t167, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l100, !tbaa !24
  br label %bb28
bb25:
  %t169 = load i64, ptr %l18, !tbaa !24
  %t170 = load i64, ptr %l17, !tbaa !24
  %t173 = sub i64 %t169, %t170
  %t174 = load i64, ptr %l19, !tbaa !24
  %t177 = add i64 %t173, %t174
  %t179 = sub i64 %t177, 1
  %t180 = load i64, ptr %l19, !tbaa !24
  %t183 = sdiv i64 %t179, %t180
  store i64 %t183, ptr %l103, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l103, !tbaa !24
  br label %bb27
bb27:
  %t185 = load i64, ptr %l103, !tbaa !24
  store i64 %t185, ptr %l100, !tbaa !24
  br label %bb28
bb28:
  %t186 = load i64, ptr %l100, !tbaa !24
  store i64 %t186, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s5
  %t187 = load i64, ptr %l21, !tbaa !24
  %t188 = load i64, ptr %l20, !tbaa !24
  %t191 = icmp slt i64 %t187, %t188
  %t193 = xor i1 %t191, true
  br i1 %t193, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb40
bb31:
  br label %bb32
bb32:
  %t195 = load i64, ptr %l17, !tbaa !24
  %t196 = load i64, ptr %l21, !tbaa !24
  %t197 = load i64, ptr %l19, !tbaa !24
  %t200 = mul i64 %t196, %t197
  %t203 = add i64 %t195, %t200
  store i64 %t203, ptr %l22, !tbaa !24
  %t205 = load ptr, ptr %l5, !tbaa !29
  %t206 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t207 = load i64, ptr %l11, !tbaa !24
  %t209 = add i64 %t207, 1
  %t211 = shl i64 %t209, 16
  %t212 = load i64, ptr %l22, !tbaa !24
  %t215 = or i64 %t211, %t212
  store { i64, [4 x i64] } zeroinitializer, ptr %t216
  %t217 = getelementptr { i64, [4 x i64] }, ptr %t216, i32 0, i32 0
  store i64 2, ptr %t217
  %t219 = insertvalue { i32, i64 } undef, i32 %t206, 0
  %t221 = insertvalue { i32, i64 } %t219, i64 %t215, 1
  %t222 = getelementptr { i64, [4 x i64] }, ptr %t216, i32 0, i32 1
  store { i32, i64 } %t221, ptr %t222
  %t223 = load { i64, [4 x i64] }, ptr %t216
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2ePush_3ccompiler_2fmir_3aOperand_3e(ptr %s0, ptr %t205, { i64, [4 x i64] } %t223)
  br label %bb33
bb33:
  %t226 = load ptr, ptr %l5, !tbaa !29
  store ptr %t226, ptr %l129, !tbaa !29
  %t227 = load ptr, ptr %l0, !tbaa !29
  store ptr %t227, ptr %l130, !tbaa !29
  %t228 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t228, ptr %l131, !tbaa !27
  %t229 = load ptr, ptr %l3, !tbaa !29
  %t231 = getelementptr %"compiler/types:Table", ptr %t229, i32 0, i32 0
  %t232 = load ptr, ptr %t231, !tbaa !29
  store ptr %t232, ptr %l133, !tbaa !29
  %t233 = load ptr, ptr %l3, !tbaa !29
  %t234 = load i32, ptr %l13, !tbaa !23
  %t237 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t233, i32 %t234)
  store i32 %t237, ptr %l136
  br label %bb34
bb34:
  %t238 = load ptr, ptr %l133, !tbaa !29
  %t239 = load i32, ptr %l136, !tbaa !23
  %t240 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t238, i32 %t239)
  store { i64, ptr } %t240, ptr %l137
  br label %bb35
bb35:
  %t241 = load ptr, ptr %l3, !tbaa !29
  %t243 = getelementptr %"compiler/types:Table", ptr %t241, i32 0, i32 0
  %t244 = load ptr, ptr %t243, !tbaa !29
  %t245 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t245, ptr %l140, !tbaa !27
  %t246 = load i64, ptr %l22, !tbaa !24
  %t248 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t249 = load ptr, ptr %t248, !tbaa !27
  %t250 = getelementptr i32, ptr %t249, i64 %t246
  %t251 = load i32, ptr %t250, !tbaa !33
  %t254 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t244, i32 %t251)
  store { i64, ptr } %t254, ptr %l143
  br label %bb36
bb36:
  %t255 = load { i64, ptr }, ptr %l131, !tbaa !27
  %t256 = extractvalue { i64, ptr } %t255, 1
  %t257 = extractvalue { i64, ptr } %t255, 0
  %t258 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t259 = extractvalue { i64, ptr } %t258, 1
  %t260 = extractvalue { i64, ptr } %t258, 0
  %t261 = add i64 %t257, %t260
  %t262 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t263 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t264 = add i64 %t261, %t263
  %t265 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t266 = extractvalue { i64, ptr } %t265, 1
  %t267 = extractvalue { i64, ptr } %t265, 0
  %t268 = add i64 %t264, %t267
  %t269 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t268)
  call void @olang_textcopy(ptr %t269, ptr %t256, i64 %t257)
  %t270 = getelementptr i8, ptr %t269, i64 %t257
  call void @olang_textcopy(ptr %t270, ptr %t259, i64 %t260)
  %t271 = getelementptr i8, ptr %t270, i64 %t260
  call void @olang_textcopy(ptr %t271, ptr %t262, i64 %t263)
  %t272 = getelementptr i8, ptr %t271, i64 %t263
  call void @olang_textcopy(ptr %t272, ptr %t266, i64 %t267)
  %t273 = insertvalue { i64, ptr } undef, i64 %t268, 0
  %t274 = insertvalue { i64, ptr } %t273, ptr %t269, 1
  %t276 = extractvalue { i64, ptr } %t274, 0
  %t277 = extractvalue { i64, ptr } %t274, 1
  %t278 = mul i64 %t276, 1
  %t279 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t278)
  call void @llvm.memcpy.p0.p0.i64(ptr %t279, ptr %t277, i64 %t278, i1 false)
  %t280 = insertvalue { i64, ptr } undef, i64 %t276, 0
  %t281 = insertvalue { i64, ptr } %t280, ptr %t279, 1
  %t283 = load ptr, ptr %l130, !tbaa !29
  %t286 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2etextData(ptr %v0, ptr %s5, ptr %t283, { i64, ptr } %t281, %"compiler/source:Span" %a2)
  store { i64, [4 x i64] } %t286, ptr %l147
  br label %bb37
bb37:
  %t287 = load ptr, ptr %l129, !tbaa !29
  %t288 = load { i64, [4 x i64] }, ptr %l147
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2ePush_3ccompiler_2fmir_3aOperand_3e(ptr %s0, ptr %t287, { i64, [4 x i64] } %t288)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s5)
  br label %bb39
bb39:
  %t289 = load i64, ptr %l21, !tbaa !24
  %t291 = add i64 %t289, 1
  store i64 %t291, ptr %l21, !tbaa !24
  br label %bb29
bb40:
  call void @__olang_scope_close(ptr %s2)
  br label %bb41
bb41:
  %t293 = load i64, ptr %l10, !tbaa !24
  %t295 = add i64 %t293, 1
  store i64 %t295, ptr %l10, !tbaa !24
  br label %bb9
bb42:
  %t297 = load ptr, ptr %l5, !tbaa !29
  %t299 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eToArray_3ccompiler_2fmir_3aOperand_3e(ptr %s0, ptr %v1, ptr %t297)
  store { i64, ptr } %t299, ptr %l153
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s0)
  %t300 = load { i64, ptr }, ptr %l153, !tbaa !27
  store { i64, ptr } %t300, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2echeck(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, i32 %a3, i64 %a4, %"compiler/source:Span" %a5) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca { i32, i64 }
  %l13 = alloca i1
  %l18 = alloca i32
  %l21 = alloca i32
  %l39 = alloca { i32, i64 }
  %l42 = alloca ptr
  %l45 = alloca { i64, [4 x i64] }
  %l49 = alloca i32
  %t28 = alloca { i64, [8 x i64] }, align 8
  %t52 = alloca { i64, [4 x i64] }, align 8
  %t55 = alloca { i64, [8 x i64] }, align 8
  %t85 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 7
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l2
  %t8 = trunc i64 0 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l13, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l13, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lower:lowering", ptr %t12, i32 0, i32 3
  %t16 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t14)
  store i32 %t16, ptr %l18
  br label %bb7
bb7:
  %t17 = load i32, ptr %l18, !tbaa !23
  store i32 %t17, ptr %l6, !tbaa !23
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/lower:lowering", ptr %t18, i32 0, i32 3
  %t22 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t20)
  store i32 %t22, ptr %l21
  br label %bb8
bb8:
  %t23 = load i32, ptr %l21, !tbaa !23
  store i32 %t23, ptr %l7, !tbaa !23
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i32, ptr %l6, !tbaa !23
  %t27 = load i32, ptr %l7, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t28
  %t29 = getelementptr { i64, [8 x i64] }, ptr %t28, i32 0, i32 0
  store i64 2, ptr %t29
  %t31 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %a1, 0
  %t33 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t31, i32 %t26, 1
  %t35 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t33, i32 %t27, 2
  %t36 = getelementptr { i64, [8 x i64] }, ptr %t28, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t35, ptr %t36
  %t37 = load { i64, [8 x i64] }, ptr %t28
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t24, { i64, [8 x i64] } %t37)
  br label %bb9
bb9:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l7, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t40, i32 %t41)
  br label %bb10
bb10:
  %t44 = load i32, ptr %l2
  %t46 = trunc i64 1 to i32
  %t47 = icmp eq i32 %t44, %t46
  br i1 %t47, label %bb11, label %bb12
bb11:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load %"compiler/source:Span", ptr %l5
  store { i64, [4 x i64] } zeroinitializer, ptr %t52
  %t53 = getelementptr { i64, [4 x i64] }, ptr %t52, i32 0, i32 0
  store i64 0, ptr %t53
  %t54 = load { i64, [4 x i64] }, ptr %t52
  store { i64, [8 x i64] } zeroinitializer, ptr %t55
  %t56 = getelementptr { i64, [8 x i64] }, ptr %t55, i32 0, i32 0
  store i64 9, ptr %t56
  %t58 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t50, 0
  %t60 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t58, i32 %a3, 1
  %t62 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t60, { i64, [4 x i64] } %t54, 2
  %t63 = getelementptr { i64, [8 x i64] }, ptr %t55, i32 0, i32 1
  store { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t62, ptr %t63
  %t64 = load { i64, [8 x i64] }, ptr %t55
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t49, { i64, [8 x i64] } %t64)
  br label %bb13
bb12:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/lower:lowering", ptr %t67, i32 0, i32 0
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t74 = call { i32, i64 } @compiler_2flower_2ecompiler_2flower_3aLowerer_2efailure(ptr %v0, ptr %t70, i64 %a4)
  store { i32, i64 } %t74, ptr %l39
  br label %bb14
bb13:
  br label %bb17
bb14:
  %t75 = load { i32, i64 }, ptr %l39
  store { i32, i64 } %t75, ptr %l8
  %t76 = getelementptr { i32, i64 }, ptr %l8, i32 0, i32 0
  %t77 = load i32, ptr %t76, !tbaa !23
  %t79 = getelementptr { i32, i64 }, ptr %l8, i32 0, i32 1
  %t80 = load i64, ptr %t79, !tbaa !24
  %t82 = load ptr, ptr %l0, !tbaa !29
  store ptr %t82, ptr %l42, !tbaa !29
  %t83 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t85
  %t86 = getelementptr { i64, [4 x i64] }, ptr %t85, i32 0, i32 0
  store i64 2, ptr %t86
  %t88 = insertvalue { i32, i64 } undef, i32 %t83, 0
  %t90 = insertvalue { i32, i64 } %t88, i64 %t80, 1
  %t91 = getelementptr { i64, [4 x i64] }, ptr %t85, i32 0, i32 1
  store { i32, i64 } %t90, ptr %t91
  %t92 = load { i64, [4 x i64] }, ptr %t85
  store { i64, [4 x i64] } %t92, ptr %l45
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/lower:lowering", ptr %t93, i32 0, i32 2
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t100 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %t96, i32 %t77)
  store i32 %t100, ptr %l49
  br label %bb15
bb15:
  %t101 = load %"compiler/source:Span", ptr %l5
  %t102 = load ptr, ptr %l42, !tbaa !29
  %t103 = load { i64, [4 x i64] }, ptr %l45
  %t104 = load i32, ptr %l49, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2edispatch(ptr %v0, ptr %t102, { i64, [4 x i64] } %t103, i32 %t104, %"compiler/source:Span" %t101, i1 true)
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t106, i32 %t107)
  br label %bb18
bb18:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ecleanup(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l11 = alloca i32
  %l14 = alloca i32
  %l28 = alloca ptr
  %l32 = alloca ptr
  %s0 = alloca %olang.scope
  %t24 = alloca { i64, [21 x i64] }, align 8
  %t73 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 7
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 11
  %t9 = load i64, ptr %l2, !tbaa !24
  %t12 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t8, i64 %t9)
  store i32 %t12, ptr %l11
  br label %bb4
bb4:
  %t13 = load i32, ptr %l11, !tbaa !23
  store i32 %t13, ptr %l3, !tbaa !23
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/lower:lowering", ptr %t14, i32 0, i32 3
  %t18 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t16)
  store i32 %t18, ptr %l14
  br label %bb5
bb5:
  %t19 = load i32, ptr %l14, !tbaa !23
  store i32 %t19, ptr %l4, !tbaa !23
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load %"compiler/source:Span", ptr %l1
  %t22 = load i32, ptr %l3, !tbaa !23
  %t23 = load i32, ptr %l4, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t24
  %t25 = getelementptr { i64, [21 x i64] }, ptr %t24, i32 0, i32 0
  store i64 13, ptr %t25
  %t27 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t21, 0
  %t29 = insertvalue { %"compiler/source:Span", i32, i32 } %t27, i32 %t22, 1
  %t31 = insertvalue { %"compiler/source:Span", i32, i32 } %t29, i32 %t23, 2
  %t32 = getelementptr { i64, [21 x i64] }, ptr %t24, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t31, ptr %t32
  %t33 = load { i64, [21 x i64] }, ptr %t24
  %t35 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t33, ptr %t35
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t20, ptr %t35)
  br label %bb6
bb6:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/lower:lowering", ptr %t38, i32 0, i32 6
  %t41 = load i32, ptr %t40, !tbaa !23
  store i32 %t41, ptr %l5, !tbaa !23
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t43, i32 %t44)
  br label %bb7
bb7:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/lower:lowering", ptr %t47, i32 0, i32 11
  %t50 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eSetAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t49, i64 %t50, i32 -1)
  br label %bb8
bb8:
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l28, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/lower:lowering", ptr %t54, i32 0, i32 10
  %t57 = load i64, ptr %l2, !tbaa !24
  %t60 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlock_26_3e_2eAt_3ccompiler_2ftyped_3aBlock_26_3e(ptr %v0, ptr %v0, ptr %t56, i64 %t57)
  store ptr %t60, ptr %l32
  br label %bb9
bb9:
  %t61 = load ptr, ptr %l28, !tbaa !29
  %t62 = load ptr, ptr %l32, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eblock(ptr %v0, ptr %v0, ptr %t61, ptr %t62)
  br label %bb10
bb10:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/lower:lowering", ptr %t63, i32 0, i32 11
  %t66 = load i64, ptr %l2, !tbaa !24
  %t67 = load i32, ptr %l3, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eSetAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t65, i64 %t66, i32 %t67)
  br label %bb11
bb11:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load %"compiler/source:Span", ptr %l1
  store { i64, [8 x i64] } zeroinitializer, ptr %t73
  %t74 = getelementptr { i64, [8 x i64] }, ptr %t73, i32 0, i32 0
  store i64 10, ptr %t74
  %t76 = insertvalue { %"compiler/source:Span" } undef, %"compiler/source:Span" %t72, 0
  %t77 = getelementptr { i64, [8 x i64] }, ptr %t73, i32 0, i32 1
  store { %"compiler/source:Span" } %t76, ptr %t77
  %t78 = load { i64, [8 x i64] }, ptr %t73
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t71, { i64, [8 x i64] } %t78)
  br label %bb12
bb12:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load i32, ptr %l5, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t81, i32 %t82)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ecombine(ptr %v0, ptr %a0, i32 %a1, { i64, [4 x i64] } %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l9 = alloca %"compiler/mir:Lvalue"
  %l10 = alloca { i64, [4 x i64] }
  %l12 = alloca { i64, [4 x i64] }
  %l13 = alloca { i64, ptr }
  %l15 = alloca { i64, [4 x i64] }
  %l16 = alloca ptr
  %l17 = alloca %"compiler/source:Span"
  %l19 = alloca %"compiler/mir:Lvalue"
  %l20 = alloca i32
  %l21 = alloca i32
  %l26 = alloca { i64, ptr }
  %l27 = alloca %"compiler/mir:Range"
  %s0 = alloca %olang.scope
  %t6 = alloca { i64, [4 x i64] }, align 8
  %t61 = alloca { i64, [15 x i64] }, align 8
  %t71 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i32 5, ptr %l6
  %t2 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t2, ptr %l7, !tbaa !23
  %t3 = load i32, ptr %l1, !tbaa !23
  %t5 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t3)
  store %"compiler/mir:Lvalue" %t5, ptr %l9
  br label %bb1
bb1:
  store { i64, [4 x i64] } zeroinitializer, ptr %t6
  %t7 = getelementptr { i64, [4 x i64] }, ptr %t6, i32 0, i32 0
  store i64 1, ptr %t7
  %t8 = load %"compiler/mir:Lvalue", ptr %l9
  %t9 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t8, 0
  %t10 = getelementptr { i64, [4 x i64] }, ptr %t6, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t9, ptr %t10
  %t11 = load { i64, [4 x i64] }, ptr %t6
  store { i64, [4 x i64] } %t11, ptr %l10
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t12, i64 1099511628211)
  store { i64, [4 x i64] } %t14, ptr %l12
  br label %bb2
bb2:
  %t15 = mul i64 2, 40
  %t16 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 2, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l13, !tbaa !27
  %t19 = load { i64, [4 x i64] }, ptr %l10
  %t20 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr { i64, [4 x i64] }, ptr %t21, i64 0
  store { i64, [4 x i64] } %t19, ptr %t22
  %t23 = load { i64, [4 x i64] }, ptr %l12
  %t24 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, [4 x i64] }, ptr %t25, i64 1
  store { i64, [4 x i64] } %t23, ptr %t26
  %t27 = load %"compiler/source:Span", ptr %l3
  %t28 = load ptr, ptr %l5, !tbaa !29
  %t29 = load i32, ptr %l6
  %t30 = load i32, ptr %l7, !tbaa !23
  %t31 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t33 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %t28, i32 %t29, i32 %t30, { i64, ptr } %t31, %"compiler/source:Span" %t27)
  store { i64, [4 x i64] } %t33, ptr %l15
  br label %bb3
bb3:
  %t34 = load { i64, [4 x i64] }, ptr %l15
  store { i64, [4 x i64] } %t34, ptr %l4
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l16, !tbaa !29
  %t36 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t36, ptr %l17
  %t37 = load i32, ptr %l1, !tbaa !23
  %t39 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t37)
  store %"compiler/mir:Lvalue" %t39, ptr %l19
  br label %bb4
bb4:
  store i32 3, ptr %l20
  %t40 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t40, ptr %l21, !tbaa !23
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/lower:lowering", ptr %t41, i32 0, i32 3
  %t44 = load { i64, [4 x i64] }, ptr %l4
  %t46 = mul i64 2, 40
  %t47 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t46)
  %t48 = insertvalue { i64, ptr } undef, i64 2, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  store { i64, ptr } %t49, ptr %l26, !tbaa !27
  %t51 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr { i64, [4 x i64] }, ptr %t52, i64 0
  store { i64, [4 x i64] } %t44, ptr %t53
  %t55 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr { i64, [4 x i64] }, ptr %t56, i64 1
  store { i64, [4 x i64] } %a2, ptr %t57
  %t59 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t60 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %s0, ptr %t43, { i64, ptr } %t59)
  store %"compiler/mir:Range" %t60, ptr %l27
  br label %bb5
bb5:
  store { i64, [15 x i64] } zeroinitializer, ptr %t61
  %t62 = getelementptr { i64, [15 x i64] }, ptr %t61, i32 0, i32 0
  store i64 3, ptr %t62
  %t63 = load i32, ptr %l20
  %t64 = insertvalue { i32, i32, %"compiler/mir:Range" } undef, i32 %t63, 0
  %t65 = load i32, ptr %l21, !tbaa !23
  %t66 = insertvalue { i32, i32, %"compiler/mir:Range" } %t64, i32 %t65, 1
  %t67 = load %"compiler/mir:Range", ptr %l27
  %t68 = insertvalue { i32, i32, %"compiler/mir:Range" } %t66, %"compiler/mir:Range" %t67, 2
  %t69 = getelementptr { i64, [15 x i64] }, ptr %t61, i32 0, i32 1
  store { i32, i32, %"compiler/mir:Range" } %t68, ptr %t69
  %t70 = load { i64, [15 x i64] }, ptr %t61
  store { i64, [21 x i64] } zeroinitializer, ptr %t71
  %t72 = getelementptr { i64, [21 x i64] }, ptr %t71, i32 0, i32 0
  store i64 0, ptr %t72
  %t73 = load %"compiler/source:Span", ptr %l17
  %t74 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t73, 0
  %t75 = load %"compiler/mir:Lvalue", ptr %l19
  %t76 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t74, %"compiler/mir:Lvalue" %t75, 1
  %t78 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t76, { i64, [15 x i64] } %t70, 2
  %t79 = getelementptr { i64, [21 x i64] }, ptr %t71, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t78, ptr %t79
  %t80 = load { i64, [21 x i64] }, ptr %t71
  %t82 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t80, ptr %t82
  %t83 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t83, ptr %t82)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %rv = alloca { i64, [4 x i64] }
  %t3 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t3
  %t4 = getelementptr { i64, [4 x i64] }, ptr %t3, i32 0, i32 0
  store i64 2, ptr %t4
  %t6 = insertvalue { i32, i64 } undef, i32 %t1, 0
  %t8 = insertvalue { i32, i64 } %t6, i64 %a1, 1
  %t9 = getelementptr { i64, [4 x i64] }, ptr %t3, i32 0, i32 1
  store { i32, i64 } %t8, ptr %t9
  %t10 = load { i64, [4 x i64] }, ptr %t3
  store { i64, [4 x i64] } %t10, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopiesArray(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca i1
  %l10 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2evalueArray(ptr %v0, ptr %t1, i32 %a2)
  store i1 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i1, ptr %l5, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t14 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopiesValue(ptr %v0, ptr %v1, ptr %t10, ptr %a1)
  store i1 %t14, ptr %l10
  br label %bb5
bb5:
  %t15 = load i1, ptr %l10, !tbaa !21
  store i1 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2edepth(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca { i64, [4 x i64] }
  %l6 = alloca { i64, [4 x i64] }
  %rv = alloca { i64, [4 x i64] }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 5
  %t4 = load { i64, [4 x i64] }, ptr %t3
  %t6 = extractvalue { i64, [4 x i64] } %t4, 0
  %t7 = icmp eq i64 %t6, 0
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t9, i64 0)
  store { i64, [4 x i64] } %t11, ptr %l6
  br label %bb3
bb2:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lower:lowering", ptr %t12, i32 0, i32 5
  %t15 = load { i64, [4 x i64] }, ptr %t14
  store { i64, [4 x i64] } %t15, ptr %l4
  br label %bb4
bb3:
  %t17 = load { i64, [4 x i64] }, ptr %l6
  store { i64, [4 x i64] } %t17, ptr %l4
  br label %bb4
bb4:
  %t18 = load { i64, [4 x i64] }, ptr %l4
  store { i64, [4 x i64] } %t18, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ederef(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca { i64, [4 x i64] }
  %l8 = alloca { i64, [4 x i64] }
  %l12 = alloca %"compiler/lower:pl"
  %l13 = alloca ptr
  %l14 = alloca { i64, [4 x i64] }
  %l16 = alloca i32
  %l18 = alloca i32
  %l19 = alloca ptr
  %l22 = alloca %"compiler/lower:pl"
  %l24 = alloca %"compiler/lower:pl"
  %rv = alloca %"compiler/lower:pl"
  %t13 = alloca { i64, [2 x i64] }, align 8
  %t33 = alloca { i64, [2 x i64] }, align 8
  %t41 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t6 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store { i64, [4 x i64] } %t6, ptr %l8
  br label %bb1
bb1:
  %t7 = load { i64, [4 x i64] }, ptr %l8
  store { i64, [4 x i64] } %t7, ptr %l3
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/lower:lowering", ptr %t8, i32 0, i32 7
  %t11 = load i1, ptr %t10, !tbaa !21
  br i1 %t11, label %bb2, label %bb3
bb2:
  store { i64, [2 x i64] } zeroinitializer, ptr %t13
  %t14 = getelementptr { i64, [2 x i64] }, ptr %t13, i32 0, i32 0
  store i64 0, ptr %t14
  %t15 = load { i64, [2 x i64] }, ptr %t13
  %t17 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %v2, { i64, [2 x i64] } %t15)
  store %"compiler/lower:pl" %t17, ptr %l12
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t18 = load %"compiler/lower:pl", ptr %l12
  store %"compiler/lower:pl" %t18, ptr %rv
  br label %ret
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l13, !tbaa !29
  %t20 = load { i64, [4 x i64] }, ptr %l3
  store { i64, [4 x i64] } %t20, ptr %l14
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t21)
  store i32 %t23, ptr %l16
  br label %bb6
bb6:
  %t25 = load ptr, ptr %l13, !tbaa !29
  %t26 = load { i64, [4 x i64] }, ptr %l14
  %t27 = load i32, ptr %l16, !tbaa !23
  %t29 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %t25, { i64, [4 x i64] } %t26, i32 %t27, %"compiler/source:Span" %a2)
  store i32 %t29, ptr %l18
  br label %bb7
bb7:
  %t30 = load i32, ptr %l18, !tbaa !23
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l19, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t33
  %t34 = getelementptr { i64, [2 x i64] }, ptr %t33, i32 0, i32 0
  store i64 1, ptr %t34
  %t36 = insertvalue { i32 } undef, i32 %t30, 0
  %t37 = getelementptr { i64, [2 x i64] }, ptr %t33, i32 0, i32 1
  store { i32 } %t36, ptr %t37
  %t38 = load { i64, [2 x i64] }, ptr %t33
  %t40 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %v2, { i64, [2 x i64] } %t38)
  store %"compiler/lower:pl" %t40, ptr %l22
  br label %bb8
bb8:
  store { i64, [1 x i64] } zeroinitializer, ptr %t41
  %t42 = getelementptr { i64, [1 x i64] }, ptr %t41, i32 0, i32 0
  store i64 3, ptr %t42
  %t43 = load { i64, [1 x i64] }, ptr %t41
  %t44 = load ptr, ptr %l19, !tbaa !29
  %t45 = load %"compiler/lower:pl", ptr %l22
  %t47 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %v2, ptr %v2, ptr %t44, %"compiler/lower:pl" %t45, { i64, [1 x i64] } %t43)
  store %"compiler/lower:pl" %t47, ptr %l24
  br label %bb9
bb9:
  %t48 = load %"compiler/lower:pl", ptr %l24
  store %"compiler/lower:pl" %t48, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:pl", ptr %rv
  ret %"compiler/lower:pl" %rr
}

define dso_local %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eelem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %lp3 = alloca ptr
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca i32
  %l6 = alloca { i64, [4 x i64] }
  %l8 = alloca i64
  %l13 = alloca %"compiler/lower:pl"
  %l18 = alloca { i64, [4 x i64] }
  %l24 = alloca i32
  %l29 = alloca ptr
  %l30 = alloca i32
  %l31 = alloca i32
  %l34 = alloca %"compiler/mir:Lvalue"
  %l36 = alloca { i64, ptr }
  %l38 = alloca { i64, [4 x i64] }
  %l43 = alloca { i64, [4 x i64] }
  %l63 = alloca %"compiler/lower:pl"
  %l64 = alloca ptr
  %l65 = alloca %"compiler/lower:pl"
  %l70 = alloca i32
  %l72 = alloca %"compiler/lower:pl"
  %s2 = alloca %olang.scope
  %rv = alloca %"compiler/lower:pl"
  %t56 = alloca { i64, [4 x i64] }, align 8
  %t127 = alloca { i64, [1 x i64] }, align 8
  %t150 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Elem", ptr %t2, i32 0, i32 0
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t9 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eplace(ptr %v0, ptr %v1, ptr %v2, ptr %t1, ptr %t5)
  store %"compiler/lower:pl" %t9, ptr %l13
  br label %bb1
bb1:
  %t10 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t10, ptr %lp3
  %t11 = load %"compiler/lower:pl", ptr %l13
  %t12 = load ptr, ptr %lp3
  store %"compiler/lower:pl" %t11, ptr %t12
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr %"compiler/typed:Elem", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t21 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t13, ptr %t17)
  store { i64, [4 x i64] } %t21, ptr %l18
  br label %bb2
bb2:
  %t22 = load { i64, [4 x i64] }, ptr %l18
  store { i64, [4 x i64] } %t22, ptr %l4
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/lower:lowering", ptr %t23, i32 0, i32 7
  %t26 = load i1, ptr %t25, !tbaa !21
  br i1 %t26, label %bb3, label %bb4
bb3:
  %t28 = load ptr, ptr %lp3
  %t29 = load %"compiler/lower:pl", ptr %t28
  store %"compiler/lower:pl" %t29, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr %"compiler/typed:Elem", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t34)
  store i32 %t36, ptr %l24
  br label %bb6
bb6:
  %t37 = load i32, ptr %l24, !tbaa !23
  store i32 %t37, ptr %l5, !tbaa !23
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Elem", ptr %t38, i32 0, i32 2
  %t41 = load i32, ptr %t40
  %t43 = trunc i64 0 to i32
  %t44 = icmp eq i32 %t41, %t43
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l29, !tbaa !29
  store i32 22, ptr %l30
  %t49 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t49, ptr %l31, !tbaa !23
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load ptr, ptr %lp3
  %t52 = load %"compiler/lower:pl", ptr %t51
  %t55 = call %"compiler/mir:Lvalue" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v2, ptr %t50, %"compiler/lower:pl" %t52)
  store %"compiler/mir:Lvalue" %t55, ptr %l34
  br label %bb9
bb8:
  br label %bb13
bb9:
  store { i64, [4 x i64] } zeroinitializer, ptr %t56
  %t57 = getelementptr { i64, [4 x i64] }, ptr %t56, i32 0, i32 0
  store i64 1, ptr %t57
  %t58 = load %"compiler/mir:Lvalue", ptr %l34
  %t59 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t58, 0
  %t60 = getelementptr { i64, [4 x i64] }, ptr %t56, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t59, ptr %t60
  %t61 = load { i64, [4 x i64] }, ptr %t56
  %t62 = mul i64 1, 40
  %t63 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t62)
  %t64 = insertvalue { i64, ptr } undef, i64 1, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  store { i64, ptr } %t65, ptr %l36, !tbaa !27
  %t67 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = getelementptr { i64, [4 x i64] }, ptr %t68, i64 0
  store { i64, [4 x i64] } %t61, ptr %t69
  %t70 = load %"compiler/source:Span", ptr %l2
  %t71 = load ptr, ptr %l29, !tbaa !29
  %t72 = load i32, ptr %l30
  %t73 = load i32, ptr %l31, !tbaa !23
  %t74 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t76 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s2, ptr %t71, i32 %t72, i32 %t73, { i64, ptr } %t74, %"compiler/source:Span" %t70)
  store { i64, [4 x i64] } %t76, ptr %l38
  br label %bb10
bb10:
  %t77 = load { i64, [4 x i64] }, ptr %l38
  store { i64, [4 x i64] } %t77, ptr %l6
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load { i64, [4 x i64] }, ptr %l4
  %t80 = load i32, ptr %l5, !tbaa !23
  %t81 = load %"compiler/source:Span", ptr %l2
  %t86 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2easI64(ptr %v0, ptr %t78, { i64, [4 x i64] } %t79, i32 %t80, %"compiler/source:Span" %t81)
  store { i64, [4 x i64] } %t86, ptr %l43
  br label %bb11
bb11:
  %t87 = load { i64, [4 x i64] }, ptr %l43
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = load { i64, [4 x i64] }, ptr %l6
  %t91 = load ptr, ptr %l1, !tbaa !29
  %t93 = getelementptr %"compiler/typed:Elem", ptr %t91, i32 0, i32 2
  %t94 = load i32, ptr %t93
  %t95 = load %"compiler/source:Span", ptr %l2
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ebounds(ptr %v0, ptr %t88, { i64, [4 x i64] } %t87, { i64, [4 x i64] } %t90, i1 false, i32 %t94, i32 7, %"compiler/source:Span" %t95)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  %t102 = load ptr, ptr %l1, !tbaa !29
  %t104 = getelementptr %"compiler/typed:Elem", ptr %t102, i32 0, i32 2
  %t105 = load i32, ptr %t104
  %t107 = trunc i64 0 to i32
  %t108 = icmp eq i32 %t105, %t107
  br i1 %t108, label %bb14, label %bb15
bb14:
  %t110 = load { i64, [4 x i64] }, ptr %l4
  %t112 = extractvalue { i64, [4 x i64] } %t110, 0
  %t113 = icmp eq i64 %t112, 2
  br i1 %t113, label %bb16, label %bb17
bb15:
  br label %bb29
bb16:
  %t115 = getelementptr { i64, [4 x i64] }, ptr %l4, i32 0, i32 1
  %t116 = getelementptr { i32, i64 }, ptr %t115, i32 0, i32 1
  %t117 = load i64, ptr %t116
  store i64 %t117, ptr %l8, !tbaa !24
  br label %bb18
bb17:
  br label %bb23
bb18:
  %t119 = load i64, ptr %l8, !tbaa !24
  %t121 = icmp sge i64 %t119, 0
  br i1 %t121, label %bb19, label %bb20
bb19:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load ptr, ptr %lp3
  %t125 = load %"compiler/lower:pl", ptr %t124
  %t126 = load i64, ptr %l8, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t127
  %t128 = getelementptr { i64, [1 x i64] }, ptr %t127, i32 0, i32 0
  store i64 2, ptr %t128
  %t130 = insertvalue { i64 } undef, i64 %t126, 0
  %t131 = getelementptr { i64, [1 x i64] }, ptr %t127, i32 0, i32 1
  store { i64 } %t130, ptr %t131
  %t132 = load { i64, [1 x i64] }, ptr %t127
  %t136 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %v2, ptr %v2, ptr %t123, %"compiler/lower:pl" %t125, { i64, [1 x i64] } %t132)
  store %"compiler/lower:pl" %t136, ptr %l63
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t137 = load %"compiler/lower:pl", ptr %l63
  store %"compiler/lower:pl" %t137, ptr %rv
  br label %ret
bb22:
  br label %bb28
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_ee7cb6b84b4996f0_d216e2901020b0e4)
  unreachable
bb28:
  br label %bb29
bb29:
  %t138 = load ptr, ptr %l0, !tbaa !29
  store ptr %t138, ptr %l64, !tbaa !29
  %t139 = load ptr, ptr %lp3
  %t140 = load %"compiler/lower:pl", ptr %t139
  store %"compiler/lower:pl" %t140, ptr %l65
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load { i64, [4 x i64] }, ptr %l4
  %t143 = load i32, ptr %l5, !tbaa !23
  %t144 = load %"compiler/source:Span", ptr %l2
  %t149 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %t141, { i64, [4 x i64] } %t142, i32 %t143, %"compiler/source:Span" %t144)
  store i32 %t149, ptr %l70
  br label %bb30
bb30:
  store { i64, [1 x i64] } zeroinitializer, ptr %t150
  %t151 = getelementptr { i64, [1 x i64] }, ptr %t150, i32 0, i32 0
  store i64 1, ptr %t151
  %t152 = load i32, ptr %l70, !tbaa !23
  %t153 = insertvalue { i32 } undef, i32 %t152, 0
  %t154 = getelementptr { i64, [1 x i64] }, ptr %t150, i32 0, i32 1
  store { i32 } %t153, ptr %t154
  %t155 = load { i64, [1 x i64] }, ptr %t150
  %t156 = load ptr, ptr %l64, !tbaa !29
  %t157 = load %"compiler/lower:pl", ptr %l65
  %t159 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %v2, ptr %v2, ptr %t156, %"compiler/lower:pl" %t157, { i64, [1 x i64] } %t155)
  store %"compiler/lower:pl" %t159, ptr %l72
  br label %bb31
bb31:
  %t160 = load %"compiler/lower:pl", ptr %l72
  store %"compiler/lower:pl" %t160, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:pl", ptr %rv
  ret %"compiler/lower:pl" %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 7
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/lower:lowering", ptr %t8, i32 0, i32 3
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/lower:lowering", ptr %t11, i32 0, i32 6
  %t14 = load i32, ptr %t13, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v0, ptr %v1, ptr %t10, i32 %t14, ptr %a1)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %a0, { i64, [8 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 7
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 3
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/lower:lowering", ptr %t9, i32 0, i32 6
  %t12 = load i32, ptr %t11, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v0, ptr %t8, i32 %t12, { i64, [8 x i64] } %a1)
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/lower:lowering", ptr %t17, i32 0, i32 7
  store i1 true, ptr %t19, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eepilogue(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %t12 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleave(ptr %v0, ptr %t1, i64 0)
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/lower:lowering", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/typed:Body", ptr %t7, i32 0, i32 4
  %t10 = load %"compiler/source:Span", ptr %t9
  store { i64, [8 x i64] } zeroinitializer, ptr %t12
  %t13 = getelementptr { i64, [8 x i64] }, ptr %t12, i32 0, i32 0
  store i64 5, ptr %t13
  %t15 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t10, 0
  %t17 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t15, { i64, [4 x i64] } %a1, 1
  %t18 = getelementptr { i64, [8 x i64] }, ptr %t12, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t17, ptr %t18
  %t19 = load { i64, [8 x i64] }, ptr %t12
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t3, { i64, [8 x i64] } %t19)
  br label %bb2
bb2:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eexitLevel(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/lower:level"
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l14 = alloca %"compiler/lower:level"
  %l21 = alloca %"compiler/source:Span"
  %l27 = alloca %"compiler/typed:BlockInfo"
  %l38 = alloca %"compiler/mir:ScopeInfo"
  %l42 = alloca i32
  %l46 = alloca { i64, ptr }
  %l61 = alloca i32
  %l72 = alloca i32
  %l75 = alloca i32
  %l92 = alloca ptr
  %l93 = alloca i64
  %l94 = alloca i32
  %l96 = alloca %"compiler/mir:Lvalue"
  %s0 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %t99 = alloca { i64, [8 x i64] }, align 8
  %t142 = alloca { i64, [8 x i64] }, align 8
  %t172 = alloca { i64, [8 x i64] }, align 8
  %t200 = alloca { i64, [21 x i64] }, align 8
  %t219 = alloca { i64, [4 x i64] }, align 8
  %t241 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 7
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 9
  %t9 = load i64, ptr %l1, !tbaa !24
  %t12 = call %"compiler/lower:level" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eAt_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t8, i64 %t9)
  store %"compiler/lower:level" %t12, ptr %l14
  br label %bb4
bb4:
  %t13 = load %"compiler/lower:level", ptr %l14
  store %"compiler/lower:level" %t13, ptr %l2
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2erunDefers(ptr %v0, ptr %t14, i64 %t15, i1 false)
  br label %bb5
bb5:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/lower:lowering", ptr %t18, i32 0, i32 7
  %t21 = load i1, ptr %t20, !tbaa !21
  br i1 %t21, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  br label %bb8
bb8:
  %t23 = getelementptr %"compiler/lower:level", ptr %l2, i32 0, i32 1
  %t24 = load i32, ptr %t23, !tbaa !23
  %t26 = icmp sge i32 %t24, 0
  br i1 %t26, label %bb9, label %bb10
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/lower:lowering", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/typed:Body", ptr %t31, i32 0, i32 8
  %t34 = getelementptr %"compiler/lower:level", ptr %l2, i32 0, i32 1
  %t35 = load i32, ptr %t34, !tbaa !23
  %t37 = sext i32 %t35 to i64
  %t40 = call %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %v0, ptr %t33, i64 %t37)
  store %"compiler/typed:BlockInfo" %t40, ptr %l27
  br label %bb11
bb10:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/lower:lowering", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/typed:Body", ptr %t44, i32 0, i32 4
  %t47 = load %"compiler/source:Span", ptr %t46
  store %"compiler/source:Span" %t47, ptr %l21
  br label %bb12
bb11:
  %t49 = getelementptr %"compiler/typed:BlockInfo", ptr %l27, i32 0, i32 2
  %t50 = load %"compiler/source:Span", ptr %t49
  store %"compiler/source:Span" %t50, ptr %l21
  br label %bb12
bb12:
  %t52 = load %"compiler/source:Span", ptr %l21
  store %"compiler/source:Span" %t52, ptr %l3
  %t53 = getelementptr %"compiler/lower:level", ptr %l2, i32 0, i32 2
  %t54 = load i32, ptr %t53
  %t56 = trunc i64 3 to i32
  %t57 = icmp eq i32 %t54, %t56
  br i1 %t57, label %bb13, label %bb14
bb13:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/lower:lowering", ptr %t59, i32 0, i32 3
  %t62 = getelementptr %"compiler/mir:Fn", ptr %t61, i32 0, i32 8
  %t63 = getelementptr %"compiler/lower:level", ptr %l2, i32 0, i32 0
  %t64 = load i32, ptr %t63, !tbaa !23
  %t66 = sext i32 %t64 to i64
  %t69 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t62, i64 %t66)
  store %"compiler/mir:ScopeInfo" %t69, ptr %l38
  br label %bb15
bb14:
  br label %bb36
bb15:
  %t70 = getelementptr %"compiler/mir:ScopeInfo", ptr %l38, i32 0, i32 4
  %t71 = load i32, ptr %t70, !tbaa !23
  store i32 %t71, ptr %l4, !tbaa !23
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/lower:lowering", ptr %t73, i32 0, i32 3
  %t77 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t75)
  store i32 %t77, ptr %l42
  br label %bb16
bb16:
  %t78 = load i32, ptr %l42, !tbaa !23
  store i32 %t78, ptr %l5, !tbaa !23
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/lower:lowering", ptr %t79, i32 0, i32 2
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t83 = load i32, ptr %l4, !tbaa !23
  %t86 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t82, i32 %t83)
  store { i64, ptr } %t86, ptr %l46
  br label %bb17
bb17:
  %t87 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 0
  %t90 = icmp eq i64 %t88, 0
  br i1 %t90, label %bb18, label %bb19
bb18:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load %"compiler/source:Span", ptr %l3
  %t94 = getelementptr %"compiler/lower:level", ptr %l2, i32 0, i32 0
  %t95 = load i32, ptr %t94, !tbaa !23
  %t96 = load i32, ptr %l5, !tbaa !23
  %t97 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t98 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t99
  %t100 = getelementptr { i64, [8 x i64] }, ptr %t99, i32 0, i32 0
  store i64 8, ptr %t100
  %t102 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } undef, %"compiler/source:Span" %t93, 0
  %t104 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } %t102, i32 %t95, 1
  %t106 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } %t104, i32 %t96, 2
  %t108 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } %t106, i32 %t97, 3
  %t110 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } %t108, i32 %t98, 4
  %t111 = getelementptr { i64, [8 x i64] }, ptr %t99, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, i32 } %t110, ptr %t111
  %t112 = load { i64, [8 x i64] }, ptr %t99
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t92, { i64, [8 x i64] } %t112)
  br label %bb20
bb19:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/lower:lowering", ptr %t115, i32 0, i32 18
  %t118 = load i1, ptr %t117, !tbaa !21
  br i1 %t118, label %bb21, label %bb22
bb20:
  br label %bb34
bb21:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t122 = load %"compiler/source:Span", ptr %l3
  %t126 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t120, i32 %t121, %"compiler/source:Span" %t122)
  store i32 %t126, ptr %l61
  br label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s7
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t129 = load %"compiler/source:Span", ptr %l3
  %t133 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t127, i32 %t128, %"compiler/source:Span" %t129)
  store i32 %t133, ptr %l72
  br label %bb25
bb23:
  %t134 = load i32, ptr %l61, !tbaa !23
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load %"compiler/source:Span", ptr %l3
  %t137 = getelementptr %"compiler/lower:level", ptr %l2, i32 0, i32 0
  %t138 = load i32, ptr %t137, !tbaa !23
  %t139 = load i32, ptr %l5, !tbaa !23
  %t141 = load i32, ptr %l5, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t142
  %t143 = getelementptr { i64, [8 x i64] }, ptr %t142, i32 0, i32 0
  store i64 8, ptr %t143
  %t145 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } undef, %"compiler/source:Span" %t136, 0
  %t147 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } %t145, i32 %t138, 1
  %t149 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } %t147, i32 %t139, 2
  %t151 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } %t149, i32 %t134, 3
  %t153 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } %t151, i32 %t141, 4
  %t154 = getelementptr { i64, [8 x i64] }, ptr %t142, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, i32 } %t153, ptr %t154
  %t155 = load { i64, [8 x i64] }, ptr %t142
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t135, { i64, [8 x i64] } %t155)
  br label %bb24
bb24:
  br label %bb33
bb25:
  %t158 = load i32, ptr %l72, !tbaa !23
  store i32 %t158, ptr %l7, !tbaa !23
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/lower:lowering", ptr %t159, i32 0, i32 3
  %t163 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t161)
  store i32 %t163, ptr %l75
  br label %bb26
bb26:
  %t164 = load i32, ptr %l75, !tbaa !23
  store i32 %t164, ptr %l8, !tbaa !23
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t166 = load %"compiler/source:Span", ptr %l3
  %t167 = getelementptr %"compiler/lower:level", ptr %l2, i32 0, i32 0
  %t168 = load i32, ptr %t167, !tbaa !23
  %t169 = load i32, ptr %l5, !tbaa !23
  %t170 = load i32, ptr %l7, !tbaa !23
  %t171 = load i32, ptr %l8, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t172
  %t173 = getelementptr { i64, [8 x i64] }, ptr %t172, i32 0, i32 0
  store i64 8, ptr %t173
  %t175 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } undef, %"compiler/source:Span" %t166, 0
  %t177 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } %t175, i32 %t168, 1
  %t179 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } %t177, i32 %t169, 2
  %t181 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } %t179, i32 %t170, 3
  %t183 = insertvalue { %"compiler/source:Span", i32, i32, i32, i32 } %t181, i32 %t171, 4
  %t184 = getelementptr { i64, [8 x i64] }, ptr %t172, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, i32 } %t183, ptr %t184
  %t185 = load { i64, [8 x i64] }, ptr %t172
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t165, { i64, [8 x i64] } %t185)
  br label %bb27
bb27:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load i32, ptr %l8, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t188, i32 %t189)
  br label %bb28
bb28:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t193 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2erunDefers(ptr %v0, ptr %t192, i64 %t193, i1 true)
  br label %bb29
bb29:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load %"compiler/source:Span", ptr %l3
  %t198 = getelementptr %"compiler/lower:level", ptr %l2, i32 0, i32 0
  %t199 = load i32, ptr %t198, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t200
  %t201 = getelementptr { i64, [21 x i64] }, ptr %t200, i32 0, i32 0
  store i64 4, ptr %t201
  %t203 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t197, 0
  %t205 = insertvalue { %"compiler/source:Span", i32 } %t203, i32 %t199, 1
  %t206 = getelementptr { i64, [21 x i64] }, ptr %t200, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t205, ptr %t206
  %t207 = load { i64, [21 x i64] }, ptr %t200
  %t209 = call ptr @__olang_scope_alloc_a(ptr %s7, i64 176, i64 8)
  store { i64, [21 x i64] } %t207, ptr %t209
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s7, ptr %t196, ptr %t209)
  br label %bb30
bb30:
  %t212 = load ptr, ptr %l0, !tbaa !29
  store ptr %t212, ptr %l92, !tbaa !29
  %t213 = load i64, ptr %l1, !tbaa !24
  store i64 %t213, ptr %l93, !tbaa !24
  %t214 = getelementptr %"compiler/lower:level", ptr %l2, i32 0, i32 0
  %t215 = load i32, ptr %t214, !tbaa !23
  store i32 %t215, ptr %l94, !tbaa !23
  %t216 = load i32, ptr %l7, !tbaa !23
  %t218 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t216)
  store %"compiler/mir:Lvalue" %t218, ptr %l96
  br label %bb31
bb31:
  store { i64, [4 x i64] } zeroinitializer, ptr %t219
  %t220 = getelementptr { i64, [4 x i64] }, ptr %t219, i32 0, i32 0
  store i64 1, ptr %t220
  %t221 = load %"compiler/mir:Lvalue", ptr %l96
  %t222 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t221, 0
  %t223 = getelementptr { i64, [4 x i64] }, ptr %t219, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t222, ptr %t223
  %t224 = load { i64, [4 x i64] }, ptr %t219
  %t225 = load i32, ptr %l4, !tbaa !23
  %t226 = load %"compiler/source:Span", ptr %l3
  %t227 = load ptr, ptr %l92, !tbaa !29
  %t228 = load i64, ptr %l93, !tbaa !24
  %t229 = load i32, ptr %l94, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ejoinFailed(ptr %v0, ptr %t227, i64 %t228, i32 %t229, { i64, [4 x i64] } %t224, i32 %t225, %"compiler/source:Span" %t226)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s7)
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t234 = load i32, ptr %l5, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t233, i32 %t234)
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t238 = load %"compiler/source:Span", ptr %l3
  %t239 = getelementptr %"compiler/lower:level", ptr %l2, i32 0, i32 0
  %t240 = load i32, ptr %t239, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t241
  %t242 = getelementptr { i64, [21 x i64] }, ptr %t241, i32 0, i32 0
  store i64 4, ptr %t242
  %t244 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t238, 0
  %t246 = insertvalue { %"compiler/source:Span", i32 } %t244, i32 %t240, 1
  %t247 = getelementptr { i64, [21 x i64] }, ptr %t241, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t246, ptr %t247
  %t248 = load { i64, [21 x i64] }, ptr %t241
  %t250 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t248, ptr %t250
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t237, ptr %t250)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2efit(ptr %v0, ptr %v1, ptr %a0, { i64, [4 x i64] } %a1, ptr %a2, i32 %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [4 x i64] }
  %l2 = alloca ptr
  %l3 = alloca i32
  %l7 = alloca i1
  %l15 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca { i64, [4 x i64] }
  %l19 = alloca i32
  %l20 = alloca i32
  %l21 = alloca %"compiler/source:Span"
  %l23 = alloca { i64, [1 x i64] }
  %l24 = alloca { i64, [4 x i64] }
  %rv = alloca { i64, [4 x i64] }
  store ptr %a0, ptr %l0
  store { i64, [4 x i64] } %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 7
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb3
bb2:
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = icmp eq ptr %t6, null
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb3
bb3:
  %t10 = load i1, ptr %l7, !tbaa !21
  br i1 %t10, label %bb4, label %bb5
bb4:
  %t11 = load { i64, [4 x i64] }, ptr %l1
  store { i64, [4 x i64] } %t11, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t16 = load i32, ptr %l3, !tbaa !23
  %t20 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2efits(ptr %v0, ptr %v1, ptr %t13, ptr %t14, i32 %t16)
  store i1 %t20, ptr %l15
  br label %bb7
bb7:
  %t21 = load i1, ptr %l15, !tbaa !21
  br i1 %t21, label %bb8, label %bb9
bb8:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l16, !tbaa !29
  %t23 = load { i64, [4 x i64] }, ptr %l1
  store { i64, [4 x i64] } %t23, ptr %l17
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t26 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t24)
  store i32 %t26, ptr %l19
  br label %bb10
bb9:
  br label %bb13
bb10:
  %t27 = load i32, ptr %l3, !tbaa !23
  store i32 %t27, ptr %l20, !tbaa !23
  store %"compiler/source:Span" %a4, ptr %l21
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einnermost(ptr %v0, ptr %t29)
  store { i64, [1 x i64] } %t31, ptr %l23
  br label %bb11
bb11:
  %t32 = load ptr, ptr %l16, !tbaa !29
  %t33 = load { i64, [4 x i64] }, ptr %l17
  %t34 = load i32, ptr %l19, !tbaa !23
  %t35 = load i32, ptr %l20, !tbaa !23
  %t36 = load %"compiler/source:Span", ptr %l21
  %t37 = load { i64, [1 x i64] }, ptr %l23
  %t38 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ewiden(ptr %v0, ptr %t32, { i64, [4 x i64] } %t33, i32 %t34, i32 %t35, %"compiler/source:Span" %t36, { i64, [1 x i64] } %t37)
  store { i64, [4 x i64] } %t38, ptr %l24
  br label %bb12
bb12:
  %t39 = load { i64, [4 x i64] }, ptr %l24
  store { i64, [4 x i64] } %t39, ptr %rv
  br label %ret
bb13:
  %t40 = load { i64, [4 x i64] }, ptr %l1
  store { i64, [4 x i64] } %t40, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2efitAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3, { i64, [1 x i64] } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, [1 x i64] }
  %l5 = alloca ptr
  %l6 = alloca { i64, [4 x i64] }
  %l7 = alloca { i64, [4 x i64] }
  %l11 = alloca i1
  %l13 = alloca ptr
  %l17 = alloca { i64, [4 x i64] }
  %l21 = alloca ptr
  %l22 = alloca { i64, [4 x i64] }
  %l24 = alloca i32
  %l28 = alloca { i64, [4 x i64] }
  %l32 = alloca { i64, [4 x i64] }
  %l35 = alloca i1
  %l40 = alloca i1
  %l43 = alloca ptr
  %l44 = alloca { i64, [4 x i64] }
  %l46 = alloca i32
  %l50 = alloca { i64, [4 x i64] }
  %rv = alloca { i64, [4 x i64] }
  %t25 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  store { i64, [1 x i64] } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = load i32, ptr %l2, !tbaa !23
  %t7 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ewidens(ptr %v0, ptr %v1, ptr %t1, ptr %t2, i32 %t3)
  store i1 %t7, ptr %l11
  br label %bb1
bb1:
  %t8 = load i1, ptr %l11, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = call ptr @compiler_2flower_2econvertArg(ptr %v1, ptr %t9)
  store ptr %t11, ptr %l13
  br label %bb4
bb3:
  br label %bb11
bb4:
  %t12 = load ptr, ptr %l13, !tbaa !29
  store ptr %t12, ptr %l5, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load ptr, ptr %l5, !tbaa !29
  %t18 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t13, ptr %t14)
  store { i64, [4 x i64] } %t18, ptr %l17
  br label %bb5
bb5:
  %t19 = load { i64, [4 x i64] }, ptr %l17
  store { i64, [4 x i64] } %t19, ptr %l6
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/lower:lowering", ptr %t20, i32 0, i32 7
  %t23 = load i1, ptr %t22, !tbaa !21
  br i1 %t23, label %bb6, label %bb7
bb6:
  store { i64, [4 x i64] } zeroinitializer, ptr %t25
  %t26 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 0
  store i64 0, ptr %t26
  %t27 = load { i64, [4 x i64] }, ptr %t25
  store { i64, [4 x i64] } %t27, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l21, !tbaa !29
  %t30 = load { i64, [4 x i64] }, ptr %l6
  store { i64, [4 x i64] } %t30, ptr %l22
  %t31 = load ptr, ptr %l5, !tbaa !29
  %t33 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t31)
  store i32 %t33, ptr %l24
  br label %bb9
bb9:
  %t34 = load i32, ptr %l2, !tbaa !23
  %t35 = load %"compiler/source:Span", ptr %l3
  %t36 = load { i64, [1 x i64] }, ptr %l4
  %t37 = load ptr, ptr %l21, !tbaa !29
  %t38 = load { i64, [4 x i64] }, ptr %l22
  %t39 = load i32, ptr %l24, !tbaa !23
  %t43 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ewiden(ptr %v0, ptr %t37, { i64, [4 x i64] } %t38, i32 %t39, i32 %t34, %"compiler/source:Span" %t35, { i64, [1 x i64] } %t36)
  store { i64, [4 x i64] } %t43, ptr %l28
  br label %bb10
bb10:
  %t44 = load { i64, [4 x i64] }, ptr %l28
  store { i64, [4 x i64] } %t44, ptr %rv
  br label %ret
bb11:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t50 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t45, ptr %t46)
  store { i64, [4 x i64] } %t50, ptr %l32
  br label %bb12
bb12:
  %t51 = load { i64, [4 x i64] }, ptr %l32
  store { i64, [4 x i64] } %t51, ptr %l7
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/lower:lowering", ptr %t52, i32 0, i32 7
  %t55 = load i1, ptr %t54, !tbaa !21
  br i1 %t55, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb16
bb14:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = load i32, ptr %l2, !tbaa !23
  %t64 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2efits(ptr %v0, ptr %v1, ptr %t57, ptr %t58, i32 %t60)
  store i1 %t64, ptr %l40
  br label %bb15
bb15:
  %t65 = load i1, ptr %l40, !tbaa !21
  %t66 = xor i1 %t65, true
  store i1 %t66, ptr %l35, !tbaa !21
  br label %bb16
bb16:
  %t68 = load i1, ptr %l35, !tbaa !21
  br i1 %t68, label %bb17, label %bb18
bb17:
  %t69 = load { i64, [4 x i64] }, ptr %l7
  store { i64, [4 x i64] } %t69, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l43, !tbaa !29
  %t72 = load { i64, [4 x i64] }, ptr %l7
  store { i64, [4 x i64] } %t72, ptr %l44
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t73)
  store i32 %t75, ptr %l46
  br label %bb20
bb20:
  %t76 = load i32, ptr %l2, !tbaa !23
  %t77 = load %"compiler/source:Span", ptr %l3
  %t78 = load { i64, [1 x i64] }, ptr %l4
  %t79 = load ptr, ptr %l43, !tbaa !29
  %t80 = load { i64, [4 x i64] }, ptr %l44
  %t81 = load i32, ptr %l46, !tbaa !23
  %t85 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ewiden(ptr %v0, ptr %t79, { i64, [4 x i64] } %t80, i32 %t81, i32 %t76, %"compiler/source:Span" %t77, { i64, [1 x i64] } %t78)
  store { i64, [4 x i64] } %t85, ptr %l50
  br label %bb21
bb21:
  %t86 = load { i64, [4 x i64] }, ptr %l50
  store { i64, [4 x i64] } %t86, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2efits(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l11 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca i32
  %l17 = alloca i32
  %l20 = alloca i32
  %l23 = alloca i1
  %l26 = alloca i32
  %l29 = alloca i1
  %l32 = alloca i32
  %l34 = alloca i1
  %l37 = alloca i32
  %l39 = alloca i1
  %l40 = alloca ptr
  %l43 = alloca i32
  %l46 = alloca i32
  %l47 = alloca i1
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = getelementptr %"compiler/lower:lowering", ptr %a0, i32 0, i32 2
  %t9 = load ptr, ptr %t8, !tbaa !29
  store ptr %t9, ptr %l3, !tbaa !29
  %t11 = load ptr, ptr %l3, !tbaa !29
  store ptr %t11, ptr %l11, !tbaa !29
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t12)
  store i32 %t14, ptr %l13
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l11, !tbaa !29
  %t16 = load i32, ptr %l13, !tbaa !23
  %t17 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t17, ptr %l14
  br label %bb5
bb5:
  %t18 = load i32, ptr %l14, !tbaa !23
  store i32 %t18, ptr %l4, !tbaa !23
  %t19 = load ptr, ptr %l3, !tbaa !29
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t19, i32 %a2)
  store i32 %t23, ptr %l17
  br label %bb6
bb6:
  %t24 = load i32, ptr %l17, !tbaa !23
  store i32 %t24, ptr %l5, !tbaa !23
  %t25 = load ptr, ptr %l3, !tbaa !29
  %t26 = load i32, ptr %l4, !tbaa !23
  %t29 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t25, i32 %t26)
  store i32 %t29, ptr %l20
  br label %bb7
bb7:
  %t30 = load i32, ptr %l20
  %t32 = trunc i64 19 to i32
  %t33 = icmp eq i32 %t30, %t32
  br i1 %t33, label %bb8, label %bb9
bb8:
  %t35 = load ptr, ptr %l3, !tbaa !29
  %t36 = load i32, ptr %l5, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t35, i32 %t36)
  store i32 %t39, ptr %l26
  br label %bb10
bb9:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb11
bb10:
  %t40 = load i32, ptr %l26
  %t42 = trunc i64 19 to i32
  %t43 = icmp eq i32 %t40, %t42
  store i1 %t43, ptr %l23, !tbaa !21
  br label %bb11
bb11:
  %t45 = load i1, ptr %l23, !tbaa !21
  br i1 %t45, label %bb12, label %bb13
bb12:
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t47 = load i32, ptr %l4, !tbaa !23
  %t50 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t46, i32 %t47)
  store i32 %t50, ptr %l32
  br label %bb14
bb13:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb15
bb14:
  %t51 = load i32, ptr %l32, !tbaa !23
  %t52 = icmp ne i32 %t51, 0
  store i1 %t52, ptr %l29, !tbaa !21
  br label %bb15
bb15:
  %t54 = load i1, ptr %l29, !tbaa !21
  br i1 %t54, label %bb16, label %bb17
bb16:
  %t55 = load ptr, ptr %l3, !tbaa !29
  %t56 = load i32, ptr %l5, !tbaa !23
  %t59 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t55, i32 %t56)
  store i32 %t59, ptr %l37
  br label %bb18
bb17:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb19
bb18:
  %t60 = load i32, ptr %l37, !tbaa !23
  %t61 = icmp eq i32 %t60, 0
  store i1 %t61, ptr %l34, !tbaa !21
  br label %bb19
bb19:
  %t63 = load i1, ptr %l34, !tbaa !21
  br i1 %t63, label %bb20, label %bb21
bb20:
  %t64 = load ptr, ptr %l3, !tbaa !29
  store ptr %t64, ptr %l40, !tbaa !29
  %t65 = load ptr, ptr %l3, !tbaa !29
  %t66 = load i32, ptr %l4, !tbaa !23
  %t69 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t65, i32 %t66)
  store i32 %t69, ptr %l43
  br label %bb22
bb21:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb25
bb22:
  %t70 = load ptr, ptr %l3, !tbaa !29
  %t71 = load i32, ptr %l5, !tbaa !23
  %t74 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t70, i32 %t71)
  store i32 %t74, ptr %l46
  br label %bb23
bb23:
  %t75 = load ptr, ptr %l40, !tbaa !29
  %t76 = load i32, ptr %l43, !tbaa !23
  %t77 = load i32, ptr %l46, !tbaa !23
  %t78 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t75, i32 %t76, i32 %t77)
  store i1 %t78, ptr %l47
  br label %bb24
bb24:
  %t79 = load i1, ptr %l47, !tbaa !21
  store i1 %t79, ptr %l39, !tbaa !21
  br label %bb25
bb25:
  %t80 = load i1, ptr %l39, !tbaa !21
  store i1 %t80, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2efnVal(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca { i64, [4 x i64] }
  %l12 = alloca ptr
  %l13 = alloca i1
  %l28 = alloca { i64, [4 x i64] }
  %l29 = alloca ptr
  %l30 = alloca i1
  %l45 = alloca { i64, [4 x i64] }
  %l46 = alloca ptr
  %l47 = alloca i1
  %l62 = alloca { i64, [4 x i64] }
  %rv = alloca { i64, [4 x i64] }
  %t19 = alloca { i64, [2 x i64] }, align 8
  %t26 = alloca { i64, [1 x i64] }, align 8
  %t31 = alloca { i64, [15 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t2 = load ptr, ptr %l12, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l12, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l13, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l13, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { i32 }, ptr %t12, i32 0, i32 0
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l4, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  %t18 = load i32, ptr %l4, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t19
  %t20 = getelementptr { i64, [2 x i64] }, ptr %t19, i32 0, i32 0
  store i64 0, ptr %t20
  %t22 = insertvalue { i32 } undef, i32 %t18, 0
  %t23 = getelementptr { i64, [2 x i64] }, ptr %t19, i32 0, i32 1
  store { i32 } %t22, ptr %t23
  %t24 = load { i64, [2 x i64] }, ptr %t19
  %t25 = load i32, ptr %l2, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t26
  %t27 = getelementptr { i64, [1 x i64] }, ptr %t26, i32 0, i32 0
  store i64 3, ptr %t27
  %t28 = load { i64, [1 x i64] }, ptr %t26
  %t29 = load %"compiler/mir:Range", ptr @G_2ecompiler_2fmir_2eEmpty
  %t30 = load %"compiler/mir:Range", ptr @G_2ecompiler_2fmir_2eEmpty
  store { i64, [15 x i64] } zeroinitializer, ptr %t31
  %t32 = getelementptr { i64, [15 x i64] }, ptr %t31, i32 0, i32 0
  store i64 10, ptr %t32
  %t34 = insertvalue { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" } undef, { i64, [2 x i64] } %t24, 0
  %t36 = insertvalue { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" } %t34, i32 %t25, 1
  %t38 = insertvalue { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" } %t36, { i64, [1 x i64] } %t28, 2
  %t40 = insertvalue { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" } %t38, %"compiler/mir:Range" %t29, 3
  %t42 = insertvalue { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" } %t40, %"compiler/mir:Range" %t30, 4
  %t43 = getelementptr { i64, [15 x i64] }, ptr %t31, i32 0, i32 1
  store { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" } %t42, ptr %t43
  %t44 = load { i64, [15 x i64] }, ptr %t31
  %t45 = load %"compiler/source:Span", ptr %l3
  %t50 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t16, i32 %t17, { i64, [15 x i64] } %t44, %"compiler/source:Span" %t45)
  store { i64, [4 x i64] } %t50, ptr %l28
  br label %bb6
bb6:
  %t51 = load { i64, [4 x i64] }, ptr %l28
  store { i64, [4 x i64] } %t51, ptr %l11
  br label %bb22
bb7:
  %t52 = load ptr, ptr %l1, !tbaa !29
  store ptr %t52, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t53 = load ptr, ptr %l29, !tbaa !29
  %t54 = icmp ne ptr %t53, null
  br i1 %t54, label %bb8, label %bb9
bb8:
  %t56 = load ptr, ptr %l29, !tbaa !29
  %t57 = load i64, ptr %t56
  %t59 = icmp eq i64 %t57, 1
  store i1 %t59, ptr %l30, !tbaa !21
  br label %bb9
bb9:
  %t60 = load i1, ptr %l30, !tbaa !21
  br i1 %t60, label %bb10, label %bb11
bb10:
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr { i64, [4 x i64] }, ptr %t61, i32 0, i32 1
  %t64 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t63, i32 0, i32 0
  %t65 = load i32, ptr %t64
  store i32 %t65, ptr %l5, !tbaa !23
  %t67 = load ptr, ptr %l1, !tbaa !29
  %t69 = getelementptr { i64, [4 x i64] }, ptr %t67, i32 0, i32 1
  %t70 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t69, i32 0, i32 1
  %t71 = load { i64, ptr }, ptr %t70
  store { i64, ptr } %t71, ptr %l6, !tbaa !27
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr { i64, [4 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t75, i32 0, i32 2
  %t77 = load i32, ptr %t76
  store i32 %t77, ptr %l7, !tbaa !23
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load i32, ptr %l5, !tbaa !23
  %t81 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t82 = load i32, ptr %l7, !tbaa !23
  %t83 = load i32, ptr %l2, !tbaa !23
  %t84 = load %"compiler/source:Span", ptr %l3
  %t91 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2elambda(ptr %v0, ptr %v1, ptr %t79, i32 %t80, { i64, ptr } %t81, i32 %t82, i32 %t83, %"compiler/source:Span" %t84)
  store { i64, [4 x i64] } %t91, ptr %l45
  br label %bb13
bb13:
  %t92 = load { i64, [4 x i64] }, ptr %l45
  store { i64, [4 x i64] } %t92, ptr %l11
  br label %bb22
bb14:
  %t93 = load ptr, ptr %l1, !tbaa !29
  store ptr %t93, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t94 = load ptr, ptr %l46, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb15, label %bb16
bb15:
  %t97 = load ptr, ptr %l46, !tbaa !29
  %t98 = load i64, ptr %t97
  %t100 = icmp eq i64 %t98, 2
  store i1 %t100, ptr %l47, !tbaa !21
  br label %bb16
bb16:
  %t101 = load i1, ptr %l47, !tbaa !21
  br i1 %t101, label %bb17, label %bb18
bb17:
  %t102 = load ptr, ptr %l1, !tbaa !29
  %t104 = getelementptr { i64, [4 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { i32, ptr, i32 }, ptr %t104, i32 0, i32 0
  %t106 = load i32, ptr %t105
  store i32 %t106, ptr %l8, !tbaa !23
  %t108 = load ptr, ptr %l1, !tbaa !29
  %t110 = getelementptr { i64, [4 x i64] }, ptr %t108, i32 0, i32 1
  %t111 = getelementptr { i32, ptr, i32 }, ptr %t110, i32 0, i32 1
  %t112 = load ptr, ptr %t111
  store ptr %t112, ptr %l9, !tbaa !29
  %t114 = load ptr, ptr %l1, !tbaa !29
  %t116 = getelementptr { i64, [4 x i64] }, ptr %t114, i32 0, i32 1
  %t117 = getelementptr { i32, ptr, i32 }, ptr %t116, i32 0, i32 2
  %t118 = load i32, ptr %t117
  store i32 %t118, ptr %l10, !tbaa !23
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load i32, ptr %l8, !tbaa !23
  %t122 = load ptr, ptr %l9, !tbaa !29
  %t123 = load i32, ptr %l10, !tbaa !23
  %t124 = load i32, ptr %l2, !tbaa !23
  %t125 = load %"compiler/source:Span", ptr %l3
  %t132 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eadapter(ptr %v0, ptr %v1, ptr %t120, i32 %t121, ptr %t122, i32 %t123, i32 %t124, %"compiler/source:Span" %t125)
  store { i64, [4 x i64] } %t132, ptr %l62
  br label %bb20
bb20:
  %t133 = load { i64, [4 x i64] }, ptr %l62
  store { i64, [4 x i64] } %t133, ptr %l11
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_a9ad50b63422a08e_67259be34391ceea)
  unreachable
bb22:
  %t134 = load { i64, [4 x i64] }, ptr %l11
  store { i64, [4 x i64] } %t134, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %t3 = alloca { i64, [8 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store { i64, [8 x i64] } zeroinitializer, ptr %t3
  %t4 = getelementptr { i64, [8 x i64] }, ptr %t3, i32 0, i32 0
  store i64 1, ptr %t4
  %t6 = insertvalue { i32 } undef, i32 %a1, 0
  %t7 = getelementptr { i64, [8 x i64] }, ptr %t3, i32 0, i32 1
  store { i32 } %t6, ptr %t7
  %t8 = load { i64, [8 x i64] }, ptr %t3
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %a0, { i64, [8 x i64] } %t8)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ehasStr(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2estrBody(ptr %v0, ptr %a0, i32 %a1)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = icmp sge i64 %t6, 0
  store i1 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ehelperCall(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, i32 %a2, { i64, ptr } %a3, { i64, ptr } %a4, i32 %a5, %"compiler/source:Span" %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l5 = alloca i32
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l8 = alloca { i64, [2 x i64] }
  %l9 = alloca i32
  %l10 = alloca i32
  %l16 = alloca i32
  %l21 = alloca i32
  %l30 = alloca i32
  %l38 = alloca i32
  %l40 = alloca ptr
  %l43 = alloca { i64, [7 x i64] }
  %l47 = alloca %"compiler/mir:Range"
  %l51 = alloca %"compiler/mir:Range"
  %l55 = alloca %"compiler/mir:Lvalue"
  %l57 = alloca %"compiler/mir:Lvalue"
  %l65 = alloca %"compiler/mir:Call"
  %l66 = alloca i32
  %l76 = alloca { i64, [4 x i64] }
  %l79 = alloca %"compiler/mir:Lvalue"
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t25 = alloca { i64, [2 x i64] }, align 8
  %t68 = alloca { i64, [7 x i64] }, align 8
  %t126 = alloca { i64, [8 x i64] }, align 8
  %t146 = alloca { i64, [4 x i64] }, align 8
  %t153 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a5, ptr %l5
  store %"compiler/source:Span" %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l1
  %t6 = load i32, ptr %l2, !tbaa !23
  %t10 = call i32 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ehelperTy(ptr %v0, ptr %t4, i32 %t5, i32 %t6)
  store i32 %t10, ptr %l16
  br label %bb1
bb1:
  %t11 = load i32, ptr %l16, !tbaa !23
  store i32 %t11, ptr %l2, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lower:lowering", ptr %t12, i32 0, i32 2
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t16 = load i32, ptr %l1
  %t17 = load i32, ptr %l2, !tbaa !23
  %t21 = call i32 @compiler_2fmir_2eHelperType(ptr %v0, ptr %t15, i32 %t16, i32 %t17)
  store i32 %t21, ptr %l21
  br label %bb2
bb2:
  %t22 = load i32, ptr %l21, !tbaa !23
  store i32 %t22, ptr %l7, !tbaa !23
  %t23 = load i32, ptr %l1
  %t24 = load i32, ptr %l2, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t25
  %t26 = getelementptr { i64, [2 x i64] }, ptr %t25, i32 0, i32 0
  store i64 2, ptr %t26
  %t28 = insertvalue { i32, i32 } undef, i32 %t23, 0
  %t30 = insertvalue { i32, i32 } %t28, i32 %t24, 1
  %t31 = getelementptr { i64, [2 x i64] }, ptr %t25, i32 0, i32 1
  store { i32, i32 } %t30, ptr %t31
  %t32 = load { i64, [2 x i64] }, ptr %t25
  store { i64, [2 x i64] } %t32, ptr %l8
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/lower:lowering", ptr %t34, i32 0, i32 0
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t38 = load { i64, [2 x i64] }, ptr %l8
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eWant(ptr %v0, ptr %t37, { i64, [2 x i64] } %t38)
  br label %bb3
bb3:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/lower:lowering", ptr %t41, i32 0, i32 3
  %t45 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t43)
  store i32 %t45, ptr %l30
  br label %bb4
bb4:
  %t46 = load i32, ptr %l30, !tbaa !23
  store i32 %t46, ptr %l9, !tbaa !23
  %t47 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  store i32 %t47, ptr %l10, !tbaa !23
  %t49 = load i32, ptr %l5, !tbaa !23
  %t50 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t53 = icmp ne i32 %t49, %t50
  br i1 %t53, label %bb5, label %bb6
bb5:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load i32, ptr %l5, !tbaa !23
  %t57 = load %"compiler/source:Span", ptr %l6
  %t61 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t55, i32 %t56, %"compiler/source:Span" %t57)
  store i32 %t61, ptr %l38
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t62 = load i32, ptr %l38, !tbaa !23
  store i32 %t62, ptr %l10, !tbaa !23
  br label %bb8
bb8:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/lower:lowering", ptr %t63, i32 0, i32 3
  store ptr %t65, ptr %l40, !tbaa !29
  %t66 = load { i64, [2 x i64] }, ptr %l8
  %t67 = load i32, ptr %l7, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t68
  %t69 = getelementptr { i64, [7 x i64] }, ptr %t68, i32 0, i32 0
  store i64 0, ptr %t69
  %t71 = insertvalue { { i64, [2 x i64] }, i32 } undef, { i64, [2 x i64] } %t66, 0
  %t73 = insertvalue { { i64, [2 x i64] }, i32 } %t71, i32 %t67, 1
  %t74 = getelementptr { i64, [7 x i64] }, ptr %t68, i32 0, i32 1
  store { { i64, [2 x i64] }, i32 } %t73, ptr %t74
  %t75 = load { i64, [7 x i64] }, ptr %t68
  store { i64, [7 x i64] } %t75, ptr %l43
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/lower:lowering", ptr %t76, i32 0, i32 3
  %t82 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %v1, ptr %t78, { i64, ptr } %a3)
  store %"compiler/mir:Range" %t82, ptr %l47
  br label %bb9
bb9:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/lower:lowering", ptr %t83, i32 0, i32 3
  %t89 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eScopeRefs(ptr %v0, ptr %v2, ptr %t85, { i64, ptr } %a4)
  store %"compiler/mir:Range" %t89, ptr %l51
  br label %bb10
bb10:
  %t90 = load i32, ptr %l10, !tbaa !23
  %t91 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t94 = icmp ne i32 %t90, %t91
  br i1 %t94, label %bb11, label %bb12
bb11:
  %t96 = load i32, ptr %l10, !tbaa !23
  %t98 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t96)
  store %"compiler/mir:Lvalue" %t98, ptr %l57
  br label %bb13
bb12:
  %t99 = load %"compiler/mir:Lvalue", ptr @G_2ecompiler_2fmir_2eNoPlace
  store %"compiler/mir:Lvalue" %t99, ptr %l55
  br label %bb14
bb13:
  %t101 = load %"compiler/mir:Lvalue", ptr %l57
  store %"compiler/mir:Lvalue" %t101, ptr %l55
  br label %bb14
bb14:
  %t102 = load i32, ptr %l10, !tbaa !23
  %t103 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t106 = icmp ne i32 %t102, %t103
  %t107 = load i32, ptr %l9, !tbaa !23
  %t108 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t109 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t110 = load { i64, [7 x i64] }, ptr %l43
  %t111 = load %"compiler/mir:Range", ptr %l47
  %t112 = load %"compiler/mir:Range", ptr %l51
  %t113 = load %"compiler/mir:Lvalue", ptr %l55
  %t118 = call %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %s0, { i64, [7 x i64] } %t110, %"compiler/mir:Range" %t111, %"compiler/mir:Range" %t112, %"compiler/mir:Lvalue" %t113, i1 %t106, i32 %t107, i32 %t108, i32 %t109)
  store %"compiler/mir:Call" %t118, ptr %l65
  br label %bb15
bb15:
  %t119 = load ptr, ptr %l40, !tbaa !29
  %t120 = load %"compiler/mir:Call", ptr %l65
  %t121 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v0, ptr %t119, %"compiler/mir:Call" %t120)
  store i32 %t121, ptr %l66
  br label %bb16
bb16:
  %t122 = load i32, ptr %l66, !tbaa !23
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load %"compiler/source:Span", ptr %l6
  store { i64, [8 x i64] } zeroinitializer, ptr %t126
  %t127 = getelementptr { i64, [8 x i64] }, ptr %t126, i32 0, i32 0
  store i64 4, ptr %t127
  %t129 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t124, 0
  %t131 = insertvalue { %"compiler/source:Span", i32 } %t129, i32 %t122, 1
  %t132 = getelementptr { i64, [8 x i64] }, ptr %t126, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t131, ptr %t132
  %t133 = load { i64, [8 x i64] }, ptr %t126
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t123, { i64, [8 x i64] } %t133)
  br label %bb17
bb17:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load i32, ptr %l9, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t136, i32 %t137)
  br label %bb18
bb18:
  %t140 = load i32, ptr %l10, !tbaa !23
  %t141 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t144 = icmp eq i32 %t140, %t141
  br i1 %t144, label %bb19, label %bb20
bb19:
  store { i64, [4 x i64] } zeroinitializer, ptr %t146
  %t147 = getelementptr { i64, [4 x i64] }, ptr %t146, i32 0, i32 0
  store i64 0, ptr %t147
  %t148 = load { i64, [4 x i64] }, ptr %t146
  store { i64, [4 x i64] } %t148, ptr %l76
  br label %bb22
bb20:
  %t150 = load i32, ptr %l10, !tbaa !23
  %t152 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t150)
  store %"compiler/mir:Lvalue" %t152, ptr %l79
  br label %bb21
bb21:
  store { i64, [4 x i64] } zeroinitializer, ptr %t153
  %t154 = getelementptr { i64, [4 x i64] }, ptr %t153, i32 0, i32 0
  store i64 1, ptr %t154
  %t155 = load %"compiler/mir:Lvalue", ptr %l79
  %t156 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t155, 0
  %t157 = getelementptr { i64, [4 x i64] }, ptr %t153, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t156, ptr %t157
  %t158 = load { i64, [4 x i64] }, ptr %t153
  store { i64, [4 x i64] } %t158, ptr %l76
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t160 = load { i64, [4 x i64] }, ptr %l76
  store { i64, [4 x i64] } %t160, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eifStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca { i64, [4 x i64] }
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca { i64, [4 x i64] }
  %l16 = alloca i32
  %l19 = alloca i32
  %l25 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l39 = alloca ptr
  %s0 = alloca %olang.scope
  %t32 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t4 = getelementptr %"compiler/typed:If", ptr %t2, i32 0, i32 0
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t9 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t1, ptr %t5)
  store { i64, [4 x i64] } %t9, ptr %l11
  br label %bb1
bb1:
  %t10 = load { i64, [4 x i64] }, ptr %l11
  store { i64, [4 x i64] } %t10, ptr %l3
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/lower:lowering", ptr %t11, i32 0, i32 7
  %t14 = load i1, ptr %t13, !tbaa !21
  br i1 %t14, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/lower:lowering", ptr %t16, i32 0, i32 3
  %t20 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t18)
  store i32 %t20, ptr %l16
  br label %bb5
bb5:
  %t21 = load i32, ptr %l16, !tbaa !23
  store i32 %t21, ptr %l4, !tbaa !23
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/lower:lowering", ptr %t22, i32 0, i32 3
  %t26 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t24)
  store i32 %t26, ptr %l19
  br label %bb6
bb6:
  %t27 = load i32, ptr %l19, !tbaa !23
  store i32 %t27, ptr %l5, !tbaa !23
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load { i64, [4 x i64] }, ptr %l3
  %t30 = load i32, ptr %l4, !tbaa !23
  %t31 = load i32, ptr %l5, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t32
  %t33 = getelementptr { i64, [8 x i64] }, ptr %t32, i32 0, i32 0
  store i64 2, ptr %t33
  %t35 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t29, 0
  %t37 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t35, i32 %t30, 1
  %t39 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t37, i32 %t31, 2
  %t40 = getelementptr { i64, [8 x i64] }, ptr %t32, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t39, ptr %t40
  %t41 = load { i64, [8 x i64] }, ptr %t32
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t28, { i64, [8 x i64] } %t41)
  br label %bb7
bb7:
  %t44 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t44, ptr %l25
  br label %bb8
bb8:
  %t45 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l25
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t45, ptr %l6
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t46, i32 %t47)
  br label %bb9
bb9:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load ptr, ptr %l2, !tbaa !29
  %t53 = getelementptr %"compiler/typed:If", ptr %t51, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eblock(ptr %v0, ptr %v1, ptr %t50, ptr %t54)
  br label %bb10
bb10:
  %t57 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleaveOpen(ptr %v0, ptr %s0, ptr %t57, ptr %l6)
  br label %bb11
bb11:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load i32, ptr %l5, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t60, i32 %t61)
  br label %bb12
bb12:
  %t64 = load ptr, ptr %l2, !tbaa !29
  %t66 = getelementptr %"compiler/typed:If", ptr %t64, i32 0, i32 2
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = icmp eq ptr %t67, null
  %t71 = xor i1 %t69, true
  br i1 %t71, label %bb13, label %bb14
bb13:
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l39, !tbaa !29
  %t74 = load ptr, ptr %l2, !tbaa !29
  %t76 = getelementptr %"compiler/typed:If", ptr %t74, i32 0, i32 2
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = icmp eq ptr %t77, null
  br i1 %t79, label %bb15, label %bb16
bb14:
  br label %bb19
bb15:
  call void @__olang_check_failed(ptr @olang_loc_64d900b05c2c7f2b_3f776bda77e5f7cf)
  unreachable
bb16:
  br label %bb17
bb17:
  %t81 = load ptr, ptr %l2, !tbaa !29
  %t83 = getelementptr %"compiler/typed:If", ptr %t81, i32 0, i32 2
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t85 = load ptr, ptr %l39, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eblock(ptr %v0, ptr %v1, ptr %t85, ptr %t84)
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t87 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleaveOpen(ptr %v0, ptr %s0, ptr %t87, ptr %l6)
  br label %bb20
bb20:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l6
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2epatch(ptr %v0, ptr %s0, ptr %t90, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t91)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %a0, i32 %a1, { i64, [15 x i64] } %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca %"compiler/source:Span"
  %l12 = alloca %"compiler/mir:Lvalue"
  %l17 = alloca %"compiler/mir:Lvalue"
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t15 = alloca { i64, [21 x i64] }, align 8
  %t32 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = load %"compiler/source:Span", ptr %l3
  %t7 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t1, i32 %a1, %"compiler/source:Span" %t3)
  store i32 %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load i32, ptr %l8, !tbaa !23
  store i32 %t8, ptr %l4, !tbaa !23
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l9, !tbaa !29
  %t10 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t10, ptr %l10
  %t11 = load i32, ptr %l4, !tbaa !23
  %t13 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t11)
  store %"compiler/mir:Lvalue" %t13, ptr %l12
  br label %bb2
bb2:
  store { i64, [21 x i64] } zeroinitializer, ptr %t15
  %t16 = getelementptr { i64, [21 x i64] }, ptr %t15, i32 0, i32 0
  store i64 0, ptr %t16
  %t17 = load %"compiler/source:Span", ptr %l10
  %t18 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t17, 0
  %t19 = load %"compiler/mir:Lvalue", ptr %l12
  %t20 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t18, %"compiler/mir:Lvalue" %t19, 1
  %t22 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t20, { i64, [15 x i64] } %a2, 2
  %t23 = getelementptr { i64, [21 x i64] }, ptr %t15, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t22, ptr %t23
  %t24 = load { i64, [21 x i64] }, ptr %t15
  %t26 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t24, ptr %t26
  %t27 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t27, ptr %t26)
  br label %bb3
bb3:
  %t29 = load i32, ptr %l4, !tbaa !23
  %t31 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t29)
  store %"compiler/mir:Lvalue" %t31, ptr %l17
  br label %bb4
bb4:
  store { i64, [4 x i64] } zeroinitializer, ptr %t32
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t32, i32 0, i32 0
  store i64 1, ptr %t33
  %t34 = load %"compiler/mir:Lvalue", ptr %l17
  %t35 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t34, 0
  %t36 = getelementptr { i64, [4 x i64] }, ptr %t32, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t35, ptr %t36
  %t37 = load { i64, [4 x i64] }, ptr %t32
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t37, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eisCaseRef(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, { i64, [4 x i64] } %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca { i64, [4 x i64] }
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca { i64, [4 x i64] }
  %l14 = alloca i32
  %l15 = alloca ptr
  %l16 = alloca %"compiler/source:Span"
  %l18 = alloca %"compiler/mir:Lvalue"
  %l21 = alloca { i64, [4 x i64] }
  %l29 = alloca i32
  %l30 = alloca ptr
  %l31 = alloca i32
  %l32 = alloca i32
  %l34 = alloca %"compiler/mir:Lvalue"
  %l38 = alloca { i64, ptr }
  %l40 = alloca { i64, [4 x i64] }
  %l43 = alloca i32
  %l46 = alloca i32
  %l54 = alloca ptr
  %l55 = alloca i32
  %l61 = alloca { i64, ptr }
  %l62 = alloca %"compiler/mir:Lvalue"
  %l65 = alloca { i64, [4 x i64] }
  %l66 = alloca ptr
  %l67 = alloca %"compiler/source:Span"
  %l69 = alloca %"compiler/mir:Lvalue"
  %l70 = alloca i32
  %l71 = alloca i32
  %l73 = alloca ptr
  %l74 = alloca { i64, [4 x i64] }
  %l79 = alloca { i64, [4 x i64] }
  %l80 = alloca { i64, ptr }
  %l81 = alloca %"compiler/mir:Range"
  %l90 = alloca %"compiler/mir:Lvalue"
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t19 = alloca { i64, [15 x i64] }, align 8
  %t25 = alloca { i64, [21 x i64] }, align 8
  %t54 = alloca { i64, [4 x i64] }, align 8
  %t61 = alloca { i64, [4 x i64] }, align 8
  %t104 = alloca { i64, [8 x i64] }, align 8
  %t126 = alloca { i64, [2 x i64] }, align 8
  %t132 = alloca { i64, [1 x i64] }, align 8
  %t147 = alloca { i64, [15 x i64] }, align 8
  %t194 = alloca { i64, [15 x i64] }, align 8
  %t204 = alloca { i64, [21 x i64] }, align 8
  %t229 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t3 = load %"compiler/source:Span", ptr %l4
  %t7 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t1, i32 %t2, %"compiler/source:Span" %t3)
  store i32 %t7, ptr %l14
  br label %bb1
bb1:
  %t8 = load i32, ptr %l14, !tbaa !23
  store i32 %t8, ptr %l5, !tbaa !23
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l15, !tbaa !29
  %t10 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t10, ptr %l16
  %t11 = load i32, ptr %l5, !tbaa !23
  %t13 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t11)
  store %"compiler/mir:Lvalue" %t13, ptr %l18
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load %"compiler/source:Span", ptr %l4
  %t18 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstBool(ptr %v0, ptr %t14, i1 false, %"compiler/source:Span" %t15)
  store { i64, [4 x i64] } %t18, ptr %l21
  br label %bb3
bb3:
  store { i64, [15 x i64] } zeroinitializer, ptr %t19
  %t20 = getelementptr { i64, [15 x i64] }, ptr %t19, i32 0, i32 0
  store i64 0, ptr %t20
  %t21 = load { i64, [4 x i64] }, ptr %l21
  %t22 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t21, 0
  %t23 = getelementptr { i64, [15 x i64] }, ptr %t19, i32 0, i32 1
  store { { i64, [4 x i64] } } %t22, ptr %t23
  %t24 = load { i64, [15 x i64] }, ptr %t19
  store { i64, [21 x i64] } zeroinitializer, ptr %t25
  %t26 = getelementptr { i64, [21 x i64] }, ptr %t25, i32 0, i32 0
  store i64 0, ptr %t26
  %t27 = load %"compiler/source:Span", ptr %l16
  %t28 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t27, 0
  %t29 = load %"compiler/mir:Lvalue", ptr %l18
  %t30 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t28, %"compiler/mir:Lvalue" %t29, 1
  %t32 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t30, { i64, [15 x i64] } %t24, 2
  %t33 = getelementptr { i64, [21 x i64] }, ptr %t25, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t32, ptr %t33
  %t34 = load { i64, [21 x i64] }, ptr %t25
  %t36 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t34, ptr %t36
  %t37 = load ptr, ptr %l15, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t37, ptr %t36)
  br label %bb4
bb4:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l2, !tbaa !23
  %t42 = load %"compiler/source:Span", ptr %l4
  %t47 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %t39, { i64, [4 x i64] } %a1, i32 %t41, %"compiler/source:Span" %t42)
  store i32 %t47, ptr %l29
  br label %bb5
bb5:
  %t48 = load i32, ptr %l29, !tbaa !23
  store i32 %t48, ptr %l6, !tbaa !23
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l30, !tbaa !29
  store i32 14, ptr %l31
  %t50 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t50, ptr %l32, !tbaa !23
  %t51 = load i32, ptr %l6, !tbaa !23
  %t53 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t51)
  store %"compiler/mir:Lvalue" %t53, ptr %l34
  br label %bb6
bb6:
  store { i64, [4 x i64] } zeroinitializer, ptr %t54
  %t55 = getelementptr { i64, [4 x i64] }, ptr %t54, i32 0, i32 0
  store i64 1, ptr %t55
  %t56 = load %"compiler/mir:Lvalue", ptr %l34
  %t57 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t56, 0
  %t58 = getelementptr { i64, [4 x i64] }, ptr %t54, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t57, ptr %t58
  %t59 = load { i64, [4 x i64] }, ptr %t54
  %t60 = load i32, ptr %l2, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t61
  %t62 = getelementptr { i64, [4 x i64] }, ptr %t61, i32 0, i32 0
  store i64 2, ptr %t62
  %t64 = insertvalue { i32, i64 } undef, i32 %t60, 0
  %t65 = insertvalue { i32, i64 } %t64, i64 0, 1
  %t66 = getelementptr { i64, [4 x i64] }, ptr %t61, i32 0, i32 1
  store { i32, i64 } %t65, ptr %t66
  %t67 = load { i64, [4 x i64] }, ptr %t61
  %t68 = mul i64 2, 40
  %t69 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t68)
  %t70 = insertvalue { i64, ptr } undef, i64 2, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t69, 1
  store { i64, ptr } %t71, ptr %l38, !tbaa !27
  %t73 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr { i64, [4 x i64] }, ptr %t74, i64 0
  store { i64, [4 x i64] } %t59, ptr %t75
  %t77 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr { i64, [4 x i64] }, ptr %t78, i64 1
  store { i64, [4 x i64] } %t67, ptr %t79
  %t80 = load %"compiler/source:Span", ptr %l4
  %t81 = load ptr, ptr %l30, !tbaa !29
  %t82 = load i32, ptr %l31
  %t83 = load i32, ptr %l32, !tbaa !23
  %t84 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t86 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %t81, i32 %t82, i32 %t83, { i64, ptr } %t84, %"compiler/source:Span" %t80)
  store { i64, [4 x i64] } %t86, ptr %l40
  br label %bb7
bb7:
  %t87 = load { i64, [4 x i64] }, ptr %l40
  store { i64, [4 x i64] } %t87, ptr %l7
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/lower:lowering", ptr %t88, i32 0, i32 3
  %t92 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t90)
  store i32 %t92, ptr %l43
  br label %bb8
bb8:
  %t93 = load i32, ptr %l43, !tbaa !23
  store i32 %t93, ptr %l8, !tbaa !23
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/lower:lowering", ptr %t94, i32 0, i32 3
  %t98 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t96)
  store i32 %t98, ptr %l46
  br label %bb9
bb9:
  %t99 = load i32, ptr %l46, !tbaa !23
  store i32 %t99, ptr %l9, !tbaa !23
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load { i64, [4 x i64] }, ptr %l7
  %t102 = load i32, ptr %l8, !tbaa !23
  %t103 = load i32, ptr %l9, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t104
  %t105 = getelementptr { i64, [8 x i64] }, ptr %t104, i32 0, i32 0
  store i64 2, ptr %t105
  %t107 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t101, 0
  %t109 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t107, i32 %t102, 1
  %t111 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t109, i32 %t103, 2
  %t112 = getelementptr { i64, [8 x i64] }, ptr %t104, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t111, ptr %t112
  %t113 = load { i64, [8 x i64] }, ptr %t104
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t100, { i64, [8 x i64] } %t113)
  br label %bb10
bb10:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load i32, ptr %l8, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t116, i32 %t117)
  br label %bb11
bb11:
  %t120 = load ptr, ptr %l0, !tbaa !29
  store ptr %t120, ptr %l54, !tbaa !29
  %t121 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t121, ptr %l55, !tbaa !23
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/lower:lowering", ptr %t122, i32 0, i32 3
  %t125 = load i32, ptr %l6, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t126
  %t127 = getelementptr { i64, [2 x i64] }, ptr %t126, i32 0, i32 0
  store i64 1, ptr %t127
  %t129 = insertvalue { i32 } undef, i32 %t125, 0
  %t130 = getelementptr { i64, [2 x i64] }, ptr %t126, i32 0, i32 1
  store { i32 } %t129, ptr %t130
  %t131 = load { i64, [2 x i64] }, ptr %t126
  store { i64, [1 x i64] } zeroinitializer, ptr %t132
  %t133 = getelementptr { i64, [1 x i64] }, ptr %t132, i32 0, i32 0
  store i64 3, ptr %t133
  %t134 = load { i64, [1 x i64] }, ptr %t132
  %t135 = mul i64 1, 16
  %t136 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t135)
  %t137 = insertvalue { i64, ptr } undef, i64 1, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t136, 1
  store { i64, ptr } %t138, ptr %l61, !tbaa !27
  %t140 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !27
  %t142 = getelementptr { i64, [1 x i64] }, ptr %t141, i64 0
  store { i64, [1 x i64] } %t134, ptr %t142
  %t145 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t146 = call %"compiler/mir:Lvalue" @compiler_2fmir_2ecompiler_2fmir_3aFn_2ePlace(ptr %v0, ptr %s0, ptr %t124, { i64, [2 x i64] } %t131, { i64, ptr } %t145)
  store %"compiler/mir:Lvalue" %t146, ptr %l62
  br label %bb12
bb12:
  store { i64, [15 x i64] } zeroinitializer, ptr %t147
  %t148 = getelementptr { i64, [15 x i64] }, ptr %t147, i32 0, i32 0
  store i64 5, ptr %t148
  %t149 = load %"compiler/mir:Lvalue", ptr %l62
  %t150 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t149, 0
  %t151 = getelementptr { i64, [15 x i64] }, ptr %t147, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t150, ptr %t151
  %t152 = load { i64, [15 x i64] }, ptr %t147
  %t153 = load %"compiler/source:Span", ptr %l4
  %t154 = load ptr, ptr %l54, !tbaa !29
  %t155 = load i32, ptr %l55, !tbaa !23
  %t158 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t154, i32 %t155, { i64, [15 x i64] } %t152, %"compiler/source:Span" %t153)
  store { i64, [4 x i64] } %t158, ptr %l65
  br label %bb13
bb13:
  %t159 = load { i64, [4 x i64] }, ptr %l65
  store { i64, [4 x i64] } %t159, ptr %l10
  %t160 = load ptr, ptr %l0, !tbaa !29
  store ptr %t160, ptr %l66, !tbaa !29
  %t161 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t161, ptr %l67
  %t162 = load i32, ptr %l5, !tbaa !23
  %t164 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t162)
  store %"compiler/mir:Lvalue" %t164, ptr %l69
  br label %bb14
bb14:
  store i32 13, ptr %l70
  %t165 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t165, ptr %l71, !tbaa !23
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/lower:lowering", ptr %t166, i32 0, i32 3
  store ptr %t168, ptr %l73, !tbaa !29
  %t169 = load { i64, [4 x i64] }, ptr %l10
  store { i64, [4 x i64] } %t169, ptr %l74
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t173 = load %"compiler/source:Span", ptr %l4
  %t178 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2easI64(ptr %v0, ptr %t170, { i64, [4 x i64] } %a3, i32 %t172, %"compiler/source:Span" %t173)
  store { i64, [4 x i64] } %t178, ptr %l79
  br label %bb15
bb15:
  %t179 = mul i64 2, 40
  %t180 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t179)
  %t181 = insertvalue { i64, ptr } undef, i64 2, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t180, 1
  store { i64, ptr } %t182, ptr %l80, !tbaa !27
  %t183 = load { i64, [4 x i64] }, ptr %l74
  %t184 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !27
  %t186 = getelementptr { i64, [4 x i64] }, ptr %t185, i64 0
  store { i64, [4 x i64] } %t183, ptr %t186
  %t187 = load { i64, [4 x i64] }, ptr %l79
  %t188 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = getelementptr { i64, [4 x i64] }, ptr %t189, i64 1
  store { i64, [4 x i64] } %t187, ptr %t190
  %t191 = load ptr, ptr %l73, !tbaa !29
  %t192 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t193 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %s0, ptr %t191, { i64, ptr } %t192)
  store %"compiler/mir:Range" %t193, ptr %l81
  br label %bb16
bb16:
  store { i64, [15 x i64] } zeroinitializer, ptr %t194
  %t195 = getelementptr { i64, [15 x i64] }, ptr %t194, i32 0, i32 0
  store i64 3, ptr %t195
  %t196 = load i32, ptr %l70
  %t197 = insertvalue { i32, i32, %"compiler/mir:Range" } undef, i32 %t196, 0
  %t198 = load i32, ptr %l71, !tbaa !23
  %t199 = insertvalue { i32, i32, %"compiler/mir:Range" } %t197, i32 %t198, 1
  %t200 = load %"compiler/mir:Range", ptr %l81
  %t201 = insertvalue { i32, i32, %"compiler/mir:Range" } %t199, %"compiler/mir:Range" %t200, 2
  %t202 = getelementptr { i64, [15 x i64] }, ptr %t194, i32 0, i32 1
  store { i32, i32, %"compiler/mir:Range" } %t201, ptr %t202
  %t203 = load { i64, [15 x i64] }, ptr %t194
  store { i64, [21 x i64] } zeroinitializer, ptr %t204
  %t205 = getelementptr { i64, [21 x i64] }, ptr %t204, i32 0, i32 0
  store i64 0, ptr %t205
  %t206 = load %"compiler/source:Span", ptr %l67
  %t207 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t206, 0
  %t208 = load %"compiler/mir:Lvalue", ptr %l69
  %t209 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t207, %"compiler/mir:Lvalue" %t208, 1
  %t211 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t209, { i64, [15 x i64] } %t203, 2
  %t212 = getelementptr { i64, [21 x i64] }, ptr %t204, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t211, ptr %t212
  %t213 = load { i64, [21 x i64] }, ptr %t204
  %t215 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t213, ptr %t215
  %t216 = load ptr, ptr %l66, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t216, ptr %t215)
  br label %bb17
bb17:
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t219 = load i32, ptr %l9, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t218, i32 %t219)
  br label %bb18
bb18:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t223 = load i32, ptr %l9, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t222, i32 %t223)
  br label %bb19
bb19:
  %t226 = load i32, ptr %l5, !tbaa !23
  %t228 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t226)
  store %"compiler/mir:Lvalue" %t228, ptr %l90
  br label %bb20
bb20:
  store { i64, [4 x i64] } zeroinitializer, ptr %t229
  %t230 = getelementptr { i64, [4 x i64] }, ptr %t229, i32 0, i32 0
  store i64 1, ptr %t230
  %t231 = load %"compiler/mir:Lvalue", ptr %l90
  %t232 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t231, 0
  %t233 = getelementptr { i64, [4 x i64] }, ptr %t229, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t232, ptr %t233
  %t234 = load { i64, [4 x i64] }, ptr %t229
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t234, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2elambda(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i32 %a3, i32 %a4, %"compiler/source:Span" %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i1
  %l7 = alloca { i64, [1 x i64] }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l21 = alloca ptr
  %l27 = alloca { i64, [1 x i64] }
  %l31 = alloca { i64, [1 x i64] }
  %l34 = alloca { i64, [1 x i64] }
  %l36 = alloca i64
  %l45 = alloca i64
  %l48 = alloca i64
  %l66 = alloca i64
  %l68 = alloca { i64, ptr }
  %l73 = alloca { i64, [4 x i64] }
  %l74 = alloca { i64, ptr }
  %l78 = alloca i32
  %l80 = alloca i1
  %l84 = alloca i1
  %l87 = alloca i1
  %l88 = alloca i64
  %l95 = alloca { i64, [4 x i64] }
  %l101 = alloca ptr
  %l102 = alloca i32
  %l104 = alloca { i64, [2 x i64] }
  %l105 = alloca i32
  %l106 = alloca { i64, [1 x i64] }
  %l110 = alloca %"compiler/mir:Range"
  %l113 = alloca %"compiler/mir:Range"
  %l116 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t24 = alloca { i64, [1 x i64] }, align 8
  %t188 = alloca { i64, [4 x i64] }, align 8
  %t195 = alloca { i64, [2 x i64] }, align 8
  %t215 = alloca { i64, [15 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i32 %a3, ptr %l3
  store i32 %a4, ptr %l4
  store %"compiler/source:Span" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/lower:Lowerer", ptr %t4, i32 0, i32 1
  %t7 = load i32, ptr %l1, !tbaa !23
  %t9 = sext i32 %t7 to i64
  %t12 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t6, i64 %t9)
  store ptr %t12, ptr %l21
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l21, !tbaa !29
  %t15 = getelementptr %"compiler/typed:Body", ptr %t13, i32 0, i32 15
  %t16 = load i1, ptr %t15, !tbaa !21
  store i1 %t16, ptr %l6, !tbaa !21
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  %t22 = icmp eq i64 %t20, 0
  br i1 %t22, label %bb2, label %bb3
bb2:
  store { i64, [1 x i64] } zeroinitializer, ptr %t24
  %t25 = getelementptr { i64, [1 x i64] }, ptr %t24, i32 0, i32 0
  store i64 3, ptr %t25
  %t26 = load { i64, [1 x i64] }, ptr %t24
  store { i64, [1 x i64] } %t26, ptr %l27
  br label %bb5
bb3:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l3, !tbaa !23
  %t32 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ebuilt(ptr %v0, ptr %t28, i32 %t29)
  store { i64, [1 x i64] } %t32, ptr %l31
  br label %bb4
bb4:
  %t33 = load { i64, [1 x i64] }, ptr %l31
  store { i64, [1 x i64] } %t33, ptr %l27
  br label %bb5
bb5:
  %t34 = load { i64, [1 x i64] }, ptr %l27
  store { i64, [1 x i64] } %t34, ptr %l7
  %t35 = load i1, ptr %l6, !tbaa !21
  br i1 %t35, label %bb6, label %bb7
bb6:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eresultScope(ptr %v0, ptr %t37)
  store { i64, [1 x i64] } %t39, ptr %l34
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t40 = load { i64, [1 x i64] }, ptr %l34
  store { i64, [1 x i64] } %t40, ptr %l7
  br label %bb9
bb9:
  %t41 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  store i64 %t43, ptr %l36, !tbaa !24
  %t44 = load i64, ptr %l36, !tbaa !24
  %t45 = icmp sge i64 %t44, 0
  br i1 %t45, label %bb10, label %bb11
bb10:
  %t47 = load i64, ptr %l36, !tbaa !24
  %t48 = icmp sle i64 %t47, 230584300921369395
  br i1 %t48, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_8dbdd81ef51b3d23_89b419ac5748f287)
  unreachable
bb12:
  %t50 = load i64, ptr %l36, !tbaa !24
  %t51 = mul i64 %t50, 40
  %t52 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t51)
  %t53 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  store { i64, ptr } %t54, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t56 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t56, 0
  store i64 %t58, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t60 = load i64, ptr %l10, !tbaa !24
  %t61 = load i64, ptr %l9, !tbaa !24
  %t64 = icmp sgt i64 %t60, %t61
  br i1 %t64, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_8dbdd81ef51b3d23_89b419ac5748f287)
  unreachable
bb14:
  %t66 = load i64, ptr %l11, !tbaa !24
  %t68 = icmp sgt i64 %t66, 0
  br i1 %t68, label %bb16, label %bb17
bb15:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb19
bb16:
  %t70 = load i64, ptr %l10, !tbaa !24
  %t71 = load i64, ptr %l9, !tbaa !24
  %t74 = sub i64 %t70, %t71
  %t75 = load i64, ptr %l11, !tbaa !24
  %t78 = add i64 %t74, %t75
  %t80 = sub i64 %t78, 1
  %t81 = load i64, ptr %l11, !tbaa !24
  %t84 = sdiv i64 %t80, %t81
  store i64 %t84, ptr %l48, !tbaa !24
  br label %bb18
bb17:
  store i64 0, ptr %l48, !tbaa !24
  br label %bb18
bb18:
  %t86 = load i64, ptr %l48, !tbaa !24
  store i64 %t86, ptr %l45, !tbaa !24
  br label %bb19
bb19:
  %t87 = load i64, ptr %l45, !tbaa !24
  store i64 %t87, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb20
bb20:
  %t88 = load i64, ptr %l13, !tbaa !24
  %t89 = load i64, ptr %l12, !tbaa !24
  %t92 = icmp slt i64 %t88, %t89
  %t94 = xor i1 %t92, true
  br i1 %t94, label %bb21, label %bb22
bb21:
  br label %bb38
bb22:
  br label %bb23
bb23:
  %t96 = load i64, ptr %l9, !tbaa !24
  %t97 = load i64, ptr %l13, !tbaa !24
  %t98 = load i64, ptr %l11, !tbaa !24
  %t101 = mul i64 %t97, %t98
  %t104 = add i64 %t96, %t101
  store i64 %t104, ptr %l14, !tbaa !24
  %t106 = load i64, ptr %l14, !tbaa !24
  store i64 %t106, ptr %l66, !tbaa !24
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t108, ptr %l68, !tbaa !27
  %t109 = load i64, ptr %l14, !tbaa !24
  %t111 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr ptr, ptr %t112, i64 %t109
  %t114 = load ptr, ptr %t113, !tbaa !39
  %t116 = getelementptr %"compiler/typed:Capture", ptr %t114, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !29
  %t121 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t107, ptr %t117)
  store { i64, [4 x i64] } %t121, ptr %l73
  br label %bb24
bb24:
  %t122 = load { i64, [4 x i64] }, ptr %l73
  %t123 = load i64, ptr %l66, !tbaa !24
  %t124 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr { i64, [4 x i64] }, ptr %t125, i64 %t123
  store { i64, [4 x i64] } %t122, ptr %t126
  %t127 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t127, ptr %l74, !tbaa !27
  %t128 = load i64, ptr %l14, !tbaa !24
  %t130 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr ptr, ptr %t131, i64 %t128
  %t133 = load ptr, ptr %t132, !tbaa !39
  %t135 = getelementptr %"compiler/typed:Capture", ptr %t133, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !29
  %t138 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t136)
  store i32 %t138, ptr %l78
  br label %bb25
bb25:
  %t139 = load i32, ptr %l78, !tbaa !23
  store i32 %t139, ptr %l15, !tbaa !23
  %t140 = load i1, ptr %l6, !tbaa !21
  br i1 %t140, label %bb26, label %bb27
bb26:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/lower:lowering", ptr %t142, i32 0, i32 7
  %t145 = load i1, ptr %t144, !tbaa !21
  %t147 = xor i1 %t145, true
  store i1 %t147, ptr %l80, !tbaa !21
  br label %bb28
bb27:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb28
bb28:
  %t149 = load i1, ptr %l80, !tbaa !21
  br i1 %t149, label %bb29, label %bb30
bb29:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load i32, ptr %l15, !tbaa !23
  %t154 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2evalueArray(ptr %v0, ptr %t150, i32 %t151)
  store i1 %t154, ptr %l87
  br label %bb31
bb30:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb32
bb31:
  %t155 = load i1, ptr %l87, !tbaa !21
  store i1 %t155, ptr %l84, !tbaa !21
  br label %bb32
bb32:
  %t156 = load i1, ptr %l84, !tbaa !21
  br i1 %t156, label %bb33, label %bb34
bb33:
  %t157 = load i64, ptr %l14, !tbaa !24
  store i64 %t157, ptr %l88, !tbaa !24
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load i64, ptr %l14, !tbaa !24
  %t161 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !27
  %t163 = getelementptr { i64, [4 x i64] }, ptr %t162, i64 %t159
  %t164 = load { i64, [4 x i64] }, ptr %t163
  %t165 = load i32, ptr %l15, !tbaa !23
  %t166 = load %"compiler/source:Span", ptr %l5
  %t167 = load { i64, [1 x i64] }, ptr %l7
  %t173 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2earrayCopy(ptr %v0, ptr %t158, { i64, [4 x i64] } %t164, i32 %t165, %"compiler/source:Span" %t166, { i64, [1 x i64] } %t167)
  store { i64, [4 x i64] } %t173, ptr %l95
  br label %bb35
bb34:
  br label %bb36
bb35:
  %t174 = load { i64, [4 x i64] }, ptr %l95
  %t175 = load i64, ptr %l88, !tbaa !24
  %t176 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr { i64, [4 x i64] }, ptr %t177, i64 %t175
  store { i64, [4 x i64] } %t174, ptr %t178
  br label %bb36
bb36:
  br label %bb37
bb37:
  %t179 = load i64, ptr %l13, !tbaa !24
  %t181 = add i64 %t179, 1
  store i64 %t181, ptr %l13, !tbaa !24
  br label %bb20
bb38:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/lower:lowering", ptr %t183, i32 0, i32 7
  %t186 = load i1, ptr %t185, !tbaa !21
  br i1 %t186, label %bb39, label %bb40
bb39:
  store { i64, [4 x i64] } zeroinitializer, ptr %t188
  %t189 = getelementptr { i64, [4 x i64] }, ptr %t188, i32 0, i32 0
  store i64 0, ptr %t189
  %t190 = load { i64, [4 x i64] }, ptr %t188
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t190, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  %t192 = load ptr, ptr %l0, !tbaa !29
  store ptr %t192, ptr %l101, !tbaa !29
  %t193 = load i32, ptr %l4, !tbaa !23
  store i32 %t193, ptr %l102, !tbaa !23
  %t194 = load i32, ptr %l1, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t195
  %t196 = getelementptr { i64, [2 x i64] }, ptr %t195, i32 0, i32 0
  store i64 0, ptr %t196
  %t198 = insertvalue { i32 } undef, i32 %t194, 0
  %t199 = getelementptr { i64, [2 x i64] }, ptr %t195, i32 0, i32 1
  store { i32 } %t198, ptr %t199
  %t200 = load { i64, [2 x i64] }, ptr %t195
  store { i64, [2 x i64] } %t200, ptr %l104
  %t201 = load i32, ptr %l4, !tbaa !23
  store i32 %t201, ptr %l105, !tbaa !23
  %t202 = load { i64, [1 x i64] }, ptr %l7
  store { i64, [1 x i64] } %t202, ptr %l106
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"compiler/lower:lowering", ptr %t203, i32 0, i32 3
  %t206 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t209 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %s0, ptr %t205, { i64, ptr } %t206)
  store %"compiler/mir:Range" %t209, ptr %l110
  br label %bb42
bb42:
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t211 = load i32, ptr %l3, !tbaa !23
  %t214 = call %"compiler/mir:Range" @compiler_2flower_2ecompiler_2flower_3alowering_2ecapScopes(ptr %v0, ptr %t210, i32 %t211)
  store %"compiler/mir:Range" %t214, ptr %l113
  br label %bb43
bb43:
  store { i64, [15 x i64] } zeroinitializer, ptr %t215
  %t216 = getelementptr { i64, [15 x i64] }, ptr %t215, i32 0, i32 0
  store i64 10, ptr %t216
  %t217 = load { i64, [2 x i64] }, ptr %l104
  %t218 = insertvalue { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" } undef, { i64, [2 x i64] } %t217, 0
  %t219 = load i32, ptr %l105, !tbaa !23
  %t220 = insertvalue { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" } %t218, i32 %t219, 1
  %t221 = load { i64, [1 x i64] }, ptr %l106
  %t222 = insertvalue { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" } %t220, { i64, [1 x i64] } %t221, 2
  %t223 = load %"compiler/mir:Range", ptr %l110
  %t224 = insertvalue { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" } %t222, %"compiler/mir:Range" %t223, 3
  %t225 = load %"compiler/mir:Range", ptr %l113
  %t226 = insertvalue { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" } %t224, %"compiler/mir:Range" %t225, 4
  %t227 = getelementptr { i64, [15 x i64] }, ptr %t215, i32 0, i32 1
  store { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" } %t226, ptr %t227
  %t228 = load { i64, [15 x i64] }, ptr %t215
  %t229 = load %"compiler/source:Span", ptr %l5
  %t230 = load ptr, ptr %l101, !tbaa !29
  %t231 = load i32, ptr %l102, !tbaa !23
  %t234 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t230, i32 %t231, { i64, [15 x i64] } %t228, %"compiler/source:Span" %t229)
  store { i64, [4 x i64] } %t234, ptr %l116
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s0)
  %t235 = load { i64, [4 x i64] }, ptr %l116
  store { i64, [4 x i64] } %t235, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2emake(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %l8 = alloca { i64, [4 x i64] }
  %l20 = alloca { i64, ptr }
  %l27 = alloca i1
  %l30 = alloca i1
  %l33 = alloca i32
  %l34 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca i32
  %l38 = alloca i64
  %l42 = alloca %"compiler/mir:Range"
  %l45 = alloca { i64, [4 x i64] }
  %l46 = alloca ptr
  %l47 = alloca i32
  %l51 = alloca { i64, [1 x i64] }
  %l56 = alloca { i64, [4 x i64] }
  %l57 = alloca ptr
  %l58 = alloca i32
  %l59 = alloca i32
  %l61 = alloca i64
  %l65 = alloca %"compiler/mir:Range"
  %l68 = alloca { i64, [4 x i64] }
  %l76 = alloca { i64, [4 x i64] }
  %l84 = alloca { i64, [4 x i64] }
  %s1 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t35 = alloca { i64, [4 x i64] }, align 8
  %t73 = alloca { i64, [15 x i64] }, align 8
  %t102 = alloca { i64, [15 x i64] }, align 8
  %t133 = alloca { i64, [15 x i64] }, align 8
  %t159 = alloca { i64, [1 x i64] }, align 8
  %t178 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Make", ptr %t6, i32 0, i32 0
  %t9 = load i32, ptr %t8
  store i32 %t9, ptr %l5
  %t11 = load i32, ptr %l5
  %t13 = trunc i64 0 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb1, label %bb2
bb1:
  br label %bb5
bb2:
  %t16 = load i32, ptr %l5
  %t18 = trunc i64 1 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb24
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Make", ptr %t22, i32 0, i32 2
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  %t28 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2evals(ptr %v0, ptr %v1, ptr %s1, ptr %t21, { i64, ptr } %t25)
  store { i64, ptr } %t28, ptr %l20
  br label %bb6
bb6:
  %t29 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t29, ptr %l6, !tbaa !27
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/lower:lowering", ptr %t30, i32 0, i32 7
  %t33 = load i1, ptr %t32, !tbaa !21
  br i1 %t33, label %bb7, label %bb8
bb7:
  store { i64, [4 x i64] } zeroinitializer, ptr %t35
  %t36 = getelementptr { i64, [4 x i64] }, ptr %t35, i32 0, i32 0
  store i64 0, ptr %t36
  %t37 = load { i64, [4 x i64] }, ptr %t35
  call void @__olang_scope_close(ptr %s1)
  store { i64, [4 x i64] } %t37, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Make", ptr %t39, i32 0, i32 4
  %t42 = load i32, ptr %t41, !tbaa !23
  %t44 = icmp sge i32 %t42, 0
  br i1 %t44, label %bb10, label %bb11
bb10:
  %t46 = load ptr, ptr %l4, !tbaa !29
  %t47 = load i32, ptr %l2, !tbaa !23
  %t50 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t46, i32 %t47)
  store i1 %t50, ptr %l30
  br label %bb12
bb11:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb13
bb12:
  %t51 = load i1, ptr %l30, !tbaa !21
  store i1 %t51, ptr %l27, !tbaa !21
  br label %bb13
bb13:
  %t52 = load i1, ptr %l27, !tbaa !21
  br i1 %t52, label %bb14, label %bb15
bb14:
  %t53 = load ptr, ptr %l4, !tbaa !29
  %t54 = load i32, ptr %l2, !tbaa !23
  %t57 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t53, i32 %t54)
  store i32 %t57, ptr %l33
  br label %bb16
bb15:
  br label %bb21
bb16:
  %t58 = load i32, ptr %l33, !tbaa !23
  store i32 %t58, ptr %l7, !tbaa !23
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l34, !tbaa !29
  %t60 = load i32, ptr %l7, !tbaa !23
  store i32 %t60, ptr %l35, !tbaa !23
  %t61 = load i32, ptr %l7, !tbaa !23
  store i32 %t61, ptr %l36, !tbaa !23
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr %"compiler/typed:Make", ptr %t62, i32 0, i32 1
  %t65 = load i64, ptr %t64, !tbaa !24
  store i64 %t65, ptr %l38, !tbaa !24
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/lower:lowering", ptr %t66, i32 0, i32 3
  %t69 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t72 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %s1, ptr %t68, { i64, ptr } %t69)
  store %"compiler/mir:Range" %t72, ptr %l42
  br label %bb17
bb17:
  store { i64, [15 x i64] } zeroinitializer, ptr %t73
  %t74 = getelementptr { i64, [15 x i64] }, ptr %t73, i32 0, i32 0
  store i64 6, ptr %t74
  %t75 = load i32, ptr %l36, !tbaa !23
  %t76 = insertvalue { i32, i64, %"compiler/mir:Range" } undef, i32 %t75, 0
  %t77 = load i64, ptr %l38, !tbaa !24
  %t78 = insertvalue { i32, i64, %"compiler/mir:Range" } %t76, i64 %t77, 1
  %t79 = load %"compiler/mir:Range", ptr %l42
  %t80 = insertvalue { i32, i64, %"compiler/mir:Range" } %t78, %"compiler/mir:Range" %t79, 2
  %t81 = getelementptr { i64, [15 x i64] }, ptr %t73, i32 0, i32 1
  store { i32, i64, %"compiler/mir:Range" } %t80, ptr %t81
  %t82 = load { i64, [15 x i64] }, ptr %t73
  %t83 = load %"compiler/source:Span", ptr %l3
  %t84 = load ptr, ptr %l34, !tbaa !29
  %t85 = load i32, ptr %l35, !tbaa !23
  %t88 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t84, i32 %t85, { i64, [15 x i64] } %t82, %"compiler/source:Span" %t83)
  store { i64, [4 x i64] } %t88, ptr %l45
  br label %bb18
bb18:
  %t89 = load { i64, [4 x i64] }, ptr %l45
  store { i64, [4 x i64] } %t89, ptr %l8
  %t90 = load ptr, ptr %l0, !tbaa !29
  store ptr %t90, ptr %l46, !tbaa !29
  %t91 = load i32, ptr %l2, !tbaa !23
  store i32 %t91, ptr %l47, !tbaa !23
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load ptr, ptr %l1, !tbaa !29
  %t95 = getelementptr %"compiler/typed:Make", ptr %t93, i32 0, i32 4
  %t96 = load i32, ptr %t95, !tbaa !23
  %t99 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ebuilt(ptr %v0, ptr %t92, i32 %t96)
  store { i64, [1 x i64] } %t99, ptr %l51
  br label %bb19
bb19:
  %t100 = load { i64, [4 x i64] }, ptr %l8
  %t101 = load i32, ptr %l2, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t102
  %t103 = getelementptr { i64, [15 x i64] }, ptr %t102, i32 0, i32 0
  store i64 7, ptr %t103
  %t104 = load { i64, [1 x i64] }, ptr %l51
  %t105 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } undef, { i64, [1 x i64] } %t104, 0
  %t107 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t105, { i64, [4 x i64] } %t100, 1
  %t109 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t107, i32 %t101, 2
  %t110 = getelementptr { i64, [15 x i64] }, ptr %t102, i32 0, i32 1
  store { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t109, ptr %t110
  %t111 = load { i64, [15 x i64] }, ptr %t102
  %t112 = load %"compiler/source:Span", ptr %l3
  %t113 = load ptr, ptr %l46, !tbaa !29
  %t114 = load i32, ptr %l47, !tbaa !23
  %t117 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t113, i32 %t114, { i64, [15 x i64] } %t111, %"compiler/source:Span" %t112)
  store { i64, [4 x i64] } %t117, ptr %l56
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s1)
  %t118 = load { i64, [4 x i64] }, ptr %l56
  store { i64, [4 x i64] } %t118, ptr %rv
  br label %ret
bb21:
  %t119 = load ptr, ptr %l0, !tbaa !29
  store ptr %t119, ptr %l57, !tbaa !29
  %t120 = load i32, ptr %l2, !tbaa !23
  store i32 %t120, ptr %l58, !tbaa !23
  %t121 = load i32, ptr %l2, !tbaa !23
  store i32 %t121, ptr %l59, !tbaa !23
  %t122 = load ptr, ptr %l1, !tbaa !29
  %t124 = getelementptr %"compiler/typed:Make", ptr %t122, i32 0, i32 1
  %t125 = load i64, ptr %t124, !tbaa !24
  store i64 %t125, ptr %l61, !tbaa !24
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/lower:lowering", ptr %t126, i32 0, i32 3
  %t129 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t132 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %s1, ptr %t128, { i64, ptr } %t129)
  store %"compiler/mir:Range" %t132, ptr %l65
  br label %bb22
bb22:
  store { i64, [15 x i64] } zeroinitializer, ptr %t133
  %t134 = getelementptr { i64, [15 x i64] }, ptr %t133, i32 0, i32 0
  store i64 6, ptr %t134
  %t135 = load i32, ptr %l59, !tbaa !23
  %t136 = insertvalue { i32, i64, %"compiler/mir:Range" } undef, i32 %t135, 0
  %t137 = load i64, ptr %l61, !tbaa !24
  %t138 = insertvalue { i32, i64, %"compiler/mir:Range" } %t136, i64 %t137, 1
  %t139 = load %"compiler/mir:Range", ptr %l65
  %t140 = insertvalue { i32, i64, %"compiler/mir:Range" } %t138, %"compiler/mir:Range" %t139, 2
  %t141 = getelementptr { i64, [15 x i64] }, ptr %t133, i32 0, i32 1
  store { i32, i64, %"compiler/mir:Range" } %t140, ptr %t141
  %t142 = load { i64, [15 x i64] }, ptr %t133
  %t143 = load %"compiler/source:Span", ptr %l3
  %t144 = load ptr, ptr %l57, !tbaa !29
  %t145 = load i32, ptr %l58, !tbaa !23
  %t148 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t144, i32 %t145, { i64, [15 x i64] } %t142, %"compiler/source:Span" %t143)
  store { i64, [4 x i64] } %t148, ptr %l68
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s1)
  %t149 = load { i64, [4 x i64] }, ptr %l68
  store { i64, [4 x i64] } %t149, ptr %rv
  br label %ret
bb24:
  %t150 = load i32, ptr %l5
  %t152 = trunc i64 2 to i32
  %t153 = icmp eq i32 %t150, %t152
  br i1 %t153, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load ptr, ptr %l1, !tbaa !29
  %t157 = load i32, ptr %l2, !tbaa !23
  %t158 = load %"compiler/source:Span", ptr %l3
  store { i64, [1 x i64] } zeroinitializer, ptr %t159
  %t160 = getelementptr { i64, [1 x i64] }, ptr %t159, i32 0, i32 0
  store i64 2, ptr %t160
  %t161 = load { i64, [1 x i64] }, ptr %t159
  %t167 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2earrayLit(ptr %v0, ptr %v1, ptr %t155, ptr %t156, i32 %t157, %"compiler/source:Span" %t158, i1 false, { i64, [1 x i64] } %t161)
  store { i64, [4 x i64] } %t167, ptr %l76
  br label %bb28
bb28:
  %t168 = load { i64, [4 x i64] }, ptr %l76
  store { i64, [4 x i64] } %t168, ptr %rv
  br label %ret
bb29:
  %t169 = load i32, ptr %l5
  %t171 = trunc i64 3 to i32
  %t172 = icmp eq i32 %t169, %t171
  br i1 %t172, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb34
bb32:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load ptr, ptr %l1, !tbaa !29
  %t176 = load i32, ptr %l2, !tbaa !23
  %t177 = load %"compiler/source:Span", ptr %l3
  store { i64, [1 x i64] } zeroinitializer, ptr %t178
  %t179 = getelementptr { i64, [1 x i64] }, ptr %t178, i32 0, i32 0
  store i64 2, ptr %t179
  %t180 = load { i64, [1 x i64] }, ptr %t178
  %t186 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2efill(ptr %v0, ptr %v1, ptr %t174, ptr %t175, i32 %t176, %"compiler/source:Span" %t177, i1 false, { i64, [1 x i64] } %t180)
  store { i64, [4 x i64] } %t186, ptr %l84
  br label %bb33
bb33:
  %t187 = load { i64, [4 x i64] }, ptr %l84
  store { i64, [4 x i64] } %t187, ptr %rv
  br label %ret
bb34:
  call void @__olang_check_failed(ptr @olang_loc_c00faf6434efe24b_96f261c8870620df)
  unreachable
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local i64 @compiler_2flower_2ecompiler_2flower_3alowering_2emethodBody(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca { i64, [2 x i64] }
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l29 = alloca i32
  %l32 = alloca i32
  %l36 = alloca i32
  %l39 = alloca i32
  %l58 = alloca ptr
  %l59 = alloca i32
  %l63 = alloca i32
  %l64 = alloca i64
  %l69 = alloca i64
  %l73 = alloca i64
  %l76 = alloca i64
  %l97 = alloca ptr
  %l105 = alloca i1
  %l109 = alloca i64
  %l112 = alloca ptr
  %l113 = alloca ptr
  %l117 = alloca ptr
  %l120 = alloca i32
  %l121 = alloca { i64, ptr }
  %l126 = alloca { i64, ptr }
  %l128 = alloca i1
  %l129 = alloca i32
  %l131 = alloca { i64, ptr }
  %l133 = alloca i32
  %l134 = alloca { i64, ptr }
  %l136 = alloca ptr
  %l139 = alloca i32
  %l142 = alloca i32
  %l143 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 2
  %t9 = load ptr, ptr %t8, !tbaa !29
  store ptr %t9, ptr %l5, !tbaa !29
  %t11 = load ptr, ptr %l5, !tbaa !29
  %t12 = load i32, ptr %l1, !tbaa !23
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t15, ptr %l29
  br label %bb1
bb1:
  %t16 = load i32, ptr %l29
  %t18 = trunc i64 18 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb2, label %bb3
bb2:
  %t21 = load i32, ptr %l1, !tbaa !23
  store i32 %t21, ptr %l32, !tbaa !23
  br label %bb5
bb3:
  %t23 = load ptr, ptr %l5, !tbaa !29
  %t24 = load i32, ptr %l1, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l36
  br label %bb4
bb4:
  %t28 = load i32, ptr %l36, !tbaa !23
  store i32 %t28, ptr %l32, !tbaa !23
  br label %bb5
bb5:
  %t29 = load i32, ptr %l32, !tbaa !23
  store i32 %t29, ptr %l6, !tbaa !23
  %t30 = load ptr, ptr %l5, !tbaa !29
  %t31 = load i32, ptr %l6, !tbaa !23
  %t34 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t30, i32 %t31)
  store i32 %t34, ptr %l39
  br label %bb6
bb6:
  %t35 = load i32, ptr %l39
  %t37 = trunc i64 18 to i32
  %t38 = icmp eq i32 %t35, %t37
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb7, label %bb8
bb7:
  store i64 -1, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  store i64 -1, ptr %l7, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s2
  %t46 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %a2, 0
  %t48 = insertvalue [2 x { i64, ptr }] %t46, { i64, ptr } %a3, 1
  %t50 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 32, i64 8)
  store [2 x { i64, ptr }] %t48, ptr %t50
  store ptr %t50, ptr %l8
  store i64 0, ptr %l9, !tbaa !24
  %t52 = load ptr, ptr %l8
  store i64 2, ptr %l10, !tbaa !24
  br label %bb10
bb10:
  %t55 = load i64, ptr %l9, !tbaa !24
  %t56 = load i64, ptr %l10, !tbaa !24
  %t59 = icmp slt i64 %t55, %t56
  %t61 = xor i1 %t59, true
  br i1 %t61, label %bb11, label %bb12
bb11:
  br label %bb67
bb12:
  br label %bb13
bb13:
  %t63 = load ptr, ptr %l8
  %t64 = load i64, ptr %l9, !tbaa !24
  %t67 = getelementptr [2 x { i64, ptr }], ptr %t63, i64 0, i64 %t64
  %t68 = load { i64, ptr }, ptr %t67, !tbaa !37
  %t70 = load ptr, ptr %l4, !tbaa !29
  %t72 = getelementptr %"compiler/lower:Lowerer", ptr %t70, i32 0, i32 0
  %t73 = load ptr, ptr %t72, !tbaa !29
  store ptr %t73, ptr %l58, !tbaa !29
  %t74 = load i32, ptr %l6, !tbaa !23
  store i32 %t74, ptr %l59, !tbaa !23
  %t75 = load ptr, ptr %l5, !tbaa !29
  %t77 = getelementptr %"compiler/types:Table", ptr %t75, i32 0, i32 0
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t82 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s2, ptr %t78, { i64, ptr } %t68)
  store i32 %t82, ptr %l63
  br label %bb14
bb14:
  %t83 = load ptr, ptr %l58, !tbaa !29
  %t84 = load i32, ptr %l59, !tbaa !23
  %t85 = load i32, ptr %l63, !tbaa !23
  %t86 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t83, i32 %t84, i32 %t85)
  store i64 %t86, ptr %l64
  br label %bb15
bb15:
  %t87 = load i64, ptr %l64, !tbaa !24
  store i64 %t87, ptr %l12, !tbaa !24
  %t88 = load i64, ptr %l12, !tbaa !24
  %t90 = icmp slt i64 %t88, 0
  br i1 %t90, label %bb16, label %bb17
bb16:
  br label %bb66
bb17:
  br label %bb18
bb18:
  store i64 0, ptr %l13, !tbaa !24
  %t92 = load ptr, ptr %l4, !tbaa !29
  %t94 = getelementptr %"compiler/lower:Lowerer", ptr %t92, i32 0, i32 1
  %t96 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t94)
  store i64 %t96, ptr %l69
  br label %bb19
bb19:
  %t97 = load i64, ptr %l69, !tbaa !24
  store i64 %t97, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t98 = load i64, ptr %l14, !tbaa !24
  %t99 = load i64, ptr %l13, !tbaa !24
  %t102 = icmp sgt i64 %t98, %t99
  br i1 %t102, label %bb20, label %bb21
bb20:
  %t104 = load i64, ptr %l15, !tbaa !24
  %t106 = icmp sgt i64 %t104, 0
  br i1 %t106, label %bb22, label %bb23
bb21:
  store i64 0, ptr %l73, !tbaa !24
  br label %bb25
bb22:
  %t108 = load i64, ptr %l14, !tbaa !24
  %t109 = load i64, ptr %l13, !tbaa !24
  %t112 = sub i64 %t108, %t109
  %t113 = load i64, ptr %l15, !tbaa !24
  %t116 = add i64 %t112, %t113
  %t118 = sub i64 %t116, 1
  %t119 = load i64, ptr %l15, !tbaa !24
  %t122 = sdiv i64 %t118, %t119
  store i64 %t122, ptr %l76, !tbaa !24
  br label %bb24
bb23:
  store i64 0, ptr %l76, !tbaa !24
  br label %bb24
bb24:
  %t124 = load i64, ptr %l76, !tbaa !24
  store i64 %t124, ptr %l73, !tbaa !24
  br label %bb25
bb25:
  %t125 = load i64, ptr %l73, !tbaa !24
  store i64 %t125, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb26
bb26:
  %t126 = load i64, ptr %l17, !tbaa !24
  %t127 = load i64, ptr %l16, !tbaa !24
  %t130 = icmp slt i64 %t126, %t127
  %t132 = xor i1 %t130, true
  br i1 %t132, label %bb27, label %bb28
bb27:
  br label %bb65
bb28:
  br label %bb29
bb29:
  %t134 = load i64, ptr %l13, !tbaa !24
  %t135 = load i64, ptr %l17, !tbaa !24
  %t136 = load i64, ptr %l15, !tbaa !24
  %t139 = mul i64 %t135, %t136
  %t142 = add i64 %t134, %t139
  store i64 %t142, ptr %l18, !tbaa !24
  %t144 = load ptr, ptr %l4, !tbaa !29
  %t146 = getelementptr %"compiler/lower:Lowerer", ptr %t144, i32 0, i32 1
  %t147 = load i64, ptr %l18, !tbaa !24
  %t150 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t146, i64 %t147)
  store ptr %t150, ptr %l97
  br label %bb30
bb30:
  %t151 = load ptr, ptr %l97, !tbaa !29
  %t153 = getelementptr %"compiler/typed:Body", ptr %t151, i32 0, i32 1
  %t154 = load { i64, [2 x i64] }, ptr %t153
  store { i64, [2 x i64] } %t154, ptr %l19
  %t156 = load { i64, [2 x i64] }, ptr %l19
  %t158 = extractvalue { i64, [2 x i64] } %t156, 0
  %t159 = icmp eq i64 %t158, 0
  br i1 %t159, label %bb31, label %bb32
bb31:
  %t161 = getelementptr { i64, [2 x i64] }, ptr %l19, i32 0, i32 1
  %t162 = getelementptr { i64 }, ptr %t161, i32 0, i32 0
  %t163 = load i64, ptr %t162
  store i64 %t163, ptr %l20, !tbaa !24
  br label %bb33
bb32:
  br label %bb58
bb33:
  %t165 = load i64, ptr %l7, !tbaa !24
  %t167 = icmp slt i64 %t165, 0
  br i1 %t167, label %bb34, label %bb35
bb34:
  %t169 = load ptr, ptr %l4, !tbaa !29
  %t171 = getelementptr %"compiler/lower:Lowerer", ptr %t169, i32 0, i32 0
  %t172 = load ptr, ptr %t171, !tbaa !29
  %t173 = load i64, ptr %l20, !tbaa !24
  %t176 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t172, i64 %t173)
  store i64 %t176, ptr %l109
  br label %bb36
bb35:
  store i1 false, ptr %l105, !tbaa !21
  br label %bb37
bb36:
  %t177 = load i64, ptr %l12, !tbaa !24
  %t178 = load i64, ptr %l109, !tbaa !24
  %t180 = icmp eq i64 %t178, %t177
  store i1 %t180, ptr %l105, !tbaa !21
  br label %bb37
bb37:
  %t182 = load i1, ptr %l105, !tbaa !21
  br i1 %t182, label %bb38, label %bb39
bb38:
  %t183 = load ptr, ptr %l5, !tbaa !29
  store ptr %t183, ptr %l112, !tbaa !29
  %t184 = load ptr, ptr %l5, !tbaa !29
  store ptr %t184, ptr %l113, !tbaa !29
  %t185 = load ptr, ptr %l4, !tbaa !29
  %t187 = getelementptr %"compiler/lower:Lowerer", ptr %t185, i32 0, i32 1
  %t188 = load i64, ptr %l18, !tbaa !24
  %t191 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t187, i64 %t188)
  store ptr %t191, ptr %l117
  br label %bb40
bb39:
  br label %bb57
bb40:
  %t192 = load ptr, ptr %l117, !tbaa !29
  %t194 = getelementptr %"compiler/typed:Body", ptr %t192, i32 0, i32 2
  %t195 = load i32, ptr %t194, !tbaa !23
  %t196 = load ptr, ptr %l113, !tbaa !29
  %t198 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t196, i32 %t195)
  store i32 %t198, ptr %l120
  br label %bb41
bb41:
  %t199 = load ptr, ptr %l112, !tbaa !29
  %t200 = load i32, ptr %l120, !tbaa !23
  %t201 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t199, i32 %t200)
  store { i64, ptr } %t201, ptr %l121
  br label %bb42
bb42:
  %t202 = load { i64, ptr }, ptr %l121, !tbaa !27
  store { i64, ptr } %t202, ptr %l21, !tbaa !27
  %t203 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t205 = extractvalue { i64, ptr } %t203, 0
  %t207 = icmp eq i64 %t205, 1
  br i1 %t207, label %bb43, label %bb44
bb43:
  %t209 = load ptr, ptr %l5, !tbaa !29
  %t210 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t210, ptr %l126, !tbaa !27
  %t211 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t212 = load ptr, ptr %t211, !tbaa !27
  %t213 = getelementptr i32, ptr %t212, i64 0
  %t214 = load i32, ptr %t213, !tbaa !33
  %t217 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t209, i32 %t214)
  store i1 %t217, ptr %l128
  br label %bb45
bb44:
  br label %bb56
bb45:
  %t218 = load i1, ptr %l128, !tbaa !21
  br i1 %t218, label %bb46, label %bb47
bb46:
  %t219 = load ptr, ptr %l5, !tbaa !29
  %t220 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t220, ptr %l131, !tbaa !27
  %t221 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t222 = load ptr, ptr %t221, !tbaa !27
  %t223 = getelementptr i32, ptr %t222, i64 0
  %t224 = load i32, ptr %t223, !tbaa !33
  %t227 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t219, i32 %t224)
  store i32 %t227, ptr %l133
  br label %bb48
bb47:
  %t228 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t228, ptr %l134, !tbaa !27
  %t229 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t230 = load ptr, ptr %t229, !tbaa !27
  %t231 = getelementptr i32, ptr %t230, i64 0
  %t232 = load i32, ptr %t231, !tbaa !33
  store i32 %t232, ptr %l129, !tbaa !23
  br label %bb49
bb48:
  %t234 = load i32, ptr %l133, !tbaa !23
  store i32 %t234, ptr %l129, !tbaa !23
  br label %bb49
bb49:
  %t235 = load i32, ptr %l129, !tbaa !23
  %t236 = load ptr, ptr %l5, !tbaa !29
  store ptr %t236, ptr %l136, !tbaa !29
  %t237 = load ptr, ptr %l5, !tbaa !29
  %t241 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t237, i32 %t235)
  store i32 %t241, ptr %l139
  br label %bb50
bb50:
  %t242 = load ptr, ptr %l5, !tbaa !29
  %t243 = load i32, ptr %l6, !tbaa !23
  %t246 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t242, i32 %t243)
  store i32 %t246, ptr %l142
  br label %bb51
bb51:
  %t247 = load ptr, ptr %l136, !tbaa !29
  %t248 = load i32, ptr %l139, !tbaa !23
  %t249 = load i32, ptr %l142, !tbaa !23
  %t250 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t247, i32 %t248, i32 %t249)
  store i1 %t250, ptr %l143
  br label %bb52
bb52:
  %t251 = load i1, ptr %l143, !tbaa !21
  br i1 %t251, label %bb53, label %bb54
bb53:
  %t252 = load i64, ptr %l18, !tbaa !24
  store i64 %t252, ptr %l7, !tbaa !24
  br label %bb55
bb54:
  br label %bb55
bb55:
  br label %bb56
bb56:
  br label %bb57
bb57:
  br label %bb63
bb58:
  br i1 true, label %bb59, label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb63
bb62:
  call void @__olang_check_failed(ptr @olang_loc_b551419724d67aba_25293d2489abf656)
  unreachable
bb63:
  br label %bb64
bb64:
  %t254 = load i64, ptr %l17, !tbaa !24
  %t256 = add i64 %t254, 1
  store i64 %t256, ptr %l17, !tbaa !24
  br label %bb26
bb65:
  br label %bb66
bb66:
  %t258 = load i64, ptr %l9, !tbaa !24
  %t260 = add i64 %t258, 1
  store i64 %t260, ptr %l9, !tbaa !24
  br label %bb10
bb67:
  call void @__olang_scope_close(ptr %s2)
  %t262 = load i64, ptr %l7, !tbaa !24
  store i64 %t262, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2emix(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, [4 x i64] }
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca { i64, [4 x i64] }
  %l9 = alloca { i64, [4 x i64] }
  %l10 = alloca { i64, ptr }
  %l12 = alloca { i64, [4 x i64] }
  %l13 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca { i64, [4 x i64] }
  %l17 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca { i64, [4 x i64] }
  %l22 = alloca { i64, [4 x i64] }
  %l23 = alloca { i64, ptr }
  %l25 = alloca { i64, [4 x i64] }
  %l26 = alloca { i64, ptr }
  %l28 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i32 5, ptr %l5
  %t2 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t2, ptr %l6, !tbaa !23
  store { i64, [4 x i64] } %a1, ptr %l7
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t4, i64 -7046029254386353131)
  store { i64, [4 x i64] } %t6, ptr %l9
  br label %bb1
bb1:
  %t7 = mul i64 2, 40
  %t8 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t7)
  %t9 = insertvalue { i64, ptr } undef, i64 2, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  store { i64, ptr } %t10, ptr %l10, !tbaa !27
  %t11 = load { i64, [4 x i64] }, ptr %l7
  %t12 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, [4 x i64] }, ptr %t13, i64 0
  store { i64, [4 x i64] } %t11, ptr %t14
  %t15 = load { i64, [4 x i64] }, ptr %l9
  %t16 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t17, i64 1
  store { i64, [4 x i64] } %t15, ptr %t18
  %t19 = load %"compiler/source:Span", ptr %l2
  %t20 = load ptr, ptr %l4, !tbaa !29
  %t21 = load i32, ptr %l5
  %t22 = load i32, ptr %l6, !tbaa !23
  %t23 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t25 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %t20, i32 %t21, i32 %t22, { i64, ptr } %t23, %"compiler/source:Span" %t19)
  store { i64, [4 x i64] } %t25, ptr %l12
  br label %bb2
bb2:
  %t26 = load { i64, [4 x i64] }, ptr %l12
  store { i64, [4 x i64] } %t26, ptr %l3
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l13, !tbaa !29
  store i32 12, ptr %l14
  %t28 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t28, ptr %l15, !tbaa !23
  %t29 = load { i64, [4 x i64] }, ptr %l3
  store { i64, [4 x i64] } %t29, ptr %l16
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l17, !tbaa !29
  store i32 9, ptr %l18
  %t31 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t31, ptr %l19, !tbaa !23
  %t32 = load { i64, [4 x i64] }, ptr %l3
  store { i64, [4 x i64] } %t32, ptr %l20
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t33, i64 29)
  store { i64, [4 x i64] } %t35, ptr %l22
  br label %bb3
bb3:
  %t36 = mul i64 2, 40
  %t37 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 2, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l23, !tbaa !27
  %t40 = load { i64, [4 x i64] }, ptr %l20
  %t41 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr { i64, [4 x i64] }, ptr %t42, i64 0
  store { i64, [4 x i64] } %t40, ptr %t43
  %t44 = load { i64, [4 x i64] }, ptr %l22
  %t45 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr { i64, [4 x i64] }, ptr %t46, i64 1
  store { i64, [4 x i64] } %t44, ptr %t47
  %t48 = load %"compiler/source:Span", ptr %l2
  %t49 = load ptr, ptr %l17, !tbaa !29
  %t50 = load i32, ptr %l18
  %t51 = load i32, ptr %l19, !tbaa !23
  %t52 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t54 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %t49, i32 %t50, i32 %t51, { i64, ptr } %t52, %"compiler/source:Span" %t48)
  store { i64, [4 x i64] } %t54, ptr %l25
  br label %bb4
bb4:
  %t55 = mul i64 2, 40
  %t56 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t55)
  %t57 = insertvalue { i64, ptr } undef, i64 2, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t56, 1
  store { i64, ptr } %t58, ptr %l26, !tbaa !27
  %t59 = load { i64, [4 x i64] }, ptr %l16
  %t60 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr { i64, [4 x i64] }, ptr %t61, i64 0
  store { i64, [4 x i64] } %t59, ptr %t62
  %t63 = load { i64, [4 x i64] }, ptr %l25
  %t64 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = getelementptr { i64, [4 x i64] }, ptr %t65, i64 1
  store { i64, [4 x i64] } %t63, ptr %t66
  %t67 = load %"compiler/source:Span", ptr %l2
  %t68 = load ptr, ptr %l13, !tbaa !29
  %t69 = load i32, ptr %l14
  %t70 = load i32, ptr %l15, !tbaa !23
  %t71 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t73 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %t68, i32 %t69, i32 %t70, { i64, ptr } %t71, %"compiler/source:Span" %t67)
  store { i64, [4 x i64] } %t73, ptr %l28
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t74 = load { i64, [4 x i64] }, ptr %l28
  store { i64, [4 x i64] } %t74, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local i64 @compiler_2flower_2ecompiler_2flower_3alowering_2emodule(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l12 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l43 = alloca ptr
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/lower:Lowerer", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/load:Loader", ptr %t10, i32 0, i32 5
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t12)
  store i64 %t14, ptr %l12
  br label %bb1
bb1:
  %t15 = load i64, ptr %l12, !tbaa !24
  store i64 %t15, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t17 = load i64, ptr %l1, !tbaa !24
  %t20 = icmp sgt i64 %t16, %t17
  br i1 %t20, label %bb2, label %bb3
bb2:
  %t22 = load i64, ptr %l3, !tbaa !24
  %t24 = icmp sgt i64 %t22, 0
  br i1 %t24, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb7
bb4:
  %t26 = load i64, ptr %l2, !tbaa !24
  %t27 = load i64, ptr %l1, !tbaa !24
  %t30 = sub i64 %t26, %t27
  %t31 = load i64, ptr %l3, !tbaa !24
  %t34 = add i64 %t30, %t31
  %t36 = sub i64 %t34, 1
  %t37 = load i64, ptr %l3, !tbaa !24
  %t40 = sdiv i64 %t36, %t37
  store i64 %t40, ptr %l19, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb6
bb6:
  %t42 = load i64, ptr %l19, !tbaa !24
  store i64 %t42, ptr %l16, !tbaa !24
  br label %bb7
bb7:
  %t43 = load i64, ptr %l16, !tbaa !24
  store i64 %t43, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  %t44 = load i64, ptr %l5, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb9, label %bb10
bb9:
  br label %bb17
bb10:
  br label %bb11
bb11:
  %t52 = load i64, ptr %l1, !tbaa !24
  %t53 = load i64, ptr %l5, !tbaa !24
  %t54 = load i64, ptr %l3, !tbaa !24
  %t57 = mul i64 %t53, %t54
  %t60 = add i64 %t52, %t57
  store i64 %t60, ptr %l6, !tbaa !24
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/lower:lowering", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/lower:Lowerer", ptr %t65, i32 0, i32 0
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = getelementptr %"compiler/generic:Program", ptr %t68, i32 0, i32 0
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = getelementptr %"compiler/load:Loader", ptr %t71, i32 0, i32 5
  %t74 = load i64, ptr %l6, !tbaa !24
  %t77 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t73, i64 %t74)
  store ptr %t77, ptr %l43
  br label %bb12
bb12:
  %t78 = load ptr, ptr %l43, !tbaa !29
  %t80 = getelementptr %"compiler/load:Module", ptr %t78, i32 0, i32 4
  %t81 = load i64, ptr %t80, !tbaa !24
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/lower:lowering", ptr %t82, i32 0, i32 4
  %t85 = load i64, ptr %t84, !tbaa !24
  %t88 = icmp eq i64 %t81, %t85
  br i1 %t88, label %bb13, label %bb14
bb13:
  %t90 = load i64, ptr %l6, !tbaa !24
  store i64 %t90, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t92 = load i64, ptr %l5, !tbaa !24
  %t94 = add i64 %t92, 1
  store i64 %t94, ptr %l5, !tbaa !24
  br label %bb8
bb17:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2epatch(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i64
  %l7 = alloca i64
  %l12 = alloca i32
  %l14 = alloca i64
  %l16 = alloca i64
  %l21 = alloca i32
  %t37 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2eLen_3ccompiler_2fmir_3aBlockId_3e(ptr %v1, ptr %l1)
  store i64 %t2, ptr %l7
  br label %bb1
bb1:
  %t3 = load i64, ptr %l7, !tbaa !24
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb2, label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 7
  store i1 true, ptr %t8, !tbaa !21
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/lower:lowering", ptr %t9, i32 0, i32 3
  %t13 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t11)
  store i32 %t13, ptr %l12
  br label %bb5
bb5:
  %t14 = load i32, ptr %l12, !tbaa !23
  store i32 %t14, ptr %l2, !tbaa !23
  store ptr %l1, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb6
bb6:
  %t16 = load i64, ptr %l4, !tbaa !24
  store i64 %t16, ptr %l14, !tbaa !24
  %t17 = load ptr, ptr %l3, !tbaa !29
  %t19 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2eLen_3ccompiler_2fmir_3aBlockId_3e(ptr %v1, ptr %t17)
  store i64 %t19, ptr %l16
  br label %bb7
bb7:
  %t20 = load i64, ptr %l14, !tbaa !24
  %t21 = load i64, ptr %l16, !tbaa !24
  %t22 = icmp slt i64 %t20, %t21
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb8, label %bb9
bb8:
  br label %bb14
bb9:
  br label %bb10
bb10:
  %t26 = load ptr, ptr %l3, !tbaa !29
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2eAt_3ccompiler_2fmir_3aBlockId_3e(ptr %v1, ptr %t26, i64 %t27)
  store i32 %t30, ptr %l21
  br label %bb11
bb11:
  %t31 = load i32, ptr %l21, !tbaa !23
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/lower:lowering", ptr %t32, i32 0, i32 3
  %t36 = load i32, ptr %l2, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t37
  %t38 = getelementptr { i64, [8 x i64] }, ptr %t37, i32 0, i32 0
  store i64 1, ptr %t38
  %t40 = insertvalue { i32 } undef, i32 %t36, 0
  %t41 = getelementptr { i64, [8 x i64] }, ptr %t37, i32 0, i32 1
  store { i32 } %t40, ptr %t41
  %t42 = load { i64, [8 x i64] }, ptr %t37
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v0, ptr %t34, i32 %t31, { i64, [8 x i64] } %t42)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t46 = load i64, ptr %l4, !tbaa !24
  %t48 = add i64 %t46, 1
  store i64 %t48, ptr %l4, !tbaa !24
  br label %bb6
bb14:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t50, i32 %t51)
  br label %bb15
bb15:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2epayloads(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, [4 x i64] } %a2, %"compiler/source:Span" %a3, ptr %a4c, ptr %a4e) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca %"compiler/source:Span"
  %l5 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l33 = alloca i64
  %l36 = alloca i64
  %l54 = alloca { i64, ptr }
  %l58 = alloca i1
  %l60 = alloca ptr
  %l63 = alloca { i64, ptr }
  %l66 = alloca i32
  %l67 = alloca { i64, ptr }
  %l75 = alloca i64
  %l79 = alloca i32
  %l81 = alloca i64
  %l82 = alloca %"compiler/mir:Case"
  %l84 = alloca %"compiler/mir:Case"
  %l89 = alloca i64
  %l94 = alloca i64
  %l98 = alloca i64
  %l101 = alloca i64
  %l119 = alloca i64
  %l122 = alloca i32
  %l123 = alloca i64
  %l126 = alloca i64
  %l129 = alloca %"compiler/mir:Case"
  %l132 = alloca ptr
  %l133 = alloca { i64, [4 x i64] }
  %l137 = alloca %"compiler/mir:Range"
  %l141 = alloca i64
  %l145 = alloca i64
  %l148 = alloca i64
  %l169 = alloca { ptr, ptr }
  %l172 = alloca i64
  %l173 = alloca { i64, ptr }
  %l176 = alloca i64
  %s0 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %t125 = alloca i64
  %t243 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store %"compiler/source:Span" %a3, ptr %l3
  %pf4 = insertvalue { ptr, ptr } undef, ptr %a4c, 0
  %pg4 = insertvalue { ptr, ptr } %pf4, ptr %a4e, 1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l27
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l27
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l5
  store i64 0, ptr %l6, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t7 = load i64, ptr %l7, !tbaa !24
  %t8 = load i64, ptr %l6, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l8, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l7, !tbaa !24
  %t18 = load i64, ptr %l6, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l8, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l8, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l36, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l36, !tbaa !24
  store i64 %t33, ptr %l33, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l33, !tbaa !24
  store i64 %t34, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l10, !tbaa !24
  %t36 = load i64, ptr %l9, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb22
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l6, !tbaa !24
  %t44 = load i64, ptr %l10, !tbaa !24
  %t45 = load i64, ptr %l8, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l11, !tbaa !24
  %t53 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t53, ptr %l54, !tbaa !27
  %t54 = load i64, ptr %l11, !tbaa !24
  %t56 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr i32, ptr %t57, i64 %t54
  %t59 = load i32, ptr %t58, !tbaa !33
  %t61 = icmp ne i32 %t59, 0
  br i1 %t61, label %bb12, label %bb13
bb12:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/lower:lowering", ptr %t63, i32 0, i32 2
  %t66 = load ptr, ptr %t65, !tbaa !29
  store ptr %t66, ptr %l60, !tbaa !29
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/lower:lowering", ptr %t67, i32 0, i32 2
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t71 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t71, ptr %l63, !tbaa !27
  %t72 = load i64, ptr %l11, !tbaa !24
  %t74 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr i32, ptr %t75, i64 %t72
  %t77 = load i32, ptr %t76, !tbaa !33
  %t80 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t70, i32 %t77)
  store i32 %t80, ptr %l66
  br label %bb14
bb13:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb16
bb14:
  %t81 = load ptr, ptr %l60, !tbaa !29
  %t82 = load i32, ptr %l66, !tbaa !23
  %t83 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t81, i32 %t82)
  store { i64, ptr } %t83, ptr %l67
  br label %bb15
bb15:
  %t84 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t84, 0
  %t87 = icmp sgt i64 %t85, 0
  store i1 %t87, ptr %l58, !tbaa !21
  br label %bb16
bb16:
  %t89 = load i1, ptr %l58, !tbaa !21
  br i1 %t89, label %bb17, label %bb18
bb17:
  %t90 = load i64, ptr %l11, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l5, i64 %t90)
  br label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t93 = load i64, ptr %l10, !tbaa !24
  %t95 = add i64 %t93, 1
  store i64 %t95, ptr %l10, !tbaa !24
  br label %bb8
bb22:
  %t98 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l5)
  store i64 %t98, ptr %l75
  br label %bb23
bb23:
  %t99 = load i64, ptr %l75, !tbaa !24
  %t100 = icmp eq i64 %t99, 0
  br i1 %t100, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb25:
  br label %bb26
bb26:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/lower:lowering", ptr %t102, i32 0, i32 3
  %t106 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t104)
  store i32 %t106, ptr %l79
  br label %bb27
bb27:
  %t107 = load i32, ptr %l79, !tbaa !23
  store i32 %t107, ptr %l12, !tbaa !23
  %t109 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l5)
  store i64 %t109, ptr %l81
  br label %bb28
bb28:
  store %"compiler/mir:Case" zeroinitializer, ptr %l82
  %t110 = load i64, ptr %l81, !tbaa !24
  %t111 = icmp sgt i64 %t110, 0
  br i1 %t111, label %bb29, label %bb30
bb29:
  %t113 = call %"compiler/mir:Case" @compiler_2fmir_3aCase_2ector(ptr %s0, i64 0, i32 0)
  store %"compiler/mir:Case" %t113, ptr %l84
  br label %bb31
bb30:
  %t114 = load i64, ptr %l81, !tbaa !24
  %t115 = icmp sge i64 %t114, 0
  br i1 %t115, label %bb32, label %bb33
bb31:
  %t117 = load %"compiler/mir:Case", ptr %l84
  store %"compiler/mir:Case" %t117, ptr %l82
  br label %bb30
bb32:
  %t118 = load i64, ptr %l81, !tbaa !24
  %t119 = icmp sle i64 %t118, 576460752303423487
  br i1 %t119, label %bb34, label %bb35
bb33:
  call void @__olang_check_failed(ptr @olang_loc_f77986af895aed4f_f84e497584b75763)
  unreachable
bb34:
  %t121 = load i64, ptr %l81, !tbaa !24
  %t122 = mul i64 %t121, 16
  %t123 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t122)
  %t124 = load %"compiler/mir:Case", ptr %l82
  store i64 0, ptr %t125
  br label %fill.126
fill.126:
  %t129 = load i64, ptr %t125
  %t130 = icmp slt i64 %t129, %t121
  br i1 %t130, label %fillb.127, label %filld.128
fillb.127:
  %t131 = getelementptr %"compiler/mir:Case", ptr %t123, i64 %t129
  store %"compiler/mir:Case" %t124, ptr %t131
  %t132 = add i64 %t129, 1
  store i64 %t132, ptr %t125
  br label %fill.126
filld.128:
  %t133 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t134 = insertvalue { i64, ptr } %t133, ptr %t123, 1
  store { i64, ptr } %t134, ptr %l13, !tbaa !27
  %t137 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l5)
  store i64 %t137, ptr %l89
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_f77986af895aed4f_f84e497584b75763)
  unreachable
bb36:
  %t138 = load i64, ptr %l89, !tbaa !24
  %t139 = icmp sge i64 %t138, 0
  br i1 %t139, label %bb37, label %bb38
bb37:
  %t141 = load i64, ptr %l89, !tbaa !24
  %t142 = icmp sle i64 %t141, 2305843009213693951
  br i1 %t142, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_4d7f91a5420115fa_db913b05a0de57ee)
  unreachable
bb39:
  %t144 = load i64, ptr %l89, !tbaa !24
  %t145 = mul i64 %t144, 4
  %t146 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t145)
  %t147 = insertvalue { i64, ptr } undef, i64 %t144, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t146, 1
  store { i64, ptr } %t148, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t151 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l5)
  store i64 %t151, ptr %l94
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_4d7f91a5420115fa_db913b05a0de57ee)
  unreachable
bb41:
  %t152 = load i64, ptr %l94, !tbaa !24
  store i64 %t152, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t153 = load i64, ptr %l16, !tbaa !24
  %t154 = load i64, ptr %l15, !tbaa !24
  %t157 = icmp sgt i64 %t153, %t154
  br i1 %t157, label %bb42, label %bb43
bb42:
  %t159 = load i64, ptr %l17, !tbaa !24
  %t161 = icmp sgt i64 %t159, 0
  br i1 %t161, label %bb44, label %bb45
bb43:
  store i64 0, ptr %l98, !tbaa !24
  br label %bb47
bb44:
  %t163 = load i64, ptr %l16, !tbaa !24
  %t164 = load i64, ptr %l15, !tbaa !24
  %t167 = sub i64 %t163, %t164
  %t168 = load i64, ptr %l17, !tbaa !24
  %t171 = add i64 %t167, %t168
  %t173 = sub i64 %t171, 1
  %t174 = load i64, ptr %l17, !tbaa !24
  %t177 = sdiv i64 %t173, %t174
  store i64 %t177, ptr %l101, !tbaa !24
  br label %bb46
bb45:
  store i64 0, ptr %l101, !tbaa !24
  br label %bb46
bb46:
  %t179 = load i64, ptr %l101, !tbaa !24
  store i64 %t179, ptr %l98, !tbaa !24
  br label %bb47
bb47:
  %t180 = load i64, ptr %l98, !tbaa !24
  store i64 %t180, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb48
bb48:
  store %olang.scope zeroinitializer, ptr %s7
  %t181 = load i64, ptr %l19, !tbaa !24
  %t182 = load i64, ptr %l18, !tbaa !24
  %t185 = icmp slt i64 %t181, %t182
  %t187 = xor i1 %t185, true
  br i1 %t187, label %bb49, label %bb50
bb49:
  call void @__olang_scope_close(ptr %s7)
  br label %bb56
bb50:
  br label %bb51
bb51:
  %t189 = load i64, ptr %l15, !tbaa !24
  %t190 = load i64, ptr %l19, !tbaa !24
  %t191 = load i64, ptr %l17, !tbaa !24
  %t194 = mul i64 %t190, %t191
  %t197 = add i64 %t189, %t194
  store i64 %t197, ptr %l20, !tbaa !24
  %t199 = load i64, ptr %l20, !tbaa !24
  store i64 %t199, ptr %l119, !tbaa !24
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = getelementptr %"compiler/lower:lowering", ptr %t200, i32 0, i32 3
  %t204 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t202)
  store i32 %t204, ptr %l122
  br label %bb52
bb52:
  %t205 = load i32, ptr %l122, !tbaa !23
  %t206 = load i64, ptr %l119, !tbaa !24
  %t207 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = getelementptr i32, ptr %t208, i64 %t206
  store i32 %t205, ptr %t209, !tbaa !33
  %t210 = load i64, ptr %l20, !tbaa !24
  store i64 %t210, ptr %l123, !tbaa !24
  %t211 = load i64, ptr %l20, !tbaa !24
  %t214 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l5, i64 %t211)
  store i64 %t214, ptr %l126
  br label %bb53
bb53:
  %t215 = load i64, ptr %l20, !tbaa !24
  %t217 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t218 = load ptr, ptr %t217, !tbaa !27
  %t219 = getelementptr i32, ptr %t218, i64 %t215
  %t220 = load i32, ptr %t219, !tbaa !33
  %t221 = load i64, ptr %l126, !tbaa !24
  %t223 = call %"compiler/mir:Case" @compiler_2fmir_3aCase_2ector(ptr %s7, i64 %t221, i32 %t220)
  store %"compiler/mir:Case" %t223, ptr %l129
  br label %bb54
bb54:
  %t224 = load %"compiler/mir:Case", ptr %l129
  %t225 = load i64, ptr %l123, !tbaa !24
  %t226 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t227 = load ptr, ptr %t226, !tbaa !27
  %t228 = getelementptr %"compiler/mir:Case", ptr %t227, i64 %t225
  store %"compiler/mir:Case" %t224, ptr %t228
  call void @__olang_scope_close(ptr %s7)
  br label %bb55
bb55:
  %t229 = load i64, ptr %l19, !tbaa !24
  %t231 = add i64 %t229, 1
  store i64 %t231, ptr %l19, !tbaa !24
  br label %bb48
bb56:
  %t233 = load ptr, ptr %l0, !tbaa !29
  store ptr %t233, ptr %l132, !tbaa !29
  store { i64, [4 x i64] } %a2, ptr %l133
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = getelementptr %"compiler/lower:lowering", ptr %t235, i32 0, i32 3
  %t238 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t241 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCases(ptr %v0, ptr %s0, ptr %t237, { i64, ptr } %t238)
  store %"compiler/mir:Range" %t241, ptr %l137
  br label %bb57
bb57:
  %t242 = load i32, ptr %l12, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t243
  %t244 = getelementptr { i64, [8 x i64] }, ptr %t243, i32 0, i32 0
  store i64 3, ptr %t244
  %t245 = load { i64, [4 x i64] }, ptr %l133
  %t246 = insertvalue { { i64, [4 x i64] }, %"compiler/mir:Range", i32 } undef, { i64, [4 x i64] } %t245, 0
  %t247 = load %"compiler/mir:Range", ptr %l137
  %t248 = insertvalue { { i64, [4 x i64] }, %"compiler/mir:Range", i32 } %t246, %"compiler/mir:Range" %t247, 1
  %t250 = insertvalue { { i64, [4 x i64] }, %"compiler/mir:Range", i32 } %t248, i32 %t242, 2
  %t251 = getelementptr { i64, [8 x i64] }, ptr %t243, i32 0, i32 1
  store { { i64, [4 x i64] }, %"compiler/mir:Range", i32 } %t250, ptr %t251
  %t252 = load { i64, [8 x i64] }, ptr %t243
  %t253 = load ptr, ptr %l132, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t253, { i64, [8 x i64] } %t252)
  br label %bb58
bb58:
  store i64 0, ptr %l21, !tbaa !24
  %t256 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l5)
  store i64 %t256, ptr %l141
  br label %bb59
bb59:
  %t257 = load i64, ptr %l141, !tbaa !24
  store i64 %t257, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t258 = load i64, ptr %l22, !tbaa !24
  %t259 = load i64, ptr %l21, !tbaa !24
  %t262 = icmp sgt i64 %t258, %t259
  br i1 %t262, label %bb60, label %bb61
bb60:
  %t264 = load i64, ptr %l23, !tbaa !24
  %t266 = icmp sgt i64 %t264, 0
  br i1 %t266, label %bb62, label %bb63
bb61:
  store i64 0, ptr %l145, !tbaa !24
  br label %bb65
bb62:
  %t268 = load i64, ptr %l22, !tbaa !24
  %t269 = load i64, ptr %l21, !tbaa !24
  %t272 = sub i64 %t268, %t269
  %t273 = load i64, ptr %l23, !tbaa !24
  %t276 = add i64 %t272, %t273
  %t278 = sub i64 %t276, 1
  %t279 = load i64, ptr %l23, !tbaa !24
  %t282 = sdiv i64 %t278, %t279
  store i64 %t282, ptr %l148, !tbaa !24
  br label %bb64
bb63:
  store i64 0, ptr %l148, !tbaa !24
  br label %bb64
bb64:
  %t284 = load i64, ptr %l148, !tbaa !24
  store i64 %t284, ptr %l145, !tbaa !24
  br label %bb65
bb65:
  %t285 = load i64, ptr %l145, !tbaa !24
  store i64 %t285, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb66
bb66:
  %t286 = load i64, ptr %l25, !tbaa !24
  %t287 = load i64, ptr %l24, !tbaa !24
  %t290 = icmp slt i64 %t286, %t287
  %t292 = xor i1 %t290, true
  br i1 %t292, label %bb67, label %bb68
bb67:
  br label %bb76
bb68:
  br label %bb69
bb69:
  %t294 = load i64, ptr %l21, !tbaa !24
  %t295 = load i64, ptr %l25, !tbaa !24
  %t296 = load i64, ptr %l23, !tbaa !24
  %t299 = mul i64 %t295, %t296
  %t302 = add i64 %t294, %t299
  store i64 %t302, ptr %l26, !tbaa !24
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t305 = load i64, ptr %l26, !tbaa !24
  %t307 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t308 = load ptr, ptr %t307, !tbaa !27
  %t309 = getelementptr i32, ptr %t308, i64 %t305
  %t310 = load i32, ptr %t309, !tbaa !33
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t304, i32 %t310)
  br label %bb70
bb70:
  store { ptr, ptr } %pg4, ptr %l169
  %t314 = load i64, ptr %l26, !tbaa !24
  %t317 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l5, i64 %t314)
  store i64 %t317, ptr %l172
  br label %bb71
bb71:
  %t318 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t318, ptr %l173, !tbaa !27
  %t319 = load i64, ptr %l26, !tbaa !24
  %t322 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l5, i64 %t319)
  store i64 %t322, ptr %l176
  br label %bb72
bb72:
  %t323 = load i64, ptr %l176, !tbaa !24
  %t324 = getelementptr { i64, ptr }, ptr %l173, i32 0, i32 1
  %t325 = load ptr, ptr %t324, !tbaa !27
  %t326 = getelementptr i32, ptr %t325, i64 %t323
  %t327 = load i32, ptr %t326, !tbaa !33
  %t328 = load { ptr, ptr }, ptr %l169
  %t329 = extractvalue { ptr, ptr } %t328, 0
  %t330 = extractvalue { ptr, ptr } %t328, 1
  %t331 = load i64, ptr %l172, !tbaa !24
  call void %t329(ptr %t330, i64 %t331, i32 %t327)
  br label %bb73
bb73:
  %t333 = load ptr, ptr %l0, !tbaa !29
  %t334 = load i32, ptr %l12, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t333, i32 %t334)
  br label %bb74
bb74:
  br label %bb75
bb75:
  %t337 = load i64, ptr %l25, !tbaa !24
  %t339 = add i64 %t337, 1
  store i64 %t339, ptr %l25, !tbaa !24
  br label %bb66
bb76:
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t342 = load i32, ptr %l12, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t341, i32 %t342)
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprimExpr(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, { i64, ptr } %a3, i32 %a4, %"compiler/source:Span" %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca { i64, [4 x i64] }
  %l8 = alloca { i64, [4 x i64] }
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca %"compiler/mir:Lvalue"
  %l13 = alloca { i64, [4 x i64] }
  %l14 = alloca { i64, [4 x i64] }
  %l16 = alloca { i64, [4 x i64] }
  %l18 = alloca { i64, [4 x i64] }
  %l19 = alloca ptr
  %l20 = alloca { i64, [4 x i64] }
  %l21 = alloca ptr
  %l22 = alloca i32
  %l23 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca { i64, [1 x i64] }
  %l26 = alloca { i64, ptr }
  %l35 = alloca { i64, [4 x i64] }
  %l39 = alloca { i64, ptr }
  %l42 = alloca { i64, [4 x i64] }
  %l46 = alloca ptr
  %l47 = alloca i32
  %l48 = alloca i32
  %l49 = alloca { i64, [4 x i64] }
  %l50 = alloca { i64, ptr }
  %l52 = alloca i32
  %l54 = alloca { i64, ptr }
  %l56 = alloca { i64, [4 x i64] }
  %l60 = alloca { i64, ptr }
  %l63 = alloca { i64, [4 x i64] }
  %l70 = alloca ptr
  %l71 = alloca i32
  %l72 = alloca i32
  %l73 = alloca { i64, [4 x i64] }
  %l74 = alloca { i64, ptr }
  %l76 = alloca i32
  %l78 = alloca { i64, ptr }
  %l80 = alloca { i64, [4 x i64] }
  %l91 = alloca { i64, ptr }
  %l93 = alloca { i64, [4 x i64] }
  %l96 = alloca { i64, ptr }
  %l98 = alloca ptr
  %l99 = alloca i1
  %l104 = alloca ptr
  %l108 = alloca %"compiler/lower:pl"
  %l109 = alloca %"compiler/mir:Lvalue"
  %l122 = alloca { i64, ptr }
  %l125 = alloca { i64, [4 x i64] }
  %l127 = alloca { i64, ptr }
  %l130 = alloca { i64, [4 x i64] }
  %l139 = alloca { i64, ptr }
  %l141 = alloca { i64, [4 x i64] }
  %l142 = alloca ptr
  %l143 = alloca { i64, [4 x i64] }
  %l147 = alloca i32
  %l157 = alloca { i64, ptr }
  %l160 = alloca { i64, [4 x i64] }
  %l164 = alloca ptr
  %l165 = alloca i32
  %l166 = alloca i32
  %l167 = alloca { i64, [4 x i64] }
  %l169 = alloca { i64, [4 x i64] }
  %l170 = alloca { i64, ptr }
  %l172 = alloca { i64, [4 x i64] }
  %l173 = alloca ptr
  %l174 = alloca { i64, [4 x i64] }
  %l178 = alloca i32
  %l188 = alloca { i64, ptr }
  %l191 = alloca { i64, [4 x i64] }
  %l195 = alloca ptr
  %l196 = alloca { i64, [4 x i64] }
  %l200 = alloca i32
  %l209 = alloca i1
  %l213 = alloca i1
  %l216 = alloca i1
  %l217 = alloca { i64, ptr }
  %l219 = alloca ptr
  %l223 = alloca i1
  %l224 = alloca ptr
  %l225 = alloca { i64, ptr }
  %l227 = alloca i32
  %l228 = alloca i32
  %l231 = alloca i1
  %l232 = alloca ptr
  %l233 = alloca ptr
  %l234 = alloca { i64, ptr }
  %l236 = alloca i32
  %l237 = alloca i32
  %l238 = alloca i64
  %l243 = alloca { i64, [4 x i64] }
  %l251 = alloca { i64, ptr }
  %l253 = alloca { i64, [4 x i64] }
  %l256 = alloca i1
  %l260 = alloca i1
  %l263 = alloca i1
  %l264 = alloca { i64, ptr }
  %l266 = alloca ptr
  %l267 = alloca i1
  %l276 = alloca i32
  %l280 = alloca i1
  %l284 = alloca i1
  %l285 = alloca ptr
  %l288 = alloca i32
  %l289 = alloca i1
  %l291 = alloca i1
  %l295 = alloca i1
  %l298 = alloca i64
  %l300 = alloca i1
  %l301 = alloca ptr
  %l304 = alloca i32
  %l305 = alloca i64
  %l307 = alloca i1
  %l314 = alloca { i64, [1 x i64] }
  %l318 = alloca { i64, [4 x i64] }
  %l324 = alloca { i64, [4 x i64] }
  %l330 = alloca { i64, [4 x i64] }
  %l333 = alloca { i64, ptr }
  %l339 = alloca i1
  %l343 = alloca i1
  %l346 = alloca i32
  %l349 = alloca i1
  %l350 = alloca ptr
  %l351 = alloca { i64, ptr }
  %l353 = alloca i32
  %l354 = alloca i32
  %l357 = alloca ptr
  %l358 = alloca i32
  %l359 = alloca { i64, [4 x i64] }
  %l360 = alloca ptr
  %l361 = alloca { i64, ptr }
  %l363 = alloca i32
  %l364 = alloca i32
  %l367 = alloca i32
  %l370 = alloca { i64, [4 x i64] }
  %l375 = alloca i1
  %l376 = alloca ptr
  %l377 = alloca { i64, [4 x i64] }
  %l378 = alloca { i64, ptr }
  %l380 = alloca i32
  %l381 = alloca i32
  %l382 = alloca %"compiler/source:Span"
  %l384 = alloca { i64, [1 x i64] }
  %l385 = alloca { i64, [4 x i64] }
  %l388 = alloca i1
  %l389 = alloca ptr
  %l390 = alloca ptr
  %l391 = alloca { i64, ptr }
  %l393 = alloca i32
  %l394 = alloca i32
  %l395 = alloca i1
  %l396 = alloca ptr
  %l397 = alloca { i64, [4 x i64] }
  %l398 = alloca { i64, ptr }
  %l400 = alloca i32
  %l403 = alloca { i64, [4 x i64] }
  %l419 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t42 = alloca { i64, [4 x i64] }, align 8
  %t57 = alloca { i64, [4 x i64] }, align 8
  %t105 = alloca { i64, [4 x i64] }, align 8
  %t126 = alloca { i64, [4 x i64] }, align 8
  %t226 = alloca { i64, [4 x i64] }, align 8
  %t233 = alloca { i64, [21 x i64] }, align 8
  %t245 = alloca { i64, [4 x i64] }, align 8
  %t281 = alloca { i64, [4 x i64] }, align 8
  %t352 = alloca { i64, [4 x i64] }, align 8
  %t402 = alloca { i64, [4 x i64] }, align 8
  %t427 = alloca { i64, [4 x i64] }, align 8
  %t534 = alloca { i64, [4 x i64] }, align 8
  %t730 = alloca { i64, [4 x i64] }, align 8
  %t796 = alloca { i64, [15 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store i32 %a4, ptr %l4
  store %"compiler/source:Span" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l6, !tbaa !29
  %t6 = load i32, ptr %l1
  %t8 = trunc i64 40 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t13 = load i32, ptr %l4, !tbaa !23
  %t14 = load %"compiler/source:Span", ptr %l5
  %t19 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eanyMake(ptr %v0, ptr %v1, ptr %t11, { i64, ptr } %t12, i32 %t13, %"compiler/source:Span" %t14)
  store { i64, [4 x i64] } %t19, ptr %l35
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t20 = load { i64, [4 x i64] }, ptr %l35
  store { i64, [4 x i64] } %t20, ptr %rv
  br label %ret
bb4:
  %t21 = load i32, ptr %l1
  %t23 = trunc i64 42 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t27, ptr %l39, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr ptr, ptr %t29, i64 0
  %t31 = load ptr, ptr %t30, !tbaa !39
  %t35 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t26, ptr %t31)
  store { i64, [4 x i64] } %t35, ptr %l42
  br label %bb7
bb6:
  br label %bb13
bb7:
  %t36 = load { i64, [4 x i64] }, ptr %l42
  store { i64, [4 x i64] } %t36, ptr %l7
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/lower:lowering", ptr %t37, i32 0, i32 7
  %t40 = load i1, ptr %t39, !tbaa !21
  br i1 %t40, label %bb8, label %bb9
bb8:
  store { i64, [4 x i64] } zeroinitializer, ptr %t42
  %t43 = getelementptr { i64, [4 x i64] }, ptr %t42, i32 0, i32 0
  store i64 0, ptr %t43
  %t44 = load { i64, [4 x i64] }, ptr %t42
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t44, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l46, !tbaa !29
  %t47 = load i32, ptr %l1
  store i32 %t47, ptr %l47
  %t48 = load i32, ptr %l4, !tbaa !23
  store i32 %t48, ptr %l48, !tbaa !23
  %t49 = load { i64, [4 x i64] }, ptr %l7
  store { i64, [4 x i64] } %t49, ptr %l49
  %t50 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t50, ptr %l50, !tbaa !27
  %t51 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr ptr, ptr %t52, i64 1
  %t54 = load ptr, ptr %t53, !tbaa !39
  %t56 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t54)
  store i32 %t56, ptr %l52
  br label %bb11
bb11:
  store { i64, [4 x i64] } zeroinitializer, ptr %t57
  %t58 = getelementptr { i64, [4 x i64] }, ptr %t57, i32 0, i32 0
  store i64 2, ptr %t58
  %t59 = load i32, ptr %l52, !tbaa !23
  %t60 = insertvalue { i32, i64 } undef, i32 %t59, 0
  %t61 = insertvalue { i32, i64 } %t60, i64 0, 1
  %t62 = getelementptr { i64, [4 x i64] }, ptr %t57, i32 0, i32 1
  store { i32, i64 } %t61, ptr %t62
  %t63 = load { i64, [4 x i64] }, ptr %t57
  %t64 = mul i64 2, 40
  %t65 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t64)
  %t66 = insertvalue { i64, ptr } undef, i64 2, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t65, 1
  store { i64, ptr } %t67, ptr %l54, !tbaa !27
  %t68 = load { i64, [4 x i64] }, ptr %l49
  %t69 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr { i64, [4 x i64] }, ptr %t70, i64 0
  store { i64, [4 x i64] } %t68, ptr %t71
  %t73 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr { i64, [4 x i64] }, ptr %t74, i64 1
  store { i64, [4 x i64] } %t63, ptr %t75
  %t76 = load %"compiler/source:Span", ptr %l5
  %t77 = load ptr, ptr %l46, !tbaa !29
  %t78 = load i32, ptr %l47
  %t79 = load i32, ptr %l48, !tbaa !23
  %t80 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t82 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s2, ptr %t77, i32 %t78, i32 %t79, { i64, ptr } %t80, %"compiler/source:Span" %t76)
  store { i64, [4 x i64] } %t82, ptr %l56
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t83 = load { i64, [4 x i64] }, ptr %l56
  store { i64, [4 x i64] } %t83, ptr %rv
  br label %ret
bb13:
  %t84 = load i32, ptr %l1
  %t86 = trunc i64 41 to i32
  %t87 = icmp eq i32 %t84, %t86
  br i1 %t87, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t90, ptr %l60, !tbaa !27
  %t91 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = getelementptr ptr, ptr %t92, i64 0
  %t94 = load ptr, ptr %t93, !tbaa !39
  %t98 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t89, ptr %t94)
  store { i64, [4 x i64] } %t98, ptr %l63
  br label %bb16
bb15:
  br label %bb27
bb16:
  %t99 = load { i64, [4 x i64] }, ptr %l63
  store { i64, [4 x i64] } %t99, ptr %l8
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/lower:lowering", ptr %t100, i32 0, i32 7
  %t103 = load i1, ptr %t102, !tbaa !21
  br i1 %t103, label %bb17, label %bb18
bb17:
  store { i64, [4 x i64] } zeroinitializer, ptr %t105
  %t106 = getelementptr { i64, [4 x i64] }, ptr %t105, i32 0, i32 0
  store i64 0, ptr %t106
  %t107 = load { i64, [4 x i64] }, ptr %t105
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t107, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t109 = load i32, ptr %l2
  %t111 = trunc i64 0 to i32
  %t112 = icmp eq i32 %t109, %t111
  %t114 = xor i1 %t112, true
  br i1 %t114, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s6
  %t116 = load ptr, ptr %l0, !tbaa !29
  store ptr %t116, ptr %l70, !tbaa !29
  store i32 42, ptr %l71
  %t117 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t117, ptr %l72, !tbaa !23
  %t118 = load { i64, [4 x i64] }, ptr %l8
  store { i64, [4 x i64] } %t118, ptr %l73
  %t119 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t119, ptr %l74, !tbaa !27
  %t120 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = getelementptr ptr, ptr %t121, i64 1
  %t123 = load ptr, ptr %t122, !tbaa !39
  %t125 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t123)
  store i32 %t125, ptr %l76
  br label %bb22
bb21:
  br label %bb25
bb22:
  store { i64, [4 x i64] } zeroinitializer, ptr %t126
  %t127 = getelementptr { i64, [4 x i64] }, ptr %t126, i32 0, i32 0
  store i64 2, ptr %t127
  %t128 = load i32, ptr %l76, !tbaa !23
  %t129 = insertvalue { i32, i64 } undef, i32 %t128, 0
  %t130 = insertvalue { i32, i64 } %t129, i64 0, 1
  %t131 = getelementptr { i64, [4 x i64] }, ptr %t126, i32 0, i32 1
  store { i32, i64 } %t130, ptr %t131
  %t132 = load { i64, [4 x i64] }, ptr %t126
  %t133 = mul i64 2, 40
  %t134 = call ptr @__olang_scope_alloc_zeroed(ptr %s6, i64 %t133)
  %t135 = insertvalue { i64, ptr } undef, i64 2, 0
  %t136 = insertvalue { i64, ptr } %t135, ptr %t134, 1
  store { i64, ptr } %t136, ptr %l78, !tbaa !27
  %t137 = load { i64, [4 x i64] }, ptr %l73
  %t138 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !27
  %t140 = getelementptr { i64, [4 x i64] }, ptr %t139, i64 0
  store { i64, [4 x i64] } %t137, ptr %t140
  %t142 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = getelementptr { i64, [4 x i64] }, ptr %t143, i64 1
  store { i64, [4 x i64] } %t132, ptr %t144
  %t145 = load %"compiler/source:Span", ptr %l5
  %t146 = load ptr, ptr %l70, !tbaa !29
  %t147 = load i32, ptr %l71
  %t148 = load i32, ptr %l72, !tbaa !23
  %t149 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t151 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s6, ptr %t146, i32 %t147, i32 %t148, { i64, ptr } %t149, %"compiler/source:Span" %t145)
  store { i64, [4 x i64] } %t151, ptr %l80
  br label %bb23
bb23:
  %t152 = load { i64, [4 x i64] }, ptr %l80
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t155 = load i32, ptr %l2
  %t156 = load i64, ptr @G_2ecompiler_2flower_2eWrongCase, !tbaa !24
  %t157 = load %"compiler/source:Span", ptr %l5
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2echeck(ptr %v0, ptr %t153, { i64, [4 x i64] } %t152, i32 %t155, i32 9, i64 %t156, %"compiler/source:Span" %t157)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s6)
  br label %bb25
bb25:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load i32, ptr %l1
  %t166 = load i32, ptr %l4, !tbaa !23
  %t167 = load { i64, [4 x i64] }, ptr %l8
  %t168 = mul i64 1, 40
  %t169 = call ptr @__olang_scope_alloc_zeroed(ptr %s4, i64 %t168)
  %t170 = insertvalue { i64, ptr } undef, i64 1, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr %t169, 1
  store { i64, ptr } %t171, ptr %l91, !tbaa !27
  %t173 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !27
  %t175 = getelementptr { i64, [4 x i64] }, ptr %t174, i64 0
  store { i64, [4 x i64] } %t167, ptr %t175
  %t176 = load %"compiler/source:Span", ptr %l5
  %t180 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t182 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s4, ptr %t164, i32 %t165, i32 %t166, { i64, ptr } %t180, %"compiler/source:Span" %t176)
  store { i64, [4 x i64] } %t182, ptr %l93
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t183 = load { i64, [4 x i64] }, ptr %l93
  store { i64, [4 x i64] } %t183, ptr %rv
  br label %ret
bb27:
  %t184 = load i32, ptr %l1
  %t186 = trunc i64 30 to i32
  %t187 = icmp eq i32 %t184, %t186
  br i1 %t187, label %bb28, label %bb29
bb28:
  %t189 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t189, ptr %l96, !tbaa !27
  %t190 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !27
  %t192 = getelementptr ptr, ptr %t191, i64 0
  %t193 = load ptr, ptr %t192, !tbaa !39
  store ptr %t193, ptr %l10, !tbaa !29
  %t195 = load ptr, ptr %l10, !tbaa !29
  store ptr %t195, ptr %l98, !tbaa !29
  store i1 false, ptr %l99, !tbaa !21
  %t196 = load ptr, ptr %l98, !tbaa !29
  %t197 = icmp ne ptr %t196, null
  br i1 %t197, label %bb30, label %bb31
bb29:
  br label %bb47
bb30:
  %t199 = load ptr, ptr %l98, !tbaa !29
  %t200 = load i64, ptr %t199
  %t202 = icmp eq i64 %t200, 2
  store i1 %t202, ptr %l99, !tbaa !21
  br label %bb31
bb31:
  %t203 = load i1, ptr %l99, !tbaa !21
  br i1 %t203, label %bb32, label %bb33
bb32:
  %t204 = load ptr, ptr %l10, !tbaa !29
  %t206 = getelementptr { i64, [5 x i64] }, ptr %t204, i32 0, i32 1
  %t207 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t206, i32 0, i32 2
  %t208 = load ptr, ptr %t207
  store ptr %t208, ptr %l11, !tbaa !29
  br label %bb34
bb33:
  br label %bb41
bb34:
  store %olang.scope zeroinitializer, ptr %s8
  %t210 = load ptr, ptr %l0, !tbaa !29
  store ptr %t210, ptr %l104, !tbaa !29
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t212 = load ptr, ptr %l11, !tbaa !29
  %t216 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eplace(ptr %v0, ptr %v1, ptr %v0, ptr %t211, ptr %t212)
  store %"compiler/lower:pl" %t216, ptr %l108
  br label %bb35
bb35:
  %t217 = load ptr, ptr %l104, !tbaa !29
  %t218 = load %"compiler/lower:pl", ptr %l108
  %t219 = call %"compiler/mir:Lvalue" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v0, ptr %t217, %"compiler/lower:pl" %t218)
  store %"compiler/mir:Lvalue" %t219, ptr %l109
  br label %bb36
bb36:
  %t220 = load %"compiler/mir:Lvalue", ptr %l109
  store %"compiler/mir:Lvalue" %t220, ptr %l12
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr %"compiler/lower:lowering", ptr %t221, i32 0, i32 7
  %t224 = load i1, ptr %t223, !tbaa !21
  br i1 %t224, label %bb37, label %bb38
bb37:
  store { i64, [4 x i64] } zeroinitializer, ptr %t226
  %t227 = getelementptr { i64, [4 x i64] }, ptr %t226, i32 0, i32 0
  store i64 0, ptr %t227
  %t228 = load { i64, [4 x i64] }, ptr %t226
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t228, ptr %rv
  br label %ret
bb38:
  br label %bb39
bb39:
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load %"compiler/source:Span", ptr %l5
  %t232 = load %"compiler/mir:Lvalue", ptr %l12
  store { i64, [21 x i64] } zeroinitializer, ptr %t233
  %t234 = getelementptr { i64, [21 x i64] }, ptr %t233, i32 0, i32 0
  store i64 8, ptr %t234
  %t236 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue" } undef, %"compiler/source:Span" %t231, 0
  %t238 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue" } %t236, %"compiler/mir:Lvalue" %t232, 1
  %t239 = getelementptr { i64, [21 x i64] }, ptr %t233, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue" } %t238, ptr %t239
  %t240 = load { i64, [21 x i64] }, ptr %t233
  %t242 = call ptr @__olang_scope_alloc_a(ptr %s8, i64 176, i64 8)
  store { i64, [21 x i64] } %t240, ptr %t242
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s8, ptr %t230, ptr %t242)
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s8)
  br label %bb46
bb41:
  br i1 true, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  call void @__olang_check_failed(ptr @olang_loc_b3ebf7d55c86e124_fe3d33fa802e84b8)
  unreachable
bb46:
  store { i64, [4 x i64] } zeroinitializer, ptr %t245
  %t246 = getelementptr { i64, [4 x i64] }, ptr %t245, i32 0, i32 0
  store i64 0, ptr %t246
  %t247 = load { i64, [4 x i64] }, ptr %t245
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t247, ptr %rv
  br label %ret
bb47:
  %t249 = load i32, ptr %l1
  %t251 = trunc i64 38 to i32
  %t252 = icmp eq i32 %t249, %t251
  br i1 %t252, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s11
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t255 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t255, ptr %l122, !tbaa !27
  %t256 = getelementptr { i64, ptr }, ptr %l122, i32 0, i32 1
  %t257 = load ptr, ptr %t256, !tbaa !27
  %t258 = getelementptr ptr, ptr %t257, i64 0
  %t259 = load ptr, ptr %t258, !tbaa !39
  %t263 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t254, ptr %t259)
  store { i64, [4 x i64] } %t263, ptr %l125
  br label %bb50
bb49:
  br label %bb60
bb50:
  %t264 = load { i64, [4 x i64] }, ptr %l125
  store { i64, [4 x i64] } %t264, ptr %l13
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t266 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t266, ptr %l127, !tbaa !27
  %t267 = getelementptr { i64, ptr }, ptr %l127, i32 0, i32 1
  %t268 = load ptr, ptr %t267, !tbaa !27
  %t269 = getelementptr ptr, ptr %t268, i64 1
  %t270 = load ptr, ptr %t269, !tbaa !39
  %t274 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t265, ptr %t270)
  store { i64, [4 x i64] } %t274, ptr %l130
  br label %bb51
bb51:
  %t275 = load { i64, [4 x i64] }, ptr %l130
  store { i64, [4 x i64] } %t275, ptr %l14
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t278 = getelementptr %"compiler/lower:lowering", ptr %t276, i32 0, i32 7
  %t279 = load i1, ptr %t278, !tbaa !21
  br i1 %t279, label %bb52, label %bb53
bb52:
  store { i64, [4 x i64] } zeroinitializer, ptr %t281
  %t282 = getelementptr { i64, [4 x i64] }, ptr %t281, i32 0, i32 0
  store i64 0, ptr %t282
  %t283 = load { i64, [4 x i64] }, ptr %t281
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t283, ptr %rv
  br label %ret
bb53:
  br label %bb54
bb54:
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t286 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t287 = load { i64, [4 x i64] }, ptr %l13
  %t288 = load { i64, [4 x i64] }, ptr %l14
  %t289 = mul i64 2, 40
  %t290 = call ptr @__olang_scope_alloc_zeroed(ptr %s11, i64 %t289)
  %t291 = insertvalue { i64, ptr } undef, i64 2, 0
  %t292 = insertvalue { i64, ptr } %t291, ptr %t290, 1
  store { i64, ptr } %t292, ptr %l139, !tbaa !27
  %t294 = getelementptr { i64, ptr }, ptr %l139, i32 0, i32 1
  %t295 = load ptr, ptr %t294, !tbaa !27
  %t296 = getelementptr { i64, [4 x i64] }, ptr %t295, i64 0
  store { i64, [4 x i64] } %t287, ptr %t296
  %t298 = getelementptr { i64, ptr }, ptr %l139, i32 0, i32 1
  %t299 = load ptr, ptr %t298, !tbaa !27
  %t300 = getelementptr { i64, [4 x i64] }, ptr %t299, i64 1
  store { i64, [4 x i64] } %t288, ptr %t300
  %t301 = load %"compiler/source:Span", ptr %l5
  %t305 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t307 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s11, ptr %t285, i32 13, i32 %t286, { i64, ptr } %t305, %"compiler/source:Span" %t301)
  store { i64, [4 x i64] } %t307, ptr %l141
  br label %bb55
bb55:
  %t308 = load { i64, [4 x i64] }, ptr %l141
  %t309 = load ptr, ptr %l0, !tbaa !29
  store ptr %t309, ptr %l142, !tbaa !29
  store { i64, [4 x i64] } %t308, ptr %l143
  %t311 = load i32, ptr %l2
  %t313 = trunc i64 0 to i32
  %t314 = icmp eq i32 %t311, %t313
  %t316 = xor i1 %t314, true
  br i1 %t316, label %bb56, label %bb57
bb56:
  %t318 = load i32, ptr %l2
  store i32 %t318, ptr %l147
  br label %bb58
bb57:
  store i32 1, ptr %l147
  br label %bb58
bb58:
  %t321 = load i64, ptr @G_2ecompiler_2flower_2eOutOfBounds, !tbaa !24
  %t322 = load %"compiler/source:Span", ptr %l5
  %t323 = load ptr, ptr %l142, !tbaa !29
  %t324 = load { i64, [4 x i64] }, ptr %l143
  %t325 = load i32, ptr %l147
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2echeck(ptr %v0, ptr %t323, { i64, [4 x i64] } %t324, i32 %t325, i32 11, i64 %t321, %"compiler/source:Span" %t322)
  br label %bb59
bb59:
  %t329 = load { i64, [4 x i64] }, ptr %l13
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t329, ptr %rv
  br label %ret
bb60:
  %t331 = load i32, ptr %l1
  %t333 = trunc i64 39 to i32
  %t334 = icmp eq i32 %t331, %t333
  br i1 %t334, label %bb61, label %bb62
bb61:
  store %olang.scope zeroinitializer, ptr %s13
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t337 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t337, ptr %l157, !tbaa !27
  %t338 = getelementptr { i64, ptr }, ptr %l157, i32 0, i32 1
  %t339 = load ptr, ptr %t338, !tbaa !27
  %t340 = getelementptr ptr, ptr %t339, i64 0
  %t341 = load ptr, ptr %t340, !tbaa !39
  %t345 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t336, ptr %t341)
  store { i64, [4 x i64] } %t345, ptr %l160
  br label %bb63
bb62:
  br label %bb73
bb63:
  %t346 = load { i64, [4 x i64] }, ptr %l160
  store { i64, [4 x i64] } %t346, ptr %l16
  %t347 = load ptr, ptr %l0, !tbaa !29
  %t349 = getelementptr %"compiler/lower:lowering", ptr %t347, i32 0, i32 7
  %t350 = load i1, ptr %t349, !tbaa !21
  br i1 %t350, label %bb64, label %bb65
bb64:
  store { i64, [4 x i64] } zeroinitializer, ptr %t352
  %t353 = getelementptr { i64, [4 x i64] }, ptr %t352, i32 0, i32 0
  store i64 0, ptr %t353
  %t354 = load { i64, [4 x i64] }, ptr %t352
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t354, ptr %rv
  br label %ret
bb65:
  br label %bb66
bb66:
  %t356 = load ptr, ptr %l0, !tbaa !29
  store ptr %t356, ptr %l164, !tbaa !29
  store i32 17, ptr %l165
  %t357 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t357, ptr %l166, !tbaa !23
  %t358 = load { i64, [4 x i64] }, ptr %l16
  store { i64, [4 x i64] } %t358, ptr %l167
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t361 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t359, i64 0)
  store { i64, [4 x i64] } %t361, ptr %l169
  br label %bb67
bb67:
  %t362 = mul i64 2, 40
  %t363 = call ptr @__olang_scope_alloc_zeroed(ptr %s13, i64 %t362)
  %t364 = insertvalue { i64, ptr } undef, i64 2, 0
  %t365 = insertvalue { i64, ptr } %t364, ptr %t363, 1
  store { i64, ptr } %t365, ptr %l170, !tbaa !27
  %t366 = load { i64, [4 x i64] }, ptr %l167
  %t367 = getelementptr { i64, ptr }, ptr %l170, i32 0, i32 1
  %t368 = load ptr, ptr %t367, !tbaa !27
  %t369 = getelementptr { i64, [4 x i64] }, ptr %t368, i64 0
  store { i64, [4 x i64] } %t366, ptr %t369
  %t370 = load { i64, [4 x i64] }, ptr %l169
  %t371 = getelementptr { i64, ptr }, ptr %l170, i32 0, i32 1
  %t372 = load ptr, ptr %t371, !tbaa !27
  %t373 = getelementptr { i64, [4 x i64] }, ptr %t372, i64 1
  store { i64, [4 x i64] } %t370, ptr %t373
  %t374 = load %"compiler/source:Span", ptr %l5
  %t375 = load ptr, ptr %l164, !tbaa !29
  %t376 = load i32, ptr %l165
  %t377 = load i32, ptr %l166, !tbaa !23
  %t378 = load { i64, ptr }, ptr %l170, !tbaa !27
  %t380 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s13, ptr %t375, i32 %t376, i32 %t377, { i64, ptr } %t378, %"compiler/source:Span" %t374)
  store { i64, [4 x i64] } %t380, ptr %l172
  br label %bb68
bb68:
  %t381 = load { i64, [4 x i64] }, ptr %l172
  %t382 = load ptr, ptr %l0, !tbaa !29
  store ptr %t382, ptr %l173, !tbaa !29
  store { i64, [4 x i64] } %t381, ptr %l174
  %t384 = load i32, ptr %l2
  %t386 = trunc i64 0 to i32
  %t387 = icmp eq i32 %t384, %t386
  %t389 = xor i1 %t387, true
  br i1 %t389, label %bb69, label %bb70
bb69:
  %t391 = load i32, ptr %l2
  store i32 %t391, ptr %l178
  br label %bb71
bb70:
  store i32 2, ptr %l178
  br label %bb71
bb71:
  %t394 = load i64, ptr @G_2ecompiler_2flower_2eEmpty, !tbaa !24
  %t395 = load %"compiler/source:Span", ptr %l5
  %t396 = load ptr, ptr %l173, !tbaa !29
  %t397 = load { i64, [4 x i64] }, ptr %l174
  %t398 = load i32, ptr %l178
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2echeck(ptr %v0, ptr %t396, { i64, [4 x i64] } %t397, i32 %t398, i32 8, i64 %t394, %"compiler/source:Span" %t395)
  br label %bb72
bb72:
  store { i64, [4 x i64] } zeroinitializer, ptr %t402
  %t403 = getelementptr { i64, [4 x i64] }, ptr %t402, i32 0, i32 0
  store i64 0, ptr %t403
  %t404 = load { i64, [4 x i64] }, ptr %t402
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t404, ptr %rv
  br label %ret
bb73:
  %t406 = load i32, ptr %l1
  %t408 = trunc i64 37 to i32
  %t409 = icmp eq i32 %t406, %t408
  br i1 %t409, label %bb74, label %bb75
bb74:
  %t411 = load ptr, ptr %l0, !tbaa !29
  %t412 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t412, ptr %l188, !tbaa !27
  %t413 = getelementptr { i64, ptr }, ptr %l188, i32 0, i32 1
  %t414 = load ptr, ptr %t413, !tbaa !27
  %t415 = getelementptr ptr, ptr %t414, i64 0
  %t416 = load ptr, ptr %t415, !tbaa !39
  %t420 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t411, ptr %t416)
  store { i64, [4 x i64] } %t420, ptr %l191
  br label %bb76
bb75:
  br label %bb84
bb76:
  %t421 = load { i64, [4 x i64] }, ptr %l191
  store { i64, [4 x i64] } %t421, ptr %l18
  %t422 = load ptr, ptr %l0, !tbaa !29
  %t424 = getelementptr %"compiler/lower:lowering", ptr %t422, i32 0, i32 7
  %t425 = load i1, ptr %t424, !tbaa !21
  br i1 %t425, label %bb77, label %bb78
bb77:
  store { i64, [4 x i64] } zeroinitializer, ptr %t427
  %t428 = getelementptr { i64, [4 x i64] }, ptr %t427, i32 0, i32 0
  store i64 0, ptr %t428
  %t429 = load { i64, [4 x i64] }, ptr %t427
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t429, ptr %rv
  br label %ret
bb78:
  br label %bb79
bb79:
  %t431 = load ptr, ptr %l0, !tbaa !29
  store ptr %t431, ptr %l195, !tbaa !29
  %t432 = load { i64, [4 x i64] }, ptr %l18
  store { i64, [4 x i64] } %t432, ptr %l196
  %t433 = load i32, ptr %l2
  %t435 = trunc i64 0 to i32
  %t436 = icmp eq i32 %t433, %t435
  %t438 = xor i1 %t436, true
  br i1 %t438, label %bb80, label %bb81
bb80:
  %t440 = load i32, ptr %l2
  store i32 %t440, ptr %l200
  br label %bb82
bb81:
  store i32 2, ptr %l200
  br label %bb82
bb82:
  %t443 = load i64, ptr @G_2ecompiler_2flower_2eContract, !tbaa !24
  %t444 = load %"compiler/source:Span", ptr %l5
  %t445 = load ptr, ptr %l195, !tbaa !29
  %t446 = load { i64, [4 x i64] }, ptr %l196
  %t447 = load i32, ptr %l200
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2echeck(ptr %v0, ptr %t445, { i64, [4 x i64] } %t446, i32 %t447, i32 6, i64 %t443, %"compiler/source:Span" %t444)
  br label %bb83
bb83:
  %t451 = load { i64, [4 x i64] }, ptr %l18
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t451, ptr %rv
  br label %ret
bb84:
  store ptr null, ptr %l19, !tbaa !29
  %t453 = load i32, ptr %l1
  %t455 = trunc i64 20 to i32
  %t456 = icmp eq i32 %t453, %t455
  br i1 %t456, label %bb85, label %bb86
bb85:
  %t458 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t460 = extractvalue { i64, ptr } %t458, 0
  %t462 = icmp eq i64 %t460, 1
  store i1 %t462, ptr %l209, !tbaa !21
  br label %bb87
bb86:
  store i1 false, ptr %l209, !tbaa !21
  br label %bb87
bb87:
  %t464 = load i1, ptr %l209, !tbaa !21
  br i1 %t464, label %bb88, label %bb89
bb88:
  %t465 = load ptr, ptr %l0, !tbaa !29
  %t466 = load i32, ptr %l4, !tbaa !23
  %t469 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2evalueArray(ptr %v0, ptr %t465, i32 %t466)
  store i1 %t469, ptr %l216
  br label %bb90
bb89:
  store i1 false, ptr %l213, !tbaa !21
  br label %bb91
bb90:
  %t470 = load i1, ptr %l216, !tbaa !21
  store i1 %t470, ptr %l213, !tbaa !21
  br label %bb91
bb91:
  %t471 = load i1, ptr %l213, !tbaa !21
  br i1 %t471, label %bb92, label %bb93
bb92:
  %t472 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t472, ptr %l217, !tbaa !27
  %t473 = getelementptr { i64, ptr }, ptr %l217, i32 0, i32 1
  %t474 = load ptr, ptr %t473, !tbaa !27
  %t475 = getelementptr ptr, ptr %t474, i64 0
  %t476 = load ptr, ptr %t475, !tbaa !39
  %t478 = call ptr @compiler_2flower_2ederefOf(ptr %v1, ptr %t476)
  store ptr %t478, ptr %l219
  br label %bb94
bb93:
  br label %bb95
bb94:
  %t479 = load ptr, ptr %l219, !tbaa !29
  store ptr %t479, ptr %l19, !tbaa !29
  br label %bb95
bb95:
  %t480 = load ptr, ptr %l19, !tbaa !29
  %t482 = icmp eq ptr %t480, null
  %t484 = xor i1 %t482, true
  br i1 %t484, label %bb96, label %bb97
bb96:
  %t486 = load ptr, ptr %l0, !tbaa !29
  store ptr %t486, ptr %l224, !tbaa !29
  %t487 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t487, ptr %l225, !tbaa !27
  %t488 = getelementptr { i64, ptr }, ptr %l225, i32 0, i32 1
  %t489 = load ptr, ptr %t488, !tbaa !27
  %t490 = getelementptr ptr, ptr %t489, i64 0
  %t491 = load ptr, ptr %t490, !tbaa !39
  %t493 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t491)
  store i32 %t493, ptr %l227
  br label %bb98
bb97:
  store i1 false, ptr %l223, !tbaa !21
  br label %bb100
bb98:
  %t494 = load ptr, ptr %l224, !tbaa !29
  %t495 = load i32, ptr %l227, !tbaa !23
  %t496 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %t494, i32 %t495)
  store i32 %t496, ptr %l228
  br label %bb99
bb99:
  %t497 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t498 = load i32, ptr %l228, !tbaa !23
  %t500 = icmp ne i32 %t498, %t497
  store i1 %t500, ptr %l223, !tbaa !21
  br label %bb100
bb100:
  %t502 = load i1, ptr %l223, !tbaa !21
  br i1 %t502, label %bb101, label %bb102
bb101:
  %t503 = load ptr, ptr %l0, !tbaa !29
  store ptr %t503, ptr %l232, !tbaa !29
  %t504 = load ptr, ptr %l0, !tbaa !29
  store ptr %t504, ptr %l233, !tbaa !29
  %t505 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t505, ptr %l234, !tbaa !27
  %t506 = getelementptr { i64, ptr }, ptr %l234, i32 0, i32 1
  %t507 = load ptr, ptr %t506, !tbaa !27
  %t508 = getelementptr ptr, ptr %t507, i64 0
  %t509 = load ptr, ptr %t508, !tbaa !39
  %t511 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t509)
  store i32 %t511, ptr %l236
  br label %bb103
bb102:
  store i1 false, ptr %l231, !tbaa !21
  br label %bb106
bb103:
  %t512 = load ptr, ptr %l233, !tbaa !29
  %t513 = load i32, ptr %l236, !tbaa !23
  %t514 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %t512, i32 %t513)
  store i32 %t514, ptr %l237
  br label %bb104
bb104:
  %t515 = load ptr, ptr %l232, !tbaa !29
  %t516 = load i32, ptr %l237, !tbaa !23
  %t517 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2efixedLen(ptr %v0, ptr %t515, i32 %t516)
  store i64 %t517, ptr %l238
  br label %bb105
bb105:
  %t518 = load i64, ptr %l238, !tbaa !24
  %t519 = icmp sge i64 %t518, 0
  store i1 %t519, ptr %l231, !tbaa !21
  br label %bb106
bb106:
  %t521 = load i1, ptr %l231, !tbaa !21
  br i1 %t521, label %bb107, label %bb108
bb107:
  store %olang.scope zeroinitializer, ptr %s18
  %t522 = load ptr, ptr %l0, !tbaa !29
  %t523 = load ptr, ptr %l19, !tbaa !29
  %t527 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t522, ptr %t523)
  store { i64, [4 x i64] } %t527, ptr %l243
  br label %bb109
bb108:
  br label %bb114
bb109:
  %t528 = load { i64, [4 x i64] }, ptr %l243
  store { i64, [4 x i64] } %t528, ptr %l20
  %t529 = load ptr, ptr %l0, !tbaa !29
  %t531 = getelementptr %"compiler/lower:lowering", ptr %t529, i32 0, i32 7
  %t532 = load i1, ptr %t531, !tbaa !21
  br i1 %t532, label %bb110, label %bb111
bb110:
  store { i64, [4 x i64] } zeroinitializer, ptr %t534
  %t535 = getelementptr { i64, [4 x i64] }, ptr %t534, i32 0, i32 0
  store i64 0, ptr %t535
  %t536 = load { i64, [4 x i64] }, ptr %t534
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t536, ptr %rv
  br label %ret
bb111:
  br label %bb112
bb112:
  %t538 = load ptr, ptr %l0, !tbaa !29
  %t539 = load i32, ptr %l1
  %t540 = load i32, ptr %l4, !tbaa !23
  %t541 = load { i64, [4 x i64] }, ptr %l20
  %t542 = mul i64 1, 40
  %t543 = call ptr @__olang_scope_alloc_zeroed(ptr %s18, i64 %t542)
  %t544 = insertvalue { i64, ptr } undef, i64 1, 0
  %t545 = insertvalue { i64, ptr } %t544, ptr %t543, 1
  store { i64, ptr } %t545, ptr %l251, !tbaa !27
  %t547 = getelementptr { i64, ptr }, ptr %l251, i32 0, i32 1
  %t548 = load ptr, ptr %t547, !tbaa !27
  %t549 = getelementptr { i64, [4 x i64] }, ptr %t548, i64 0
  store { i64, [4 x i64] } %t541, ptr %t549
  %t550 = load %"compiler/source:Span", ptr %l5
  %t554 = load { i64, ptr }, ptr %l251, !tbaa !27
  %t556 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s18, ptr %t538, i32 %t539, i32 %t540, { i64, ptr } %t554, %"compiler/source:Span" %t550)
  store { i64, [4 x i64] } %t556, ptr %l253
  br label %bb113
bb113:
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s0)
  %t557 = load { i64, [4 x i64] }, ptr %l253
  store { i64, [4 x i64] } %t557, ptr %rv
  br label %ret
bb114:
  %t558 = load i32, ptr %l1
  %t560 = trunc i64 20 to i32
  %t561 = icmp eq i32 %t558, %t560
  br i1 %t561, label %bb115, label %bb116
bb115:
  %t563 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t565 = extractvalue { i64, ptr } %t563, 0
  %t567 = icmp eq i64 %t565, 1
  store i1 %t567, ptr %l256, !tbaa !21
  br label %bb117
bb116:
  store i1 false, ptr %l256, !tbaa !21
  br label %bb117
bb117:
  %t569 = load i1, ptr %l256, !tbaa !21
  br i1 %t569, label %bb118, label %bb119
bb118:
  %t570 = load ptr, ptr %l0, !tbaa !29
  %t571 = load i32, ptr %l4, !tbaa !23
  %t574 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2evalueArray(ptr %v0, ptr %t570, i32 %t571)
  store i1 %t574, ptr %l263
  br label %bb120
bb119:
  store i1 false, ptr %l260, !tbaa !21
  br label %bb121
bb120:
  %t575 = load i1, ptr %l263, !tbaa !21
  store i1 %t575, ptr %l260, !tbaa !21
  br label %bb121
bb121:
  %t576 = load i1, ptr %l260, !tbaa !21
  br i1 %t576, label %bb122, label %bb123
bb122:
  %t577 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t577, ptr %l264, !tbaa !27
  %t578 = getelementptr { i64, ptr }, ptr %l264, i32 0, i32 1
  %t579 = load ptr, ptr %t578, !tbaa !27
  %t580 = getelementptr ptr, ptr %t579, i64 0
  %t581 = load ptr, ptr %t580, !tbaa !39
  store ptr %t581, ptr %l21, !tbaa !29
  %t583 = load ptr, ptr %l21, !tbaa !29
  store ptr %t583, ptr %l266, !tbaa !29
  store i1 false, ptr %l267, !tbaa !21
  %t584 = load ptr, ptr %l266, !tbaa !29
  %t585 = icmp ne ptr %t584, null
  br i1 %t585, label %bb124, label %bb125
bb123:
  br label %bb168
bb124:
  %t587 = load ptr, ptr %l266, !tbaa !29
  %t588 = load i64, ptr %t587
  %t590 = icmp eq i64 %t588, 7
  store i1 %t590, ptr %l267, !tbaa !21
  br label %bb125
bb125:
  %t591 = load i1, ptr %l267, !tbaa !21
  br i1 %t591, label %bb126, label %bb127
bb126:
  %t592 = load ptr, ptr %l21, !tbaa !29
  %t594 = getelementptr { i64, [5 x i64] }, ptr %t592, i32 0, i32 1
  %t595 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t594, i32 0, i32 1
  %t596 = load i32, ptr %t595
  store i32 %t596, ptr %l22, !tbaa !23
  %t598 = load ptr, ptr %l21, !tbaa !29
  %t600 = getelementptr { i64, [5 x i64] }, ptr %t598, i32 0, i32 1
  %t601 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t600, i32 0, i32 2
  %t602 = load ptr, ptr %t601
  store ptr %t602, ptr %l23, !tbaa !29
  br label %bb128
bb127:
  br label %bb162
bb128:
  %t604 = load ptr, ptr %l0, !tbaa !29
  %t605 = load i32, ptr %l22, !tbaa !23
  %t608 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %t604, i32 %t605)
  store i32 %t608, ptr %l276
  br label %bb129
bb129:
  %t609 = load i32, ptr %l276, !tbaa !23
  store i32 %t609, ptr %l24, !tbaa !23
  %t610 = load ptr, ptr %l23, !tbaa !29
  %t612 = getelementptr %"compiler/typed:Make", ptr %t610, i32 0, i32 0
  %t613 = load i32, ptr %t612
  %t615 = trunc i64 3 to i32
  %t616 = icmp eq i32 %t613, %t615
  br i1 %t616, label %bb130, label %bb131
bb130:
  store i1 true, ptr %l280, !tbaa !21
  br label %bb132
bb131:
  %t618 = load ptr, ptr %l23, !tbaa !29
  %t620 = getelementptr %"compiler/typed:Make", ptr %t618, i32 0, i32 0
  %t621 = load i32, ptr %t620
  %t623 = trunc i64 2 to i32
  %t624 = icmp eq i32 %t621, %t623
  store i1 %t624, ptr %l280, !tbaa !21
  br label %bb132
bb132:
  %t626 = load i1, ptr %l280, !tbaa !21
  br i1 %t626, label %bb133, label %bb134
bb133:
  %t627 = load ptr, ptr %l6, !tbaa !29
  store ptr %t627, ptr %l285, !tbaa !29
  %t628 = load ptr, ptr %l6, !tbaa !29
  %t629 = load i32, ptr %l22, !tbaa !23
  %t632 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t628, i32 %t629)
  store i32 %t632, ptr %l288
  br label %bb135
bb134:
  store i1 false, ptr %l284, !tbaa !21
  br label %bb137
bb135:
  %t633 = load ptr, ptr %l285, !tbaa !29
  %t634 = load i32, ptr %l288, !tbaa !23
  %t635 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t633, i32 %t634)
  store i1 %t635, ptr %l289
  br label %bb136
bb136:
  %t636 = load i1, ptr %l289, !tbaa !21
  %t637 = xor i1 %t636, true
  store i1 %t637, ptr %l284, !tbaa !21
  br label %bb137
bb137:
  %t639 = load i1, ptr %l284, !tbaa !21
  br i1 %t639, label %bb138, label %bb139
bb138:
  %t640 = load i32, ptr %l24, !tbaa !23
  %t641 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t644 = icmp ne i32 %t640, %t641
  store i1 %t644, ptr %l291, !tbaa !21
  br label %bb140
bb139:
  store i1 false, ptr %l291, !tbaa !21
  br label %bb140
bb140:
  %t646 = load i1, ptr %l291, !tbaa !21
  br i1 %t646, label %bb141, label %bb142
bb141:
  %t647 = load ptr, ptr %l0, !tbaa !29
  %t648 = load i32, ptr %l24, !tbaa !23
  %t651 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2efixedLen(ptr %v0, ptr %t647, i32 %t648)
  store i64 %t651, ptr %l298
  br label %bb143
bb142:
  store i1 false, ptr %l295, !tbaa !21
  br label %bb144
bb143:
  %t652 = load i64, ptr %l298, !tbaa !24
  %t653 = icmp sge i64 %t652, 0
  store i1 %t653, ptr %l295, !tbaa !21
  br label %bb144
bb144:
  %t655 = load i1, ptr %l295, !tbaa !21
  br i1 %t655, label %bb145, label %bb146
bb145:
  %t656 = load ptr, ptr %l0, !tbaa !29
  store ptr %t656, ptr %l301, !tbaa !29
  %t657 = load ptr, ptr %l0, !tbaa !29
  %t658 = load i32, ptr %l4, !tbaa !23
  %t661 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %t657, i32 %t658)
  store i32 %t661, ptr %l304
  br label %bb147
bb146:
  store i1 false, ptr %l300, !tbaa !21
  br label %bb149
bb147:
  %t662 = load ptr, ptr %l301, !tbaa !29
  %t663 = load i32, ptr %l304, !tbaa !23
  %t664 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2efixedLen(ptr %v0, ptr %t662, i32 %t663)
  store i64 %t664, ptr %l305
  br label %bb148
bb148:
  %t665 = load i64, ptr %l305, !tbaa !24
  %t666 = icmp slt i64 %t665, 0
  store i1 %t666, ptr %l300, !tbaa !21
  br label %bb149
bb149:
  %t668 = load i1, ptr %l300, !tbaa !21
  br i1 %t668, label %bb150, label %bb151
bb150:
  %t669 = load ptr, ptr %l23, !tbaa !29
  %t671 = getelementptr %"compiler/typed:Make", ptr %t669, i32 0, i32 4
  %t672 = load i32, ptr %t671, !tbaa !23
  %t674 = icmp sge i32 %t672, 0
  store i1 %t674, ptr %l307, !tbaa !21
  br label %bb152
bb151:
  store i1 false, ptr %l307, !tbaa !21
  br label %bb152
bb152:
  %t676 = load i1, ptr %l307, !tbaa !21
  br i1 %t676, label %bb153, label %bb154
bb153:
  %t677 = load ptr, ptr %l0, !tbaa !29
  %t678 = load ptr, ptr %l23, !tbaa !29
  %t680 = getelementptr %"compiler/typed:Make", ptr %t678, i32 0, i32 4
  %t681 = load i32, ptr %t680, !tbaa !23
  %t684 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ebuilt(ptr %v0, ptr %t677, i32 %t681)
  store { i64, [1 x i64] } %t684, ptr %l314
  br label %bb155
bb154:
  br label %bb161
bb155:
  %t685 = load { i64, [1 x i64] }, ptr %l314
  store { i64, [1 x i64] } %t685, ptr %l25
  %t686 = load ptr, ptr %l23, !tbaa !29
  %t688 = getelementptr %"compiler/typed:Make", ptr %t686, i32 0, i32 0
  %t689 = load i32, ptr %t688
  %t691 = trunc i64 3 to i32
  %t692 = icmp eq i32 %t689, %t691
  br i1 %t692, label %bb156, label %bb157
bb156:
  %t694 = load ptr, ptr %l0, !tbaa !29
  %t695 = load ptr, ptr %l23, !tbaa !29
  %t696 = load i32, ptr %l4, !tbaa !23
  %t697 = load %"compiler/source:Span", ptr %l5
  %t698 = load { i64, [1 x i64] }, ptr %l25
  %t704 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2efill(ptr %v0, ptr %v1, ptr %t694, ptr %t695, i32 %t696, %"compiler/source:Span" %t697, i1 true, { i64, [1 x i64] } %t698)
  store { i64, [4 x i64] } %t704, ptr %l324
  br label %bb158
bb157:
  %t705 = load ptr, ptr %l0, !tbaa !29
  %t706 = load ptr, ptr %l23, !tbaa !29
  %t707 = load i32, ptr %l4, !tbaa !23
  %t708 = load %"compiler/source:Span", ptr %l5
  %t709 = load { i64, [1 x i64] }, ptr %l25
  %t715 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2earrayLit(ptr %v0, ptr %v1, ptr %t705, ptr %t706, i32 %t707, %"compiler/source:Span" %t708, i1 true, { i64, [1 x i64] } %t709)
  store { i64, [4 x i64] } %t715, ptr %l330
  br label %bb159
bb158:
  %t716 = load { i64, [4 x i64] }, ptr %l324
  store { i64, [4 x i64] } %t716, ptr %l318
  br label %bb160
bb159:
  %t717 = load { i64, [4 x i64] }, ptr %l330
  store { i64, [4 x i64] } %t717, ptr %l318
  br label %bb160
bb160:
  call void @__olang_scope_close(ptr %s0)
  %t718 = load { i64, [4 x i64] }, ptr %l318
  store { i64, [4 x i64] } %t718, ptr %rv
  br label %ret
bb161:
  br label %bb167
bb162:
  br i1 true, label %bb163, label %bb164
bb163:
  br label %bb165
bb164:
  br label %bb166
bb165:
  br label %bb167
bb166:
  call void @__olang_check_failed(ptr @olang_loc_fcf54f1de4315015_3c2061767d7aa89)
  unreachable
bb167:
  br label %bb168
bb168:
  %t719 = load ptr, ptr %l0, !tbaa !29
  %t720 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t723 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2evals(ptr %v0, ptr %v1, ptr %s0, ptr %t719, { i64, ptr } %t720)
  store { i64, ptr } %t723, ptr %l333
  br label %bb169
bb169:
  %t724 = load { i64, ptr }, ptr %l333, !tbaa !27
  store { i64, ptr } %t724, ptr %l26, !tbaa !27
  %t725 = load ptr, ptr %l0, !tbaa !29
  %t727 = getelementptr %"compiler/lower:lowering", ptr %t725, i32 0, i32 7
  %t728 = load i1, ptr %t727, !tbaa !21
  br i1 %t728, label %bb170, label %bb171
bb170:
  store { i64, [4 x i64] } zeroinitializer, ptr %t730
  %t731 = getelementptr { i64, [4 x i64] }, ptr %t730, i32 0, i32 0
  store i64 0, ptr %t731
  %t732 = load { i64, [4 x i64] }, ptr %t730
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t732, ptr %rv
  br label %ret
bb171:
  br label %bb172
bb172:
  %t734 = load i32, ptr %l1
  %t736 = trunc i64 20 to i32
  %t737 = icmp eq i32 %t734, %t736
  br i1 %t737, label %bb173, label %bb174
bb173:
  %t739 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t741 = extractvalue { i64, ptr } %t739, 0
  %t743 = icmp eq i64 %t741, 1
  store i1 %t743, ptr %l339, !tbaa !21
  br label %bb175
bb174:
  store i1 false, ptr %l339, !tbaa !21
  br label %bb175
bb175:
  %t745 = load i1, ptr %l339, !tbaa !21
  br i1 %t745, label %bb176, label %bb177
bb176:
  %t746 = load ptr, ptr %l6, !tbaa !29
  %t747 = load i32, ptr %l4, !tbaa !23
  %t750 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t746, i32 %t747)
  store i32 %t750, ptr %l346
  br label %bb178
bb177:
  store i1 false, ptr %l343, !tbaa !21
  br label %bb179
bb178:
  %t751 = load i32, ptr %l346
  %t753 = trunc i64 32 to i32
  %t754 = icmp eq i32 %t751, %t753
  store i1 %t754, ptr %l343, !tbaa !21
  br label %bb179
bb179:
  %t756 = load i1, ptr %l343, !tbaa !21
  br i1 %t756, label %bb180, label %bb181
bb180:
  %t757 = load ptr, ptr %l6, !tbaa !29
  store ptr %t757, ptr %l350, !tbaa !29
  %t758 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t758, ptr %l351, !tbaa !27
  %t759 = getelementptr { i64, ptr }, ptr %l351, i32 0, i32 1
  %t760 = load ptr, ptr %t759, !tbaa !27
  %t761 = getelementptr ptr, ptr %t760, i64 0
  %t762 = load ptr, ptr %t761, !tbaa !39
  %t764 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t762)
  store i32 %t764, ptr %l353
  br label %bb182
bb181:
  store i1 false, ptr %l349, !tbaa !21
  br label %bb184
bb182:
  %t765 = load ptr, ptr %l350, !tbaa !29
  %t766 = load i32, ptr %l353, !tbaa !23
  %t767 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t765, i32 %t766)
  store i32 %t767, ptr %l354
  br label %bb183
bb183:
  %t768 = load i32, ptr %l354
  %t770 = trunc i64 32 to i32
  %t771 = icmp eq i32 %t768, %t770
  store i1 %t771, ptr %l349, !tbaa !21
  br label %bb184
bb184:
  %t773 = load i1, ptr %l349, !tbaa !21
  br i1 %t773, label %bb185, label %bb186
bb185:
  %t774 = load ptr, ptr %l0, !tbaa !29
  store ptr %t774, ptr %l357, !tbaa !29
  %t775 = load i32, ptr %l4, !tbaa !23
  store i32 %t775, ptr %l358, !tbaa !23
  %t776 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t777 = load ptr, ptr %t776, !tbaa !27
  %t778 = getelementptr { i64, [4 x i64] }, ptr %t777, i64 0
  %t779 = load { i64, [4 x i64] }, ptr %t778
  store { i64, [4 x i64] } %t779, ptr %l359
  %t780 = load ptr, ptr %l6, !tbaa !29
  store ptr %t780, ptr %l360, !tbaa !29
  %t781 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t781, ptr %l361, !tbaa !27
  %t782 = getelementptr { i64, ptr }, ptr %l361, i32 0, i32 1
  %t783 = load ptr, ptr %t782, !tbaa !27
  %t784 = getelementptr ptr, ptr %t783, i64 0
  %t785 = load ptr, ptr %t784, !tbaa !39
  %t787 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t785)
  store i32 %t787, ptr %l363
  br label %bb187
bb186:
  br label %bb191
bb187:
  %t788 = load ptr, ptr %l360, !tbaa !29
  %t789 = load i32, ptr %l363, !tbaa !23
  %t790 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %t788, i32 %t789)
  store i32 %t790, ptr %l364
  br label %bb188
bb188:
  %t791 = load ptr, ptr %l6, !tbaa !29
  %t792 = load i32, ptr %l4, !tbaa !23
  %t795 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %t791, i32 %t792)
  store i32 %t795, ptr %l367
  br label %bb189
bb189:
  store { i64, [15 x i64] } zeroinitializer, ptr %t796
  %t797 = getelementptr { i64, [15 x i64] }, ptr %t796, i32 0, i32 0
  store i64 11, ptr %t797
  %t798 = load { i64, [4 x i64] }, ptr %l359
  %t799 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t798, 0
  %t800 = load i32, ptr %l364, !tbaa !23
  %t801 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t799, i32 %t800, 1
  %t802 = load i32, ptr %l367, !tbaa !23
  %t803 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t801, i32 %t802, 2
  %t804 = getelementptr { i64, [15 x i64] }, ptr %t796, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t803, ptr %t804
  %t805 = load { i64, [15 x i64] }, ptr %t796
  %t806 = load %"compiler/source:Span", ptr %l5
  %t807 = load ptr, ptr %l357, !tbaa !29
  %t808 = load i32, ptr %l358, !tbaa !23
  %t811 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t807, i32 %t808, { i64, [15 x i64] } %t805, %"compiler/source:Span" %t806)
  store { i64, [4 x i64] } %t811, ptr %l370
  br label %bb190
bb190:
  call void @__olang_scope_close(ptr %s0)
  %t812 = load { i64, [4 x i64] }, ptr %l370
  store { i64, [4 x i64] } %t812, ptr %rv
  br label %ret
bb191:
  %t813 = load ptr, ptr %l0, !tbaa !29
  %t814 = load i32, ptr %l1
  %t815 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t816 = load i32, ptr %l4, !tbaa !23
  %t821 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ewidening(ptr %v0, ptr %v1, ptr %t813, i32 %t814, { i64, ptr } %t815, i32 %t816)
  store i1 %t821, ptr %l375
  br label %bb192
bb192:
  %t822 = load i1, ptr %l375, !tbaa !21
  br i1 %t822, label %bb193, label %bb194
bb193:
  %t823 = load ptr, ptr %l0, !tbaa !29
  store ptr %t823, ptr %l376, !tbaa !29
  %t824 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t825 = load ptr, ptr %t824, !tbaa !27
  %t826 = getelementptr { i64, [4 x i64] }, ptr %t825, i64 0
  %t827 = load { i64, [4 x i64] }, ptr %t826
  store { i64, [4 x i64] } %t827, ptr %l377
  %t828 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t828, ptr %l378, !tbaa !27
  %t829 = getelementptr { i64, ptr }, ptr %l378, i32 0, i32 1
  %t830 = load ptr, ptr %t829, !tbaa !27
  %t831 = getelementptr ptr, ptr %t830, i64 0
  %t832 = load ptr, ptr %t831, !tbaa !39
  %t834 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t832)
  store i32 %t834, ptr %l380
  br label %bb195
bb194:
  br label %bb198
bb195:
  %t835 = load i32, ptr %l4, !tbaa !23
  store i32 %t835, ptr %l381, !tbaa !23
  %t836 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t836, ptr %l382
  %t837 = load ptr, ptr %l0, !tbaa !29
  %t839 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einnermost(ptr %v0, ptr %t837)
  store { i64, [1 x i64] } %t839, ptr %l384
  br label %bb196
bb196:
  %t840 = load ptr, ptr %l376, !tbaa !29
  %t841 = load { i64, [4 x i64] }, ptr %l377
  %t842 = load i32, ptr %l380, !tbaa !23
  %t843 = load i32, ptr %l381, !tbaa !23
  %t844 = load %"compiler/source:Span", ptr %l382
  %t845 = load { i64, [1 x i64] }, ptr %l384
  %t846 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ewiden(ptr %v0, ptr %t840, { i64, [4 x i64] } %t841, i32 %t842, i32 %t843, %"compiler/source:Span" %t844, { i64, [1 x i64] } %t845)
  store { i64, [4 x i64] } %t846, ptr %l385
  br label %bb197
bb197:
  call void @__olang_scope_close(ptr %s0)
  %t847 = load { i64, [4 x i64] }, ptr %l385
  store { i64, [4 x i64] } %t847, ptr %rv
  br label %ret
bb198:
  %t848 = load i32, ptr %l1
  %t850 = trunc i64 23 to i32
  %t851 = icmp eq i32 %t848, %t850
  br i1 %t851, label %bb199, label %bb200
bb199:
  %t853 = load ptr, ptr %l6, !tbaa !29
  store ptr %t853, ptr %l389, !tbaa !29
  %t854 = load ptr, ptr %l6, !tbaa !29
  store ptr %t854, ptr %l390, !tbaa !29
  %t855 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t855, ptr %l391, !tbaa !27
  %t856 = getelementptr { i64, ptr }, ptr %l391, i32 0, i32 1
  %t857 = load ptr, ptr %t856, !tbaa !27
  %t858 = getelementptr ptr, ptr %t857, i64 0
  %t859 = load ptr, ptr %t858, !tbaa !39
  %t861 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t859)
  store i32 %t861, ptr %l393
  br label %bb201
bb200:
  store i1 false, ptr %l388, !tbaa !21
  br label %bb204
bb201:
  %t862 = load ptr, ptr %l390, !tbaa !29
  %t863 = load i32, ptr %l393, !tbaa !23
  %t864 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t862, i32 %t863)
  store i32 %t864, ptr %l394
  br label %bb202
bb202:
  %t865 = load ptr, ptr %l389, !tbaa !29
  %t866 = load i32, ptr %l394, !tbaa !23
  %t867 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t865, i32 %t866)
  store i1 %t867, ptr %l395
  br label %bb203
bb203:
  %t868 = load i1, ptr %l395, !tbaa !21
  store i1 %t868, ptr %l388, !tbaa !21
  br label %bb204
bb204:
  %t869 = load i1, ptr %l388, !tbaa !21
  br i1 %t869, label %bb205, label %bb206
bb205:
  %t870 = load ptr, ptr %l0, !tbaa !29
  store ptr %t870, ptr %l396, !tbaa !29
  %t871 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t872 = load ptr, ptr %t871, !tbaa !27
  %t873 = getelementptr { i64, [4 x i64] }, ptr %t872, i64 0
  %t874 = load { i64, [4 x i64] }, ptr %t873
  store { i64, [4 x i64] } %t874, ptr %l397
  %t875 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t875, ptr %l398, !tbaa !27
  %t876 = getelementptr { i64, ptr }, ptr %l398, i32 0, i32 1
  %t877 = load ptr, ptr %t876, !tbaa !27
  %t878 = getelementptr ptr, ptr %t877, i64 0
  %t879 = load ptr, ptr %t878, !tbaa !39
  %t881 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t879)
  store i32 %t881, ptr %l400
  br label %bb207
bb206:
  br label %bb209
bb207:
  %t882 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t883 = load ptr, ptr %t882, !tbaa !27
  %t884 = getelementptr { i64, [4 x i64] }, ptr %t883, i64 1
  %t885 = load { i64, [4 x i64] }, ptr %t884
  %t886 = load %"compiler/source:Span", ptr %l5
  %t887 = load ptr, ptr %l396, !tbaa !29
  %t888 = load { i64, [4 x i64] }, ptr %l397
  %t889 = load i32, ptr %l400, !tbaa !23
  %t892 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eisCaseRef(ptr %v0, ptr %t887, { i64, [4 x i64] } %t888, i32 %t889, { i64, [4 x i64] } %t885, %"compiler/source:Span" %t886)
  store { i64, [4 x i64] } %t892, ptr %l403
  br label %bb208
bb208:
  call void @__olang_scope_close(ptr %s0)
  %t893 = load { i64, [4 x i64] }, ptr %l403
  store { i64, [4 x i64] } %t893, ptr %rv
  br label %ret
bb209:
  %t894 = load i32, ptr %l2
  %t896 = trunc i64 0 to i32
  %t897 = icmp eq i32 %t894, %t896
  %t899 = xor i1 %t897, true
  br i1 %t899, label %bb210, label %bb211
bb210:
  %t901 = load ptr, ptr %l0, !tbaa !29
  %t902 = load i32, ptr %l1
  %t903 = load i32, ptr %l2
  %t904 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t905 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t906 = load i32, ptr %l4, !tbaa !23
  %t907 = load %"compiler/source:Span", ptr %l5
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eprimChecks(ptr %v0, ptr %s0, ptr %v1, ptr %t901, i32 %t902, i32 %t903, { i64, ptr } %t904, { i64, ptr } %t905, i32 %t906, %"compiler/source:Span" %t907)
  br label %bb212
bb211:
  br label %bb213
bb212:
  br label %bb213
bb213:
  %t915 = load ptr, ptr %l0, !tbaa !29
  %t916 = load i32, ptr %l1
  %t917 = load i32, ptr %l4, !tbaa !23
  %t918 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t919 = load %"compiler/source:Span", ptr %l5
  %t925 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %t915, i32 %t916, i32 %t917, { i64, ptr } %t918, %"compiler/source:Span" %t919)
  store { i64, [4 x i64] } %t925, ptr %l419
  br label %bb214
bb214:
  call void @__olang_scope_close(ptr %s0)
  %t926 = load { i64, [4 x i64] }, ptr %l419
  store { i64, [4 x i64] } %t926, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2epromote(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca i32
  %l14 = alloca { i64, [1 x i64] }
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca { i64, [1 x i64] }
  %l25 = alloca i32
  %l26 = alloca { i64, ptr }
  %l27 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca ptr
  %l30 = alloca i32
  %l31 = alloca { i64, [1 x i64] }
  %l32 = alloca { i64, [4 x i64] }
  %l33 = alloca { i64, [1 x i64] }
  %l34 = alloca { i64, [4 x i64] }
  %l35 = alloca ptr
  %l40 = alloca i32
  %l41 = alloca ptr
  %l44 = alloca i32
  %l45 = alloca i1
  %l46 = alloca i1
  %l50 = alloca i1
  %l53 = alloca i64
  %l57 = alloca ptr
  %l61 = alloca i1
  %l67 = alloca ptr
  %l68 = alloca i1
  %l81 = alloca { i64, ptr }
  %l98 = alloca ptr
  %l102 = alloca { i64, [1 x i64] }
  %l107 = alloca { i64, [4 x i64] }
  %l117 = alloca ptr
  %l118 = alloca i1
  %l126 = alloca i1
  %l130 = alloca i1
  %l141 = alloca ptr
  %l145 = alloca { i64, [1 x i64] }
  %l149 = alloca { i64, [4 x i64] }
  %l155 = alloca { i64, [4 x i64] }
  %l161 = alloca { i64, [4 x i64] }
  %l169 = alloca ptr
  %l170 = alloca i1
  %l179 = alloca i1
  %l183 = alloca i1
  %l186 = alloca i32
  %l188 = alloca { i64, ptr }
  %l190 = alloca ptr
  %l191 = alloca i1
  %l200 = alloca i32
  %l204 = alloca i1
  %l208 = alloca i1
  %l209 = alloca ptr
  %l212 = alloca i32
  %l213 = alloca i1
  %l215 = alloca i1
  %l219 = alloca i1
  %l222 = alloca i64
  %l227 = alloca { i64, [1 x i64] }
  %l231 = alloca { i64, [4 x i64] }
  %l237 = alloca { i64, [4 x i64] }
  %l243 = alloca { i64, [4 x i64] }
  %l248 = alloca { i64, [4 x i64] }
  %l255 = alloca { i64, [1 x i64] }
  %l263 = alloca { i64, [4 x i64] }
  %l268 = alloca i1
  %l269 = alloca i1
  %l270 = alloca ptr
  %l273 = alloca i32
  %l274 = alloca i32
  %l277 = alloca i1
  %l278 = alloca ptr
  %l281 = alloca i32
  %l282 = alloca i1
  %l283 = alloca i1
  %l284 = alloca ptr
  %l287 = alloca i32
  %l288 = alloca i1
  %l289 = alloca ptr
  %l290 = alloca %"compiler/source:Span"
  %l291 = alloca { i64, [1 x i64] }
  %l294 = alloca i32
  %s18 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t117 = alloca { i64, [4 x i64] }, align 8
  %t264 = alloca { i64, [1 x i64] }, align 8
  %t277 = alloca { i64, [1 x i64] }, align 8
  %t483 = alloca { i64, [4 x i64] }, align 8
  %t501 = alloca { i64, [15 x i64] }, align 8
  %t575 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l40
  br label %bb1
bb1:
  %t11 = load i32, ptr %l40, !tbaa !23
  store i32 %t11, ptr %l5, !tbaa !23
  %t12 = load ptr, ptr %l4, !tbaa !29
  store ptr %t12, ptr %l41, !tbaa !29
  %t13 = load ptr, ptr %l4, !tbaa !29
  %t14 = load i32, ptr %l2, !tbaa !23
  %t17 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t13, i32 %t14)
  store i32 %t17, ptr %l44
  br label %bb2
bb2:
  %t18 = load ptr, ptr %l41, !tbaa !29
  %t19 = load i32, ptr %l44, !tbaa !23
  %t20 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t18, i32 %t19)
  store i1 %t20, ptr %l45
  br label %bb3
bb3:
  %t21 = load i1, ptr %l45, !tbaa !21
  br i1 %t21, label %bb4, label %bb5
bb4:
  %t22 = load i32, ptr %l5, !tbaa !23
  %t23 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t26 = icmp ne i32 %t22, %t23
  store i1 %t26, ptr %l46, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb6
bb6:
  %t28 = load i1, ptr %l46, !tbaa !21
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i32, ptr %l5, !tbaa !23
  %t33 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2efixedLen(ptr %v0, ptr %t29, i32 %t30)
  store i64 %t33, ptr %l53
  br label %bb9
bb8:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb10
bb9:
  %t34 = load i64, ptr %l53, !tbaa !24
  %t35 = icmp slt i64 %t34, 0
  store i1 %t35, ptr %l50, !tbaa !21
  br label %bb10
bb10:
  %t37 = load i1, ptr %l50, !tbaa !21
  br i1 %t37, label %bb11, label %bb12
bb11:
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Promote", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = call ptr @compiler_2flower_2ecollectOf(ptr %v1, ptr %t41)
  store ptr %t43, ptr %l57
  br label %bb13
bb12:
  br label %bb121
bb13:
  %t44 = load ptr, ptr %l57, !tbaa !29
  store ptr %t44, ptr %l6, !tbaa !29
  %t45 = load ptr, ptr %l6, !tbaa !29
  %t47 = icmp eq ptr %t45, null
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb14, label %bb15
bb14:
  %t51 = load ptr, ptr %l6, !tbaa !29
  %t53 = getelementptr %"compiler/typed:Collect", ptr %t51, i32 0, i32 2
  %t54 = load i32, ptr %t53, !tbaa !23
  %t56 = icmp sge i32 %t54, 0
  store i1 %t56, ptr %l61, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb16
bb16:
  %t58 = load i1, ptr %l61, !tbaa !21
  br i1 %t58, label %bb17, label %bb18
bb17:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr %"compiler/typed:Promote", ptr %t59, i32 0, i32 0
  %t62 = load ptr, ptr %t61, !tbaa !29
  store ptr %t62, ptr %l7, !tbaa !29
  %t64 = load ptr, ptr %l7, !tbaa !29
  store ptr %t64, ptr %l67, !tbaa !29
  store i1 false, ptr %l68, !tbaa !21
  %t65 = load ptr, ptr %l67, !tbaa !29
  %t66 = icmp ne ptr %t65, null
  br i1 %t66, label %bb19, label %bb20
bb18:
  br label %bb42
bb19:
  %t68 = load ptr, ptr %l67, !tbaa !29
  %t69 = load i64, ptr %t68
  %t71 = icmp eq i64 %t69, 12
  store i1 %t71, ptr %l68, !tbaa !21
  br label %bb20
bb20:
  %t72 = load i1, ptr %l68, !tbaa !21
  br i1 %t72, label %bb21, label %bb22
bb21:
  %t73 = load ptr, ptr %l7, !tbaa !29
  %t75 = getelementptr { i64, [5 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t75, i32 0, i32 2
  %t77 = load ptr, ptr %t76
  store ptr %t77, ptr %l8, !tbaa !29
  br label %bb23
bb22:
  br label %bb34
bb23:
  %t79 = load ptr, ptr %l8, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Seq", ptr %t79, i32 0, i32 0
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  store { i64, ptr } %t82, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t84 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t84, 0
  store i64 %t86, ptr %l11, !tbaa !24
  br label %bb24
bb24:
  %t88 = load i64, ptr %l10, !tbaa !24
  %t89 = load i64, ptr %l11, !tbaa !24
  %t92 = icmp slt i64 %t88, %t89
  %t94 = xor i1 %t92, true
  br i1 %t94, label %bb25, label %bb26
bb25:
  br label %bb30
bb26:
  br label %bb27
bb27:
  %t96 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t96, ptr %l81, !tbaa !27
  %t97 = load i64, ptr %l10, !tbaa !24
  %t99 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr ptr, ptr %t100, i64 %t97
  %t102 = load ptr, ptr %t101, !tbaa !39
  %t104 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estmt(ptr %v0, ptr %v1, ptr %t104, ptr %t102)
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t108 = load i64, ptr %l10, !tbaa !24
  %t110 = add i64 %t108, 1
  store i64 %t110, ptr %l10, !tbaa !24
  br label %bb24
bb30:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/lower:lowering", ptr %t112, i32 0, i32 7
  %t115 = load i1, ptr %t114, !tbaa !21
  br i1 %t115, label %bb31, label %bb32
bb31:
  store { i64, [4 x i64] } zeroinitializer, ptr %t117
  %t118 = getelementptr { i64, [4 x i64] }, ptr %t117, i32 0, i32 0
  store i64 0, ptr %t118
  %t119 = load { i64, [4 x i64] }, ptr %t117
  store { i64, [4 x i64] } %t119, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  br label %bb39
bb34:
  br i1 true, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_f5162d6fd39a8c0b_7722e13858f6fdef)
  unreachable
bb39:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/lower:lowering", ptr %t121, i32 0, i32 20
  %t124 = load i32, ptr %t123, !tbaa !23
  store i32 %t124, ptr %l13, !tbaa !23
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/lower:lowering", ptr %t126, i32 0, i32 21
  %t129 = load { i64, [1 x i64] }, ptr %t128
  store { i64, [1 x i64] } %t129, ptr %l14
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load ptr, ptr %l6, !tbaa !29
  %t134 = getelementptr %"compiler/typed:Collect", ptr %t132, i32 0, i32 2
  %t135 = load i32, ptr %t134, !tbaa !23
  %t138 = getelementptr %"compiler/lower:lowering", ptr %t131, i32 0, i32 20
  store i32 %t135, ptr %t138, !tbaa !23
  %t139 = load ptr, ptr %l0, !tbaa !29
  store ptr %t139, ptr %l98, !tbaa !29
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load ptr, ptr %l1, !tbaa !29
  %t143 = getelementptr %"compiler/typed:Promote", ptr %t141, i32 0, i32 1
  %t144 = load i32, ptr %t143, !tbaa !23
  %t147 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ebuilt(ptr %v0, ptr %t140, i32 %t144)
  store { i64, [1 x i64] } %t147, ptr %l102
  br label %bb40
bb40:
  %t148 = load { i64, [1 x i64] }, ptr %l102
  %t149 = load ptr, ptr %l98, !tbaa !29
  %t150 = getelementptr %"compiler/lower:lowering", ptr %t149, i32 0, i32 21
  store { i64, [1 x i64] } %t148, ptr %t150
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load ptr, ptr %l6, !tbaa !29
  %t153 = load i32, ptr %l2, !tbaa !23
  %t154 = load %"compiler/source:Span", ptr %l3
  %t159 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ecollect(ptr %v0, ptr %v1, ptr %t151, ptr %t152, i32 %t153, %"compiler/source:Span" %t154)
  store { i64, [4 x i64] } %t159, ptr %l107
  br label %bb41
bb41:
  %t160 = load { i64, [4 x i64] }, ptr %l107
  %t161 = load i32, ptr %l13, !tbaa !23
  %t163 = load { i64, [1 x i64] }, ptr %l14
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/lower:lowering", ptr %t165, i32 0, i32 20
  store i32 %t161, ptr %t169, !tbaa !23
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t174 = getelementptr %"compiler/lower:lowering", ptr %t170, i32 0, i32 21
  store { i64, [1 x i64] } %t163, ptr %t174
  store { i64, [4 x i64] } %t160, ptr %rv
  br label %ret
bb42:
  %t177 = load ptr, ptr %l1, !tbaa !29
  %t179 = getelementptr %"compiler/typed:Promote", ptr %t177, i32 0, i32 0
  %t180 = load ptr, ptr %t179, !tbaa !29
  store ptr %t180, ptr %l18, !tbaa !29
  %t182 = load ptr, ptr %l18, !tbaa !29
  store ptr %t182, ptr %l117, !tbaa !29
  store i1 false, ptr %l118, !tbaa !21
  %t183 = load ptr, ptr %l117, !tbaa !29
  %t184 = icmp ne ptr %t183, null
  br i1 %t184, label %bb43, label %bb44
bb43:
  %t186 = load ptr, ptr %l117, !tbaa !29
  %t187 = load i64, ptr %t186
  %t189 = icmp eq i64 %t187, 7
  store i1 %t189, ptr %l118, !tbaa !21
  br label %bb44
bb44:
  %t190 = load i1, ptr %l118, !tbaa !21
  br i1 %t190, label %bb45, label %bb46
bb45:
  %t191 = load ptr, ptr %l18, !tbaa !29
  %t193 = getelementptr { i64, [5 x i64] }, ptr %t191, i32 0, i32 1
  %t194 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t193, i32 0, i32 2
  %t195 = load ptr, ptr %t194
  store ptr %t195, ptr %l19, !tbaa !29
  br label %bb47
bb46:
  br label %bb63
bb47:
  %t197 = load ptr, ptr %l19, !tbaa !29
  %t199 = getelementptr %"compiler/typed:Make", ptr %t197, i32 0, i32 0
  %t200 = load i32, ptr %t199
  %t202 = trunc i64 3 to i32
  %t203 = icmp eq i32 %t200, %t202
  br i1 %t203, label %bb48, label %bb49
bb48:
  store i1 true, ptr %l126, !tbaa !21
  br label %bb50
bb49:
  %t205 = load ptr, ptr %l19, !tbaa !29
  %t207 = getelementptr %"compiler/typed:Make", ptr %t205, i32 0, i32 0
  %t208 = load i32, ptr %t207
  %t210 = trunc i64 2 to i32
  %t211 = icmp eq i32 %t208, %t210
  store i1 %t211, ptr %l126, !tbaa !21
  br label %bb50
bb50:
  %t213 = load i1, ptr %l126, !tbaa !21
  br i1 %t213, label %bb51, label %bb52
bb51:
  %t214 = load ptr, ptr %l19, !tbaa !29
  %t216 = getelementptr %"compiler/typed:Make", ptr %t214, i32 0, i32 4
  %t217 = load i32, ptr %t216, !tbaa !23
  %t219 = icmp sge i32 %t217, 0
  store i1 %t219, ptr %l130, !tbaa !21
  br label %bb53
bb52:
  store i1 false, ptr %l130, !tbaa !21
  br label %bb53
bb53:
  %t221 = load i1, ptr %l130, !tbaa !21
  br i1 %t221, label %bb54, label %bb55
bb54:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/lower:lowering", ptr %t222, i32 0, i32 20
  %t225 = load i32, ptr %t224, !tbaa !23
  store i32 %t225, ptr %l20, !tbaa !23
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t229 = getelementptr %"compiler/lower:lowering", ptr %t227, i32 0, i32 21
  %t230 = load { i64, [1 x i64] }, ptr %t229
  store { i64, [1 x i64] } %t230, ptr %l21
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = load ptr, ptr %l19, !tbaa !29
  %t235 = getelementptr %"compiler/typed:Make", ptr %t233, i32 0, i32 4
  %t236 = load i32, ptr %t235, !tbaa !23
  %t239 = getelementptr %"compiler/lower:lowering", ptr %t232, i32 0, i32 20
  store i32 %t236, ptr %t239, !tbaa !23
  %t240 = load ptr, ptr %l0, !tbaa !29
  store ptr %t240, ptr %l141, !tbaa !29
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t242 = load ptr, ptr %l1, !tbaa !29
  %t244 = getelementptr %"compiler/typed:Promote", ptr %t242, i32 0, i32 1
  %t245 = load i32, ptr %t244, !tbaa !23
  %t248 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ebuilt(ptr %v0, ptr %t241, i32 %t245)
  store { i64, [1 x i64] } %t248, ptr %l145
  br label %bb56
bb55:
  br label %bb62
bb56:
  %t249 = load { i64, [1 x i64] }, ptr %l145
  %t250 = load ptr, ptr %l141, !tbaa !29
  %t251 = getelementptr %"compiler/lower:lowering", ptr %t250, i32 0, i32 21
  store { i64, [1 x i64] } %t249, ptr %t251
  %t252 = load ptr, ptr %l19, !tbaa !29
  %t254 = getelementptr %"compiler/typed:Make", ptr %t252, i32 0, i32 0
  %t255 = load i32, ptr %t254
  %t257 = trunc i64 3 to i32
  %t258 = icmp eq i32 %t255, %t257
  br i1 %t258, label %bb57, label %bb58
bb57:
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t261 = load ptr, ptr %l19, !tbaa !29
  %t262 = load i32, ptr %l2, !tbaa !23
  %t263 = load %"compiler/source:Span", ptr %l3
  store { i64, [1 x i64] } zeroinitializer, ptr %t264
  %t265 = getelementptr { i64, [1 x i64] }, ptr %t264, i32 0, i32 0
  store i64 2, ptr %t265
  %t266 = load { i64, [1 x i64] }, ptr %t264
  %t272 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2efill(ptr %v0, ptr %v1, ptr %t260, ptr %t261, i32 %t262, %"compiler/source:Span" %t263, i1 false, { i64, [1 x i64] } %t266)
  store { i64, [4 x i64] } %t272, ptr %l155
  br label %bb59
bb58:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t274 = load ptr, ptr %l19, !tbaa !29
  %t275 = load i32, ptr %l2, !tbaa !23
  %t276 = load %"compiler/source:Span", ptr %l3
  store { i64, [1 x i64] } zeroinitializer, ptr %t277
  %t278 = getelementptr { i64, [1 x i64] }, ptr %t277, i32 0, i32 0
  store i64 2, ptr %t278
  %t279 = load { i64, [1 x i64] }, ptr %t277
  %t285 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2earrayLit(ptr %v0, ptr %v1, ptr %t273, ptr %t274, i32 %t275, %"compiler/source:Span" %t276, i1 false, { i64, [1 x i64] } %t279)
  store { i64, [4 x i64] } %t285, ptr %l161
  br label %bb60
bb59:
  %t286 = load { i64, [4 x i64] }, ptr %l155
  store { i64, [4 x i64] } %t286, ptr %l149
  br label %bb61
bb60:
  %t287 = load { i64, [4 x i64] }, ptr %l161
  store { i64, [4 x i64] } %t287, ptr %l149
  br label %bb61
bb61:
  %t288 = load { i64, [4 x i64] }, ptr %l149
  %t289 = load i32, ptr %l20, !tbaa !23
  %t291 = load { i64, [1 x i64] }, ptr %l21
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t297 = getelementptr %"compiler/lower:lowering", ptr %t293, i32 0, i32 20
  store i32 %t289, ptr %t297, !tbaa !23
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t302 = getelementptr %"compiler/lower:lowering", ptr %t298, i32 0, i32 21
  store { i64, [1 x i64] } %t291, ptr %t302
  store { i64, [4 x i64] } %t288, ptr %rv
  br label %ret
bb62:
  br label %bb120
bb63:
  %t305 = load ptr, ptr %l18, !tbaa !29
  store ptr %t305, ptr %l169, !tbaa !29
  store i1 false, ptr %l170, !tbaa !21
  %t306 = load ptr, ptr %l169, !tbaa !29
  %t307 = icmp ne ptr %t306, null
  br i1 %t307, label %bb64, label %bb65
bb64:
  %t309 = load ptr, ptr %l169, !tbaa !29
  %t310 = load i64, ptr %t309
  %t312 = icmp eq i64 %t310, 9
  store i1 %t312, ptr %l170, !tbaa !21
  br label %bb65
bb65:
  %t313 = load i1, ptr %l170, !tbaa !21
  br i1 %t313, label %bb66, label %bb67
bb66:
  %t314 = load ptr, ptr %l18, !tbaa !29
  %t316 = getelementptr { i64, [5 x i64] }, ptr %t314, i32 0, i32 1
  %t317 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t316, i32 0, i32 2
  %t318 = load i32, ptr %t317
  store i32 %t318, ptr %l25
  %t320 = load ptr, ptr %l18, !tbaa !29
  %t322 = getelementptr { i64, [5 x i64] }, ptr %t320, i32 0, i32 1
  %t323 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t322, i32 0, i32 4
  %t324 = load { i64, ptr }, ptr %t323
  store { i64, ptr } %t324, ptr %l26, !tbaa !27
  br label %bb68
bb67:
  br label %bb115
bb68:
  %t326 = load i32, ptr %l25
  %t328 = trunc i64 20 to i32
  %t329 = icmp eq i32 %t326, %t328
  br i1 %t329, label %bb69, label %bb70
bb69:
  %t331 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t333 = extractvalue { i64, ptr } %t331, 0
  %t335 = icmp eq i64 %t333, 1
  store i1 %t335, ptr %l179, !tbaa !21
  br label %bb71
bb70:
  store i1 false, ptr %l179, !tbaa !21
  br label %bb71
bb71:
  %t337 = load i1, ptr %l179, !tbaa !21
  br i1 %t337, label %bb72, label %bb73
bb72:
  %t338 = load ptr, ptr %l4, !tbaa !29
  %t339 = load i32, ptr %l5, !tbaa !23
  %t342 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t338, i32 %t339)
  store i32 %t342, ptr %l186
  br label %bb74
bb73:
  store i1 false, ptr %l183, !tbaa !21
  br label %bb75
bb74:
  %t343 = load i32, ptr %l186, !tbaa !23
  %t344 = icmp eq i32 %t343, 0
  store i1 %t344, ptr %l183, !tbaa !21
  br label %bb75
bb75:
  %t346 = load i1, ptr %l183, !tbaa !21
  br i1 %t346, label %bb76, label %bb77
bb76:
  %t347 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t347, ptr %l188, !tbaa !27
  %t348 = getelementptr { i64, ptr }, ptr %l188, i32 0, i32 1
  %t349 = load ptr, ptr %t348, !tbaa !27
  %t350 = getelementptr ptr, ptr %t349, i64 0
  %t351 = load ptr, ptr %t350, !tbaa !39
  store ptr %t351, ptr %l27, !tbaa !29
  %t353 = load ptr, ptr %l27, !tbaa !29
  store ptr %t353, ptr %l190, !tbaa !29
  store i1 false, ptr %l191, !tbaa !21
  %t354 = load ptr, ptr %l190, !tbaa !29
  %t355 = icmp ne ptr %t354, null
  br i1 %t355, label %bb78, label %bb79
bb77:
  br label %bb114
bb78:
  %t357 = load ptr, ptr %l190, !tbaa !29
  %t358 = load i64, ptr %t357
  %t360 = icmp eq i64 %t358, 7
  store i1 %t360, ptr %l191, !tbaa !21
  br label %bb79
bb79:
  %t361 = load i1, ptr %l191, !tbaa !21
  br i1 %t361, label %bb80, label %bb81
bb80:
  %t362 = load ptr, ptr %l27, !tbaa !29
  %t364 = getelementptr { i64, [5 x i64] }, ptr %t362, i32 0, i32 1
  %t365 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t364, i32 0, i32 1
  %t366 = load i32, ptr %t365
  store i32 %t366, ptr %l28, !tbaa !23
  %t368 = load ptr, ptr %l27, !tbaa !29
  %t370 = getelementptr { i64, [5 x i64] }, ptr %t368, i32 0, i32 1
  %t371 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t370, i32 0, i32 2
  %t372 = load ptr, ptr %t371
  store ptr %t372, ptr %l29, !tbaa !29
  br label %bb82
bb81:
  br label %bb108
bb82:
  %t374 = load ptr, ptr %l0, !tbaa !29
  %t375 = load i32, ptr %l28, !tbaa !23
  %t378 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %t374, i32 %t375)
  store i32 %t378, ptr %l200
  br label %bb83
bb83:
  %t379 = load i32, ptr %l200, !tbaa !23
  store i32 %t379, ptr %l30, !tbaa !23
  %t380 = load ptr, ptr %l29, !tbaa !29
  %t382 = getelementptr %"compiler/typed:Make", ptr %t380, i32 0, i32 0
  %t383 = load i32, ptr %t382
  %t385 = trunc i64 3 to i32
  %t386 = icmp eq i32 %t383, %t385
  br i1 %t386, label %bb84, label %bb85
bb84:
  store i1 true, ptr %l204, !tbaa !21
  br label %bb86
bb85:
  %t388 = load ptr, ptr %l29, !tbaa !29
  %t390 = getelementptr %"compiler/typed:Make", ptr %t388, i32 0, i32 0
  %t391 = load i32, ptr %t390
  %t393 = trunc i64 2 to i32
  %t394 = icmp eq i32 %t391, %t393
  store i1 %t394, ptr %l204, !tbaa !21
  br label %bb86
bb86:
  %t396 = load i1, ptr %l204, !tbaa !21
  br i1 %t396, label %bb87, label %bb88
bb87:
  %t397 = load ptr, ptr %l4, !tbaa !29
  store ptr %t397, ptr %l209, !tbaa !29
  %t398 = load ptr, ptr %l4, !tbaa !29
  %t399 = load i32, ptr %l28, !tbaa !23
  %t402 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t398, i32 %t399)
  store i32 %t402, ptr %l212
  br label %bb89
bb88:
  store i1 false, ptr %l208, !tbaa !21
  br label %bb91
bb89:
  %t403 = load ptr, ptr %l209, !tbaa !29
  %t404 = load i32, ptr %l212, !tbaa !23
  %t405 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t403, i32 %t404)
  store i1 %t405, ptr %l213
  br label %bb90
bb90:
  %t406 = load i1, ptr %l213, !tbaa !21
  %t407 = xor i1 %t406, true
  store i1 %t407, ptr %l208, !tbaa !21
  br label %bb91
bb91:
  %t409 = load i1, ptr %l208, !tbaa !21
  br i1 %t409, label %bb92, label %bb93
bb92:
  %t410 = load i32, ptr %l30, !tbaa !23
  %t411 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t414 = icmp ne i32 %t410, %t411
  store i1 %t414, ptr %l215, !tbaa !21
  br label %bb94
bb93:
  store i1 false, ptr %l215, !tbaa !21
  br label %bb94
bb94:
  %t416 = load i1, ptr %l215, !tbaa !21
  br i1 %t416, label %bb95, label %bb96
bb95:
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t418 = load i32, ptr %l30, !tbaa !23
  %t421 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2efixedLen(ptr %v0, ptr %t417, i32 %t418)
  store i64 %t421, ptr %l222
  br label %bb97
bb96:
  store i1 false, ptr %l219, !tbaa !21
  br label %bb98
bb97:
  %t422 = load i64, ptr %l222, !tbaa !24
  %t423 = icmp sge i64 %t422, 0
  store i1 %t423, ptr %l219, !tbaa !21
  br label %bb98
bb98:
  %t425 = load i1, ptr %l219, !tbaa !21
  br i1 %t425, label %bb99, label %bb100
bb99:
  %t426 = load ptr, ptr %l0, !tbaa !29
  %t427 = load ptr, ptr %l1, !tbaa !29
  %t429 = getelementptr %"compiler/typed:Promote", ptr %t427, i32 0, i32 1
  %t430 = load i32, ptr %t429, !tbaa !23
  %t433 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ebuilt(ptr %v0, ptr %t426, i32 %t430)
  store { i64, [1 x i64] } %t433, ptr %l227
  br label %bb101
bb100:
  br label %bb107
bb101:
  %t434 = load { i64, [1 x i64] }, ptr %l227
  store { i64, [1 x i64] } %t434, ptr %l31
  %t435 = load ptr, ptr %l29, !tbaa !29
  %t437 = getelementptr %"compiler/typed:Make", ptr %t435, i32 0, i32 0
  %t438 = load i32, ptr %t437
  %t440 = trunc i64 3 to i32
  %t441 = icmp eq i32 %t438, %t440
  br i1 %t441, label %bb102, label %bb103
bb102:
  %t443 = load ptr, ptr %l0, !tbaa !29
  %t444 = load ptr, ptr %l29, !tbaa !29
  %t445 = load i32, ptr %l2, !tbaa !23
  %t446 = load %"compiler/source:Span", ptr %l3
  %t447 = load { i64, [1 x i64] }, ptr %l31
  %t453 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2efill(ptr %v0, ptr %v1, ptr %t443, ptr %t444, i32 %t445, %"compiler/source:Span" %t446, i1 true, { i64, [1 x i64] } %t447)
  store { i64, [4 x i64] } %t453, ptr %l237
  br label %bb104
bb103:
  %t454 = load ptr, ptr %l0, !tbaa !29
  %t455 = load ptr, ptr %l29, !tbaa !29
  %t456 = load i32, ptr %l2, !tbaa !23
  %t457 = load %"compiler/source:Span", ptr %l3
  %t458 = load { i64, [1 x i64] }, ptr %l31
  %t464 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2earrayLit(ptr %v0, ptr %v1, ptr %t454, ptr %t455, i32 %t456, %"compiler/source:Span" %t457, i1 true, { i64, [1 x i64] } %t458)
  store { i64, [4 x i64] } %t464, ptr %l243
  br label %bb105
bb104:
  %t465 = load { i64, [4 x i64] }, ptr %l237
  store { i64, [4 x i64] } %t465, ptr %l231
  br label %bb106
bb105:
  %t466 = load { i64, [4 x i64] }, ptr %l243
  store { i64, [4 x i64] } %t466, ptr %l231
  br label %bb106
bb106:
  %t467 = load { i64, [4 x i64] }, ptr %l231
  store { i64, [4 x i64] } %t467, ptr %rv
  br label %ret
bb107:
  br label %bb113
bb108:
  br i1 true, label %bb109, label %bb110
bb109:
  br label %bb111
bb110:
  br label %bb112
bb111:
  br label %bb113
bb112:
  call void @__olang_check_failed(ptr @olang_loc_3c6cf9f7cb6c21ca_21635d3489f6812e)
  unreachable
bb113:
  br label %bb114
bb114:
  br label %bb120
bb115:
  br i1 true, label %bb116, label %bb117
bb116:
  br label %bb118
bb117:
  br label %bb119
bb118:
  br label %bb120
bb119:
  call void @__olang_check_failed(ptr @olang_loc_deec9e883dfec261_7ab86f6deb3822e5)
  unreachable
bb120:
  br label %bb121
bb121:
  %t468 = load ptr, ptr %l0, !tbaa !29
  %t469 = load ptr, ptr %l1, !tbaa !29
  %t471 = getelementptr %"compiler/typed:Promote", ptr %t469, i32 0, i32 0
  %t472 = load ptr, ptr %t471, !tbaa !29
  %t476 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t468, ptr %t472)
  store { i64, [4 x i64] } %t476, ptr %l248
  br label %bb122
bb122:
  %t477 = load { i64, [4 x i64] }, ptr %l248
  store { i64, [4 x i64] } %t477, ptr %l32
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t480 = getelementptr %"compiler/lower:lowering", ptr %t478, i32 0, i32 7
  %t481 = load i1, ptr %t480, !tbaa !21
  br i1 %t481, label %bb123, label %bb124
bb123:
  store { i64, [4 x i64] } zeroinitializer, ptr %t483
  %t484 = getelementptr { i64, [4 x i64] }, ptr %t483, i32 0, i32 0
  store i64 0, ptr %t484
  %t485 = load { i64, [4 x i64] }, ptr %t483
  store { i64, [4 x i64] } %t485, ptr %rv
  br label %ret
bb124:
  br label %bb125
bb125:
  %t487 = load ptr, ptr %l0, !tbaa !29
  %t488 = load ptr, ptr %l1, !tbaa !29
  %t490 = getelementptr %"compiler/typed:Promote", ptr %t488, i32 0, i32 1
  %t491 = load i32, ptr %t490, !tbaa !23
  %t494 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ebuilt(ptr %v0, ptr %t487, i32 %t491)
  store { i64, [1 x i64] } %t494, ptr %l255
  br label %bb126
bb126:
  %t495 = load { i64, [1 x i64] }, ptr %l255
  store { i64, [1 x i64] } %t495, ptr %l33
  %t496 = load ptr, ptr %l0, !tbaa !29
  %t497 = load i32, ptr %l2, !tbaa !23
  %t498 = load { i64, [1 x i64] }, ptr %l33
  %t499 = load { i64, [4 x i64] }, ptr %l32
  %t500 = load i32, ptr %l2, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t501
  %t502 = getelementptr { i64, [15 x i64] }, ptr %t501, i32 0, i32 0
  store i64 7, ptr %t502
  %t504 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } undef, { i64, [1 x i64] } %t498, 0
  %t506 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t504, { i64, [4 x i64] } %t499, 1
  %t508 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t506, i32 %t500, 2
  %t509 = getelementptr { i64, [15 x i64] }, ptr %t501, i32 0, i32 1
  store { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t508, ptr %t509
  %t510 = load { i64, [15 x i64] }, ptr %t501
  %t511 = load %"compiler/source:Span", ptr %l3
  %t516 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t496, i32 %t497, { i64, [15 x i64] } %t510, %"compiler/source:Span" %t511)
  store { i64, [4 x i64] } %t516, ptr %l263
  br label %bb127
bb127:
  %t517 = load { i64, [4 x i64] }, ptr %l263
  store { i64, [4 x i64] } %t517, ptr %l34
  %t518 = load ptr, ptr %l0, !tbaa !29
  %t520 = getelementptr %"compiler/lower:lowering", ptr %t518, i32 0, i32 2
  %t521 = load ptr, ptr %t520, !tbaa !29
  store ptr %t521, ptr %l35, !tbaa !29
  %t523 = load ptr, ptr %l35, !tbaa !29
  %t524 = load i32, ptr %l2, !tbaa !23
  %t527 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t523, i32 %t524)
  store i1 %t527, ptr %l268
  br label %bb128
bb128:
  %t528 = load i1, ptr %l268, !tbaa !21
  br i1 %t528, label %bb129, label %bb130
bb129:
  %t529 = load ptr, ptr %l35, !tbaa !29
  store ptr %t529, ptr %l270, !tbaa !29
  %t530 = load ptr, ptr %l35, !tbaa !29
  %t531 = load i32, ptr %l2, !tbaa !23
  %t534 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t530, i32 %t531)
  store i32 %t534, ptr %l273
  br label %bb131
bb130:
  store i1 false, ptr %l269, !tbaa !21
  br label %bb133
bb131:
  %t535 = load ptr, ptr %l270, !tbaa !29
  %t536 = load i32, ptr %l273, !tbaa !23
  %t537 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t535, i32 %t536)
  store i32 %t537, ptr %l274
  br label %bb132
bb132:
  %t538 = load i32, ptr %l274
  %t540 = trunc i64 18 to i32
  %t541 = icmp eq i32 %t538, %t540
  store i1 %t541, ptr %l269, !tbaa !21
  br label %bb133
bb133:
  %t543 = load i1, ptr %l269, !tbaa !21
  br i1 %t543, label %bb134, label %bb135
bb134:
  %t544 = load ptr, ptr %l35, !tbaa !29
  store ptr %t544, ptr %l278, !tbaa !29
  %t545 = load ptr, ptr %l35, !tbaa !29
  %t546 = load i32, ptr %l2, !tbaa !23
  %t549 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t545, i32 %t546)
  store i32 %t549, ptr %l281
  br label %bb136
bb135:
  store i1 false, ptr %l277, !tbaa !21
  br label %bb138
bb136:
  %t550 = load ptr, ptr %l278, !tbaa !29
  %t551 = load i32, ptr %l281, !tbaa !23
  %t552 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t550, i32 %t551)
  store i1 %t552, ptr %l282
  br label %bb137
bb137:
  %t553 = load i1, ptr %l282, !tbaa !21
  store i1 %t553, ptr %l277, !tbaa !21
  br label %bb138
bb138:
  %t554 = load i1, ptr %l277, !tbaa !21
  br i1 %t554, label %bb139, label %bb140
bb139:
  %t555 = load ptr, ptr %l35, !tbaa !29
  store ptr %t555, ptr %l284, !tbaa !29
  %t556 = load ptr, ptr %l35, !tbaa !29
  %t557 = load i32, ptr %l2, !tbaa !23
  %t560 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t556, i32 %t557)
  store i32 %t560, ptr %l287
  br label %bb141
bb140:
  store i1 false, ptr %l283, !tbaa !21
  br label %bb143
bb141:
  %t561 = load ptr, ptr %l284, !tbaa !29
  %t562 = load i32, ptr %l287, !tbaa !23
  %t563 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %t561, i32 %t562)
  store i1 %t563, ptr %l288
  br label %bb142
bb142:
  %t564 = load i1, ptr %l288, !tbaa !21
  store i1 %t564, ptr %l283, !tbaa !21
  br label %bb143
bb143:
  %t565 = load i1, ptr %l283, !tbaa !21
  br i1 %t565, label %bb144, label %bb145
bb144:
  store %olang.scope zeroinitializer, ptr %s18
  %t566 = load ptr, ptr %l0, !tbaa !29
  store ptr %t566, ptr %l289, !tbaa !29
  %t567 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t567, ptr %l290
  %t568 = load { i64, [1 x i64] }, ptr %l33
  store { i64, [1 x i64] } %t568, ptr %l291
  %t569 = load ptr, ptr %l35, !tbaa !29
  %t570 = load i32, ptr %l2, !tbaa !23
  %t573 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t569, i32 %t570)
  store i32 %t573, ptr %l294
  br label %bb146
bb145:
  br label %bb148
bb146:
  %t574 = load { i64, [4 x i64] }, ptr %l34
  store { i64, [21 x i64] } zeroinitializer, ptr %t575
  %t576 = getelementptr { i64, [21 x i64] }, ptr %t575, i32 0, i32 0
  store i64 6, ptr %t576
  %t577 = load %"compiler/source:Span", ptr %l290
  %t578 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t577, 0
  %t579 = load { i64, [1 x i64] }, ptr %l291
  %t580 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t578, { i64, [1 x i64] } %t579, 1
  %t581 = load i32, ptr %l294, !tbaa !23
  %t582 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t580, i32 %t581, 2
  %t584 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t582, { i64, [4 x i64] } %t574, 3
  %t585 = getelementptr { i64, [21 x i64] }, ptr %t575, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t584, ptr %t585
  %t586 = load { i64, [21 x i64] }, ptr %t575
  %t588 = call ptr @__olang_scope_alloc_a(ptr %s18, i64 176, i64 8)
  store { i64, [21 x i64] } %t586, ptr %t588
  %t589 = load ptr, ptr %l289, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s18, ptr %t589, ptr %t588)
  br label %bb147
bb147:
  call void @__olang_scope_close(ptr %s18)
  br label %bb148
bb148:
  %t591 = load { i64, [4 x i64] }, ptr %l34
  store { i64, [4 x i64] } %t591, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eraise(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, { i64, [4 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca i1
  %l6 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca { i64, ptr }
  %l25 = alloca i32
  %l32 = alloca ptr
  %l33 = alloca %"compiler/source:Span"
  %l35 = alloca %"compiler/mir:Lvalue"
  %t29 = alloca { i64, [4 x i64] }, align 8
  %t32 = alloca { i64, [8 x i64] }, align 8
  %t74 = alloca { i64, [4 x i64] }, align 8
  %t80 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l6, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/lower:lowering", ptr %t5, i32 0, i32 2
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/lower:lowering", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t12, i32 0, i32 2
  %t15 = load i32, ptr %t14, !tbaa !23
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t8, i32 %t15)
  store i32 %t18, ptr %l12
  br label %bb1
bb1:
  %t19 = load ptr, ptr %l6, !tbaa !29
  %t20 = load i32, ptr %l12, !tbaa !23
  %t21 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t19, i32 %t20)
  store { i64, ptr } %t21, ptr %l13
  br label %bb2
bb2:
  %t22 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  %t25 = icmp eq i64 %t23, 0
  br i1 %t25, label %bb3, label %bb4
bb3:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load %"compiler/source:Span", ptr %l1
  store { i64, [4 x i64] } zeroinitializer, ptr %t29
  %t30 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 0
  store i64 0, ptr %t30
  %t31 = load { i64, [4 x i64] }, ptr %t29
  store { i64, [8 x i64] } zeroinitializer, ptr %t32
  %t33 = getelementptr { i64, [8 x i64] }, ptr %t32, i32 0, i32 0
  store i64 9, ptr %t33
  %t35 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t28, 0
  %t37 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t35, i32 3, 1
  %t39 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t37, { i64, [4 x i64] } %t31, 2
  %t40 = getelementptr { i64, [8 x i64] }, ptr %t32, i32 0, i32 1
  store { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t39, ptr %t40
  %t41 = load { i64, [8 x i64] }, ptr %t32
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t27, { i64, [8 x i64] } %t41)
  br label %bb5
bb4:
  br label %bb6
bb5:
  br label %ret
bb6:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t47 = load %"compiler/source:Span", ptr %l1
  %t52 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %t44, { i64, [4 x i64] } %a2, i32 %t46, %"compiler/source:Span" %t47)
  store i32 %t52, ptr %l25
  br label %bb7
bb7:
  %t53 = load i32, ptr %l25, !tbaa !23
  store i32 %t53, ptr %l3, !tbaa !23
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/lower:lowering", ptr %t54, i32 0, i32 18
  %t57 = load i1, ptr %t56, !tbaa !21
  store i1 %t57, ptr %l4, !tbaa !21
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/lower:lowering", ptr %t59, i32 0, i32 18
  store i1 true, ptr %t61, !tbaa !21
  %t62 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleave(ptr %v0, ptr %t62, i64 0)
  br label %bb8
bb8:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load i1, ptr %l4, !tbaa !21
  %t68 = getelementptr %"compiler/lower:lowering", ptr %t64, i32 0, i32 18
  store i1 %t65, ptr %t68, !tbaa !21
  %t69 = load ptr, ptr %l0, !tbaa !29
  store ptr %t69, ptr %l32, !tbaa !29
  %t70 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t70, ptr %l33
  %t71 = load i32, ptr %l3, !tbaa !23
  %t73 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t71)
  store %"compiler/mir:Lvalue" %t73, ptr %l35
  br label %bb9
bb9:
  store { i64, [4 x i64] } zeroinitializer, ptr %t74
  %t75 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 0
  store i64 1, ptr %t75
  %t76 = load %"compiler/mir:Lvalue", ptr %l35
  %t77 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t76, 0
  %t78 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t77, ptr %t78
  %t79 = load { i64, [4 x i64] }, ptr %t74
  store { i64, [8 x i64] } zeroinitializer, ptr %t80
  %t81 = getelementptr { i64, [8 x i64] }, ptr %t80, i32 0, i32 0
  store i64 7, ptr %t81
  %t82 = load %"compiler/source:Span", ptr %l33
  %t83 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t82, 0
  %t85 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t83, { i64, [4 x i64] } %t79, 1
  %t86 = getelementptr { i64, [8 x i64] }, ptr %t80, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t85, ptr %t86
  %t87 = load { i64, [8 x i64] }, ptr %t80
  %t88 = load ptr, ptr %l32, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t88, { i64, [8 x i64] } %t87)
  br label %bb10
bb10:
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eread(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca %"compiler/lower:pl"
  %l8 = alloca %"compiler/lower:pl"
  %l12 = alloca ptr
  %l13 = alloca i32
  %l16 = alloca %"compiler/mir:Lvalue"
  %l20 = alloca { i64, [4 x i64] }
  %rv = alloca { i64, [4 x i64] }
  %t13 = alloca { i64, [4 x i64] }, align 8
  %t24 = alloca { i64, [4 x i64] }, align 8
  %t30 = alloca { i64, [15 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t6 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eplace(ptr %v0, ptr %v1, ptr %v0, ptr %t1, ptr %a1)
  store %"compiler/lower:pl" %t6, ptr %l8
  br label %bb1
bb1:
  %t7 = load %"compiler/lower:pl", ptr %l8
  store %"compiler/lower:pl" %t7, ptr %l4
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/lower:lowering", ptr %t8, i32 0, i32 7
  %t11 = load i1, ptr %t10, !tbaa !21
  br i1 %t11, label %bb2, label %bb3
bb2:
  store { i64, [4 x i64] } zeroinitializer, ptr %t13
  %t14 = getelementptr { i64, [4 x i64] }, ptr %t13, i32 0, i32 0
  store i64 0, ptr %t14
  %t15 = load { i64, [4 x i64] }, ptr %t13
  store { i64, [4 x i64] } %t15, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l12, !tbaa !29
  store i32 %a2, ptr %l13, !tbaa !23
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load %"compiler/lower:pl", ptr %l4
  %t23 = call %"compiler/mir:Lvalue" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v0, ptr %t19, %"compiler/lower:pl" %t20)
  store %"compiler/mir:Lvalue" %t23, ptr %l16
  br label %bb5
bb5:
  store { i64, [4 x i64] } zeroinitializer, ptr %t24
  %t25 = getelementptr { i64, [4 x i64] }, ptr %t24, i32 0, i32 0
  store i64 1, ptr %t25
  %t26 = load %"compiler/mir:Lvalue", ptr %l16
  %t27 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t26, 0
  %t28 = getelementptr { i64, [4 x i64] }, ptr %t24, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t27, ptr %t28
  %t29 = load { i64, [4 x i64] }, ptr %t24
  store { i64, [15 x i64] } zeroinitializer, ptr %t30
  %t31 = getelementptr { i64, [15 x i64] }, ptr %t30, i32 0, i32 0
  store i64 0, ptr %t31
  %t33 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t29, 0
  %t34 = getelementptr { i64, [15 x i64] }, ptr %t30, i32 0, i32 1
  store { { i64, [4 x i64] } } %t33, ptr %t34
  %t35 = load { i64, [15 x i64] }, ptr %t30
  %t37 = load ptr, ptr %l12, !tbaa !29
  %t38 = load i32, ptr %l13, !tbaa !23
  %t41 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t37, i32 %t38, { i64, [15 x i64] } %t35, %"compiler/source:Span" %a3)
  store { i64, [4 x i64] } %t41, ptr %l20
  br label %bb6
bb6:
  %t42 = load { i64, [4 x i64] }, ptr %l20
  store { i64, [4 x i64] } %t42, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eregionOf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i64
  %l5 = alloca { i64, [1 x i64] }
  %l6 = alloca ptr
  %l7 = alloca { i64, [4 x i64] }
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i32
  %l30 = alloca i64
  %l32 = alloca { i64, ptr }
  %l37 = alloca { i64, [1 x i64] }
  %l40 = alloca { i64, ptr }
  %l43 = alloca { i64, [1 x i64] }
  %l47 = alloca ptr
  %l49 = alloca { i64, ptr }
  %l58 = alloca { i64, [4 x i64] }
  %l62 = alloca i32
  %l63 = alloca ptr
  %l64 = alloca %"compiler/source:Span"
  %l66 = alloca %"compiler/mir:Lvalue"
  %l85 = alloca i32
  %l86 = alloca ptr
  %l87 = alloca %"compiler/source:Span"
  %l89 = alloca %"compiler/mir:Lvalue"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, [1 x i64] }
  %t23 = alloca { i64, [1 x i64] }, align 8
  %t82 = alloca { i64, [1 x i64] }, align 8
  %t133 = alloca { i64, [15 x i64] }, align 8
  %t141 = alloca { i64, [21 x i64] }, align 8
  %t168 = alloca { i64, [1 x i64] }, align 8
  %t176 = alloca { i64, [1 x i64] }, align 8
  %t197 = alloca { i64, [15 x i64] }, align 8
  %t203 = alloca { i64, [21 x i64] }, align 8
  %t226 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 24
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fmir_3aLocalId_3e_2_H1e3bc46345ebb5614acbe688055fe55f(ptr %v0, ptr %t3, i64 %t4)
  %t8 = extractvalue { i32, i32 } %t7, 1
  %t9 = extractvalue { i32, i32 } %t7, 0
  store i32 %t9, ptr %l15
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i32 %t8, ptr %l14
  br label %bb1
bb1:
  %t12 = load i32, ptr %l14, !tbaa !23
  store i32 %t12, ptr %l10, !tbaa !23
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  %t13 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  store i32 %t13, ptr %l10, !tbaa !23
  br label %bb4
bb4:
  %t15 = load i32, ptr %l10, !tbaa !23
  store i32 %t15, ptr %l2, !tbaa !23
  %t16 = load i32, ptr %l2, !tbaa !23
  %t17 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t20 = icmp ne i32 %t16, %t17
  br i1 %t20, label %bb5, label %bb6
bb5:
  %t22 = load i32, ptr %l2, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t23
  %t24 = getelementptr { i64, [1 x i64] }, ptr %t23, i32 0, i32 0
  store i64 4, ptr %t24
  %t26 = insertvalue { i32 } undef, i32 %t22, 0
  %t27 = getelementptr { i64, [1 x i64] }, ptr %t23, i32 0, i32 1
  store { i32 } %t26, ptr %t27
  %t28 = load { i64, [1 x i64] }, ptr %t23
  call void @__olang_scope_close(ptr %s0)
  store { i64, [1 x i64] } %t28, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/lower:lowering", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/typed:Body", ptr %t33, i32 0, i32 4
  %t36 = load %"compiler/source:Span", ptr %t35
  store %"compiler/source:Span" %t36, ptr %l3
  %t38 = load i64, ptr %l1, !tbaa !24
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/lower:lowering", ptr %t39, i32 0, i32 22
  %t42 = getelementptr %"compiler/typed:Plan", ptr %t41, i32 0, i32 4
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t48 = icmp slt i64 %t38, %t45
  br i1 %t48, label %bb8, label %bb9
bb8:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/lower:lowering", ptr %t50, i32 0, i32 22
  %t53 = getelementptr %"compiler/typed:Plan", ptr %t52, i32 0, i32 4
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  store { i64, ptr } %t54, ptr %l32, !tbaa !27
  %t55 = load i64, ptr %l1, !tbaa !24
  %t57 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr i64, ptr %t58, i64 %t55
  %t60 = load i64, ptr %t59, !tbaa !34
  store i64 %t60, ptr %l30, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb10
bb10:
  %t62 = load i64, ptr %l30, !tbaa !24
  store i64 %t62, ptr %l4, !tbaa !24
  %t63 = load i64, ptr %l4, !tbaa !24
  %t65 = icmp ne i64 %t63, 0
  br i1 %t65, label %bb11, label %bb12
bb11:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/lower:lowering", ptr %t68, i32 0, i32 22
  %t71 = getelementptr %"compiler/typed:Plan", ptr %t70, i32 0, i32 5
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  store { i64, ptr } %t72, ptr %l40, !tbaa !27
  %t73 = load i64, ptr %l1, !tbaa !24
  %t75 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr { i64, [1 x i64] }, ptr %t76, i64 %t73
  %t78 = load { i64, [1 x i64] }, ptr %t77
  %t81 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2escopeRef(ptr %v0, ptr %t67, { i64, [1 x i64] } %t78)
  store { i64, [1 x i64] } %t81, ptr %l43
  br label %bb13
bb12:
  store { i64, [1 x i64] } zeroinitializer, ptr %t82
  %t83 = getelementptr { i64, [1 x i64] }, ptr %t82, i32 0, i32 0
  store i64 2, ptr %t83
  %t84 = load { i64, [1 x i64] }, ptr %t82
  store { i64, [1 x i64] } %t84, ptr %l37
  br label %bb14
bb13:
  %t86 = load { i64, [1 x i64] }, ptr %l43
  store { i64, [1 x i64] } %t86, ptr %l37
  br label %bb14
bb14:
  %t87 = load { i64, [1 x i64] }, ptr %l37
  store { i64, [1 x i64] } %t87, ptr %l5
  %t88 = load i64, ptr %l4, !tbaa !24
  %t90 = icmp ne i64 %t88, 0
  br i1 %t90, label %bb15, label %bb16
bb15:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/lower:lowering", ptr %t92, i32 0, i32 22
  %t95 = getelementptr %"compiler/typed:Plan", ptr %t94, i32 0, i32 6
  %t96 = load { i64, ptr }, ptr %t95, !tbaa !27
  store { i64, ptr } %t96, ptr %l49, !tbaa !27
  %t97 = load i64, ptr %l1, !tbaa !24
  %t99 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr ptr, ptr %t100, i64 %t97
  %t102 = load ptr, ptr %t101, !tbaa !39
  store ptr %t102, ptr %l47, !tbaa !29
  br label %bb17
bb16:
  store ptr null, ptr %l47, !tbaa !29
  br label %bb17
bb17:
  %t104 = load ptr, ptr %l47, !tbaa !29
  store ptr %t104, ptr %l6, !tbaa !29
  %t105 = load ptr, ptr %l6, !tbaa !29
  %t107 = icmp eq ptr %t105, null
  %t109 = xor i1 %t107, true
  br i1 %t109, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s2
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load ptr, ptr %l6, !tbaa !29
  %t116 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v0, ptr %t111, ptr %t112)
  store { i64, [4 x i64] } %t116, ptr %l58
  br label %bb20
bb19:
  br label %bb28
bb20:
  %t117 = load { i64, [4 x i64] }, ptr %l58
  store { i64, [4 x i64] } %t117, ptr %l7
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t120 = load %"compiler/source:Span", ptr %l3
  %t124 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t118, i32 %t119, %"compiler/source:Span" %t120)
  store i32 %t124, ptr %l62
  br label %bb21
bb21:
  %t125 = load i32, ptr %l62, !tbaa !23
  store i32 %t125, ptr %l8, !tbaa !23
  %t126 = load ptr, ptr %l0, !tbaa !29
  store ptr %t126, ptr %l63, !tbaa !29
  %t127 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t127, ptr %l64
  %t128 = load i32, ptr %l8, !tbaa !23
  %t130 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t128)
  store %"compiler/mir:Lvalue" %t130, ptr %l66
  br label %bb22
bb22:
  %t131 = load { i64, [4 x i64] }, ptr %l7
  %t132 = load { i64, [1 x i64] }, ptr %l5
  store { i64, [15 x i64] } zeroinitializer, ptr %t133
  %t134 = getelementptr { i64, [15 x i64] }, ptr %t133, i32 0, i32 0
  store i64 14, ptr %t134
  %t136 = insertvalue { { i64, [4 x i64] }, { i64, [1 x i64] } } undef, { i64, [4 x i64] } %t131, 0
  %t138 = insertvalue { { i64, [4 x i64] }, { i64, [1 x i64] } } %t136, { i64, [1 x i64] } %t132, 1
  %t139 = getelementptr { i64, [15 x i64] }, ptr %t133, i32 0, i32 1
  store { { i64, [4 x i64] }, { i64, [1 x i64] } } %t138, ptr %t139
  %t140 = load { i64, [15 x i64] }, ptr %t133
  store { i64, [21 x i64] } zeroinitializer, ptr %t141
  %t142 = getelementptr { i64, [21 x i64] }, ptr %t141, i32 0, i32 0
  store i64 0, ptr %t142
  %t143 = load %"compiler/source:Span", ptr %l64
  %t144 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t143, 0
  %t145 = load %"compiler/mir:Lvalue", ptr %l66
  %t146 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t144, %"compiler/mir:Lvalue" %t145, 1
  %t148 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t146, { i64, [15 x i64] } %t140, 2
  %t149 = getelementptr { i64, [21 x i64] }, ptr %t141, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t148, ptr %t149
  %t150 = load { i64, [21 x i64] }, ptr %t141
  %t152 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 176, i64 8)
  store { i64, [21 x i64] } %t150, ptr %t152
  %t153 = load ptr, ptr %l63, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s2, ptr %t153, ptr %t152)
  br label %bb23
bb23:
  %t155 = load i64, ptr %l4, !tbaa !24
  %t157 = icmp eq i64 %t155, 2
  br i1 %t157, label %bb24, label %bb25
bb24:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/lower:lowering", ptr %t159, i32 0, i32 24
  %t162 = load i64, ptr %l1, !tbaa !24
  %t163 = load i32, ptr %l8, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fmir_3aLocalId_3e_2_H6363fee5e3f1c076b4ec00933ab48c6c(ptr %v0, ptr %t161, i64 %t162, i32 %t163)
  br label %bb26
bb25:
  br label %bb27
bb26:
  %t167 = load i32, ptr %l8, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t168
  %t169 = getelementptr { i64, [1 x i64] }, ptr %t168, i32 0, i32 0
  store i64 4, ptr %t169
  %t171 = insertvalue { i32 } undef, i32 %t167, 0
  %t172 = getelementptr { i64, [1 x i64] }, ptr %t168, i32 0, i32 1
  store { i32 } %t171, ptr %t172
  %t173 = load { i64, [1 x i64] }, ptr %t168
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store { i64, [1 x i64] } %t173, ptr %rv
  br label %ret
bb27:
  %t175 = load i32, ptr %l8, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t176
  %t177 = getelementptr { i64, [1 x i64] }, ptr %t176, i32 0, i32 0
  store i64 4, ptr %t177
  %t179 = insertvalue { i32 } undef, i32 %t175, 0
  %t180 = getelementptr { i64, [1 x i64] }, ptr %t176, i32 0, i32 1
  store { i32 } %t179, ptr %t180
  %t181 = load { i64, [1 x i64] }, ptr %t176
  store { i64, [1 x i64] } %t181, ptr %l5
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb28:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t185 = load %"compiler/source:Span", ptr %l3
  %t189 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t183, i32 %t184, %"compiler/source:Span" %t185)
  store i32 %t189, ptr %l85
  br label %bb29
bb29:
  %t190 = load i32, ptr %l85, !tbaa !23
  store i32 %t190, ptr %l9, !tbaa !23
  %t191 = load ptr, ptr %l0, !tbaa !29
  store ptr %t191, ptr %l86, !tbaa !29
  %t192 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t192, ptr %l87
  %t193 = load i32, ptr %l9, !tbaa !23
  %t195 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t193)
  store %"compiler/mir:Lvalue" %t195, ptr %l89
  br label %bb30
bb30:
  %t196 = load { i64, [1 x i64] }, ptr %l5
  store { i64, [15 x i64] } zeroinitializer, ptr %t197
  %t198 = getelementptr { i64, [15 x i64] }, ptr %t197, i32 0, i32 0
  store i64 13, ptr %t198
  %t200 = insertvalue { { i64, [1 x i64] } } undef, { i64, [1 x i64] } %t196, 0
  %t201 = getelementptr { i64, [15 x i64] }, ptr %t197, i32 0, i32 1
  store { { i64, [1 x i64] } } %t200, ptr %t201
  %t202 = load { i64, [15 x i64] }, ptr %t197
  store { i64, [21 x i64] } zeroinitializer, ptr %t203
  %t204 = getelementptr { i64, [21 x i64] }, ptr %t203, i32 0, i32 0
  store i64 0, ptr %t204
  %t205 = load %"compiler/source:Span", ptr %l87
  %t206 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t205, 0
  %t207 = load %"compiler/mir:Lvalue", ptr %l89
  %t208 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t206, %"compiler/mir:Lvalue" %t207, 1
  %t210 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t208, { i64, [15 x i64] } %t202, 2
  %t211 = getelementptr { i64, [21 x i64] }, ptr %t203, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t210, ptr %t211
  %t212 = load { i64, [21 x i64] }, ptr %t203
  %t214 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t212, ptr %t214
  %t215 = load ptr, ptr %l86, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t215, ptr %t214)
  br label %bb31
bb31:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t219 = getelementptr %"compiler/lower:lowering", ptr %t217, i32 0, i32 24
  %t220 = load i64, ptr %l1, !tbaa !24
  %t221 = load i32, ptr %l9, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fmir_3aLocalId_3e_2_H6363fee5e3f1c076b4ec00933ab48c6c(ptr %v0, ptr %t219, i64 %t220, i32 %t221)
  br label %bb32
bb32:
  %t225 = load i32, ptr %l9, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t226
  %t227 = getelementptr { i64, [1 x i64] }, ptr %t226, i32 0, i32 0
  store i64 4, ptr %t227
  %t229 = insertvalue { i32 } undef, i32 %t225, 0
  %t230 = getelementptr { i64, [1 x i64] }, ptr %t226, i32 0, i32 1
  store { i32 } %t229, ptr %t230
  %t231 = load { i64, [1 x i64] }, ptr %t226
  call void @__olang_scope_close(ptr %s0)
  store { i64, [1 x i64] } %t231, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2flower_2ecompiler_2flower_3alowering_2ereleases(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca %"compiler/free:leaf"
  %lp9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca ptr
  %l23 = alloca i1
  %l36 = alloca i64
  %l39 = alloca ptr
  %l42 = alloca i1
  %l43 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l50 = alloca ptr
  %l52 = alloca i32
  %l53 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l55 = alloca i64
  %l57 = alloca i64
  %l62 = alloca %"compiler/free:leaf"
  %l65 = alloca i1
  %l68 = alloca i64
  %l77 = alloca i64
  %l80 = alloca i64
  %l99 = alloca { i64, ptr }
  %s6 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l16
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t2, ptr %lp3
  %t3 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l16
  %t4 = load ptr, ptr %lp3
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/lower:lowering", ptr %t5, i32 0, i32 23
  %t8 = load i1, ptr %t7, !tbaa !21
  %t10 = xor i1 %t8, true
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %lp3
  %t13 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t12
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  br i1 %a2, label %bb5, label %bb6
bb5:
  %t17 = load ptr, ptr %l1, !tbaa !29
  store ptr %t17, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t18 = load ptr, ptr %l22, !tbaa !29
  %t19 = icmp ne ptr %t18, null
  br i1 %t19, label %bb7, label %bb8
bb6:
  br label %bb18
bb7:
  %t21 = load ptr, ptr %l22, !tbaa !29
  %t22 = load i64, ptr %t21
  %t24 = icmp eq i64 %t22, 4
  store i1 %t24, ptr %l23, !tbaa !21
  br label %bb8
bb8:
  %t25 = load i1, ptr %l23, !tbaa !21
  br i1 %t25, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t26 = load ptr, ptr %lp3
  %t27 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t26
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t27, ptr %rv
  br label %ret
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_b05049138e3c9583_5b10da44a83c4f97)
  unreachable
bb17:
  br label %bb18
bb18:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/lower:lowering", ptr %t29, i32 0, i32 0
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/lower:Lowerer", ptr %t32, i32 0, i32 3
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = icmp eq ptr %t35, null
  br i1 %t37, label %bb19, label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_7978ceed25dd57db_b68e0a2baf6deaf)
  unreachable
bb20:
  br label %bb21
bb21:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/lower:lowering", ptr %t39, i32 0, i32 0
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = getelementptr %"compiler/lower:Lowerer", ptr %t42, i32 0, i32 3
  %t45 = load ptr, ptr %t44, !tbaa !29
  store ptr %t45, ptr %l4, !tbaa !29
  %t47 = load ptr, ptr %l4, !tbaa !29
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t51 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eSolePlace(ptr %v0, ptr %v1, ptr %t47, ptr %t48)
  store i64 %t51, ptr %l36
  br label %bb22
bb22:
  %t52 = load i64, ptr %l36, !tbaa !24
  store i64 %t52, ptr %l5, !tbaa !24
  %t53 = load i64, ptr %l5, !tbaa !24
  %t55 = icmp sge i64 %t53, 0
  br i1 %t55, label %bb23, label %bb24
bb23:
  %t57 = load ptr, ptr %lp3
  store ptr %t57, ptr %l39, !tbaa !29
  %t58 = load ptr, ptr %l4, !tbaa !29
  %t59 = load i64, ptr %l5, !tbaa !24
  %t62 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsHandle(ptr %v0, ptr %t58, i64 %t59)
  store i1 %t62, ptr %l42
  br label %bb25
bb24:
  br label %bb34
bb25:
  %t63 = load i1, ptr %l42, !tbaa !21
  br i1 %t63, label %bb26, label %bb27
bb26:
  %t64 = mul i64 1, 8
  %t65 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t64)
  %t66 = insertvalue { i64, ptr } undef, i64 1, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t65, 1
  store { i64, ptr } %t67, ptr %l44, !tbaa !27
  %t68 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr i64, ptr %t69, i64 0
  store i64 0, ptr %t70, !tbaa !34
  %t71 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t71, ptr %l43, !tbaa !27
  br label %bb32
bb27:
  %t72 = icmp sge i64 0, 0
  br i1 %t72, label %bb28, label %bb29
bb28:
  %t74 = icmp sle i64 0, 1152921504606846975
  br i1 %t74, label %bb30, label %bb31
bb29:
  call void @__olang_check_failed(ptr @olang_loc_6cf042e1e67efefa_11456615317dde16)
  unreachable
bb30:
  %t76 = mul i64 0, 8
  %t77 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t76)
  %t78 = insertvalue { i64, ptr } undef, i64 0, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  store { i64, ptr } %t79, ptr %l43, !tbaa !27
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_6cf042e1e67efefa_11456615317dde16)
  unreachable
bb32:
  %t81 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t81, 0
  %t83 = extractvalue { i64, ptr } %t81, 1
  %t84 = mul i64 %t82, 8
  %t85 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t84)
  call void @llvm.memcpy.p0.p0.i64(ptr %t85, ptr %t83, i64 %t84, i1 false)
  %t86 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t85, 1
  %t88 = load ptr, ptr %l39, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v2, ptr %v2, ptr %t88, { i64, ptr } %t87)
  br label %bb33
bb33:
  %t90 = load ptr, ptr %lp3
  %t91 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t90
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t91, ptr %rv
  br label %ret
bb34:
  store %olang.scope zeroinitializer, ptr %s6
  %t93 = load ptr, ptr %l4, !tbaa !29
  store ptr %t93, ptr %l50, !tbaa !29
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t96 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t94)
  store i32 %t96, ptr %l52
  br label %bb35
bb35:
  %t97 = load ptr, ptr %l50, !tbaa !29
  %t98 = load i32, ptr %l52, !tbaa !23
  %t99 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eSoleLeaves(ptr %v0, ptr %v0, ptr %t97, i32 %t98)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t99, ptr %l53
  br label %bb36
bb36:
  %t100 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l53
  %t101 = call ptr @__olang_scope_alloc_a(ptr %s6, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t100, ptr %t101
  store ptr %t101, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb37
bb37:
  %t103 = load i64, ptr %l7, !tbaa !24
  store i64 %t103, ptr %l55, !tbaa !24
  %t104 = load ptr, ptr %l6, !tbaa !29
  %t106 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %t104)
  store i64 %t106, ptr %l57
  br label %bb38
bb38:
  %t107 = load i64, ptr %l55, !tbaa !24
  %t108 = load i64, ptr %l57, !tbaa !24
  %t109 = icmp slt i64 %t107, %t108
  %t111 = xor i1 %t109, true
  br i1 %t111, label %bb39, label %bb40
bb39:
  br label %bb66
bb40:
  br label %bb41
bb41:
  %t113 = load ptr, ptr %l6, !tbaa !29
  %t114 = load i64, ptr %l7, !tbaa !24
  %t117 = call %"compiler/free:leaf" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eAt_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %v0, ptr %t113, i64 %t114)
  store %"compiler/free:leaf" %t117, ptr %l62
  br label %bb42
bb42:
  %t118 = load %"compiler/free:leaf", ptr %l62
  store %"compiler/free:leaf" %t118, ptr %l8
  %t119 = load ptr, ptr %l4, !tbaa !29
  %t120 = getelementptr %"compiler/free:leaf", ptr %l8, i32 0, i32 1
  %t121 = load i64, ptr %t120, !tbaa !24
  %t124 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsHandle(ptr %v0, ptr %t119, i64 %t121)
  store i1 %t124, ptr %l65
  br label %bb43
bb43:
  %t125 = load i1, ptr %l65, !tbaa !21
  br i1 %t125, label %bb44, label %bb45
bb44:
  %t126 = getelementptr %"compiler/free:leaf", ptr %l8, i32 0, i32 0
  %t127 = load { i64, ptr }, ptr %t126, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t127, 0
  %t131 = add i64 %t129, 1
  store i64 %t131, ptr %l68, !tbaa !24
  %t132 = load i64, ptr %l68, !tbaa !24
  %t133 = icmp sge i64 %t132, 0
  br i1 %t133, label %bb46, label %bb47
bb45:
  %t135 = load ptr, ptr %lp3
  %t136 = getelementptr %"compiler/free:leaf", ptr %l8, i32 0, i32 0
  %t137 = load { i64, ptr }, ptr %t136, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v2, ptr %v0, ptr %t135, { i64, ptr } %t137)
  br label %bb63
bb46:
  %t140 = load i64, ptr %l68, !tbaa !24
  %t141 = icmp sle i64 %t140, 1152921504606846975
  br i1 %t141, label %bb48, label %bb49
bb47:
  call void @__olang_check_failed(ptr @olang_loc_16ea37ec2dd8d64f_b36c061d5e238e2b)
  unreachable
bb48:
  %t143 = load i64, ptr %l68, !tbaa !24
  %t144 = mul i64 %t143, 8
  %t145 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t144)
  %t146 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t147 = insertvalue { i64, ptr } %t146, ptr %t145, 1
  %t148 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t148, ptr %lp9
  %t150 = load ptr, ptr %lp9
  store { i64, ptr } %t147, ptr %t150, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t151 = getelementptr %"compiler/free:leaf", ptr %l8, i32 0, i32 0
  %t152 = load { i64, ptr }, ptr %t151, !tbaa !27
  %t154 = extractvalue { i64, ptr } %t152, 0
  store i64 %t154, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t156 = load i64, ptr %l11, !tbaa !24
  %t157 = load i64, ptr %l10, !tbaa !24
  %t160 = icmp sgt i64 %t156, %t157
  br i1 %t160, label %bb50, label %bb51
bb49:
  call void @__olang_check_failed(ptr @olang_loc_16ea37ec2dd8d64f_b36c061d5e238e2b)
  unreachable
bb50:
  %t162 = load i64, ptr %l12, !tbaa !24
  %t164 = icmp sgt i64 %t162, 0
  br i1 %t164, label %bb52, label %bb53
bb51:
  store i64 0, ptr %l77, !tbaa !24
  br label %bb55
bb52:
  %t166 = load i64, ptr %l11, !tbaa !24
  %t167 = load i64, ptr %l10, !tbaa !24
  %t170 = sub i64 %t166, %t167
  %t171 = load i64, ptr %l12, !tbaa !24
  %t174 = add i64 %t170, %t171
  %t176 = sub i64 %t174, 1
  %t177 = load i64, ptr %l12, !tbaa !24
  %t180 = sdiv i64 %t176, %t177
  store i64 %t180, ptr %l80, !tbaa !24
  br label %bb54
bb53:
  store i64 0, ptr %l80, !tbaa !24
  br label %bb54
bb54:
  %t182 = load i64, ptr %l80, !tbaa !24
  store i64 %t182, ptr %l77, !tbaa !24
  br label %bb55
bb55:
  %t183 = load i64, ptr %l77, !tbaa !24
  store i64 %t183, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb56
bb56:
  %t184 = load i64, ptr %l14, !tbaa !24
  %t185 = load i64, ptr %l13, !tbaa !24
  %t188 = icmp slt i64 %t184, %t185
  %t190 = xor i1 %t188, true
  br i1 %t190, label %bb57, label %bb58
bb57:
  br label %bb61
bb58:
  br label %bb59
bb59:
  %t192 = load i64, ptr %l10, !tbaa !24
  %t193 = load i64, ptr %l14, !tbaa !24
  %t194 = load i64, ptr %l12, !tbaa !24
  %t197 = mul i64 %t193, %t194
  %t200 = add i64 %t192, %t197
  store i64 %t200, ptr %l15, !tbaa !24
  %t202 = load i64, ptr %l15, !tbaa !24
  %t203 = getelementptr %"compiler/free:leaf", ptr %l8, i32 0, i32 0
  %t204 = load { i64, ptr }, ptr %t203, !tbaa !27
  store { i64, ptr } %t204, ptr %l99, !tbaa !27
  %t205 = load i64, ptr %l15, !tbaa !24
  %t207 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = getelementptr i64, ptr %t208, i64 %t205
  %t210 = load i64, ptr %t209, !tbaa !34
  %t212 = load ptr, ptr %lp9
  %t214 = getelementptr { i64, ptr }, ptr %t212, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = getelementptr i64, ptr %t215, i64 %t202
  store i64 %t210, ptr %t216, !tbaa !34
  br label %bb60
bb60:
  %t217 = load i64, ptr %l14, !tbaa !24
  %t219 = add i64 %t217, 1
  store i64 %t219, ptr %l14, !tbaa !24
  br label %bb56
bb61:
  %t221 = getelementptr %"compiler/free:leaf", ptr %l8, i32 0, i32 0
  %t222 = load { i64, ptr }, ptr %t221, !tbaa !27
  %t224 = extractvalue { i64, ptr } %t222, 0
  %t225 = load ptr, ptr %lp9
  %t227 = getelementptr { i64, ptr }, ptr %t225, i32 0, i32 1
  %t228 = load ptr, ptr %t227, !tbaa !27
  %t229 = getelementptr i64, ptr %t228, i64 %t224
  store i64 0, ptr %t229, !tbaa !34
  %t230 = load ptr, ptr %lp3
  %t231 = load ptr, ptr %lp9
  %t232 = load { i64, ptr }, ptr %t231, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v2, ptr %v2, ptr %t230, { i64, ptr } %t232)
  br label %bb62
bb62:
  br label %bb64
bb63:
  br label %bb64
bb64:
  br label %bb65
bb65:
  %t235 = load i64, ptr %l7, !tbaa !24
  %t237 = add i64 %t235, 1
  store i64 %t237, ptr %l7, !tbaa !24
  br label %bb37
bb66:
  call void @__olang_scope_close(ptr %s6)
  %t239 = load ptr, ptr %lp3
  %t240 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t239
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t240, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2erender(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1, { i64, [4 x i64] } %a2, i32 %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [1 x i64] }
  %l2 = alloca { i64, [4 x i64] }
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i1
  %l9 = alloca i32
  %l10 = alloca { i64, [4 x i64] }
  %l11 = alloca { i64, [7 x i64] }
  %l12 = alloca i32
  %l19 = alloca i1
  %l22 = alloca ptr
  %l25 = alloca i32
  %l26 = alloca i1
  %l34 = alloca i32
  %l44 = alloca i32
  %l48 = alloca i1
  %l51 = alloca i1
  %l59 = alloca i1
  %l63 = alloca i1
  %l67 = alloca i1
  %l71 = alloca i1
  %l85 = alloca i32
  %l89 = alloca i32
  %l90 = alloca ptr
  %l91 = alloca ptr
  %l94 = alloca i32
  %l95 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l97 = alloca i32
  %l102 = alloca i32
  %l103 = alloca %"compiler/mir:Lvalue"
  %l104 = alloca ptr
  %l107 = alloca i32
  %l108 = alloca { i64, ptr }
  %l109 = alloca { i64, ptr }
  %l113 = alloca { i64, [4 x i64] }
  %l126 = alloca i32
  %l128 = alloca ptr
  %l129 = alloca { i64, [7 x i64] }
  %l131 = alloca ptr
  %l132 = alloca { i64, [4 x i64] }
  %l134 = alloca { i64, [4 x i64] }
  %l135 = alloca { i64, ptr }
  %l136 = alloca %"compiler/mir:Range"
  %l140 = alloca { i64, ptr }
  %l141 = alloca %"compiler/mir:Range"
  %l146 = alloca %"compiler/mir:Call"
  %l147 = alloca i32
  %s0 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %t120 = alloca { i64, [21 x i64] }, align 8
  %t193 = alloca { i64, [15 x i64] }, align 8
  %t209 = alloca { i64, [2 x i64] }, align 8
  %t218 = alloca { i64, [7 x i64] }, align 8
  %t232 = alloca { i64, [2 x i64] }, align 8
  %t308 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, [1 x i64] } %a1, ptr %l1
  store { i64, [4 x i64] } %a2, ptr %l2
  store i32 %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t6 = load i32, ptr %l3, !tbaa !23
  %t7 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t10 = icmp eq i32 %t6, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb3
bb2:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lower:lowering", ptr %t12, i32 0, i32 8
  %t15 = load i1, ptr %t14, !tbaa !21
  store i1 %t15, ptr %l19, !tbaa !21
  br label %bb3
bb3:
  %t17 = load i1, ptr %l19, !tbaa !21
  br i1 %t17, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  br label %bb6
bb6:
  %t18 = load ptr, ptr %l5, !tbaa !29
  store ptr %t18, ptr %l22, !tbaa !29
  %t19 = load ptr, ptr %l5, !tbaa !29
  %t20 = load i32, ptr %l3, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t19, i32 %t20)
  store i32 %t23, ptr %l25
  br label %bb7
bb7:
  %t24 = load ptr, ptr %l22, !tbaa !29
  %t25 = load i32, ptr %l25, !tbaa !23
  %t26 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsAny(ptr %v0, ptr %t24, i32 %t25)
  store i1 %t26, ptr %l26
  br label %bb8
bb8:
  %t27 = load i1, ptr %l26, !tbaa !21
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load { i64, [1 x i64] }, ptr %l1
  %t30 = load { i64, [4 x i64] }, ptr %l2
  %t31 = load i32, ptr %l3, !tbaa !23
  %t32 = load %"compiler/source:Span", ptr %l4
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2erenderAny(ptr %v0, ptr %t28, { i64, [1 x i64] } %t29, { i64, [4 x i64] } %t30, i32 %t31, i1 true, %"compiler/source:Span" %t32)
  br label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb12:
  %t38 = load ptr, ptr %l5, !tbaa !29
  %t39 = load i32, ptr %l3, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l34
  br label %bb13
bb13:
  %t43 = load i32, ptr %l34
  %t45 = trunc i64 32 to i32
  %t46 = icmp eq i32 %t43, %t45
  br i1 %t46, label %bb14, label %bb15
bb14:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load { i64, [1 x i64] }, ptr %l1
  %t50 = load { i64, [4 x i64] }, ptr %l2
  %t51 = load i32, ptr %l3, !tbaa !23
  %t52 = load %"compiler/source:Span", ptr %l4
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2erenderErr(ptr %v0, ptr %t48, { i64, [1 x i64] } %t49, { i64, [4 x i64] } %t50, i32 %t51, %"compiler/source:Span" %t52)
  br label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb17:
  %t58 = load ptr, ptr %l5, !tbaa !29
  %t59 = load i32, ptr %l3, !tbaa !23
  %t62 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t58, i32 %t59)
  store i32 %t62, ptr %l44
  br label %bb18
bb18:
  %t63 = load i32, ptr %l44, !tbaa !23
  store i32 %t63, ptr %l6, !tbaa !23
  store i32 7, ptr %l7
  store i1 true, ptr %l8, !tbaa !21
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load i32, ptr %l3, !tbaa !23
  %t69 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ehasStr(ptr %v0, ptr %t65, i32 %t66)
  store i1 %t69, ptr %l48
  br label %bb19
bb19:
  %t70 = load i1, ptr %l48, !tbaa !21
  br i1 %t70, label %bb20, label %bb21
bb20:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb45
bb21:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load i32, ptr %l3, !tbaa !23
  %t75 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eisChar(ptr %v0, ptr %t71, i32 %t72)
  store i1 %t75, ptr %l51
  br label %bb22
bb22:
  %t76 = load i1, ptr %l51, !tbaa !21
  br i1 %t76, label %bb23, label %bb24
bb23:
  store i32 2, ptr %l7
  br label %bb44
bb24:
  %t78 = load i32, ptr %l6, !tbaa !23
  %t79 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t82 = icmp eq i32 %t78, %t79
  br i1 %t82, label %bb25, label %bb26
bb25:
  store i32 7, ptr %l7
  br label %bb43
bb26:
  %t85 = load ptr, ptr %l5, !tbaa !29
  %t86 = load i32, ptr %l6, !tbaa !23
  %t89 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t85, i32 %t86)
  store i1 %t89, ptr %l59
  br label %bb27
bb27:
  %t90 = load i1, ptr %l59, !tbaa !21
  br i1 %t90, label %bb28, label %bb29
bb28:
  store i32 5, ptr %l7
  br label %bb42
bb29:
  %t92 = load ptr, ptr %l5, !tbaa !29
  %t93 = load i32, ptr %l6, !tbaa !23
  %t96 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t92, i32 %t93)
  store i1 %t96, ptr %l63
  br label %bb30
bb30:
  %t97 = load i1, ptr %l63, !tbaa !21
  br i1 %t97, label %bb31, label %bb32
bb31:
  store i32 4, ptr %l7
  br label %bb41
bb32:
  %t99 = load ptr, ptr %l5, !tbaa !29
  %t100 = load i32, ptr %l6, !tbaa !23
  %t103 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t99, i32 %t100)
  store i1 %t103, ptr %l67
  br label %bb33
bb33:
  %t104 = load i1, ptr %l67, !tbaa !21
  br i1 %t104, label %bb34, label %bb35
bb34:
  store i32 6, ptr %l7
  br label %bb40
bb35:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load i32, ptr %l3, !tbaa !23
  %t110 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eisText(ptr %v0, ptr %t106, i32 %t107)
  store i1 %t110, ptr %l71
  br label %bb36
bb36:
  %t111 = load i1, ptr %l71, !tbaa !21
  br i1 %t111, label %bb37, label %bb38
bb37:
  store i32 0, ptr %l7
  br label %bb39
bb38:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb39
bb39:
  br label %bb40
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  br label %bb43
bb43:
  br label %bb44
bb44:
  br label %bb45
bb45:
  %t113 = load i1, ptr %l8, !tbaa !21
  br i1 %t113, label %bb46, label %bb47
bb46:
  store %olang.scope zeroinitializer, ptr %s18
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load %"compiler/source:Span", ptr %l4
  %t117 = load { i64, [1 x i64] }, ptr %l1
  %t118 = load i32, ptr %l7
  %t119 = load { i64, [4 x i64] }, ptr %l2
  store { i64, [21 x i64] } zeroinitializer, ptr %t120
  %t121 = getelementptr { i64, [21 x i64] }, ptr %t120, i32 0, i32 0
  store i64 9, ptr %t121
  %t123 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t116, 0
  %t125 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t123, { i64, [1 x i64] } %t117, 1
  %t127 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t125, i32 %t118, 2
  %t129 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t127, { i64, [4 x i64] } %t119, 3
  %t130 = getelementptr { i64, [21 x i64] }, ptr %t120, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t129, ptr %t130
  %t131 = load { i64, [21 x i64] }, ptr %t120
  %t133 = call ptr @__olang_scope_alloc_a(ptr %s18, i64 176, i64 8)
  store { i64, [21 x i64] } %t131, ptr %t133
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s18, ptr %t115, ptr %t133)
  br label %bb48
bb47:
  br label %bb49
bb48:
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb49:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/lower:lowering", ptr %t136, i32 0, i32 0
  %t139 = load ptr, ptr %t138, !tbaa !29
  %t140 = load i32, ptr %l3, !tbaa !23
  %t144 = call i32 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ehelperTy(ptr %v0, ptr %t139, i32 0, i32 %t140)
  store i32 %t144, ptr %l85
  br label %bb50
bb50:
  %t145 = load i32, ptr %l85, !tbaa !23
  store i32 %t145, ptr %l3, !tbaa !23
  %t146 = load ptr, ptr %l5, !tbaa !29
  %t147 = load i32, ptr %l3, !tbaa !23
  %t151 = call i32 @compiler_2fmir_2eHelperType(ptr %v0, ptr %t146, i32 0, i32 %t147)
  store i32 %t151, ptr %l89
  br label %bb51
bb51:
  %t152 = load i32, ptr %l89, !tbaa !23
  store i32 %t152, ptr %l9, !tbaa !23
  %t153 = load ptr, ptr %l0, !tbaa !29
  store ptr %t153, ptr %l90, !tbaa !29
  %t154 = load ptr, ptr %l5, !tbaa !29
  store ptr %t154, ptr %l91, !tbaa !29
  %t155 = load ptr, ptr %l5, !tbaa !29
  %t156 = load i32, ptr %l9, !tbaa !23
  %t159 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t155, i32 %t156)
  store i32 %t159, ptr %l94
  br label %bb52
bb52:
  %t160 = load ptr, ptr %l91, !tbaa !29
  %t161 = load i32, ptr %l94, !tbaa !23
  %t162 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t160, i32 %t161)
  store { i64, ptr } %t162, ptr %l95
  br label %bb53
bb53:
  %t163 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t163, ptr %l96, !tbaa !27
  %t164 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !27
  %t166 = getelementptr i32, ptr %t165, i64 0
  %t167 = load i32, ptr %t166, !tbaa !33
  store i32 %t167, ptr %l97, !tbaa !23
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t169 = load { i64, [4 x i64] }, ptr %l2
  %t170 = load i32, ptr %l3, !tbaa !23
  %t171 = load %"compiler/source:Span", ptr %l4
  %t176 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %t168, { i64, [4 x i64] } %t169, i32 %t170, %"compiler/source:Span" %t171)
  store i32 %t176, ptr %l102
  br label %bb54
bb54:
  %t177 = load i32, ptr %l102, !tbaa !23
  %t178 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t177)
  store %"compiler/mir:Lvalue" %t178, ptr %l103
  br label %bb55
bb55:
  %t179 = load ptr, ptr %l5, !tbaa !29
  store ptr %t179, ptr %l104, !tbaa !29
  %t180 = load ptr, ptr %l5, !tbaa !29
  %t181 = load i32, ptr %l9, !tbaa !23
  %t184 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t180, i32 %t181)
  store i32 %t184, ptr %l107
  br label %bb56
bb56:
  %t185 = load ptr, ptr %l104, !tbaa !29
  %t186 = load i32, ptr %l107, !tbaa !23
  %t187 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t185, i32 %t186)
  store { i64, ptr } %t187, ptr %l108
  br label %bb57
bb57:
  %t188 = load { i64, ptr }, ptr %l108, !tbaa !27
  store { i64, ptr } %t188, ptr %l109, !tbaa !27
  %t189 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !27
  %t191 = getelementptr i32, ptr %t190, i64 0
  %t192 = load i32, ptr %t191, !tbaa !33
  store { i64, [15 x i64] } zeroinitializer, ptr %t193
  %t194 = getelementptr { i64, [15 x i64] }, ptr %t193, i32 0, i32 0
  store i64 1, ptr %t194
  %t195 = load %"compiler/mir:Lvalue", ptr %l103
  %t196 = insertvalue { %"compiler/mir:Lvalue", i32 } undef, %"compiler/mir:Lvalue" %t195, 0
  %t198 = insertvalue { %"compiler/mir:Lvalue", i32 } %t196, i32 %t192, 1
  %t199 = getelementptr { i64, [15 x i64] }, ptr %t193, i32 0, i32 1
  store { %"compiler/mir:Lvalue", i32 } %t198, ptr %t199
  %t200 = load { i64, [15 x i64] }, ptr %t193
  %t201 = load %"compiler/source:Span", ptr %l4
  %t202 = load ptr, ptr %l90, !tbaa !29
  %t203 = load i32, ptr %l97, !tbaa !23
  %t206 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t202, i32 %t203, { i64, [15 x i64] } %t200, %"compiler/source:Span" %t201)
  store { i64, [4 x i64] } %t206, ptr %l113
  br label %bb58
bb58:
  %t207 = load { i64, [4 x i64] }, ptr %l113
  store { i64, [4 x i64] } %t207, ptr %l10
  %t208 = load i32, ptr %l3, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t209
  %t210 = getelementptr { i64, [2 x i64] }, ptr %t209, i32 0, i32 0
  store i64 2, ptr %t210
  %t212 = insertvalue { i32, i32 } undef, i32 0, 0
  %t214 = insertvalue { i32, i32 } %t212, i32 %t208, 1
  %t215 = getelementptr { i64, [2 x i64] }, ptr %t209, i32 0, i32 1
  store { i32, i32 } %t214, ptr %t215
  %t216 = load { i64, [2 x i64] }, ptr %t209
  %t217 = load i32, ptr %l9, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t218
  %t219 = getelementptr { i64, [7 x i64] }, ptr %t218, i32 0, i32 0
  store i64 0, ptr %t219
  %t221 = insertvalue { { i64, [2 x i64] }, i32 } undef, { i64, [2 x i64] } %t216, 0
  %t223 = insertvalue { { i64, [2 x i64] }, i32 } %t221, i32 %t217, 1
  %t224 = getelementptr { i64, [7 x i64] }, ptr %t218, i32 0, i32 1
  store { { i64, [2 x i64] }, i32 } %t223, ptr %t224
  %t225 = load { i64, [7 x i64] }, ptr %t218
  store { i64, [7 x i64] } %t225, ptr %l11
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t229 = getelementptr %"compiler/lower:lowering", ptr %t227, i32 0, i32 0
  %t230 = load ptr, ptr %t229, !tbaa !29
  %t231 = load i32, ptr %l3, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t232
  %t233 = getelementptr { i64, [2 x i64] }, ptr %t232, i32 0, i32 0
  store i64 2, ptr %t233
  %t235 = insertvalue { i32, i32 } undef, i32 0, 0
  %t237 = insertvalue { i32, i32 } %t235, i32 %t231, 1
  %t238 = getelementptr { i64, [2 x i64] }, ptr %t232, i32 0, i32 1
  store { i32, i32 } %t237, ptr %t238
  %t239 = load { i64, [2 x i64] }, ptr %t232
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eWant(ptr %v0, ptr %t230, { i64, [2 x i64] } %t239)
  br label %bb59
bb59:
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t244 = getelementptr %"compiler/lower:lowering", ptr %t242, i32 0, i32 3
  %t246 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t244)
  store i32 %t246, ptr %l126
  br label %bb60
bb60:
  %t247 = load i32, ptr %l126, !tbaa !23
  store i32 %t247, ptr %l12, !tbaa !23
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t250 = getelementptr %"compiler/lower:lowering", ptr %t248, i32 0, i32 3
  store ptr %t250, ptr %l128, !tbaa !29
  %t251 = load { i64, [7 x i64] }, ptr %l11
  store { i64, [7 x i64] } %t251, ptr %l129
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = getelementptr %"compiler/lower:lowering", ptr %t252, i32 0, i32 3
  store ptr %t254, ptr %l131, !tbaa !29
  %t255 = load { i64, [4 x i64] }, ptr %l10
  store { i64, [4 x i64] } %t255, ptr %l132
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2edepth(ptr %v0, ptr %t256)
  store { i64, [4 x i64] } %t258, ptr %l134
  br label %bb61
bb61:
  %t259 = mul i64 2, 40
  %t260 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t259)
  %t261 = insertvalue { i64, ptr } undef, i64 2, 0
  %t262 = insertvalue { i64, ptr } %t261, ptr %t260, 1
  store { i64, ptr } %t262, ptr %l135, !tbaa !27
  %t263 = load { i64, [4 x i64] }, ptr %l132
  %t264 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t265 = load ptr, ptr %t264, !tbaa !27
  %t266 = getelementptr { i64, [4 x i64] }, ptr %t265, i64 0
  store { i64, [4 x i64] } %t263, ptr %t266
  %t267 = load { i64, [4 x i64] }, ptr %l134
  %t268 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t269 = load ptr, ptr %t268, !tbaa !27
  %t270 = getelementptr { i64, [4 x i64] }, ptr %t269, i64 1
  store { i64, [4 x i64] } %t267, ptr %t270
  %t271 = load ptr, ptr %l131, !tbaa !29
  %t272 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t273 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %s0, ptr %t271, { i64, ptr } %t272)
  store %"compiler/mir:Range" %t273, ptr %l136
  br label %bb62
bb62:
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = getelementptr %"compiler/lower:lowering", ptr %t274, i32 0, i32 3
  %t277 = load { i64, [1 x i64] }, ptr %l1
  %t278 = mul i64 1, 16
  %t279 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t278)
  %t280 = insertvalue { i64, ptr } undef, i64 1, 0
  %t281 = insertvalue { i64, ptr } %t280, ptr %t279, 1
  store { i64, ptr } %t281, ptr %l140, !tbaa !27
  %t283 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t284 = load ptr, ptr %t283, !tbaa !27
  %t285 = getelementptr { i64, [1 x i64] }, ptr %t284, i64 0
  store { i64, [1 x i64] } %t277, ptr %t285
  %t287 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t288 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eScopeRefs(ptr %v0, ptr %s0, ptr %t276, { i64, ptr } %t287)
  store %"compiler/mir:Range" %t288, ptr %l141
  br label %bb63
bb63:
  %t289 = load %"compiler/mir:Lvalue", ptr @G_2ecompiler_2fmir_2eNoPlace
  %t290 = load i32, ptr %l12, !tbaa !23
  %t291 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t292 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t293 = load { i64, [7 x i64] }, ptr %l129
  %t294 = load %"compiler/mir:Range", ptr %l136
  %t295 = load %"compiler/mir:Range", ptr %l141
  %t300 = call %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %s0, { i64, [7 x i64] } %t293, %"compiler/mir:Range" %t294, %"compiler/mir:Range" %t295, %"compiler/mir:Lvalue" %t289, i1 false, i32 %t290, i32 %t291, i32 %t292)
  store %"compiler/mir:Call" %t300, ptr %l146
  br label %bb64
bb64:
  %t301 = load ptr, ptr %l128, !tbaa !29
  %t302 = load %"compiler/mir:Call", ptr %l146
  %t303 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v0, ptr %t301, %"compiler/mir:Call" %t302)
  store i32 %t303, ptr %l147
  br label %bb65
bb65:
  %t304 = load i32, ptr %l147, !tbaa !23
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t306 = load %"compiler/source:Span", ptr %l4
  store { i64, [8 x i64] } zeroinitializer, ptr %t308
  %t309 = getelementptr { i64, [8 x i64] }, ptr %t308, i32 0, i32 0
  store i64 4, ptr %t309
  %t311 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t306, 0
  %t313 = insertvalue { %"compiler/source:Span", i32 } %t311, i32 %t304, 1
  %t314 = getelementptr { i64, [8 x i64] }, ptr %t308, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t313, ptr %t314
  %t315 = load { i64, [8 x i64] }, ptr %t308
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t305, { i64, [8 x i64] } %t315)
  br label %bb66
bb66:
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t319 = load i32, ptr %l12, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t318, i32 %t319)
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2erenderAny(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1, { i64, [4 x i64] } %a2, i32 %a3, i1 %a4, %"compiler/source:Span" %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [1 x i64] }
  %l3 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca { i64, [4 x i64] }
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca { i64, [4 x i64] }
  %l13 = alloca { i64, [4 x i64] }
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca { i64, [4 x i64] }
  %l17 = alloca i32
  %l18 = alloca { i64, [7 x i64] }
  %l19 = alloca i32
  %l27 = alloca i32
  %l30 = alloca i32
  %l31 = alloca ptr
  %l34 = alloca i32
  %l35 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i32
  %l38 = alloca i32
  %l40 = alloca %"compiler/mir:Lvalue"
  %l44 = alloca { i64, ptr }
  %l46 = alloca { i64, [4 x i64] }
  %l49 = alloca i32
  %l52 = alloca i32
  %l68 = alloca { i64, [4 x i64] }
  %l69 = alloca ptr
  %l70 = alloca i32
  %l71 = alloca i32
  %l72 = alloca { i64, [4 x i64] }
  %l74 = alloca { i64, [4 x i64] }
  %l75 = alloca { i64, ptr }
  %l77 = alloca { i64, [4 x i64] }
  %l80 = alloca i32
  %l83 = alloca i32
  %l98 = alloca ptr
  %l99 = alloca i32
  %l100 = alloca i32
  %l101 = alloca { i64, [4 x i64] }
  %l103 = alloca { i64, [4 x i64] }
  %l104 = alloca { i64, ptr }
  %l106 = alloca { i64, [4 x i64] }
  %l107 = alloca ptr
  %l108 = alloca i32
  %l109 = alloca ptr
  %l112 = alloca i32
  %l113 = alloca i32
  %l114 = alloca i32
  %l116 = alloca %"compiler/mir:Lvalue"
  %l117 = alloca { i64, [4 x i64] }
  %l119 = alloca i64
  %l124 = alloca i32
  %l126 = alloca ptr
  %l127 = alloca { i64, [7 x i64] }
  %l129 = alloca ptr
  %l131 = alloca %"compiler/mir:Lvalue"
  %l134 = alloca { i64, ptr }
  %l135 = alloca %"compiler/mir:Range"
  %l139 = alloca { i64, ptr }
  %l140 = alloca %"compiler/mir:Range"
  %l145 = alloca %"compiler/mir:Call"
  %l146 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %t37 = alloca { i64, [4 x i64] }, align 8
  %t44 = alloca { i64, [4 x i64] }, align 8
  %t87 = alloca { i64, [8 x i64] }, align 8
  %t163 = alloca { i64, [8 x i64] }, align 8
  %t237 = alloca { i64, [4 x i64] }, align 8
  %t246 = alloca { i64, [7 x i64] }, align 8
  %t273 = alloca { i64, [4 x i64] }, align 8
  %t329 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, [1 x i64] } %a1, ptr %l1
  store i32 %a3, ptr %l3
  store %"compiler/source:Span" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l6, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l3, !tbaa !23
  %t9 = load %"compiler/source:Span", ptr %l5
  %t14 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %t6, { i64, [4 x i64] } %a2, i32 %t8, %"compiler/source:Span" %t9)
  store i32 %t14, ptr %l27
  br label %bb1
bb1:
  %t15 = load i32, ptr %l27, !tbaa !23
  store i32 %t15, ptr %l7, !tbaa !23
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/lower:lowering", ptr %t16, i32 0, i32 3
  %t20 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t18)
  store i32 %t20, ptr %l30
  br label %bb2
bb2:
  %t21 = load i32, ptr %l30, !tbaa !23
  store i32 %t21, ptr %l8, !tbaa !23
  %t22 = load ptr, ptr %l6, !tbaa !29
  store ptr %t22, ptr %l31, !tbaa !29
  %t23 = load ptr, ptr %l6, !tbaa !29
  %t24 = load i32, ptr %l3, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l34
  br label %bb3
bb3:
  %t28 = load ptr, ptr %l31, !tbaa !29
  %t29 = load i32, ptr %l34, !tbaa !23
  %t30 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t28, i32 %t29)
  store i1 %t30, ptr %l35
  br label %bb4
bb4:
  %t31 = load i1, ptr %l35, !tbaa !21
  br i1 %t31, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l36, !tbaa !29
  store i32 14, ptr %l37
  %t33 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t33, ptr %l38, !tbaa !23
  %t34 = load i32, ptr %l7, !tbaa !23
  %t36 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t34)
  store %"compiler/mir:Lvalue" %t36, ptr %l40
  br label %bb7
bb6:
  br label %bb16
bb7:
  store { i64, [4 x i64] } zeroinitializer, ptr %t37
  %t38 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 0
  store i64 1, ptr %t38
  %t39 = load %"compiler/mir:Lvalue", ptr %l40
  %t40 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t39, 0
  %t41 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t40, ptr %t41
  %t42 = load { i64, [4 x i64] }, ptr %t37
  %t43 = load i32, ptr %l3, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t44
  %t45 = getelementptr { i64, [4 x i64] }, ptr %t44, i32 0, i32 0
  store i64 2, ptr %t45
  %t47 = insertvalue { i32, i64 } undef, i32 %t43, 0
  %t48 = insertvalue { i32, i64 } %t47, i64 0, 1
  %t49 = getelementptr { i64, [4 x i64] }, ptr %t44, i32 0, i32 1
  store { i32, i64 } %t48, ptr %t49
  %t50 = load { i64, [4 x i64] }, ptr %t44
  %t51 = mul i64 2, 40
  %t52 = call ptr @__olang_scope_alloc_zeroed(ptr %s1, i64 %t51)
  %t53 = insertvalue { i64, ptr } undef, i64 2, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  store { i64, ptr } %t54, ptr %l44, !tbaa !27
  %t56 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr { i64, [4 x i64] }, ptr %t57, i64 0
  store { i64, [4 x i64] } %t42, ptr %t58
  %t60 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr { i64, [4 x i64] }, ptr %t61, i64 1
  store { i64, [4 x i64] } %t50, ptr %t62
  %t63 = load %"compiler/source:Span", ptr %l5
  %t64 = load ptr, ptr %l36, !tbaa !29
  %t65 = load i32, ptr %l37
  %t66 = load i32, ptr %l38, !tbaa !23
  %t67 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t69 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s1, ptr %t64, i32 %t65, i32 %t66, { i64, ptr } %t67, %"compiler/source:Span" %t63)
  store { i64, [4 x i64] } %t69, ptr %l46
  br label %bb8
bb8:
  %t70 = load { i64, [4 x i64] }, ptr %l46
  store { i64, [4 x i64] } %t70, ptr %l9
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/lower:lowering", ptr %t71, i32 0, i32 3
  %t75 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t73)
  store i32 %t75, ptr %l49
  br label %bb9
bb9:
  %t76 = load i32, ptr %l49, !tbaa !23
  store i32 %t76, ptr %l10, !tbaa !23
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/lower:lowering", ptr %t77, i32 0, i32 3
  %t81 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t79)
  store i32 %t81, ptr %l52
  br label %bb10
bb10:
  %t82 = load i32, ptr %l52, !tbaa !23
  store i32 %t82, ptr %l11, !tbaa !23
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load { i64, [4 x i64] }, ptr %l9
  %t85 = load i32, ptr %l10, !tbaa !23
  %t86 = load i32, ptr %l11, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t87
  %t88 = getelementptr { i64, [8 x i64] }, ptr %t87, i32 0, i32 0
  store i64 2, ptr %t88
  %t90 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t84, 0
  %t92 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t90, i32 %t85, 1
  %t94 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t92, i32 %t86, 2
  %t95 = getelementptr { i64, [8 x i64] }, ptr %t87, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t94, ptr %t95
  %t96 = load { i64, [8 x i64] }, ptr %t87
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t83, { i64, [8 x i64] } %t96)
  br label %bb11
bb11:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load i32, ptr %l11, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t99, i32 %t100)
  br label %bb12
bb12:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load { i64, [1 x i64] }, ptr %l1
  %t105 = load %"compiler/source:Span", ptr %l5
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eword(ptr %v0, ptr %s1, ptr %t103, { i64, [1 x i64] } %t104, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d14, i32 0, i32 1) }, %"compiler/source:Span" %t105)
  br label %bb13
bb13:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load i32, ptr %l8, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t109, i32 %t110)
  br label %bb14
bb14:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load i32, ptr %l10, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t113, i32 %t114)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s1)
  br label %bb16
bb16:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2edepth(ptr %v0, ptr %t117)
  store { i64, [4 x i64] } %t119, ptr %l68
  br label %bb17
bb17:
  %t120 = load { i64, [4 x i64] }, ptr %l68
  store { i64, [4 x i64] } %t120, ptr %l12
  %t121 = load ptr, ptr %l0, !tbaa !29
  store ptr %t121, ptr %l69, !tbaa !29
  store i32 18, ptr %l70
  %t122 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t122, ptr %l71, !tbaa !23
  %t123 = load { i64, [4 x i64] }, ptr %l12
  store { i64, [4 x i64] } %t123, ptr %l72
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t124, i64 8)
  store { i64, [4 x i64] } %t126, ptr %l74
  br label %bb18
bb18:
  %t127 = mul i64 2, 40
  %t128 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t127)
  %t129 = insertvalue { i64, ptr } undef, i64 2, 0
  %t130 = insertvalue { i64, ptr } %t129, ptr %t128, 1
  store { i64, ptr } %t130, ptr %l75, !tbaa !27
  %t131 = load { i64, [4 x i64] }, ptr %l72
  %t132 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr { i64, [4 x i64] }, ptr %t133, i64 0
  store { i64, [4 x i64] } %t131, ptr %t134
  %t135 = load { i64, [4 x i64] }, ptr %l74
  %t136 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !27
  %t138 = getelementptr { i64, [4 x i64] }, ptr %t137, i64 1
  store { i64, [4 x i64] } %t135, ptr %t138
  %t139 = load %"compiler/source:Span", ptr %l5
  %t140 = load ptr, ptr %l69, !tbaa !29
  %t141 = load i32, ptr %l70
  %t142 = load i32, ptr %l71, !tbaa !23
  %t143 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t145 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %t140, i32 %t141, i32 %t142, { i64, ptr } %t143, %"compiler/source:Span" %t139)
  store { i64, [4 x i64] } %t145, ptr %l77
  br label %bb19
bb19:
  %t146 = load { i64, [4 x i64] }, ptr %l77
  store { i64, [4 x i64] } %t146, ptr %l13
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/lower:lowering", ptr %t147, i32 0, i32 3
  %t151 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t149)
  store i32 %t151, ptr %l80
  br label %bb20
bb20:
  %t152 = load i32, ptr %l80, !tbaa !23
  store i32 %t152, ptr %l14, !tbaa !23
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t155 = getelementptr %"compiler/lower:lowering", ptr %t153, i32 0, i32 3
  %t157 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t155)
  store i32 %t157, ptr %l83
  br label %bb21
bb21:
  %t158 = load i32, ptr %l83, !tbaa !23
  store i32 %t158, ptr %l15, !tbaa !23
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load { i64, [4 x i64] }, ptr %l13
  %t161 = load i32, ptr %l14, !tbaa !23
  %t162 = load i32, ptr %l15, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t163
  %t164 = getelementptr { i64, [8 x i64] }, ptr %t163, i32 0, i32 0
  store i64 2, ptr %t164
  %t166 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t160, 0
  %t168 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t166, i32 %t161, 1
  %t170 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t168, i32 %t162, 2
  %t171 = getelementptr { i64, [8 x i64] }, ptr %t163, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t170, ptr %t171
  %t172 = load { i64, [8 x i64] }, ptr %t163
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t159, { i64, [8 x i64] } %t172)
  br label %bb22
bb22:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = load i32, ptr %l14, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t175, i32 %t176)
  br label %bb23
bb23:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load { i64, [1 x i64] }, ptr %l1
  %t181 = load %"compiler/source:Span", ptr %l5
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eword(ptr %v0, ptr %s0, ptr %t179, { i64, [1 x i64] } %t180, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d15, i32 0, i32 1) }, %"compiler/source:Span" %t181)
  br label %bb24
bb24:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load i32, ptr %l8, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t185, i32 %t186)
  br label %bb25
bb25:
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load i32, ptr %l15, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t189, i32 %t190)
  br label %bb26
bb26:
  %t193 = load ptr, ptr %l0, !tbaa !29
  store ptr %t193, ptr %l98, !tbaa !29
  store i32 3, ptr %l99
  %t194 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t194, ptr %l100, !tbaa !23
  %t195 = load { i64, [4 x i64] }, ptr %l12
  store { i64, [4 x i64] } %t195, ptr %l101
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t196, i64 1)
  store { i64, [4 x i64] } %t198, ptr %l103
  br label %bb27
bb27:
  %t199 = mul i64 2, 40
  %t200 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t199)
  %t201 = insertvalue { i64, ptr } undef, i64 2, 0
  %t202 = insertvalue { i64, ptr } %t201, ptr %t200, 1
  store { i64, ptr } %t202, ptr %l104, !tbaa !27
  %t203 = load { i64, [4 x i64] }, ptr %l101
  %t204 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t205 = load ptr, ptr %t204, !tbaa !27
  %t206 = getelementptr { i64, [4 x i64] }, ptr %t205, i64 0
  store { i64, [4 x i64] } %t203, ptr %t206
  %t207 = load { i64, [4 x i64] }, ptr %l103
  %t208 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr { i64, [4 x i64] }, ptr %t209, i64 1
  store { i64, [4 x i64] } %t207, ptr %t210
  %t211 = load %"compiler/source:Span", ptr %l5
  %t212 = load ptr, ptr %l98, !tbaa !29
  %t213 = load i32, ptr %l99
  %t214 = load i32, ptr %l100, !tbaa !23
  %t215 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t217 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %t212, i32 %t213, i32 %t214, { i64, ptr } %t215, %"compiler/source:Span" %t211)
  store { i64, [4 x i64] } %t217, ptr %l106
  br label %bb28
bb28:
  %t218 = load { i64, [4 x i64] }, ptr %l106
  store { i64, [4 x i64] } %t218, ptr %l16
  %t219 = load ptr, ptr %l6, !tbaa !29
  store ptr %t219, ptr %l107, !tbaa !29
  store i32 0, ptr %l108
  %t220 = load ptr, ptr %l6, !tbaa !29
  store ptr %t220, ptr %l109, !tbaa !29
  %t221 = load ptr, ptr %l6, !tbaa !29
  %t222 = load i32, ptr %l3, !tbaa !23
  %t225 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t221, i32 %t222)
  store i32 %t225, ptr %l112
  br label %bb29
bb29:
  %t226 = load ptr, ptr %l109, !tbaa !29
  %t227 = load i32, ptr %l112, !tbaa !23
  %t228 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t226, i32 %t227)
  store i32 %t228, ptr %l113
  br label %bb30
bb30:
  %t229 = load ptr, ptr %l107, !tbaa !29
  %t230 = load i32, ptr %l108
  %t231 = load i32, ptr %l113, !tbaa !23
  %t232 = call i32 @compiler_2fmir_2eHelperType(ptr %v0, ptr %t229, i32 %t230, i32 %t231)
  store i32 %t232, ptr %l114
  br label %bb31
bb31:
  %t233 = load i32, ptr %l114, !tbaa !23
  store i32 %t233, ptr %l17, !tbaa !23
  %t234 = load i32, ptr %l7, !tbaa !23
  %t236 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t234)
  store %"compiler/mir:Lvalue" %t236, ptr %l116
  br label %bb32
bb32:
  store { i64, [4 x i64] } zeroinitializer, ptr %t237
  %t238 = getelementptr { i64, [4 x i64] }, ptr %t237, i32 0, i32 0
  store i64 1, ptr %t238
  %t239 = load %"compiler/mir:Lvalue", ptr %l116
  %t240 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t239, 0
  %t241 = getelementptr { i64, [4 x i64] }, ptr %t237, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t240, ptr %t241
  %t242 = load { i64, [4 x i64] }, ptr %t237
  store { i64, [4 x i64] } %t242, ptr %l117
  br i1 %a4, label %bb33, label %bb34
bb33:
  store i64 -1, ptr %l119, !tbaa !24
  br label %bb35
bb34:
  store i64 -2, ptr %l119, !tbaa !24
  br label %bb35
bb35:
  %t245 = load i32, ptr %l17, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t246
  %t247 = getelementptr { i64, [7 x i64] }, ptr %t246, i32 0, i32 0
  store i64 3, ptr %t247
  %t248 = load { i64, [4 x i64] }, ptr %l117
  %t249 = insertvalue { { i64, [4 x i64] }, i64, i32 } undef, { i64, [4 x i64] } %t248, 0
  %t250 = load i64, ptr %l119, !tbaa !24
  %t251 = insertvalue { { i64, [4 x i64] }, i64, i32 } %t249, i64 %t250, 1
  %t253 = insertvalue { { i64, [4 x i64] }, i64, i32 } %t251, i32 %t245, 2
  %t254 = getelementptr { i64, [7 x i64] }, ptr %t246, i32 0, i32 1
  store { { i64, [4 x i64] }, i64, i32 } %t253, ptr %t254
  %t255 = load { i64, [7 x i64] }, ptr %t246
  store { i64, [7 x i64] } %t255, ptr %l18
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = getelementptr %"compiler/lower:lowering", ptr %t257, i32 0, i32 3
  %t261 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t259)
  store i32 %t261, ptr %l124
  br label %bb36
bb36:
  %t262 = load i32, ptr %l124, !tbaa !23
  store i32 %t262, ptr %l19, !tbaa !23
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t265 = getelementptr %"compiler/lower:lowering", ptr %t263, i32 0, i32 3
  store ptr %t265, ptr %l126, !tbaa !29
  %t266 = load { i64, [7 x i64] }, ptr %l18
  store { i64, [7 x i64] } %t266, ptr %l127
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"compiler/lower:lowering", ptr %t267, i32 0, i32 3
  store ptr %t269, ptr %l129, !tbaa !29
  %t270 = load i32, ptr %l7, !tbaa !23
  %t272 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t270)
  store %"compiler/mir:Lvalue" %t272, ptr %l131
  br label %bb37
bb37:
  store { i64, [4 x i64] } zeroinitializer, ptr %t273
  %t274 = getelementptr { i64, [4 x i64] }, ptr %t273, i32 0, i32 0
  store i64 1, ptr %t274
  %t275 = load %"compiler/mir:Lvalue", ptr %l131
  %t276 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t275, 0
  %t277 = getelementptr { i64, [4 x i64] }, ptr %t273, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t276, ptr %t277
  %t278 = load { i64, [4 x i64] }, ptr %t273
  %t279 = load { i64, [4 x i64] }, ptr %l16
  %t280 = mul i64 2, 40
  %t281 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t280)
  %t282 = insertvalue { i64, ptr } undef, i64 2, 0
  %t283 = insertvalue { i64, ptr } %t282, ptr %t281, 1
  store { i64, ptr } %t283, ptr %l134, !tbaa !27
  %t285 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t286 = load ptr, ptr %t285, !tbaa !27
  %t287 = getelementptr { i64, [4 x i64] }, ptr %t286, i64 0
  store { i64, [4 x i64] } %t278, ptr %t287
  %t289 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t290 = load ptr, ptr %t289, !tbaa !27
  %t291 = getelementptr { i64, [4 x i64] }, ptr %t290, i64 1
  store { i64, [4 x i64] } %t279, ptr %t291
  %t292 = load ptr, ptr %l129, !tbaa !29
  %t293 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t294 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %s0, ptr %t292, { i64, ptr } %t293)
  store %"compiler/mir:Range" %t294, ptr %l135
  br label %bb38
bb38:
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t297 = getelementptr %"compiler/lower:lowering", ptr %t295, i32 0, i32 3
  %t298 = load { i64, [1 x i64] }, ptr %l1
  %t299 = mul i64 1, 16
  %t300 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t299)
  %t301 = insertvalue { i64, ptr } undef, i64 1, 0
  %t302 = insertvalue { i64, ptr } %t301, ptr %t300, 1
  store { i64, ptr } %t302, ptr %l139, !tbaa !27
  %t304 = getelementptr { i64, ptr }, ptr %l139, i32 0, i32 1
  %t305 = load ptr, ptr %t304, !tbaa !27
  %t306 = getelementptr { i64, [1 x i64] }, ptr %t305, i64 0
  store { i64, [1 x i64] } %t298, ptr %t306
  %t308 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t309 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eScopeRefs(ptr %v0, ptr %s0, ptr %t297, { i64, ptr } %t308)
  store %"compiler/mir:Range" %t309, ptr %l140
  br label %bb39
bb39:
  %t310 = load %"compiler/mir:Lvalue", ptr @G_2ecompiler_2fmir_2eNoPlace
  %t311 = load i32, ptr %l19, !tbaa !23
  %t312 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t313 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t314 = load { i64, [7 x i64] }, ptr %l127
  %t315 = load %"compiler/mir:Range", ptr %l135
  %t316 = load %"compiler/mir:Range", ptr %l140
  %t321 = call %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %s0, { i64, [7 x i64] } %t314, %"compiler/mir:Range" %t315, %"compiler/mir:Range" %t316, %"compiler/mir:Lvalue" %t310, i1 false, i32 %t311, i32 %t312, i32 %t313)
  store %"compiler/mir:Call" %t321, ptr %l145
  br label %bb40
bb40:
  %t322 = load ptr, ptr %l126, !tbaa !29
  %t323 = load %"compiler/mir:Call", ptr %l145
  %t324 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v0, ptr %t322, %"compiler/mir:Call" %t323)
  store i32 %t324, ptr %l146
  br label %bb41
bb41:
  %t325 = load i32, ptr %l146, !tbaa !23
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t327 = load %"compiler/source:Span", ptr %l5
  store { i64, [8 x i64] } zeroinitializer, ptr %t329
  %t330 = getelementptr { i64, [8 x i64] }, ptr %t329, i32 0, i32 0
  store i64 4, ptr %t330
  %t332 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t327, 0
  %t334 = insertvalue { %"compiler/source:Span", i32 } %t332, i32 %t325, 1
  %t335 = getelementptr { i64, [8 x i64] }, ptr %t329, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t334, ptr %t335
  %t336 = load { i64, [8 x i64] }, ptr %t329
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t326, { i64, [8 x i64] } %t336)
  br label %bb42
bb42:
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t340 = load i32, ptr %l19, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t339, i32 %t340)
  br label %bb43
bb43:
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t344 = load i32, ptr %l8, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t343, i32 %t344)
  br label %bb44
bb44:
  %t347 = load ptr, ptr %l0, !tbaa !29
  %t348 = load i32, ptr %l8, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t347, i32 %t348)
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eresultScope(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l14 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i64
  %l43 = alloca { i64, [1 x i64] }
  %rv = alloca { i64, [1 x i64] }
  %t8 = alloca { i64, [1 x i64] }, align 8
  %t83 = alloca { i64, [1 x i64] }, align 8
  %t94 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 19
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store { i64, [1 x i64] } zeroinitializer, ptr %t8
  %t9 = getelementptr { i64, [1 x i64] }, ptr %t8, i32 0, i32 0
  store i64 2, ptr %t9
  %t10 = load { i64, [1 x i64] }, ptr %t8
  store { i64, [1 x i64] } %t10, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l1, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lower:lowering", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Body", ptr %t15, i32 0, i32 6
  %t19 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eLen_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t17)
  store i64 %t19, ptr %l14
  br label %bb4
bb4:
  %t20 = load i64, ptr %l14, !tbaa !24
  store i64 %t20, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t21 = load i64, ptr %l2, !tbaa !24
  %t22 = load i64, ptr %l1, !tbaa !24
  %t25 = icmp sgt i64 %t21, %t22
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t27 = load i64, ptr %l3, !tbaa !24
  %t29 = icmp sgt i64 %t27, 0
  br i1 %t29, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb10
bb7:
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = sub i64 %t31, %t32
  %t36 = load i64, ptr %l3, !tbaa !24
  %t39 = add i64 %t35, %t36
  %t41 = sub i64 %t39, 1
  %t42 = load i64, ptr %l3, !tbaa !24
  %t45 = sdiv i64 %t41, %t42
  store i64 %t45, ptr %l21, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb9
bb9:
  %t47 = load i64, ptr %l21, !tbaa !24
  store i64 %t47, ptr %l18, !tbaa !24
  br label %bb10
bb10:
  %t48 = load i64, ptr %l18, !tbaa !24
  store i64 %t48, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb11
bb11:
  %t49 = load i64, ptr %l5, !tbaa !24
  %t50 = load i64, ptr %l4, !tbaa !24
  %t53 = icmp slt i64 %t49, %t50
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb12, label %bb13
bb12:
  br label %bb20
bb13:
  br label %bb14
bb14:
  %t57 = load i64, ptr %l1, !tbaa !24
  %t58 = load i64, ptr %l5, !tbaa !24
  %t59 = load i64, ptr %l3, !tbaa !24
  %t62 = mul i64 %t58, %t59
  %t65 = add i64 %t57, %t62
  store i64 %t65, ptr %l6, !tbaa !24
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/lower:lowering", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = getelementptr %"compiler/typed:Body", ptr %t70, i32 0, i32 6
  %t73 = load i64, ptr %l6, !tbaa !24
  %t76 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t72, i64 %t73)
  store { i64, [1 x i64] } %t76, ptr %l43
  br label %bb15
bb15:
  %t77 = load { i64, [1 x i64] }, ptr %l43
  %t79 = extractvalue { i64, [1 x i64] } %t77, 0
  %t80 = icmp eq i64 %t79, 1
  br i1 %t80, label %bb16, label %bb17
bb16:
  %t82 = load i64, ptr %l6, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t83
  %t84 = getelementptr { i64, [1 x i64] }, ptr %t83, i32 0, i32 0
  store i64 1, ptr %t84
  %t86 = insertvalue { i64 } undef, i64 %t82, 0
  %t87 = getelementptr { i64, [1 x i64] }, ptr %t83, i32 0, i32 1
  store { i64 } %t86, ptr %t87
  %t88 = load { i64, [1 x i64] }, ptr %t83
  store { i64, [1 x i64] } %t88, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t90 = load i64, ptr %l5, !tbaa !24
  %t92 = add i64 %t90, 1
  store i64 %t92, ptr %l5, !tbaa !24
  br label %bb11
bb20:
  store { i64, [1 x i64] } zeroinitializer, ptr %t94
  %t95 = getelementptr { i64, [1 x i64] }, ptr %t94, i32 0, i32 0
  store i64 2, ptr %t95
  %t96 = load { i64, [1 x i64] }, ptr %t94
  store { i64, [1 x i64] } %t96, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2espawn(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca %"compiler/source:Span"
  %l20 = alloca ptr
  %l21 = alloca { { i64, [7 x i64] }, i32 }
  %l22 = alloca { i64, [7 x i64] }
  %l23 = alloca i32
  %l24 = alloca %"compiler/mir:Range"
  %l25 = alloca i64
  %l26 = alloca i32
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca { i64, [4 x i64] }
  %l36 = alloca %"compiler/mir:Range"
  %l37 = alloca %"compiler/mir:Range"
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca ptr
  %l50 = alloca i64
  %l58 = alloca %"compiler/lower:level"
  %l61 = alloca i1
  %l68 = alloca %"compiler/lower:level"
  %l79 = alloca ptr
  %l80 = alloca i1
  %l94 = alloca i32
  %l103 = alloca { i64, ptr }
  %l106 = alloca i64
  %l107 = alloca %"compiler/mir:Lvalue"
  %l109 = alloca %"compiler/mir:Range"
  %l110 = alloca %"compiler/mir:Lvalue"
  %l120 = alloca i64
  %l123 = alloca i64
  %l142 = alloca { i64, ptr }
  %l150 = alloca i32
  %l157 = alloca i32
  %l158 = alloca ptr
  %l159 = alloca %"compiler/source:Span"
  %l161 = alloca %"compiler/mir:Lvalue"
  %l167 = alloca i64
  %l169 = alloca %"compiler/mir:Lvalue"
  %l170 = alloca i64
  %l171 = alloca ptr
  %l174 = alloca { i64, ptr }
  %l177 = alloca %"compiler/lower:pl"
  %l178 = alloca %"compiler/mir:Lvalue"
  %l181 = alloca ptr
  %l182 = alloca i1
  %l193 = alloca { { i64, [7 x i64] }, i32 }
  %l202 = alloca %"compiler/mir:Range"
  %l213 = alloca { i64, [4 x i64] }
  %l219 = alloca i64
  %l220 = alloca %"compiler/mir:TaskClause"
  %l222 = alloca %"compiler/mir:Range"
  %l223 = alloca %"compiler/mir:TaskClause"
  %l233 = alloca i64
  %l236 = alloca i64
  %l255 = alloca { i64, ptr }
  %l266 = alloca { i64, [4 x i64] }
  %l267 = alloca i64
  %l272 = alloca %"compiler/mir:Range"
  %l276 = alloca %"compiler/mir:TaskClause"
  %l284 = alloca ptr
  %l285 = alloca ptr
  %l289 = alloca i32
  %l291 = alloca { i64, ptr }
  %l292 = alloca %"compiler/mir:Range"
  %l293 = alloca %"compiler/mir:Range"
  %l296 = alloca i1
  %l299 = alloca i64
  %l309 = alloca i64
  %l312 = alloca i64
  %l333 = alloca { i64, ptr }
  %l339 = alloca i1
  %l340 = alloca ptr
  %l342 = alloca i32
  %l343 = alloca i1
  %l344 = alloca i1
  %l345 = alloca ptr
  %l346 = alloca ptr
  %l348 = alloca i32
  %l349 = alloca i1
  %l350 = alloca i64
  %l353 = alloca { i64, [1 x i64] }
  %l359 = alloca %"compiler/mir:Range"
  %l361 = alloca ptr
  %l362 = alloca { i64, [7 x i64] }
  %l363 = alloca %"compiler/mir:Range"
  %l364 = alloca ptr
  %l369 = alloca i64
  %l372 = alloca %"compiler/mir:Range"
  %l373 = alloca { i64, ptr }
  %l374 = alloca { i64, ptr }
  %l375 = alloca %"compiler/mir:Range"
  %l378 = alloca %"compiler/source:Span"
  %l380 = alloca i32
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %t146 = alloca i64
  %t271 = alloca { i64, [4 x i64] }, align 8
  %t278 = alloca { i64, [15 x i64] }, align 8
  %t284 = alloca { i64, [21 x i64] }, align 8
  %t403 = alloca { i64, [7 x i64] }, align 8
  %t437 = alloca i64
  %t512 = alloca { i64, [4 x i64] }, align 8
  %t673 = alloca { i64, [1 x i64] }, align 8
  %t790 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr @G_2ecompiler_2fmir_2eNoScope, !tbaa !23
  store i32 %t1, ptr %l3, !tbaa !23
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/lower:lowering", ptr %t3, i32 0, i32 9
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t5)
  store i64 %t7, ptr %l50
  br label %bb1
bb1:
  %t8 = load i64, ptr %l50, !tbaa !24
  %t9 = sub i64 %t8, 1
  store i64 %t9, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sge i64 %t11, 0
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb15
bb4:
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/lower:lowering", ptr %t17, i32 0, i32 9
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = call %"compiler/lower:level" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eAt_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t19, i64 %t20)
  store %"compiler/lower:level" %t23, ptr %l58
  br label %bb6
bb6:
  %t24 = getelementptr %"compiler/lower:level", ptr %l58, i32 0, i32 2
  %t25 = load i32, ptr %t24
  %t27 = trunc i64 3 to i32
  %t28 = icmp eq i32 %t25, %t27
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t30 = load i32, ptr %l3, !tbaa !23
  %t31 = load i32, ptr @G_2ecompiler_2fmir_2eNoScope, !tbaa !23
  %t34 = icmp eq i32 %t30, %t31
  store i1 %t34, ptr %l61, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb9
bb9:
  %t36 = load i1, ptr %l61, !tbaa !21
  br i1 %t36, label %bb10, label %bb11
bb10:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/lower:lowering", ptr %t37, i32 0, i32 9
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = call %"compiler/lower:level" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eAt_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t39, i64 %t40)
  store %"compiler/lower:level" %t43, ptr %l68
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t44 = getelementptr %"compiler/lower:level", ptr %l68, i32 0, i32 0
  %t45 = load i32, ptr %t44, !tbaa !23
  store i32 %t45, ptr %l3, !tbaa !23
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t47 = load i64, ptr %l4, !tbaa !24
  %t49 = sub i64 %t47, 1
  store i64 %t49, ptr %l4, !tbaa !24
  br label %bb2
bb15:
  %t51 = load i32, ptr %l3, !tbaa !23
  %t52 = load i32, ptr @G_2ecompiler_2fmir_2eNoScope, !tbaa !23
  %t55 = icmp eq i32 %t51, %t52
  br i1 %t55, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s5
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egap(ptr %v0, ptr %s5, ptr %t57, %"compiler/source:Span" %t58, { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d16, i32 0, i32 1) })
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb19:
  %t61 = load ptr, ptr %l2, !tbaa !29
  %t63 = getelementptr %"compiler/typed:Spawn", ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !29
  store ptr %t64, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t66 = load ptr, ptr %l5, !tbaa !29
  store ptr %t66, ptr %l79, !tbaa !29
  store i1 false, ptr %l80, !tbaa !21
  %t67 = load ptr, ptr %l79, !tbaa !29
  %t68 = icmp ne ptr %t67, null
  br i1 %t68, label %bb20, label %bb21
bb20:
  %t70 = load ptr, ptr %l79, !tbaa !29
  %t71 = load i64, ptr %t70
  %t73 = icmp eq i64 %t71, 14
  store i1 %t73, ptr %l80, !tbaa !21
  br label %bb21
bb21:
  %t74 = load i1, ptr %l80, !tbaa !21
  br i1 %t74, label %bb22, label %bb23
bb22:
  %t75 = load ptr, ptr %l5, !tbaa !29
  %t77 = getelementptr { i64, [5 x i64] }, ptr %t75, i32 0, i32 1
  %t78 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t77, i32 0, i32 2
  %t79 = load ptr, ptr %t78
  store ptr %t79, ptr %l7, !tbaa !29
  br label %bb24
bb23:
  br label %bb30
bb24:
  %t81 = load ptr, ptr %l7, !tbaa !29
  %t83 = getelementptr %"compiler/typed:Try", ptr %t81, i32 0, i32 2
  %t84 = load i1, ptr %t83, !tbaa !21
  br i1 %t84, label %bb25, label %bb26
bb25:
  %t86 = load ptr, ptr %l7, !tbaa !29
  %t88 = getelementptr %"compiler/typed:Try", ptr %t86, i32 0, i32 0
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = icmp eq ptr %t89, null
  br i1 %t91, label %bb27, label %bb28
bb26:
  br label %bb30
bb27:
  call void @__olang_check_failed(ptr @olang_loc_1f89626f934b863_cae48f8c5308207f)
  unreachable
bb28:
  br label %bb29
bb29:
  %t93 = load ptr, ptr %l7, !tbaa !29
  %t95 = getelementptr %"compiler/typed:Try", ptr %t93, i32 0, i32 0
  %t96 = load ptr, ptr %t95, !tbaa !29
  store ptr %t96, ptr %l5, !tbaa !29
  store i1 true, ptr %l6, !tbaa !21
  br label %bb35
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_bd186c5d6cd7a57b_c31a7bfdd180fca7)
  unreachable
bb35:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load ptr, ptr %l5, !tbaa !29
  %t102 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etaskType(ptr %v0, ptr %v1, ptr %t98, ptr %t99)
  store i32 %t102, ptr %l94
  br label %bb36
bb36:
  %t103 = load i32, ptr %l94, !tbaa !23
  store i32 %t103, ptr %l8, !tbaa !23
  %t104 = load i32, ptr %l8, !tbaa !23
  %t105 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t108 = icmp eq i32 %t104, %t105
  br i1 %t108, label %bb37, label %bb38
bb37:
  store %olang.scope zeroinitializer, ptr %s8
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egap(ptr %v0, ptr %s8, ptr %t110, %"compiler/source:Span" %t111, { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d17, i32 0, i32 1) })
  br label %bb39
bb38:
  br label %bb40
bb39:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb40:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/lower:lowering", ptr %t114, i32 0, i32 2
  %t117 = load ptr, ptr %t116, !tbaa !29
  %t118 = load i32, ptr %l8, !tbaa !23
  %t121 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s0, ptr %t117, i32 %t118)
  store { i64, ptr } %t121, ptr %l103
  br label %bb41
bb41:
  %t122 = load { i64, ptr }, ptr %l103, !tbaa !27
  store { i64, ptr } %t122, ptr %l9, !tbaa !27
  %t123 = load ptr, ptr %l2, !tbaa !29
  %t125 = getelementptr %"compiler/typed:Spawn", ptr %t123, i32 0, i32 0
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t126, 0
  store i64 %t128, ptr %l106, !tbaa !24
  store %"compiler/mir:Lvalue" zeroinitializer, ptr %l107
  %t129 = load i64, ptr %l106, !tbaa !24
  %t130 = icmp sgt i64 %t129, 0
  br i1 %t130, label %bb42, label %bb43
bb42:
  %t132 = call %"compiler/mir:Range" @compiler_2fmir_3aRange_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/mir:Range" %t132, ptr %l109
  br label %bb44
bb43:
  %t133 = load i64, ptr %l106, !tbaa !24
  %t134 = icmp sge i64 %t133, 0
  br i1 %t134, label %bb46, label %bb47
bb44:
  %t136 = load %"compiler/mir:Range", ptr %l109
  %t137 = call %"compiler/mir:Lvalue" @compiler_2fmir_3aLvalue_2ector(ptr %s0, { i64, [2 x i64] } zeroinitializer, %"compiler/mir:Range" %t136)
  store %"compiler/mir:Lvalue" %t137, ptr %l110
  br label %bb45
bb45:
  %t138 = load %"compiler/mir:Lvalue", ptr %l110
  store %"compiler/mir:Lvalue" %t138, ptr %l107
  br label %bb43
bb46:
  %t139 = load i64, ptr %l106, !tbaa !24
  %t140 = icmp sle i64 %t139, 288230376151711743
  br i1 %t140, label %bb48, label %bb49
bb47:
  call void @__olang_check_failed(ptr @olang_loc_50381a907c443937_a4d06b271538b33b)
  unreachable
bb48:
  %t142 = load i64, ptr %l106, !tbaa !24
  %t143 = mul i64 %t142, 32
  %t144 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t143)
  %t145 = load %"compiler/mir:Lvalue", ptr %l107
  store i64 0, ptr %t146
  br label %fill.147
fill.147:
  %t150 = load i64, ptr %t146
  %t151 = icmp slt i64 %t150, %t142
  br i1 %t151, label %fillb.148, label %filld.149
fillb.148:
  %t152 = getelementptr %"compiler/mir:Lvalue", ptr %t144, i64 %t150
  store %"compiler/mir:Lvalue" %t145, ptr %t152
  %t153 = add i64 %t150, 1
  store i64 %t153, ptr %t146
  br label %fill.147
filld.149:
  %t154 = insertvalue { i64, ptr } undef, i64 %t142, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t144, 1
  store { i64, ptr } %t155, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t157 = load ptr, ptr %l2, !tbaa !29
  %t159 = getelementptr %"compiler/typed:Spawn", ptr %t157, i32 0, i32 0
  %t160 = load { i64, ptr }, ptr %t159, !tbaa !27
  %t162 = extractvalue { i64, ptr } %t160, 0
  store i64 %t162, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t164 = load i64, ptr %l12, !tbaa !24
  %t165 = load i64, ptr %l11, !tbaa !24
  %t168 = icmp sgt i64 %t164, %t165
  br i1 %t168, label %bb50, label %bb51
bb49:
  call void @__olang_check_failed(ptr @olang_loc_50381a907c443937_a4d06b271538b33b)
  unreachable
bb50:
  %t170 = load i64, ptr %l13, !tbaa !24
  %t172 = icmp sgt i64 %t170, 0
  br i1 %t172, label %bb52, label %bb53
bb51:
  store i64 0, ptr %l120, !tbaa !24
  br label %bb55
bb52:
  %t174 = load i64, ptr %l12, !tbaa !24
  %t175 = load i64, ptr %l11, !tbaa !24
  %t178 = sub i64 %t174, %t175
  %t179 = load i64, ptr %l13, !tbaa !24
  %t182 = add i64 %t178, %t179
  %t184 = sub i64 %t182, 1
  %t185 = load i64, ptr %l13, !tbaa !24
  %t188 = sdiv i64 %t184, %t185
  store i64 %t188, ptr %l123, !tbaa !24
  br label %bb54
bb53:
  store i64 0, ptr %l123, !tbaa !24
  br label %bb54
bb54:
  %t190 = load i64, ptr %l123, !tbaa !24
  store i64 %t190, ptr %l120, !tbaa !24
  br label %bb55
bb55:
  %t191 = load i64, ptr %l120, !tbaa !24
  store i64 %t191, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb56
bb56:
  %t192 = load i64, ptr %l15, !tbaa !24
  %t193 = load i64, ptr %l14, !tbaa !24
  %t196 = icmp slt i64 %t192, %t193
  %t198 = xor i1 %t196, true
  br i1 %t198, label %bb57, label %bb58
bb57:
  br label %bb73
bb58:
  br label %bb59
bb59:
  %t200 = load i64, ptr %l11, !tbaa !24
  %t201 = load i64, ptr %l15, !tbaa !24
  %t202 = load i64, ptr %l13, !tbaa !24
  %t205 = mul i64 %t201, %t202
  %t208 = add i64 %t200, %t205
  store i64 %t208, ptr %l16, !tbaa !24
  %t210 = load ptr, ptr %l2, !tbaa !29
  %t212 = getelementptr %"compiler/typed:Spawn", ptr %t210, i32 0, i32 0
  %t213 = load { i64, ptr }, ptr %t212, !tbaa !27
  store { i64, ptr } %t213, ptr %l142, !tbaa !27
  %t214 = load i64, ptr %l16, !tbaa !24
  %t216 = getelementptr { i64, ptr }, ptr %l142, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !27
  %t218 = getelementptr ptr, ptr %t217, i64 %t214
  %t219 = load ptr, ptr %t218, !tbaa !39
  %t221 = icmp eq ptr %t219, null
  br i1 %t221, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s11
  %t223 = load i64, ptr %l16, !tbaa !24
  %t224 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t226 = extractvalue { i64, ptr } %t224, 0
  %t229 = icmp slt i64 %t223, %t226
  br i1 %t229, label %bb62, label %bb63
bb61:
  %t231 = load i64, ptr %l16, !tbaa !24
  store i64 %t231, ptr %l170, !tbaa !24
  %t232 = load ptr, ptr %l0, !tbaa !29
  store ptr %t232, ptr %l171, !tbaa !29
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t234 = load ptr, ptr %l2, !tbaa !29
  %t236 = getelementptr %"compiler/typed:Spawn", ptr %t234, i32 0, i32 0
  %t237 = load { i64, ptr }, ptr %t236, !tbaa !27
  store { i64, ptr } %t237, ptr %l174, !tbaa !27
  %t238 = load i64, ptr %l16, !tbaa !24
  %t240 = getelementptr { i64, ptr }, ptr %l174, i32 0, i32 1
  %t241 = load ptr, ptr %t240, !tbaa !27
  %t242 = getelementptr ptr, ptr %t241, i64 %t238
  %t243 = load ptr, ptr %t242, !tbaa !39
  %t246 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eplace(ptr %v0, ptr %v1, ptr %v0, ptr %t233, ptr %t243)
  store %"compiler/lower:pl" %t246, ptr %l177
  br label %bb69
bb62:
  %t247 = load i64, ptr %l16, !tbaa !24
  %t249 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t250 = load ptr, ptr %t249, !tbaa !27
  %t251 = getelementptr i32, ptr %t250, i64 %t247
  %t252 = load i32, ptr %t251, !tbaa !33
  store i32 %t252, ptr %l150, !tbaa !23
  br label %bb64
bb63:
  %t254 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t254, ptr %l150, !tbaa !23
  br label %bb64
bb64:
  %t256 = load i32, ptr %l150, !tbaa !23
  store i32 %t256, ptr %l17, !tbaa !23
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load i32, ptr %l17, !tbaa !23
  %t259 = load %"compiler/source:Span", ptr %l1
  %t263 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t257, i32 %t258, %"compiler/source:Span" %t259)
  store i32 %t263, ptr %l157
  br label %bb65
bb65:
  %t264 = load i32, ptr %l157, !tbaa !23
  store i32 %t264, ptr %l18, !tbaa !23
  %t265 = load ptr, ptr %l0, !tbaa !29
  store ptr %t265, ptr %l158, !tbaa !29
  %t266 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t266, ptr %l159
  %t267 = load i32, ptr %l18, !tbaa !23
  %t269 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t267)
  store %"compiler/mir:Lvalue" %t269, ptr %l161
  br label %bb66
bb66:
  %t270 = load i32, ptr %l17, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t271
  %t272 = getelementptr { i64, [4 x i64] }, ptr %t271, i32 0, i32 0
  store i64 2, ptr %t272
  %t274 = insertvalue { i32, i64 } undef, i32 %t270, 0
  %t275 = insertvalue { i32, i64 } %t274, i64 0, 1
  %t276 = getelementptr { i64, [4 x i64] }, ptr %t271, i32 0, i32 1
  store { i32, i64 } %t275, ptr %t276
  %t277 = load { i64, [4 x i64] }, ptr %t271
  store { i64, [15 x i64] } zeroinitializer, ptr %t278
  %t279 = getelementptr { i64, [15 x i64] }, ptr %t278, i32 0, i32 0
  store i64 0, ptr %t279
  %t281 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t277, 0
  %t282 = getelementptr { i64, [15 x i64] }, ptr %t278, i32 0, i32 1
  store { { i64, [4 x i64] } } %t281, ptr %t282
  %t283 = load { i64, [15 x i64] }, ptr %t278
  store { i64, [21 x i64] } zeroinitializer, ptr %t284
  %t285 = getelementptr { i64, [21 x i64] }, ptr %t284, i32 0, i32 0
  store i64 0, ptr %t285
  %t286 = load %"compiler/source:Span", ptr %l159
  %t287 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t286, 0
  %t288 = load %"compiler/mir:Lvalue", ptr %l161
  %t289 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t287, %"compiler/mir:Lvalue" %t288, 1
  %t291 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t289, { i64, [15 x i64] } %t283, 2
  %t292 = getelementptr { i64, [21 x i64] }, ptr %t284, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t291, ptr %t292
  %t293 = load { i64, [21 x i64] }, ptr %t284
  %t295 = call ptr @__olang_scope_alloc_a(ptr %s11, i64 176, i64 8)
  store { i64, [21 x i64] } %t293, ptr %t295
  %t296 = load ptr, ptr %l158, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s11, ptr %t296, ptr %t295)
  br label %bb67
bb67:
  %t298 = load i64, ptr %l16, !tbaa !24
  store i64 %t298, ptr %l167, !tbaa !24
  %t299 = load i32, ptr %l18, !tbaa !23
  %t301 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t299)
  store %"compiler/mir:Lvalue" %t301, ptr %l169
  br label %bb68
bb68:
  %t302 = load %"compiler/mir:Lvalue", ptr %l169
  %t303 = load i64, ptr %l167, !tbaa !24
  %t304 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t305 = load ptr, ptr %t304, !tbaa !27
  %t306 = getelementptr %"compiler/mir:Lvalue", ptr %t305, i64 %t303
  store %"compiler/mir:Lvalue" %t302, ptr %t306
  call void @__olang_scope_close(ptr %s11)
  br label %bb71
bb69:
  %t307 = load ptr, ptr %l171, !tbaa !29
  %t308 = load %"compiler/lower:pl", ptr %l177
  %t309 = call %"compiler/mir:Lvalue" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v0, ptr %t307, %"compiler/lower:pl" %t308)
  store %"compiler/mir:Lvalue" %t309, ptr %l178
  br label %bb70
bb70:
  %t310 = load %"compiler/mir:Lvalue", ptr %l178
  %t311 = load i64, ptr %l170, !tbaa !24
  %t312 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t313 = load ptr, ptr %t312, !tbaa !27
  %t314 = getelementptr %"compiler/mir:Lvalue", ptr %t313, i64 %t311
  store %"compiler/mir:Lvalue" %t310, ptr %t314
  br label %bb71
bb71:
  br label %bb72
bb72:
  %t315 = load i64, ptr %l15, !tbaa !24
  %t317 = add i64 %t315, 1
  store i64 %t317, ptr %l15, !tbaa !24
  br label %bb56
bb73:
  %t319 = load ptr, ptr %l5, !tbaa !29
  store ptr %t319, ptr %l181, !tbaa !29
  store i1 false, ptr %l182, !tbaa !21
  %t320 = load ptr, ptr %l181, !tbaa !29
  %t321 = icmp ne ptr %t320, null
  br i1 %t321, label %bb74, label %bb75
bb74:
  %t323 = load ptr, ptr %l181, !tbaa !29
  %t324 = load i64, ptr %t323
  %t326 = icmp eq i64 %t324, 6
  store i1 %t326, ptr %l182, !tbaa !21
  br label %bb75
bb75:
  %t327 = load i1, ptr %l182, !tbaa !21
  br i1 %t327, label %bb76, label %bb77
bb76:
  %t328 = load ptr, ptr %l5, !tbaa !29
  %t330 = getelementptr { i64, [5 x i64] }, ptr %t328, i32 0, i32 1
  %t331 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t330, i32 0, i32 0
  %t332 = load %"compiler/source:Span", ptr %t331
  store %"compiler/source:Span" %t332, ptr %l19
  %t334 = load ptr, ptr %l5, !tbaa !29
  %t336 = getelementptr { i64, [5 x i64] }, ptr %t334, i32 0, i32 1
  %t337 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t336, i32 0, i32 2
  %t338 = load ptr, ptr %t337
  store ptr %t338, ptr %l20, !tbaa !29
  br label %bb78
bb77:
  br label %bb173
bb78:
  store %olang.scope zeroinitializer, ptr %s14
  %t340 = load ptr, ptr %l0, !tbaa !29
  %t341 = load ptr, ptr %l20, !tbaa !29
  %t343 = getelementptr %"compiler/typed:Call", ptr %t341, i32 0, i32 0
  %t344 = load ptr, ptr %t343, !tbaa !29
  %t345 = load %"compiler/source:Span", ptr %l19
  %t349 = call { { i64, [7 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2ecallee(ptr %v0, ptr %v1, ptr %t340, ptr %t344, %"compiler/source:Span" %t345)
  store { { i64, [7 x i64] }, i32 } %t349, ptr %l193
  br label %bb79
bb79:
  %t350 = load { { i64, [7 x i64] }, i32 }, ptr %l193
  store { { i64, [7 x i64] }, i32 } %t350, ptr %l21
  %t351 = getelementptr { { i64, [7 x i64] }, i32 }, ptr %l21, i32 0, i32 0
  %t352 = load { i64, [7 x i64] }, ptr %t351
  store { i64, [7 x i64] } %t352, ptr %l22
  %t354 = getelementptr { { i64, [7 x i64] }, i32 }, ptr %l21, i32 0, i32 1
  %t355 = load i32, ptr %t354, !tbaa !23
  store i32 %t355, ptr %l23, !tbaa !23
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t359 = getelementptr %"compiler/lower:lowering", ptr %t357, i32 0, i32 7
  %t360 = load i1, ptr %t359, !tbaa !21
  br i1 %t360, label %bb80, label %bb81
bb80:
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb81:
  br label %bb82
bb82:
  %t362 = load ptr, ptr %l0, !tbaa !29
  %t363 = load ptr, ptr %l20, !tbaa !29
  %t364 = load { i64, [7 x i64] }, ptr %l22
  %t365 = load i32, ptr %l23, !tbaa !23
  %t370 = call %"compiler/mir:Range" @compiler_2flower_2ecompiler_2flower_3alowering_2eargs(ptr %v0, ptr %v1, ptr %t362, ptr %t363, { i64, [7 x i64] } %t364, i32 %t365)
  store %"compiler/mir:Range" %t370, ptr %l202
  br label %bb83
bb83:
  %t371 = load %"compiler/mir:Range", ptr %l202
  store %"compiler/mir:Range" %t371, ptr %l24
  %t372 = load ptr, ptr %l0, !tbaa !29
  %t374 = getelementptr %"compiler/lower:lowering", ptr %t372, i32 0, i32 7
  %t375 = load i1, ptr %t374, !tbaa !21
  br i1 %t375, label %bb84, label %bb85
bb84:
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb85:
  br label %bb86
bb86:
  %t377 = load { i64, [7 x i64] }, ptr %l22
  %t379 = extractvalue { i64, [7 x i64] } %t377, 0
  %t380 = icmp eq i64 %t379, 3
  br i1 %t380, label %bb87, label %bb88
bb87:
  %t382 = getelementptr { i64, [7 x i64] }, ptr %l22, i32 0, i32 1
  %t383 = getelementptr { { i64, [4 x i64] }, i64, i32 }, ptr %t382, i32 0, i32 1
  %t384 = load i64, ptr %t383
  store i64 %t384, ptr %l25, !tbaa !24
  %t386 = getelementptr { i64, [7 x i64] }, ptr %l22, i32 0, i32 1
  %t387 = getelementptr { { i64, [4 x i64] }, i64, i32 }, ptr %t386, i32 0, i32 2
  %t388 = load i32, ptr %t387
  store i32 %t388, ptr %l26, !tbaa !23
  br label %bb89
bb88:
  br label %bb91
bb89:
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t392 = getelementptr %"compiler/lower:lowering", ptr %t390, i32 0, i32 3
  %t393 = getelementptr %"compiler/mir:Fn", ptr %t392, i32 0, i32 11
  %t394 = getelementptr %"compiler/mir:Range", ptr %l24, i32 0, i32 0
  %t395 = load i32, ptr %t394, !tbaa !23
  %t397 = sext i32 %t395 to i64
  %t400 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t393, i64 %t397)
  store { i64, [4 x i64] } %t400, ptr %l213
  br label %bb90
bb90:
  %t401 = load i64, ptr %l25, !tbaa !24
  %t402 = load i32, ptr %l26, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t403
  %t404 = getelementptr { i64, [7 x i64] }, ptr %t403, i32 0, i32 0
  store i64 3, ptr %t404
  %t405 = load { i64, [4 x i64] }, ptr %l213
  %t406 = insertvalue { { i64, [4 x i64] }, i64, i32 } undef, { i64, [4 x i64] } %t405, 0
  %t408 = insertvalue { { i64, [4 x i64] }, i64, i32 } %t406, i64 %t401, 1
  %t410 = insertvalue { { i64, [4 x i64] }, i64, i32 } %t408, i32 %t402, 2
  %t411 = getelementptr { i64, [7 x i64] }, ptr %t403, i32 0, i32 1
  store { { i64, [4 x i64] }, i64, i32 } %t410, ptr %t411
  %t412 = load { i64, [7 x i64] }, ptr %t403
  store { i64, [7 x i64] } %t412, ptr %l22
  br label %bb96
bb91:
  br i1 true, label %bb92, label %bb93
bb92:
  br label %bb94
bb93:
  br label %bb95
bb94:
  br label %bb96
bb95:
  call void @__olang_check_failed(ptr @olang_loc_400575d530dd6291_b9c64e3b22c571dd)
  unreachable
bb96:
  %t414 = load ptr, ptr %l2, !tbaa !29
  %t416 = getelementptr %"compiler/typed:Spawn", ptr %t414, i32 0, i32 2
  %t417 = load { i64, ptr }, ptr %t416, !tbaa !27
  %t419 = extractvalue { i64, ptr } %t417, 0
  store i64 %t419, ptr %l219, !tbaa !24
  store %"compiler/mir:TaskClause" zeroinitializer, ptr %l220
  %t420 = load i64, ptr %l219, !tbaa !24
  %t421 = icmp sgt i64 %t420, 0
  br i1 %t421, label %bb97, label %bb98
bb97:
  %t423 = call %"compiler/mir:Range" @compiler_2fmir_3aRange_2ector(ptr %s14, i32 0, i32 0)
  store %"compiler/mir:Range" %t423, ptr %l222
  br label %bb99
bb98:
  %t424 = load i64, ptr %l219, !tbaa !24
  %t425 = icmp sge i64 %t424, 0
  br i1 %t425, label %bb101, label %bb102
bb99:
  %t427 = load %"compiler/mir:Range", ptr %l222
  %t428 = call %"compiler/mir:TaskClause" @compiler_2fmir_3aTaskClause_2ector(ptr %s14, %"compiler/mir:Range" %t427, i1 false, { i64, [4 x i64] } zeroinitializer)
  store %"compiler/mir:TaskClause" %t428, ptr %l223
  br label %bb100
bb100:
  %t429 = load %"compiler/mir:TaskClause", ptr %l223
  store %"compiler/mir:TaskClause" %t429, ptr %l220
  br label %bb98
bb101:
  %t430 = load i64, ptr %l219, !tbaa !24
  %t431 = icmp sle i64 %t430, 164703072086692425
  br i1 %t431, label %bb103, label %bb104
bb102:
  call void @__olang_check_failed(ptr @olang_loc_956aeda6c669b3b5_1d6c951e348c7771)
  unreachable
bb103:
  %t433 = load i64, ptr %l219, !tbaa !24
  %t434 = mul i64 %t433, 56
  %t435 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t434)
  %t436 = load %"compiler/mir:TaskClause", ptr %l220
  store i64 0, ptr %t437
  br label %fill.438
fill.438:
  %t441 = load i64, ptr %t437
  %t442 = icmp slt i64 %t441, %t433
  br i1 %t442, label %fillb.439, label %filld.440
fillb.439:
  %t443 = getelementptr %"compiler/mir:TaskClause", ptr %t435, i64 %t441
  store %"compiler/mir:TaskClause" %t436, ptr %t443
  %t444 = add i64 %t441, 1
  store i64 %t444, ptr %t437
  br label %fill.438
filld.440:
  %t445 = insertvalue { i64, ptr } undef, i64 %t433, 0
  %t446 = insertvalue { i64, ptr } %t445, ptr %t435, 1
  store { i64, ptr } %t446, ptr %l27, !tbaa !27
  store i64 0, ptr %l28, !tbaa !24
  %t448 = load ptr, ptr %l2, !tbaa !29
  %t450 = getelementptr %"compiler/typed:Spawn", ptr %t448, i32 0, i32 2
  %t451 = load { i64, ptr }, ptr %t450, !tbaa !27
  %t453 = extractvalue { i64, ptr } %t451, 0
  store i64 %t453, ptr %l29, !tbaa !24
  store i64 1, ptr %l30, !tbaa !24
  %t455 = load i64, ptr %l29, !tbaa !24
  %t456 = load i64, ptr %l28, !tbaa !24
  %t459 = icmp sgt i64 %t455, %t456
  br i1 %t459, label %bb105, label %bb106
bb104:
  call void @__olang_check_failed(ptr @olang_loc_956aeda6c669b3b5_1d6c951e348c7771)
  unreachable
bb105:
  %t461 = load i64, ptr %l30, !tbaa !24
  %t463 = icmp sgt i64 %t461, 0
  br i1 %t463, label %bb107, label %bb108
bb106:
  store i64 0, ptr %l233, !tbaa !24
  br label %bb110
bb107:
  %t465 = load i64, ptr %l29, !tbaa !24
  %t466 = load i64, ptr %l28, !tbaa !24
  %t469 = sub i64 %t465, %t466
  %t470 = load i64, ptr %l30, !tbaa !24
  %t473 = add i64 %t469, %t470
  %t475 = sub i64 %t473, 1
  %t476 = load i64, ptr %l30, !tbaa !24
  %t479 = sdiv i64 %t475, %t476
  store i64 %t479, ptr %l236, !tbaa !24
  br label %bb109
bb108:
  store i64 0, ptr %l236, !tbaa !24
  br label %bb109
bb109:
  %t481 = load i64, ptr %l236, !tbaa !24
  store i64 %t481, ptr %l233, !tbaa !24
  br label %bb110
bb110:
  %t482 = load i64, ptr %l233, !tbaa !24
  store i64 %t482, ptr %l31, !tbaa !24
  store i64 0, ptr %l32, !tbaa !24
  br label %bb111
bb111:
  store %olang.scope zeroinitializer, ptr %s20
  %t483 = load i64, ptr %l32, !tbaa !24
  %t484 = load i64, ptr %l31, !tbaa !24
  %t487 = icmp slt i64 %t483, %t484
  %t489 = xor i1 %t487, true
  br i1 %t489, label %bb112, label %bb113
bb112:
  call void @__olang_scope_close(ptr %s20)
  br label %bb122
bb113:
  br label %bb114
bb114:
  %t491 = load i64, ptr %l28, !tbaa !24
  %t492 = load i64, ptr %l32, !tbaa !24
  %t493 = load i64, ptr %l30, !tbaa !24
  %t496 = mul i64 %t492, %t493
  %t499 = add i64 %t491, %t496
  store i64 %t499, ptr %l33, !tbaa !24
  %t501 = load ptr, ptr %l2, !tbaa !29
  %t503 = getelementptr %"compiler/typed:Spawn", ptr %t501, i32 0, i32 2
  %t504 = load { i64, ptr }, ptr %t503, !tbaa !27
  store { i64, ptr } %t504, ptr %l255, !tbaa !27
  %t505 = load i64, ptr %l33, !tbaa !24
  %t507 = getelementptr { i64, ptr }, ptr %l255, i32 0, i32 1
  %t508 = load ptr, ptr %t507, !tbaa !27
  %t509 = getelementptr ptr, ptr %t508, i64 %t505
  %t510 = load ptr, ptr %t509, !tbaa !39
  store ptr %t510, ptr %l34, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t512
  %t513 = getelementptr { i64, [4 x i64] }, ptr %t512, i32 0, i32 0
  store i64 0, ptr %t513
  %t514 = load { i64, [4 x i64] }, ptr %t512
  store { i64, [4 x i64] } %t514, ptr %l35
  %t516 = load ptr, ptr %l34, !tbaa !29
  %t518 = getelementptr %"compiler/typed:TaskClause", ptr %t516, i32 0, i32 3
  %t519 = load ptr, ptr %t518, !tbaa !29
  %t521 = icmp eq ptr %t519, null
  %t523 = xor i1 %t521, true
  br i1 %t523, label %bb115, label %bb116
bb115:
  %t525 = load ptr, ptr %l0, !tbaa !29
  %t526 = load ptr, ptr %l34, !tbaa !29
  %t528 = getelementptr %"compiler/typed:TaskClause", ptr %t526, i32 0, i32 3
  %t529 = load ptr, ptr %t528, !tbaa !29
  %t532 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t525, ptr %t529)
  store { i64, [4 x i64] } %t532, ptr %l266
  br label %bb117
bb116:
  br label %bb118
bb117:
  %t533 = load { i64, [4 x i64] }, ptr %l266
  store { i64, [4 x i64] } %t533, ptr %l35
  br label %bb118
bb118:
  %t534 = load i64, ptr %l33, !tbaa !24
  store i64 %t534, ptr %l267, !tbaa !24
  %t535 = load ptr, ptr %l0, !tbaa !29
  %t537 = getelementptr %"compiler/lower:lowering", ptr %t535, i32 0, i32 3
  %t538 = load ptr, ptr %l34, !tbaa !29
  %t540 = getelementptr %"compiler/typed:TaskClause", ptr %t538, i32 0, i32 1
  %t541 = load { i64, ptr }, ptr %t540, !tbaa !27
  %t544 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddItems(ptr %v0, ptr %v1, ptr %t537, { i64, ptr } %t541)
  store %"compiler/mir:Range" %t544, ptr %l272
  br label %bb119
bb119:
  %t545 = load ptr, ptr %l34, !tbaa !29
  %t547 = getelementptr %"compiler/typed:TaskClause", ptr %t545, i32 0, i32 2
  %t548 = load i1, ptr %t547, !tbaa !21
  %t549 = load { i64, [4 x i64] }, ptr %l35
  %t550 = load %"compiler/mir:Range", ptr %l272
  %t553 = call %"compiler/mir:TaskClause" @compiler_2fmir_3aTaskClause_2ector(ptr %s20, %"compiler/mir:Range" %t550, i1 %t548, { i64, [4 x i64] } %t549)
  store %"compiler/mir:TaskClause" %t553, ptr %l276
  br label %bb120
bb120:
  %t554 = load %"compiler/mir:TaskClause", ptr %l276
  %t555 = load i64, ptr %l267, !tbaa !24
  %t556 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t557 = load ptr, ptr %t556, !tbaa !27
  %t558 = getelementptr %"compiler/mir:TaskClause", ptr %t557, i64 %t555
  store %"compiler/mir:TaskClause" %t554, ptr %t558
  call void @__olang_scope_close(ptr %s20)
  br label %bb121
bb121:
  %t559 = load i64, ptr %l32, !tbaa !24
  %t561 = add i64 %t559, 1
  store i64 %t561, ptr %l32, !tbaa !24
  br label %bb111
bb122:
  %t563 = load ptr, ptr %l0, !tbaa !29
  %t565 = getelementptr %"compiler/lower:lowering", ptr %t563, i32 0, i32 7
  %t566 = load i1, ptr %t565, !tbaa !21
  br i1 %t566, label %bb123, label %bb124
bb123:
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb124:
  br label %bb125
bb125:
  %t568 = load %"compiler/mir:Range", ptr @G_2ecompiler_2fmir_2eEmpty
  store %"compiler/mir:Range" %t568, ptr %l36
  %t570 = load i1, ptr %l6, !tbaa !21
  br i1 %t570, label %bb126, label %bb127
bb126:
  store %olang.scope zeroinitializer, ptr %s24
  %t572 = load ptr, ptr %l0, !tbaa !29
  %t574 = getelementptr %"compiler/lower:lowering", ptr %t572, i32 0, i32 3
  store ptr %t574, ptr %l284, !tbaa !29
  %t575 = load ptr, ptr %l0, !tbaa !29
  store ptr %t575, ptr %l285, !tbaa !29
  %t576 = load ptr, ptr %l0, !tbaa !29
  %t578 = getelementptr %"compiler/lower:lowering", ptr %t576, i32 0, i32 2
  %t579 = load ptr, ptr %t578, !tbaa !29
  %t580 = load i32, ptr %l23, !tbaa !23
  %t583 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t579, i32 %t580)
  store i32 %t583, ptr %l289
  br label %bb128
bb127:
  br label %bb131
bb128:
  %t584 = load %"compiler/source:Span", ptr %l1
  %t585 = load ptr, ptr %l285, !tbaa !29
  %t586 = load i32, ptr %l289, !tbaa !23
  %t588 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2ebangNames(ptr %v0, ptr %s24, ptr %t585, i32 %t586, %"compiler/source:Span" %t584)
  store { i64, ptr } %t588, ptr %l291
  br label %bb129
bb129:
  %t589 = load ptr, ptr %l284, !tbaa !29
  %t590 = load { i64, ptr }, ptr %l291, !tbaa !27
  %t591 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %s24, ptr %t589, { i64, ptr } %t590)
  store %"compiler/mir:Range" %t591, ptr %l292
  br label %bb130
bb130:
  %t592 = load %"compiler/mir:Range", ptr %l292
  store %"compiler/mir:Range" %t592, ptr %l36
  call void @__olang_scope_close(ptr %s24)
  br label %bb131
bb131:
  %t593 = call %"compiler/mir:Range" @compiler_2fmir_3aRange_2ector(ptr %s14, i32 0, i32 0)
  store %"compiler/mir:Range" %t593, ptr %l293
  br label %bb132
bb132:
  %t594 = load %"compiler/mir:Range", ptr %l293
  store %"compiler/mir:Range" %t594, ptr %l37
  %t595 = load ptr, ptr %l0, !tbaa !29
  %t596 = load ptr, ptr %l2, !tbaa !29
  %t599 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2evalueTargets(ptr %v0, ptr %v1, ptr %t595, ptr %t596)
  store i1 %t599, ptr %l296
  br label %bb133
bb133:
  %t600 = load i1, ptr %l296, !tbaa !21
  br i1 %t600, label %bb134, label %bb135
bb134:
  store %olang.scope zeroinitializer, ptr %s25
  %t601 = load ptr, ptr %l2, !tbaa !29
  %t603 = getelementptr %"compiler/typed:Spawn", ptr %t601, i32 0, i32 0
  %t604 = load { i64, ptr }, ptr %t603, !tbaa !27
  %t606 = extractvalue { i64, ptr } %t604, 0
  store i64 %t606, ptr %l299, !tbaa !24
  %t607 = load i64, ptr %l299, !tbaa !24
  %t608 = icmp sge i64 %t607, 0
  br i1 %t608, label %bb136, label %bb137
bb135:
  br label %bb167
bb136:
  %t610 = load i64, ptr %l299, !tbaa !24
  %t611 = icmp sle i64 %t610, 576460752303423487
  br i1 %t611, label %bb138, label %bb139
bb137:
  call void @__olang_check_failed(ptr @olang_loc_be92bcaa720f0648_1d4634382d4dfc64)
  unreachable
bb138:
  %t613 = load i64, ptr %l299, !tbaa !24
  %t614 = mul i64 %t613, 16
  %t615 = call ptr @__olang_scope_alloc_zeroed(ptr %s25, i64 %t614)
  %t616 = insertvalue { i64, ptr } undef, i64 %t613, 0
  %t617 = insertvalue { i64, ptr } %t616, ptr %t615, 1
  store { i64, ptr } %t617, ptr %l38, !tbaa !27
  store i64 0, ptr %l39, !tbaa !24
  %t619 = load ptr, ptr %l2, !tbaa !29
  %t621 = getelementptr %"compiler/typed:Spawn", ptr %t619, i32 0, i32 0
  %t622 = load { i64, ptr }, ptr %t621, !tbaa !27
  %t624 = extractvalue { i64, ptr } %t622, 0
  store i64 %t624, ptr %l40, !tbaa !24
  store i64 1, ptr %l41, !tbaa !24
  %t626 = load i64, ptr %l40, !tbaa !24
  %t627 = load i64, ptr %l39, !tbaa !24
  %t630 = icmp sgt i64 %t626, %t627
  br i1 %t630, label %bb140, label %bb141
bb139:
  call void @__olang_check_failed(ptr @olang_loc_be92bcaa720f0648_1d4634382d4dfc64)
  unreachable
bb140:
  %t632 = load i64, ptr %l41, !tbaa !24
  %t634 = icmp sgt i64 %t632, 0
  br i1 %t634, label %bb142, label %bb143
bb141:
  store i64 0, ptr %l309, !tbaa !24
  br label %bb145
bb142:
  %t636 = load i64, ptr %l40, !tbaa !24
  %t637 = load i64, ptr %l39, !tbaa !24
  %t640 = sub i64 %t636, %t637
  %t641 = load i64, ptr %l41, !tbaa !24
  %t644 = add i64 %t640, %t641
  %t646 = sub i64 %t644, 1
  %t647 = load i64, ptr %l41, !tbaa !24
  %t650 = sdiv i64 %t646, %t647
  store i64 %t650, ptr %l312, !tbaa !24
  br label %bb144
bb143:
  store i64 0, ptr %l312, !tbaa !24
  br label %bb144
bb144:
  %t652 = load i64, ptr %l312, !tbaa !24
  store i64 %t652, ptr %l309, !tbaa !24
  br label %bb145
bb145:
  %t653 = load i64, ptr %l309, !tbaa !24
  store i64 %t653, ptr %l42, !tbaa !24
  store i64 0, ptr %l43, !tbaa !24
  br label %bb146
bb146:
  %t654 = load i64, ptr %l43, !tbaa !24
  %t655 = load i64, ptr %l42, !tbaa !24
  %t658 = icmp slt i64 %t654, %t655
  %t660 = xor i1 %t658, true
  br i1 %t660, label %bb147, label %bb148
bb147:
  br label %bb165
bb148:
  br label %bb149
bb149:
  %t662 = load i64, ptr %l39, !tbaa !24
  %t663 = load i64, ptr %l43, !tbaa !24
  %t664 = load i64, ptr %l41, !tbaa !24
  %t667 = mul i64 %t663, %t664
  %t670 = add i64 %t662, %t667
  store i64 %t670, ptr %l44, !tbaa !24
  %t672 = load i64, ptr %l44, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t673
  %t674 = getelementptr { i64, [1 x i64] }, ptr %t673, i32 0, i32 0
  store i64 3, ptr %t674
  %t675 = load { i64, [1 x i64] }, ptr %t673
  %t678 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t679 = load ptr, ptr %t678, !tbaa !27
  %t680 = getelementptr { i64, [1 x i64] }, ptr %t679, i64 %t672
  store { i64, [1 x i64] } %t675, ptr %t680
  %t681 = load ptr, ptr %l2, !tbaa !29
  %t683 = getelementptr %"compiler/typed:Spawn", ptr %t681, i32 0, i32 0
  %t684 = load { i64, ptr }, ptr %t683, !tbaa !27
  store { i64, ptr } %t684, ptr %l333, !tbaa !27
  %t685 = load i64, ptr %l44, !tbaa !24
  %t687 = getelementptr { i64, ptr }, ptr %l333, i32 0, i32 1
  %t688 = load ptr, ptr %t687, !tbaa !27
  %t689 = getelementptr ptr, ptr %t688, i64 %t685
  %t690 = load ptr, ptr %t689, !tbaa !39
  store ptr %t690, ptr %l45, !tbaa !29
  %t692 = load ptr, ptr %l45, !tbaa !29
  %t694 = icmp eq ptr %t692, null
  %t696 = xor i1 %t694, true
  br i1 %t696, label %bb150, label %bb151
bb150:
  %t698 = load ptr, ptr %l0, !tbaa !29
  store ptr %t698, ptr %l340, !tbaa !29
  %t699 = load ptr, ptr %l45, !tbaa !29
  %t701 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t699)
  store i32 %t701, ptr %l342
  br label %bb152
bb151:
  store i1 false, ptr %l339, !tbaa !21
  br label %bb154
bb152:
  %t702 = load ptr, ptr %l340, !tbaa !29
  %t703 = load i32, ptr %l342, !tbaa !23
  %t704 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2evalueArray(ptr %v0, ptr %t702, i32 %t703)
  store i1 %t704, ptr %l343
  br label %bb153
bb153:
  %t705 = load i1, ptr %l343, !tbaa !21
  store i1 %t705, ptr %l339, !tbaa !21
  br label %bb154
bb154:
  %t706 = load i1, ptr %l339, !tbaa !21
  br i1 %t706, label %bb155, label %bb156
bb155:
  %t707 = load ptr, ptr %l0, !tbaa !29
  store ptr %t707, ptr %l345, !tbaa !29
  %t708 = load ptr, ptr %l5, !tbaa !29
  store ptr %t708, ptr %l346, !tbaa !29
  %t709 = load ptr, ptr %l45, !tbaa !29
  %t711 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t709)
  store i32 %t711, ptr %l348
  br label %bb157
bb156:
  store i1 false, ptr %l344, !tbaa !21
  br label %bb159
bb157:
  %t712 = load ptr, ptr %l345, !tbaa !29
  %t713 = load ptr, ptr %l346, !tbaa !29
  %t714 = load i32, ptr %l348, !tbaa !23
  %t715 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopiesArray(ptr %v0, ptr %v1, ptr %t712, ptr %t713, i32 %t714)
  store i1 %t715, ptr %l349
  br label %bb158
bb158:
  %t716 = load i1, ptr %l349, !tbaa !21
  store i1 %t716, ptr %l344, !tbaa !21
  br label %bb159
bb159:
  %t717 = load i1, ptr %l344, !tbaa !21
  br i1 %t717, label %bb160, label %bb161
bb160:
  %t718 = load i64, ptr %l44, !tbaa !24
  store i64 %t718, ptr %l350, !tbaa !24
  %t719 = load ptr, ptr %l0, !tbaa !29
  %t720 = load ptr, ptr %l45, !tbaa !29
  %t723 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eplaceStorage(ptr %v0, ptr %v1, ptr %t719, ptr %t720)
  store { i64, [1 x i64] } %t723, ptr %l353
  br label %bb162
bb161:
  br label %bb163
bb162:
  %t724 = load { i64, [1 x i64] }, ptr %l353
  %t725 = load i64, ptr %l350, !tbaa !24
  %t726 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t727 = load ptr, ptr %t726, !tbaa !27
  %t728 = getelementptr { i64, [1 x i64] }, ptr %t727, i64 %t725
  store { i64, [1 x i64] } %t724, ptr %t728
  br label %bb163
bb163:
  br label %bb164
bb164:
  %t729 = load i64, ptr %l43, !tbaa !24
  %t731 = add i64 %t729, 1
  store i64 %t731, ptr %l43, !tbaa !24
  br label %bb146
bb165:
  %t733 = load ptr, ptr %l0, !tbaa !29
  %t735 = getelementptr %"compiler/lower:lowering", ptr %t733, i32 0, i32 3
  %t736 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t739 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eScopeRefs(ptr %v0, ptr %s25, ptr %t735, { i64, ptr } %t736)
  store %"compiler/mir:Range" %t739, ptr %l359
  br label %bb166
bb166:
  %t740 = load %"compiler/mir:Range", ptr %l359
  store %"compiler/mir:Range" %t740, ptr %l37
  call void @__olang_scope_close(ptr %s25)
  br label %bb167
bb167:
  %t741 = load ptr, ptr %l0, !tbaa !29
  %t743 = getelementptr %"compiler/lower:lowering", ptr %t741, i32 0, i32 3
  store ptr %t743, ptr %l361, !tbaa !29
  %t744 = load { i64, [7 x i64] }, ptr %l22
  store { i64, [7 x i64] } %t744, ptr %l362
  %t745 = load %"compiler/mir:Range", ptr %l24
  store %"compiler/mir:Range" %t745, ptr %l363
  %t746 = load ptr, ptr %l0, !tbaa !29
  store ptr %t746, ptr %l364, !tbaa !29
  %t747 = load ptr, ptr %l0, !tbaa !29
  %t749 = getelementptr %"compiler/lower:lowering", ptr %t747, i32 0, i32 2
  %t750 = load ptr, ptr %t749, !tbaa !29
  %t751 = load { i64, [7 x i64] }, ptr %l22
  %t752 = load i32, ptr %l23, !tbaa !23
  %t756 = call i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %t750, { i64, [7 x i64] } %t751, i32 %t752)
  store i64 %t756, ptr %l369
  br label %bb168
bb168:
  %t757 = load ptr, ptr %l20, !tbaa !29
  %t759 = getelementptr %"compiler/typed:Call", ptr %t757, i32 0, i32 3
  %t760 = load i32, ptr %t759, !tbaa !23
  %t761 = load ptr, ptr %l364, !tbaa !29
  %t762 = load i64, ptr %l369, !tbaa !24
  %t764 = call %"compiler/mir:Range" @compiler_2flower_2ecompiler_2flower_3alowering_2epassed(ptr %v0, ptr %t761, i64 %t762, i32 %t760)
  store %"compiler/mir:Range" %t764, ptr %l372
  br label %bb169
bb169:
  %t765 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t765, ptr %l373, !tbaa !27
  %t766 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t766, ptr %l374, !tbaa !27
  %t767 = load %"compiler/mir:Range", ptr %l36
  store %"compiler/mir:Range" %t767, ptr %l375
  %t768 = load ptr, ptr %l2, !tbaa !29
  %t770 = getelementptr %"compiler/typed:Spawn", ptr %t768, i32 0, i32 1
  %t771 = load ptr, ptr %t770, !tbaa !29
  %t773 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t771)
  store %"compiler/source:Span" %t773, ptr %l378
  br label %bb170
bb170:
  %t774 = load %"compiler/mir:Range", ptr %l37
  %t775 = load ptr, ptr %l361, !tbaa !29
  %t776 = load { i64, [7 x i64] }, ptr %l362
  %t777 = load %"compiler/mir:Range", ptr %l363
  %t778 = load %"compiler/mir:Range", ptr %l372
  %t779 = load { i64, ptr }, ptr %l373, !tbaa !27
  %t780 = load { i64, ptr }, ptr %l374, !tbaa !27
  %t781 = load %"compiler/mir:Range", ptr %l375
  %t782 = load %"compiler/source:Span", ptr %l378
  %t784 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTask(ptr %v0, ptr %s0, ptr %s14, ptr %t775, { i64, [7 x i64] } %t776, %"compiler/mir:Range" %t777, %"compiler/mir:Range" %t778, { i64, ptr } %t779, { i64, ptr } %t780, %"compiler/mir:Range" %t781, %"compiler/source:Span" %t782, %"compiler/mir:Range" %t774)
  store i32 %t784, ptr %l380
  br label %bb171
bb171:
  %t785 = load i32, ptr %l380, !tbaa !23
  %t786 = load ptr, ptr %l0, !tbaa !29
  %t787 = load %"compiler/source:Span", ptr %l1
  %t788 = load i32, ptr %l3, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t790
  %t791 = getelementptr { i64, [21 x i64] }, ptr %t790, i32 0, i32 0
  store i64 11, ptr %t791
  %t793 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t787, 0
  %t795 = insertvalue { %"compiler/source:Span", i32, i32 } %t793, i32 %t788, 1
  %t797 = insertvalue { %"compiler/source:Span", i32, i32 } %t795, i32 %t785, 2
  %t798 = getelementptr { i64, [21 x i64] }, ptr %t790, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t797, ptr %t798
  %t799 = load { i64, [21 x i64] }, ptr %t790
  %t801 = call ptr @__olang_scope_alloc_a(ptr %s14, i64 176, i64 8)
  store { i64, [21 x i64] } %t799, ptr %t801
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s14, ptr %t786, ptr %t801)
  br label %bb172
bb172:
  call void @__olang_scope_close(ptr %s14)
  br label %bb178
bb173:
  br i1 true, label %bb174, label %bb175
bb174:
  br label %bb176
bb175:
  br label %bb177
bb176:
  br label %bb178
bb177:
  call void @__olang_check_failed(ptr @olang_loc_e3f6d6028e0207dc_be5b0d4cacd6b290)
  unreachable
bb178:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2espell(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i1 %a2, i1 %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i1
  %l3 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca %"std/prelude/text:StringBuilder"
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca %"std/prelude/text:StringBuilder"
  %l26 = alloca i32
  %l27 = alloca { i64, ptr }
  %l28 = alloca i1
  %l29 = alloca i1
  %l30 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l56 = alloca i32
  %l61 = alloca ptr
  %l62 = alloca ptr
  %l65 = alloca i32
  %l66 = alloca i32
  %l67 = alloca { i64, ptr }
  %l68 = alloca ptr
  %l71 = alloca i32
  %l72 = alloca { i64, ptr }
  %l78 = alloca %"std/prelude/text:StringBuilder"
  %l87 = alloca i64
  %l90 = alloca i64
  %l111 = alloca ptr
  %l113 = alloca { i64, ptr }
  %l116 = alloca { i64, ptr }
  %l122 = alloca { i64, ptr }
  %l123 = alloca { i64, ptr }
  %l124 = alloca i64
  %l125 = alloca { i64, ptr }
  %l130 = alloca i64
  %l134 = alloca { i64, ptr }
  %l135 = alloca { i64, ptr }
  %l136 = alloca ptr
  %l139 = alloca i32
  %l141 = alloca { i64, ptr }
  %l144 = alloca i64
  %l148 = alloca { i64, ptr }
  %l152 = alloca ptr
  %l155 = alloca i32
  %l157 = alloca { i64, ptr }
  %l161 = alloca ptr
  %l164 = alloca i32
  %l165 = alloca { i64, ptr }
  %l171 = alloca i64
  %l178 = alloca { i64, ptr }
  %l181 = alloca %"std/prelude/text:StringBuilder"
  %l182 = alloca ptr
  %l185 = alloca i32
  %l186 = alloca { i64, ptr }
  %l193 = alloca i64
  %l196 = alloca i64
  %l217 = alloca ptr
  %l219 = alloca { i64, ptr }
  %l222 = alloca { i64, ptr }
  %l228 = alloca { i64, ptr }
  %l229 = alloca { i64, ptr }
  %l230 = alloca i64
  %l231 = alloca { i64, ptr }
  %l234 = alloca %"std/prelude/text:StringBuilder"
  %l237 = alloca i32
  %l238 = alloca ptr
  %l241 = alloca i32
  %l242 = alloca { i64, ptr }
  %l245 = alloca i32
  %l248 = alloca i1
  %l249 = alloca ptr
  %l252 = alloca i32
  %l253 = alloca { i64, ptr }
  %l256 = alloca i1
  %l261 = alloca i1
  %l263 = alloca i1
  %l265 = alloca i1
  %l272 = alloca ptr
  %l275 = alloca i32
  %l276 = alloca { i64, ptr }
  %l279 = alloca { i64, ptr }
  %l285 = alloca i64
  %l288 = alloca i64
  %l314 = alloca ptr
  %l317 = alloca { i64, ptr }
  %l322 = alloca { i64, ptr }
  %l325 = alloca ptr
  %l327 = alloca { i64, ptr }
  %l330 = alloca { i64, ptr }
  %l337 = alloca i32
  %l340 = alloca ptr
  %l343 = alloca i32
  %l344 = alloca { i64, ptr }
  %l350 = alloca i64
  %l353 = alloca i64
  %l371 = alloca ptr
  %l374 = alloca { i64, ptr }
  %l376 = alloca { i64, ptr }
  %l379 = alloca { i64, ptr }
  %l390 = alloca i1
  %l393 = alloca i32
  %l396 = alloca i1
  %l397 = alloca ptr
  %l400 = alloca i32
  %l401 = alloca { i64, ptr }
  %l404 = alloca ptr
  %l408 = alloca { i64, ptr }
  %l420 = alloca i64
  %l423 = alloca i64
  %l441 = alloca ptr
  %l444 = alloca { i64, ptr }
  %l445 = alloca ptr
  %l447 = alloca { i64, ptr }
  %l450 = alloca i32
  %l451 = alloca { i64, ptr }
  %l459 = alloca { i64, ptr }
  %l460 = alloca { i64, ptr }
  %l461 = alloca i64
  %l462 = alloca { i64, ptr }
  %l465 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s41 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i1 %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l5, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l56
  br label %bb1
bb1:
  %t11 = load i32, ptr %l56
  store i32 %t11, ptr %l6
  %t12 = load i32, ptr %l6
  %t14 = trunc i64 18 to i32
  %t15 = icmp eq i32 %t12, %t14
  br i1 %t15, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/lower:lowering", ptr %t17, i32 0, i32 2
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = getelementptr %"compiler/types:Table", ptr %t20, i32 0, i32 0
  %t23 = load ptr, ptr %t22, !tbaa !29
  store ptr %t23, ptr %l61, !tbaa !29
  %t24 = load ptr, ptr %l5, !tbaa !29
  store ptr %t24, ptr %l62, !tbaa !29
  %t25 = load ptr, ptr %l5, !tbaa !29
  %t26 = load i32, ptr %l1, !tbaa !23
  %t29 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t25, i32 %t26)
  store i32 %t29, ptr %l65
  br label %bb4
bb3:
  br label %bb35
bb4:
  %t30 = load ptr, ptr %l62, !tbaa !29
  %t31 = load i32, ptr %l65, !tbaa !23
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t30, i32 %t31)
  store i32 %t32, ptr %l66
  br label %bb5
bb5:
  %t33 = load ptr, ptr %l61, !tbaa !29
  %t34 = load i32, ptr %l66, !tbaa !23
  %t35 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t33, i32 %t34)
  store { i64, ptr } %t35, ptr %l67
  br label %bb6
bb6:
  %t36 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t36, ptr %l7, !tbaa !27
  %t37 = load ptr, ptr %l5, !tbaa !29
  store ptr %t37, ptr %l68, !tbaa !29
  %t38 = load ptr, ptr %l5, !tbaa !29
  %t39 = load i32, ptr %l1, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l71
  br label %bb7
bb7:
  %t43 = load ptr, ptr %l68, !tbaa !29
  %t44 = load i32, ptr %l71, !tbaa !23
  %t45 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t43, i32 %t44)
  store { i64, ptr } %t45, ptr %l72
  br label %bb8
bb8:
  %t46 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t46, ptr %l8, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 0
  %t51 = icmp eq i64 %t49, 0
  br i1 %t51, label %bb9, label %bb10
bb9:
  %t53 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 1
  %t56 = extractvalue { i64, ptr } %t53, 0
  %t57 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t56)
  call void @olang_textcopy(ptr %t57, ptr %t55, i64 %t56)
  %t58 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t57, 1
  call void @__olang_scope_close(ptr %s1)
  store { i64, ptr } %t59, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t61 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s1)
  store %"std/prelude/text:StringBuilder" %t61, ptr %l78
  br label %bb12
bb12:
  %t62 = load %"std/prelude/text:StringBuilder", ptr %l78
  store %"std/prelude/text:StringBuilder" %t62, ptr %l9
  %t63 = load { i64, ptr }, ptr %l7, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s1, ptr %v0, ptr %l9, { i64, ptr } %t63)
  br label %bb13
bb13:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s1, ptr %l9, i8 60)
  br label %bb14
bb14:
  store i64 0, ptr %l10, !tbaa !24
  %t67 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t67, 0
  store i64 %t69, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t71 = load i64, ptr %l11, !tbaa !24
  %t72 = load i64, ptr %l10, !tbaa !24
  %t75 = icmp sgt i64 %t71, %t72
  br i1 %t75, label %bb15, label %bb16
bb15:
  %t77 = load i64, ptr %l12, !tbaa !24
  %t79 = icmp sgt i64 %t77, 0
  br i1 %t79, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l87, !tbaa !24
  br label %bb20
bb17:
  %t81 = load i64, ptr %l11, !tbaa !24
  %t82 = load i64, ptr %l10, !tbaa !24
  %t85 = sub i64 %t81, %t82
  %t86 = load i64, ptr %l12, !tbaa !24
  %t89 = add i64 %t85, %t86
  %t91 = sub i64 %t89, 1
  %t92 = load i64, ptr %l12, !tbaa !24
  %t95 = sdiv i64 %t91, %t92
  store i64 %t95, ptr %l90, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l90, !tbaa !24
  br label %bb19
bb19:
  %t97 = load i64, ptr %l90, !tbaa !24
  store i64 %t97, ptr %l87, !tbaa !24
  br label %bb20
bb20:
  %t98 = load i64, ptr %l87, !tbaa !24
  store i64 %t98, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s5
  %t99 = load i64, ptr %l14, !tbaa !24
  %t100 = load i64, ptr %l13, !tbaa !24
  %t103 = icmp slt i64 %t99, %t100
  %t105 = xor i1 %t103, true
  br i1 %t105, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s5)
  br label %bb32
bb23:
  br label %bb24
bb24:
  %t107 = load i64, ptr %l10, !tbaa !24
  %t108 = load i64, ptr %l14, !tbaa !24
  %t109 = load i64, ptr %l12, !tbaa !24
  %t112 = mul i64 %t108, %t109
  %t115 = add i64 %t107, %t112
  store i64 %t115, ptr %l15, !tbaa !24
  %t117 = load i64, ptr %l15, !tbaa !24
  %t119 = icmp sgt i64 %t117, 0
  br i1 %t119, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s6
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s1, ptr %s6, ptr %l9, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d18, i32 0, i32 1) })
  br label %bb27
bb26:
  br label %bb28
bb27:
  call void @__olang_scope_close(ptr %s6)
  br label %bb28
bb28:
  store ptr %l9, ptr %l111, !tbaa !29
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t123, ptr %l113, !tbaa !27
  %t124 = load i64, ptr %l15, !tbaa !24
  %t126 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr i32, ptr %t127, i64 %t124
  %t129 = load i32, ptr %t128, !tbaa !33
  %t132 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2espell(ptr %v0, ptr %s5, ptr %t122, i32 %t129, i1 true, i1 true, i1 false)
  store { i64, ptr } %t132, ptr %l116
  br label %bb29
bb29:
  %t133 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t133, 0
  %t135 = extractvalue { i64, ptr } %t133, 1
  %t136 = mul i64 %t134, 1
  %t137 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t136)
  call void @llvm.memcpy.p0.p0.i64(ptr %t137, ptr %t135, i64 %t136, i1 false)
  %t138 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t137, 1
  %t140 = load ptr, ptr %l111, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s1, ptr %s5, ptr %t140, { i64, ptr } %t139)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb31
bb31:
  %t142 = load i64, ptr %l14, !tbaa !24
  %t144 = add i64 %t142, 1
  store i64 %t144, ptr %l14, !tbaa !24
  br label %bb21
bb32:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s1, ptr %l9, i8 62)
  br label %bb33
bb33:
  %t148 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s1, ptr %v1, ptr %l9)
  store { i64, ptr } %t148, ptr %l122
  br label %bb34
bb34:
  %t149 = load { i64, ptr }, ptr %l122, !tbaa !27
  store { i64, ptr } %t149, ptr %l123, !tbaa !27
  %t150 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t151 = extractvalue { i64, ptr } %t150, 0
  store i64 %t151, ptr %l124, !tbaa !24
  %t152 = load i64, ptr %l124, !tbaa !24
  %t153 = mul i64 %t152, 1
  %t154 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t153)
  %t155 = insertvalue { i64, ptr } undef, i64 %t152, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t154, 1
  store { i64, ptr } %t156, ptr %l125, !tbaa !27
  %t157 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = load i64, ptr %l124, !tbaa !24
  %t162 = mul i64 %t161, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t158, ptr %t160, i64 %t162, i1 false)
  %t163 = load { i64, ptr }, ptr %l125, !tbaa !27
  store { i64, ptr } %t163, ptr %l123, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  %t164 = load { i64, ptr }, ptr %l123, !tbaa !27
  store { i64, ptr } %t164, ptr %rv
  br label %ret
bb35:
  %t165 = load i32, ptr %l6
  %t167 = trunc i64 20 to i32
  %t168 = icmp eq i32 %t165, %t167
  br i1 %t168, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s8
  %t170 = load ptr, ptr %l5, !tbaa !29
  %t171 = load i32, ptr %l1, !tbaa !23
  %t174 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t170, i32 %t171)
  store i64 %t174, ptr %l130
  br label %bb38
bb37:
  br label %bb48
bb38:
  %t175 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t176 = load i64, ptr %l130, !tbaa !24
  %t178 = and i64 %t176, %t175
  %t180 = icmp ne i64 %t178, 0
  br i1 %t180, label %bb39, label %bb40
bb39:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %l134, !tbaa !27
  br label %bb41
bb40:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d20, i32 0, i32 1) }, ptr %l134, !tbaa !27
  br label %bb41
bb41:
  %t182 = load { i64, ptr }, ptr %l134, !tbaa !27
  store { i64, ptr } %t182, ptr %l135, !tbaa !27
  %t184 = load ptr, ptr %l0, !tbaa !29
  store ptr %t184, ptr %l136, !tbaa !29
  %t185 = load ptr, ptr %l5, !tbaa !29
  %t186 = load i32, ptr %l1, !tbaa !23
  %t189 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t185, i32 %t186)
  store i32 %t189, ptr %l139
  br label %bb42
bb42:
  %t190 = load i1, ptr %l3, !tbaa !21
  %t191 = load ptr, ptr %l136, !tbaa !29
  %t192 = load i32, ptr %l139, !tbaa !23
  %t194 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2espell(ptr %v0, ptr %s8, ptr %t191, i32 %t192, i1 true, i1 %t190, i1 false)
  store { i64, ptr } %t194, ptr %l141
  br label %bb43
bb43:
  %t195 = load ptr, ptr %l5, !tbaa !29
  %t196 = load i32, ptr %l1, !tbaa !23
  %t199 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t195, i32 %t196)
  store i64 %t199, ptr %l144
  br label %bb44
bb44:
  %t200 = load i64, ptr @G_2ecompiler_2ftypes_2eNullable, !tbaa !24
  %t201 = load i64, ptr %l144, !tbaa !24
  %t203 = and i64 %t201, %t200
  %t205 = icmp ne i64 %t203, 0
  br i1 %t205, label %bb45, label %bb46
bb45:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d21, i32 0, i32 1) }, ptr %l148, !tbaa !27
  br label %bb47
bb46:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) }, ptr %l148, !tbaa !27
  br label %bb47
bb47:
  %t207 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t208 = extractvalue { i64, ptr } %t207, 1
  %t209 = extractvalue { i64, ptr } %t207, 0
  %t210 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t210, 1
  %t212 = extractvalue { i64, ptr } %t210, 0
  %t213 = add i64 %t209, %t212
  %t214 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t215 = extractvalue { i64, ptr } %t214, 1
  %t216 = extractvalue { i64, ptr } %t214, 0
  %t217 = add i64 %t213, %t216
  %t218 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t217)
  call void @olang_textcopy(ptr %t218, ptr %t208, i64 %t209)
  %t219 = getelementptr i8, ptr %t218, i64 %t209
  call void @olang_textcopy(ptr %t219, ptr %t211, i64 %t212)
  %t220 = getelementptr i8, ptr %t219, i64 %t212
  call void @olang_textcopy(ptr %t220, ptr %t215, i64 %t216)
  %t221 = insertvalue { i64, ptr } undef, i64 %t217, 0
  %t222 = insertvalue { i64, ptr } %t221, ptr %t218, 1
  call void @__olang_scope_close(ptr %s8)
  store { i64, ptr } %t222, ptr %rv
  br label %ret
bb48:
  %t224 = load i32, ptr %l6
  %t226 = trunc i64 29 to i32
  %t227 = icmp eq i32 %t224, %t226
  br i1 %t227, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s10
  %t229 = load ptr, ptr %l0, !tbaa !29
  store ptr %t229, ptr %l152, !tbaa !29
  %t230 = load ptr, ptr %l5, !tbaa !29
  %t231 = load i32, ptr %l1, !tbaa !23
  %t234 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t230, i32 %t231)
  store i32 %t234, ptr %l155
  br label %bb51
bb50:
  br label %bb53
bb51:
  %t235 = load i1, ptr %l3, !tbaa !21
  %t236 = load ptr, ptr %l152, !tbaa !29
  %t237 = load i32, ptr %l155, !tbaa !23
  %t239 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2espell(ptr %v0, ptr %s10, ptr %t236, i32 %t237, i1 true, i1 %t235, i1 false)
  store { i64, ptr } %t239, ptr %l157
  br label %bb52
bb52:
  %t240 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t241 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t242 = load { i64, ptr }, ptr %l157, !tbaa !27
  %t243 = extractvalue { i64, ptr } %t242, 1
  %t244 = extractvalue { i64, ptr } %t242, 0
  %t245 = add i64 %t241, %t244
  %t246 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t245)
  call void @olang_textcopy(ptr %t246, ptr %t240, i64 %t241)
  %t247 = getelementptr i8, ptr %t246, i64 %t241
  call void @olang_textcopy(ptr %t247, ptr %t243, i64 %t244)
  %t248 = insertvalue { i64, ptr } undef, i64 %t245, 0
  %t249 = insertvalue { i64, ptr } %t248, ptr %t246, 1
  call void @__olang_scope_close(ptr %s10)
  store { i64, ptr } %t249, ptr %rv
  br label %ret
bb53:
  %t251 = load i32, ptr %l6
  %t253 = trunc i64 19 to i32
  %t254 = icmp eq i32 %t251, %t253
  br i1 %t254, label %bb54, label %bb55
bb54:
  store %olang.scope zeroinitializer, ptr %s12
  %t256 = load ptr, ptr %l0, !tbaa !29
  store ptr %t256, ptr %l161, !tbaa !29
  %t257 = load ptr, ptr %l5, !tbaa !29
  %t258 = load i32, ptr %l1, !tbaa !23
  %t261 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t257, i32 %t258)
  store i32 %t261, ptr %l164
  br label %bb56
bb55:
  br label %bb58
bb56:
  %t262 = load ptr, ptr %l161, !tbaa !29
  %t263 = load i32, ptr %l164, !tbaa !23
  %t264 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2espell(ptr %v0, ptr %s12, ptr %t262, i32 %t263, i1 true, i1 true, i1 false)
  store { i64, ptr } %t264, ptr %l165
  br label %bb57
bb57:
  %t265 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t266 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t267 = load { i64, ptr }, ptr %l165, !tbaa !27
  %t268 = extractvalue { i64, ptr } %t267, 1
  %t269 = extractvalue { i64, ptr } %t267, 0
  %t270 = add i64 %t266, %t269
  %t271 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t272 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t273 = add i64 %t270, %t272
  %t274 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t273)
  call void @olang_textcopy(ptr %t274, ptr %t265, i64 %t266)
  %t275 = getelementptr i8, ptr %t274, i64 %t266
  call void @olang_textcopy(ptr %t275, ptr %t268, i64 %t269)
  %t276 = getelementptr i8, ptr %t275, i64 %t269
  call void @olang_textcopy(ptr %t276, ptr %t271, i64 %t272)
  %t277 = insertvalue { i64, ptr } undef, i64 %t273, 0
  %t278 = insertvalue { i64, ptr } %t277, ptr %t274, 1
  call void @__olang_scope_close(ptr %s12)
  store { i64, ptr } %t278, ptr %rv
  br label %ret
bb58:
  %t280 = load i32, ptr %l6
  %t282 = trunc i64 26 to i32
  %t283 = icmp eq i32 %t280, %t282
  br i1 %t283, label %bb59, label %bb60
bb59:
  %t285 = load ptr, ptr %l5, !tbaa !29
  %t286 = load i32, ptr %l1, !tbaa !23
  %t289 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t285, i32 %t286)
  store i64 %t289, ptr %l171
  br label %bb61
bb60:
  br label %bb62
bb61:
  %t290 = load i64, ptr %l171, !tbaa !24
  %t291 = call i64 @__olang_fmt_i64(ptr null, i64 %t290)
  %t292 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t291)
  %t293 = call i64 @__olang_fmt_i64(ptr %t292, i64 %t290)
  %t294 = insertvalue { i64, ptr } undef, i64 %t291, 0
  %t295 = insertvalue { i64, ptr } %t294, ptr %t292, 1
  store { i64, ptr } %t295, ptr %rv
  br label %ret
bb62:
  %t297 = load i32, ptr %l6
  %t299 = trunc i64 32 to i32
  %t300 = icmp eq i32 %t297, %t299
  br i1 %t300, label %bb63, label %bb64
bb63:
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t304 = getelementptr %"compiler/lower:lowering", ptr %t302, i32 0, i32 0
  %t305 = load ptr, ptr %t304, !tbaa !29
  %t306 = load i32, ptr %l1, !tbaa !23
  %t309 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3aLowerer_2eErrValSpelling(ptr %v0, ptr %v1, ptr %t305, i32 %t306)
  store { i64, ptr } %t309, ptr %l178
  br label %bb65
bb64:
  br label %bb66
bb65:
  %t310 = load { i64, ptr }, ptr %l178, !tbaa !27
  store { i64, ptr } %t310, ptr %rv
  br label %ret
bb66:
  %t311 = load i32, ptr %l6
  %t313 = trunc i64 22 to i32
  %t314 = icmp eq i32 %t311, %t313
  br i1 %t314, label %bb67, label %bb68
bb67:
  store %olang.scope zeroinitializer, ptr %s17
  %t316 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s17)
  store %"std/prelude/text:StringBuilder" %t316, ptr %l181
  br label %bb69
bb68:
  br label %bb93
bb69:
  %t317 = load %"std/prelude/text:StringBuilder", ptr %l181
  store %"std/prelude/text:StringBuilder" %t317, ptr %l17
  %t318 = load ptr, ptr %l5, !tbaa !29
  store ptr %t318, ptr %l182, !tbaa !29
  %t319 = load ptr, ptr %l5, !tbaa !29
  %t320 = load i32, ptr %l1, !tbaa !23
  %t323 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t319, i32 %t320)
  store i32 %t323, ptr %l185
  br label %bb70
bb70:
  %t324 = load ptr, ptr %l182, !tbaa !29
  %t325 = load i32, ptr %l185, !tbaa !23
  %t326 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t324, i32 %t325)
  store { i64, ptr } %t326, ptr %l186
  br label %bb71
bb71:
  %t327 = load { i64, ptr }, ptr %l186, !tbaa !27
  store { i64, ptr } %t327, ptr %l18, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s17, ptr %l17, i8 40)
  br label %bb72
bb72:
  store i64 0, ptr %l19, !tbaa !24
  %t329 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t331 = extractvalue { i64, ptr } %t329, 0
  store i64 %t331, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t333 = load i64, ptr %l20, !tbaa !24
  %t334 = load i64, ptr %l19, !tbaa !24
  %t337 = icmp sgt i64 %t333, %t334
  br i1 %t337, label %bb73, label %bb74
bb73:
  %t339 = load i64, ptr %l21, !tbaa !24
  %t341 = icmp sgt i64 %t339, 0
  br i1 %t341, label %bb75, label %bb76
bb74:
  store i64 0, ptr %l193, !tbaa !24
  br label %bb78
bb75:
  %t343 = load i64, ptr %l20, !tbaa !24
  %t344 = load i64, ptr %l19, !tbaa !24
  %t347 = sub i64 %t343, %t344
  %t348 = load i64, ptr %l21, !tbaa !24
  %t351 = add i64 %t347, %t348
  %t353 = sub i64 %t351, 1
  %t354 = load i64, ptr %l21, !tbaa !24
  %t357 = sdiv i64 %t353, %t354
  store i64 %t357, ptr %l196, !tbaa !24
  br label %bb77
bb76:
  store i64 0, ptr %l196, !tbaa !24
  br label %bb77
bb77:
  %t359 = load i64, ptr %l196, !tbaa !24
  store i64 %t359, ptr %l193, !tbaa !24
  br label %bb78
bb78:
  %t360 = load i64, ptr %l193, !tbaa !24
  store i64 %t360, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb79
bb79:
  store %olang.scope zeroinitializer, ptr %s19
  %t361 = load i64, ptr %l23, !tbaa !24
  %t362 = load i64, ptr %l22, !tbaa !24
  %t365 = icmp slt i64 %t361, %t362
  %t367 = xor i1 %t365, true
  br i1 %t367, label %bb80, label %bb81
bb80:
  call void @__olang_scope_close(ptr %s19)
  br label %bb90
bb81:
  br label %bb82
bb82:
  %t369 = load i64, ptr %l19, !tbaa !24
  %t370 = load i64, ptr %l23, !tbaa !24
  %t371 = load i64, ptr %l21, !tbaa !24
  %t374 = mul i64 %t370, %t371
  %t377 = add i64 %t369, %t374
  store i64 %t377, ptr %l24, !tbaa !24
  %t379 = load i64, ptr %l24, !tbaa !24
  %t381 = icmp sgt i64 %t379, 0
  br i1 %t381, label %bb83, label %bb84
bb83:
  store %olang.scope zeroinitializer, ptr %s20
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s17, ptr %s20, ptr %l17, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d26, i32 0, i32 1) })
  br label %bb85
bb84:
  br label %bb86
bb85:
  call void @__olang_scope_close(ptr %s20)
  br label %bb86
bb86:
  store ptr %l17, ptr %l217, !tbaa !29
  %t384 = load ptr, ptr %l0, !tbaa !29
  %t385 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t385, ptr %l219, !tbaa !27
  %t386 = load i64, ptr %l24, !tbaa !24
  %t388 = getelementptr { i64, ptr }, ptr %l219, i32 0, i32 1
  %t389 = load ptr, ptr %t388, !tbaa !27
  %t390 = getelementptr i32, ptr %t389, i64 %t386
  %t391 = load i32, ptr %t390, !tbaa !33
  %t394 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2espell(ptr %v0, ptr %s19, ptr %t384, i32 %t391, i1 true, i1 true, i1 false)
  store { i64, ptr } %t394, ptr %l222
  br label %bb87
bb87:
  %t395 = load { i64, ptr }, ptr %l222, !tbaa !27
  %t396 = extractvalue { i64, ptr } %t395, 0
  %t397 = extractvalue { i64, ptr } %t395, 1
  %t398 = mul i64 %t396, 1
  %t399 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t398)
  call void @llvm.memcpy.p0.p0.i64(ptr %t399, ptr %t397, i64 %t398, i1 false)
  %t400 = insertvalue { i64, ptr } undef, i64 %t396, 0
  %t401 = insertvalue { i64, ptr } %t400, ptr %t399, 1
  %t402 = load ptr, ptr %l217, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s17, ptr %s19, ptr %t402, { i64, ptr } %t401)
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s19)
  br label %bb89
bb89:
  %t404 = load i64, ptr %l23, !tbaa !24
  %t406 = add i64 %t404, 1
  store i64 %t406, ptr %l23, !tbaa !24
  br label %bb79
bb90:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s17, ptr %l17, i8 41)
  br label %bb91
bb91:
  %t410 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s17, ptr %v1, ptr %l17)
  store { i64, ptr } %t410, ptr %l228
  br label %bb92
bb92:
  %t411 = load { i64, ptr }, ptr %l228, !tbaa !27
  store { i64, ptr } %t411, ptr %l229, !tbaa !27
  %t412 = load { i64, ptr }, ptr %l229, !tbaa !27
  %t413 = extractvalue { i64, ptr } %t412, 0
  store i64 %t413, ptr %l230, !tbaa !24
  %t414 = load i64, ptr %l230, !tbaa !24
  %t415 = mul i64 %t414, 1
  %t416 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t415)
  %t417 = insertvalue { i64, ptr } undef, i64 %t414, 0
  %t418 = insertvalue { i64, ptr } %t417, ptr %t416, 1
  store { i64, ptr } %t418, ptr %l231, !tbaa !27
  %t419 = getelementptr { i64, ptr }, ptr %l231, i32 0, i32 1
  %t420 = load ptr, ptr %t419, !tbaa !27
  %t421 = getelementptr { i64, ptr }, ptr %l229, i32 0, i32 1
  %t422 = load ptr, ptr %t421, !tbaa !27
  %t423 = load i64, ptr %l230, !tbaa !24
  %t424 = mul i64 %t423, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t420, ptr %t422, i64 %t424, i1 false)
  %t425 = load { i64, ptr }, ptr %l231, !tbaa !27
  store { i64, ptr } %t425, ptr %l229, !tbaa !27
  call void @__olang_scope_close(ptr %s17)
  %t426 = load { i64, ptr }, ptr %l229, !tbaa !27
  store { i64, ptr } %t426, ptr %rv
  br label %ret
bb93:
  %t427 = load i32, ptr %l6
  %t429 = trunc i64 21 to i32
  %t430 = icmp eq i32 %t427, %t429
  br i1 %t430, label %bb94, label %bb95
bb94:
  store %olang.scope zeroinitializer, ptr %s22
  %t432 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s22)
  store %"std/prelude/text:StringBuilder" %t432, ptr %l234
  br label %bb96
bb95:
  br label %bb218
bb96:
  %t433 = load %"std/prelude/text:StringBuilder", ptr %l234
  store %"std/prelude/text:StringBuilder" %t433, ptr %l25
  %t434 = load ptr, ptr %l5, !tbaa !29
  %t435 = load i32, ptr %l1, !tbaa !23
  %t438 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t434, i32 %t435)
  store i32 %t438, ptr %l237
  br label %bb97
bb97:
  %t439 = load i32, ptr %l237, !tbaa !23
  store i32 %t439, ptr %l26, !tbaa !23
  %t440 = load ptr, ptr %l5, !tbaa !29
  store ptr %t440, ptr %l238, !tbaa !29
  %t441 = load ptr, ptr %l5, !tbaa !29
  %t442 = load i32, ptr %l1, !tbaa !23
  %t445 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t441, i32 %t442)
  store i32 %t445, ptr %l241
  br label %bb98
bb98:
  %t446 = load ptr, ptr %l238, !tbaa !29
  %t447 = load i32, ptr %l241, !tbaa !23
  %t448 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t446, i32 %t447)
  store { i64, ptr } %t448, ptr %l242
  br label %bb99
bb99:
  %t449 = load { i64, ptr }, ptr %l242, !tbaa !27
  store { i64, ptr } %t449, ptr %l27, !tbaa !27
  %t450 = load ptr, ptr %l5, !tbaa !29
  %t451 = load i32, ptr %l26, !tbaa !23
  %t454 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t450, i32 %t451)
  store i32 %t454, ptr %l245
  br label %bb100
bb100:
  %t455 = load i32, ptr %l245
  %t457 = trunc i64 22 to i32
  %t458 = icmp eq i32 %t455, %t457
  br i1 %t458, label %bb101, label %bb102
bb101:
  %t460 = load ptr, ptr %l5, !tbaa !29
  store ptr %t460, ptr %l249, !tbaa !29
  %t461 = load ptr, ptr %l5, !tbaa !29
  %t462 = load i32, ptr %l26, !tbaa !23
  %t465 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t461, i32 %t462)
  store i32 %t465, ptr %l252
  br label %bb103
bb102:
  store i1 false, ptr %l248, !tbaa !21
  br label %bb105
bb103:
  %t466 = load ptr, ptr %l249, !tbaa !29
  %t467 = load i32, ptr %l252, !tbaa !23
  %t468 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t466, i32 %t467)
  store { i64, ptr } %t468, ptr %l253
  br label %bb104
bb104:
  %t469 = load { i64, ptr }, ptr %l253, !tbaa !27
  %t470 = extractvalue { i64, ptr } %t469, 0
  %t472 = icmp sgt i64 %t470, 1
  store i1 %t472, ptr %l248, !tbaa !21
  br label %bb105
bb105:
  %t474 = load i1, ptr %l248, !tbaa !21
  br i1 %t474, label %bb106, label %bb107
bb106:
  store i1 true, ptr %l256, !tbaa !21
  br label %bb108
bb107:
  %t475 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t477 = extractvalue { i64, ptr } %t475, 0
  %t479 = icmp sgt i64 %t477, 1
  store i1 %t479, ptr %l256, !tbaa !21
  br label %bb108
bb108:
  %t481 = load i1, ptr %l256, !tbaa !21
  store i1 %t481, ptr %l28, !tbaa !21
  %t482 = load i1, ptr %l2, !tbaa !21
  br i1 %t482, label %bb109, label %bb110
bb109:
  br i1 %a4, label %bb111, label %bb112
bb110:
  store i1 false, ptr %l261, !tbaa !21
  br label %bb117
bb111:
  store i1 true, ptr %l263, !tbaa !21
  br label %bb116
bb112:
  %t486 = load i1, ptr %l3, !tbaa !21
  br i1 %t486, label %bb113, label %bb114
bb113:
  %t488 = load i1, ptr %l28, !tbaa !21
  store i1 %t488, ptr %l265, !tbaa !21
  br label %bb115
bb114:
  store i1 false, ptr %l265, !tbaa !21
  br label %bb115
bb115:
  %t490 = load i1, ptr %l265, !tbaa !21
  store i1 %t490, ptr %l263, !tbaa !21
  br label %bb116
bb116:
  %t491 = load i1, ptr %l263, !tbaa !21
  store i1 %t491, ptr %l261, !tbaa !21
  br label %bb117
bb117:
  %t492 = load i1, ptr %l261, !tbaa !21
  store i1 %t492, ptr %l29, !tbaa !21
  %t493 = load i1, ptr %l29, !tbaa !21
  br i1 %t493, label %bb118, label %bb119
bb118:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s22, ptr %l25, i8 40)
  br label %bb120
bb119:
  br label %bb121
bb120:
  br label %bb121
bb121:
  %t496 = load i1, ptr %l2, !tbaa !21
  br i1 %t496, label %bb122, label %bb123
bb122:
  store %olang.scope zeroinitializer, ptr %s24
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s22, ptr %s24, ptr %l25, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d27, i32 0, i32 1) })
  br label %bb124
bb123:
  br label %bb125
bb124:
  call void @__olang_scope_close(ptr %s24)
  br label %bb125
bb125:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s22, ptr %l25, i8 40)
  br label %bb126
bb126:
  %t500 = load ptr, ptr %l5, !tbaa !29
  store ptr %t500, ptr %l272, !tbaa !29
  %t501 = load ptr, ptr %l5, !tbaa !29
  %t502 = load i32, ptr %l1, !tbaa !23
  %t505 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t501, i32 %t502)
  store i32 %t505, ptr %l275
  br label %bb127
bb127:
  %t506 = load ptr, ptr %l272, !tbaa !29
  %t507 = load i32, ptr %l275, !tbaa !23
  %t508 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t506, i32 %t507)
  store { i64, ptr } %t508, ptr %l276
  br label %bb128
bb128:
  %t509 = load { i64, ptr }, ptr %l276, !tbaa !27
  store { i64, ptr } %t509, ptr %l30, !tbaa !27
  %t510 = load ptr, ptr %l5, !tbaa !29
  %t511 = load i32, ptr %l1, !tbaa !23
  %t514 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesOf(ptr %v0, ptr %t510, i32 %t511)
  store { i64, ptr } %t514, ptr %l279
  br label %bb129
bb129:
  %t515 = load { i64, ptr }, ptr %l279, !tbaa !27
  store { i64, ptr } %t515, ptr %l31, !tbaa !27
  store i64 0, ptr %l32, !tbaa !24
  %t516 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t518 = extractvalue { i64, ptr } %t516, 0
  store i64 %t518, ptr %l33, !tbaa !24
  store i64 1, ptr %l34, !tbaa !24
  %t520 = load i64, ptr %l33, !tbaa !24
  %t521 = load i64, ptr %l32, !tbaa !24
  %t524 = icmp sgt i64 %t520, %t521
  br i1 %t524, label %bb130, label %bb131
bb130:
  %t526 = load i64, ptr %l34, !tbaa !24
  %t528 = icmp sgt i64 %t526, 0
  br i1 %t528, label %bb132, label %bb133
bb131:
  store i64 0, ptr %l285, !tbaa !24
  br label %bb135
bb132:
  %t530 = load i64, ptr %l33, !tbaa !24
  %t531 = load i64, ptr %l32, !tbaa !24
  %t534 = sub i64 %t530, %t531
  %t535 = load i64, ptr %l34, !tbaa !24
  %t538 = add i64 %t534, %t535
  %t540 = sub i64 %t538, 1
  %t541 = load i64, ptr %l34, !tbaa !24
  %t544 = sdiv i64 %t540, %t541
  store i64 %t544, ptr %l288, !tbaa !24
  br label %bb134
bb133:
  store i64 0, ptr %l288, !tbaa !24
  br label %bb134
bb134:
  %t546 = load i64, ptr %l288, !tbaa !24
  store i64 %t546, ptr %l285, !tbaa !24
  br label %bb135
bb135:
  %t547 = load i64, ptr %l285, !tbaa !24
  store i64 %t547, ptr %l35, !tbaa !24
  store i64 0, ptr %l36, !tbaa !24
  br label %bb136
bb136:
  store %olang.scope zeroinitializer, ptr %s26
  %t548 = load i64, ptr %l36, !tbaa !24
  %t549 = load i64, ptr %l35, !tbaa !24
  %t552 = icmp slt i64 %t548, %t549
  %t554 = xor i1 %t552, true
  br i1 %t554, label %bb137, label %bb138
bb137:
  call void @__olang_scope_close(ptr %s26)
  br label %bb152
bb138:
  br label %bb139
bb139:
  %t556 = load i64, ptr %l32, !tbaa !24
  %t557 = load i64, ptr %l36, !tbaa !24
  %t558 = load i64, ptr %l34, !tbaa !24
  %t561 = mul i64 %t557, %t558
  %t564 = add i64 %t556, %t561
  store i64 %t564, ptr %l37, !tbaa !24
  %t566 = load i64, ptr %l37, !tbaa !24
  %t568 = icmp sgt i64 %t566, 0
  br i1 %t568, label %bb140, label %bb141
bb140:
  store %olang.scope zeroinitializer, ptr %s27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s22, ptr %s27, ptr %l25, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d28, i32 0, i32 1) })
  br label %bb142
bb141:
  br label %bb143
bb142:
  call void @__olang_scope_close(ptr %s27)
  br label %bb143
bb143:
  %t571 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t573 = extractvalue { i64, ptr } %t571, 0
  %t574 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t576 = extractvalue { i64, ptr } %t574, 0
  %t579 = icmp eq i64 %t573, %t576
  br i1 %t579, label %bb144, label %bb145
bb144:
  store %olang.scope zeroinitializer, ptr %s28
  store ptr %l25, ptr %l314, !tbaa !29
  %t581 = load ptr, ptr %l5, !tbaa !29
  %t583 = getelementptr %"compiler/types:Table", ptr %t581, i32 0, i32 0
  %t584 = load ptr, ptr %t583, !tbaa !29
  %t585 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t585, ptr %l317, !tbaa !27
  %t586 = load i64, ptr %l37, !tbaa !24
  %t588 = getelementptr { i64, ptr }, ptr %l317, i32 0, i32 1
  %t589 = load ptr, ptr %t588, !tbaa !27
  %t590 = getelementptr i64, ptr %t589, i64 %t586
  %t591 = load i64, ptr %t590, !tbaa !34
  %t593 = trunc i64 %t591 to i32
  %t597 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t584, i32 %t593)
  store { i64, ptr } %t597, ptr %l322
  br label %bb146
bb145:
  br label %bb148
bb146:
  %t598 = load { i64, ptr }, ptr %l322, !tbaa !27
  %t599 = extractvalue { i64, ptr } %t598, 1
  %t600 = extractvalue { i64, ptr } %t598, 0
  %t601 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t602 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  %t603 = add i64 %t600, %t602
  %t604 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t603)
  call void @olang_textcopy(ptr %t604, ptr %t599, i64 %t600)
  %t605 = getelementptr i8, ptr %t604, i64 %t600
  call void @olang_textcopy(ptr %t605, ptr %t601, i64 %t602)
  %t606 = insertvalue { i64, ptr } undef, i64 %t603, 0
  %t607 = insertvalue { i64, ptr } %t606, ptr %t604, 1
  %t609 = extractvalue { i64, ptr } %t607, 0
  %t610 = extractvalue { i64, ptr } %t607, 1
  %t611 = mul i64 %t609, 1
  %t612 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t611)
  call void @llvm.memcpy.p0.p0.i64(ptr %t612, ptr %t610, i64 %t611, i1 false)
  %t613 = insertvalue { i64, ptr } undef, i64 %t609, 0
  %t614 = insertvalue { i64, ptr } %t613, ptr %t612, 1
  %t615 = load ptr, ptr %l314, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s22, ptr %s28, ptr %t615, { i64, ptr } %t614)
  br label %bb147
bb147:
  call void @__olang_scope_close(ptr %s28)
  br label %bb148
bb148:
  store ptr %l25, ptr %l325, !tbaa !29
  %t617 = load ptr, ptr %l0, !tbaa !29
  %t618 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t618, ptr %l327, !tbaa !27
  %t619 = load i64, ptr %l37, !tbaa !24
  %t621 = getelementptr { i64, ptr }, ptr %l327, i32 0, i32 1
  %t622 = load ptr, ptr %t621, !tbaa !27
  %t623 = getelementptr i32, ptr %t622, i64 %t619
  %t624 = load i32, ptr %t623, !tbaa !33
  %t627 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2espell(ptr %v0, ptr %s26, ptr %t617, i32 %t624, i1 true, i1 true, i1 false)
  store { i64, ptr } %t627, ptr %l330
  br label %bb149
bb149:
  %t628 = load { i64, ptr }, ptr %l330, !tbaa !27
  %t629 = extractvalue { i64, ptr } %t628, 0
  %t630 = extractvalue { i64, ptr } %t628, 1
  %t631 = mul i64 %t629, 1
  %t632 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t631)
  call void @llvm.memcpy.p0.p0.i64(ptr %t632, ptr %t630, i64 %t631, i1 false)
  %t633 = insertvalue { i64, ptr } undef, i64 %t629, 0
  %t634 = insertvalue { i64, ptr } %t633, ptr %t632, 1
  %t635 = load ptr, ptr %l325, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s22, ptr %s26, ptr %t635, { i64, ptr } %t634)
  br label %bb150
bb150:
  call void @__olang_scope_close(ptr %s26)
  br label %bb151
bb151:
  %t637 = load i64, ptr %l36, !tbaa !24
  %t639 = add i64 %t637, 1
  store i64 %t639, ptr %l36, !tbaa !24
  br label %bb136
bb152:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s22, ptr %l25, i8 41)
  br label %bb153
bb153:
  %t642 = load ptr, ptr %l5, !tbaa !29
  %t643 = load i32, ptr %l26, !tbaa !23
  %t646 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t642, i32 %t643)
  store i32 %t646, ptr %l337
  br label %bb154
bb154:
  %t647 = load i32, ptr %l337
  %t649 = trunc i64 22 to i32
  %t650 = icmp eq i32 %t647, %t649
  br i1 %t650, label %bb155, label %bb156
bb155:
  %t652 = load ptr, ptr %l5, !tbaa !29
  store ptr %t652, ptr %l340, !tbaa !29
  %t653 = load ptr, ptr %l5, !tbaa !29
  %t654 = load i32, ptr %l26, !tbaa !23
  %t657 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t653, i32 %t654)
  store i32 %t657, ptr %l343
  br label %bb157
bb156:
  %t658 = load i32, ptr %l26, !tbaa !23
  %t659 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t662 = icmp ne i32 %t658, %t659
  br i1 %t662, label %bb176, label %bb177
bb157:
  %t664 = load ptr, ptr %l340, !tbaa !29
  %t665 = load i32, ptr %l343, !tbaa !23
  %t666 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t664, i32 %t665)
  store { i64, ptr } %t666, ptr %l344
  br label %bb158
bb158:
  %t667 = load { i64, ptr }, ptr %l344, !tbaa !27
  store { i64, ptr } %t667, ptr %l38, !tbaa !27
  store i64 0, ptr %l39, !tbaa !24
  %t668 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t670 = extractvalue { i64, ptr } %t668, 0
  store i64 %t670, ptr %l40, !tbaa !24
  store i64 1, ptr %l41, !tbaa !24
  %t672 = load i64, ptr %l40, !tbaa !24
  %t673 = load i64, ptr %l39, !tbaa !24
  %t676 = icmp sgt i64 %t672, %t673
  br i1 %t676, label %bb159, label %bb160
bb159:
  %t678 = load i64, ptr %l41, !tbaa !24
  %t680 = icmp sgt i64 %t678, 0
  br i1 %t680, label %bb161, label %bb162
bb160:
  store i64 0, ptr %l350, !tbaa !24
  br label %bb164
bb161:
  %t682 = load i64, ptr %l40, !tbaa !24
  %t683 = load i64, ptr %l39, !tbaa !24
  %t686 = sub i64 %t682, %t683
  %t687 = load i64, ptr %l41, !tbaa !24
  %t690 = add i64 %t686, %t687
  %t692 = sub i64 %t690, 1
  %t693 = load i64, ptr %l41, !tbaa !24
  %t696 = sdiv i64 %t692, %t693
  store i64 %t696, ptr %l353, !tbaa !24
  br label %bb163
bb162:
  store i64 0, ptr %l353, !tbaa !24
  br label %bb163
bb163:
  %t698 = load i64, ptr %l353, !tbaa !24
  store i64 %t698, ptr %l350, !tbaa !24
  br label %bb164
bb164:
  %t699 = load i64, ptr %l350, !tbaa !24
  store i64 %t699, ptr %l42, !tbaa !24
  store i64 0, ptr %l43, !tbaa !24
  br label %bb165
bb165:
  store %olang.scope zeroinitializer, ptr %s33
  %t700 = load i64, ptr %l43, !tbaa !24
  %t701 = load i64, ptr %l42, !tbaa !24
  %t704 = icmp slt i64 %t700, %t701
  %t706 = xor i1 %t704, true
  br i1 %t706, label %bb166, label %bb167
bb166:
  call void @__olang_scope_close(ptr %s33)
  br label %bb175
bb167:
  br label %bb168
bb168:
  %t708 = load i64, ptr %l39, !tbaa !24
  %t709 = load i64, ptr %l43, !tbaa !24
  %t710 = load i64, ptr %l41, !tbaa !24
  %t713 = mul i64 %t709, %t710
  %t716 = add i64 %t708, %t713
  store i64 %t716, ptr %l44, !tbaa !24
  store ptr %l25, ptr %l371, !tbaa !29
  %t718 = load i64, ptr %l44, !tbaa !24
  %t720 = icmp sgt i64 %t718, 0
  br i1 %t720, label %bb169, label %bb170
bb169:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d30, i32 0, i32 1) }, ptr %l374, !tbaa !27
  br label %bb171
bb170:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, ptr %l374, !tbaa !27
  br label %bb171
bb171:
  %t722 = load ptr, ptr %l0, !tbaa !29
  %t723 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t723, ptr %l376, !tbaa !27
  %t724 = load i64, ptr %l44, !tbaa !24
  %t726 = getelementptr { i64, ptr }, ptr %l376, i32 0, i32 1
  %t727 = load ptr, ptr %t726, !tbaa !27
  %t728 = getelementptr i32, ptr %t727, i64 %t724
  %t729 = load i32, ptr %t728, !tbaa !33
  %t732 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2espell(ptr %v0, ptr %s33, ptr %t722, i32 %t729, i1 true, i1 true, i1 false)
  store { i64, ptr } %t732, ptr %l379
  br label %bb172
bb172:
  %t733 = load { i64, ptr }, ptr %l374, !tbaa !27
  %t734 = extractvalue { i64, ptr } %t733, 1
  %t735 = extractvalue { i64, ptr } %t733, 0
  %t736 = load { i64, ptr }, ptr %l379, !tbaa !27
  %t737 = extractvalue { i64, ptr } %t736, 1
  %t738 = extractvalue { i64, ptr } %t736, 0
  %t739 = add i64 %t735, %t738
  %t740 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t739)
  call void @olang_textcopy(ptr %t740, ptr %t734, i64 %t735)
  %t741 = getelementptr i8, ptr %t740, i64 %t735
  call void @olang_textcopy(ptr %t741, ptr %t737, i64 %t738)
  %t742 = insertvalue { i64, ptr } undef, i64 %t739, 0
  %t743 = insertvalue { i64, ptr } %t742, ptr %t740, 1
  %t745 = extractvalue { i64, ptr } %t743, 0
  %t746 = extractvalue { i64, ptr } %t743, 1
  %t747 = mul i64 %t745, 1
  %t748 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t747)
  call void @llvm.memcpy.p0.p0.i64(ptr %t748, ptr %t746, i64 %t747, i1 false)
  %t749 = insertvalue { i64, ptr } undef, i64 %t745, 0
  %t750 = insertvalue { i64, ptr } %t749, ptr %t748, 1
  %t751 = load ptr, ptr %l371, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s22, ptr %s33, ptr %t751, { i64, ptr } %t750)
  br label %bb173
bb173:
  call void @__olang_scope_close(ptr %s33)
  br label %bb174
bb174:
  %t753 = load i64, ptr %l43, !tbaa !24
  %t755 = add i64 %t753, 1
  store i64 %t755, ptr %l43, !tbaa !24
  br label %bb165
bb175:
  br label %bb190
bb176:
  store %olang.scope zeroinitializer, ptr %s37
  %t757 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t759 = extractvalue { i64, ptr } %t757, 0
  %t761 = icmp sgt i64 %t759, 0
  br i1 %t761, label %bb178, label %bb179
bb177:
  br label %bb189
bb178:
  %t763 = load ptr, ptr %l5, !tbaa !29
  %t764 = load i32, ptr %l26, !tbaa !23
  %t767 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t763, i32 %t764)
  store i32 %t767, ptr %l393
  br label %bb180
bb179:
  store i1 false, ptr %l390, !tbaa !21
  br label %bb181
bb180:
  %t768 = load i32, ptr %l393
  %t770 = trunc i64 21 to i32
  %t771 = icmp eq i32 %t768, %t770
  store i1 %t771, ptr %l390, !tbaa !21
  br label %bb181
bb181:
  %t773 = load i1, ptr %l390, !tbaa !21
  br i1 %t773, label %bb182, label %bb183
bb182:
  %t774 = load ptr, ptr %l5, !tbaa !29
  store ptr %t774, ptr %l397, !tbaa !29
  %t775 = load ptr, ptr %l5, !tbaa !29
  %t776 = load i32, ptr %l26, !tbaa !23
  %t779 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t775, i32 %t776)
  store i32 %t779, ptr %l400
  br label %bb184
bb183:
  store i1 false, ptr %l396, !tbaa !21
  br label %bb186
bb184:
  %t780 = load ptr, ptr %l397, !tbaa !29
  %t781 = load i32, ptr %l400, !tbaa !23
  %t782 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t780, i32 %t781)
  store { i64, ptr } %t782, ptr %l401
  br label %bb185
bb185:
  %t783 = load { i64, ptr }, ptr %l401, !tbaa !27
  %t784 = extractvalue { i64, ptr } %t783, 0
  %t786 = icmp eq i64 %t784, 0
  store i1 %t786, ptr %l396, !tbaa !21
  br label %bb186
bb186:
  %t788 = load i1, ptr %l396, !tbaa !21
  store ptr %l25, ptr %l404, !tbaa !29
  %t789 = load ptr, ptr %l0, !tbaa !29
  %t790 = load i32, ptr %l26, !tbaa !23
  %t795 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2espell(ptr %v0, ptr %s37, ptr %t789, i32 %t790, i1 true, i1 true, i1 %t788)
  store { i64, ptr } %t795, ptr %l408
  br label %bb187
bb187:
  %t796 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t797 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t798 = load { i64, ptr }, ptr %l408, !tbaa !27
  %t799 = extractvalue { i64, ptr } %t798, 1
  %t800 = extractvalue { i64, ptr } %t798, 0
  %t801 = add i64 %t797, %t800
  %t802 = call ptr @__olang_scope_alloc(ptr %s37, i64 %t801)
  call void @olang_textcopy(ptr %t802, ptr %t796, i64 %t797)
  %t803 = getelementptr i8, ptr %t802, i64 %t797
  call void @olang_textcopy(ptr %t803, ptr %t799, i64 %t800)
  %t804 = insertvalue { i64, ptr } undef, i64 %t801, 0
  %t805 = insertvalue { i64, ptr } %t804, ptr %t802, 1
  %t807 = extractvalue { i64, ptr } %t805, 0
  %t808 = extractvalue { i64, ptr } %t805, 1
  %t809 = mul i64 %t807, 1
  %t810 = call ptr @__olang_scope_alloc(ptr %s37, i64 %t809)
  call void @llvm.memcpy.p0.p0.i64(ptr %t810, ptr %t808, i64 %t809, i1 false)
  %t811 = insertvalue { i64, ptr } undef, i64 %t807, 0
  %t812 = insertvalue { i64, ptr } %t811, ptr %t810, 1
  %t813 = load ptr, ptr %l404, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s22, ptr %s37, ptr %t813, { i64, ptr } %t812)
  br label %bb188
bb188:
  call void @__olang_scope_close(ptr %s37)
  br label %bb189
bb189:
  br label %bb190
bb190:
  %t815 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t817 = extractvalue { i64, ptr } %t815, 0
  %t819 = icmp sgt i64 %t817, 0
  br i1 %t819, label %bb191, label %bb192
bb191:
  store %olang.scope zeroinitializer, ptr %s39
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s22, ptr %s39, ptr %l25, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d33, i32 0, i32 1) })
  br label %bb193
bb192:
  br label %bb212
bb193:
  store i64 0, ptr %l46, !tbaa !24
  %t822 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t824 = extractvalue { i64, ptr } %t822, 0
  store i64 %t824, ptr %l47, !tbaa !24
  store i64 1, ptr %l48, !tbaa !24
  %t826 = load i64, ptr %l47, !tbaa !24
  %t827 = load i64, ptr %l46, !tbaa !24
  %t830 = icmp sgt i64 %t826, %t827
  br i1 %t830, label %bb194, label %bb195
bb194:
  %t832 = load i64, ptr %l48, !tbaa !24
  %t834 = icmp sgt i64 %t832, 0
  br i1 %t834, label %bb196, label %bb197
bb195:
  store i64 0, ptr %l420, !tbaa !24
  br label %bb199
bb196:
  %t836 = load i64, ptr %l47, !tbaa !24
  %t837 = load i64, ptr %l46, !tbaa !24
  %t840 = sub i64 %t836, %t837
  %t841 = load i64, ptr %l48, !tbaa !24
  %t844 = add i64 %t840, %t841
  %t846 = sub i64 %t844, 1
  %t847 = load i64, ptr %l48, !tbaa !24
  %t850 = sdiv i64 %t846, %t847
  store i64 %t850, ptr %l423, !tbaa !24
  br label %bb198
bb197:
  store i64 0, ptr %l423, !tbaa !24
  br label %bb198
bb198:
  %t852 = load i64, ptr %l423, !tbaa !24
  store i64 %t852, ptr %l420, !tbaa !24
  br label %bb199
bb199:
  %t853 = load i64, ptr %l420, !tbaa !24
  store i64 %t853, ptr %l49, !tbaa !24
  store i64 0, ptr %l50, !tbaa !24
  br label %bb200
bb200:
  store %olang.scope zeroinitializer, ptr %s41
  %t854 = load i64, ptr %l50, !tbaa !24
  %t855 = load i64, ptr %l49, !tbaa !24
  %t858 = icmp slt i64 %t854, %t855
  %t860 = xor i1 %t858, true
  br i1 %t860, label %bb201, label %bb202
bb201:
  call void @__olang_scope_close(ptr %s41)
  br label %bb211
bb202:
  br label %bb203
bb203:
  %t862 = load i64, ptr %l46, !tbaa !24
  %t863 = load i64, ptr %l50, !tbaa !24
  %t864 = load i64, ptr %l48, !tbaa !24
  %t867 = mul i64 %t863, %t864
  %t870 = add i64 %t862, %t867
  store i64 %t870, ptr %l51, !tbaa !24
  store ptr %l25, ptr %l441, !tbaa !29
  %t872 = load i64, ptr %l51, !tbaa !24
  %t874 = icmp sgt i64 %t872, 0
  br i1 %t874, label %bb204, label %bb205
bb204:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d34, i32 0, i32 1) }, ptr %l444, !tbaa !27
  br label %bb206
bb205:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) }, ptr %l444, !tbaa !27
  br label %bb206
bb206:
  %t876 = load ptr, ptr %l0, !tbaa !29
  store ptr %t876, ptr %l445, !tbaa !29
  %t877 = load ptr, ptr %l5, !tbaa !29
  %t878 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t878, ptr %l447, !tbaa !27
  %t879 = load i64, ptr %l51, !tbaa !24
  %t881 = getelementptr { i64, ptr }, ptr %l447, i32 0, i32 1
  %t882 = load ptr, ptr %t881, !tbaa !27
  %t883 = getelementptr i32, ptr %t882, i64 %t879
  %t884 = load i32, ptr %t883, !tbaa !33
  %t887 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t877, i32 %t884)
  store i32 %t887, ptr %l450
  br label %bb207
bb207:
  %t888 = load ptr, ptr %l445, !tbaa !29
  %t889 = load i32, ptr %l450, !tbaa !23
  %t890 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2espell(ptr %v0, ptr %s41, ptr %t888, i32 %t889, i1 true, i1 false, i1 false)
  store { i64, ptr } %t890, ptr %l451
  br label %bb208
bb208:
  %t891 = load { i64, ptr }, ptr %l444, !tbaa !27
  %t892 = extractvalue { i64, ptr } %t891, 1
  %t893 = extractvalue { i64, ptr } %t891, 0
  %t894 = load { i64, ptr }, ptr %l451, !tbaa !27
  %t895 = extractvalue { i64, ptr } %t894, 1
  %t896 = extractvalue { i64, ptr } %t894, 0
  %t897 = add i64 %t893, %t896
  %t898 = call ptr @__olang_scope_alloc(ptr %s41, i64 %t897)
  call void @olang_textcopy(ptr %t898, ptr %t892, i64 %t893)
  %t899 = getelementptr i8, ptr %t898, i64 %t893
  call void @olang_textcopy(ptr %t899, ptr %t895, i64 %t896)
  %t900 = insertvalue { i64, ptr } undef, i64 %t897, 0
  %t901 = insertvalue { i64, ptr } %t900, ptr %t898, 1
  %t903 = extractvalue { i64, ptr } %t901, 0
  %t904 = extractvalue { i64, ptr } %t901, 1
  %t905 = mul i64 %t903, 1
  %t906 = call ptr @__olang_scope_alloc(ptr %s41, i64 %t905)
  call void @llvm.memcpy.p0.p0.i64(ptr %t906, ptr %t904, i64 %t905, i1 false)
  %t907 = insertvalue { i64, ptr } undef, i64 %t903, 0
  %t908 = insertvalue { i64, ptr } %t907, ptr %t906, 1
  %t909 = load ptr, ptr %l441, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s22, ptr %s41, ptr %t909, { i64, ptr } %t908)
  br label %bb209
bb209:
  call void @__olang_scope_close(ptr %s41)
  br label %bb210
bb210:
  %t911 = load i64, ptr %l50, !tbaa !24
  %t913 = add i64 %t911, 1
  store i64 %t913, ptr %l50, !tbaa !24
  br label %bb200
bb211:
  call void @__olang_scope_close(ptr %s39)
  br label %bb212
bb212:
  %t915 = load i1, ptr %l29, !tbaa !21
  br i1 %t915, label %bb213, label %bb214
bb213:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s22, ptr %l25, i8 41)
  br label %bb215
bb214:
  br label %bb216
bb215:
  br label %bb216
bb216:
  %t919 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s22, ptr %v1, ptr %l25)
  store { i64, ptr } %t919, ptr %l459
  br label %bb217
bb217:
  %t920 = load { i64, ptr }, ptr %l459, !tbaa !27
  store { i64, ptr } %t920, ptr %l460, !tbaa !27
  %t921 = load { i64, ptr }, ptr %l460, !tbaa !27
  %t922 = extractvalue { i64, ptr } %t921, 0
  store i64 %t922, ptr %l461, !tbaa !24
  %t923 = load i64, ptr %l461, !tbaa !24
  %t924 = mul i64 %t923, 1
  %t925 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t924)
  %t926 = insertvalue { i64, ptr } undef, i64 %t923, 0
  %t927 = insertvalue { i64, ptr } %t926, ptr %t925, 1
  store { i64, ptr } %t927, ptr %l462, !tbaa !27
  %t928 = getelementptr { i64, ptr }, ptr %l462, i32 0, i32 1
  %t929 = load ptr, ptr %t928, !tbaa !27
  %t930 = getelementptr { i64, ptr }, ptr %l460, i32 0, i32 1
  %t931 = load ptr, ptr %t930, !tbaa !27
  %t932 = load i64, ptr %l461, !tbaa !24
  %t933 = mul i64 %t932, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t929, ptr %t931, i64 %t933, i1 false)
  %t934 = load { i64, ptr }, ptr %l462, !tbaa !27
  store { i64, ptr } %t934, ptr %l460, !tbaa !27
  call void @__olang_scope_close(ptr %s22)
  %t935 = load { i64, ptr }, ptr %l460, !tbaa !27
  store { i64, ptr } %t935, ptr %rv
  br label %ret
bb218:
  %t936 = load ptr, ptr %l5, !tbaa !29
  %t937 = load i32, ptr %l1, !tbaa !23
  %t940 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %t936, i32 %t937)
  store { i64, ptr } %t940, ptr %l465
  br label %bb219
bb219:
  %t941 = load { i64, ptr }, ptr %l465, !tbaa !27
  store { i64, ptr } %t941, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2flower_2ecompiler_2flower_3alowering_2estrBody(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i64
  %l13 = alloca i32
  %l16 = alloca i32
  %l20 = alloca i32
  %l23 = alloca i32
  %l28 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i32
  %l39 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 2
  %t9 = load ptr, ptr %t8, !tbaa !29
  store ptr %t9, ptr %l3, !tbaa !29
  %t11 = load ptr, ptr %l3, !tbaa !29
  %t12 = load i32, ptr %l1, !tbaa !23
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t15, ptr %l13
  br label %bb1
bb1:
  %t16 = load i32, ptr %l13
  %t18 = trunc i64 18 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb2, label %bb3
bb2:
  %t21 = load i32, ptr %l1, !tbaa !23
  store i32 %t21, ptr %l16, !tbaa !23
  br label %bb5
bb3:
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t24 = load i32, ptr %l1, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l20
  br label %bb4
bb4:
  %t28 = load i32, ptr %l20, !tbaa !23
  store i32 %t28, ptr %l16, !tbaa !23
  br label %bb5
bb5:
  %t29 = load i32, ptr %l16, !tbaa !23
  store i32 %t29, ptr %l4, !tbaa !23
  %t30 = load ptr, ptr %l3, !tbaa !29
  %t31 = load i32, ptr %l4, !tbaa !23
  %t34 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t30, i32 %t31)
  store i32 %t34, ptr %l23
  br label %bb6
bb6:
  %t35 = load i32, ptr %l23
  %t37 = trunc i64 18 to i32
  %t38 = icmp eq i32 %t35, %t37
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t43 = load ptr, ptr %l2, !tbaa !29
  %t45 = getelementptr %"compiler/lower:Lowerer", ptr %t43, i32 0, i32 11
  %t46 = load i32, ptr %l4, !tbaa !23
  %t49 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %v0, ptr %t45, i32 %t46)
  %t50 = extractvalue { i32, i64 } %t49, 1
  %t51 = extractvalue { i32, i64 } %t49, 0
  store i32 %t51, ptr %l33
  %t52 = icmp ne i32 %t51, 0
  br i1 %t52, label %bb11, label %ok.53, !prof !99
ok.53:
  store i64 %t50, ptr %l32
  br label %bb10
bb10:
  %t54 = load i64, ptr %l32, !tbaa !24
  store i64 %t54, ptr %l28, !tbaa !24
  br label %bb13
bb11:
  br label %bb12
bb12:
  call void @__olang_ert_req_clear()
  store i64 -2, ptr %l28, !tbaa !24
  br label %bb13
bb13:
  %t55 = load i64, ptr %l28, !tbaa !24
  store i64 %t55, ptr %l5, !tbaa !24
  %t56 = load i64, ptr %l5, !tbaa !24
  %t58 = icmp ne i64 %t56, -2
  br i1 %t58, label %bb14, label %bb15
bb14:
  %t60 = load i64, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t60, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load i32, ptr %l1, !tbaa !23
  %t66 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2emethodBody(ptr %v0, ptr %s0, ptr %s0, ptr %t62, i32 %t63, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d36, i32 0, i32 1) }, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d37, i32 0, i32 1) })
  store i64 %t66, ptr %l39
  br label %bb17
bb17:
  %t67 = load i64, ptr %l39, !tbaa !24
  store i64 %t67, ptr %l6, !tbaa !24
  %t68 = load ptr, ptr %l2, !tbaa !29
  %t70 = getelementptr %"compiler/lower:Lowerer", ptr %t68, i32 0, i32 11
  %t71 = load i32, ptr %l4, !tbaa !23
  %t72 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__Hccd9659a44f570da1fa06b019882a84d(ptr %v0, ptr %t70, i32 %t71, i64 %t72)
  br label %bb18
bb18:
  %t76 = load i64, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t76, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l7 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/lower:lowering", ptr %a0, i32 0, i32 3
  %t9 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v0, ptr %t3, i32 %a1, %"compiler/source:Span" %a2)
  store i32 %t9, ptr %l7
  br label %bb1
bb1:
  %t10 = load i32, ptr %l7, !tbaa !23
  store i32 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"compiler/lower:level" @compiler_2flower_2ecompiler_2flower_3alowering_2etop(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l5 = alloca i64
  %l7 = alloca %"compiler/lower:level"
  %rv = alloca %"compiler/lower:level"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 9
  store ptr %t3, ptr %l2, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/lower:lowering", ptr %t4, i32 0, i32 9
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l5
  br label %bb1
bb1:
  %t9 = load i64, ptr %l5, !tbaa !24
  %t10 = sub i64 %t9, 1
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t13 = call %"compiler/lower:level" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eAt_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t11, i64 %t10)
  store %"compiler/lower:level" %t13, ptr %l7
  br label %bb2
bb2:
  %t14 = load %"compiler/lower:level", ptr %l7
  store %"compiler/lower:level" %t14, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:level", ptr %rv
  ret %"compiler/lower:level" %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2etry(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca { i64, [4 x i64] }
  %l13 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l16 = alloca i32
  %l21 = alloca i1
  %l28 = alloca i32
  %l34 = alloca i64
  %l41 = alloca %"compiler/lower:tryCtx"
  %l51 = alloca { i64, ptr }
  %l66 = alloca { i64, [4 x i64] }
  %l67 = alloca %"compiler/lower:tryCtx"
  %l70 = alloca %"compiler/lower:tryCtx"
  %l71 = alloca i32
  %l72 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l76 = alloca i1
  %l80 = alloca i1
  %l84 = alloca ptr
  %l85 = alloca %"compiler/source:Span"
  %l87 = alloca %"compiler/mir:Lvalue"
  %l94 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l95 = alloca ptr
  %l98 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l125 = alloca %"compiler/mir:Lvalue"
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t153 = alloca { i64, [15 x i64] }, align 8
  %t159 = alloca { i64, [21 x i64] }, align 8
  %t245 = alloca { i64, [4 x i64] }, align 8
  %t252 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %a1)
  store i32 %t3, ptr %l16
  br label %bb1
bb1:
  %t4 = load i32, ptr %l16, !tbaa !23
  store i32 %t4, ptr %l4, !tbaa !23
  %t5 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  store i32 %t5, ptr %l5, !tbaa !23
  %t7 = load i32, ptr %l4, !tbaa !23
  %t8 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t11 = icmp ne i32 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i32, ptr %l4, !tbaa !23
  %t14 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t17 = icmp ne i32 %t13, %t14
  store i1 %t17, ptr %l21, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l21, !tbaa !21
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l4, !tbaa !23
  %t22 = load %"compiler/source:Span", ptr %l3
  %t26 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t20, i32 %t21, %"compiler/source:Span" %t22)
  store i32 %t26, ptr %l28
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t27 = load i32, ptr %l28, !tbaa !23
  store i32 %t27, ptr %l5, !tbaa !23
  br label %bb8
bb8:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/lower:lowering", ptr %t28, i32 0, i32 25
  %t31 = load i64, ptr %t30, !tbaa !24
  store i64 %t31, ptr %l6, !tbaa !24
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/lower:lowering", ptr %t33, i32 0, i32 25
  store i64 -1, ptr %t35, !tbaa !24
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/lower:lowering", ptr %t36, i32 0, i32 9
  %t40 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t38)
  store i64 %t40, ptr %l34
  br label %bb9
bb9:
  %t41 = load ptr, ptr %l2, !tbaa !29
  %t43 = getelementptr %"compiler/typed:Try", ptr %t41, i32 0, i32 1
  %t44 = load { i64, ptr }, ptr %t43, !tbaa !27
  %t45 = load ptr, ptr %l2, !tbaa !29
  %t47 = getelementptr %"compiler/typed:Try", ptr %t45, i32 0, i32 2
  %t48 = load i1, ptr %t47, !tbaa !21
  %t49 = load ptr, ptr %l2, !tbaa !29
  %t51 = getelementptr %"compiler/typed:Try", ptr %t49, i32 0, i32 3
  %t52 = load i1, ptr %t51, !tbaa !21
  %t53 = load i64, ptr %l34, !tbaa !24
  %t57 = call %"compiler/lower:tryCtx" @compiler_2flower_3atryCtx_2ector(ptr %v2, ptr %v0, i64 %t53, { i64, ptr } %t44, i1 %t48, i1 %t52)
  store %"compiler/lower:tryCtx" %t57, ptr %l41
  br label %bb10
bb10:
  %t58 = load %"compiler/lower:tryCtx", ptr %l41
  %t59 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store %"compiler/lower:tryCtx" %t58, ptr %t59
  store ptr %t59, ptr %l7, !tbaa !29
  %t61 = load ptr, ptr %l2, !tbaa !29
  %t63 = getelementptr %"compiler/typed:Try", ptr %t61, i32 0, i32 1
  %t64 = load { i64, ptr }, ptr %t63, !tbaa !27
  store { i64, ptr } %t64, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t66 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t66, 0
  store i64 %t68, ptr %l10, !tbaa !24
  br label %bb11
bb11:
  %t70 = load i64, ptr %l9, !tbaa !24
  %t71 = load i64, ptr %l10, !tbaa !24
  %t74 = icmp slt i64 %t70, %t71
  %t76 = xor i1 %t74, true
  br i1 %t76, label %bb12, label %bb13
bb12:
  br label %bb17
bb13:
  br label %bb14
bb14:
  %t78 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t78, ptr %l51, !tbaa !27
  %t79 = load i64, ptr %l9, !tbaa !24
  %t81 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr ptr, ptr %t82, i64 %t79
  %t84 = load ptr, ptr %t83, !tbaa !39
  store ptr %t84, ptr %l11, !tbaa !29
  %t86 = load ptr, ptr %l7, !tbaa !29
  %t88 = getelementptr %"compiler/lower:tryCtx", ptr %t86, i32 0, i32 4
  %t89 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ePush_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %t88, i32 %t89)
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t92 = load i64, ptr %l9, !tbaa !24
  %t94 = add i64 %t92, 1
  store i64 %t94, ptr %l9, !tbaa !24
  br label %bb11
bb17:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/lower:lowering", ptr %t96, i32 0, i32 13
  %t99 = load ptr, ptr %l7, !tbaa !29
  %t101 = load %"compiler/lower:tryCtx", ptr %t99
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3atryCtx_3e_2ePush_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %v0, ptr %t98, %"compiler/lower:tryCtx" %t101)
  br label %bb18
bb18:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load ptr, ptr %l2, !tbaa !29
  %t107 = getelementptr %"compiler/typed:Try", ptr %t105, i32 0, i32 0
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t111 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v2, ptr %t104, ptr %t108)
  store { i64, [4 x i64] } %t111, ptr %l66
  br label %bb19
bb19:
  %t112 = load { i64, [4 x i64] }, ptr %l66
  store { i64, [4 x i64] } %t112, ptr %l12
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/lower:lowering", ptr %t113, i32 0, i32 13
  %t117 = call { i32, %"compiler/lower:tryCtx" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3atryCtx_3e_2ePop_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %v0, ptr %t115)
  %t118 = extractvalue { i32, %"compiler/lower:tryCtx" } %t117, 1
  %t119 = extractvalue { i32, %"compiler/lower:tryCtx" } %t117, 0
  store i32 %t119, ptr %l71
  %t120 = icmp ne i32 %t119, 0
  br i1 %t120, label %bb21, label %ok.121, !prof !99
ok.121:
  store %"compiler/lower:tryCtx" %t118, ptr %l70
  br label %bb20
bb20:
  %t122 = load %"compiler/lower:tryCtx", ptr %l70
  store %"compiler/lower:tryCtx" %t122, ptr %l67
  br label %bb23
bb21:
  br label %bb22
bb22:
  call void @__olang_ert_req_clear()
  br label %bb23
bb23:
  %t123 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t123, ptr %l72
  br label %bb24
bb24:
  %t124 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l72
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t124, ptr %l13
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/lower:lowering", ptr %t125, i32 0, i32 7
  %t128 = load i1, ptr %t127, !tbaa !21
  %t130 = xor i1 %t128, true
  br i1 %t130, label %bb25, label %bb26
bb25:
  %t132 = load i32, ptr %l5, !tbaa !23
  %t133 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t136 = icmp ne i32 %t132, %t133
  store i1 %t136, ptr %l76, !tbaa !21
  br label %bb27
bb26:
  store i1 false, ptr %l76, !tbaa !21
  br label %bb27
bb27:
  %t138 = load i1, ptr %l76, !tbaa !21
  br i1 %t138, label %bb28, label %bb29
bb28:
  %t139 = load { i64, [4 x i64] }, ptr %l12
  %t141 = extractvalue { i64, [4 x i64] } %t139, 0
  %t142 = icmp eq i64 %t141, 0
  %t144 = xor i1 %t142, true
  store i1 %t144, ptr %l80, !tbaa !21
  br label %bb30
bb29:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb30
bb30:
  %t146 = load i1, ptr %l80, !tbaa !21
  br i1 %t146, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s6
  %t147 = load ptr, ptr %l0, !tbaa !29
  store ptr %t147, ptr %l84, !tbaa !29
  %t148 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t148, ptr %l85
  %t149 = load i32, ptr %l5, !tbaa !23
  %t151 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t149)
  store %"compiler/mir:Lvalue" %t151, ptr %l87
  br label %bb33
bb32:
  br label %bb48
bb33:
  %t152 = load { i64, [4 x i64] }, ptr %l12
  store { i64, [15 x i64] } zeroinitializer, ptr %t153
  %t154 = getelementptr { i64, [15 x i64] }, ptr %t153, i32 0, i32 0
  store i64 0, ptr %t154
  %t156 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t152, 0
  %t157 = getelementptr { i64, [15 x i64] }, ptr %t153, i32 0, i32 1
  store { { i64, [4 x i64] } } %t156, ptr %t157
  %t158 = load { i64, [15 x i64] }, ptr %t153
  store { i64, [21 x i64] } zeroinitializer, ptr %t159
  %t160 = getelementptr { i64, [21 x i64] }, ptr %t159, i32 0, i32 0
  store i64 0, ptr %t160
  %t161 = load %"compiler/source:Span", ptr %l85
  %t162 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t161, 0
  %t163 = load %"compiler/mir:Lvalue", ptr %l87
  %t164 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t162, %"compiler/mir:Lvalue" %t163, 1
  %t166 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t164, { i64, [15 x i64] } %t158, 2
  %t167 = getelementptr { i64, [21 x i64] }, ptr %t159, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t166, ptr %t167
  %t168 = load { i64, [21 x i64] }, ptr %t159
  %t170 = call ptr @__olang_scope_alloc_a(ptr %s6, i64 176, i64 8)
  store { i64, [21 x i64] } %t168, ptr %t170
  %t171 = load ptr, ptr %l84, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s6, ptr %t171, ptr %t170)
  br label %bb34
bb34:
  %t173 = load i64, ptr %l6, !tbaa !24
  %t175 = icmp sge i64 %t173, 0
  br i1 %t175, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s7
  %t177 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ector(ptr %s7, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t177, ptr %l94
  br label %bb37
bb36:
  br label %bb47
bb37:
  %t178 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l94
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t178, ptr %l14
  store ptr %l14, ptr %l95, !tbaa !29
  %t179 = load i64, ptr %l6, !tbaa !24
  %t181 = icmp eq i64 %t179, 1
  br i1 %t181, label %bb38, label %bb39
bb38:
  %t183 = mul i64 1, 8
  %t184 = call ptr @__olang_scope_alloc_zeroed(ptr %s7, i64 %t183)
  %t185 = insertvalue { i64, ptr } undef, i64 1, 0
  %t186 = insertvalue { i64, ptr } %t185, ptr %t184, 1
  store { i64, ptr } %t186, ptr %l99, !tbaa !27
  %t187 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t188 = load ptr, ptr %t187, !tbaa !27
  %t189 = getelementptr i64, ptr %t188, i64 0
  store i64 0, ptr %t189, !tbaa !34
  %t190 = load { i64, ptr }, ptr %l99, !tbaa !27
  store { i64, ptr } %t190, ptr %l98, !tbaa !27
  br label %bb44
bb39:
  %t191 = icmp sge i64 0, 0
  br i1 %t191, label %bb40, label %bb41
bb40:
  %t193 = icmp sle i64 0, 1152921504606846975
  br i1 %t193, label %bb42, label %bb43
bb41:
  call void @__olang_check_failed(ptr @olang_loc_2157f043f9fed58b_cfe589e7cd689437)
  unreachable
bb42:
  %t195 = mul i64 0, 8
  %t196 = call ptr @__olang_scope_alloc_zeroed(ptr %s7, i64 %t195)
  %t197 = insertvalue { i64, ptr } undef, i64 0, 0
  %t198 = insertvalue { i64, ptr } %t197, ptr %t196, 1
  store { i64, ptr } %t198, ptr %l98, !tbaa !27
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_2157f043f9fed58b_cfe589e7cd689437)
  unreachable
bb44:
  %t200 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t201 = extractvalue { i64, ptr } %t200, 0
  %t202 = extractvalue { i64, ptr } %t200, 1
  %t203 = mul i64 %t201, 8
  %t204 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t203)
  call void @llvm.memcpy.p0.p0.i64(ptr %t204, ptr %t202, i64 %t203, i1 false)
  %t205 = insertvalue { i64, ptr } undef, i64 %t201, 0
  %t206 = insertvalue { i64, ptr } %t205, ptr %t204, 1
  %t207 = load ptr, ptr %l95, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %s7, ptr %s7, ptr %t207, { i64, ptr } %t206)
  br label %bb45
bb45:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load i32, ptr %l5, !tbaa !23
  %t211 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ereleaseAt(ptr %v0, ptr %s7, ptr %t209, i32 %t210, ptr %l14, %"compiler/source:Span" %t211)
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s7)
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s6)
  br label %bb48
bb48:
  %t216 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleaveOpen(ptr %v0, ptr %s0, ptr %t216, ptr %l13)
  br label %bb49
bb49:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load ptr, ptr %l7, !tbaa !29
  %t222 = load %"compiler/lower:tryCtx", ptr %t220
  %t223 = load ptr, ptr %l2, !tbaa !29
  %t225 = getelementptr %"compiler/typed:Try", ptr %t223, i32 0, i32 1
  %t226 = load { i64, ptr }, ptr %t225, !tbaa !27
  %t227 = load i32, ptr %l5, !tbaa !23
  %t228 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eclauses(ptr %v0, ptr %v0, ptr %v2, ptr %s0, ptr %t219, %"compiler/lower:tryCtx" %t222, { i64, ptr } %t226, i32 %t227, i32 %t228, ptr %l13)
  br label %bb50
bb50:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t236 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2epatch(ptr %v0, ptr %s0, ptr %t235, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t236)
  br label %bb51
bb51:
  %t239 = load i32, ptr %l5, !tbaa !23
  %t240 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t243 = icmp eq i32 %t239, %t240
  br i1 %t243, label %bb52, label %bb53
bb52:
  store { i64, [4 x i64] } zeroinitializer, ptr %t245
  %t246 = getelementptr { i64, [4 x i64] }, ptr %t245, i32 0, i32 0
  store i64 0, ptr %t246
  %t247 = load { i64, [4 x i64] }, ptr %t245
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t247, ptr %rv
  br label %ret
bb53:
  br label %bb54
bb54:
  %t249 = load i32, ptr %l5, !tbaa !23
  %t251 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t249)
  store %"compiler/mir:Lvalue" %t251, ptr %l125
  br label %bb55
bb55:
  store { i64, [4 x i64] } zeroinitializer, ptr %t252
  %t253 = getelementptr { i64, [4 x i64] }, ptr %t252, i32 0, i32 0
  store i64 1, ptr %t253
  %t254 = load %"compiler/mir:Lvalue", ptr %l125
  %t255 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t254, 0
  %t256 = getelementptr { i64, [4 x i64] }, ptr %t252, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t255, ptr %t256
  %t257 = load { i64, [4 x i64] }, ptr %t252
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t257, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local ptr @compiler_2flower_2ecompiler_2flower_3alowering_2eunconvert(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i1
  %l14 = alloca i1
  %l18 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l22 = alloca i32
  %l23 = alloca i1
  %l25 = alloca { i64, ptr }
  %l27 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 9
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t18, i32 0, i32 4
  %t20 = load { i64, ptr }, ptr %t19
  store { i64, ptr } %t20, ptr %l3, !tbaa !27
  br label %bb5
bb4:
  br label %bb18
bb5:
  %t22 = load i32, ptr %l2
  %t24 = trunc i64 20 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t27 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t31 = icmp eq i64 %t29, 1
  store i1 %t31, ptr %l14, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l14, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l19, !tbaa !29
  %t35 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t35, ptr %l20, !tbaa !27
  %t36 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr ptr, ptr %t37, i64 0
  %t39 = load ptr, ptr %t38, !tbaa !39
  %t41 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t39)
  store i32 %t41, ptr %l22
  br label %bb11
bb10:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb13
bb11:
  %t42 = load ptr, ptr %l19, !tbaa !29
  %t43 = load i32, ptr %l22, !tbaa !23
  %t44 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2evalueArray(ptr %v0, ptr %t42, i32 %t43)
  store i1 %t44, ptr %l23
  br label %bb12
bb12:
  %t45 = load i1, ptr %l23, !tbaa !21
  store i1 %t45, ptr %l18, !tbaa !21
  br label %bb13
bb13:
  %t46 = load i1, ptr %l18, !tbaa !21
  br i1 %t46, label %bb14, label %bb15
bb14:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t48, ptr %l25, !tbaa !27
  %t49 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr ptr, ptr %t50, i64 0
  %t52 = load ptr, ptr %t51, !tbaa !39
  %t55 = call ptr @compiler_2flower_2ecompiler_2flower_3alowering_2eunconvert(ptr %v0, ptr %v1, ptr %t47, ptr %t52)
  store ptr %t55, ptr %l27
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t56 = load ptr, ptr %l27, !tbaa !29
  store ptr %t56, ptr %rv
  br label %ret
bb17:
  br label %bb23
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_d8cada644e10ccc9_6a931382540e069d)
  unreachable
bb23:
  %t57 = load ptr, ptr %l1, !tbaa !29
  store ptr %t57, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2evalueArray(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l8 = alloca i32
  %l11 = alloca i32
  %l14 = alloca i1
  %l17 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/lower:lowering", ptr %a0, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load i32, ptr %l8, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l11
  br label %bb2
bb2:
  %t17 = load i32, ptr %l11
  %t19 = trunc i64 19 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t23 = load i32, ptr %l3, !tbaa !23
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t22, i32 %t23)
  store i32 %t26, ptr %l17
  br label %bb5
bb4:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb6
bb5:
  %t27 = load i32, ptr %l17, !tbaa !23
  %t28 = icmp eq i32 %t27, 0
  store i1 %t28, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t30 = load i1, ptr %l14, !tbaa !21
  store i1 %t30, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2evalueTargets(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l20 = alloca i1
  %l21 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Spawn", ptr %a1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb14
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l14, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  store ptr %t24, ptr %l5, !tbaa !29
  %t26 = load ptr, ptr %l5, !tbaa !29
  %t28 = icmp eq ptr %t26, null
  %t30 = xor i1 %t28, true
  br i1 %t30, label %bb5, label %bb6
bb5:
  store ptr %a0, ptr %l21, !tbaa !29
  %t33 = load ptr, ptr %l5, !tbaa !29
  %t35 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t33)
  store i32 %t35, ptr %l23
  br label %bb7
bb6:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb9
bb7:
  %t36 = load ptr, ptr %l21, !tbaa !29
  %t37 = load i32, ptr %l23, !tbaa !23
  %t38 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2evalueArray(ptr %v0, ptr %t36, i32 %t37)
  store i1 %t38, ptr %l24
  br label %bb8
bb8:
  %t39 = load i1, ptr %l24, !tbaa !21
  store i1 %t39, ptr %l20, !tbaa !21
  br label %bb9
bb9:
  %t40 = load i1, ptr %l20, !tbaa !21
  br i1 %t40, label %bb10, label %bb11
bb10:
  store i1 true, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t42 = load i64, ptr %l3, !tbaa !24
  %t44 = add i64 %t42, 1
  store i64 %t44, ptr %l3, !tbaa !24
  br label %bb1
bb14:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ewiden(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, i32 %a3, %"compiler/source:Span" %a4, { i64, [1 x i64] } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l7 = alloca { i64, [4 x i64] }
  %l8 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca i64
  %l24 = alloca i32
  %l25 = alloca ptr
  %l26 = alloca %"compiler/source:Span"
  %l28 = alloca %"compiler/mir:Lvalue"
  %l36 = alloca ptr
  %l37 = alloca %"compiler/source:Span"
  %l39 = alloca %"compiler/mir:Lvalue"
  %l41 = alloca %"compiler/mir:Lvalue"
  %l46 = alloca %"compiler/mir:Lvalue"
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t21 = alloca { i64, [4 x i64] }, align 8
  %t46 = alloca { i64, [4 x i64] }, align 8
  %t49 = alloca { i64, [15 x i64] }, align 8
  %t61 = alloca { i64, [21 x i64] }, align 8
  %t84 = alloca { i64, [21 x i64] }, align 8
  %t103 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = load i32, ptr %l2, !tbaa !23
  %t4 = load %"compiler/source:Span", ptr %l4
  %t9 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %t1, { i64, [4 x i64] } %a1, i32 %t3, %"compiler/source:Span" %t4)
  store i32 %t9, ptr %l13
  br label %bb1
bb1:
  %t10 = load i32, ptr %l13, !tbaa !23
  store i32 %t10, ptr %l6, !tbaa !23
  %t11 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t11, ptr %l14, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l15, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l2, !tbaa !23
  %t17 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %t13, i32 %t14)
  store i32 %t17, ptr %l18
  br label %bb2
bb2:
  %t18 = load ptr, ptr %l15, !tbaa !29
  %t19 = load i32, ptr %l18, !tbaa !23
  %t20 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2efixedLen(ptr %v0, ptr %t18, i32 %t19)
  store i64 %t20, ptr %l19
  br label %bb3
bb3:
  store { i64, [4 x i64] } zeroinitializer, ptr %t21
  %t22 = getelementptr { i64, [4 x i64] }, ptr %t21, i32 0, i32 0
  store i64 2, ptr %t22
  %t23 = load i32, ptr %l14, !tbaa !23
  %t24 = insertvalue { i32, i64 } undef, i32 %t23, 0
  %t25 = load i64, ptr %l19, !tbaa !24
  %t26 = insertvalue { i32, i64 } %t24, i64 %t25, 1
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t21, i32 0, i32 1
  store { i32, i64 } %t26, ptr %t27
  %t28 = load { i64, [4 x i64] }, ptr %t21
  store { i64, [4 x i64] } %t28, ptr %l7
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i32, ptr %l3, !tbaa !23
  %t32 = load %"compiler/source:Span", ptr %l4
  %t36 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t30, i32 %t31, %"compiler/source:Span" %t32)
  store i32 %t36, ptr %l24
  br label %bb4
bb4:
  %t37 = load i32, ptr %l24, !tbaa !23
  store i32 %t37, ptr %l8, !tbaa !23
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l25, !tbaa !29
  %t39 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t39, ptr %l26
  %t40 = load i32, ptr %l8, !tbaa !23
  %t42 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t40)
  store %"compiler/mir:Lvalue" %t42, ptr %l28
  br label %bb5
bb5:
  %t44 = load i32, ptr %l3, !tbaa !23
  %t45 = load { i64, [4 x i64] }, ptr %l7
  store { i64, [4 x i64] } zeroinitializer, ptr %t46
  %t47 = getelementptr { i64, [4 x i64] }, ptr %t46, i32 0, i32 0
  store i64 0, ptr %t47
  %t48 = load { i64, [4 x i64] }, ptr %t46
  store { i64, [15 x i64] } zeroinitializer, ptr %t49
  %t50 = getelementptr { i64, [15 x i64] }, ptr %t49, i32 0, i32 0
  store i64 8, ptr %t50
  %t52 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } undef, { i64, [1 x i64] } %a5, 0
  %t54 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t52, i32 %t44, 1
  %t56 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t54, { i64, [4 x i64] } %t45, 2
  %t58 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t56, { i64, [4 x i64] } %t48, 3
  %t59 = getelementptr { i64, [15 x i64] }, ptr %t49, i32 0, i32 1
  store { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t58, ptr %t59
  %t60 = load { i64, [15 x i64] }, ptr %t49
  store { i64, [21 x i64] } zeroinitializer, ptr %t61
  %t62 = getelementptr { i64, [21 x i64] }, ptr %t61, i32 0, i32 0
  store i64 0, ptr %t62
  %t63 = load %"compiler/source:Span", ptr %l26
  %t64 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t63, 0
  %t65 = load %"compiler/mir:Lvalue", ptr %l28
  %t66 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t64, %"compiler/mir:Lvalue" %t65, 1
  %t68 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t66, { i64, [15 x i64] } %t60, 2
  %t69 = getelementptr { i64, [21 x i64] }, ptr %t61, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t68, ptr %t69
  %t70 = load { i64, [21 x i64] }, ptr %t61
  %t72 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t70, ptr %t72
  %t73 = load ptr, ptr %l25, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t73, ptr %t72)
  br label %bb6
bb6:
  %t75 = load ptr, ptr %l0, !tbaa !29
  store ptr %t75, ptr %l36, !tbaa !29
  %t76 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t76, ptr %l37
  %t77 = load i32, ptr %l8, !tbaa !23
  %t79 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t77)
  store %"compiler/mir:Lvalue" %t79, ptr %l39
  br label %bb7
bb7:
  %t80 = load i32, ptr %l6, !tbaa !23
  %t82 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t80)
  store %"compiler/mir:Lvalue" %t82, ptr %l41
  br label %bb8
bb8:
  %t83 = load { i64, [4 x i64] }, ptr %l7
  store { i64, [21 x i64] } zeroinitializer, ptr %t84
  %t85 = getelementptr { i64, [21 x i64] }, ptr %t84, i32 0, i32 0
  store i64 10, ptr %t85
  %t86 = load %"compiler/source:Span", ptr %l37
  %t87 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t86, 0
  %t88 = load %"compiler/mir:Lvalue", ptr %l39
  %t89 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } } %t87, %"compiler/mir:Lvalue" %t88, 1
  %t90 = load %"compiler/mir:Lvalue", ptr %l41
  %t91 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } } %t89, %"compiler/mir:Lvalue" %t90, 2
  %t93 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } } %t91, { i64, [4 x i64] } %t83, 3
  %t94 = getelementptr { i64, [21 x i64] }, ptr %t84, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } } %t93, ptr %t94
  %t95 = load { i64, [21 x i64] }, ptr %t84
  %t97 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t95, ptr %t97
  %t98 = load ptr, ptr %l36, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t98, ptr %t97)
  br label %bb9
bb9:
  %t100 = load i32, ptr %l8, !tbaa !23
  %t102 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t100)
  store %"compiler/mir:Lvalue" %t102, ptr %l46
  br label %bb10
bb10:
  store { i64, [4 x i64] } zeroinitializer, ptr %t103
  %t104 = getelementptr { i64, [4 x i64] }, ptr %t103, i32 0, i32 0
  store i64 1, ptr %t104
  %t105 = load %"compiler/mir:Lvalue", ptr %l46
  %t106 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t105, 0
  %t107 = getelementptr { i64, [4 x i64] }, ptr %t103, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t106, ptr %t107
  %t108 = load { i64, [4 x i64] }, ptr %t103
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t108, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ewidening(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l9 = alloca i1
  %l13 = alloca i1
  %l16 = alloca i1
  %l17 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca i1
  %l26 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l30 = alloca i32
  %l31 = alloca i32
  %l34 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l39 = alloca i32
  %l40 = alloca i32
  %l41 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t8 = trunc i64 20 to i32
  %t9 = icmp eq i32 %a1, %t8
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t15 = icmp eq i64 %t13, 1
  store i1 %t15, ptr %l9, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb3
bb3:
  %t17 = load i1, ptr %l9, !tbaa !21
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t22 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2evalueArray(ptr %v0, ptr %t18, i32 %a3)
  store i1 %t22, ptr %l16
  br label %bb6
bb5:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb7
bb6:
  %t23 = load i1, ptr %l16, !tbaa !21
  store i1 %t23, ptr %l13, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l13, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l4, !tbaa !29
  store ptr %t25, ptr %l18, !tbaa !29
  %t26 = load ptr, ptr %l4, !tbaa !29
  store ptr %t26, ptr %l19, !tbaa !29
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t27, ptr %l20, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr ptr, ptr %t29, i64 0
  %t31 = load ptr, ptr %t30, !tbaa !39
  %t33 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t31)
  store i32 %t33, ptr %l22
  br label %bb10
bb9:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb13
bb10:
  %t34 = load ptr, ptr %l19, !tbaa !29
  %t35 = load i32, ptr %l22, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t36, ptr %l23
  br label %bb11
bb11:
  %t37 = load ptr, ptr %l18, !tbaa !29
  %t38 = load i32, ptr %l23, !tbaa !23
  %t39 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t37, i32 %t38)
  store i1 %t39, ptr %l24
  br label %bb12
bb12:
  %t40 = load i1, ptr %l24, !tbaa !21
  %t41 = xor i1 %t40, true
  store i1 %t41, ptr %l17, !tbaa !21
  br label %bb13
bb13:
  %t43 = load i1, ptr %l17, !tbaa !21
  br i1 %t43, label %bb14, label %bb15
bb14:
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l27, !tbaa !29
  %t45 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t45, ptr %l28, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr ptr, ptr %t47, i64 0
  %t49 = load ptr, ptr %t48, !tbaa !39
  %t51 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t49)
  store i32 %t51, ptr %l30
  br label %bb16
bb15:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb18
bb16:
  %t52 = load ptr, ptr %l27, !tbaa !29
  %t53 = load i32, ptr %l30, !tbaa !23
  %t54 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %t52, i32 %t53)
  store i32 %t54, ptr %l31
  br label %bb17
bb17:
  %t55 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t56 = load i32, ptr %l31, !tbaa !23
  %t58 = icmp ne i32 %t56, %t55
  store i1 %t58, ptr %l26, !tbaa !21
  br label %bb18
bb18:
  %t60 = load i1, ptr %l26, !tbaa !21
  br i1 %t60, label %bb19, label %bb20
bb19:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l35, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  store ptr %t62, ptr %l36, !tbaa !29
  %t63 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t63, ptr %l37, !tbaa !27
  %t64 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = getelementptr ptr, ptr %t65, i64 0
  %t67 = load ptr, ptr %t66, !tbaa !39
  %t69 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t67)
  store i32 %t69, ptr %l39
  br label %bb21
bb20:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb24
bb21:
  %t70 = load ptr, ptr %l36, !tbaa !29
  %t71 = load i32, ptr %l39, !tbaa !23
  %t72 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %t70, i32 %t71)
  store i32 %t72, ptr %l40
  br label %bb22
bb22:
  %t73 = load ptr, ptr %l35, !tbaa !29
  %t74 = load i32, ptr %l40, !tbaa !23
  %t75 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2efixedLen(ptr %v0, ptr %t73, i32 %t74)
  store i64 %t75, ptr %l41
  br label %bb23
bb23:
  %t76 = load i64, ptr %l41, !tbaa !24
  %t77 = icmp sge i64 %t76, 0
  store i1 %t77, ptr %l34, !tbaa !21
  br label %bb24
bb24:
  %t79 = load i1, ptr %l34, !tbaa !21
  store i1 %t79, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/lower:pl" %a1, { i64, [1 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/lower:pl"
  %lp3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l8 = alloca %"compiler/lower:pl"
  %l10 = alloca i64
  %l12 = alloca i64
  %l17 = alloca { i64, [1 x i64] }
  %rv = alloca %"compiler/lower:pl"
  store ptr %a0, ptr %l0
  store %"compiler/lower:pl" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/lower:pl", ptr %l1, i32 0, i32 0
  %t2 = load { i64, [2 x i64] }, ptr %t1
  %t4 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %v2, { i64, [2 x i64] } %t2)
  store %"compiler/lower:pl" %t4, ptr %l8
  br label %bb1
bb1:
  %t5 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t5, ptr %lp3
  %t6 = load %"compiler/lower:pl", ptr %l8
  %t7 = load ptr, ptr %lp3
  store %"compiler/lower:pl" %t6, ptr %t7
  %t8 = getelementptr %"compiler/lower:pl", ptr %l1, i32 0, i32 1
  store ptr %t8, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t10 = load i64, ptr %l5, !tbaa !24
  store i64 %t10, ptr %l10, !tbaa !24
  %t11 = load ptr, ptr %l4, !tbaa !29
  %t13 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eLen_3ccompiler_2fmir_3aProj_3e(ptr %v1, ptr %t11)
  store i64 %t13, ptr %l12
  br label %bb3
bb3:
  %t14 = load i64, ptr %l10, !tbaa !24
  %t15 = load i64, ptr %l12, !tbaa !24
  %t16 = icmp slt i64 %t14, %t15
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb4, label %bb5
bb4:
  br label %bb10
bb5:
  br label %bb6
bb6:
  %t20 = load ptr, ptr %l4, !tbaa !29
  %t21 = load i64, ptr %l5, !tbaa !24
  %t24 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %v1, ptr %t20, i64 %t21)
  store { i64, [1 x i64] } %t24, ptr %l17
  br label %bb7
bb7:
  %t25 = load { i64, [1 x i64] }, ptr %l17
  %t26 = load ptr, ptr %lp3
  %t27 = getelementptr %"compiler/lower:pl", ptr %t26, i32 0, i32 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2ePush_3ccompiler_2fmir_3aProj_3e(ptr %v2, ptr %t27, { i64, [1 x i64] } %t25)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t31 = load i64, ptr %l5, !tbaa !24
  %t33 = add i64 %t31, 1
  store i64 %t33, ptr %l5, !tbaa !24
  br label %bb2
bb10:
  %t35 = load ptr, ptr %lp3
  %t36 = getelementptr %"compiler/lower:pl", ptr %t35, i32 0, i32 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2ePush_3ccompiler_2fmir_3aProj_3e(ptr %v2, ptr %t36, { i64, [1 x i64] } %a2)
  br label %bb11
bb11:
  %t40 = load ptr, ptr %lp3
  %t41 = load %"compiler/lower:pl", ptr %t40
  store %"compiler/lower:pl" %t41, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:pl", ptr %rv
  ret %"compiler/lower:pl" %rr
}

define dso_local ptr @compiler_2flower_2econvertArg(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %l9 = alloca { i64, ptr }
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 9
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t12, i32 0, i32 4
  %t14 = load { i64, ptr }, ptr %t13
  store { i64, ptr } %t14, ptr %l1, !tbaa !27
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t16, ptr %l9, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr ptr, ptr %t18, i64 0
  %t20 = load ptr, ptr %t19, !tbaa !39
  store ptr %t20, ptr %l2, !tbaa !29
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_e6acc166178563a1_2a0e2f77fd7658ed)
  unreachable
bb11:
  %t24 = load ptr, ptr %l2, !tbaa !29
  store ptr %t24, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2flower_2ederefOf(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t17 = load ptr, ptr %l11, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l11, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 2
  store i1 %t23, ptr %l12, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t27, i32 0, i32 2
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l2, !tbaa !29
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t31 = load ptr, ptr %l2, !tbaa !29
  store ptr %t31, ptr %l10, !tbaa !29
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store ptr null, ptr %l10, !tbaa !29
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_eebb62a013643219_b45f662b48cacfad)
  unreachable
bb16:
  %t34 = load ptr, ptr %l10, !tbaa !29
  store ptr %t34, ptr %l3, !tbaa !29
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store ptr null, ptr %l3, !tbaa !29
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_18ba96ebd2acdd48_1f3e7581818ceffc)
  unreachable
bb22:
  %t35 = load ptr, ptr %l3, !tbaa !29
  store ptr %t35, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/lower:level" @compiler_2flower_3alevel_2ector(ptr %v0, i32 %a0, i32 %a1, i32 %a2) #0 {
entry:
  %rv = alloca %"compiler/lower:level"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/lower:level" undef, i32 %a0, 0
  %t10 = insertvalue %"compiler/lower:level" %t8, i32 %a1, 1
  %t12 = insertvalue %"compiler/lower:level" %t10, i32 %a2, 2
  store %"compiler/lower:level" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:level", ptr %rv
  ret %"compiler/lower:level" %rr
}

define dso_local %"compiler/lower:loopCtx" @compiler_2flower_3aloopCtx_2ector(ptr %v0, i32 %a0, i64 %a1) #0 {
entry:
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/lower:loopCtx"
  br label %start
start:
  br label %bb0
bb0:
  store i32 %a0, ptr %l2, !tbaa !23
  store i64 %a1, ptr %l3, !tbaa !24
  %t5 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  store i32 %t5, ptr %l4, !tbaa !23
  %t7 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l10
  br label %bb1
bb1:
  %t8 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %l5
  %t9 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %l11
  br label %bb2
bb2:
  %t10 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  %t11 = load i32, ptr %l2, !tbaa !23
  %t12 = insertvalue %"compiler/lower:loopCtx" undef, i32 %t11, 0
  %t13 = load i64, ptr %l3, !tbaa !24
  %t14 = insertvalue %"compiler/lower:loopCtx" %t12, i64 %t13, 1
  %t15 = load i32, ptr %l4, !tbaa !23
  %t16 = insertvalue %"compiler/lower:loopCtx" %t14, i32 %t15, 2
  %t17 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l5
  %t18 = insertvalue %"compiler/lower:loopCtx" %t16, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, 3
  %t20 = insertvalue %"compiler/lower:loopCtx" %t18, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, 4
  store %"compiler/lower:loopCtx" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:loopCtx", ptr %rv
  ret %"compiler/lower:loopCtx" %rr
}

define dso_local %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %v0, { i64, [2 x i64] } %a0) #0 {
entry:
  %l1 = alloca { i64, [2 x i64] }
  %l4 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/lower:pl"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, [2 x i64] } %a0, ptr %l1
  %t3 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l4
  %t5 = load { i64, [2 x i64] }, ptr %l1
  %t6 = insertvalue %"compiler/lower:pl" undef, { i64, [2 x i64] } %t5, 0
  %t8 = insertvalue %"compiler/lower:pl" %t6, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, 1
  store %"compiler/lower:pl" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:pl", ptr %rv
  ret %"compiler/lower:pl" %rr
}

define dso_local %"compiler/lower:tryCtx" @compiler_2flower_3atryCtx_2ector(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1, i1 %a2, i1 %a3) #0 {
entry:
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i1
  %l7 = alloca i1
  %l13 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/lower:tryCtx"
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a0, ptr %l4, !tbaa !24
  store { i64, ptr } %a1, ptr %l5, !tbaa !27
  store i1 %a2, ptr %l6, !tbaa !21
  store i1 %a3, ptr %l7, !tbaa !21
  %t9 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %l13
  br label %bb1
bb1:
  %t10 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = insertvalue %"compiler/lower:tryCtx" undef, i64 %t11, 0
  %t13 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t14 = insertvalue %"compiler/lower:tryCtx" %t12, { i64, ptr } %t13, 1
  %t15 = load i1, ptr %l6, !tbaa !21
  %t16 = insertvalue %"compiler/lower:tryCtx" %t14, i1 %t15, 2
  %t17 = load i1, ptr %l7, !tbaa !21
  %t18 = insertvalue %"compiler/lower:tryCtx" %t16, i1 %t17, 3
  %t20 = insertvalue %"compiler/lower:tryCtx" %t18, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, 4
  store %"compiler/lower:tryCtx" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:tryCtx", ptr %rv
  ret %"compiler/lower:tryCtx" %rr
}

define dso_local void @olang_2einit_2ecompiler_2flower() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2flower_2eOutOfBounds_2einit()
  br label %bb1
bb1:
  call void @compiler_2flower_2eOverflow_2einit()
  br label %bb2
bb2:
  call void @compiler_2flower_2eInvalid_2einit()
  br label %bb3
bb3:
  call void @compiler_2flower_2eWrongCase_2einit()
  br label %bb4
bb4:
  call void @compiler_2flower_2eContract_2einit()
  br label %bb5
bb5:
  call void @compiler_2flower_2eEmpty_2einit()
  br label %bb6
bb6:
  call void @compiler_2flower_2eFailIds_2einit()
  br label %bb7
bb7:
  call void @compiler_2flower_2eFailTypes_2einit()
  br label %bb8
bb8:
  call void @compiler_2flower_2eFailWords_2einit()
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

@.d0 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"OUT_OF_RANGE" }>, align 8
@.d1 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"OVERFLOW" }>, align 8
@.d2 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"INVALID" }>, align 8
@.d3 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"WRONG_CASE" }>, align 8
@.d4 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"INVALID" }>, align 8
@.d5 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"EMPTY" }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d6 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"std/prelude/iterator" }>, align 8
@.d7 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"Exhausted" }>, align 8
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d8 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d9 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@.d10 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d11 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"std/prelude/text" }>, align 8
@.d12 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"String" }>, align 8
@.d13 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @__olang_ert_req_clear()
@.d14 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d15 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"..." }>, align 8
@.d16 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"a spawn outside a join" }>, align 8
@.d17 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"a task that is no call" }>, align 8
@.d18 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d19 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"mut " }>, align 8
@.d20 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d21 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"?&" }>, align 8
@.d22 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"&" }>, align 8
@.d23 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"any " }>, align 8
@.d24 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Array<" }>, align 8
@.d25 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c">" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d26 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d27 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"fn" }>, align 8
@.d28 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d29 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d30 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d31 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d32 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d33 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" ?" }>, align 8
@.d34 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d35 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d36 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Str" }>, align 8
@.d37 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"str" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@olang_loc_9dd6f9307adcfcd5_1dbcb3e322355069 = external constant [0 x i8]
@olang_loc_7df9a24eda8a923d_42e903e9e9d8e7b1 = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2fmir_3aFn_2ector(ptr %out, ptr %v0, { i64, [2 x i64] } %a0, i32 %a1, i64 %a2, %"compiler/source:Span" %a3)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eLen_3cI32_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eAt_3cI32_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2ePush_3cI32_3e(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fmir_2eErrorCode(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3)
declare void @compiler_2flower_3alowering_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, ptr %a3)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eLen_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_f8b3706059fec8c0_d163f284ba6a3ccc = external constant [0 x i8]
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eFrees(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2erun(ptr %v0, ptr %a0)
declare void @compiler_2flower_2ecompiler_2flower_3aLowerer_2ehelper(ptr %out, ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eadapterFn(ptr %out, ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eanyRender(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1, i1 %a2)
@olang_loc_3c213ca88cac8ac4_ee776128d38d19e0 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eVerify(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eDump(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fload_2eErrQualifier(ptr %v0, ptr %v1, { i64, ptr } %a0, i1 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnnamed(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5)
declare void @compiler_2flower_2estandIn(ptr %out, ptr %v0, i32 %a0)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eprologue(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %a0)
@G_2ecompiler_2fmir_2eEmpty = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fmir_2eNoPlace = available_externally constant <{ [32 x i8] }> <{ [32 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
@G_2ecompiler_2fmir_2eNoLocal = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2fmir_2eNoBlock = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
declare %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %v0, { i64, [7 x i64] } %a0, %"compiler/mir:Range" %a1, %"compiler/mir:Range" %a2, %"compiler/mir:Lvalue" %a3, i1 %a4, i32 %a5, i32 %a6, i32 %a7)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v0, ptr %a0, %"compiler/mir:Call" %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_6409d1aa34b20bea_1e68de4bb2ab27de = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddParam(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3)
declare %"compiler/mir:Local" @compiler_2fmir_3aLocal_2ector(ptr %v0, i32 %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, { i64, [1 x i64] } %a4)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddLocal(ptr %v0, ptr %a0, %"compiler/mir:Local" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2ePush_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2ePush_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2fmir_2eNoScope = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddScope(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, %"compiler/source:Span" %a4, i32 %a5)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2ePush_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %a0, %"compiler/lower:level" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0)
@olang_loc_f03a362eaee136d1_c4ccf5bb34eed07d = external constant [0 x i8]
declare %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
@G_2ecompiler_2fmir_2eI32T = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\05\00\00\00" }>, align 8
declare %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eleave(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_8a5ba3d76fdc22ed_b870bfe3eff73029 = external constant [0 x i8]
declare %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eScopeRefs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2ector(ptr %v0, i64 %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2ePush_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2etextData(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, %"compiler/source:Span" %a2)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eToArray_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i32, i64 } @compiler_2flower_2ecompiler_2flower_3aLowerer_2efailure(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2edispatch(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %a3, i1 %a4)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eSetAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlock_26_3e_2eAt_3ccompiler_2ftyped_3aBlock_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2fmir_2eI64T = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\06\00\00\00" }>, align 8
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, { i64, ptr } %a3, %"compiler/source:Span" %a4)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopiesValue(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
declare i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %a3)
declare %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eplace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"compiler/mir:Lvalue" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:pl" %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2easI64(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %a3)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2ebounds(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, { i64, [4 x i64] } %a2, i1 %a3, i32 %a4, i32 %a5, %"compiler/source:Span" %a6)
@olang_loc_ee7cb6b84b4996f0_d216e2901020b0e4 = external constant [0 x i8]
declare void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v0, ptr %a0, i32 %a1, { i64, [8 x i64] } %a2)
declare %"compiler/lower:level" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eAt_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2erunDefers(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2ejoinFailed(ptr %v0, ptr %a0, i64 %a1, i32 %a2, { i64, [4 x i64] } %a3, i32 %a4, %"compiler/source:Span" %a5)
declare { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einnermost(ptr %v0, ptr %a0)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ewidens(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eadapter(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, i32 %a3, i32 %a4, %"compiler/source:Span" %a5)
@olang_loc_a9ad50b63422a08e_67259be34391ceea = external constant [0 x i8]
declare i32 @compiler_2fmir_2eHelperType(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eWant(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ector(ptr %v0, i64 %a0)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eleaveOpen(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_64d900b05c2c7f2b_3f776bda77e5f7cf = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstBool(ptr %v0, ptr %a0, i1 %a1, %"compiler/source:Span" %a2)
declare %"compiler/mir:Lvalue" @compiler_2fmir_2ecompiler_2fmir_3aFn_2ePlace(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1, { i64, ptr } %a2)
declare { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ebuilt(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_8dbdd81ef51b3d23_89b419ac5748f287 = external constant [0 x i8]
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2earrayCopy(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %a3, { i64, [1 x i64] } %a4)
declare %"compiler/mir:Range" @compiler_2flower_2ecompiler_2flower_3alowering_2ecapScopes(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2evals(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2earrayLit(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3, i1 %a4, { i64, [1 x i64] } %a5)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2efill(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3, i1 %a4, { i64, [1 x i64] } %a5)
@olang_loc_c00faf6434efe24b_96f261c8870620df = external constant [0 x i8]
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_b551419724d67aba_25293d2489abf656 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2eLen_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2eAt_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/mir:Case" @compiler_2fmir_3aCase_2ector(ptr %v0, i64 %a0, i32 %a1)
@olang_loc_f77986af895aed4f_f84e497584b75763 = external constant [0 x i8]
@olang_loc_4d7f91a5420115fa_db913b05a0de57ee = external constant [0 x i8]
declare %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCases(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eanyMake(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2, %"compiler/source:Span" %a3)
@olang_loc_b3ebf7d55c86e124_fe3d33fa802e84b8 = external constant [0 x i8]
declare i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2flower_2ecompiler_2flower_3alowering_2efixedLen(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_fcf54f1de4315015_3c2061767d7aa89 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eprimChecks(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, i32 %a2, { i64, ptr } %a3, { i64, ptr } %a4, i32 %a5, %"compiler/source:Span" %a6)
declare ptr @compiler_2flower_2ecollectOf(ptr %v0, ptr %a0)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_f5162d6fd39a8c0b_7722e13858f6fdef = external constant [0 x i8]
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ecollect(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
@olang_loc_3c6cf9f7cb6c21ca_21635d3489f6812e = external constant [0 x i8]
@olang_loc_deec9e883dfec261_7ab86f6deb3822e5 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fmir_3aLocalId_3e_2_H1e3bc46345ebb5614acbe688055fe55f(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2escopeRef(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fmir_3aLocalId_3e_2_H6363fee5e3f1c076b4ec00933ab48c6c(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_b05049138e3c9583_5b10da44a83c4f97 = external constant [0 x i8]
@olang_loc_7978ceed25dd57db_b68e0a2baf6deaf = external constant [0 x i8]
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eSolePlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsHandle(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_6cf042e1e67efefa_11456615317dde16 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eSoleLeaves(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %a0)
declare %"compiler/free:leaf" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eAt_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_16ea37ec2dd8d64f_b36c061d5e238e2b = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsAny(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2erenderErr(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1, { i64, [4 x i64] } %a2, i32 %a3, %"compiler/source:Span" %a4)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eisChar(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eisText(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eword(ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eLen_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %a0)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %a0)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2egap(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
@olang_loc_1f89626f934b863_cae48f8c5308207f = external constant [0 x i8]
@olang_loc_bd186c5d6cd7a57b_c31a7bfdd180fca7 = external constant [0 x i8]
declare i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etaskType(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/mir:Range" @compiler_2fmir_3aRange_2ector(ptr %v0, i32 %a0, i32 %a1)
declare %"compiler/mir:Lvalue" @compiler_2fmir_3aLvalue_2ector(ptr %v0, { i64, [2 x i64] } %a0, %"compiler/mir:Range" %a1)
@olang_loc_50381a907c443937_a4d06b271538b33b = external constant [0 x i8]
declare { { i64, [7 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2ecallee(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
declare %"compiler/mir:Range" @compiler_2flower_2ecompiler_2flower_3alowering_2eargs(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [7 x i64] } %a2, i32 %a3)
declare { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_400575d530dd6291_b9c64e3b22c571dd = external constant [0 x i8]
declare %"compiler/mir:TaskClause" @compiler_2fmir_3aTaskClause_2ector(ptr %v0, %"compiler/mir:Range" %a0, i1 %a1, { i64, [4 x i64] } %a2)
@olang_loc_956aeda6c669b3b5_1d6c951e348c7771 = external constant [0 x i8]
declare %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddItems(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_be92bcaa720f0648_1d4634382d4dfc64 = external constant [0 x i8]
declare { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eplaceStorage(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %a0, { i64, [7 x i64] } %a1, i32 %a2)
declare %"compiler/mir:Range" @compiler_2flower_2ecompiler_2flower_3alowering_2epassed(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTask(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [7 x i64] } %a1, %"compiler/mir:Range" %a2, %"compiler/mir:Range" %a3, { i64, ptr } %a4, { i64, ptr } %a5, %"compiler/mir:Range" %a6, %"compiler/source:Span" %a7, %"compiler/mir:Range" %a8)
@olang_loc_e3f6d6028e0207dc_be5b0d4cacd6b290 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eNullable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2flower_2ecompiler_2flower_3aLowerer_2eErrValSpelling(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesOf(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__Hccd9659a44f570da1fa06b019882a84d(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ePush_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3atryCtx_3e_2ePush_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:tryCtx" %a1)
declare { i32, %"compiler/lower:tryCtx" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3atryCtx_3e_2ePop_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_2157f043f9fed58b_cfe589e7cd689437 = external constant [0 x i8]
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2ereleaseAt(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, %"compiler/source:Span" %a3)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eclauses(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/lower:tryCtx" %a1, { i64, ptr } %a2, i32 %a3, i32 %a4, ptr %a5)
@olang_loc_d8cada644e10ccc9_6a931382540e069d = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eLen_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %a0)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2ePush_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
@olang_loc_e6acc166178563a1_2a0e2f77fd7658ed = external constant [0 x i8]
@olang_loc_eebb62a013643219_b45f662b48cacfad = external constant [0 x i8]
@olang_loc_18ba96ebd2acdd48_1f3e7581818ceffc = external constant [0 x i8]
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2ector(ptr %v0, i64 %a0)
declare void @compiler_2flower_2eOutOfBounds_2einit()
declare void @compiler_2flower_2eOverflow_2einit()
declare void @compiler_2flower_2eInvalid_2einit()
declare void @compiler_2flower_2eContract_2einit()
declare void @compiler_2flower_2eEmpty_2einit()
declare void @compiler_2flower_2eFailIds_2einit()
declare void @compiler_2flower_2eFailTypes_2einit()

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
