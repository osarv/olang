; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"std/os:FileInfo" = type { i32, i64, i64 }
%"compiler/build:Held" = type { { i64, ptr }, { i64, ptr }, i64, i64 }
%"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33" = type { i64, { i64, ptr }, i64, i64, i64, i1, i64, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"<pthread.h>:pthread_mutex_t", %"<pthread.h>:pthread_cond_t", %"<pthread.h>:pthread_cond_t" }
%"<pthread.h>:pthread_mutex_t" = type { [5 x i64] }
%"<pthread.h>:pthread_cond_t" = type { [6 x i64] }
%"std/os:Output" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/build:Config" = type { { i64, ptr }, { i64, ptr }, %"compiler/target:Target", %"compiler/cond:Consts", i1, i1, i1, i1, i1, i1, i1, i1, { i64, ptr }, i1, i1, i1, { i64, ptr }, i64, i1, i1, i1, i64, i1, { i64, ptr }, i1, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i1, { i64, ptr }, { i64, ptr }, i64, i64, i1, i1, { i64, ptr }, { i64, ptr } }
%"compiler/target:Target" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i1, i1, i1, i1, i64, { i64, ptr } }
%"compiler/cond:Consts" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/diagmsg:Msg" = type { i32, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/build:compiles" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/build:Program" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/build:Unit" = type { { i64, ptr }, i32, { i64, ptr }, { i64, ptr }, { i64, ptr }, i64 }
%"compiler/build:Sha256" = type { [8 x i32], [64 x i8], i64, i64 }
%"compiler/build:stubFrontend" = type { i64, i64 }
%"compiler/build:Listed" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
define dso_local { i64, ptr } @compiler_2fbuild_2eAnalysisDir(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca i1
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i32
  %l20 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i32
  %l28 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l42 = alloca { i64, ptr }
  %l47 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l51 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l52 = alloca { i64, ptr }
  %l53 = alloca ptr
  %l54 = alloca ptr
  %l55 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i1 %t3, ptr %l8
  br label %bb1
bb1:
  %t4 = load i1, ptr %l8, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %s0, { i64, ptr } %t7)
  %t10 = extractvalue { i32, { i64, ptr } } %t9, 1
  %t11 = extractvalue { i32, { i64, ptr } } %t9, 0
  store i32 %t11, ptr %l14
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb5, label %ok.13, !prof !99
ok.13:
  store { i64, ptr } %t10, ptr %l13
  br label %bb4
bb3:
  %t14 = call { i32, { i64, ptr } } @std_2fos_2eCwd(ptr %s0)
  %t15 = extractvalue { i32, { i64, ptr } } %t14, 1
  %t16 = extractvalue { i32, { i64, ptr } } %t14, 0
  store i32 %t16, ptr %l24
  %t17 = icmp ne i32 %t16, 0
  br i1 %t17, label %bb12, label %ok.18, !prof !99
ok.18:
  store { i64, ptr } %t15, ptr %l23
  br label %bb11
bb4:
  %t19 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t19, ptr %l11, !tbaa !27
  br label %bb9
bb5:
  %t20 = load i32, ptr %l14, !tbaa !23
  %t21 = ashr i32 %t20, 16
  %t23 = icmp eq i32 %t21, 1
  br i1 %t23, label %bb6, label %bb7
bb6:
  call void @__olang_errpay_pop()
  br label %bb7
bb7:
  br label %bb8
bb8:
  %t25 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 1
  %t28 = extractvalue { i64, ptr } %t25, 0
  %t29 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t27, i64 %t28)
  %t30 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  store { i64, ptr } %t31, ptr %l11, !tbaa !27
  br label %bb9
bb9:
  %t34 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t35 = call { i64, ptr } @std_2ffilepath_2eDir(ptr %s0, ptr %s0, { i64, ptr } %t34)
  store { i64, ptr } %t35, ptr %l20
  br label %bb10
bb10:
  %t36 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 1
  %t38 = extractvalue { i64, ptr } %t36, 0
  %t39 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t38)
  call void @olang_textcopy(ptr %t39, ptr %t37, i64 %t38)
  %t40 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  store { i64, ptr } %t41, ptr %l10, !tbaa !27
  br label %bb17
bb11:
  %t43 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t43, ptr %l22, !tbaa !27
  br label %bb16
bb12:
  %t44 = load i32, ptr %l24, !tbaa !23
  %t45 = ashr i32 %t44, 16
  %t47 = icmp eq i32 %t45, 1
  br i1 %t47, label %bb13, label %bb14
bb13:
  call void @__olang_errpay_pop()
  br label %bb14
bb14:
  br label %bb15
bb15:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l22, !tbaa !27
  br label %bb16
bb16:
  %t49 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 1
  %t51 = extractvalue { i64, ptr } %t49, 0
  %t52 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t51)
  call void @olang_textcopy(ptr %t52, ptr %t50, i64 %t51)
  %t53 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  store { i64, ptr } %t54, ptr %l10, !tbaa !27
  br label %bb17
bb17:
  %t56 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t56, ptr %l1, !tbaa !27
  %t57 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t57, ptr %l28
  br label %bb18
bb18:
  %t58 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l28
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t58, ptr %l2
  %t59 = load { i64, ptr }, ptr %l1, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } %t59)
  br label %bb19
bb19:
  %t62 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t64 = call { i64, ptr } @std_2ffilepath_2eBase(ptr %s0, ptr %s0, { i64, ptr } %t62)
  store { i64, ptr } %t64, ptr %l32
  br label %bb20
bb20:
  %t65 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t66 = call { i64, ptr } @compiler_2fbuild_2eReadable(ptr %s0, ptr %s0, { i64, ptr } %t65)
  store { i64, ptr } %t66, ptr %l33
  br label %bb21
bb21:
  %t68 = call { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %s0, ptr %s0, ptr %l2)
  store { i64, ptr } %t68, ptr %l35
  br label %bb22
bb22:
  %t69 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 0
  store i64 %t70, ptr %l36, !tbaa !24
  %t71 = icmp sge i64 0, 0
  br i1 %t71, label %bb23, label %bb24
bb23:
  %t73 = icmp sle i64 0, 16
  br i1 %t73, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_dcb60eb4101256c1_b0bcaebfd2588235)
  unreachable
bb25:
  %t75 = load i64, ptr %l36, !tbaa !24
  %t76 = icmp sle i64 16, %t75
  br i1 %t76, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_dcb60eb4101256c1_b0bcaebfd2588235)
  unreachable
bb27:
  %t78 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr i8, ptr %t79, i64 0
  %t81 = sub i64 16, 0
  %t82 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t80, 1
  %t84 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t84, 1
  %t86 = extractvalue { i64, ptr } %t84, 0
  %t87 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t88 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t89 = add i64 %t86, %t88
  %t91 = extractvalue { i64, ptr } %t83, 1
  %t92 = extractvalue { i64, ptr } %t83, 0
  %t93 = add i64 %t89, %t92
  %t94 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t93)
  call void @olang_textcopy(ptr %t94, ptr %t85, i64 %t86)
  %t95 = getelementptr i8, ptr %t94, i64 %t86
  call void @olang_textcopy(ptr %t95, ptr %t87, i64 %t88)
  %t96 = getelementptr i8, ptr %t95, i64 %t88
  call void @olang_textcopy(ptr %t96, ptr %t91, i64 %t92)
  %t97 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t94, 1
  store { i64, ptr } %t98, ptr %l3, !tbaa !27
  %t100 = call { i64, ptr } @compiler_2fbuild_2eCacheDir(ptr %s0, ptr %s0, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store { i64, ptr } %t100, ptr %l42
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_dcb60eb4101256c1_b0bcaebfd2588235)
  unreachable
bb29:
  %t101 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t101, ptr %l4, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t102, 1
  %t106 = extractvalue { i64, ptr } %t102, 0
  %t107 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t108 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t109 = add i64 %t106, %t108
  %t111 = extractvalue { i64, ptr } %t103, 1
  %t112 = extractvalue { i64, ptr } %t103, 0
  %t113 = add i64 %t109, %t112
  %t114 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t113)
  call void @olang_textcopy(ptr %t114, ptr %t105, i64 %t106)
  %t115 = getelementptr i8, ptr %t114, i64 %t106
  call void @olang_textcopy(ptr %t115, ptr %t107, i64 %t108)
  %t116 = getelementptr i8, ptr %t115, i64 %t108
  call void @olang_textcopy(ptr %t116, ptr %t111, i64 %t112)
  %t117 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t114, 1
  call void @compiler_2fbuild_2eTouch(ptr %s0, { i64, ptr } %t118)
  br label %bb30
bb30:
  %t121 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t121, ptr %l47
  br label %bb31
bb31:
  %t122 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l47
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t122, ptr %l5
  %t123 = load { i64, ptr }, ptr %l3, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %s0, ptr %s0, ptr %l5, { i64, ptr } %t123, i1 true)
  br label %bb32
bb32:
  %t126 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t128 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbuild_2eHoldings(ptr %s0, ptr %s0, { i64, ptr } %t126, i64 0, i1 true)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t128, ptr %l51
  br label %bb33
bb33:
  %t129 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l51
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t129, ptr %l6
  %t130 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t130, ptr %l52, !tbaa !27
  store ptr %l6, ptr %l53, !tbaa !29
  store ptr %l5, ptr %l54, !tbaa !29
  %t131 = call i64 @compiler_2fbuild_2eRecent()
  store i64 %t131, ptr %l55
  br label %bb34
bb34:
  %t132 = load i64, ptr @G_2ecompiler_2fbuild_2eAnalysisCacheCap, !tbaa !24
  %t133 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t134 = load ptr, ptr %l53, !tbaa !29
  %t135 = load ptr, ptr %l54, !tbaa !29
  %t136 = load i64, ptr %l55, !tbaa !24
  call void @compiler_2fbuild_2eTrim(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t133, ptr %t134, ptr %t135, i64 %t136, i64 %t132)
  br label %bb35
bb35:
  %t138 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t139 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t138, 1
  %t142 = extractvalue { i64, ptr } %t138, 0
  %t143 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t144 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t145 = add i64 %t142, %t144
  %t147 = extractvalue { i64, ptr } %t139, 1
  %t148 = extractvalue { i64, ptr } %t139, 0
  %t149 = add i64 %t145, %t148
  %t150 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t149)
  call void @olang_textcopy(ptr %t150, ptr %t141, i64 %t142)
  %t151 = getelementptr i8, ptr %t150, i64 %t142
  call void @olang_textcopy(ptr %t151, ptr %t143, i64 %t144)
  %t152 = getelementptr i8, ptr %t151, i64 %t144
  call void @olang_textcopy(ptr %t152, ptr %t147, i64 %t148)
  %t153 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t154 = insertvalue { i64, ptr } %t153, ptr %t150, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t154, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2eCacheDir(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l7 = alloca i1
  %l11 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l20 = alloca i1
  %l24 = alloca i1
  %l29 = alloca { i64, ptr }
  %l30 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d6, i32 0, i32 1) })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l5
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  store { i64, ptr } %t2, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  br label %bb6
bb2:
  %t7 = load i32, ptr %l5, !tbaa !23
  %t8 = ashr i32 %t7, 16
  %t10 = icmp eq i32 %t8, 1
  store i1 %t10, ptr %l7, !tbaa !21
  %t11 = load i32, ptr %l5, !tbaa !23
  %t12 = ashr i32 %t11, 16
  %t14 = icmp eq i32 %t12, 1
  br i1 %t14, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr %l3, !tbaa !27
  br label %bb6
bb6:
  %t16 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t16, ptr %l1, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t17, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store i1 %t19, ptr %l11
  br label %bb7
bb7:
  %t20 = load i1, ptr %l11, !tbaa !21
  %t21 = xor i1 %t20, true
  br i1 %t21, label %bb8, label %bb9
bb8:
  %t23 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t23, 1
  %t27 = extractvalue { i64, ptr } %t23, 0
  %t28 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t29 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t30 = add i64 %t27, %t29
  %t32 = extractvalue { i64, ptr } %t24, 1
  %t33 = extractvalue { i64, ptr } %t24, 0
  %t34 = add i64 %t30, %t33
  %t35 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t34)
  call void @olang_textcopy(ptr %t35, ptr %t26, i64 %t27)
  %t36 = getelementptr i8, ptr %t35, i64 %t27
  call void @olang_textcopy(ptr %t36, ptr %t28, i64 %t29)
  %t37 = getelementptr i8, ptr %t36, i64 %t29
  call void @olang_textcopy(ptr %t37, ptr %t32, i64 %t33)
  %t38 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t35, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t39, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t41 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d10, i32 0, i32 1) })
  %t42 = extractvalue { i32, { i64, ptr } } %t41, 1
  %t43 = extractvalue { i32, { i64, ptr } } %t41, 0
  store i32 %t43, ptr %l18
  %t44 = icmp ne i32 %t43, 0
  br i1 %t44, label %bb12, label %ok.45, !prof !99
ok.45:
  store { i64, ptr } %t42, ptr %l17
  br label %bb11
bb11:
  %t46 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t46, ptr %l16, !tbaa !27
  br label %bb16
bb12:
  %t47 = load i32, ptr %l18, !tbaa !23
  %t48 = ashr i32 %t47, 16
  %t50 = icmp eq i32 %t48, 1
  store i1 %t50, ptr %l20, !tbaa !21
  %t51 = load i32, ptr %l18, !tbaa !23
  %t52 = ashr i32 %t51, 16
  %t54 = icmp eq i32 %t52, 1
  br i1 %t54, label %bb13, label %bb14
bb13:
  call void @__olang_errpay_pop()
  br label %bb14
bb14:
  br label %bb15
bb15:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d11, i32 0, i32 1) }, ptr %l16, !tbaa !27
  br label %bb16
bb16:
  %t56 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t56, ptr %l2, !tbaa !27
  %t57 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t59 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t57, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i1 %t59, ptr %l24
  br label %bb17
bb17:
  %t60 = load i1, ptr %l24, !tbaa !21
  %t61 = xor i1 %t60, true
  br i1 %t61, label %bb18, label %bb19
bb18:
  %t63 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t63, 1
  %t67 = extractvalue { i64, ptr } %t63, 0
  %t68 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t69 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t70 = add i64 %t67, %t69
  %t72 = extractvalue { i64, ptr } %t64, 1
  %t73 = extractvalue { i64, ptr } %t64, 0
  %t74 = add i64 %t70, %t73
  %t75 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t74)
  call void @olang_textcopy(ptr %t75, ptr %t66, i64 %t67)
  %t76 = getelementptr i8, ptr %t75, i64 %t67
  call void @olang_textcopy(ptr %t76, ptr %t68, i64 %t69)
  %t77 = getelementptr i8, ptr %t76, i64 %t69
  call void @olang_textcopy(ptr %t77, ptr %t72, i64 %t73)
  %t78 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t75, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t79, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t81 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t81, ptr %l29, !tbaa !27
  %t82 = call i32 @getuid()
  store i32 %t82, ptr %l30
  br label %bb21
bb21:
  %t83 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t84 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t85 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 1
  %t87 = extractvalue { i64, ptr } %t85, 0
  %t88 = add i64 %t84, %t87
  %t89 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t90 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t91 = add i64 %t88, %t90
  %t92 = load i32, ptr %l30, !tbaa !64
  %t93 = zext i32 %t92 to i64
  %t94 = call i64 @__olang_fmt_u64(ptr null, i64 %t93)
  %t95 = add i64 %t91, %t94
  %t96 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t95)
  call void @olang_textcopy(ptr %t96, ptr %t83, i64 %t84)
  %t97 = getelementptr i8, ptr %t96, i64 %t84
  call void @olang_textcopy(ptr %t97, ptr %t86, i64 %t87)
  %t98 = getelementptr i8, ptr %t97, i64 %t87
  call void @olang_textcopy(ptr %t98, ptr %t89, i64 %t90)
  %t99 = getelementptr i8, ptr %t98, i64 %t90
  %t100 = call i64 @__olang_fmt_u64(ptr %t99, i64 %t93)
  %t101 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t96, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t102, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbuild_2eHoldings(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %lp3 = alloca ptr
  %l4 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"std/os:FileInfo"
  %l11 = alloca i1
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l18 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i32
  %l23 = alloca i1
  %l36 = alloca { i64, ptr }
  %l39 = alloca %"std/os:FileInfo"
  %l44 = alloca %"std/os:FileInfo"
  %l45 = alloca i32
  %l47 = alloca i1
  %l53 = alloca i1
  %l57 = alloca i64
  %l62 = alloca i64
  %l64 = alloca i64
  %l67 = alloca { i64, ptr }
  %l68 = alloca i64
  %l71 = alloca i64
  %l72 = alloca i32
  %l75 = alloca ptr
  %l76 = alloca { i64, ptr }
  %l78 = alloca i64
  %l79 = alloca ptr
  %l84 = alloca %"compiler/build:Held"
  %l87 = alloca ptr
  %l88 = alloca ptr
  %l89 = alloca i64
  %l96 = alloca { i64, ptr }
  %l98 = alloca ptr
  %l103 = alloca ptr
  %l107 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aHeld_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l16
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t2, ptr %lp3
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  %t4 = load ptr, ptr %lp3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t5 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t5, ptr %l17
  br label %bb2
bb2:
  %t6 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l17
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t6, ptr %l4
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = call { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v0, ptr %v1, { i64, ptr } %t7)
  %t10 = extractvalue { i32, { i64, ptr } } %t9, 1
  %t11 = extractvalue { i32, { i64, ptr } } %t9, 0
  store i32 %t11, ptr %l21
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb4, label %ok.13, !prof !99
ok.13:
  store { i64, ptr } %t10, ptr %l20
  br label %bb3
bb3:
  %t14 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t14, ptr %l18, !tbaa !27
  br label %bb12
bb4:
  %t15 = load i32, ptr %l21, !tbaa !23
  %t16 = ashr i32 %t15, 16
  %t18 = icmp eq i32 %t16, 1
  store i1 %t18, ptr %l23, !tbaa !21
  %t19 = load i32, ptr %l21, !tbaa !23
  %t20 = ashr i32 %t19, 16
  %t22 = icmp eq i32 %t20, 1
  br i1 %t22, label %bb5, label %bb6
bb5:
  call void @__olang_errpay_pop()
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t24 = icmp sge i64 0, 0
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = icmp sle i64 0, 576460752303423487
  br i1 %t26, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_88ea926d2658d5c0_814689e720f02d14)
  unreachable
bb10:
  %t28 = mul i64 0, 16
  %t29 = insertvalue { i64, ptr } undef, i64 0, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t30, ptr %l18, !tbaa !27
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_88ea926d2658d5c0_814689e720f02d14)
  unreachable
bb12:
  %t32 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t32, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  store i64 %t37, ptr %l8, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  %t39 = load i64, ptr %l7, !tbaa !24
  %t40 = load i64, ptr %l8, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb53
bb15:
  br label %bb16
bb16:
  %t47 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t47, ptr %l36, !tbaa !27
  %t48 = load i64, ptr %l7, !tbaa !24
  %t50 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr { i64, ptr }, ptr %t51, i64 %t48
  %t53 = load { i64, ptr }, ptr %t52, !tbaa !37
  store { i64, ptr } %t53, ptr %l9, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t55, 1
  %t59 = extractvalue { i64, ptr } %t55, 0
  %t60 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t61 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t62 = add i64 %t59, %t61
  %t64 = extractvalue { i64, ptr } %t56, 1
  %t65 = extractvalue { i64, ptr } %t56, 0
  %t66 = add i64 %t62, %t65
  %t67 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t66)
  call void @olang_textcopy(ptr %t67, ptr %t58, i64 %t59)
  %t68 = getelementptr i8, ptr %t67, i64 %t59
  call void @olang_textcopy(ptr %t68, ptr %t60, i64 %t61)
  %t69 = getelementptr i8, ptr %t68, i64 %t61
  call void @olang_textcopy(ptr %t69, ptr %t64, i64 %t65)
  %t70 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t67, 1
  %t74 = call { i32, %"std/os:FileInfo" } @std_2fos_2eFileInfo_2eStat(ptr %s2, { i64, ptr } %t71)
  %t75 = extractvalue { i32, %"std/os:FileInfo" } %t74, 1
  %t76 = extractvalue { i32, %"std/os:FileInfo" } %t74, 0
  store i32 %t76, ptr %l45
  %t77 = icmp ne i32 %t76, 0
  br i1 %t77, label %bb18, label %ok.78, !prof !99
ok.78:
  store %"std/os:FileInfo" %t75, ptr %l44
  br label %bb17
bb17:
  %t79 = load %"std/os:FileInfo", ptr %l44
  store %"std/os:FileInfo" %t79, ptr %l39
  br label %bb22
bb18:
  %t80 = load i32, ptr %l45, !tbaa !23
  %t81 = ashr i32 %t80, 16
  %t83 = icmp eq i32 %t81, 1
  store i1 %t83, ptr %l47, !tbaa !21
  %t84 = load i32, ptr %l45, !tbaa !23
  %t85 = ashr i32 %t84, 16
  %t87 = icmp eq i32 %t85, 1
  br i1 %t87, label %bb19, label %bb20
bb19:
  call void @__olang_errpay_pop()
  br label %bb20
bb20:
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb52
bb22:
  %t89 = load %"std/os:FileInfo", ptr %l39
  store %"std/os:FileInfo" %t89, ptr %l10
  %t90 = getelementptr %"std/os:FileInfo", ptr %l10, i32 0, i32 0
  %t91 = load i32, ptr %t90, !range !{i32 0, i32 3}
  %t93 = trunc i64 1 to i32
  %t94 = icmp eq i32 %t91, %t93
  store i1 %t94, ptr %l11, !tbaa !21
  %t96 = load i1, ptr %l11, !tbaa !21
  br i1 %t96, label %bb23, label %bb24
bb23:
  %t100 = xor i1 %a2, true
  store i1 %t100, ptr %l53, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb25
bb25:
  %t102 = load i1, ptr %l53, !tbaa !21
  br i1 %t102, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s2)
  br label %bb52
bb27:
  br label %bb28
bb28:
  %t103 = load i1, ptr %l11, !tbaa !21
  br i1 %t103, label %bb29, label %bb30
bb29:
  %t105 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t106 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t105, 1
  %t109 = extractvalue { i64, ptr } %t105, 0
  %t110 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t111 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t112 = add i64 %t109, %t111
  %t114 = extractvalue { i64, ptr } %t106, 1
  %t115 = extractvalue { i64, ptr } %t106, 0
  %t116 = add i64 %t112, %t115
  %t117 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t116)
  call void @olang_textcopy(ptr %t117, ptr %t108, i64 %t109)
  %t118 = getelementptr i8, ptr %t117, i64 %t109
  call void @olang_textcopy(ptr %t118, ptr %t110, i64 %t111)
  %t119 = getelementptr i8, ptr %t118, i64 %t111
  call void @olang_textcopy(ptr %t119, ptr %t114, i64 %t115)
  %t120 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t121 = insertvalue { i64, ptr } %t120, ptr %t117, 1
  %t124 = call i64 @compiler_2fbuild_2etreeBytes(ptr %s2, { i64, ptr } %t121)
  store i64 %t124, ptr %l62
  br label %bb31
bb30:
  %t125 = getelementptr %"std/os:FileInfo", ptr %l10, i32 0, i32 1
  %t126 = load i64, ptr %t125, !tbaa !24
  %t128 = call i64 @compiler_2fbuild_2eonDisk(i64 %t126)
  store i64 %t128, ptr %l64
  br label %bb32
bb31:
  %t129 = load i64, ptr %l62, !tbaa !24
  store i64 %t129, ptr %l57, !tbaa !24
  br label %bb33
bb32:
  %t130 = load i64, ptr %l64, !tbaa !24
  store i64 %t130, ptr %l57, !tbaa !24
  br label %bb33
bb33:
  %t131 = load i64, ptr %l57, !tbaa !24
  store i64 %t131, ptr %l12, !tbaa !24
  %t132 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t136 = call { i64, ptr } @compiler_2fbuild_2eStemOf(ptr %v1, ptr %v1, { i64, ptr } %t132, i64 %a1)
  store { i64, ptr } %t136, ptr %l67
  br label %bb34
bb34:
  %t137 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t137, ptr %l13, !tbaa !27
  %t138 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t141 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %s0, ptr %v1, ptr %l4, { i64, ptr } %t138)
  %t142 = extractvalue { i32, i64 } %t141, 1
  %t143 = extractvalue { i32, i64 } %t141, 0
  store i32 %t143, ptr %l72
  %t144 = icmp ne i32 %t143, 0
  br i1 %t144, label %bb36, label %ok.145, !prof !99
ok.145:
  store i64 %t142, ptr %l71
  br label %bb35
bb35:
  %t146 = load i64, ptr %l71, !tbaa !24
  store i64 %t146, ptr %l68, !tbaa !24
  br label %bb38
bb36:
  br label %bb37
bb37:
  store i64 -1, ptr %l68, !tbaa !24
  br label %bb38
bb38:
  %t147 = load i64, ptr %l68, !tbaa !24
  store i64 %t147, ptr %l14, !tbaa !24
  %t148 = load i64, ptr %l14, !tbaa !24
  %t150 = icmp slt i64 %t148, 0
  br i1 %t150, label %bb39, label %bb40
bb39:
  store ptr %l4, ptr %l75, !tbaa !29
  %t152 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t152, ptr %l76, !tbaa !27
  %t153 = load ptr, ptr %lp3
  %t155 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aHeld_3e_2eLen_3ccompiler_2fbuild_3aHeld_3e(ptr %v1, ptr %t153)
  store i64 %t155, ptr %l78
  br label %bb41
bb40:
  br label %bb45
bb41:
  %t156 = load ptr, ptr %l75, !tbaa !29
  %t157 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t158 = load i64, ptr %l78, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %s0, ptr %v1, ptr %t156, { i64, ptr } %t157, i64 %t158)
  br label %bb42
bb42:
  %t159 = load ptr, ptr %lp3
  store ptr %t159, ptr %l79, !tbaa !29
  %t160 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t161 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t162 = load i64, ptr %l12, !tbaa !24
  %t163 = getelementptr %"std/os:FileInfo", ptr %l10, i32 0, i32 2
  %t164 = load i64, ptr %t163, !tbaa !24
  %t169 = call %"compiler/build:Held" @compiler_2fbuild_3aHeld_2ector(ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t160, { i64, ptr } %t161, i64 %t162, i64 %t164)
  store %"compiler/build:Held" %t169, ptr %l84
  br label %bb43
bb43:
  %t170 = load ptr, ptr %l79, !tbaa !29
  %t171 = load %"compiler/build:Held", ptr %l84
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aHeld_3e_2ePush_3ccompiler_2fbuild_3aHeld_3e(ptr %v1, ptr %v1, ptr %t170, %"compiler/build:Held" %t171)
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s2)
  br label %bb52
bb45:
  %t172 = load ptr, ptr %lp3
  %t173 = load i64, ptr %l14, !tbaa !24
  %t176 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aHeld_3e_2eRefMut_3ccompiler_2fbuild_3aHeld_3e(ptr %v1, ptr %v1, ptr %t172, i64 %t173)
  store ptr %t176, ptr %l87
  br label %bb46
bb46:
  %t177 = load ptr, ptr %l87, !tbaa !29
  store ptr %t177, ptr %l15, !tbaa !29
  %t178 = load ptr, ptr %l15, !tbaa !29
  store ptr %t178, ptr %l88, !tbaa !29
  %t179 = call ptr @__olang_scope_hold(ptr %v1)
  %t180 = ptrtoint ptr %t179 to i64
  store i64 %t180, ptr %l89, !tbaa !24
  %t181 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3aHeld_2e1
  br i1 %t181, label %bb47, label %bb48
bb47:
  %t183 = call ptr @__olang_region_make(ptr %v1)
  %t184 = ptrtoint ptr %t183 to i64
  store i64 %t184, ptr %l89, !tbaa !24
  br label %bb48
bb48:
  %t185 = load ptr, ptr %l15, !tbaa !29
  %t187 = getelementptr %"compiler/build:Held", ptr %t185, i32 0, i32 1
  %t188 = load { i64, ptr }, ptr %t187, !tbaa !27
  %t189 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t188, 1
  %t192 = extractvalue { i64, ptr } %t188, 0
  %t193 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t194 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t195 = add i64 %t192, %t194
  %t197 = extractvalue { i64, ptr } %t189, 1
  %t198 = extractvalue { i64, ptr } %t189, 0
  %t199 = add i64 %t195, %t198
  %t200 = load i64, ptr %l89
  %t201 = inttoptr i64 %t200 to ptr
  %t202 = call ptr @__olang_held_alloc(ptr %t201, i64 %t199)
  call void @olang_textcopy(ptr %t202, ptr %t191, i64 %t192)
  %t203 = getelementptr i8, ptr %t202, i64 %t192
  call void @olang_textcopy(ptr %t203, ptr %t193, i64 %t194)
  %t204 = getelementptr i8, ptr %t203, i64 %t194
  call void @olang_textcopy(ptr %t204, ptr %t197, i64 %t198)
  %t205 = insertvalue { i64, ptr } undef, i64 %t199, 0
  %t206 = insertvalue { i64, ptr } %t205, ptr %t202, 1
  %t208 = load ptr, ptr %l88, !tbaa !29
  %t209 = getelementptr %"compiler/build:Held", ptr %t208, i32 0, i32 1
  %t210 = load { i64, ptr }, ptr %t209, !tbaa !27
  store { i64, ptr } %t210, ptr %l96, !tbaa !27
  %t212 = load ptr, ptr %l88, !tbaa !29
  %t213 = getelementptr %"compiler/build:Held", ptr %t212, i32 0, i32 1
  store { i64, ptr } %t206, ptr %t213, !tbaa !27
  %t214 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3aHeld_2e1
  br i1 %t214, label %bb49, label %bb50
bb49:
  %t216 = load { i64, ptr }, ptr %l96
  %t217 = extractvalue { i64, ptr } %t216, 1
  call void @__olang_region_release(ptr %t217)
  store { i64, ptr } zeroinitializer, ptr %l96
  br label %bb50
bb50:
  %t218 = load ptr, ptr %l15, !tbaa !29
  store ptr %t218, ptr %l98, !tbaa !29
  %t219 = load ptr, ptr %l98, !tbaa !29
  %t220 = getelementptr %"compiler/build:Held", ptr %t219, i32 0, i32 2
  %t221 = load i64, ptr %t220, !tbaa !24
  %t223 = load i64, ptr %l12, !tbaa !24
  %t226 = add i64 %t221, %t223
  %t228 = load ptr, ptr %l98, !tbaa !29
  %t229 = getelementptr %"compiler/build:Held", ptr %t228, i32 0, i32 2
  store i64 %t226, ptr %t229, !tbaa !24
  %t230 = load ptr, ptr %l15, !tbaa !29
  store ptr %t230, ptr %l103, !tbaa !29
  %t231 = load ptr, ptr %l15, !tbaa !29
  %t233 = getelementptr %"compiler/build:Held", ptr %t231, i32 0, i32 3
  %t234 = load i64, ptr %t233, !tbaa !24
  %t235 = getelementptr %"std/os:FileInfo", ptr %l10, i32 0, i32 2
  %t236 = load i64, ptr %t235, !tbaa !24
  %t239 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t234, i64 %t236)
  store i64 %t239, ptr %l107
  br label %bb51
bb51:
  %t240 = load i64, ptr %l107, !tbaa !24
  %t241 = load ptr, ptr %l103, !tbaa !29
  %t242 = getelementptr %"compiler/build:Held", ptr %t241, i32 0, i32 3
  store i64 %t240, ptr %t242, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb52
bb52:
  %t243 = load i64, ptr %l7, !tbaa !24
  %t246 = add i64 %t243, 1
  store i64 %t246, ptr %l7, !tbaa !24
  br label %bb13
bb53:
  %t248 = load ptr, ptr %lp3
  %t249 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t248
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t249, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2eIrHashes(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l26 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l31 = alloca i64
  %l33 = alloca i64
  %l38 = alloca i64
  %l45 = alloca i64
  %l49 = alloca i64
  %l52 = alloca i64
  %l75 = alloca i64
  %l77 = alloca i64
  %l79 = alloca i64
  %l80 = alloca i64
  %l85 = alloca i64
  %l88 = alloca i64
  %l115 = alloca { i64, ptr }
  %l116 = alloca i64
  %l117 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %jh9 = alloca ptr
  %rv = alloca { i64, ptr }
  %t13 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %t1)
  store i64 %t3, ptr %l22
  br label %bb1
bb1:
  %t4 = load i64, ptr %l22, !tbaa !24
  %t5 = icmp sge i64 %t4, 0
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t7 = load i64, ptr %l22, !tbaa !24
  %t8 = icmp sle i64 %t7, 576460752303423487
  br i1 %t8, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_31b16802902b645_2a48a8850fa1a6d9)
  unreachable
bb4:
  %t10 = load i64, ptr %l22, !tbaa !24
  %t11 = mul i64 %t10, 16
  %t12 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t11)
  store i64 0, ptr %t13
  br label %fill.14
fill.14:
  %t17 = load i64, ptr %t13
  %t18 = icmp slt i64 %t17, %t10
  br i1 %t18, label %fillb.15, label %filld.16
fillb.15:
  %t19 = getelementptr { i64, ptr }, ptr %t12, i64 %t17
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %t19
  %t20 = add i64 %t17, 1
  store i64 %t20, ptr %t13
  br label %fill.14
filld.16:
  %t21 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t12, 1
  store { i64, ptr } %t22, ptr %l2, !tbaa !27
  %t24 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l26
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_31b16802902b645_2a48a8850fa1a6d9)
  unreachable
bb6:
  %t25 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l26
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %l3
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t28 = icmp eq ptr %t26, null
  %t30 = xor i1 %t28, true
  br i1 %t30, label %bb7, label %bb8
bb7:
  %t32 = load ptr, ptr %l1, !tbaa !29
  store ptr %t32, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l7, !tbaa !24
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %t34)
  store i64 %t36, ptr %l45
  br label %bb18
bb9:
  %t37 = load i64, ptr %l5, !tbaa !24
  store i64 %t37, ptr %l31, !tbaa !24
  %t38 = load ptr, ptr %l4, !tbaa !29
  %t40 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t38)
  store i64 %t40, ptr %l33
  br label %bb10
bb10:
  %t41 = load i64, ptr %l31, !tbaa !24
  %t42 = load i64, ptr %l33, !tbaa !24
  %t43 = icmp slt i64 %t41, %t42
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb11, label %bb12
bb11:
  br label %bb17
bb12:
  br label %bb13
bb13:
  %t47 = load ptr, ptr %l4, !tbaa !29
  %t48 = load i64, ptr %l5, !tbaa !24
  %t51 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t47, i64 %t48)
  store i64 %t51, ptr %l38
  br label %bb14
bb14:
  %t52 = load i64, ptr %l38, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t52)
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t56 = load i64, ptr %l5, !tbaa !24
  %t59 = add i64 %t56, 1
  store i64 %t59, ptr %l5, !tbaa !24
  br label %bb9
bb17:
  br label %bb32
bb18:
  %t61 = load i64, ptr %l45, !tbaa !24
  store i64 %t61, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t62 = load i64, ptr %l8, !tbaa !24
  %t63 = load i64, ptr %l7, !tbaa !24
  %t66 = icmp sgt i64 %t62, %t63
  br i1 %t66, label %bb19, label %bb20
bb19:
  %t68 = load i64, ptr %l9, !tbaa !24
  %t70 = icmp sgt i64 %t68, 0
  br i1 %t70, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l49, !tbaa !24
  br label %bb24
bb21:
  %t72 = load i64, ptr %l8, !tbaa !24
  %t73 = load i64, ptr %l7, !tbaa !24
  %t76 = sub i64 %t72, %t73
  %t77 = load i64, ptr %l9, !tbaa !24
  %t80 = add i64 %t76, %t77
  %t82 = sub i64 %t80, 1
  %t83 = load i64, ptr %l9, !tbaa !24
  %t86 = sdiv i64 %t82, %t83
  store i64 %t86, ptr %l52, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l52, !tbaa !24
  br label %bb23
bb23:
  %t88 = load i64, ptr %l52, !tbaa !24
  store i64 %t88, ptr %l49, !tbaa !24
  br label %bb24
bb24:
  %t89 = load i64, ptr %l49, !tbaa !24
  store i64 %t89, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb25
bb25:
  %t90 = load i64, ptr %l11, !tbaa !24
  %t91 = load i64, ptr %l10, !tbaa !24
  %t94 = icmp slt i64 %t90, %t91
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb26, label %bb27
bb26:
  br label %bb31
bb27:
  br label %bb28
bb28:
  %t98 = load i64, ptr %l7, !tbaa !24
  %t99 = load i64, ptr %l11, !tbaa !24
  %t100 = load i64, ptr %l9, !tbaa !24
  %t103 = mul i64 %t99, %t100
  %t106 = add i64 %t98, %t103
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t106)
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t111 = load i64, ptr %l11, !tbaa !24
  %t114 = add i64 %t111, 1
  store i64 %t114, ptr %l11, !tbaa !24
  br label %bb25
bb31:
  br label %bb32
bb32:
  %t116 = call i64 @sysconf(i32 84)
  store i64 %t116, ptr %l75
  br label %bb33
bb33:
  %t117 = load i64, ptr %l75, !tbaa !24
  %t120 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t117, i64 1)
  store i64 %t120, ptr %l77
  br label %bb34
bb34:
  %t122 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l3)
  store i64 %t122, ptr %l79
  br label %bb35
bb35:
  %t123 = load i64, ptr %l77, !tbaa !24
  %t124 = load i64, ptr %l79, !tbaa !24
  %t125 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t123, i64 %t124)
  store i64 %t125, ptr %l80
  br label %bb36
bb36:
  %t126 = load i64, ptr %l80, !tbaa !24
  store i64 %t126, ptr %l14, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s9
  store ptr null, ptr %jh9
  store i64 0, ptr %l15, !tbaa !24
  %t127 = load i64, ptr %l14, !tbaa !24
  store i64 %t127, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t129 = load i64, ptr %l16, !tbaa !24
  %t130 = load i64, ptr %l15, !tbaa !24
  %t133 = icmp sgt i64 %t129, %t130
  br i1 %t133, label %bb37, label %bb38
bb37:
  %t135 = load i64, ptr %l17, !tbaa !24
  %t137 = icmp sgt i64 %t135, 0
  br i1 %t137, label %bb39, label %bb40
bb38:
  store i64 0, ptr %l85, !tbaa !24
  br label %bb42
bb39:
  %t139 = load i64, ptr %l16, !tbaa !24
  %t140 = load i64, ptr %l15, !tbaa !24
  %t143 = sub i64 %t139, %t140
  %t144 = load i64, ptr %l17, !tbaa !24
  %t147 = add i64 %t143, %t144
  %t149 = sub i64 %t147, 1
  %t150 = load i64, ptr %l17, !tbaa !24
  %t153 = sdiv i64 %t149, %t150
  store i64 %t153, ptr %l88, !tbaa !24
  br label %bb41
bb40:
  store i64 0, ptr %l88, !tbaa !24
  br label %bb41
bb41:
  %t155 = load i64, ptr %l88, !tbaa !24
  store i64 %t155, ptr %l85, !tbaa !24
  br label %bb42
bb42:
  %t156 = load i64, ptr %l85, !tbaa !24
  store i64 %t156, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb43
bb43:
  %t157 = load i64, ptr %l19, !tbaa !24
  %t158 = load i64, ptr %l18, !tbaa !24
  %t161 = icmp slt i64 %t157, %t158
  %t163 = xor i1 %t161, true
  br i1 %t163, label %bb44, label %bb45
bb44:
  br label %bb48
bb45:
  br label %bb46
bb46:
  %t165 = load i64, ptr %l15, !tbaa !24
  %t166 = load i64, ptr %l19, !tbaa !24
  %t167 = load i64, ptr %l17, !tbaa !24
  %t170 = mul i64 %t166, %t167
  %t173 = add i64 %t165, %t170
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t178 = load i64, ptr %l14, !tbaa !24
  %t184 = call ptr @__olang_standin_in(ptr %v0, ptr %s9)
  %t185 = call ptr @__olang_standin_in(ptr %s0, ptr %s9)
  %t186 = call ptr @__olang_standin_in(ptr %v2, ptr %s9)
  %t187 = getelementptr { ptr, ptr, { i64, ptr }, i64, i64, ptr, ptr, ptr }, ptr null, i32 1
  %t188 = ptrtoint ptr %t187 to i64
  %t189 = call ptr @__olang_scope_alloc_a(ptr %s9, i64 %t188, i64 8)
  %t190 = getelementptr { ptr, ptr, { i64, ptr }, i64, i64, ptr, ptr, ptr }, ptr %t189, i32 0, i32 0
  store ptr %t175, ptr %t190
  %t191 = getelementptr { ptr, ptr, { i64, ptr }, i64, i64, ptr, ptr, ptr }, ptr %t189, i32 0, i32 1
  store ptr %l3, ptr %t191
  %t192 = getelementptr { ptr, ptr, { i64, ptr }, i64, i64, ptr, ptr, ptr }, ptr %t189, i32 0, i32 2
  store { i64, ptr } %t176, ptr %t192
  %t193 = getelementptr { ptr, ptr, { i64, ptr }, i64, i64, ptr, ptr, ptr }, ptr %t189, i32 0, i32 3
  store i64 %t173, ptr %t193
  %t194 = getelementptr { ptr, ptr, { i64, ptr }, i64, i64, ptr, ptr, ptr }, ptr %t189, i32 0, i32 4
  store i64 %t178, ptr %t194
  %t195 = getelementptr { ptr, ptr, { i64, ptr }, i64, i64, ptr, ptr, ptr }, ptr %t189, i32 0, i32 5
  store ptr %t184, ptr %t195
  %t196 = getelementptr { ptr, ptr, { i64, ptr }, i64, i64, ptr, ptr, ptr }, ptr %t189, i32 0, i32 6
  store ptr %t185, ptr %t196
  %t197 = getelementptr { ptr, ptr, { i64, ptr }, i64, i64, ptr, ptr, ptr }, ptr %t189, i32 0, i32 7
  store ptr %t186, ptr %t197
  %t198 = call ptr @__olang_scope_alloc_a(ptr %s9, i64 40, i64 8)
  %t199 = call ptr @__olang_scope_alloc_a(ptr %s9, i64 16, i64 8)
  store ptr null, ptr %t199
  %t200 = getelementptr { ptr, ptr }, ptr %t199, i32 0, i32 1
  store ptr %t184, ptr %t200
  %t201 = call ptr @__olang_scope_alloc_a(ptr %s9, i64 16, i64 8)
  store ptr %t199, ptr %t201
  %t202 = getelementptr { ptr, ptr }, ptr %t201, i32 0, i32 1
  store ptr %t185, ptr %t202
  %t203 = call ptr @__olang_scope_alloc_a(ptr %s9, i64 16, i64 8)
  store ptr %t201, ptr %t203
  %t204 = getelementptr { ptr, ptr }, ptr %t203, i32 0, i32 1
  store ptr %t186, ptr %t204
  %t205 = getelementptr { ptr, i64, ptr, i64, ptr }, ptr %t198, i32 0, i32 2
  store ptr %t203, ptr %t205
  %t206 = getelementptr { ptr, i64, ptr, i64, ptr }, ptr %t198, i32 0, i32 1
  store i64 0, ptr %t206
  %t207 = getelementptr { ptr, i64, ptr, i64, ptr }, ptr %t198, i32 0, i32 3
  store i64 0, ptr %t207
  %t208 = getelementptr { ptr, i64, ptr, i64, ptr }, ptr %t198, i32 0, i32 4
  store ptr null, ptr %t208
  %t209 = call ptr @__olang_worker_get()
  call void @__olang_worker_start(ptr %t209, ptr @olang_task20, ptr %t189, ptr %t198)
  %t210 = load ptr, ptr %jh9
  store ptr %t210, ptr %t198
  store ptr %t198, ptr %jh9
  br label %bb47
bb47:
  %t211 = load i64, ptr %l19, !tbaa !24
  %t214 = add i64 %t211, 1
  store i64 %t214, ptr %l19, !tbaa !24
  br label %bb43
bb48:
  %t216 = call i64 @__olang_join_tasks_keep(ptr %jh9, i1 false)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s9)
  br label %bb50
bb50:
  %t217 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t217, ptr %l115, !tbaa !27
  %t219 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t220 = extractvalue { i64, ptr } %t219, 0
  store i64 %t220, ptr %l116, !tbaa !24
  %t221 = load i64, ptr %l116, !tbaa !24
  %t222 = mul i64 %t221, 16
  %t223 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t222)
  %t224 = insertvalue { i64, ptr } undef, i64 %t221, 0
  %t225 = insertvalue { i64, ptr } %t224, ptr %t223, 1
  store { i64, ptr } %t225, ptr %l117, !tbaa !27
  %t226 = getelementptr { i64, ptr }, ptr %l117, i32 0, i32 1
  %t227 = load ptr, ptr %t226, !tbaa !27
  %t228 = getelementptr { i64, ptr }, ptr %l115, i32 0, i32 1
  %t229 = load ptr, ptr %t228, !tbaa !27
  %t230 = load i64, ptr %l116, !tbaa !24
  %t231 = mul i64 %t230, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t227, ptr %t229, i64 %t231, i1 false)
  %t232 = load { i64, ptr }, ptr %l117, !tbaa !27
  store { i64, ptr } %t232, ptr %l115, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t233 = load { i64, ptr }, ptr %l115, !tbaa !27
  store { i64, ptr } %t233, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fbuild_2ePhase(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l7 = alloca i1
  %l10 = alloca i64
  %l13 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l23 = alloca i1
  %l24 = alloca i1
  %l26 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d21, i32 0, i32 1) })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l5
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  store { i64, ptr } %t2, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  br label %bb6
bb2:
  %t7 = load i32, ptr %l5, !tbaa !23
  %t8 = ashr i32 %t7, 16
  %t10 = icmp eq i32 %t8, 1
  store i1 %t10, ptr %l7, !tbaa !21
  %t11 = load i32, ptr %l5, !tbaa !23
  %t12 = ashr i32 %t11, 16
  %t14 = icmp eq i32 %t12, 1
  br i1 %t14, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  %t16 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t16, ptr %l1, !tbaa !27
  %t17 = call i64 @std_2ftime_2eNow()
  store i64 %t17, ptr %l10
  br label %bb7
bb7:
  %t18 = load i64, ptr %l10, !tbaa !24
  store i64 %t18, ptr %l2, !tbaa !24
  %t19 = load i64, ptr @G_2ecompiler_2fbuild_2ePhaseAt, !tbaa !24
  %t21 = icmp ne i64 %t19, 0
  br i1 %t21, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t23, ptr %l13, !tbaa !27
  %t24 = load i64, ptr %l2, !tbaa !24
  %t25 = load i64, ptr @G_2ecompiler_2fbuild_2ePhaseAt, !tbaa !24
  %t28 = sub i64 %t24, %t25
  %t30 = sdiv i64 %t28, 1000000
  store i64 %t30, ptr %l17, !tbaa !24
  %t31 = call { i64, ptr } @compiler_2fbuild_2ememoryNow(ptr %s2)
  store { i64, ptr } %t31, ptr %l18
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t32 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t34 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 1
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t37 = add i64 %t33, %t36
  %t38 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t39 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t40 = add i64 %t37, %t39
  %t41 = load i64, ptr %l17, !tbaa !24
  %t42 = call i64 @__olang_fmt_i64(ptr null, i64 %t41)
  %t43 = add i64 %t40, %t42
  %t44 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t45 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t46 = add i64 %t43, %t45
  %t47 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t47, 1
  %t49 = extractvalue { i64, ptr } %t47, 0
  %t50 = add i64 %t46, %t49
  %t51 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t52 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t53 = add i64 %t50, %t52
  %t54 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t53)
  call void @olang_textcopy(ptr %t54, ptr %t32, i64 %t33)
  %t55 = getelementptr i8, ptr %t54, i64 %t33
  call void @olang_textcopy(ptr %t55, ptr %t35, i64 %t36)
  %t56 = getelementptr i8, ptr %t55, i64 %t36
  call void @olang_textcopy(ptr %t56, ptr %t38, i64 %t39)
  %t57 = getelementptr i8, ptr %t56, i64 %t39
  %t58 = call i64 @__olang_fmt_i64(ptr %t57, i64 %t41)
  %t59 = getelementptr i8, ptr %t57, i64 %t42
  call void @olang_textcopy(ptr %t59, ptr %t44, i64 %t45)
  %t60 = getelementptr i8, ptr %t59, i64 %t45
  call void @olang_textcopy(ptr %t60, ptr %t48, i64 %t49)
  %t61 = getelementptr i8, ptr %t60, i64 %t49
  call void @olang_textcopy(ptr %t61, ptr %t51, i64 %t52)
  %t62 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t54, 1
  call void @compiler_2fbuild_2esayErr(ptr %s2, { i64, ptr } %t63)
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb12:
  %t66 = load i64, ptr %l2, !tbaa !24
  store i64 %t66, ptr @G_2ecompiler_2fbuild_2ePhaseAt, !tbaa !24
  %t68 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t70 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t68, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d26, i32 0, i32 1) })
  store i1 %t70, ptr %l23
  br label %bb13
bb13:
  %t71 = load i1, ptr %l23, !tbaa !21
  br i1 %t71, label %bb14, label %bb15
bb14:
  %t72 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t74 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t72, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d27, i32 0, i32 1) })
  store i1 %t74, ptr %l26
  br label %bb16
bb15:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb17
bb16:
  %t75 = load i1, ptr %l26, !tbaa !21
  store i1 %t75, ptr %l24, !tbaa !21
  br label %bb17
bb17:
  %t76 = load i1, ptr %l24, !tbaa !21
  br i1 %t76, label %bb18, label %bb19
bb18:
  call void @std_2fos_2eExit(i32 0)
  unreachable
bb19:
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_1a0af222d89a1264_6ae848cde6020298)
  unreachable
bb21:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { { i64, ptr }, { i64, ptr } } @compiler_2fbuild_2eRunAll(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l27 = alloca i64
  %l31 = alloca i64
  %l41 = alloca { { i64, ptr }, { i64, ptr } }
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l56 = alloca i64
  %l59 = alloca i64
  %l68 = alloca i64
  %l71 = alloca i1
  %l93 = alloca %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33"
  %l102 = alloca { i64, ptr }
  %l107 = alloca i32
  %l109 = alloca i1
  %l116 = alloca i64
  %l119 = alloca i1
  %l128 = alloca i64
  %l131 = alloca i64
  %l161 = alloca { { i64, ptr }, { i64, ptr } }
  %l162 = alloca { i64, ptr }
  %l163 = alloca i64
  %l164 = alloca { i64, ptr }
  %l165 = alloca { i64, ptr }
  %l166 = alloca i64
  %l167 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %jh12 = alloca ptr
  %rv = alloca { { i64, ptr }, { i64, ptr } }
  %t28 = alloca i64
  %t178 = alloca { { i64, ptr }, ptr }, align 8
  %t190 = alloca %"std/chan:Chan.2a97fb60857ef5a63442ec031c672e33", align 8
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l3, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  store i64 %t5, ptr %l27, !tbaa !24
  %t6 = load i64, ptr %l27, !tbaa !24
  %t7 = icmp sge i64 %t6, 0
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l27, !tbaa !24
  %t10 = icmp sle i64 %t9, 2305843009213693951
  br i1 %t10, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_2b4b55182e30c5b8_1dd1254afca8c384)
  unreachable
bb3:
  %t12 = load i64, ptr %l27, !tbaa !24
  %t13 = mul i64 %t12, 4
  %t14 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t13)
  %t15 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l4, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  store i64 %t18, ptr %l31, !tbaa !24
  %t19 = load i64, ptr %l31, !tbaa !24
  %t20 = icmp sge i64 %t19, 0
  br i1 %t20, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_2b4b55182e30c5b8_1dd1254afca8c384)
  unreachable
bb5:
  %t22 = load i64, ptr %l31, !tbaa !24
  %t23 = icmp sle i64 %t22, 576460752303423487
  br i1 %t23, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_3fd1be9bff2cc025_306b5f0bb3e84491)
  unreachable
bb7:
  %t25 = load i64, ptr %l31, !tbaa !24
  %t26 = mul i64 %t25, 16
  %t27 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t26)
  store i64 0, ptr %t28
  br label %fill.29
fill.29:
  %t32 = load i64, ptr %t28
  %t33 = icmp slt i64 %t32, %t25
  br i1 %t33, label %fillb.30, label %filld.31
fillb.30:
  %t34 = getelementptr { i64, ptr }, ptr %t27, i64 %t32
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d28, i32 0, i32 1) }, ptr %t34
  %t35 = add i64 %t32, 1
  store i64 %t35, ptr %t28
  br label %fill.29
filld.31:
  %t36 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t27, 1
  store { i64, ptr } %t37, ptr %l5, !tbaa !27
  %t39 = load i64, ptr %l3, !tbaa !24
  %t41 = icmp eq i64 %t39, 0
  br i1 %t41, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_3fd1be9bff2cc025_306b5f0bb3e84491)
  unreachable
bb9:
  %t43 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t48 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t43, 0
  %t50 = insertvalue { { i64, ptr }, { i64, ptr } } %t48, { i64, ptr } %t45, 1
  store { { i64, ptr }, { i64, ptr } } %t50, ptr %l41
  %t51 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l41, i32 0, i32 0
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  store { i64, ptr } %t52, ptr %l42, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t53, 0
  store i64 %t54, ptr %l43, !tbaa !24
  %t55 = load i64, ptr %l43, !tbaa !24
  %t56 = mul i64 %t55, 4
  %t57 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t56)
  %t58 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t57, 1
  store { i64, ptr } %t59, ptr %l44, !tbaa !27
  %t60 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = load i64, ptr %l43, !tbaa !24
  %t65 = mul i64 %t64, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t61, ptr %t63, i64 %t65, i1 false)
  %t66 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t67 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l41, i32 0, i32 0
  store { i64, ptr } %t66, ptr %t67, !tbaa !27
  %t68 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l41, i32 0, i32 1
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  store { i64, ptr } %t69, ptr %l45, !tbaa !27
  %t70 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t70, 0
  store i64 %t71, ptr %l46, !tbaa !24
  %t72 = load i64, ptr %l46, !tbaa !24
  %t73 = mul i64 %t72, 16
  %t74 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t73)
  %t75 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  store { i64, ptr } %t76, ptr %l47, !tbaa !27
  %t77 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = load i64, ptr %l46, !tbaa !24
  %t82 = mul i64 %t81, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t78, ptr %t80, i64 %t82, i1 false)
  %t83 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t84 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l41, i32 0, i32 1
  store { i64, ptr } %t83, ptr %t84, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t85 = load { { i64, ptr }, { i64, ptr } }, ptr %l41
  store { { i64, ptr }, { i64, ptr } } %t85, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t86 = load i64, ptr %l3, !tbaa !24
  store i64 %t86, ptr %l48, !tbaa !24
  %t87 = load i64, ptr %l48, !tbaa !24
  %t88 = icmp sge i64 %t87, 0
  br i1 %t88, label %bb12, label %bb13
bb12:
  %t90 = load i64, ptr %l48, !tbaa !24
  %t91 = icmp sle i64 %t90, 1152921504606846975
  br i1 %t91, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_bc625dc042a99e06_c0b5fdead4ea6272)
  unreachable
bb14:
  %t93 = load i64, ptr %l48, !tbaa !24
  %t94 = mul i64 %t93, 8
  %t95 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t94)
  %t96 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t95, 1
  store { i64, ptr } %t97, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t99 = load i64, ptr %l3, !tbaa !24
  store i64 %t99, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t101 = load i64, ptr %l8, !tbaa !24
  %t102 = load i64, ptr %l7, !tbaa !24
  %t105 = icmp sgt i64 %t101, %t102
  br i1 %t105, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_bc625dc042a99e06_c0b5fdead4ea6272)
  unreachable
bb16:
  %t107 = load i64, ptr %l9, !tbaa !24
  %t109 = icmp sgt i64 %t107, 0
  br i1 %t109, label %bb18, label %bb19
bb17:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb21
bb18:
  %t111 = load i64, ptr %l8, !tbaa !24
  %t112 = load i64, ptr %l7, !tbaa !24
  %t115 = sub i64 %t111, %t112
  %t116 = load i64, ptr %l9, !tbaa !24
  %t119 = add i64 %t115, %t116
  %t121 = sub i64 %t119, 1
  %t122 = load i64, ptr %l9, !tbaa !24
  %t125 = sdiv i64 %t121, %t122
  store i64 %t125, ptr %l59, !tbaa !24
  br label %bb20
bb19:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb20
bb20:
  %t127 = load i64, ptr %l59, !tbaa !24
  store i64 %t127, ptr %l56, !tbaa !24
  br label %bb21
bb21:
  %t128 = load i64, ptr %l56, !tbaa !24
  store i64 %t128, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  %t129 = load i64, ptr %l10, !tbaa !24
  %t130 = sub i64 %t129, 1
  store i64 %t130, ptr %l68, !tbaa !24
  %t131 = load i64, ptr %l10, !tbaa !24
  %t132 = icmp slt i64 %t131, 2147483648
  %t133 = load i64, ptr %l11, !tbaa !24
  %t134 = icmp sge i64 %t133, 0
  %t137 = and i1 %t132, %t134
  store i1 %t137, ptr %l71, !tbaa !21
  br label %bb22
bb22:
  %t138 = load i64, ptr %l11, !tbaa !24
  %t139 = load i64, ptr %l10, !tbaa !24
  %t142 = icmp slt i64 %t138, %t139
  %t144 = xor i1 %t142, true
  br i1 %t144, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t146 = load i64, ptr %l7, !tbaa !24
  %t147 = load i64, ptr %l11, !tbaa !24
  %t148 = load i64, ptr %l9, !tbaa !24
  %t151 = mul i64 %t147, %t148
  %t154 = add i64 %t146, %t151
  store i64 %t154, ptr %l12, !tbaa !24
  %t156 = load i64, ptr %l12, !tbaa !24
  %t157 = load i64, ptr %l12, !tbaa !24
  %t160 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !27
  %t162 = getelementptr i64, ptr %t161, i64 %t156
  store i64 %t157, ptr %t162, !tbaa !34
  br label %bb26
bb26:
  %t163 = load i64, ptr %l11, !tbaa !24
  %t166 = add i64 %t163, 1
  store i64 %t166, ptr %l11, !tbaa !24
  br label %bb22
bb27:
  %t168 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t170 = extractvalue { i64, ptr } %t168, 0
  %t172 = icmp sgt i64 %t170, 0
  br i1 %t172, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s5
  %t174 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t175 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t176 = getelementptr { { i64, ptr }, ptr }, ptr null, i32 1
  %t177 = ptrtoint ptr %t176 to i64
  %t179 = getelementptr { { i64, ptr }, ptr }, ptr %t178, i32 0, i32 0
  store { i64, ptr } %t175, ptr %t179, !tbaa !28
  call void @__olang_scope_escape(ptr %v1)
  %t181 = call ptr @__olang_scope_hold(ptr %v1)
  %t182 = getelementptr { { i64, ptr }, ptr }, ptr %t178, i32 0, i32 1
  store ptr %t181, ptr %t182, !tbaa !28
  %t183 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_29, 0
  %t184 = insertvalue { ptr, ptr } %t183, ptr %t178, 1
  %t187 = extractvalue { ptr, ptr } %t184, 0
  %t188 = extractvalue { ptr, ptr } %t184, 1
  call void @std_2fprelude_2farray_2eArray_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %s0, ptr %s5, { i64, ptr } %t174, ptr %t187, ptr %t188)
  br label %bb30
bb29:
  br label %bb31
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb31
bb31:
  %t189 = load i64, ptr %l3, !tbaa !24
  call void @std_2fchan_3aChan_3cI64_3e_2ector(ptr %t190, ptr %s0, i64 %t189)
  call void @llvm.memmove.p0.p0.i64(ptr %l93, ptr %t190, i64 264, i1 false)
  br label %bb32
bb32:
  %t192 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 264, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t192, ptr %l93, i64 264, i1 false)
  store ptr %t192, ptr %l13, !tbaa !29
  %t194 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t194, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t196 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t196, 0
  store i64 %t198, ptr %l16, !tbaa !24
  br label %bb33
bb33:
  %t200 = load i64, ptr %l15, !tbaa !24
  %t201 = load i64, ptr %l16, !tbaa !24
  %t204 = icmp slt i64 %t200, %t201
  %t206 = xor i1 %t204, true
  br i1 %t206, label %bb34, label %bb35
bb34:
  br label %bb42
bb35:
  br label %bb36
bb36:
  %t208 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t208, ptr %l102, !tbaa !27
  %t209 = load i64, ptr %l15, !tbaa !24
  %t211 = getelementptr { i64, ptr }, ptr %l102, i32 0, i32 1
  %t212 = load ptr, ptr %t211, !tbaa !27
  %t213 = getelementptr i64, ptr %t212, i64 %t209
  %t214 = load i64, ptr %t213, !tbaa !34
  %t216 = load ptr, ptr %l13, !tbaa !29
  %t220 = call i32 @std_2fchan_2eSend_3cI64_3e(ptr %s0, ptr %t216, i64 %t214)
  store i32 %t220, ptr %l107
  %t221 = icmp ne i32 %t220, 0
  br i1 %t221, label %bb38, label %ok.222, !prof !99
ok.222:
  br label %bb37
bb37:
  br label %bb40
bb38:
  %t223 = load i32, ptr %l107, !tbaa !23
  %t224 = ashr i32 %t223, 16
  %t226 = icmp eq i32 %t224, 1
  store i1 %t226, ptr %l109, !tbaa !21
  br label %bb39
bb39:
  call void @__olang_check_failed(ptr @olang_loc_1359a9f97975288c_a8d4abcb606172b0)
  unreachable
bb40:
  br label %bb41
bb41:
  %t227 = load i64, ptr %l15, !tbaa !24
  %t230 = add i64 %t227, 1
  store i64 %t230, ptr %l15, !tbaa !24
  br label %bb33
bb42:
  %t232 = load i64, ptr %l1, !tbaa !24
  %t233 = load i64, ptr %l3, !tbaa !24
  %t236 = icmp slt i64 %t232, %t233
  br i1 %t236, label %bb43, label %bb44
bb43:
  %t238 = load i64, ptr %l1, !tbaa !24
  store i64 %t238, ptr %l116, !tbaa !24
  br label %bb45
bb44:
  %t240 = load i64, ptr %l3, !tbaa !24
  store i64 %t240, ptr %l116, !tbaa !24
  br label %bb45
bb45:
  %t242 = load i64, ptr %l116, !tbaa !24
  store i64 %t242, ptr %l18, !tbaa !24
  store i64 0, ptr @G_2ecompiler_2fbuild_2eRan, !tbaa !24
  %t243 = call i1 @compiler_2fbuild_2etimed()
  store i1 %t243, ptr %l119
  br label %bb46
bb46:
  %t244 = load i1, ptr %l119, !tbaa !21
  br i1 %t244, label %bb47, label %bb48
bb47:
  store %olang.scope zeroinitializer, ptr %s10
  %t245 = load i64, ptr %l3, !tbaa !24
  %t246 = load i64, ptr %l18, !tbaa !24
  %t247 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t248 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  %t250 = call i64 @__olang_fmt_i64(ptr null, i64 %t245)
  %t251 = add i64 %t248, %t250
  %t252 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t253 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t254 = add i64 %t251, %t253
  %t256 = call i64 @__olang_fmt_i64(ptr null, i64 %t246)
  %t257 = add i64 %t254, %t256
  %t258 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t259 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t260 = add i64 %t257, %t259
  %t261 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t260)
  call void @olang_textcopy(ptr %t261, ptr %t247, i64 %t248)
  %t262 = getelementptr i8, ptr %t261, i64 %t248
  %t263 = call i64 @__olang_fmt_i64(ptr %t262, i64 %t245)
  %t264 = getelementptr i8, ptr %t262, i64 %t250
  call void @olang_textcopy(ptr %t264, ptr %t252, i64 %t253)
  %t265 = getelementptr i8, ptr %t264, i64 %t253
  %t266 = call i64 @__olang_fmt_i64(ptr %t265, i64 %t246)
  %t267 = getelementptr i8, ptr %t265, i64 %t256
  call void @olang_textcopy(ptr %t267, ptr %t258, i64 %t259)
  %t268 = insertvalue { i64, ptr } undef, i64 %t260, 0
  %t269 = insertvalue { i64, ptr } %t268, ptr %t261, 1
  call void @compiler_2fbuild_2esayErr(ptr %s10, { i64, ptr } %t269)
  br label %bb49
bb48:
  br label %bb50
bb49:
  call void @__olang_scope_close(ptr %s10)
  br label %bb50
bb50:
  store %olang.scope zeroinitializer, ptr %s12
  store ptr null, ptr %jh12
  store i64 0, ptr %l19, !tbaa !24
  %t272 = load i64, ptr %l18, !tbaa !24
  store i64 %t272, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t274 = load i64, ptr %l20, !tbaa !24
  %t275 = load i64, ptr %l19, !tbaa !24
  %t278 = icmp sgt i64 %t274, %t275
  br i1 %t278, label %bb51, label %bb52
bb51:
  %t280 = load i64, ptr %l21, !tbaa !24
  %t282 = icmp sgt i64 %t280, 0
  br i1 %t282, label %bb53, label %bb54
bb52:
  store i64 0, ptr %l128, !tbaa !24
  br label %bb56
bb53:
  %t284 = load i64, ptr %l20, !tbaa !24
  %t285 = load i64, ptr %l19, !tbaa !24
  %t288 = sub i64 %t284, %t285
  %t289 = load i64, ptr %l21, !tbaa !24
  %t292 = add i64 %t288, %t289
  %t294 = sub i64 %t292, 1
  %t295 = load i64, ptr %l21, !tbaa !24
  %t298 = sdiv i64 %t294, %t295
  store i64 %t298, ptr %l131, !tbaa !24
  br label %bb55
bb54:
  store i64 0, ptr %l131, !tbaa !24
  br label %bb55
bb55:
  %t300 = load i64, ptr %l131, !tbaa !24
  store i64 %t300, ptr %l128, !tbaa !24
  br label %bb56
bb56:
  %t301 = load i64, ptr %l128, !tbaa !24
  store i64 %t301, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb57
bb57:
  %t302 = load i64, ptr %l23, !tbaa !24
  %t303 = load i64, ptr %l22, !tbaa !24
  %t306 = icmp slt i64 %t302, %t303
  %t308 = xor i1 %t306, true
  br i1 %t308, label %bb58, label %bb59
bb58:
  br label %bb62
bb59:
  br label %bb60
bb60:
  %t310 = load i64, ptr %l19, !tbaa !24
  %t311 = load i64, ptr %l23, !tbaa !24
  %t312 = load i64, ptr %l21, !tbaa !24
  %t315 = mul i64 %t311, %t312
  %t318 = add i64 %t310, %t315
  store i64 %t318, ptr %l24, !tbaa !24
  %t320 = load ptr, ptr %l13, !tbaa !29
  %t321 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t322 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t323 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t328 = call ptr @__olang_standin_in(ptr %s0, ptr %s12)
  %t329 = call ptr @__olang_standin_in(ptr %v0, ptr %s12)
  %t330 = call ptr @__olang_standin_in(ptr %s0, ptr %s12)
  %t331 = call ptr @__olang_standin_in(ptr %v2, ptr %s12)
  %t332 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr null, i32 1
  %t333 = ptrtoint ptr %t332 to i64
  %t334 = call ptr @__olang_scope_alloc_a(ptr %s12, i64 %t333, i64 8)
  %t335 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t334, i32 0, i32 0
  store ptr %t320, ptr %t335
  %t336 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t334, i32 0, i32 1
  store { i64, ptr } %t321, ptr %t336
  %t337 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t334, i32 0, i32 2
  store { i64, ptr } %t322, ptr %t337
  %t338 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t334, i32 0, i32 3
  store { i64, ptr } %t323, ptr %t338
  %t339 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t334, i32 0, i32 4
  store ptr %t328, ptr %t339
  %t340 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t334, i32 0, i32 5
  store ptr %t329, ptr %t340
  %t341 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t334, i32 0, i32 6
  store ptr %t330, ptr %t341
  %t342 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t334, i32 0, i32 7
  store ptr %t331, ptr %t342
  %t343 = call ptr @__olang_scope_alloc_a(ptr %s12, i64 40, i64 8)
  %t344 = call ptr @__olang_scope_alloc_a(ptr %s12, i64 16, i64 8)
  store ptr null, ptr %t344
  %t345 = getelementptr { ptr, ptr }, ptr %t344, i32 0, i32 1
  store ptr %t328, ptr %t345
  %t346 = call ptr @__olang_scope_alloc_a(ptr %s12, i64 16, i64 8)
  store ptr %t344, ptr %t346
  %t347 = getelementptr { ptr, ptr }, ptr %t346, i32 0, i32 1
  store ptr %t329, ptr %t347
  %t348 = call ptr @__olang_scope_alloc_a(ptr %s12, i64 16, i64 8)
  store ptr %t346, ptr %t348
  %t349 = getelementptr { ptr, ptr }, ptr %t348, i32 0, i32 1
  store ptr %t330, ptr %t349
  %t350 = call ptr @__olang_scope_alloc_a(ptr %s12, i64 16, i64 8)
  store ptr %t348, ptr %t350
  %t351 = getelementptr { ptr, ptr }, ptr %t350, i32 0, i32 1
  store ptr %t331, ptr %t351
  %t352 = getelementptr { ptr, i64, ptr, i64, ptr }, ptr %t343, i32 0, i32 2
  store ptr %t350, ptr %t352
  %t353 = getelementptr { ptr, i64, ptr, i64, ptr }, ptr %t343, i32 0, i32 1
  store i64 0, ptr %t353
  %t354 = getelementptr { ptr, i64, ptr, i64, ptr }, ptr %t343, i32 0, i32 3
  store i64 0, ptr %t354
  %t355 = getelementptr { ptr, i64, ptr, i64, ptr }, ptr %t343, i32 0, i32 4
  store ptr null, ptr %t355
  %t356 = call ptr @__olang_worker_get()
  call void @__olang_worker_start(ptr %t356, ptr @olang_task33, ptr %t334, ptr %t343)
  %t357 = load ptr, ptr %jh12
  store ptr %t357, ptr %t343
  store ptr %t343, ptr %jh12
  br label %bb61
bb61:
  %t358 = load i64, ptr %l23, !tbaa !24
  %t361 = add i64 %t358, 1
  store i64 %t361, ptr %l23, !tbaa !24
  br label %bb57
bb62:
  %t363 = load ptr, ptr %l13, !tbaa !29
  call void @std_2fchan_2eClose_3cI64_3e(ptr %s0, ptr %t363)
  br label %bb63
bb63:
  %t365 = call i64 @__olang_join_tasks_keep(ptr %jh12, i1 false)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s12)
  br label %bb65
bb65:
  %t366 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t368 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t371 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t366, 0
  %t373 = insertvalue { { i64, ptr }, { i64, ptr } } %t371, { i64, ptr } %t368, 1
  store { { i64, ptr }, { i64, ptr } } %t373, ptr %l161
  %t374 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l161, i32 0, i32 0
  %t375 = load { i64, ptr }, ptr %t374, !tbaa !27
  store { i64, ptr } %t375, ptr %l162, !tbaa !27
  %t376 = load { i64, ptr }, ptr %l162, !tbaa !27
  %t377 = extractvalue { i64, ptr } %t376, 0
  store i64 %t377, ptr %l163, !tbaa !24
  %t378 = load i64, ptr %l163, !tbaa !24
  %t379 = mul i64 %t378, 4
  %t380 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t379)
  %t381 = insertvalue { i64, ptr } undef, i64 %t378, 0
  %t382 = insertvalue { i64, ptr } %t381, ptr %t380, 1
  store { i64, ptr } %t382, ptr %l164, !tbaa !27
  %t383 = getelementptr { i64, ptr }, ptr %l164, i32 0, i32 1
  %t384 = load ptr, ptr %t383, !tbaa !27
  %t385 = getelementptr { i64, ptr }, ptr %l162, i32 0, i32 1
  %t386 = load ptr, ptr %t385, !tbaa !27
  %t387 = load i64, ptr %l163, !tbaa !24
  %t388 = mul i64 %t387, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t384, ptr %t386, i64 %t388, i1 false)
  %t389 = load { i64, ptr }, ptr %l164, !tbaa !27
  %t390 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l161, i32 0, i32 0
  store { i64, ptr } %t389, ptr %t390, !tbaa !27
  %t391 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l161, i32 0, i32 1
  %t392 = load { i64, ptr }, ptr %t391, !tbaa !27
  store { i64, ptr } %t392, ptr %l165, !tbaa !27
  %t393 = load { i64, ptr }, ptr %l165, !tbaa !27
  %t394 = extractvalue { i64, ptr } %t393, 0
  store i64 %t394, ptr %l166, !tbaa !24
  %t395 = load i64, ptr %l166, !tbaa !24
  %t396 = mul i64 %t395, 16
  %t397 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t396)
  %t398 = insertvalue { i64, ptr } undef, i64 %t395, 0
  %t399 = insertvalue { i64, ptr } %t398, ptr %t397, 1
  store { i64, ptr } %t399, ptr %l167, !tbaa !27
  %t400 = getelementptr { i64, ptr }, ptr %l167, i32 0, i32 1
  %t401 = load ptr, ptr %t400, !tbaa !27
  %t402 = getelementptr { i64, ptr }, ptr %l165, i32 0, i32 1
  %t403 = load ptr, ptr %t402, !tbaa !27
  %t404 = load i64, ptr %l166, !tbaa !24
  %t405 = mul i64 %t404, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t401, ptr %t403, i64 %t405, i1 false)
  %t406 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t407 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l161, i32 0, i32 1
  store { i64, ptr } %t406, ptr %t407, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t408 = load { { i64, ptr }, { i64, ptr } }, ptr %l161
  store { { i64, ptr }, { i64, ptr } } %t408, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, ptr }, { i64, ptr } }, ptr %rv
  ret { { i64, ptr }, { i64, ptr } } %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2eStemOf(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l26 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l35 = alloca i64
  %l37 = alloca i64
  %l39 = alloca i64
  %l41 = alloca i64
  %l43 = alloca i64
  %l83 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l118 = alloca { i64, ptr }
  %l119 = alloca i64
  %l120 = alloca i64
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t5 = load i64, ptr %l4, !tbaa !24
  %t6 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l5, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l5, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l17, !tbaa !24
  store i64 %t31, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l14, !tbaa !24
  store i64 %t32, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = sub i64 %t33, 1
  store i64 %t34, ptr %l26, !tbaa !24
  %t35 = load i64, ptr %l6, !tbaa !24
  %t36 = icmp slt i64 %t35, 2147483648
  %t37 = load i64, ptr %l7, !tbaa !24
  %t38 = icmp sge i64 %t37, 0
  %t41 = and i1 %t36, %t38
  %t42 = load i64, ptr %l5, !tbaa !24
  %t43 = mul i64 0, %t42
  %t44 = load i64, ptr %l5, !tbaa !24
  %t45 = mul i64 1, %t44
  %t46 = load i64, ptr %l3, !tbaa !24
  %t48 = add i64 %t46, %t43
  store i64 %t48, ptr %l32, !tbaa !24
  %t50 = add i64 0, %t45
  store i64 %t50, ptr %l33, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t51, 0
  store i64 %t53, ptr %l35, !tbaa !24
  %t54 = load i64, ptr %l7, !tbaa !24
  %t55 = mul i64 0, %t54
  %t57 = add i64 0, %t55
  store i64 %t57, ptr %l37, !tbaa !24
  %t58 = load i64, ptr %l33, !tbaa !24
  %t59 = load i64, ptr %l7, !tbaa !24
  %t60 = mul i64 %t58, %t59
  %t61 = load i64, ptr %l32, !tbaa !24
  %t63 = add i64 %t61, %t60
  store i64 %t63, ptr %l39, !tbaa !24
  %t64 = load i64, ptr %l26, !tbaa !24
  %t65 = mul i64 0, %t64
  %t67 = add i64 0, %t65
  store i64 %t67, ptr %l41, !tbaa !24
  %t68 = load i64, ptr %l33, !tbaa !24
  %t69 = load i64, ptr %l26, !tbaa !24
  %t70 = mul i64 %t68, %t69
  %t71 = load i64, ptr %l32, !tbaa !24
  %t73 = add i64 %t71, %t70
  store i64 %t73, ptr %l43, !tbaa !24
  %t74 = icmp sgt i64 0, -4611686018427387904
  %t75 = icmp slt i64 0, 4611686018427387904
  %t78 = and i1 %t74, %t75
  %t81 = and i1 %t41, %t78
  %t82 = load i64, ptr %l32, !tbaa !24
  %t83 = icmp sgt i64 %t82, -4611686018427387904
  %t84 = load i64, ptr %l32, !tbaa !24
  %t85 = icmp slt i64 %t84, 4611686018427387904
  %t88 = and i1 %t83, %t85
  %t91 = and i1 %t81, %t88
  %t92 = icmp sgt i64 0, -2147483648
  %t93 = icmp slt i64 0, 2147483648
  %t96 = and i1 %t92, %t93
  %t99 = and i1 %t91, %t96
  %t100 = load i64, ptr %l33, !tbaa !24
  %t101 = icmp sgt i64 %t100, -2147483648
  %t102 = load i64, ptr %l33, !tbaa !24
  %t103 = icmp slt i64 %t102, 2147483648
  %t106 = and i1 %t101, %t103
  %t109 = and i1 %t99, %t106
  %t110 = load i64, ptr %l37, !tbaa !24
  %t111 = icmp sle i64 0, %t110
  %t114 = and i1 %t109, %t111
  %t115 = load i64, ptr %l41, !tbaa !24
  %t116 = icmp sle i64 0, %t115
  %t119 = and i1 %t114, %t116
  %t120 = load i64, ptr %l37, !tbaa !24
  %t121 = load i64, ptr %l39, !tbaa !24
  %t122 = icmp sle i64 %t120, %t121
  %t125 = and i1 %t119, %t122
  %t126 = load i64, ptr %l41, !tbaa !24
  %t127 = load i64, ptr %l43, !tbaa !24
  %t128 = icmp sle i64 %t126, %t127
  %t131 = and i1 %t125, %t128
  %t132 = load i64, ptr %l39, !tbaa !24
  %t133 = load i64, ptr %l35, !tbaa !24
  %t134 = icmp sle i64 %t132, %t133
  %t137 = and i1 %t131, %t134
  %t138 = load i64, ptr %l43, !tbaa !24
  %t139 = load i64, ptr %l35, !tbaa !24
  %t140 = icmp sle i64 %t138, %t139
  %t143 = and i1 %t137, %t140
  %t144 = load i64, ptr %l6, !tbaa !24
  %t145 = load i64, ptr %l7, !tbaa !24
  %t146 = icmp sle i64 %t144, %t145
  %t149 = or i1 %t146, %t143
  br i1 %t149, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb21
bb9:
  %t151 = load i64, ptr %l7, !tbaa !24
  %t152 = load i64, ptr %l6, !tbaa !24
  %t155 = icmp slt i64 %t151, %t152
  %t157 = xor i1 %t155, true
  br i1 %t157, label %bb10, label %bb11
bb10:
  br label %bb20
bb11:
  br label %bb12
bb12:
  %t159 = load i64, ptr %l3, !tbaa !24
  %t160 = load i64, ptr %l7, !tbaa !24
  %t161 = load i64, ptr %l5, !tbaa !24
  %t164 = mul i64 %t160, %t161
  %t167 = add i64 %t159, %t164
  store i64 %t167, ptr %l8, !tbaa !24
  %t169 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t169, ptr %l83, !tbaa !27
  %t170 = load i64, ptr %l8, !tbaa !24
  %t172 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !27
  %t174 = getelementptr i8, ptr %t173, i64 %t170
  %t175 = load i8, ptr %t174, !tbaa !32
  %t177 = icmp ne i8 %t175, 46
  br i1 %t177, label %bb13, label %bb14
bb13:
  br label %bb19
bb14:
  br label %bb15
bb15:
  %t179 = load i64, ptr %l2, !tbaa !24
  %t182 = add i64 %t179, 1
  store i64 %t182, ptr %l2, !tbaa !24
  %t184 = load i64, ptr %l2, !tbaa !24
  %t185 = load i64, ptr %l1, !tbaa !24
  %t188 = icmp eq i64 %t184, %t185
  br i1 %t188, label %bb16, label %bb17
bb16:
  %t190 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t190, ptr %l93, !tbaa !27
  %t191 = load i64, ptr %l8, !tbaa !24
  %t192 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t195 = getelementptr i8, ptr %t193, i64 0
  %t196 = sub i64 %t191, 0
  %t197 = insertvalue { i64, ptr } undef, i64 %t196, 0
  %t198 = insertvalue { i64, ptr } %t197, ptr %t195, 1
  store { i64, ptr } %t198, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t200 = load i64, ptr %l7, !tbaa !24
  %t203 = add i64 %t200, 1
  store i64 %t203, ptr %l7, !tbaa !24
  br label %bb9
bb20:
  br label %bb39
bb21:
  %t205 = load i64, ptr %l7, !tbaa !24
  %t206 = load i64, ptr %l6, !tbaa !24
  %t209 = icmp slt i64 %t205, %t206
  %t211 = xor i1 %t209, true
  br i1 %t211, label %bb22, label %bb23
bb22:
  br label %bb38
bb23:
  br label %bb24
bb24:
  %t213 = load i64, ptr %l3, !tbaa !24
  %t214 = load i64, ptr %l7, !tbaa !24
  %t215 = load i64, ptr %l5, !tbaa !24
  %t218 = mul i64 %t214, %t215
  %t221 = add i64 %t213, %t218
  store i64 %t221, ptr %l8, !tbaa !24
  %t223 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t223, ptr %l108, !tbaa !27
  %t224 = load i64, ptr %l8, !tbaa !24
  %t226 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t227 = load ptr, ptr %t226, !tbaa !27
  %t228 = getelementptr i8, ptr %t227, i64 %t224
  %t229 = load i8, ptr %t228, !tbaa !32
  %t231 = icmp ne i8 %t229, 46
  br i1 %t231, label %bb25, label %bb26
bb25:
  br label %bb37
bb26:
  br label %bb27
bb27:
  %t233 = load i64, ptr %l2, !tbaa !24
  %t236 = add i64 %t233, 1
  store i64 %t236, ptr %l2, !tbaa !24
  %t238 = load i64, ptr %l2, !tbaa !24
  %t239 = load i64, ptr %l1, !tbaa !24
  %t242 = icmp eq i64 %t238, %t239
  br i1 %t242, label %bb28, label %bb29
bb28:
  %t244 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t244, ptr %l118, !tbaa !27
  %t245 = load i64, ptr %l8, !tbaa !24
  store i64 %t245, ptr %l119, !tbaa !24
  %t246 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t247 = extractvalue { i64, ptr } %t246, 0
  store i64 %t247, ptr %l120, !tbaa !24
  %t248 = icmp sge i64 0, 0
  br i1 %t248, label %bb30, label %bb31
bb29:
  br label %bb36
bb30:
  %t250 = load i64, ptr %l119, !tbaa !24
  %t251 = icmp sle i64 0, %t250
  br i1 %t251, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @olang_loc_32a3ed5515231110_c7421fb70a543f2c)
  unreachable
bb32:
  %t253 = load i64, ptr %l119, !tbaa !24
  %t254 = load i64, ptr %l120, !tbaa !24
  %t255 = icmp sle i64 %t253, %t254
  br i1 %t255, label %bb34, label %bb35
bb33:
  call void @__olang_check_failed(ptr @olang_loc_32a3ed5515231110_c7421fb70a543f2c)
  unreachable
bb34:
  %t257 = getelementptr { i64, ptr }, ptr %l118, i32 0, i32 1
  %t258 = load ptr, ptr %t257, !tbaa !27
  %t259 = load i64, ptr %l119, !tbaa !24
  %t260 = getelementptr i8, ptr %t258, i64 0
  %t261 = sub i64 %t259, 0
  %t262 = insertvalue { i64, ptr } undef, i64 %t261, 0
  %t263 = insertvalue { i64, ptr } %t262, ptr %t260, 1
  store { i64, ptr } %t263, ptr %rv
  br label %ret
bb35:
  call void @__olang_check_failed(ptr @olang_loc_32a3ed5515231110_c7421fb70a543f2c)
  unreachable
bb36:
  br label %bb37
bb37:
  %t265 = load i64, ptr %l7, !tbaa !24
  %t268 = add i64 %t265, 1
  store i64 %t268, ptr %l7, !tbaa !24
  br label %bb21
bb38:
  br label %bb39
bb39:
  %t270 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t270, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fbuild_2eTestFiles(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca i1
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l22 = alloca %"std/os:Output"
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l30 = alloca i1
  %l31 = alloca i1
  %l34 = alloca i1
  %l36 = alloca i1
  %l41 = alloca i1
  %l45 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l57 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l71 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l96 = alloca %"std/os:Output"
  %l98 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l100 = alloca %"std/os:Output"
  %l101 = alloca i32
  %l103 = alloca i1
  %l110 = alloca { i64, ptr }
  %l114 = alloca ptr
  %l115 = alloca { i64, ptr }
  %l118 = alloca { i64, ptr }
  %l121 = alloca { i64, ptr }
  %l127 = alloca i1
  %l135 = alloca i1
  %l140 = alloca i64
  %l141 = alloca i64
  %l144 = alloca { i64, ptr }
  %l149 = alloca i1
  %l153 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l161 = alloca { i64, ptr }
  %l164 = alloca ptr
  %l165 = alloca i64
  %l173 = alloca ptr
  %l175 = alloca { i64, ptr }
  %l178 = alloca { i64, ptr }
  %l182 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @compiler_2fspin_2eEnd()
  br label %bb1
bb1:
  %t1 = call i64 @std_2ftime_2eNow()
  store i64 %t1, ptr %l28
  br label %bb2
bb2:
  %t2 = load i64, ptr %l28, !tbaa !24
  store i64 %t2, ptr %l5, !tbaa !24
  store i1 false, ptr %l6, !tbaa !21
  store i1 false, ptr %l7, !tbaa !21
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i1 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eracesSpawners(ptr %v0, ptr %t3)
  store i1 %t5, ptr %l30
  br label %bb3
bb3:
  %t6 = load i1, ptr %l30, !tbaa !21
  br i1 %t6, label %bb4, label %bb5
bb4:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/build:Config", ptr %t7, i32 0, i32 1
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  %t12 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t10, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d34, i32 0, i32 1) })
  store i1 %t12, ptr %l34
  br label %bb6
bb5:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb7
bb6:
  %t13 = load i1, ptr %l34, !tbaa !21
  %t14 = xor i1 %t13, true
  store i1 %t14, ptr %l31, !tbaa !21
  br label %bb7
bb7:
  %t16 = load i1, ptr %l31, !tbaa !21
  br i1 %t16, label %bb8, label %bb9
bb8:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/build:Config", ptr %t17, i32 0, i32 1
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/build:Config", ptr %t21, i32 0, i32 2
  %t24 = getelementptr %"compiler/target:Target", ptr %t23, i32 0, i32 2
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  %t28 = call i1 @compiler_2ftarget_2eHasRaceRuntime(ptr %v0, ptr %v0, { i64, ptr } %t20, { i64, ptr } %t25)
  store i1 %t28, ptr %l41
  br label %bb10
bb9:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb11
bb10:
  %t29 = load i1, ptr %l41, !tbaa !21
  %t30 = xor i1 %t29, true
  store i1 %t30, ptr %l36, !tbaa !21
  br label %bb11
bb11:
  %t32 = load i1, ptr %l36, !tbaa !21
  store i1 %t32, ptr %l8, !tbaa !21
  %t33 = load i1, ptr %l8, !tbaa !21
  br i1 %t33, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s1
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2enoRaceRuntime(ptr %v0, ptr %s1, ptr %t35)
  store { i64, ptr } %t37, ptr %l45
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t38 = load { i64, ptr }, ptr %l45, !tbaa !27
  call void @compiler_2fbuild_2esayln(ptr %s1, { i64, ptr } %t38)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s1)
  br label %bb16
bb16:
  %t40 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t40, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  store i64 %t44, ptr %l11, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t46 = load i64, ptr %l10, !tbaa !24
  %t47 = load i64, ptr %l11, !tbaa !24
  %t50 = icmp slt i64 %t46, %t47
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb69
bb19:
  br label %bb20
bb20:
  %t54 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t54, ptr %l54, !tbaa !27
  %t55 = load i64, ptr %l10, !tbaa !24
  %t57 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr { i64, ptr }, ptr %t58, i64 %t55
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !37
  store { i64, ptr } %t60, ptr %l12, !tbaa !27
  %t62 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t62, ptr %l57
  br label %bb21
bb21:
  %t63 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l57
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t63, ptr %l13
  %t64 = load i1, ptr %l8, !tbaa !21
  br i1 %t64, label %bb22, label %bb23
bb22:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s3, ptr %s3, ptr %l13, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d35, i32 0, i32 1) })
  br label %bb24
bb23:
  br label %bb26
bb24:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s3, ptr %s3, ptr %l13, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d36, i32 0, i32 1) })
  br label %bb25
bb25:
  br label %bb26
bb26:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s3, ptr %v1, ptr %l13, { i64, ptr } %a1)
  br label %bb27
bb27:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s3, ptr %s3, ptr %l13, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d37, i32 0, i32 1) })
  br label %bb28
bb28:
  store { i64, ptr } %a2, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t74 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t74, 0
  store i64 %t76, ptr %l16, !tbaa !24
  br label %bb29
bb29:
  %t78 = load i64, ptr %l15, !tbaa !24
  %t79 = load i64, ptr %l16, !tbaa !24
  %t82 = icmp slt i64 %t78, %t79
  %t84 = xor i1 %t82, true
  br i1 %t84, label %bb30, label %bb31
bb30:
  br label %bb35
bb31:
  br label %bb32
bb32:
  %t86 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t86, ptr %l71, !tbaa !27
  %t87 = load i64, ptr %l15, !tbaa !24
  %t89 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr { i64, ptr }, ptr %t90, i64 %t87
  %t92 = load { i64, ptr }, ptr %t91, !tbaa !37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s3, ptr %v2, ptr %l13, { i64, ptr } %t92)
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t97 = load i64, ptr %l15, !tbaa !24
  %t100 = add i64 %t97, 1
  store i64 %t100, ptr %l15, !tbaa !24
  br label %bb29
bb35:
  %t102 = load { i64, ptr }, ptr %l12, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s3, ptr %v3, ptr %l13, { i64, ptr } %t102)
  br label %bb36
bb36:
  %t105 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t105, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t107 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t107, 0
  store i64 %t109, ptr %l20, !tbaa !24
  br label %bb37
bb37:
  %t111 = load i64, ptr %l19, !tbaa !24
  %t112 = load i64, ptr %l20, !tbaa !24
  %t115 = icmp slt i64 %t111, %t112
  %t117 = xor i1 %t115, true
  br i1 %t117, label %bb38, label %bb39
bb38:
  br label %bb43
bb39:
  br label %bb40
bb40:
  %t119 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t119, ptr %l88, !tbaa !27
  %t120 = load i64, ptr %l19, !tbaa !24
  %t122 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = getelementptr { i64, ptr }, ptr %t123, i64 %t120
  %t125 = load { i64, ptr }, ptr %t124, !tbaa !37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s3, ptr %v4, ptr %l13, { i64, ptr } %t125)
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t130 = load i64, ptr %l19, !tbaa !24
  %t133 = add i64 %t130, 1
  store i64 %t133, ptr %l19, !tbaa !24
  br label %bb37
bb43:
  %t136 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %s3, ptr %s3, ptr %l13)
  store { i64, ptr } %t136, ptr %l98
  br label %bb44
bb44:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %l99, !tbaa !27
  %t137 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t138 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t139 = call { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExec(ptr %s3, ptr %s3, ptr %s3, ptr %s3, { i64, ptr } %t137, { i64, ptr } %t138, i1 false, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d39, i32 0, i32 1) })
  %t140 = extractvalue { i32, %"std/os:Output" } %t139, 1
  %t141 = extractvalue { i32, %"std/os:Output" } %t139, 0
  store i32 %t141, ptr %l101
  %t142 = icmp ne i32 %t141, 0
  br i1 %t142, label %bb46, label %ok.143, !prof !99
ok.143:
  store %"std/os:Output" %t140, ptr %l100
  br label %bb45
bb45:
  %t144 = load %"std/os:Output", ptr %l100
  store %"std/os:Output" %t144, ptr %l96
  br label %bb52
bb46:
  %t145 = load i32, ptr %l101, !tbaa !23
  %t146 = ashr i32 %t145, 16
  %t148 = icmp eq i32 %t146, 1
  store i1 %t148, ptr %l103, !tbaa !21
  %t149 = load i32, ptr %l101, !tbaa !23
  %t150 = ashr i32 %t149, 16
  %t152 = icmp eq i32 %t150, 1
  br i1 %t152, label %bb47, label %bb48
bb47:
  call void @__olang_errpay_pop()
  br label %bb48
bb48:
  br label %bb49
bb49:
  store %olang.scope zeroinitializer, ptr %s11
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t157 = extractvalue { i64, ptr } %t155, 1
  %t158 = extractvalue { i64, ptr } %t155, 0
  %t159 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d40, i32 0, i32 1) }, 1
  %t160 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d40, i32 0, i32 1) }, 0
  %t161 = add i64 %t158, %t160
  %t162 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t161)
  call void @olang_textcopy(ptr %t162, ptr %t157, i64 %t158)
  %t163 = getelementptr i8, ptr %t162, i64 %t158
  call void @olang_textcopy(ptr %t163, ptr %t159, i64 %t160)
  %t164 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t165 = insertvalue { i64, ptr } %t164, ptr %t162, 1
  %t169 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %s11, ptr %s11, ptr %s11, ptr %t154, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d41, i32 0, i32 1) }, { i64, ptr } %t165)
  store { i64, ptr } %t169, ptr %l110
  br label %bb50
bb50:
  %t170 = load { i64, ptr }, ptr %l110, !tbaa !27
  call void @compiler_2fbuild_2esayln(ptr %s11, { i64, ptr } %t170)
  br label %bb51
bb51:
  store i1 true, ptr %l6, !tbaa !21
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s3)
  br label %bb68
bb52:
  %t172 = load %"std/os:Output", ptr %l96
  store %"std/os:Output" %t172, ptr %l22
  %t173 = getelementptr %"std/os:Output", ptr %l22, i32 0, i32 0
  %t174 = load i32, ptr %t173, !tbaa !23
  %t176 = icmp sgt i32 %t174, 128
  br i1 %t176, label %bb53, label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s13
  %t178 = load ptr, ptr %l0, !tbaa !29
  store ptr %t178, ptr %l114, !tbaa !29
  %t179 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t179, ptr %l115, !tbaa !27
  %t180 = getelementptr %"std/os:Output", ptr %l22, i32 0, i32 0
  %t181 = load i32, ptr %t180, !tbaa !23
  %t183 = sub i32 %t181, 128
  %t185 = call { i64, ptr } @compiler_2fbuild_2eSignalName(ptr %s13, i32 %t183)
  store { i64, ptr } %t185, ptr %l118
  br label %bb55
bb54:
  br label %bb58
bb55:
  %t186 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t187 = extractvalue { i64, ptr } %t186, 1
  %t188 = extractvalue { i64, ptr } %t186, 0
  %t189 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t190 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t191 = add i64 %t188, %t190
  %t192 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t192, 1
  %t194 = extractvalue { i64, ptr } %t192, 0
  %t195 = add i64 %t191, %t194
  %t196 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t197 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t198 = add i64 %t195, %t197
  %t199 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t198)
  call void @olang_textcopy(ptr %t199, ptr %t187, i64 %t188)
  %t200 = getelementptr i8, ptr %t199, i64 %t188
  call void @olang_textcopy(ptr %t200, ptr %t189, i64 %t190)
  %t201 = getelementptr i8, ptr %t200, i64 %t190
  call void @olang_textcopy(ptr %t201, ptr %t193, i64 %t194)
  %t202 = getelementptr i8, ptr %t201, i64 %t194
  call void @olang_textcopy(ptr %t202, ptr %t196, i64 %t197)
  %t203 = insertvalue { i64, ptr } undef, i64 %t198, 0
  %t204 = insertvalue { i64, ptr } %t203, ptr %t199, 1
  %t206 = load ptr, ptr %l114, !tbaa !29
  %t208 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %s13, ptr %s13, ptr %s13, ptr %t206, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d44, i32 0, i32 1) }, { i64, ptr } %t204)
  store { i64, ptr } %t208, ptr %l121
  br label %bb56
bb56:
  %t209 = load { i64, ptr }, ptr %l121, !tbaa !27
  call void @compiler_2fbuild_2esayln(ptr %s13, { i64, ptr } %t209)
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s13)
  br label %bb58
bb58:
  %t211 = getelementptr %"std/os:Output", ptr %l22, i32 0, i32 0
  %t212 = load i32, ptr %t211, !tbaa !23
  %t214 = icmp ne i32 %t212, 3
  br i1 %t214, label %bb59, label %bb60
bb59:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb61
bb60:
  br label %bb61
bb61:
  %t216 = getelementptr %"std/os:Output", ptr %l22, i32 0, i32 0
  %t217 = load i32, ptr %t216, !tbaa !23
  %t219 = icmp ne i32 %t217, 0
  br i1 %t219, label %bb62, label %bb63
bb62:
  %t221 = getelementptr %"std/os:Output", ptr %l22, i32 0, i32 0
  %t222 = load i32, ptr %t221, !tbaa !23
  %t224 = icmp ne i32 %t222, 3
  store i1 %t224, ptr %l127, !tbaa !21
  br label %bb64
bb63:
  store i1 false, ptr %l127, !tbaa !21
  br label %bb64
bb64:
  %t226 = load i1, ptr %l127, !tbaa !21
  br i1 %t226, label %bb65, label %bb66
bb65:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb67
bb66:
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s3)
  br label %bb68
bb68:
  %t227 = load i64, ptr %l10, !tbaa !24
  %t230 = add i64 %t227, 1
  store i64 %t230, ptr %l10, !tbaa !24
  br label %bb17
bb69:
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t234 = getelementptr %"compiler/build:Config", ptr %t232, i32 0, i32 20
  %t235 = load i1, ptr %t234, !tbaa !21
  br i1 %t235, label %bb70, label %bb71
bb70:
  %t237 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t239 = extractvalue { i64, ptr } %t237, 0
  %t241 = icmp sgt i64 %t239, 1
  store i1 %t241, ptr %l135, !tbaa !21
  br label %bb72
bb71:
  store i1 false, ptr %l135, !tbaa !21
  br label %bb72
bb72:
  %t243 = load i1, ptr %l135, !tbaa !21
  br i1 %t243, label %bb73, label %bb74
bb73:
  store %olang.scope zeroinitializer, ptr %s18
  %t244 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t246 = extractvalue { i64, ptr } %t244, 0
  store i64 %t246, ptr %l140, !tbaa !24
  %t247 = call i64 @std_2ftime_2eNow()
  store i64 %t247, ptr %l141
  br label %bb75
bb74:
  br label %bb78
bb75:
  %t248 = load i64, ptr %l5, !tbaa !24
  %t249 = load i64, ptr %l141, !tbaa !24
  %t251 = sub i64 %t249, %t248
  %t252 = load i64, ptr %l140, !tbaa !24
  %t254 = call { i64, ptr } @compiler_2fmeasure_2eTotal(ptr %s18, i64 %t252, i64 %t251)
  store { i64, ptr } %t254, ptr %l144
  br label %bb76
bb76:
  %t255 = load { i64, ptr }, ptr %l144, !tbaa !27
  %t256 = extractvalue { i64, ptr } %t255, 1
  %t257 = extractvalue { i64, ptr } %t255, 0
  %t258 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t259 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  %t260 = add i64 %t257, %t259
  %t261 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t260)
  call void @olang_textcopy(ptr %t261, ptr %t256, i64 %t257)
  %t262 = getelementptr i8, ptr %t261, i64 %t257
  call void @olang_textcopy(ptr %t262, ptr %t258, i64 %t259)
  %t263 = insertvalue { i64, ptr } undef, i64 %t260, 0
  %t264 = insertvalue { i64, ptr } %t263, ptr %t261, 1
  call void @compiler_2fbuild_2esayErr(ptr %s18, { i64, ptr } %t264)
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s18)
  br label %bb78
bb78:
  %t267 = load i1, ptr %l7, !tbaa !21
  %t269 = xor i1 %t267, true
  br i1 %t269, label %bb79, label %bb80
bb79:
  %t271 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t273 = extractvalue { i64, ptr } %t271, 0
  %t275 = icmp sgt i64 %t273, 0
  store i1 %t275, ptr %l149, !tbaa !21
  br label %bb81
bb80:
  store i1 false, ptr %l149, !tbaa !21
  br label %bb81
bb81:
  %t277 = load i1, ptr %l149, !tbaa !21
  br i1 %t277, label %bb82, label %bb83
bb82:
  store %olang.scope zeroinitializer, ptr %s20
  %t278 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s20, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t278, ptr %l153
  br label %bb84
bb83:
  br label %bb97
bb84:
  %t279 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l153
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t279, ptr %l23
  %t280 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t280, ptr %l24, !tbaa !27
  store i64 0, ptr %l25, !tbaa !24
  %t282 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t284 = extractvalue { i64, ptr } %t282, 0
  store i64 %t284, ptr %l26, !tbaa !24
  br label %bb85
bb85:
  %t286 = load i64, ptr %l25, !tbaa !24
  %t287 = load i64, ptr %l26, !tbaa !24
  %t290 = icmp slt i64 %t286, %t287
  %t292 = xor i1 %t290, true
  br i1 %t292, label %bb86, label %bb87
bb86:
  br label %bb93
bb87:
  br label %bb88
bb88:
  %t294 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t294, ptr %l161, !tbaa !27
  %t295 = load i64, ptr %l25, !tbaa !24
  %t297 = getelementptr { i64, ptr }, ptr %l161, i32 0, i32 1
  %t298 = load ptr, ptr %t297, !tbaa !27
  %t299 = getelementptr { i64, ptr }, ptr %t298, i64 %t295
  %t300 = load { i64, ptr }, ptr %t299, !tbaa !37
  store { i64, ptr } %t300, ptr %l27, !tbaa !27
  store ptr %l23, ptr %l164, !tbaa !29
  %t302 = call ptr @__olang_scope_hold(ptr %s20)
  %t303 = ptrtoint ptr %t302 to i64
  store i64 %t303, ptr %l165, !tbaa !24
  %t304 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t304, label %bb89, label %bb90
bb89:
  %t306 = call ptr @__olang_region_make(ptr %s20)
  %t307 = ptrtoint ptr %t306 to i64
  store i64 %t307, ptr %l165, !tbaa !24
  br label %bb90
bb90:
  %t308 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t309 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t310 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  %t312 = extractvalue { i64, ptr } %t308, 1
  %t313 = extractvalue { i64, ptr } %t308, 0
  %t314 = add i64 %t310, %t313
  %t315 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t316 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  %t317 = add i64 %t314, %t316
  %t318 = load i64, ptr %l165
  %t319 = inttoptr i64 %t318 to ptr
  %t320 = call ptr @__olang_held_alloc(ptr %t319, i64 %t317)
  call void @olang_textcopy(ptr %t320, ptr %t309, i64 %t310)
  %t321 = getelementptr i8, ptr %t320, i64 %t310
  call void @olang_textcopy(ptr %t321, ptr %t312, i64 %t313)
  %t322 = getelementptr i8, ptr %t321, i64 %t313
  call void @olang_textcopy(ptr %t322, ptr %t315, i64 %t316)
  %t323 = insertvalue { i64, ptr } undef, i64 %t317, 0
  %t324 = insertvalue { i64, ptr } %t323, ptr %t320, 1
  %t326 = load ptr, ptr %l164, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s20, ptr %s20, ptr %t326, { i64, ptr } %t324)
  br label %bb91
bb91:
  br label %bb92
bb92:
  %t328 = load i64, ptr %l25, !tbaa !24
  %t331 = add i64 %t328, 1
  store i64 %t331, ptr %l25, !tbaa !24
  br label %bb85
bb93:
  %t333 = load ptr, ptr %l0, !tbaa !29
  store ptr %t333, ptr %l173, !tbaa !29
  %t335 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s20, ptr %s20, ptr %s20, ptr %l23, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d48, i32 0, i32 1) })
  store { i64, ptr } %t335, ptr %l175
  br label %bb94
bb94:
  %t336 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t337 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  %t338 = load { i64, ptr }, ptr %l175, !tbaa !27
  %t339 = extractvalue { i64, ptr } %t338, 1
  %t340 = extractvalue { i64, ptr } %t338, 0
  %t341 = add i64 %t337, %t340
  %t342 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t341)
  call void @olang_textcopy(ptr %t342, ptr %t336, i64 %t337)
  %t343 = getelementptr i8, ptr %t342, i64 %t337
  call void @olang_textcopy(ptr %t343, ptr %t339, i64 %t340)
  %t344 = insertvalue { i64, ptr } undef, i64 %t341, 0
  %t345 = insertvalue { i64, ptr } %t344, ptr %t342, 1
  %t347 = load ptr, ptr %l173, !tbaa !29
  %t349 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %s20, ptr %s20, ptr %s20, ptr %t347, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d50, i32 0, i32 1) }, { i64, ptr } %t345)
  store { i64, ptr } %t349, ptr %l178
  br label %bb95
bb95:
  %t350 = load { i64, ptr }, ptr %l178, !tbaa !27
  call void @compiler_2fbuild_2esayln(ptr %s20, { i64, ptr } %t350)
  br label %bb96
bb96:
  call void @__olang_scope_close(ptr %s20)
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb97:
  %t353 = load i1, ptr %l6, !tbaa !21
  br i1 %t353, label %bb98, label %bb99
bb98:
  store i32 1, ptr %l182, !tbaa !23
  br label %bb100
bb99:
  store i32 0, ptr %l182, !tbaa !23
  br label %bb100
bb100:
  call void @__olang_scope_close(ptr %s0)
  %t355 = load i32, ptr %l182, !tbaa !23
  store i32 %t355, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2fbuild_2ecloseness(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l12 = alloca i64
  %l27 = alloca i64
  %l30 = alloca i64
  %l48 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l50 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l60 = alloca i64
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = call i64 @compiler_2fmsgs_2eDistance(ptr %v0, ptr %v1, { i64, ptr } %t1, { i64, ptr } %t2)
  store i64 %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load i64, ptr %l12, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t10 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  %t15 = icmp sgt i64 %t9, %t12
  br i1 %t15, label %bb2, label %bb3
bb2:
  store i64 0, ptr %l3, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 0
  %t25 = sub i64 %t19, %t22
  %t27 = add i64 %t25, 1
  store i64 %t27, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t29 = load i64, ptr %l4, !tbaa !24
  %t30 = load i64, ptr %l3, !tbaa !24
  %t33 = icmp sgt i64 %t29, %t30
  br i1 %t33, label %bb4, label %bb5
bb3:
  br label %bb26
bb4:
  %t35 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp sgt i64 %t35, 0
  br i1 %t37, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb9
bb6:
  %t39 = load i64, ptr %l4, !tbaa !24
  %t40 = load i64, ptr %l3, !tbaa !24
  %t43 = sub i64 %t39, %t40
  %t44 = load i64, ptr %l5, !tbaa !24
  %t47 = add i64 %t43, %t44
  %t49 = sub i64 %t47, 1
  %t50 = load i64, ptr %l5, !tbaa !24
  %t53 = sdiv i64 %t49, %t50
  store i64 %t53, ptr %l30, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb8
bb8:
  %t55 = load i64, ptr %l30, !tbaa !24
  store i64 %t55, ptr %l27, !tbaa !24
  br label %bb9
bb9:
  %t56 = load i64, ptr %l27, !tbaa !24
  store i64 %t56, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb10
bb10:
  %t57 = load i64, ptr %l7, !tbaa !24
  %t58 = load i64, ptr %l6, !tbaa !24
  %t61 = icmp slt i64 %t57, %t58
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb11, label %bb12
bb11:
  br label %bb25
bb12:
  br label %bb13
bb13:
  %t65 = load i64, ptr %l3, !tbaa !24
  %t66 = load i64, ptr %l7, !tbaa !24
  %t67 = load i64, ptr %l5, !tbaa !24
  %t70 = mul i64 %t66, %t67
  %t73 = add i64 %t65, %t70
  store i64 %t73, ptr %l8, !tbaa !24
  %t75 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t75, ptr %l48, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t76, ptr %l49, !tbaa !27
  %t77 = load i64, ptr %l8, !tbaa !24
  store i64 %t77, ptr %l50, !tbaa !24
  %t78 = load i64, ptr %l8, !tbaa !24
  %t79 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t84 = add i64 %t78, %t81
  store i64 %t84, ptr %l54, !tbaa !24
  %t85 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 0
  store i64 %t86, ptr %l55, !tbaa !24
  %t87 = load i64, ptr %l50, !tbaa !24
  %t88 = icmp sge i64 %t87, 0
  br i1 %t88, label %bb14, label %bb15
bb14:
  %t90 = load i64, ptr %l50, !tbaa !24
  %t91 = load i64, ptr %l54, !tbaa !24
  %t92 = icmp sle i64 %t90, %t91
  br i1 %t92, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_7d17f382592ac8ef_3cd22268ed245003)
  unreachable
bb16:
  %t94 = load i64, ptr %l54, !tbaa !24
  %t95 = load i64, ptr %l55, !tbaa !24
  %t96 = icmp sle i64 %t94, %t95
  br i1 %t96, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_7d17f382592ac8ef_3cd22268ed245003)
  unreachable
bb18:
  %t98 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = load i64, ptr %l50, !tbaa !24
  %t101 = load i64, ptr %l54, !tbaa !24
  %t102 = getelementptr i8, ptr %t99, i64 %t100
  %t103 = sub i64 %t101, %t100
  %t104 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t105 = insertvalue { i64, ptr } %t104, ptr %t102, 1
  %t106 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t108 = call i64 @compiler_2fmsgs_2eDistance(ptr %v0, ptr %v1, { i64, ptr } %t106, { i64, ptr } %t105)
  store i64 %t108, ptr %l60
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_7d17f382592ac8ef_3cd22268ed245003)
  unreachable
bb20:
  %t109 = load i64, ptr %l60, !tbaa !24
  store i64 %t109, ptr %l9, !tbaa !24
  %t110 = load i64, ptr %l9, !tbaa !24
  %t111 = load i64, ptr %l2, !tbaa !24
  %t114 = icmp slt i64 %t110, %t111
  br i1 %t114, label %bb21, label %bb22
bb21:
  %t116 = load i64, ptr %l9, !tbaa !24
  store i64 %t116, ptr %l2, !tbaa !24
  br label %bb23
bb22:
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t118 = load i64, ptr %l7, !tbaa !24
  %t121 = add i64 %t118, 1
  store i64 %t121, ptr %l7, !tbaa !24
  br label %bb10
bb25:
  br label %bb26
bb26:
  %t123 = load i64, ptr %l2, !tbaa !24
  store i64 %t123, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eCFlags(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca ptr
  %l7 = alloca i64
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l20 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i64
  %l30 = alloca i1
  %l38 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l3
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/build:Config", ptr %t3, i32 0, i32 2
  %t6 = getelementptr %"compiler/target:Target", ptr %t5, i32 0, i32 9
  %t7 = load i1, ptr %t6, !tbaa !21
  br i1 %t7, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  store ptr %l1, ptr %l6, !tbaa !29
  %t9 = call ptr @__olang_scope_hold(ptr %v1)
  %t10 = ptrtoint ptr %t9 to i64
  store i64 %t10, ptr %l7, !tbaa !24
  %t11 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t11, label %bb4, label %bb5
bb3:
  br label %bb19
bb4:
  %t13 = call ptr @__olang_region_make(ptr %v1)
  %t14 = ptrtoint ptr %t13 to i64
  store i64 %t14, ptr %l7, !tbaa !24
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/build:Config", ptr %t15, i32 0, i32 2
  %t18 = getelementptr %"compiler/target:Target", ptr %t17, i32 0, i32 1
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  %t20 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  %t23 = extractvalue { i64, ptr } %t19, 1
  %t24 = extractvalue { i64, ptr } %t19, 0
  %t25 = add i64 %t21, %t24
  %t26 = load i64, ptr %l7
  %t27 = inttoptr i64 %t26 to ptr
  %t28 = call ptr @__olang_held_alloc(ptr %t27, i64 %t25)
  call void @olang_textcopy(ptr %t28, ptr %t20, i64 %t21)
  %t29 = getelementptr i8, ptr %t28, i64 %t21
  call void @olang_textcopy(ptr %t29, ptr %t23, i64 %t24)
  %t30 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t28, 1
  %t33 = load ptr, ptr %l6, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t33, { i64, ptr } %t31)
  br label %bb6
bb6:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/build:Config", ptr %t35, i32 0, i32 2
  %t38 = getelementptr %"compiler/target:Target", ptr %t37, i32 0, i32 13
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  %t41 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t39, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d52, i32 0, i32 1) })
  store i1 %t41, ptr %l15
  br label %bb7
bb7:
  %t42 = load i1, ptr %l15, !tbaa !21
  br i1 %t42, label %bb8, label %bb9
bb8:
  %t43 = call { i64, ptr } @compiler_2ftarget_2eSysroot(ptr %s1)
  store { i64, ptr } %t43, ptr %l17
  br label %bb10
bb9:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d53, i32 0, i32 1) }, ptr %l16, !tbaa !27
  br label %bb11
bb10:
  %t44 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t44, ptr %l16, !tbaa !27
  br label %bb11
bb11:
  %t46 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t46, ptr %l2, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t49 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s1, { i64, ptr } %t47, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d54, i32 0, i32 1) })
  store i1 %t49, ptr %l20
  br label %bb12
bb12:
  %t50 = load i1, ptr %l20, !tbaa !21
  %t51 = xor i1 %t50, true
  br i1 %t51, label %bb13, label %bb14
bb13:
  store ptr %l1, ptr %l22, !tbaa !29
  %t53 = call ptr @__olang_scope_hold(ptr %v1)
  %t54 = ptrtoint ptr %t53 to i64
  store i64 %t54, ptr %l23, !tbaa !24
  %t55 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t55, label %bb15, label %bb16
bb14:
  br label %bb18
bb15:
  %t57 = call ptr @__olang_region_make(ptr %v1)
  %t58 = ptrtoint ptr %t57 to i64
  store i64 %t58, ptr %l23, !tbaa !24
  br label %bb16
bb16:
  %t59 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t60 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d55, i32 0, i32 1) }, 1
  %t61 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d55, i32 0, i32 1) }, 0
  %t63 = extractvalue { i64, ptr } %t59, 1
  %t64 = extractvalue { i64, ptr } %t59, 0
  %t65 = add i64 %t61, %t64
  %t66 = load i64, ptr %l23
  %t67 = inttoptr i64 %t66 to ptr
  %t68 = call ptr @__olang_held_alloc(ptr %t67, i64 %t65)
  call void @olang_textcopy(ptr %t68, ptr %t60, i64 %t61)
  %t69 = getelementptr i8, ptr %t68, i64 %t61
  call void @olang_textcopy(ptr %t69, ptr %t63, i64 %t64)
  %t70 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t68, 1
  %t73 = load ptr, ptr %l22, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t73, { i64, ptr } %t71)
  br label %bb17
bb17:
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s1)
  br label %bb19
bb19:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/build:Config", ptr %t75, i32 0, i32 12
  %t78 = load { i64, ptr }, ptr %t77, !tbaa !27
  %t80 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t78, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d56, i32 0, i32 1) })
  store i1 %t80, ptr %l30
  br label %bb20
bb20:
  %t81 = load i1, ptr %l30, !tbaa !21
  %t82 = xor i1 %t81, true
  br i1 %t82, label %bb21, label %bb22
bb21:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %l1, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d57, i32 0, i32 1) })
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/build:Config", ptr %t85, i32 0, i32 12
  %t88 = load { i64, ptr }, ptr %t87, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v0, ptr %l1, { i64, ptr } %t88)
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/build:Config", ptr %t91, i32 0, i32 2
  %t94 = getelementptr %"compiler/target:Target", ptr %t93, i32 0, i32 6
  %t95 = load { i64, ptr }, ptr %t94, !tbaa !27
  %t97 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t95, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d58, i32 0, i32 1) })
  store i1 %t97, ptr %l38
  br label %bb26
bb26:
  %t98 = load i1, ptr %l38, !tbaa !21
  %t99 = xor i1 %t98, true
  br i1 %t99, label %bb27, label %bb28
bb27:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/build:Config", ptr %t101, i32 0, i32 2
  %t104 = getelementptr %"compiler/target:Target", ptr %t103, i32 0, i32 6
  %t105 = load { i64, ptr }, ptr %t104, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v0, ptr %l1, { i64, ptr } %t105)
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb30
bb30:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %l1, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d59, i32 0, i32 1) })
  br label %bb31
bb31:
  %t109 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t109, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eDataFlags(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca i64
  %l11 = alloca i64
  %l16 = alloca { i64, ptr }
  %l18 = alloca i1
  %l20 = alloca i1
  %l22 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eModeFlags(ptr %v0, ptr %v1, ptr %a0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l7
  br label %bb2
bb2:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  %t7 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  store ptr %t7, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = load i64, ptr %l3, !tbaa !24
  store i64 %t9, ptr %l9, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v1, ptr %t10)
  store i64 %t12, ptr %l11
  br label %bb4
bb4:
  %t13 = load i64, ptr %l9, !tbaa !24
  %t14 = load i64, ptr %l11, !tbaa !24
  %t15 = icmp slt i64 %t13, %t14
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb6:
  br label %bb7
bb7:
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t20 = load i64, ptr %l3, !tbaa !24
  %t23 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t19, i64 %t20)
  store { i64, ptr } %t23, ptr %l16
  br label %bb8
bb8:
  %t24 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t24, ptr %l4, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t27 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s2, { i64, ptr } %t25, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d60, i32 0, i32 1) })
  store i1 %t27, ptr %l18
  br label %bb9
bb9:
  %t28 = load i1, ptr %l18, !tbaa !21
  %t29 = xor i1 %t28, true
  br i1 %t29, label %bb10, label %bb11
bb10:
  %t31 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t33 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s2, { i64, ptr } %t31, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d61, i32 0, i32 1) })
  store i1 %t33, ptr %l22
  br label %bb12
bb11:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb13
bb12:
  %t34 = load i1, ptr %l22, !tbaa !21
  %t35 = xor i1 %t34, true
  store i1 %t35, ptr %l20, !tbaa !21
  br label %bb13
bb13:
  %t37 = load i1, ptr %l20, !tbaa !21
  br i1 %t37, label %bb14, label %bb15
bb14:
  %t38 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %l1, { i64, ptr } %t38)
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  %t41 = load i64, ptr %l3, !tbaa !24
  %t44 = add i64 %t41, 1
  store i64 %t44, ptr %l3, !tbaa !24
  br label %bb3
bb19:
  %t46 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t46, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eLink(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, i1 %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca ptr
  %l8 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca %"std/prelude/text:StringBuilder"
  %l12 = alloca ptr
  %l13 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca ptr
  %l27 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca %"std/os:Output"
  %l32 = alloca %"std/os:FileInfo"
  %l33 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l38 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l40 = alloca i64
  %l42 = alloca i64
  %l47 = alloca { i64, ptr }
  %l55 = alloca i1
  %l58 = alloca i1
  %l59 = alloca i1
  %l62 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i64
  %l70 = alloca ptr
  %l71 = alloca i64
  %l77 = alloca ptr
  %l78 = alloca i64
  %l85 = alloca ptr
  %l86 = alloca i64
  %l92 = alloca ptr
  %l93 = alloca i64
  %l99 = alloca ptr
  %l100 = alloca i64
  %l111 = alloca %"std/prelude/text:StringBuilder"
  %l114 = alloca i64
  %l116 = alloca i64
  %l121 = alloca { i64, ptr }
  %l130 = alloca { i64, ptr }
  %l132 = alloca { i64, ptr }
  %l135 = alloca i32
  %l137 = alloca i1
  %l141 = alloca ptr
  %l142 = alloca i64
  %l147 = alloca ptr
  %l148 = alloca i64
  %l151 = alloca { i64, ptr }
  %l158 = alloca i64
  %l160 = alloca i64
  %l165 = alloca { i64, ptr }
  %l172 = alloca i64
  %l174 = alloca i64
  %l179 = alloca { i64, ptr }
  %l186 = alloca { i64, ptr }
  %l194 = alloca { i64, ptr }
  %l204 = alloca i1
  %l207 = alloca i1
  %l208 = alloca i1
  %l214 = alloca i1
  %l223 = alloca i1
  %l230 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l232 = alloca i64
  %l234 = alloca i64
  %l239 = alloca { i64, ptr }
  %l245 = alloca ptr
  %l247 = alloca { i64, ptr }
  %l249 = alloca { i64, ptr }
  %l255 = alloca i1
  %l257 = alloca i32
  %l259 = alloca i1
  %l264 = alloca i1
  %l268 = alloca ptr
  %l269 = alloca i64
  %l272 = alloca i64
  %l275 = alloca %"std/os:Output"
  %l277 = alloca { i64, ptr }
  %l278 = alloca { i64, ptr }
  %l279 = alloca %"std/os:Output"
  %l280 = alloca i32
  %l282 = alloca i1
  %l289 = alloca ptr
  %l293 = alloca %"std/os:FileInfo"
  %l295 = alloca %"std/os:FileInfo"
  %l296 = alloca i32
  %l298 = alloca i1
  %l308 = alloca i32
  %l310 = alloca i1
  %s0 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @compiler_2fspin_2eRetitle(ptr %s0, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d62, i32 0, i32 1) })
  br label %bb1
bb1:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l33
  br label %bb2
bb2:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l6
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/build:Config", ptr %t3, i32 0, i32 1
  %t6 = load { i64, ptr }, ptr %t5, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v0, ptr %l6, { i64, ptr } %t6)
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eModeFlags(ptr %v0, ptr %s0, ptr %t9)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %l38
  br label %bb4
bb4:
  %t12 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l38
  %t13 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t12, ptr %t13
  store ptr %t13, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb5
bb5:
  %t15 = load i64, ptr %l8, !tbaa !24
  store i64 %t15, ptr %l40, !tbaa !24
  %t16 = load ptr, ptr %l7, !tbaa !29
  %t18 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t16)
  store i64 %t18, ptr %l42
  br label %bb6
bb6:
  %t19 = load i64, ptr %l40, !tbaa !24
  %t20 = load i64, ptr %l42, !tbaa !24
  %t21 = icmp slt i64 %t19, %t20
  %t23 = xor i1 %t21, true
  br i1 %t23, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  br label %bb9
bb9:
  %t25 = load ptr, ptr %l7, !tbaa !29
  %t26 = load i64, ptr %l8, !tbaa !24
  %t29 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t25, i64 %t26)
  store { i64, ptr } %t29, ptr %l47
  br label %bb10
bb10:
  %t30 = load { i64, ptr }, ptr %l47, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } %t30)
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t34 = load i64, ptr %l8, !tbaa !24
  %t37 = add i64 %t34, 1
  store i64 %t37, ptr %l8, !tbaa !24
  br label %bb5
bb13:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/build:Config", ptr %t39, i32 0, i32 38
  %t42 = load i1, ptr %t41, !tbaa !21
  br i1 %t42, label %bb14, label %bb15
bb14:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/build:Config", ptr %t44, i32 0, i32 2
  %t47 = getelementptr %"compiler/target:Target", ptr %t46, i32 0, i32 3
  %t48 = load { i64, ptr }, ptr %t47, !tbaa !27
  %t50 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t48, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d63, i32 0, i32 1) })
  store i1 %t50, ptr %l58
  br label %bb16
bb15:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb21
bb16:
  %t51 = load i1, ptr %l58, !tbaa !21
  br i1 %t51, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l59, !tbaa !21
  br label %bb20
bb18:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/build:Config", ptr %t52, i32 0, i32 2
  %t55 = getelementptr %"compiler/target:Target", ptr %t54, i32 0, i32 3
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t56, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d64, i32 0, i32 1) })
  store i1 %t58, ptr %l62
  br label %bb19
bb19:
  %t59 = load i1, ptr %l62, !tbaa !21
  store i1 %t59, ptr %l59, !tbaa !21
  br label %bb20
bb20:
  %t60 = load i1, ptr %l59, !tbaa !21
  store i1 %t60, ptr %l55, !tbaa !21
  br label %bb21
bb21:
  %t61 = load i1, ptr %l55, !tbaa !21
  br i1 %t61, label %bb22, label %bb23
bb22:
  store ptr %l6, ptr %l63, !tbaa !29
  %t62 = call ptr @__olang_scope_hold(ptr %s0)
  %t63 = ptrtoint ptr %t62 to i64
  store i64 %t63, ptr %l64, !tbaa !24
  %t64 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t64, label %bb24, label %bb25
bb23:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/build:Config", ptr %t66, i32 0, i32 38
  %t69 = load i1, ptr %t68, !tbaa !21
  br i1 %t69, label %bb33, label %bb34
bb24:
  %t71 = call ptr @__olang_region_make(ptr %s0)
  %t72 = ptrtoint ptr %t71 to i64
  store i64 %t72, ptr %l64, !tbaa !24
  br label %bb25
bb25:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/build:Config", ptr %t73, i32 0, i32 0
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  %t77 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d65, i32 0, i32 1) }, 1
  %t78 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d65, i32 0, i32 1) }, 0
  %t80 = extractvalue { i64, ptr } %t76, 1
  %t81 = extractvalue { i64, ptr } %t76, 0
  %t82 = add i64 %t78, %t81
  %t83 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d66, i32 0, i32 1) }, 1
  %t84 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d66, i32 0, i32 1) }, 0
  %t85 = add i64 %t82, %t84
  %t86 = load i64, ptr %l64
  %t87 = inttoptr i64 %t86 to ptr
  %t88 = call ptr @__olang_held_alloc(ptr %t87, i64 %t85)
  call void @olang_textcopy(ptr %t88, ptr %t77, i64 %t78)
  %t89 = getelementptr i8, ptr %t88, i64 %t78
  call void @olang_textcopy(ptr %t89, ptr %t80, i64 %t81)
  %t90 = getelementptr i8, ptr %t89, i64 %t81
  call void @olang_textcopy(ptr %t90, ptr %t83, i64 %t84)
  %t91 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t88, 1
  %t94 = load ptr, ptr %l63, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t94, { i64, ptr } %t92)
  br label %bb26
bb26:
  store ptr %l6, ptr %l70, !tbaa !29
  %t96 = call ptr @__olang_scope_hold(ptr %s0)
  %t97 = ptrtoint ptr %t96 to i64
  store i64 %t97, ptr %l71, !tbaa !24
  %t98 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t98, label %bb27, label %bb28
bb27:
  %t100 = call ptr @__olang_region_make(ptr %s0)
  %t101 = ptrtoint ptr %t100 to i64
  store i64 %t101, ptr %l71, !tbaa !24
  br label %bb28
bb28:
  %t102 = load i64, ptr @G_2ecompiler_2fbuild_2eThinCacheCap, !tbaa !24
  %t104 = ashr i64 %t102, 20
  %t105 = extractvalue { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d67, i32 0, i32 1) }, 1
  %t106 = extractvalue { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d67, i32 0, i32 1) }, 0
  %t108 = call i64 @__olang_fmt_i64(ptr null, i64 %t104)
  %t109 = add i64 %t106, %t108
  %t110 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d68, i32 0, i32 1) }, 1
  %t111 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d68, i32 0, i32 1) }, 0
  %t112 = add i64 %t109, %t111
  %t113 = load i64, ptr %l71
  %t114 = inttoptr i64 %t113 to ptr
  %t115 = call ptr @__olang_held_alloc(ptr %t114, i64 %t112)
  call void @olang_textcopy(ptr %t115, ptr %t105, i64 %t106)
  %t116 = getelementptr i8, ptr %t115, i64 %t106
  %t117 = call i64 @__olang_fmt_i64(ptr %t116, i64 %t104)
  %t118 = getelementptr i8, ptr %t116, i64 %t108
  call void @olang_textcopy(ptr %t118, ptr %t110, i64 %t111)
  %t119 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %t115, 1
  %t122 = load ptr, ptr %l70, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t122, { i64, ptr } %t120)
  br label %bb29
bb29:
  store ptr %l6, ptr %l77, !tbaa !29
  %t124 = call ptr @__olang_scope_hold(ptr %s0)
  %t125 = ptrtoint ptr %t124 to i64
  store i64 %t125, ptr %l78, !tbaa !24
  %t126 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t126, label %bb30, label %bb31
bb30:
  %t128 = call ptr @__olang_region_make(ptr %s0)
  %t129 = ptrtoint ptr %t128 to i64
  store i64 %t129, ptr %l78, !tbaa !24
  br label %bb31
bb31:
  %t130 = load i64, ptr @G_2ecompiler_2fbuild_2eImportLimit, !tbaa !24
  %t131 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d69, i32 0, i32 1) }, 1
  %t132 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d69, i32 0, i32 1) }, 0
  %t134 = call i64 @__olang_fmt_i64(ptr null, i64 %t130)
  %t135 = add i64 %t132, %t134
  %t136 = load i64, ptr %l78
  %t137 = inttoptr i64 %t136 to ptr
  %t138 = call ptr @__olang_held_alloc(ptr %t137, i64 %t135)
  call void @olang_textcopy(ptr %t138, ptr %t131, i64 %t132)
  %t139 = getelementptr i8, ptr %t138, i64 %t132
  %t140 = call i64 @__olang_fmt_i64(ptr %t139, i64 %t130)
  %t141 = insertvalue { i64, ptr } undef, i64 %t135, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t138, 1
  %t144 = load ptr, ptr %l77, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t144, { i64, ptr } %t142)
  br label %bb32
bb32:
  br label %bb45
bb33:
  store ptr %l6, ptr %l85, !tbaa !29
  %t146 = call ptr @__olang_scope_hold(ptr %s0)
  %t147 = ptrtoint ptr %t146 to i64
  store i64 %t147, ptr %l86, !tbaa !24
  %t148 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t148, label %bb35, label %bb36
bb34:
  br label %bb44
bb35:
  %t150 = call ptr @__olang_region_make(ptr %s0)
  %t151 = ptrtoint ptr %t150 to i64
  store i64 %t151, ptr %l86, !tbaa !24
  br label %bb36
bb36:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/build:Config", ptr %t152, i32 0, i32 0
  %t155 = load { i64, ptr }, ptr %t154, !tbaa !27
  %t156 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d70, i32 0, i32 1) }, 1
  %t157 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d70, i32 0, i32 1) }, 0
  %t159 = extractvalue { i64, ptr } %t155, 1
  %t160 = extractvalue { i64, ptr } %t155, 0
  %t161 = add i64 %t157, %t160
  %t162 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d71, i32 0, i32 1) }, 1
  %t163 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d71, i32 0, i32 1) }, 0
  %t164 = add i64 %t161, %t163
  %t165 = load i64, ptr %l86
  %t166 = inttoptr i64 %t165 to ptr
  %t167 = call ptr @__olang_held_alloc(ptr %t166, i64 %t164)
  call void @olang_textcopy(ptr %t167, ptr %t156, i64 %t157)
  %t168 = getelementptr i8, ptr %t167, i64 %t157
  call void @olang_textcopy(ptr %t168, ptr %t159, i64 %t160)
  %t169 = getelementptr i8, ptr %t168, i64 %t160
  call void @olang_textcopy(ptr %t169, ptr %t162, i64 %t163)
  %t170 = insertvalue { i64, ptr } undef, i64 %t164, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr %t167, 1
  %t173 = load ptr, ptr %l85, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t173, { i64, ptr } %t171)
  br label %bb37
bb37:
  store ptr %l6, ptr %l92, !tbaa !29
  %t175 = call ptr @__olang_scope_hold(ptr %s0)
  %t176 = ptrtoint ptr %t175 to i64
  store i64 %t176, ptr %l93, !tbaa !24
  %t177 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t177, label %bb38, label %bb39
bb38:
  %t179 = call ptr @__olang_region_make(ptr %s0)
  %t180 = ptrtoint ptr %t179 to i64
  store i64 %t180, ptr %l93, !tbaa !24
  br label %bb39
bb39:
  %t181 = load i64, ptr @G_2ecompiler_2fbuild_2eThinCacheCap, !tbaa !24
  %t183 = ashr i64 %t181, 20
  %t184 = extractvalue { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t185 = extractvalue { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  %t187 = call i64 @__olang_fmt_i64(ptr null, i64 %t183)
  %t188 = add i64 %t185, %t187
  %t189 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t190 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  %t191 = add i64 %t188, %t190
  %t192 = load i64, ptr %l93
  %t193 = inttoptr i64 %t192 to ptr
  %t194 = call ptr @__olang_held_alloc(ptr %t193, i64 %t191)
  call void @olang_textcopy(ptr %t194, ptr %t184, i64 %t185)
  %t195 = getelementptr i8, ptr %t194, i64 %t185
  %t196 = call i64 @__olang_fmt_i64(ptr %t195, i64 %t183)
  %t197 = getelementptr i8, ptr %t195, i64 %t187
  call void @olang_textcopy(ptr %t197, ptr %t189, i64 %t190)
  %t198 = insertvalue { i64, ptr } undef, i64 %t191, 0
  %t199 = insertvalue { i64, ptr } %t198, ptr %t194, 1
  %t201 = load ptr, ptr %l92, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t201, { i64, ptr } %t199)
  br label %bb40
bb40:
  store ptr %l6, ptr %l99, !tbaa !29
  %t203 = call ptr @__olang_scope_hold(ptr %s0)
  %t204 = ptrtoint ptr %t203 to i64
  store i64 %t204, ptr %l100, !tbaa !24
  %t205 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t205, label %bb41, label %bb42
bb41:
  %t207 = call ptr @__olang_region_make(ptr %s0)
  %t208 = ptrtoint ptr %t207 to i64
  store i64 %t208, ptr %l100, !tbaa !24
  br label %bb42
bb42:
  %t209 = load i64, ptr @G_2ecompiler_2fbuild_2eImportLimit, !tbaa !24
  %t210 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d74, i32 0, i32 1) }, 1
  %t211 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d74, i32 0, i32 1) }, 0
  %t213 = call i64 @__olang_fmt_i64(ptr null, i64 %t209)
  %t214 = add i64 %t211, %t213
  %t215 = load i64, ptr %l100
  %t216 = inttoptr i64 %t215 to ptr
  %t217 = call ptr @__olang_held_alloc(ptr %t216, i64 %t214)
  call void @olang_textcopy(ptr %t217, ptr %t210, i64 %t211)
  %t218 = getelementptr i8, ptr %t217, i64 %t211
  %t219 = call i64 @__olang_fmt_i64(ptr %t218, i64 %t209)
  %t220 = insertvalue { i64, ptr } undef, i64 %t214, 0
  %t221 = insertvalue { i64, ptr } %t220, ptr %t217, 1
  %t223 = load ptr, ptr %l99, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t223, { i64, ptr } %t221)
  br label %bb43
bb43:
  br label %bb44
bb44:
  br label %bb45
bb45:
  %t225 = load ptr, ptr %l5, !tbaa !29
  %t227 = icmp eq ptr %t225, null
  %t229 = xor i1 %t227, true
  br i1 %t229, label %bb46, label %bb47
bb46:
  store %olang.scope zeroinitializer, ptr %s13
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d75, i32 0, i32 1) })
  br label %bb48
bb47:
  br label %bb75
bb48:
  %t232 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t234 = extractvalue { i64, ptr } %t232, 1
  %t235 = extractvalue { i64, ptr } %t232, 0
  %t236 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d76, i32 0, i32 1) }, 1
  %t237 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d76, i32 0, i32 1) }, 0
  %t238 = add i64 %t235, %t237
  %t239 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t238)
  call void @olang_textcopy(ptr %t239, ptr %t234, i64 %t235)
  %t240 = getelementptr i8, ptr %t239, i64 %t235
  call void @olang_textcopy(ptr %t240, ptr %t236, i64 %t237)
  %t241 = insertvalue { i64, ptr } undef, i64 %t238, 0
  %t242 = insertvalue { i64, ptr } %t241, ptr %t239, 1
  store { i64, ptr } %t242, ptr %l10, !tbaa !27
  %t244 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s13)
  store %"std/prelude/text:StringBuilder" %t244, ptr %l111
  br label %bb49
bb49:
  %t245 = load %"std/prelude/text:StringBuilder", ptr %l111
  store %"std/prelude/text:StringBuilder" %t245, ptr %l11
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s13, ptr %s13, ptr %l11, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d77, i32 0, i32 1) })
  br label %bb50
bb50:
  %t247 = load ptr, ptr %l5, !tbaa !29
  store ptr %t247, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb51
bb51:
  store %olang.scope zeroinitializer, ptr %s16
  %t249 = load i64, ptr %l13, !tbaa !24
  store i64 %t249, ptr %l114, !tbaa !24
  %t250 = load ptr, ptr %l12, !tbaa !29
  %t252 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v4, ptr %t250)
  store i64 %t252, ptr %l116
  br label %bb52
bb52:
  %t253 = load i64, ptr %l114, !tbaa !24
  %t254 = load i64, ptr %l116, !tbaa !24
  %t255 = icmp slt i64 %t253, %t254
  %t257 = xor i1 %t255, true
  br i1 %t257, label %bb53, label %bb54
bb53:
  call void @__olang_scope_close(ptr %s16)
  br label %bb59
bb54:
  br label %bb55
bb55:
  %t259 = load ptr, ptr %l12, !tbaa !29
  %t260 = load i64, ptr %l13, !tbaa !24
  %t263 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v4, ptr %v4, ptr %t259, i64 %t260)
  store { i64, ptr } %t263, ptr %l121
  br label %bb56
bb56:
  %t264 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t266 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d78, i32 0, i32 1) }, 1
  %t267 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d78, i32 0, i32 1) }, 0
  %t269 = extractvalue { i64, ptr } %t264, 1
  %t270 = extractvalue { i64, ptr } %t264, 0
  %t271 = add i64 %t267, %t270
  %t272 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d79, i32 0, i32 1) }, 1
  %t273 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d79, i32 0, i32 1) }, 0
  %t274 = add i64 %t271, %t273
  %t275 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t274)
  call void @olang_textcopy(ptr %t275, ptr %t266, i64 %t267)
  %t276 = getelementptr i8, ptr %t275, i64 %t267
  call void @olang_textcopy(ptr %t276, ptr %t269, i64 %t270)
  %t277 = getelementptr i8, ptr %t276, i64 %t270
  call void @olang_textcopy(ptr %t277, ptr %t272, i64 %t273)
  %t278 = insertvalue { i64, ptr } undef, i64 %t274, 0
  %t279 = insertvalue { i64, ptr } %t278, ptr %t275, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s13, ptr %s16, ptr %l11, { i64, ptr } %t279)
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s16)
  br label %bb58
bb58:
  %t283 = load i64, ptr %l13, !tbaa !24
  %t286 = add i64 %t283, 1
  store i64 %t286, ptr %l13, !tbaa !24
  br label %bb51
bb59:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s13, ptr %s13, ptr %l11, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d80, i32 0, i32 1) })
  br label %bb60
bb60:
  %t289 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t289, ptr %l130, !tbaa !27
  %t291 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s13, ptr %s13, ptr %l11)
  store { i64, ptr } %t291, ptr %l132
  br label %bb61
bb61:
  %t292 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t294 = extractvalue { i64, ptr } %t292, 0
  %t295 = extractvalue { i64, ptr } %t292, 1
  %t296 = mul i64 %t294, 1
  %t297 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t296)
  call void @llvm.memcpy.p0.p0.i64(ptr %t297, ptr %t295, i64 %t296, i1 false)
  %t298 = insertvalue { i64, ptr } undef, i64 %t294, 0
  %t299 = insertvalue { i64, ptr } %t298, ptr %t297, 1
  %t300 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t302 = call i32 @std_2fos_2eWriteFile(ptr %s13, ptr %s13, { i64, ptr } %t300, { i64, ptr } %t299)
  store i32 %t302, ptr %l135
  %t303 = icmp ne i32 %t302, 0
  br i1 %t303, label %bb63, label %ok.304, !prof !99
ok.304:
  br label %bb62
bb62:
  br label %bb67
bb63:
  %t305 = load i32, ptr %l135, !tbaa !23
  %t306 = ashr i32 %t305, 16
  %t308 = icmp eq i32 %t306, 1
  store i1 %t308, ptr %l137, !tbaa !21
  %t309 = load i32, ptr %l135, !tbaa !23
  %t310 = ashr i32 %t309, 16
  %t312 = icmp eq i32 %t310, 1
  br i1 %t312, label %bb64, label %bb65
bb64:
  call void @__olang_errpay_pop()
  br label %bb65
bb65:
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb67:
  store ptr %l6, ptr %l141, !tbaa !29
  %t315 = call ptr @__olang_scope_hold(ptr %s0)
  %t316 = ptrtoint ptr %t315 to i64
  store i64 %t316, ptr %l142, !tbaa !24
  %t317 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t317, label %bb68, label %bb69
bb68:
  %t319 = call ptr @__olang_region_make(ptr %s0)
  %t320 = ptrtoint ptr %t319 to i64
  store i64 %t320, ptr %l142, !tbaa !24
  br label %bb69
bb69:
  %t321 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t322 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d81, i32 0, i32 1) }, 1
  %t323 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d81, i32 0, i32 1) }, 0
  %t325 = extractvalue { i64, ptr } %t321, 1
  %t326 = extractvalue { i64, ptr } %t321, 0
  %t327 = add i64 %t323, %t326
  %t328 = load i64, ptr %l142
  %t329 = inttoptr i64 %t328 to ptr
  %t330 = call ptr @__olang_held_alloc(ptr %t329, i64 %t327)
  call void @olang_textcopy(ptr %t330, ptr %t322, i64 %t323)
  %t331 = getelementptr i8, ptr %t330, i64 %t323
  call void @olang_textcopy(ptr %t331, ptr %t325, i64 %t326)
  %t332 = insertvalue { i64, ptr } undef, i64 %t327, 0
  %t333 = insertvalue { i64, ptr } %t332, ptr %t330, 1
  %t335 = load ptr, ptr %l141, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t335, { i64, ptr } %t333)
  br label %bb70
bb70:
  store ptr %l6, ptr %l147, !tbaa !29
  %t337 = call ptr @__olang_scope_hold(ptr %s0)
  %t338 = ptrtoint ptr %t337 to i64
  store i64 %t338, ptr %l148, !tbaa !24
  %t339 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t339, label %bb71, label %bb72
bb71:
  %t341 = call ptr @__olang_region_make(ptr %s0)
  %t342 = ptrtoint ptr %t341 to i64
  store i64 %t342, ptr %l148, !tbaa !24
  br label %bb72
bb72:
  %t343 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t345 = call { i64, ptr } @std_2ffilepath_2eBase(ptr %v2, ptr %s13, { i64, ptr } %t343)
  store { i64, ptr } %t345, ptr %l151
  br label %bb73
bb73:
  %t346 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d82, i32 0, i32 1) }, 1
  %t347 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d82, i32 0, i32 1) }, 0
  %t348 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t349 = extractvalue { i64, ptr } %t348, 1
  %t350 = extractvalue { i64, ptr } %t348, 0
  %t351 = add i64 %t347, %t350
  %t352 = load i64, ptr %l148
  %t353 = inttoptr i64 %t352 to ptr
  %t354 = call ptr @__olang_held_alloc(ptr %t353, i64 %t351)
  call void @olang_textcopy(ptr %t354, ptr %t346, i64 %t347)
  %t355 = getelementptr i8, ptr %t354, i64 %t347
  call void @olang_textcopy(ptr %t355, ptr %t349, i64 %t350)
  %t356 = insertvalue { i64, ptr } undef, i64 %t351, 0
  %t357 = insertvalue { i64, ptr } %t356, ptr %t354, 1
  %t359 = load ptr, ptr %l147, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t359, { i64, ptr } %t357)
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s13)
  br label %bb75
bb75:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d83, i32 0, i32 1) })
  br label %bb76
bb76:
  %t362 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v2, ptr %l6, { i64, ptr } %t362)
  br label %bb77
bb77:
  store ptr %a1, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  br label %bb78
bb78:
  %t367 = load i64, ptr %l16, !tbaa !24
  store i64 %t367, ptr %l158, !tbaa !24
  %t368 = load ptr, ptr %l15, !tbaa !29
  %t370 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v1, ptr %t368)
  store i64 %t370, ptr %l160
  br label %bb79
bb79:
  %t371 = load i64, ptr %l158, !tbaa !24
  %t372 = load i64, ptr %l160, !tbaa !24
  %t373 = icmp slt i64 %t371, %t372
  %t375 = xor i1 %t373, true
  br i1 %t375, label %bb80, label %bb81
bb80:
  br label %bb86
bb81:
  br label %bb82
bb82:
  %t377 = load ptr, ptr %l15, !tbaa !29
  %t378 = load i64, ptr %l16, !tbaa !24
  %t381 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t377, i64 %t378)
  store { i64, ptr } %t381, ptr %l165
  br label %bb83
bb83:
  %t382 = load { i64, ptr }, ptr %l165, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v1, ptr %l6, { i64, ptr } %t382)
  br label %bb84
bb84:
  br label %bb85
bb85:
  %t386 = load i64, ptr %l16, !tbaa !24
  %t389 = add i64 %t386, 1
  store i64 %t389, ptr %l16, !tbaa !24
  br label %bb78
bb86:
  store ptr %a4, ptr %l18, !tbaa !29
  store i64 0, ptr %l19, !tbaa !24
  br label %bb87
bb87:
  %t393 = load i64, ptr %l19, !tbaa !24
  store i64 %t393, ptr %l172, !tbaa !24
  %t394 = load ptr, ptr %l18, !tbaa !29
  %t396 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v3, ptr %t394)
  store i64 %t396, ptr %l174
  br label %bb88
bb88:
  %t397 = load i64, ptr %l172, !tbaa !24
  %t398 = load i64, ptr %l174, !tbaa !24
  %t399 = icmp slt i64 %t397, %t398
  %t401 = xor i1 %t399, true
  br i1 %t401, label %bb89, label %bb90
bb89:
  br label %bb95
bb90:
  br label %bb91
bb91:
  %t403 = load ptr, ptr %l18, !tbaa !29
  %t404 = load i64, ptr %l19, !tbaa !24
  %t407 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v3, ptr %v3, ptr %t403, i64 %t404)
  store { i64, ptr } %t407, ptr %l179
  br label %bb92
bb92:
  %t408 = load { i64, ptr }, ptr %l179, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v3, ptr %l6, { i64, ptr } %t408)
  br label %bb93
bb93:
  br label %bb94
bb94:
  %t412 = load i64, ptr %l19, !tbaa !24
  %t415 = add i64 %t412, 1
  store i64 %t415, ptr %l19, !tbaa !24
  br label %bb87
bb95:
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t419 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eSystemLibs(ptr %v0, ptr %s0, ptr %t417)
  store { i64, ptr } %t419, ptr %l186
  br label %bb96
bb96:
  %t420 = load { i64, ptr }, ptr %l186, !tbaa !27
  store { i64, ptr } %t420, ptr %l21, !tbaa !27
  store i64 0, ptr %l22, !tbaa !24
  %t422 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t424 = extractvalue { i64, ptr } %t422, 0
  store i64 %t424, ptr %l23, !tbaa !24
  br label %bb97
bb97:
  %t426 = load i64, ptr %l22, !tbaa !24
  %t427 = load i64, ptr %l23, !tbaa !24
  %t430 = icmp slt i64 %t426, %t427
  %t432 = xor i1 %t430, true
  br i1 %t432, label %bb98, label %bb99
bb98:
  br label %bb103
bb99:
  br label %bb100
bb100:
  %t434 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t434, ptr %l194, !tbaa !27
  %t435 = load i64, ptr %l22, !tbaa !24
  %t437 = getelementptr { i64, ptr }, ptr %l194, i32 0, i32 1
  %t438 = load ptr, ptr %t437, !tbaa !27
  %t439 = getelementptr { i64, ptr }, ptr %t438, i64 %t435
  %t440 = load { i64, ptr }, ptr %t439, !tbaa !37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } %t440)
  br label %bb101
bb101:
  br label %bb102
bb102:
  %t445 = load i64, ptr %l22, !tbaa !24
  %t448 = add i64 %t445, 1
  store i64 %t448, ptr %l22, !tbaa !24
  br label %bb97
bb103:
  %t450 = load ptr, ptr %l0, !tbaa !29
  %t452 = getelementptr %"compiler/build:Config", ptr %t450, i32 0, i32 13
  %t453 = load i1, ptr %t452, !tbaa !21
  br i1 %t453, label %bb104, label %bb105
bb104:
  store i1 true, ptr %l204, !tbaa !21
  br label %bb107
bb105:
  %t455 = load ptr, ptr %l0, !tbaa !29
  %t457 = getelementptr %"compiler/build:Config", ptr %t455, i32 0, i32 2
  %t458 = getelementptr %"compiler/target:Target", ptr %t457, i32 0, i32 3
  %t459 = load { i64, ptr }, ptr %t458, !tbaa !27
  %t461 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t459, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d84, i32 0, i32 1) })
  store i1 %t461, ptr %l207
  br label %bb106
bb106:
  %t462 = load i1, ptr %l207, !tbaa !21
  store i1 %t462, ptr %l204, !tbaa !21
  br label %bb107
bb107:
  %t463 = load i1, ptr %l204, !tbaa !21
  br i1 %t463, label %bb108, label %bb109
bb108:
  %t464 = load ptr, ptr %l5, !tbaa !29
  %t466 = icmp eq ptr %t464, null
  store i1 %t466, ptr %l208, !tbaa !21
  br label %bb110
bb109:
  store i1 false, ptr %l208, !tbaa !21
  br label %bb110
bb110:
  %t468 = load i1, ptr %l208, !tbaa !21
  br i1 %t468, label %bb111, label %bb112
bb111:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d85, i32 0, i32 1) })
  br label %bb113
bb112:
  br label %bb114
bb113:
  br label %bb114
bb114:
  %t470 = load ptr, ptr %l0, !tbaa !29
  %t472 = getelementptr %"compiler/build:Config", ptr %t470, i32 0, i32 2
  %t473 = getelementptr %"compiler/target:Target", ptr %t472, i32 0, i32 3
  %t474 = load { i64, ptr }, ptr %t473, !tbaa !27
  %t476 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t474, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d86, i32 0, i32 1) })
  store i1 %t476, ptr %l214
  br label %bb115
bb115:
  %t477 = load i1, ptr %l214, !tbaa !21
  br i1 %t477, label %bb116, label %bb117
bb116:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d87, i32 0, i32 1) })
  br label %bb118
bb117:
  br label %bb120
bb118:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d88, i32 0, i32 1) })
  br label %bb119
bb119:
  br label %bb120
bb120:
  %t480 = load ptr, ptr %l0, !tbaa !29
  %t482 = getelementptr %"compiler/build:Config", ptr %t480, i32 0, i32 18
  %t483 = load i1, ptr %t482, !tbaa !21
  br i1 %t483, label %bb121, label %bb122
bb121:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d89, i32 0, i32 1) })
  br label %bb123
bb122:
  br label %bb131
bb123:
  %t486 = load ptr, ptr %l0, !tbaa !29
  %t488 = getelementptr %"compiler/build:Config", ptr %t486, i32 0, i32 5
  %t489 = load i1, ptr %t488, !tbaa !21
  %t491 = xor i1 %t489, true
  br i1 %t491, label %bb124, label %bb125
bb124:
  %t493 = load ptr, ptr %l0, !tbaa !29
  %t495 = getelementptr %"compiler/build:Config", ptr %t493, i32 0, i32 4
  %t496 = load i1, ptr %t495, !tbaa !21
  %t498 = xor i1 %t496, true
  store i1 %t498, ptr %l223, !tbaa !21
  br label %bb126
bb125:
  store i1 false, ptr %l223, !tbaa !21
  br label %bb126
bb126:
  %t500 = load i1, ptr %l223, !tbaa !21
  br i1 %t500, label %bb127, label %bb128
bb127:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d90, i32 0, i32 1) })
  br label %bb129
bb128:
  br label %bb130
bb129:
  br label %bb130
bb130:
  br label %bb131
bb131:
  br i1 %a3, label %bb132, label %bb133
bb132:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d91, i32 0, i32 1) })
  br label %bb134
bb133:
  br label %bb135
bb134:
  br label %bb135
bb135:
  %t505 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t505, ptr %l230
  br label %bb136
bb136:
  %t506 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l230
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t506, ptr %l25
  store ptr %l6, ptr %l26, !tbaa !29
  store i64 0, ptr %l27, !tbaa !24
  br label %bb137
bb137:
  %t508 = load i64, ptr %l27, !tbaa !24
  store i64 %t508, ptr %l232, !tbaa !24
  %t509 = load ptr, ptr %l26, !tbaa !29
  %t511 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t509)
  store i64 %t511, ptr %l234
  br label %bb138
bb138:
  %t512 = load i64, ptr %l232, !tbaa !24
  %t513 = load i64, ptr %l234, !tbaa !24
  %t514 = icmp slt i64 %t512, %t513
  %t516 = xor i1 %t514, true
  br i1 %t516, label %bb139, label %bb140
bb139:
  br label %bb145
bb140:
  br label %bb141
bb141:
  %t518 = load ptr, ptr %l26, !tbaa !29
  %t519 = load i64, ptr %l27, !tbaa !24
  %t522 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t518, i64 %t519)
  store { i64, ptr } %t522, ptr %l239
  br label %bb142
bb142:
  %t523 = load { i64, ptr }, ptr %l239, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l25, { i64, ptr } %t523)
  br label %bb143
bb143:
  br label %bb144
bb144:
  %t527 = load i64, ptr %l27, !tbaa !24
  %t530 = add i64 %t527, 1
  store i64 %t530, ptr %l27, !tbaa !24
  br label %bb137
bb145:
  store ptr %l25, ptr %l245, !tbaa !29
  %t532 = load ptr, ptr %l0, !tbaa !29
  %t534 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eclangVersion(ptr %v0, ptr %v0, ptr %t532)
  store { i64, ptr } %t534, ptr %l247
  br label %bb146
bb146:
  %t535 = load ptr, ptr %l245, !tbaa !29
  %t536 = load { i64, ptr }, ptr %l247, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v0, ptr %t535, { i64, ptr } %t536)
  br label %bb147
bb147:
  %t538 = call { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %s0, ptr %s0, ptr %l25)
  store { i64, ptr } %t538, ptr %l249
  br label %bb148
bb148:
  %t539 = load { i64, ptr }, ptr %l249, !tbaa !27
  store { i64, ptr } %t539, ptr %l29, !tbaa !27
  %t540 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t542 = extractvalue { i64, ptr } %t540, 1
  %t543 = extractvalue { i64, ptr } %t540, 0
  %t544 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d92, i32 0, i32 1) }, 1
  %t545 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d92, i32 0, i32 1) }, 0
  %t546 = add i64 %t543, %t545
  %t547 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t546)
  call void @olang_textcopy(ptr %t547, ptr %t542, i64 %t543)
  %t548 = getelementptr i8, ptr %t547, i64 %t543
  call void @olang_textcopy(ptr %t548, ptr %t544, i64 %t545)
  %t549 = insertvalue { i64, ptr } undef, i64 %t546, 0
  %t550 = insertvalue { i64, ptr } %t549, ptr %t547, 1
  store { i64, ptr } %t550, ptr %l30, !tbaa !27
  %t552 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t553 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t554 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t558 = call i1 @compiler_2fbuild_2elinkCurrent(ptr %v2, ptr %s0, ptr %s0, { i64, ptr } %t552, { i64, ptr } %t553, { i64, ptr } %t554)
  store i1 %t558, ptr %l255
  br label %bb149
bb149:
  %t559 = load i1, ptr %l255, !tbaa !21
  br i1 %t559, label %bb150, label %bb151
bb150:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb151:
  br label %bb152
bb152:
  %t560 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t562 = call i32 @std_2fos_2eRemove(ptr %s0, { i64, ptr } %t560)
  store i32 %t562, ptr %l257
  %t563 = icmp ne i32 %t562, 0
  br i1 %t563, label %bb154, label %ok.564, !prof !99
ok.564:
  br label %bb153
bb153:
  br label %bb158
bb154:
  %t565 = load i32, ptr %l257, !tbaa !23
  %t566 = ashr i32 %t565, 16
  %t568 = icmp eq i32 %t566, 1
  store i1 %t568, ptr %l259, !tbaa !21
  %t569 = load i32, ptr %l257, !tbaa !23
  %t570 = ashr i32 %t569, 16
  %t572 = icmp eq i32 %t570, 1
  br i1 %t572, label %bb155, label %bb156
bb155:
  call void @__olang_errpay_pop()
  br label %bb156
bb156:
  br label %bb157
bb157:
  br label %bb158
bb158:
  %t574 = load ptr, ptr %l0, !tbaa !29
  %t576 = getelementptr %"compiler/build:Config", ptr %t574, i32 0, i32 1
  %t577 = load { i64, ptr }, ptr %t576, !tbaa !27
  %t579 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t577, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d93, i32 0, i32 1) })
  store i1 %t579, ptr %l264
  br label %bb159
bb159:
  %t580 = load i1, ptr %l264, !tbaa !21
  br i1 %t580, label %bb160, label %bb161
bb160:
  call void @__olang_scope_close(ptr %s0)
  store i32 65537, ptr %rv
  br label %ret
bb161:
  br label %bb162
bb162:
  %t582 = load ptr, ptr %l0, !tbaa !29
  %t584 = getelementptr %"compiler/build:Config", ptr %t582, i32 0, i32 38
  %t585 = load i1, ptr %t584, !tbaa !21
  br i1 %t585, label %bb163, label %bb164
bb163:
  store ptr %l6, ptr %l268, !tbaa !29
  %t587 = call ptr @__olang_scope_hold(ptr %s0)
  %t588 = ptrtoint ptr %t587 to i64
  store i64 %t588, ptr %l269, !tbaa !24
  %t589 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t589, label %bb165, label %bb166
bb164:
  br label %bb169
bb165:
  %t591 = call ptr @__olang_region_make(ptr %s0)
  %t592 = ptrtoint ptr %t591 to i64
  store i64 %t592, ptr %l269, !tbaa !24
  br label %bb166
bb166:
  %t593 = load ptr, ptr %l0, !tbaa !29
  %t595 = call i64 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewidth(ptr %v0, ptr %t593)
  store i64 %t595, ptr %l272
  br label %bb167
bb167:
  %t596 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d94, i32 0, i32 1) }, 1
  %t597 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d94, i32 0, i32 1) }, 0
  %t598 = load i64, ptr %l272, !tbaa !24
  %t599 = call i64 @__olang_fmt_i64(ptr null, i64 %t598)
  %t600 = add i64 %t597, %t599
  %t601 = load i64, ptr %l269
  %t602 = inttoptr i64 %t601 to ptr
  %t603 = call ptr @__olang_held_alloc(ptr %t602, i64 %t600)
  call void @olang_textcopy(ptr %t603, ptr %t596, i64 %t597)
  %t604 = getelementptr i8, ptr %t603, i64 %t597
  %t605 = call i64 @__olang_fmt_i64(ptr %t604, i64 %t598)
  %t606 = insertvalue { i64, ptr } undef, i64 %t600, 0
  %t607 = insertvalue { i64, ptr } %t606, ptr %t603, 1
  %t609 = load ptr, ptr %l268, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t609, { i64, ptr } %t607)
  br label %bb168
bb168:
  br label %bb169
bb169:
  %t612 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %s0, ptr %s0, ptr %l6)
  store { i64, ptr } %t612, ptr %l277
  br label %bb170
bb170:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %l278, !tbaa !27
  %t613 = load { i64, ptr }, ptr %l277, !tbaa !27
  %t614 = load { i64, ptr }, ptr %l278, !tbaa !27
  %t615 = call { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExec(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t613, { i64, ptr } %t614, i1 false, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d39, i32 0, i32 1) })
  %t616 = extractvalue { i32, %"std/os:Output" } %t615, 1
  %t617 = extractvalue { i32, %"std/os:Output" } %t615, 0
  store i32 %t617, ptr %l280
  %t618 = icmp ne i32 %t617, 0
  br i1 %t618, label %bb172, label %ok.619, !prof !99
ok.619:
  store %"std/os:Output" %t616, ptr %l279
  br label %bb171
bb171:
  %t620 = load %"std/os:Output", ptr %l279
  store %"std/os:Output" %t620, ptr %l275
  br label %bb176
bb172:
  %t621 = load i32, ptr %l280, !tbaa !23
  %t622 = ashr i32 %t621, 16
  %t624 = icmp eq i32 %t622, 1
  store i1 %t624, ptr %l282, !tbaa !21
  %t625 = load i32, ptr %l280, !tbaa !23
  %t626 = ashr i32 %t625, 16
  %t628 = icmp eq i32 %t626, 1
  br i1 %t628, label %bb173, label %bb174
bb173:
  call void @__olang_errpay_pop()
  br label %bb174
bb174:
  br label %bb175
bb175:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb176:
  %t631 = load %"std/os:Output", ptr %l275
  store %"std/os:Output" %t631, ptr %l31
  %t632 = getelementptr %"std/os:Output", ptr %l31, i32 0, i32 0
  %t633 = load i32, ptr %t632, !tbaa !23
  %t635 = icmp ne i32 %t633, 0
  br i1 %t635, label %bb177, label %bb178
bb177:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb178:
  br label %bb179
bb179:
  %t638 = load ptr, ptr %l0, !tbaa !29
  store ptr %t638, ptr %l289, !tbaa !29
  %t639 = load ptr, ptr %l289, !tbaa !29
  %t640 = getelementptr %"compiler/build:Config", ptr %t639, i32 0, i32 37
  %t641 = load i64, ptr %t640, !tbaa !24
  %t644 = add i64 %t641, 1
  %t646 = load ptr, ptr %l289, !tbaa !29
  %t647 = getelementptr %"compiler/build:Config", ptr %t646, i32 0, i32 37
  store i64 %t644, ptr %t647, !tbaa !24
  %t648 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t650 = call { i32, %"std/os:FileInfo" } @std_2fos_2eFileInfo_2eStat(ptr %v2, { i64, ptr } %t648)
  %t651 = extractvalue { i32, %"std/os:FileInfo" } %t650, 1
  %t652 = extractvalue { i32, %"std/os:FileInfo" } %t650, 0
  store i32 %t652, ptr %l296
  %t653 = icmp ne i32 %t652, 0
  br i1 %t653, label %bb181, label %ok.654, !prof !99
ok.654:
  store %"std/os:FileInfo" %t651, ptr %l295
  br label %bb180
bb180:
  %t655 = load %"std/os:FileInfo", ptr %l295
  store %"std/os:FileInfo" %t655, ptr %l293
  br label %bb185
bb181:
  %t656 = load i32, ptr %l296, !tbaa !23
  %t657 = ashr i32 %t656, 16
  %t659 = icmp eq i32 %t657, 1
  store i1 %t659, ptr %l298, !tbaa !21
  %t660 = load i32, ptr %l296, !tbaa !23
  %t661 = ashr i32 %t660, 16
  %t663 = icmp eq i32 %t661, 1
  br i1 %t663, label %bb182, label %bb183
bb182:
  call void @__olang_errpay_pop()
  br label %bb183
bb183:
  br label %bb184
bb184:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb185:
  %t665 = load %"std/os:FileInfo", ptr %l293
  store %"std/os:FileInfo" %t665, ptr %l32
  %t666 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t667 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t668 = getelementptr %"std/os:FileInfo", ptr %l32, i32 0, i32 1
  %t669 = load i64, ptr %t668, !tbaa !24
  %t670 = getelementptr %"std/os:FileInfo", ptr %l32, i32 0, i32 2
  %t671 = load i64, ptr %t670, !tbaa !24
  %t673 = extractvalue { i64, ptr } %t667, 1
  %t674 = extractvalue { i64, ptr } %t667, 0
  %t675 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d95, i32 0, i32 1) }, 1
  %t676 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d95, i32 0, i32 1) }, 0
  %t677 = add i64 %t674, %t676
  %t679 = call i64 @__olang_fmt_i64(ptr null, i64 %t669)
  %t680 = add i64 %t677, %t679
  %t681 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d95, i32 0, i32 1) }, 1
  %t682 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d95, i32 0, i32 1) }, 0
  %t683 = add i64 %t680, %t682
  %t685 = call i64 @__olang_fmt_i64(ptr null, i64 %t671)
  %t686 = add i64 %t683, %t685
  %t687 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d96, i32 0, i32 1) }, 1
  %t688 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d96, i32 0, i32 1) }, 0
  %t689 = add i64 %t686, %t688
  %t690 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t689)
  call void @olang_textcopy(ptr %t690, ptr %t673, i64 %t674)
  %t691 = getelementptr i8, ptr %t690, i64 %t674
  call void @olang_textcopy(ptr %t691, ptr %t675, i64 %t676)
  %t692 = getelementptr i8, ptr %t691, i64 %t676
  %t693 = call i64 @__olang_fmt_i64(ptr %t692, i64 %t669)
  %t694 = getelementptr i8, ptr %t692, i64 %t679
  call void @olang_textcopy(ptr %t694, ptr %t681, i64 %t682)
  %t695 = getelementptr i8, ptr %t694, i64 %t682
  %t696 = call i64 @__olang_fmt_i64(ptr %t695, i64 %t671)
  %t697 = getelementptr i8, ptr %t695, i64 %t685
  call void @olang_textcopy(ptr %t697, ptr %t687, i64 %t688)
  %t698 = insertvalue { i64, ptr } undef, i64 %t689, 0
  %t699 = insertvalue { i64, ptr } %t698, ptr %t690, 1
  %t702 = extractvalue { i64, ptr } %t699, 0
  %t703 = extractvalue { i64, ptr } %t699, 1
  %t704 = mul i64 %t702, 1
  %t705 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t704)
  call void @llvm.memcpy.p0.p0.i64(ptr %t705, ptr %t703, i64 %t704, i1 false)
  %t706 = insertvalue { i64, ptr } undef, i64 %t702, 0
  %t707 = insertvalue { i64, ptr } %t706, ptr %t705, 1
  %t710 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s0, { i64, ptr } %t666, { i64, ptr } %t707)
  store i32 %t710, ptr %l308
  %t711 = icmp ne i32 %t710, 0
  br i1 %t711, label %bb187, label %ok.712, !prof !99
ok.712:
  br label %bb186
bb186:
  br label %bb191
bb187:
  %t713 = load i32, ptr %l308, !tbaa !23
  %t714 = ashr i32 %t713, 16
  %t716 = icmp eq i32 %t714, 1
  store i1 %t716, ptr %l310, !tbaa !21
  %t717 = load i32, ptr %l308, !tbaa !23
  %t718 = ashr i32 %t717, 16
  %t720 = icmp eq i32 %t718, 1
  br i1 %t720, label %bb188, label %bb189
bb188:
  call void @__olang_errpay_pop()
  br label %bb189
bb189:
  br label %bb190
bb190:
  br label %bb191
bb191:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eModeFlags(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca ptr
  %l7 = alloca i64
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l20 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i64
  %l30 = alloca i1
  %l37 = alloca i1
  %l43 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l3
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/build:Config", ptr %t3, i32 0, i32 2
  %t6 = getelementptr %"compiler/target:Target", ptr %t5, i32 0, i32 9
  %t7 = load i1, ptr %t6, !tbaa !21
  br i1 %t7, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  store ptr %l1, ptr %l6, !tbaa !29
  %t9 = call ptr @__olang_scope_hold(ptr %v1)
  %t10 = ptrtoint ptr %t9 to i64
  store i64 %t10, ptr %l7, !tbaa !24
  %t11 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t11, label %bb4, label %bb5
bb3:
  br label %bb19
bb4:
  %t13 = call ptr @__olang_region_make(ptr %v1)
  %t14 = ptrtoint ptr %t13 to i64
  store i64 %t14, ptr %l7, !tbaa !24
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/build:Config", ptr %t15, i32 0, i32 2
  %t18 = getelementptr %"compiler/target:Target", ptr %t17, i32 0, i32 1
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  %t20 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d97, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d97, i32 0, i32 1) }, 0
  %t23 = extractvalue { i64, ptr } %t19, 1
  %t24 = extractvalue { i64, ptr } %t19, 0
  %t25 = add i64 %t21, %t24
  %t26 = load i64, ptr %l7
  %t27 = inttoptr i64 %t26 to ptr
  %t28 = call ptr @__olang_held_alloc(ptr %t27, i64 %t25)
  call void @olang_textcopy(ptr %t28, ptr %t20, i64 %t21)
  %t29 = getelementptr i8, ptr %t28, i64 %t21
  call void @olang_textcopy(ptr %t29, ptr %t23, i64 %t24)
  %t30 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t28, 1
  %t33 = load ptr, ptr %l6, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t33, { i64, ptr } %t31)
  br label %bb6
bb6:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/build:Config", ptr %t35, i32 0, i32 2
  %t38 = getelementptr %"compiler/target:Target", ptr %t37, i32 0, i32 13
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  %t41 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t39, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d98, i32 0, i32 1) })
  store i1 %t41, ptr %l15
  br label %bb7
bb7:
  %t42 = load i1, ptr %l15, !tbaa !21
  br i1 %t42, label %bb8, label %bb9
bb8:
  %t43 = call { i64, ptr } @compiler_2ftarget_2eSysroot(ptr %s1)
  store { i64, ptr } %t43, ptr %l17
  br label %bb10
bb9:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d99, i32 0, i32 1) }, ptr %l16, !tbaa !27
  br label %bb11
bb10:
  %t44 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t44, ptr %l16, !tbaa !27
  br label %bb11
bb11:
  %t46 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t46, ptr %l2, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t49 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s1, { i64, ptr } %t47, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d100, i32 0, i32 1) })
  store i1 %t49, ptr %l20
  br label %bb12
bb12:
  %t50 = load i1, ptr %l20, !tbaa !21
  %t51 = xor i1 %t50, true
  br i1 %t51, label %bb13, label %bb14
bb13:
  store ptr %l1, ptr %l22, !tbaa !29
  %t53 = call ptr @__olang_scope_hold(ptr %v1)
  %t54 = ptrtoint ptr %t53 to i64
  store i64 %t54, ptr %l23, !tbaa !24
  %t55 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t55, label %bb15, label %bb16
bb14:
  br label %bb18
bb15:
  %t57 = call ptr @__olang_region_make(ptr %v1)
  %t58 = ptrtoint ptr %t57 to i64
  store i64 %t58, ptr %l23, !tbaa !24
  br label %bb16
bb16:
  %t59 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t60 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d101, i32 0, i32 1) }, 1
  %t61 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d101, i32 0, i32 1) }, 0
  %t63 = extractvalue { i64, ptr } %t59, 1
  %t64 = extractvalue { i64, ptr } %t59, 0
  %t65 = add i64 %t61, %t64
  %t66 = load i64, ptr %l23
  %t67 = inttoptr i64 %t66 to ptr
  %t68 = call ptr @__olang_held_alloc(ptr %t67, i64 %t65)
  call void @olang_textcopy(ptr %t68, ptr %t60, i64 %t61)
  %t69 = getelementptr i8, ptr %t68, i64 %t61
  call void @olang_textcopy(ptr %t69, ptr %t63, i64 %t64)
  %t70 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t68, 1
  %t73 = load ptr, ptr %l22, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t73, { i64, ptr } %t71)
  br label %bb17
bb17:
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s1)
  br label %bb19
bb19:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/build:Config", ptr %t75, i32 0, i32 2
  %t78 = getelementptr %"compiler/target:Target", ptr %t77, i32 0, i32 6
  %t79 = load { i64, ptr }, ptr %t78, !tbaa !27
  %t81 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t79, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d102, i32 0, i32 1) })
  store i1 %t81, ptr %l30
  br label %bb20
bb20:
  %t82 = load i1, ptr %l30, !tbaa !21
  %t83 = xor i1 %t82, true
  br i1 %t83, label %bb21, label %bb22
bb21:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/build:Config", ptr %t85, i32 0, i32 2
  %t88 = getelementptr %"compiler/target:Target", ptr %t87, i32 0, i32 6
  %t89 = load { i64, ptr }, ptr %t88, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v0, ptr %l1, { i64, ptr } %t89)
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb24
bb24:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/build:Config", ptr %t92, i32 0, i32 11
  %t95 = load i1, ptr %t94, !tbaa !21
  br i1 %t95, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb27
bb26:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/build:Config", ptr %t97, i32 0, i32 14
  %t100 = load i1, ptr %t99, !tbaa !21
  store i1 %t100, ptr %l37, !tbaa !21
  br label %bb27
bb27:
  %t102 = load i1, ptr %l37, !tbaa !21
  br i1 %t102, label %bb28, label %bb29
bb28:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %l1, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d103, i32 0, i32 1) })
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb31
bb31:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/build:Config", ptr %t104, i32 0, i32 16
  %t107 = load { i64, ptr }, ptr %t106, !tbaa !27
  %t109 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t107, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d104, i32 0, i32 1) })
  store i1 %t109, ptr %l43
  br label %bb32
bb32:
  %t110 = load i1, ptr %l43, !tbaa !21
  %t111 = xor i1 %t110, true
  br i1 %t111, label %bb33, label %bb34
bb33:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %l1, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d105, i32 0, i32 1) })
  br label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb36
bb36:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/build:Config", ptr %t114, i32 0, i32 4
  %t117 = load i1, ptr %t116, !tbaa !21
  br i1 %t117, label %bb37, label %bb38
bb37:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %l1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d106, i32 0, i32 1) })
  br label %bb39
bb38:
  br label %bb45
bb39:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %l1, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d107, i32 0, i32 1) })
  br label %bb40
bb40:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/build:Config", ptr %t121, i32 0, i32 6
  %t124 = load i1, ptr %t123, !tbaa !21
  br i1 %t124, label %bb41, label %bb42
bb41:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %l1, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d108, i32 0, i32 1) })
  br label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb44
bb44:
  %t127 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t127, ptr %rv
  br label %ret
bb45:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/build:Config", ptr %t129, i32 0, i32 6
  %t132 = load i1, ptr %t131, !tbaa !21
  br i1 %t132, label %bb46, label %bb47
bb46:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %l1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d109, i32 0, i32 1) })
  br label %bb48
bb47:
  br label %bb50
bb48:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %l1, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d110, i32 0, i32 1) })
  br label %bb49
bb49:
  %t136 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t136, ptr %rv
  br label %ret
bb50:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/build:Config", ptr %t138, i32 0, i32 5
  %t141 = load i1, ptr %t140, !tbaa !21
  br i1 %t141, label %bb51, label %bb52
bb51:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %l1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d111, i32 0, i32 1) })
  br label %bb53
bb52:
  br label %bb54
bb53:
  %t144 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t144, ptr %rv
  br label %ret
bb54:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %l1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d112, i32 0, i32 1) })
  br label %bb55
bb55:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/build:Config", ptr %t147, i32 0, i32 38
  %t150 = load i1, ptr %t149, !tbaa !21
  br i1 %t150, label %bb56, label %bb57
bb56:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %l1, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d113, i32 0, i32 1) })
  br label %bb58
bb57:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %l1, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d114, i32 0, i32 1) })
  br label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb60
bb60:
  %t154 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t154, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjectPath(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca ptr
  %l7 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca i64
  %l16 = alloca i64
  %l21 = alloca { i64, ptr }
  %l27 = alloca ptr
  %l29 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l39 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v2, ptr %l5, { i64, ptr } %a3)
  br label %bb2
bb2:
  store ptr %a4, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb3
bb3:
  %t8 = load i64, ptr %l7, !tbaa !24
  store i64 %t8, ptr %l14, !tbaa !24
  %t9 = load ptr, ptr %l6, !tbaa !29
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v3, ptr %t9)
  store i64 %t11, ptr %l16
  br label %bb4
bb4:
  %t12 = load i64, ptr %l14, !tbaa !24
  %t13 = load i64, ptr %l16, !tbaa !24
  %t14 = icmp slt i64 %t12, %t13
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb5, label %bb6
bb5:
  br label %bb11
bb6:
  br label %bb7
bb7:
  %t18 = load ptr, ptr %l6, !tbaa !29
  %t19 = load i64, ptr %l7, !tbaa !24
  %t22 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v3, ptr %v3, ptr %t18, i64 %t19)
  store { i64, ptr } %t22, ptr %l21
  br label %bb8
bb8:
  %t23 = load { i64, ptr }, ptr %l21, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v3, ptr %l5, { i64, ptr } %t23)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t27 = load i64, ptr %l7, !tbaa !24
  %t30 = add i64 %t27, 1
  store i64 %t30, ptr %l7, !tbaa !24
  br label %bb3
bb11:
  store ptr %l5, ptr %l27, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eclangVersion(ptr %v0, ptr %v0, ptr %t32)
  store { i64, ptr } %t34, ptr %l29
  br label %bb12
bb12:
  %t35 = load ptr, ptr %l27, !tbaa !29
  %t36 = load { i64, ptr }, ptr %l29, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v0, ptr %t35, { i64, ptr } %t36)
  br label %bb13
bb13:
  %t38 = call { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %s0, ptr %s0, ptr %l5)
  store { i64, ptr } %t38, ptr %l31
  br label %bb14
bb14:
  %t39 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t39, ptr %l9, !tbaa !27
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/build:Config", ptr %t40, i32 0, i32 0
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !27
  store { i64, ptr } %t43, ptr %l33, !tbaa !27
  store { i64, ptr } %a1, ptr %l34, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t45, 0
  store i64 %t46, ptr %l35, !tbaa !24
  %t47 = icmp sge i64 0, 0
  br i1 %t47, label %bb15, label %bb16
bb15:
  %t49 = icmp sle i64 0, 16
  br i1 %t49, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_4cf283899a273ea5_54dbe84ebef87a69)
  unreachable
bb17:
  %t51 = load i64, ptr %l35, !tbaa !24
  %t52 = icmp sle i64 16, %t51
  br i1 %t52, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_4cf283899a273ea5_54dbe84ebef87a69)
  unreachable
bb19:
  %t54 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i8, ptr %t55, i64 0
  %t57 = sub i64 16, 0
  %t58 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t56, 1
  store { i64, ptr } %t59, ptr %l39, !tbaa !27
  %t62 = call { i64, ptr } @compiler_2fbuild_2ekindSuffix(ptr %s0, i32 %a2)
  store { i64, ptr } %t62, ptr %l41
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_4cf283899a273ea5_54dbe84ebef87a69)
  unreachable
bb21:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v0, ptr %s0, ptr %t63)
  store { i64, ptr } %t65, ptr %l43
  br label %bb22
bb22:
  %t66 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 1
  %t68 = extractvalue { i64, ptr } %t66, 0
  %t69 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d115, i32 0, i32 1) }, 1
  %t70 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d115, i32 0, i32 1) }, 0
  %t71 = add i64 %t68, %t70
  %t72 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t72, 1
  %t74 = extractvalue { i64, ptr } %t72, 0
  %t75 = add i64 %t71, %t74
  %t76 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d116, i32 0, i32 1) }, 1
  %t77 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d116, i32 0, i32 1) }, 0
  %t78 = add i64 %t75, %t77
  %t79 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t79, 1
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t82 = add i64 %t78, %t81
  %t83 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t83, 1
  %t85 = extractvalue { i64, ptr } %t83, 0
  %t86 = add i64 %t82, %t85
  %t87 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 1
  %t89 = extractvalue { i64, ptr } %t87, 0
  %t90 = add i64 %t86, %t89
  %t91 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d117, i32 0, i32 1) }, 1
  %t92 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d117, i32 0, i32 1) }, 0
  %t93 = add i64 %t90, %t92
  %t94 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t93)
  call void @olang_textcopy(ptr %t94, ptr %t67, i64 %t68)
  %t95 = getelementptr i8, ptr %t94, i64 %t68
  call void @olang_textcopy(ptr %t95, ptr %t69, i64 %t70)
  %t96 = getelementptr i8, ptr %t95, i64 %t70
  call void @olang_textcopy(ptr %t96, ptr %t73, i64 %t74)
  %t97 = getelementptr i8, ptr %t96, i64 %t74
  call void @olang_textcopy(ptr %t97, ptr %t76, i64 %t77)
  %t98 = getelementptr i8, ptr %t97, i64 %t77
  call void @olang_textcopy(ptr %t98, ptr %t80, i64 %t81)
  %t99 = getelementptr i8, ptr %t98, i64 %t81
  call void @olang_textcopy(ptr %t99, ptr %t84, i64 %t85)
  %t100 = getelementptr i8, ptr %t99, i64 %t85
  call void @olang_textcopy(ptr %t100, ptr %t88, i64 %t89)
  %t101 = getelementptr i8, ptr %t100, i64 %t89
  call void @olang_textcopy(ptr %t101, ptr %t91, i64 %t92)
  %t102 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t94, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t103, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eSpillDir(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l12 = alloca i32
  %l14 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i32
  %l26 = alloca i1
  %l39 = alloca { i64, ptr }
  %l42 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i32
  %l48 = alloca i1
  %l49 = alloca { i64, ptr }
  %l50 = alloca i64
  %l51 = alloca i64
  %l58 = alloca i1
  %l64 = alloca i32
  %l66 = alloca i1
  %l72 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l74 = alloca i32
  %l77 = alloca { i64, ptr }
  %l78 = alloca i32
  %l80 = alloca i1
  %l83 = alloca { i64, ptr }
  %l84 = alloca i64
  %l85 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/build:Config", ptr %a0, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 1
  %t7 = extractvalue { i64, ptr } %t4, 0
  %t8 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d118, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d118, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t6, i64 %t7)
  %t12 = getelementptr i8, ptr %t11, i64 %t7
  call void @olang_textcopy(ptr %t12, ptr %t8, i64 %t9)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t11, 1
  store { i64, ptr } %t14, ptr %l1, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t18 = call i32 @std_2fos_2eMkDirAll(ptr %s0, { i64, ptr } %t16)
  store i32 %t18, ptr %l12
  %t19 = icmp ne i32 %t18, 0
  br i1 %t19, label %bb2, label %ok.20, !prof !99
ok.20:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t21 = load i32, ptr %l12, !tbaa !23
  %t22 = ashr i32 %t21, 16
  %t24 = icmp eq i32 %t22, 1
  store i1 %t24, ptr %l14, !tbaa !21
  %t25 = load i32, ptr %l12, !tbaa !23
  %t26 = ashr i32 %t25, 16
  %t28 = icmp eq i32 %t26, 1
  br i1 %t28, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d119, i32 0, i32 1) }, ptr %l17, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t30, ptr %l18, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l19, !tbaa !24
  %t33 = load i64, ptr %l19, !tbaa !24
  %t34 = mul i64 %t33, 1
  %t35 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t34)
  %t36 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  store { i64, ptr } %t37, ptr %l20, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = load i64, ptr %l19, !tbaa !24
  %t43 = mul i64 %t42, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t39, ptr %t41, i64 %t43, i1 false)
  %t44 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t44, ptr %l18, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t45 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t45, ptr %rv
  br label %ret
bb6:
  %t46 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t48 = call { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %s0, ptr %s0, { i64, ptr } %t46)
  %t49 = extractvalue { i32, { i64, ptr } } %t48, 1
  %t50 = extractvalue { i32, { i64, ptr } } %t48, 0
  store i32 %t50, ptr %l24
  %t51 = icmp ne i32 %t50, 0
  br i1 %t51, label %bb8, label %ok.52, !prof !99
ok.52:
  store { i64, ptr } %t49, ptr %l23
  br label %bb7
bb7:
  %t53 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t53, ptr %l21, !tbaa !27
  br label %bb16
bb8:
  %t54 = load i32, ptr %l24, !tbaa !23
  %t55 = ashr i32 %t54, 16
  %t57 = icmp eq i32 %t55, 1
  store i1 %t57, ptr %l26, !tbaa !21
  %t58 = load i32, ptr %l24, !tbaa !23
  %t59 = ashr i32 %t58, 16
  %t61 = icmp eq i32 %t59, 1
  br i1 %t61, label %bb9, label %bb10
bb9:
  call void @__olang_errpay_pop()
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t63 = icmp sge i64 0, 0
  br i1 %t63, label %bb12, label %bb13
bb12:
  %t65 = icmp sle i64 0, 576460752303423487
  br i1 %t65, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_fea310fef6f4afce_d971442cb72d2c82)
  unreachable
bb14:
  %t67 = mul i64 0, 16
  %t68 = insertvalue { i64, ptr } undef, i64 0, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t69, ptr %l21, !tbaa !27
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_fea310fef6f4afce_d971442cb72d2c82)
  unreachable
bb16:
  %t71 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t71, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t74 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t74, 0
  store i64 %t76, ptr %l5, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s4
  %t78 = load i64, ptr %l4, !tbaa !24
  %t79 = load i64, ptr %l5, !tbaa !24
  %t82 = icmp slt i64 %t78, %t79
  %t84 = xor i1 %t82, true
  br i1 %t84, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s4)
  br label %bb45
bb19:
  br label %bb20
bb20:
  %t86 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t86, ptr %l39, !tbaa !27
  %t87 = load i64, ptr %l4, !tbaa !24
  %t89 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr { i64, ptr }, ptr %t90, i64 %t87
  %t92 = load { i64, ptr }, ptr %t91, !tbaa !37
  store { i64, ptr } %t92, ptr %l6, !tbaa !27
  %t94 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t96 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %s0, ptr %s4, { i64, ptr } %t94, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d120, i32 0, i32 1) })
  %t97 = extractvalue { i32, i64 } %t96, 1
  %t98 = extractvalue { i32, i64 } %t96, 0
  store i32 %t98, ptr %l45
  %t99 = icmp ne i32 %t98, 0
  br i1 %t99, label %bb22, label %ok.100, !prof !99
ok.100:
  store i64 %t97, ptr %l44
  br label %bb21
bb21:
  %t101 = load i64, ptr %l44, !tbaa !24
  store i64 %t101, ptr %l42, !tbaa !24
  br label %bb24
bb22:
  br label %bb23
bb23:
  store i64 -1, ptr %l42, !tbaa !24
  br label %bb24
bb24:
  %t102 = load i64, ptr %l42, !tbaa !24
  store i64 %t102, ptr %l7, !tbaa !24
  %t103 = load i64, ptr %l7, !tbaa !24
  %t105 = icmp sgt i64 %t103, 0
  br i1 %t105, label %bb25, label %bb26
bb25:
  %t107 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t107, ptr %l49, !tbaa !27
  %t108 = load i64, ptr %l7, !tbaa !24
  store i64 %t108, ptr %l50, !tbaa !24
  %t109 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 0
  store i64 %t110, ptr %l51, !tbaa !24
  %t111 = icmp sge i64 0, 0
  br i1 %t111, label %bb27, label %bb28
bb26:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb34
bb27:
  %t113 = load i64, ptr %l50, !tbaa !24
  %t114 = icmp sle i64 0, %t113
  br i1 %t114, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_971dc51609f108cb_e0495ae22580df77)
  unreachable
bb29:
  %t116 = load i64, ptr %l50, !tbaa !24
  %t117 = load i64, ptr %l51, !tbaa !24
  %t118 = icmp sle i64 %t116, %t117
  br i1 %t118, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_971dc51609f108cb_e0495ae22580df77)
  unreachable
bb31:
  %t120 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = load i64, ptr %l50, !tbaa !24
  %t123 = getelementptr i8, ptr %t121, i64 0
  %t124 = sub i64 %t122, 0
  %t125 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t123, 1
  %t127 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d121, i32 0, i32 1) }, 1
  %t128 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d121, i32 0, i32 1) }, 0
  %t130 = extractvalue { i64, ptr } %t126, 1
  %t131 = extractvalue { i64, ptr } %t126, 0
  %t132 = add i64 %t128, %t131
  %t133 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t132)
  call void @olang_textcopy(ptr %t133, ptr %t127, i64 %t128)
  %t134 = getelementptr i8, ptr %t133, i64 %t128
  call void @olang_textcopy(ptr %t134, ptr %t130, i64 %t131)
  %t135 = insertvalue { i64, ptr } undef, i64 %t132, 0
  %t136 = insertvalue { i64, ptr } %t135, ptr %t133, 1
  %t139 = call i1 @std_2fos_2eExists(ptr %s4, { i64, ptr } %t136)
  store i1 %t139, ptr %l58
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_971dc51609f108cb_e0495ae22580df77)
  unreachable
bb33:
  %t140 = load i1, ptr %l58, !tbaa !21
  %t141 = xor i1 %t140, true
  store i1 %t141, ptr %l48, !tbaa !21
  br label %bb34
bb34:
  %t143 = load i1, ptr %l48, !tbaa !21
  br i1 %t143, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s6
  %t144 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t145 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t144, 1
  %t148 = extractvalue { i64, ptr } %t144, 0
  %t149 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d122, i32 0, i32 1) }, 1
  %t150 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d122, i32 0, i32 1) }, 0
  %t151 = add i64 %t148, %t150
  %t153 = extractvalue { i64, ptr } %t145, 1
  %t154 = extractvalue { i64, ptr } %t145, 0
  %t155 = add i64 %t151, %t154
  %t156 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t155)
  call void @olang_textcopy(ptr %t156, ptr %t147, i64 %t148)
  %t157 = getelementptr i8, ptr %t156, i64 %t148
  call void @olang_textcopy(ptr %t157, ptr %t149, i64 %t150)
  %t158 = getelementptr i8, ptr %t157, i64 %t150
  call void @olang_textcopy(ptr %t158, ptr %t153, i64 %t154)
  %t159 = insertvalue { i64, ptr } undef, i64 %t155, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t156, 1
  %t163 = call i32 @std_2fos_2eRemoveAll(ptr %s6, { i64, ptr } %t160)
  store i32 %t163, ptr %l64
  %t164 = icmp ne i32 %t163, 0
  br i1 %t164, label %bb38, label %ok.165, !prof !99
ok.165:
  br label %bb37
bb36:
  br label %bb43
bb37:
  br label %bb42
bb38:
  %t166 = load i32, ptr %l64, !tbaa !23
  %t167 = ashr i32 %t166, 16
  %t169 = icmp eq i32 %t167, 1
  store i1 %t169, ptr %l66, !tbaa !21
  %t170 = load i32, ptr %l64, !tbaa !23
  %t171 = ashr i32 %t170, 16
  %t173 = icmp eq i32 %t171, 1
  br i1 %t173, label %bb39, label %bb40
bb39:
  call void @__olang_errpay_pop()
  br label %bb40
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s6)
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s4)
  br label %bb44
bb44:
  %t175 = load i64, ptr %l4, !tbaa !24
  %t178 = add i64 %t175, 1
  store i64 %t178, ptr %l4, !tbaa !24
  br label %bb17
bb45:
  %t180 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t180, ptr %l73, !tbaa !27
  %t181 = call i32 @compiler_2fbuild_2ePid()
  store i32 %t181, ptr %l74
  br label %bb46
bb46:
  %t182 = extractvalue { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d123, i32 0, i32 1) }, 1
  %t183 = extractvalue { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d123, i32 0, i32 1) }, 0
  %t184 = load i32, ptr %l74, !tbaa !23
  %t185 = sext i32 %t184 to i64
  %t186 = call i64 @__olang_fmt_i64(ptr null, i64 %t185)
  %t187 = add i64 %t183, %t186
  %t188 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d124, i32 0, i32 1) }, 1
  %t189 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d124, i32 0, i32 1) }, 0
  %t190 = add i64 %t187, %t189
  %t191 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t190)
  call void @olang_textcopy(ptr %t191, ptr %t182, i64 %t183)
  %t192 = getelementptr i8, ptr %t191, i64 %t183
  %t193 = call i64 @__olang_fmt_i64(ptr %t192, i64 %t185)
  %t194 = getelementptr i8, ptr %t192, i64 %t186
  call void @olang_textcopy(ptr %t194, ptr %t188, i64 %t189)
  %t195 = insertvalue { i64, ptr } undef, i64 %t190, 0
  %t196 = insertvalue { i64, ptr } %t195, ptr %t191, 1
  %t198 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t200 = call { i32, { i64, ptr } } @std_2fos_2eMkTemp(ptr %s0, ptr %s0, ptr %v1, { i64, ptr } %t198, { i64, ptr } %t196)
  %t201 = extractvalue { i32, { i64, ptr } } %t200, 1
  %t202 = extractvalue { i32, { i64, ptr } } %t200, 0
  store i32 %t202, ptr %l78
  %t203 = icmp ne i32 %t202, 0
  br i1 %t203, label %bb48, label %ok.204, !prof !99
ok.204:
  store { i64, ptr } %t201, ptr %l77
  br label %bb47
bb47:
  %t205 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t205, ptr %l72, !tbaa !27
  br label %bb52
bb48:
  %t206 = load i32, ptr %l78, !tbaa !23
  %t207 = ashr i32 %t206, 16
  %t209 = icmp eq i32 %t207, 1
  store i1 %t209, ptr %l80, !tbaa !21
  %t210 = load i32, ptr %l78, !tbaa !23
  %t211 = ashr i32 %t210, 16
  %t213 = icmp eq i32 %t211, 1
  br i1 %t213, label %bb49, label %bb50
bb49:
  call void @__olang_errpay_pop()
  br label %bb50
bb50:
  br label %bb51
bb51:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d125, i32 0, i32 1) }, ptr %l72, !tbaa !27
  br label %bb52
bb52:
  %t215 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t215, ptr %l83, !tbaa !27
  %t216 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t217 = extractvalue { i64, ptr } %t216, 0
  store i64 %t217, ptr %l84, !tbaa !24
  %t218 = load i64, ptr %l84, !tbaa !24
  %t219 = mul i64 %t218, 1
  %t220 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t219)
  %t221 = insertvalue { i64, ptr } undef, i64 %t218, 0
  %t222 = insertvalue { i64, ptr } %t221, ptr %t220, 1
  store { i64, ptr } %t222, ptr %l85, !tbaa !27
  %t223 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t224 = load ptr, ptr %t223, !tbaa !27
  %t225 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !27
  %t227 = load i64, ptr %l84, !tbaa !24
  %t228 = mul i64 %t227, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t224, ptr %t226, i64 %t228, i1 false)
  %t229 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t229, ptr %l83, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t230 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t230, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ebitcodeText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca { { i64, ptr }, { i64, ptr } }
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca i32
  %l33 = alloca i1
  %l46 = alloca { i64, ptr }
  %l50 = alloca i1
  %l52 = alloca i1
  %l54 = alloca i1
  %l56 = alloca i1
  %l62 = alloca i32
  %l64 = alloca i1
  %l67 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l74 = alloca ptr
  %l75 = alloca i64
  %l84 = alloca i64
  %l90 = alloca [9 x { i64, ptr }]
  %l106 = alloca ptr
  %l107 = alloca i64
  %l110 = alloca { i64, ptr }
  %l115 = alloca { i64, ptr }
  %l117 = alloca i64
  %l121 = alloca { { i64, ptr }, { i64, ptr } }
  %l122 = alloca { i64, ptr }
  %l123 = alloca i64
  %l124 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l126 = alloca i64
  %l127 = alloca { i64, ptr }
  %l133 = alloca i64
  %l136 = alloca i64
  %l159 = alloca ptr
  %l160 = alloca { i64, [3 x i64] }
  %l163 = alloca { i64, ptr }
  %l164 = alloca { i64, ptr }
  %l167 = alloca { i64, ptr }
  %l171 = alloca %"compiler/diagmsg:Msg"
  %l177 = alloca i64
  %l179 = alloca i64
  %l184 = alloca { i64, ptr }
  %l185 = alloca { i64, ptr }
  %l190 = alloca i32
  %l192 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %rv = alloca i32
  %t356 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l27
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l3
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = call { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v1, ptr %s0, { i64, ptr } %t3)
  %t6 = extractvalue { i32, { i64, ptr } } %t5, 1
  %t7 = extractvalue { i32, { i64, ptr } } %t5, 0
  store i32 %t7, ptr %l31
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb3, label %ok.9, !prof !99
ok.9:
  store { i64, ptr } %t6, ptr %l30
  br label %bb2
bb2:
  %t10 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t10, ptr %l28, !tbaa !27
  br label %bb11
bb3:
  %t11 = load i32, ptr %l31, !tbaa !23
  %t12 = ashr i32 %t11, 16
  %t14 = icmp eq i32 %t12, 1
  store i1 %t14, ptr %l33, !tbaa !21
  %t15 = load i32, ptr %l31, !tbaa !23
  %t16 = ashr i32 %t15, 16
  %t18 = icmp eq i32 %t16, 1
  br i1 %t18, label %bb4, label %bb5
bb4:
  call void @__olang_errpay_pop()
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t20 = icmp sge i64 0, 0
  br i1 %t20, label %bb7, label %bb8
bb7:
  %t22 = icmp sle i64 0, 576460752303423487
  br i1 %t22, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_ed85b58552229ad2_db88a25435ad515e)
  unreachable
bb9:
  %t24 = mul i64 0, 16
  %t25 = insertvalue { i64, ptr } undef, i64 0, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t26, ptr %l28, !tbaa !27
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_ed85b58552229ad2_db88a25435ad515e)
  unreachable
bb11:
  %t28 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t28, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  store i64 %t33, ptr %l7, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i64, ptr %l6, !tbaa !24
  %t36 = load i64, ptr %l7, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb56
bb14:
  br label %bb15
bb15:
  %t43 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t43, ptr %l46, !tbaa !27
  %t44 = load i64, ptr %l6, !tbaa !24
  %t46 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %t47, i64 %t44
  %t49 = load { i64, ptr }, ptr %t48, !tbaa !37
  store { i64, ptr } %t49, ptr %l8, !tbaa !27
  %t51 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t53 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s2, { i64, ptr } %t51, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d126, i32 0, i32 1) })
  store i1 %t53, ptr %l50
  br label %bb16
bb16:
  %t54 = load i1, ptr %l50, !tbaa !21
  %t55 = xor i1 %t54, true
  br i1 %t55, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l52, !tbaa !21
  br label %bb20
bb18:
  %t57 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t59 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s0, ptr %s2, { i64, ptr } %t57, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d127, i32 0, i32 1) })
  store i1 %t59, ptr %l54
  br label %bb19
bb19:
  %t60 = load i1, ptr %l54, !tbaa !21
  store i1 %t60, ptr %l52, !tbaa !21
  br label %bb20
bb20:
  %t61 = load i1, ptr %l52, !tbaa !21
  br i1 %t61, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb55
bb22:
  br label %bb23
bb23:
  %t62 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t64 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s0, ptr %s2, { i64, ptr } %t62, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d128, i32 0, i32 1) })
  store i1 %t64, ptr %l56
  br label %bb24
bb24:
  %t65 = load i1, ptr %l56, !tbaa !21
  %t66 = xor i1 %t65, true
  br i1 %t66, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s4
  %t68 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t69 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t68, 1
  %t72 = extractvalue { i64, ptr } %t68, 0
  %t73 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d129, i32 0, i32 1) }, 1
  %t74 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d129, i32 0, i32 1) }, 0
  %t75 = add i64 %t72, %t74
  %t77 = extractvalue { i64, ptr } %t69, 1
  %t78 = extractvalue { i64, ptr } %t69, 0
  %t79 = add i64 %t75, %t78
  %t80 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t79)
  call void @olang_textcopy(ptr %t80, ptr %t71, i64 %t72)
  %t81 = getelementptr i8, ptr %t80, i64 %t72
  call void @olang_textcopy(ptr %t81, ptr %t73, i64 %t74)
  %t82 = getelementptr i8, ptr %t81, i64 %t74
  call void @olang_textcopy(ptr %t82, ptr %t77, i64 %t78)
  %t83 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t80, 1
  %t87 = call i32 @std_2fos_2eRemove(ptr %s4, { i64, ptr } %t84)
  store i32 %t87, ptr %l62
  %t88 = icmp ne i32 %t87, 0
  br i1 %t88, label %bb28, label %ok.89, !prof !99
ok.89:
  br label %bb27
bb26:
  br label %bb33
bb27:
  br label %bb32
bb28:
  %t90 = load i32, ptr %l62, !tbaa !23
  %t91 = ashr i32 %t90, 16
  %t93 = icmp eq i32 %t91, 1
  store i1 %t93, ptr %l64, !tbaa !21
  %t94 = load i32, ptr %l62, !tbaa !23
  %t95 = ashr i32 %t94, 16
  %t97 = icmp eq i32 %t95, 1
  br i1 %t97, label %bb29, label %bb30
bb29:
  call void @__olang_errpay_pop()
  br label %bb30
bb30:
  br label %bb31
bb31:
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  br label %bb55
bb33:
  %t99 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t99, ptr %l67
  br label %bb34
bb34:
  %t100 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l67
  %t101 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t100, ptr %t101
  store ptr %t101, ptr %l9, !tbaa !29
  %t103 = load ptr, ptr %l9, !tbaa !29
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/build:Config", ptr %t104, i32 0, i32 1
  %t107 = load { i64, ptr }, ptr %t106, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v0, ptr %t103, { i64, ptr } %t107)
  br label %bb35
bb35:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/build:Config", ptr %t110, i32 0, i32 2
  %t113 = getelementptr %"compiler/target:Target", ptr %t112, i32 0, i32 9
  %t114 = load i1, ptr %t113, !tbaa !21
  br i1 %t114, label %bb36, label %bb37
bb36:
  %t116 = load ptr, ptr %l9, !tbaa !29
  store ptr %t116, ptr %l74, !tbaa !29
  %t117 = call ptr @__olang_scope_hold(ptr %s0)
  %t118 = ptrtoint ptr %t117 to i64
  store i64 %t118, ptr %l75, !tbaa !24
  %t119 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t119, label %bb38, label %bb39
bb37:
  br label %bb41
bb38:
  %t121 = call ptr @__olang_region_make(ptr %s0)
  %t122 = ptrtoint ptr %t121 to i64
  store i64 %t122, ptr %l75, !tbaa !24
  br label %bb39
bb39:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/build:Config", ptr %t123, i32 0, i32 2
  %t126 = getelementptr %"compiler/target:Target", ptr %t125, i32 0, i32 1
  %t127 = load { i64, ptr }, ptr %t126, !tbaa !27
  %t128 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d130, i32 0, i32 1) }, 1
  %t129 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d130, i32 0, i32 1) }, 0
  %t131 = extractvalue { i64, ptr } %t127, 1
  %t132 = extractvalue { i64, ptr } %t127, 0
  %t133 = add i64 %t129, %t132
  %t134 = load i64, ptr %l75
  %t135 = inttoptr i64 %t134 to ptr
  %t136 = call ptr @__olang_held_alloc(ptr %t135, i64 %t133)
  call void @olang_textcopy(ptr %t136, ptr %t128, i64 %t129)
  %t137 = getelementptr i8, ptr %t136, i64 %t129
  call void @olang_textcopy(ptr %t137, ptr %t131, i64 %t132)
  %t138 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t136, 1
  %t141 = load ptr, ptr %l74, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t141, { i64, ptr } %t139)
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t143 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t144 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t143, 1
  %t147 = extractvalue { i64, ptr } %t143, 0
  %t148 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d131, i32 0, i32 1) }, 1
  %t149 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d131, i32 0, i32 1) }, 0
  %t150 = add i64 %t147, %t149
  %t152 = extractvalue { i64, ptr } %t144, 1
  %t153 = extractvalue { i64, ptr } %t144, 0
  %t154 = add i64 %t150, %t153
  %t155 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t154)
  call void @olang_textcopy(ptr %t155, ptr %t146, i64 %t147)
  %t156 = getelementptr i8, ptr %t155, i64 %t147
  call void @olang_textcopy(ptr %t156, ptr %t148, i64 %t149)
  %t157 = getelementptr i8, ptr %t156, i64 %t149
  call void @olang_textcopy(ptr %t157, ptr %t152, i64 %t153)
  %t158 = insertvalue { i64, ptr } undef, i64 %t154, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t155, 1
  store { i64, ptr } %t159, ptr %l10, !tbaa !27
  %t161 = call ptr @__olang_scope_hold(ptr %s0)
  %t162 = ptrtoint ptr %t161 to i64
  store i64 %t162, ptr %l84, !tbaa !24
  %t163 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_209_3e_2e_2d1
  br i1 %t163, label %bb42, label %bb43
bb42:
  %t165 = call ptr @__olang_region_make(ptr %s0)
  %t166 = ptrtoint ptr %t165 to i64
  store i64 %t166, ptr %l84, !tbaa !24
  br label %bb43
bb43:
  %t167 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t167, 1
  %t170 = extractvalue { i64, ptr } %t167, 0
  %t171 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d132, i32 0, i32 1) }, 1
  %t172 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d132, i32 0, i32 1) }, 0
  %t173 = add i64 %t170, %t172
  %t174 = load i64, ptr %l84
  %t175 = inttoptr i64 %t174 to ptr
  %t176 = call ptr @__olang_held_alloc(ptr %t175, i64 %t173)
  call void @olang_textcopy(ptr %t176, ptr %t169, i64 %t170)
  %t177 = getelementptr i8, ptr %t176, i64 %t170
  call void @olang_textcopy(ptr %t177, ptr %t171, i64 %t172)
  %t178 = insertvalue { i64, ptr } undef, i64 %t173, 0
  %t179 = insertvalue { i64, ptr } %t178, ptr %t176, 1
  %t181 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t182 = getelementptr [9 x { i64, ptr }], ptr %l90, i64 0, i64 0
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d133, i32 0, i32 1) }, ptr %t182, !tbaa !37
  %t183 = getelementptr [9 x { i64, ptr }], ptr %l90, i64 0, i64 1
  store { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d134, i32 0, i32 1) }, ptr %t183, !tbaa !37
  %t184 = getelementptr [9 x { i64, ptr }], ptr %l90, i64 0, i64 2
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d135, i32 0, i32 1) }, ptr %t184, !tbaa !37
  %t185 = getelementptr [9 x { i64, ptr }], ptr %l90, i64 0, i64 3
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d136, i32 0, i32 1) }, ptr %t185, !tbaa !37
  %t186 = getelementptr [9 x { i64, ptr }], ptr %l90, i64 0, i64 4
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d137, i32 0, i32 1) }, ptr %t186, !tbaa !37
  %t187 = getelementptr [9 x { i64, ptr }], ptr %l90, i64 0, i64 5
  store { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d138, i32 0, i32 1) }, ptr %t187, !tbaa !37
  %t188 = getelementptr [9 x { i64, ptr }], ptr %l90, i64 0, i64 6
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d139, i32 0, i32 1) }, ptr %t188, !tbaa !37
  %t189 = getelementptr [9 x { i64, ptr }], ptr %l90, i64 0, i64 7
  store { i64, ptr } %t179, ptr %t189, !tbaa !37
  %t191 = getelementptr [9 x { i64, ptr }], ptr %l90, i64 0, i64 8
  store { i64, ptr } %t181, ptr %t191, !tbaa !37
  %t193 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 144, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t193, ptr %l90, i64 144, i1 false)
  store ptr %t193, ptr %l11
  store i64 0, ptr %l12, !tbaa !24
  %t195 = load ptr, ptr %l11
  store i64 9, ptr %l13, !tbaa !24
  br label %bb44
bb44:
  %t198 = load i64, ptr %l12, !tbaa !24
  %t199 = load i64, ptr %l13, !tbaa !24
  %t202 = icmp slt i64 %t198, %t199
  %t204 = xor i1 %t202, true
  br i1 %t204, label %bb45, label %bb46
bb45:
  br label %bb50
bb46:
  br label %bb47
bb47:
  %t206 = load ptr, ptr %l11
  %t207 = load i64, ptr %l12, !tbaa !24
  %t210 = getelementptr [9 x { i64, ptr }], ptr %t206, i64 0, i64 %t207
  %t211 = load { i64, ptr }, ptr %t210, !tbaa !37
  %t213 = load ptr, ptr %l9, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t213, { i64, ptr } %t211)
  br label %bb48
bb48:
  br label %bb49
bb49:
  %t217 = load i64, ptr %l12, !tbaa !24
  %t220 = add i64 %t217, 1
  store i64 %t220, ptr %l12, !tbaa !24
  br label %bb44
bb50:
  store ptr %l3, ptr %l106, !tbaa !29
  %t222 = call ptr @__olang_scope_hold(ptr %s0)
  %t223 = ptrtoint ptr %t222 to i64
  store i64 %t223, ptr %l107, !tbaa !24
  %t224 = load i1, ptr @olang_2esole_2eArray_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2e_2d1
  br i1 %t224, label %bb51, label %bb52
bb51:
  %t226 = call ptr @__olang_region_make(ptr %s0)
  %t227 = ptrtoint ptr %t226 to i64
  store i64 %t227, ptr %l107, !tbaa !24
  br label %bb52
bb52:
  %t228 = load ptr, ptr %l9, !tbaa !29
  %t229 = load i64, ptr %l107
  %t230 = inttoptr i64 %t229 to ptr
  %t232 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %s0, ptr %t230, ptr %t228)
  store { i64, ptr } %t232, ptr %l110
  br label %bb53
bb53:
  %t233 = load ptr, ptr %l106, !tbaa !29
  %t234 = load { i64, ptr }, ptr %l110, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s0, ptr %s0, ptr %t233, { i64, ptr } %t234)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s2)
  br label %bb55
bb55:
  %t235 = load i64, ptr %l6, !tbaa !24
  %t238 = add i64 %t235, 1
  store i64 %t238, ptr %l6, !tbaa !24
  br label %bb12
bb56:
  %t241 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s0, ptr %s0, ptr %l3)
  store { i64, ptr } %t241, ptr %l115
  br label %bb57
bb57:
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t244 = call i64 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewidth(ptr %v0, ptr %t242)
  store i64 %t244, ptr %l117
  br label %bb58
bb58:
  %t245 = icmp sge i64 0, 0
  br i1 %t245, label %bb59, label %bb60
bb59:
  %t247 = icmp sle i64 0, 1152921504606846975
  br i1 %t247, label %bb61, label %bb62
bb60:
  call void @__olang_check_failed(ptr @olang_loc_39c6cdce0ac4fdc7_621aa1b204fc2693)
  unreachable
bb61:
  %t249 = mul i64 0, 8
  %t250 = insertvalue { i64, ptr } undef, i64 0, 0
  %t251 = insertvalue { i64, ptr } %t250, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t252 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t253 = load i64, ptr %l117, !tbaa !24
  %t255 = call { { i64, ptr }, { i64, ptr } } @compiler_2fbuild_2eRunAll(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t252, i64 %t253, { i64, ptr } %t251)
  store { { i64, ptr }, { i64, ptr } } %t255, ptr %l121
  br label %bb63
bb62:
  call void @__olang_check_failed(ptr @olang_loc_39c6cdce0ac4fdc7_621aa1b204fc2693)
  unreachable
bb63:
  %t256 = load { { i64, ptr }, { i64, ptr } }, ptr %l121
  store { { i64, ptr }, { i64, ptr } } %t256, ptr %l15
  %t257 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l15, i32 0, i32 0
  %t258 = load { i64, ptr }, ptr %t257, !tbaa !27
  store { i64, ptr } %t258, ptr %l122, !tbaa !27
  %t259 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t260 = extractvalue { i64, ptr } %t259, 0
  store i64 %t260, ptr %l123, !tbaa !24
  %t261 = load i64, ptr %l123, !tbaa !24
  %t262 = mul i64 %t261, 4
  %t263 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t262)
  %t264 = insertvalue { i64, ptr } undef, i64 %t261, 0
  %t265 = insertvalue { i64, ptr } %t264, ptr %t263, 1
  store { i64, ptr } %t265, ptr %l124, !tbaa !27
  %t266 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t267 = load ptr, ptr %t266, !tbaa !27
  %t268 = getelementptr { i64, ptr }, ptr %l122, i32 0, i32 1
  %t269 = load ptr, ptr %t268, !tbaa !27
  %t270 = load i64, ptr %l123, !tbaa !24
  %t271 = mul i64 %t270, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t267, ptr %t269, i64 %t271, i1 false)
  %t272 = load { i64, ptr }, ptr %l124, !tbaa !27
  store { i64, ptr } %t272, ptr %l16, !tbaa !27
  %t273 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l15, i32 0, i32 1
  %t274 = load { i64, ptr }, ptr %t273, !tbaa !27
  store { i64, ptr } %t274, ptr %l125, !tbaa !27
  %t275 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t276 = extractvalue { i64, ptr } %t275, 0
  store i64 %t276, ptr %l126, !tbaa !24
  %t277 = load i64, ptr %l126, !tbaa !24
  %t278 = mul i64 %t277, 16
  %t279 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t278)
  %t280 = insertvalue { i64, ptr } undef, i64 %t277, 0
  %t281 = insertvalue { i64, ptr } %t280, ptr %t279, 1
  store { i64, ptr } %t281, ptr %l127, !tbaa !27
  %t282 = getelementptr { i64, ptr }, ptr %l127, i32 0, i32 1
  %t283 = load ptr, ptr %t282, !tbaa !27
  %t284 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t285 = load ptr, ptr %t284, !tbaa !27
  %t286 = load i64, ptr %l126, !tbaa !24
  %t287 = mul i64 %t286, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t283, ptr %t285, i64 %t287, i1 false)
  %t288 = load { i64, ptr }, ptr %l127, !tbaa !27
  store { i64, ptr } %t288, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t289 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t291 = extractvalue { i64, ptr } %t289, 0
  store i64 %t291, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t293 = load i64, ptr %l19, !tbaa !24
  %t294 = load i64, ptr %l18, !tbaa !24
  %t297 = icmp sgt i64 %t293, %t294
  br i1 %t297, label %bb64, label %bb65
bb64:
  %t299 = load i64, ptr %l20, !tbaa !24
  %t301 = icmp sgt i64 %t299, 0
  br i1 %t301, label %bb66, label %bb67
bb65:
  store i64 0, ptr %l133, !tbaa !24
  br label %bb69
bb66:
  %t303 = load i64, ptr %l19, !tbaa !24
  %t304 = load i64, ptr %l18, !tbaa !24
  %t307 = sub i64 %t303, %t304
  %t308 = load i64, ptr %l20, !tbaa !24
  %t311 = add i64 %t307, %t308
  %t313 = sub i64 %t311, 1
  %t314 = load i64, ptr %l20, !tbaa !24
  %t317 = sdiv i64 %t313, %t314
  store i64 %t317, ptr %l136, !tbaa !24
  br label %bb68
bb67:
  store i64 0, ptr %l136, !tbaa !24
  br label %bb68
bb68:
  %t319 = load i64, ptr %l136, !tbaa !24
  store i64 %t319, ptr %l133, !tbaa !24
  br label %bb69
bb69:
  %t320 = load i64, ptr %l133, !tbaa !24
  store i64 %t320, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb70
bb70:
  store %olang.scope zeroinitializer, ptr %s16
  %t321 = load i64, ptr %l22, !tbaa !24
  %t322 = load i64, ptr %l21, !tbaa !24
  %t325 = icmp slt i64 %t321, %t322
  %t327 = xor i1 %t325, true
  br i1 %t327, label %bb71, label %bb72
bb71:
  call void @__olang_scope_close(ptr %s16)
  br label %bb83
bb72:
  br label %bb73
bb73:
  %t329 = load i64, ptr %l18, !tbaa !24
  %t330 = load i64, ptr %l22, !tbaa !24
  %t331 = load i64, ptr %l20, !tbaa !24
  %t334 = mul i64 %t330, %t331
  %t337 = add i64 %t329, %t334
  store i64 %t337, ptr %l23, !tbaa !24
  %t339 = load i64, ptr %l23, !tbaa !24
  %t341 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t342 = load ptr, ptr %t341, !tbaa !27
  %t343 = getelementptr i32, ptr %t342, i64 %t339
  %t344 = load i32, ptr %t343, !tbaa !33
  %t346 = icmp eq i32 %t344, 0
  br i1 %t346, label %bb74, label %bb75
bb74:
  call void @__olang_scope_close(ptr %s16)
  br label %bb82
bb75:
  br label %bb76
bb76:
  %t348 = load i64, ptr %l23, !tbaa !24
  %t350 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t351 = load ptr, ptr %t350, !tbaa !27
  %t352 = getelementptr { i64, ptr }, ptr %t351, i64 %t348
  %t353 = load { i64, ptr }, ptr %t352, !tbaa !37
  call void @compiler_2fbuild_2esayErr(ptr %s0, { i64, ptr } %t353)
  br label %bb77
bb77:
  store ptr %a2, ptr %l159, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t356
  %t357 = getelementptr { i64, [3 x i64] }, ptr %t356, i32 0, i32 0
  store i64 0, ptr %t357
  %t358 = load { i64, [3 x i64] }, ptr %t356
  store { i64, [3 x i64] } %t358, ptr %l160
  %t359 = load i64, ptr %l23, !tbaa !24
  %t362 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %s0, ptr %s0, ptr %l3, i64 %t359)
  store { i64, ptr } %t362, ptr %l163
  br label %bb78
bb78:
  %t363 = load { i64, ptr }, ptr %l163, !tbaa !27
  store { i64, ptr } %t363, ptr %l164, !tbaa !27
  %t364 = load i64, ptr %l23, !tbaa !24
  %t367 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %s0, ptr %s16, ptr %l3, i64 %t364)
  store { i64, ptr } %t367, ptr %l167
  br label %bb79
bb79:
  %t368 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t369 = extractvalue { i64, ptr } %t368, 0
  %t371 = sub i64 %t369, 1
  %t373 = getelementptr { i64, ptr }, ptr %l164, i32 0, i32 1
  %t374 = load ptr, ptr %t373, !tbaa !27
  %t375 = getelementptr { i64, ptr }, ptr %t374, i64 %t371
  %t376 = load { i64, ptr }, ptr %t375, !tbaa !37
  %t378 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eClangFailed(ptr %s0, ptr %v2, { i64, ptr } %t376)
  store %"compiler/diagmsg:Msg" %t378, ptr %l171
  br label %bb80
bb80:
  %t379 = load ptr, ptr %l159, !tbaa !29
  %t380 = load { i64, [3 x i64] }, ptr %l160
  %t381 = load %"compiler/diagmsg:Msg", ptr %l171
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v2, ptr %v2, ptr %t379, { i64, [3 x i64] } %t380, %"compiler/diagmsg:Msg" %t381)
  br label %bb81
bb81:
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb82:
  %t383 = load i64, ptr %l22, !tbaa !24
  %t386 = add i64 %t383, 1
  store i64 %t386, ptr %l22, !tbaa !24
  br label %bb70
bb83:
  store ptr %l3, ptr %l24, !tbaa !29
  store i64 0, ptr %l25, !tbaa !24
  br label %bb84
bb84:
  %t389 = load i64, ptr %l25, !tbaa !24
  store i64 %t389, ptr %l177, !tbaa !24
  %t390 = load ptr, ptr %l24, !tbaa !29
  %t392 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H2ab12f44ffbd18d099d1f5a69642975a(ptr %s0, ptr %t390)
  store i64 %t392, ptr %l179
  br label %bb85
bb85:
  %t393 = load i64, ptr %l177, !tbaa !24
  %t394 = load i64, ptr %l179, !tbaa !24
  %t395 = icmp slt i64 %t393, %t394
  %t397 = xor i1 %t395, true
  br i1 %t397, label %bb86, label %bb87
bb86:
  br label %bb97
bb87:
  br label %bb88
bb88:
  %t399 = load ptr, ptr %l24, !tbaa !29
  %t400 = load i64, ptr %l25, !tbaa !24
  %t403 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %s0, ptr %s0, ptr %t399, i64 %t400)
  store { i64, ptr } %t403, ptr %l184
  br label %bb89
bb89:
  %t404 = load { i64, ptr }, ptr %l184, !tbaa !27
  store { i64, ptr } %t404, ptr %l26, !tbaa !27
  %t405 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t405, ptr %l185, !tbaa !27
  %t406 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t408 = extractvalue { i64, ptr } %t406, 0
  %t410 = sub i64 %t408, 1
  %t412 = getelementptr { i64, ptr }, ptr %l185, i32 0, i32 1
  %t413 = load ptr, ptr %t412, !tbaa !27
  %t414 = getelementptr { i64, ptr }, ptr %t413, i64 %t410
  %t415 = load { i64, ptr }, ptr %t414, !tbaa !37
  %t417 = call i32 @std_2fos_2eRemove(ptr %s0, { i64, ptr } %t415)
  store i32 %t417, ptr %l190
  %t418 = icmp ne i32 %t417, 0
  br i1 %t418, label %bb91, label %ok.419, !prof !99
ok.419:
  br label %bb90
bb90:
  br label %bb95
bb91:
  %t420 = load i32, ptr %l190, !tbaa !23
  %t421 = ashr i32 %t420, 16
  %t423 = icmp eq i32 %t421, 1
  store i1 %t423, ptr %l192, !tbaa !21
  %t424 = load i32, ptr %l190, !tbaa !23
  %t425 = ashr i32 %t424, 16
  %t427 = icmp eq i32 %t425, 1
  br i1 %t427, label %bb92, label %bb93
bb92:
  call void @__olang_errpay_pop()
  br label %bb93
bb93:
  br label %bb94
bb94:
  br label %bb95
bb95:
  br label %bb96
bb96:
  %t429 = load i64, ptr %l25, !tbaa !24
  %t432 = add i64 %t429, 1
  store i64 %t432, ptr %l25, !tbaa !24
  br label %bb84
bb97:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ecompile(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { { i64, ptr }, { i64, ptr } }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %l18 = alloca { i64, ptr }
  %l20 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca { { i64, ptr }, { i64, ptr } }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca ptr
  %l32 = alloca i64
  %l35 = alloca i64
  %l42 = alloca i64
  %l45 = alloca i64
  %l66 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l71 = alloca i32
  %l73 = alloca i1
  %l83 = alloca ptr
  %l84 = alloca { i64, [3 x i64] }
  %l88 = alloca { i64, ptr }
  %l89 = alloca %"compiler/diagmsg:Msg"
  %l93 = alloca { i64, ptr }
  %l94 = alloca i32
  %l96 = alloca i1
  %l102 = alloca { i64, ptr }
  %l103 = alloca i1
  %l108 = alloca { i64, ptr }
  %l109 = alloca i32
  %l111 = alloca i1
  %l116 = alloca i1
  %l123 = alloca { i64, ptr }
  %l124 = alloca i1
  %l129 = alloca { i64, ptr }
  %l133 = alloca { i64, ptr }
  %l134 = alloca { i64, ptr }
  %l136 = alloca i32
  %l138 = alloca i1
  %l143 = alloca i64
  %l148 = alloca { i64, ptr }
  %l149 = alloca { i64, ptr }
  %l150 = alloca { i64, ptr }
  %l151 = alloca %"compiler/diagmsg:Msg"
  %l153 = alloca ptr
  %l157 = alloca { i64, ptr }
  %l158 = alloca { i64, ptr }
  %l163 = alloca { i64, ptr }
  %l167 = alloca { i64, ptr }
  %l168 = alloca i32
  %l170 = alloca i1
  %l178 = alloca { i64, ptr }
  %l179 = alloca %"compiler/diagmsg:Msg"
  %l181 = alloca ptr
  %l185 = alloca { i64, ptr }
  %l191 = alloca i64
  %l193 = alloca i64
  %l198 = alloca { i64, ptr }
  %l200 = alloca i32
  %l202 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca i32
  %t165 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/build:compiles", ptr %t1, i32 0, i32 0
  %t5 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %v1, ptr %v1, ptr %t3)
  store { i64, ptr } %t5, ptr %l18
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i64 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewidth(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l20
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = getelementptr %"compiler/build:compiles", ptr %t9, i32 0, i32 6
  %t13 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v1, ptr %s0, ptr %t11)
  store { i64, ptr } %t13, ptr %l23
  br label %bb3
bb3:
  %t14 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t15 = load i64, ptr %l20, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t17 = call { { i64, ptr }, { i64, ptr } } @compiler_2fbuild_2eRunAll(ptr %v1, ptr %s0, ptr %s0, { i64, ptr } %t14, i64 %t15, { i64, ptr } %t16)
  store { { i64, ptr }, { i64, ptr } } %t17, ptr %l24
  br label %bb4
bb4:
  %t18 = load { { i64, ptr }, { i64, ptr } }, ptr %l24
  store { { i64, ptr }, { i64, ptr } } %t18, ptr %l3
  %t19 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l3, i32 0, i32 0
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l25, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 0
  store i64 %t22, ptr %l26, !tbaa !24
  %t23 = load i64, ptr %l26, !tbaa !24
  %t24 = mul i64 %t23, 4
  %t25 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t24)
  %t26 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l27, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = load i64, ptr %l26, !tbaa !24
  %t33 = mul i64 %t32, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t29, ptr %t31, i64 %t33, i1 false)
  %t34 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t34, ptr %l4, !tbaa !27
  %t35 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l3, i32 0, i32 1
  %t36 = load { i64, ptr }, ptr %t35, !tbaa !27
  store { i64, ptr } %t36, ptr %l28, !tbaa !27
  %t37 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 0
  store i64 %t38, ptr %l29, !tbaa !24
  %t39 = load i64, ptr %l29, !tbaa !24
  %t40 = mul i64 %t39, 16
  %t41 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t40)
  %t42 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t41, 1
  store { i64, ptr } %t43, ptr %l30, !tbaa !27
  %t44 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = load i64, ptr %l29, !tbaa !24
  %t49 = mul i64 %t48, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t45, ptr %t47, i64 %t49, i1 false)
  %t50 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t50, ptr %l5, !tbaa !27
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l31, !tbaa !29
  %t52 = load ptr, ptr %l31, !tbaa !29
  %t53 = getelementptr %"compiler/build:Config", ptr %t52, i32 0, i32 36
  %t54 = load i64, ptr %t53, !tbaa !24
  store i64 %t54, ptr %l32, !tbaa !24
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr %"compiler/build:compiles", ptr %t55, i32 0, i32 0
  %t59 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H2ab12f44ffbd18d099d1f5a69642975a(ptr %v1, ptr %t57)
  store i64 %t59, ptr %l35
  br label %bb5
bb5:
  %t60 = load i64, ptr %l32, !tbaa !24
  %t61 = load i64, ptr %l35, !tbaa !24
  %t62 = add i64 %t60, %t61
  %t64 = load ptr, ptr %l31, !tbaa !29
  %t65 = getelementptr %"compiler/build:Config", ptr %t64, i32 0, i32 36
  store i64 %t62, ptr %t65, !tbaa !24
  store i1 false, ptr %l6, !tbaa !21
  store i64 0, ptr %l7, !tbaa !24
  %t66 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t66, 0
  store i64 %t68, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t70 = load i64, ptr %l8, !tbaa !24
  %t71 = load i64, ptr %l7, !tbaa !24
  %t74 = icmp sgt i64 %t70, %t71
  br i1 %t74, label %bb6, label %bb7
bb6:
  %t76 = load i64, ptr %l9, !tbaa !24
  %t78 = icmp sgt i64 %t76, 0
  br i1 %t78, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb11
bb8:
  %t80 = load i64, ptr %l8, !tbaa !24
  %t81 = load i64, ptr %l7, !tbaa !24
  %t84 = sub i64 %t80, %t81
  %t85 = load i64, ptr %l9, !tbaa !24
  %t88 = add i64 %t84, %t85
  %t90 = sub i64 %t88, 1
  %t91 = load i64, ptr %l9, !tbaa !24
  %t94 = sdiv i64 %t90, %t91
  store i64 %t94, ptr %l45, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb10
bb10:
  %t96 = load i64, ptr %l45, !tbaa !24
  store i64 %t96, ptr %l42, !tbaa !24
  br label %bb11
bb11:
  %t97 = load i64, ptr %l42, !tbaa !24
  store i64 %t97, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t98 = load i64, ptr %l11, !tbaa !24
  %t99 = load i64, ptr %l10, !tbaa !24
  %t102 = icmp slt i64 %t98, %t99
  %t104 = xor i1 %t102, true
  br i1 %t104, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb101
bb14:
  br label %bb15
bb15:
  %t106 = load i64, ptr %l7, !tbaa !24
  %t107 = load i64, ptr %l11, !tbaa !24
  %t108 = load i64, ptr %l9, !tbaa !24
  %t111 = mul i64 %t107, %t108
  %t114 = add i64 %t106, %t111
  store i64 %t114, ptr %l12, !tbaa !24
  %t116 = load ptr, ptr %l1, !tbaa !29
  %t118 = getelementptr %"compiler/build:compiles", ptr %t116, i32 0, i32 4
  %t119 = load i64, ptr %l12, !tbaa !24
  %t122 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t118, i64 %t119)
  store { i64, ptr } %t122, ptr %l66
  br label %bb16
bb16:
  %t123 = load ptr, ptr %l1, !tbaa !29
  %t125 = getelementptr %"compiler/build:compiles", ptr %t123, i32 0, i32 3
  %t126 = load i64, ptr %l12, !tbaa !24
  %t129 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t125, i64 %t126)
  store { i64, ptr } %t129, ptr %l70
  br label %bb17
bb17:
  %t130 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t131 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t132 = call i32 @std_2fos_2eRename(ptr %v1, ptr %v1, { i64, ptr } %t130, { i64, ptr } %t131)
  store i32 %t132, ptr %l71
  %t133 = icmp ne i32 %t132, 0
  br i1 %t133, label %bb19, label %ok.134, !prof !99
ok.134:
  br label %bb18
bb18:
  br label %bb23
bb19:
  %t135 = load i32, ptr %l71, !tbaa !23
  %t136 = ashr i32 %t135, 16
  %t138 = icmp eq i32 %t136, 1
  store i1 %t138, ptr %l73, !tbaa !21
  %t139 = load i32, ptr %l71, !tbaa !23
  %t140 = ashr i32 %t139, 16
  %t142 = icmp eq i32 %t140, 1
  br i1 %t142, label %bb20, label %bb21
bb20:
  call void @__olang_errpay_pop()
  br label %bb21
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t144 = load i64, ptr %l12, !tbaa !24
  %t146 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr i32, ptr %t147, i64 %t144
  %t149 = load i32, ptr %t148, !tbaa !33
  %t151 = icmp ne i32 %t149, 0
  br i1 %t151, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s4
  %t153 = load i64, ptr %l12, !tbaa !24
  %t155 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !27
  %t157 = getelementptr { i64, ptr }, ptr %t156, i64 %t153
  %t158 = load { i64, ptr }, ptr %t157, !tbaa !37
  call void @compiler_2fbuild_2esayErr(ptr %s0, { i64, ptr } %t158)
  br label %bb26
bb25:
  br label %bb52
bb26:
  %t160 = load i1, ptr %l6, !tbaa !21
  %t162 = xor i1 %t160, true
  br i1 %t162, label %bb27, label %bb28
bb27:
  %t164 = load ptr, ptr %l2, !tbaa !29
  store ptr %t164, ptr %l83, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t165
  %t166 = getelementptr { i64, [3 x i64] }, ptr %t165, i32 0, i32 0
  store i64 0, ptr %t166
  %t167 = load { i64, [3 x i64] }, ptr %t165
  store { i64, [3 x i64] } %t167, ptr %l84
  %t168 = load ptr, ptr %l1, !tbaa !29
  %t170 = getelementptr %"compiler/build:compiles", ptr %t168, i32 0, i32 3
  %t171 = load i64, ptr %l12, !tbaa !24
  %t174 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t170, i64 %t171)
  store { i64, ptr } %t174, ptr %l88
  br label %bb29
bb28:
  br label %bb32
bb29:
  %t175 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t176 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eClangFailed(ptr %v1, ptr %v2, { i64, ptr } %t175)
  store %"compiler/diagmsg:Msg" %t176, ptr %l89
  br label %bb30
bb30:
  %t177 = load ptr, ptr %l83, !tbaa !29
  %t178 = load { i64, [3 x i64] }, ptr %l84
  %t179 = load %"compiler/diagmsg:Msg", ptr %l89
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v2, ptr %v2, ptr %t177, { i64, [3 x i64] } %t178, %"compiler/diagmsg:Msg" %t179)
  br label %bb31
bb31:
  br label %bb32
bb32:
  store i1 true, ptr %l6, !tbaa !21
  %t180 = load ptr, ptr %l1, !tbaa !29
  %t182 = getelementptr %"compiler/build:compiles", ptr %t180, i32 0, i32 1
  %t183 = load i64, ptr %l12, !tbaa !24
  %t186 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t182, i64 %t183)
  store { i64, ptr } %t186, ptr %l93
  br label %bb33
bb33:
  %t187 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t188 = call i32 @std_2fos_2eRemove(ptr %v1, { i64, ptr } %t187)
  store i32 %t188, ptr %l94
  %t189 = icmp ne i32 %t188, 0
  br i1 %t189, label %bb35, label %ok.190, !prof !99
ok.190:
  br label %bb34
bb34:
  br label %bb39
bb35:
  %t191 = load i32, ptr %l94, !tbaa !23
  %t192 = ashr i32 %t191, 16
  %t194 = icmp eq i32 %t192, 1
  store i1 %t194, ptr %l96, !tbaa !21
  %t195 = load i32, ptr %l94, !tbaa !23
  %t196 = ashr i32 %t195, 16
  %t198 = icmp eq i32 %t196, 1
  br i1 %t198, label %bb36, label %bb37
bb36:
  call void @__olang_errpay_pop()
  br label %bb37
bb37:
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t200 = load ptr, ptr %l1, !tbaa !29
  %t202 = getelementptr %"compiler/build:compiles", ptr %t200, i32 0, i32 5
  %t203 = load i64, ptr %l12, !tbaa !24
  %t206 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t202, i64 %t203)
  store { i64, ptr } %t206, ptr %l102
  br label %bb40
bb40:
  %t207 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t208 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s4, { i64, ptr } %t207, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d140, i32 0, i32 1) })
  store i1 %t208, ptr %l103
  br label %bb41
bb41:
  %t209 = load i1, ptr %l103, !tbaa !21
  %t210 = xor i1 %t209, true
  br i1 %t210, label %bb42, label %bb43
bb42:
  %t212 = load ptr, ptr %l1, !tbaa !29
  %t214 = getelementptr %"compiler/build:compiles", ptr %t212, i32 0, i32 5
  %t215 = load i64, ptr %l12, !tbaa !24
  %t218 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t214, i64 %t215)
  store { i64, ptr } %t218, ptr %l108
  br label %bb44
bb43:
  br label %bb51
bb44:
  %t219 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t220 = call i32 @std_2fos_2eRemove(ptr %v1, { i64, ptr } %t219)
  store i32 %t220, ptr %l109
  %t221 = icmp ne i32 %t220, 0
  br i1 %t221, label %bb46, label %ok.222, !prof !99
ok.222:
  br label %bb45
bb45:
  br label %bb50
bb46:
  %t223 = load i32, ptr %l109, !tbaa !23
  %t224 = ashr i32 %t223, 16
  %t226 = icmp eq i32 %t224, 1
  store i1 %t226, ptr %l111, !tbaa !21
  %t227 = load i32, ptr %l109, !tbaa !23
  %t228 = ashr i32 %t227, 16
  %t230 = icmp eq i32 %t228, 1
  br i1 %t230, label %bb47, label %bb48
bb47:
  call void @__olang_errpay_pop()
  br label %bb48
bb48:
  br label %bb49
bb49:
  br label %bb50
bb50:
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  br label %bb100
bb52:
  %t232 = load i64, ptr %l12, !tbaa !24
  %t234 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !27
  %t236 = getelementptr { i64, ptr }, ptr %t235, i64 %t232
  %t237 = load { i64, ptr }, ptr %t236, !tbaa !37
  %t239 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s2, { i64, ptr } %t237, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d141, i32 0, i32 1) })
  store i1 %t239, ptr %l116
  br label %bb53
bb53:
  %t240 = load i1, ptr %l116, !tbaa !21
  %t241 = xor i1 %t240, true
  br i1 %t241, label %bb54, label %bb55
bb54:
  %t243 = load i64, ptr %l12, !tbaa !24
  %t245 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t246 = load ptr, ptr %t245, !tbaa !27
  %t247 = getelementptr { i64, ptr }, ptr %t246, i64 %t243
  %t248 = load { i64, ptr }, ptr %t247, !tbaa !37
  call void @compiler_2fbuild_2esayErr(ptr %s0, { i64, ptr } %t248)
  br label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb57
bb57:
  %t250 = load ptr, ptr %l1, !tbaa !29
  %t252 = getelementptr %"compiler/build:compiles", ptr %t250, i32 0, i32 5
  %t253 = load i64, ptr %l12, !tbaa !24
  %t256 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t252, i64 %t253)
  store { i64, ptr } %t256, ptr %l123
  br label %bb58
bb58:
  %t257 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t258 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s2, { i64, ptr } %t257, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d142, i32 0, i32 1) })
  store i1 %t258, ptr %l124
  br label %bb59
bb59:
  %t259 = load i1, ptr %l124, !tbaa !21
  %t260 = xor i1 %t259, true
  br i1 %t260, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s10
  %t262 = load ptr, ptr %l1, !tbaa !29
  %t264 = getelementptr %"compiler/build:compiles", ptr %t262, i32 0, i32 5
  %t265 = load i64, ptr %l12, !tbaa !24
  %t268 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t264, i64 %t265)
  store { i64, ptr } %t268, ptr %l129
  br label %bb62
bb61:
  br label %bb83
bb62:
  %t269 = load ptr, ptr %l1, !tbaa !29
  %t271 = getelementptr %"compiler/build:compiles", ptr %t269, i32 0, i32 2
  %t272 = load i64, ptr %l12, !tbaa !24
  %t275 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t271, i64 %t272)
  store { i64, ptr } %t275, ptr %l133
  br label %bb63
bb63:
  %t276 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t277 = call { i64, ptr } @compiler_2fbuild_2eRemarksOf(ptr %v1, ptr %s10, { i64, ptr } %t276)
  store { i64, ptr } %t277, ptr %l134
  br label %bb64
bb64:
  %t278 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t279 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t281 = call i32 @std_2fos_2eRename(ptr %v1, ptr %s10, { i64, ptr } %t279, { i64, ptr } %t278)
  store i32 %t281, ptr %l136
  %t282 = icmp ne i32 %t281, 0
  br i1 %t282, label %bb66, label %ok.283, !prof !99
ok.283:
  br label %bb65
bb65:
  br label %bb79
bb66:
  %t284 = load i32, ptr %l136, !tbaa !23
  %t285 = ashr i32 %t284, 16
  %t287 = icmp eq i32 %t285, 1
  store i1 %t287, ptr %l138, !tbaa !21
  %t288 = load i32, ptr %l136, !tbaa !23
  %t289 = ashr i32 %t288, 16
  %t291 = icmp eq i32 %t289, 1
  br i1 %t291, label %bb67, label %bb68
bb67:
  call void @__olang_errpay_pop()
  br label %bb68
bb68:
  br label %bb69
bb69:
  %t293 = load i1, ptr %l6, !tbaa !21
  %t295 = xor i1 %t293, true
  br i1 %t295, label %bb70, label %bb71
bb70:
  %t297 = call ptr @__olang_scope_hold(ptr %v2)
  %t298 = ptrtoint ptr %t297 to i64
  store i64 %t298, ptr %l143, !tbaa !24
  %t299 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t299, label %bb72, label %bb73
bb71:
  br label %bb78
bb72:
  %t301 = call ptr @__olang_region_make(ptr %v2)
  %t302 = ptrtoint ptr %t301 to i64
  store i64 %t302, ptr %l143, !tbaa !24
  br label %bb73
bb73:
  %t303 = load ptr, ptr %l1, !tbaa !29
  %t305 = getelementptr %"compiler/build:compiles", ptr %t303, i32 0, i32 2
  %t306 = load i64, ptr %l12, !tbaa !24
  %t309 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t305, i64 %t306)
  store { i64, ptr } %t309, ptr %l148
  br label %bb74
bb74:
  %t310 = load i64, ptr %l143
  %t311 = inttoptr i64 %t310 to ptr
  %t312 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t313 = call { i64, ptr } @compiler_2fbuild_2eRemarksOf(ptr %v1, ptr %t311, { i64, ptr } %t312)
  store { i64, ptr } %t313, ptr %l149
  br label %bb75
bb75:
  %t314 = load { i64, ptr }, ptr %l149, !tbaa !27
  store { i64, ptr } %t314, ptr %l150, !tbaa !27
  %t315 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %v2)
  store %"compiler/diagmsg:Msg" %t315, ptr %l151
  br label %bb76
bb76:
  %t316 = load ptr, ptr %l2, !tbaa !29
  %t317 = load { i64, ptr }, ptr %l150, !tbaa !27
  %t318 = load %"compiler/diagmsg:Msg", ptr %l151
  call void @compiler_2fbuild_2efileFatal(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t317, %"compiler/diagmsg:Msg" %t318, ptr %t316)
  br label %bb77
bb77:
  br label %bb78
bb78:
  store i1 true, ptr %l6, !tbaa !21
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s2)
  br label %bb100
bb79:
  %t320 = load ptr, ptr %l0, !tbaa !29
  store ptr %t320, ptr %l153, !tbaa !29
  %t321 = load ptr, ptr %l1, !tbaa !29
  %t323 = getelementptr %"compiler/build:compiles", ptr %t321, i32 0, i32 2
  %t324 = load i64, ptr %l12, !tbaa !24
  %t327 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t323, i64 %t324)
  store { i64, ptr } %t327, ptr %l157
  br label %bb80
bb80:
  %t328 = load { i64, ptr }, ptr %l157, !tbaa !27
  %t329 = call { i64, ptr } @compiler_2fbuild_2eRemarksOf(ptr %v1, ptr %s10, { i64, ptr } %t328)
  store { i64, ptr } %t329, ptr %l158
  br label %bb81
bb81:
  %t330 = load { i64, ptr }, ptr %l158, !tbaa !27
  %t331 = load ptr, ptr %l153, !tbaa !29
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ekeep(ptr %v0, ptr %s10, ptr %t331, { i64, ptr } %t330)
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s10)
  br label %bb83
bb83:
  %t333 = load ptr, ptr %l1, !tbaa !29
  %t335 = getelementptr %"compiler/build:compiles", ptr %t333, i32 0, i32 1
  %t336 = load i64, ptr %l12, !tbaa !24
  %t339 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t335, i64 %t336)
  store { i64, ptr } %t339, ptr %l163
  br label %bb84
bb84:
  %t340 = load ptr, ptr %l1, !tbaa !29
  %t342 = getelementptr %"compiler/build:compiles", ptr %t340, i32 0, i32 2
  %t343 = load i64, ptr %l12, !tbaa !24
  %t346 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t342, i64 %t343)
  store { i64, ptr } %t346, ptr %l167
  br label %bb85
bb85:
  %t347 = load { i64, ptr }, ptr %l163, !tbaa !27
  %t348 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t349 = call i32 @std_2fos_2eRename(ptr %v1, ptr %v1, { i64, ptr } %t347, { i64, ptr } %t348)
  store i32 %t349, ptr %l168
  %t350 = icmp ne i32 %t349, 0
  br i1 %t350, label %bb87, label %ok.351, !prof !99
ok.351:
  br label %bb86
bb86:
  br label %bb97
bb87:
  %t352 = load i32, ptr %l168, !tbaa !23
  %t353 = ashr i32 %t352, 16
  %t355 = icmp eq i32 %t353, 1
  store i1 %t355, ptr %l170, !tbaa !21
  %t356 = load i32, ptr %l168, !tbaa !23
  %t357 = ashr i32 %t356, 16
  %t359 = icmp eq i32 %t357, 1
  br i1 %t359, label %bb88, label %bb89
bb88:
  call void @__olang_errpay_pop()
  br label %bb89
bb89:
  br label %bb90
bb90:
  %t361 = load i1, ptr %l6, !tbaa !21
  %t363 = xor i1 %t361, true
  br i1 %t363, label %bb91, label %bb92
bb91:
  %t365 = load ptr, ptr %l1, !tbaa !29
  %t367 = getelementptr %"compiler/build:compiles", ptr %t365, i32 0, i32 2
  %t368 = load i64, ptr %l12, !tbaa !24
  %t371 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t367, i64 %t368)
  store { i64, ptr } %t371, ptr %l178
  br label %bb93
bb92:
  br label %bb96
bb93:
  %t372 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %v2)
  store %"compiler/diagmsg:Msg" %t372, ptr %l179
  br label %bb94
bb94:
  %t373 = load ptr, ptr %l2, !tbaa !29
  %t374 = load { i64, ptr }, ptr %l178, !tbaa !27
  %t375 = load %"compiler/diagmsg:Msg", ptr %l179
  call void @compiler_2fbuild_2efileFatal(ptr %v1, ptr %v2, ptr %v2, { i64, ptr } %t374, %"compiler/diagmsg:Msg" %t375, ptr %t373)
  br label %bb95
bb95:
  br label %bb96
bb96:
  store i1 true, ptr %l6, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  br label %bb100
bb97:
  %t377 = load ptr, ptr %l0, !tbaa !29
  store ptr %t377, ptr %l181, !tbaa !29
  %t378 = load ptr, ptr %l1, !tbaa !29
  %t380 = getelementptr %"compiler/build:compiles", ptr %t378, i32 0, i32 2
  %t381 = load i64, ptr %l12, !tbaa !24
  %t384 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t380, i64 %t381)
  store { i64, ptr } %t384, ptr %l185
  br label %bb98
bb98:
  %t385 = load ptr, ptr %l181, !tbaa !29
  %t386 = load { i64, ptr }, ptr %l185, !tbaa !27
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ekeep(ptr %v0, ptr %v1, ptr %t385, { i64, ptr } %t386)
  br label %bb99
bb99:
  call void @__olang_scope_close(ptr %s2)
  br label %bb100
bb100:
  %t387 = load i64, ptr %l11, !tbaa !24
  %t390 = add i64 %t387, 1
  store i64 %t390, ptr %l11, !tbaa !24
  br label %bb12
bb101:
  %t392 = load ptr, ptr %l1, !tbaa !29
  %t394 = getelementptr %"compiler/build:compiles", ptr %t392, i32 0, i32 7
  store ptr %t394, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb102
bb102:
  %t396 = load i64, ptr %l14, !tbaa !24
  store i64 %t396, ptr %l191, !tbaa !24
  %t397 = load ptr, ptr %l13, !tbaa !29
  %t399 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v1, ptr %t397)
  store i64 %t399, ptr %l193
  br label %bb103
bb103:
  %t400 = load i64, ptr %l191, !tbaa !24
  %t401 = load i64, ptr %l193, !tbaa !24
  %t402 = icmp slt i64 %t400, %t401
  %t404 = xor i1 %t402, true
  br i1 %t404, label %bb104, label %bb105
bb104:
  br label %bb115
bb105:
  br label %bb106
bb106:
  %t406 = load ptr, ptr %l13, !tbaa !29
  %t407 = load i64, ptr %l14, !tbaa !24
  %t410 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t406, i64 %t407)
  store { i64, ptr } %t410, ptr %l198
  br label %bb107
bb107:
  %t411 = load { i64, ptr }, ptr %l198, !tbaa !27
  %t414 = call i32 @std_2fos_2eRemoveAll(ptr %v1, { i64, ptr } %t411)
  store i32 %t414, ptr %l200
  %t415 = icmp ne i32 %t414, 0
  br i1 %t415, label %bb109, label %ok.416, !prof !99
ok.416:
  br label %bb108
bb108:
  br label %bb113
bb109:
  %t417 = load i32, ptr %l200, !tbaa !23
  %t418 = ashr i32 %t417, 16
  %t420 = icmp eq i32 %t418, 1
  store i1 %t420, ptr %l202, !tbaa !21
  %t421 = load i32, ptr %l200, !tbaa !23
  %t422 = ashr i32 %t421, 16
  %t424 = icmp eq i32 %t422, 1
  br i1 %t424, label %bb110, label %bb111
bb110:
  call void @__olang_errpay_pop()
  br label %bb111
bb111:
  br label %bb112
bb112:
  br label %bb113
bb113:
  br label %bb114
bb114:
  %t426 = load i64, ptr %l14, !tbaa !24
  %t429 = add i64 %t426, 1
  store i64 %t429, ptr %l14, !tbaa !24
  br label %bb102
bb115:
  %t431 = load i1, ptr %l6, !tbaa !21
  br i1 %t431, label %bb116, label %bb117
bb116:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb117:
  br label %bb118
bb118:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2efuzzRun(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"std/os:Output"
  %l7 = alloca ptr
  %l8 = alloca i64
  %l21 = alloca { i64, ptr }
  %l23 = alloca %"std/os:Output"
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca %"std/os:Output"
  %l28 = alloca i32
  %l30 = alloca i1
  %l41 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 17
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp sgt i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l1, !tbaa !29
  store ptr %t8, ptr %l7, !tbaa !29
  %t9 = call ptr @__olang_scope_hold(ptr %v1)
  %t10 = ptrtoint ptr %t9 to i64
  store i64 %t10, ptr %l8, !tbaa !24
  %t11 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t11, label %bb3, label %bb4
bb2:
  br label %bb6
bb3:
  %t13 = call ptr @__olang_region_make(ptr %v1)
  %t14 = ptrtoint ptr %t13 to i64
  store i64 %t14, ptr %l8, !tbaa !24
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/build:Config", ptr %t15, i32 0, i32 17
  %t18 = load i64, ptr %t17, !tbaa !24
  %t19 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d143, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d143, i32 0, i32 1) }, 0
  %t22 = call i64 @__olang_fmt_i64(ptr null, i64 %t18)
  %t23 = add i64 %t20, %t22
  %t24 = load i64, ptr %l8
  %t25 = inttoptr i64 %t24 to ptr
  %t26 = call ptr @__olang_held_alloc(ptr %t25, i64 %t23)
  call void @olang_textcopy(ptr %t26, ptr %t19, i64 %t20)
  %t27 = getelementptr i8, ptr %t26, i64 %t20
  %t28 = call i64 @__olang_fmt_i64(ptr %t27, i64 %t18)
  %t29 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t26, 1
  %t32 = load ptr, ptr %l7, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t32, { i64, ptr } %t30)
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/build:Config", ptr %t35, i32 0, i32 16
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  %t39 = load ptr, ptr %l2, !tbaa !29
  %t41 = getelementptr %"compiler/build:Program", ptr %t39, i32 0, i32 6
  %t42 = load { i64, ptr }, ptr %t41, !tbaa !27
  %t43 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d144, i32 0, i32 1) }, 1
  %t44 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d144, i32 0, i32 1) }, 0
  %t46 = extractvalue { i64, ptr } %t38, 1
  %t47 = extractvalue { i64, ptr } %t38, 0
  %t48 = add i64 %t44, %t47
  %t49 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d145, i32 0, i32 1) }, 1
  %t50 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d145, i32 0, i32 1) }, 0
  %t51 = add i64 %t48, %t50
  %t53 = extractvalue { i64, ptr } %t42, 1
  %t54 = extractvalue { i64, ptr } %t42, 0
  %t55 = add i64 %t51, %t54
  %t56 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d146, i32 0, i32 1) }, 1
  %t57 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d146, i32 0, i32 1) }, 0
  %t58 = add i64 %t55, %t57
  %t59 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t58)
  call void @olang_textcopy(ptr %t59, ptr %t43, i64 %t44)
  %t60 = getelementptr i8, ptr %t59, i64 %t44
  call void @olang_textcopy(ptr %t60, ptr %t46, i64 %t47)
  %t61 = getelementptr i8, ptr %t60, i64 %t47
  call void @olang_textcopy(ptr %t61, ptr %t49, i64 %t50)
  %t62 = getelementptr i8, ptr %t61, i64 %t50
  call void @olang_textcopy(ptr %t62, ptr %t53, i64 %t54)
  %t63 = getelementptr i8, ptr %t62, i64 %t54
  call void @olang_textcopy(ptr %t63, ptr %t56, i64 %t57)
  %t64 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t59, 1
  %t69 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t34, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d147, i32 0, i32 1) }, { i64, ptr } %t65)
  store { i64, ptr } %t69, ptr %l21
  br label %bb7
bb7:
  %t70 = load { i64, ptr }, ptr %l21, !tbaa !27
  call void @compiler_2fbuild_2esayln(ptr %s0, { i64, ptr } %t70)
  br label %bb8
bb8:
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t74 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v1, ptr %v1, ptr %t72)
  store { i64, ptr } %t74, ptr %l25
  br label %bb9
bb9:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %l26, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t77 = call { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExec(ptr %v1, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t75, { i64, ptr } %t76, i1 false, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d39, i32 0, i32 1) })
  %t78 = extractvalue { i32, %"std/os:Output" } %t77, 1
  %t79 = extractvalue { i32, %"std/os:Output" } %t77, 0
  store i32 %t79, ptr %l28
  %t80 = icmp ne i32 %t79, 0
  br i1 %t80, label %bb11, label %ok.81, !prof !99
ok.81:
  store %"std/os:Output" %t78, ptr %l27
  br label %bb10
bb10:
  %t82 = load %"std/os:Output", ptr %l27
  store %"std/os:Output" %t82, ptr %l23
  br label %bb15
bb11:
  %t83 = load i32, ptr %l28, !tbaa !23
  %t84 = ashr i32 %t83, 16
  %t86 = icmp eq i32 %t84, 1
  store i1 %t86, ptr %l30, !tbaa !21
  %t87 = load i32, ptr %l28, !tbaa !23
  %t88 = ashr i32 %t87, 16
  %t90 = icmp eq i32 %t88, 1
  br i1 %t90, label %bb12, label %bb13
bb12:
  call void @__olang_errpay_pop()
  br label %bb13
bb13:
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb15:
  %t93 = load %"std/os:Output", ptr %l23
  store %"std/os:Output" %t93, ptr %l3
  %t94 = getelementptr %"std/os:Output", ptr %l3, i32 0, i32 0
  %t95 = load i32, ptr %t94, !tbaa !23
  %t97 = icmp eq i32 %t95, 0
  br i1 %t97, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s5
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/build:Config", ptr %t100, i32 0, i32 16
  %t103 = load { i64, ptr }, ptr %t102, !tbaa !27
  %t104 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d148, i32 0, i32 1) }, 1
  %t105 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d148, i32 0, i32 1) }, 0
  %t107 = extractvalue { i64, ptr } %t103, 1
  %t108 = extractvalue { i64, ptr } %t103, 0
  %t109 = add i64 %t105, %t108
  %t110 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d149, i32 0, i32 1) }, 1
  %t111 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d149, i32 0, i32 1) }, 0
  %t112 = add i64 %t109, %t111
  %t113 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t112)
  call void @olang_textcopy(ptr %t113, ptr %t104, i64 %t105)
  %t114 = getelementptr i8, ptr %t113, i64 %t105
  call void @olang_textcopy(ptr %t114, ptr %t107, i64 %t108)
  %t115 = getelementptr i8, ptr %t114, i64 %t108
  call void @olang_textcopy(ptr %t115, ptr %t110, i64 %t111)
  %t116 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t113, 1
  %t121 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %s5, ptr %s5, ptr %s5, ptr %t99, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d150, i32 0, i32 1) }, { i64, ptr } %t117)
  store { i64, ptr } %t121, ptr %l41
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t122 = load { i64, ptr }, ptr %l41, !tbaa !27
  call void @compiler_2fbuild_2esayln(ptr %s5, { i64, ptr } %t122)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb20:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/build:Config", ptr %t126, i32 0, i32 16
  %t129 = load { i64, ptr }, ptr %t128, !tbaa !27
  %t130 = load ptr, ptr %l2, !tbaa !29
  %t132 = getelementptr %"compiler/build:Program", ptr %t130, i32 0, i32 6
  %t133 = load { i64, ptr }, ptr %t132, !tbaa !27
  %t134 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d151, i32 0, i32 1) }, 1
  %t135 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d151, i32 0, i32 1) }, 0
  %t137 = extractvalue { i64, ptr } %t129, 1
  %t138 = extractvalue { i64, ptr } %t129, 0
  %t139 = add i64 %t135, %t138
  %t140 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d152, i32 0, i32 1) }, 1
  %t141 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d152, i32 0, i32 1) }, 0
  %t142 = add i64 %t139, %t141
  %t144 = extractvalue { i64, ptr } %t133, 1
  %t145 = extractvalue { i64, ptr } %t133, 0
  %t146 = add i64 %t142, %t145
  %t147 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d153, i32 0, i32 1) }, 1
  %t148 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d153, i32 0, i32 1) }, 0
  %t149 = add i64 %t146, %t148
  %t150 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t149)
  call void @olang_textcopy(ptr %t150, ptr %t134, i64 %t135)
  %t151 = getelementptr i8, ptr %t150, i64 %t135
  call void @olang_textcopy(ptr %t151, ptr %t137, i64 %t138)
  %t152 = getelementptr i8, ptr %t151, i64 %t138
  call void @olang_textcopy(ptr %t152, ptr %t140, i64 %t141)
  %t153 = getelementptr i8, ptr %t152, i64 %t141
  call void @olang_textcopy(ptr %t153, ptr %t144, i64 %t145)
  %t154 = getelementptr i8, ptr %t153, i64 %t145
  call void @olang_textcopy(ptr %t154, ptr %t147, i64 %t148)
  %t155 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t150, 1
  %t160 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t125, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d154, i32 0, i32 1) }, { i64, ptr } %t156)
  store { i64, ptr } %t160, ptr %l51
  br label %bb21
bb21:
  %t161 = load { i64, ptr }, ptr %l51, !tbaa !27
  call void @compiler_2fbuild_2esayln(ptr %s0, { i64, ptr } %t161)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ekeep(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l6 = alloca i1
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l13 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l24 = alloca i1
  %l27 = alloca i32
  %l29 = alloca i1
  %l32 = alloca { i64, ptr }
  %l33 = alloca i32
  %l37 = alloca i32
  %l39 = alloca i1
  %l44 = alloca i32
  %l46 = alloca i1
  %l50 = alloca i32
  %l52 = alloca i1
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 40
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t4, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d155, i32 0, i32 1) })
  store i1 %t6, ptr %l6
  br label %bb1
bb1:
  %t7 = load i1, ptr %l6, !tbaa !21
  br i1 %t7, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/build:Config", ptr %t8, i32 0, i32 40
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  store { i64, ptr } %t11, ptr %l8, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t12, ptr %l9, !tbaa !27
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/build:Config", ptr %t13, i32 0, i32 0
  %t16 = load { i64, ptr }, ptr %t15, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  %t20 = add i64 %t18, 1
  store i64 %t20, ptr %l13, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t21, 0
  store i64 %t24, ptr %l16, !tbaa !24
  %t25 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t25, 0
  store i64 %t26, ptr %l17, !tbaa !24
  %t27 = load i64, ptr %l13, !tbaa !24
  %t28 = icmp sge i64 %t27, 0
  br i1 %t28, label %bb5, label %bb6
bb5:
  %t30 = load i64, ptr %l13, !tbaa !24
  %t31 = load i64, ptr %l16, !tbaa !24
  %t32 = icmp sle i64 %t30, %t31
  br i1 %t32, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_3ba7d2bc4f70132e_88e22ea564bfc3e2)
  unreachable
bb7:
  %t34 = load i64, ptr %l16, !tbaa !24
  %t35 = load i64, ptr %l17, !tbaa !24
  %t36 = icmp sle i64 %t34, %t35
  br i1 %t36, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_3ba7d2bc4f70132e_88e22ea564bfc3e2)
  unreachable
bb9:
  %t38 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = load i64, ptr %l13, !tbaa !24
  %t41 = load i64, ptr %l16, !tbaa !24
  %t42 = getelementptr i8, ptr %t39, i64 %t40
  %t43 = sub i64 %t41, %t40
  %t44 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t42, 1
  %t46 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 1
  %t48 = extractvalue { i64, ptr } %t46, 0
  %t49 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d156, i32 0, i32 1) }, 1
  %t50 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d156, i32 0, i32 1) }, 0
  %t51 = add i64 %t48, %t50
  %t53 = extractvalue { i64, ptr } %t45, 1
  %t54 = extractvalue { i64, ptr } %t45, 0
  %t55 = add i64 %t51, %t54
  %t56 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t55)
  call void @olang_textcopy(ptr %t56, ptr %t47, i64 %t48)
  %t57 = getelementptr i8, ptr %t56, i64 %t48
  call void @olang_textcopy(ptr %t57, ptr %t49, i64 %t50)
  %t58 = getelementptr i8, ptr %t57, i64 %t50
  call void @olang_textcopy(ptr %t58, ptr %t53, i64 %t54)
  %t59 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t56, 1
  store { i64, ptr } %t60, ptr %l2, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t64 = call i1 @std_2fos_2eExists(ptr %s0, { i64, ptr } %t62)
  store i1 %t64, ptr %l24
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_3ba7d2bc4f70132e_88e22ea564bfc3e2)
  unreachable
bb11:
  %t65 = load i1, ptr %l24, !tbaa !21
  br i1 %t65, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb13:
  br label %bb14
bb14:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/build:Config", ptr %t66, i32 0, i32 40
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  %t71 = call i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %t69)
  store i32 %t71, ptr %l27
  %t72 = icmp ne i32 %t71, 0
  br i1 %t72, label %bb16, label %ok.73, !prof !99
ok.73:
  br label %bb15
bb15:
  br label %bb20
bb16:
  %t74 = load i32, ptr %l27, !tbaa !23
  %t75 = ashr i32 %t74, 16
  %t77 = icmp eq i32 %t75, 1
  store i1 %t77, ptr %l29, !tbaa !21
  %t78 = load i32, ptr %l27, !tbaa !23
  %t79 = ashr i32 %t78, 16
  %t81 = icmp eq i32 %t79, 1
  br i1 %t81, label %bb17, label %bb18
bb17:
  call void @__olang_errpay_pop()
  br label %bb18
bb18:
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb20:
  %t83 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t83, ptr %l32, !tbaa !27
  %t84 = call i32 @getpid()
  store i32 %t84, ptr %l33
  br label %bb21
bb21:
  %t85 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 1
  %t87 = extractvalue { i64, ptr } %t85, 0
  %t88 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d157, i32 0, i32 1) }, 1
  %t89 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d157, i32 0, i32 1) }, 0
  %t90 = add i64 %t87, %t89
  %t91 = load i32, ptr %l33, !tbaa !23
  %t92 = sext i32 %t91 to i64
  %t93 = call i64 @__olang_fmt_i64(ptr null, i64 %t92)
  %t94 = add i64 %t90, %t93
  %t95 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d158, i32 0, i32 1) }, 1
  %t96 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d158, i32 0, i32 1) }, 0
  %t97 = add i64 %t94, %t96
  %t98 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t97)
  call void @olang_textcopy(ptr %t98, ptr %t86, i64 %t87)
  %t99 = getelementptr i8, ptr %t98, i64 %t87
  call void @olang_textcopy(ptr %t99, ptr %t88, i64 %t89)
  %t100 = getelementptr i8, ptr %t99, i64 %t89
  %t101 = call i64 @__olang_fmt_i64(ptr %t100, i64 %t92)
  %t102 = getelementptr i8, ptr %t100, i64 %t93
  call void @olang_textcopy(ptr %t102, ptr %t95, i64 %t96)
  %t103 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t98, 1
  store { i64, ptr } %t104, ptr %l3, !tbaa !27
  %t106 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t107 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t110 = call i32 @std_2fos_2eLink(ptr %v1, ptr %s0, { i64, ptr } %t106, { i64, ptr } %t107)
  store i32 %t110, ptr %l37
  %t111 = icmp ne i32 %t110, 0
  br i1 %t111, label %bb23, label %ok.112, !prof !99
ok.112:
  br label %bb22
bb22:
  br label %bb27
bb23:
  %t113 = load i32, ptr %l37, !tbaa !23
  %t114 = ashr i32 %t113, 16
  %t116 = icmp eq i32 %t114, 1
  store i1 %t116, ptr %l39, !tbaa !21
  %t117 = load i32, ptr %l37, !tbaa !23
  %t118 = ashr i32 %t117, 16
  %t120 = icmp eq i32 %t118, 1
  br i1 %t120, label %bb24, label %bb25
bb24:
  call void @__olang_errpay_pop()
  br label %bb25
bb25:
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb27:
  %t122 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t123 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t126 = call i32 @std_2fos_2eRename(ptr %s0, ptr %s0, { i64, ptr } %t122, { i64, ptr } %t123)
  store i32 %t126, ptr %l44
  %t127 = icmp ne i32 %t126, 0
  br i1 %t127, label %bb29, label %ok.128, !prof !99
ok.128:
  br label %bb28
bb28:
  br label %bb39
bb29:
  %t129 = load i32, ptr %l44, !tbaa !23
  %t130 = ashr i32 %t129, 16
  %t132 = icmp eq i32 %t130, 1
  store i1 %t132, ptr %l46, !tbaa !21
  %t133 = load i32, ptr %l44, !tbaa !23
  %t134 = ashr i32 %t133, 16
  %t136 = icmp eq i32 %t134, 1
  br i1 %t136, label %bb30, label %bb31
bb30:
  call void @__olang_errpay_pop()
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t138 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t140 = call i32 @std_2fos_2eRemove(ptr %s0, { i64, ptr } %t138)
  store i32 %t140, ptr %l50
  %t141 = icmp ne i32 %t140, 0
  br i1 %t141, label %bb34, label %ok.142, !prof !99
ok.142:
  br label %bb33
bb33:
  br label %bb38
bb34:
  %t143 = load i32, ptr %l50, !tbaa !23
  %t144 = ashr i32 %t143, 16
  %t146 = icmp eq i32 %t144, 1
  store i1 %t146, ptr %l52, !tbaa !21
  %t147 = load i32, ptr %l50, !tbaa !23
  %t148 = ashr i32 %t147, 16
  %t150 = icmp eq i32 %t148, 1
  br i1 %t150, label %bb35, label %bb36
bb35:
  call void @__olang_errpay_pop()
  br label %bb36
bb36:
  br label %bb37
bb37:
  br label %bb38
bb38:
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2elibrary(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %lp6 = alloca ptr
  %l7 = alloca [2 x { i64, ptr }]
  %lp8 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l13 = alloca i1
  %l15 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l41 = alloca { i64, ptr }
  %l42 = alloca ptr
  %l43 = alloca ptr
  %l44 = alloca { i64, ptr }
  %l47 = alloca i1
  %l53 = alloca i32
  %l55 = alloca i1
  %l56 = alloca ptr
  %l57 = alloca { i64, [3 x i64] }
  %l59 = alloca %"compiler/diagmsg:Msg"
  %l61 = alloca i32
  %l66 = alloca i32
  %l68 = alloca i1
  %l71 = alloca { i64, ptr }
  %l72 = alloca %"compiler/diagmsg:Msg"
  %l75 = alloca i32
  %l76 = alloca ptr
  %l78 = alloca { i64, ptr }
  %l83 = alloca ptr
  %l85 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca i32
  %t143 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i64, ptr } @compiler_2fbuild_2eLibName(ptr %v3, ptr %s0, { i64, ptr } %a3)
  store { i64, ptr } %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t4, ptr %l5, !tbaa !27
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/build:Config", ptr %t5, i32 0, i32 34
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t8, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d159, i32 0, i32 1) })
  store i1 %t10, ptr %l13
  br label %bb2
bb2:
  %t11 = load i1, ptr %l13, !tbaa !21
  %t12 = xor i1 %t11, true
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/build:Config", ptr %t14, i32 0, i32 34
  %t17 = load { i64, ptr }, ptr %t16, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 1
  %t20 = extractvalue { i64, ptr } %t17, 0
  %t21 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t20)
  call void @olang_textcopy(ptr %t21, ptr %t19, i64 %t20)
  %t22 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l15, !tbaa !27
  br label %bb7
bb4:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/build:Config", ptr %t25, i32 0, i32 0
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  store { i64, ptr } %t28, ptr %l20, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t29, ptr %l21, !tbaa !27
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v0, ptr %s0, ptr %t30)
  store { i64, ptr } %t32, ptr %l23
  br label %bb5
bb5:
  %t33 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t36 = extractvalue { i64, ptr } %t33, 1
  %t37 = mul i64 %t35, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t37)
  call void @llvm.memcpy.p0.p0.i64(ptr %t38, ptr %t36, i64 %t37, i1 false)
  %t39 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d160, i32 0, i32 1) }, ptr %l26, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d161, i32 0, i32 1) }, ptr %l27, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t44 = call { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t40, { i64, ptr } %t42, { i64, ptr } %t43)
  store { i64, ptr } %t44, ptr %l28
  br label %bb6
bb6:
  %t45 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 1
  %t48 = extractvalue { i64, ptr } %t46, 0
  %t49 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d162, i32 0, i32 1) }, 1
  %t50 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d162, i32 0, i32 1) }, 0
  %t51 = add i64 %t48, %t50
  %t52 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 1
  %t54 = extractvalue { i64, ptr } %t52, 0
  %t55 = add i64 %t51, %t54
  %t57 = extractvalue { i64, ptr } %t45, 1
  %t58 = extractvalue { i64, ptr } %t45, 0
  %t59 = add i64 %t55, %t58
  %t60 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d163, i32 0, i32 1) }, 1
  %t61 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d163, i32 0, i32 1) }, 0
  %t62 = add i64 %t59, %t61
  %t63 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t62)
  call void @olang_textcopy(ptr %t63, ptr %t47, i64 %t48)
  %t64 = getelementptr i8, ptr %t63, i64 %t48
  call void @olang_textcopy(ptr %t64, ptr %t49, i64 %t50)
  %t65 = getelementptr i8, ptr %t64, i64 %t50
  call void @olang_textcopy(ptr %t65, ptr %t53, i64 %t54)
  %t66 = getelementptr i8, ptr %t65, i64 %t54
  call void @olang_textcopy(ptr %t66, ptr %t57, i64 %t58)
  %t67 = getelementptr i8, ptr %t66, i64 %t58
  call void @olang_textcopy(ptr %t67, ptr %t60, i64 %t61)
  %t68 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t63, 1
  store { i64, ptr } %t69, ptr %l15, !tbaa !27
  br label %bb7
bb7:
  %t71 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t71, ptr %lp6
  %t72 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t73 = load ptr, ptr %lp6
  store { i64, ptr } %t72, ptr %t73, !tbaa !27
  %t74 = load ptr, ptr %lp6
  %t75 = load { i64, ptr }, ptr %t74, !tbaa !27
  %t77 = call { i64, ptr } @std_2ffilepath_2eDir(ptr %v0, ptr %s0, { i64, ptr } %t75)
  store { i64, ptr } %t77, ptr %l32
  br label %bb8
bb8:
  %t78 = call ptr @__olang_scope_hold(ptr %s0)
  %t79 = ptrtoint ptr %t78 to i64
  store i64 %t79, ptr %l33, !tbaa !24
  %t80 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_202_3e_2e_2d1
  br i1 %t80, label %bb9, label %bb10
bb9:
  %t82 = call ptr @__olang_region_make(ptr %s0)
  %t83 = ptrtoint ptr %t82 to i64
  store i64 %t83, ptr %l33, !tbaa !24
  br label %bb10
bb10:
  %t84 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t84, 1
  %t87 = extractvalue { i64, ptr } %t84, 0
  %t88 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d164, i32 0, i32 1) }, 1
  %t89 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d164, i32 0, i32 1) }, 0
  %t90 = add i64 %t87, %t89
  %t91 = load i64, ptr %l33
  %t92 = inttoptr i64 %t91 to ptr
  %t93 = call ptr @__olang_held_alloc(ptr %t92, i64 %t90)
  call void @olang_textcopy(ptr %t93, ptr %t86, i64 %t87)
  %t94 = getelementptr i8, ptr %t93, i64 %t87
  call void @olang_textcopy(ptr %t94, ptr %t88, i64 %t89)
  %t95 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t93, 1
  %t98 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t99 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t98, 0
  %t101 = insertvalue [2 x { i64, ptr }] %t99, { i64, ptr } %t96, 1
  store [2 x { i64, ptr }] %t101, ptr %l7
  %t104 = insertvalue { i64, ptr } undef, i64 2, 0
  %t105 = insertvalue { i64, ptr } %t104, ptr %l7, 1
  %t107 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %v4, { i64, ptr } %t105)
  store { i64, ptr } %t107, ptr %l41
  br label %bb11
bb11:
  %t108 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 16, i64 8)
  store ptr %t108, ptr %lp8
  %t109 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t110 = load ptr, ptr %lp8
  store { i64, ptr } %t109, ptr %t110, !tbaa !27
  %t111 = load ptr, ptr %l0, !tbaa !29
  store ptr %t111, ptr %l42, !tbaa !29
  store ptr %a2, ptr %l43, !tbaa !29
  %t113 = load ptr, ptr %lp6
  %t114 = load { i64, ptr }, ptr %t113, !tbaa !27
  store { i64, ptr } %t114, ptr %l44, !tbaa !27
  %t115 = load ptr, ptr %l1, !tbaa !29
  %t117 = getelementptr %"compiler/build:Program", ptr %t115, i32 0, i32 2
  %t118 = load { i64, ptr }, ptr %t117, !tbaa !27
  %t120 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t118, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d165, i32 0, i32 1) })
  store i1 %t120, ptr %l47
  br label %bb12
bb12:
  %t121 = load i1, ptr %l47, !tbaa !21
  %t122 = xor i1 %t121, true
  %t123 = load ptr, ptr %l1, !tbaa !29
  %t125 = getelementptr %"compiler/build:Program", ptr %t123, i32 0, i32 3
  %t126 = load ptr, ptr %l1, !tbaa !29
  %t128 = getelementptr %"compiler/build:Program", ptr %t126, i32 0, i32 4
  %t129 = load ptr, ptr %l42, !tbaa !29
  %t130 = load ptr, ptr %l43, !tbaa !29
  %t131 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t135 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eLink(ptr %v0, ptr %v2, ptr %v0, ptr %v1, ptr %v1, ptr %t129, ptr %t130, { i64, ptr } %t131, i1 %t122, ptr %t125, ptr %t128)
  store i32 %t135, ptr %l53
  %t136 = icmp ne i32 %t135, 0
  br i1 %t136, label %bb14, label %ok.137, !prof !99
ok.137:
  br label %bb13
bb13:
  br label %bb19
bb14:
  %t138 = load i32, ptr %l53, !tbaa !23
  %t139 = ashr i32 %t138, 16
  %t141 = icmp eq i32 %t139, 1
  store i1 %t141, ptr %l55, !tbaa !21
  br label %bb15
bb15:
  %t142 = load ptr, ptr %l4, !tbaa !29
  store ptr %t142, ptr %l56, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t143
  %t144 = getelementptr { i64, [3 x i64] }, ptr %t143, i32 0, i32 0
  store i64 0, ptr %t144
  %t145 = load { i64, [3 x i64] }, ptr %t143
  store { i64, [3 x i64] } %t145, ptr %l57
  %t146 = load ptr, ptr %lp6
  %t147 = load { i64, ptr }, ptr %t146, !tbaa !27
  %t149 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLinkFailed(ptr %v0, ptr %v4, { i64, ptr } %t147)
  store %"compiler/diagmsg:Msg" %t149, ptr %l59
  br label %bb16
bb16:
  %t150 = load ptr, ptr %l56, !tbaa !29
  %t151 = load { i64, [3 x i64] }, ptr %l57
  %t152 = load %"compiler/diagmsg:Msg", ptr %l59
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v4, ptr %v4, ptr %t150, { i64, [3 x i64] } %t151, %"compiler/diagmsg:Msg" %t152)
  br label %bb17
bb17:
  %t153 = load ptr, ptr %l4, !tbaa !29
  %t155 = call i32 @compiler_2fbuild_2efinish(ptr %v4, ptr %t153)
  store i32 %t155, ptr %l61
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s0)
  %t156 = load i32, ptr %l61, !tbaa !23
  store i32 %t156, ptr %rv
  br label %ret
bb19:
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d166, i32 0, i32 1) })
  br label %bb20
bb20:
  %t157 = load ptr, ptr %lp8
  %t158 = load { i64, ptr }, ptr %t157, !tbaa !27
  %t159 = load ptr, ptr %l1, !tbaa !29
  %t161 = getelementptr %"compiler/build:Program", ptr %t159, i32 0, i32 5
  %t162 = load { i64, ptr }, ptr %t161, !tbaa !27
  %t166 = call i32 @std_2fos_2eWriteFile(ptr %v4, ptr %v1, { i64, ptr } %t158, { i64, ptr } %t162)
  store i32 %t166, ptr %l66
  %t167 = icmp ne i32 %t166, 0
  br i1 %t167, label %bb22, label %ok.168, !prof !99
ok.168:
  br label %bb21
bb21:
  br label %bb29
bb22:
  %t169 = load i32, ptr %l66, !tbaa !23
  %t170 = ashr i32 %t169, 16
  %t172 = icmp eq i32 %t170, 1
  store i1 %t172, ptr %l68, !tbaa !21
  %t173 = load i32, ptr %l66, !tbaa !23
  %t174 = ashr i32 %t173, 16
  %t176 = icmp eq i32 %t174, 1
  br i1 %t176, label %bb23, label %bb24
bb23:
  call void @__olang_errpay_pop()
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t178 = load ptr, ptr %lp8
  %t179 = load { i64, ptr }, ptr %t178, !tbaa !27
  store { i64, ptr } %t179, ptr %l71, !tbaa !27
  %t180 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eOutputCannotWrite(ptr %v4)
  store %"compiler/diagmsg:Msg" %t180, ptr %l72
  br label %bb26
bb26:
  %t181 = load ptr, ptr %l4, !tbaa !29
  %t182 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t183 = load %"compiler/diagmsg:Msg", ptr %l72
  call void @compiler_2fbuild_2efileFatal(ptr %v4, ptr %v4, ptr %v4, { i64, ptr } %t182, %"compiler/diagmsg:Msg" %t183, ptr %t181)
  br label %bb27
bb27:
  %t185 = load ptr, ptr %l4, !tbaa !29
  %t187 = call i32 @compiler_2fbuild_2efinish(ptr %v4, ptr %t185)
  store i32 %t187, ptr %l75
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s0)
  %t188 = load i32, ptr %l75, !tbaa !23
  store i32 %t188, ptr %rv
  br label %ret
bb29:
  %t189 = load ptr, ptr %l0, !tbaa !29
  store ptr %t189, ptr %l76, !tbaa !29
  %t190 = load ptr, ptr %lp6
  %t191 = load { i64, ptr }, ptr %t190, !tbaa !27
  %t192 = load ptr, ptr %l76, !tbaa !29
  %t193 = getelementptr %"compiler/build:Config", ptr %t192, i32 0, i32 35
  %t194 = load { i64, ptr }, ptr %t193, !tbaa !27
  store { i64, ptr } %t194, ptr %l78, !tbaa !27
  %t196 = load ptr, ptr %l76, !tbaa !29
  %t197 = getelementptr %"compiler/build:Config", ptr %t196, i32 0, i32 35
  store { i64, ptr } %t191, ptr %t197, !tbaa !27
  %t198 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3aConfig_2e35
  br i1 %t198, label %bb30, label %bb31
bb30:
  %t200 = load { i64, ptr }, ptr %l78
  %t201 = extractvalue { i64, ptr } %t200, 1
  call void @__olang_region_release(ptr %t201)
  store { i64, ptr } zeroinitializer, ptr %l78
  br label %bb31
bb31:
  call void @compiler_2fspin_2eEnd()
  br label %bb32
bb32:
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = getelementptr %"compiler/build:Config", ptr %t202, i32 0, i32 33
  %t205 = load i1, ptr %t204, !tbaa !21
  %t207 = xor i1 %t205, true
  br i1 %t207, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s6
  %t209 = load ptr, ptr %l0, !tbaa !29
  store ptr %t209, ptr %l83, !tbaa !29
  %t210 = load ptr, ptr %lp6
  %t211 = load { i64, ptr }, ptr %t210, !tbaa !27
  %t213 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %v0, ptr %s6, { i64, ptr } %t211)
  store { i64, ptr } %t213, ptr %l85
  br label %bb35
bb34:
  br label %bb39
bb35:
  %t214 = load ptr, ptr %lp8
  %t215 = load { i64, ptr }, ptr %t214, !tbaa !27
  %t217 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %v4, ptr %s6, { i64, ptr } %t215)
  store { i64, ptr } %t217, ptr %l87
  br label %bb36
bb36:
  %t218 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d167, i32 0, i32 1) }, 1
  %t219 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d167, i32 0, i32 1) }, 0
  %t220 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t221 = extractvalue { i64, ptr } %t220, 1
  %t222 = extractvalue { i64, ptr } %t220, 0
  %t223 = add i64 %t219, %t222
  %t224 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d168, i32 0, i32 1) }, 1
  %t225 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d168, i32 0, i32 1) }, 0
  %t226 = add i64 %t223, %t225
  %t227 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t228 = extractvalue { i64, ptr } %t227, 1
  %t229 = extractvalue { i64, ptr } %t227, 0
  %t230 = add i64 %t226, %t229
  %t231 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t230)
  call void @olang_textcopy(ptr %t231, ptr %t218, i64 %t219)
  %t232 = getelementptr i8, ptr %t231, i64 %t219
  call void @olang_textcopy(ptr %t232, ptr %t221, i64 %t222)
  %t233 = getelementptr i8, ptr %t232, i64 %t222
  call void @olang_textcopy(ptr %t233, ptr %t224, i64 %t225)
  %t234 = getelementptr i8, ptr %t233, i64 %t225
  call void @olang_textcopy(ptr %t234, ptr %t228, i64 %t229)
  %t235 = insertvalue { i64, ptr } undef, i64 %t230, 0
  %t236 = insertvalue { i64, ptr } %t235, ptr %t231, 1
  %t238 = load ptr, ptr %l83, !tbaa !29
  %t240 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %s6, ptr %s6, ptr %s6, ptr %t238, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d169, i32 0, i32 1) }, { i64, ptr } %t236)
  store { i64, ptr } %t240, ptr %l90
  br label %bb37
bb37:
  %t241 = load { i64, ptr }, ptr %l90, !tbaa !27
  call void @compiler_2fbuild_2esayln(ptr %s6, { i64, ptr } %t241)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s6)
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2elistLink(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, ptr %a2, { i64, ptr } %a3, i1 %a4, ptr %a5, ptr %a6) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca ptr
  %l9 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca ptr
  %l23 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca %"std/os:Output"
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca i64
  %l36 = alloca i64
  %l41 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l50 = alloca i64
  %l55 = alloca ptr
  %l56 = alloca i64
  %l59 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l66 = alloca ptr
  %l67 = alloca i64
  %l72 = alloca ptr
  %l73 = alloca i64
  %l79 = alloca ptr
  %l80 = alloca i64
  %l86 = alloca i64
  %l88 = alloca i64
  %l93 = alloca { i64, ptr }
  %l101 = alloca i64
  %l103 = alloca i64
  %l108 = alloca { i64, ptr }
  %l115 = alloca { i64, ptr }
  %l123 = alloca { i64, ptr }
  %l133 = alloca i1
  %l138 = alloca i1
  %l140 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l142 = alloca i64
  %l144 = alloca i64
  %l149 = alloca { i64, ptr }
  %l155 = alloca ptr
  %l157 = alloca { i64, ptr }
  %l159 = alloca { i64, ptr }
  %l162 = alloca i1
  %l168 = alloca i32
  %l170 = alloca %"std/os:Output"
  %l172 = alloca { i64, ptr }
  %l173 = alloca { i64, ptr }
  %l174 = alloca %"std/os:Output"
  %l175 = alloca i32
  %l177 = alloca i1
  %l180 = alloca %"std/os:Output"
  %l187 = alloca ptr
  %l188 = alloca { i64, [3 x i64] }
  %l192 = alloca %"compiler/diagmsg:Msg"
  %l194 = alloca ptr
  %l202 = alloca i32
  %l211 = alloca i32
  %l213 = alloca i1
  %s0 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %rv = alloca i32
  %t383 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store i1 %a4, ptr %l4
  store ptr %a5, ptr %l5
  store ptr %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l27
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l7
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/build:Config", ptr %t3, i32 0, i32 1
  %t6 = load { i64, ptr }, ptr %t5, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v0, ptr %l7, { i64, ptr } %t6)
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eModeFlags(ptr %v0, ptr %s0, ptr %t9)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %l32
  br label %bb3
bb3:
  %t12 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32
  %t13 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t12, ptr %t13
  store ptr %t13, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb4
bb4:
  %t15 = load i64, ptr %l9, !tbaa !24
  store i64 %t15, ptr %l34, !tbaa !24
  %t16 = load ptr, ptr %l8, !tbaa !29
  %t18 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t16)
  store i64 %t18, ptr %l36
  br label %bb5
bb5:
  %t19 = load i64, ptr %l34, !tbaa !24
  %t20 = load i64, ptr %l36, !tbaa !24
  %t21 = icmp slt i64 %t19, %t20
  %t23 = xor i1 %t21, true
  br i1 %t23, label %bb6, label %bb7
bb6:
  br label %bb12
bb7:
  br label %bb8
bb8:
  %t25 = load ptr, ptr %l8, !tbaa !29
  %t26 = load i64, ptr %l9, !tbaa !24
  %t29 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t25, i64 %t26)
  store { i64, ptr } %t29, ptr %l41
  br label %bb9
bb9:
  %t30 = load { i64, ptr }, ptr %l41, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l7, { i64, ptr } %t30)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t34 = load i64, ptr %l9, !tbaa !24
  %t37 = add i64 %t34, 1
  store i64 %t37, ptr %l9, !tbaa !24
  br label %bb4
bb12:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/build:Config", ptr %t39, i32 0, i32 38
  %t42 = load i1, ptr %t41, !tbaa !21
  br i1 %t42, label %bb13, label %bb14
bb13:
  store ptr %l7, ptr %l49, !tbaa !29
  %t44 = call ptr @__olang_scope_hold(ptr %s0)
  %t45 = ptrtoint ptr %t44 to i64
  store i64 %t45, ptr %l50, !tbaa !24
  %t46 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t46, label %bb15, label %bb16
bb14:
  br label %bb18
bb15:
  %t48 = call ptr @__olang_region_make(ptr %s0)
  %t49 = ptrtoint ptr %t48 to i64
  store i64 %t49, ptr %l50, !tbaa !24
  br label %bb16
bb16:
  %t50 = load i64, ptr @G_2ecompiler_2fbuild_2eImportLimit, !tbaa !24
  %t51 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d170, i32 0, i32 1) }, 1
  %t52 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d170, i32 0, i32 1) }, 0
  %t54 = call i64 @__olang_fmt_i64(ptr null, i64 %t50)
  %t55 = add i64 %t52, %t54
  %t56 = load i64, ptr %l50
  %t57 = inttoptr i64 %t56 to ptr
  %t58 = call ptr @__olang_held_alloc(ptr %t57, i64 %t55)
  call void @olang_textcopy(ptr %t58, ptr %t51, i64 %t52)
  %t59 = getelementptr i8, ptr %t58, i64 %t52
  %t60 = call i64 @__olang_fmt_i64(ptr %t59, i64 %t50)
  %t61 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t58, 1
  %t64 = load ptr, ptr %l49, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t64, { i64, ptr } %t62)
  br label %bb17
bb17:
  br label %bb18
bb18:
  store ptr %l7, ptr %l55, !tbaa !29
  %t66 = call ptr @__olang_scope_hold(ptr %s0)
  %t67 = ptrtoint ptr %t66 to i64
  store i64 %t67, ptr %l56, !tbaa !24
  %t68 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t68, label %bb19, label %bb20
bb19:
  %t70 = call ptr @__olang_region_make(ptr %s0)
  %t71 = ptrtoint ptr %t70 to i64
  store i64 %t71, ptr %l56, !tbaa !24
  br label %bb20
bb20:
  %t72 = load i1, ptr %l4, !tbaa !21
  br i1 %t72, label %bb21, label %bb22
bb21:
  store { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d171, i32 0, i32 1) }, ptr %l60, !tbaa !27
  %t74 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t76 = load i64, ptr %l56
  %t77 = inttoptr i64 %t76 to ptr
  %t78 = extractvalue { i64, ptr } %t74, 0
  %t79 = extractvalue { i64, ptr } %t74, 1
  %t80 = mul i64 %t78, 1
  %t81 = call ptr @__olang_held_alloc(ptr %t77, i64 %t80)
  call void @llvm.memcpy.p0.p0.i64(ptr %t81, ptr %t79, i64 %t80, i1 false)
  %t82 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t81, 1
  store { i64, ptr } %t83, ptr %l59, !tbaa !27
  br label %bb23
bb22:
  store { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d172, i32 0, i32 1) }, ptr %l63, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t87 = load i64, ptr %l56
  %t88 = inttoptr i64 %t87 to ptr
  %t89 = extractvalue { i64, ptr } %t85, 0
  %t90 = extractvalue { i64, ptr } %t85, 1
  %t91 = mul i64 %t89, 1
  %t92 = call ptr @__olang_held_alloc(ptr %t88, i64 %t91)
  call void @llvm.memcpy.p0.p0.i64(ptr %t92, ptr %t90, i64 %t91, i1 false)
  %t93 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t92, 1
  store { i64, ptr } %t94, ptr %l59, !tbaa !27
  br label %bb23
bb23:
  %t96 = load ptr, ptr %l55, !tbaa !29
  %t97 = load { i64, ptr }, ptr %l59, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t96, { i64, ptr } %t97)
  br label %bb24
bb24:
  store ptr %l7, ptr %l66, !tbaa !29
  %t98 = call ptr @__olang_scope_hold(ptr %s0)
  %t99 = ptrtoint ptr %t98 to i64
  store i64 %t99, ptr %l67, !tbaa !24
  %t100 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t100, label %bb25, label %bb26
bb25:
  %t102 = call ptr @__olang_region_make(ptr %s0)
  %t103 = ptrtoint ptr %t102 to i64
  store i64 %t103, ptr %l67, !tbaa !24
  br label %bb26
bb26:
  %t104 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t105 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d173, i32 0, i32 1) }, 1
  %t106 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d173, i32 0, i32 1) }, 0
  %t108 = extractvalue { i64, ptr } %t104, 1
  %t109 = extractvalue { i64, ptr } %t104, 0
  %t110 = add i64 %t106, %t109
  %t111 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d174, i32 0, i32 1) }, 1
  %t112 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d174, i32 0, i32 1) }, 0
  %t113 = add i64 %t110, %t112
  %t114 = load i64, ptr %l67
  %t115 = inttoptr i64 %t114 to ptr
  %t116 = call ptr @__olang_held_alloc(ptr %t115, i64 %t113)
  call void @olang_textcopy(ptr %t116, ptr %t105, i64 %t106)
  %t117 = getelementptr i8, ptr %t116, i64 %t106
  call void @olang_textcopy(ptr %t117, ptr %t108, i64 %t109)
  %t118 = getelementptr i8, ptr %t117, i64 %t109
  call void @olang_textcopy(ptr %t118, ptr %t111, i64 %t112)
  %t119 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %t116, 1
  %t122 = load ptr, ptr %l66, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t122, { i64, ptr } %t120)
  br label %bb27
bb27:
  store ptr %l7, ptr %l72, !tbaa !29
  %t124 = call ptr @__olang_scope_hold(ptr %s0)
  %t125 = ptrtoint ptr %t124 to i64
  store i64 %t125, ptr %l73, !tbaa !24
  %t126 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t126, label %bb28, label %bb29
bb28:
  %t128 = call ptr @__olang_region_make(ptr %s0)
  %t129 = ptrtoint ptr %t128 to i64
  store i64 %t129, ptr %l73, !tbaa !24
  br label %bb29
bb29:
  %t130 = load { i64, ptr }, ptr @G_2ecompiler_2fbuild_2eRemarkPasses, !tbaa !27
  %t131 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d175, i32 0, i32 1) }, 1
  %t132 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d175, i32 0, i32 1) }, 0
  %t134 = extractvalue { i64, ptr } %t130, 1
  %t135 = extractvalue { i64, ptr } %t130, 0
  %t136 = add i64 %t132, %t135
  %t137 = load i64, ptr %l73
  %t138 = inttoptr i64 %t137 to ptr
  %t139 = call ptr @__olang_held_alloc(ptr %t138, i64 %t136)
  call void @olang_textcopy(ptr %t139, ptr %t131, i64 %t132)
  %t140 = getelementptr i8, ptr %t139, i64 %t132
  call void @olang_textcopy(ptr %t140, ptr %t134, i64 %t135)
  %t141 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t139, 1
  %t144 = load ptr, ptr %l72, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t144, { i64, ptr } %t142)
  br label %bb30
bb30:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l7, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d176, i32 0, i32 1) })
  br label %bb31
bb31:
  store ptr %l7, ptr %l79, !tbaa !29
  %t147 = call ptr @__olang_scope_hold(ptr %s0)
  %t148 = ptrtoint ptr %t147 to i64
  store i64 %t148, ptr %l80, !tbaa !24
  %t149 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t149, label %bb32, label %bb33
bb32:
  %t151 = call ptr @__olang_region_make(ptr %s0)
  %t152 = ptrtoint ptr %t151 to i64
  store i64 %t152, ptr %l80, !tbaa !24
  br label %bb33
bb33:
  %t153 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t153, 1
  %t156 = extractvalue { i64, ptr } %t153, 0
  %t157 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d177, i32 0, i32 1) }, 1
  %t158 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d177, i32 0, i32 1) }, 0
  %t159 = add i64 %t156, %t158
  %t160 = load i64, ptr %l80
  %t161 = inttoptr i64 %t160 to ptr
  %t162 = call ptr @__olang_held_alloc(ptr %t161, i64 %t159)
  call void @olang_textcopy(ptr %t162, ptr %t155, i64 %t156)
  %t163 = getelementptr i8, ptr %t162, i64 %t156
  call void @olang_textcopy(ptr %t163, ptr %t157, i64 %t158)
  %t164 = insertvalue { i64, ptr } undef, i64 %t159, 0
  %t165 = insertvalue { i64, ptr } %t164, ptr %t162, 1
  %t167 = load ptr, ptr %l79, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t167, { i64, ptr } %t165)
  br label %bb34
bb34:
  store ptr %a1, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb35
bb35:
  %t171 = load i64, ptr %l12, !tbaa !24
  store i64 %t171, ptr %l86, !tbaa !24
  %t172 = load ptr, ptr %l11, !tbaa !29
  %t174 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v1, ptr %t172)
  store i64 %t174, ptr %l88
  br label %bb36
bb36:
  %t175 = load i64, ptr %l86, !tbaa !24
  %t176 = load i64, ptr %l88, !tbaa !24
  %t177 = icmp slt i64 %t175, %t176
  %t179 = xor i1 %t177, true
  br i1 %t179, label %bb37, label %bb38
bb37:
  br label %bb43
bb38:
  br label %bb39
bb39:
  %t181 = load ptr, ptr %l11, !tbaa !29
  %t182 = load i64, ptr %l12, !tbaa !24
  %t185 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t181, i64 %t182)
  store { i64, ptr } %t185, ptr %l93
  br label %bb40
bb40:
  %t186 = load { i64, ptr }, ptr %l93, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v1, ptr %l7, { i64, ptr } %t186)
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t190 = load i64, ptr %l12, !tbaa !24
  %t193 = add i64 %t190, 1
  store i64 %t193, ptr %l12, !tbaa !24
  br label %bb35
bb43:
  %t195 = load ptr, ptr %l2, !tbaa !29
  %t197 = getelementptr %"compiler/build:Program", ptr %t195, i32 0, i32 3
  store ptr %t197, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb44
bb44:
  %t199 = load i64, ptr %l15, !tbaa !24
  store i64 %t199, ptr %l101, !tbaa !24
  %t200 = load ptr, ptr %l14, !tbaa !29
  %t202 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v2, ptr %t200)
  store i64 %t202, ptr %l103
  br label %bb45
bb45:
  %t203 = load i64, ptr %l101, !tbaa !24
  %t204 = load i64, ptr %l103, !tbaa !24
  %t205 = icmp slt i64 %t203, %t204
  %t207 = xor i1 %t205, true
  br i1 %t207, label %bb46, label %bb47
bb46:
  br label %bb52
bb47:
  br label %bb48
bb48:
  %t209 = load ptr, ptr %l14, !tbaa !29
  %t210 = load i64, ptr %l15, !tbaa !24
  %t213 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v2, ptr %v2, ptr %t209, i64 %t210)
  store { i64, ptr } %t213, ptr %l108
  br label %bb49
bb49:
  %t214 = load { i64, ptr }, ptr %l108, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v2, ptr %l7, { i64, ptr } %t214)
  br label %bb50
bb50:
  br label %bb51
bb51:
  %t218 = load i64, ptr %l15, !tbaa !24
  %t221 = add i64 %t218, 1
  store i64 %t221, ptr %l15, !tbaa !24
  br label %bb44
bb52:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t225 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eSystemLibs(ptr %v0, ptr %s0, ptr %t223)
  store { i64, ptr } %t225, ptr %l115
  br label %bb53
bb53:
  %t226 = load { i64, ptr }, ptr %l115, !tbaa !27
  store { i64, ptr } %t226, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t228 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t230 = extractvalue { i64, ptr } %t228, 0
  store i64 %t230, ptr %l19, !tbaa !24
  br label %bb54
bb54:
  %t232 = load i64, ptr %l18, !tbaa !24
  %t233 = load i64, ptr %l19, !tbaa !24
  %t236 = icmp slt i64 %t232, %t233
  %t238 = xor i1 %t236, true
  br i1 %t238, label %bb55, label %bb56
bb55:
  br label %bb60
bb56:
  br label %bb57
bb57:
  %t240 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t240, ptr %l123, !tbaa !27
  %t241 = load i64, ptr %l18, !tbaa !24
  %t243 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !27
  %t245 = getelementptr { i64, ptr }, ptr %t244, i64 %t241
  %t246 = load { i64, ptr }, ptr %t245, !tbaa !37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l7, { i64, ptr } %t246)
  br label %bb58
bb58:
  br label %bb59
bb59:
  %t251 = load i64, ptr %l18, !tbaa !24
  %t254 = add i64 %t251, 1
  store i64 %t254, ptr %l18, !tbaa !24
  br label %bb54
bb60:
  %t256 = load ptr, ptr %l2, !tbaa !29
  %t258 = getelementptr %"compiler/build:Program", ptr %t256, i32 0, i32 2
  %t259 = load { i64, ptr }, ptr %t258, !tbaa !27
  %t261 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t259, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d178, i32 0, i32 1) })
  store i1 %t261, ptr %l133
  br label %bb61
bb61:
  %t262 = load i1, ptr %l133, !tbaa !21
  %t263 = xor i1 %t262, true
  br i1 %t263, label %bb62, label %bb63
bb62:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l7, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d179, i32 0, i32 1) })
  br label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb65
bb65:
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t268 = getelementptr %"compiler/build:Config", ptr %t266, i32 0, i32 1
  %t269 = load { i64, ptr }, ptr %t268, !tbaa !27
  %t271 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t269, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d180, i32 0, i32 1) })
  store i1 %t271, ptr %l138
  br label %bb66
bb66:
  %t272 = load i1, ptr %l138, !tbaa !21
  br i1 %t272, label %bb67, label %bb68
bb67:
  call void @__olang_scope_close(ptr %s0)
  store i32 65537, ptr %rv
  br label %ret
bb68:
  br label %bb69
bb69:
  %t274 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t274, ptr %l140
  br label %bb70
bb70:
  %t275 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l140
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t275, ptr %l21
  store ptr %l7, ptr %l22, !tbaa !29
  store i64 0, ptr %l23, !tbaa !24
  br label %bb71
bb71:
  %t277 = load i64, ptr %l23, !tbaa !24
  store i64 %t277, ptr %l142, !tbaa !24
  %t278 = load ptr, ptr %l22, !tbaa !29
  %t280 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t278)
  store i64 %t280, ptr %l144
  br label %bb72
bb72:
  %t281 = load i64, ptr %l142, !tbaa !24
  %t282 = load i64, ptr %l144, !tbaa !24
  %t283 = icmp slt i64 %t281, %t282
  %t285 = xor i1 %t283, true
  br i1 %t285, label %bb73, label %bb74
bb73:
  br label %bb79
bb74:
  br label %bb75
bb75:
  %t287 = load ptr, ptr %l22, !tbaa !29
  %t288 = load i64, ptr %l23, !tbaa !24
  %t291 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t287, i64 %t288)
  store { i64, ptr } %t291, ptr %l149
  br label %bb76
bb76:
  %t292 = load { i64, ptr }, ptr %l149, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l21, { i64, ptr } %t292)
  br label %bb77
bb77:
  br label %bb78
bb78:
  %t296 = load i64, ptr %l23, !tbaa !24
  %t299 = add i64 %t296, 1
  store i64 %t299, ptr %l23, !tbaa !24
  br label %bb71
bb79:
  store ptr %l21, ptr %l155, !tbaa !29
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t303 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eclangVersion(ptr %v0, ptr %v0, ptr %t301)
  store { i64, ptr } %t303, ptr %l157
  br label %bb80
bb80:
  %t304 = load ptr, ptr %l155, !tbaa !29
  %t305 = load { i64, ptr }, ptr %l157, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v0, ptr %t304, { i64, ptr } %t305)
  br label %bb81
bb81:
  %t307 = call { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %s0, ptr %s0, ptr %l21)
  store { i64, ptr } %t307, ptr %l159
  br label %bb82
bb82:
  %t308 = load { i64, ptr }, ptr %l159, !tbaa !27
  store { i64, ptr } %t308, ptr %l25, !tbaa !27
  %t309 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t310 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t313 = call i1 @compiler_2fbuild_2emadeBefore(ptr %v3, ptr %s0, { i64, ptr } %t309, { i64, ptr } %t310)
  store i1 %t313, ptr %l162
  br label %bb83
bb83:
  %t314 = load i1, ptr %l162, !tbaa !21
  br i1 %t314, label %bb84, label %bb85
bb84:
  %t315 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t316 = load i1, ptr %l4, !tbaa !21
  %t317 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fbuild_2elistFiles(ptr %v3, ptr %v4, { i64, ptr } %t315, i1 %t316, ptr %t317)
  br label %bb86
bb85:
  br label %bb87
bb86:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb87:
  %t321 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t322 = load ptr, ptr %l6, !tbaa !29
  %t325 = call i32 @compiler_2fbuild_2eafresh(ptr %v3, ptr %v5, { i64, ptr } %t321, ptr %t322)
  store i32 %t325, ptr %l168
  %t326 = icmp ne i32 %t325, 0
  br i1 %t326, label %bb89, label %ok.327, !prof !99
ok.327:
  br label %bb88
bb88:
  br label %bb90
bb89:
  %t328 = load i32, ptr %l168, !tbaa !23
  %t329 = lshr i32 %t328, 16
  %t330 = and i32 %t328, 65535
  %t331 = icmp eq i32 %t329, 1
  %t332 = select i1 %t331, i32 1, i32 0
  %t333 = icmp eq i32 %t328, 0
  %t334 = shl i32 %t332, 16
  %t335 = or i32 %t334, %t330
  %t336 = select i1 %t333, i32 0, i32 %t335
  call void @__olang_scope_close(ptr %s0)
  store i32 %t336, ptr %rv
  br label %ret
bb90:
  %t339 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %s0, ptr %s0, ptr %l7)
  store { i64, ptr } %t339, ptr %l172
  br label %bb91
bb91:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %l173, !tbaa !27
  %t340 = load { i64, ptr }, ptr %l172, !tbaa !27
  %t341 = load { i64, ptr }, ptr %l173, !tbaa !27
  %t342 = call { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExec(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t340, { i64, ptr } %t341, i1 true, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d39, i32 0, i32 1) })
  %t343 = extractvalue { i32, %"std/os:Output" } %t342, 1
  %t344 = extractvalue { i32, %"std/os:Output" } %t342, 0
  store i32 %t344, ptr %l175
  %t345 = icmp ne i32 %t344, 0
  br i1 %t345, label %bb93, label %ok.346, !prof !99
ok.346:
  store %"std/os:Output" %t343, ptr %l174
  br label %bb92
bb92:
  %t347 = load %"std/os:Output", ptr %l174
  store %"std/os:Output" %t347, ptr %l170
  br label %bb98
bb93:
  %t348 = load i32, ptr %l175, !tbaa !23
  %t349 = ashr i32 %t348, 16
  %t351 = icmp eq i32 %t349, 1
  store i1 %t351, ptr %l177, !tbaa !21
  %t352 = load i32, ptr %l175, !tbaa !23
  %t353 = ashr i32 %t352, 16
  %t355 = icmp eq i32 %t353, 1
  br i1 %t355, label %bb94, label %bb95
bb94:
  call void @__olang_errpay_pop()
  br label %bb95
bb95:
  br label %bb96
bb96:
  %t357 = call %"std/os:Output" @std_2fos_3aOutput_2ector(ptr %s0, ptr %s0, ptr %s0, i32 127, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d181, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d182, i32 0, i32 1) })
  store %"std/os:Output" %t357, ptr %l180
  br label %bb97
bb97:
  %t358 = load %"std/os:Output", ptr %l180
  store %"std/os:Output" %t358, ptr %l170
  br label %bb98
bb98:
  %t359 = load %"std/os:Output", ptr %l170
  store %"std/os:Output" %t359, ptr %l26
  %t360 = getelementptr %"std/os:Output", ptr %l26, i32 0, i32 0
  %t361 = load i32, ptr %t360, !tbaa !23
  %t363 = icmp ne i32 %t361, 0
  br i1 %t363, label %bb99, label %bb100
bb99:
  store %olang.scope zeroinitializer, ptr %s24
  %t365 = getelementptr %"std/os:Output", ptr %l26, i32 0, i32 1
  %t366 = load { i64, ptr }, ptr %t365, !tbaa !27
  %t367 = getelementptr %"std/os:Output", ptr %l26, i32 0, i32 2
  %t368 = load { i64, ptr }, ptr %t367, !tbaa !27
  %t370 = extractvalue { i64, ptr } %t366, 1
  %t371 = extractvalue { i64, ptr } %t366, 0
  %t373 = extractvalue { i64, ptr } %t368, 1
  %t374 = extractvalue { i64, ptr } %t368, 0
  %t375 = add i64 %t371, %t374
  %t376 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t375)
  call void @olang_textcopy(ptr %t376, ptr %t370, i64 %t371)
  %t377 = getelementptr i8, ptr %t376, i64 %t371
  call void @olang_textcopy(ptr %t377, ptr %t373, i64 %t374)
  %t378 = insertvalue { i64, ptr } undef, i64 %t375, 0
  %t379 = insertvalue { i64, ptr } %t378, ptr %t376, 1
  call void @compiler_2fbuild_2esayErr(ptr %s24, { i64, ptr } %t379)
  br label %bb101
bb100:
  br label %bb104
bb101:
  %t382 = load ptr, ptr %l6, !tbaa !29
  store ptr %t382, ptr %l187, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t383
  %t384 = getelementptr { i64, [3 x i64] }, ptr %t383, i32 0, i32 0
  store i64 0, ptr %t384
  %t385 = load { i64, [3 x i64] }, ptr %t383
  store { i64, [3 x i64] } %t385, ptr %l188
  %t386 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t388 = extractvalue { i64, ptr } %t386, 1
  %t389 = extractvalue { i64, ptr } %t386, 0
  %t390 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d183, i32 0, i32 1) }, 1
  %t391 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d183, i32 0, i32 1) }, 0
  %t392 = add i64 %t389, %t391
  %t393 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t392)
  call void @olang_textcopy(ptr %t393, ptr %t388, i64 %t389)
  %t394 = getelementptr i8, ptr %t393, i64 %t389
  call void @olang_textcopy(ptr %t394, ptr %t390, i64 %t391)
  %t395 = insertvalue { i64, ptr } undef, i64 %t392, 0
  %t396 = insertvalue { i64, ptr } %t395, ptr %t393, 1
  %t399 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLinkFailed(ptr %s24, ptr %v5, { i64, ptr } %t396)
  store %"compiler/diagmsg:Msg" %t399, ptr %l192
  br label %bb102
bb102:
  %t400 = load ptr, ptr %l187, !tbaa !29
  %t401 = load { i64, [3 x i64] }, ptr %l188
  %t402 = load %"compiler/diagmsg:Msg", ptr %l192
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v5, ptr %v5, ptr %t400, { i64, [3 x i64] } %t401, %"compiler/diagmsg:Msg" %t402)
  br label %bb103
bb103:
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb104:
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d184, i32 0, i32 1) })
  br label %bb105
bb105:
  %t404 = load ptr, ptr %l0, !tbaa !29
  store ptr %t404, ptr %l194, !tbaa !29
  %t405 = load ptr, ptr %l194, !tbaa !29
  %t406 = getelementptr %"compiler/build:Config", ptr %t405, i32 0, i32 37
  %t407 = load i64, ptr %t406, !tbaa !24
  %t410 = add i64 %t407, 1
  %t412 = load ptr, ptr %l194, !tbaa !29
  %t413 = getelementptr %"compiler/build:Config", ptr %t412, i32 0, i32 37
  store i64 %t410, ptr %t413, !tbaa !24
  %t414 = load i1, ptr %l4, !tbaa !21
  br i1 %t414, label %bb106, label %bb107
bb106:
  %t416 = load ptr, ptr %l0, !tbaa !29
  %t417 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t418 = load ptr, ptr %l6, !tbaa !29
  %t422 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ebitcodeText(ptr %v0, ptr %v3, ptr %v5, ptr %t416, { i64, ptr } %t417, ptr %t418)
  store i32 %t422, ptr %l202
  %t423 = icmp ne i32 %t422, 0
  br i1 %t423, label %bb109, label %ok.424, !prof !99
ok.424:
  br label %bb108
bb107:
  br label %bb111
bb108:
  br label %bb110
bb109:
  %t425 = load i32, ptr %l202, !tbaa !23
  %t426 = lshr i32 %t425, 16
  %t427 = and i32 %t425, 65535
  %t428 = icmp eq i32 %t426, 1
  %t429 = select i1 %t428, i32 1, i32 0
  %t430 = icmp eq i32 %t425, 0
  %t431 = shl i32 %t429, 16
  %t432 = or i32 %t431, %t427
  %t433 = select i1 %t430, i32 0, i32 %t432
  call void @__olang_scope_close(ptr %s0)
  store i32 %t433, ptr %rv
  br label %ret
bb110:
  br label %bb111
bb111:
  %t435 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t437 = extractvalue { i64, ptr } %t435, 1
  %t438 = extractvalue { i64, ptr } %t435, 0
  %t439 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d185, i32 0, i32 1) }, 1
  %t440 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d185, i32 0, i32 1) }, 0
  %t441 = add i64 %t438, %t440
  %t442 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t441)
  call void @olang_textcopy(ptr %t442, ptr %t437, i64 %t438)
  %t443 = getelementptr i8, ptr %t442, i64 %t438
  call void @olang_textcopy(ptr %t443, ptr %t439, i64 %t440)
  %t444 = insertvalue { i64, ptr } undef, i64 %t441, 0
  %t445 = insertvalue { i64, ptr } %t444, ptr %t442, 1
  %t447 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t449 = extractvalue { i64, ptr } %t447, 1
  %t450 = extractvalue { i64, ptr } %t447, 0
  %t451 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d186, i32 0, i32 1) }, 1
  %t452 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d186, i32 0, i32 1) }, 0
  %t453 = add i64 %t450, %t452
  %t454 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t453)
  call void @olang_textcopy(ptr %t454, ptr %t449, i64 %t450)
  %t455 = getelementptr i8, ptr %t454, i64 %t450
  call void @olang_textcopy(ptr %t455, ptr %t451, i64 %t452)
  %t456 = insertvalue { i64, ptr } undef, i64 %t453, 0
  %t457 = insertvalue { i64, ptr } %t456, ptr %t454, 1
  %t460 = extractvalue { i64, ptr } %t457, 0
  %t461 = extractvalue { i64, ptr } %t457, 1
  %t462 = mul i64 %t460, 1
  %t463 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t462)
  call void @llvm.memcpy.p0.p0.i64(ptr %t463, ptr %t461, i64 %t462, i1 false)
  %t464 = insertvalue { i64, ptr } undef, i64 %t460, 0
  %t465 = insertvalue { i64, ptr } %t464, ptr %t463, 1
  %t468 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s0, { i64, ptr } %t445, { i64, ptr } %t465)
  store i32 %t468, ptr %l211
  %t469 = icmp ne i32 %t468, 0
  br i1 %t469, label %bb113, label %ok.470, !prof !99
ok.470:
  br label %bb112
bb112:
  br label %bb117
bb113:
  %t471 = load i32, ptr %l211, !tbaa !23
  %t472 = ashr i32 %t471, 16
  %t474 = icmp eq i32 %t472, 1
  store i1 %t474, ptr %l213, !tbaa !21
  %t475 = load i32, ptr %l211, !tbaa !23
  %t476 = ashr i32 %t475, 16
  %t478 = icmp eq i32 %t476, 1
  br i1 %t478, label %bb114, label %bb115
bb114:
  call void @__olang_errpay_pop()
  br label %bb115
bb115:
  br label %bb116
bb116:
  br label %bb117
bb117:
  %t480 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t481 = load i1, ptr %l4, !tbaa !21
  %t482 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fbuild_2elistFiles(ptr %v3, ptr %v4, { i64, ptr } %t480, i1 %t481, ptr %t482)
  br label %bb118
bb118:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2elistQuick(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, i1 %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"compiler/build:Unit"
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l15 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %lp24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca i64
  %l31 = alloca i64
  %l33 = alloca { { i64, ptr }, { i64, ptr } }
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l48 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l51 = alloca i64
  %l53 = alloca i64
  %l58 = alloca %"compiler/build:Unit"
  %l69 = alloca i1
  %l76 = alloca i1
  %l83 = alloca i1
  %l85 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l87 = alloca i64
  %l89 = alloca i64
  %l94 = alloca { i64, ptr }
  %l95 = alloca ptr
  %l96 = alloca i64
  %l99 = alloca { i64, ptr }
  %l103 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l105 = alloca i64
  %l107 = alloca i64
  %l112 = alloca { i64, ptr }
  %l121 = alloca ptr
  %l122 = alloca i64
  %l127 = alloca ptr
  %l129 = alloca { i64, ptr }
  %l131 = alloca { i64, ptr }
  %l134 = alloca i1
  %l140 = alloca i32
  %l142 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l143 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l145 = alloca i64
  %l147 = alloca i64
  %l153 = alloca { i64, ptr }
  %l160 = alloca i32
  %l162 = alloca i1
  %l165 = alloca { i64, ptr }
  %l166 = alloca %"compiler/diagmsg:Msg"
  %l169 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l176 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l178 = alloca i64
  %l180 = alloca i64
  %l185 = alloca { i64, ptr }
  %l194 = alloca i64
  %l196 = alloca { i64, ptr }
  %l197 = alloca i64
  %l199 = alloca { i64, ptr }
  %l201 = alloca { i64, ptr }
  %l202 = alloca { i64, ptr }
  %l203 = alloca i64
  %l225 = alloca ptr
  %l226 = alloca i64
  %l229 = alloca { i64, ptr }
  %l237 = alloca { i64, ptr }
  %l239 = alloca i64
  %l241 = alloca { i64, ptr }
  %l242 = alloca { { i64, ptr }, { i64, ptr } }
  %l243 = alloca { i64, ptr }
  %l244 = alloca i64
  %l245 = alloca { i64, ptr }
  %l246 = alloca { i64, ptr }
  %l247 = alloca i64
  %l248 = alloca { i64, ptr }
  %l249 = alloca ptr
  %l250 = alloca i64
  %l252 = alloca i64
  %l259 = alloca i64
  %l262 = alloca i64
  %l285 = alloca ptr
  %l286 = alloca { i64, [3 x i64] }
  %l291 = alloca %"compiler/diagmsg:Msg"
  %l297 = alloca i64
  %l301 = alloca i64
  %l304 = alloca i64
  %l326 = alloca i32
  %l328 = alloca i1
  %l341 = alloca i32
  %l343 = alloca i1
  %s0 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %rv = alloca i32
  %t578 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i1 %a3, ptr %l3
  store ptr %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l48
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l48
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l6
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/build:Program", ptr %t3, i32 0, i32 0
  store ptr %t5, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i64, ptr %l8, !tbaa !24
  store i64 %t7, ptr %l51, !tbaa !24
  %t8 = load ptr, ptr %l7, !tbaa !29
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v1, ptr %t8)
  store i64 %t10, ptr %l53
  br label %bb3
bb3:
  %t11 = load i64, ptr %l51, !tbaa !24
  %t12 = load i64, ptr %l53, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb4, label %bb5
bb4:
  br label %bb13
bb5:
  br label %bb6
bb6:
  %t17 = load ptr, ptr %l7, !tbaa !29
  %t18 = load i64, ptr %l8, !tbaa !24
  %t21 = call %"compiler/build:Unit" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eAt_3ccompiler_2fbuild_3aUnit_3e(ptr %v1, ptr %v1, ptr %t17, i64 %t18)
  store %"compiler/build:Unit" %t21, ptr %l58
  br label %bb7
bb7:
  %t22 = load %"compiler/build:Unit", ptr %l58
  store %"compiler/build:Unit" %t22, ptr %l9
  %t23 = getelementptr %"compiler/build:Unit", ptr %l9, i32 0, i32 1
  %t24 = load i32, ptr %t23, !range !{i32 0, i32 5}
  %t26 = trunc i64 4 to i32
  %t27 = icmp eq i32 %t24, %t26
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb8, label %bb9
bb8:
  %t31 = getelementptr %"compiler/build:Unit", ptr %l9, i32 0, i32 2
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v1, ptr %l6, { i64, ptr } %t32)
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t35 = load i64, ptr %l8, !tbaa !24
  %t38 = add i64 %t35, 1
  store i64 %t38, ptr %l8, !tbaa !24
  br label %bb2
bb13:
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr %"compiler/build:Program", ptr %t40, i32 0, i32 1
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !27
  %t45 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t43, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d187, i32 0, i32 1) })
  store i1 %t45, ptr %l69
  br label %bb14
bb14:
  %t46 = load i1, ptr %l69, !tbaa !21
  %t47 = xor i1 %t46, true
  br i1 %t47, label %bb15, label %bb16
bb15:
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr %"compiler/build:Program", ptr %t49, i32 0, i32 1
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v1, ptr %l6, { i64, ptr } %t52)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr %"compiler/build:Program", ptr %t55, i32 0, i32 2
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  %t60 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t58, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d188, i32 0, i32 1) })
  store i1 %t60, ptr %l76
  br label %bb19
bb19:
  %t61 = load i1, ptr %l76, !tbaa !21
  %t62 = xor i1 %t61, true
  br i1 %t62, label %bb20, label %bb21
bb20:
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr %"compiler/build:Program", ptr %t64, i32 0, i32 2
  %t67 = load { i64, ptr }, ptr %t66, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v1, ptr %l6, { i64, ptr } %t67)
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb23
bb23:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/build:Config", ptr %t70, i32 0, i32 1
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  %t75 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t73, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d189, i32 0, i32 1) })
  store i1 %t75, ptr %l83
  br label %bb24
bb24:
  %t76 = load i1, ptr %l83, !tbaa !21
  br i1 %t76, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s0)
  store i32 65537, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t78 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t78, ptr %l85
  br label %bb28
bb28:
  %t79 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l85
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t79, ptr %l10
  store ptr %l6, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb29
bb29:
  %t81 = load i64, ptr %l12, !tbaa !24
  store i64 %t81, ptr %l87, !tbaa !24
  %t82 = load ptr, ptr %l11, !tbaa !29
  %t84 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t82)
  store i64 %t84, ptr %l89
  br label %bb30
bb30:
  %t85 = load i64, ptr %l87, !tbaa !24
  %t86 = load i64, ptr %l89, !tbaa !24
  %t87 = icmp slt i64 %t85, %t86
  %t89 = xor i1 %t87, true
  br i1 %t89, label %bb31, label %bb32
bb31:
  br label %bb50
bb32:
  br label %bb33
bb33:
  %t91 = load ptr, ptr %l11, !tbaa !29
  %t92 = load i64, ptr %l12, !tbaa !24
  %t95 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t91, i64 %t92)
  store { i64, ptr } %t95, ptr %l94
  br label %bb34
bb34:
  %t96 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t96, ptr %l13, !tbaa !27
  store ptr %l10, ptr %l95, !tbaa !29
  %t97 = call ptr @__olang_scope_hold(ptr %s0)
  %t98 = ptrtoint ptr %t97 to i64
  store i64 %t98, ptr %l96, !tbaa !24
  %t99 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t99, label %bb35, label %bb36
bb35:
  %t101 = call ptr @__olang_region_make(ptr %s0)
  %t102 = ptrtoint ptr %t101 to i64
  store i64 %t102, ptr %l96, !tbaa !24
  br label %bb36
bb36:
  %t103 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t104 = load i64, ptr %l96
  %t105 = inttoptr i64 %t104 to ptr
  %t107 = call { i64, ptr } @compiler_2fbuild_2eIrHash(ptr %s0, ptr %t105, { i64, ptr } %t103)
  store { i64, ptr } %t107, ptr %l99
  br label %bb37
bb37:
  %t108 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t109 = load ptr, ptr %l95, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t109, { i64, ptr } %t108)
  br label %bb38
bb38:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t115 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eCompileFlags(ptr %v0, ptr %s0, ptr %s0, ptr %t111, { i64, ptr } %t112)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t115, ptr %l103
  br label %bb39
bb39:
  %t116 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l103
  %t117 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t116, ptr %t117
  store ptr %t117, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb40
bb40:
  %t119 = load i64, ptr %l15, !tbaa !24
  store i64 %t119, ptr %l105, !tbaa !24
  %t120 = load ptr, ptr %l14, !tbaa !29
  %t122 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t120)
  store i64 %t122, ptr %l107
  br label %bb41
bb41:
  %t123 = load i64, ptr %l105, !tbaa !24
  %t124 = load i64, ptr %l107, !tbaa !24
  %t125 = icmp slt i64 %t123, %t124
  %t127 = xor i1 %t125, true
  br i1 %t127, label %bb42, label %bb43
bb42:
  br label %bb48
bb43:
  br label %bb44
bb44:
  %t129 = load ptr, ptr %l14, !tbaa !29
  %t130 = load i64, ptr %l15, !tbaa !24
  %t133 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t129, i64 %t130)
  store { i64, ptr } %t133, ptr %l112
  br label %bb45
bb45:
  %t134 = load { i64, ptr }, ptr %l112, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l10, { i64, ptr } %t134)
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t138 = load i64, ptr %l15, !tbaa !24
  %t141 = add i64 %t138, 1
  store i64 %t141, ptr %l15, !tbaa !24
  br label %bb40
bb48:
  br label %bb49
bb49:
  %t143 = load i64, ptr %l12, !tbaa !24
  %t146 = add i64 %t143, 1
  store i64 %t146, ptr %l12, !tbaa !24
  br label %bb29
bb50:
  store ptr %l10, ptr %l121, !tbaa !29
  %t148 = call ptr @__olang_scope_hold(ptr %s0)
  %t149 = ptrtoint ptr %t148 to i64
  store i64 %t149, ptr %l122, !tbaa !24
  %t150 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t150, label %bb51, label %bb52
bb51:
  %t152 = call ptr @__olang_region_make(ptr %s0)
  %t153 = ptrtoint ptr %t152 to i64
  store i64 %t153, ptr %l122, !tbaa !24
  br label %bb52
bb52:
  %t154 = load i1, ptr %l3, !tbaa !21
  %t156 = select i1 %t154, ptr @.c190, ptr @.c191
  %t157 = select i1 %t154, i64 4, i64 5
  %t158 = load i64, ptr %l122
  %t159 = inttoptr i64 %t158 to ptr
  %t160 = call ptr @__olang_held_alloc(ptr %t159, i64 %t157)
  call void @olang_textcopy(ptr %t160, ptr %t156, i64 %t157)
  %t161 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t162 = insertvalue { i64, ptr } %t161, ptr %t160, 1
  %t164 = load ptr, ptr %l121, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t164, { i64, ptr } %t162)
  br label %bb53
bb53:
  store ptr %l10, ptr %l127, !tbaa !29
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eclangVersion(ptr %v0, ptr %v0, ptr %t166)
  store { i64, ptr } %t168, ptr %l129
  br label %bb54
bb54:
  %t169 = load ptr, ptr %l127, !tbaa !29
  %t170 = load { i64, ptr }, ptr %l129, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v0, ptr %t169, { i64, ptr } %t170)
  br label %bb55
bb55:
  %t172 = call { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %s0, ptr %s0, ptr %l10)
  store { i64, ptr } %t172, ptr %l131
  br label %bb56
bb56:
  %t173 = load { i64, ptr }, ptr %l131, !tbaa !27
  store { i64, ptr } %t173, ptr %l17, !tbaa !27
  %t174 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t175 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t178 = call i1 @compiler_2fbuild_2emadeBefore(ptr %v2, ptr %s0, { i64, ptr } %t174, { i64, ptr } %t175)
  store i1 %t178, ptr %l134
  br label %bb57
bb57:
  %t179 = load i1, ptr %l134, !tbaa !21
  br i1 %t179, label %bb58, label %bb59
bb58:
  %t180 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t181 = load i1, ptr %l3, !tbaa !21
  %t182 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fbuild_2elistFiles(ptr %v2, ptr %v3, { i64, ptr } %t180, i1 %t181, ptr %t182)
  br label %bb60
bb59:
  br label %bb61
bb60:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb61:
  %t186 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t187 = load ptr, ptr %l5, !tbaa !29
  %t190 = call i32 @compiler_2fbuild_2eafresh(ptr %v2, ptr %v4, { i64, ptr } %t186, ptr %t187)
  store i32 %t190, ptr %l140
  %t191 = icmp ne i32 %t190, 0
  br i1 %t191, label %bb63, label %ok.192, !prof !99
ok.192:
  br label %bb62
bb62:
  br label %bb64
bb63:
  %t193 = load i32, ptr %l140, !tbaa !23
  %t194 = lshr i32 %t193, 16
  %t195 = and i32 %t193, 65535
  %t196 = icmp eq i32 %t194, 1
  %t197 = select i1 %t196, i32 1, i32 0
  %t198 = icmp eq i32 %t193, 0
  %t199 = shl i32 %t197, 16
  %t200 = or i32 %t199, %t195
  %t201 = select i1 %t198, i32 0, i32 %t200
  call void @__olang_scope_close(ptr %s0)
  store i32 %t201, ptr %rv
  br label %ret
bb64:
  %t203 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t203, ptr %l142
  br label %bb65
bb65:
  %t204 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l142
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t204, ptr %l18
  %t205 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t205, ptr %l143
  br label %bb66
bb66:
  %t206 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l143
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t206, ptr %l19
  store ptr %l6, ptr %l20, !tbaa !29
  store i64 0, ptr %l21, !tbaa !24
  br label %bb67
bb67:
  %t208 = load i64, ptr %l21, !tbaa !24
  store i64 %t208, ptr %l145, !tbaa !24
  %t209 = load ptr, ptr %l20, !tbaa !29
  %t211 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t209)
  store i64 %t211, ptr %l147
  br label %bb68
bb68:
  %t212 = load i64, ptr %l145, !tbaa !24
  %t213 = load i64, ptr %l147, !tbaa !24
  %t214 = icmp slt i64 %t212, %t213
  %t216 = xor i1 %t214, true
  br i1 %t216, label %bb69, label %bb70
bb69:
  br label %bb118
bb70:
  br label %bb71
bb71:
  %t218 = load i64, ptr %l21, !tbaa !24
  store i64 %t218, ptr %l22, !tbaa !24
  %t220 = load ptr, ptr %l20, !tbaa !29
  %t221 = load i64, ptr %l21, !tbaa !24
  %t224 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t220, i64 %t221)
  store { i64, ptr } %t224, ptr %l153
  br label %bb72
bb72:
  %t225 = load { i64, ptr }, ptr %l153, !tbaa !27
  store { i64, ptr } %t225, ptr %l23, !tbaa !27
  %t226 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t227 = load i64, ptr %l22, !tbaa !24
  %t229 = extractvalue { i64, ptr } %t226, 1
  %t230 = extractvalue { i64, ptr } %t226, 0
  %t231 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d192, i32 0, i32 1) }, 1
  %t232 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d192, i32 0, i32 1) }, 0
  %t233 = add i64 %t230, %t232
  %t235 = call i64 @__olang_fmt_i64(ptr null, i64 %t227)
  %t236 = add i64 %t233, %t235
  %t237 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d193, i32 0, i32 1) }, 1
  %t238 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d193, i32 0, i32 1) }, 0
  %t239 = add i64 %t236, %t238
  %t240 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t239)
  call void @olang_textcopy(ptr %t240, ptr %t229, i64 %t230)
  %t241 = getelementptr i8, ptr %t240, i64 %t230
  call void @olang_textcopy(ptr %t241, ptr %t231, i64 %t232)
  %t242 = getelementptr i8, ptr %t241, i64 %t232
  %t243 = call i64 @__olang_fmt_i64(ptr %t242, i64 %t227)
  %t244 = getelementptr i8, ptr %t242, i64 %t235
  call void @olang_textcopy(ptr %t244, ptr %t237, i64 %t238)
  %t245 = insertvalue { i64, ptr } undef, i64 %t239, 0
  %t246 = insertvalue { i64, ptr } %t245, ptr %t240, 1
  %t247 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 16, i64 8)
  store ptr %t247, ptr %lp24
  %t249 = load ptr, ptr %lp24
  store { i64, ptr } %t246, ptr %t249, !tbaa !27
  %t250 = load ptr, ptr %lp24
  %t251 = load { i64, ptr }, ptr %t250, !tbaa !27
  %t252 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t256 = call i32 @std_2fos_2eWriteFile(ptr %v4, ptr %s0, { i64, ptr } %t251, { i64, ptr } %t252)
  store i32 %t256, ptr %l160
  %t257 = icmp ne i32 %t256, 0
  br i1 %t257, label %bb74, label %ok.258, !prof !99
ok.258:
  br label %bb73
bb73:
  br label %bb80
bb74:
  %t259 = load i32, ptr %l160, !tbaa !23
  %t260 = ashr i32 %t259, 16
  %t262 = icmp eq i32 %t260, 1
  store i1 %t262, ptr %l162, !tbaa !21
  %t263 = load i32, ptr %l160, !tbaa !23
  %t264 = ashr i32 %t263, 16
  %t266 = icmp eq i32 %t264, 1
  br i1 %t266, label %bb75, label %bb76
bb75:
  call void @__olang_errpay_pop()
  br label %bb76
bb76:
  br label %bb77
bb77:
  %t268 = load ptr, ptr %lp24
  %t269 = load { i64, ptr }, ptr %t268, !tbaa !27
  store { i64, ptr } %t269, ptr %l165, !tbaa !27
  %t270 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %v4)
  store %"compiler/diagmsg:Msg" %t270, ptr %l166
  br label %bb78
bb78:
  %t271 = load ptr, ptr %l5, !tbaa !29
  %t272 = load { i64, ptr }, ptr %l165, !tbaa !27
  %t273 = load %"compiler/diagmsg:Msg", ptr %l166
  call void @compiler_2fbuild_2efileFatal(ptr %v4, ptr %v4, ptr %v4, { i64, ptr } %t272, %"compiler/diagmsg:Msg" %t273, ptr %t271)
  br label %bb79
bb79:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb80:
  %t276 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t276, ptr %l169
  br label %bb81
bb81:
  %t277 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l169
  %t278 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t277, ptr %t278
  store ptr %t278, ptr %l25, !tbaa !29
  %t280 = load ptr, ptr %l25, !tbaa !29
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t283 = getelementptr %"compiler/build:Config", ptr %t281, i32 0, i32 1
  %t284 = load { i64, ptr }, ptr %t283, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v0, ptr %t280, { i64, ptr } %t284)
  br label %bb82
bb82:
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t288 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t291 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eCompileFlags(ptr %v0, ptr %s0, ptr %s0, ptr %t287, { i64, ptr } %t288)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t291, ptr %l176
  br label %bb83
bb83:
  %t292 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l176
  %t293 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t292, ptr %t293
  store ptr %t293, ptr %l26, !tbaa !29
  store i64 0, ptr %l27, !tbaa !24
  br label %bb84
bb84:
  %t295 = load i64, ptr %l27, !tbaa !24
  store i64 %t295, ptr %l178, !tbaa !24
  %t296 = load ptr, ptr %l26, !tbaa !29
  %t298 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t296)
  store i64 %t298, ptr %l180
  br label %bb85
bb85:
  %t299 = load i64, ptr %l178, !tbaa !24
  %t300 = load i64, ptr %l180, !tbaa !24
  %t301 = icmp slt i64 %t299, %t300
  %t303 = xor i1 %t301, true
  br i1 %t303, label %bb86, label %bb87
bb86:
  br label %bb92
bb87:
  br label %bb88
bb88:
  %t305 = load ptr, ptr %l26, !tbaa !29
  %t306 = load i64, ptr %l27, !tbaa !24
  %t309 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t305, i64 %t306)
  store { i64, ptr } %t309, ptr %l185
  br label %bb89
bb89:
  %t310 = load { i64, ptr }, ptr %l185, !tbaa !27
  %t311 = load ptr, ptr %l25, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t311, { i64, ptr } %t310)
  br label %bb90
bb90:
  br label %bb91
bb91:
  %t315 = load i64, ptr %l27, !tbaa !24
  %t318 = add i64 %t315, 1
  store i64 %t318, ptr %l27, !tbaa !24
  br label %bb84
bb92:
  %t320 = load ptr, ptr %l25, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t320, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d194, i32 0, i32 1) })
  br label %bb93
bb93:
  %t322 = load i1, ptr %l3, !tbaa !21
  br i1 %t322, label %bb94, label %bb95
bb94:
  %t324 = load ptr, ptr %l25, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t324, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d195, i32 0, i32 1) })
  br label %bb96
bb95:
  br label %bb97
bb96:
  br label %bb97
bb97:
  %t326 = call ptr @__olang_scope_hold(ptr %s0)
  %t327 = ptrtoint ptr %t326 to i64
  store i64 %t327, ptr %l194, !tbaa !24
  %t328 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_204_3e_2e_2d1
  br i1 %t328, label %bb98, label %bb99
bb98:
  %t330 = call ptr @__olang_region_make(ptr %s0)
  %t331 = ptrtoint ptr %t330 to i64
  store i64 %t331, ptr %l194, !tbaa !24
  br label %bb99
bb99:
  %t332 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t332, ptr %l196, !tbaa !27
  %t333 = load i64, ptr %l22, !tbaa !24
  store i64 %t333, ptr %l197, !tbaa !24
  %t334 = load i1, ptr %l3, !tbaa !21
  br i1 %t334, label %bb100, label %bb101
bb100:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d196, i32 0, i32 1) }, ptr %l199, !tbaa !27
  br label %bb102
bb101:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d197, i32 0, i32 1) }, ptr %l199, !tbaa !27
  br label %bb102
bb102:
  %t336 = load { i64, ptr }, ptr %l196, !tbaa !27
  %t337 = extractvalue { i64, ptr } %t336, 1
  %t338 = extractvalue { i64, ptr } %t336, 0
  %t339 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d198, i32 0, i32 1) }, 1
  %t340 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d198, i32 0, i32 1) }, 0
  %t341 = add i64 %t338, %t340
  %t342 = load i64, ptr %l197, !tbaa !24
  %t343 = call i64 @__olang_fmt_i64(ptr null, i64 %t342)
  %t344 = add i64 %t341, %t343
  %t345 = load { i64, ptr }, ptr %l199, !tbaa !27
  %t346 = extractvalue { i64, ptr } %t345, 1
  %t347 = extractvalue { i64, ptr } %t345, 0
  %t348 = add i64 %t344, %t347
  %t349 = load i64, ptr %l194
  %t350 = inttoptr i64 %t349 to ptr
  %t351 = call ptr @__olang_held_alloc(ptr %t350, i64 %t348)
  call void @olang_textcopy(ptr %t351, ptr %t337, i64 %t338)
  %t352 = getelementptr i8, ptr %t351, i64 %t338
  call void @olang_textcopy(ptr %t352, ptr %t339, i64 %t340)
  %t353 = getelementptr i8, ptr %t352, i64 %t340
  %t354 = call i64 @__olang_fmt_i64(ptr %t353, i64 %t342)
  %t355 = getelementptr i8, ptr %t353, i64 %t343
  call void @olang_textcopy(ptr %t355, ptr %t346, i64 %t347)
  %t356 = insertvalue { i64, ptr } undef, i64 %t348, 0
  %t357 = insertvalue { i64, ptr } %t356, ptr %t351, 1
  store { i64, ptr } %t357, ptr %l201, !tbaa !27
  %t359 = load ptr, ptr %lp24
  %t360 = load { i64, ptr }, ptr %t359, !tbaa !27
  store { i64, ptr } %t360, ptr %l202, !tbaa !27
  %t361 = call ptr @__olang_scope_hold(ptr %s0)
  %t362 = ptrtoint ptr %t361 to i64
  store i64 %t362, ptr %l203, !tbaa !24
  %t363 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_204_3e_2e_2d1
  br i1 %t363, label %bb103, label %bb104
bb103:
  %t365 = call ptr @__olang_region_make(ptr %s0)
  %t366 = ptrtoint ptr %t365 to i64
  store i64 %t366, ptr %l203, !tbaa !24
  br label %bb104
bb104:
  %t367 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t368 = load i64, ptr %l22, !tbaa !24
  %t369 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d199, i32 0, i32 1) }, 1
  %t370 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d199, i32 0, i32 1) }, 0
  %t372 = extractvalue { i64, ptr } %t367, 1
  %t373 = extractvalue { i64, ptr } %t367, 0
  %t374 = add i64 %t370, %t373
  %t375 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d200, i32 0, i32 1) }, 1
  %t376 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d200, i32 0, i32 1) }, 0
  %t377 = add i64 %t374, %t376
  %t379 = call i64 @__olang_fmt_i64(ptr null, i64 %t368)
  %t380 = add i64 %t377, %t379
  %t381 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d201, i32 0, i32 1) }, 1
  %t382 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d201, i32 0, i32 1) }, 0
  %t383 = add i64 %t380, %t382
  %t384 = load i64, ptr %l203
  %t385 = inttoptr i64 %t384 to ptr
  %t386 = call ptr @__olang_held_alloc(ptr %t385, i64 %t383)
  call void @olang_textcopy(ptr %t386, ptr %t369, i64 %t370)
  %t387 = getelementptr i8, ptr %t386, i64 %t370
  call void @olang_textcopy(ptr %t387, ptr %t372, i64 %t373)
  %t388 = getelementptr i8, ptr %t387, i64 %t373
  call void @olang_textcopy(ptr %t388, ptr %t375, i64 %t376)
  %t389 = getelementptr i8, ptr %t388, i64 %t376
  %t390 = call i64 @__olang_fmt_i64(ptr %t389, i64 %t368)
  %t391 = getelementptr i8, ptr %t389, i64 %t379
  call void @olang_textcopy(ptr %t391, ptr %t381, i64 %t382)
  %t392 = insertvalue { i64, ptr } undef, i64 %t383, 0
  %t393 = insertvalue { i64, ptr } %t392, ptr %t386, 1
  %t395 = insertvalue [4 x { i64, ptr }] undef, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d202, i32 0, i32 1) }, 0
  %t396 = load { i64, ptr }, ptr %l201, !tbaa !27
  %t397 = insertvalue [4 x { i64, ptr }] %t395, { i64, ptr } %t396, 1
  %t398 = load { i64, ptr }, ptr %l202, !tbaa !27
  %t399 = insertvalue [4 x { i64, ptr }] %t397, { i64, ptr } %t398, 2
  %t401 = insertvalue [4 x { i64, ptr }] %t399, { i64, ptr } %t393, 3
  %t403 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 64, i64 8)
  store [4 x { i64, ptr }] %t401, ptr %t403
  store ptr %t403, ptr %l29
  store i64 0, ptr %l30, !tbaa !24
  %t405 = load ptr, ptr %l29
  store i64 4, ptr %l31, !tbaa !24
  br label %bb105
bb105:
  %t408 = load i64, ptr %l30, !tbaa !24
  %t409 = load i64, ptr %l31, !tbaa !24
  %t412 = icmp slt i64 %t408, %t409
  %t414 = xor i1 %t412, true
  br i1 %t414, label %bb106, label %bb107
bb106:
  br label %bb111
bb107:
  br label %bb108
bb108:
  %t416 = load ptr, ptr %l29
  %t417 = load i64, ptr %l30, !tbaa !24
  %t420 = getelementptr [4 x { i64, ptr }], ptr %t416, i64 0, i64 %t417
  %t421 = load { i64, ptr }, ptr %t420, !tbaa !37
  %t423 = load ptr, ptr %l25, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t423, { i64, ptr } %t421)
  br label %bb109
bb109:
  br label %bb110
bb110:
  %t427 = load i64, ptr %l30, !tbaa !24
  %t430 = add i64 %t427, 1
  store i64 %t430, ptr %l30, !tbaa !24
  br label %bb105
bb111:
  store ptr %l18, ptr %l225, !tbaa !29
  %t432 = call ptr @__olang_scope_hold(ptr %s0)
  %t433 = ptrtoint ptr %t432 to i64
  store i64 %t433, ptr %l226, !tbaa !24
  %t434 = load i1, ptr @olang_2esole_2eArray_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2e_2d1
  br i1 %t434, label %bb112, label %bb113
bb112:
  %t436 = call ptr @__olang_region_make(ptr %s0)
  %t437 = ptrtoint ptr %t436 to i64
  store i64 %t437, ptr %l226, !tbaa !24
  br label %bb113
bb113:
  %t438 = load ptr, ptr %l25, !tbaa !29
  %t439 = load i64, ptr %l226
  %t440 = inttoptr i64 %t439 to ptr
  %t442 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %s0, ptr %t440, ptr %t438)
  store { i64, ptr } %t442, ptr %l229
  br label %bb114
bb114:
  %t443 = load ptr, ptr %l225, !tbaa !29
  %t444 = load { i64, ptr }, ptr %l229, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s0, ptr %s0, ptr %t443, { i64, ptr } %t444)
  br label %bb115
bb115:
  %t445 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t447 = extractvalue { i64, ptr } %t445, 0
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l19, i64 %t447)
  br label %bb116
bb116:
  br label %bb117
bb117:
  %t450 = load i64, ptr %l21, !tbaa !24
  %t453 = add i64 %t450, 1
  store i64 %t453, ptr %l21, !tbaa !24
  br label %bb67
bb118:
  %t456 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s0, ptr %s0, ptr %l18)
  store { i64, ptr } %t456, ptr %l237
  br label %bb119
bb119:
  %t457 = load ptr, ptr %l0, !tbaa !29
  %t459 = call i64 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewidth(ptr %v0, ptr %t457)
  store i64 %t459, ptr %l239
  br label %bb120
bb120:
  %t461 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %s0, ptr %l19)
  store { i64, ptr } %t461, ptr %l241
  br label %bb121
bb121:
  %t462 = load { i64, ptr }, ptr %l237, !tbaa !27
  %t463 = load i64, ptr %l239, !tbaa !24
  %t464 = load { i64, ptr }, ptr %l241, !tbaa !27
  %t465 = call { { i64, ptr }, { i64, ptr } } @compiler_2fbuild_2eRunAll(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t462, i64 %t463, { i64, ptr } %t464)
  store { { i64, ptr }, { i64, ptr } } %t465, ptr %l242
  br label %bb122
bb122:
  %t466 = load { { i64, ptr }, { i64, ptr } }, ptr %l242
  store { { i64, ptr }, { i64, ptr } } %t466, ptr %l33
  %t467 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l33, i32 0, i32 0
  %t468 = load { i64, ptr }, ptr %t467, !tbaa !27
  store { i64, ptr } %t468, ptr %l243, !tbaa !27
  %t469 = load { i64, ptr }, ptr %l243, !tbaa !27
  %t470 = extractvalue { i64, ptr } %t469, 0
  store i64 %t470, ptr %l244, !tbaa !24
  %t471 = load i64, ptr %l244, !tbaa !24
  %t472 = mul i64 %t471, 4
  %t473 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t472)
  %t474 = insertvalue { i64, ptr } undef, i64 %t471, 0
  %t475 = insertvalue { i64, ptr } %t474, ptr %t473, 1
  store { i64, ptr } %t475, ptr %l245, !tbaa !27
  %t476 = getelementptr { i64, ptr }, ptr %l245, i32 0, i32 1
  %t477 = load ptr, ptr %t476, !tbaa !27
  %t478 = getelementptr { i64, ptr }, ptr %l243, i32 0, i32 1
  %t479 = load ptr, ptr %t478, !tbaa !27
  %t480 = load i64, ptr %l244, !tbaa !24
  %t481 = mul i64 %t480, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t477, ptr %t479, i64 %t481, i1 false)
  %t482 = load { i64, ptr }, ptr %l245, !tbaa !27
  store { i64, ptr } %t482, ptr %l34, !tbaa !27
  %t483 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l33, i32 0, i32 1
  %t484 = load { i64, ptr }, ptr %t483, !tbaa !27
  store { i64, ptr } %t484, ptr %l246, !tbaa !27
  %t485 = load { i64, ptr }, ptr %l246, !tbaa !27
  %t486 = extractvalue { i64, ptr } %t485, 0
  store i64 %t486, ptr %l247, !tbaa !24
  %t487 = load i64, ptr %l247, !tbaa !24
  %t488 = mul i64 %t487, 16
  %t489 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t488)
  %t490 = insertvalue { i64, ptr } undef, i64 %t487, 0
  %t491 = insertvalue { i64, ptr } %t490, ptr %t489, 1
  store { i64, ptr } %t491, ptr %l248, !tbaa !27
  %t492 = getelementptr { i64, ptr }, ptr %l248, i32 0, i32 1
  %t493 = load ptr, ptr %t492, !tbaa !27
  %t494 = getelementptr { i64, ptr }, ptr %l246, i32 0, i32 1
  %t495 = load ptr, ptr %t494, !tbaa !27
  %t496 = load i64, ptr %l247, !tbaa !24
  %t497 = mul i64 %t496, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t493, ptr %t495, i64 %t497, i1 false)
  %t498 = load { i64, ptr }, ptr %l248, !tbaa !27
  store { i64, ptr } %t498, ptr %l35, !tbaa !27
  %t499 = load ptr, ptr %l0, !tbaa !29
  store ptr %t499, ptr %l249, !tbaa !29
  %t500 = load ptr, ptr %l249, !tbaa !29
  %t501 = getelementptr %"compiler/build:Config", ptr %t500, i32 0, i32 36
  %t502 = load i64, ptr %t501, !tbaa !24
  store i64 %t502, ptr %l250, !tbaa !24
  %t504 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H2ab12f44ffbd18d099d1f5a69642975a(ptr %s0, ptr %l18)
  store i64 %t504, ptr %l252
  br label %bb123
bb123:
  %t505 = load i64, ptr %l250, !tbaa !24
  %t506 = load i64, ptr %l252, !tbaa !24
  %t507 = add i64 %t505, %t506
  %t509 = load ptr, ptr %l249, !tbaa !29
  %t510 = getelementptr %"compiler/build:Config", ptr %t509, i32 0, i32 36
  store i64 %t507, ptr %t510, !tbaa !24
  store i64 0, ptr %l36, !tbaa !24
  %t511 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t513 = extractvalue { i64, ptr } %t511, 0
  store i64 %t513, ptr %l37, !tbaa !24
  store i64 1, ptr %l38, !tbaa !24
  %t515 = load i64, ptr %l37, !tbaa !24
  %t516 = load i64, ptr %l36, !tbaa !24
  %t519 = icmp sgt i64 %t515, %t516
  br i1 %t519, label %bb124, label %bb125
bb124:
  %t521 = load i64, ptr %l38, !tbaa !24
  %t523 = icmp sgt i64 %t521, 0
  br i1 %t523, label %bb126, label %bb127
bb125:
  store i64 0, ptr %l259, !tbaa !24
  br label %bb129
bb126:
  %t525 = load i64, ptr %l37, !tbaa !24
  %t526 = load i64, ptr %l36, !tbaa !24
  %t529 = sub i64 %t525, %t526
  %t530 = load i64, ptr %l38, !tbaa !24
  %t533 = add i64 %t529, %t530
  %t535 = sub i64 %t533, 1
  %t536 = load i64, ptr %l38, !tbaa !24
  %t539 = sdiv i64 %t535, %t536
  store i64 %t539, ptr %l262, !tbaa !24
  br label %bb128
bb127:
  store i64 0, ptr %l262, !tbaa !24
  br label %bb128
bb128:
  %t541 = load i64, ptr %l262, !tbaa !24
  store i64 %t541, ptr %l259, !tbaa !24
  br label %bb129
bb129:
  %t542 = load i64, ptr %l259, !tbaa !24
  store i64 %t542, ptr %l39, !tbaa !24
  store i64 0, ptr %l40, !tbaa !24
  br label %bb130
bb130:
  store %olang.scope zeroinitializer, ptr %s31
  %t543 = load i64, ptr %l40, !tbaa !24
  %t544 = load i64, ptr %l39, !tbaa !24
  %t547 = icmp slt i64 %t543, %t544
  %t549 = xor i1 %t547, true
  br i1 %t549, label %bb131, label %bb132
bb131:
  call void @__olang_scope_close(ptr %s31)
  br label %bb141
bb132:
  br label %bb133
bb133:
  %t551 = load i64, ptr %l36, !tbaa !24
  %t552 = load i64, ptr %l40, !tbaa !24
  %t553 = load i64, ptr %l38, !tbaa !24
  %t556 = mul i64 %t552, %t553
  %t559 = add i64 %t551, %t556
  store i64 %t559, ptr %l41, !tbaa !24
  %t561 = load i64, ptr %l41, !tbaa !24
  %t563 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t564 = load ptr, ptr %t563, !tbaa !27
  %t565 = getelementptr i32, ptr %t564, i64 %t561
  %t566 = load i32, ptr %t565, !tbaa !33
  %t568 = icmp eq i32 %t566, 0
  br i1 %t568, label %bb134, label %bb135
bb134:
  call void @__olang_scope_close(ptr %s31)
  br label %bb140
bb135:
  br label %bb136
bb136:
  %t570 = load i64, ptr %l41, !tbaa !24
  %t572 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t573 = load ptr, ptr %t572, !tbaa !27
  %t574 = getelementptr { i64, ptr }, ptr %t573, i64 %t570
  %t575 = load { i64, ptr }, ptr %t574, !tbaa !37
  call void @compiler_2fbuild_2esayErr(ptr %s0, { i64, ptr } %t575)
  br label %bb137
bb137:
  %t577 = load ptr, ptr %l5, !tbaa !29
  store ptr %t577, ptr %l285, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t578
  %t579 = getelementptr { i64, [3 x i64] }, ptr %t578, i32 0, i32 0
  store i64 0, ptr %t579
  %t580 = load { i64, [3 x i64] }, ptr %t578
  store { i64, [3 x i64] } %t580, ptr %l286
  %t581 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t582 = load i64, ptr %l41, !tbaa !24
  %t584 = extractvalue { i64, ptr } %t581, 1
  %t585 = extractvalue { i64, ptr } %t581, 0
  %t586 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d203, i32 0, i32 1) }, 1
  %t587 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d203, i32 0, i32 1) }, 0
  %t588 = add i64 %t585, %t587
  %t590 = call i64 @__olang_fmt_i64(ptr null, i64 %t582)
  %t591 = add i64 %t588, %t590
  %t592 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d204, i32 0, i32 1) }, 1
  %t593 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d204, i32 0, i32 1) }, 0
  %t594 = add i64 %t591, %t593
  %t595 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t594)
  call void @olang_textcopy(ptr %t595, ptr %t584, i64 %t585)
  %t596 = getelementptr i8, ptr %t595, i64 %t585
  call void @olang_textcopy(ptr %t596, ptr %t586, i64 %t587)
  %t597 = getelementptr i8, ptr %t596, i64 %t587
  %t598 = call i64 @__olang_fmt_i64(ptr %t597, i64 %t582)
  %t599 = getelementptr i8, ptr %t597, i64 %t590
  call void @olang_textcopy(ptr %t599, ptr %t592, i64 %t593)
  %t600 = insertvalue { i64, ptr } undef, i64 %t594, 0
  %t601 = insertvalue { i64, ptr } %t600, ptr %t595, 1
  %t604 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eClangFailed(ptr %s31, ptr %v4, { i64, ptr } %t601)
  store %"compiler/diagmsg:Msg" %t604, ptr %l291
  br label %bb138
bb138:
  %t605 = load ptr, ptr %l285, !tbaa !29
  %t606 = load { i64, [3 x i64] }, ptr %l286
  %t607 = load %"compiler/diagmsg:Msg", ptr %l291
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v4, ptr %v4, ptr %t605, { i64, [3 x i64] } %t606, %"compiler/diagmsg:Msg" %t607)
  br label %bb139
bb139:
  call void @__olang_scope_close(ptr %s31)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb140:
  %t609 = load i64, ptr %l40, !tbaa !24
  %t612 = add i64 %t609, 1
  store i64 %t612, ptr %l40, !tbaa !24
  br label %bb130
bb141:
  store i64 0, ptr %l42, !tbaa !24
  %t615 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l6)
  store i64 %t615, ptr %l297
  br label %bb142
bb142:
  %t616 = load i64, ptr %l297, !tbaa !24
  store i64 %t616, ptr %l43, !tbaa !24
  store i64 1, ptr %l44, !tbaa !24
  %t617 = load i64, ptr %l43, !tbaa !24
  %t618 = load i64, ptr %l42, !tbaa !24
  %t621 = icmp sgt i64 %t617, %t618
  br i1 %t621, label %bb143, label %bb144
bb143:
  %t623 = load i64, ptr %l44, !tbaa !24
  %t625 = icmp sgt i64 %t623, 0
  br i1 %t625, label %bb145, label %bb146
bb144:
  store i64 0, ptr %l301, !tbaa !24
  br label %bb148
bb145:
  %t627 = load i64, ptr %l43, !tbaa !24
  %t628 = load i64, ptr %l42, !tbaa !24
  %t631 = sub i64 %t627, %t628
  %t632 = load i64, ptr %l44, !tbaa !24
  %t635 = add i64 %t631, %t632
  %t637 = sub i64 %t635, 1
  %t638 = load i64, ptr %l44, !tbaa !24
  %t641 = sdiv i64 %t637, %t638
  store i64 %t641, ptr %l304, !tbaa !24
  br label %bb147
bb146:
  store i64 0, ptr %l304, !tbaa !24
  br label %bb147
bb147:
  %t643 = load i64, ptr %l304, !tbaa !24
  store i64 %t643, ptr %l301, !tbaa !24
  br label %bb148
bb148:
  %t644 = load i64, ptr %l301, !tbaa !24
  store i64 %t644, ptr %l45, !tbaa !24
  store i64 0, ptr %l46, !tbaa !24
  br label %bb149
bb149:
  store %olang.scope zeroinitializer, ptr %s36
  %t645 = load i64, ptr %l46, !tbaa !24
  %t646 = load i64, ptr %l45, !tbaa !24
  %t649 = icmp slt i64 %t645, %t646
  %t651 = xor i1 %t649, true
  br i1 %t651, label %bb150, label %bb151
bb150:
  call void @__olang_scope_close(ptr %s36)
  br label %bb160
bb151:
  br label %bb152
bb152:
  %t653 = load i64, ptr %l42, !tbaa !24
  %t654 = load i64, ptr %l46, !tbaa !24
  %t655 = load i64, ptr %l44, !tbaa !24
  %t658 = mul i64 %t654, %t655
  %t661 = add i64 %t653, %t658
  %t663 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t666 = extractvalue { i64, ptr } %t663, 1
  %t667 = extractvalue { i64, ptr } %t663, 0
  %t668 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d205, i32 0, i32 1) }, 1
  %t669 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d205, i32 0, i32 1) }, 0
  %t670 = add i64 %t667, %t669
  %t672 = call i64 @__olang_fmt_i64(ptr null, i64 %t661)
  %t673 = add i64 %t670, %t672
  %t674 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d206, i32 0, i32 1) }, 1
  %t675 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d206, i32 0, i32 1) }, 0
  %t676 = add i64 %t673, %t675
  %t677 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t676)
  call void @olang_textcopy(ptr %t677, ptr %t666, i64 %t667)
  %t678 = getelementptr i8, ptr %t677, i64 %t667
  call void @olang_textcopy(ptr %t678, ptr %t668, i64 %t669)
  %t679 = getelementptr i8, ptr %t678, i64 %t669
  %t680 = call i64 @__olang_fmt_i64(ptr %t679, i64 %t661)
  %t681 = getelementptr i8, ptr %t679, i64 %t672
  call void @olang_textcopy(ptr %t681, ptr %t674, i64 %t675)
  %t682 = insertvalue { i64, ptr } undef, i64 %t676, 0
  %t683 = insertvalue { i64, ptr } %t682, ptr %t677, 1
  %t686 = call i32 @std_2fos_2eRemove(ptr %s36, { i64, ptr } %t683)
  store i32 %t686, ptr %l326
  %t687 = icmp ne i32 %t686, 0
  br i1 %t687, label %bb154, label %ok.688, !prof !99
ok.688:
  br label %bb153
bb153:
  br label %bb158
bb154:
  %t689 = load i32, ptr %l326, !tbaa !23
  %t690 = ashr i32 %t689, 16
  %t692 = icmp eq i32 %t690, 1
  store i1 %t692, ptr %l328, !tbaa !21
  %t693 = load i32, ptr %l326, !tbaa !23
  %t694 = ashr i32 %t693, 16
  %t696 = icmp eq i32 %t694, 1
  br i1 %t696, label %bb155, label %bb156
bb155:
  call void @__olang_errpay_pop()
  br label %bb156
bb156:
  br label %bb157
bb157:
  br label %bb158
bb158:
  call void @__olang_scope_close(ptr %s36)
  br label %bb159
bb159:
  %t698 = load i64, ptr %l46, !tbaa !24
  %t701 = add i64 %t698, 1
  store i64 %t701, ptr %l46, !tbaa !24
  br label %bb149
bb160:
  %t703 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t705 = extractvalue { i64, ptr } %t703, 1
  %t706 = extractvalue { i64, ptr } %t703, 0
  %t707 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d207, i32 0, i32 1) }, 1
  %t708 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d207, i32 0, i32 1) }, 0
  %t709 = add i64 %t706, %t708
  %t710 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t709)
  call void @olang_textcopy(ptr %t710, ptr %t705, i64 %t706)
  %t711 = getelementptr i8, ptr %t710, i64 %t706
  call void @olang_textcopy(ptr %t711, ptr %t707, i64 %t708)
  %t712 = insertvalue { i64, ptr } undef, i64 %t709, 0
  %t713 = insertvalue { i64, ptr } %t712, ptr %t710, 1
  %t715 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t717 = extractvalue { i64, ptr } %t715, 1
  %t718 = extractvalue { i64, ptr } %t715, 0
  %t719 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d208, i32 0, i32 1) }, 1
  %t720 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d208, i32 0, i32 1) }, 0
  %t721 = add i64 %t718, %t720
  %t722 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t721)
  call void @olang_textcopy(ptr %t722, ptr %t717, i64 %t718)
  %t723 = getelementptr i8, ptr %t722, i64 %t718
  call void @olang_textcopy(ptr %t723, ptr %t719, i64 %t720)
  %t724 = insertvalue { i64, ptr } undef, i64 %t721, 0
  %t725 = insertvalue { i64, ptr } %t724, ptr %t722, 1
  %t728 = extractvalue { i64, ptr } %t725, 0
  %t729 = extractvalue { i64, ptr } %t725, 1
  %t730 = mul i64 %t728, 1
  %t731 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t730)
  call void @llvm.memcpy.p0.p0.i64(ptr %t731, ptr %t729, i64 %t730, i1 false)
  %t732 = insertvalue { i64, ptr } undef, i64 %t728, 0
  %t733 = insertvalue { i64, ptr } %t732, ptr %t731, 1
  %t736 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s0, { i64, ptr } %t713, { i64, ptr } %t733)
  store i32 %t736, ptr %l341
  %t737 = icmp ne i32 %t736, 0
  br i1 %t737, label %bb162, label %ok.738, !prof !99
ok.738:
  br label %bb161
bb161:
  br label %bb166
bb162:
  %t739 = load i32, ptr %l341, !tbaa !23
  %t740 = ashr i32 %t739, 16
  %t742 = icmp eq i32 %t740, 1
  store i1 %t742, ptr %l343, !tbaa !21
  %t743 = load i32, ptr %l341, !tbaa !23
  %t744 = ashr i32 %t743, 16
  %t746 = icmp eq i32 %t744, 1
  br i1 %t746, label %bb163, label %bb164
bb163:
  call void @__olang_errpay_pop()
  br label %bb164
bb164:
  br label %bb165
bb165:
  br label %bb166
bb166:
  %t748 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t749 = load i1, ptr %l3, !tbaa !21
  %t750 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fbuild_2elistFiles(ptr %v2, ptr %v3, { i64, ptr } %t748, i1 %t749, ptr %t750)
  br label %bb167
bb167:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l21 = alloca i1
  %l23 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 6
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d209, i32 0, i32 1) }, ptr %l3, !tbaa !27
  br label %bb3
bb2:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d210, i32 0, i32 1) }, ptr %l3, !tbaa !27
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/build:Config", ptr %t6, i32 0, i32 4
  %t9 = load i1, ptr %t8, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d211, i32 0, i32 1) }, ptr %l6, !tbaa !27
  br label %bb6
bb5:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d212, i32 0, i32 1) }, ptr %l6, !tbaa !27
  br label %bb6
bb6:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/build:Config", ptr %t11, i32 0, i32 5
  %t14 = load i1, ptr %t13, !tbaa !21
  br i1 %t14, label %bb7, label %bb8
bb7:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d213, i32 0, i32 1) }, ptr %l9, !tbaa !27
  br label %bb9
bb8:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d214, i32 0, i32 1) }, ptr %l9, !tbaa !27
  br label %bb9
bb9:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/build:Config", ptr %t16, i32 0, i32 7
  %t19 = load i1, ptr %t18, !tbaa !21
  br i1 %t19, label %bb10, label %bb11
bb10:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d215, i32 0, i32 1) }, ptr %l12, !tbaa !27
  br label %bb12
bb11:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d216, i32 0, i32 1) }, ptr %l12, !tbaa !27
  br label %bb12
bb12:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/build:Config", ptr %t21, i32 0, i32 11
  %t24 = load i1, ptr %t23, !tbaa !21
  br i1 %t24, label %bb13, label %bb14
bb13:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d217, i32 0, i32 1) }, ptr %l15, !tbaa !27
  br label %bb15
bb14:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d218, i32 0, i32 1) }, ptr %l15, !tbaa !27
  br label %bb15
bb15:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/build:Config", ptr %t26, i32 0, i32 14
  %t29 = load i1, ptr %t28, !tbaa !21
  br i1 %t29, label %bb16, label %bb17
bb16:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d219, i32 0, i32 1) }, ptr %l18, !tbaa !27
  br label %bb18
bb17:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d220, i32 0, i32 1) }, ptr %l18, !tbaa !27
  br label %bb18
bb18:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/build:Config", ptr %t31, i32 0, i32 16
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  %t36 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t34, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d221, i32 0, i32 1) })
  store i1 %t36, ptr %l21
  br label %bb19
bb19:
  %t37 = load i1, ptr %l21, !tbaa !21
  %t38 = xor i1 %t37, true
  br i1 %t38, label %bb20, label %bb21
bb20:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d222, i32 0, i32 1) }, ptr %l23, !tbaa !27
  br label %bb22
bb21:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d223, i32 0, i32 1) }, ptr %l23, !tbaa !27
  br label %bb22
bb22:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/build:Config", ptr %t40, i32 0, i32 18
  %t43 = load i1, ptr %t42, !tbaa !21
  br i1 %t43, label %bb23, label %bb24
bb23:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d224, i32 0, i32 1) }, ptr %l26, !tbaa !27
  br label %bb25
bb24:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d225, i32 0, i32 1) }, ptr %l26, !tbaa !27
  br label %bb25
bb25:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/build:Config", ptr %t45, i32 0, i32 22
  %t48 = load i1, ptr %t47, !tbaa !21
  br i1 %t48, label %bb26, label %bb27
bb26:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d226, i32 0, i32 1) }, ptr %l29, !tbaa !27
  br label %bb28
bb27:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d227, i32 0, i32 1) }, ptr %l29, !tbaa !27
  br label %bb28
bb28:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/build:Config", ptr %t50, i32 0, i32 19
  %t53 = load i1, ptr %t52, !tbaa !21
  br i1 %t53, label %bb29, label %bb30
bb29:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d228, i32 0, i32 1) }, ptr %l32, !tbaa !27
  br label %bb31
bb30:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d229, i32 0, i32 1) }, ptr %l32, !tbaa !27
  br label %bb31
bb31:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/build:Config", ptr %t55, i32 0, i32 26
  %t58 = load i1, ptr %t57, !tbaa !21
  br i1 %t58, label %bb32, label %bb33
bb32:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d230, i32 0, i32 1) }, ptr %l35, !tbaa !27
  br label %bb34
bb33:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d231, i32 0, i32 1) }, ptr %l35, !tbaa !27
  br label %bb34
bb34:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/build:Config", ptr %t60, i32 0, i32 10
  %t63 = load i1, ptr %t62, !tbaa !21
  br i1 %t63, label %bb35, label %bb36
bb35:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d232, i32 0, i32 1) }, ptr %l38, !tbaa !27
  br label %bb37
bb36:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d233, i32 0, i32 1) }, ptr %l38, !tbaa !27
  br label %bb37
bb37:
  %t65 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 1
  %t67 = extractvalue { i64, ptr } %t65, 0
  %t68 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 1
  %t70 = extractvalue { i64, ptr } %t68, 0
  %t71 = add i64 %t67, %t70
  %t72 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t72, 1
  %t74 = extractvalue { i64, ptr } %t72, 0
  %t75 = add i64 %t71, %t74
  %t76 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t76, 1
  %t78 = extractvalue { i64, ptr } %t76, 0
  %t79 = add i64 %t75, %t78
  %t80 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 1
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t83 = add i64 %t79, %t82
  %t84 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t84, 1
  %t86 = extractvalue { i64, ptr } %t84, 0
  %t87 = add i64 %t83, %t86
  %t88 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t88, 1
  %t90 = extractvalue { i64, ptr } %t88, 0
  %t91 = add i64 %t87, %t90
  %t92 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 1
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t95 = add i64 %t91, %t94
  %t96 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t96, 1
  %t98 = extractvalue { i64, ptr } %t96, 0
  %t99 = add i64 %t95, %t98
  %t100 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 1
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t103 = add i64 %t99, %t102
  %t104 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 1
  %t106 = extractvalue { i64, ptr } %t104, 0
  %t107 = add i64 %t103, %t106
  %t108 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t108, 1
  %t110 = extractvalue { i64, ptr } %t108, 0
  %t111 = add i64 %t107, %t110
  %t112 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t111)
  call void @olang_textcopy(ptr %t112, ptr %t66, i64 %t67)
  %t113 = getelementptr i8, ptr %t112, i64 %t67
  call void @olang_textcopy(ptr %t113, ptr %t69, i64 %t70)
  %t114 = getelementptr i8, ptr %t113, i64 %t70
  call void @olang_textcopy(ptr %t114, ptr %t73, i64 %t74)
  %t115 = getelementptr i8, ptr %t114, i64 %t74
  call void @olang_textcopy(ptr %t115, ptr %t77, i64 %t78)
  %t116 = getelementptr i8, ptr %t115, i64 %t78
  call void @olang_textcopy(ptr %t116, ptr %t81, i64 %t82)
  %t117 = getelementptr i8, ptr %t116, i64 %t82
  call void @olang_textcopy(ptr %t117, ptr %t85, i64 %t86)
  %t118 = getelementptr i8, ptr %t117, i64 %t86
  call void @olang_textcopy(ptr %t118, ptr %t89, i64 %t90)
  %t119 = getelementptr i8, ptr %t118, i64 %t90
  call void @olang_textcopy(ptr %t119, ptr %t93, i64 %t94)
  %t120 = getelementptr i8, ptr %t119, i64 %t94
  call void @olang_textcopy(ptr %t120, ptr %t97, i64 %t98)
  %t121 = getelementptr i8, ptr %t120, i64 %t98
  call void @olang_textcopy(ptr %t121, ptr %t101, i64 %t102)
  %t122 = getelementptr i8, ptr %t121, i64 %t102
  call void @olang_textcopy(ptr %t122, ptr %t105, i64 %t106)
  %t123 = getelementptr i8, ptr %t122, i64 %t106
  call void @olang_textcopy(ptr %t123, ptr %t109, i64 %t110)
  %t124 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t112, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t125, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eobjects(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/build:Unit"
  %lp7 = alloca ptr
  %lp8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca %"compiler/build:Unit"
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %lp16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca %"compiler/build:Unit"
  %l22 = alloca { i64, ptr }
  %l25 = alloca i64
  %l27 = alloca i64
  %l32 = alloca %"compiler/build:Unit"
  %l33 = alloca i64
  %l35 = alloca i64
  %l40 = alloca ptr
  %l44 = alloca i1
  %l48 = alloca i1
  %l52 = alloca i1
  %l56 = alloca %"compiler/build:compiles"
  %l57 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l60 = alloca { i64, ptr }
  %l63 = alloca i64
  %l65 = alloca i64
  %l71 = alloca %"compiler/build:Unit"
  %l72 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l75 = alloca i32
  %l77 = alloca i1
  %l80 = alloca { i64, ptr }
  %l81 = alloca %"compiler/diagmsg:Msg"
  %l84 = alloca ptr
  %l85 = alloca i64
  %l87 = alloca { i64, ptr }
  %l88 = alloca ptr
  %l89 = alloca ptr
  %l91 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l100 = alloca i32
  %l108 = alloca i64
  %l111 = alloca i1
  %l113 = alloca ptr
  %l114 = alloca i64
  %l116 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l125 = alloca i32
  %l130 = alloca i1
  %l132 = alloca ptr
  %l133 = alloca i64
  %l135 = alloca { i64, ptr }
  %l144 = alloca { i64, ptr }
  %l145 = alloca i32
  %l151 = alloca i32
  %l154 = alloca i64
  %l156 = alloca %"compiler/build:compiles"
  %l158 = alloca i64
  %l160 = alloca i64
  %l165 = alloca i64
  %l170 = alloca i1
  %l173 = alloca i1
  %l175 = alloca { i64, ptr }
  %l178 = alloca { i64, ptr }
  %l181 = alloca { i64, ptr }
  %l183 = alloca i1
  %l185 = alloca i1
  %l189 = alloca i1
  %l191 = alloca i32
  %l193 = alloca i1
  %l200 = alloca %"compiler/build:Unit"
  %l201 = alloca { i64, ptr }
  %l203 = alloca { i64, ptr }
  %l204 = alloca i32
  %l206 = alloca i1
  %l209 = alloca { i64, ptr }
  %l210 = alloca %"compiler/diagmsg:Msg"
  %l213 = alloca { i64, ptr }
  %l214 = alloca ptr
  %l215 = alloca ptr
  %l217 = alloca { i64, ptr }
  %l223 = alloca { i64, ptr }
  %l224 = alloca i32
  %l229 = alloca { i64, ptr }
  %l236 = alloca { i64, ptr }
  %l237 = alloca i32
  %l239 = alloca { i64, ptr }
  %l246 = alloca { i64, ptr }
  %l247 = alloca i32
  %l255 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %rv = alloca { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
  %t66 = alloca %"compiler/build:compiles", align 8
  %t344 = alloca %"compiler/build:compiles", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l3, !tbaa !24
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/build:Program", ptr %t1, i32 0, i32 0
  store ptr %t3, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load i64, ptr %l5, !tbaa !24
  store i64 %t5, ptr %l25, !tbaa !24
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v1, ptr %t6)
  store i64 %t8, ptr %l27
  br label %bb2
bb2:
  %t9 = load i64, ptr %l25, !tbaa !24
  %t10 = load i64, ptr %l27, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l4, !tbaa !29
  %t16 = load i64, ptr %l5, !tbaa !24
  %t19 = call %"compiler/build:Unit" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eAt_3ccompiler_2fbuild_3aUnit_3e(ptr %v1, ptr %v1, ptr %t15, i64 %t16)
  store %"compiler/build:Unit" %t19, ptr %l32
  br label %bb6
bb6:
  %t20 = load %"compiler/build:Unit", ptr %l32
  store %"compiler/build:Unit" %t20, ptr %l6
  %t21 = load i64, ptr %l3, !tbaa !24
  store i64 %t21, ptr %l33, !tbaa !24
  %t23 = call i64 @compiler_2fbuild_2ecompiler_2fbuild_3aUnit_2eLen(ptr %s2, ptr %l6)
  store i64 %t23, ptr %l35
  br label %bb7
bb7:
  %t24 = load i64, ptr %l33, !tbaa !24
  %t25 = load i64, ptr %l35, !tbaa !24
  %t26 = add i64 %t24, %t25
  store i64 %t26, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb8:
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = add i64 %t28, 1
  store i64 %t31, ptr %l5, !tbaa !24
  br label %bb1
bb9:
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l40, !tbaa !29
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/build:Config", ptr %t34, i32 0, i32 4
  %t37 = load i1, ptr %t36, !tbaa !21
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb10, label %bb11
bb10:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/build:Config", ptr %t41, i32 0, i32 6
  %t44 = load i1, ptr %t43, !tbaa !21
  %t46 = xor i1 %t44, true
  store i1 %t46, ptr %l44, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb12
bb12:
  %t48 = load i1, ptr %l44, !tbaa !21
  br i1 %t48, label %bb13, label %bb14
bb13:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/build:Config", ptr %t49, i32 0, i32 5
  %t52 = load i1, ptr %t51, !tbaa !21
  %t54 = xor i1 %t52, true
  store i1 %t54, ptr %l48, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb15
bb15:
  %t56 = load i1, ptr %l48, !tbaa !21
  br i1 %t56, label %bb16, label %bb17
bb16:
  %t57 = load i64, ptr %l3, !tbaa !24
  %t58 = load i64, ptr @G_2ecompiler_2fbuild_2eThinFrom, !tbaa !24
  %t61 = icmp sge i64 %t57, %t58
  store i1 %t61, ptr %l52, !tbaa !21
  br label %bb18
bb17:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb18
bb18:
  %t63 = load i1, ptr %l52, !tbaa !21
  %t64 = load ptr, ptr %l40, !tbaa !29
  %t65 = getelementptr %"compiler/build:Config", ptr %t64, i32 0, i32 38
  store i1 %t63, ptr %t65, !tbaa !21
  call void @compiler_2fbuild_3acompiles_2ector(ptr %t66, ptr %v2)
  call void @llvm.memmove.p0.p0.i64(ptr %l56, ptr %t66, i64 288, i1 false)
  br label %bb19
bb19:
  %t67 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 288, i64 8)
  store ptr %t67, ptr %lp7
  %t68 = load ptr, ptr %lp7
  call void @llvm.memmove.p0.p0.i64(ptr %t68, ptr %l56, i64 288, i1 false)
  %t69 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t69, ptr %l57
  br label %bb20
bb20:
  %t70 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 32, i64 8)
  store ptr %t70, ptr %lp8
  %t71 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l57
  %t72 = load ptr, ptr %lp8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t71, ptr %t72
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr %"compiler/build:Program", ptr %t73, i32 0, i32 0
  %t77 = call { i64, ptr } @compiler_2fbuild_2eIrHashes(ptr %v1, ptr %s0, ptr %s0, ptr %t75, ptr null)
  store { i64, ptr } %t77, ptr %l60
  br label %bb21
bb21:
  %t78 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t78, ptr %l9, !tbaa !27
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr %"compiler/build:Program", ptr %t79, i32 0, i32 0
  store ptr %t81, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s5
  %t83 = load i64, ptr %l11, !tbaa !24
  store i64 %t83, ptr %l63, !tbaa !24
  %t84 = load ptr, ptr %l10, !tbaa !29
  %t86 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v1, ptr %t84)
  store i64 %t86, ptr %l65
  br label %bb23
bb23:
  %t87 = load i64, ptr %l63, !tbaa !24
  %t88 = load i64, ptr %l65, !tbaa !24
  %t89 = icmp slt i64 %t87, %t88
  %t91 = xor i1 %t89, true
  br i1 %t91, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s5)
  br label %bb44
bb25:
  br label %bb26
bb26:
  %t93 = load i64, ptr %l11, !tbaa !24
  store i64 %t93, ptr %l12, !tbaa !24
  %t95 = load ptr, ptr %l10, !tbaa !29
  %t96 = load i64, ptr %l11, !tbaa !24
  %t99 = call %"compiler/build:Unit" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eAt_3ccompiler_2fbuild_3aUnit_3e(ptr %v1, ptr %v1, ptr %t95, i64 %t96)
  store %"compiler/build:Unit" %t99, ptr %l71
  br label %bb27
bb27:
  %t100 = load %"compiler/build:Unit", ptr %l71
  store %"compiler/build:Unit" %t100, ptr %l13
  %t102 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aUnit_2eText(ptr %s5, ptr %s5, ptr %l13)
  %t103 = extractvalue { i32, { i64, ptr } } %t102, 1
  %t104 = extractvalue { i32, { i64, ptr } } %t102, 0
  store i32 %t104, ptr %l75
  %t105 = icmp ne i32 %t104, 0
  br i1 %t105, label %bb29, label %ok.106, !prof !99
ok.106:
  store { i64, ptr } %t103, ptr %l74
  br label %bb28
bb28:
  %t107 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t107, ptr %l72, !tbaa !27
  br label %bb35
bb29:
  %t108 = load i32, ptr %l75, !tbaa !23
  %t109 = ashr i32 %t108, 16
  %t111 = icmp eq i32 %t109, 1
  store i1 %t111, ptr %l77, !tbaa !21
  %t112 = load i32, ptr %l75, !tbaa !23
  %t113 = ashr i32 %t112, 16
  %t115 = icmp eq i32 %t113, 1
  br i1 %t115, label %bb30, label %bb31
bb30:
  call void @__olang_errpay_pop()
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t117 = getelementptr %"compiler/build:Unit", ptr %l13, i32 0, i32 4
  %t118 = load { i64, ptr }, ptr %t117, !tbaa !27
  store { i64, ptr } %t118, ptr %l80, !tbaa !27
  %t119 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %v2)
  store %"compiler/diagmsg:Msg" %t119, ptr %l81
  br label %bb33
bb33:
  %t120 = load ptr, ptr %l2, !tbaa !29
  %t121 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t122 = load %"compiler/diagmsg:Msg", ptr %l81
  call void @compiler_2fbuild_2efileFatal(ptr %v1, ptr %v2, ptr %v2, { i64, ptr } %t121, %"compiler/diagmsg:Msg" %t122, ptr %t120)
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t125 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 65536, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t125, ptr %rv
  br label %ret
bb35:
  %t126 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t126, ptr %l14, !tbaa !27
  %t127 = load ptr, ptr %lp8
  store ptr %t127, ptr %l84, !tbaa !29
  %t128 = call ptr @__olang_scope_hold(ptr %v3)
  %t129 = ptrtoint ptr %t128 to i64
  store i64 %t129, ptr %l85, !tbaa !24
  %t130 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t130, label %bb36, label %bb37
bb36:
  %t132 = call ptr @__olang_region_make(ptr %v3)
  %t133 = ptrtoint ptr %t132 to i64
  store i64 %t133, ptr %l85, !tbaa !24
  br label %bb37
bb37:
  %t134 = load ptr, ptr %l0, !tbaa !29
  store ptr %t134, ptr %l88, !tbaa !29
  %t135 = load ptr, ptr %lp7
  store ptr %t135, ptr %l89, !tbaa !29
  %t136 = getelementptr %"compiler/build:Unit", ptr %l13, i32 0, i32 0
  %t137 = load { i64, ptr }, ptr %t136, !tbaa !27
  %t139 = call { i64, ptr } @compiler_2fbuild_2eReadable(ptr %v1, ptr %s5, { i64, ptr } %t137)
  store { i64, ptr } %t139, ptr %l91
  br label %bb38
bb38:
  %t140 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t141 = getelementptr %"compiler/build:Unit", ptr %l13, i32 0, i32 1
  %t142 = load i32, ptr %t141, !range !{i32 0, i32 5}
  %t143 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t144 = load ptr, ptr %l2, !tbaa !29
  %t145 = load i64, ptr %l12, !tbaa !24
  %t147 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !27
  %t149 = getelementptr { i64, ptr }, ptr %t148, i64 %t145
  %t150 = load { i64, ptr }, ptr %t149, !tbaa !37
  %t151 = load i64, ptr %l12, !tbaa !24
  %t152 = load ptr, ptr %l88, !tbaa !29
  %t153 = load ptr, ptr %l89, !tbaa !29
  %t160 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewant(ptr %v0, ptr %v2, ptr %s5, ptr %s5, ptr %v2, ptr %s0, ptr %v3, ptr %t152, ptr %t153, { i64, ptr } %t140, i32 %t142, { i64, ptr } %t143, ptr %t144, { i64, ptr } %t150, i64 %t151)
  %t161 = extractvalue { i32, { i64, ptr } } %t160, 1
  %t162 = extractvalue { i32, { i64, ptr } } %t160, 0
  store i32 %t162, ptr %l100
  %t163 = icmp ne i32 %t162, 0
  br i1 %t163, label %bb40, label %ok.164, !prof !99
ok.164:
  store { i64, ptr } %t161, ptr %l99
  br label %bb39
bb39:
  %t165 = load { i64, ptr }, ptr %l99, !tbaa !27
  store { i64, ptr } %t165, ptr %l87, !tbaa !27
  br label %bb41
bb40:
  %t166 = load i32, ptr %l100, !tbaa !23
  %t167 = lshr i32 %t166, 16
  %t168 = and i32 %t166, 65535
  %t169 = icmp eq i32 %t167, 1
  %t170 = select i1 %t169, i32 1, i32 0
  %t171 = icmp eq i32 %t166, 0
  %t172 = shl i32 %t170, 16
  %t173 = or i32 %t172, %t168
  %t174 = select i1 %t171, i32 0, i32 %t173
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t176 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 %t174, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t176, ptr %rv
  br label %ret
bb41:
  %t177 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t178 = load i64, ptr %l85
  %t179 = inttoptr i64 %t178 to ptr
  %t180 = extractvalue { i64, ptr } %t177, 0
  %t181 = extractvalue { i64, ptr } %t177, 1
  %t182 = mul i64 %t180, 1
  %t183 = call ptr @__olang_held_alloc(ptr %t179, i64 %t182)
  call void @llvm.memcpy.p0.p0.i64(ptr %t183, ptr %t181, i64 %t182, i1 false)
  %t184 = insertvalue { i64, ptr } undef, i64 %t180, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t183, 1
  %t186 = load ptr, ptr %l84, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v3, ptr %v3, ptr %t186, { i64, ptr } %t185)
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s5)
  br label %bb43
bb43:
  %t188 = load i64, ptr %l11, !tbaa !24
  %t191 = add i64 %t188, 1
  store i64 %t191, ptr %l11, !tbaa !24
  br label %bb22
bb44:
  %t193 = load ptr, ptr %l1, !tbaa !29
  %t195 = getelementptr %"compiler/build:Program", ptr %t193, i32 0, i32 0
  %t197 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v1, ptr %t195)
  store i64 %t197, ptr %l108
  br label %bb45
bb45:
  %t198 = load i64, ptr %l108, !tbaa !24
  store i64 %t198, ptr %l15, !tbaa !24
  %t199 = load ptr, ptr %l1, !tbaa !29
  %t201 = getelementptr %"compiler/build:Program", ptr %t199, i32 0, i32 1
  %t202 = load { i64, ptr }, ptr %t201, !tbaa !27
  %t204 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t202, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d234, i32 0, i32 1) })
  store i1 %t204, ptr %l111
  br label %bb46
bb46:
  %t205 = load i1, ptr %l111, !tbaa !21
  %t206 = xor i1 %t205, true
  br i1 %t206, label %bb47, label %bb48
bb47:
  store %olang.scope zeroinitializer, ptr %s8
  %t208 = load ptr, ptr %lp8
  store ptr %t208, ptr %l113, !tbaa !29
  %t209 = call ptr @__olang_scope_hold(ptr %v3)
  %t210 = ptrtoint ptr %t209 to i64
  store i64 %t210, ptr %l114, !tbaa !24
  %t211 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t211, label %bb49, label %bb50
bb48:
  br label %bb55
bb49:
  %t213 = call ptr @__olang_region_make(ptr %v3)
  %t214 = ptrtoint ptr %t213 to i64
  store i64 %t214, ptr %l114, !tbaa !24
  br label %bb50
bb50:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = load ptr, ptr %lp7
  %t217 = load ptr, ptr %l1, !tbaa !29
  %t219 = getelementptr %"compiler/build:Program", ptr %t217, i32 0, i32 1
  %t220 = load { i64, ptr }, ptr %t219, !tbaa !27
  %t221 = load ptr, ptr %l2, !tbaa !29
  %t222 = load i64, ptr %l15, !tbaa !24
  %t229 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewant(ptr %v0, ptr %v2, ptr %s8, ptr %v1, ptr %v2, ptr %v3, ptr %v3, ptr %t215, ptr %t216, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d235, i32 0, i32 1) }, i32 0, { i64, ptr } %t220, ptr %t221, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d236, i32 0, i32 1) }, i64 %t222)
  %t230 = extractvalue { i32, { i64, ptr } } %t229, 1
  %t231 = extractvalue { i32, { i64, ptr } } %t229, 0
  store i32 %t231, ptr %l125
  %t232 = icmp ne i32 %t231, 0
  br i1 %t232, label %bb52, label %ok.233, !prof !99
ok.233:
  store { i64, ptr } %t230, ptr %l124
  br label %bb51
bb51:
  %t234 = load { i64, ptr }, ptr %l124, !tbaa !27
  store { i64, ptr } %t234, ptr %l116, !tbaa !27
  br label %bb53
bb52:
  %t235 = load i32, ptr %l125, !tbaa !23
  %t236 = lshr i32 %t235, 16
  %t237 = and i32 %t235, 65535
  %t238 = icmp eq i32 %t236, 1
  %t239 = select i1 %t238, i32 1, i32 0
  %t240 = icmp eq i32 %t235, 0
  %t241 = shl i32 %t239, 16
  %t242 = or i32 %t241, %t237
  %t243 = select i1 %t240, i32 0, i32 %t242
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t245 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 %t243, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t245, ptr %rv
  br label %ret
bb53:
  %t246 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t247 = load i64, ptr %l114
  %t248 = inttoptr i64 %t247 to ptr
  %t249 = extractvalue { i64, ptr } %t246, 0
  %t250 = extractvalue { i64, ptr } %t246, 1
  %t251 = mul i64 %t249, 1
  %t252 = call ptr @__olang_held_alloc(ptr %t248, i64 %t251)
  call void @llvm.memcpy.p0.p0.i64(ptr %t252, ptr %t250, i64 %t251, i1 false)
  %t253 = insertvalue { i64, ptr } undef, i64 %t249, 0
  %t254 = insertvalue { i64, ptr } %t253, ptr %t252, 1
  %t255 = load ptr, ptr %l113, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v3, ptr %v3, ptr %t255, { i64, ptr } %t254)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s8)
  br label %bb55
bb55:
  %t257 = load ptr, ptr %l1, !tbaa !29
  %t259 = getelementptr %"compiler/build:Program", ptr %t257, i32 0, i32 2
  %t260 = load { i64, ptr }, ptr %t259, !tbaa !27
  %t262 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t260, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d237, i32 0, i32 1) })
  store i1 %t262, ptr %l130
  br label %bb56
bb56:
  %t263 = load i1, ptr %l130, !tbaa !21
  %t264 = xor i1 %t263, true
  br i1 %t264, label %bb57, label %bb58
bb57:
  store %olang.scope zeroinitializer, ptr %s9
  %t266 = load ptr, ptr %lp8
  store ptr %t266, ptr %l132, !tbaa !29
  %t267 = call ptr @__olang_scope_hold(ptr %v3)
  %t268 = ptrtoint ptr %t267 to i64
  store i64 %t268, ptr %l133, !tbaa !24
  %t269 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t269, label %bb59, label %bb60
bb58:
  br label %bb65
bb59:
  %t271 = call ptr @__olang_region_make(ptr %v3)
  %t272 = ptrtoint ptr %t271 to i64
  store i64 %t272, ptr %l133, !tbaa !24
  br label %bb60
bb60:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t274 = load ptr, ptr %lp7
  %t275 = load ptr, ptr %l1, !tbaa !29
  %t277 = getelementptr %"compiler/build:Program", ptr %t275, i32 0, i32 2
  %t278 = load { i64, ptr }, ptr %t277, !tbaa !27
  %t279 = load ptr, ptr %l2, !tbaa !29
  %t280 = load i64, ptr %l15, !tbaa !24
  %t282 = add i64 %t280, 1
  %t289 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewant(ptr %v0, ptr %v2, ptr %s9, ptr %v1, ptr %v2, ptr %v3, ptr %v3, ptr %t273, ptr %t274, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d238, i32 0, i32 1) }, i32 0, { i64, ptr } %t278, ptr %t279, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d239, i32 0, i32 1) }, i64 %t282)
  %t290 = extractvalue { i32, { i64, ptr } } %t289, 1
  %t291 = extractvalue { i32, { i64, ptr } } %t289, 0
  store i32 %t291, ptr %l145
  %t292 = icmp ne i32 %t291, 0
  br i1 %t292, label %bb62, label %ok.293, !prof !99
ok.293:
  store { i64, ptr } %t290, ptr %l144
  br label %bb61
bb61:
  %t294 = load { i64, ptr }, ptr %l144, !tbaa !27
  store { i64, ptr } %t294, ptr %l135, !tbaa !27
  br label %bb63
bb62:
  %t295 = load i32, ptr %l145, !tbaa !23
  %t296 = lshr i32 %t295, 16
  %t297 = and i32 %t295, 65535
  %t298 = icmp eq i32 %t296, 1
  %t299 = select i1 %t298, i32 1, i32 0
  %t300 = icmp eq i32 %t295, 0
  %t301 = shl i32 %t299, 16
  %t302 = or i32 %t301, %t297
  %t303 = select i1 %t300, i32 0, i32 %t302
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t305 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 %t303, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t305, ptr %rv
  br label %ret
bb63:
  %t306 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t307 = load i64, ptr %l133
  %t308 = inttoptr i64 %t307 to ptr
  %t309 = extractvalue { i64, ptr } %t306, 0
  %t310 = extractvalue { i64, ptr } %t306, 1
  %t311 = mul i64 %t309, 1
  %t312 = call ptr @__olang_held_alloc(ptr %t308, i64 %t311)
  call void @llvm.memcpy.p0.p0.i64(ptr %t312, ptr %t310, i64 %t311, i1 false)
  %t313 = insertvalue { i64, ptr } undef, i64 %t309, 0
  %t314 = insertvalue { i64, ptr } %t313, ptr %t312, 1
  %t315 = load ptr, ptr %l132, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v3, ptr %v3, ptr %t315, { i64, ptr } %t314)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s9)
  br label %bb65
bb65:
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t318 = load ptr, ptr %lp7
  %t319 = load ptr, ptr %l2, !tbaa !29
  %t323 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ecompile(ptr %v0, ptr %v2, ptr %v2, ptr %t317, ptr %t318, ptr %t319)
  store i32 %t323, ptr %l151
  %t324 = icmp ne i32 %t323, 0
  br i1 %t324, label %bb67, label %ok.325, !prof !99
ok.325:
  br label %bb66
bb66:
  br label %bb68
bb67:
  %t326 = load i32, ptr %l151, !tbaa !23
  %t327 = lshr i32 %t326, 16
  %t328 = and i32 %t326, 65535
  %t329 = icmp eq i32 %t327, 1
  %t330 = select i1 %t329, i32 1, i32 0
  %t331 = icmp eq i32 %t326, 0
  %t332 = shl i32 %t330, 16
  %t333 = or i32 %t332, %t328
  %t334 = select i1 %t331, i32 0, i32 %t333
  call void @__olang_scope_close(ptr %s0)
  %t336 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 %t334, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t336, ptr %rv
  br label %ret
bb68:
  %t337 = load ptr, ptr %lp7
  %t338 = getelementptr %"compiler/build:compiles", ptr %t337, i32 0, i32 8
  %t340 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v2, ptr %t338)
  store i64 %t340, ptr %l154
  br label %bb69
bb69:
  %t341 = load i64, ptr %l154, !tbaa !24
  %t342 = icmp sgt i64 %t341, 0
  br i1 %t342, label %bb70, label %bb71
bb70:
  call void @compiler_2fbuild_3acompiles_2ector(ptr %t344, ptr %v2)
  call void @llvm.memmove.p0.p0.i64(ptr %l156, ptr %t344, i64 288, i1 false)
  br label %bb72
bb71:
  br label %bb134
bb72:
  %t345 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 288, i64 8)
  store ptr %t345, ptr %lp16
  %t346 = load ptr, ptr %lp16
  call void @llvm.memmove.p0.p0.i64(ptr %t346, ptr %l156, i64 288, i1 false)
  %t347 = load ptr, ptr %lp7
  %t348 = getelementptr %"compiler/build:compiles", ptr %t347, i32 0, i32 8
  store ptr %t348, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb73
bb73:
  store %olang.scope zeroinitializer, ptr %s12
  %t350 = load i64, ptr %l18, !tbaa !24
  store i64 %t350, ptr %l158, !tbaa !24
  %t351 = load ptr, ptr %l17, !tbaa !29
  %t353 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v2, ptr %t351)
  store i64 %t353, ptr %l160
  br label %bb74
bb74:
  %t354 = load i64, ptr %l158, !tbaa !24
  %t355 = load i64, ptr %l160, !tbaa !24
  %t356 = icmp slt i64 %t354, %t355
  %t358 = xor i1 %t356, true
  br i1 %t358, label %bb75, label %bb76
bb75:
  call void @__olang_scope_close(ptr %s12)
  br label %bb130
bb76:
  br label %bb77
bb77:
  %t360 = load ptr, ptr %l17, !tbaa !29
  %t361 = load i64, ptr %l18, !tbaa !24
  %t364 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t360, i64 %t361)
  store i64 %t364, ptr %l165
  br label %bb78
bb78:
  %t365 = load i64, ptr %l165, !tbaa !24
  store i64 %t365, ptr %l19, !tbaa !24
  %t366 = load i64, ptr %l19, !tbaa !24
  %t367 = load i64, ptr %l15, !tbaa !24
  %t369 = add i64 %t367, 1
  %t372 = icmp slt i64 %t366, %t369
  br i1 %t372, label %bb79, label %bb80
bb79:
  store i1 true, ptr %l170, !tbaa !21
  br label %bb82
bb80:
  %t374 = load ptr, ptr %l1, !tbaa !29
  %t376 = getelementptr %"compiler/build:Program", ptr %t374, i32 0, i32 1
  %t377 = load { i64, ptr }, ptr %t376, !tbaa !27
  %t379 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s12, { i64, ptr } %t377, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d240, i32 0, i32 1) })
  store i1 %t379, ptr %l173
  br label %bb81
bb81:
  %t380 = load i1, ptr %l173, !tbaa !21
  %t381 = xor i1 %t380, true
  store i1 %t381, ptr %l170, !tbaa !21
  br label %bb82
bb82:
  %t383 = load i1, ptr %l170, !tbaa !21
  br i1 %t383, label %bb83, label %bb84
bb83:
  %t384 = load ptr, ptr %lp8
  %t385 = load i64, ptr %l19, !tbaa !24
  %t388 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v3, ptr %s12, ptr %t384, i64 %t385)
  store { i64, ptr } %t388, ptr %l178
  br label %bb85
bb84:
  %t389 = load ptr, ptr %lp8
  %t390 = load i64, ptr %l15, !tbaa !24
  %t393 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v3, ptr %s12, ptr %t389, i64 %t390)
  store { i64, ptr } %t393, ptr %l181
  br label %bb86
bb85:
  %t394 = load { i64, ptr }, ptr %l178, !tbaa !27
  store { i64, ptr } %t394, ptr %l175, !tbaa !27
  br label %bb87
bb86:
  %t395 = load { i64, ptr }, ptr %l181, !tbaa !27
  store { i64, ptr } %t395, ptr %l175, !tbaa !27
  br label %bb87
bb87:
  %t396 = load { i64, ptr }, ptr %l175, !tbaa !27
  store { i64, ptr } %t396, ptr %l20, !tbaa !27
  br label %bb88
bb88:
  store %olang.scope zeroinitializer, ptr %s13
  %t397 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t399 = call i1 @std_2fos_2eExists(ptr %s12, { i64, ptr } %t397)
  store i1 %t399, ptr %l183
  br label %bb89
bb89:
  %t400 = load i1, ptr %l183, !tbaa !21
  %t401 = xor i1 %t400, true
  br i1 %t401, label %bb90, label %bb91
bb90:
  %t403 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t405 = extractvalue { i64, ptr } %t403, 1
  %t406 = extractvalue { i64, ptr } %t403, 0
  %t407 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d241, i32 0, i32 1) }, 1
  %t408 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d241, i32 0, i32 1) }, 0
  %t409 = add i64 %t406, %t408
  %t410 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t409)
  call void @olang_textcopy(ptr %t410, ptr %t405, i64 %t406)
  %t411 = getelementptr i8, ptr %t410, i64 %t406
  call void @olang_textcopy(ptr %t411, ptr %t407, i64 %t408)
  %t412 = insertvalue { i64, ptr } undef, i64 %t409, 0
  %t413 = insertvalue { i64, ptr } %t412, ptr %t410, 1
  %t416 = call i1 @compiler_2fbuild_2eholderAlive(ptr %s13, { i64, ptr } %t413)
  store i1 %t416, ptr %l189
  br label %bb92
bb91:
  store i1 false, ptr %l185, !tbaa !21
  br label %bb93
bb92:
  %t417 = load i1, ptr %l189, !tbaa !21
  store i1 %t417, ptr %l185, !tbaa !21
  br label %bb93
bb93:
  %t418 = load i1, ptr %l185, !tbaa !21
  %t419 = xor i1 %t418, true
  br i1 %t419, label %bb94, label %bb95
bb94:
  call void @__olang_scope_close(ptr %s13)
  br label %bb99
bb95:
  br label %bb96
bb96:
  %t421 = call i32 @usleep(i32 20000)
  store i32 %t421, ptr %l191
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s13)
  br label %bb98
bb98:
  br label %bb88
bb99:
  %t422 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t424 = call i1 @std_2fos_2eExists(ptr %s12, { i64, ptr } %t422)
  store i1 %t424, ptr %l193
  br label %bb100
bb100:
  %t425 = load i1, ptr %l193, !tbaa !21
  br i1 %t425, label %bb101, label %bb102
bb101:
  call void @__olang_scope_close(ptr %s12)
  br label %bb129
bb102:
  br label %bb103
bb103:
  %t426 = load i64, ptr %l19, !tbaa !24
  %t427 = load i64, ptr %l15, !tbaa !24
  %t430 = icmp slt i64 %t426, %t427
  br i1 %t430, label %bb104, label %bb105
bb104:
  store %olang.scope zeroinitializer, ptr %s16
  %t432 = load ptr, ptr %l1, !tbaa !29
  %t434 = getelementptr %"compiler/build:Program", ptr %t432, i32 0, i32 0
  %t435 = load i64, ptr %l19, !tbaa !24
  %t438 = call %"compiler/build:Unit" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eAt_3ccompiler_2fbuild_3aUnit_3e(ptr %v1, ptr %v1, ptr %t434, i64 %t435)
  store %"compiler/build:Unit" %t438, ptr %l200
  br label %bb106
bb105:
  %t439 = load i64, ptr %l19, !tbaa !24
  %t440 = load i64, ptr %l15, !tbaa !24
  %t443 = icmp eq i64 %t439, %t440
  br i1 %t443, label %bb119, label %bb120
bb106:
  %t445 = load %"compiler/build:Unit", ptr %l200
  store %"compiler/build:Unit" %t445, ptr %l21
  %t447 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aUnit_2eText(ptr %v1, ptr %s16, ptr %l21)
  %t448 = extractvalue { i32, { i64, ptr } } %t447, 1
  %t449 = extractvalue { i32, { i64, ptr } } %t447, 0
  store i32 %t449, ptr %l204
  %t450 = icmp ne i32 %t449, 0
  br i1 %t450, label %bb108, label %ok.451, !prof !99
ok.451:
  store { i64, ptr } %t448, ptr %l203
  br label %bb107
bb107:
  %t452 = load { i64, ptr }, ptr %l203, !tbaa !27
  store { i64, ptr } %t452, ptr %l201, !tbaa !27
  br label %bb114
bb108:
  %t453 = load i32, ptr %l204, !tbaa !23
  %t454 = ashr i32 %t453, 16
  %t456 = icmp eq i32 %t454, 1
  store i1 %t456, ptr %l206, !tbaa !21
  %t457 = load i32, ptr %l204, !tbaa !23
  %t458 = ashr i32 %t457, 16
  %t460 = icmp eq i32 %t458, 1
  br i1 %t460, label %bb109, label %bb110
bb109:
  call void @__olang_errpay_pop()
  br label %bb110
bb110:
  br label %bb111
bb111:
  %t462 = getelementptr %"compiler/build:Unit", ptr %l21, i32 0, i32 4
  %t463 = load { i64, ptr }, ptr %t462, !tbaa !27
  store { i64, ptr } %t463, ptr %l209, !tbaa !27
  %t464 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %v2)
  store %"compiler/diagmsg:Msg" %t464, ptr %l210
  br label %bb112
bb112:
  %t465 = load ptr, ptr %l2, !tbaa !29
  %t466 = load { i64, ptr }, ptr %l209, !tbaa !27
  %t467 = load %"compiler/diagmsg:Msg", ptr %l210
  call void @compiler_2fbuild_2efileFatal(ptr %v1, ptr %v2, ptr %v2, { i64, ptr } %t466, %"compiler/diagmsg:Msg" %t467, ptr %t465)
  br label %bb113
bb113:
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  %t470 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 65536, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t470, ptr %rv
  br label %ret
bb114:
  %t471 = load { i64, ptr }, ptr %l201, !tbaa !27
  store { i64, ptr } %t471, ptr %l22, !tbaa !27
  %t472 = load ptr, ptr %l0, !tbaa !29
  store ptr %t472, ptr %l214, !tbaa !29
  %t473 = load ptr, ptr %lp16
  store ptr %t473, ptr %l215, !tbaa !29
  %t474 = getelementptr %"compiler/build:Unit", ptr %l21, i32 0, i32 0
  %t475 = load { i64, ptr }, ptr %t474, !tbaa !27
  %t477 = call { i64, ptr } @compiler_2fbuild_2eReadable(ptr %v1, ptr %s16, { i64, ptr } %t475)
  store { i64, ptr } %t477, ptr %l217
  br label %bb115
bb115:
  %t478 = load { i64, ptr }, ptr %l217, !tbaa !27
  %t479 = getelementptr %"compiler/build:Unit", ptr %l21, i32 0, i32 1
  %t480 = load i32, ptr %t479, !range !{i32 0, i32 5}
  %t481 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t482 = load ptr, ptr %l2, !tbaa !29
  %t483 = getelementptr %"compiler/build:Unit", ptr %l21, i32 0, i32 3
  %t484 = load { i64, ptr }, ptr %t483, !tbaa !27
  %t485 = load ptr, ptr %l214, !tbaa !29
  %t486 = load ptr, ptr %l215, !tbaa !29
  %t492 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewant(ptr %v0, ptr %v2, ptr %s16, ptr %s16, ptr %v2, ptr %v1, ptr %v2, ptr %t485, ptr %t486, { i64, ptr } %t478, i32 %t480, { i64, ptr } %t481, ptr %t482, { i64, ptr } %t484, i64 -1)
  %t493 = extractvalue { i32, { i64, ptr } } %t492, 1
  %t494 = extractvalue { i32, { i64, ptr } } %t492, 0
  store i32 %t494, ptr %l224
  %t495 = icmp ne i32 %t494, 0
  br i1 %t495, label %bb117, label %ok.496, !prof !99
ok.496:
  store { i64, ptr } %t493, ptr %l223
  br label %bb116
bb116:
  %t497 = load { i64, ptr }, ptr %l223, !tbaa !27
  store { i64, ptr } %t497, ptr %l213, !tbaa !27
  br label %bb118
bb117:
  %t498 = load i32, ptr %l224, !tbaa !23
  %t499 = lshr i32 %t498, 16
  %t500 = and i32 %t498, 65535
  %t501 = icmp eq i32 %t499, 1
  %t502 = select i1 %t501, i32 1, i32 0
  %t503 = icmp eq i32 %t498, 0
  %t504 = shl i32 %t502, 16
  %t505 = or i32 %t504, %t500
  %t506 = select i1 %t503, i32 0, i32 %t505
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  %t508 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 %t506, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t508, ptr %rv
  br label %ret
bb118:
  call void @__olang_scope_close(ptr %s16)
  br label %bb128
bb119:
  store %olang.scope zeroinitializer, ptr %s19
  %t509 = load ptr, ptr %l0, !tbaa !29
  %t510 = load ptr, ptr %lp16
  %t511 = load ptr, ptr %l1, !tbaa !29
  %t513 = getelementptr %"compiler/build:Program", ptr %t511, i32 0, i32 1
  %t514 = load { i64, ptr }, ptr %t513, !tbaa !27
  %t515 = load ptr, ptr %l2, !tbaa !29
  %t521 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewant(ptr %v0, ptr %v2, ptr %s19, ptr %v1, ptr %v2, ptr %v2, ptr %v2, ptr %t509, ptr %t510, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d242, i32 0, i32 1) }, i32 0, { i64, ptr } %t514, ptr %t515, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d243, i32 0, i32 1) }, i64 -1)
  %t522 = extractvalue { i32, { i64, ptr } } %t521, 1
  %t523 = extractvalue { i32, { i64, ptr } } %t521, 0
  store i32 %t523, ptr %l237
  %t524 = icmp ne i32 %t523, 0
  br i1 %t524, label %bb122, label %ok.525, !prof !99
ok.525:
  store { i64, ptr } %t522, ptr %l236
  br label %bb121
bb120:
  store %olang.scope zeroinitializer, ptr %s20
  %t526 = load ptr, ptr %l0, !tbaa !29
  %t527 = load ptr, ptr %lp16
  %t528 = load ptr, ptr %l1, !tbaa !29
  %t530 = getelementptr %"compiler/build:Program", ptr %t528, i32 0, i32 2
  %t531 = load { i64, ptr }, ptr %t530, !tbaa !27
  %t532 = load ptr, ptr %l2, !tbaa !29
  %t538 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewant(ptr %v0, ptr %v2, ptr %s20, ptr %v1, ptr %v2, ptr %v2, ptr %v2, ptr %t526, ptr %t527, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d244, i32 0, i32 1) }, i32 0, { i64, ptr } %t531, ptr %t532, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d243, i32 0, i32 1) }, i64 -1)
  %t539 = extractvalue { i32, { i64, ptr } } %t538, 1
  %t540 = extractvalue { i32, { i64, ptr } } %t538, 0
  store i32 %t540, ptr %l247
  %t541 = icmp ne i32 %t540, 0
  br i1 %t541, label %bb125, label %ok.542, !prof !99
ok.542:
  store { i64, ptr } %t539, ptr %l246
  br label %bb124
bb121:
  %t543 = load { i64, ptr }, ptr %l236, !tbaa !27
  store { i64, ptr } %t543, ptr %l229, !tbaa !27
  br label %bb123
bb122:
  %t544 = load i32, ptr %l237, !tbaa !23
  %t545 = lshr i32 %t544, 16
  %t546 = and i32 %t544, 65535
  %t547 = icmp eq i32 %t545, 1
  %t548 = select i1 %t547, i32 1, i32 0
  %t549 = icmp eq i32 %t544, 0
  %t550 = shl i32 %t548, 16
  %t551 = or i32 %t550, %t546
  %t552 = select i1 %t549, i32 0, i32 %t551
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  %t554 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 %t552, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t554, ptr %rv
  br label %ret
bb123:
  call void @__olang_scope_close(ptr %s19)
  br label %bb127
bb124:
  %t555 = load { i64, ptr }, ptr %l246, !tbaa !27
  store { i64, ptr } %t555, ptr %l239, !tbaa !27
  br label %bb126
bb125:
  %t556 = load i32, ptr %l247, !tbaa !23
  %t557 = lshr i32 %t556, 16
  %t558 = and i32 %t556, 65535
  %t559 = icmp eq i32 %t557, 1
  %t560 = select i1 %t559, i32 1, i32 0
  %t561 = icmp eq i32 %t556, 0
  %t562 = shl i32 %t560, 16
  %t563 = or i32 %t562, %t558
  %t564 = select i1 %t561, i32 0, i32 %t563
  call void @__olang_scope_close(ptr %s20)
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  %t566 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 %t564, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t566, ptr %rv
  br label %ret
bb126:
  call void @__olang_scope_close(ptr %s20)
  br label %bb127
bb127:
  br label %bb128
bb128:
  call void @__olang_scope_close(ptr %s12)
  br label %bb129
bb129:
  %t567 = load i64, ptr %l18, !tbaa !24
  %t570 = add i64 %t567, 1
  store i64 %t570, ptr %l18, !tbaa !24
  br label %bb73
bb130:
  %t572 = load ptr, ptr %l0, !tbaa !29
  %t573 = load ptr, ptr %lp16
  %t574 = load ptr, ptr %l2, !tbaa !29
  %t578 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ecompile(ptr %v0, ptr %v2, ptr %v2, ptr %t572, ptr %t573, ptr %t574)
  store i32 %t578, ptr %l255
  %t579 = icmp ne i32 %t578, 0
  br i1 %t579, label %bb132, label %ok.580, !prof !99
ok.580:
  br label %bb131
bb131:
  br label %bb133
bb132:
  %t581 = load i32, ptr %l255, !tbaa !23
  %t582 = lshr i32 %t581, 16
  %t583 = and i32 %t581, 65535
  %t584 = icmp eq i32 %t582, 1
  %t585 = select i1 %t584, i32 1, i32 0
  %t586 = icmp eq i32 %t581, 0
  %t587 = shl i32 %t585, 16
  %t588 = or i32 %t587, %t583
  %t589 = select i1 %t586, i32 0, i32 %t588
  call void @__olang_scope_close(ptr %s0)
  %t591 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 %t589, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t591, ptr %rv
  br label %ret
bb133:
  br label %bb134
bb134:
  %t592 = load ptr, ptr %lp8
  %t593 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t592
  call void @__olang_scope_close(ptr %s0)
  %t595 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t593, 1
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t595, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }, ptr %rv
  ret { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %rr
}

define dso_local i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2erunParts(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4, { i64, ptr } %a5, ptr %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l7 = alloca i32
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca i32
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca i32
  %l43 = alloca i32
  %l44 = alloca ptr
  %l45 = alloca i64
  %l51 = alloca i64
  %l53 = alloca i64
  %l58 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l62 = alloca i32
  %l64 = alloca i1
  %l68 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l73 = alloca i64
  %l74 = alloca i64
  %l75 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l77 = alloca i64
  %l78 = alloca i32
  %l79 = alloca i64
  %l80 = alloca i32
  %l82 = alloca i64
  %l83 = alloca i64
  %l84 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l86 = alloca i64
  %l87 = alloca i32
  %l88 = alloca i64
  %l89 = alloca i32
  %l96 = alloca i1
  %l105 = alloca i1
  %l109 = alloca ptr
  %l112 = alloca i1
  %l115 = alloca i32
  %l119 = alloca i32
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 3, ptr %l7, !tbaa !23
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l17
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l8
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t3, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d245, i32 0, i32 1) })
  store i1 %t5, ptr %l19
  br label %bb2
bb2:
  %t6 = load i1, ptr %l19, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb3, label %bb4
bb3:
  store ptr %l8, ptr %l21, !tbaa !29
  %t9 = call ptr @__olang_scope_hold(ptr %s0)
  %t10 = ptrtoint ptr %t9 to i64
  store i64 %t10, ptr %l22, !tbaa !24
  %t11 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t11, label %bb5, label %bb6
bb4:
  br label %bb10
bb5:
  %t13 = call ptr @__olang_region_make(ptr %s0)
  %t14 = ptrtoint ptr %t13 to i64
  store i64 %t14, ptr %l22, !tbaa !24
  br label %bb6
bb6:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = extractvalue { i64, ptr } %t15, 0
  %t19 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d246, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d246, i32 0, i32 1) }, 0
  %t21 = add i64 %t18, %t20
  %t22 = load i64, ptr %l22
  %t23 = inttoptr i64 %t22 to ptr
  %t24 = call ptr @__olang_held_alloc(ptr %t23, i64 %t21)
  call void @olang_textcopy(ptr %t24, ptr %t17, i64 %t18)
  %t25 = getelementptr i8, ptr %t24, i64 %t18
  call void @olang_textcopy(ptr %t25, ptr %t19, i64 %t20)
  %t26 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t24, 1
  %t29 = load ptr, ptr %l21, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t29, { i64, ptr } %t27)
  br label %bb7
bb7:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l27, !tbaa !29
  %t32 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t32, ptr %l28, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t33, ptr %l29, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t34, ptr %l30, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t35, ptr %l31, !tbaa !27
  %t37 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l8, i64 0)
  store { i64, ptr } %t37, ptr %l33
  br label %bb8
bb8:
  %t38 = load ptr, ptr %l27, !tbaa !29
  %t39 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t40 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t44 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2erunTests(ptr %v0, ptr %v1, ptr %v2, ptr %v4, ptr %v5, ptr %s0, ptr %t38, { i64, ptr } %t39, { i64, ptr } %t40, { i64, ptr } %t41, { i64, ptr } %t42, { i64, ptr } %t43, i64 0)
  store i32 %t44, ptr %l34
  br label %bb9
bb9:
  %t45 = load i32, ptr %l34, !tbaa !23
  store i32 %t45, ptr %l7, !tbaa !23
  br label %bb10
bb10:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t51 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t51, 1
  %t54 = extractvalue { i64, ptr } %t51, 0
  %t55 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d247, i32 0, i32 1) }, 1
  %t56 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d247, i32 0, i32 1) }, 0
  %t57 = add i64 %t54, %t56
  %t58 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t57)
  call void @olang_textcopy(ptr %t58, ptr %t53, i64 %t54)
  %t59 = getelementptr i8, ptr %t58, i64 %t54
  call void @olang_textcopy(ptr %t59, ptr %t55, i64 %t56)
  %t60 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t58, 1
  %t69 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2erunTests(ptr %v0, ptr %v1, ptr %v3, ptr %v4, ptr %v5, ptr %s0, ptr %t46, { i64, ptr } %t47, { i64, ptr } %t48, { i64, ptr } %t49, { i64, ptr } %t50, { i64, ptr } %t61, i64 0)
  store i32 %t69, ptr %l43
  br label %bb11
bb11:
  %t70 = load i32, ptr %l43, !tbaa !23
  store i32 %t70, ptr %l9, !tbaa !23
  store ptr %l8, ptr %l44, !tbaa !29
  %t71 = call ptr @__olang_scope_hold(ptr %s0)
  %t72 = ptrtoint ptr %t71 to i64
  store i64 %t72, ptr %l45, !tbaa !24
  %t73 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t73, label %bb12, label %bb13
bb12:
  %t75 = call ptr @__olang_region_make(ptr %s0)
  %t76 = ptrtoint ptr %t75 to i64
  store i64 %t76, ptr %l45, !tbaa !24
  br label %bb13
bb13:
  %t77 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t77, 1
  %t80 = extractvalue { i64, ptr } %t77, 0
  %t81 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d248, i32 0, i32 1) }, 1
  %t82 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d248, i32 0, i32 1) }, 0
  %t83 = add i64 %t80, %t82
  %t84 = load i64, ptr %l45
  %t85 = inttoptr i64 %t84 to ptr
  %t86 = call ptr @__olang_held_alloc(ptr %t85, i64 %t83)
  call void @olang_textcopy(ptr %t86, ptr %t79, i64 %t80)
  %t87 = getelementptr i8, ptr %t86, i64 %t80
  call void @olang_textcopy(ptr %t87, ptr %t81, i64 %t82)
  %t88 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t86, 1
  %t91 = load ptr, ptr %l44, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t91, { i64, ptr } %t89)
  br label %bb14
bb14:
  store i64 0, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  store ptr %l8, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s6
  %t94 = load i64, ptr %l13, !tbaa !24
  store i64 %t94, ptr %l51, !tbaa !24
  %t95 = load ptr, ptr %l12, !tbaa !29
  %t97 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t95)
  store i64 %t97, ptr %l53
  br label %bb16
bb16:
  %t98 = load i64, ptr %l51, !tbaa !24
  %t99 = load i64, ptr %l53, !tbaa !24
  %t100 = icmp slt i64 %t98, %t99
  %t102 = xor i1 %t100, true
  br i1 %t102, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s6)
  br label %bb45
bb18:
  br label %bb19
bb19:
  %t104 = load ptr, ptr %l12, !tbaa !29
  %t105 = load i64, ptr %l13, !tbaa !24
  %t108 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t104, i64 %t105)
  store { i64, ptr } %t108, ptr %l58
  br label %bb20
bb20:
  %t109 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t112 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s6, { i64, ptr } %t109)
  %t113 = extractvalue { i32, { i64, ptr } } %t112, 1
  %t114 = extractvalue { i32, { i64, ptr } } %t112, 0
  store i32 %t114, ptr %l62
  %t115 = icmp ne i32 %t114, 0
  br i1 %t115, label %bb22, label %ok.116, !prof !99
ok.116:
  store { i64, ptr } %t113, ptr %l61
  br label %bb21
bb21:
  %t117 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t117, ptr %l59, !tbaa !27
  br label %bb26
bb22:
  %t118 = load i32, ptr %l62, !tbaa !23
  %t119 = ashr i32 %t118, 16
  %t121 = icmp eq i32 %t119, 1
  store i1 %t121, ptr %l64, !tbaa !21
  %t122 = load i32, ptr %l62, !tbaa !23
  %t123 = ashr i32 %t122, 16
  %t125 = icmp eq i32 %t123, 1
  br i1 %t125, label %bb23, label %bb24
bb23:
  call void @__olang_errpay_pop()
  br label %bb24
bb24:
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s6)
  br label %bb44
bb26:
  %t127 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t130 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %s6, ptr %s6, { i64, ptr } %t127)
  store { i64, ptr } %t130, ptr %l68
  br label %bb27
bb27:
  %t131 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t132 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %s6, ptr %s6, ptr %s6, { i64, ptr } %t131, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d249, i32 0, i32 1) })
  store { i64, ptr } %t132, ptr %l69
  br label %bb28
bb28:
  %t133 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t133, ptr %l16, !tbaa !27
  %t134 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t134, 0
  %t138 = icmp ne i64 %t136, 2
  br i1 %t138, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s6)
  br label %bb44
bb30:
  br label %bb31
bb31:
  %t140 = load i64, ptr %l10, !tbaa !24
  store i64 %t140, ptr %l73, !tbaa !24
  %t141 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t141, ptr %l75, !tbaa !27
  %t142 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = getelementptr { i64, ptr }, ptr %t143, i64 0
  %t145 = load { i64, ptr }, ptr %t144, !tbaa !37
  store { i64, ptr } %t145, ptr %l76, !tbaa !27
  %t146 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s6, i64 10)
  %t147 = extractvalue { i32, i64 } %t146, 1
  %t148 = extractvalue { i32, i64 } %t146, 0
  store i32 %t148, ptr %l78
  %t149 = icmp ne i32 %t148, 0
  br i1 %t149, label %bb33, label %ok.150, !prof !99
ok.150:
  store i64 %t147, ptr %l77
  br label %bb32
bb32:
  %t151 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t152 = load i64, ptr %l77, !tbaa !24
  %t153 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s6, { i64, ptr } %t151, i64 %t152)
  %t154 = extractvalue { i32, i64 } %t153, 1
  %t155 = extractvalue { i32, i64 } %t153, 0
  store i32 %t155, ptr %l80
  %t156 = icmp ne i32 %t155, 0
  br i1 %t156, label %bb36, label %ok.157, !prof !99
ok.157:
  store i64 %t154, ptr %l79
  br label %bb35
bb33:
  br label %bb34
bb34:
  store i64 0, ptr %l74, !tbaa !24
  br label %bb37
bb35:
  %t158 = load i64, ptr %l79, !tbaa !24
  store i64 %t158, ptr %l74, !tbaa !24
  br label %bb37
bb36:
  br label %bb34
bb37:
  %t159 = load i64, ptr %l73, !tbaa !24
  %t160 = load i64, ptr %l74, !tbaa !24
  %t161 = add i64 %t159, %t160
  store i64 %t161, ptr %l10, !tbaa !24
  %t163 = load i64, ptr %l11, !tbaa !24
  store i64 %t163, ptr %l82, !tbaa !24
  %t164 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t164, ptr %l84, !tbaa !27
  %t165 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !27
  %t167 = getelementptr { i64, ptr }, ptr %t166, i64 1
  %t168 = load { i64, ptr }, ptr %t167, !tbaa !37
  store { i64, ptr } %t168, ptr %l85, !tbaa !27
  %t169 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s6, i64 10)
  %t170 = extractvalue { i32, i64 } %t169, 1
  %t171 = extractvalue { i32, i64 } %t169, 0
  store i32 %t171, ptr %l87
  %t172 = icmp ne i32 %t171, 0
  br i1 %t172, label %bb39, label %ok.173, !prof !99
ok.173:
  store i64 %t170, ptr %l86
  br label %bb38
bb38:
  %t174 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t175 = load i64, ptr %l86, !tbaa !24
  %t176 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s6, { i64, ptr } %t174, i64 %t175)
  %t177 = extractvalue { i32, i64 } %t176, 1
  %t178 = extractvalue { i32, i64 } %t176, 0
  store i32 %t178, ptr %l89
  %t179 = icmp ne i32 %t178, 0
  br i1 %t179, label %bb42, label %ok.180, !prof !99
ok.180:
  store i64 %t177, ptr %l88
  br label %bb41
bb39:
  br label %bb40
bb40:
  store i64 0, ptr %l83, !tbaa !24
  br label %bb43
bb41:
  %t181 = load i64, ptr %l88, !tbaa !24
  store i64 %t181, ptr %l83, !tbaa !24
  br label %bb43
bb42:
  br label %bb40
bb43:
  %t182 = load i64, ptr %l82, !tbaa !24
  %t183 = load i64, ptr %l83, !tbaa !24
  %t184 = add i64 %t182, %t183
  store i64 %t184, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb44
bb44:
  %t186 = load i64, ptr %l13, !tbaa !24
  %t189 = add i64 %t186, 1
  store i64 %t189, ptr %l13, !tbaa !24
  br label %bb15
bb45:
  %t191 = load i32, ptr %l7, !tbaa !23
  %t193 = icmp ne i32 %t191, 3
  br i1 %t193, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l96, !tbaa !21
  br label %bb48
bb47:
  %t195 = load i32, ptr %l9, !tbaa !23
  %t197 = icmp ne i32 %t195, 3
  store i1 %t197, ptr %l96, !tbaa !21
  br label %bb48
bb48:
  %t199 = load i1, ptr %l96, !tbaa !21
  br i1 %t199, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s10
  %t200 = load i64, ptr %l10, !tbaa !24
  %t201 = load i64, ptr %l11, !tbaa !24
  %t203 = call i64 @__olang_fmt_i64(ptr null, i64 %t200)
  %t204 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d250, i32 0, i32 1) }, 1
  %t205 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d250, i32 0, i32 1) }, 0
  %t206 = add i64 %t203, %t205
  %t208 = call i64 @__olang_fmt_i64(ptr null, i64 %t201)
  %t209 = add i64 %t206, %t208
  %t210 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d251, i32 0, i32 1) }, 1
  %t211 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d251, i32 0, i32 1) }, 0
  %t212 = add i64 %t209, %t211
  %t213 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t212)
  %t214 = call i64 @__olang_fmt_i64(ptr %t213, i64 %t200)
  %t215 = getelementptr i8, ptr %t213, i64 %t203
  call void @olang_textcopy(ptr %t215, ptr %t204, i64 %t205)
  %t216 = getelementptr i8, ptr %t215, i64 %t205
  %t217 = call i64 @__olang_fmt_i64(ptr %t216, i64 %t201)
  %t218 = getelementptr i8, ptr %t216, i64 %t208
  call void @olang_textcopy(ptr %t218, ptr %t210, i64 %t211)
  %t219 = insertvalue { i64, ptr } undef, i64 %t212, 0
  %t220 = insertvalue { i64, ptr } %t219, ptr %t213, 1
  call void @compiler_2fbuild_2esayln(ptr %s10, { i64, ptr } %t220)
  br label %bb51
bb50:
  br label %bb52
bb51:
  call void @__olang_scope_close(ptr %s10)
  br label %bb52
bb52:
  %t223 = load i32, ptr %l7, !tbaa !23
  %t225 = icmp eq i32 %t223, 1
  br i1 %t225, label %bb53, label %bb54
bb53:
  store i1 true, ptr %l105, !tbaa !21
  br label %bb55
bb54:
  %t227 = load i32, ptr %l9, !tbaa !23
  %t229 = icmp eq i32 %t227, 1
  store i1 %t229, ptr %l105, !tbaa !21
  br label %bb55
bb55:
  %t231 = load i1, ptr %l105, !tbaa !21
  br i1 %t231, label %bb56, label %bb57
bb56:
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb57:
  br label %bb58
bb58:
  %t233 = load ptr, ptr %l0, !tbaa !29
  store ptr %t233, ptr %l109, !tbaa !29
  %t234 = load i32, ptr %l7, !tbaa !23
  %t236 = icmp eq i32 %t234, 3
  br i1 %t236, label %bb59, label %bb60
bb59:
  %t238 = load i32, ptr %l9, !tbaa !23
  %t240 = icmp eq i32 %t238, 3
  store i1 %t240, ptr %l112, !tbaa !21
  br label %bb61
bb60:
  store i1 false, ptr %l112, !tbaa !21
  br label %bb61
bb61:
  %t242 = load i1, ptr %l112, !tbaa !21
  br i1 %t242, label %bb62, label %bb63
bb62:
  store i32 3, ptr %l115, !tbaa !23
  br label %bb64
bb63:
  store i32 0, ptr %l115, !tbaa !23
  br label %bb64
bb64:
  %t243 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t244 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t246 = load ptr, ptr %l109, !tbaa !29
  %t247 = load i32, ptr %l115, !tbaa !23
  %t251 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2etestsEnded(ptr %v0, ptr %v4, ptr %v5, ptr %v6, ptr %t246, i32 %t247, { i64, ptr } %t243, { i64, ptr } %t244, ptr %a6)
  store i32 %t251, ptr %l119
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s0)
  %t252 = load i32, ptr %l119, !tbaa !23
  store i32 %t252, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2erunTests(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4, { i64, ptr } %a5, i64 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca i32
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca i1
  %l22 = alloca i32
  %l24 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i64
  %l41 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l50 = alloca i64
  %l53 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l70 = alloca ptr
  %l72 = alloca { i64, ptr }
  %l74 = alloca i32
  %l80 = alloca ptr
  %l81 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l91 = alloca i1
  %l94 = alloca i1
  %l102 = alloca { i64, ptr }
  %l106 = alloca i1
  %l113 = alloca i32
  %s0 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l17
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l7
  %t3 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t5 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v5, ptr %s0, { i64, ptr } %t3, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d252, i32 0, i32 1) })
  store i1 %t5, ptr %l19
  br label %bb2
bb2:
  %t6 = load i1, ptr %l19, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb3, label %bb4
bb3:
  %t9 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t11 = call i32 @std_2fos_2eRemove(ptr %v5, { i64, ptr } %t9)
  store i32 %t11, ptr %l22
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb6, label %ok.13, !prof !99
ok.13:
  br label %bb5
bb4:
  br label %bb15
bb5:
  br label %bb10
bb6:
  %t14 = load i32, ptr %l22, !tbaa !23
  %t15 = ashr i32 %t14, 16
  %t17 = icmp eq i32 %t15, 1
  store i1 %t17, ptr %l24, !tbaa !21
  %t18 = load i32, ptr %l22, !tbaa !23
  %t19 = ashr i32 %t18, 16
  %t21 = icmp eq i32 %t19, 1
  br i1 %t21, label %bb7, label %bb8
bb7:
  call void @__olang_errpay_pop()
  br label %bb8
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l7, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d253, i32 0, i32 1) })
  br label %bb11
bb11:
  store ptr %l7, ptr %l28, !tbaa !29
  %t24 = call ptr @__olang_scope_hold(ptr %s0)
  %t25 = ptrtoint ptr %t24 to i64
  store i64 %t25, ptr %l29, !tbaa !24
  %t26 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t26, label %bb12, label %bb13
bb12:
  %t28 = call ptr @__olang_region_make(ptr %s0)
  %t29 = ptrtoint ptr %t28 to i64
  store i64 %t29, ptr %l29, !tbaa !24
  br label %bb13
bb13:
  %t30 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t31 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d254, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d254, i32 0, i32 1) }, 0
  %t34 = extractvalue { i64, ptr } %t30, 1
  %t35 = extractvalue { i64, ptr } %t30, 0
  %t36 = add i64 %t32, %t35
  %t37 = load i64, ptr %l29
  %t38 = inttoptr i64 %t37 to ptr
  %t39 = call ptr @__olang_held_alloc(ptr %t38, i64 %t36)
  call void @olang_textcopy(ptr %t39, ptr %t31, i64 %t32)
  %t40 = getelementptr i8, ptr %t39, i64 %t32
  call void @olang_textcopy(ptr %t40, ptr %t34, i64 %t35)
  %t41 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t39, 1
  %t44 = load ptr, ptr %l28, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t44, { i64, ptr } %t42)
  br label %bb14
bb14:
  br label %bb15
bb15:
  store { i64, ptr } %a1, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t48 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t48, 0
  store i64 %t50, ptr %l10, !tbaa !24
  br label %bb16
bb16:
  %t52 = load i64, ptr %l9, !tbaa !24
  %t53 = load i64, ptr %l10, !tbaa !24
  %t56 = icmp slt i64 %t52, %t53
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb17, label %bb18
bb17:
  br label %bb22
bb18:
  br label %bb19
bb19:
  %t60 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t60, ptr %l41, !tbaa !27
  %t61 = load i64, ptr %l9, !tbaa !24
  %t63 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr { i64, ptr }, ptr %t64, i64 %t61
  %t66 = load { i64, ptr }, ptr %t65, !tbaa !37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v1, ptr %l7, { i64, ptr } %t66)
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t71 = load i64, ptr %l9, !tbaa !24
  %t74 = add i64 %t71, 1
  store i64 %t74, ptr %l9, !tbaa !24
  br label %bb16
bb22:
  store ptr %l7, ptr %l49, !tbaa !29
  %t76 = call ptr @__olang_scope_hold(ptr %s0)
  %t77 = ptrtoint ptr %t76 to i64
  store i64 %t77, ptr %l50, !tbaa !24
  %t78 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t78, label %bb23, label %bb24
bb23:
  %t80 = call ptr @__olang_region_make(ptr %s0)
  %t81 = ptrtoint ptr %t80 to i64
  store i64 %t81, ptr %l50, !tbaa !24
  br label %bb24
bb24:
  %t83 = load i64, ptr %l50
  %t84 = inttoptr i64 %t83 to ptr
  %t86 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %v2, ptr %t84, { i64, ptr } %a2)
  store { i64, ptr } %t86, ptr %l53
  br label %bb25
bb25:
  %t87 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t88 = load ptr, ptr %l49, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t88, { i64, ptr } %t87)
  br label %bb26
bb26:
  %t90 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t90, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  store i64 %t94, ptr %l14, !tbaa !24
  br label %bb27
bb27:
  %t96 = load i64, ptr %l13, !tbaa !24
  %t97 = load i64, ptr %l14, !tbaa !24
  %t100 = icmp slt i64 %t96, %t97
  %t102 = xor i1 %t100, true
  br i1 %t102, label %bb28, label %bb29
bb28:
  br label %bb33
bb29:
  br label %bb30
bb30:
  %t104 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t104, ptr %l62, !tbaa !27
  %t105 = load i64, ptr %l13, !tbaa !24
  %t107 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = getelementptr { i64, ptr }, ptr %t108, i64 %t105
  %t110 = load { i64, ptr }, ptr %t109, !tbaa !37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v4, ptr %l7, { i64, ptr } %t110)
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t115 = load i64, ptr %l13, !tbaa !24
  %t118 = add i64 %t115, 1
  store i64 %t118, ptr %l13, !tbaa !24
  br label %bb27
bb33:
  %t120 = load ptr, ptr %l0, !tbaa !29
  store ptr %t120, ptr %l70, !tbaa !29
  %t122 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %s0, ptr %s0, ptr %l7)
  store { i64, ptr } %t122, ptr %l72
  br label %bb34
bb34:
  %t124 = load ptr, ptr %l70, !tbaa !29
  %t125 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t127 = call i32 @compiler_2fbuild_2eexecTests(ptr %v0, ptr %s0, ptr %t124, { i64, ptr } %t125, i64 %a6)
  store i32 %t127, ptr %l74
  br label %bb35
bb35:
  %t128 = load i32, ptr %l74, !tbaa !23
  store i32 %t128, ptr %l16, !tbaa !23
  %t129 = load i32, ptr %l16, !tbaa !23
  %t131 = icmp slt i32 %t129, 0
  br i1 %t131, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb37:
  br label %bb38
bb38:
  %t134 = load i32, ptr %l16, !tbaa !23
  %t136 = icmp sgt i32 %t134, 128
  br i1 %t136, label %bb39, label %bb40
bb39:
  store %olang.scope zeroinitializer, ptr %s11
  %t138 = load ptr, ptr %l0, !tbaa !29
  store ptr %t138, ptr %l80, !tbaa !29
  %t139 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t139, ptr %l81, !tbaa !27
  %t140 = load i32, ptr %l16, !tbaa !23
  %t142 = sub i32 %t140, 128
  %t144 = call { i64, ptr } @compiler_2fbuild_2eSignalName(ptr %s11, i32 %t142)
  store { i64, ptr } %t144, ptr %l84
  br label %bb41
bb40:
  %t145 = load i32, ptr %l16, !tbaa !23
  %t147 = icmp ne i32 %t145, 0
  br i1 %t147, label %bb44, label %bb45
bb41:
  %t149 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t150 = extractvalue { i64, ptr } %t149, 1
  %t151 = extractvalue { i64, ptr } %t149, 0
  %t152 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d255, i32 0, i32 1) }, 1
  %t153 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d255, i32 0, i32 1) }, 0
  %t154 = add i64 %t151, %t153
  %t155 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t156 = extractvalue { i64, ptr } %t155, 1
  %t157 = extractvalue { i64, ptr } %t155, 0
  %t158 = add i64 %t154, %t157
  %t159 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d256, i32 0, i32 1) }, 1
  %t160 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d256, i32 0, i32 1) }, 0
  %t161 = add i64 %t158, %t160
  %t162 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t161)
  call void @olang_textcopy(ptr %t162, ptr %t150, i64 %t151)
  %t163 = getelementptr i8, ptr %t162, i64 %t151
  call void @olang_textcopy(ptr %t163, ptr %t152, i64 %t153)
  %t164 = getelementptr i8, ptr %t163, i64 %t153
  call void @olang_textcopy(ptr %t164, ptr %t156, i64 %t157)
  %t165 = getelementptr i8, ptr %t164, i64 %t157
  call void @olang_textcopy(ptr %t165, ptr %t159, i64 %t160)
  %t166 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t167 = insertvalue { i64, ptr } %t166, ptr %t162, 1
  %t169 = load ptr, ptr %l80, !tbaa !29
  %t171 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %s11, ptr %s11, ptr %s11, ptr %t169, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d257, i32 0, i32 1) }, { i64, ptr } %t167)
  store { i64, ptr } %t171, ptr %l87
  br label %bb42
bb42:
  %t172 = load { i64, ptr }, ptr %l87, !tbaa !27
  call void @compiler_2fbuild_2esayln(ptr %s11, { i64, ptr } %t172)
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s11)
  br label %bb55
bb44:
  %t174 = load i32, ptr %l16, !tbaa !23
  %t176 = icmp ne i32 %t174, 1
  store i1 %t176, ptr %l91, !tbaa !21
  br label %bb46
bb45:
  store i1 false, ptr %l91, !tbaa !21
  br label %bb46
bb46:
  %t178 = load i1, ptr %l91, !tbaa !21
  br i1 %t178, label %bb47, label %bb48
bb47:
  %t179 = load i32, ptr %l16, !tbaa !23
  %t181 = icmp ne i32 %t179, 3
  store i1 %t181, ptr %l94, !tbaa !21
  br label %bb49
bb48:
  store i1 false, ptr %l94, !tbaa !21
  br label %bb49
bb49:
  %t183 = load i1, ptr %l94, !tbaa !21
  br i1 %t183, label %bb50, label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s14
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t185 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t186 = load i32, ptr %l16, !tbaa !23
  %t188 = extractvalue { i64, ptr } %t185, 1
  %t189 = extractvalue { i64, ptr } %t185, 0
  %t190 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d258, i32 0, i32 1) }, 1
  %t191 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d258, i32 0, i32 1) }, 0
  %t192 = add i64 %t189, %t191
  %t194 = sext i32 %t186 to i64
  %t195 = call i64 @__olang_fmt_i64(ptr null, i64 %t194)
  %t196 = add i64 %t192, %t195
  %t197 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d259, i32 0, i32 1) }, 1
  %t198 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d259, i32 0, i32 1) }, 0
  %t199 = add i64 %t196, %t198
  %t200 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t199)
  call void @olang_textcopy(ptr %t200, ptr %t188, i64 %t189)
  %t201 = getelementptr i8, ptr %t200, i64 %t189
  call void @olang_textcopy(ptr %t201, ptr %t190, i64 %t191)
  %t202 = getelementptr i8, ptr %t201, i64 %t191
  %t203 = call i64 @__olang_fmt_i64(ptr %t202, i64 %t194)
  %t204 = getelementptr i8, ptr %t202, i64 %t195
  call void @olang_textcopy(ptr %t204, ptr %t197, i64 %t198)
  %t205 = insertvalue { i64, ptr } undef, i64 %t199, 0
  %t206 = insertvalue { i64, ptr } %t205, ptr %t200, 1
  %t210 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %s14, ptr %s14, ptr %s14, ptr %t184, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d260, i32 0, i32 1) }, { i64, ptr } %t206)
  store { i64, ptr } %t210, ptr %l102
  br label %bb52
bb51:
  br label %bb54
bb52:
  %t211 = load { i64, ptr }, ptr %l102, !tbaa !27
  call void @compiler_2fbuild_2esayln(ptr %s14, { i64, ptr } %t211)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s14)
  br label %bb54
bb54:
  br label %bb55
bb55:
  %t213 = load i32, ptr %l16, !tbaa !23
  %t215 = icmp eq i32 %t213, 3
  br i1 %t215, label %bb56, label %bb57
bb56:
  %t217 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t219 = extractvalue { i64, ptr } %t217, 0
  %t221 = icmp sgt i64 %t219, 0
  store i1 %t221, ptr %l106, !tbaa !21
  br label %bb58
bb57:
  store i1 false, ptr %l106, !tbaa !21
  br label %bb58
bb58:
  %t223 = load i1, ptr %l106, !tbaa !21
  br i1 %t223, label %bb59, label %bb60
bb59:
  call void @__olang_scope_close(ptr %s0)
  store i32 3, ptr %rv
  br label %ret
bb60:
  br label %bb61
bb61:
  %t225 = load i32, ptr %l16, !tbaa !23
  %t227 = icmp eq i32 %t225, 0
  br i1 %t227, label %bb62, label %bb63
bb62:
  store i32 0, ptr %l113, !tbaa !23
  br label %bb64
bb63:
  store i32 1, ptr %l113, !tbaa !23
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s0)
  %t229 = load i32, ptr %l113, !tbaa !23
  store i32 %t229, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewant(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %a0, ptr %a1, { i64, ptr } %a2, i32 %a3, { i64, ptr } %a4, ptr %a5, { i64, ptr } %a6, i64 %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca i1
  %l10 = alloca { i64, ptr }
  %lp11 = alloca ptr
  %l12 = alloca i1
  %lp14 = alloca ptr
  %l15 = alloca { i64, ptr }
  %lp17 = alloca ptr
  %lp20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca i64
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca i1
  %l40 = alloca i1
  %l42 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l47 = alloca ptr
  %l48 = alloca { i64, ptr }
  %l49 = alloca i32
  %l51 = alloca { i64, ptr }
  %l52 = alloca i64
  %l57 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l64 = alloca i1
  %l68 = alloca { i64, ptr }
  %l69 = alloca i64
  %l70 = alloca { i64, ptr }
  %l74 = alloca i1
  %l75 = alloca i1
  %l77 = alloca i1
  %l78 = alloca i1
  %l81 = alloca i1
  %l83 = alloca { i64, ptr }
  %l85 = alloca i1
  %l86 = alloca { i64, ptr }
  %l87 = alloca i64
  %l88 = alloca { i64, ptr }
  %l91 = alloca i1
  %l95 = alloca { i64, ptr }
  %l97 = alloca { i64, ptr }
  %l101 = alloca i64
  %l103 = alloca { i64, ptr }
  %l105 = alloca i64
  %l106 = alloca i64
  %l112 = alloca { i64, ptr }
  %l114 = alloca { i64, ptr }
  %l116 = alloca i32
  %l118 = alloca i1
  %l123 = alloca i1
  %l125 = alloca { i64, ptr }
  %l127 = alloca i1
  %l129 = alloca { i64, ptr }
  %l133 = alloca i64
  %l135 = alloca i64
  %l136 = alloca i64
  %l144 = alloca i32
  %l146 = alloca i1
  %l150 = alloca i1
  %l151 = alloca { i64, ptr }
  %l152 = alloca i64
  %l153 = alloca { i64, ptr }
  %l156 = alloca i1
  %l159 = alloca i1
  %l164 = alloca { i64, ptr }
  %l165 = alloca i64
  %l166 = alloca { i64, ptr }
  %l167 = alloca i64
  %l171 = alloca i64
  %l172 = alloca i64
  %l177 = alloca { i64, ptr }
  %l182 = alloca { i64, ptr }
  %l183 = alloca { i64, ptr }
  %l185 = alloca { i64, ptr }
  %l187 = alloca { i64, ptr }
  %l190 = alloca i1
  %l192 = alloca i1
  %l197 = alloca i1
  %l199 = alloca i64
  %l201 = alloca { i64, ptr }
  %l202 = alloca i64
  %l203 = alloca { i64, ptr }
  %l204 = alloca { i64, ptr }
  %l209 = alloca i64
  %l210 = alloca i64
  %l214 = alloca { i64, ptr }
  %l215 = alloca i32
  %l218 = alloca i1
  %l219 = alloca i1
  %l222 = alloca { i64, ptr }
  %l223 = alloca i1
  %l225 = alloca { i64, ptr }
  %l229 = alloca { i64, ptr }
  %l234 = alloca i32
  %l236 = alloca i1
  %l239 = alloca { i64, ptr }
  %l240 = alloca %"compiler/diagmsg:Msg"
  %l245 = alloca i1
  %l248 = alloca i32
  %l250 = alloca i1
  %l253 = alloca ptr
  %l254 = alloca { i64, [3 x i64] }
  %l256 = alloca %"compiler/diagmsg:Msg"
  %l258 = alloca { i64, ptr }
  %l259 = alloca i32
  %l261 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l267 = alloca i64
  %l269 = alloca i64
  %l274 = alloca { i64, ptr }
  %l287 = alloca ptr
  %l288 = alloca i64
  %l295 = alloca ptr
  %l296 = alloca i64
  %l299 = alloca { i64, ptr }
  %l301 = alloca { i64, ptr }
  %l303 = alloca { i64, ptr }
  %l306 = alloca ptr
  %l307 = alloca i64
  %l310 = alloca { i64, ptr }
  %l315 = alloca ptr
  %l316 = alloca i64
  %l319 = alloca { i64, ptr }
  %l323 = alloca { i64, ptr }
  %l339 = alloca { i64, ptr }
  %l340 = alloca i64
  %l341 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %t704 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i32 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  store ptr %a5, ptr %l5
  store { i64, ptr } %a6, ptr %l6
  store i64 %a7, ptr %l7
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l3, !range !{i32 0, i32 5}
  %t3 = trunc i64 4 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eDataFlags(ptr %v0, ptr %v1, ptr %t6)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l29
  br label %bb3
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t13 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eCompileFlags(ptr %v0, ptr %v3, ptr %v1, ptr %t9, { i64, ptr } %t10)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l32
  br label %bb4
bb3:
  %t14 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l29
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l27
  br label %bb5
bb4:
  %t15 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %l27
  br label %bb5
bb5:
  %t16 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %l8
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/build:Config", ptr %t17, i32 0, i32 39
  %t20 = load i1, ptr %t19, !tbaa !21
  br i1 %t20, label %bb6, label %bb7
bb6:
  %t22 = load i32, ptr %l3, !range !{i32 0, i32 5}
  %t24 = trunc i64 4 to i32
  %t25 = icmp eq i32 %t22, %t24
  %t27 = xor i1 %t25, true
  store i1 %t27, ptr %l35, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb8
bb8:
  %t29 = load i1, ptr %l35, !tbaa !21
  store i1 %t29, ptr %l9, !tbaa !21
  %t30 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t32 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v5, ptr %s0, { i64, ptr } %t30, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d261, i32 0, i32 1) })
  store i1 %t32, ptr %l40
  br label %bb9
bb9:
  %t33 = load i1, ptr %l40, !tbaa !21
  %t34 = xor i1 %t33, true
  br i1 %t34, label %bb10, label %bb11
bb10:
  %t36 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t36, ptr %l42, !tbaa !27
  br label %bb13
bb11:
  %t38 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t40 = call { i64, ptr } @compiler_2fbuild_2eIrHash(ptr %v3, ptr %v5, { i64, ptr } %t38)
  store { i64, ptr } %t40, ptr %l45
  br label %bb12
bb12:
  %t41 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t41, ptr %l42, !tbaa !27
  br label %bb13
bb13:
  %t43 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t43, ptr %l10, !tbaa !27
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l47, !tbaa !29
  %t45 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t45, ptr %l48, !tbaa !27
  %t46 = load i32, ptr %l3, !range !{i32 0, i32 5}
  store i32 %t46, ptr %l49
  %t47 = load i1, ptr %l9, !tbaa !21
  br i1 %t47, label %bb14, label %bb15
bb14:
  %t49 = call ptr @__olang_scope_hold(ptr %v5)
  %t50 = ptrtoint ptr %t49 to i64
  store i64 %t50, ptr %l52, !tbaa !24
  %t51 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t51, label %bb16, label %bb17
bb15:
  %t53 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t53, ptr %l51, !tbaa !27
  br label %bb19
bb16:
  %t55 = call ptr @__olang_region_make(ptr %v5)
  %t56 = ptrtoint ptr %t55 to i64
  store i64 %t56, ptr %l52, !tbaa !24
  br label %bb17
bb17:
  %t57 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t57, 1
  %t60 = extractvalue { i64, ptr } %t57, 0
  %t61 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d262, i32 0, i32 1) }, 1
  %t62 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d262, i32 0, i32 1) }, 0
  %t63 = add i64 %t60, %t62
  %t64 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t63)
  call void @olang_textcopy(ptr %t64, ptr %t59, i64 %t60)
  %t65 = getelementptr i8, ptr %t64, i64 %t60
  call void @olang_textcopy(ptr %t65, ptr %t61, i64 %t62)
  %t66 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t64, 1
  %t69 = load i64, ptr %l52
  %t70 = inttoptr i64 %t69 to ptr
  %t72 = call { i64, ptr } @compiler_2fbuild_2eIrHash(ptr %s0, ptr %t70, { i64, ptr } %t67)
  store { i64, ptr } %t72, ptr %l57
  br label %bb18
bb18:
  %t73 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t73, ptr %l51, !tbaa !27
  br label %bb19
bb19:
  %t75 = load ptr, ptr %l47, !tbaa !29
  %t76 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t77 = load i32, ptr %l49, !range !{i32 0, i32 5}
  %t78 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t80 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjectPath(ptr %v0, ptr %v2, ptr %v5, ptr %v1, ptr %v6, ptr %t75, { i64, ptr } %t76, i32 %t77, { i64, ptr } %t78, ptr %l8)
  store { i64, ptr } %t80, ptr %l61
  br label %bb20
bb20:
  %t81 = call ptr @__olang_scope_alloc_a(ptr %v6, i64 16, i64 8)
  store ptr %t81, ptr %lp11
  %t82 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t83 = load ptr, ptr %lp11
  store { i64, ptr } %t82, ptr %t83, !tbaa !27
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/build:Config", ptr %t84, i32 0, i32 22
  %t87 = load i1, ptr %t86, !tbaa !21
  br i1 %t87, label %bb21, label %bb22
bb21:
  %t89 = load i32, ptr %l3, !range !{i32 0, i32 5}
  %t91 = trunc i64 4 to i32
  %t92 = icmp eq i32 %t89, %t91
  %t94 = xor i1 %t92, true
  store i1 %t94, ptr %l64, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb23
bb23:
  %t96 = load i1, ptr %l64, !tbaa !21
  store i1 %t96, ptr %l12, !tbaa !21
  %t97 = load ptr, ptr %lp11
  %t98 = load { i64, ptr }, ptr %t97, !tbaa !27
  store { i64, ptr } %t98, ptr %l68, !tbaa !27
  %t99 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t99, 0
  store i64 %t100, ptr %l69, !tbaa !24
  %t101 = load i64, ptr %l69, !tbaa !24
  %t102 = mul i64 %t101, 1
  %t103 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t102)
  %t104 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t105 = insertvalue { i64, ptr } %t104, ptr %t103, 1
  store { i64, ptr } %t105, ptr %l70, !tbaa !27
  %t106 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = load i64, ptr %l69, !tbaa !24
  %t111 = mul i64 %t110, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t107, ptr %t109, i64 %t111, i1 false)
  %t112 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t113 = load ptr, ptr %l1, !tbaa !29
  %t115 = getelementptr %"compiler/build:compiles", ptr %t113, i32 0, i32 2
  %t119 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H0127831368543eff3b7740d7d3240080(ptr %v1, ptr %s0, ptr %t115, { i64, ptr } %t112)
  store i1 %t119, ptr %l74
  br label %bb24
bb24:
  %t120 = load i1, ptr %l74, !tbaa !21
  br i1 %t120, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l75, !tbaa !21
  br label %bb36
bb26:
  %t121 = load ptr, ptr %lp11
  %t122 = load { i64, ptr }, ptr %t121, !tbaa !27
  %t124 = call i1 @std_2fos_2eExists(ptr %v6, { i64, ptr } %t122)
  store i1 %t124, ptr %l77
  br label %bb27
bb27:
  %t125 = load i1, ptr %l77, !tbaa !21
  br i1 %t125, label %bb28, label %bb29
bb28:
  %t126 = load i1, ptr %l12, !tbaa !21
  %t128 = xor i1 %t126, true
  br i1 %t128, label %bb30, label %bb31
bb29:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb35
bb30:
  store i1 true, ptr %l81, !tbaa !21
  br label %bb34
bb31:
  %t130 = load ptr, ptr %lp11
  %t131 = load { i64, ptr }, ptr %t130, !tbaa !27
  %t133 = call { i64, ptr } @compiler_2fbuild_2eRemarksOf(ptr %v6, ptr %s0, { i64, ptr } %t131)
  store { i64, ptr } %t133, ptr %l83
  br label %bb32
bb32:
  %t134 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t136 = call i1 @std_2fos_2eExists(ptr %s0, { i64, ptr } %t134)
  store i1 %t136, ptr %l85
  br label %bb33
bb33:
  %t137 = load i1, ptr %l85, !tbaa !21
  store i1 %t137, ptr %l81, !tbaa !21
  br label %bb34
bb34:
  %t138 = load i1, ptr %l81, !tbaa !21
  store i1 %t138, ptr %l78, !tbaa !21
  br label %bb35
bb35:
  %t139 = load i1, ptr %l78, !tbaa !21
  store i1 %t139, ptr %l75, !tbaa !21
  br label %bb36
bb36:
  %t140 = load i1, ptr %l75, !tbaa !21
  br i1 %t140, label %bb37, label %bb38
bb37:
  %t141 = load ptr, ptr %lp11
  %t142 = load { i64, ptr }, ptr %t141, !tbaa !27
  store { i64, ptr } %t142, ptr %l86, !tbaa !27
  %t143 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t144 = extractvalue { i64, ptr } %t143, 0
  store i64 %t144, ptr %l87, !tbaa !24
  %t145 = load i64, ptr %l87, !tbaa !24
  %t146 = mul i64 %t145, 1
  %t147 = call ptr @__olang_scope_alloc(ptr %v6, i64 %t146)
  %t148 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t147, 1
  store { i64, ptr } %t149, ptr %l88, !tbaa !27
  %t150 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = load i64, ptr %l87, !tbaa !24
  %t155 = mul i64 %t154, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t151, ptr %t153, i64 %t155, i1 false)
  %t156 = load { i64, ptr }, ptr %l88, !tbaa !27
  store { i64, ptr } %t156, ptr %l86, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t157 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t158 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t157, 1
  store { i32, { i64, ptr } } %t158, ptr %rv
  br label %ret
bb38:
  br label %bb39
bb39:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/build:Config", ptr %t159, i32 0, i32 40
  %t162 = load { i64, ptr }, ptr %t161, !tbaa !27
  %t164 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t162, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d263, i32 0, i32 1) })
  store i1 %t164, ptr %l91
  br label %bb40
bb40:
  %t165 = load i1, ptr %l91, !tbaa !21
  %t166 = xor i1 %t165, true
  br i1 %t166, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s3
  %t168 = load i1, ptr %l12, !tbaa !21
  br i1 %t168, label %bb43, label %bb44
bb42:
  br label %bb85
bb43:
  store %olang.scope zeroinitializer, ptr %s4
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/build:Config", ptr %t170, i32 0, i32 40
  %t173 = load { i64, ptr }, ptr %t172, !tbaa !27
  store { i64, ptr } %t173, ptr %l95, !tbaa !27
  %t174 = load ptr, ptr %lp11
  %t175 = load { i64, ptr }, ptr %t174, !tbaa !27
  %t177 = call { i64, ptr } @compiler_2fbuild_2eRemarksOf(ptr %v6, ptr %s4, { i64, ptr } %t175)
  store { i64, ptr } %t177, ptr %l97
  br label %bb45
bb44:
  br label %bb60
bb45:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr %"compiler/build:Config", ptr %t178, i32 0, i32 0
  %t181 = load { i64, ptr }, ptr %t180, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t181, 0
  %t185 = add i64 %t183, 1
  store i64 %t185, ptr %l101, !tbaa !24
  %t186 = load ptr, ptr %lp11
  %t187 = load { i64, ptr }, ptr %t186, !tbaa !27
  %t189 = call { i64, ptr } @compiler_2fbuild_2eRemarksOf(ptr %v6, ptr %s4, { i64, ptr } %t187)
  store { i64, ptr } %t189, ptr %l103
  br label %bb46
bb46:
  %t190 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t190, 0
  store i64 %t192, ptr %l105, !tbaa !24
  %t193 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t194 = extractvalue { i64, ptr } %t193, 0
  store i64 %t194, ptr %l106, !tbaa !24
  %t195 = load i64, ptr %l101, !tbaa !24
  %t196 = icmp sge i64 %t195, 0
  br i1 %t196, label %bb47, label %bb48
bb47:
  %t198 = load i64, ptr %l101, !tbaa !24
  %t199 = load i64, ptr %l105, !tbaa !24
  %t200 = icmp sle i64 %t198, %t199
  br i1 %t200, label %bb49, label %bb50
bb48:
  call void @__olang_check_failed(ptr @olang_loc_81dfa638548de3d7_ab0731b6a5acba3)
  unreachable
bb49:
  %t202 = load i64, ptr %l105, !tbaa !24
  %t203 = load i64, ptr %l106, !tbaa !24
  %t204 = icmp sle i64 %t202, %t203
  br i1 %t204, label %bb51, label %bb52
bb50:
  call void @__olang_check_failed(ptr @olang_loc_81dfa638548de3d7_ab0731b6a5acba3)
  unreachable
bb51:
  %t206 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t207 = load ptr, ptr %t206, !tbaa !27
  %t208 = load i64, ptr %l101, !tbaa !24
  %t209 = load i64, ptr %l105, !tbaa !24
  %t210 = getelementptr i8, ptr %t207, i64 %t208
  %t211 = sub i64 %t209, %t208
  %t212 = insertvalue { i64, ptr } undef, i64 %t211, 0
  %t213 = insertvalue { i64, ptr } %t212, ptr %t210, 1
  %t214 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t215 = extractvalue { i64, ptr } %t214, 1
  %t216 = extractvalue { i64, ptr } %t214, 0
  %t217 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d264, i32 0, i32 1) }, 1
  %t218 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d264, i32 0, i32 1) }, 0
  %t219 = add i64 %t216, %t218
  %t221 = extractvalue { i64, ptr } %t213, 1
  %t222 = extractvalue { i64, ptr } %t213, 0
  %t223 = add i64 %t219, %t222
  %t224 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t223)
  call void @olang_textcopy(ptr %t224, ptr %t215, i64 %t216)
  %t225 = getelementptr i8, ptr %t224, i64 %t216
  call void @olang_textcopy(ptr %t225, ptr %t217, i64 %t218)
  %t226 = getelementptr i8, ptr %t225, i64 %t218
  call void @olang_textcopy(ptr %t226, ptr %t221, i64 %t222)
  %t227 = insertvalue { i64, ptr } undef, i64 %t223, 0
  %t228 = insertvalue { i64, ptr } %t227, ptr %t224, 1
  store { i64, ptr } %t228, ptr %l112, !tbaa !27
  %t230 = load ptr, ptr %lp11
  %t231 = load { i64, ptr }, ptr %t230, !tbaa !27
  %t233 = call { i64, ptr } @compiler_2fbuild_2eRemarksOf(ptr %v6, ptr %s4, { i64, ptr } %t231)
  store { i64, ptr } %t233, ptr %l114
  br label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_81dfa638548de3d7_ab0731b6a5acba3)
  unreachable
bb53:
  %t234 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t235 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t237 = call i32 @std_2fos_2eLink(ptr %s4, ptr %s4, { i64, ptr } %t235, { i64, ptr } %t234)
  store i32 %t237, ptr %l116
  %t238 = icmp ne i32 %t237, 0
  br i1 %t238, label %bb55, label %ok.239, !prof !99
ok.239:
  br label %bb54
bb54:
  br label %bb59
bb55:
  %t240 = load i32, ptr %l116, !tbaa !23
  %t241 = ashr i32 %t240, 16
  %t243 = icmp eq i32 %t241, 1
  store i1 %t243, ptr %l118, !tbaa !21
  %t244 = load i32, ptr %l116, !tbaa !23
  %t245 = ashr i32 %t244, 16
  %t247 = icmp eq i32 %t245, 1
  br i1 %t247, label %bb56, label %bb57
bb56:
  call void @__olang_errpay_pop()
  br label %bb57
bb57:
  br label %bb58
bb58:
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s4)
  br label %bb60
bb60:
  %t249 = load i1, ptr %l12, !tbaa !21
  %t251 = xor i1 %t249, true
  br i1 %t251, label %bb61, label %bb62
bb61:
  store i1 true, ptr %l123, !tbaa !21
  br label %bb65
bb62:
  %t253 = load ptr, ptr %lp11
  %t254 = load { i64, ptr }, ptr %t253, !tbaa !27
  %t256 = call { i64, ptr } @compiler_2fbuild_2eRemarksOf(ptr %v6, ptr %s3, { i64, ptr } %t254)
  store { i64, ptr } %t256, ptr %l125
  br label %bb63
bb63:
  %t257 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t259 = call i1 @std_2fos_2eExists(ptr %s3, { i64, ptr } %t257)
  store i1 %t259, ptr %l127
  br label %bb64
bb64:
  %t260 = load i1, ptr %l127, !tbaa !21
  store i1 %t260, ptr %l123, !tbaa !21
  br label %bb65
bb65:
  %t261 = load i1, ptr %l123, !tbaa !21
  br i1 %t261, label %bb66, label %bb67
bb66:
  store %olang.scope zeroinitializer, ptr %s7
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t264 = getelementptr %"compiler/build:Config", ptr %t262, i32 0, i32 40
  %t265 = load { i64, ptr }, ptr %t264, !tbaa !27
  store { i64, ptr } %t265, ptr %l129, !tbaa !27
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t268 = getelementptr %"compiler/build:Config", ptr %t266, i32 0, i32 0
  %t269 = load { i64, ptr }, ptr %t268, !tbaa !27
  %t271 = extractvalue { i64, ptr } %t269, 0
  %t273 = add i64 %t271, 1
  store i64 %t273, ptr %l133, !tbaa !24
  %t274 = load ptr, ptr %lp11
  %t275 = load { i64, ptr }, ptr %t274, !tbaa !27
  %t277 = extractvalue { i64, ptr } %t275, 0
  store i64 %t277, ptr %l135, !tbaa !24
  %t278 = load ptr, ptr %lp11
  %t279 = load { i64, ptr }, ptr %t278, !tbaa !27
  %t280 = extractvalue { i64, ptr } %t279, 0
  store i64 %t280, ptr %l136, !tbaa !24
  %t281 = load i64, ptr %l133, !tbaa !24
  %t282 = icmp sge i64 %t281, 0
  br i1 %t282, label %bb68, label %bb69
bb67:
  br label %bb80
bb68:
  %t284 = load i64, ptr %l133, !tbaa !24
  %t285 = load i64, ptr %l135, !tbaa !24
  %t286 = icmp sle i64 %t284, %t285
  br i1 %t286, label %bb70, label %bb71
bb69:
  call void @__olang_check_failed(ptr @olang_loc_64cef890f5e30dfa_ab05d47f854753c6)
  unreachable
bb70:
  %t288 = load i64, ptr %l135, !tbaa !24
  %t289 = load i64, ptr %l136, !tbaa !24
  %t290 = icmp sle i64 %t288, %t289
  br i1 %t290, label %bb72, label %bb73
bb71:
  call void @__olang_check_failed(ptr @olang_loc_64cef890f5e30dfa_ab05d47f854753c6)
  unreachable
bb72:
  %t292 = load ptr, ptr %lp11
  %t293 = getelementptr { i64, ptr }, ptr %t292, i32 0, i32 1
  %t294 = load ptr, ptr %t293, !tbaa !27
  %t295 = load i64, ptr %l133, !tbaa !24
  %t296 = load i64, ptr %l135, !tbaa !24
  %t297 = getelementptr i8, ptr %t294, i64 %t295
  %t298 = sub i64 %t296, %t295
  %t299 = insertvalue { i64, ptr } undef, i64 %t298, 0
  %t300 = insertvalue { i64, ptr } %t299, ptr %t297, 1
  %t301 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t302 = extractvalue { i64, ptr } %t301, 1
  %t303 = extractvalue { i64, ptr } %t301, 0
  %t304 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d265, i32 0, i32 1) }, 1
  %t305 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d265, i32 0, i32 1) }, 0
  %t306 = add i64 %t303, %t305
  %t308 = extractvalue { i64, ptr } %t300, 1
  %t309 = extractvalue { i64, ptr } %t300, 0
  %t310 = add i64 %t306, %t309
  %t311 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t310)
  call void @olang_textcopy(ptr %t311, ptr %t302, i64 %t303)
  %t312 = getelementptr i8, ptr %t311, i64 %t303
  call void @olang_textcopy(ptr %t312, ptr %t304, i64 %t305)
  %t313 = getelementptr i8, ptr %t312, i64 %t305
  call void @olang_textcopy(ptr %t313, ptr %t308, i64 %t309)
  %t314 = insertvalue { i64, ptr } undef, i64 %t310, 0
  %t315 = insertvalue { i64, ptr } %t314, ptr %t311, 1
  %t317 = load ptr, ptr %lp11
  %t318 = load { i64, ptr }, ptr %t317, !tbaa !27
  %t321 = call i32 @std_2fos_2eLink(ptr %s7, ptr %v6, { i64, ptr } %t315, { i64, ptr } %t318)
  store i32 %t321, ptr %l144
  %t322 = icmp ne i32 %t321, 0
  br i1 %t322, label %bb75, label %ok.323, !prof !99
ok.323:
  br label %bb74
bb73:
  call void @__olang_check_failed(ptr @olang_loc_64cef890f5e30dfa_ab05d47f854753c6)
  unreachable
bb74:
  br label %bb79
bb75:
  %t324 = load i32, ptr %l144, !tbaa !23
  %t325 = ashr i32 %t324, 16
  %t327 = icmp eq i32 %t325, 1
  store i1 %t327, ptr %l146, !tbaa !21
  %t328 = load i32, ptr %l144, !tbaa !23
  %t329 = ashr i32 %t328, 16
  %t331 = icmp eq i32 %t329, 1
  br i1 %t331, label %bb76, label %bb77
bb76:
  call void @__olang_errpay_pop()
  br label %bb77
bb77:
  br label %bb78
bb78:
  br label %bb79
bb79:
  call void @__olang_scope_close(ptr %s7)
  br label %bb80
bb80:
  %t333 = load ptr, ptr %lp11
  %t334 = load { i64, ptr }, ptr %t333, !tbaa !27
  %t336 = call i1 @std_2fos_2eExists(ptr %v6, { i64, ptr } %t334)
  store i1 %t336, ptr %l150
  br label %bb81
bb81:
  %t337 = load i1, ptr %l150, !tbaa !21
  br i1 %t337, label %bb82, label %bb83
bb82:
  %t338 = load ptr, ptr %lp11
  %t339 = load { i64, ptr }, ptr %t338, !tbaa !27
  store { i64, ptr } %t339, ptr %l151, !tbaa !27
  %t340 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t341 = extractvalue { i64, ptr } %t340, 0
  store i64 %t341, ptr %l152, !tbaa !24
  %t342 = load i64, ptr %l152, !tbaa !24
  %t343 = mul i64 %t342, 1
  %t344 = call ptr @__olang_scope_alloc(ptr %v6, i64 %t343)
  %t345 = insertvalue { i64, ptr } undef, i64 %t342, 0
  %t346 = insertvalue { i64, ptr } %t345, ptr %t344, 1
  store { i64, ptr } %t346, ptr %l153, !tbaa !27
  %t347 = getelementptr { i64, ptr }, ptr %l153, i32 0, i32 1
  %t348 = load ptr, ptr %t347, !tbaa !27
  %t349 = getelementptr { i64, ptr }, ptr %l151, i32 0, i32 1
  %t350 = load ptr, ptr %t349, !tbaa !27
  %t351 = load i64, ptr %l152, !tbaa !24
  %t352 = mul i64 %t351, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t348, ptr %t350, i64 %t352, i1 false)
  %t353 = load { i64, ptr }, ptr %l153, !tbaa !27
  store { i64, ptr } %t353, ptr %l151, !tbaa !27
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t354 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t355 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t354, 1
  store { i32, { i64, ptr } } %t355, ptr %rv
  br label %ret
bb83:
  br label %bb84
bb84:
  call void @__olang_scope_close(ptr %s3)
  br label %bb85
bb85:
  %t356 = load i64, ptr %l7, !tbaa !24
  %t358 = icmp sge i64 %t356, 0
  br i1 %t358, label %bb86, label %bb87
bb86:
  %t360 = load ptr, ptr %l1, !tbaa !29
  %t361 = load ptr, ptr %lp11
  %t362 = load { i64, ptr }, ptr %t361, !tbaa !27
  %t365 = call i1 @compiler_2fbuild_2ecompiler_2fbuild_3acompiles_2eclaim(ptr %v1, ptr %v6, ptr %t360, { i64, ptr } %t362)
  store i1 %t365, ptr %l159
  br label %bb88
bb87:
  store i1 false, ptr %l156, !tbaa !21
  br label %bb89
bb88:
  %t366 = load i1, ptr %l159, !tbaa !21
  %t367 = xor i1 %t366, true
  store i1 %t367, ptr %l156, !tbaa !21
  br label %bb89
bb89:
  %t369 = load i1, ptr %l156, !tbaa !21
  br i1 %t369, label %bb90, label %bb91
bb90:
  %t370 = load ptr, ptr %l1, !tbaa !29
  %t372 = getelementptr %"compiler/build:compiles", ptr %t370, i32 0, i32 8
  %t373 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t372, i64 %t373)
  br label %bb92
bb91:
  br label %bb93
bb92:
  %t376 = load ptr, ptr %lp11
  %t377 = load { i64, ptr }, ptr %t376, !tbaa !27
  store { i64, ptr } %t377, ptr %l164, !tbaa !27
  %t378 = load { i64, ptr }, ptr %l164, !tbaa !27
  %t379 = extractvalue { i64, ptr } %t378, 0
  store i64 %t379, ptr %l165, !tbaa !24
  %t380 = load i64, ptr %l165, !tbaa !24
  %t381 = mul i64 %t380, 1
  %t382 = call ptr @__olang_scope_alloc(ptr %v6, i64 %t381)
  %t383 = insertvalue { i64, ptr } undef, i64 %t380, 0
  %t384 = insertvalue { i64, ptr } %t383, ptr %t382, 1
  store { i64, ptr } %t384, ptr %l166, !tbaa !27
  %t385 = getelementptr { i64, ptr }, ptr %l166, i32 0, i32 1
  %t386 = load ptr, ptr %t385, !tbaa !27
  %t387 = getelementptr { i64, ptr }, ptr %l164, i32 0, i32 1
  %t388 = load ptr, ptr %t387, !tbaa !27
  %t389 = load i64, ptr %l165, !tbaa !24
  %t390 = mul i64 %t389, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t386, ptr %t388, i64 %t390, i1 false)
  %t391 = load { i64, ptr }, ptr %l166, !tbaa !27
  store { i64, ptr } %t391, ptr %l164, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t392 = load { i64, ptr }, ptr %l164, !tbaa !27
  %t393 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t392, 1
  store { i32, { i64, ptr } } %t393, ptr %rv
  br label %ret
bb93:
  %t394 = call ptr @__olang_scope_hold(ptr %v4)
  %t395 = ptrtoint ptr %t394 to i64
  store i64 %t395, ptr %l167, !tbaa !24
  %t396 = load i1, ptr @olang_2esole_2ecompiler__2fbuild__2ecompiler__2fbuild__3aConfig__2ewant_2elocal_2e14
  br i1 %t396, label %bb94, label %bb95
bb94:
  %t398 = call ptr @__olang_region_make(ptr %v4)
  %t399 = ptrtoint ptr %t398 to i64
  store i64 %t399, ptr %l167, !tbaa !24
  br label %bb95
bb95:
  %t400 = load ptr, ptr %lp11
  %t401 = load { i64, ptr }, ptr %t400, !tbaa !27
  %t403 = extractvalue { i64, ptr } %t401, 0
  %t405 = sub i64 %t403, 2
  store i64 %t405, ptr %l171, !tbaa !24
  %t406 = load ptr, ptr %lp11
  %t407 = load { i64, ptr }, ptr %t406, !tbaa !27
  %t408 = extractvalue { i64, ptr } %t407, 0
  store i64 %t408, ptr %l172, !tbaa !24
  %t409 = icmp sge i64 0, 0
  br i1 %t409, label %bb96, label %bb97
bb96:
  %t411 = load i64, ptr %l171, !tbaa !24
  %t412 = icmp sle i64 0, %t411
  br i1 %t412, label %bb98, label %bb99
bb97:
  call void @__olang_check_failed(ptr @olang_loc_adf83e678ec27f19_e5a5f2a4f92e5ce5)
  unreachable
bb98:
  %t414 = load i64, ptr %l171, !tbaa !24
  %t415 = load i64, ptr %l172, !tbaa !24
  %t416 = icmp sle i64 %t414, %t415
  br i1 %t416, label %bb100, label %bb101
bb99:
  call void @__olang_check_failed(ptr @olang_loc_adf83e678ec27f19_e5a5f2a4f92e5ce5)
  unreachable
bb100:
  %t418 = load ptr, ptr %lp11
  %t419 = getelementptr { i64, ptr }, ptr %t418, i32 0, i32 1
  %t420 = load ptr, ptr %t419, !tbaa !27
  %t421 = load i64, ptr %l171, !tbaa !24
  %t422 = getelementptr i8, ptr %t420, i64 0
  %t423 = sub i64 %t421, 0
  %t424 = insertvalue { i64, ptr } undef, i64 %t423, 0
  %t425 = insertvalue { i64, ptr } %t424, ptr %t422, 1
  %t427 = extractvalue { i64, ptr } %t425, 1
  %t428 = extractvalue { i64, ptr } %t425, 0
  %t429 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d266, i32 0, i32 1) }, 1
  %t430 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d266, i32 0, i32 1) }, 0
  %t431 = add i64 %t428, %t430
  %t432 = load i64, ptr %l167
  %t433 = inttoptr i64 %t432 to ptr
  %t434 = call ptr @__olang_held_alloc(ptr %t433, i64 %t431)
  call void @olang_textcopy(ptr %t434, ptr %t427, i64 %t428)
  %t435 = getelementptr i8, ptr %t434, i64 %t428
  call void @olang_textcopy(ptr %t435, ptr %t429, i64 %t430)
  %t436 = insertvalue { i64, ptr } undef, i64 %t431, 0
  %t437 = insertvalue { i64, ptr } %t436, ptr %t434, 1
  store { i64, ptr } %t437, ptr %l177, !tbaa !27
  %t438 = load i1, ptr @olang_2esole_2ecompiler__2fbuild__2ecompiler__2fbuild__3aConfig__2ewant_2elocal_2e14
  br i1 %t438, label %bb102, label %bb103
bb101:
  call void @__olang_check_failed(ptr @olang_loc_adf83e678ec27f19_e5a5f2a4f92e5ce5)
  unreachable
bb102:
  %t440 = load { i64, ptr }, ptr %l177, !tbaa !27
  %t441 = extractvalue { i64, ptr } %t440, 0
  %t443 = icmp eq i64 %t441, 0
  br i1 %t443, label %bb104, label %bb105
bb103:
  %t445 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 16, i64 8)
  store ptr %t445, ptr %lp14
  %t446 = load { i64, ptr }, ptr %l177, !tbaa !27
  %t447 = load ptr, ptr %lp14
  store { i64, ptr } %t446, ptr %t447, !tbaa !27
  %t448 = load ptr, ptr %l0, !tbaa !29
  %t450 = getelementptr %"compiler/build:Config", ptr %t448, i32 0, i32 0
  %t451 = load { i64, ptr }, ptr %t450, !tbaa !27
  store { i64, ptr } %t451, ptr %l182, !tbaa !27
  %t452 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t452, ptr %l183, !tbaa !27
  %t453 = load i32, ptr %l3, !range !{i32 0, i32 5}
  %t455 = call { i64, ptr } @compiler_2fbuild_2ekindSuffix(ptr %s0, i32 %t453)
  store { i64, ptr } %t455, ptr %l185
  br label %bb106
bb104:
  store { i64, ptr } zeroinitializer, ptr %l177, !tbaa !27
  br label %bb105
bb105:
  %t456 = load i64, ptr %l167
  %t457 = inttoptr i64 %t456 to ptr
  %t458 = load { i64, ptr }, ptr %l177
  %t459 = extractvalue { i64, ptr } %t458, 1
  %t460 = call ptr @__olang_region_or(ptr %t459, ptr null)
  %t461 = icmp ne ptr %t460, null
  %t462 = select i1 %t461, ptr %t460, ptr null
  call void @__olang_region_settle_in(ptr %t457, ptr %t462)
  br label %bb103
bb106:
  %t463 = load ptr, ptr %l0, !tbaa !29
  %t465 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v0, ptr %s0, ptr %t463)
  store { i64, ptr } %t465, ptr %l187
  br label %bb107
bb107:
  %t466 = load { i64, ptr }, ptr %l182, !tbaa !27
  %t467 = extractvalue { i64, ptr } %t466, 1
  %t468 = extractvalue { i64, ptr } %t466, 0
  %t469 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d267, i32 0, i32 1) }, 1
  %t470 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d267, i32 0, i32 1) }, 0
  %t471 = add i64 %t468, %t470
  %t472 = load { i64, ptr }, ptr %l183, !tbaa !27
  %t473 = extractvalue { i64, ptr } %t472, 1
  %t474 = extractvalue { i64, ptr } %t472, 0
  %t475 = add i64 %t471, %t474
  %t476 = load { i64, ptr }, ptr %l185, !tbaa !27
  %t477 = extractvalue { i64, ptr } %t476, 1
  %t478 = extractvalue { i64, ptr } %t476, 0
  %t479 = add i64 %t475, %t478
  %t480 = load { i64, ptr }, ptr %l187, !tbaa !27
  %t481 = extractvalue { i64, ptr } %t480, 1
  %t482 = extractvalue { i64, ptr } %t480, 0
  %t483 = add i64 %t479, %t482
  %t484 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d268, i32 0, i32 1) }, 1
  %t485 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d268, i32 0, i32 1) }, 0
  %t486 = add i64 %t483, %t485
  %t487 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t486)
  call void @olang_textcopy(ptr %t487, ptr %t467, i64 %t468)
  %t488 = getelementptr i8, ptr %t487, i64 %t468
  call void @olang_textcopy(ptr %t488, ptr %t469, i64 %t470)
  %t489 = getelementptr i8, ptr %t488, i64 %t470
  call void @olang_textcopy(ptr %t489, ptr %t473, i64 %t474)
  %t490 = getelementptr i8, ptr %t489, i64 %t474
  call void @olang_textcopy(ptr %t490, ptr %t477, i64 %t478)
  %t491 = getelementptr i8, ptr %t490, i64 %t478
  call void @olang_textcopy(ptr %t491, ptr %t481, i64 %t482)
  %t492 = getelementptr i8, ptr %t491, i64 %t482
  call void @olang_textcopy(ptr %t492, ptr %t484, i64 %t485)
  %t493 = insertvalue { i64, ptr } undef, i64 %t486, 0
  %t494 = insertvalue { i64, ptr } %t493, ptr %t487, 1
  store { i64, ptr } %t494, ptr %l15, !tbaa !27
  %t496 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t498 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v2, ptr %s0, { i64, ptr } %t496, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d269, i32 0, i32 1) })
  store i1 %t498, ptr %l190
  br label %bb108
bb108:
  %t499 = load i1, ptr %l190, !tbaa !21
  %t500 = xor i1 %t499, true
  br i1 %t500, label %bb109, label %bb110
bb109:
  %t502 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t504 = load ptr, ptr %l1, !tbaa !29
  %t506 = getelementptr %"compiler/build:compiles", ptr %t504, i32 0, i32 3
  %t510 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H0127831368543eff3b7740d7d3240080(ptr %v1, ptr %s0, ptr %t506, { i64, ptr } %t502)
  store i1 %t510, ptr %l197
  br label %bb111
bb110:
  store i1 false, ptr %l192, !tbaa !21
  br label %bb112
bb111:
  %t511 = load i1, ptr %l197, !tbaa !21
  %t512 = xor i1 %t511, true
  store i1 %t512, ptr %l192, !tbaa !21
  br label %bb112
bb112:
  %t514 = load i1, ptr %l192, !tbaa !21
  br i1 %t514, label %bb113, label %bb114
bb113:
  %t515 = call ptr @__olang_scope_hold(ptr %v4)
  %t516 = ptrtoint ptr %t515 to i64
  store i64 %t516, ptr %l199, !tbaa !24
  %t517 = load i1, ptr @olang_2esole_2ecompiler__2fbuild__2ecompiler__2fbuild__3aConfig__2ewant_2elocal_2e14
  br i1 %t517, label %bb115, label %bb116
bb114:
  br label %bb121
bb115:
  %t519 = call ptr @__olang_region_make(ptr %v4)
  %t520 = ptrtoint ptr %t519 to i64
  store i64 %t520, ptr %l199, !tbaa !24
  br label %bb116
bb116:
  %t521 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t521, ptr %l201, !tbaa !27
  %t522 = load { i64, ptr }, ptr %l201, !tbaa !27
  %t523 = extractvalue { i64, ptr } %t522, 0
  store i64 %t523, ptr %l202, !tbaa !24
  %t524 = load i64, ptr %l202, !tbaa !24
  %t525 = mul i64 %t524, 1
  %t526 = load i64, ptr %l199
  %t527 = inttoptr i64 %t526 to ptr
  %t528 = call ptr @__olang_held_alloc(ptr %t527, i64 %t525)
  %t529 = insertvalue { i64, ptr } undef, i64 %t524, 0
  %t530 = insertvalue { i64, ptr } %t529, ptr %t528, 1
  store { i64, ptr } %t530, ptr %l203, !tbaa !27
  %t531 = getelementptr { i64, ptr }, ptr %l203, i32 0, i32 1
  %t532 = load ptr, ptr %t531, !tbaa !27
  %t533 = getelementptr { i64, ptr }, ptr %l201, i32 0, i32 1
  %t534 = load ptr, ptr %t533, !tbaa !27
  %t535 = load i64, ptr %l202, !tbaa !24
  %t536 = mul i64 %t535, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t532, ptr %t534, i64 %t536, i1 false)
  %t537 = load ptr, ptr %lp14
  %t538 = load { i64, ptr }, ptr %t537, !tbaa !27
  store { i64, ptr } %t538, ptr %l204, !tbaa !27
  %t539 = load { i64, ptr }, ptr %l203, !tbaa !27
  %t540 = load ptr, ptr %lp14
  store { i64, ptr } %t539, ptr %t540, !tbaa !27
  %t541 = load i1, ptr @olang_2esole_2ecompiler__2fbuild__2ecompiler__2fbuild__3aConfig__2ewant_2elocal_2e14
  br i1 %t541, label %bb117, label %bb118
bb117:
  %t543 = load { i64, ptr }, ptr %l204
  %t544 = extractvalue { i64, ptr } %t543, 1
  call void @__olang_region_release(ptr %t544)
  store { i64, ptr } zeroinitializer, ptr %l204
  br label %bb118
bb118:
  %t545 = load i1, ptr @olang_2esole_2ecompiler__2fbuild__2ecompiler__2fbuild__3aConfig__2ewant_2elocal_2e14
  br i1 %t545, label %bb119, label %bb120
bb119:
  %t547 = load ptr, ptr %lp14
  %t548 = load i64, ptr %l199
  %t549 = inttoptr i64 %t548 to ptr
  %t550 = load { i64, ptr }, ptr %t547
  %t551 = extractvalue { i64, ptr } %t550, 1
  %t552 = call ptr @__olang_region_or(ptr %t551, ptr null)
  %t553 = icmp ne ptr %t552, null
  %t554 = select i1 %t553, ptr %t552, ptr null
  call void @__olang_region_settle_in(ptr %t549, ptr %t554)
  br label %bb120
bb120:
  br label %bb121
bb121:
  %t555 = load ptr, ptr %lp14
  %t556 = load { i64, ptr }, ptr %t555, !tbaa !27
  %t558 = extractvalue { i64, ptr } %t556, 0
  %t560 = sub i64 %t558, 3
  store i64 %t560, ptr %l209, !tbaa !24
  %t561 = load ptr, ptr %lp14
  %t562 = load { i64, ptr }, ptr %t561, !tbaa !27
  %t563 = extractvalue { i64, ptr } %t562, 0
  store i64 %t563, ptr %l210, !tbaa !24
  %t564 = icmp sge i64 0, 0
  br i1 %t564, label %bb122, label %bb123
bb122:
  %t566 = load i64, ptr %l209, !tbaa !24
  %t567 = icmp sle i64 0, %t566
  br i1 %t567, label %bb124, label %bb125
bb123:
  call void @__olang_check_failed(ptr @olang_loc_d790d12bf07ae06c_96ebe5e6b28bd688)
  unreachable
bb124:
  %t569 = load i64, ptr %l209, !tbaa !24
  %t570 = load i64, ptr %l210, !tbaa !24
  %t571 = icmp sle i64 %t569, %t570
  br i1 %t571, label %bb126, label %bb127
bb125:
  call void @__olang_check_failed(ptr @olang_loc_d790d12bf07ae06c_96ebe5e6b28bd688)
  unreachable
bb126:
  %t573 = load ptr, ptr %lp14
  %t574 = getelementptr { i64, ptr }, ptr %t573, i32 0, i32 1
  %t575 = load ptr, ptr %t574, !tbaa !27
  %t576 = load i64, ptr %l209, !tbaa !24
  %t577 = getelementptr i8, ptr %t575, i64 0
  %t578 = sub i64 %t576, 0
  %t579 = insertvalue { i64, ptr } undef, i64 %t578, 0
  %t580 = insertvalue { i64, ptr } %t579, ptr %t577, 1
  store { i64, ptr } %t580, ptr %l214, !tbaa !27
  %t581 = call i32 @getpid()
  store i32 %t581, ptr %l215
  br label %bb128
bb127:
  call void @__olang_check_failed(ptr @olang_loc_d790d12bf07ae06c_96ebe5e6b28bd688)
  unreachable
bb128:
  %t582 = load { i64, ptr }, ptr %l214, !tbaa !27
  %t583 = extractvalue { i64, ptr } %t582, 1
  %t584 = extractvalue { i64, ptr } %t582, 0
  %t585 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d270, i32 0, i32 1) }, 1
  %t586 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d270, i32 0, i32 1) }, 0
  %t587 = add i64 %t584, %t586
  %t588 = load i32, ptr %l215, !tbaa !23
  %t589 = sext i32 %t588 to i64
  %t590 = call i64 @__olang_fmt_i64(ptr null, i64 %t589)
  %t591 = add i64 %t587, %t590
  %t592 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d271, i32 0, i32 1) }, 1
  %t593 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d271, i32 0, i32 1) }, 0
  %t594 = add i64 %t591, %t593
  %t595 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t594)
  call void @olang_textcopy(ptr %t595, ptr %t583, i64 %t584)
  %t596 = getelementptr i8, ptr %t595, i64 %t584
  call void @olang_textcopy(ptr %t596, ptr %t585, i64 %t586)
  %t597 = getelementptr i8, ptr %t596, i64 %t586
  %t598 = call i64 @__olang_fmt_i64(ptr %t597, i64 %t589)
  %t599 = getelementptr i8, ptr %t597, i64 %t590
  call void @olang_textcopy(ptr %t599, ptr %t592, i64 %t593)
  %t600 = insertvalue { i64, ptr } undef, i64 %t594, 0
  %t601 = insertvalue { i64, ptr } %t600, ptr %t595, 1
  %t602 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t602, ptr %lp17
  %t604 = load ptr, ptr %lp17
  store { i64, ptr } %t601, ptr %t604, !tbaa !27
  %t605 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t607 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v3, ptr %s0, { i64, ptr } %t605, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d272, i32 0, i32 1) })
  store i1 %t607, ptr %l218
  br label %bb129
bb129:
  %t608 = load i1, ptr %l218, !tbaa !21
  br i1 %t608, label %bb130, label %bb131
bb130:
  store i1 true, ptr %l219, !tbaa !21
  br label %bb133
bb131:
  %t609 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d273, i32 0, i32 1) }, ptr %l222, !tbaa !27
  %t612 = load { i64, ptr }, ptr %l222, !tbaa !27
  %t613 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v3, ptr %s0, { i64, ptr } %t609, { i64, ptr } %t612)
  store i1 %t613, ptr %l223
  br label %bb132
bb132:
  %t614 = load i1, ptr %l223, !tbaa !21
  store i1 %t614, ptr %l219, !tbaa !21
  br label %bb133
bb133:
  %t615 = load i1, ptr %l219, !tbaa !21
  br i1 %t615, label %bb134, label %bb135
bb134:
  %t618 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t620 = extractvalue { i64, ptr } %t618, 1
  %t621 = extractvalue { i64, ptr } %t618, 0
  %t622 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t621)
  call void @olang_textcopy(ptr %t622, ptr %t620, i64 %t621)
  %t623 = insertvalue { i64, ptr } undef, i64 %t621, 0
  %t624 = insertvalue { i64, ptr } %t623, ptr %t622, 1
  store { i64, ptr } %t624, ptr %l225, !tbaa !27
  br label %bb137
bb135:
  %t626 = load ptr, ptr %lp14
  %t627 = load { i64, ptr }, ptr %t626, !tbaa !27
  %t629 = call { i64, ptr } @std_2ffilepath_2eBase(ptr %v4, ptr %s0, { i64, ptr } %t627)
  store { i64, ptr } %t629, ptr %l229
  br label %bb136
bb136:
  %t630 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t631 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d274, i32 0, i32 1) }, 1
  %t632 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d274, i32 0, i32 1) }, 0
  %t633 = load { i64, ptr }, ptr %l229, !tbaa !27
  %t634 = extractvalue { i64, ptr } %t633, 1
  %t635 = extractvalue { i64, ptr } %t633, 0
  %t636 = add i64 %t632, %t635
  %t637 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d275, i32 0, i32 1) }, 1
  %t638 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d275, i32 0, i32 1) }, 0
  %t639 = add i64 %t636, %t638
  %t641 = extractvalue { i64, ptr } %t630, 1
  %t642 = extractvalue { i64, ptr } %t630, 0
  %t643 = add i64 %t639, %t642
  %t644 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t643)
  call void @olang_textcopy(ptr %t644, ptr %t631, i64 %t632)
  %t645 = getelementptr i8, ptr %t644, i64 %t632
  call void @olang_textcopy(ptr %t645, ptr %t634, i64 %t635)
  %t646 = getelementptr i8, ptr %t645, i64 %t635
  call void @olang_textcopy(ptr %t646, ptr %t637, i64 %t638)
  %t647 = getelementptr i8, ptr %t646, i64 %t638
  call void @olang_textcopy(ptr %t647, ptr %t641, i64 %t642)
  %t648 = insertvalue { i64, ptr } undef, i64 %t643, 0
  %t649 = insertvalue { i64, ptr } %t648, ptr %t644, 1
  store { i64, ptr } %t649, ptr %l225, !tbaa !27
  br label %bb137
bb137:
  %t651 = load { i64, ptr }, ptr %l225, !tbaa !27
  %t652 = load ptr, ptr %lp17
  %t653 = load { i64, ptr }, ptr %t652, !tbaa !27
  %t657 = call i32 @std_2fos_2eWriteFile(ptr %v1, ptr %s0, { i64, ptr } %t653, { i64, ptr } %t651)
  store i32 %t657, ptr %l234
  %t658 = icmp ne i32 %t657, 0
  br i1 %t658, label %bb139, label %ok.659, !prof !99
ok.659:
  br label %bb138
bb138:
  br label %bb145
bb139:
  %t660 = load i32, ptr %l234, !tbaa !23
  %t661 = ashr i32 %t660, 16
  %t663 = icmp eq i32 %t661, 1
  store i1 %t663, ptr %l236, !tbaa !21
  %t664 = load i32, ptr %l234, !tbaa !23
  %t665 = ashr i32 %t664, 16
  %t667 = icmp eq i32 %t665, 1
  br i1 %t667, label %bb140, label %bb141
bb140:
  call void @__olang_errpay_pop()
  br label %bb141
bb141:
  br label %bb142
bb142:
  %t669 = load ptr, ptr %lp14
  %t670 = load { i64, ptr }, ptr %t669, !tbaa !27
  store { i64, ptr } %t670, ptr %l239, !tbaa !27
  %t671 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %v4)
  store %"compiler/diagmsg:Msg" %t671, ptr %l240
  br label %bb143
bb143:
  %t672 = load ptr, ptr %l5, !tbaa !29
  %t673 = load { i64, ptr }, ptr %l239, !tbaa !27
  %t674 = load %"compiler/diagmsg:Msg", ptr %l240
  call void @compiler_2fbuild_2efileFatal(ptr %v4, ptr %v4, ptr %v4, { i64, ptr } %t673, %"compiler/diagmsg:Msg" %t674, ptr %t672)
  br label %bb144
bb144:
  call void @__olang_scope_close(ptr %s0)
  %t677 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t677, ptr %rv
  br label %ret
bb145:
  %t678 = load ptr, ptr %l0, !tbaa !29
  %t680 = getelementptr %"compiler/build:Config", ptr %t678, i32 0, i32 1
  %t681 = load { i64, ptr }, ptr %t680, !tbaa !27
  %t683 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t681, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d276, i32 0, i32 1) })
  store i1 %t683, ptr %l245
  br label %bb146
bb146:
  %t684 = load i1, ptr %l245, !tbaa !21
  br i1 %t684, label %bb147, label %bb148
bb147:
  %t685 = load ptr, ptr %lp17
  %t686 = load { i64, ptr }, ptr %t685, !tbaa !27
  %t687 = load ptr, ptr %lp14
  %t688 = load { i64, ptr }, ptr %t687, !tbaa !27
  %t691 = call i32 @std_2fos_2eRename(ptr %v1, ptr %v4, { i64, ptr } %t686, { i64, ptr } %t688)
  store i32 %t691, ptr %l248
  %t692 = icmp ne i32 %t691, 0
  br i1 %t692, label %bb150, label %ok.693, !prof !99
ok.693:
  br label %bb149
bb148:
  br label %bb157
bb149:
  br label %bb154
bb150:
  %t694 = load i32, ptr %l248, !tbaa !23
  %t695 = ashr i32 %t694, 16
  %t697 = icmp eq i32 %t695, 1
  store i1 %t697, ptr %l250, !tbaa !21
  %t698 = load i32, ptr %l248, !tbaa !23
  %t699 = ashr i32 %t698, 16
  %t701 = icmp eq i32 %t699, 1
  br i1 %t701, label %bb151, label %bb152
bb151:
  call void @__olang_errpay_pop()
  br label %bb152
bb152:
  br label %bb153
bb153:
  br label %bb154
bb154:
  %t703 = load ptr, ptr %l5, !tbaa !29
  store ptr %t703, ptr %l253, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t704
  %t705 = getelementptr { i64, [3 x i64] }, ptr %t704, i32 0, i32 0
  store i64 0, ptr %t705
  %t706 = load { i64, [3 x i64] }, ptr %t704
  store { i64, [3 x i64] } %t706, ptr %l254
  %t707 = load ptr, ptr %lp14
  %t708 = load { i64, ptr }, ptr %t707, !tbaa !27
  %t710 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoClang(ptr %v4, ptr %v4, { i64, ptr } %t708)
  store %"compiler/diagmsg:Msg" %t710, ptr %l256
  br label %bb155
bb155:
  %t711 = load ptr, ptr %l253, !tbaa !29
  %t712 = load { i64, [3 x i64] }, ptr %l254
  %t713 = load %"compiler/diagmsg:Msg", ptr %l256
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v4, ptr %v4, ptr %t711, { i64, [3 x i64] } %t712, %"compiler/diagmsg:Msg" %t713)
  br label %bb156
bb156:
  call void @__olang_scope_close(ptr %s0)
  %t715 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t715, ptr %rv
  br label %ret
bb157:
  %t716 = load ptr, ptr %lp11
  %t717 = load { i64, ptr }, ptr %t716, !tbaa !27
  store { i64, ptr } %t717, ptr %l258, !tbaa !27
  %t718 = call i32 @getpid()
  store i32 %t718, ptr %l259
  br label %bb158
bb158:
  %t719 = load { i64, ptr }, ptr %l258, !tbaa !27
  %t720 = extractvalue { i64, ptr } %t719, 1
  %t721 = extractvalue { i64, ptr } %t719, 0
  %t722 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d277, i32 0, i32 1) }, 1
  %t723 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d277, i32 0, i32 1) }, 0
  %t724 = add i64 %t721, %t723
  %t725 = load i32, ptr %l259, !tbaa !23
  %t726 = sext i32 %t725 to i64
  %t727 = call i64 @__olang_fmt_i64(ptr null, i64 %t726)
  %t728 = add i64 %t724, %t727
  %t729 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d278, i32 0, i32 1) }, 1
  %t730 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d278, i32 0, i32 1) }, 0
  %t731 = add i64 %t728, %t730
  %t732 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t731)
  call void @olang_textcopy(ptr %t732, ptr %t720, i64 %t721)
  %t733 = getelementptr i8, ptr %t732, i64 %t721
  call void @olang_textcopy(ptr %t733, ptr %t722, i64 %t723)
  %t734 = getelementptr i8, ptr %t733, i64 %t723
  %t735 = call i64 @__olang_fmt_i64(ptr %t734, i64 %t726)
  %t736 = getelementptr i8, ptr %t734, i64 %t727
  call void @olang_textcopy(ptr %t736, ptr %t729, i64 %t730)
  %t737 = insertvalue { i64, ptr } undef, i64 %t731, 0
  %t738 = insertvalue { i64, ptr } %t737, ptr %t732, 1
  %t739 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t739, ptr %lp20
  %t741 = load ptr, ptr %lp20
  store { i64, ptr } %t738, ptr %t741, !tbaa !27
  %t742 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t742, ptr %l261
  br label %bb159
bb159:
  %t743 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l261
  %t744 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t743, ptr %t744
  store ptr %t744, ptr %l21, !tbaa !29
  %t746 = load ptr, ptr %l21, !tbaa !29
  %t747 = load ptr, ptr %l0, !tbaa !29
  %t749 = getelementptr %"compiler/build:Config", ptr %t747, i32 0, i32 1
  %t750 = load { i64, ptr }, ptr %t749, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v0, ptr %t746, { i64, ptr } %t750)
  br label %bb160
bb160:
  store ptr %l8, ptr %l22, !tbaa !29
  store i64 0, ptr %l23, !tbaa !24
  br label %bb161
bb161:
  %t754 = load i64, ptr %l23, !tbaa !24
  store i64 %t754, ptr %l267, !tbaa !24
  %t755 = load ptr, ptr %l22, !tbaa !29
  %t757 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v1, ptr %t755)
  store i64 %t757, ptr %l269
  br label %bb162
bb162:
  %t758 = load i64, ptr %l267, !tbaa !24
  %t759 = load i64, ptr %l269, !tbaa !24
  %t760 = icmp slt i64 %t758, %t759
  %t762 = xor i1 %t760, true
  br i1 %t762, label %bb163, label %bb164
bb163:
  br label %bb169
bb164:
  br label %bb165
bb165:
  %t764 = load ptr, ptr %l22, !tbaa !29
  %t765 = load i64, ptr %l23, !tbaa !24
  %t768 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t764, i64 %t765)
  store { i64, ptr } %t768, ptr %l274
  br label %bb166
bb166:
  %t769 = load { i64, ptr }, ptr %l274, !tbaa !27
  %t770 = load ptr, ptr %l21, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t770, { i64, ptr } %t769)
  br label %bb167
bb167:
  br label %bb168
bb168:
  %t774 = load i64, ptr %l23, !tbaa !24
  %t777 = add i64 %t774, 1
  store i64 %t777, ptr %l23, !tbaa !24
  br label %bb161
bb169:
  %t779 = load ptr, ptr %l21, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t779, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d279, i32 0, i32 1) })
  br label %bb170
bb170:
  %t781 = load ptr, ptr %l21, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t781, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d280, i32 0, i32 1) })
  br label %bb171
bb171:
  %t783 = load ptr, ptr %l21, !tbaa !29
  %t784 = load ptr, ptr %lp20
  %t785 = load { i64, ptr }, ptr %t784, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t783, { i64, ptr } %t785)
  br label %bb172
bb172:
  %t788 = load ptr, ptr %l21, !tbaa !29
  %t789 = load ptr, ptr %lp17
  %t790 = load { i64, ptr }, ptr %t789, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t788, { i64, ptr } %t790)
  br label %bb173
bb173:
  %t793 = load i1, ptr %l12, !tbaa !21
  br i1 %t793, label %bb174, label %bb175
bb174:
  %t795 = load ptr, ptr %l21, !tbaa !29
  store ptr %t795, ptr %l287, !tbaa !29
  %t796 = call ptr @__olang_scope_hold(ptr %v1)
  %t797 = ptrtoint ptr %t796 to i64
  store i64 %t797, ptr %l288, !tbaa !24
  %t798 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t798, label %bb176, label %bb177
bb175:
  br label %bb179
bb176:
  %t800 = call ptr @__olang_region_make(ptr %v1)
  %t801 = ptrtoint ptr %t800 to i64
  store i64 %t801, ptr %l288, !tbaa !24
  br label %bb177
bb177:
  %t802 = load ptr, ptr %lp20
  %t803 = load { i64, ptr }, ptr %t802, !tbaa !27
  %t804 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d281, i32 0, i32 1) }, 1
  %t805 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d281, i32 0, i32 1) }, 0
  %t807 = extractvalue { i64, ptr } %t803, 1
  %t808 = extractvalue { i64, ptr } %t803, 0
  %t809 = add i64 %t805, %t808
  %t810 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d282, i32 0, i32 1) }, 1
  %t811 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d282, i32 0, i32 1) }, 0
  %t812 = add i64 %t809, %t811
  %t813 = load i64, ptr %l288
  %t814 = inttoptr i64 %t813 to ptr
  %t815 = call ptr @__olang_held_alloc(ptr %t814, i64 %t812)
  call void @olang_textcopy(ptr %t815, ptr %t804, i64 %t805)
  %t816 = getelementptr i8, ptr %t815, i64 %t805
  call void @olang_textcopy(ptr %t816, ptr %t807, i64 %t808)
  %t817 = getelementptr i8, ptr %t816, i64 %t808
  call void @olang_textcopy(ptr %t817, ptr %t810, i64 %t811)
  %t818 = insertvalue { i64, ptr } undef, i64 %t812, 0
  %t819 = insertvalue { i64, ptr } %t818, ptr %t815, 1
  %t821 = load ptr, ptr %l287, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t821, { i64, ptr } %t819)
  br label %bb178
bb178:
  br label %bb179
bb179:
  %t823 = load i1, ptr %l9, !tbaa !21
  br i1 %t823, label %bb180, label %bb181
bb180:
  %t825 = load ptr, ptr %l1, !tbaa !29
  %t827 = getelementptr %"compiler/build:compiles", ptr %t825, i32 0, i32 0
  store ptr %t827, ptr %l295, !tbaa !29
  %t828 = call ptr @__olang_scope_hold(ptr %v1)
  %t829 = ptrtoint ptr %t828 to i64
  store i64 %t829, ptr %l296, !tbaa !24
  %t830 = load i1, ptr @olang_2esole_2eArray_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2e_2d1
  br i1 %t830, label %bb182, label %bb183
bb181:
  %t832 = load ptr, ptr %l1, !tbaa !29
  %t834 = getelementptr %"compiler/build:compiles", ptr %t832, i32 0, i32 0
  store ptr %t834, ptr %l306, !tbaa !29
  %t835 = call ptr @__olang_scope_hold(ptr %v1)
  %t836 = ptrtoint ptr %t835 to i64
  store i64 %t836, ptr %l307, !tbaa !24
  %t837 = load i1, ptr @olang_2esole_2eArray_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2e_2d1
  br i1 %t837, label %bb187, label %bb188
bb182:
  %t839 = call ptr @__olang_region_make(ptr %v1)
  %t840 = ptrtoint ptr %t839 to i64
  store i64 %t840, ptr %l296, !tbaa !24
  br label %bb183
bb183:
  %t841 = load ptr, ptr %l0, !tbaa !29
  %t843 = getelementptr %"compiler/build:Config", ptr %t841, i32 0, i32 1
  %t844 = load { i64, ptr }, ptr %t843, !tbaa !27
  store { i64, ptr } %t844, ptr %l299, !tbaa !27
  %t845 = load ptr, ptr %l21, !tbaa !29
  %t847 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v1, ptr %v1, ptr %t845)
  store { i64, ptr } %t847, ptr %l301
  br label %bb184
bb184:
  %t848 = load ptr, ptr %lp17
  %t849 = load { i64, ptr }, ptr %t848, !tbaa !27
  %t850 = load i64, ptr %l296
  %t851 = inttoptr i64 %t850 to ptr
  %t852 = load i64, ptr %l296
  %t853 = inttoptr i64 %t852 to ptr
  %t854 = load { i64, ptr }, ptr %l299, !tbaa !27
  %t855 = load { i64, ptr }, ptr %l301, !tbaa !27
  %t857 = call { i64, ptr } @compiler_2fbuild_2ehoisted(ptr %v0, ptr %t851, ptr %v1, ptr %t853, { i64, ptr } %t854, { i64, ptr } %t855, { i64, ptr } %t849)
  store { i64, ptr } %t857, ptr %l303
  br label %bb185
bb185:
  %t858 = load { i64, ptr }, ptr %l303, !tbaa !27
  %t859 = load ptr, ptr %l295, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %v1, ptr %v1, ptr %t859, { i64, ptr } %t858)
  br label %bb186
bb186:
  br label %bb191
bb187:
  %t861 = call ptr @__olang_region_make(ptr %v1)
  %t862 = ptrtoint ptr %t861 to i64
  store i64 %t862, ptr %l307, !tbaa !24
  br label %bb188
bb188:
  %t863 = load ptr, ptr %l21, !tbaa !29
  %t864 = load i64, ptr %l307
  %t865 = inttoptr i64 %t864 to ptr
  %t867 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v1, ptr %t865, ptr %t863)
  store { i64, ptr } %t867, ptr %l310
  br label %bb189
bb189:
  %t868 = load ptr, ptr %l306, !tbaa !29
  %t869 = load { i64, ptr }, ptr %l310, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %v1, ptr %v1, ptr %t868, { i64, ptr } %t869)
  br label %bb190
bb190:
  br label %bb191
bb191:
  %t870 = load ptr, ptr %l1, !tbaa !29
  %t872 = getelementptr %"compiler/build:compiles", ptr %t870, i32 0, i32 1
  %t873 = load ptr, ptr %lp20
  %t874 = load { i64, ptr }, ptr %t873, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t872, { i64, ptr } %t874)
  br label %bb192
bb192:
  %t877 = load ptr, ptr %l1, !tbaa !29
  %t879 = getelementptr %"compiler/build:compiles", ptr %t877, i32 0, i32 5
  store ptr %t879, ptr %l315, !tbaa !29
  %t880 = call ptr @__olang_scope_hold(ptr %v1)
  %t881 = ptrtoint ptr %t880 to i64
  store i64 %t881, ptr %l316, !tbaa !24
  %t882 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t882, label %bb193, label %bb194
bb193:
  %t884 = call ptr @__olang_region_make(ptr %v1)
  %t885 = ptrtoint ptr %t884 to i64
  store i64 %t885, ptr %l316, !tbaa !24
  br label %bb194
bb194:
  %t886 = load i1, ptr %l12, !tbaa !21
  br i1 %t886, label %bb195, label %bb196
bb195:
  %t888 = load ptr, ptr %lp20
  %t889 = load { i64, ptr }, ptr %t888, !tbaa !27
  %t891 = extractvalue { i64, ptr } %t889, 1
  %t892 = extractvalue { i64, ptr } %t889, 0
  %t893 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d283, i32 0, i32 1) }, 1
  %t894 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d283, i32 0, i32 1) }, 0
  %t895 = add i64 %t892, %t894
  %t896 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t895)
  call void @olang_textcopy(ptr %t896, ptr %t891, i64 %t892)
  %t897 = getelementptr i8, ptr %t896, i64 %t892
  call void @olang_textcopy(ptr %t897, ptr %t893, i64 %t894)
  %t898 = insertvalue { i64, ptr } undef, i64 %t895, 0
  %t899 = insertvalue { i64, ptr } %t898, ptr %t896, 1
  %t901 = load i64, ptr %l316
  %t902 = inttoptr i64 %t901 to ptr
  %t903 = extractvalue { i64, ptr } %t899, 0
  %t904 = extractvalue { i64, ptr } %t899, 1
  %t905 = mul i64 %t903, 1
  %t906 = call ptr @__olang_held_alloc(ptr %t902, i64 %t905)
  call void @llvm.memcpy.p0.p0.i64(ptr %t906, ptr %t904, i64 %t905, i1 false)
  %t907 = insertvalue { i64, ptr } undef, i64 %t903, 0
  %t908 = insertvalue { i64, ptr } %t907, ptr %t906, 1
  store { i64, ptr } %t908, ptr %l319, !tbaa !27
  br label %bb197
bb196:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d284, i32 0, i32 1) }, ptr %l323, !tbaa !27
  %t910 = load { i64, ptr }, ptr %l323, !tbaa !27
  %t912 = load i64, ptr %l316
  %t913 = inttoptr i64 %t912 to ptr
  %t914 = extractvalue { i64, ptr } %t910, 0
  %t915 = extractvalue { i64, ptr } %t910, 1
  %t916 = mul i64 %t914, 1
  %t917 = call ptr @__olang_held_alloc(ptr %t913, i64 %t916)
  call void @llvm.memcpy.p0.p0.i64(ptr %t917, ptr %t915, i64 %t916, i1 false)
  %t918 = insertvalue { i64, ptr } undef, i64 %t914, 0
  %t919 = insertvalue { i64, ptr } %t918, ptr %t917, 1
  store { i64, ptr } %t919, ptr %l319, !tbaa !27
  br label %bb197
bb197:
  %t921 = load ptr, ptr %l315, !tbaa !29
  %t922 = load { i64, ptr }, ptr %l319, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t921, { i64, ptr } %t922)
  br label %bb198
bb198:
  %t923 = load ptr, ptr %l1, !tbaa !29
  %t925 = getelementptr %"compiler/build:compiles", ptr %t923, i32 0, i32 2
  %t926 = load ptr, ptr %lp11
  %t927 = load { i64, ptr }, ptr %t926, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v6, ptr %t925, { i64, ptr } %t927)
  br label %bb199
bb199:
  %t930 = load ptr, ptr %l1, !tbaa !29
  %t932 = getelementptr %"compiler/build:compiles", ptr %t930, i32 0, i32 3
  %t933 = load ptr, ptr %lp14
  %t934 = load { i64, ptr }, ptr %t933, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v4, ptr %t932, { i64, ptr } %t934)
  br label %bb200
bb200:
  %t937 = load ptr, ptr %l1, !tbaa !29
  %t939 = getelementptr %"compiler/build:compiles", ptr %t937, i32 0, i32 4
  %t940 = load ptr, ptr %lp17
  %t941 = load { i64, ptr }, ptr %t940, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t939, { i64, ptr } %t941)
  br label %bb201
bb201:
  %t944 = load ptr, ptr %l1, !tbaa !29
  %t946 = getelementptr %"compiler/build:compiles", ptr %t944, i32 0, i32 6
  %t947 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t949 = extractvalue { i64, ptr } %t947, 0
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t946, i64 %t949)
  br label %bb202
bb202:
  %t952 = load ptr, ptr %lp11
  %t953 = load { i64, ptr }, ptr %t952, !tbaa !27
  store { i64, ptr } %t953, ptr %l339, !tbaa !27
  %t954 = load { i64, ptr }, ptr %l339, !tbaa !27
  %t955 = extractvalue { i64, ptr } %t954, 0
  store i64 %t955, ptr %l340, !tbaa !24
  %t956 = load i64, ptr %l340, !tbaa !24
  %t957 = mul i64 %t956, 1
  %t958 = call ptr @__olang_scope_alloc(ptr %v6, i64 %t957)
  %t959 = insertvalue { i64, ptr } undef, i64 %t956, 0
  %t960 = insertvalue { i64, ptr } %t959, ptr %t958, 1
  store { i64, ptr } %t960, ptr %l341, !tbaa !27
  %t961 = getelementptr { i64, ptr }, ptr %l341, i32 0, i32 1
  %t962 = load ptr, ptr %t961, !tbaa !27
  %t963 = getelementptr { i64, ptr }, ptr %l339, i32 0, i32 1
  %t964 = load ptr, ptr %t963, !tbaa !27
  %t965 = load i64, ptr %l340, !tbaa !24
  %t966 = mul i64 %t965, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t962, ptr %t964, i64 %t966, i1 false)
  %t967 = load { i64, ptr }, ptr %l341, !tbaa !27
  store { i64, ptr } %t967, ptr %l339, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t968 = load { i64, ptr }, ptr %l339, !tbaa !27
  %t969 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t968, 1
  store { i32, { i64, ptr } } %t969, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i64 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewidth(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i32
  %l17 = alloca i1
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i32
  %l23 = alloca i64
  %l24 = alloca i32
  %l28 = alloca i64
  %l31 = alloca i64
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca i32
  %l37 = alloca i1
  %l42 = alloca i64
  %l52 = alloca i64
  %l55 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 31
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp sgt i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/build:Config", ptr %t8, i32 0, i32 31
  %t11 = load i64, ptr %t10, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t11, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t13 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d285, i32 0, i32 1) })
  %t14 = extractvalue { i32, { i64, ptr } } %t13, 1
  %t15 = extractvalue { i32, { i64, ptr } } %t13, 0
  store i32 %t15, ptr %l15
  %t16 = icmp ne i32 %t15, 0
  br i1 %t16, label %bb5, label %ok.17, !prof !99
ok.17:
  store { i64, ptr } %t14, ptr %l14
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t18, ptr %l13, !tbaa !27
  br label %bb9
bb5:
  %t19 = load i32, ptr %l15, !tbaa !23
  %t20 = ashr i32 %t19, 16
  %t22 = icmp eq i32 %t20, 1
  store i1 %t22, ptr %l17, !tbaa !21
  %t23 = load i32, ptr %l15, !tbaa !23
  %t24 = ashr i32 %t23, 16
  %t26 = icmp eq i32 %t24, 1
  br i1 %t26, label %bb6, label %bb7
bb6:
  call void @__olang_errpay_pop()
  br label %bb7
bb7:
  br label %bb8
bb8:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d286, i32 0, i32 1) }, ptr %l13, !tbaa !27
  br label %bb9
bb9:
  %t28 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t29 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %s0, ptr %s0, { i64, ptr } %t28)
  store { i64, ptr } %t29, ptr %l20
  br label %bb10
bb10:
  %t30 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 10)
  %t31 = extractvalue { i32, i64 } %t30, 1
  %t32 = extractvalue { i32, i64 } %t30, 0
  store i32 %t32, ptr %l22
  %t33 = icmp ne i32 %t32, 0
  br i1 %t33, label %bb12, label %ok.34, !prof !99
ok.34:
  store i64 %t31, ptr %l21
  br label %bb11
bb11:
  %t35 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t36 = load i64, ptr %l21, !tbaa !24
  %t37 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s0, { i64, ptr } %t35, i64 %t36)
  %t38 = extractvalue { i32, i64 } %t37, 1
  %t39 = extractvalue { i32, i64 } %t37, 0
  store i32 %t39, ptr %l24
  %t40 = icmp ne i32 %t39, 0
  br i1 %t40, label %bb15, label %ok.41, !prof !99
ok.41:
  store i64 %t38, ptr %l23
  br label %bb14
bb12:
  br label %bb13
bb13:
  store i64 0, ptr %l12, !tbaa !24
  br label %bb16
bb14:
  %t42 = load i64, ptr %l23, !tbaa !24
  store i64 %t42, ptr %l12, !tbaa !24
  br label %bb16
bb15:
  br label %bb13
bb16:
  %t43 = load i64, ptr %l12, !tbaa !24
  store i64 %t43, ptr %l1, !tbaa !24
  %t44 = load i64, ptr %l1, !tbaa !24
  %t46 = icmp sgt i64 %t44, 0
  br i1 %t46, label %bb17, label %bb18
bb17:
  %t48 = load i64, ptr %l1, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t48, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t50 = call i64 @sysconf(i32 84)
  store i64 %t50, ptr %l28
  br label %bb20
bb20:
  %t51 = load i64, ptr %l28, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  %t52 = load i64, ptr %l2, !tbaa !24
  %t54 = icmp sgt i64 %t52, 0
  br i1 %t54, label %bb21, label %bb22
bb21:
  %t56 = load i64, ptr %l2, !tbaa !24
  store i64 %t56, ptr %l31, !tbaa !24
  br label %bb23
bb22:
  store i64 1, ptr %l31, !tbaa !24
  br label %bb23
bb23:
  %t58 = load i64, ptr %l31, !tbaa !24
  store i64 %t58, ptr %l3, !tbaa !24
  %t59 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s0, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d287, i32 0, i32 1) })
  %t60 = extractvalue { i32, { i64, ptr } } %t59, 1
  %t61 = extractvalue { i32, { i64, ptr } } %t59, 0
  store i32 %t61, ptr %l35
  %t62 = icmp ne i32 %t61, 0
  br i1 %t62, label %bb25, label %ok.63, !prof !99
ok.63:
  store { i64, ptr } %t60, ptr %l34
  br label %bb24
bb24:
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t64, ptr %l33, !tbaa !27
  br label %bb29
bb25:
  %t65 = load i32, ptr %l35, !tbaa !23
  %t66 = ashr i32 %t65, 16
  %t68 = icmp eq i32 %t66, 1
  store i1 %t68, ptr %l37, !tbaa !21
  %t69 = load i32, ptr %l35, !tbaa !23
  %t70 = ashr i32 %t69, 16
  %t72 = icmp eq i32 %t70, 1
  br i1 %t72, label %bb26, label %bb27
bb26:
  call void @__olang_errpay_pop()
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t74 = load i64, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t74, ptr %rv
  br label %ret
bb29:
  %t76 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t79 = call i64 @compiler_2fbuild_2ekbOf(ptr %s0, ptr %s0, { i64, ptr } %t76, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d288, i32 0, i32 1) })
  store i64 %t79, ptr %l42
  br label %bb30
bb30:
  %t80 = load i64, ptr %l42, !tbaa !24
  store i64 %t80, ptr %l5, !tbaa !24
  %t81 = load i64, ptr %l5, !tbaa !24
  %t83 = icmp sle i64 %t81, 0
  br i1 %t83, label %bb31, label %bb32
bb31:
  %t85 = load i64, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t85, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  %t87 = load i64, ptr %l5, !tbaa !24
  %t88 = load i64, ptr @G_2ecompiler_2fbuild_2eJobMemory, !tbaa !24
  %t90 = mul i64 %t88, 1024
  %t93 = sdiv i64 %t87, %t90
  store i64 %t93, ptr %l6, !tbaa !24
  %t95 = load i64, ptr %l6, !tbaa !24
  %t97 = icmp slt i64 %t95, 1
  br i1 %t97, label %bb34, label %bb35
bb34:
  store i64 1, ptr %l52, !tbaa !24
  br label %bb37
bb35:
  %t99 = load i64, ptr %l3, !tbaa !24
  %t100 = load i64, ptr %l6, !tbaa !24
  %t103 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t99, i64 %t100)
  store i64 %t103, ptr %l55
  br label %bb36
bb36:
  %t104 = load i64, ptr %l55, !tbaa !24
  store i64 %t104, ptr %l52, !tbaa !24
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s0)
  %t105 = load i64, ptr %l52, !tbaa !24
  store i64 %t105, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eSum(ptr %v0, ptr %v1, ptr noalias dereferenceable(112) align 8 %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca [8 x i8]
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l27 = alloca i64
  %l30 = alloca i64
  %l39 = alloca i64
  %l42 = alloca i1
  %l57 = alloca i64
  %l66 = alloca %"std/prelude/text:StringBuilder"
  %l78 = alloca ptr
  %l79 = alloca i32
  %l80 = alloca i64
  %l81 = alloca i32
  %l82 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/build:Sha256", ptr %t1, i32 0, i32 3
  %t4 = load i64, ptr %t3, !tbaa !24
  %t7 = mul i64 %t4, 8
  store i64 %t7, ptr %l1, !tbaa !65
  %t9 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eWrite(ptr %v0, ptr %s0, ptr %t9, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d289, i32 0, i32 1) })
  br label %bb1
bb1:
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/build:Sha256", ptr %t11, i32 0, i32 2
  %t14 = load i64, ptr %t13, !tbaa !24
  %t16 = icmp ne i64 %t14, 56
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t20 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eWrite(ptr %v0, ptr %s1, ptr %t20, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d290, i32 0, i32 1) })
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb7
bb7:
  br label %bb2
bb8:
  store i64 0, ptr %l3, !tbaa !24
  store i64 8, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t23 = load i64, ptr %l3, !tbaa !24
  %t26 = icmp sgt i64 %t22, %t23
  br i1 %t26, label %bb9, label %bb10
bb9:
  %t28 = load i64, ptr %l5, !tbaa !24
  %t30 = icmp sgt i64 %t28, 0
  br i1 %t30, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb14
bb11:
  %t32 = load i64, ptr %l4, !tbaa !24
  %t33 = load i64, ptr %l3, !tbaa !24
  %t36 = sub i64 %t32, %t33
  %t37 = load i64, ptr %l5, !tbaa !24
  %t40 = add i64 %t36, %t37
  %t42 = sub i64 %t40, 1
  %t43 = load i64, ptr %l5, !tbaa !24
  %t46 = sdiv i64 %t42, %t43
  store i64 %t46, ptr %l30, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb13
bb13:
  %t48 = load i64, ptr %l30, !tbaa !24
  store i64 %t48, ptr %l27, !tbaa !24
  br label %bb14
bb14:
  %t49 = load i64, ptr %l27, !tbaa !24
  store i64 %t49, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  %t50 = load i64, ptr %l6, !tbaa !24
  %t51 = sub i64 %t50, 1
  store i64 %t51, ptr %l39, !tbaa !24
  %t52 = load i64, ptr %l6, !tbaa !24
  %t53 = icmp slt i64 %t52, 2147483648
  %t54 = load i64, ptr %l7, !tbaa !24
  %t55 = icmp sge i64 %t54, 0
  %t58 = and i1 %t53, %t55
  store i1 %t58, ptr %l42, !tbaa !21
  br label %bb15
bb15:
  %t59 = load i64, ptr %l7, !tbaa !24
  %t60 = load i64, ptr %l6, !tbaa !24
  %t63 = icmp slt i64 %t59, %t60
  %t65 = xor i1 %t63, true
  br i1 %t65, label %bb16, label %bb17
bb16:
  br label %bb20
bb17:
  br label %bb18
bb18:
  %t67 = load i64, ptr %l3, !tbaa !24
  %t68 = load i64, ptr %l7, !tbaa !24
  %t69 = load i64, ptr %l5, !tbaa !24
  %t72 = mul i64 %t68, %t69
  %t75 = add i64 %t67, %t72
  store i64 %t75, ptr %l8, !tbaa !24
  %t77 = load i64, ptr %l8, !tbaa !24
  %t78 = load i64, ptr %l1, !tbaa !65
  %t79 = load i64, ptr %l8, !tbaa !24
  %t81 = mul i64 8, %t79
  %t83 = sub i64 56, %t81
  store i64 %t83, ptr %l57, !tbaa !65
  %t86 = load i64, ptr %l57, !tbaa !65
  %t87 = load i64, ptr %l57, !tbaa !65
  %t88 = lshr i64 %t78, %t87
  %t90 = trunc i64 %t88 to i8
  %t93 = getelementptr [8 x i8], ptr %l2, i64 0, i64 %t77
  store i8 %t90, ptr %t93, !tbaa !32
  br label %bb19
bb19:
  %t94 = load i64, ptr %l7, !tbaa !24
  %t97 = add i64 %t94, 1
  store i64 %t97, ptr %l7, !tbaa !24
  br label %bb15
bb20:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = insertvalue { i64, ptr } undef, i64 8, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %l2, 1
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eWrite(ptr %v0, ptr %s0, ptr %t99, { i64, ptr } %t102)
  br label %bb21
bb21:
  %t105 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t105, ptr %l66
  br label %bb22
bb22:
  %t106 = load %"std/prelude/text:StringBuilder", ptr %l66
  store %"std/prelude/text:StringBuilder" %t106, ptr %l9
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/build:Sha256", ptr %t107, i32 0, i32 0
  store ptr %t109, ptr %l10
  store i64 0, ptr %l11, !tbaa !24
  %t111 = load ptr, ptr %l10
  store i64 8, ptr %l12, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s6
  %t114 = load i64, ptr %l11, !tbaa !24
  %t115 = load i64, ptr %l12, !tbaa !24
  %t118 = icmp slt i64 %t114, %t115
  %t120 = xor i1 %t118, true
  br i1 %t120, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s6)
  br label %bb33
bb25:
  br label %bb26
bb26:
  %t122 = load ptr, ptr %l10
  %t123 = load i64, ptr %l11, !tbaa !24
  %t126 = getelementptr [8 x i32], ptr %t122, i64 0, i64 %t123
  %t127 = load i32, ptr %t126, !tbaa !84
  store ptr %l9, ptr %l78, !tbaa !29
  store i32 %t127, ptr %l79, !tbaa !64
  %t130 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s6, i64 16)
  %t131 = extractvalue { i32, i64 } %t130, 1
  %t132 = extractvalue { i32, i64 } %t130, 0
  store i32 %t132, ptr %l81
  %t133 = icmp ne i32 %t132, 0
  br i1 %t133, label %bb28, label %ok.134, !prof !99
ok.134:
  store i64 %t131, ptr %l80
  br label %bb27
bb27:
  %t135 = load i32, ptr %l79, !tbaa !64
  %t136 = load i64, ptr %l80, !tbaa !24
  %t137 = call { i64, ptr } @std_2fprelude_2ftext_2eU32_2eFormat(ptr %s6, i32 %t135, i64 %t136)
  store { i64, ptr } %t137, ptr %l82
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_8179dc362f2d1bfc_fef952a35fe3ad58)
  unreachable
bb29:
  %t138 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t140 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %s6, ptr %s6, { i64, ptr } %t138, i64 8, i8 48)
  store { i64, ptr } %t140, ptr %l84
  br label %bb30
bb30:
  %t141 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t141, 0
  %t143 = extractvalue { i64, ptr } %t141, 1
  %t144 = mul i64 %t142, 1
  %t145 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t144)
  call void @llvm.memcpy.p0.p0.i64(ptr %t145, ptr %t143, i64 %t144, i1 false)
  %t146 = insertvalue { i64, ptr } undef, i64 %t142, 0
  %t147 = insertvalue { i64, ptr } %t146, ptr %t145, 1
  %t148 = load ptr, ptr %l78, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %t148, { i64, ptr } %t147)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s6)
  br label %bb32
bb32:
  %t150 = load i64, ptr %l11, !tbaa !24
  %t153 = add i64 %t150, 1
  store i64 %t153, ptr %l11, !tbaa !24
  br label %bb23
bb33:
  %t156 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l9)
  store { i64, ptr } %t156, ptr %l90
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s0)
  %t157 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t157, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2ecompress(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca [64 x i32]
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca i32
  %l25 = alloca i32
  %l26 = alloca i32
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l35 = alloca i32
  %l38 = alloca [64 x i32]
  %l42 = alloca i64
  %l45 = alloca i64
  %l54 = alloca i64
  %l57 = alloca i1
  %l72 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l103 = alloca i64
  %l106 = alloca i64
  %l127 = alloca i32
  %l131 = alloca i32
  %l141 = alloca i32
  %l145 = alloca i32
  %l186 = alloca i64
  %l189 = alloca i64
  %l208 = alloca i32
  %l210 = alloca i32
  %l211 = alloca i32
  %l213 = alloca i32
  %l235 = alloca i32
  %l237 = alloca i32
  %l238 = alloca i32
  %l240 = alloca i32
  %l270 = alloca ptr
  %l275 = alloca ptr
  %l280 = alloca ptr
  %l285 = alloca ptr
  %l290 = alloca ptr
  %l295 = alloca ptr
  %l300 = alloca ptr
  %l305 = alloca ptr
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  br label %fill.4
fill.4:
  br label %fill.1
fill.1:
  %t5 = phi i64 [ 0, %fill.4 ], [ %t6, %fill.2 ]
  %t7 = icmp slt i64 %t5, 64
  br i1 %t7, label %fill.2, label %fill.3
fill.2:
  %t8 = getelementptr [64 x i32], ptr %l38, i64 0, i64 %t5
  store i32 0, ptr %t8
  %t6 = add i64 %t5, 1
  br label %fill.1
fill.3:
  call void @llvm.memmove.p0.p0.i64(ptr %l3, ptr %l38, i64 256, i1 false)
  store i64 0, ptr %l4, !tbaa !24
  store i64 16, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t9 = load i64, ptr %l5, !tbaa !24
  %t10 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load i64, ptr %l6, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb6
bb3:
  %t19 = load i64, ptr %l5, !tbaa !24
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l6, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l6, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l45, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb5
bb5:
  %t35 = load i64, ptr %l45, !tbaa !24
  store i64 %t35, ptr %l42, !tbaa !24
  br label %bb6
bb6:
  %t36 = load i64, ptr %l42, !tbaa !24
  store i64 %t36, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t37 = load i64, ptr %l7, !tbaa !24
  %t38 = sub i64 %t37, 1
  store i64 %t38, ptr %l54, !tbaa !24
  %t39 = load i64, ptr %l7, !tbaa !24
  %t40 = icmp slt i64 %t39, 2147483648
  %t41 = load i64, ptr %l8, !tbaa !24
  %t42 = icmp sge i64 %t41, 0
  %t45 = and i1 %t40, %t42
  store i1 %t45, ptr %l57, !tbaa !21
  br label %bb7
bb7:
  %t46 = load i64, ptr %l8, !tbaa !24
  %t47 = load i64, ptr %l7, !tbaa !24
  %t50 = icmp slt i64 %t46, %t47
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb8, label %bb9
bb8:
  br label %bb12
bb9:
  br label %bb10
bb10:
  %t54 = load i64, ptr %l4, !tbaa !24
  %t55 = load i64, ptr %l8, !tbaa !24
  %t56 = load i64, ptr %l6, !tbaa !24
  %t59 = mul i64 %t55, %t56
  %t62 = add i64 %t54, %t59
  store i64 %t62, ptr %l9, !tbaa !24
  %t65 = load i64, ptr %l9, !tbaa !24
  %t67 = mul i64 %t65, 4
  %t70 = add i64 %a2, %t67
  store i64 %t70, ptr %l10, !tbaa !24
  %t72 = load i64, ptr %l9, !tbaa !24
  %t73 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t73, ptr %l72, !tbaa !27
  %t74 = load i64, ptr %l10, !tbaa !24
  %t76 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr i8, ptr %t77, i64 %t74
  %t79 = load i8, ptr %t78, !tbaa !32
  %t81 = zext i8 %t79 to i32
  %t83 = shl i32 %t81, 24
  %t84 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t84, ptr %l77, !tbaa !27
  %t85 = load i64, ptr %l10, !tbaa !24
  %t87 = add i64 %t85, 1
  %t89 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr i8, ptr %t90, i64 %t87
  %t92 = load i8, ptr %t91, !tbaa !32
  %t94 = zext i8 %t92 to i32
  %t96 = shl i32 %t94, 16
  %t99 = or i32 %t83, %t96
  %t100 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t100, ptr %l84, !tbaa !27
  %t101 = load i64, ptr %l10, !tbaa !24
  %t103 = add i64 %t101, 2
  %t105 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = getelementptr i8, ptr %t106, i64 %t103
  %t108 = load i8, ptr %t107, !tbaa !32
  %t110 = zext i8 %t108 to i32
  %t112 = shl i32 %t110, 8
  %t115 = or i32 %t99, %t112
  %t116 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t116, ptr %l91, !tbaa !27
  %t117 = load i64, ptr %l10, !tbaa !24
  %t119 = add i64 %t117, 3
  %t121 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = getelementptr i8, ptr %t122, i64 %t119
  %t124 = load i8, ptr %t123, !tbaa !32
  %t126 = zext i8 %t124 to i32
  %t129 = or i32 %t115, %t126
  %t132 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t72
  store i32 %t129, ptr %t132, !tbaa !84
  br label %bb11
bb11:
  %t133 = load i64, ptr %l8, !tbaa !24
  %t136 = add i64 %t133, 1
  store i64 %t136, ptr %l8, !tbaa !24
  br label %bb7
bb12:
  store i64 16, ptr %l11, !tbaa !24
  store i64 64, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t138 = load i64, ptr %l12, !tbaa !24
  %t139 = load i64, ptr %l11, !tbaa !24
  %t142 = icmp sgt i64 %t138, %t139
  br i1 %t142, label %bb13, label %bb14
bb13:
  %t144 = load i64, ptr %l13, !tbaa !24
  %t146 = icmp sgt i64 %t144, 0
  br i1 %t146, label %bb15, label %bb16
bb14:
  store i64 0, ptr %l103, !tbaa !24
  br label %bb18
bb15:
  %t148 = load i64, ptr %l12, !tbaa !24
  %t149 = load i64, ptr %l11, !tbaa !24
  %t152 = sub i64 %t148, %t149
  %t153 = load i64, ptr %l13, !tbaa !24
  %t156 = add i64 %t152, %t153
  %t158 = sub i64 %t156, 1
  %t159 = load i64, ptr %l13, !tbaa !24
  %t162 = sdiv i64 %t158, %t159
  store i64 %t162, ptr %l106, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l106, !tbaa !24
  br label %bb17
bb17:
  %t164 = load i64, ptr %l106, !tbaa !24
  store i64 %t164, ptr %l103, !tbaa !24
  br label %bb18
bb18:
  %t165 = load i64, ptr %l103, !tbaa !24
  store i64 %t165, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb19
bb19:
  %t166 = load i64, ptr %l15, !tbaa !24
  %t167 = load i64, ptr %l14, !tbaa !24
  %t170 = icmp slt i64 %t166, %t167
  %t172 = xor i1 %t170, true
  br i1 %t172, label %bb20, label %bb21
bb20:
  br label %bb28
bb21:
  br label %bb22
bb22:
  %t174 = load i64, ptr %l11, !tbaa !24
  %t175 = load i64, ptr %l15, !tbaa !24
  %t176 = load i64, ptr %l13, !tbaa !24
  %t179 = mul i64 %t175, %t176
  %t182 = add i64 %t174, %t179
  store i64 %t182, ptr %l16, !tbaa !24
  %t184 = load i64, ptr %l16, !tbaa !24
  %t186 = sub i64 %t184, 15
  %t188 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t186
  %t189 = load i32, ptr %t188, !tbaa !84
  %t191 = call i32 @compiler_2fbuild_2erotr(i32 %t189, i32 7)
  store i32 %t191, ptr %l127
  br label %bb23
bb23:
  %t192 = load i64, ptr %l16, !tbaa !24
  %t194 = sub i64 %t192, 15
  %t196 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t194
  %t197 = load i32, ptr %t196, !tbaa !84
  %t199 = call i32 @compiler_2fbuild_2erotr(i32 %t197, i32 18)
  store i32 %t199, ptr %l131
  br label %bb24
bb24:
  %t200 = load i32, ptr %l127, !tbaa !64
  %t201 = load i32, ptr %l131, !tbaa !64
  %t202 = xor i32 %t200, %t201
  %t203 = load i64, ptr %l16, !tbaa !24
  %t205 = sub i64 %t203, 15
  %t207 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t205
  %t208 = load i32, ptr %t207, !tbaa !84
  %t210 = lshr i32 %t208, 3
  %t213 = xor i32 %t202, %t210
  store i32 %t213, ptr %l17, !tbaa !64
  %t215 = load i64, ptr %l16, !tbaa !24
  %t217 = sub i64 %t215, 2
  %t219 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t217
  %t220 = load i32, ptr %t219, !tbaa !84
  %t222 = call i32 @compiler_2fbuild_2erotr(i32 %t220, i32 17)
  store i32 %t222, ptr %l141
  br label %bb25
bb25:
  %t223 = load i64, ptr %l16, !tbaa !24
  %t225 = sub i64 %t223, 2
  %t227 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t225
  %t228 = load i32, ptr %t227, !tbaa !84
  %t230 = call i32 @compiler_2fbuild_2erotr(i32 %t228, i32 19)
  store i32 %t230, ptr %l145
  br label %bb26
bb26:
  %t231 = load i32, ptr %l141, !tbaa !64
  %t232 = load i32, ptr %l145, !tbaa !64
  %t233 = xor i32 %t231, %t232
  %t234 = load i64, ptr %l16, !tbaa !24
  %t236 = sub i64 %t234, 2
  %t238 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t236
  %t239 = load i32, ptr %t238, !tbaa !84
  %t241 = lshr i32 %t239, 10
  %t244 = xor i32 %t233, %t241
  %t246 = load i64, ptr %l16, !tbaa !24
  %t247 = load i64, ptr %l16, !tbaa !24
  %t249 = sub i64 %t247, 16
  %t251 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t249
  %t252 = load i32, ptr %t251, !tbaa !84
  %t253 = load i32, ptr %l17, !tbaa !64
  %t256 = add i32 %t252, %t253
  %t257 = load i64, ptr %l16, !tbaa !24
  %t259 = sub i64 %t257, 7
  %t261 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t259
  %t262 = load i32, ptr %t261, !tbaa !84
  %t265 = add i32 %t256, %t262
  %t269 = add i32 %t265, %t244
  %t272 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t246
  store i32 %t269, ptr %t272, !tbaa !84
  br label %bb27
bb27:
  %t273 = load i64, ptr %l15, !tbaa !24
  %t276 = add i64 %t273, 1
  store i64 %t276, ptr %l15, !tbaa !24
  br label %bb19
bb28:
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t280 = getelementptr %"compiler/build:Sha256", ptr %t278, i32 0, i32 0
  %t281 = getelementptr [8 x i32], ptr %t280, i64 0, i64 0
  %t282 = load i32, ptr %t281, !tbaa !84
  store i32 %t282, ptr %l19, !tbaa !64
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t286 = getelementptr %"compiler/build:Sha256", ptr %t284, i32 0, i32 0
  %t287 = getelementptr [8 x i32], ptr %t286, i64 0, i64 1
  %t288 = load i32, ptr %t287, !tbaa !84
  store i32 %t288, ptr %l20, !tbaa !64
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t292 = getelementptr %"compiler/build:Sha256", ptr %t290, i32 0, i32 0
  %t293 = getelementptr [8 x i32], ptr %t292, i64 0, i64 2
  %t294 = load i32, ptr %t293, !tbaa !84
  store i32 %t294, ptr %l21, !tbaa !64
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t298 = getelementptr %"compiler/build:Sha256", ptr %t296, i32 0, i32 0
  %t299 = getelementptr [8 x i32], ptr %t298, i64 0, i64 3
  %t300 = load i32, ptr %t299, !tbaa !84
  store i32 %t300, ptr %l22, !tbaa !64
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t304 = getelementptr %"compiler/build:Sha256", ptr %t302, i32 0, i32 0
  %t305 = getelementptr [8 x i32], ptr %t304, i64 0, i64 4
  %t306 = load i32, ptr %t305, !tbaa !84
  store i32 %t306, ptr %l23, !tbaa !64
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t310 = getelementptr %"compiler/build:Sha256", ptr %t308, i32 0, i32 0
  %t311 = getelementptr [8 x i32], ptr %t310, i64 0, i64 5
  %t312 = load i32, ptr %t311, !tbaa !84
  store i32 %t312, ptr %l24, !tbaa !64
  %t314 = load ptr, ptr %l0, !tbaa !29
  %t316 = getelementptr %"compiler/build:Sha256", ptr %t314, i32 0, i32 0
  %t317 = getelementptr [8 x i32], ptr %t316, i64 0, i64 6
  %t318 = load i32, ptr %t317, !tbaa !84
  store i32 %t318, ptr %l25, !tbaa !64
  %t320 = load ptr, ptr %l0, !tbaa !29
  %t322 = getelementptr %"compiler/build:Sha256", ptr %t320, i32 0, i32 0
  %t323 = getelementptr [8 x i32], ptr %t322, i64 0, i64 7
  %t324 = load i32, ptr %t323, !tbaa !84
  store i32 %t324, ptr %l26, !tbaa !64
  store i64 0, ptr %l27, !tbaa !24
  store i64 64, ptr %l28, !tbaa !24
  store i64 1, ptr %l29, !tbaa !24
  %t326 = load i64, ptr %l28, !tbaa !24
  %t327 = load i64, ptr %l27, !tbaa !24
  %t330 = icmp sgt i64 %t326, %t327
  br i1 %t330, label %bb29, label %bb30
bb29:
  %t332 = load i64, ptr %l29, !tbaa !24
  %t334 = icmp sgt i64 %t332, 0
  br i1 %t334, label %bb31, label %bb32
bb30:
  store i64 0, ptr %l186, !tbaa !24
  br label %bb34
bb31:
  %t336 = load i64, ptr %l28, !tbaa !24
  %t337 = load i64, ptr %l27, !tbaa !24
  %t340 = sub i64 %t336, %t337
  %t341 = load i64, ptr %l29, !tbaa !24
  %t344 = add i64 %t340, %t341
  %t346 = sub i64 %t344, 1
  %t347 = load i64, ptr %l29, !tbaa !24
  %t350 = sdiv i64 %t346, %t347
  store i64 %t350, ptr %l189, !tbaa !24
  br label %bb33
bb32:
  store i64 0, ptr %l189, !tbaa !24
  br label %bb33
bb33:
  %t352 = load i64, ptr %l189, !tbaa !24
  store i64 %t352, ptr %l186, !tbaa !24
  br label %bb34
bb34:
  %t353 = load i64, ptr %l186, !tbaa !24
  store i64 %t353, ptr %l30, !tbaa !24
  store i64 0, ptr %l31, !tbaa !24
  br label %bb35
bb35:
  %t354 = load i64, ptr %l31, !tbaa !24
  %t355 = load i64, ptr %l30, !tbaa !24
  %t358 = icmp slt i64 %t354, %t355
  %t360 = xor i1 %t358, true
  br i1 %t360, label %bb36, label %bb37
bb36:
  br label %bb46
bb37:
  br label %bb38
bb38:
  %t362 = load i64, ptr %l27, !tbaa !24
  %t363 = load i64, ptr %l31, !tbaa !24
  %t364 = load i64, ptr %l29, !tbaa !24
  %t367 = mul i64 %t363, %t364
  %t370 = add i64 %t362, %t367
  store i64 %t370, ptr %l32, !tbaa !24
  %t372 = load i32, ptr %l23, !tbaa !64
  %t374 = call i32 @compiler_2fbuild_2erotr(i32 %t372, i32 6)
  store i32 %t374, ptr %l208
  br label %bb39
bb39:
  %t375 = load i32, ptr %l23, !tbaa !64
  %t377 = call i32 @compiler_2fbuild_2erotr(i32 %t375, i32 11)
  store i32 %t377, ptr %l210
  br label %bb40
bb40:
  %t378 = load i32, ptr %l208, !tbaa !64
  %t379 = load i32, ptr %l210, !tbaa !64
  %t380 = xor i32 %t378, %t379
  store i32 %t380, ptr %l211, !tbaa !64
  %t381 = load i32, ptr %l23, !tbaa !64
  %t383 = call i32 @compiler_2fbuild_2erotr(i32 %t381, i32 25)
  store i32 %t383, ptr %l213
  br label %bb41
bb41:
  %t384 = load i32, ptr %l211, !tbaa !64
  %t385 = load i32, ptr %l213, !tbaa !64
  %t386 = xor i32 %t384, %t385
  %t388 = load i32, ptr %l23, !tbaa !64
  %t389 = load i32, ptr %l24, !tbaa !64
  %t392 = and i32 %t388, %t389
  %t393 = load i32, ptr %l23, !tbaa !64
  %t395 = xor i32 %t393, -1
  %t396 = load i32, ptr %l25, !tbaa !64
  %t399 = and i32 %t395, %t396
  %t402 = xor i32 %t392, %t399
  %t404 = load i32, ptr %l26, !tbaa !64
  %t408 = add i32 %t404, %t386
  %t412 = add i32 %t408, %t402
  %t413 = load i64, ptr %l32, !tbaa !24
  %t415 = getelementptr [64 x i32], ptr @G_2ecompiler_2fbuild_2eShaK, i64 0, i64 %t413
  %t416 = load i32, ptr %t415, !tbaa !84
  %t419 = add i32 %t412, %t416
  %t420 = load i64, ptr %l32, !tbaa !24
  %t422 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t420
  %t423 = load i32, ptr %t422, !tbaa !84
  %t426 = add i32 %t419, %t423
  store i32 %t426, ptr %l35, !tbaa !64
  %t428 = load i32, ptr %l19, !tbaa !64
  %t430 = call i32 @compiler_2fbuild_2erotr(i32 %t428, i32 2)
  store i32 %t430, ptr %l235
  br label %bb42
bb42:
  %t431 = load i32, ptr %l19, !tbaa !64
  %t433 = call i32 @compiler_2fbuild_2erotr(i32 %t431, i32 13)
  store i32 %t433, ptr %l237
  br label %bb43
bb43:
  %t434 = load i32, ptr %l235, !tbaa !64
  %t435 = load i32, ptr %l237, !tbaa !64
  %t436 = xor i32 %t434, %t435
  store i32 %t436, ptr %l238, !tbaa !64
  %t437 = load i32, ptr %l19, !tbaa !64
  %t439 = call i32 @compiler_2fbuild_2erotr(i32 %t437, i32 22)
  store i32 %t439, ptr %l240
  br label %bb44
bb44:
  %t440 = load i32, ptr %l238, !tbaa !64
  %t441 = load i32, ptr %l240, !tbaa !64
  %t442 = xor i32 %t440, %t441
  %t444 = load i32, ptr %l19, !tbaa !64
  %t445 = load i32, ptr %l20, !tbaa !64
  %t448 = and i32 %t444, %t445
  %t449 = load i32, ptr %l19, !tbaa !64
  %t450 = load i32, ptr %l21, !tbaa !64
  %t453 = and i32 %t449, %t450
  %t456 = xor i32 %t448, %t453
  %t457 = load i32, ptr %l20, !tbaa !64
  %t458 = load i32, ptr %l21, !tbaa !64
  %t461 = and i32 %t457, %t458
  %t464 = xor i32 %t456, %t461
  %t466 = load i32, ptr %l25, !tbaa !64
  store i32 %t466, ptr %l26, !tbaa !64
  %t468 = load i32, ptr %l24, !tbaa !64
  store i32 %t468, ptr %l25, !tbaa !64
  %t470 = load i32, ptr %l23, !tbaa !64
  store i32 %t470, ptr %l24, !tbaa !64
  %t472 = load i32, ptr %l22, !tbaa !64
  %t473 = load i32, ptr %l35, !tbaa !64
  %t476 = add i32 %t472, %t473
  store i32 %t476, ptr %l23, !tbaa !64
  %t478 = load i32, ptr %l21, !tbaa !64
  store i32 %t478, ptr %l22, !tbaa !64
  %t480 = load i32, ptr %l20, !tbaa !64
  store i32 %t480, ptr %l21, !tbaa !64
  %t482 = load i32, ptr %l19, !tbaa !64
  store i32 %t482, ptr %l20, !tbaa !64
  %t484 = load i32, ptr %l35, !tbaa !64
  %t488 = add i32 %t484, %t442
  %t492 = add i32 %t488, %t464
  store i32 %t492, ptr %l19, !tbaa !64
  br label %bb45
bb45:
  %t494 = load i64, ptr %l31, !tbaa !24
  %t497 = add i64 %t494, 1
  store i64 %t497, ptr %l31, !tbaa !24
  br label %bb35
bb46:
  %t499 = load ptr, ptr %l0, !tbaa !29
  store ptr %t499, ptr %l270, !tbaa !29
  %t500 = load ptr, ptr %l270, !tbaa !29
  %t501 = getelementptr %"compiler/build:Sha256", ptr %t500, i32 0, i32 0
  %t502 = getelementptr [8 x i32], ptr %t501, i64 0, i64 0
  %t503 = load i32, ptr %t502, !tbaa !84
  %t505 = load i32, ptr %l19, !tbaa !64
  %t508 = add i32 %t503, %t505
  %t510 = load ptr, ptr %l270, !tbaa !29
  %t511 = getelementptr %"compiler/build:Sha256", ptr %t510, i32 0, i32 0
  %t512 = getelementptr [8 x i32], ptr %t511, i64 0, i64 0
  store i32 %t508, ptr %t512, !tbaa !84
  %t513 = load ptr, ptr %l0, !tbaa !29
  store ptr %t513, ptr %l275, !tbaa !29
  %t514 = load ptr, ptr %l275, !tbaa !29
  %t515 = getelementptr %"compiler/build:Sha256", ptr %t514, i32 0, i32 0
  %t516 = getelementptr [8 x i32], ptr %t515, i64 0, i64 1
  %t517 = load i32, ptr %t516, !tbaa !84
  %t519 = load i32, ptr %l20, !tbaa !64
  %t522 = add i32 %t517, %t519
  %t524 = load ptr, ptr %l275, !tbaa !29
  %t525 = getelementptr %"compiler/build:Sha256", ptr %t524, i32 0, i32 0
  %t526 = getelementptr [8 x i32], ptr %t525, i64 0, i64 1
  store i32 %t522, ptr %t526, !tbaa !84
  %t527 = load ptr, ptr %l0, !tbaa !29
  store ptr %t527, ptr %l280, !tbaa !29
  %t528 = load ptr, ptr %l280, !tbaa !29
  %t529 = getelementptr %"compiler/build:Sha256", ptr %t528, i32 0, i32 0
  %t530 = getelementptr [8 x i32], ptr %t529, i64 0, i64 2
  %t531 = load i32, ptr %t530, !tbaa !84
  %t533 = load i32, ptr %l21, !tbaa !64
  %t536 = add i32 %t531, %t533
  %t538 = load ptr, ptr %l280, !tbaa !29
  %t539 = getelementptr %"compiler/build:Sha256", ptr %t538, i32 0, i32 0
  %t540 = getelementptr [8 x i32], ptr %t539, i64 0, i64 2
  store i32 %t536, ptr %t540, !tbaa !84
  %t541 = load ptr, ptr %l0, !tbaa !29
  store ptr %t541, ptr %l285, !tbaa !29
  %t542 = load ptr, ptr %l285, !tbaa !29
  %t543 = getelementptr %"compiler/build:Sha256", ptr %t542, i32 0, i32 0
  %t544 = getelementptr [8 x i32], ptr %t543, i64 0, i64 3
  %t545 = load i32, ptr %t544, !tbaa !84
  %t547 = load i32, ptr %l22, !tbaa !64
  %t550 = add i32 %t545, %t547
  %t552 = load ptr, ptr %l285, !tbaa !29
  %t553 = getelementptr %"compiler/build:Sha256", ptr %t552, i32 0, i32 0
  %t554 = getelementptr [8 x i32], ptr %t553, i64 0, i64 3
  store i32 %t550, ptr %t554, !tbaa !84
  %t555 = load ptr, ptr %l0, !tbaa !29
  store ptr %t555, ptr %l290, !tbaa !29
  %t556 = load ptr, ptr %l290, !tbaa !29
  %t557 = getelementptr %"compiler/build:Sha256", ptr %t556, i32 0, i32 0
  %t558 = getelementptr [8 x i32], ptr %t557, i64 0, i64 4
  %t559 = load i32, ptr %t558, !tbaa !84
  %t561 = load i32, ptr %l23, !tbaa !64
  %t564 = add i32 %t559, %t561
  %t566 = load ptr, ptr %l290, !tbaa !29
  %t567 = getelementptr %"compiler/build:Sha256", ptr %t566, i32 0, i32 0
  %t568 = getelementptr [8 x i32], ptr %t567, i64 0, i64 4
  store i32 %t564, ptr %t568, !tbaa !84
  %t569 = load ptr, ptr %l0, !tbaa !29
  store ptr %t569, ptr %l295, !tbaa !29
  %t570 = load ptr, ptr %l295, !tbaa !29
  %t571 = getelementptr %"compiler/build:Sha256", ptr %t570, i32 0, i32 0
  %t572 = getelementptr [8 x i32], ptr %t571, i64 0, i64 5
  %t573 = load i32, ptr %t572, !tbaa !84
  %t575 = load i32, ptr %l24, !tbaa !64
  %t578 = add i32 %t573, %t575
  %t580 = load ptr, ptr %l295, !tbaa !29
  %t581 = getelementptr %"compiler/build:Sha256", ptr %t580, i32 0, i32 0
  %t582 = getelementptr [8 x i32], ptr %t581, i64 0, i64 5
  store i32 %t578, ptr %t582, !tbaa !84
  %t583 = load ptr, ptr %l0, !tbaa !29
  store ptr %t583, ptr %l300, !tbaa !29
  %t584 = load ptr, ptr %l300, !tbaa !29
  %t585 = getelementptr %"compiler/build:Sha256", ptr %t584, i32 0, i32 0
  %t586 = getelementptr [8 x i32], ptr %t585, i64 0, i64 6
  %t587 = load i32, ptr %t586, !tbaa !84
  %t589 = load i32, ptr %l25, !tbaa !64
  %t592 = add i32 %t587, %t589
  %t594 = load ptr, ptr %l300, !tbaa !29
  %t595 = getelementptr %"compiler/build:Sha256", ptr %t594, i32 0, i32 0
  %t596 = getelementptr [8 x i32], ptr %t595, i64 0, i64 6
  store i32 %t592, ptr %t596, !tbaa !84
  %t597 = load ptr, ptr %l0, !tbaa !29
  store ptr %t597, ptr %l305, !tbaa !29
  %t598 = load ptr, ptr %l305, !tbaa !29
  %t599 = getelementptr %"compiler/build:Sha256", ptr %t598, i32 0, i32 0
  %t600 = getelementptr [8 x i32], ptr %t599, i64 0, i64 7
  %t601 = load i32, ptr %t600, !tbaa !84
  %t603 = load i32, ptr %l26, !tbaa !64
  %t606 = add i32 %t601, %t603
  %t608 = load ptr, ptr %l305, !tbaa !29
  %t609 = getelementptr %"compiler/build:Sha256", ptr %t608, i32 0, i32 0
  %t610 = getelementptr [8 x i32], ptr %t609, i64 0, i64 7
  store i32 %t606, ptr %t610, !tbaa !84
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fbuild_2ecompiler_2fbuild_3aUnit_2eLen(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i1
  %l5 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/build:Unit", ptr %t1, i32 0, i32 4
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t4, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d291, i32 0, i32 1) })
  store i1 %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load i1, ptr %l3, !tbaa !21
  %t8 = xor i1 %t7, true
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/build:Unit", ptr %t10, i32 0, i32 5
  %t13 = load i64, ptr %t12, !tbaa !24
  store i64 %t13, ptr %l5, !tbaa !24
  br label %bb4
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/build:Unit", ptr %t15, i32 0, i32 2
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  store i64 %t20, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t22 = load i64, ptr %l5, !tbaa !24
  store i64 %t22, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fbuild_2ecompiler_2fbuild_3acompiles_2eclaim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %lp2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i1
  %l15 = alloca i64
  %l18 = alloca i64
  %l37 = alloca i32
  %l42 = alloca i1
  %l49 = alloca { i64, ptr }
  %l50 = alloca i32
  %l54 = alloca i32
  %l56 = alloca i1
  %l64 = alloca i1
  %l67 = alloca i32
  %l69 = alloca i1
  %s6 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a1, 1
  %t4 = extractvalue { i64, ptr } %a1, 0
  %t5 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d292, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d292, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t12 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t12, ptr %lp2
  %t14 = load ptr, ptr %lp2
  store { i64, ptr } %t11, ptr %t14, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  store i64 2, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = icmp sgt i64 %t15, %t16
  br i1 %t19, label %bb1, label %bb2
bb1:
  %t21 = load i64, ptr %l5, !tbaa !24
  %t23 = icmp sgt i64 %t21, 0
  br i1 %t23, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb6
bb3:
  %t25 = load i64, ptr %l4, !tbaa !24
  %t26 = load i64, ptr %l3, !tbaa !24
  %t29 = sub i64 %t25, %t26
  %t30 = load i64, ptr %l5, !tbaa !24
  %t33 = add i64 %t29, %t30
  %t35 = sub i64 %t33, 1
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = sdiv i64 %t35, %t36
  store i64 %t39, ptr %l18, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb5
bb5:
  %t41 = load i64, ptr %l18, !tbaa !24
  store i64 %t41, ptr %l15, !tbaa !24
  br label %bb6
bb6:
  %t42 = load i64, ptr %l15, !tbaa !24
  store i64 %t42, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  %t43 = load i64, ptr %l7, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb8, label %bb9
bb8:
  br label %bb44
bb9:
  br label %bb10
bb10:
  %t51 = load i64, ptr %l3, !tbaa !24
  %t52 = load i64, ptr %l7, !tbaa !24
  %t53 = load i64, ptr %l5, !tbaa !24
  %t56 = mul i64 %t52, %t53
  %t59 = add i64 %t51, %t56
  store i64 %t59, ptr %l8, !tbaa !24
  store i1 true, ptr %l9, !tbaa !21
  %t61 = load ptr, ptr %lp2
  %t62 = load { i64, ptr }, ptr %t61, !tbaa !27
  %t64 = call i32 @std_2fos_2eMkDir(ptr %v0, { i64, ptr } %t62)
  store i32 %t64, ptr %l37
  %t65 = icmp ne i32 %t64, 0
  br i1 %t65, label %bb12, label %ok.66, !prof !99
ok.66:
  br label %bb11
bb11:
  br label %bb21
bb12:
  %t67 = load i32, ptr %l37, !tbaa !23
  %t68 = icmp eq i32 %t67, 65537
  br i1 %t68, label %bb13, label %bb14
bb13:
  %t70 = load i32, ptr %l37, !tbaa !23
  %t71 = ashr i32 %t70, 16
  %t73 = icmp eq i32 %t71, 1
  br i1 %t73, label %bb15, label %bb16
bb14:
  %t75 = load i32, ptr %l37, !tbaa !23
  %t76 = ashr i32 %t75, 16
  %t78 = icmp eq i32 %t76, 1
  store i1 %t78, ptr %l42, !tbaa !21
  %t79 = load i32, ptr %l37, !tbaa !23
  %t80 = ashr i32 %t79, 16
  %t82 = icmp eq i32 %t80, 1
  br i1 %t82, label %bb18, label %bb19
bb15:
  call void @__olang_errpay_pop()
  br label %bb16
bb16:
  br label %bb17
bb17:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb21
bb18:
  call void @__olang_errpay_pop()
  br label %bb19
bb19:
  br label %bb20
bb20:
  store i1 true, ptr %rv
  br label %ret
bb21:
  %t85 = load i1, ptr %l9, !tbaa !21
  br i1 %t85, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s6
  %t87 = load ptr, ptr %lp2
  %t88 = load { i64, ptr }, ptr %t87, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t88, 1
  %t91 = extractvalue { i64, ptr } %t88, 0
  %t92 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d293, i32 0, i32 1) }, 1
  %t93 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d293, i32 0, i32 1) }, 0
  %t94 = add i64 %t91, %t93
  %t95 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t94)
  call void @olang_textcopy(ptr %t95, ptr %t90, i64 %t91)
  %t96 = getelementptr i8, ptr %t95, i64 %t91
  call void @olang_textcopy(ptr %t96, ptr %t92, i64 %t93)
  %t97 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t95, 1
  store { i64, ptr } %t98, ptr %l49, !tbaa !27
  %t100 = call i32 @getpid()
  store i32 %t100, ptr %l50
  br label %bb24
bb23:
  br label %bb32
bb24:
  %t101 = load i32, ptr %l50, !tbaa !23
  %t102 = sext i32 %t101 to i64
  %t103 = call i64 @__olang_fmt_i64(ptr null, i64 %t102)
  %t104 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t103)
  %t105 = call i64 @__olang_fmt_i64(ptr %t104, i64 %t102)
  %t106 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t104, 1
  %t110 = extractvalue { i64, ptr } %t107, 0
  %t111 = extractvalue { i64, ptr } %t107, 1
  %t112 = mul i64 %t110, 1
  %t113 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t112)
  call void @llvm.memcpy.p0.p0.i64(ptr %t113, ptr %t111, i64 %t112, i1 false)
  %t114 = insertvalue { i64, ptr } undef, i64 %t110, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t113, 1
  %t116 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t118 = call i32 @std_2fos_2eWriteFile(ptr %s6, ptr %s6, { i64, ptr } %t116, { i64, ptr } %t115)
  store i32 %t118, ptr %l54
  %t119 = icmp ne i32 %t118, 0
  br i1 %t119, label %bb26, label %ok.120, !prof !99
ok.120:
  br label %bb25
bb25:
  br label %bb30
bb26:
  %t121 = load i32, ptr %l54, !tbaa !23
  %t122 = ashr i32 %t121, 16
  %t124 = icmp eq i32 %t122, 1
  store i1 %t124, ptr %l56, !tbaa !21
  %t125 = load i32, ptr %l54, !tbaa !23
  %t126 = ashr i32 %t125, 16
  %t128 = icmp eq i32 %t126, 1
  br i1 %t128, label %bb27, label %bb28
bb27:
  call void @__olang_errpay_pop()
  br label %bb28
bb28:
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t132 = getelementptr %"compiler/build:compiles", ptr %a0, i32 0, i32 7
  %t133 = load ptr, ptr %lp2
  %t134 = load { i64, ptr }, ptr %t133, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t132, { i64, ptr } %t134)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s6)
  store i1 true, ptr %rv
  br label %ret
bb32:
  %t138 = load ptr, ptr %lp2
  %t139 = load { i64, ptr }, ptr %t138, !tbaa !27
  %t141 = call i1 @compiler_2fbuild_2eholderAlive(ptr %v0, { i64, ptr } %t139)
  store i1 %t141, ptr %l64
  br label %bb33
bb33:
  %t142 = load i1, ptr %l64, !tbaa !21
  br i1 %t142, label %bb34, label %bb35
bb34:
  store i1 false, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  %t144 = load ptr, ptr %lp2
  %t145 = load { i64, ptr }, ptr %t144, !tbaa !27
  %t147 = call i32 @std_2fos_2eRemoveAll(ptr %v0, { i64, ptr } %t145)
  store i32 %t147, ptr %l67
  %t148 = icmp ne i32 %t147, 0
  br i1 %t148, label %bb38, label %ok.149, !prof !99
ok.149:
  br label %bb37
bb37:
  br label %bb42
bb38:
  %t150 = load i32, ptr %l67, !tbaa !23
  %t151 = ashr i32 %t150, 16
  %t153 = icmp eq i32 %t151, 1
  store i1 %t153, ptr %l69, !tbaa !21
  %t154 = load i32, ptr %l67, !tbaa !23
  %t155 = ashr i32 %t154, 16
  %t157 = icmp eq i32 %t155, 1
  br i1 %t157, label %bb39, label %bb40
bb39:
  call void @__olang_errpay_pop()
  br label %bb40
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t159 = load i64, ptr %l7, !tbaa !24
  %t162 = add i64 %t159, 1
  store i64 %t162, ptr %l7, !tbaa !24
  br label %bb7
bb44:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fbuild_2ecompiler_2fbuild_3astubFrontend_2eAnalyze(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, i32 %a2, ptr %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l29 = alloca ptr
  %l30 = alloca i32
  %l31 = alloca i64
  %l38 = alloca %"compiler/build:Unit"
  %l40 = alloca ptr
  %l41 = alloca i32
  %l42 = alloca i64
  %l50 = alloca %"compiler/build:Unit"
  %l56 = alloca ptr
  %l59 = alloca i32
  %l63 = alloca %"compiler/build:Unit"
  %l65 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca i64
  %l73 = alloca %"compiler/build:Unit"
  %l74 = alloca ptr
  %l75 = alloca i64
  %l81 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  %t2 = load ptr, ptr %l10, !tbaa !29
  %t3 = getelementptr %"compiler/build:stubFrontend", ptr %t2, i32 0, i32 1
  %t4 = load i64, ptr %t3, !tbaa !24
  %t7 = add i64 %t4, 1
  %t9 = load ptr, ptr %l10, !tbaa !29
  %t10 = getelementptr %"compiler/build:stubFrontend", ptr %t9, i32 0, i32 1
  store i64 %t7, ptr %t10, !tbaa !24
  %t11 = load ptr, ptr %l3, !tbaa !29
  %t13 = getelementptr %"compiler/build:Config", ptr %t11, i32 0, i32 3
  %t15 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eHas(ptr %v2, ptr %s0, ptr %t13, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d294, i32 0, i32 1) })
  store i1 %t15, ptr %l16
  br label %bb1
bb1:
  %t16 = load i1, ptr %l16, !tbaa !21
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t17 = load ptr, ptr %l3, !tbaa !29
  %t19 = getelementptr %"compiler/build:Config", ptr %t17, i32 0, i32 3
  %t21 = call { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eRaw(ptr %v2, ptr %s0, ptr %s0, ptr %t19, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d295, i32 0, i32 1) })
  store { i64, ptr } %t21, ptr %l20
  br label %bb4
bb3:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d296, i32 0, i32 1) }, ptr %l17, !tbaa !27
  br label %bb5
bb4:
  %t22 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  br label %bb5
bb5:
  %t24 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t24, ptr %l6, !tbaa !27
  %t25 = load ptr, ptr %l3, !tbaa !29
  %t27 = getelementptr %"compiler/build:Config", ptr %t25, i32 0, i32 2
  %t28 = getelementptr %"compiler/target:Target", ptr %t27, i32 0, i32 5
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  %t30 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d297, i32 0, i32 1) }, 1
  %t31 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d297, i32 0, i32 1) }, 0
  %t33 = extractvalue { i64, ptr } %t29, 1
  %t34 = extractvalue { i64, ptr } %t29, 0
  %t35 = add i64 %t31, %t34
  %t36 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d298, i32 0, i32 1) }, 1
  %t37 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d298, i32 0, i32 1) }, 0
  %t38 = add i64 %t35, %t37
  %t39 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t38)
  call void @olang_textcopy(ptr %t39, ptr %t30, i64 %t31)
  %t40 = getelementptr i8, ptr %t39, i64 %t31
  call void @olang_textcopy(ptr %t40, ptr %t33, i64 %t34)
  %t41 = getelementptr i8, ptr %t40, i64 %t34
  call void @olang_textcopy(ptr %t41, ptr %t36, i64 %t37)
  %t42 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t39, 1
  store { i64, ptr } %t43, ptr %l7, !tbaa !27
  %t45 = load ptr, ptr %l3, !tbaa !29
  %t47 = getelementptr %"compiler/build:Config", ptr %t45, i32 0, i32 2
  %t48 = getelementptr %"compiler/target:Target", ptr %t47, i32 0, i32 1
  %t49 = load { i64, ptr }, ptr %t48, !tbaa !27
  %t50 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d299, i32 0, i32 1) }, 1
  %t51 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d299, i32 0, i32 1) }, 0
  %t53 = extractvalue { i64, ptr } %t49, 1
  %t54 = extractvalue { i64, ptr } %t49, 0
  %t55 = add i64 %t51, %t54
  %t56 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d300, i32 0, i32 1) }, 1
  %t57 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d300, i32 0, i32 1) }, 0
  %t58 = add i64 %t55, %t57
  %t59 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t58)
  call void @olang_textcopy(ptr %t59, ptr %t50, i64 %t51)
  %t60 = getelementptr i8, ptr %t59, i64 %t51
  call void @olang_textcopy(ptr %t60, ptr %t53, i64 %t54)
  %t61 = getelementptr i8, ptr %t60, i64 %t54
  call void @olang_textcopy(ptr %t61, ptr %t56, i64 %t57)
  %t62 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t59, 1
  store { i64, ptr } %t63, ptr %l8, !tbaa !27
  %t65 = load ptr, ptr %l4, !tbaa !29
  %t67 = getelementptr %"compiler/build:Program", ptr %t65, i32 0, i32 0
  store ptr %t67, ptr %l29, !tbaa !29
  store i32 0, ptr %l30
  %t68 = call ptr @__olang_scope_hold(ptr %v3)
  %t69 = ptrtoint ptr %t68 to i64
  store i64 %t69, ptr %l31, !tbaa !24
  %t70 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3aUnit_2e2
  br i1 %t70, label %bb6, label %bb7
bb6:
  %t72 = call ptr @__olang_region_make(ptr %v3)
  %t73 = ptrtoint ptr %t72 to i64
  store i64 %t73, ptr %l31, !tbaa !24
  br label %bb7
bb7:
  %t74 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t74, 1
  %t79 = extractvalue { i64, ptr } %t74, 0
  %t80 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d301, i32 0, i32 1) }, 1
  %t81 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d301, i32 0, i32 1) }, 0
  %t82 = add i64 %t79, %t81
  %t84 = extractvalue { i64, ptr } %t75, 1
  %t85 = extractvalue { i64, ptr } %t75, 0
  %t86 = add i64 %t82, %t85
  %t87 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d302, i32 0, i32 1) }, 1
  %t88 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d302, i32 0, i32 1) }, 0
  %t89 = add i64 %t86, %t88
  %t91 = extractvalue { i64, ptr } %t76, 1
  %t92 = extractvalue { i64, ptr } %t76, 0
  %t93 = add i64 %t89, %t92
  %t94 = load i64, ptr %l31
  %t95 = inttoptr i64 %t94 to ptr
  %t96 = call ptr @__olang_held_alloc(ptr %t95, i64 %t93)
  call void @olang_textcopy(ptr %t96, ptr %t78, i64 %t79)
  %t97 = getelementptr i8, ptr %t96, i64 %t79
  call void @olang_textcopy(ptr %t97, ptr %t80, i64 %t81)
  %t98 = getelementptr i8, ptr %t97, i64 %t81
  call void @olang_textcopy(ptr %t98, ptr %t84, i64 %t85)
  %t99 = getelementptr i8, ptr %t98, i64 %t85
  call void @olang_textcopy(ptr %t99, ptr %t87, i64 %t88)
  %t100 = getelementptr i8, ptr %t99, i64 %t88
  call void @olang_textcopy(ptr %t100, ptr %t91, i64 %t92)
  %t101 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t96, 1
  %t104 = load i32, ptr %l30, !range !{i32 0, i32 5}
  %t106 = call %"compiler/build:Unit" @compiler_2fbuild_3aUnit_2ector(ptr %v3, ptr %v3, ptr %v3, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d303, i32 0, i32 1) }, i32 %t104, { i64, ptr } %t102)
  store %"compiler/build:Unit" %t106, ptr %l38
  br label %bb8
bb8:
  %t107 = load ptr, ptr %l29, !tbaa !29
  %t108 = load %"compiler/build:Unit", ptr %l38
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2ePush_3ccompiler_2fbuild_3aUnit_3e(ptr %v3, ptr %v3, ptr %t107, %"compiler/build:Unit" %t108)
  br label %bb9
bb9:
  %t109 = load ptr, ptr %l4, !tbaa !29
  %t111 = getelementptr %"compiler/build:Program", ptr %t109, i32 0, i32 0
  store ptr %t111, ptr %l40, !tbaa !29
  store i32 0, ptr %l41
  %t112 = call ptr @__olang_scope_hold(ptr %v3)
  %t113 = ptrtoint ptr %t112 to i64
  store i64 %t113, ptr %l42, !tbaa !24
  %t114 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3aUnit_2e2
  br i1 %t114, label %bb10, label %bb11
bb10:
  %t116 = call ptr @__olang_region_make(ptr %v3)
  %t117 = ptrtoint ptr %t116 to i64
  store i64 %t117, ptr %l42, !tbaa !24
  br label %bb11
bb11:
  %t118 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/build:stubFrontend", ptr %t119, i32 0, i32 0
  %t122 = load i64, ptr %t121, !tbaa !24
  %t123 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t118, 1
  %t126 = extractvalue { i64, ptr } %t118, 0
  %t127 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d304, i32 0, i32 1) }, 1
  %t128 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d304, i32 0, i32 1) }, 0
  %t129 = add i64 %t126, %t128
  %t131 = call i64 @__olang_fmt_i64(ptr null, i64 %t122)
  %t132 = add i64 %t129, %t131
  %t133 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d305, i32 0, i32 1) }, 1
  %t134 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d305, i32 0, i32 1) }, 0
  %t135 = add i64 %t132, %t134
  %t137 = extractvalue { i64, ptr } %t123, 1
  %t138 = extractvalue { i64, ptr } %t123, 0
  %t139 = add i64 %t135, %t138
  %t140 = load i64, ptr %l42
  %t141 = inttoptr i64 %t140 to ptr
  %t142 = call ptr @__olang_held_alloc(ptr %t141, i64 %t139)
  call void @olang_textcopy(ptr %t142, ptr %t125, i64 %t126)
  %t143 = getelementptr i8, ptr %t142, i64 %t126
  call void @olang_textcopy(ptr %t143, ptr %t127, i64 %t128)
  %t144 = getelementptr i8, ptr %t143, i64 %t128
  %t145 = call i64 @__olang_fmt_i64(ptr %t144, i64 %t122)
  %t146 = getelementptr i8, ptr %t144, i64 %t131
  call void @olang_textcopy(ptr %t146, ptr %t133, i64 %t134)
  %t147 = getelementptr i8, ptr %t146, i64 %t134
  call void @olang_textcopy(ptr %t147, ptr %t137, i64 %t138)
  %t148 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t142, 1
  %t151 = load i32, ptr %l41, !range !{i32 0, i32 5}
  %t153 = call %"compiler/build:Unit" @compiler_2fbuild_3aUnit_2ector(ptr %v3, ptr %v3, ptr %v3, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d306, i32 0, i32 1) }, i32 %t151, { i64, ptr } %t149)
  store %"compiler/build:Unit" %t153, ptr %l50
  br label %bb12
bb12:
  %t154 = load ptr, ptr %l40, !tbaa !29
  %t155 = load %"compiler/build:Unit", ptr %l50
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2ePush_3ccompiler_2fbuild_3aUnit_3e(ptr %v3, ptr %v3, ptr %t154, %"compiler/build:Unit" %t155)
  br label %bb13
bb13:
  %t156 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t159 = extractvalue { i64, ptr } %t156, 1
  %t160 = extractvalue { i64, ptr } %t156, 0
  %t161 = extractvalue { i64, ptr } { i64 90, ptr getelementptr inbounds (<{ i64, [90 x i8] }>, ptr @.d307, i32 0, i32 1) }, 1
  %t162 = extractvalue { i64, ptr } { i64 90, ptr getelementptr inbounds (<{ i64, [90 x i8] }>, ptr @.d307, i32 0, i32 1) }, 0
  %t163 = add i64 %t160, %t162
  %t164 = extractvalue { i64, ptr } { i64 73, ptr getelementptr inbounds (<{ i64, [73 x i8] }>, ptr @.d308, i32 0, i32 1) }, 1
  %t165 = extractvalue { i64, ptr } { i64 73, ptr getelementptr inbounds (<{ i64, [73 x i8] }>, ptr @.d308, i32 0, i32 1) }, 0
  %t166 = add i64 %t163, %t165
  %t167 = extractvalue { i64, ptr } { i64 96, ptr getelementptr inbounds (<{ i64, [96 x i8] }>, ptr @.d309, i32 0, i32 1) }, 1
  %t168 = extractvalue { i64, ptr } { i64 96, ptr getelementptr inbounds (<{ i64, [96 x i8] }>, ptr @.d309, i32 0, i32 1) }, 0
  %t169 = add i64 %t166, %t168
  %t170 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d310, i32 0, i32 1) }, 1
  %t171 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d310, i32 0, i32 1) }, 0
  %t172 = add i64 %t169, %t171
  %t174 = extractvalue { i64, ptr } %t157, 1
  %t175 = extractvalue { i64, ptr } %t157, 0
  %t176 = add i64 %t172, %t175
  %t177 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t176)
  call void @olang_textcopy(ptr %t177, ptr %t159, i64 %t160)
  %t178 = getelementptr i8, ptr %t177, i64 %t160
  call void @olang_textcopy(ptr %t178, ptr %t161, i64 %t162)
  %t179 = getelementptr i8, ptr %t178, i64 %t162
  call void @olang_textcopy(ptr %t179, ptr %t164, i64 %t165)
  %t180 = getelementptr i8, ptr %t179, i64 %t165
  call void @olang_textcopy(ptr %t180, ptr %t167, i64 %t168)
  %t181 = getelementptr i8, ptr %t180, i64 %t168
  call void @olang_textcopy(ptr %t181, ptr %t170, i64 %t171)
  %t182 = getelementptr i8, ptr %t181, i64 %t171
  call void @olang_textcopy(ptr %t182, ptr %t174, i64 %t175)
  %t183 = insertvalue { i64, ptr } undef, i64 %t176, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t177, 1
  store { i64, ptr } %t184, ptr %l9, !tbaa !27
  %t187 = load ptr, ptr %l4, !tbaa !29
  %t189 = getelementptr %"compiler/build:Program", ptr %t187, i32 0, i32 0
  store ptr %t189, ptr %l56, !tbaa !29
  %t192 = trunc i64 1 to i32
  %t193 = icmp eq i32 %a2, %t192
  br i1 %t193, label %bb14, label %bb15
bb14:
  store i32 1, ptr %l59
  br label %bb16
bb15:
  store i32 2, ptr %l59
  br label %bb16
bb16:
  %t197 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t198 = load i32, ptr %l59, !range !{i32 0, i32 5}
  %t200 = call %"compiler/build:Unit" @compiler_2fbuild_3aUnit_2ector(ptr %v3, ptr %v3, ptr %v3, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d311, i32 0, i32 1) }, i32 %t198, { i64, ptr } %t197)
  store %"compiler/build:Unit" %t200, ptr %l63
  br label %bb17
bb17:
  %t201 = load ptr, ptr %l56, !tbaa !29
  %t202 = load %"compiler/build:Unit", ptr %l63
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2ePush_3ccompiler_2fbuild_3aUnit_3e(ptr %v3, ptr %v3, ptr %t201, %"compiler/build:Unit" %t202)
  br label %bb18
bb18:
  %t203 = load ptr, ptr %l4, !tbaa !29
  %t205 = getelementptr %"compiler/build:Program", ptr %t203, i32 0, i32 0
  store ptr %t205, ptr %l65, !tbaa !29
  store i32 3, ptr %l66
  %t206 = call ptr @__olang_scope_hold(ptr %v3)
  %t207 = ptrtoint ptr %t206 to i64
  store i64 %t207, ptr %l67, !tbaa !24
  %t208 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3aUnit_2e2
  br i1 %t208, label %bb19, label %bb20
bb19:
  %t210 = call ptr @__olang_region_make(ptr %v3)
  %t211 = ptrtoint ptr %t210 to i64
  store i64 %t211, ptr %l67, !tbaa !24
  br label %bb20
bb20:
  %t212 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t213 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t215 = extractvalue { i64, ptr } %t212, 1
  %t216 = extractvalue { i64, ptr } %t212, 0
  %t217 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d312, i32 0, i32 1) }, 1
  %t218 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d312, i32 0, i32 1) }, 0
  %t219 = add i64 %t216, %t218
  %t221 = extractvalue { i64, ptr } %t213, 1
  %t222 = extractvalue { i64, ptr } %t213, 0
  %t223 = add i64 %t219, %t222
  %t224 = load i64, ptr %l67
  %t225 = inttoptr i64 %t224 to ptr
  %t226 = call ptr @__olang_held_alloc(ptr %t225, i64 %t223)
  call void @olang_textcopy(ptr %t226, ptr %t215, i64 %t216)
  %t227 = getelementptr i8, ptr %t226, i64 %t216
  call void @olang_textcopy(ptr %t227, ptr %t217, i64 %t218)
  %t228 = getelementptr i8, ptr %t227, i64 %t218
  call void @olang_textcopy(ptr %t228, ptr %t221, i64 %t222)
  %t229 = insertvalue { i64, ptr } undef, i64 %t223, 0
  %t230 = insertvalue { i64, ptr } %t229, ptr %t226, 1
  %t232 = load i32, ptr %l66, !range !{i32 0, i32 5}
  %t234 = call %"compiler/build:Unit" @compiler_2fbuild_3aUnit_2ector(ptr %v3, ptr %v3, ptr %v3, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d313, i32 0, i32 1) }, i32 %t232, { i64, ptr } %t230)
  store %"compiler/build:Unit" %t234, ptr %l73
  br label %bb21
bb21:
  %t235 = load ptr, ptr %l65, !tbaa !29
  %t236 = load %"compiler/build:Unit", ptr %l73
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2ePush_3ccompiler_2fbuild_3aUnit_3e(ptr %v3, ptr %v3, ptr %t235, %"compiler/build:Unit" %t236)
  br label %bb22
bb22:
  %t237 = load ptr, ptr %l4, !tbaa !29
  store ptr %t237, ptr %l74, !tbaa !29
  %t238 = call ptr @__olang_scope_hold(ptr %v3)
  %t239 = ptrtoint ptr %t238 to i64
  store i64 %t239, ptr %l75, !tbaa !24
  %t240 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3aProgram_2e1
  br i1 %t240, label %bb23, label %bb24
bb23:
  %t242 = call ptr @__olang_region_make(ptr %v3)
  %t243 = ptrtoint ptr %t242 to i64
  store i64 %t243, ptr %l75, !tbaa !24
  br label %bb24
bb24:
  %t244 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t245 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t247 = extractvalue { i64, ptr } %t244, 1
  %t248 = extractvalue { i64, ptr } %t244, 0
  %t249 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d314, i32 0, i32 1) }, 1
  %t250 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d314, i32 0, i32 1) }, 0
  %t251 = add i64 %t248, %t250
  %t253 = extractvalue { i64, ptr } %t245, 1
  %t254 = extractvalue { i64, ptr } %t245, 0
  %t255 = add i64 %t251, %t254
  %t256 = load i64, ptr %l75
  %t257 = inttoptr i64 %t256 to ptr
  %t258 = call ptr @__olang_held_alloc(ptr %t257, i64 %t255)
  call void @olang_textcopy(ptr %t258, ptr %t247, i64 %t248)
  %t259 = getelementptr i8, ptr %t258, i64 %t248
  call void @olang_textcopy(ptr %t259, ptr %t249, i64 %t250)
  %t260 = getelementptr i8, ptr %t259, i64 %t250
  call void @olang_textcopy(ptr %t260, ptr %t253, i64 %t254)
  %t261 = insertvalue { i64, ptr } undef, i64 %t255, 0
  %t262 = insertvalue { i64, ptr } %t261, ptr %t258, 1
  %t264 = load ptr, ptr %l74, !tbaa !29
  %t265 = getelementptr %"compiler/build:Program", ptr %t264, i32 0, i32 1
  %t266 = load { i64, ptr }, ptr %t265, !tbaa !27
  store { i64, ptr } %t266, ptr %l81, !tbaa !27
  %t268 = load ptr, ptr %l74, !tbaa !29
  %t269 = getelementptr %"compiler/build:Program", ptr %t268, i32 0, i32 1
  store { i64, ptr } %t262, ptr %t269, !tbaa !27
  %t270 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3aProgram_2e1
  br i1 %t270, label %bb25, label %bb26
bb25:
  %t272 = load { i64, ptr }, ptr %l81
  %t273 = extractvalue { i64, ptr } %t272, 1
  call void @__olang_region_release(ptr %t273)
  store { i64, ptr } zeroinitializer, ptr %l81
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2eexecTests(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l3 = alloca %"std/os:Output"
  %l8 = alloca i32
  %l9 = alloca %"std/os:Output"
  %l11 = alloca { i64, ptr }
  %l12 = alloca %"std/os:Output"
  %l13 = alloca i32
  %l15 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/build:Config", ptr %a0, i32 0, i32 20
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t6 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t10 = call i32 @compiler_2fmeasure_2eMeasure(ptr %v1, ptr %s1, { i64, ptr } %t6, i64 %a2, i64 1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d315, i32 0, i32 1) })
  store i32 %t10, ptr %l8
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t11 = load i32, ptr %l8, !tbaa !23
  store i32 %t11, ptr %rv
  br label %ret
bb4:
  %t12 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %l11, !tbaa !27
  %t14 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t15 = call { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExec(ptr %v1, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t12, { i64, ptr } %t14, i1 false, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d39, i32 0, i32 1) })
  %t16 = extractvalue { i32, %"std/os:Output" } %t15, 1
  %t17 = extractvalue { i32, %"std/os:Output" } %t15, 0
  store i32 %t17, ptr %l13
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb6, label %ok.19, !prof !99
ok.19:
  store %"std/os:Output" %t16, ptr %l12
  br label %bb5
bb5:
  %t20 = load %"std/os:Output", ptr %l12
  store %"std/os:Output" %t20, ptr %l9
  br label %bb10
bb6:
  %t21 = load i32, ptr %l13, !tbaa !23
  %t22 = ashr i32 %t21, 16
  %t24 = icmp eq i32 %t22, 1
  store i1 %t24, ptr %l15, !tbaa !21
  %t25 = load i32, ptr %l13, !tbaa !23
  %t26 = ashr i32 %t25, 16
  %t28 = icmp eq i32 %t26, 1
  br i1 %t28, label %bb7, label %bb8
bb7:
  call void @__olang_errpay_pop()
  br label %bb8
bb8:
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  store i32 -1, ptr %rv
  br label %ret
bb10:
  %t31 = load %"std/os:Output", ptr %l9
  store %"std/os:Output" %t31, ptr %l3
  %t32 = getelementptr %"std/os:Output", ptr %l3, i32 0, i32 0
  %t33 = load i32, ptr %t32, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t33, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ehoisted(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i1
  %l23 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l34 = alloca %"std/prelude/text:StringBuilder"
  %l35 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l56 = alloca ptr
  %l59 = alloca i1
  %l61 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l71 = alloca ptr
  %l73 = alloca { i64, ptr }
  %l76 = alloca i64
  %l79 = alloca { i64, ptr }
  %l81 = alloca [3 x { i64, ptr }]
  %l82 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i64, ptr } @std_2ffilepath_2eBase(ptr %v0, ptr %s0, { i64, ptr } %t1)
  store { i64, ptr } %t3, ptr %l13
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d316, i32 0, i32 1) }, ptr %l15, !tbaa !27
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d317, i32 0, i32 1) }, ptr %l16, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t8 = call { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t4, { i64, ptr } %t6, { i64, ptr } %t7)
  store { i64, ptr } %t8, ptr %l17
  br label %bb2
bb2:
  %t9 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t9, ptr %l3, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d318, i32 0, i32 1) }, ptr %l21, !tbaa !27
  %t14 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t15 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s0, { i64, ptr } %t11, { i64, ptr } %t14)
  store i1 %t15, ptr %l22
  br label %bb3
bb3:
  %t16 = load i1, ptr %l22, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t17 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t19 = call { i64, ptr } @std_2ffilepath_2eDir(ptr %v0, ptr %s0, { i64, ptr } %t17)
  store { i64, ptr } %t19, ptr %l25
  br label %bb6
bb5:
  %t20 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 1
  %t23 = extractvalue { i64, ptr } %t20, 0
  %t24 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t22, i64 %t23)
  %t25 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  store { i64, ptr } %t26, ptr %l23, !tbaa !27
  br label %bb7
bb6:
  %t28 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 1
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t32 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d319, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d319, i32 0, i32 1) }, 0
  %t34 = add i64 %t31, %t33
  %t36 = extractvalue { i64, ptr } %t28, 1
  %t37 = extractvalue { i64, ptr } %t28, 0
  %t38 = add i64 %t34, %t37
  %t39 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t38)
  call void @olang_textcopy(ptr %t39, ptr %t30, i64 %t31)
  %t40 = getelementptr i8, ptr %t39, i64 %t31
  call void @olang_textcopy(ptr %t40, ptr %t32, i64 %t33)
  %t41 = getelementptr i8, ptr %t40, i64 %t33
  call void @olang_textcopy(ptr %t41, ptr %t36, i64 %t37)
  %t42 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t39, 1
  store { i64, ptr } %t43, ptr %l23, !tbaa !27
  br label %bb7
bb7:
  %t45 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t45, ptr %l4, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t46, 1
  %t49 = extractvalue { i64, ptr } %t46, 0
  %t50 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d320, i32 0, i32 1) }, 1
  %t51 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d320, i32 0, i32 1) }, 0
  %t52 = add i64 %t49, %t51
  %t53 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t52)
  call void @olang_textcopy(ptr %t53, ptr %t48, i64 %t49)
  %t54 = getelementptr i8, ptr %t53, i64 %t49
  call void @olang_textcopy(ptr %t54, ptr %t50, i64 %t51)
  %t55 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t53, 1
  store { i64, ptr } %t56, ptr %l5, !tbaa !27
  store { i64, ptr } { i64 129, ptr getelementptr inbounds (<{ i64, [129 x i8] }>, ptr @.d321, i32 0, i32 1) }, ptr %l32, !tbaa !27
  %t58 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t58, ptr %l6, !tbaa !27
  %t60 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t60, ptr %l34
  br label %bb8
bb8:
  %t61 = load %"std/prelude/text:StringBuilder", ptr %l34
  store %"std/prelude/text:StringBuilder" %t61, ptr %l7
  store ptr %l7, ptr %l35, !tbaa !29
  %t62 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t64 = call { i64, ptr } @std_2fos_2eQuote(ptr %s0, ptr %s0, { i64, ptr } %t62)
  store { i64, ptr } %t64, ptr %l37
  br label %bb9
bb9:
  %t65 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t67 = call { i64, ptr } @std_2fos_2eQuote(ptr %s0, ptr %s0, { i64, ptr } %t65)
  store { i64, ptr } %t67, ptr %l39
  br label %bb10
bb10:
  %t68 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t70 = call { i64, ptr } @std_2fos_2eQuote(ptr %v2, ptr %s0, { i64, ptr } %t68)
  store { i64, ptr } %t70, ptr %l41
  br label %bb11
bb11:
  %t71 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t73 = call { i64, ptr } @std_2fos_2eQuote(ptr %s0, ptr %s0, { i64, ptr } %t71)
  store { i64, ptr } %t73, ptr %l43
  br label %bb12
bb12:
  %t74 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t74, 1
  %t76 = extractvalue { i64, ptr } %t74, 0
  %t77 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d322, i32 0, i32 1) }, 1
  %t78 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d322, i32 0, i32 1) }, 0
  %t79 = add i64 %t76, %t78
  %t80 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 1
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t83 = add i64 %t79, %t82
  %t84 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d323, i32 0, i32 1) }, 1
  %t85 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d323, i32 0, i32 1) }, 0
  %t86 = add i64 %t83, %t85
  %t87 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 1
  %t89 = extractvalue { i64, ptr } %t87, 0
  %t90 = add i64 %t86, %t89
  %t91 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d324, i32 0, i32 1) }, 1
  %t92 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d324, i32 0, i32 1) }, 0
  %t93 = add i64 %t90, %t92
  %t94 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 1
  %t96 = extractvalue { i64, ptr } %t94, 0
  %t97 = add i64 %t93, %t96
  %t98 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d325, i32 0, i32 1) }, 1
  %t99 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d325, i32 0, i32 1) }, 0
  %t100 = add i64 %t97, %t99
  %t101 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t100)
  call void @olang_textcopy(ptr %t101, ptr %t75, i64 %t76)
  %t102 = getelementptr i8, ptr %t101, i64 %t76
  call void @olang_textcopy(ptr %t102, ptr %t77, i64 %t78)
  %t103 = getelementptr i8, ptr %t102, i64 %t78
  call void @olang_textcopy(ptr %t103, ptr %t81, i64 %t82)
  %t104 = getelementptr i8, ptr %t103, i64 %t82
  call void @olang_textcopy(ptr %t104, ptr %t84, i64 %t85)
  %t105 = getelementptr i8, ptr %t104, i64 %t85
  call void @olang_textcopy(ptr %t105, ptr %t88, i64 %t89)
  %t106 = getelementptr i8, ptr %t105, i64 %t89
  call void @olang_textcopy(ptr %t106, ptr %t91, i64 %t92)
  %t107 = getelementptr i8, ptr %t106, i64 %t92
  call void @olang_textcopy(ptr %t107, ptr %t95, i64 %t96)
  %t108 = getelementptr i8, ptr %t107, i64 %t96
  call void @olang_textcopy(ptr %t108, ptr %t98, i64 %t99)
  %t109 = insertvalue { i64, ptr } undef, i64 %t100, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t101, 1
  %t112 = load ptr, ptr %l35, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t112, { i64, ptr } %t110)
  br label %bb13
bb13:
  store { i64, ptr } %a1, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t116 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t116, 0
  store i64 %t118, ptr %l10, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s6
  %t120 = load i64, ptr %l9, !tbaa !24
  %t121 = load i64, ptr %l10, !tbaa !24
  %t124 = icmp slt i64 %t120, %t121
  %t126 = xor i1 %t124, true
  br i1 %t126, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s6)
  br label %bb25
bb16:
  br label %bb17
bb17:
  %t128 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t128, ptr %l53, !tbaa !27
  %t129 = load i64, ptr %l9, !tbaa !24
  %t131 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr { i64, ptr }, ptr %t132, i64 %t129
  %t134 = load { i64, ptr }, ptr %t133, !tbaa !37
  store { i64, ptr } %t134, ptr %l11, !tbaa !27
  store ptr %l7, ptr %l56, !tbaa !29
  %t136 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t137 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t140 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %v2, { i64, ptr } %t136, { i64, ptr } %t137)
  store i1 %t140, ptr %l59
  br label %bb18
bb18:
  %t141 = load i1, ptr %l59, !tbaa !21
  %t142 = xor i1 %t141, true
  br i1 %t142, label %bb19, label %bb20
bb19:
  %t144 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t144, ptr %l61, !tbaa !27
  br label %bb21
bb20:
  %t146 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t146, ptr %l61, !tbaa !27
  br label %bb21
bb21:
  %t148 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t149 = extractvalue { i64, ptr } %t148, 1
  %t150 = call ptr @__olang_scope_of(ptr %t149, ptr null)
  %t151 = call ptr @__olang_scope_hold(ptr %t150)
  %t152 = ptrtoint ptr %t151 to i64
  %t154 = inttoptr i64 %t152 to ptr
  %t155 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t156 = call { i64, ptr } @std_2fos_2eQuote(ptr %t154, ptr %s6, { i64, ptr } %t155)
  store { i64, ptr } %t156, ptr %l65
  br label %bb22
bb22:
  %t157 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d326, i32 0, i32 1) }, 1
  %t158 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d326, i32 0, i32 1) }, 0
  %t159 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t159, 1
  %t161 = extractvalue { i64, ptr } %t159, 0
  %t162 = add i64 %t158, %t161
  %t163 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t162)
  call void @olang_textcopy(ptr %t163, ptr %t157, i64 %t158)
  %t164 = getelementptr i8, ptr %t163, i64 %t158
  call void @olang_textcopy(ptr %t164, ptr %t160, i64 %t161)
  %t165 = insertvalue { i64, ptr } undef, i64 %t162, 0
  %t166 = insertvalue { i64, ptr } %t165, ptr %t163, 1
  %t168 = load ptr, ptr %l56, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %t168, { i64, ptr } %t166)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s6)
  br label %bb24
bb24:
  %t170 = load i64, ptr %l9, !tbaa !24
  %t173 = add i64 %t170, 1
  store i64 %t173, ptr %l9, !tbaa !24
  br label %bb14
bb25:
  store ptr %l7, ptr %l71, !tbaa !29
  %t175 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t177 = call { i64, ptr } @std_2fos_2eQuote(ptr %s0, ptr %s0, { i64, ptr } %t175)
  store { i64, ptr } %t177, ptr %l73
  br label %bb26
bb26:
  %t178 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d327, i32 0, i32 1) }, 1
  %t179 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d327, i32 0, i32 1) }, 0
  %t180 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t181 = extractvalue { i64, ptr } %t180, 1
  %t182 = extractvalue { i64, ptr } %t180, 0
  %t183 = add i64 %t179, %t182
  %t184 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d328, i32 0, i32 1) }, 1
  %t185 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d328, i32 0, i32 1) }, 0
  %t186 = add i64 %t183, %t185
  %t187 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t186)
  call void @olang_textcopy(ptr %t187, ptr %t178, i64 %t179)
  %t188 = getelementptr i8, ptr %t187, i64 %t179
  call void @olang_textcopy(ptr %t188, ptr %t181, i64 %t182)
  %t189 = getelementptr i8, ptr %t188, i64 %t182
  call void @olang_textcopy(ptr %t189, ptr %t184, i64 %t185)
  %t190 = insertvalue { i64, ptr } undef, i64 %t186, 0
  %t191 = insertvalue { i64, ptr } %t190, ptr %t187, 1
  %t193 = load ptr, ptr %l71, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t193, { i64, ptr } %t191)
  br label %bb27
bb27:
  %t195 = call ptr @__olang_scope_hold(ptr %v3)
  %t196 = ptrtoint ptr %t195 to i64
  store i64 %t196, ptr %l76, !tbaa !24
  %t197 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_203_3e_2e_2d1
  br i1 %t197, label %bb28, label %bb29
bb28:
  %t199 = call ptr @__olang_region_make(ptr %v3)
  %t200 = ptrtoint ptr %t199 to i64
  store i64 %t200, ptr %l76, !tbaa !24
  br label %bb29
bb29:
  %t201 = load i64, ptr %l76
  %t202 = inttoptr i64 %t201 to ptr
  %t204 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %t202, ptr %l7)
  store { i64, ptr } %t204, ptr %l79
  br label %bb30
bb30:
  %t205 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t206 = insertvalue [3 x { i64, ptr }] undef, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d329, i32 0, i32 1) }, 0
  %t207 = insertvalue [3 x { i64, ptr }] %t206, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d330, i32 0, i32 1) }, 1
  %t209 = insertvalue [3 x { i64, ptr }] %t207, { i64, ptr } %t205, 2
  store [3 x { i64, ptr }] %t209, ptr %l81
  %t210 = mul i64 3, 16
  %t211 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t210)
  %t212 = insertvalue { i64, ptr } undef, i64 3, 0
  %t213 = insertvalue { i64, ptr } %t212, ptr %t211, 1
  store { i64, ptr } %t213, ptr %l82, !tbaa !27
  %t214 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = mul i64 3, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t215, ptr %l81, i64 %t216, i1 false)
  call void @__olang_scope_close(ptr %s0)
  %t217 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t217, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fbuild_2eholderAlive(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/os:FileInfo"
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/os:FileInfo"
  %l6 = alloca %"std/os:FileInfo"
  %l7 = alloca i32
  %l9 = alloca i1
  %l13 = alloca i64
  %l19 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i32
  %l26 = alloca i1
  %l32 = alloca i1
  %l38 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, %"std/os:FileInfo" } @std_2fos_2eFileInfo_2eStat(ptr %v0, { i64, ptr } %t1)
  %t4 = extractvalue { i32, %"std/os:FileInfo" } %t3, 1
  %t5 = extractvalue { i32, %"std/os:FileInfo" } %t3, 0
  store i32 %t5, ptr %l7
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store %"std/os:FileInfo" %t4, ptr %l6
  br label %bb1
bb1:
  %t8 = load %"std/os:FileInfo", ptr %l6
  store %"std/os:FileInfo" %t8, ptr %l4
  br label %bb6
bb2:
  %t9 = load i32, ptr %l7, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  store i1 %t12, ptr %l9, !tbaa !21
  %t13 = load i32, ptr %l7, !tbaa !23
  %t14 = ashr i32 %t13, 16
  %t16 = icmp eq i32 %t14, 1
  br i1 %t16, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb6:
  %t19 = load %"std/os:FileInfo", ptr %l4
  store %"std/os:FileInfo" %t19, ptr %l1
  %t20 = call i64 @std_2ftime_2eWall()
  store i64 %t20, ptr %l13
  br label %bb7
bb7:
  %t21 = getelementptr %"std/os:FileInfo", ptr %l1, i32 0, i32 2
  %t22 = load i64, ptr %t21, !tbaa !24
  %t23 = load i64, ptr %l13, !tbaa !24
  %t25 = sub i64 %t23, %t22
  store i64 %t25, ptr %l2, !tbaa !24
  %t27 = load i64, ptr %l2, !tbaa !24
  %t29 = icmp sgt i64 %t27, 1800000000000
  br i1 %t29, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t32 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 1
  %t35 = extractvalue { i64, ptr } %t32, 0
  %t36 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d331, i32 0, i32 1) }, 1
  %t37 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d331, i32 0, i32 1) }, 0
  %t38 = add i64 %t35, %t37
  %t39 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t38)
  call void @olang_textcopy(ptr %t39, ptr %t34, i64 %t35)
  %t40 = getelementptr i8, ptr %t39, i64 %t35
  call void @olang_textcopy(ptr %t40, ptr %t36, i64 %t37)
  %t41 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t39, 1
  %t45 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s0, { i64, ptr } %t42)
  %t46 = extractvalue { i32, { i64, ptr } } %t45, 1
  %t47 = extractvalue { i32, { i64, ptr } } %t45, 0
  store i32 %t47, ptr %l24
  %t48 = icmp ne i32 %t47, 0
  br i1 %t48, label %bb12, label %ok.49, !prof !99
ok.49:
  store { i64, ptr } %t46, ptr %l23
  br label %bb11
bb11:
  %t50 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t50, ptr %l19, !tbaa !27
  br label %bb16
bb12:
  %t51 = load i32, ptr %l24, !tbaa !23
  %t52 = ashr i32 %t51, 16
  %t54 = icmp eq i32 %t52, 1
  store i1 %t54, ptr %l26, !tbaa !21
  %t55 = load i32, ptr %l24, !tbaa !23
  %t56 = ashr i32 %t55, 16
  %t58 = icmp eq i32 %t56, 1
  br i1 %t58, label %bb13, label %bb14
bb13:
  call void @__olang_errpay_pop()
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t60 = load i64, ptr %l2, !tbaa !24
  %t62 = icmp slt i64 %t60, 60000000000
  call void @__olang_scope_close(ptr %s0)
  store i1 %t62, ptr %rv
  br label %ret
bb16:
  %t64 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t64, ptr %l3, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t67 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t65, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d332, i32 0, i32 1) })
  store i1 %t67, ptr %l32
  br label %bb17
bb17:
  %t68 = load i1, ptr %l32, !tbaa !21
  br i1 %t68, label %bb18, label %bb19
bb18:
  %t69 = load i64, ptr %l2, !tbaa !24
  %t71 = icmp slt i64 %t69, 60000000000
  call void @__olang_scope_close(ptr %s0)
  store i1 %t71, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t73 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t74 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d333, i32 0, i32 1) }, 1
  %t75 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d333, i32 0, i32 1) }, 0
  %t77 = extractvalue { i64, ptr } %t73, 1
  %t78 = extractvalue { i64, ptr } %t73, 0
  %t79 = add i64 %t75, %t78
  %t80 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t79)
  call void @olang_textcopy(ptr %t80, ptr %t74, i64 %t75)
  %t81 = getelementptr i8, ptr %t80, i64 %t75
  call void @olang_textcopy(ptr %t81, ptr %t77, i64 %t78)
  %t82 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t80, 1
  %t86 = call i1 @std_2fos_2eExists(ptr %s0, { i64, ptr } %t83)
  store i1 %t86, ptr %l38
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s0)
  %t87 = load i1, ptr %l38, !tbaa !21
  store i1 %t87, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fbuild_2elinkCurrent(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/os:FileInfo"
  %l5 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %l10 = alloca i1
  %l14 = alloca %"std/os:FileInfo"
  %l16 = alloca %"std/os:FileInfo"
  %l17 = alloca i32
  %l19 = alloca i1
  %l29 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v1, ptr %s0, { i64, ptr } %a1)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l8
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store { i64, ptr } %t4, ptr %l7
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t8, ptr %l5, !tbaa !27
  br label %bb6
bb2:
  %t9 = load i32, ptr %l8, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  store i1 %t12, ptr %l10, !tbaa !21
  %t13 = load i32, ptr %l8, !tbaa !23
  %t14 = ashr i32 %t13, 16
  %t16 = icmp eq i32 %t14, 1
  br i1 %t16, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb6:
  %t19 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t19, ptr %l3, !tbaa !27
  %t22 = call { i32, %"std/os:FileInfo" } @std_2fos_2eFileInfo_2eStat(ptr %v0, { i64, ptr } %a0)
  %t23 = extractvalue { i32, %"std/os:FileInfo" } %t22, 1
  %t24 = extractvalue { i32, %"std/os:FileInfo" } %t22, 0
  store i32 %t24, ptr %l17
  %t25 = icmp ne i32 %t24, 0
  br i1 %t25, label %bb8, label %ok.26, !prof !99
ok.26:
  store %"std/os:FileInfo" %t23, ptr %l16
  br label %bb7
bb7:
  %t27 = load %"std/os:FileInfo", ptr %l16
  store %"std/os:FileInfo" %t27, ptr %l14
  br label %bb12
bb8:
  %t28 = load i32, ptr %l17, !tbaa !23
  %t29 = ashr i32 %t28, 16
  %t31 = icmp eq i32 %t29, 1
  store i1 %t31, ptr %l19, !tbaa !21
  %t32 = load i32, ptr %l17, !tbaa !23
  %t33 = ashr i32 %t32, 16
  %t35 = icmp eq i32 %t33, 1
  br i1 %t35, label %bb9, label %bb10
bb9:
  call void @__olang_errpay_pop()
  br label %bb10
bb10:
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb12:
  %t38 = load %"std/os:FileInfo", ptr %l14
  store %"std/os:FileInfo" %t38, ptr %l4
  %t39 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t41 = getelementptr %"std/os:FileInfo", ptr %l4, i32 0, i32 1
  %t42 = load i64, ptr %t41, !tbaa !24
  %t43 = getelementptr %"std/os:FileInfo", ptr %l4, i32 0, i32 2
  %t44 = load i64, ptr %t43, !tbaa !24
  %t46 = extractvalue { i64, ptr } %a2, 1
  %t47 = extractvalue { i64, ptr } %a2, 0
  %t48 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d334, i32 0, i32 1) }, 1
  %t49 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d334, i32 0, i32 1) }, 0
  %t50 = add i64 %t47, %t49
  %t52 = call i64 @__olang_fmt_i64(ptr null, i64 %t42)
  %t53 = add i64 %t50, %t52
  %t54 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d334, i32 0, i32 1) }, 1
  %t55 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d334, i32 0, i32 1) }, 0
  %t56 = add i64 %t53, %t55
  %t58 = call i64 @__olang_fmt_i64(ptr null, i64 %t44)
  %t59 = add i64 %t56, %t58
  %t60 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d335, i32 0, i32 1) }, 1
  %t61 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d335, i32 0, i32 1) }, 0
  %t62 = add i64 %t59, %t61
  %t63 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t62)
  call void @olang_textcopy(ptr %t63, ptr %t46, i64 %t47)
  %t64 = getelementptr i8, ptr %t63, i64 %t47
  call void @olang_textcopy(ptr %t64, ptr %t48, i64 %t49)
  %t65 = getelementptr i8, ptr %t64, i64 %t49
  %t66 = call i64 @__olang_fmt_i64(ptr %t65, i64 %t42)
  %t67 = getelementptr i8, ptr %t65, i64 %t52
  call void @olang_textcopy(ptr %t67, ptr %t54, i64 %t55)
  %t68 = getelementptr i8, ptr %t67, i64 %t55
  %t69 = call i64 @__olang_fmt_i64(ptr %t68, i64 %t44)
  %t70 = getelementptr i8, ptr %t68, i64 %t58
  call void @olang_textcopy(ptr %t70, ptr %t60, i64 %t61)
  %t71 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t63, 1
  %t76 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t39, { i64, ptr } %t72)
  store i1 %t76, ptr %l29
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t77 = load i1, ptr %l29, !tbaa !21
  store i1 %t77, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fbuild_2elistFiles(ptr %v0, ptr %v1, { i64, ptr } %a0, i1 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i32
  %l18 = alloca i1
  %l31 = alloca { i64, ptr }
  %l42 = alloca i64
  %l44 = alloca i64
  %l49 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l53 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i64
  %l63 = alloca i1
  %l64 = alloca i1
  %l67 = alloca { i64, ptr }
  %l68 = alloca i1
  %l69 = alloca i1
  %l71 = alloca i1
  %l72 = alloca i1
  %l74 = alloca i1
  %l77 = alloca ptr
  %l78 = alloca i64
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store { i64, ptr } %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l12
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l3
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = call { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v0, ptr %s0, { i64, ptr } %t3)
  %t6 = extractvalue { i32, { i64, ptr } } %t5, 1
  %t7 = extractvalue { i32, { i64, ptr } } %t5, 0
  store i32 %t7, ptr %l16
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb3, label %ok.9, !prof !99
ok.9:
  store { i64, ptr } %t6, ptr %l15
  br label %bb2
bb2:
  %t10 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t10, ptr %l13, !tbaa !27
  br label %bb11
bb3:
  %t11 = load i32, ptr %l16, !tbaa !23
  %t12 = ashr i32 %t11, 16
  %t14 = icmp eq i32 %t12, 1
  store i1 %t14, ptr %l18, !tbaa !21
  %t15 = load i32, ptr %l16, !tbaa !23
  %t16 = ashr i32 %t15, 16
  %t18 = icmp eq i32 %t16, 1
  br i1 %t18, label %bb4, label %bb5
bb4:
  call void @__olang_errpay_pop()
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t20 = icmp sge i64 0, 0
  br i1 %t20, label %bb7, label %bb8
bb7:
  %t22 = icmp sle i64 0, 576460752303423487
  br i1 %t22, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_46572e8a3ed1f877_752b2fa47e3744e3)
  unreachable
bb9:
  %t24 = mul i64 0, 16
  %t25 = insertvalue { i64, ptr } undef, i64 0, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t26, ptr %l13, !tbaa !27
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_46572e8a3ed1f877_752b2fa47e3744e3)
  unreachable
bb11:
  %t28 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t28, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  store i64 %t33, ptr %l7, !tbaa !24
  br label %bb12
bb12:
  %t35 = load i64, ptr %l6, !tbaa !24
  %t36 = load i64, ptr %l7, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb13, label %bb14
bb13:
  br label %bb18
bb14:
  br label %bb15
bb15:
  %t43 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t43, ptr %l31, !tbaa !27
  %t44 = load i64, ptr %l6, !tbaa !24
  %t46 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %t47, i64 %t44
  %t49 = load { i64, ptr }, ptr %t48, !tbaa !37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } %t49)
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t54 = load i64, ptr %l6, !tbaa !24
  %t57 = add i64 %t54, 1
  store i64 %t57, ptr %l6, !tbaa !24
  br label %bb12
bb18:
  %t59 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_336, 0
  %t60 = insertvalue { ptr, ptr } %t59, ptr null, 1
  %t63 = extractvalue { ptr, ptr } %t60, 0
  %t64 = extractvalue { ptr, ptr } %t60, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H1642129570dad448bb7dcc47c334de83(ptr %s0, ptr %s0, ptr %l3, ptr %t63, ptr %t64)
  br label %bb19
bb19:
  store ptr %l3, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s5
  %t66 = load i64, ptr %l10, !tbaa !24
  store i64 %t66, ptr %l42, !tbaa !24
  %t67 = load ptr, ptr %l9, !tbaa !29
  %t69 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t67)
  store i64 %t69, ptr %l44
  br label %bb21
bb21:
  %t70 = load i64, ptr %l42, !tbaa !24
  %t71 = load i64, ptr %l44, !tbaa !24
  %t72 = icmp slt i64 %t70, %t71
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s5)
  br label %bb53
bb23:
  br label %bb24
bb24:
  %t76 = load ptr, ptr %l9, !tbaa !29
  %t77 = load i64, ptr %l10, !tbaa !24
  %t80 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t76, i64 %t77)
  store { i64, ptr } %t80, ptr %l49
  br label %bb25
bb25:
  %t81 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t81, ptr %l11, !tbaa !27
  %t82 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d337, i32 0, i32 1) }, ptr %l52, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t86 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s0, ptr %s5, { i64, ptr } %t82, { i64, ptr } %t85)
  store i1 %t86, ptr %l53
  br label %bb26
bb26:
  %t87 = load i1, ptr %l53, !tbaa !21
  br i1 %t87, label %bb27, label %bb28
bb27:
  %t88 = load ptr, ptr %l2, !tbaa !29
  %t90 = getelementptr %"compiler/build:Listed", ptr %t88, i32 0, i32 1
  store ptr %t90, ptr %l55, !tbaa !29
  %t91 = call ptr @__olang_scope_hold(ptr %v1)
  %t92 = ptrtoint ptr %t91 to i64
  store i64 %t92, ptr %l56, !tbaa !24
  %t93 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t93, label %bb29, label %bb30
bb28:
  br label %bb32
bb29:
  %t95 = call ptr @__olang_region_make(ptr %v1)
  %t96 = ptrtoint ptr %t95 to i64
  store i64 %t96, ptr %l56, !tbaa !24
  br label %bb30
bb30:
  %t97 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t98 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t97, 1
  %t101 = extractvalue { i64, ptr } %t97, 0
  %t102 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d338, i32 0, i32 1) }, 1
  %t103 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d338, i32 0, i32 1) }, 0
  %t104 = add i64 %t101, %t103
  %t106 = extractvalue { i64, ptr } %t98, 1
  %t107 = extractvalue { i64, ptr } %t98, 0
  %t108 = add i64 %t104, %t107
  %t109 = load i64, ptr %l56
  %t110 = inttoptr i64 %t109 to ptr
  %t111 = call ptr @__olang_held_alloc(ptr %t110, i64 %t108)
  call void @olang_textcopy(ptr %t111, ptr %t100, i64 %t101)
  %t112 = getelementptr i8, ptr %t111, i64 %t101
  call void @olang_textcopy(ptr %t112, ptr %t102, i64 %t103)
  %t113 = getelementptr i8, ptr %t112, i64 %t103
  call void @olang_textcopy(ptr %t113, ptr %t106, i64 %t107)
  %t114 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t111, 1
  %t117 = load ptr, ptr %l55, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t117, { i64, ptr } %t115)
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t119 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t121 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s5, { i64, ptr } %t119, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d339, i32 0, i32 1) })
  store i1 %t121, ptr %l63
  br label %bb33
bb33:
  %t122 = load i1, ptr %l63, !tbaa !21
  br i1 %t122, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l64, !tbaa !21
  br label %bb37
bb35:
  %t123 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d340, i32 0, i32 1) }, ptr %l67, !tbaa !27
  %t126 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t127 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s0, ptr %s5, { i64, ptr } %t123, { i64, ptr } %t126)
  store i1 %t127, ptr %l68
  br label %bb36
bb36:
  %t128 = load i1, ptr %l68, !tbaa !21
  store i1 %t128, ptr %l64, !tbaa !21
  br label %bb37
bb37:
  %t129 = load i1, ptr %l64, !tbaa !21
  br i1 %t129, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l69, !tbaa !21
  br label %bb41
bb39:
  %t130 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t132 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s0, ptr %s5, { i64, ptr } %t130, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d341, i32 0, i32 1) })
  store i1 %t132, ptr %l71
  br label %bb40
bb40:
  %t133 = load i1, ptr %l71, !tbaa !21
  store i1 %t133, ptr %l69, !tbaa !21
  br label %bb41
bb41:
  %t134 = load i1, ptr %l69, !tbaa !21
  br i1 %t134, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s5)
  br label %bb52
bb43:
  br label %bb44
bb44:
  store i1 %a1, ptr %l72, !tbaa !21
  %t136 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t138 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s0, ptr %s5, { i64, ptr } %t136, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d342, i32 0, i32 1) })
  store i1 %t138, ptr %l74
  br label %bb45
bb45:
  %t139 = load i1, ptr %l72, !tbaa !21
  %t140 = load i1, ptr %l74, !tbaa !21
  %t141 = icmp eq i1 %t139, %t140
  br i1 %t141, label %bb46, label %bb47
bb46:
  %t143 = load ptr, ptr %l2, !tbaa !29
  %t145 = getelementptr %"compiler/build:Listed", ptr %t143, i32 0, i32 0
  store ptr %t145, ptr %l77, !tbaa !29
  %t146 = call ptr @__olang_scope_hold(ptr %v1)
  %t147 = ptrtoint ptr %t146 to i64
  store i64 %t147, ptr %l78, !tbaa !24
  %t148 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t148, label %bb48, label %bb49
bb47:
  br label %bb51
bb48:
  %t150 = call ptr @__olang_region_make(ptr %v1)
  %t151 = ptrtoint ptr %t150 to i64
  store i64 %t151, ptr %l78, !tbaa !24
  br label %bb49
bb49:
  %t152 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t153 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t152, 1
  %t156 = extractvalue { i64, ptr } %t152, 0
  %t157 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d343, i32 0, i32 1) }, 1
  %t158 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d343, i32 0, i32 1) }, 0
  %t159 = add i64 %t156, %t158
  %t161 = extractvalue { i64, ptr } %t153, 1
  %t162 = extractvalue { i64, ptr } %t153, 0
  %t163 = add i64 %t159, %t162
  %t164 = load i64, ptr %l78
  %t165 = inttoptr i64 %t164 to ptr
  %t166 = call ptr @__olang_held_alloc(ptr %t165, i64 %t163)
  call void @olang_textcopy(ptr %t166, ptr %t155, i64 %t156)
  %t167 = getelementptr i8, ptr %t166, i64 %t156
  call void @olang_textcopy(ptr %t167, ptr %t157, i64 %t158)
  %t168 = getelementptr i8, ptr %t167, i64 %t158
  call void @olang_textcopy(ptr %t168, ptr %t161, i64 %t162)
  %t169 = insertvalue { i64, ptr } undef, i64 %t163, 0
  %t170 = insertvalue { i64, ptr } %t169, ptr %t166, 1
  %t172 = load ptr, ptr %l77, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t172, { i64, ptr } %t170)
  br label %bb50
bb50:
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s5)
  br label %bb52
bb52:
  %t174 = load i64, ptr %l10, !tbaa !24
  %t177 = add i64 %t174, 1
  store i64 %t177, ptr %l10, !tbaa !24
  br label %bb20
bb53:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fbuild_2ememoryNow(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l5 = alloca i1
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s0, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d344, i32 0, i32 1) })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l3
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  store { i64, ptr } %t2, ptr %l2
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t6, ptr %l1, !tbaa !27
  br label %bb6
bb2:
  %t7 = load i32, ptr %l3, !tbaa !23
  %t8 = ashr i32 %t7, 16
  %t10 = icmp eq i32 %t8, 1
  store i1 %t10, ptr %l5, !tbaa !21
  %t11 = load i32, ptr %l3, !tbaa !23
  %t12 = ashr i32 %t11, 16
  %t14 = icmp eq i32 %t12, 1
  br i1 %t14, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  store { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d345, i32 0, i32 1) }, ptr %l8, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t16, ptr %l9, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 0
  store i64 %t18, ptr %l10, !tbaa !24
  %t19 = load i64, ptr %l10, !tbaa !24
  %t20 = mul i64 %t19, 1
  %t21 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t20)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l11, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = load i64, ptr %l10, !tbaa !24
  %t29 = mul i64 %t28, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t25, ptr %t27, i64 %t29, i1 false)
  %t30 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t30, ptr %l9, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t31 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t31, ptr %rv
  br label %ret
bb6:
  %t32 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t32, ptr %l0, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t35 = call i64 @compiler_2fbuild_2ekbOf(ptr %s0, ptr %s0, { i64, ptr } %t33, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d346, i32 0, i32 1) })
  store i64 %t35, ptr %l13
  br label %bb7
bb7:
  %t36 = load i64, ptr %l13, !tbaa !24
  %t37 = sdiv i64 %t36, 1024
  store i64 %t37, ptr %l14, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t40 = call i64 @compiler_2fbuild_2ekbOf(ptr %s0, ptr %s0, { i64, ptr } %t38, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d347, i32 0, i32 1) })
  store i64 %t40, ptr %l16
  br label %bb8
bb8:
  %t41 = load i64, ptr %l16, !tbaa !24
  %t42 = sdiv i64 %t41, 1024
  %t43 = load i64, ptr %l14, !tbaa !24
  %t44 = call i64 @__olang_fmt_i64(ptr null, i64 %t43)
  %t45 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d348, i32 0, i32 1) }, 1
  %t46 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d348, i32 0, i32 1) }, 0
  %t47 = add i64 %t44, %t46
  %t49 = call i64 @__olang_fmt_i64(ptr null, i64 %t42)
  %t50 = add i64 %t47, %t49
  %t51 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d349, i32 0, i32 1) }, 1
  %t52 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d349, i32 0, i32 1) }, 0
  %t53 = add i64 %t50, %t52
  %t54 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t53)
  %t55 = call i64 @__olang_fmt_i64(ptr %t54, i64 %t43)
  %t56 = getelementptr i8, ptr %t54, i64 %t44
  call void @olang_textcopy(ptr %t56, ptr %t45, i64 %t46)
  %t57 = getelementptr i8, ptr %t56, i64 %t46
  %t58 = call i64 @__olang_fmt_i64(ptr %t57, i64 %t42)
  %t59 = getelementptr i8, ptr %t57, i64 %t49
  call void @olang_textcopy(ptr %t59, ptr %t51, i64 %t52)
  %t60 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t54, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t61, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2enoTestNamed(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, ptr %a2) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l31 = alloca i64
  %l39 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l52 = alloca i64
  %l54 = alloca i64
  %l59 = alloca { i64, ptr }
  %l62 = alloca i64
  %l65 = alloca i1
  %l66 = alloca i1
  %l71 = alloca i64
  %l74 = alloca { i64, ptr }
  %l75 = alloca i64
  %l76 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l87 = alloca i1
  %l89 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l19
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l3
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t3, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l6, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l5, !tbaa !24
  %t10 = load i64, ptr %l6, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb10
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t17, ptr %l27, !tbaa !27
  %t18 = load i64, ptr %l5, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %t21, i64 %t18
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !37
  store { i64, ptr } %t23, ptr %l7, !tbaa !27
  store ptr %l3, ptr %l30, !tbaa !29
  %t25 = call ptr @__olang_scope_hold(ptr %s0)
  %t26 = ptrtoint ptr %t25 to i64
  store i64 %t26, ptr %l31, !tbaa !24
  %t27 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t27, label %bb6, label %bb7
bb6:
  %t29 = call ptr @__olang_region_make(ptr %s0)
  %t30 = ptrtoint ptr %t29 to i64
  store i64 %t30, ptr %l31, !tbaa !24
  br label %bb7
bb7:
  %t31 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t32 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d350, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d350, i32 0, i32 1) }, 0
  %t35 = extractvalue { i64, ptr } %t31, 1
  %t36 = extractvalue { i64, ptr } %t31, 0
  %t37 = add i64 %t33, %t36
  %t38 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d351, i32 0, i32 1) }, 1
  %t39 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d351, i32 0, i32 1) }, 0
  %t40 = add i64 %t37, %t39
  %t41 = load i64, ptr %l31
  %t42 = inttoptr i64 %t41 to ptr
  %t43 = call ptr @__olang_held_alloc(ptr %t42, i64 %t40)
  call void @olang_textcopy(ptr %t43, ptr %t32, i64 %t33)
  %t44 = getelementptr i8, ptr %t43, i64 %t33
  call void @olang_textcopy(ptr %t44, ptr %t35, i64 %t36)
  %t45 = getelementptr i8, ptr %t44, i64 %t36
  call void @olang_textcopy(ptr %t45, ptr %t38, i64 %t39)
  %t46 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t43, 1
  %t49 = load ptr, ptr %l30, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t49, { i64, ptr } %t47)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = add i64 %t51, 1
  store i64 %t54, ptr %l5, !tbaa !24
  br label %bb2
bb10:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d352, i32 0, i32 1) }, ptr %l39, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t56, ptr %l8, !tbaa !27
  store i64 1073741824, ptr %l9, !tbaa !24
  %t58 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t58, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t60 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t60, 0
  store i64 %t62, ptr %l12, !tbaa !24
  br label %bb11
bb11:
  %t64 = load i64, ptr %l11, !tbaa !24
  %t65 = load i64, ptr %l12, !tbaa !24
  %t68 = icmp slt i64 %t64, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb12, label %bb13
bb12:
  br label %bb38
bb13:
  br label %bb14
bb14:
  %t72 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t72, ptr %l48, !tbaa !27
  %t73 = load i64, ptr %l11, !tbaa !24
  %t75 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr { i64, ptr }, ptr %t76, i64 %t73
  %t78 = load { i64, ptr }, ptr %t77, !tbaa !37
  store { i64, ptr } %t78, ptr %l13, !tbaa !27
  store ptr %a2, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb15
bb15:
  %t82 = load i64, ptr %l15, !tbaa !24
  store i64 %t82, ptr %l52, !tbaa !24
  %t83 = load ptr, ptr %l14, !tbaa !29
  %t85 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v2, ptr %t83)
  store i64 %t85, ptr %l54
  br label %bb16
bb16:
  %t86 = load i64, ptr %l52, !tbaa !24
  %t87 = load i64, ptr %l54, !tbaa !24
  %t88 = icmp slt i64 %t86, %t87
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb17, label %bb18
bb17:
  br label %bb36
bb18:
  br label %bb19
bb19:
  %t92 = load ptr, ptr %l14, !tbaa !29
  %t93 = load i64, ptr %l15, !tbaa !24
  %t96 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v2, ptr %v2, ptr %t92, i64 %t93)
  store { i64, ptr } %t96, ptr %l59
  br label %bb20
bb20:
  %t97 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t97, ptr %l16, !tbaa !27
  %t98 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t99 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t102 = call i64 @compiler_2fbuild_2ecloseness(ptr %v1, ptr %v2, { i64, ptr } %t98, { i64, ptr } %t99)
  store i64 %t102, ptr %l62
  br label %bb21
bb21:
  %t103 = load i64, ptr %l62, !tbaa !24
  store i64 %t103, ptr %l17, !tbaa !24
  %t104 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t105 = load i64, ptr %l17, !tbaa !24
  %t108 = call i1 @compiler_2fmsgs_2eNear(ptr %v1, { i64, ptr } %t104, i64 %t105)
  store i1 %t108, ptr %l65
  br label %bb22
bb22:
  %t109 = load i1, ptr %l65, !tbaa !21
  br i1 %t109, label %bb23, label %bb24
bb23:
  %t110 = load i64, ptr %l17, !tbaa !24
  %t111 = load i64, ptr %l9, !tbaa !24
  %t114 = icmp slt i64 %t110, %t111
  store i1 %t114, ptr %l66, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb25
bb25:
  %t116 = load i1, ptr %l66, !tbaa !21
  br i1 %t116, label %bb26, label %bb27
bb26:
  %t117 = load i64, ptr %l17, !tbaa !24
  store i64 %t117, ptr %l9, !tbaa !24
  %t119 = call ptr @__olang_scope_hold(ptr %s0)
  %t120 = ptrtoint ptr %t119 to i64
  store i64 %t120, ptr %l71, !tbaa !24
  %t121 = load i1, ptr @olang_2esole_2ecompiler__2fbuild__2enoTestNamed_2elocal_2e8
  br i1 %t121, label %bb28, label %bb29
bb27:
  br label %bb34
bb28:
  %t123 = call ptr @__olang_region_make(ptr %s0)
  %t124 = ptrtoint ptr %t123 to i64
  store i64 %t124, ptr %l71, !tbaa !24
  br label %bb29
bb29:
  %t125 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t125, ptr %l74, !tbaa !27
  %t127 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t127, 0
  store i64 %t128, ptr %l75, !tbaa !24
  %t129 = load i64, ptr %l75, !tbaa !24
  %t130 = mul i64 %t129, 1
  %t131 = load i64, ptr %l71
  %t132 = inttoptr i64 %t131 to ptr
  %t133 = call ptr @__olang_held_alloc(ptr %t132, i64 %t130)
  %t134 = insertvalue { i64, ptr } undef, i64 %t129, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr %t133, 1
  store { i64, ptr } %t135, ptr %l76, !tbaa !27
  %t136 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !27
  %t138 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !27
  %t140 = load i64, ptr %l75, !tbaa !24
  %t141 = mul i64 %t140, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t137, ptr %t139, i64 %t141, i1 false)
  %t142 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t142, ptr %l77, !tbaa !27
  %t143 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t143, ptr %l8, !tbaa !27
  %t144 = load i1, ptr @olang_2esole_2ecompiler__2fbuild__2enoTestNamed_2elocal_2e8
  br i1 %t144, label %bb30, label %bb31
bb30:
  %t146 = load { i64, ptr }, ptr %l77
  %t147 = extractvalue { i64, ptr } %t146, 1
  call void @__olang_region_release(ptr %t147)
  store { i64, ptr } zeroinitializer, ptr %l77
  br label %bb31
bb31:
  %t148 = load i1, ptr @olang_2esole_2ecompiler__2fbuild__2enoTestNamed_2elocal_2e8
  br i1 %t148, label %bb32, label %bb33
bb32:
  %t150 = load i64, ptr %l71
  %t151 = inttoptr i64 %t150 to ptr
  %t152 = load { i64, ptr }, ptr %l8
  %t153 = extractvalue { i64, ptr } %t152, 1
  %t154 = call ptr @__olang_region_or(ptr %t153, ptr null)
  %t155 = icmp ne ptr %t154, null
  %t156 = select i1 %t155, ptr %t154, ptr null
  call void @__olang_region_settle_in(ptr %t151, ptr %t156)
  br label %bb33
bb33:
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t157 = load i64, ptr %l15, !tbaa !24
  %t160 = add i64 %t157, 1
  store i64 %t160, ptr %l15, !tbaa !24
  br label %bb15
bb36:
  br label %bb37
bb37:
  %t162 = load i64, ptr %l11, !tbaa !24
  %t165 = add i64 %t162, 1
  store i64 %t165, ptr %l11, !tbaa !24
  br label %bb11
bb38:
  %t167 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t169 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t167, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d353, i32 0, i32 1) })
  store i1 %t169, ptr %l87
  br label %bb39
bb39:
  %t170 = load i1, ptr %l87, !tbaa !21
  %t171 = xor i1 %t170, true
  br i1 %t171, label %bb40, label %bb41
bb40:
  %t173 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t174 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d354, i32 0, i32 1) }, 1
  %t175 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d354, i32 0, i32 1) }, 0
  %t177 = extractvalue { i64, ptr } %t173, 1
  %t178 = extractvalue { i64, ptr } %t173, 0
  %t179 = add i64 %t175, %t178
  %t180 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d355, i32 0, i32 1) }, 1
  %t181 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d355, i32 0, i32 1) }, 0
  %t182 = add i64 %t179, %t181
  %t183 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t182)
  call void @olang_textcopy(ptr %t183, ptr %t174, i64 %t175)
  %t184 = getelementptr i8, ptr %t183, i64 %t175
  call void @olang_textcopy(ptr %t184, ptr %t177, i64 %t178)
  %t185 = getelementptr i8, ptr %t184, i64 %t178
  call void @olang_textcopy(ptr %t185, ptr %t180, i64 %t181)
  %t186 = insertvalue { i64, ptr } undef, i64 %t182, 0
  %t187 = insertvalue { i64, ptr } %t186, ptr %t183, 1
  store { i64, ptr } %t187, ptr %l89, !tbaa !27
  br label %bb42
bb41:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d356, i32 0, i32 1) }, ptr %l89, !tbaa !27
  br label %bb42
bb42:
  %t190 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t190, ptr %l18, !tbaa !27
  store { i64, ptr } %a0, ptr %l93, !tbaa !27
  %t193 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s0, ptr %s0, ptr %s0, ptr %l3, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d357, i32 0, i32 1) })
  store { i64, ptr } %t193, ptr %l95
  br label %bb43
bb43:
  %t194 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t195 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t196 = extractvalue { i64, ptr } %t195, 1
  %t197 = extractvalue { i64, ptr } %t195, 0
  %t198 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d358, i32 0, i32 1) }, 1
  %t199 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d358, i32 0, i32 1) }, 0
  %t200 = add i64 %t197, %t199
  %t201 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t202 = extractvalue { i64, ptr } %t201, 1
  %t203 = extractvalue { i64, ptr } %t201, 0
  %t204 = add i64 %t200, %t203
  %t206 = extractvalue { i64, ptr } %t194, 1
  %t207 = extractvalue { i64, ptr } %t194, 0
  %t208 = add i64 %t204, %t207
  %t209 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t208)
  call void @olang_textcopy(ptr %t209, ptr %t196, i64 %t197)
  %t210 = getelementptr i8, ptr %t209, i64 %t197
  call void @olang_textcopy(ptr %t210, ptr %t198, i64 %t199)
  %t211 = getelementptr i8, ptr %t210, i64 %t199
  call void @olang_textcopy(ptr %t211, ptr %t202, i64 %t203)
  %t212 = getelementptr i8, ptr %t211, i64 %t203
  call void @olang_textcopy(ptr %t212, ptr %t206, i64 %t207)
  %t213 = insertvalue { i64, ptr } undef, i64 %t208, 0
  %t214 = insertvalue { i64, ptr } %t213, ptr %t209, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t214, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2eoutputOf(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i64
  %l34 = alloca { i64, ptr }
  %l37 = alloca i1
  %l38 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = sub i64 %t3, 1
  store i64 %t5, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load i64, ptr %l1, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load i64, ptr %l3, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l13, !tbaa !24
  br label %bb6
bb3:
  %t17 = load i64, ptr %l2, !tbaa !24
  %t18 = load i64, ptr %l1, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l16, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb5
bb5:
  %t33 = load i64, ptr %l16, !tbaa !24
  store i64 %t33, ptr %l13, !tbaa !24
  br label %bb6
bb6:
  %t34 = load i64, ptr %l13, !tbaa !24
  store i64 %t34, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i64, ptr %l5, !tbaa !24
  %t36 = load i64, ptr %l4, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb9:
  br label %bb10
bb10:
  %t43 = load i64, ptr %l1, !tbaa !24
  %t44 = load i64, ptr %l5, !tbaa !24
  %t45 = load i64, ptr %l3, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l6, !tbaa !24
  %t53 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t53, ptr %l34, !tbaa !27
  %t54 = load i64, ptr %l6, !tbaa !24
  %t56 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr { i64, ptr }, ptr %t57, i64 %t54
  %t59 = load { i64, ptr }, ptr %t58, !tbaa !37
  %t61 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t59, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d359, i32 0, i32 1) })
  store i1 %t61, ptr %l37
  br label %bb11
bb11:
  %t62 = load i1, ptr %l37, !tbaa !21
  br i1 %t62, label %bb12, label %bb13
bb12:
  %t63 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t63, ptr %l38, !tbaa !27
  %t64 = load i64, ptr %l6, !tbaa !24
  %t66 = add i64 %t64, 1
  %t68 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr { i64, ptr }, ptr %t69, i64 %t66
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !37
  call void @__olang_scope_close(ptr %s2)
  store { i64, ptr } %t71, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  %t73 = load i64, ptr %l5, !tbaa !24
  %t76 = add i64 %t73, 1
  store i64 %t76, ptr %l5, !tbaa !24
  br label %bb7
bb16:
  %t78 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t78, ptr %l45, !tbaa !27
  %t79 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t83 = sub i64 %t81, 1
  %t85 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = getelementptr { i64, ptr }, ptr %t86, i64 %t83
  %t88 = load { i64, ptr }, ptr %t87, !tbaa !37
  store { i64, ptr } %t88, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fbuild_2erestamp(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/os:FileInfo"
  %l4 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l12 = alloca i1
  %l15 = alloca %"std/os:FileInfo"
  %l17 = alloca %"std/os:FileInfo"
  %l18 = alloca i32
  %l20 = alloca i1
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l37 = alloca i32
  %l39 = alloca i1
  %s0 = alloca %olang.scope
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 1
  %t4 = extractvalue { i64, ptr } %t1, 0
  %t5 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d360, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d360, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  store { i64, ptr } %t11, ptr %l1, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t15 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s0, { i64, ptr } %t13)
  %t16 = extractvalue { i32, { i64, ptr } } %t15, 1
  %t17 = extractvalue { i32, { i64, ptr } } %t15, 0
  store i32 %t17, ptr %l10
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb2, label %ok.19, !prof !99
ok.19:
  store { i64, ptr } %t16, ptr %l9
  br label %bb1
bb1:
  %t20 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t20, ptr %l7, !tbaa !27
  br label %bb6
bb2:
  %t21 = load i32, ptr %l10, !tbaa !23
  %t22 = ashr i32 %t21, 16
  %t24 = icmp eq i32 %t22, 1
  store i1 %t24, ptr %l12, !tbaa !21
  %t25 = load i32, ptr %l10, !tbaa !23
  %t26 = ashr i32 %t25, 16
  %t28 = icmp eq i32 %t26, 1
  br i1 %t28, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  %t30 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t30, ptr %l2, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t33 = call { i32, %"std/os:FileInfo" } @std_2fos_2eFileInfo_2eStat(ptr %v0, { i64, ptr } %t31)
  %t34 = extractvalue { i32, %"std/os:FileInfo" } %t33, 1
  %t35 = extractvalue { i32, %"std/os:FileInfo" } %t33, 0
  store i32 %t35, ptr %l18
  %t36 = icmp ne i32 %t35, 0
  br i1 %t36, label %bb8, label %ok.37, !prof !99
ok.37:
  store %"std/os:FileInfo" %t34, ptr %l17
  br label %bb7
bb7:
  %t38 = load %"std/os:FileInfo", ptr %l17
  store %"std/os:FileInfo" %t38, ptr %l15
  br label %bb12
bb8:
  %t39 = load i32, ptr %l18, !tbaa !23
  %t40 = ashr i32 %t39, 16
  %t42 = icmp eq i32 %t40, 1
  store i1 %t42, ptr %l20, !tbaa !21
  %t43 = load i32, ptr %l18, !tbaa !23
  %t44 = ashr i32 %t43, 16
  %t46 = icmp eq i32 %t44, 1
  br i1 %t46, label %bb9, label %bb10
bb9:
  call void @__olang_errpay_pop()
  br label %bb10
bb10:
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb12:
  %t48 = load %"std/os:FileInfo", ptr %l15
  store %"std/os:FileInfo" %t48, ptr %l3
  %t49 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t51 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %s0, ptr %s0, { i64, ptr } %t49)
  store { i64, ptr } %t51, ptr %l24
  br label %bb13
bb13:
  %t52 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t53 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t52, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d361, i32 0, i32 1) })
  store { i64, ptr } %t53, ptr %l25
  br label %bb14
bb14:
  %t54 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t54, ptr %l4, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t55, 0
  %t59 = icmp ne i64 %t57, 3
  br i1 %t59, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb16:
  br label %bb17
bb17:
  %t61 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t62, ptr %l30, !tbaa !27
  %t63 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr { i64, ptr }, ptr %t64, i64 0
  %t66 = load { i64, ptr }, ptr %t65, !tbaa !37
  %t67 = getelementptr %"std/os:FileInfo", ptr %l3, i32 0, i32 1
  %t68 = load i64, ptr %t67, !tbaa !24
  %t69 = getelementptr %"std/os:FileInfo", ptr %l3, i32 0, i32 2
  %t70 = load i64, ptr %t69, !tbaa !24
  %t72 = extractvalue { i64, ptr } %t66, 1
  %t73 = extractvalue { i64, ptr } %t66, 0
  %t74 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d362, i32 0, i32 1) }, 1
  %t75 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d362, i32 0, i32 1) }, 0
  %t76 = add i64 %t73, %t75
  %t78 = call i64 @__olang_fmt_i64(ptr null, i64 %t68)
  %t79 = add i64 %t76, %t78
  %t80 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d362, i32 0, i32 1) }, 1
  %t81 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d362, i32 0, i32 1) }, 0
  %t82 = add i64 %t79, %t81
  %t84 = call i64 @__olang_fmt_i64(ptr null, i64 %t70)
  %t85 = add i64 %t82, %t84
  %t86 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d363, i32 0, i32 1) }, 1
  %t87 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d363, i32 0, i32 1) }, 0
  %t88 = add i64 %t85, %t87
  %t89 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t88)
  call void @olang_textcopy(ptr %t89, ptr %t72, i64 %t73)
  %t90 = getelementptr i8, ptr %t89, i64 %t73
  call void @olang_textcopy(ptr %t90, ptr %t74, i64 %t75)
  %t91 = getelementptr i8, ptr %t90, i64 %t75
  %t92 = call i64 @__olang_fmt_i64(ptr %t91, i64 %t68)
  %t93 = getelementptr i8, ptr %t91, i64 %t78
  call void @olang_textcopy(ptr %t93, ptr %t80, i64 %t81)
  %t94 = getelementptr i8, ptr %t93, i64 %t81
  %t95 = call i64 @__olang_fmt_i64(ptr %t94, i64 %t70)
  %t96 = getelementptr i8, ptr %t94, i64 %t84
  call void @olang_textcopy(ptr %t96, ptr %t86, i64 %t87)
  %t97 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t89, 1
  %t101 = extractvalue { i64, ptr } %t98, 0
  %t102 = extractvalue { i64, ptr } %t98, 1
  %t103 = mul i64 %t101, 1
  %t104 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t103)
  call void @llvm.memcpy.p0.p0.i64(ptr %t104, ptr %t102, i64 %t103, i1 false)
  %t105 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t104, 1
  %t109 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s0, { i64, ptr } %t61, { i64, ptr } %t106)
  store i32 %t109, ptr %l37
  %t110 = icmp ne i32 %t109, 0
  br i1 %t110, label %bb19, label %ok.111, !prof !99
ok.111:
  br label %bb18
bb18:
  br label %bb23
bb19:
  %t112 = load i32, ptr %l37, !tbaa !23
  %t113 = ashr i32 %t112, 16
  %t115 = icmp eq i32 %t113, 1
  store i1 %t115, ptr %l39, !tbaa !21
  %t116 = load i32, ptr %l37, !tbaa !23
  %t117 = ashr i32 %t116, 16
  %t119 = icmp eq i32 %t117, 1
  br i1 %t119, label %bb20, label %bb21
bb20:
  call void @__olang_errpay_pop()
  br label %bb21
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fbuild_2erotr(i32 %a0, i32 %a1) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i32
  %l3 = alloca i32
  %l7 = alloca i32
  %rv = alloca i32
  store i32 %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !tbaa !64
  %t2 = load i32, ptr %l1, !tbaa !64
  store i32 %t2, ptr %l3, !tbaa !64
  %t4 = load i32, ptr %l3, !tbaa !64
  %t5 = load i32, ptr %l3, !tbaa !64
  %t6 = lshr i32 %t1, %t5
  %t7 = load i32, ptr %l0, !tbaa !64
  %t8 = load i32, ptr %l1, !tbaa !64
  %t10 = sub i32 32, %t8
  store i32 %t10, ptr %l7, !tbaa !64
  %t12 = load i32, ptr %l7, !tbaa !64
  %t13 = load i32, ptr %l7, !tbaa !64
  %t14 = shl i32 %t7, %t13
  %t17 = or i32 %t6, %t14
  store i32 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fbuild_2erunner(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"std/os:Output"
  %l8 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  %l13 = alloca i1
  %l14 = alloca %"std/os:Output"
  %l15 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca %"std/os:Output"
  %l20 = alloca i32
  %l22 = alloca i1
  %l25 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l31 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca i64
  %l48 = alloca i1
  %l51 = alloca i64
  %l53 = alloca i64
  %l54 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l4, !tbaa !29
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t3 = load ptr, ptr %l4, !tbaa !29
  %t5 = call { i32, i64 } @std_2fchan_2estd_2fchan_3aChan_3cI64_3e_2eNext_3cI64_3e(ptr %v0, ptr %t3)
  %t6 = extractvalue { i32, i64 } %t5, 1
  %t7 = extractvalue { i32, i64 } %t5, 0
  store i32 %t7, ptr %l11
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb3, label %ok.9, !prof !99
ok.9:
  store i64 %t6, ptr %l10
  br label %bb2
bb2:
  %t10 = load i64, ptr %l10, !tbaa !24
  store i64 %t10, ptr %l8, !tbaa !24
  br label %bb5
bb3:
  %t11 = load i32, ptr %l11, !tbaa !23
  %t12 = ashr i32 %t11, 16
  %t14 = icmp eq i32 %t12, 1
  store i1 %t14, ptr %l13, !tbaa !21
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb24
bb5:
  %t15 = load i64, ptr %l8, !tbaa !24
  store i64 %t15, ptr %l5, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t16, ptr %l15, !tbaa !27
  %t17 = load i64, ptr %l5, !tbaa !24
  %t19 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr { i64, ptr }, ptr %t20, i64 %t17
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !37
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %l18, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t25 = call { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExec(ptr %v1, ptr %s2, ptr %s2, ptr %s2, { i64, ptr } %t22, { i64, ptr } %t24, i1 true, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d39, i32 0, i32 1) })
  %t26 = extractvalue { i32, %"std/os:Output" } %t25, 1
  %t27 = extractvalue { i32, %"std/os:Output" } %t25, 0
  store i32 %t27, ptr %l20
  %t28 = icmp ne i32 %t27, 0
  br i1 %t28, label %bb7, label %ok.29, !prof !99
ok.29:
  store %"std/os:Output" %t26, ptr %l19
  br label %bb6
bb6:
  %t30 = load %"std/os:Output", ptr %l19
  store %"std/os:Output" %t30, ptr %l14
  br label %bb13
bb7:
  %t31 = load i32, ptr %l20, !tbaa !23
  %t32 = ashr i32 %t31, 16
  %t34 = icmp eq i32 %t32, 1
  store i1 %t34, ptr %l22, !tbaa !21
  %t35 = load i32, ptr %l20, !tbaa !23
  %t36 = ashr i32 %t35, 16
  %t38 = icmp eq i32 %t36, 1
  br i1 %t38, label %bb8, label %bb9
bb8:
  call void @__olang_errpay_pop()
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t40 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t40, ptr %l25, !tbaa !27
  %t41 = load i64, ptr %l5, !tbaa !24
  %t43 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr i32, ptr %t44, i64 %t41
  store i32 127, ptr %t45, !tbaa !33
  %t46 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t46, ptr %l27, !tbaa !27
  %t47 = load i64, ptr %l5, !tbaa !24
  store i64 %t47, ptr %l28, !tbaa !24
  %t48 = call ptr @__olang_scope_hold(ptr %v3)
  %t49 = ptrtoint ptr %t48 to i64
  store i64 %t49, ptr %l29, !tbaa !24
  %t50 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t50, label %bb11, label %bb12
bb11:
  %t52 = call ptr @__olang_region_make(ptr %v3)
  %t53 = ptrtoint ptr %t52 to i64
  store i64 %t53, ptr %l29, !tbaa !24
  br label %bb12
bb12:
  %t54 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t54, ptr %l31, !tbaa !27
  %t55 = load i64, ptr %l5, !tbaa !24
  %t57 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr { i64, ptr }, ptr %t58, i64 %t55
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !37
  store { i64, ptr } %t60, ptr %l33, !tbaa !27
  %t61 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr { i64, ptr }, ptr %t62, i64 0
  %t64 = load { i64, ptr }, ptr %t63, !tbaa !37
  %t65 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d364, i32 0, i32 1) }, 1
  %t66 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d364, i32 0, i32 1) }, 0
  %t68 = extractvalue { i64, ptr } %t64, 1
  %t69 = extractvalue { i64, ptr } %t64, 0
  %t70 = add i64 %t66, %t69
  %t71 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d365, i32 0, i32 1) }, 1
  %t72 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d365, i32 0, i32 1) }, 0
  %t73 = add i64 %t70, %t72
  %t74 = load i64, ptr %l29
  %t75 = inttoptr i64 %t74 to ptr
  %t76 = call ptr @__olang_held_alloc(ptr %t75, i64 %t73)
  call void @olang_textcopy(ptr %t76, ptr %t65, i64 %t66)
  %t77 = getelementptr i8, ptr %t76, i64 %t66
  call void @olang_textcopy(ptr %t77, ptr %t68, i64 %t69)
  %t78 = getelementptr i8, ptr %t77, i64 %t69
  call void @olang_textcopy(ptr %t78, ptr %t71, i64 %t72)
  %t79 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t76, 1
  %t83 = load i64, ptr %l28, !tbaa !24
  %t84 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = getelementptr { i64, ptr }, ptr %t85, i64 %t83
  store { i64, ptr } %t80, ptr %t86, !tbaa !37
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb13:
  %t87 = load %"std/os:Output", ptr %l14
  store %"std/os:Output" %t87, ptr %l6
  %t88 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t88, ptr %l37, !tbaa !27
  %t89 = load i64, ptr %l5, !tbaa !24
  %t90 = getelementptr %"std/os:Output", ptr %l6, i32 0, i32 0
  %t91 = load i32, ptr %t90, !tbaa !23
  %t94 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr i32, ptr %t95, i64 %t89
  store i32 %t91, ptr %t96, !tbaa !33
  %t97 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t97, ptr %l40, !tbaa !27
  %t98 = load i64, ptr %l5, !tbaa !24
  store i64 %t98, ptr %l41, !tbaa !24
  %t99 = call ptr @__olang_scope_hold(ptr %v3)
  %t100 = ptrtoint ptr %t99 to i64
  store i64 %t100, ptr %l42, !tbaa !24
  %t101 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t101, label %bb14, label %bb15
bb14:
  %t103 = call ptr @__olang_region_make(ptr %v3)
  %t104 = ptrtoint ptr %t103 to i64
  store i64 %t104, ptr %l42, !tbaa !24
  br label %bb15
bb15:
  %t105 = getelementptr %"std/os:Output", ptr %l6, i32 0, i32 1
  %t106 = load { i64, ptr }, ptr %t105, !tbaa !27
  %t107 = getelementptr %"std/os:Output", ptr %l6, i32 0, i32 2
  %t108 = load { i64, ptr }, ptr %t107, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t106, 1
  %t111 = extractvalue { i64, ptr } %t106, 0
  %t113 = extractvalue { i64, ptr } %t108, 1
  %t114 = extractvalue { i64, ptr } %t108, 0
  %t115 = add i64 %t111, %t114
  %t116 = load i64, ptr %l42
  %t117 = inttoptr i64 %t116 to ptr
  %t118 = call ptr @__olang_held_alloc(ptr %t117, i64 %t115)
  call void @olang_textcopy(ptr %t118, ptr %t110, i64 %t111)
  %t119 = getelementptr i8, ptr %t118, i64 %t111
  call void @olang_textcopy(ptr %t119, ptr %t113, i64 %t114)
  %t120 = insertvalue { i64, ptr } undef, i64 %t115, 0
  %t121 = insertvalue { i64, ptr } %t120, ptr %t118, 1
  %t124 = load i64, ptr %l41, !tbaa !24
  %t125 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = getelementptr { i64, ptr }, ptr %t126, i64 %t124
  store { i64, ptr } %t121, ptr %t127, !tbaa !37
  %t128 = call i1 @compiler_2fbuild_2etimed()
  store i1 %t128, ptr %l48
  br label %bb16
bb16:
  %t129 = load i1, ptr %l48, !tbaa !21
  br i1 %t129, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s6
  %t131 = atomicrmw add ptr @G_2ecompiler_2fbuild_2eRan, i64 1 seq_cst
  %t133 = add i64 %t131, 1
  store i64 %t133, ptr %l51, !tbaa !24
  %t134 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t134, 0
  store i64 %t136, ptr %l53, !tbaa !24
  %t137 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t137, ptr %l54, !tbaa !27
  %t138 = load i64, ptr %l5, !tbaa !24
  %t140 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !27
  %t142 = getelementptr { i64, ptr }, ptr %t141, i64 %t138
  %t143 = load { i64, ptr }, ptr %t142, !tbaa !37
  %t145 = call { i64, ptr } @compiler_2fbuild_2eoutputOf(ptr %v1, ptr %v1, { i64, ptr } %t143)
  store { i64, ptr } %t145, ptr %l57
  br label %bb19
bb18:
  br label %bb22
bb19:
  %t146 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t147 = call { i64, ptr } @std_2ffilepath_2eBase(ptr %v1, ptr %s6, { i64, ptr } %t146)
  store { i64, ptr } %t147, ptr %l58
  br label %bb20
bb20:
  %t148 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d366, i32 0, i32 1) }, 1
  %t149 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d366, i32 0, i32 1) }, 0
  %t150 = load i64, ptr %l51, !tbaa !24
  %t151 = call i64 @__olang_fmt_i64(ptr null, i64 %t150)
  %t152 = add i64 %t149, %t151
  %t153 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d367, i32 0, i32 1) }, 1
  %t154 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d367, i32 0, i32 1) }, 0
  %t155 = add i64 %t152, %t154
  %t156 = load i64, ptr %l53, !tbaa !24
  %t157 = call i64 @__olang_fmt_i64(ptr null, i64 %t156)
  %t158 = add i64 %t155, %t157
  %t159 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d368, i32 0, i32 1) }, 1
  %t160 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d368, i32 0, i32 1) }, 0
  %t161 = add i64 %t158, %t160
  %t162 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t163 = extractvalue { i64, ptr } %t162, 1
  %t164 = extractvalue { i64, ptr } %t162, 0
  %t165 = add i64 %t161, %t164
  %t166 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d369, i32 0, i32 1) }, 1
  %t167 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d369, i32 0, i32 1) }, 0
  %t168 = add i64 %t165, %t167
  %t169 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t168)
  call void @olang_textcopy(ptr %t169, ptr %t148, i64 %t149)
  %t170 = getelementptr i8, ptr %t169, i64 %t149
  %t171 = call i64 @__olang_fmt_i64(ptr %t170, i64 %t150)
  %t172 = getelementptr i8, ptr %t170, i64 %t151
  call void @olang_textcopy(ptr %t172, ptr %t153, i64 %t154)
  %t173 = getelementptr i8, ptr %t172, i64 %t154
  %t174 = call i64 @__olang_fmt_i64(ptr %t173, i64 %t156)
  %t175 = getelementptr i8, ptr %t173, i64 %t157
  call void @olang_textcopy(ptr %t175, ptr %t159, i64 %t160)
  %t176 = getelementptr i8, ptr %t175, i64 %t160
  call void @olang_textcopy(ptr %t176, ptr %t163, i64 %t164)
  %t177 = getelementptr i8, ptr %t176, i64 %t164
  call void @olang_textcopy(ptr %t177, ptr %t166, i64 %t167)
  %t178 = insertvalue { i64, ptr } undef, i64 %t168, 0
  %t179 = insertvalue { i64, ptr } %t178, ptr %t169, 1
  call void @compiler_2fbuild_2esayErr(ptr %s6, { i64, ptr } %t179)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s6)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb23:
  br label %bb1
bb24:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fbuild_2etreeBytes(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"std/os:FileInfo"
  %l8 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i32
  %l13 = alloca i1
  %l26 = alloca { i64, ptr }
  %l29 = alloca %"std/os:FileInfo"
  %l34 = alloca %"std/os:FileInfo"
  %l35 = alloca i32
  %l37 = alloca i1
  %l40 = alloca i64
  %l43 = alloca i64
  %l48 = alloca i64
  %l50 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v0, ptr %s0, { i64, ptr } %t1)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l11
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store { i64, ptr } %t4, ptr %l10
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t8, ptr %l8, !tbaa !27
  br label %bb10
bb2:
  %t9 = load i32, ptr %l11, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  store i1 %t12, ptr %l13, !tbaa !21
  %t13 = load i32, ptr %l11, !tbaa !23
  %t14 = ashr i32 %t13, 16
  %t16 = icmp eq i32 %t14, 1
  br i1 %t16, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  %t18 = icmp sge i64 0, 0
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = icmp sle i64 0, 576460752303423487
  br i1 %t20, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_ce9989f7be3b1aff_770cc8c701cb1c1b)
  unreachable
bb8:
  %t22 = mul i64 0, 16
  %t23 = insertvalue { i64, ptr } undef, i64 0, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t24, ptr %l8, !tbaa !27
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_ce9989f7be3b1aff_770cc8c701cb1c1b)
  unreachable
bb10:
  %t26 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t26, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t29 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t29, 0
  store i64 %t31, ptr %l5, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load i64, ptr %l4, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb13:
  br label %bb14
bb14:
  %t41 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t41, ptr %l26, !tbaa !27
  %t42 = load i64, ptr %l4, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %t45, i64 %t42
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !37
  store { i64, ptr } %t47, ptr %l6, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t49, 1
  %t53 = extractvalue { i64, ptr } %t49, 0
  %t54 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d370, i32 0, i32 1) }, 1
  %t55 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d370, i32 0, i32 1) }, 0
  %t56 = add i64 %t53, %t55
  %t58 = extractvalue { i64, ptr } %t50, 1
  %t59 = extractvalue { i64, ptr } %t50, 0
  %t60 = add i64 %t56, %t59
  %t61 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t60)
  call void @olang_textcopy(ptr %t61, ptr %t52, i64 %t53)
  %t62 = getelementptr i8, ptr %t61, i64 %t53
  call void @olang_textcopy(ptr %t62, ptr %t54, i64 %t55)
  %t63 = getelementptr i8, ptr %t62, i64 %t55
  call void @olang_textcopy(ptr %t63, ptr %t58, i64 %t59)
  %t64 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t61, 1
  %t68 = call { i32, %"std/os:FileInfo" } @std_2fos_2eFileInfo_2eStat(ptr %s2, { i64, ptr } %t65)
  %t69 = extractvalue { i32, %"std/os:FileInfo" } %t68, 1
  %t70 = extractvalue { i32, %"std/os:FileInfo" } %t68, 0
  store i32 %t70, ptr %l35
  %t71 = icmp ne i32 %t70, 0
  br i1 %t71, label %bb16, label %ok.72, !prof !99
ok.72:
  store %"std/os:FileInfo" %t69, ptr %l34
  br label %bb15
bb15:
  %t73 = load %"std/os:FileInfo", ptr %l34
  store %"std/os:FileInfo" %t73, ptr %l29
  br label %bb20
bb16:
  %t74 = load i32, ptr %l35, !tbaa !23
  %t75 = ashr i32 %t74, 16
  %t77 = icmp eq i32 %t75, 1
  store i1 %t77, ptr %l37, !tbaa !21
  %t78 = load i32, ptr %l35, !tbaa !23
  %t79 = ashr i32 %t78, 16
  %t81 = icmp eq i32 %t79, 1
  br i1 %t81, label %bb17, label %bb18
bb17:
  call void @__olang_errpay_pop()
  br label %bb18
bb18:
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb26
bb20:
  %t83 = load %"std/os:FileInfo", ptr %l29
  store %"std/os:FileInfo" %t83, ptr %l7
  %t84 = load i64, ptr %l1, !tbaa !24
  store i64 %t84, ptr %l40, !tbaa !24
  %t85 = getelementptr %"std/os:FileInfo", ptr %l7, i32 0, i32 0
  %t86 = load i32, ptr %t85, !range !{i32 0, i32 3}
  %t88 = trunc i64 1 to i32
  %t89 = icmp eq i32 %t86, %t88
  br i1 %t89, label %bb21, label %bb22
bb21:
  %t91 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t92 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t91, 1
  %t95 = extractvalue { i64, ptr } %t91, 0
  %t96 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d371, i32 0, i32 1) }, 1
  %t97 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d371, i32 0, i32 1) }, 0
  %t98 = add i64 %t95, %t97
  %t100 = extractvalue { i64, ptr } %t92, 1
  %t101 = extractvalue { i64, ptr } %t92, 0
  %t102 = add i64 %t98, %t101
  %t103 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t102)
  call void @olang_textcopy(ptr %t103, ptr %t94, i64 %t95)
  %t104 = getelementptr i8, ptr %t103, i64 %t95
  call void @olang_textcopy(ptr %t104, ptr %t96, i64 %t97)
  %t105 = getelementptr i8, ptr %t104, i64 %t97
  call void @olang_textcopy(ptr %t105, ptr %t100, i64 %t101)
  %t106 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t103, 1
  %t110 = call i64 @compiler_2fbuild_2etreeBytes(ptr %s2, { i64, ptr } %t107)
  store i64 %t110, ptr %l48
  br label %bb23
bb22:
  %t111 = getelementptr %"std/os:FileInfo", ptr %l7, i32 0, i32 1
  %t112 = load i64, ptr %t111, !tbaa !24
  %t114 = call i64 @compiler_2fbuild_2eonDisk(i64 %t112)
  store i64 %t114, ptr %l50
  br label %bb24
bb23:
  %t115 = load i64, ptr %l48, !tbaa !24
  store i64 %t115, ptr %l43, !tbaa !24
  br label %bb25
bb24:
  %t116 = load i64, ptr %l50, !tbaa !24
  store i64 %t116, ptr %l43, !tbaa !24
  br label %bb25
bb25:
  %t117 = load i64, ptr %l40, !tbaa !24
  %t118 = load i64, ptr %l43, !tbaa !24
  %t119 = add i64 %t117, %t118
  store i64 %t119, ptr %l1, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb26
bb26:
  %t121 = load i64, ptr %l4, !tbaa !24
  %t124 = add i64 %t121, 1
  store i64 %t124, ptr %l4, !tbaa !24
  br label %bb11
bb27:
  %t126 = load i64, ptr %l1, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t126, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/build:Held" @compiler_2fbuild_3aHeld_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i64 %a2, i64 %a3) #0 {
entry:
  %rv = alloca %"compiler/build:Held"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/build:Held" undef, { i64, ptr } %a0, 0
  %t12 = insertvalue %"compiler/build:Held" %t10, { i64, ptr } %a1, 1
  %t14 = insertvalue %"compiler/build:Held" %t12, i64 %a2, 2
  %t16 = insertvalue %"compiler/build:Held" %t14, i64 %a3, 3
  store %"compiler/build:Held" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/build:Held", ptr %rv
  ret %"compiler/build:Held" %rr
}

define dso_local void @compiler_2fbuild_3aProgram_2ector(ptr %out, ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca i64
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca i64
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca i64
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca i64
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca i64
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l29 = alloca i64
  %l31 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca %"compiler/build:Program"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l12
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l0
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d372, i32 0, i32 1) }, ptr %l1, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d373, i32 0, i32 1) }, ptr %l2, !tbaa !27
  %t3 = call ptr @__olang_scope_hold(ptr %v0)
  %t4 = ptrtoint ptr %t3 to i64
  store i64 %t4, ptr %l13, !tbaa !24
  %t5 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3aProgram_2e3
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t7 = call ptr @__olang_region_make(ptr %v0)
  %t8 = ptrtoint ptr %t7 to i64
  store i64 %t8, ptr %l13, !tbaa !24
  br label %bb3
bb3:
  %t9 = load i64, ptr %l13
  %t10 = inttoptr i64 %t9 to ptr
  %t11 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t10, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %l15
  br label %bb4
bb4:
  %t12 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3aProgram_2e3
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load i64, ptr %l13
  %t15 = inttoptr i64 %t14 to ptr
  %t16 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15, i32 0, i32 0
  %t17 = load { i64, ptr }, ptr %t16
  %t18 = extractvalue { i64, ptr } %t17, 1
  %t19 = call ptr @__olang_region_or(ptr %t18, ptr null)
  %t20 = call ptr @__olang_region_home(ptr %t19)
  %t21 = icmp ne ptr %t20, null
  %t22 = select i1 %t21, ptr %t20, ptr null
  call void @__olang_region_settle_in(ptr %t15, ptr %t22)
  br label %bb6
bb6:
  %t23 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %l3
  %t24 = call ptr @__olang_scope_hold(ptr %v0)
  %t25 = ptrtoint ptr %t24 to i64
  store i64 %t25, ptr %l17, !tbaa !24
  %t26 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3aProgram_2e4
  br i1 %t26, label %bb7, label %bb8
bb7:
  %t28 = call ptr @__olang_region_make(ptr %v0)
  %t29 = ptrtoint ptr %t28 to i64
  store i64 %t29, ptr %l17, !tbaa !24
  br label %bb8
bb8:
  %t30 = load i64, ptr %l17
  %t31 = inttoptr i64 %t30 to ptr
  %t32 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t31, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t32, ptr %l19
  br label %bb9
bb9:
  %t33 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3aProgram_2e4
  br i1 %t33, label %bb10, label %bb11
bb10:
  %t35 = load i64, ptr %l17
  %t36 = inttoptr i64 %t35 to ptr
  %t37 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19, i32 0, i32 0
  %t38 = load { i64, ptr }, ptr %t37
  %t39 = extractvalue { i64, ptr } %t38, 1
  %t40 = call ptr @__olang_region_or(ptr %t39, ptr null)
  %t41 = call ptr @__olang_region_home(ptr %t40)
  %t42 = icmp ne ptr %t41, null
  %t43 = select i1 %t42, ptr %t41, ptr null
  call void @__olang_region_settle_in(ptr %t36, ptr %t43)
  br label %bb11
bb11:
  %t44 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t44, ptr %l4
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d374, i32 0, i32 1) }, ptr %l5, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d375, i32 0, i32 1) }, ptr %l6, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d376, i32 0, i32 1) }, ptr %l7, !tbaa !27
  %t45 = call ptr @__olang_scope_hold(ptr %v0)
  %t46 = ptrtoint ptr %t45 to i64
  store i64 %t46, ptr %l21, !tbaa !24
  %t47 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3aProgram_2e8
  br i1 %t47, label %bb12, label %bb13
bb12:
  %t49 = call ptr @__olang_region_make(ptr %v0)
  %t50 = ptrtoint ptr %t49 to i64
  store i64 %t50, ptr %l21, !tbaa !24
  br label %bb13
bb13:
  %t51 = load i64, ptr %l21
  %t52 = inttoptr i64 %t51 to ptr
  %t53 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t52, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t53, ptr %l23
  br label %bb14
bb14:
  %t54 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3aProgram_2e8
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t56 = load i64, ptr %l21
  %t57 = inttoptr i64 %t56 to ptr
  %t58 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23, i32 0, i32 0
  %t59 = load { i64, ptr }, ptr %t58
  %t60 = extractvalue { i64, ptr } %t59, 1
  %t61 = call ptr @__olang_region_or(ptr %t60, ptr null)
  %t62 = call ptr @__olang_region_home(ptr %t61)
  %t63 = icmp ne ptr %t62, null
  %t64 = select i1 %t63, ptr %t62, ptr null
  call void @__olang_region_settle_in(ptr %t57, ptr %t64)
  br label %bb16
bb16:
  %t65 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t65, ptr %l8
  %t66 = call ptr @__olang_scope_hold(ptr %v0)
  %t67 = ptrtoint ptr %t66 to i64
  store i64 %t67, ptr %l25, !tbaa !24
  %t68 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3aProgram_2e9
  br i1 %t68, label %bb17, label %bb18
bb17:
  %t70 = call ptr @__olang_region_make(ptr %v0)
  %t71 = ptrtoint ptr %t70 to i64
  store i64 %t71, ptr %l25, !tbaa !24
  br label %bb18
bb18:
  %t72 = load i64, ptr %l25
  %t73 = inttoptr i64 %t72 to ptr
  %t74 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t73, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t74, ptr %l27
  br label %bb19
bb19:
  %t75 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3aProgram_2e9
  br i1 %t75, label %bb20, label %bb21
bb20:
  %t77 = load i64, ptr %l25
  %t78 = inttoptr i64 %t77 to ptr
  %t79 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27, i32 0, i32 0
  %t80 = load { i64, ptr }, ptr %t79
  %t81 = extractvalue { i64, ptr } %t80, 1
  %t82 = call ptr @__olang_region_or(ptr %t81, ptr null)
  %t83 = call ptr @__olang_region_home(ptr %t82)
  %t84 = icmp ne ptr %t83, null
  %t85 = select i1 %t84, ptr %t83, ptr null
  call void @__olang_region_settle_in(ptr %t78, ptr %t85)
  br label %bb21
bb21:
  %t86 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t86, ptr %l9
  store i64 0, ptr %l10, !tbaa !24
  %t87 = call ptr @__olang_scope_hold(ptr %v0)
  %t88 = ptrtoint ptr %t87 to i64
  store i64 %t88, ptr %l29, !tbaa !24
  %t89 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3aProgram_2e11
  br i1 %t89, label %bb22, label %bb23
bb22:
  %t91 = call ptr @__olang_region_make(ptr %v0)
  %t92 = ptrtoint ptr %t91 to i64
  store i64 %t92, ptr %l29, !tbaa !24
  br label %bb23
bb23:
  %t93 = load i64, ptr %l29
  %t94 = inttoptr i64 %t93 to ptr
  %t95 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aCode_3e_2ector(ptr %t94, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t95, ptr %l31
  br label %bb24
bb24:
  %t96 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3aProgram_2e11
  br i1 %t96, label %bb25, label %bb26
bb25:
  %t98 = load i64, ptr %l29
  %t99 = inttoptr i64 %t98 to ptr
  %t100 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l31, i32 0, i32 0
  %t101 = load { i64, ptr }, ptr %t100
  %t102 = extractvalue { i64, ptr } %t101, 1
  %t103 = call ptr @__olang_region_or(ptr %t102, ptr null)
  %t104 = call ptr @__olang_region_home(ptr %t103)
  %t105 = icmp ne ptr %t104, null
  %t106 = select i1 %t105, ptr %t104, ptr null
  call void @__olang_region_settle_in(ptr %t99, ptr %t106)
  br label %bb26
bb26:
  %t107 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l31
  %t108 = getelementptr %"compiler/build:Program", ptr %l33, i32 0, i32 0
  %t109 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t109, ptr %t108
  %t110 = getelementptr %"compiler/build:Program", ptr %l33, i32 0, i32 1
  %t111 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t111, ptr %t110, !tbaa !27
  %t112 = getelementptr %"compiler/build:Program", ptr %l33, i32 0, i32 2
  %t113 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t113, ptr %t112, !tbaa !27
  %t114 = getelementptr %"compiler/build:Program", ptr %l33, i32 0, i32 3
  %t115 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t115, ptr %t114
  %t116 = getelementptr %"compiler/build:Program", ptr %l33, i32 0, i32 4
  %t117 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t117, ptr %t116
  %t118 = getelementptr %"compiler/build:Program", ptr %l33, i32 0, i32 5
  %t119 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t119, ptr %t118, !tbaa !27
  %t120 = getelementptr %"compiler/build:Program", ptr %l33, i32 0, i32 6
  %t121 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t121, ptr %t120, !tbaa !27
  %t122 = getelementptr %"compiler/build:Program", ptr %l33, i32 0, i32 7
  %t123 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t123, ptr %t122, !tbaa !27
  %t124 = getelementptr %"compiler/build:Program", ptr %l33, i32 0, i32 8
  %t125 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t125, ptr %t124
  %t126 = getelementptr %"compiler/build:Program", ptr %l33, i32 0, i32 9
  %t127 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t127, ptr %t126
  %t128 = getelementptr %"compiler/build:Program", ptr %l33, i32 0, i32 10
  %t129 = load i64, ptr %l10, !tbaa !24
  store i64 %t129, ptr %t128, !tbaa !24
  %t130 = getelementptr %"compiler/build:Program", ptr %l33, i32 0, i32 11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t107, ptr %t130
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l33, i64 280, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fbuild_3acompiles_2ector(ptr %out, ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca i64
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca i64
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca i64
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca i64
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca i64
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l29 = alloca i64
  %l31 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca i64
  %l35 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l37 = alloca i64
  %l39 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l41 = alloca i64
  %l43 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l45 = alloca %"compiler/build:compiles"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call ptr @__olang_scope_hold(ptr %v0)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l9, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3acompiles_2e0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v0)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l9, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i64, ptr %l9
  %t8 = inttoptr i64 %t7 to ptr
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %t8, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l11
  br label %bb3
bb3:
  %t10 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3acompiles_2e0
  br i1 %t10, label %bb4, label %bb5
bb4:
  %t12 = load i64, ptr %l9
  %t13 = inttoptr i64 %t12 to ptr
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14
  %t16 = extractvalue { i64, ptr } %t15, 1
  %t17 = call ptr @__olang_region_or(ptr %t16, ptr null)
  %t18 = call ptr @__olang_region_home(ptr %t17)
  %t19 = icmp ne ptr %t18, null
  %t20 = select i1 %t19, ptr %t18, ptr null
  call void @__olang_region_settle_in(ptr %t13, ptr %t20)
  br label %bb5
bb5:
  %t21 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l0
  %t22 = call ptr @__olang_scope_hold(ptr %v0)
  %t23 = ptrtoint ptr %t22 to i64
  store i64 %t23, ptr %l13, !tbaa !24
  %t24 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3acompiles_2e1
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = call ptr @__olang_region_make(ptr %v0)
  %t27 = ptrtoint ptr %t26 to i64
  store i64 %t27, ptr %l13, !tbaa !24
  br label %bb7
bb7:
  %t28 = load i64, ptr %l13
  %t29 = inttoptr i64 %t28 to ptr
  %t30 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t29, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t30, ptr %l15
  br label %bb8
bb8:
  %t31 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3acompiles_2e1
  br i1 %t31, label %bb9, label %bb10
bb9:
  %t33 = load i64, ptr %l13
  %t34 = inttoptr i64 %t33 to ptr
  %t35 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15, i32 0, i32 0
  %t36 = load { i64, ptr }, ptr %t35
  %t37 = extractvalue { i64, ptr } %t36, 1
  %t38 = call ptr @__olang_region_or(ptr %t37, ptr null)
  %t39 = call ptr @__olang_region_home(ptr %t38)
  %t40 = icmp ne ptr %t39, null
  %t41 = select i1 %t40, ptr %t39, ptr null
  call void @__olang_region_settle_in(ptr %t34, ptr %t41)
  br label %bb10
bb10:
  %t42 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t42, ptr %l1
  %t43 = call ptr @__olang_scope_hold(ptr %v0)
  %t44 = ptrtoint ptr %t43 to i64
  store i64 %t44, ptr %l17, !tbaa !24
  %t45 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3acompiles_2e2
  br i1 %t45, label %bb11, label %bb12
bb11:
  %t47 = call ptr @__olang_region_make(ptr %v0)
  %t48 = ptrtoint ptr %t47 to i64
  store i64 %t48, ptr %l17, !tbaa !24
  br label %bb12
bb12:
  %t49 = load i64, ptr %l17
  %t50 = inttoptr i64 %t49 to ptr
  %t51 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t50, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t51, ptr %l19
  br label %bb13
bb13:
  %t52 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3acompiles_2e2
  br i1 %t52, label %bb14, label %bb15
bb14:
  %t54 = load i64, ptr %l17
  %t55 = inttoptr i64 %t54 to ptr
  %t56 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19, i32 0, i32 0
  %t57 = load { i64, ptr }, ptr %t56
  %t58 = extractvalue { i64, ptr } %t57, 1
  %t59 = call ptr @__olang_region_or(ptr %t58, ptr null)
  %t60 = call ptr @__olang_region_home(ptr %t59)
  %t61 = icmp ne ptr %t60, null
  %t62 = select i1 %t61, ptr %t60, ptr null
  call void @__olang_region_settle_in(ptr %t55, ptr %t62)
  br label %bb15
bb15:
  %t63 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t63, ptr %l2
  %t64 = call ptr @__olang_scope_hold(ptr %v0)
  %t65 = ptrtoint ptr %t64 to i64
  store i64 %t65, ptr %l21, !tbaa !24
  %t66 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3acompiles_2e3
  br i1 %t66, label %bb16, label %bb17
bb16:
  %t68 = call ptr @__olang_region_make(ptr %v0)
  %t69 = ptrtoint ptr %t68 to i64
  store i64 %t69, ptr %l21, !tbaa !24
  br label %bb17
bb17:
  %t70 = load i64, ptr %l21
  %t71 = inttoptr i64 %t70 to ptr
  %t72 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t71, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t72, ptr %l23
  br label %bb18
bb18:
  %t73 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3acompiles_2e3
  br i1 %t73, label %bb19, label %bb20
bb19:
  %t75 = load i64, ptr %l21
  %t76 = inttoptr i64 %t75 to ptr
  %t77 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23, i32 0, i32 0
  %t78 = load { i64, ptr }, ptr %t77
  %t79 = extractvalue { i64, ptr } %t78, 1
  %t80 = call ptr @__olang_region_or(ptr %t79, ptr null)
  %t81 = call ptr @__olang_region_home(ptr %t80)
  %t82 = icmp ne ptr %t81, null
  %t83 = select i1 %t82, ptr %t81, ptr null
  call void @__olang_region_settle_in(ptr %t76, ptr %t83)
  br label %bb20
bb20:
  %t84 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t84, ptr %l3
  %t85 = call ptr @__olang_scope_hold(ptr %v0)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l25, !tbaa !24
  %t87 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3acompiles_2e4
  br i1 %t87, label %bb21, label %bb22
bb21:
  %t89 = call ptr @__olang_region_make(ptr %v0)
  %t90 = ptrtoint ptr %t89 to i64
  store i64 %t90, ptr %l25, !tbaa !24
  br label %bb22
bb22:
  %t91 = load i64, ptr %l25
  %t92 = inttoptr i64 %t91 to ptr
  %t93 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t92, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t93, ptr %l27
  br label %bb23
bb23:
  %t94 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3acompiles_2e4
  br i1 %t94, label %bb24, label %bb25
bb24:
  %t96 = load i64, ptr %l25
  %t97 = inttoptr i64 %t96 to ptr
  %t98 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27, i32 0, i32 0
  %t99 = load { i64, ptr }, ptr %t98
  %t100 = extractvalue { i64, ptr } %t99, 1
  %t101 = call ptr @__olang_region_or(ptr %t100, ptr null)
  %t102 = call ptr @__olang_region_home(ptr %t101)
  %t103 = icmp ne ptr %t102, null
  %t104 = select i1 %t103, ptr %t102, ptr null
  call void @__olang_region_settle_in(ptr %t97, ptr %t104)
  br label %bb25
bb25:
  %t105 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t105, ptr %l4
  %t106 = call ptr @__olang_scope_hold(ptr %v0)
  %t107 = ptrtoint ptr %t106 to i64
  store i64 %t107, ptr %l29, !tbaa !24
  %t108 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3acompiles_2e5
  br i1 %t108, label %bb26, label %bb27
bb26:
  %t110 = call ptr @__olang_region_make(ptr %v0)
  %t111 = ptrtoint ptr %t110 to i64
  store i64 %t111, ptr %l29, !tbaa !24
  br label %bb27
bb27:
  %t112 = load i64, ptr %l29
  %t113 = inttoptr i64 %t112 to ptr
  %t114 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t113, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t114, ptr %l31
  br label %bb28
bb28:
  %t115 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3acompiles_2e5
  br i1 %t115, label %bb29, label %bb30
bb29:
  %t117 = load i64, ptr %l29
  %t118 = inttoptr i64 %t117 to ptr
  %t119 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l31, i32 0, i32 0
  %t120 = load { i64, ptr }, ptr %t119
  %t121 = extractvalue { i64, ptr } %t120, 1
  %t122 = call ptr @__olang_region_or(ptr %t121, ptr null)
  %t123 = call ptr @__olang_region_home(ptr %t122)
  %t124 = icmp ne ptr %t123, null
  %t125 = select i1 %t124, ptr %t123, ptr null
  call void @__olang_region_settle_in(ptr %t118, ptr %t125)
  br label %bb30
bb30:
  %t126 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l31
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t126, ptr %l5
  %t127 = call ptr @__olang_scope_hold(ptr %v0)
  %t128 = ptrtoint ptr %t127 to i64
  store i64 %t128, ptr %l33, !tbaa !24
  %t129 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3acompiles_2e6
  br i1 %t129, label %bb31, label %bb32
bb31:
  %t131 = call ptr @__olang_region_make(ptr %v0)
  %t132 = ptrtoint ptr %t131 to i64
  store i64 %t132, ptr %l33, !tbaa !24
  br label %bb32
bb32:
  %t133 = load i64, ptr %l33
  %t134 = inttoptr i64 %t133 to ptr
  %t135 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t134, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t135, ptr %l35
  br label %bb33
bb33:
  %t136 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3acompiles_2e6
  br i1 %t136, label %bb34, label %bb35
bb34:
  %t138 = load i64, ptr %l33
  %t139 = inttoptr i64 %t138 to ptr
  %t140 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l35, i32 0, i32 0
  %t141 = load { i64, ptr }, ptr %t140
  %t142 = extractvalue { i64, ptr } %t141, 1
  %t143 = call ptr @__olang_region_or(ptr %t142, ptr null)
  %t144 = call ptr @__olang_region_home(ptr %t143)
  %t145 = icmp ne ptr %t144, null
  %t146 = select i1 %t145, ptr %t144, ptr null
  call void @__olang_region_settle_in(ptr %t139, ptr %t146)
  br label %bb35
bb35:
  %t147 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l35
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t147, ptr %l6
  %t148 = call ptr @__olang_scope_hold(ptr %v0)
  %t149 = ptrtoint ptr %t148 to i64
  store i64 %t149, ptr %l37, !tbaa !24
  %t150 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3acompiles_2e7
  br i1 %t150, label %bb36, label %bb37
bb36:
  %t152 = call ptr @__olang_region_make(ptr %v0)
  %t153 = ptrtoint ptr %t152 to i64
  store i64 %t153, ptr %l37, !tbaa !24
  br label %bb37
bb37:
  %t154 = load i64, ptr %l37
  %t155 = inttoptr i64 %t154 to ptr
  %t156 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t155, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t156, ptr %l39
  br label %bb38
bb38:
  %t157 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3acompiles_2e7
  br i1 %t157, label %bb39, label %bb40
bb39:
  %t159 = load i64, ptr %l37
  %t160 = inttoptr i64 %t159 to ptr
  %t161 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l39, i32 0, i32 0
  %t162 = load { i64, ptr }, ptr %t161
  %t163 = extractvalue { i64, ptr } %t162, 1
  %t164 = call ptr @__olang_region_or(ptr %t163, ptr null)
  %t165 = call ptr @__olang_region_home(ptr %t164)
  %t166 = icmp ne ptr %t165, null
  %t167 = select i1 %t166, ptr %t165, ptr null
  call void @__olang_region_settle_in(ptr %t160, ptr %t167)
  br label %bb40
bb40:
  %t168 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l39
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t168, ptr %l7
  %t169 = call ptr @__olang_scope_hold(ptr %v0)
  %t170 = ptrtoint ptr %t169 to i64
  store i64 %t170, ptr %l41, !tbaa !24
  %t171 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3acompiles_2e8
  br i1 %t171, label %bb41, label %bb42
bb41:
  %t173 = call ptr @__olang_region_make(ptr %v0)
  %t174 = ptrtoint ptr %t173 to i64
  store i64 %t174, ptr %l41, !tbaa !24
  br label %bb42
bb42:
  %t175 = load i64, ptr %l41
  %t176 = inttoptr i64 %t175 to ptr
  %t177 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t176, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t177, ptr %l43
  br label %bb43
bb43:
  %t178 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3acompiles_2e8
  br i1 %t178, label %bb44, label %bb45
bb44:
  %t180 = load i64, ptr %l41
  %t181 = inttoptr i64 %t180 to ptr
  %t182 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43, i32 0, i32 0
  %t183 = load { i64, ptr }, ptr %t182
  %t184 = extractvalue { i64, ptr } %t183, 1
  %t185 = call ptr @__olang_region_or(ptr %t184, ptr null)
  %t186 = call ptr @__olang_region_home(ptr %t185)
  %t187 = icmp ne ptr %t186, null
  %t188 = select i1 %t187, ptr %t186, ptr null
  call void @__olang_region_settle_in(ptr %t181, ptr %t188)
  br label %bb45
bb45:
  %t189 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43
  %t190 = getelementptr %"compiler/build:compiles", ptr %l45, i32 0, i32 0
  %t191 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t191, ptr %t190
  %t192 = getelementptr %"compiler/build:compiles", ptr %l45, i32 0, i32 1
  %t193 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t193, ptr %t192
  %t194 = getelementptr %"compiler/build:compiles", ptr %l45, i32 0, i32 2
  %t195 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t195, ptr %t194
  %t196 = getelementptr %"compiler/build:compiles", ptr %l45, i32 0, i32 3
  %t197 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t197, ptr %t196
  %t198 = getelementptr %"compiler/build:compiles", ptr %l45, i32 0, i32 4
  %t199 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t199, ptr %t198
  %t200 = getelementptr %"compiler/build:compiles", ptr %l45, i32 0, i32 5
  %t201 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t201, ptr %t200
  %t202 = getelementptr %"compiler/build:compiles", ptr %l45, i32 0, i32 6
  %t203 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t203, ptr %t202
  %t204 = getelementptr %"compiler/build:compiles", ptr %l45, i32 0, i32 7
  %t205 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t205, ptr %t204
  %t206 = getelementptr %"compiler/build:compiles", ptr %l45, i32 0, i32 8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t189, ptr %t206
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l45, i64 288, i1 false)
  br label %ret
ret:
  ret void
}

@.d0 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @__olang_errpay_pop()
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d1 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
@.d2 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"-" }>, align 8
@.d3 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"analysis" }>, align 8
@.d4 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d5 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d6 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"XDG_CACHE_HOME" }>, align 8
@.d7 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d8 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d9 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"/olang/" }>, align 8
@.d10 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"HOME" }>, align 8
@.d11 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d12 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d13 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"/.cache/olang/" }>, align 8
declare i32 @getuid()
@.d14 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"/tmp/olang-" }>, align 8
@.d15 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"-" }>, align 8
declare i64 @__olang_fmt_u64(ptr, i64)
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@__olang_empty_array = external constant [16 x i64]
@.d16 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d17 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2ecompiler_2fbuild_3aHeld_2e1 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
@.d18 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @__olang_region_release(ptr) noinline
@.d19 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare i64 @sysconf(i32)
declare ptr @__olang_standin_in(ptr, ptr)
declare ptr @__olang_worker_get()
declare void @__olang_worker_start(ptr, ptr, ptr, ptr)
define internal ptr @olang_task20(ptr %env) #0 {
entry:
  %f0 = getelementptr { ptr, ptr, { i64, ptr }, i64, i64, ptr, ptr, ptr }, ptr %env, i32 0, i32 0
  %f1 = getelementptr { ptr, ptr, { i64, ptr }, i64, i64, ptr, ptr, ptr }, ptr %env, i32 0, i32 1
  %f2 = getelementptr { ptr, ptr, { i64, ptr }, i64, i64, ptr, ptr, ptr }, ptr %env, i32 0, i32 2
  %f3 = getelementptr { ptr, ptr, { i64, ptr }, i64, i64, ptr, ptr, ptr }, ptr %env, i32 0, i32 3
  %f4 = getelementptr { ptr, ptr, { i64, ptr }, i64, i64, ptr, ptr, ptr }, ptr %env, i32 0, i32 4
  %f5 = getelementptr { ptr, ptr, { i64, ptr }, i64, i64, ptr, ptr, ptr }, ptr %env, i32 0, i32 5
  %f6 = getelementptr { ptr, ptr, { i64, ptr }, i64, i64, ptr, ptr, ptr }, ptr %env, i32 0, i32 6
  %f7 = getelementptr { ptr, ptr, { i64, ptr }, i64, i64, ptr, ptr, ptr }, ptr %env, i32 0, i32 7
  %sc0 = load ptr, ptr %f5
  %sn0 = icmp eq ptr %sc0, null
  %sg0 = load ptr, ptr @__olang_prog_scope
  %ss0 = select i1 %sn0, ptr %sg0, ptr %sc0
  %sc1 = load ptr, ptr %f6
  %sn1 = icmp eq ptr %sc1, null
  %sg1 = load ptr, ptr @__olang_prog_scope
  %ss1 = select i1 %sn1, ptr %sg1, ptr %sc1
  %sc2 = load ptr, ptr %f7
  %sn2 = icmp eq ptr %sc2, null
  %sg2 = load ptr, ptr @__olang_prog_scope
  %ss2 = select i1 %sn2, ptr %sg2, ptr %sc2
  %a0 = load ptr, ptr %f0
  %a1 = load ptr, ptr %f1
  %a2 = load { i64, ptr }, ptr %f2
  %a3 = load i64, ptr %f3
  %a4 = load i64, ptr %f4
  call void @compiler_2fbuild_2ehashUnits(ptr %ss0, ptr %ss1, ptr %ss2, ptr %a0, ptr %a1, { i64, ptr } %a2, i64 %a3, i64 %a4)
  ret ptr null
}

declare i64 @__olang_join_tasks_keep(ptr, i1)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d21 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"OLANG_TIMES" }>, align 8
@.d22 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"olang: " }>, align 8
@.d23 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d24 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" ms, " }>, align 8
@.d25 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d26 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"front" }>, align 8
@.d27 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"lower+emit" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d28 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal i1 @olang_lambda_29(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %rv = alloca i1
  %cp0 = getelementptr { { i64, ptr }, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load { i64, ptr }, ptr %cp0, !tbaa !28
  store { i64, ptr } %cv0, ptr %l2
  %vq0 = getelementptr { { i64, ptr }, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t1, ptr %l3, !tbaa !27
  %t4 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !27
  %t6 = getelementptr i64, ptr %t5, i64 %a0
  %t7 = load i64, ptr %t6, !tbaa !34
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t8, ptr %l6, !tbaa !27
  %t11 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !27
  %t13 = getelementptr i64, ptr %t12, i64 %a1
  %t14 = load i64, ptr %t13, !tbaa !34
  %t17 = icmp sgt i64 %t7, %t14
  store i1 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d30 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"olang: compiling " }>, align 8
@.d31 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" objects, " }>, align 8
@.d32 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" at once\0A" }>, align 8
define internal ptr @olang_task33(ptr %env) #0 {
entry:
  %f0 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 0
  %f1 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 1
  %f2 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 2
  %f3 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 3
  %f4 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 4
  %f5 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 5
  %f6 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 6
  %f7 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 7
  %sc0 = load ptr, ptr %f4
  %sn0 = icmp eq ptr %sc0, null
  %sg0 = load ptr, ptr @__olang_prog_scope
  %ss0 = select i1 %sn0, ptr %sg0, ptr %sc0
  %sc1 = load ptr, ptr %f5
  %sn1 = icmp eq ptr %sc1, null
  %sg1 = load ptr, ptr @__olang_prog_scope
  %ss1 = select i1 %sn1, ptr %sg1, ptr %sc1
  %sc2 = load ptr, ptr %f6
  %sn2 = icmp eq ptr %sc2, null
  %sg2 = load ptr, ptr @__olang_prog_scope
  %ss2 = select i1 %sn2, ptr %sg2, ptr %sc2
  %sc3 = load ptr, ptr %f7
  %sn3 = icmp eq ptr %sc3, null
  %sg3 = load ptr, ptr @__olang_prog_scope
  %ss3 = select i1 %sn3, ptr %sg3, ptr %sc3
  %a0 = load ptr, ptr %f0
  %a1 = load { i64, ptr }, ptr %f1
  %a2 = load { i64, ptr }, ptr %f2
  %a3 = load { i64, ptr }, ptr %f3
  call void @compiler_2fbuild_2erunner(ptr %ss0, ptr %ss1, ptr %ss2, ptr %ss3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
  ret ptr null
}

@.d34 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d35 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"env" }>, align 8
@.d36 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"OLANG_AUTORACE=0" }>, align 8
@.d37 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"test" }>, align 8
@.d38 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d39 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d40 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c": lost track of its build, skipping" }>, align 8
@.d41 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"31" }>, align 8
@.d42 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c": the compiler ended (" }>, align 8
@.d43 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"), skipping" }>, align 8
@.d44 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"31" }>, align 8
@.d45 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1 = weak hidden constant i1 false
@.d46 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d47 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d48 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d49 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"no listed file has a test named by " }>, align 8
@.d50 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"31" }>, align 8
@.d51 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"--target=" }>, align 8
@.d52 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d53 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d54 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d55 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"--sysroot=" }>, align 8
@.d56 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d57 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"-isystem" }>, align 8
@.d58 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d59 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"-D_GNU_SOURCE" }>, align 8
@.d60 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"-flto" }>, align 8
@.d61 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"-flto=thin" }>, align 8
@.d62 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"linking" }>, align 8
@.d63 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"windows" }>, align 8
@.d64 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"android" }>, align 8
@.d65 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"-Wl,--thinlto-cache-dir=" }>, align 8
@.d66 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"/thinlto" }>, align 8
@.d67 = private constant <{ i64, [44 x i8] }> <{ i64 0, [44 x i8] c"-Wl,--thinlto-cache-policy=cache_size_bytes=" }>, align 8
@.d68 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"m" }>, align 8
@.d69 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"-Wl,-mllvm,-import-instr-limit=" }>, align 8
@.d70 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"-Wl,-plugin-opt,cache-dir=" }>, align 8
@.d71 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"/thinlto" }>, align 8
@.d72 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c"-Wl,-plugin-opt,cache-policy=cache_size_bytes=" }>, align 8
@.d73 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"m" }>, align 8
@.d74 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"-Wl,-plugin-opt,-import-instr-limit=" }>, align 8
@.d75 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"-shared" }>, align 8
@.d76 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c".map" }>, align 8
@.d77 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"{\0A  global:\0A" }>, align 8
@.d78 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d79 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c";\0A" }>, align 8
@.d80 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"  local: *;\0A};\0A" }>, align 8
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d81 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"-Wl,--version-script=" }>, align 8
@.d82 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"-Wl,-soname," }>, align 8
@.d83 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-o" }>, align 8
@.d84 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"windows" }>, align 8
@.d85 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"-static" }>, align 8
@.d86 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"windows" }>, align 8
@.d87 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"-fuse-ld=lld" }>, align 8
@.d88 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"-Wl,--stack,8388608" }>, align 8
@.d89 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"-lrt" }>, align 8
@.d90 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"-Wl,-plugin-opt=-enable-shrink-wrap=false" }>, align 8
@.d91 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"-lffi" }>, align 8
@.d92 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".link" }>, align 8
@.d93 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d94 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"-flto-jobs=" }>, align 8
@.d95 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d96 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d97 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"--target=" }>, align 8
@.d98 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d99 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d100 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d101 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"--sysroot=" }>, align 8
@.d102 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d103 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"-fPIC" }>, align 8
@.d104 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d105 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"-fsanitize=fuzzer" }>, align 8
@.d106 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"-O0" }>, align 8
@.d107 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-g" }>, align 8
@.d108 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"-fsanitize=thread" }>, align 8
@.d109 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"-O1" }>, align 8
@.d110 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"-fsanitize=thread" }>, align 8
@.d111 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"-O2" }>, align 8
@.d112 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"-O3" }>, align 8
@.d113 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"-flto=thin" }>, align 8
@.d114 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"-flto" }>, align 8
@.d115 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d116 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d117 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".o" }>, align 8
@.d118 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"/spill" }>, align 8
@.d119 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d120 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"-" }>, align 8
@.d121 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"/proc/" }>, align 8
@.d122 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d123 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d124 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"-" }>, align 8
@.d125 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d126 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"code" }>, align 8
@.d127 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c".ll" }>, align 8
@.d128 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c".5.precodegen.bc" }>, align 8
@.d129 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d130 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"--target=" }>, align 8
@.d131 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_209_3e_2e_2d1 = weak hidden constant i1 false
@.d132 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c".ll" }>, align 8
@.d133 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-S" }>, align 8
@.d134 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"-emit-llvm" }>, align 8
@.d135 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-x" }>, align 8
@.d136 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"ir" }>, align 8
@.d137 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"-Xclang" }>, align 8
@.d138 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"-disable-llvm-passes" }>, align 8
@.d139 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-o" }>, align 8
@olang_2esole_2eArray_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2e_2d1 = weak hidden constant i1 false
@.d140 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d141 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d142 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d143 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"-max_total_time=" }>, align 8
@.d144 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"fuzzing " }>, align 8
@.d145 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c": failing inputs go to " }>, align 8
@.d146 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d147 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"36" }>, align 8
@.d148 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"fuzzing " }>, align 8
@.d149 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c": nothing failed" }>, align 8
@.d150 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"32" }>, align 8
@.d151 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"fuzzing " }>, align 8
@.d152 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c": an input failed, saved in " }>, align 8
@.d153 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"/ - 'olang test' replays it" }>, align 8
@.d154 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"31" }>, align 8
@.d155 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d156 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
declare i32 @getpid()
@.d157 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d158 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c".tmp" }>, align 8
@.d159 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d160 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c".lib" }>, align 8
@.d161 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d162 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"/lib" }>, align 8
@.d163 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c".so" }>, align 8
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_202_3e_2e_2d1 = weak hidden constant i1 false
@.d164 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".h" }>, align 8
@.d165 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d166 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"link" }>, align 8
@olang_2esole_2ecompiler_2fbuild_3aConfig_2e35 = weak hidden constant i1 false
@.d167 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"built " }>, align 8
@.d168 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" and " }>, align 8
@.d169 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"32" }>, align 8
@.d170 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"-Wl,-plugin-opt,-import-instr-limit=" }>, align 8
@.d171 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"-Wl,-plugin-opt=save-temps" }>, align 8
@.d172 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"-Wl,-plugin-opt=emit-asm" }>, align 8
@.d173 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c"-Wl,-plugin-opt=opt-remarks-filename=" }>, align 8
@.d174 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"/link.yaml" }>, align 8
@.d175 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"-Wl,-plugin-opt=opt-remarks-passes=" }>, align 8
@.d176 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-o" }>, align 8
@.d177 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"/code" }>, align 8
@.d178 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d179 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"-lffi" }>, align 8
@.d180 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d181 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d182 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d183 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"/code" }>, align 8
@.d184 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"link" }>, align 8
@.d185 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"/made" }>, align 8
@.d186 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d187 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d188 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d189 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.c190 = private unnamed_addr constant [5 x i8] c"true\00"
@.c191 = private unnamed_addr constant [6 x i8] c"false\00"
@.d192 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"/u" }>, align 8
@.d193 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".in.ll" }>, align 8
@.d194 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-S" }>, align 8
@.d195 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"-emit-llvm" }>, align 8
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_204_3e_2e_2d1 = weak hidden constant i1 false
@.d196 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c".ll" }>, align 8
@.d197 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".s" }>, align 8
@.d198 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"/u" }>, align 8
@.d199 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"-foptimization-record-file=" }>, align 8
@.d200 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"/u" }>, align 8
@.d201 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".yaml" }>, align 8
@.d202 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-o" }>, align 8
@.d203 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"/u" }>, align 8
@.d204 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".in.ll" }>, align 8
@.d205 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"/u" }>, align 8
@.d206 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".in.ll" }>, align 8
@.d207 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"/made" }>, align 8
@.d208 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d209 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".race" }>, align 8
@.d210 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d211 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".debug" }>, align 8
@.d212 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d213 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".quick" }>, align 8
@.d214 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d215 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c".san" }>, align 8
@.d216 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d217 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c".lib" }>, align 8
@.d218 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d219 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".cell" }>, align 8
@.d220 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d221 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d222 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".fuzz" }>, align 8
@.d223 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d224 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".prof" }>, align 8
@.d225 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d226 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c".listing" }>, align 8
@.d227 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d228 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".bench" }>, align 8
@.d229 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d230 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c".checked" }>, align 8
@.d231 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d232 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".late" }>, align 8
@.d233 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d234 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d235 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"olang_runtime" }>, align 8
@.d236 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d237 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d238 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"olang_dyncall" }>, align 8
@.d239 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d240 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d241 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".lock" }>, align 8
declare i32 @usleep(i32)
@.d242 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"olang_runtime" }>, align 8
@.d243 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d244 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"olang_dyncall" }>, align 8
@.d245 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d246 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c".counts" }>, align 8
@.d247 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c".counts" }>, align 8
@.d248 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c".counts" }>, align 8
@.d249 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d250 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" passed, " }>, align 8
@.d251 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" failed" }>, align 8
@.d252 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d253 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"env" }>, align 8
@.d254 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"OLANG_TEST_COUNTS=" }>, align 8
@.d255 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c": the tests ended by a signal (" }>, align 8
@.d256 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d257 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"31" }>, align 8
@.d258 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c": the tests ended with status " }>, align 8
@.d259 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c" before every test had run" }>, align 8
@.d260 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"31" }>, align 8
@.d261 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d262 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"|hoist" }>, align 8
@.d263 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d264 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d265 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@olang_2esole_2ecompiler__2fbuild__2ecompiler__2fbuild__3aConfig__2ewant_2elocal_2e14 = weak hidden constant i1 false
@.d266 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c".ll" }>, align 8
declare ptr @__olang_region_or(ptr, ptr)
declare void @__olang_region_settle_in(ptr, ptr)
@.d267 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d268 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c".ll" }>, align 8
@.d269 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"olang_" }>, align 8
@.d270 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d271 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c".tmp.ll" }>, align 8
@.d272 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"source_filename" }>, align 8
@.d273 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"\0Asource_filename" }>, align 8
@.d274 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"source_filename = \22" }>, align 8
@.d275 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\22\0A" }>, align 8
@.d276 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d277 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d278 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c".tmp" }>, align 8
@.d279 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-c" }>, align 8
@.d280 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-o" }>, align 8
@.d281 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"-foptimization-record-file=" }>, align 8
@.d282 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".yaml" }>, align 8
@.d283 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".yaml" }>, align 8
@.d284 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d285 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"OLANG_JOBS" }>, align 8
@.d286 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d287 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"/proc/meminfo" }>, align 8
@.d288 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"MemAvailable:" }>, align 8
@.d289 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] [i8 -128] }>, align 8
@.d290 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] [i8 0] }>, align 8
@.d291 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d292 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".lock" }>, align 8
@.d293 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"/pid" }>, align 8
@.d294 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"N" }>, align 8
@.d295 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"N" }>, align 8
@.d296 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"41" }>, align 8
@.d297 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"attributes #0 = { nounwind " }>, align 8
@.d298 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" }\0A" }>, align 8
@.d299 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"target triple = \22" }>, align 8
@.d300 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\22\0A" }>, align 8
@olang_2esole_2ecompiler_2fbuild_3aUnit_2e2 = weak hidden constant i1 false
@.d301 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"define i32 @lib_n() #0 {\0A  ret i32 " }>, align 8
@.d302 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"\0A}\0A" }>, align 8
@.d303 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"lib" }>, align 8
@.d304 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"define i32 @util_k() #0 {\0A  ret i32 " }>, align 8
@.d305 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"\0A}\0A" }>, align 8
@.d306 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"util" }>, align 8
@.d307 = private constant <{ i64, [90 x i8] }> <{ i64 0, [90 x i8] c"declare i32 @lib_n()\0Adeclare i32 @util_k()\0Adeclare i32 @inst_z()\0Adeclare void @olang_rt()\0A" }>, align 8
@.d308 = private constant <{ i64, [73 x i8] }> <{ i64 0, [73 x i8] c"define i32 @main() #0 {\0A  call void @olang_rt()\0A  %a = call i32 @lib_n()\0A" }>, align 8
@.d309 = private constant <{ i64, [96 x i8] }> <{ i64 0, [96 x i8] c"  %b = call i32 @util_k()\0A  %c = call i32 @inst_z()\0A  %s = add i32 %a, %b\0A  %t = add i32 %s, %c\0A" }>, align 8
@.d310 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"  ret i32 %t\0A}\0A" }>, align 8
@.d311 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"app" }>, align 8
@.d312 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"define i32 @inst_z() #0 {\0A  ret i32 0\0A}\0A" }>, align 8
@.d313 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"app" }>, align 8
@olang_2esole_2ecompiler_2fbuild_3aProgram_2e1 = weak hidden constant i1 false
@.d314 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"define void @olang_rt() #0 {\0A  ret void\0A}\0A" }>, align 8
@.d315 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d316 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"clang" }>, align 8
@.d317 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"opt" }>, align 8
@.d318 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d319 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d320 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c".bc" }>, align 8
@.d321 = private constant <{ i64, [129 x i8] }> <{ i64 0, [129 x i8] c"function(sroa,early-cse<memssa>,simplifycfg,instcombine<no-verify-fixpoint>),function(loop-mssa(loop-rotate,licm)),function(irce)" }>, align 8
@.d322 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" -passes=" }>, align 8
@.d323 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d324 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" -o " }>, align 8
@.d325 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" &&" }>, align 8
declare ptr @__olang_scope_of(ptr, ptr) noinline
@.d326 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d327 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"; s=$?; rm -f " }>, align 8
@.d328 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"; exit $s" }>, align 8
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_203_3e_2e_2d1 = weak hidden constant i1 false
@.d329 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"/bin/sh" }>, align 8
@.d330 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-c" }>, align 8
@.d331 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"/pid" }>, align 8
@.d332 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d333 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"/proc/" }>, align 8
@.d334 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d335 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
define internal i1 @olang_lambda_336(ptr %env, ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l7 = alloca i1
  %l13 = alloca i1
  %l16 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t9 = icmp slt i64 %t3, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb7
bb2:
  %t11 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  %t19 = icmp eq i64 %t13, %t16
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t25 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %t21, { i64, ptr } %t22)
  store i1 %t25, ptr %l16
  br label %bb5
bb4:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb6
bb5:
  %t26 = load i1, ptr %l16, !tbaa !21
  store i1 %t26, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l13, !tbaa !21
  store i1 %t27, ptr %l7, !tbaa !21
  br label %bb7
bb7:
  %t28 = load i1, ptr %l7, !tbaa !21
  store i1 %t28, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d337 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".yaml" }>, align 8
@.d338 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d339 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"made" }>, align 8
@.d340 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".yaml" }>, align 8
@.d341 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".in.ll" }>, align 8
@.d342 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c".ll" }>, align 8
@.d343 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d344 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"/proc/self/status" }>, align 8
@.d345 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"memory unknown" }>, align 8
@.d346 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"VmRSS:" }>, align 8
@.d347 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"VmHWM:" }>, align 8
@.d348 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c" MB resident (at most " }>, align 8
@.d349 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" MB)" }>, align 8
@.d350 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d351 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d352 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler__2fbuild__2enoTestNamed_2elocal_2e8 = weak hidden constant i1 false
@.d353 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d354 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c" - did you mean '" }>, align 8
@.d355 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"'?" }>, align 8
@.d356 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d357 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d358 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c": no test is named by " }>, align 8
@.d359 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-o" }>, align 8
@.d360 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".link" }>, align 8
@.d361 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d362 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d363 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d364 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"cannot run " }>, align 8
@.d365 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d366 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"olang: compiled " }>, align 8
@.d367 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d368 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d369 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d370 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d371 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d372 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d373 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fbuild_3aProgram_2e3 = weak hidden constant i1 false
declare ptr @__olang_region_home(ptr)
@olang_2esole_2ecompiler_2fbuild_3aProgram_2e4 = weak hidden constant i1 false
@.d374 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d375 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d376 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fbuild_3aProgram_2e8 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fbuild_3aProgram_2e9 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fbuild_3aProgram_2e11 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fbuild_3acompiles_2e0 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fbuild_3acompiles_2e1 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fbuild_3acompiles_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fbuild_3acompiles_2e3 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fbuild_3acompiles_2e4 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fbuild_3acompiles_2e5 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fbuild_3acompiles_2e6 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fbuild_3acompiles_2e7 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fbuild_3acompiles_2e8 = weak hidden constant i1 false
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@__olang_prog_scope = external thread_local(initialexec) global ptr
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare ptr @__olang_scope_mine_slow(ptr) noinline
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fos_2eCwd(ptr %v0)
declare { i64, ptr } @std_2ffilepath_2eDir(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2ffilepath_2eBase(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fbuild_2eReadable(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_dcb60eb4101256c1_b0bcaebfd2588235 = external constant [0 x i8]
declare void @compiler_2fbuild_2eTouch(ptr %v0, { i64, ptr } %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i1 %a2)
declare i64 @compiler_2fbuild_2eRecent()
@G_2ecompiler_2fbuild_2eAnalysisCacheCap = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\40\00\00\00\00" }>, align 8
declare void @compiler_2fbuild_2eTrim(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1, ptr %a2, i64 %a3, i64 %a4)
declare { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aHeld_3e_2ector(ptr %v0, i64 %a0)
declare { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_88ea926d2658d5c0_814689e720f02d14 = external constant [0 x i8]
declare { i32, %"std/os:FileInfo" } @std_2fos_2eFileInfo_2eStat(ptr %v0, { i64, ptr } %a0)
declare i64 @compiler_2fbuild_2eonDisk(i64 %a0)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aHeld_3e_2eLen_3ccompiler_2fbuild_3aHeld_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aHeld_3e_2ePush_3ccompiler_2fbuild_3aHeld_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/build:Held" %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aHeld_3e_2eRefMut_3ccompiler_2fbuild_3aHeld_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %a0)
@olang_loc_31b16802902b645_2a48a8850fa1a6d9 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1)
declare i64 @std_2ftime_2eNow()
@G_2ecompiler_2fbuild_2ePhaseAt = external global i64
declare void @compiler_2fbuild_2esayErr(ptr %v0, { i64, ptr } %a0)
declare void @std_2fos_2eExit(i32 %a0)
@olang_loc_1a0af222d89a1264_6ae848cde6020298 = external constant [0 x i8]
@olang_loc_2b4b55182e30c5b8_1dd1254afca8c384 = external constant [0 x i8]
@olang_loc_3fd1be9bff2cc025_306b5f0bb3e84491 = external constant [0 x i8]
@olang_loc_bc625dc042a99e06_c0b5fdead4ea6272 = external constant [0 x i8]
declare void @std_2fprelude_2farray_2eArray_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e)
declare void @std_2fchan_3aChan_3cI64_3e_2ector(ptr %out, ptr %v0, i64 %a0)
declare i32 @std_2fchan_2eSend_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_1359a9f97975288c_a8d4abcb606172b0 = external constant [0 x i8]
@G_2ecompiler_2fbuild_2eRan = external global i64
declare i1 @compiler_2fbuild_2etimed()
declare void @std_2fchan_2eClose_3cI64_3e(ptr %v0, ptr %a0)
@olang_loc_32a3ed5515231110_c7421fb70a543f2c = external constant [0 x i8]
declare void @compiler_2fspin_2eEnd()
declare i1 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eracesSpawners(ptr %v0, ptr %a0)
declare i1 @compiler_2ftarget_2eHasRaceRuntime(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2enoRaceRuntime(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2fbuild_2esayln(ptr %v0, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExec(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3)
declare { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i64, ptr } @compiler_2fbuild_2eSignalName(ptr %v0, i32 %a0)
declare { i64, ptr } @compiler_2fmeasure_2eTotal(ptr %v0, i64 %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fmsgs_2eDistance(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_7d17f382592ac8ef_3cd22268ed245003 = external constant [0 x i8]
declare { i64, ptr } @compiler_2ftarget_2eSysroot(ptr %v0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2fspin_2eRetitle(ptr %v0, { i64, ptr } %a0)
@G_2ecompiler_2fbuild_2eThinCacheCap = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\20\00\00\00\00" }>, align 8
@G_2ecompiler_2fbuild_2eImportLimit = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\46\00\00\00\00\00\00\00" }>, align 8
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eSystemLibs(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eclangVersion(ptr %v0, ptr %v1, ptr %a0)
declare i32 @std_2fos_2eRemove(ptr %v0, { i64, ptr } %a0)
@olang_loc_4cf283899a273ea5_54dbe84ebef87a69 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fbuild_2ekindSuffix(ptr %v0, i32 %a0)
declare i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %a0)
@olang_loc_fea310fef6f4afce_d971442cb72d2c82 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_971dc51609f108cb_e0495ae22580df77 = external constant [0 x i8]
declare i1 @std_2fos_2eExists(ptr %v0, { i64, ptr } %a0)
declare i32 @std_2fos_2eRemoveAll(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2fbuild_2ePid()
declare { i32, { i64, ptr } } @std_2fos_2eMkTemp(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_ed85b58552229ad2_db88a25435ad515e = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_39c6cdce0ac4fdc7_621aa1b204fc2693 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eClangFailed(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/diagmsg:Msg" %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H2ab12f44ffbd18d099d1f5a69642975a(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare i32 @std_2fos_2eRename(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fbuild_2eRemarksOf(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %v0)
declare void @compiler_2fbuild_2efileFatal(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, %"compiler/diagmsg:Msg" %a1, ptr %a2)
@olang_loc_3ba7d2bc4f70132e_88e22ea564bfc3e2 = external constant [0 x i8]
declare i32 @std_2fos_2eLink(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fbuild_2eLibName(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i64, ptr } @std_2ffilepath_2eJoin(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLinkFailed(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2fbuild_2efinish(ptr %v0, ptr %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eOutputCannotWrite(ptr %v0)
declare { i64, ptr } @compiler_2fbuild_2eShown(ptr %v0, ptr %v1, { i64, ptr } %a0)
@G_2ecompiler_2fbuild_2eRemarkPasses = external constant <{ [8 x i8], ptr }>
declare i1 @compiler_2fbuild_2emadeBefore(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @compiler_2fbuild_2eafresh(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
declare %"std/os:Output" @std_2fos_3aOutput_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"compiler/build:Unit" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eAt_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fbuild_2eIrHash(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eCompileFlags(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2fbuild_2eThinFrom = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\02\00\00\00\00" }>, align 8
declare { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aUnit_2eText(ptr %v0, ptr %v1, ptr %a0)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2etestsEnded(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i32 %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H0127831368543eff3b7740d7d3240080(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_81dfa638548de3d7_ab0731b6a5acba3 = external constant [0 x i8]
@olang_loc_64cef890f5e30dfa_ab05d47f854753c6 = external constant [0 x i8]
@olang_loc_adf83e678ec27f19_e5a5f2a4f92e5ce5 = external constant [0 x i8]
@olang_loc_d790d12bf07ae06c_96ebe5e6b28bd688 = external constant [0 x i8]
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoClang(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fbuild_2ekbOf(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@G_2ecompiler_2fbuild_2eJobMemory = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\02\00\00\00\00\00\00" }>, align 8
declare void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eWrite(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2eU32_2eFormat(ptr %v0, i32 %a0, i64 %a1)
@olang_loc_8179dc362f2d1bfc_fef952a35fe3ad58 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i8 %a2)
@G_2ecompiler_2fbuild_2eShaK = available_externally constant <{ [256 x i8] }> <{ [256 x i8] c"\98\2F\8A\42\91\44\37\71\CF\FB\C0\B5\A5\DB\B5\E9\5B\C2\56\39\F1\11\F1\59\A4\82\3F\92\D5\5E\1C\AB\98\AA\07\D8\01\5B\83\12\BE\85\31\24\C3\7D\0C\55\74\5D\BE\72\FE\B1\DE\80\A7\06\DC\9B\74\F1\9B\C1\C1\69\9B\E4\86\47\BE\EF\C6\9D\C1\0F\CC\A1\0C\24\6F\2C\E9\2D\AA\84\74\4A\DC\A9\B0\5C\DA\88\F9\76\52\51\3E\98\6D\C6\31\A8\C8\27\03\B0\C7\7F\59\BF\F3\0B\E0\C6\47\91\A7\D5\51\63\CA\06\67\29\29\14\85\0A\B7\27\38\21\1B\2E\FC\6D\2C\4D\13\0D\38\53\54\73\0A\65\BB\0A\6A\76\2E\C9\C2\81\85\2C\72\92\A1\E8\BF\A2\4B\66\1A\A8\70\8B\4B\C2\A3\51\6C\C7\19\E8\92\D1\24\06\99\D6\85\35\0E\F4\70\A0\6A\10\16\C1\A4\19\08\6C\37\1E\4C\77\48\27\B5\BC\B0\34\B3\0C\1C\39\4A\AA\D8\4E\4F\CA\9C\5B\F3\6F\2E\68\EE\82\8F\74\6F\63\A5\78\14\78\C8\84\08\02\C7\8C\FA\FF\BE\90\EB\6C\50\A4\F7\A3\F9\BE\F2\78\71\C6" }>, align 64
declare i32 @std_2fos_2eMkDir(ptr %v0, { i64, ptr } %a0)
declare i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eHas(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eRaw(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare %"compiler/build:Unit" @compiler_2fbuild_3aUnit_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i32 %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2ePush_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/build:Unit" %a1)
declare i32 @compiler_2fmeasure_2eMeasure(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i64 %a2, { i64, ptr } %a3)
declare { i64, ptr } @std_2fos_2eQuote(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @std_2ftime_2eWall()
@olang_loc_46572e8a3ed1f877_752b2fa47e3744e3 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H1642129570dad448bb7dcc47c334de83(ptr %v0, ptr %v1, ptr %a0, ptr %a1c, ptr %a1e)
declare i1 @compiler_2fmsgs_2eNear(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare { i32, i64 } @std_2fchan_2estd_2fchan_3aChan_3cI64_3e_2eNext_3cI64_3e(ptr %v0, ptr %a0)
@olang_loc_ce9989f7be3b1aff_770cc8c701cb1c1b = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aCode_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0)
declare void @compiler_2fbuild_2ehashUnits(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, i64 %a3, i64 %a4)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
