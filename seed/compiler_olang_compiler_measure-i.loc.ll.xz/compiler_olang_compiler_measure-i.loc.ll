; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_3a3dff66b4ee7c81_b6ae595f2a02f1cd = weak_odr constant [54 x i8] c"std/prelude/vec.olang:284: array length out of range\0A\00"
@olang_loc_7ee3993ad0f598de_d867035649894e22 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:61: slice bounds out of range\0A\00"
@olang_loc_89448de9da712574_f11f012cbafb19a0 = weak_odr constant [54 x i8] c"std/prelude/vec.olang:283: array length out of range\0A\00"
