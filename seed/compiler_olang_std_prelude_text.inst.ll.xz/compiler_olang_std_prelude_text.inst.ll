; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/list:listState.9783095779ea18337775adeb6569839d" = type { { i64, ptr }, { i64, ptr }, i64, i64, { i64, ptr }, i64, i64, i64 }
define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2eCl_He62a1125a32dfc5a59291318c690abf4(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t6, i32 0, i32 7
  store i64 0, ptr %t8, !tbaa !24
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t9, i32 0, i32 5
  store i64 0, ptr %t11, !tbaa !24
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t12, i32 0, i32 3
  %t15 = load i64, ptr %t14, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb1, label %bb2
bb1:
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t19, i32 0, i32 2
  store i64 1, ptr %t21, !tbaa !24
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t25 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t23, i32 0, i32 1
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  %t29 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t22, i32 0, i32 4
  store { i64, ptr } %t26, ptr %t29, !tbaa !27
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t31, i32 0, i32 4
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t39 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t30, i32 0, i32 6
  store i64 %t36, ptr %t39, !tbaa !24
  br label %bb3
bb2:
  br label %bb3
bb3:
  br label %ret
ret:
  ret void
}

define dso_local i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2eLe_H123f33f8ddaac384b8a67c2466e49838(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2ePu_H19b8985d31946b3485fef8ba31e677f6(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l32 = alloca i64
  %l35 = alloca i64
  %l54 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l64 = alloca ptr
  %l69 = alloca ptr
  %l85 = alloca { i64, ptr }
  %l108 = alloca i64
  %l111 = alloca i64
  %l130 = alloca { i64, ptr }
  %l135 = alloca { i64, ptr }
  %l142 = alloca ptr
  %l149 = alloca ptr
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t11 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t9, i32 0, i32 6
  %t12 = load i64, ptr %t11, !tbaa !24
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t15 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t13, i32 0, i32 5
  %t16 = load i64, ptr %t15, !tbaa !24
  %t19 = sub i64 %t12, %t16
  %t22 = icmp sle i64 %t8, %t19
  br i1 %t22, label %bb1, label %bb2
bb1:
  store i64 0, ptr %l3, !tbaa !24
  %t24 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  store i64 %t26, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t28 = load i64, ptr %l4, !tbaa !24
  %t29 = load i64, ptr %l3, !tbaa !24
  %t32 = icmp sgt i64 %t28, %t29
  br i1 %t32, label %bb3, label %bb4
bb2:
  br label %bb15
bb3:
  %t34 = load i64, ptr %l5, !tbaa !24
  %t36 = icmp sgt i64 %t34, 0
  br i1 %t36, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb8
bb5:
  %t38 = load i64, ptr %l4, !tbaa !24
  %t39 = load i64, ptr %l3, !tbaa !24
  %t42 = sub i64 %t38, %t39
  %t43 = load i64, ptr %l5, !tbaa !24
  %t46 = add i64 %t42, %t43
  %t48 = sub i64 %t46, 1
  %t49 = load i64, ptr %l5, !tbaa !24
  %t52 = sdiv i64 %t48, %t49
  store i64 %t52, ptr %l35, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb7
bb7:
  %t54 = load i64, ptr %l35, !tbaa !24
  store i64 %t54, ptr %l32, !tbaa !24
  br label %bb8
bb8:
  %t55 = load i64, ptr %l32, !tbaa !24
  store i64 %t55, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t56 = load i64, ptr %l7, !tbaa !24
  %t57 = load i64, ptr %l6, !tbaa !24
  %t60 = icmp slt i64 %t56, %t57
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb14
bb11:
  br label %bb12
bb12:
  %t64 = load i64, ptr %l3, !tbaa !24
  %t65 = load i64, ptr %l7, !tbaa !24
  %t66 = load i64, ptr %l5, !tbaa !24
  %t69 = mul i64 %t65, %t66
  %t72 = add i64 %t64, %t69
  store i64 %t72, ptr %l8, !tbaa !24
  %t74 = load ptr, ptr %l2, !tbaa !29
  %t76 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t74, i32 0, i32 4
  %t77 = load { i64, ptr }, ptr %t76, !tbaa !27
  store { i64, ptr } %t77, ptr %l54, !tbaa !27
  %t78 = load ptr, ptr %l2, !tbaa !29
  %t80 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t78, i32 0, i32 5
  %t81 = load i64, ptr %t80, !tbaa !24
  %t82 = load i64, ptr %l8, !tbaa !24
  %t85 = add i64 %t81, %t82
  %t86 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t86, ptr %l59, !tbaa !27
  %t87 = load i64, ptr %l8, !tbaa !24
  %t89 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr i8, ptr %t90, i64 %t87
  %t92 = load i8, ptr %t91, !tbaa !32
  %t95 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr i8, ptr %t96, i64 %t85
  store i8 %t92, ptr %t97, !tbaa !32
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb13:
  %t98 = load i64, ptr %l7, !tbaa !24
  %t100 = add i64 %t98, 1
  store i64 %t100, ptr %l7, !tbaa !24
  br label %bb9
bb14:
  %t102 = load ptr, ptr %l2, !tbaa !29
  store ptr %t102, ptr %l64, !tbaa !29
  %t103 = load ptr, ptr %l64, !tbaa !29
  %t104 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t103, i32 0, i32 5
  %t105 = load i64, ptr %t104, !tbaa !24
  %t106 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t106, 0
  %t111 = add i64 %t105, %t108
  %t113 = load ptr, ptr %l64, !tbaa !29
  %t114 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t113, i32 0, i32 5
  store i64 %t111, ptr %t114, !tbaa !24
  %t115 = load ptr, ptr %l2, !tbaa !29
  store ptr %t115, ptr %l69, !tbaa !29
  %t116 = load ptr, ptr %l69, !tbaa !29
  %t117 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t116, i32 0, i32 7
  %t118 = load i64, ptr %t117, !tbaa !24
  %t119 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t124 = add i64 %t118, %t121
  %t126 = load ptr, ptr %l69, !tbaa !29
  %t127 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t126, i32 0, i32 7
  store i64 %t124, ptr %t127, !tbaa !24
  br label %ret
bb15:
  store i64 0, ptr %l9, !tbaa !24
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s5
  %t128 = load i64, ptr %l9, !tbaa !24
  %t129 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t129, 0
  %t134 = icmp slt i64 %t128, %t131
  %t136 = xor i1 %t134, true
  br i1 %t136, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s5)
  br label %bb40
bb18:
  br label %bb19
bb19:
  %t138 = load ptr, ptr %l2, !tbaa !29
  %t140 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t138, i32 0, i32 5
  %t141 = load i64, ptr %t140, !tbaa !24
  %t142 = load ptr, ptr %l2, !tbaa !29
  %t144 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t142, i32 0, i32 6
  %t145 = load i64, ptr %t144, !tbaa !24
  %t148 = icmp eq i64 %t141, %t145
  br i1 %t148, label %bb20, label %bb21
bb20:
  %t150 = load ptr, ptr %l2, !tbaa !29
  %t151 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t151, ptr %l85, !tbaa !27
  %t152 = load i64, ptr %l9, !tbaa !24
  %t154 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = getelementptr i8, ptr %t155, i64 %t152
  %t157 = load i8, ptr %t156, !tbaa !32
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cstd_2fprelude_2ftext_3aChar_3e_H1ed7a0a5600a328d35a58405b24846d4(ptr %v0, ptr %t150, i8 %t157)
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb23
bb23:
  %t160 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t162 = extractvalue { i64, ptr } %t160, 0
  %t163 = load i64, ptr %l9, !tbaa !24
  %t166 = sub i64 %t162, %t163
  store i64 %t166, ptr %l10, !tbaa !24
  %t168 = load ptr, ptr %l2, !tbaa !29
  %t170 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t168, i32 0, i32 6
  %t171 = load i64, ptr %t170, !tbaa !24
  %t172 = load ptr, ptr %l2, !tbaa !29
  %t174 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t172, i32 0, i32 5
  %t175 = load i64, ptr %t174, !tbaa !24
  %t178 = sub i64 %t171, %t175
  %t179 = load i64, ptr %l10, !tbaa !24
  %t182 = icmp slt i64 %t178, %t179
  br i1 %t182, label %bb24, label %bb25
bb24:
  %t184 = load ptr, ptr %l2, !tbaa !29
  %t186 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t184, i32 0, i32 6
  %t187 = load i64, ptr %t186, !tbaa !24
  %t188 = load ptr, ptr %l2, !tbaa !29
  %t190 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t188, i32 0, i32 5
  %t191 = load i64, ptr %t190, !tbaa !24
  %t194 = sub i64 %t187, %t191
  store i64 %t194, ptr %l10, !tbaa !24
  br label %bb26
bb25:
  br label %bb26
bb26:
  store i64 0, ptr %l11, !tbaa !24
  %t196 = load i64, ptr %l10, !tbaa !24
  store i64 %t196, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t198 = load i64, ptr %l12, !tbaa !24
  %t199 = load i64, ptr %l11, !tbaa !24
  %t202 = icmp sgt i64 %t198, %t199
  br i1 %t202, label %bb27, label %bb28
bb27:
  %t204 = load i64, ptr %l13, !tbaa !24
  %t206 = icmp sgt i64 %t204, 0
  br i1 %t206, label %bb29, label %bb30
bb28:
  store i64 0, ptr %l108, !tbaa !24
  br label %bb32
bb29:
  %t208 = load i64, ptr %l12, !tbaa !24
  %t209 = load i64, ptr %l11, !tbaa !24
  %t212 = sub i64 %t208, %t209
  %t213 = load i64, ptr %l13, !tbaa !24
  %t216 = add i64 %t212, %t213
  %t218 = sub i64 %t216, 1
  %t219 = load i64, ptr %l13, !tbaa !24
  %t222 = sdiv i64 %t218, %t219
  store i64 %t222, ptr %l111, !tbaa !24
  br label %bb31
bb30:
  store i64 0, ptr %l111, !tbaa !24
  br label %bb31
bb31:
  %t224 = load i64, ptr %l111, !tbaa !24
  store i64 %t224, ptr %l108, !tbaa !24
  br label %bb32
bb32:
  %t225 = load i64, ptr %l108, !tbaa !24
  store i64 %t225, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb33
bb33:
  store %olang.scope zeroinitializer, ptr %s9
  %t226 = load i64, ptr %l15, !tbaa !24
  %t227 = load i64, ptr %l14, !tbaa !24
  %t230 = icmp slt i64 %t226, %t227
  %t232 = xor i1 %t230, true
  br i1 %t232, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s9)
  br label %bb38
bb35:
  br label %bb36
bb36:
  %t234 = load i64, ptr %l11, !tbaa !24
  %t235 = load i64, ptr %l15, !tbaa !24
  %t236 = load i64, ptr %l13, !tbaa !24
  %t239 = mul i64 %t235, %t236
  %t242 = add i64 %t234, %t239
  store i64 %t242, ptr %l16, !tbaa !24
  %t244 = load ptr, ptr %l2, !tbaa !29
  %t246 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t244, i32 0, i32 4
  %t247 = load { i64, ptr }, ptr %t246, !tbaa !27
  store { i64, ptr } %t247, ptr %l130, !tbaa !27
  %t248 = load ptr, ptr %l2, !tbaa !29
  %t250 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t248, i32 0, i32 5
  %t251 = load i64, ptr %t250, !tbaa !24
  %t252 = load i64, ptr %l16, !tbaa !24
  %t255 = add i64 %t251, %t252
  %t256 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t256, ptr %l135, !tbaa !27
  %t257 = load i64, ptr %l9, !tbaa !24
  %t258 = load i64, ptr %l16, !tbaa !24
  %t261 = add i64 %t257, %t258
  %t263 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t264 = load ptr, ptr %t263, !tbaa !27
  %t265 = getelementptr i8, ptr %t264, i64 %t261
  %t266 = load i8, ptr %t265, !tbaa !32
  %t269 = getelementptr { i64, ptr }, ptr %l130, i32 0, i32 1
  %t270 = load ptr, ptr %t269, !tbaa !27
  %t271 = getelementptr i8, ptr %t270, i64 %t255
  store i8 %t266, ptr %t271, !tbaa !32
  call void @__olang_scope_close(ptr %s9)
  br label %bb37
bb37:
  %t272 = load i64, ptr %l15, !tbaa !24
  %t274 = add i64 %t272, 1
  store i64 %t274, ptr %l15, !tbaa !24
  br label %bb33
bb38:
  %t276 = load ptr, ptr %l2, !tbaa !29
  store ptr %t276, ptr %l142, !tbaa !29
  %t277 = load ptr, ptr %l142, !tbaa !29
  %t278 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t277, i32 0, i32 5
  %t279 = load i64, ptr %t278, !tbaa !24
  %t280 = load i64, ptr %l10, !tbaa !24
  %t283 = add i64 %t279, %t280
  %t285 = load ptr, ptr %l142, !tbaa !29
  %t286 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t285, i32 0, i32 5
  store i64 %t283, ptr %t286, !tbaa !24
  %t287 = load i64, ptr %l9, !tbaa !24
  %t288 = load i64, ptr %l10, !tbaa !24
  %t291 = add i64 %t287, %t288
  store i64 %t291, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb39
bb39:
  br label %bb16
bb40:
  %t293 = load ptr, ptr %l2, !tbaa !29
  store ptr %t293, ptr %l149, !tbaa !29
  %t294 = load ptr, ptr %l149, !tbaa !29
  %t295 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t294, i32 0, i32 7
  %t296 = load i64, ptr %t295, !tbaa !24
  %t297 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t299 = extractvalue { i64, ptr } %t297, 0
  %t302 = add i64 %t296, %t299
  %t304 = load ptr, ptr %l149, !tbaa !29
  %t305 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t304, i32 0, i32 7
  store i64 %t302, ptr %t305, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2ePu_H849b787d6464fd61c7b36d59bd222081(ptr %v0, ptr %a0, i8 %a1) #0 {
entry:
  %l1 = alloca i8
  %l2 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l20 = alloca ptr
  store i8 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t6, i32 0, i32 5
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t10, i32 0, i32 6
  %t13 = load i64, ptr %t12, !tbaa !24
  %t16 = icmp eq i64 %t9, %t13
  br i1 %t16, label %bb1, label %bb2
bb1:
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t19 = load i8, ptr %l1, !tbaa !22
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cstd_2fprelude_2ftext_3aChar_3e_H1ed7a0a5600a328d35a58405b24846d4(ptr %v0, ptr %t18, i8 %t19)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t22, i32 0, i32 4
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  store { i64, ptr } %t25, ptr %l13, !tbaa !27
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t26, i32 0, i32 5
  %t29 = load i64, ptr %t28, !tbaa !24
  %t30 = load i8, ptr %l1, !tbaa !22
  %t33 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr i8, ptr %t34, i64 %t29
  store i8 %t30, ptr %t35, !tbaa !32
  %t36 = load ptr, ptr %l2, !tbaa !29
  store ptr %t36, ptr %l17, !tbaa !29
  %t37 = load ptr, ptr %l17, !tbaa !29
  %t38 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t37, i32 0, i32 5
  %t39 = load i64, ptr %t38, !tbaa !24
  %t41 = add i64 %t39, 1
  %t43 = load ptr, ptr %l17, !tbaa !29
  %t44 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t43, i32 0, i32 5
  store i64 %t41, ptr %t44, !tbaa !24
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l20, !tbaa !29
  %t46 = load ptr, ptr %l20, !tbaa !29
  %t47 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t46, i32 0, i32 7
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = add i64 %t48, 1
  %t52 = load ptr, ptr %l20, !tbaa !29
  %t53 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t52, i32 0, i32 7
  store i64 %t50, ptr %t53, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2eTo_Hb8acb615cfdcbcf79972fa4c281da350(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l26 = alloca i64
  %l28 = alloca { i64, ptr }
  %l29 = alloca i8
  %l37 = alloca i64
  %l40 = alloca i64
  %l60 = alloca { i64, ptr }
  %l74 = alloca i64
  %l77 = alloca i64
  %l95 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t39 = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t6, i32 0, i32 7
  %t9 = load i64, ptr %t8, !tbaa !24
  %t11 = icmp eq i64 %t9, 0
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = icmp sge i64 0, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  br label %bb5
bb3:
  %t15 = mul i64 0, 1
  %t16 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 0, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  call void @__olang_check_failed(ptr @olang_loc_633bdd7e62b7da5c_1326dd696b8e1bc0)
  unreachable
bb5:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t20, i32 0, i32 7
  %t23 = load i64, ptr %t22, !tbaa !24
  store i64 %t23, ptr %l26, !tbaa !24
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t24, i32 0, i32 1
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %l28, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr i8, ptr %t29, i64 0
  %t31 = load i8, ptr %t30, !tbaa !32
  store i8 %t31, ptr %l29, !tbaa !22
  %t32 = load i64, ptr %l26, !tbaa !24
  %t33 = icmp sge i64 %t32, 0
  br i1 %t33, label %bb6, label %bb7
bb6:
  %t35 = load i64, ptr %l26, !tbaa !24
  %t36 = mul i64 %t35, 1
  %t37 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t36)
  %t38 = load i8, ptr %l29, !tbaa !22
  store i64 0, ptr %t39
  br label %fill.40
fill.40:
  %t43 = load i64, ptr %t39
  %t44 = icmp slt i64 %t43, %t35
  br i1 %t44, label %fillb.41, label %filld.42
fillb.41:
  %t45 = getelementptr i8, ptr %t37, i64 %t43
  store i8 %t38, ptr %t45
  %t46 = add i64 %t43, 1
  store i64 %t46, ptr %t39
  br label %fill.40
filld.42:
  %t47 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t37, 1
  store { i64, ptr } %t48, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t50, i32 0, i32 2
  %t53 = load i64, ptr %t52, !tbaa !24
  store i64 %t53, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t55 = load i64, ptr %l5, !tbaa !24
  %t56 = load i64, ptr %l4, !tbaa !24
  %t59 = icmp sgt i64 %t55, %t56
  br i1 %t59, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_3f899fc571d42529_c24733a4ca5f80ed)
  unreachable
bb8:
  %t61 = load i64, ptr %l6, !tbaa !24
  %t63 = icmp sgt i64 %t61, 0
  br i1 %t63, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb13
bb10:
  %t65 = load i64, ptr %l5, !tbaa !24
  %t66 = load i64, ptr %l4, !tbaa !24
  %t69 = sub i64 %t65, %t66
  %t70 = load i64, ptr %l6, !tbaa !24
  %t73 = add i64 %t69, %t70
  %t75 = sub i64 %t73, 1
  %t76 = load i64, ptr %l6, !tbaa !24
  %t79 = sdiv i64 %t75, %t76
  store i64 %t79, ptr %l40, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb12
bb12:
  %t81 = load i64, ptr %l40, !tbaa !24
  store i64 %t81, ptr %l37, !tbaa !24
  br label %bb13
bb13:
  %t82 = load i64, ptr %l37, !tbaa !24
  store i64 %t82, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t83 = load i64, ptr %l8, !tbaa !24
  %t84 = load i64, ptr %l7, !tbaa !24
  %t87 = icmp slt i64 %t83, %t84
  %t89 = xor i1 %t87, true
  br i1 %t89, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb35
bb16:
  br label %bb17
bb17:
  %t91 = load i64, ptr %l4, !tbaa !24
  %t92 = load i64, ptr %l8, !tbaa !24
  %t93 = load i64, ptr %l6, !tbaa !24
  %t96 = mul i64 %t92, %t93
  %t99 = add i64 %t91, %t96
  store i64 %t99, ptr %l9, !tbaa !24
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t102 = load i64, ptr %l9, !tbaa !24
  %t105 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t101, i64 %t102)
  store { i64, ptr } %t105, ptr %l60
  br label %bb18
bb18:
  %t106 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t106, ptr %l10, !tbaa !27
  %t107 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t107, 0
  store i64 %t109, ptr %l11, !tbaa !24
  %t111 = load i64, ptr %l9, !tbaa !24
  %t112 = load ptr, ptr %l1, !tbaa !29
  %t114 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t112, i32 0, i32 2
  %t115 = load i64, ptr %t114, !tbaa !24
  %t117 = sub i64 %t115, 1
  %t120 = icmp eq i64 %t111, %t117
  br i1 %t120, label %bb19, label %bb20
bb19:
  %t122 = load ptr, ptr %l1, !tbaa !29
  %t124 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t122, i32 0, i32 5
  %t125 = load i64, ptr %t124, !tbaa !24
  store i64 %t125, ptr %l11, !tbaa !24
  br label %bb21
bb20:
  br label %bb21
bb21:
  store i64 0, ptr %l12, !tbaa !24
  %t127 = load i64, ptr %l11, !tbaa !24
  store i64 %t127, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t129 = load i64, ptr %l13, !tbaa !24
  %t130 = load i64, ptr %l12, !tbaa !24
  %t133 = icmp sgt i64 %t129, %t130
  br i1 %t133, label %bb22, label %bb23
bb22:
  %t135 = load i64, ptr %l14, !tbaa !24
  %t137 = icmp sgt i64 %t135, 0
  br i1 %t137, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l74, !tbaa !24
  br label %bb27
bb24:
  %t139 = load i64, ptr %l13, !tbaa !24
  %t140 = load i64, ptr %l12, !tbaa !24
  %t143 = sub i64 %t139, %t140
  %t144 = load i64, ptr %l14, !tbaa !24
  %t147 = add i64 %t143, %t144
  %t149 = sub i64 %t147, 1
  %t150 = load i64, ptr %l14, !tbaa !24
  %t153 = sdiv i64 %t149, %t150
  store i64 %t153, ptr %l77, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l77, !tbaa !24
  br label %bb26
bb26:
  %t155 = load i64, ptr %l77, !tbaa !24
  store i64 %t155, ptr %l74, !tbaa !24
  br label %bb27
bb27:
  %t156 = load i64, ptr %l74, !tbaa !24
  store i64 %t156, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s6
  %t157 = load i64, ptr %l16, !tbaa !24
  %t158 = load i64, ptr %l15, !tbaa !24
  %t161 = icmp slt i64 %t157, %t158
  %t163 = xor i1 %t161, true
  br i1 %t163, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s6)
  br label %bb33
bb30:
  br label %bb31
bb31:
  %t165 = load i64, ptr %l12, !tbaa !24
  %t166 = load i64, ptr %l16, !tbaa !24
  %t167 = load i64, ptr %l14, !tbaa !24
  %t170 = mul i64 %t166, %t167
  %t173 = add i64 %t165, %t170
  store i64 %t173, ptr %l17, !tbaa !24
  %t175 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t175, ptr %l95, !tbaa !27
  %t176 = load i64, ptr %l3, !tbaa !24
  %t177 = load i64, ptr %l17, !tbaa !24
  %t180 = add i64 %t176, %t177
  %t181 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t181, ptr %l99, !tbaa !27
  %t182 = load i64, ptr %l17, !tbaa !24
  %t184 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !27
  %t186 = getelementptr i8, ptr %t185, i64 %t182
  %t187 = load i8, ptr %t186, !tbaa !32
  %t190 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !27
  %t192 = getelementptr i8, ptr %t191, i64 %t180
  store i8 %t187, ptr %t192, !tbaa !32
  call void @__olang_scope_close(ptr %s6)
  br label %bb32
bb32:
  %t193 = load i64, ptr %l16, !tbaa !24
  %t195 = add i64 %t193, 1
  store i64 %t195, ptr %l16, !tbaa !24
  br label %bb28
bb33:
  %t197 = load i64, ptr %l3, !tbaa !24
  %t198 = load i64, ptr %l11, !tbaa !24
  %t201 = add i64 %t197, %t198
  store i64 %t201, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb34
bb34:
  %t203 = load i64, ptr %l8, !tbaa !24
  %t205 = add i64 %t203, 1
  store i64 %t205, ptr %l8, !tbaa !24
  br label %bb14
bb35:
  %t207 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t207, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cstd_2fprelude_2ftext_3aChar_3e_H1ed7a0a5600a328d35a58405b24846d4(ptr %v0, ptr %a0, i8 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i8
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca i8
  %l35 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l49 = alloca i64
  %l51 = alloca { i64, ptr }
  %l60 = alloca i64
  %l63 = alloca i64
  %l81 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l94 = alloca i64
  %l97 = alloca i64
  %l98 = alloca i64
  %l99 = alloca i8
  %l104 = alloca { i64, ptr }
  %l108 = alloca ptr
  %l111 = alloca ptr
  %s9 = alloca %olang.scope
  %t51 = alloca i64
  %t101 = alloca i64
  %t134 = alloca i64
  %t247 = alloca i64
  store ptr %a0, ptr %l0
  store i8 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t5, i32 0, i32 3
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = icmp slt i64 %t4, %t8
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l14, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t15, i32 0, i32 2
  %t18 = load i64, ptr %t17, !tbaa !24
  %t21 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t14, i64 %t18)
  store { i64, ptr } %t21, ptr %l18
  br label %bb3
bb2:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t22, i32 0, i32 3
  %t25 = load i64, ptr %t24, !tbaa !24
  %t27 = icmp eq i64 %t25, 0
  br i1 %t27, label %bb4, label %bb5
bb3:
  %t29 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t30 = load ptr, ptr %l14, !tbaa !29
  %t31 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t30, i32 0, i32 4
  store { i64, ptr } %t29, ptr %t31, !tbaa !27
  br label %bb37
bb4:
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l22, !tbaa !29
  %t33 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  store i64 %t33, ptr %l23, !tbaa !24
  %t34 = load i8, ptr %l1, !tbaa !22
  store i8 %t34, ptr %l24, !tbaa !22
  %t35 = load i64, ptr %l23, !tbaa !24
  %t36 = icmp sge i64 %t35, 0
  br i1 %t36, label %bb6, label %bb7
bb5:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t38, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t45 = icmp eq i64 %t43, 0
  br i1 %t45, label %bb8, label %bb9
bb6:
  %t47 = load i64, ptr %l23, !tbaa !24
  %t48 = mul i64 %t47, 1
  %t49 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t48)
  %t50 = load i8, ptr %l24, !tbaa !22
  store i64 0, ptr %t51
  br label %fill.52
fill.52:
  %t55 = load i64, ptr %t51
  %t56 = icmp slt i64 %t55, %t47
  br i1 %t56, label %fillb.53, label %filld.54
fillb.53:
  %t57 = getelementptr i8, ptr %t49, i64 %t55
  store i8 %t50, ptr %t57
  %t58 = add i64 %t55, 1
  store i64 %t58, ptr %t51
  br label %fill.52
filld.54:
  %t59 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t49, 1
  %t62 = load ptr, ptr %l22, !tbaa !29
  %t63 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t62, i32 0, i32 1
  store { i64, ptr } %t60, ptr %t63, !tbaa !27
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t65, i32 0, i32 1
  %t68 = load { i64, ptr }, ptr %t67, !tbaa !27
  %t71 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t64, i32 0, i32 4
  store { i64, ptr } %t68, ptr %t71, !tbaa !27
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t72, i32 0, i32 3
  store i64 1, ptr %t74, !tbaa !24
  br label %bb36
bb7:
  call void @__olang_check_failed(ptr @olang_loc_6945ad779c7e7f7c_aa454bb08a1e6148)
  unreachable
bb8:
  %t75 = load ptr, ptr %l0, !tbaa !29
  store ptr %t75, ptr %l35, !tbaa !29
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t76, i32 0, i32 1
  %t79 = load { i64, ptr }, ptr %t78, !tbaa !27
  store { i64, ptr } %t79, ptr %l37, !tbaa !27
  %t80 = icmp sge i64 4, 0
  br i1 %t80, label %bb10, label %bb11
bb9:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t82, i32 0, i32 3
  %t85 = load i64, ptr %t84, !tbaa !24
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t86, i32 0, i32 0
  %t89 = load { i64, ptr }, ptr %t88, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t89, 0
  %t94 = icmp eq i64 %t85, %t91
  br i1 %t94, label %bb14, label %bb15
bb10:
  %t96 = icmp sle i64 4, 576460752303423487
  br i1 %t96, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_705f0c942e068bc9_811d7cacde790eb5)
  unreachable
bb12:
  %t98 = mul i64 4, 16
  %t99 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t98)
  %t100 = load { i64, ptr }, ptr %l37, !tbaa !27
  store i64 0, ptr %t101
  br label %fill.102
fill.102:
  %t105 = load i64, ptr %t101
  %t106 = icmp slt i64 %t105, 4
  br i1 %t106, label %fillb.103, label %filld.104
fillb.103:
  %t107 = getelementptr { i64, ptr }, ptr %t99, i64 %t105
  store { i64, ptr } %t100, ptr %t107
  %t108 = add i64 %t105, 1
  store i64 %t108, ptr %t101
  br label %fill.102
filld.104:
  %t109 = insertvalue { i64, ptr } undef, i64 4, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t99, 1
  %t112 = load ptr, ptr %l35, !tbaa !29
  %t113 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t112, i32 0, i32 0
  store { i64, ptr } %t110, ptr %t113, !tbaa !27
  br label %bb33
bb13:
  call void @__olang_check_failed(ptr @olang_loc_705f0c942e068bc9_811d7cacde790eb5)
  unreachable
bb14:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t114, i32 0, i32 3
  %t117 = load i64, ptr %t116, !tbaa !24
  %t119 = mul i64 %t117, 2
  store i64 %t119, ptr %l49, !tbaa !24
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t120, i32 0, i32 1
  %t123 = load { i64, ptr }, ptr %t122, !tbaa !27
  store { i64, ptr } %t123, ptr %l51, !tbaa !27
  %t124 = load i64, ptr %l49, !tbaa !24
  %t125 = icmp sge i64 %t124, 0
  br i1 %t125, label %bb16, label %bb17
bb15:
  br label %bb32
bb16:
  %t127 = load i64, ptr %l49, !tbaa !24
  %t128 = icmp sle i64 %t127, 576460752303423487
  br i1 %t128, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_eae9d5df37060f0a_8a452e5dcec4c596)
  unreachable
bb18:
  %t130 = load i64, ptr %l49, !tbaa !24
  %t131 = mul i64 %t130, 16
  %t132 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t131)
  %t133 = load { i64, ptr }, ptr %l51, !tbaa !27
  store i64 0, ptr %t134
  br label %fill.135
fill.135:
  %t138 = load i64, ptr %t134
  %t139 = icmp slt i64 %t138, %t130
  br i1 %t139, label %fillb.136, label %filld.137
fillb.136:
  %t140 = getelementptr { i64, ptr }, ptr %t132, i64 %t138
  store { i64, ptr } %t133, ptr %t140
  %t141 = add i64 %t138, 1
  store i64 %t141, ptr %t134
  br label %fill.135
filld.137:
  %t142 = insertvalue { i64, ptr } undef, i64 %t130, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t132, 1
  store { i64, ptr } %t143, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t145, i32 0, i32 3
  %t148 = load i64, ptr %t147, !tbaa !24
  store i64 %t148, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t150 = load i64, ptr %l4, !tbaa !24
  %t151 = load i64, ptr %l3, !tbaa !24
  %t154 = icmp sgt i64 %t150, %t151
  br i1 %t154, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_eae9d5df37060f0a_8a452e5dcec4c596)
  unreachable
bb20:
  %t156 = load i64, ptr %l5, !tbaa !24
  %t158 = icmp sgt i64 %t156, 0
  br i1 %t158, label %bb22, label %bb23
bb21:
  store i64 0, ptr %l60, !tbaa !24
  br label %bb25
bb22:
  %t160 = load i64, ptr %l4, !tbaa !24
  %t161 = load i64, ptr %l3, !tbaa !24
  %t164 = sub i64 %t160, %t161
  %t165 = load i64, ptr %l5, !tbaa !24
  %t168 = add i64 %t164, %t165
  %t170 = sub i64 %t168, 1
  %t171 = load i64, ptr %l5, !tbaa !24
  %t174 = sdiv i64 %t170, %t171
  store i64 %t174, ptr %l63, !tbaa !24
  br label %bb24
bb23:
  store i64 0, ptr %l63, !tbaa !24
  br label %bb24
bb24:
  %t176 = load i64, ptr %l63, !tbaa !24
  store i64 %t176, ptr %l60, !tbaa !24
  br label %bb25
bb25:
  %t177 = load i64, ptr %l60, !tbaa !24
  store i64 %t177, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s9
  %t178 = load i64, ptr %l7, !tbaa !24
  %t179 = load i64, ptr %l6, !tbaa !24
  %t182 = icmp slt i64 %t178, %t179
  %t184 = xor i1 %t182, true
  br i1 %t184, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s9)
  br label %bb31
bb28:
  br label %bb29
bb29:
  %t186 = load i64, ptr %l3, !tbaa !24
  %t187 = load i64, ptr %l7, !tbaa !24
  %t188 = load i64, ptr %l5, !tbaa !24
  %t191 = mul i64 %t187, %t188
  %t194 = add i64 %t186, %t191
  store i64 %t194, ptr %l8, !tbaa !24
  %t196 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t196, ptr %l81, !tbaa !27
  %t197 = load i64, ptr %l8, !tbaa !24
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t198, i32 0, i32 0
  %t201 = load { i64, ptr }, ptr %t200, !tbaa !27
  store { i64, ptr } %t201, ptr %l84, !tbaa !27
  %t202 = load i64, ptr %l8, !tbaa !24
  %t204 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t205 = load ptr, ptr %t204, !tbaa !27
  %t206 = getelementptr { i64, ptr }, ptr %t205, i64 %t202
  %t207 = load { i64, ptr }, ptr %t206, !tbaa !37
  %t210 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t211 = load ptr, ptr %t210, !tbaa !27
  %t212 = getelementptr { i64, ptr }, ptr %t211, i64 %t197
  store { i64, ptr } %t207, ptr %t212, !tbaa !37
  call void @__olang_scope_close(ptr %s9)
  br label %bb30
bb30:
  %t213 = load i64, ptr %l7, !tbaa !24
  %t215 = add i64 %t213, 1
  store i64 %t215, ptr %l7, !tbaa !24
  br label %bb26
bb31:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t221 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t217, i32 0, i32 0
  store { i64, ptr } %t218, ptr %t221, !tbaa !27
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t222, i32 0, i32 0
  %t225 = load { i64, ptr }, ptr %t224, !tbaa !27
  store { i64, ptr } %t225, ptr %l92, !tbaa !27
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t226, i32 0, i32 3
  %t229 = load i64, ptr %t228, !tbaa !24
  store i64 %t229, ptr %l94, !tbaa !24
  %t230 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t233 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t231, i32 0, i32 3
  %t234 = load i64, ptr %t233, !tbaa !24
  store i64 %t234, ptr %l97, !tbaa !24
  %t236 = load i64, ptr %l97, !tbaa !24
  %t237 = load i64, ptr %l97, !tbaa !24
  %t238 = shl i64 %t230, %t237
  store i64 %t238, ptr %l98, !tbaa !24
  %t239 = load i8, ptr %l1, !tbaa !22
  store i8 %t239, ptr %l99, !tbaa !22
  %t240 = load i64, ptr %l98, !tbaa !24
  %t241 = icmp sge i64 %t240, 0
  br i1 %t241, label %bb34, label %bb35
bb34:
  %t243 = load i64, ptr %l98, !tbaa !24
  %t244 = mul i64 %t243, 1
  %t245 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t244)
  %t246 = load i8, ptr %l99, !tbaa !22
  store i64 0, ptr %t247
  br label %fill.248
fill.248:
  %t251 = load i64, ptr %t247
  %t252 = icmp slt i64 %t251, %t243
  br i1 %t252, label %fillb.249, label %filld.250
fillb.249:
  %t253 = getelementptr i8, ptr %t245, i64 %t251
  store i8 %t246, ptr %t253
  %t254 = add i64 %t251, 1
  store i64 %t254, ptr %t247
  br label %fill.248
filld.250:
  %t255 = insertvalue { i64, ptr } undef, i64 %t243, 0
  %t256 = insertvalue { i64, ptr } %t255, ptr %t245, 1
  %t258 = load i64, ptr %l94, !tbaa !24
  %t259 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t260 = load ptr, ptr %t259, !tbaa !27
  %t261 = getelementptr { i64, ptr }, ptr %t260, i64 %t258
  store { i64, ptr } %t256, ptr %t261, !tbaa !37
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t265 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t263, i32 0, i32 0
  %t266 = load { i64, ptr }, ptr %t265, !tbaa !27
  store { i64, ptr } %t266, ptr %l104, !tbaa !27
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t267, i32 0, i32 3
  %t270 = load i64, ptr %t269, !tbaa !24
  %t272 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !27
  %t274 = getelementptr { i64, ptr }, ptr %t273, i64 %t270
  %t275 = load { i64, ptr }, ptr %t274, !tbaa !37
  %t278 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t262, i32 0, i32 4
  store { i64, ptr } %t275, ptr %t278, !tbaa !27
  %t279 = load ptr, ptr %l0, !tbaa !29
  store ptr %t279, ptr %l108, !tbaa !29
  %t280 = load ptr, ptr %l108, !tbaa !29
  %t281 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t280, i32 0, i32 3
  %t282 = load i64, ptr %t281, !tbaa !24
  %t284 = add i64 %t282, 1
  %t286 = load ptr, ptr %l108, !tbaa !29
  %t287 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t286, i32 0, i32 3
  store i64 %t284, ptr %t287, !tbaa !24
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_4dc06d9077551cdf_2c6bce65fb6a75ab)
  unreachable
bb36:
  br label %bb37
bb37:
  %t288 = load ptr, ptr %l0, !tbaa !29
  store ptr %t288, ptr %l111, !tbaa !29
  %t289 = load ptr, ptr %l111, !tbaa !29
  %t290 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t289, i32 0, i32 2
  %t291 = load i64, ptr %t290, !tbaa !24
  %t293 = add i64 %t291, 1
  %t295 = load ptr, ptr %l111, !tbaa !29
  %t296 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t295, i32 0, i32 2
  store i64 %t293, ptr %t296, !tbaa !24
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t299 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t297, i32 0, i32 5
  store i64 0, ptr %t299, !tbaa !24
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t303 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t301, i32 0, i32 4
  %t304 = load { i64, ptr }, ptr %t303, !tbaa !27
  %t306 = extractvalue { i64, ptr } %t304, 0
  %t309 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t300, i32 0, i32 6
  store i64 %t306, ptr %t309, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cstd_2fprelude_2ftext_3aChar_3e_H31d3c0f1aa05014571ac02855217c1a3(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %a0, i64 %a1)
  ret { i64, ptr } %r
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2ector(ptr %v0) #0 {
entry:
  %l1 = alloca %"std/prelude/list:listState.9783095779ea18337775adeb6569839d"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3cstd_2fprelude_2ftext_3aChar_3e_2ector(ptr %v0)
  store %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %t1, ptr %l1
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %l1
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 88, i64 8)
  store %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %t2, ptr %t3
  %t6 = insertvalue %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" undef, ptr %t3, 0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3cstd_2fprelude_2ftext_3aChar_3e_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %rv = alloca %"std/prelude/list:listState.9783095779ea18337775adeb6569839d"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = icmp sge i64 0, 0
  br i1 %t1, label %bb1, label %bb2
bb1:
  %t3 = icmp sle i64 0, 576460752303423487
  br i1 %t3, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_6b4064a4db3c0e1a_ae9fabcb554ef13e)
  unreachable
bb3:
  %t5 = mul i64 0, 16
  %t6 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t5)
  %t7 = insertvalue { i64, ptr } undef, i64 0, 0
  %t8 = insertvalue { i64, ptr } %t7, ptr %t6, 1
  store { i64, ptr } %t8, ptr %l0, !tbaa !27
  %t10 = icmp sge i64 0, 0
  br i1 %t10, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_6b4064a4db3c0e1a_ae9fabcb554ef13e)
  unreachable
bb5:
  %t12 = mul i64 0, 1
  %t13 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 0, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  %t17 = icmp sge i64 0, 0
  br i1 %t17, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_8bf73551b96bdeef_865952527ff4c073)
  unreachable
bb7:
  %t19 = mul i64 0, 1
  %t20 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 0, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t24 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t25 = insertvalue %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" undef, { i64, ptr } %t24, 0
  %t26 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t27 = insertvalue %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %t25, { i64, ptr } %t26, 1
  %t28 = load i64, ptr %l2, !tbaa !24
  %t29 = insertvalue %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %t27, i64 %t28, 2
  %t30 = load i64, ptr %l3, !tbaa !24
  %t31 = insertvalue %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %t29, i64 %t30, 3
  %t33 = insertvalue %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %t31, { i64, ptr } %t22, 4
  %t35 = insertvalue %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %t33, i64 0, 5
  %t37 = insertvalue %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %t35, i64 0, 6
  %t39 = insertvalue %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %t37, i64 0, 7
  store %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %t39, ptr %rv
  br label %ret
bb8:
  call void @__olang_check_failed(ptr @olang_loc_bf019c573f3a88c_d9422507a3cea850)
  unreachable
ret:
  %rr = load %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %rv
  ret %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %rr
}

define dso_local i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l5 = alloca i64
  %rv = alloca i64
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = icmp slt i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l1, !tbaa !24
  store i64 %t7, ptr %l5, !tbaa !24
  br label %bb3
bb2:
  %t9 = load i64, ptr %l0, !tbaa !24
  store i64 %t9, ptr %l5, !tbaa !24
  br label %bb3
bb3:
  %t11 = load i64, ptr %l5, !tbaa !24
  store i64 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l3 = alloca i1
  %l6 = alloca i1
  %rv = alloca { i32, i64 }
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t3 = icmp ne i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l0, !tbaa !24
  %t7 = icmp slt i64 %t5, 2
  br i1 %t7, label %bb3, label %bb4
bb2:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb6
bb3:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb5
bb4:
  %t9 = load i64, ptr %l0, !tbaa !24
  %t11 = icmp sgt i64 %t9, 36
  store i1 %t11, ptr %l6, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l6, !tbaa !21
  store i1 %t13, ptr %l3, !tbaa !21
  br label %bb6
bb6:
  %t14 = load i1, ptr %l3, !tbaa !21
  br i1 %t14, label %bb7, label %bb8
bb7:
  %t16 = insertvalue { i32, i64 } zeroinitializer, i32 65537, 0
  store { i32, i64 } %t16, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t17 = load i64, ptr %l0, !tbaa !24
  %t18 = insertvalue { i32, i64 } zeroinitializer, i64 %t17, 1
  store { i32, i64 } %t18, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @__olang_check_failed(ptr)
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
@olang_loc_633bdd7e62b7da5c_1326dd696b8e1bc0 = external constant [0 x i8]
@olang_loc_3f899fc571d42529_c24733a4ca5f80ed = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2estd_2fprelude_2flist_2efirstChunk = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\08\00\00\00\00\00\00\00" }>, align 8
@olang_loc_6945ad779c7e7f7c_aa454bb08a1e6148 = external constant [0 x i8]
@olang_loc_705f0c942e068bc9_811d7cacde790eb5 = external constant [0 x i8]
@olang_loc_eae9d5df37060f0a_8a452e5dcec4c596 = external constant [0 x i8]
@olang_loc_4dc06d9077551cdf_2c6bce65fb6a75ab = external constant [0 x i8]
@olang_loc_6b4064a4db3c0e1a_ae9fabcb554ef13e = external constant [0 x i8]
@olang_loc_8bf73551b96bdeef_865952527ff4c073 = external constant [0 x i8]
@olang_loc_bf019c573f3a88c_d9422507a3cea850 = external constant [0 x i8]

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
