; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_3f700dbf9799aae8_c678d751cb1ed234 = weak_odr constant [55 x i8] c"std/prelude/list.olang:516: slice bounds out of range\0A\00"
@olang_loc_b14b618956096383_af42a567f1c6d96f = weak_odr constant [55 x i8] c"std/prelude/list.olang:522: slice bounds out of range\0A\00"
@olang_loc_c64e4849e339cb26_210c4852a1b2f3f2 = weak_odr constant [55 x i8] c"std/prelude/list.olang:523: slice bounds out of range\0A\00"
