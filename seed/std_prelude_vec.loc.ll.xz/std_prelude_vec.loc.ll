; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_5461083e20419ecf_ec056c5ee939d7f3 = weak_odr constant [54 x i8] c"std/prelude/vec.olang:225: slice bounds out of range\0A\00"
@olang_loc_5f30745f6a2e2524_5e91c024f183fd8 = weak_odr constant [54 x i8] c"std/prelude/vec.olang:231: array length out of range\0A\00"
