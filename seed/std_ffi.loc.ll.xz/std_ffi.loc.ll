; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_693223463d286ace_cb376d1b1db73152 = weak_odr constant [39 x i8] c"std/ffi.olang:68: unreachable reached\0A\00"
@olang_loc_8abc9384c4eef1e5_cd004ffb84c268d1 = weak_odr constant [46 x i8] c"std/ffi.olang:101: array length out of range\0A\00"
@olang_loc_d3c1ac7fefda45a1_f7bbef25d0ad212d = weak_odr constant [39 x i8] c"std/ffi.olang:47: unreachable reached\0A\00"
@olang_loc_ff20c9fa943c3ec7_a348c6c6ec1ff0ab = weak_odr constant [40 x i8] c"std/ffi.olang:105: unreachable reached\0A\00"
