; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_8abc9384c4eef1e5_cd004ffb84c268d1 = weak_odr constant [45 x i8] c"std/ffi.olang:97: array length out of range\0A\00"
@olang_loc_d3c1ac7fefda45a1_f7bbef25d0ad212d = weak_odr constant [39 x i8] c"std/ffi.olang:43: unreachable reached\0A\00"
