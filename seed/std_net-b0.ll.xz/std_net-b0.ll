; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/net:Addr" = type { %"std/net:IP", i16 }
%"std/net:IP" = type { i1, [16 x i8] }
%"std/net:Conn" = type { i32 }
%"std/net:Listener" = type { i32 }
%"std/net:UDP" = type { i32 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"<netdb.h>:addrinfo" = type { i32, i32, i32, i32, i32, ptr, ptr, ptr }
%"<poll.h>:pollfd" = type { i32, i16, i16 }
define dso_local { i32, %"std/net:Addr" } @std_2fnet_2eAddr_2eResolve(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, i64 }
  %l3 = alloca i64
  %l5 = alloca { i64, ptr }
  %l9 = alloca i1
  %l10 = alloca { i64, ptr }
  %l13 = alloca %"std/net:Addr"
  %l15 = alloca %"std/net:Addr"
  %l16 = alloca i32
  %l18 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i32
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, [2 x i64] }
  %l27 = alloca i64
  %l29 = alloca { i64, [2 x i64] }
  %l32 = alloca { i64, i64 }
  %l36 = alloca { i64, i64 }
  %l37 = alloca i32
  %l39 = alloca i1
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca { i64, ptr }
  %l44 = alloca { i64, [2 x i64] }
  %l45 = alloca i64
  %l47 = alloca { i64, [2 x i64] }
  %l57 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca { i64, ptr }
  %l60 = alloca { i64, [2 x i64] }
  %l61 = alloca i64
  %l63 = alloca { i64, [2 x i64] }
  %l66 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l68 = alloca i64
  %l69 = alloca i64
  %l74 = alloca { i64, ptr }
  %l75 = alloca i32
  %l80 = alloca %"std/net:Addr"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i32, %"std/net:Addr" }
  %t60 = alloca { i64, [2 x i64] }, align 8
  %t111 = alloca { i64, [2 x i64] }, align 8
  %t160 = alloca { i64, [2 x i64] }, align 8
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp sgt i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t7, ptr %l10, !tbaa !27
  %t8 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !27
  %t10 = getelementptr i8, ptr %t9, i64 0
  %t11 = load i8, ptr %t10, !tbaa !32
  %t13 = icmp eq i8 %t11, 91
  store i1 %t13, ptr %l9, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l9, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  %t16 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t18 = call { i32, %"std/net:Addr" } @std_2fnet_2eAddr_2eParse(ptr %v0, { i64, ptr } %t16)
  %t19 = extractvalue { i32, %"std/net:Addr" } %t18, 1
  %t20 = extractvalue { i32, %"std/net:Addr" } %t18, 0
  store i32 %t20, ptr %l16
  %t21 = icmp ne i32 %t20, 0
  br i1 %t21, label %bb7, label %ok.22, !prof !99
ok.22:
  store %"std/net:Addr" %t19, ptr %l15
  br label %bb6
bb5:
  br label %bb9
bb6:
  %t23 = load %"std/net:Addr", ptr %l15
  store %"std/net:Addr" %t23, ptr %l13
  br label %bb8
bb7:
  %t24 = load i32, ptr %l16, !tbaa !23
  %t25 = lshr i32 %t24, 16
  %t26 = and i32 %t24, 65535
  %t27 = icmp eq i32 %t25, 1
  %t28 = select i1 %t27, i32 1, i32 0
  %t29 = icmp eq i32 %t24, 0
  %t30 = shl i32 %t28, 16
  %t31 = or i32 %t30, %t26
  %t32 = select i1 %t29, i32 0, i32 %t31
  call void @__olang_scope_close(ptr %s0)
  %t34 = insertvalue { i32, %"std/net:Addr" } zeroinitializer, i32 %t32, 0
  store { i32, %"std/net:Addr" } %t34, ptr %rv
  br label %ret
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t35 = load %"std/net:Addr", ptr %l13
  %t36 = insertvalue { i32, %"std/net:Addr" } zeroinitializer, %"std/net:Addr" %t35, 1
  store { i32, %"std/net:Addr" } %t36, ptr %rv
  br label %ret
bb9:
  %t37 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t39 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %s0, { i64, ptr } %t37, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) })
  %t40 = extractvalue { i32, i64 } %t39, 1
  %t41 = extractvalue { i32, i64 } %t39, 0
  store i32 %t41, ptr %l21
  %t42 = icmp ne i32 %t41, 0
  br i1 %t42, label %bb11, label %ok.43, !prof !99
ok.43:
  store i64 %t40, ptr %l20
  br label %bb10
bb10:
  %t44 = load i64, ptr %l20, !tbaa !24
  store i64 %t44, ptr %l18, !tbaa !24
  br label %bb14
bb11:
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t45 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t45, ptr %l23, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t47, 0
  store i64 %t48, ptr %l24, !tbaa !24
  %t49 = load i64, ptr %l24, !tbaa !24
  %t50 = mul i64 %t49, 1
  %t51 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t50)
  %t52 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t51, 1
  store { i64, ptr } %t53, ptr %l25, !tbaa !27
  %t54 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = load i64, ptr %l24, !tbaa !24
  %t59 = mul i64 %t58, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t55, ptr %t57, i64 %t59, i1 false)
  store { i64, [2 x i64] } zeroinitializer, ptr %t60
  %t61 = getelementptr { i64, [2 x i64] }, ptr %t60, i32 0, i32 0
  store i64 5, ptr %t61
  %t62 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t63 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t62, 0
  %t64 = getelementptr { i64, [2 x i64] }, ptr %t60, i32 0, i32 1
  store { { i64, ptr } } %t63, ptr %t64
  %t65 = load { i64, [2 x i64] }, ptr %t60
  store { i64, [2 x i64] } %t65, ptr %l26
  %t66 = call ptr @__olang_errpay_push()
  %t67 = ptrtoint ptr %t66 to i64
  store i64 %t67, ptr %l27, !tbaa !24
  %t68 = load i64, ptr %l27
  %t69 = inttoptr i64 %t68 to ptr
  %t71 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fnet_3aError_24payload(ptr %t69, ptr %l26)
  store { i64, [2 x i64] } %t71, ptr %l29
  br label %bb13
bb13:
  %t72 = load { i64, [2 x i64] }, ptr %l29
  %t73 = load i64, ptr %l27
  %t74 = inttoptr i64 %t73 to ptr
  %t75 = call ptr @__olang_scope_alloc_a(ptr %t74, i64 24, i64 8)
  store { i64, [2 x i64] } %t72, ptr %t75
  call void @__olang_errpay_set(ptr %t75)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t78 = insertvalue { i32, %"std/net:Addr" } zeroinitializer, i32 65541, 0
  store { i32, %"std/net:Addr" } %t78, ptr %rv
  br label %ret
bb14:
  %t79 = load i64, ptr %l18, !tbaa !24
  store i64 %t79, ptr %l1, !tbaa !24
  %t80 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t81 = load i64, ptr %l1, !tbaa !24
  %t83 = add i64 %t81, 1
  %t86 = call { i32, { i64, i64 } } @std_2fnet_2edecimalAt(ptr %v0, { i64, ptr } %t80, i64 %t83, i64 65535)
  %t87 = extractvalue { i32, { i64, i64 } } %t86, 1
  %t88 = extractvalue { i32, { i64, i64 } } %t86, 0
  store i32 %t88, ptr %l37
  %t89 = icmp ne i32 %t88, 0
  br i1 %t89, label %bb16, label %ok.90, !prof !99
ok.90:
  store { i64, i64 } %t87, ptr %l36
  br label %bb15
bb15:
  %t91 = load { i64, i64 }, ptr %l36
  store { i64, i64 } %t91, ptr %l32
  br label %bb19
bb16:
  %t92 = load i32, ptr %l37, !tbaa !23
  %t93 = ashr i32 %t92, 16
  %t95 = icmp eq i32 %t93, 1
  store i1 %t95, ptr %l39, !tbaa !21
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t96 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t96, ptr %l41, !tbaa !27
  %t98 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t98, 0
  store i64 %t99, ptr %l42, !tbaa !24
  %t100 = load i64, ptr %l42, !tbaa !24
  %t101 = mul i64 %t100, 1
  %t102 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t101)
  %t103 = insertvalue { i64, ptr } undef, i64 %t100, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t102, 1
  store { i64, ptr } %t104, ptr %l43, !tbaa !27
  %t105 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = load i64, ptr %l42, !tbaa !24
  %t110 = mul i64 %t109, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t106, ptr %t108, i64 %t110, i1 false)
  store { i64, [2 x i64] } zeroinitializer, ptr %t111
  %t112 = getelementptr { i64, [2 x i64] }, ptr %t111, i32 0, i32 0
  store i64 5, ptr %t112
  %t113 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t114 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t113, 0
  %t115 = getelementptr { i64, [2 x i64] }, ptr %t111, i32 0, i32 1
  store { { i64, ptr } } %t114, ptr %t115
  %t116 = load { i64, [2 x i64] }, ptr %t111
  store { i64, [2 x i64] } %t116, ptr %l44
  %t117 = call ptr @__olang_errpay_push()
  %t118 = ptrtoint ptr %t117 to i64
  store i64 %t118, ptr %l45, !tbaa !24
  %t119 = load i64, ptr %l45
  %t120 = inttoptr i64 %t119 to ptr
  %t122 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fnet_3aError_24payload(ptr %t120, ptr %l44)
  store { i64, [2 x i64] } %t122, ptr %l47
  br label %bb18
bb18:
  %t123 = load { i64, [2 x i64] }, ptr %l47
  %t124 = load i64, ptr %l45
  %t125 = inttoptr i64 %t124 to ptr
  %t126 = call ptr @__olang_scope_alloc_a(ptr %t125, i64 24, i64 8)
  store { i64, [2 x i64] } %t123, ptr %t126
  call void @__olang_errpay_set(ptr %t126)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t129 = insertvalue { i32, %"std/net:Addr" } zeroinitializer, i32 65541, 0
  store { i32, %"std/net:Addr" } %t129, ptr %rv
  br label %ret
bb19:
  %t130 = load { i64, i64 }, ptr %l32
  store { i64, i64 } %t130, ptr %l2
  %t131 = getelementptr { i64, i64 }, ptr %l2, i32 0, i32 0
  %t132 = load i64, ptr %t131, !tbaa !24
  store i64 %t132, ptr %l3, !tbaa !24
  %t134 = getelementptr { i64, i64 }, ptr %l2, i32 0, i32 1
  %t135 = load i64, ptr %t134, !tbaa !24
  %t138 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t138, 0
  %t143 = icmp ne i64 %t135, %t140
  br i1 %t143, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s4
  %t145 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t145, ptr %l57, !tbaa !27
  %t147 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t147, 0
  store i64 %t148, ptr %l58, !tbaa !24
  %t149 = load i64, ptr %l58, !tbaa !24
  %t150 = mul i64 %t149, 1
  %t151 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t150)
  %t152 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr %t151, 1
  store { i64, ptr } %t153, ptr %l59, !tbaa !27
  %t154 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !27
  %t158 = load i64, ptr %l58, !tbaa !24
  %t159 = mul i64 %t158, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t155, ptr %t157, i64 %t159, i1 false)
  store { i64, [2 x i64] } zeroinitializer, ptr %t160
  %t161 = getelementptr { i64, [2 x i64] }, ptr %t160, i32 0, i32 0
  store i64 5, ptr %t161
  %t162 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t163 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t162, 0
  %t164 = getelementptr { i64, [2 x i64] }, ptr %t160, i32 0, i32 1
  store { { i64, ptr } } %t163, ptr %t164
  %t165 = load { i64, [2 x i64] }, ptr %t160
  store { i64, [2 x i64] } %t165, ptr %l60
  %t166 = call ptr @__olang_errpay_push()
  %t167 = ptrtoint ptr %t166 to i64
  store i64 %t167, ptr %l61, !tbaa !24
  %t168 = load i64, ptr %l61
  %t169 = inttoptr i64 %t168 to ptr
  %t171 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fnet_3aError_24payload(ptr %t169, ptr %l60)
  store { i64, [2 x i64] } %t171, ptr %l63
  br label %bb22
bb21:
  br label %bb23
bb22:
  %t172 = load { i64, [2 x i64] }, ptr %l63
  %t173 = load i64, ptr %l61
  %t174 = inttoptr i64 %t173 to ptr
  %t175 = call ptr @__olang_scope_alloc_a(ptr %t174, i64 24, i64 8)
  store { i64, [2 x i64] } %t172, ptr %t175
  call void @__olang_errpay_set(ptr %t175)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t178 = insertvalue { i32, %"std/net:Addr" } zeroinitializer, i32 65541, 0
  store { i32, %"std/net:Addr" } %t178, ptr %rv
  br label %ret
bb23:
  %t179 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t179, ptr %l67, !tbaa !27
  %t180 = load i64, ptr %l1, !tbaa !24
  store i64 %t180, ptr %l68, !tbaa !24
  %t181 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t181, 0
  store i64 %t182, ptr %l69, !tbaa !24
  %t183 = icmp sge i64 0, 0
  br i1 %t183, label %bb24, label %bb25
bb24:
  %t185 = load i64, ptr %l68, !tbaa !24
  %t186 = icmp sle i64 0, %t185
  br i1 %t186, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_f1d1c13cf3902f30_d152dc4ae276584)
  unreachable
bb26:
  %t188 = load i64, ptr %l68, !tbaa !24
  %t189 = load i64, ptr %l69, !tbaa !24
  %t190 = icmp sle i64 %t188, %t189
  br i1 %t190, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_f1d1c13cf3902f30_d152dc4ae276584)
  unreachable
bb28:
  %t192 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t194 = load i64, ptr %l68, !tbaa !24
  %t195 = getelementptr i8, ptr %t193, i64 0
  %t196 = sub i64 %t194, 0
  %t197 = insertvalue { i64, ptr } undef, i64 %t196, 0
  %t198 = insertvalue { i64, ptr } %t197, ptr %t195, 1
  %t200 = call { i32, { i64, ptr } } @std_2fnet_2eLookup(ptr %v0, ptr %s0, { i64, ptr } %t198)
  %t201 = extractvalue { i32, { i64, ptr } } %t200, 1
  %t202 = extractvalue { i32, { i64, ptr } } %t200, 0
  store i32 %t202, ptr %l75
  %t203 = icmp ne i32 %t202, 0
  br i1 %t203, label %bb31, label %ok.204, !prof !99
ok.204:
  store { i64, ptr } %t201, ptr %l74
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_f1d1c13cf3902f30_d152dc4ae276584)
  unreachable
bb30:
  %t205 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t205, ptr %l66, !tbaa !27
  br label %bb32
bb31:
  %t206 = load i32, ptr %l75, !tbaa !23
  %t207 = lshr i32 %t206, 16
  %t208 = and i32 %t206, 65535
  %t209 = icmp eq i32 %t207, 1
  %t210 = select i1 %t209, i32 1, i32 0
  %t211 = icmp eq i32 %t206, 0
  %t212 = shl i32 %t210, 16
  %t213 = or i32 %t212, %t208
  %t214 = select i1 %t211, i32 0, i32 %t213
  call void @__olang_scope_close(ptr %s0)
  %t216 = insertvalue { i32, %"std/net:Addr" } zeroinitializer, i32 %t214, 0
  store { i32, %"std/net:Addr" } %t216, ptr %rv
  br label %ret
bb32:
  %t217 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t217, ptr %l5, !tbaa !27
  %t218 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t219 = load ptr, ptr %t218, !tbaa !27
  %t220 = getelementptr %"std/net:IP", ptr %t219, i64 0
  %t221 = load %"std/net:IP", ptr %t220
  %t222 = load i64, ptr %l3, !tbaa !24
  %t224 = trunc i64 %t222 to i16
  %t227 = call %"std/net:Addr" @std_2fnet_3aAddr_2ector(ptr %s0, %"std/net:IP" %t221, i16 %t224)
  store %"std/net:Addr" %t227, ptr %l80
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s0)
  %t228 = load %"std/net:Addr", ptr %l80
  %t229 = insertvalue { i32, %"std/net:Addr" } zeroinitializer, %"std/net:Addr" %t228, 1
  store { i32, %"std/net:Addr" } %t229, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/net:Addr" }, ptr %rv
  ret { i32, %"std/net:Addr" } %rr
}

define dso_local { i32, %"std/net:Addr" } @std_2fnet_2eAddr_2ehostPort(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca %"std/net:IP"
  %l3 = alloca { i64, i64 }
  %l4 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"std/net:IP"
  %l8 = alloca { i64, i64 }
  %l9 = alloca i64
  %l14 = alloca i1
  %l15 = alloca { i64, ptr }
  %l18 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i32
  %l29 = alloca i1
  %l30 = alloca { i64, ptr }
  %l36 = alloca %"std/net:IP"
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca i64
  %l44 = alloca %"std/net:IP"
  %l45 = alloca i32
  %l47 = alloca { i64, i64 }
  %l51 = alloca { i64, i64 }
  %l52 = alloca i32
  %l64 = alloca %"std/net:Addr"
  %l65 = alloca i64
  %l67 = alloca i64
  %l68 = alloca i32
  %l70 = alloca %"std/net:IP"
  %l71 = alloca { i64, ptr }
  %l72 = alloca i64
  %l73 = alloca i64
  %l78 = alloca %"std/net:IP"
  %l79 = alloca i32
  %l87 = alloca { i64, i64 }
  %l91 = alloca { i64, i64 }
  %l92 = alloca i32
  %l104 = alloca %"std/net:Addr"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i32, %"std/net:Addr" }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp sgt i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t7, ptr %l15, !tbaa !27
  %t8 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !27
  %t10 = getelementptr i8, ptr %t9, i64 0
  %t11 = load i8, ptr %t10, !tbaa !32
  %t13 = icmp eq i8 %t11, 91
  store i1 %t13, ptr %l14, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l14, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t19 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %t16, i8 93)
  %t20 = extractvalue { i32, i64 } %t19, 1
  %t21 = extractvalue { i32, i64 } %t19, 0
  store i32 %t21, ptr %l22
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb7, label %ok.23, !prof !99
ok.23:
  store i64 %t20, ptr %l21
  br label %bb6
bb5:
  br label %bb32
bb6:
  %t24 = load i64, ptr %l21, !tbaa !24
  store i64 %t24, ptr %l18, !tbaa !24
  br label %bb9
bb7:
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t26 = insertvalue { i32, %"std/net:Addr" } zeroinitializer, i32 65536, 0
  store { i32, %"std/net:Addr" } %t26, ptr %rv
  br label %ret
bb9:
  %t27 = load i64, ptr %l18, !tbaa !24
  store i64 %t27, ptr %l1, !tbaa !24
  %t28 = load i64, ptr %l1, !tbaa !24
  %t30 = add i64 %t28, 1
  %t31 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t36 = icmp sge i64 %t30, %t33
  br i1 %t36, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb12
bb11:
  %t38 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t38, ptr %l30, !tbaa !27
  %t39 = load i64, ptr %l1, !tbaa !24
  %t41 = add i64 %t39, 1
  %t43 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr i8, ptr %t44, i64 %t41
  %t46 = load i8, ptr %t45, !tbaa !32
  %t48 = icmp ne i8 %t46, 58
  store i1 %t48, ptr %l29, !tbaa !21
  br label %bb12
bb12:
  %t50 = load i1, ptr %l29, !tbaa !21
  br i1 %t50, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t52 = insertvalue { i32, %"std/net:Addr" } zeroinitializer, i32 65536, 0
  store { i32, %"std/net:Addr" } %t52, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t53 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t53, ptr %l37, !tbaa !27
  %t54 = load i64, ptr %l1, !tbaa !24
  store i64 %t54, ptr %l38, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 0
  store i64 %t56, ptr %l39, !tbaa !24
  %t57 = icmp sge i64 1, 0
  br i1 %t57, label %bb16, label %bb17
bb16:
  %t59 = load i64, ptr %l38, !tbaa !24
  %t60 = icmp sle i64 1, %t59
  br i1 %t60, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_7b75bbc114d81c9_eaa9ae6a6f8e790d)
  unreachable
bb18:
  %t62 = load i64, ptr %l38, !tbaa !24
  %t63 = load i64, ptr %l39, !tbaa !24
  %t64 = icmp sle i64 %t62, %t63
  br i1 %t64, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_7b75bbc114d81c9_eaa9ae6a6f8e790d)
  unreachable
bb20:
  %t66 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = load i64, ptr %l38, !tbaa !24
  %t69 = getelementptr i8, ptr %t67, i64 1
  %t70 = sub i64 %t68, 1
  %t71 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t69, 1
  %t74 = call { i32, %"std/net:IP" } @std_2fnet_2eIP_2eparse6(ptr %v0, { i64, ptr } %t72)
  %t75 = extractvalue { i32, %"std/net:IP" } %t74, 1
  %t76 = extractvalue { i32, %"std/net:IP" } %t74, 0
  store i32 %t76, ptr %l45
  %t77 = icmp ne i32 %t76, 0
  br i1 %t77, label %bb23, label %ok.78, !prof !99
ok.78:
  store %"std/net:IP" %t75, ptr %l44
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_7b75bbc114d81c9_eaa9ae6a6f8e790d)
  unreachable
bb22:
  %t79 = load %"std/net:IP", ptr %l44
  store %"std/net:IP" %t79, ptr %l36
  br label %bb24
bb23:
  %t80 = load i32, ptr %l45, !tbaa !23
  %t81 = lshr i32 %t80, 16
  %t82 = and i32 %t80, 65535
  %t83 = icmp eq i32 %t81, 1
  %t84 = select i1 %t83, i32 1, i32 0
  %t85 = icmp eq i32 %t80, 0
  %t86 = shl i32 %t84, 16
  %t87 = or i32 %t86, %t82
  %t88 = select i1 %t85, i32 0, i32 %t87
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t90 = insertvalue { i32, %"std/net:Addr" } zeroinitializer, i32 %t88, 0
  store { i32, %"std/net:Addr" } %t90, ptr %rv
  br label %ret
bb24:
  %t91 = load %"std/net:IP", ptr %l36
  store %"std/net:IP" %t91, ptr %l2
  %t92 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t93 = load i64, ptr %l1, !tbaa !24
  %t95 = add i64 %t93, 2
  %t98 = call { i32, { i64, i64 } } @std_2fnet_2edecimalAt(ptr %v0, { i64, ptr } %t92, i64 %t95, i64 65535)
  %t99 = extractvalue { i32, { i64, i64 } } %t98, 1
  %t100 = extractvalue { i32, { i64, i64 } } %t98, 0
  store i32 %t100, ptr %l52
  %t101 = icmp ne i32 %t100, 0
  br i1 %t101, label %bb26, label %ok.102, !prof !99
ok.102:
  store { i64, i64 } %t99, ptr %l51
  br label %bb25
bb25:
  %t103 = load { i64, i64 }, ptr %l51
  store { i64, i64 } %t103, ptr %l47
  br label %bb27
bb26:
  %t104 = load i32, ptr %l52, !tbaa !23
  %t105 = lshr i32 %t104, 16
  %t106 = and i32 %t104, 65535
  %t107 = icmp eq i32 %t105, 1
  %t108 = select i1 %t107, i32 1, i32 0
  %t109 = icmp eq i32 %t104, 0
  %t110 = shl i32 %t108, 16
  %t111 = or i32 %t110, %t106
  %t112 = select i1 %t109, i32 0, i32 %t111
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t114 = insertvalue { i32, %"std/net:Addr" } zeroinitializer, i32 %t112, 0
  store { i32, %"std/net:Addr" } %t114, ptr %rv
  br label %ret
bb27:
  %t115 = load { i64, i64 }, ptr %l47
  store { i64, i64 } %t115, ptr %l3
  %t116 = getelementptr { i64, i64 }, ptr %l3, i32 0, i32 0
  %t117 = load i64, ptr %t116, !tbaa !24
  store i64 %t117, ptr %l4, !tbaa !24
  %t119 = getelementptr { i64, i64 }, ptr %l3, i32 0, i32 1
  %t120 = load i64, ptr %t119, !tbaa !24
  %t123 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t123, 0
  %t128 = icmp ne i64 %t120, %t125
  br i1 %t128, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t131 = insertvalue { i32, %"std/net:Addr" } zeroinitializer, i32 65536, 0
  store { i32, %"std/net:Addr" } %t131, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t132 = load %"std/net:IP", ptr %l2
  %t133 = load i64, ptr %l4, !tbaa !24
  %t135 = trunc i64 %t133 to i16
  %t138 = call %"std/net:Addr" @std_2fnet_3aAddr_2ector(ptr %s1, %"std/net:IP" %t132, i16 %t135)
  store %"std/net:Addr" %t138, ptr %l64
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t139 = load %"std/net:Addr", ptr %l64
  %t140 = insertvalue { i32, %"std/net:Addr" } zeroinitializer, %"std/net:Addr" %t139, 1
  store { i32, %"std/net:Addr" } %t140, ptr %rv
  br label %ret
bb32:
  %t141 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t143 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %s0, { i64, ptr } %t141, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) })
  %t144 = extractvalue { i32, i64 } %t143, 1
  %t145 = extractvalue { i32, i64 } %t143, 0
  store i32 %t145, ptr %l68
  %t146 = icmp ne i32 %t145, 0
  br i1 %t146, label %bb34, label %ok.147, !prof !99
ok.147:
  store i64 %t144, ptr %l67
  br label %bb33
bb33:
  %t148 = load i64, ptr %l67, !tbaa !24
  store i64 %t148, ptr %l65, !tbaa !24
  br label %bb36
bb34:
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s0)
  %t150 = insertvalue { i32, %"std/net:Addr" } zeroinitializer, i32 65536, 0
  store { i32, %"std/net:Addr" } %t150, ptr %rv
  br label %ret
bb36:
  %t151 = load i64, ptr %l65, !tbaa !24
  store i64 %t151, ptr %l6, !tbaa !24
  %t152 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t152, ptr %l71, !tbaa !27
  %t153 = load i64, ptr %l6, !tbaa !24
  store i64 %t153, ptr %l72, !tbaa !24
  %t154 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t154, 0
  store i64 %t155, ptr %l73, !tbaa !24
  %t156 = icmp sge i64 0, 0
  br i1 %t156, label %bb37, label %bb38
bb37:
  %t158 = load i64, ptr %l72, !tbaa !24
  %t159 = icmp sle i64 0, %t158
  br i1 %t159, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_890a129ff0c26c5c_548b75716a348c30)
  unreachable
bb39:
  %t161 = load i64, ptr %l72, !tbaa !24
  %t162 = load i64, ptr %l73, !tbaa !24
  %t163 = icmp sle i64 %t161, %t162
  br i1 %t163, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_890a129ff0c26c5c_548b75716a348c30)
  unreachable
bb41:
  %t165 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !27
  %t167 = load i64, ptr %l72, !tbaa !24
  %t168 = getelementptr i8, ptr %t166, i64 0
  %t169 = sub i64 %t167, 0
  %t170 = insertvalue { i64, ptr } undef, i64 %t169, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr %t168, 1
  %t173 = call { i32, %"std/net:IP" } @std_2fnet_2eIP_2eParse(ptr %v0, { i64, ptr } %t171)
  %t174 = extractvalue { i32, %"std/net:IP" } %t173, 1
  %t175 = extractvalue { i32, %"std/net:IP" } %t173, 0
  store i32 %t175, ptr %l79
  %t176 = icmp ne i32 %t175, 0
  br i1 %t176, label %bb44, label %ok.177, !prof !99
ok.177:
  store %"std/net:IP" %t174, ptr %l78
  br label %bb43
bb42:
  call void @__olang_check_failed(ptr @olang_loc_890a129ff0c26c5c_548b75716a348c30)
  unreachable
bb43:
  %t178 = load %"std/net:IP", ptr %l78
  store %"std/net:IP" %t178, ptr %l70
  br label %bb50
bb44:
  %t179 = load i32, ptr %l79, !tbaa !23
  %t180 = icmp eq i32 %t179, 65541
  br i1 %t180, label %bb45, label %bb46
bb45:
  %t182 = load i32, ptr %l79, !tbaa !23
  %t183 = ashr i32 %t182, 16
  %t185 = icmp eq i32 %t183, 1
  br i1 %t185, label %bb47, label %bb48
bb46:
  %t187 = load i32, ptr %l79, !tbaa !23
  %t188 = lshr i32 %t187, 16
  %t189 = and i32 %t187, 65535
  %t190 = icmp eq i32 %t188, 1
  %t191 = select i1 %t190, i32 0, i32 0
  %t192 = icmp eq i32 %t187, 0
  %t193 = shl i32 %t191, 16
  %t194 = or i32 %t193, %t189
  %t195 = select i1 %t192, i32 0, i32 %t194
  call void @__olang_scope_close(ptr %s0)
  %t197 = insertvalue { i32, %"std/net:Addr" } zeroinitializer, i32 %t195, 0
  store { i32, %"std/net:Addr" } %t197, ptr %rv
  br label %ret
bb47:
  call void @__olang_errpay_pop()
  br label %bb48
bb48:
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s0)
  %t199 = insertvalue { i32, %"std/net:Addr" } zeroinitializer, i32 65536, 0
  store { i32, %"std/net:Addr" } %t199, ptr %rv
  br label %ret
bb50:
  %t200 = load %"std/net:IP", ptr %l70
  store %"std/net:IP" %t200, ptr %l7
  %t201 = getelementptr %"std/net:IP", ptr %l7, i32 0, i32 0
  %t202 = load i1, ptr %t201, !tbaa !21
  br i1 %t202, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s0)
  %t205 = insertvalue { i32, %"std/net:Addr" } zeroinitializer, i32 65536, 0
  store { i32, %"std/net:Addr" } %t205, ptr %rv
  br label %ret
bb52:
  br label %bb53
bb53:
  %t206 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t207 = load i64, ptr %l6, !tbaa !24
  %t209 = add i64 %t207, 1
  %t212 = call { i32, { i64, i64 } } @std_2fnet_2edecimalAt(ptr %v0, { i64, ptr } %t206, i64 %t209, i64 65535)
  %t213 = extractvalue { i32, { i64, i64 } } %t212, 1
  %t214 = extractvalue { i32, { i64, i64 } } %t212, 0
  store i32 %t214, ptr %l92
  %t215 = icmp ne i32 %t214, 0
  br i1 %t215, label %bb55, label %ok.216, !prof !99
ok.216:
  store { i64, i64 } %t213, ptr %l91
  br label %bb54
bb54:
  %t217 = load { i64, i64 }, ptr %l91
  store { i64, i64 } %t217, ptr %l87
  br label %bb56
bb55:
  %t218 = load i32, ptr %l92, !tbaa !23
  %t219 = lshr i32 %t218, 16
  %t220 = and i32 %t218, 65535
  %t221 = icmp eq i32 %t219, 1
  %t222 = select i1 %t221, i32 1, i32 0
  %t223 = icmp eq i32 %t218, 0
  %t224 = shl i32 %t222, 16
  %t225 = or i32 %t224, %t220
  %t226 = select i1 %t223, i32 0, i32 %t225
  call void @__olang_scope_close(ptr %s0)
  %t228 = insertvalue { i32, %"std/net:Addr" } zeroinitializer, i32 %t226, 0
  store { i32, %"std/net:Addr" } %t228, ptr %rv
  br label %ret
bb56:
  %t229 = load { i64, i64 }, ptr %l87
  store { i64, i64 } %t229, ptr %l8
  %t230 = getelementptr { i64, i64 }, ptr %l8, i32 0, i32 0
  %t231 = load i64, ptr %t230, !tbaa !24
  store i64 %t231, ptr %l9, !tbaa !24
  %t233 = getelementptr { i64, i64 }, ptr %l8, i32 0, i32 1
  %t234 = load i64, ptr %t233, !tbaa !24
  %t237 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t239 = extractvalue { i64, ptr } %t237, 0
  %t242 = icmp ne i64 %t234, %t239
  br i1 %t242, label %bb57, label %bb58
bb57:
  call void @__olang_scope_close(ptr %s0)
  %t245 = insertvalue { i32, %"std/net:Addr" } zeroinitializer, i32 65536, 0
  store { i32, %"std/net:Addr" } %t245, ptr %rv
  br label %ret
bb58:
  br label %bb59
bb59:
  %t246 = load %"std/net:IP", ptr %l7
  %t247 = load i64, ptr %l9, !tbaa !24
  %t249 = trunc i64 %t247 to i16
  %t252 = call %"std/net:Addr" @std_2fnet_3aAddr_2ector(ptr %s0, %"std/net:IP" %t246, i16 %t249)
  store %"std/net:Addr" %t252, ptr %l104
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s0)
  %t253 = load %"std/net:Addr", ptr %l104
  %t254 = insertvalue { i32, %"std/net:Addr" } zeroinitializer, %"std/net:Addr" %t253, 1
  store { i32, %"std/net:Addr" } %t254, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/net:Addr" }, ptr %rv
  ret { i32, %"std/net:Addr" } %rr
}

define dso_local { i32, %"std/net:Conn" } @std_2fnet_2eConn_2eDial(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l11 = alloca { i64, ptr }
  %l14 = alloca i32
  %l16 = alloca i32
  %l18 = alloca i32
  %l19 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l22 = alloca i32
  %l25 = alloca %"std/net:Conn"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %rv = alloca { i32, %"std/net:Conn" }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr @G_2estd_2fnet_2esockStream, !tbaa !23
  %t5 = call { i32, i32 } @std_2fnet_2eopen(ptr %v0, ptr %t1, i32 %t2)
  %t6 = extractvalue { i32, i32 } %t5, 1
  %t7 = extractvalue { i32, i32 } %t5, 0
  store i32 %t7, ptr %l8
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9, !prof !99
ok.9:
  store i32 %t6, ptr %l7
  br label %bb1
bb1:
  %t10 = load i32, ptr %l7, !tbaa !23
  store i32 %t10, ptr %l4, !tbaa !23
  br label %bb3
bb2:
  %t11 = load i32, ptr %l8, !tbaa !23
  %t12 = lshr i32 %t11, 16
  %t13 = and i32 %t11, 65535
  %t14 = icmp eq i32 %t12, 1
  %t15 = select i1 %t14, i32 1, i32 0
  %t16 = icmp eq i32 %t11, 0
  %t17 = shl i32 %t15, 16
  %t18 = or i32 %t17, %t13
  %t19 = select i1 %t16, i32 0, i32 %t18
  call void @__olang_scope_close(ptr %s0)
  %t21 = insertvalue { i32, %"std/net:Conn" } zeroinitializer, i32 %t19, 0
  store { i32, %"std/net:Conn" } %t21, ptr %rv
  br label %ret
bb3:
  %t22 = load i32, ptr %l4, !tbaa !23
  store i32 %t22, ptr %l1, !tbaa !23
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = call { i64, ptr } @std_2fnet_2esockaddr(ptr %v0, ptr %s0, ptr %t23)
  store { i64, ptr } %t25, ptr %l11
  br label %bb4
bb4:
  %t26 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t27 = load i32, ptr %l1, !tbaa !23
  %t31 = call i32 @std_2fnet_2esysConnect(ptr %s0, i32 %t27, { i64, ptr } %t26)
  store i32 %t31, ptr %l14
  br label %bb5
bb5:
  %t32 = load i32, ptr %l14, !tbaa !23
  %t33 = icmp slt i32 %t32, 0
  br i1 %t33, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t35 = call i32 @std_2fnet_2esockErr()
  store i32 %t35, ptr %l16
  br label %bb8
bb7:
  br label %bb14
bb8:
  %t36 = load i32, ptr %l16, !tbaa !23
  store i32 %t36, ptr %l3, !tbaa !23
  %t37 = load i32, ptr %l1, !tbaa !23
  call void @std_2fnet_2ecloseSock(i32 %t37)
  br label %bb9
bb9:
  %t39 = load i32, ptr %l3, !tbaa !23
  store i32 %t39, ptr %l18, !tbaa !23
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l19, !tbaa !29
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  call void @olang_2emir_2eHelperKind_2eRender_2estd_2fnet_3aAddr_26(ptr %s2, ptr %l19, i64 0)
  br label %bb10
bb10:
  %t42 = load ptr, ptr %s2
  %t43 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t44 = load i64, ptr %t43
  %t45 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t44)
  call void @olang_textcopy(ptr %t45, ptr %t42, i64 %t44)
  %t46 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  store { i64, ptr } %t47, ptr %l21, !tbaa !27
  %t48 = getelementptr %olang.builder, ptr %s2, i32 0, i32 3
  %t49 = load ptr, ptr %t48
  %t50 = icmp ne ptr %t49, null
  br i1 %t50, label %sbgrew.51, label %sbdone.52
sbgrew.51:
  call void @__olang_sb_done(ptr %s2)
  br label %sbdone.52
sbdone.52:
  %t53 = load i32, ptr %l18, !tbaa !23
  %t54 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t55 = call i32 @std_2fnet_2eraise(i32 %t53, { i64, ptr } %t54)
  store i32 %t55, ptr %l22
  %t56 = icmp ne i32 %t55, 0
  br i1 %t56, label %bb12, label %ok.57, !prof !99
ok.57:
  br label %bb11
bb11:
  br label %bb13
bb12:
  %t58 = load i32, ptr %l22, !tbaa !23
  %t59 = lshr i32 %t58, 16
  %t60 = and i32 %t58, 65535
  %t61 = icmp eq i32 %t59, 1
  %t62 = select i1 %t61, i32 1, i32 0
  %t63 = icmp eq i32 %t58, 0
  %t64 = shl i32 %t62, 16
  %t65 = or i32 %t64, %t60
  %t66 = select i1 %t63, i32 0, i32 %t65
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t68 = insertvalue { i32, %"std/net:Conn" } zeroinitializer, i32 %t66, 0
  store { i32, %"std/net:Conn" } %t68, ptr %rv
  br label %ret
bb13:
  call void @__olang_scope_close(ptr %s1)
  br label %bb14
bb14:
  %t69 = load i32, ptr %l1, !tbaa !23
  %t71 = call %"std/net:Conn" @std_2fnet_3aConn_2ector(ptr %s0, i32 %t69)
  store %"std/net:Conn" %t71, ptr %l25
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  %t72 = load %"std/net:Conn", ptr %l25
  %t73 = insertvalue { i32, %"std/net:Conn" } zeroinitializer, %"std/net:Conn" %t72, 1
  store { i32, %"std/net:Conn" } %t73, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/net:Conn" }, ptr %rv
  ret { i32, %"std/net:Conn" } %rr
}

define dso_local %"std/net:IP" @std_2fnet_2eIP_2eLoopback4() #0 {
entry:
  %l0 = alloca %"std/net:IP"
  %rv = alloca %"std/net:IP"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/net:IP" @std_2fnet_2eIP_2eIPv4(i8 127, i8 0, i8 0, i8 1)
  store %"std/net:IP" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/net:IP", ptr %l0
  store %"std/net:IP" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/net:IP", ptr %rv
  ret %"std/net:IP" %rr
}

define dso_local { i32, %"std/net:IP" } @std_2fnet_2eIP_2eParse(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i1
  %l3 = alloca i1
  %l4 = alloca %"std/net:IP"
  %l5 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  %l11 = alloca %"std/net:IP"
  %l13 = alloca %"std/net:IP"
  %l14 = alloca i32
  %l16 = alloca i1
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, [2 x i64] }
  %l22 = alloca i64
  %l24 = alloca { i64, [2 x i64] }
  %l27 = alloca %"std/net:IP"
  %l29 = alloca %"std/net:IP"
  %l30 = alloca i32
  %l32 = alloca i1
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, [2 x i64] }
  %l38 = alloca i64
  %l40 = alloca { i64, [2 x i64] }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i32, %"std/net:IP" }
  %t46 = alloca { i64, [2 x i64] }, align 8
  %t94 = alloca { i64, [2 x i64] }, align 8
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i1 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i1, ptr %l3, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  %t5 = call %"std/net:IP" @std_2fnet_2eIP_2eLoopback4()
  store %"std/net:IP" %t5, ptr %l4
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t6 = load %"std/net:IP", ptr %l4
  %t7 = insertvalue { i32, %"std/net:IP" } zeroinitializer, %"std/net:IP" %t6, 1
  store { i32, %"std/net:IP" } %t7, ptr %rv
  br label %ret
bb5:
  store i1 true, ptr %l1, !tbaa !21
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t11 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %t8, i8 58)
  %t12 = extractvalue { i32, i64 } %t11, 1
  %t13 = extractvalue { i32, i64 } %t11, 0
  store i32 %t13, ptr %l9
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb7, label %ok.15, !prof !99
ok.15:
  store i64 %t12, ptr %l8
  br label %bb6
bb6:
  %t16 = load i64, ptr %l8, !tbaa !24
  store i64 %t16, ptr %l5, !tbaa !24
  br label %bb9
bb7:
  br label %bb8
bb8:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb9
bb9:
  %t17 = load i1, ptr %l1, !tbaa !21
  br i1 %t17, label %bb10, label %bb11
bb10:
  %t19 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t21 = call { i32, %"std/net:IP" } @std_2fnet_2eIP_2eparse6(ptr %v0, { i64, ptr } %t19)
  %t22 = extractvalue { i32, %"std/net:IP" } %t21, 1
  %t23 = extractvalue { i32, %"std/net:IP" } %t21, 0
  store i32 %t23, ptr %l14
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb13, label %ok.25, !prof !99
ok.25:
  store %"std/net:IP" %t22, ptr %l13
  br label %bb12
bb11:
  br label %bb17
bb12:
  %t26 = load %"std/net:IP", ptr %l13
  store %"std/net:IP" %t26, ptr %l11
  br label %bb16
bb13:
  %t27 = load i32, ptr %l14, !tbaa !23
  %t28 = ashr i32 %t27, 16
  %t30 = icmp eq i32 %t28, 1
  store i1 %t30, ptr %l16, !tbaa !21
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  %t31 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t31, ptr %l18, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  store i64 %t34, ptr %l19, !tbaa !24
  %t35 = load i64, ptr %l19, !tbaa !24
  %t36 = mul i64 %t35, 1
  %t37 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l20, !tbaa !27
  %t40 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l19, !tbaa !24
  %t45 = mul i64 %t44, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t41, ptr %t43, i64 %t45, i1 false)
  store { i64, [2 x i64] } zeroinitializer, ptr %t46
  %t47 = getelementptr { i64, [2 x i64] }, ptr %t46, i32 0, i32 0
  store i64 5, ptr %t47
  %t48 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t49 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t48, 0
  %t50 = getelementptr { i64, [2 x i64] }, ptr %t46, i32 0, i32 1
  store { { i64, ptr } } %t49, ptr %t50
  %t51 = load { i64, [2 x i64] }, ptr %t46
  store { i64, [2 x i64] } %t51, ptr %l21
  %t52 = call ptr @__olang_errpay_push()
  %t53 = ptrtoint ptr %t52 to i64
  store i64 %t53, ptr %l22, !tbaa !24
  %t54 = load i64, ptr %l22
  %t55 = inttoptr i64 %t54 to ptr
  %t57 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fnet_3aError_24payload(ptr %t55, ptr %l21)
  store { i64, [2 x i64] } %t57, ptr %l24
  br label %bb15
bb15:
  %t58 = load { i64, [2 x i64] }, ptr %l24
  %t59 = load i64, ptr %l22
  %t60 = inttoptr i64 %t59 to ptr
  %t61 = call ptr @__olang_scope_alloc_a(ptr %t60, i64 24, i64 8)
  store { i64, [2 x i64] } %t58, ptr %t61
  call void @__olang_errpay_set(ptr %t61)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t64 = insertvalue { i32, %"std/net:IP" } zeroinitializer, i32 65541, 0
  store { i32, %"std/net:IP" } %t64, ptr %rv
  br label %ret
bb16:
  call void @__olang_scope_close(ptr %s0)
  %t65 = load %"std/net:IP", ptr %l11
  %t66 = insertvalue { i32, %"std/net:IP" } zeroinitializer, %"std/net:IP" %t65, 1
  store { i32, %"std/net:IP" } %t66, ptr %rv
  br label %ret
bb17:
  %t67 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t69 = call { i32, %"std/net:IP" } @std_2fnet_2eIP_2eparse4(ptr %v0, { i64, ptr } %t67)
  %t70 = extractvalue { i32, %"std/net:IP" } %t69, 1
  %t71 = extractvalue { i32, %"std/net:IP" } %t69, 0
  store i32 %t71, ptr %l30
  %t72 = icmp ne i32 %t71, 0
  br i1 %t72, label %bb19, label %ok.73, !prof !99
ok.73:
  store %"std/net:IP" %t70, ptr %l29
  br label %bb18
bb18:
  %t74 = load %"std/net:IP", ptr %l29
  store %"std/net:IP" %t74, ptr %l27
  br label %bb22
bb19:
  %t75 = load i32, ptr %l30, !tbaa !23
  %t76 = ashr i32 %t75, 16
  %t78 = icmp eq i32 %t76, 1
  store i1 %t78, ptr %l32, !tbaa !21
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s5
  %t79 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t79, ptr %l34, !tbaa !27
  %t81 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t81, 0
  store i64 %t82, ptr %l35, !tbaa !24
  %t83 = load i64, ptr %l35, !tbaa !24
  %t84 = mul i64 %t83, 1
  %t85 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t84)
  %t86 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t85, 1
  store { i64, ptr } %t87, ptr %l36, !tbaa !27
  %t88 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = load i64, ptr %l35, !tbaa !24
  %t93 = mul i64 %t92, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t89, ptr %t91, i64 %t93, i1 false)
  store { i64, [2 x i64] } zeroinitializer, ptr %t94
  %t95 = getelementptr { i64, [2 x i64] }, ptr %t94, i32 0, i32 0
  store i64 5, ptr %t95
  %t96 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t97 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t96, 0
  %t98 = getelementptr { i64, [2 x i64] }, ptr %t94, i32 0, i32 1
  store { { i64, ptr } } %t97, ptr %t98
  %t99 = load { i64, [2 x i64] }, ptr %t94
  store { i64, [2 x i64] } %t99, ptr %l37
  %t100 = call ptr @__olang_errpay_push()
  %t101 = ptrtoint ptr %t100 to i64
  store i64 %t101, ptr %l38, !tbaa !24
  %t102 = load i64, ptr %l38
  %t103 = inttoptr i64 %t102 to ptr
  %t105 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fnet_3aError_24payload(ptr %t103, ptr %l37)
  store { i64, [2 x i64] } %t105, ptr %l40
  br label %bb21
bb21:
  %t106 = load { i64, [2 x i64] }, ptr %l40
  %t107 = load i64, ptr %l38
  %t108 = inttoptr i64 %t107 to ptr
  %t109 = call ptr @__olang_scope_alloc_a(ptr %t108, i64 24, i64 8)
  store { i64, [2 x i64] } %t106, ptr %t109
  call void @__olang_errpay_set(ptr %t109)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t112 = insertvalue { i32, %"std/net:IP" } zeroinitializer, i32 65541, 0
  store { i32, %"std/net:IP" } %t112, ptr %rv
  br label %ret
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t113 = load %"std/net:IP", ptr %l27
  %t114 = insertvalue { i32, %"std/net:IP" } zeroinitializer, %"std/net:IP" %t113, 1
  store { i32, %"std/net:IP" } %t114, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/net:IP" }, ptr %rv
  ret { i32, %"std/net:IP" } %rr
}

define dso_local { i32, %"std/net:IP" } @std_2fnet_2eIP_2eparse6(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca [8 x i64]
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"std/net:IP"
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"std/net:IP"
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i1
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i32
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i32
  %l60 = alloca i1
  %l63 = alloca i1
  %l70 = alloca %"std/net:IP"
  %l71 = alloca { i64, ptr }
  %l72 = alloca i64
  %l75 = alloca i64
  %l76 = alloca i64
  %l81 = alloca %"std/net:IP"
  %l82 = alloca i32
  %l109 = alloca i1
  %l110 = alloca { i64, ptr }
  %l113 = alloca i64
  %l115 = alloca i1
  %l122 = alloca i64
  %l123 = alloca { i64, ptr }
  %l126 = alloca i64
  %l144 = alloca { i64, ptr }
  %l156 = alloca i1
  %l157 = alloca { i64, ptr }
  %l175 = alloca i1
  %l178 = alloca i1
  %l181 = alloca i1
  %l185 = alloca %"std/net:IP"
  %l192 = alloca i64
  %l195 = alloca i64
  %l204 = alloca i64
  %l207 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca { i32, %"std/net:IP" }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = insertvalue [8 x i64] undef, i64 0, 0
  %t2 = insertvalue [8 x i64] %t1, i64 0, 1
  %t3 = insertvalue [8 x i64] %t2, i64 0, 2
  %t4 = insertvalue [8 x i64] %t3, i64 0, 3
  %t5 = insertvalue [8 x i64] %t4, i64 0, 4
  %t6 = insertvalue [8 x i64] %t5, i64 0, 5
  %t7 = insertvalue [8 x i64] %t6, i64 0, 6
  %t8 = insertvalue [8 x i64] %t7, i64 0, 7
  store [8 x i64] %t8, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  store i64 -1, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t12 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t10, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i1 %t12, ptr %l21
  br label %bb1
bb1:
  %t13 = load i1, ptr %l21, !tbaa !21
  br i1 %t13, label %bb2, label %bb3
bb2:
  store i64 0, ptr %l3, !tbaa !24
  store i64 2, ptr %l4, !tbaa !24
  br label %bb4
bb3:
  br label %bb4
bb4:
  br label %bb5
bb5:
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t20 = icmp slt i64 %t14, %t17
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb6, label %bb7
bb6:
  br label %bb89
bb7:
  br label %bb8
bb8:
  %t24 = load i64, ptr %l2, !tbaa !24
  %t26 = icmp eq i64 %t24, 8
  br i1 %t26, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t29 = insertvalue { i32, %"std/net:IP" } zeroinitializer, i32 65536, 0
  store { i32, %"std/net:IP" } %t29, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t30 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t30, ptr %l31, !tbaa !27
  %t31 = load i64, ptr %l4, !tbaa !24
  store i64 %t31, ptr %l32, !tbaa !24
  %t32 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t32, 0
  store i64 %t35, ptr %l35, !tbaa !24
  %t36 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 0
  store i64 %t37, ptr %l36, !tbaa !24
  %t38 = load i64, ptr %l32, !tbaa !24
  %t39 = icmp sge i64 %t38, 0
  br i1 %t39, label %bb12, label %bb13
bb12:
  %t41 = load i64, ptr %l32, !tbaa !24
  %t42 = load i64, ptr %l35, !tbaa !24
  %t43 = icmp sle i64 %t41, %t42
  br i1 %t43, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_f002e9158933fedd_16edb23c552ec181)
  unreachable
bb14:
  %t45 = load i64, ptr %l35, !tbaa !24
  %t46 = load i64, ptr %l36, !tbaa !24
  %t47 = icmp sle i64 %t45, %t46
  br i1 %t47, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_f002e9158933fedd_16edb23c552ec181)
  unreachable
bb16:
  %t49 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = load i64, ptr %l32, !tbaa !24
  %t52 = load i64, ptr %l35, !tbaa !24
  %t53 = getelementptr i8, ptr %t50, i64 %t51
  %t54 = sub i64 %t52, %t51
  %t55 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t53, 1
  %t59 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %t56, i8 46)
  %t60 = extractvalue { i32, i64 } %t59, 1
  %t61 = extractvalue { i32, i64 } %t59, 0
  store i32 %t61, ptr %l43
  %t62 = icmp ne i32 %t61, 0
  br i1 %t62, label %bb19, label %ok.63, !prof !99
ok.63:
  store i64 %t60, ptr %l42
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_f002e9158933fedd_16edb23c552ec181)
  unreachable
bb18:
  %t64 = load i64, ptr %l42, !tbaa !24
  store i64 %t64, ptr %l30, !tbaa !24
  br label %bb21
bb19:
  br label %bb20
bb20:
  store i64 -1, ptr %l30, !tbaa !24
  br label %bb21
bb21:
  %t65 = load i64, ptr %l30, !tbaa !24
  store i64 %t65, ptr %l5, !tbaa !24
  %t66 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t66, ptr %l45, !tbaa !27
  %t67 = load i64, ptr %l4, !tbaa !24
  store i64 %t67, ptr %l46, !tbaa !24
  %t68 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t68, 0
  store i64 %t71, ptr %l49, !tbaa !24
  %t72 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t72, 0
  store i64 %t73, ptr %l50, !tbaa !24
  %t74 = load i64, ptr %l46, !tbaa !24
  %t75 = icmp sge i64 %t74, 0
  br i1 %t75, label %bb22, label %bb23
bb22:
  %t77 = load i64, ptr %l46, !tbaa !24
  %t78 = load i64, ptr %l49, !tbaa !24
  %t79 = icmp sle i64 %t77, %t78
  br i1 %t79, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_ab8b57281d5db880_ee039328189ec414)
  unreachable
bb24:
  %t81 = load i64, ptr %l49, !tbaa !24
  %t82 = load i64, ptr %l50, !tbaa !24
  %t83 = icmp sle i64 %t81, %t82
  br i1 %t83, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_ab8b57281d5db880_ee039328189ec414)
  unreachable
bb26:
  %t85 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = load i64, ptr %l46, !tbaa !24
  %t88 = load i64, ptr %l49, !tbaa !24
  %t89 = getelementptr i8, ptr %t86, i64 %t87
  %t90 = sub i64 %t88, %t87
  %t91 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t89, 1
  %t95 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %t92, i8 58)
  %t96 = extractvalue { i32, i64 } %t95, 1
  %t97 = extractvalue { i32, i64 } %t95, 0
  store i32 %t97, ptr %l57
  %t98 = icmp ne i32 %t97, 0
  br i1 %t98, label %bb29, label %ok.99, !prof !99
ok.99:
  store i64 %t96, ptr %l56
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_ab8b57281d5db880_ee039328189ec414)
  unreachable
bb28:
  %t100 = load i64, ptr %l56, !tbaa !24
  store i64 %t100, ptr %l44, !tbaa !24
  br label %bb31
bb29:
  br label %bb30
bb30:
  store i64 -1, ptr %l44, !tbaa !24
  br label %bb31
bb31:
  %t101 = load i64, ptr %l44, !tbaa !24
  store i64 %t101, ptr %l6, !tbaa !24
  %t102 = load i64, ptr %l5, !tbaa !24
  %t104 = icmp sge i64 %t102, 0
  br i1 %t104, label %bb32, label %bb33
bb32:
  %t106 = load i64, ptr %l6, !tbaa !24
  %t108 = icmp slt i64 %t106, 0
  br i1 %t108, label %bb34, label %bb35
bb33:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb37
bb34:
  store i1 true, ptr %l63, !tbaa !21
  br label %bb36
bb35:
  %t110 = load i64, ptr %l5, !tbaa !24
  %t111 = load i64, ptr %l6, !tbaa !24
  %t114 = icmp slt i64 %t110, %t111
  store i1 %t114, ptr %l63, !tbaa !21
  br label %bb36
bb36:
  %t116 = load i1, ptr %l63, !tbaa !21
  store i1 %t116, ptr %l60, !tbaa !21
  br label %bb37
bb37:
  %t117 = load i1, ptr %l60, !tbaa !21
  br i1 %t117, label %bb38, label %bb39
bb38:
  %t118 = load i64, ptr %l2, !tbaa !24
  %t120 = icmp sgt i64 %t118, 6
  br i1 %t120, label %bb40, label %bb41
bb39:
  br label %bb52
bb40:
  call void @__olang_scope_close(ptr %s0)
  %t123 = insertvalue { i32, %"std/net:IP" } zeroinitializer, i32 65536, 0
  store { i32, %"std/net:IP" } %t123, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  %t124 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t124, ptr %l71, !tbaa !27
  %t125 = load i64, ptr %l4, !tbaa !24
  store i64 %t125, ptr %l72, !tbaa !24
  %t126 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t126, 0
  store i64 %t129, ptr %l75, !tbaa !24
  %t130 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t130, 0
  store i64 %t131, ptr %l76, !tbaa !24
  %t132 = load i64, ptr %l72, !tbaa !24
  %t133 = icmp sge i64 %t132, 0
  br i1 %t133, label %bb43, label %bb44
bb43:
  %t135 = load i64, ptr %l72, !tbaa !24
  %t136 = load i64, ptr %l75, !tbaa !24
  %t137 = icmp sle i64 %t135, %t136
  br i1 %t137, label %bb45, label %bb46
bb44:
  call void @__olang_check_failed(ptr @olang_loc_5cec024583c1c07b_b48952299688f87f)
  unreachable
bb45:
  %t139 = load i64, ptr %l75, !tbaa !24
  %t140 = load i64, ptr %l76, !tbaa !24
  %t141 = icmp sle i64 %t139, %t140
  br i1 %t141, label %bb47, label %bb48
bb46:
  call void @__olang_check_failed(ptr @olang_loc_5cec024583c1c07b_b48952299688f87f)
  unreachable
bb47:
  %t143 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !27
  %t145 = load i64, ptr %l72, !tbaa !24
  %t146 = load i64, ptr %l75, !tbaa !24
  %t147 = getelementptr i8, ptr %t144, i64 %t145
  %t148 = sub i64 %t146, %t145
  %t149 = insertvalue { i64, ptr } undef, i64 %t148, 0
  %t150 = insertvalue { i64, ptr } %t149, ptr %t147, 1
  %t152 = call { i32, %"std/net:IP" } @std_2fnet_2eIP_2eparse4(ptr %v0, { i64, ptr } %t150)
  %t153 = extractvalue { i32, %"std/net:IP" } %t152, 1
  %t154 = extractvalue { i32, %"std/net:IP" } %t152, 0
  store i32 %t154, ptr %l82
  %t155 = icmp ne i32 %t154, 0
  br i1 %t155, label %bb50, label %ok.156, !prof !99
ok.156:
  store %"std/net:IP" %t153, ptr %l81
  br label %bb49
bb48:
  call void @__olang_check_failed(ptr @olang_loc_5cec024583c1c07b_b48952299688f87f)
  unreachable
bb49:
  %t157 = load %"std/net:IP", ptr %l81
  store %"std/net:IP" %t157, ptr %l70
  br label %bb51
bb50:
  %t158 = load i32, ptr %l82, !tbaa !23
  %t159 = lshr i32 %t158, 16
  %t160 = and i32 %t158, 65535
  %t161 = icmp eq i32 %t159, 1
  %t162 = select i1 %t161, i32 1, i32 0
  %t163 = icmp eq i32 %t158, 0
  %t164 = shl i32 %t162, 16
  %t165 = or i32 %t164, %t160
  %t166 = select i1 %t163, i32 0, i32 %t165
  call void @__olang_scope_close(ptr %s0)
  %t168 = insertvalue { i32, %"std/net:IP" } zeroinitializer, i32 %t166, 0
  store { i32, %"std/net:IP" } %t168, ptr %rv
  br label %ret
bb51:
  %t169 = load %"std/net:IP", ptr %l70
  store %"std/net:IP" %t169, ptr %l7
  %t170 = load i64, ptr %l2, !tbaa !24
  %t171 = getelementptr %"std/net:IP", ptr %l7, i32 0, i32 1
  %t172 = getelementptr [16 x i8], ptr %t171, i64 0, i64 0
  %t173 = load i8, ptr %t172, !tbaa !32
  %t175 = zext i8 %t173 to i64
  %t177 = shl i64 %t175, 8
  %t178 = getelementptr %"std/net:IP", ptr %l7, i32 0, i32 1
  %t179 = getelementptr [16 x i8], ptr %t178, i64 0, i64 1
  %t180 = load i8, ptr %t179, !tbaa !32
  %t182 = zext i8 %t180 to i64
  %t185 = or i64 %t177, %t182
  %t188 = getelementptr [8 x i64], ptr %l1, i64 0, i64 %t170
  store i64 %t185, ptr %t188, !tbaa !34
  %t189 = load i64, ptr %l2, !tbaa !24
  %t191 = add i64 %t189, 1
  %t192 = getelementptr %"std/net:IP", ptr %l7, i32 0, i32 1
  %t193 = getelementptr [16 x i8], ptr %t192, i64 0, i64 2
  %t194 = load i8, ptr %t193, !tbaa !32
  %t196 = zext i8 %t194 to i64
  %t198 = shl i64 %t196, 8
  %t199 = getelementptr %"std/net:IP", ptr %l7, i32 0, i32 1
  %t200 = getelementptr [16 x i8], ptr %t199, i64 0, i64 3
  %t201 = load i8, ptr %t200, !tbaa !32
  %t203 = zext i8 %t201 to i64
  %t206 = or i64 %t198, %t203
  %t209 = getelementptr [8 x i64], ptr %l1, i64 0, i64 %t191
  store i64 %t206, ptr %t209, !tbaa !34
  %t210 = load i64, ptr %l2, !tbaa !24
  %t213 = add i64 %t210, 2
  store i64 %t213, ptr %l2, !tbaa !24
  %t215 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t217 = extractvalue { i64, ptr } %t215, 0
  store i64 %t217, ptr %l4, !tbaa !24
  br label %bb89
bb52:
  store i64 0, ptr %l8, !tbaa !24
  %t219 = load i64, ptr %l4, !tbaa !24
  store i64 %t219, ptr %l9, !tbaa !24
  br label %bb53
bb53:
  %t221 = load i64, ptr %l4, !tbaa !24
  %t222 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t224 = extractvalue { i64, ptr } %t222, 0
  %t227 = icmp slt i64 %t221, %t224
  br i1 %t227, label %bb54, label %bb55
bb54:
  %t229 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t229, ptr %l110, !tbaa !27
  %t230 = load i64, ptr %l4, !tbaa !24
  %t232 = getelementptr { i64, ptr }, ptr %l110, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !27
  %t234 = getelementptr i8, ptr %t233, i64 %t230
  %t235 = load i8, ptr %t234, !tbaa !32
  %t237 = call i64 @std_2fnet_2ehexDigit(i8 %t235)
  store i64 %t237, ptr %l113
  br label %bb56
bb55:
  store i1 false, ptr %l109, !tbaa !21
  br label %bb57
bb56:
  %t238 = load i64, ptr %l113, !tbaa !24
  %t239 = icmp sge i64 %t238, 0
  store i1 %t239, ptr %l109, !tbaa !21
  br label %bb57
bb57:
  %t241 = load i1, ptr %l109, !tbaa !21
  br i1 %t241, label %bb58, label %bb59
bb58:
  %t242 = load i64, ptr %l4, !tbaa !24
  %t243 = load i64, ptr %l9, !tbaa !24
  %t246 = sub i64 %t242, %t243
  %t248 = icmp slt i64 %t246, 4
  store i1 %t248, ptr %l115, !tbaa !21
  br label %bb60
bb59:
  store i1 false, ptr %l115, !tbaa !21
  br label %bb60
bb60:
  %t250 = load i1, ptr %l115, !tbaa !21
  %t251 = xor i1 %t250, true
  br i1 %t251, label %bb61, label %bb62
bb61:
  br label %bb66
bb62:
  br label %bb63
bb63:
  %t253 = load i64, ptr %l8, !tbaa !24
  %t255 = mul i64 %t253, 16
  store i64 %t255, ptr %l122, !tbaa !24
  %t256 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t256, ptr %l123, !tbaa !27
  %t257 = load i64, ptr %l4, !tbaa !24
  %t259 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t260 = load ptr, ptr %t259, !tbaa !27
  %t261 = getelementptr i8, ptr %t260, i64 %t257
  %t262 = load i8, ptr %t261, !tbaa !32
  %t264 = call i64 @std_2fnet_2ehexDigit(i8 %t262)
  store i64 %t264, ptr %l126
  br label %bb64
bb64:
  %t265 = load i64, ptr %l122, !tbaa !24
  %t266 = load i64, ptr %l126, !tbaa !24
  %t267 = add i64 %t265, %t266
  store i64 %t267, ptr %l8, !tbaa !24
  %t269 = load i64, ptr %l4, !tbaa !24
  %t272 = add i64 %t269, 1
  store i64 %t272, ptr %l4, !tbaa !24
  br label %bb65
bb65:
  br label %bb53
bb66:
  %t274 = load i64, ptr %l4, !tbaa !24
  %t275 = load i64, ptr %l9, !tbaa !24
  %t278 = icmp eq i64 %t274, %t275
  br i1 %t278, label %bb67, label %bb68
bb67:
  call void @__olang_scope_close(ptr %s0)
  %t281 = insertvalue { i32, %"std/net:IP" } zeroinitializer, i32 65536, 0
  store { i32, %"std/net:IP" } %t281, ptr %rv
  br label %ret
bb68:
  br label %bb69
bb69:
  %t282 = load i64, ptr %l2, !tbaa !24
  %t283 = load i64, ptr %l8, !tbaa !24
  %t286 = getelementptr [8 x i64], ptr %l1, i64 0, i64 %t282
  store i64 %t283, ptr %t286, !tbaa !34
  %t287 = load i64, ptr %l2, !tbaa !24
  %t290 = add i64 %t287, 1
  store i64 %t290, ptr %l2, !tbaa !24
  %t292 = load i64, ptr %l4, !tbaa !24
  %t293 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t295 = extractvalue { i64, ptr } %t293, 0
  %t298 = icmp eq i64 %t292, %t295
  br i1 %t298, label %bb70, label %bb71
bb70:
  br label %bb89
bb71:
  br label %bb72
bb72:
  %t300 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t300, ptr %l144, !tbaa !27
  %t301 = load i64, ptr %l4, !tbaa !24
  %t303 = getelementptr { i64, ptr }, ptr %l144, i32 0, i32 1
  %t304 = load ptr, ptr %t303, !tbaa !27
  %t305 = getelementptr i8, ptr %t304, i64 %t301
  %t306 = load i8, ptr %t305, !tbaa !32
  %t308 = icmp ne i8 %t306, 58
  br i1 %t308, label %bb73, label %bb74
bb73:
  call void @__olang_scope_close(ptr %s0)
  %t311 = insertvalue { i32, %"std/net:IP" } zeroinitializer, i32 65536, 0
  store { i32, %"std/net:IP" } %t311, ptr %rv
  br label %ret
bb74:
  br label %bb75
bb75:
  %t312 = load i64, ptr %l4, !tbaa !24
  %t315 = add i64 %t312, 1
  store i64 %t315, ptr %l4, !tbaa !24
  %t317 = load i64, ptr %l4, !tbaa !24
  %t318 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t320 = extractvalue { i64, ptr } %t318, 0
  %t323 = icmp slt i64 %t317, %t320
  br i1 %t323, label %bb76, label %bb77
bb76:
  %t325 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t325, ptr %l157, !tbaa !27
  %t326 = load i64, ptr %l4, !tbaa !24
  %t328 = getelementptr { i64, ptr }, ptr %l157, i32 0, i32 1
  %t329 = load ptr, ptr %t328, !tbaa !27
  %t330 = getelementptr i8, ptr %t329, i64 %t326
  %t331 = load i8, ptr %t330, !tbaa !32
  %t333 = icmp eq i8 %t331, 58
  store i1 %t333, ptr %l156, !tbaa !21
  br label %bb78
bb77:
  store i1 false, ptr %l156, !tbaa !21
  br label %bb78
bb78:
  %t335 = load i1, ptr %l156, !tbaa !21
  br i1 %t335, label %bb79, label %bb80
bb79:
  %t336 = load i64, ptr %l3, !tbaa !24
  %t338 = icmp sge i64 %t336, 0
  br i1 %t338, label %bb81, label %bb82
bb80:
  %t340 = load i64, ptr %l4, !tbaa !24
  %t341 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t343 = extractvalue { i64, ptr } %t341, 0
  %t346 = icmp eq i64 %t340, %t343
  br i1 %t346, label %bb84, label %bb85
bb81:
  call void @__olang_scope_close(ptr %s0)
  %t349 = insertvalue { i32, %"std/net:IP" } zeroinitializer, i32 65536, 0
  store { i32, %"std/net:IP" } %t349, ptr %rv
  br label %ret
bb82:
  br label %bb83
bb83:
  %t350 = load i64, ptr %l2, !tbaa !24
  store i64 %t350, ptr %l3, !tbaa !24
  %t352 = load i64, ptr %l4, !tbaa !24
  %t355 = add i64 %t352, 1
  store i64 %t355, ptr %l4, !tbaa !24
  br label %bb87
bb84:
  call void @__olang_scope_close(ptr %s0)
  %t358 = insertvalue { i32, %"std/net:IP" } zeroinitializer, i32 65536, 0
  store { i32, %"std/net:IP" } %t358, ptr %rv
  br label %ret
bb85:
  br label %bb86
bb86:
  br label %bb87
bb87:
  br label %bb88
bb88:
  br label %bb5
bb89:
  %t359 = load i64, ptr %l3, !tbaa !24
  %t361 = icmp slt i64 %t359, 0
  br i1 %t361, label %bb90, label %bb91
bb90:
  %t363 = load i64, ptr %l2, !tbaa !24
  %t365 = icmp ne i64 %t363, 8
  store i1 %t365, ptr %l175, !tbaa !21
  br label %bb92
bb91:
  store i1 false, ptr %l175, !tbaa !21
  br label %bb92
bb92:
  %t367 = load i1, ptr %l175, !tbaa !21
  br i1 %t367, label %bb93, label %bb94
bb93:
  store i1 true, ptr %l178, !tbaa !21
  br label %bb98
bb94:
  %t368 = load i64, ptr %l3, !tbaa !24
  %t370 = icmp sge i64 %t368, 0
  br i1 %t370, label %bb95, label %bb96
bb95:
  %t372 = load i64, ptr %l2, !tbaa !24
  %t374 = icmp eq i64 %t372, 8
  store i1 %t374, ptr %l181, !tbaa !21
  br label %bb97
bb96:
  store i1 false, ptr %l181, !tbaa !21
  br label %bb97
bb97:
  %t376 = load i1, ptr %l181, !tbaa !21
  store i1 %t376, ptr %l178, !tbaa !21
  br label %bb98
bb98:
  %t377 = load i1, ptr %l178, !tbaa !21
  br i1 %t377, label %bb99, label %bb100
bb99:
  call void @__olang_scope_close(ptr %s0)
  %t379 = insertvalue { i32, %"std/net:IP" } zeroinitializer, i32 65536, 0
  store { i32, %"std/net:IP" } %t379, ptr %rv
  br label %ret
bb100:
  br label %bb101
bb101:
  %t380 = call %"std/net:IP" @std_2fnet_3aIP_2ector(ptr %s0, i1 true)
  store %"std/net:IP" %t380, ptr %l185
  br label %bb102
bb102:
  %t381 = load %"std/net:IP", ptr %l185
  store %"std/net:IP" %t381, ptr %l10
  %t382 = load i64, ptr %l2, !tbaa !24
  %t384 = sub i64 8, %t382
  store i64 %t384, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  %t386 = load i64, ptr %l2, !tbaa !24
  store i64 %t386, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t388 = load i64, ptr %l14, !tbaa !24
  %t389 = load i64, ptr %l13, !tbaa !24
  %t392 = icmp sgt i64 %t388, %t389
  br i1 %t392, label %bb103, label %bb104
bb103:
  %t394 = load i64, ptr %l15, !tbaa !24
  %t396 = icmp sgt i64 %t394, 0
  br i1 %t396, label %bb105, label %bb106
bb104:
  store i64 0, ptr %l192, !tbaa !24
  br label %bb108
bb105:
  %t398 = load i64, ptr %l14, !tbaa !24
  %t399 = load i64, ptr %l13, !tbaa !24
  %t402 = sub i64 %t398, %t399
  %t403 = load i64, ptr %l15, !tbaa !24
  %t406 = add i64 %t402, %t403
  %t408 = sub i64 %t406, 1
  %t409 = load i64, ptr %l15, !tbaa !24
  %t412 = sdiv i64 %t408, %t409
  store i64 %t412, ptr %l195, !tbaa !24
  br label %bb107
bb106:
  store i64 0, ptr %l195, !tbaa !24
  br label %bb107
bb107:
  %t414 = load i64, ptr %l195, !tbaa !24
  store i64 %t414, ptr %l192, !tbaa !24
  br label %bb108
bb108:
  %t415 = load i64, ptr %l192, !tbaa !24
  store i64 %t415, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  %t416 = load i64, ptr %l16, !tbaa !24
  %t417 = sub i64 %t416, 1
  store i64 %t417, ptr %l204, !tbaa !24
  %t418 = load i64, ptr %l16, !tbaa !24
  %t419 = icmp slt i64 %t418, 2147483648
  %t420 = load i64, ptr %l17, !tbaa !24
  %t421 = icmp sge i64 %t420, 0
  %t424 = and i1 %t419, %t421
  store i1 %t424, ptr %l207, !tbaa !21
  br label %bb109
bb109:
  %t425 = load i64, ptr %l17, !tbaa !24
  %t426 = load i64, ptr %l16, !tbaa !24
  %t429 = icmp slt i64 %t425, %t426
  %t431 = xor i1 %t429, true
  br i1 %t431, label %bb110, label %bb111
bb110:
  br label %bb117
bb111:
  br label %bb112
bb112:
  %t433 = load i64, ptr %l13, !tbaa !24
  %t434 = load i64, ptr %l17, !tbaa !24
  %t435 = load i64, ptr %l15, !tbaa !24
  %t438 = mul i64 %t434, %t435
  %t441 = add i64 %t433, %t438
  store i64 %t441, ptr %l18, !tbaa !24
  %t443 = load i64, ptr %l18, !tbaa !24
  %t444 = load i64, ptr %l3, !tbaa !24
  %t447 = icmp eq i64 %t443, %t444
  br i1 %t447, label %bb113, label %bb114
bb113:
  %t449 = load i64, ptr %l12, !tbaa !24
  %t451 = load i64, ptr %l11, !tbaa !24
  %t454 = add i64 %t449, %t451
  store i64 %t454, ptr %l12, !tbaa !24
  br label %bb115
bb114:
  br label %bb115
bb115:
  %t456 = load i64, ptr %l12, !tbaa !24
  %t458 = mul i64 2, %t456
  %t459 = load i64, ptr %l18, !tbaa !24
  %t461 = getelementptr [8 x i64], ptr %l1, i64 0, i64 %t459
  %t462 = load i64, ptr %t461, !tbaa !34
  %t464 = ashr i64 %t462, 8
  %t466 = trunc i64 %t464 to i8
  %t468 = getelementptr %"std/net:IP", ptr %l10, i32 0, i32 1
  %t470 = getelementptr [16 x i8], ptr %t468, i64 0, i64 %t458
  store i8 %t466, ptr %t470, !tbaa !32
  %t471 = load i64, ptr %l12, !tbaa !24
  %t473 = mul i64 2, %t471
  %t475 = add i64 %t473, 1
  %t476 = load i64, ptr %l18, !tbaa !24
  %t478 = getelementptr [8 x i64], ptr %l1, i64 0, i64 %t476
  %t479 = load i64, ptr %t478, !tbaa !34
  %t481 = and i64 %t479, 255
  %t483 = trunc i64 %t481 to i8
  %t485 = getelementptr %"std/net:IP", ptr %l10, i32 0, i32 1
  %t487 = getelementptr [16 x i8], ptr %t485, i64 0, i64 %t475
  store i8 %t483, ptr %t487, !tbaa !32
  %t488 = load i64, ptr %l12, !tbaa !24
  %t491 = add i64 %t488, 1
  store i64 %t491, ptr %l12, !tbaa !24
  br label %bb116
bb116:
  %t493 = load i64, ptr %l17, !tbaa !24
  %t496 = add i64 %t493, 1
  store i64 %t496, ptr %l17, !tbaa !24
  br label %bb109
bb117:
  %t498 = load %"std/net:IP", ptr %l10
  call void @__olang_scope_close(ptr %s0)
  %t500 = insertvalue { i32, %"std/net:IP" } zeroinitializer, %"std/net:IP" %t498, 1
  store { i32, %"std/net:IP" } %t500, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/net:IP" }, ptr %rv
  ret { i32, %"std/net:IP" } %rr
}

define dso_local { i32, %"std/net:Listener" } @std_2fnet_2eListener_2eListen(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l11 = alloca i1
  %l22 = alloca { i64, ptr }
  %l25 = alloca i32
  %l27 = alloca i1
  %l30 = alloca i32
  %l32 = alloca i32
  %l34 = alloca i32
  %l35 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l38 = alloca i32
  %l41 = alloca %"std/net:Listener"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.builder
  %s4room = alloca [64 x i8], align 8
  %rv = alloca { i32, %"std/net:Listener" }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr @G_2estd_2fnet_2esockStream, !tbaa !23
  %t5 = call { i32, i32 } @std_2fnet_2eopen(ptr %v0, ptr %t1, i32 %t2)
  %t6 = extractvalue { i32, i32 } %t5, 1
  %t7 = extractvalue { i32, i32 } %t5, 0
  store i32 %t7, ptr %l9
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9, !prof !99
ok.9:
  store i32 %t6, ptr %l8
  br label %bb1
bb1:
  %t10 = load i32, ptr %l8, !tbaa !23
  store i32 %t10, ptr %l5, !tbaa !23
  br label %bb3
bb2:
  %t11 = load i32, ptr %l9, !tbaa !23
  %t12 = lshr i32 %t11, 16
  %t13 = and i32 %t11, 65535
  %t14 = icmp eq i32 %t12, 1
  %t15 = select i1 %t14, i32 1, i32 0
  %t16 = icmp eq i32 %t11, 0
  %t17 = shl i32 %t15, 16
  %t18 = or i32 %t17, %t13
  %t19 = select i1 %t16, i32 0, i32 %t18
  call void @__olang_scope_close(ptr %s0)
  %t21 = insertvalue { i32, %"std/net:Listener" } zeroinitializer, i32 %t19, 0
  store { i32, %"std/net:Listener" } %t21, ptr %rv
  br label %ret
bb3:
  %t22 = load i32, ptr %l5, !tbaa !23
  store i32 %t22, ptr %l2, !tbaa !23
  %t23 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d4, i32 0, i32 1) }, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store i1 %t23, ptr %l11
  br label %bb4
bb4:
  %t24 = load i1, ptr %l11, !tbaa !21
  %t25 = xor i1 %t24, true
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t27 = load i32, ptr %l2, !tbaa !23
  %t28 = load i32, ptr @G_2estd_2fnet_2esolSocket, !tbaa !23
  %t29 = load i32, ptr @G_2estd_2fnet_2esoReuseaddr, !tbaa !23
  call void @std_2fnet_2esetInt(i32 %t27, i32 %t28, i32 %t29, i32 1)
  br label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb8
bb8:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"std/net:Addr", ptr %t33, i32 0, i32 0
  %t36 = getelementptr %"std/net:IP", ptr %t35, i32 0, i32 0
  %t37 = load i1, ptr %t36, !tbaa !21
  br i1 %t37, label %bb9, label %bb10
bb9:
  %t39 = load i32, ptr %l2, !tbaa !23
  %t40 = load i32, ptr @G_2estd_2fnet_2eipprotoIpv6, !tbaa !23
  %t41 = load i32, ptr @G_2estd_2fnet_2eipv6V6only, !tbaa !23
  call void @std_2fnet_2esetInt(i32 %t39, i32 %t40, i32 %t41, i32 0)
  br label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = call { i64, ptr } @std_2fnet_2esockaddr(ptr %v0, ptr %s0, ptr %t45)
  store { i64, ptr } %t47, ptr %l22
  br label %bb13
bb13:
  %t48 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t49 = load i32, ptr %l2, !tbaa !23
  %t53 = call i32 @std_2fnet_2esysBind(ptr %s0, i32 %t49, { i64, ptr } %t48)
  store i32 %t53, ptr %l25
  br label %bb14
bb14:
  %t54 = load i32, ptr %l25, !tbaa !23
  %t55 = icmp slt i32 %t54, 0
  br i1 %t55, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb18
bb16:
  %t57 = load i32, ptr %l2, !tbaa !23
  %t61 = call i32 @std_2fnet_2esysListen(i32 %t57, i32 %a1)
  store i32 %t61, ptr %l30
  br label %bb17
bb17:
  %t62 = load i32, ptr %l30, !tbaa !23
  %t63 = icmp slt i32 %t62, 0
  store i1 %t63, ptr %l27, !tbaa !21
  br label %bb18
bb18:
  %t65 = load i1, ptr %l27, !tbaa !21
  br i1 %t65, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t66 = call i32 @std_2fnet_2esockErr()
  store i32 %t66, ptr %l32
  br label %bb21
bb20:
  br label %bb27
bb21:
  %t67 = load i32, ptr %l32, !tbaa !23
  store i32 %t67, ptr %l4, !tbaa !23
  %t68 = load i32, ptr %l2, !tbaa !23
  call void @std_2fnet_2ecloseSock(i32 %t68)
  br label %bb22
bb22:
  %t70 = load i32, ptr %l4, !tbaa !23
  store i32 %t70, ptr %l34, !tbaa !23
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l35, !tbaa !29
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s4
  store ptr %s4room, ptr %s4
  call void @olang_2emir_2eHelperKind_2eRender_2estd_2fnet_3aAddr_26(ptr %s4, ptr %l35, i64 0)
  br label %bb23
bb23:
  %t73 = load ptr, ptr %s4
  %t74 = getelementptr %olang.builder, ptr %s4, i32 0, i32 1
  %t75 = load i64, ptr %t74
  %t76 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t75)
  call void @olang_textcopy(ptr %t76, ptr %t73, i64 %t75)
  %t77 = insertvalue { i64, ptr } undef, i64 %t75, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t76, 1
  store { i64, ptr } %t78, ptr %l37, !tbaa !27
  %t79 = getelementptr %olang.builder, ptr %s4, i32 0, i32 3
  %t80 = load ptr, ptr %t79
  %t81 = icmp ne ptr %t80, null
  br i1 %t81, label %sbgrew.82, label %sbdone.83
sbgrew.82:
  call void @__olang_sb_done(ptr %s4)
  br label %sbdone.83
sbdone.83:
  %t84 = load i32, ptr %l34, !tbaa !23
  %t85 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t86 = call i32 @std_2fnet_2eraise(i32 %t84, { i64, ptr } %t85)
  store i32 %t86, ptr %l38
  %t87 = icmp ne i32 %t86, 0
  br i1 %t87, label %bb25, label %ok.88, !prof !99
ok.88:
  br label %bb24
bb24:
  br label %bb26
bb25:
  %t89 = load i32, ptr %l38, !tbaa !23
  %t90 = lshr i32 %t89, 16
  %t91 = and i32 %t89, 65535
  %t92 = icmp eq i32 %t90, 1
  %t93 = select i1 %t92, i32 1, i32 0
  %t94 = icmp eq i32 %t89, 0
  %t95 = shl i32 %t93, 16
  %t96 = or i32 %t95, %t91
  %t97 = select i1 %t94, i32 0, i32 %t96
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t99 = insertvalue { i32, %"std/net:Listener" } zeroinitializer, i32 %t97, 0
  store { i32, %"std/net:Listener" } %t99, ptr %rv
  br label %ret
bb26:
  call void @__olang_scope_close(ptr %s3)
  br label %bb27
bb27:
  %t100 = load i32, ptr %l2, !tbaa !23
  %t102 = call %"std/net:Listener" @std_2fnet_3aListener_2ector(ptr %s0, i32 %t100)
  store %"std/net:Listener" %t102, ptr %l41
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s0)
  %t103 = load %"std/net:Listener", ptr %l41
  %t104 = insertvalue { i32, %"std/net:Listener" } zeroinitializer, %"std/net:Listener" %t103, 1
  store { i32, %"std/net:Listener" } %t104, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/net:Listener" }, ptr %rv
  ret { i32, %"std/net:Listener" } %rr
}

define dso_local { i32, { i64, ptr } } @std_2fnet_2eLookup(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i1
  %l2 = alloca %"std/net:IP"
  %l3 = alloca { i64, ptr }
  %l5 = alloca i1
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, [2 x i64] }
  %l11 = alloca i64
  %l13 = alloca { i64, [2 x i64] }
  %l17 = alloca i1
  %l19 = alloca %"std/net:IP"
  %l21 = alloca %"std/net:IP"
  %l22 = alloca i32
  %l25 = alloca %"std/net:IP"
  %l28 = alloca [1 x %"std/net:IP"]
  %l29 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca i32
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %l42 = alloca { i64, [2 x i64] }
  %l43 = alloca i64
  %l45 = alloca { i64, [2 x i64] }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %t20 = alloca { i64, [2 x i64] }, align 8
  %t116 = alloca { i64, [2 x i64] }, align 8
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store i1 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i1, ptr %l5, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t5, ptr %l7, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  store i64 %t8, ptr %l8, !tbaa !24
  %t9 = load i64, ptr %l8, !tbaa !24
  %t10 = mul i64 %t9, 1
  %t11 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l9, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = load i64, ptr %l8, !tbaa !24
  %t19 = mul i64 %t18, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t15, ptr %t17, i64 %t19, i1 false)
  store { i64, [2 x i64] } zeroinitializer, ptr %t20
  %t21 = getelementptr { i64, [2 x i64] }, ptr %t20, i32 0, i32 0
  store i64 6, ptr %t21
  %t22 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t23 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t22, 0
  %t24 = getelementptr { i64, [2 x i64] }, ptr %t20, i32 0, i32 1
  store { { i64, ptr } } %t23, ptr %t24
  %t25 = load { i64, [2 x i64] }, ptr %t20
  store { i64, [2 x i64] } %t25, ptr %l10
  %t26 = call ptr @__olang_errpay_push()
  %t27 = ptrtoint ptr %t26 to i64
  store i64 %t27, ptr %l11, !tbaa !24
  %t28 = load i64, ptr %l11
  %t29 = inttoptr i64 %t28 to ptr
  %t31 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fnet_3aError_24payload(ptr %t29, ptr %l10)
  store { i64, [2 x i64] } %t31, ptr %l13
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t32 = load { i64, [2 x i64] }, ptr %l13
  %t33 = load i64, ptr %l11
  %t34 = inttoptr i64 %t33 to ptr
  %t35 = call ptr @__olang_scope_alloc_a(ptr %t34, i64 24, i64 8)
  store { i64, [2 x i64] } %t32, ptr %t35
  call void @__olang_errpay_set(ptr %t35)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t38 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65542, 0
  store { i32, { i64, ptr } } %t38, ptr %rv
  br label %ret
bb5:
  %t39 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t41 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t39, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store i1 %t41, ptr %l17
  br label %bb6
bb6:
  %t42 = load i1, ptr %l17, !tbaa !21
  %t43 = xor i1 %t42, true
  br i1 %t43, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  store i1 true, ptr %l1, !tbaa !21
  %t45 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t47 = call { i32, %"std/net:IP" } @std_2fnet_2eIP_2eParse(ptr %v0, { i64, ptr } %t45)
  %t48 = extractvalue { i32, %"std/net:IP" } %t47, 1
  %t49 = extractvalue { i32, %"std/net:IP" } %t47, 0
  store i32 %t49, ptr %l22
  %t50 = icmp ne i32 %t49, 0
  br i1 %t50, label %bb10, label %ok.51, !prof !99
ok.51:
  store %"std/net:IP" %t48, ptr %l21
  br label %bb9
bb8:
  br label %bb19
bb9:
  %t52 = load %"std/net:IP", ptr %l21
  store %"std/net:IP" %t52, ptr %l19
  br label %bb15
bb10:
  %t53 = load i32, ptr %l22, !tbaa !23
  %t54 = ashr i32 %t53, 16
  %t56 = icmp eq i32 %t54, 1
  br i1 %t56, label %bb11, label %bb12
bb11:
  call void @__olang_errpay_pop()
  br label %bb12
bb12:
  br label %bb13
bb13:
  store i1 false, ptr %l1, !tbaa !21
  %t58 = call %"std/net:IP" @std_2fnet_3aIP_2ector(ptr %s2, i1 false)
  store %"std/net:IP" %t58, ptr %l25
  br label %bb14
bb14:
  %t59 = load %"std/net:IP", ptr %l25
  store %"std/net:IP" %t59, ptr %l19
  br label %bb15
bb15:
  %t60 = load %"std/net:IP", ptr %l19
  store %"std/net:IP" %t60, ptr %l2
  %t61 = load i1, ptr %l1, !tbaa !21
  br i1 %t61, label %bb16, label %bb17
bb16:
  %t63 = load %"std/net:IP", ptr %l2
  %t65 = insertvalue [1 x %"std/net:IP"] undef, %"std/net:IP" %t63, 0
  store [1 x %"std/net:IP"] %t65, ptr %l28
  %t66 = mul i64 1, 17
  %t67 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t66)
  %t68 = insertvalue { i64, ptr } undef, i64 1, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  store { i64, ptr } %t69, ptr %l29, !tbaa !27
  %t70 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = mul i64 1, 17
  call void @llvm.memmove.p0.p0.i64(ptr %t71, ptr %l28, i64 %t72, i1 false)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t73 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t74 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t73, 1
  store { i32, { i64, ptr } } %t74, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  %t75 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t77 = call { i32, { i64, ptr } } @std_2fnet_2esysLookup(ptr %v0, ptr %v1, { i64, ptr } %t75)
  %t78 = extractvalue { i32, { i64, ptr } } %t77, 1
  %t79 = extractvalue { i32, { i64, ptr } } %t77, 0
  store i32 %t79, ptr %l33
  %t80 = icmp ne i32 %t79, 0
  br i1 %t80, label %bb21, label %ok.81, !prof !99
ok.81:
  store { i64, ptr } %t78, ptr %l32
  br label %bb20
bb20:
  %t82 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t82, ptr %l30, !tbaa !27
  br label %bb22
bb21:
  %t83 = load i32, ptr %l33, !tbaa !23
  %t84 = lshr i32 %t83, 16
  %t85 = and i32 %t83, 65535
  %t86 = icmp eq i32 %t84, 1
  %t87 = select i1 %t86, i32 1, i32 0
  %t88 = icmp eq i32 %t83, 0
  %t89 = shl i32 %t87, 16
  %t90 = or i32 %t89, %t85
  %t91 = select i1 %t88, i32 0, i32 %t90
  call void @__olang_scope_close(ptr %s0)
  %t93 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t91, 0
  store { i32, { i64, ptr } } %t93, ptr %rv
  br label %ret
bb22:
  %t94 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t94, ptr %l3, !tbaa !27
  %t95 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t95, 0
  %t99 = icmp eq i64 %t97, 0
  br i1 %t99, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s5
  %t101 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t101, ptr %l39, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t103, 0
  store i64 %t104, ptr %l40, !tbaa !24
  %t105 = load i64, ptr %l40, !tbaa !24
  %t106 = mul i64 %t105, 1
  %t107 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t106)
  %t108 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t107, 1
  store { i64, ptr } %t109, ptr %l41, !tbaa !27
  %t110 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = load i64, ptr %l40, !tbaa !24
  %t115 = mul i64 %t114, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t111, ptr %t113, i64 %t115, i1 false)
  store { i64, [2 x i64] } zeroinitializer, ptr %t116
  %t117 = getelementptr { i64, [2 x i64] }, ptr %t116, i32 0, i32 0
  store i64 6, ptr %t117
  %t118 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t119 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t118, 0
  %t120 = getelementptr { i64, [2 x i64] }, ptr %t116, i32 0, i32 1
  store { { i64, ptr } } %t119, ptr %t120
  %t121 = load { i64, [2 x i64] }, ptr %t116
  store { i64, [2 x i64] } %t121, ptr %l42
  %t122 = call ptr @__olang_errpay_push()
  %t123 = ptrtoint ptr %t122 to i64
  store i64 %t123, ptr %l43, !tbaa !24
  %t124 = load i64, ptr %l43
  %t125 = inttoptr i64 %t124 to ptr
  %t127 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fnet_3aError_24payload(ptr %t125, ptr %l42)
  store { i64, [2 x i64] } %t127, ptr %l45
  br label %bb25
bb24:
  br label %bb26
bb25:
  %t128 = load { i64, [2 x i64] }, ptr %l45
  %t129 = load i64, ptr %l43
  %t130 = inttoptr i64 %t129 to ptr
  %t131 = call ptr @__olang_scope_alloc_a(ptr %t130, i64 24, i64 8)
  store { i64, [2 x i64] } %t128, ptr %t131
  call void @__olang_errpay_set(ptr %t131)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t134 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65542, 0
  store { i32, { i64, ptr } } %t134, ptr %rv
  br label %ret
bb26:
  %t135 = load { i64, ptr }, ptr %l3, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t137 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t135, 1
  store { i32, { i64, ptr } } %t137, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, %"std/net:UDP" } @std_2fnet_2eUDP_2eListen(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l16 = alloca { i64, ptr }
  %l19 = alloca i32
  %l21 = alloca i32
  %l23 = alloca i32
  %l24 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l27 = alloca i32
  %l30 = alloca %"std/net:UDP"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.builder
  %s3room = alloca [64 x i8], align 8
  %rv = alloca { i32, %"std/net:UDP" }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr @G_2estd_2fnet_2esockDgram, !tbaa !23
  %t5 = call { i32, i32 } @std_2fnet_2eopen(ptr %v0, ptr %t1, i32 %t2)
  %t6 = extractvalue { i32, i32 } %t5, 1
  %t7 = extractvalue { i32, i32 } %t5, 0
  store i32 %t7, ptr %l8
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9, !prof !99
ok.9:
  store i32 %t6, ptr %l7
  br label %bb1
bb1:
  %t10 = load i32, ptr %l7, !tbaa !23
  store i32 %t10, ptr %l4, !tbaa !23
  br label %bb3
bb2:
  %t11 = load i32, ptr %l8, !tbaa !23
  %t12 = lshr i32 %t11, 16
  %t13 = and i32 %t11, 65535
  %t14 = icmp eq i32 %t12, 1
  %t15 = select i1 %t14, i32 1, i32 0
  %t16 = icmp eq i32 %t11, 0
  %t17 = shl i32 %t15, 16
  %t18 = or i32 %t17, %t13
  %t19 = select i1 %t16, i32 0, i32 %t18
  call void @__olang_scope_close(ptr %s0)
  %t21 = insertvalue { i32, %"std/net:UDP" } zeroinitializer, i32 %t19, 0
  store { i32, %"std/net:UDP" } %t21, ptr %rv
  br label %ret
bb3:
  %t22 = load i32, ptr %l4, !tbaa !23
  store i32 %t22, ptr %l1, !tbaa !23
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"std/net:Addr", ptr %t23, i32 0, i32 0
  %t26 = getelementptr %"std/net:IP", ptr %t25, i32 0, i32 0
  %t27 = load i1, ptr %t26, !tbaa !21
  br i1 %t27, label %bb4, label %bb5
bb4:
  %t29 = load i32, ptr %l1, !tbaa !23
  %t30 = load i32, ptr @G_2estd_2fnet_2eipprotoIpv6, !tbaa !23
  %t31 = load i32, ptr @G_2estd_2fnet_2eipv6V6only, !tbaa !23
  call void @std_2fnet_2esetInt(i32 %t29, i32 %t30, i32 %t31, i32 0)
  br label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb7
bb7:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = call { i64, ptr } @std_2fnet_2esockaddr(ptr %v0, ptr %s0, ptr %t35)
  store { i64, ptr } %t37, ptr %l16
  br label %bb8
bb8:
  %t38 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t39 = load i32, ptr %l1, !tbaa !23
  %t43 = call i32 @std_2fnet_2esysBind(ptr %s0, i32 %t39, { i64, ptr } %t38)
  store i32 %t43, ptr %l19
  br label %bb9
bb9:
  %t44 = load i32, ptr %l19, !tbaa !23
  %t45 = icmp slt i32 %t44, 0
  br i1 %t45, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t47 = call i32 @std_2fnet_2esockErr()
  store i32 %t47, ptr %l21
  br label %bb12
bb11:
  br label %bb18
bb12:
  %t48 = load i32, ptr %l21, !tbaa !23
  store i32 %t48, ptr %l3, !tbaa !23
  %t49 = load i32, ptr %l1, !tbaa !23
  call void @std_2fnet_2ecloseSock(i32 %t49)
  br label %bb13
bb13:
  %t51 = load i32, ptr %l3, !tbaa !23
  store i32 %t51, ptr %l23, !tbaa !23
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l24, !tbaa !29
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s3
  store ptr %s3room, ptr %s3
  call void @olang_2emir_2eHelperKind_2eRender_2estd_2fnet_3aAddr_26(ptr %s3, ptr %l24, i64 0)
  br label %bb14
bb14:
  %t54 = load ptr, ptr %s3
  %t55 = getelementptr %olang.builder, ptr %s3, i32 0, i32 1
  %t56 = load i64, ptr %t55
  %t57 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t56)
  call void @olang_textcopy(ptr %t57, ptr %t54, i64 %t56)
  %t58 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t57, 1
  store { i64, ptr } %t59, ptr %l26, !tbaa !27
  %t60 = getelementptr %olang.builder, ptr %s3, i32 0, i32 3
  %t61 = load ptr, ptr %t60
  %t62 = icmp ne ptr %t61, null
  br i1 %t62, label %sbgrew.63, label %sbdone.64
sbgrew.63:
  call void @__olang_sb_done(ptr %s3)
  br label %sbdone.64
sbdone.64:
  %t65 = load i32, ptr %l23, !tbaa !23
  %t66 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t67 = call i32 @std_2fnet_2eraise(i32 %t65, { i64, ptr } %t66)
  store i32 %t67, ptr %l27
  %t68 = icmp ne i32 %t67, 0
  br i1 %t68, label %bb16, label %ok.69, !prof !99
ok.69:
  br label %bb15
bb15:
  br label %bb17
bb16:
  %t70 = load i32, ptr %l27, !tbaa !23
  %t71 = lshr i32 %t70, 16
  %t72 = and i32 %t70, 65535
  %t73 = icmp eq i32 %t71, 1
  %t74 = select i1 %t73, i32 1, i32 0
  %t75 = icmp eq i32 %t70, 0
  %t76 = shl i32 %t74, 16
  %t77 = or i32 %t76, %t72
  %t78 = select i1 %t75, i32 0, i32 %t77
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t80 = insertvalue { i32, %"std/net:UDP" } zeroinitializer, i32 %t78, 0
  store { i32, %"std/net:UDP" } %t80, ptr %rv
  br label %ret
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  %t81 = load i32, ptr %l1, !tbaa !23
  %t83 = call %"std/net:UDP" @std_2fnet_3aUDP_2ector(ptr %s0, i32 %t81)
  store %"std/net:UDP" %t83, ptr %l30
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  %t84 = load %"std/net:UDP", ptr %l30
  %t85 = insertvalue { i32, %"std/net:UDP" } zeroinitializer, %"std/net:UDP" %t84, 1
  store { i32, %"std/net:UDP" } %t85, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/net:UDP" }, ptr %rv
  ret { i32, %"std/net:UDP" } %rr
}

define dso_local void @std_2fnet_2eaddOnce(ptr %v0, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca [28 x i8]
  %l4 = alloca %"std/net:IP"
  %l6 = alloca [28 x i8]
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca ptr
  %l14 = alloca %"std/net:Addr"
  %l19 = alloca i1
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  br label %fill.4
fill.4:
  br label %fill.1
fill.1:
  %t5 = phi i64 [ 0, %fill.4 ], [ %t6, %fill.2 ]
  %t7 = icmp slt i64 %t5, 28
  br i1 %t7, label %fill.2, label %fill.3
fill.2:
  %t8 = getelementptr [28 x i8], ptr %l6, i64 0, i64 %t5
  store i8 0, ptr %t8
  %t6 = add i64 %t5, 1
  br label %fill.1
fill.3:
  %t9 = load [28 x i8], ptr %l6
  store [28 x i8] %t9, ptr %l3
  store ptr %l3, ptr %l7
  store ptr %a1, ptr %l8, !tbaa !29
  %t13 = call i64 @std_2fprelude_2fnumber_2eU64_2eMin_3cU64_3e(i64 %a2, i64 28)
  store i64 %t13, ptr %l10
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l7
  %t15 = load ptr, ptr %l8, !tbaa !29
  %t16 = load i64, ptr %l10, !tbaa !65
  %t17 = call ptr @memmove(ptr %t14, ptr %t15, i64 %t16)
  store ptr %t17, ptr %l11
  br label %bb2
bb2:
  %t19 = insertvalue { i64, ptr } undef, i64 28, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %l3, 1
  %t22 = call %"std/net:Addr" @std_2fnet_2eAddr_2efromSockaddr(ptr %s0, { i64, ptr } %t20)
  store %"std/net:Addr" %t22, ptr %l14
  br label %bb3
bb3:
  %t23 = getelementptr %"std/net:Addr", ptr %l14, i32 0, i32 0
  %t24 = load %"std/net:IP", ptr %t23
  store %"std/net:IP" %t24, ptr %l4
  %t26 = load %"std/net:IP", ptr %l4
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t32 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fnet_3aIP_3e_2eHas_3cstd_2fnet_3aIP_3e(ptr %v0, ptr %t28, %"std/net:IP" %t26)
  store i1 %t32, ptr %l19
  br label %bb4
bb4:
  %t33 = load i1, ptr %l19, !tbaa !21
  %t34 = xor i1 %t33, true
  br i1 %t34, label %bb5, label %bb6
bb5:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load %"std/net:IP", ptr %l4
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fnet_3aIP_3e_2ePush_3cstd_2fnet_3aIP_3e(ptr %v0, ptr %t36, %"std/net:IP" %t37)
  br label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @std_2fnet_2ehexDigit(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l2 = alloca i1
  %l8 = alloca i1
  %l17 = alloca i1
  %rv = alloca i64
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i8, ptr %l0, !tbaa !22
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t1)
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  %t5 = load i8, ptr %l0, !tbaa !22
  %t7 = sub i8 %t5, 48
  %t9 = zext i8 %t7 to i64
  store i64 %t9, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load i8, ptr %l0, !tbaa !22
  %t13 = icmp uge i8 %t11, 97
  br i1 %t13, label %bb5, label %bb6
bb5:
  %t15 = load i8, ptr %l0, !tbaa !22
  %t17 = icmp ule i8 %t15, 102
  store i1 %t17, ptr %l8, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb7
bb7:
  %t19 = load i1, ptr %l8, !tbaa !21
  br i1 %t19, label %bb8, label %bb9
bb8:
  %t20 = load i8, ptr %l0, !tbaa !22
  %t22 = sub i8 %t20, 97
  %t24 = zext i8 %t22 to i64
  %t26 = add i64 %t24, 10
  store i64 %t26, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t28 = load i8, ptr %l0, !tbaa !22
  %t30 = icmp uge i8 %t28, 65
  br i1 %t30, label %bb11, label %bb12
bb11:
  %t32 = load i8, ptr %l0, !tbaa !22
  %t34 = icmp ule i8 %t32, 70
  store i1 %t34, ptr %l17, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb13
bb13:
  %t36 = load i1, ptr %l17, !tbaa !21
  br i1 %t36, label %bb14, label %bb15
bb14:
  %t37 = load i8, ptr %l0, !tbaa !22
  %t39 = sub i8 %t37, 65
  %t41 = zext i8 %t39 to i64
  %t43 = add i64 %t41, 10
  store i64 %t43, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @std_2fnet_2elookupFailed(ptr %v0, i32 %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca i32
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, [2 x i64] }
  %l21 = alloca i64
  %l23 = alloca { i64, [2 x i64] }
  %l30 = alloca { i64, [2 x i64] }
  %l31 = alloca i64
  %l33 = alloca { i64, [2 x i64] }
  %l36 = alloca { i64, [2 x i64] }
  %l37 = alloca i64
  %l39 = alloca { i64, [2 x i64] }
  %s1 = alloca %olang.scope
  %rv = alloca i32
  %t44 = alloca { i64, [2 x i64] }, align 8
  %t70 = alloca { i64, [2 x i64] }, align 8
  %t85 = alloca { i64, [2 x i64] }, align 8
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !tbaa !23
  %t3 = icmp eq i32 %t1, -2
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %bb15
bb2:
  %t5 = load i32, ptr %l0, !tbaa !23
  %t7 = icmp eq i32 %t5, -5
  br i1 %t7, label %bb3, label %bb4
bb3:
  br label %bb15
bb4:
  %t9 = load i32, ptr %l0, !tbaa !23
  %t11 = icmp eq i32 %t9, -4
  br i1 %t11, label %bb5, label %bb6
bb5:
  br label %bb15
bb6:
  %t13 = load i32, ptr %l0, !tbaa !23
  %t15 = icmp eq i32 %t13, -9
  br i1 %t15, label %bb7, label %bb8
bb7:
  br label %bb15
bb8:
  %t17 = load i32, ptr %l0, !tbaa !23
  %t19 = icmp eq i32 %t17, 11001
  br i1 %t19, label %bb9, label %bb10
bb9:
  br label %bb15
bb10:
  %t21 = load i32, ptr %l0, !tbaa !23
  %t23 = icmp eq i32 %t21, 11003
  br i1 %t23, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  %t25 = load i32, ptr %l0, !tbaa !23
  %t27 = icmp eq i32 %t25, 11004
  br i1 %t27, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb17
bb15:
  store %olang.scope zeroinitializer, ptr %s1
  store { i64, ptr } %a1, ptr %l17, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l18, !tbaa !24
  %t33 = load i64, ptr %l18, !tbaa !24
  %t34 = mul i64 %t33, 1
  %t35 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t34)
  %t36 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  store { i64, ptr } %t37, ptr %l19, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = load i64, ptr %l18, !tbaa !24
  %t43 = mul i64 %t42, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t39, ptr %t41, i64 %t43, i1 false)
  store { i64, [2 x i64] } zeroinitializer, ptr %t44
  %t45 = getelementptr { i64, [2 x i64] }, ptr %t44, i32 0, i32 0
  store i64 6, ptr %t45
  %t46 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t47 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t46, 0
  %t48 = getelementptr { i64, [2 x i64] }, ptr %t44, i32 0, i32 1
  store { { i64, ptr } } %t47, ptr %t48
  %t49 = load { i64, [2 x i64] }, ptr %t44
  store { i64, [2 x i64] } %t49, ptr %l20
  %t50 = call ptr @__olang_errpay_push()
  %t51 = ptrtoint ptr %t50 to i64
  store i64 %t51, ptr %l21, !tbaa !24
  %t52 = load i64, ptr %l21
  %t53 = inttoptr i64 %t52 to ptr
  %t55 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fnet_3aError_24payload(ptr %t53, ptr %l20)
  store { i64, [2 x i64] } %t55, ptr %l23
  br label %bb16
bb16:
  %t56 = load { i64, [2 x i64] }, ptr %l23
  %t57 = load i64, ptr %l21
  %t58 = inttoptr i64 %t57 to ptr
  %t59 = call ptr @__olang_scope_alloc_a(ptr %t58, i64 24, i64 8)
  store { i64, [2 x i64] } %t56, ptr %t59
  call void @__olang_errpay_set(ptr %t59)
  call void @__olang_scope_close(ptr %s1)
  store i32 65542, ptr %rv
  br label %ret
bb17:
  %t62 = load i32, ptr %l0, !tbaa !23
  %t64 = icmp eq i32 %t62, -3
  br i1 %t64, label %bb18, label %bb19
bb18:
  br label %bb22
bb19:
  %t66 = load i32, ptr %l0, !tbaa !23
  %t68 = icmp eq i32 %t66, 11002
  br i1 %t68, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb24
bb22:
  store { i64, [2 x i64] } zeroinitializer, ptr %t70
  %t71 = getelementptr { i64, [2 x i64] }, ptr %t70, i32 0, i32 0
  store i64 4, ptr %t71
  %t72 = load { i64, [2 x i64] }, ptr %t70
  store { i64, [2 x i64] } %t72, ptr %l30
  %t73 = call ptr @__olang_errpay_push()
  %t74 = ptrtoint ptr %t73 to i64
  store i64 %t74, ptr %l31, !tbaa !24
  %t75 = load i64, ptr %l31
  %t76 = inttoptr i64 %t75 to ptr
  %t78 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fnet_3aError_24payload(ptr %t76, ptr %l30)
  store { i64, [2 x i64] } %t78, ptr %l33
  br label %bb23
bb23:
  %t79 = load { i64, [2 x i64] }, ptr %l33
  %t80 = load i64, ptr %l31
  %t81 = inttoptr i64 %t80 to ptr
  %t82 = call ptr @__olang_scope_alloc_a(ptr %t81, i64 24, i64 8)
  store { i64, [2 x i64] } %t79, ptr %t82
  call void @__olang_errpay_set(ptr %t82)
  store i32 65540, ptr %rv
  br label %ret
bb24:
  br i1 true, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb29
bb27:
  store { i64, [2 x i64] } zeroinitializer, ptr %t85
  %t86 = getelementptr { i64, [2 x i64] }, ptr %t85, i32 0, i32 0
  store i64 9, ptr %t86
  %t87 = load { i64, [2 x i64] }, ptr %t85
  store { i64, [2 x i64] } %t87, ptr %l36
  %t88 = call ptr @__olang_errpay_push()
  %t89 = ptrtoint ptr %t88 to i64
  store i64 %t89, ptr %l37, !tbaa !24
  %t90 = load i64, ptr %l37
  %t91 = inttoptr i64 %t90 to ptr
  %t93 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fnet_3aError_24payload(ptr %t91, ptr %l36)
  store { i64, [2 x i64] } %t93, ptr %l39
  br label %bb28
bb28:
  %t94 = load { i64, [2 x i64] }, ptr %l39
  %t95 = load i64, ptr %l37
  %t96 = inttoptr i64 %t95 to ptr
  %t97 = call ptr @__olang_scope_alloc_a(ptr %t96, i64 24, i64 8)
  store { i64, [2 x i64] } %t94, ptr %t97
  call void @__olang_errpay_set(ptr %t97)
  store i32 65545, ptr %rv
  br label %ret
bb29:
  call void @__olang_check_failed(ptr @olang_loc_8981c24167caedc7_91d5c812394e4ba3)
  unreachable
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fnet_2eraise(i32 %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca i32
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca i64
  %l7 = alloca { i64, [2 x i64] }
  %l12 = alloca { i64, [2 x i64] }
  %l13 = alloca i64
  %l15 = alloca { i64, [2 x i64] }
  %l20 = alloca { i64, [2 x i64] }
  %l21 = alloca i64
  %l23 = alloca { i64, [2 x i64] }
  %l28 = alloca { i64, [2 x i64] }
  %l29 = alloca i64
  %l31 = alloca { i64, [2 x i64] }
  %l36 = alloca { i64, [2 x i64] }
  %l37 = alloca i64
  %l39 = alloca { i64, [2 x i64] }
  %l44 = alloca { i64, [2 x i64] }
  %l45 = alloca i64
  %l47 = alloca { i64, [2 x i64] }
  %l52 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca { i64, ptr }
  %l55 = alloca { i64, [2 x i64] }
  %l56 = alloca i64
  %l58 = alloca { i64, [2 x i64] }
  %l61 = alloca { i64, [2 x i64] }
  %l62 = alloca i64
  %l64 = alloca { i64, [2 x i64] }
  %s7 = alloca %olang.scope
  %rv = alloca i32
  %t5 = alloca { i64, [2 x i64] }, align 8
  %t24 = alloca { i64, [2 x i64] }, align 8
  %t43 = alloca { i64, [2 x i64] }, align 8
  %t62 = alloca { i64, [2 x i64] }, align 8
  %t81 = alloca { i64, [2 x i64] }, align 8
  %t100 = alloca { i64, [2 x i64] }, align 8
  %t133 = alloca { i64, [2 x i64] }, align 8
  %t151 = alloca { i64, [2 x i64] }, align 8
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !tbaa !23
  %t3 = icmp eq i32 %t1, 3
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb5
bb3:
  store { i64, [2 x i64] } zeroinitializer, ptr %t5
  %t6 = getelementptr { i64, [2 x i64] }, ptr %t5, i32 0, i32 0
  store i64 8, ptr %t6
  %t7 = load { i64, [2 x i64] }, ptr %t5
  store { i64, [2 x i64] } %t7, ptr %l4
  %t8 = call ptr @__olang_errpay_push()
  %t9 = ptrtoint ptr %t8 to i64
  store i64 %t9, ptr %l5, !tbaa !24
  %t10 = load i64, ptr %l5
  %t11 = inttoptr i64 %t10 to ptr
  %t13 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fnet_3aError_24payload(ptr %t11, ptr %l4)
  store { i64, [2 x i64] } %t13, ptr %l7
  br label %bb4
bb4:
  %t14 = load { i64, [2 x i64] }, ptr %l7
  %t15 = load i64, ptr %l5
  %t16 = inttoptr i64 %t15 to ptr
  %t17 = call ptr @__olang_scope_alloc_a(ptr %t16, i64 24, i64 8)
  store { i64, [2 x i64] } %t14, ptr %t17
  call void @__olang_errpay_set(ptr %t17)
  store i32 65544, ptr %rv
  br label %ret
bb5:
  %t20 = load i32, ptr %l0, !tbaa !23
  %t22 = icmp eq i32 %t20, 7
  br i1 %t22, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb10
bb8:
  store { i64, [2 x i64] } zeroinitializer, ptr %t24
  %t25 = getelementptr { i64, [2 x i64] }, ptr %t24, i32 0, i32 0
  store i64 0, ptr %t25
  %t26 = load { i64, [2 x i64] }, ptr %t24
  store { i64, [2 x i64] } %t26, ptr %l12
  %t27 = call ptr @__olang_errpay_push()
  %t28 = ptrtoint ptr %t27 to i64
  store i64 %t28, ptr %l13, !tbaa !24
  %t29 = load i64, ptr %l13
  %t30 = inttoptr i64 %t29 to ptr
  %t32 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fnet_3aError_24payload(ptr %t30, ptr %l12)
  store { i64, [2 x i64] } %t32, ptr %l15
  br label %bb9
bb9:
  %t33 = load { i64, [2 x i64] }, ptr %l15
  %t34 = load i64, ptr %l13
  %t35 = inttoptr i64 %t34 to ptr
  %t36 = call ptr @__olang_scope_alloc_a(ptr %t35, i64 24, i64 8)
  store { i64, [2 x i64] } %t33, ptr %t36
  call void @__olang_errpay_set(ptr %t36)
  store i32 65536, ptr %rv
  br label %ret
bb10:
  %t39 = load i32, ptr %l0, !tbaa !23
  %t41 = icmp eq i32 %t39, 8
  br i1 %t41, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb15
bb13:
  store { i64, [2 x i64] } zeroinitializer, ptr %t43
  %t44 = getelementptr { i64, [2 x i64] }, ptr %t43, i32 0, i32 0
  store i64 1, ptr %t44
  %t45 = load { i64, [2 x i64] }, ptr %t43
  store { i64, [2 x i64] } %t45, ptr %l20
  %t46 = call ptr @__olang_errpay_push()
  %t47 = ptrtoint ptr %t46 to i64
  store i64 %t47, ptr %l21, !tbaa !24
  %t48 = load i64, ptr %l21
  %t49 = inttoptr i64 %t48 to ptr
  %t51 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fnet_3aError_24payload(ptr %t49, ptr %l20)
  store { i64, [2 x i64] } %t51, ptr %l23
  br label %bb14
bb14:
  %t52 = load { i64, [2 x i64] }, ptr %l23
  %t53 = load i64, ptr %l21
  %t54 = inttoptr i64 %t53 to ptr
  %t55 = call ptr @__olang_scope_alloc_a(ptr %t54, i64 24, i64 8)
  store { i64, [2 x i64] } %t52, ptr %t55
  call void @__olang_errpay_set(ptr %t55)
  store i32 65537, ptr %rv
  br label %ret
bb15:
  %t58 = load i32, ptr %l0, !tbaa !23
  %t60 = icmp eq i32 %t58, 9
  br i1 %t60, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb20
bb18:
  store { i64, [2 x i64] } zeroinitializer, ptr %t62
  %t63 = getelementptr { i64, [2 x i64] }, ptr %t62, i32 0, i32 0
  store i64 2, ptr %t63
  %t64 = load { i64, [2 x i64] }, ptr %t62
  store { i64, [2 x i64] } %t64, ptr %l28
  %t65 = call ptr @__olang_errpay_push()
  %t66 = ptrtoint ptr %t65 to i64
  store i64 %t66, ptr %l29, !tbaa !24
  %t67 = load i64, ptr %l29
  %t68 = inttoptr i64 %t67 to ptr
  %t70 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fnet_3aError_24payload(ptr %t68, ptr %l28)
  store { i64, [2 x i64] } %t70, ptr %l31
  br label %bb19
bb19:
  %t71 = load { i64, [2 x i64] }, ptr %l31
  %t72 = load i64, ptr %l29
  %t73 = inttoptr i64 %t72 to ptr
  %t74 = call ptr @__olang_scope_alloc_a(ptr %t73, i64 24, i64 8)
  store { i64, [2 x i64] } %t71, ptr %t74
  call void @__olang_errpay_set(ptr %t74)
  store i32 65538, ptr %rv
  br label %ret
bb20:
  %t77 = load i32, ptr %l0, !tbaa !23
  %t79 = icmp eq i32 %t77, 10
  br i1 %t79, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb25
bb23:
  store { i64, [2 x i64] } zeroinitializer, ptr %t81
  %t82 = getelementptr { i64, [2 x i64] }, ptr %t81, i32 0, i32 0
  store i64 3, ptr %t82
  %t83 = load { i64, [2 x i64] }, ptr %t81
  store { i64, [2 x i64] } %t83, ptr %l36
  %t84 = call ptr @__olang_errpay_push()
  %t85 = ptrtoint ptr %t84 to i64
  store i64 %t85, ptr %l37, !tbaa !24
  %t86 = load i64, ptr %l37
  %t87 = inttoptr i64 %t86 to ptr
  %t89 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fnet_3aError_24payload(ptr %t87, ptr %l36)
  store { i64, [2 x i64] } %t89, ptr %l39
  br label %bb24
bb24:
  %t90 = load { i64, [2 x i64] }, ptr %l39
  %t91 = load i64, ptr %l37
  %t92 = inttoptr i64 %t91 to ptr
  %t93 = call ptr @__olang_scope_alloc_a(ptr %t92, i64 24, i64 8)
  store { i64, [2 x i64] } %t90, ptr %t93
  call void @__olang_errpay_set(ptr %t93)
  store i32 65539, ptr %rv
  br label %ret
bb25:
  %t96 = load i32, ptr %l0, !tbaa !23
  %t98 = icmp eq i32 %t96, 11
  br i1 %t98, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb30
bb28:
  store { i64, [2 x i64] } zeroinitializer, ptr %t100
  %t101 = getelementptr { i64, [2 x i64] }, ptr %t100, i32 0, i32 0
  store i64 4, ptr %t101
  %t102 = load { i64, [2 x i64] }, ptr %t100
  store { i64, [2 x i64] } %t102, ptr %l44
  %t103 = call ptr @__olang_errpay_push()
  %t104 = ptrtoint ptr %t103 to i64
  store i64 %t104, ptr %l45, !tbaa !24
  %t105 = load i64, ptr %l45
  %t106 = inttoptr i64 %t105 to ptr
  %t108 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fnet_3aError_24payload(ptr %t106, ptr %l44)
  store { i64, [2 x i64] } %t108, ptr %l47
  br label %bb29
bb29:
  %t109 = load { i64, [2 x i64] }, ptr %l47
  %t110 = load i64, ptr %l45
  %t111 = inttoptr i64 %t110 to ptr
  %t112 = call ptr @__olang_scope_alloc_a(ptr %t111, i64 24, i64 8)
  store { i64, [2 x i64] } %t109, ptr %t112
  call void @__olang_errpay_set(ptr %t112)
  store i32 65540, ptr %rv
  br label %ret
bb30:
  %t115 = load i32, ptr %l0, !tbaa !23
  %t117 = icmp eq i32 %t115, 12
  br i1 %t117, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb35
bb33:
  store %olang.scope zeroinitializer, ptr %s7
  store { i64, ptr } %a1, ptr %l52, !tbaa !27
  %t120 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t120, 0
  store i64 %t121, ptr %l53, !tbaa !24
  %t122 = load i64, ptr %l53, !tbaa !24
  %t123 = mul i64 %t122, 1
  %t124 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t123)
  %t125 = insertvalue { i64, ptr } undef, i64 %t122, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t124, 1
  store { i64, ptr } %t126, ptr %l54, !tbaa !27
  %t127 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !27
  %t129 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = load i64, ptr %l53, !tbaa !24
  %t132 = mul i64 %t131, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t128, ptr %t130, i64 %t132, i1 false)
  store { i64, [2 x i64] } zeroinitializer, ptr %t133
  %t134 = getelementptr { i64, [2 x i64] }, ptr %t133, i32 0, i32 0
  store i64 5, ptr %t134
  %t135 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t136 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t135, 0
  %t137 = getelementptr { i64, [2 x i64] }, ptr %t133, i32 0, i32 1
  store { { i64, ptr } } %t136, ptr %t137
  %t138 = load { i64, [2 x i64] }, ptr %t133
  store { i64, [2 x i64] } %t138, ptr %l55
  %t139 = call ptr @__olang_errpay_push()
  %t140 = ptrtoint ptr %t139 to i64
  store i64 %t140, ptr %l56, !tbaa !24
  %t141 = load i64, ptr %l56
  %t142 = inttoptr i64 %t141 to ptr
  %t144 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fnet_3aError_24payload(ptr %t142, ptr %l55)
  store { i64, [2 x i64] } %t144, ptr %l58
  br label %bb34
bb34:
  %t145 = load { i64, [2 x i64] }, ptr %l58
  %t146 = load i64, ptr %l56
  %t147 = inttoptr i64 %t146 to ptr
  %t148 = call ptr @__olang_scope_alloc_a(ptr %t147, i64 24, i64 8)
  store { i64, [2 x i64] } %t145, ptr %t148
  call void @__olang_errpay_set(ptr %t148)
  call void @__olang_scope_close(ptr %s7)
  store i32 65541, ptr %rv
  br label %ret
bb35:
  br i1 true, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb40
bb38:
  store { i64, [2 x i64] } zeroinitializer, ptr %t151
  %t152 = getelementptr { i64, [2 x i64] }, ptr %t151, i32 0, i32 0
  store i64 9, ptr %t152
  %t153 = load { i64, [2 x i64] }, ptr %t151
  store { i64, [2 x i64] } %t153, ptr %l61
  %t154 = call ptr @__olang_errpay_push()
  %t155 = ptrtoint ptr %t154 to i64
  store i64 %t155, ptr %l62, !tbaa !24
  %t156 = load i64, ptr %l62
  %t157 = inttoptr i64 %t156 to ptr
  %t159 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fnet_3aError_24payload(ptr %t157, ptr %l61)
  store { i64, [2 x i64] } %t159, ptr %l64
  br label %bb39
bb39:
  %t160 = load { i64, [2 x i64] }, ptr %l64
  %t161 = load i64, ptr %l62
  %t162 = inttoptr i64 %t161 to ptr
  %t163 = call ptr @__olang_scope_alloc_a(ptr %t162, i64 24, i64 8)
  store { i64, [2 x i64] } %t160, ptr %t163
  call void @__olang_errpay_set(ptr %t163)
  store i32 65545, ptr %rv
  br label %ret
bb40:
  call void @__olang_check_failed(ptr @olang_loc_bc64e253b1e7f486_2f7ea114c0e9c0f2)
  unreachable
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @std_2fnet_2esockaddr(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l22 = alloca i32
  %l44 = alloca i64
  %l47 = alloca i64
  %l56 = alloca i64
  %l59 = alloca i1
  %l80 = alloca i64
  %l83 = alloca i64
  %l92 = alloca i64
  %l95 = alloca i1
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/net:Addr", ptr %t1, i32 0, i32 0
  %t4 = getelementptr %"std/net:IP", ptr %t3, i32 0, i32 0
  %t5 = load i1, ptr %t4, !tbaa !21
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i64 28, ptr %l17, !tbaa !24
  br label %bb3
bb2:
  store i64 16, ptr %l17, !tbaa !24
  br label %bb3
bb3:
  %t7 = load i64, ptr %l17, !tbaa !24
  %t8 = icmp sge i64 %t7, 0
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load i64, ptr %l17, !tbaa !24
  %t11 = mul i64 %t10, 1
  %t12 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l1, !tbaa !27
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"std/net:Addr", ptr %t16, i32 0, i32 0
  %t19 = getelementptr %"std/net:IP", ptr %t18, i32 0, i32 0
  %t20 = load i1, ptr %t19, !tbaa !21
  br i1 %t20, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_f53fdd983c71e658_198e9c3d6c980e94)
  unreachable
bb6:
  %t22 = load i32, ptr @G_2estd_2fnet_2eafInet6, !tbaa !23
  store i32 %t22, ptr %l22, !tbaa !23
  br label %bb8
bb7:
  %t24 = load i32, ptr @G_2estd_2fnet_2eafInet, !tbaa !23
  store i32 %t24, ptr %l22, !tbaa !23
  br label %bb8
bb8:
  %t26 = load i32, ptr %l22, !tbaa !23
  store i32 %t26, ptr %l2, !tbaa !23
  %t27 = load i32, ptr %l2, !tbaa !23
  %t29 = and i32 %t27, 255
  %t31 = trunc i32 %t29 to i8
  %t33 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr i8, ptr %t34, i64 0
  store i8 %t31, ptr %t35, !tbaa !32
  %t36 = load i32, ptr %l2, !tbaa !23
  %t38 = ashr i32 %t36, 8
  %t40 = trunc i32 %t38 to i8
  %t42 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr i8, ptr %t43, i64 1
  store i8 %t40, ptr %t44, !tbaa !32
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"std/net:Addr", ptr %t45, i32 0, i32 1
  %t48 = load i16, ptr %t47, !tbaa !63
  %t50 = lshr i16 %t48, 8
  %t52 = trunc i16 %t50 to i8
  %t54 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i8, ptr %t55, i64 2
  store i8 %t52, ptr %t56, !tbaa !32
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"std/net:Addr", ptr %t57, i32 0, i32 1
  %t60 = load i16, ptr %t59, !tbaa !63
  %t62 = and i16 %t60, 255
  %t64 = trunc i16 %t62 to i8
  %t66 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = getelementptr i8, ptr %t67, i64 3
  store i8 %t64, ptr %t68, !tbaa !32
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"std/net:Addr", ptr %t69, i32 0, i32 0
  %t72 = getelementptr %"std/net:IP", ptr %t71, i32 0, i32 0
  %t73 = load i1, ptr %t72, !tbaa !21
  br i1 %t73, label %bb9, label %bb10
bb9:
  store i64 0, ptr %l3, !tbaa !24
  store i64 16, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t75 = load i64, ptr %l4, !tbaa !24
  %t76 = load i64, ptr %l3, !tbaa !24
  %t79 = icmp sgt i64 %t75, %t76
  br i1 %t79, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l9, !tbaa !24
  store i64 4, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t81 = load i64, ptr %l10, !tbaa !24
  %t82 = load i64, ptr %l9, !tbaa !24
  %t85 = icmp sgt i64 %t81, %t82
  br i1 %t85, label %bb23, label %bb24
bb11:
  %t87 = load i64, ptr %l5, !tbaa !24
  %t89 = icmp sgt i64 %t87, 0
  br i1 %t89, label %bb13, label %bb14
bb12:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb16
bb13:
  %t91 = load i64, ptr %l4, !tbaa !24
  %t92 = load i64, ptr %l3, !tbaa !24
  %t95 = sub i64 %t91, %t92
  %t96 = load i64, ptr %l5, !tbaa !24
  %t99 = add i64 %t95, %t96
  %t101 = sub i64 %t99, 1
  %t102 = load i64, ptr %l5, !tbaa !24
  %t105 = sdiv i64 %t101, %t102
  store i64 %t105, ptr %l47, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l47, !tbaa !24
  br label %bb15
bb15:
  %t107 = load i64, ptr %l47, !tbaa !24
  store i64 %t107, ptr %l44, !tbaa !24
  br label %bb16
bb16:
  %t108 = load i64, ptr %l44, !tbaa !24
  store i64 %t108, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  %t109 = load i64, ptr %l6, !tbaa !24
  %t110 = sub i64 %t109, 1
  store i64 %t110, ptr %l56, !tbaa !24
  %t111 = load i64, ptr %l6, !tbaa !24
  %t112 = icmp slt i64 %t111, 2147483648
  %t113 = load i64, ptr %l7, !tbaa !24
  %t114 = icmp sge i64 %t113, 0
  %t117 = and i1 %t112, %t114
  store i1 %t117, ptr %l59, !tbaa !21
  br label %bb17
bb17:
  %t118 = load i64, ptr %l7, !tbaa !24
  %t119 = load i64, ptr %l6, !tbaa !24
  %t122 = icmp slt i64 %t118, %t119
  %t124 = xor i1 %t122, true
  br i1 %t124, label %bb18, label %bb19
bb18:
  br label %bb22
bb19:
  br label %bb20
bb20:
  %t126 = load i64, ptr %l3, !tbaa !24
  %t127 = load i64, ptr %l7, !tbaa !24
  %t128 = load i64, ptr %l5, !tbaa !24
  %t131 = mul i64 %t127, %t128
  %t134 = add i64 %t126, %t131
  store i64 %t134, ptr %l8, !tbaa !24
  %t136 = load i64, ptr %l8, !tbaa !24
  %t138 = add i64 8, %t136
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load i64, ptr %l8, !tbaa !24
  %t142 = getelementptr %"std/net:Addr", ptr %t139, i32 0, i32 0
  %t143 = getelementptr %"std/net:IP", ptr %t142, i32 0, i32 1
  %t145 = getelementptr [16 x i8], ptr %t143, i64 0, i64 %t140
  %t146 = load i8, ptr %t145, !tbaa !32
  %t149 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !27
  %t151 = getelementptr i8, ptr %t150, i64 %t138
  store i8 %t146, ptr %t151, !tbaa !32
  br label %bb21
bb21:
  %t152 = load i64, ptr %l7, !tbaa !24
  %t155 = add i64 %t152, 1
  store i64 %t155, ptr %l7, !tbaa !24
  br label %bb17
bb22:
  br label %bb35
bb23:
  %t157 = load i64, ptr %l11, !tbaa !24
  %t159 = icmp sgt i64 %t157, 0
  br i1 %t159, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l80, !tbaa !24
  br label %bb28
bb25:
  %t161 = load i64, ptr %l10, !tbaa !24
  %t162 = load i64, ptr %l9, !tbaa !24
  %t165 = sub i64 %t161, %t162
  %t166 = load i64, ptr %l11, !tbaa !24
  %t169 = add i64 %t165, %t166
  %t171 = sub i64 %t169, 1
  %t172 = load i64, ptr %l11, !tbaa !24
  %t175 = sdiv i64 %t171, %t172
  store i64 %t175, ptr %l83, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l83, !tbaa !24
  br label %bb27
bb27:
  %t177 = load i64, ptr %l83, !tbaa !24
  store i64 %t177, ptr %l80, !tbaa !24
  br label %bb28
bb28:
  %t178 = load i64, ptr %l80, !tbaa !24
  store i64 %t178, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  %t179 = load i64, ptr %l12, !tbaa !24
  %t180 = sub i64 %t179, 1
  store i64 %t180, ptr %l92, !tbaa !24
  %t181 = load i64, ptr %l12, !tbaa !24
  %t182 = icmp slt i64 %t181, 2147483648
  %t183 = load i64, ptr %l13, !tbaa !24
  %t184 = icmp sge i64 %t183, 0
  %t187 = and i1 %t182, %t184
  store i1 %t187, ptr %l95, !tbaa !21
  br label %bb29
bb29:
  %t188 = load i64, ptr %l13, !tbaa !24
  %t189 = load i64, ptr %l12, !tbaa !24
  %t192 = icmp slt i64 %t188, %t189
  %t194 = xor i1 %t192, true
  br i1 %t194, label %bb30, label %bb31
bb30:
  br label %bb34
bb31:
  br label %bb32
bb32:
  %t196 = load i64, ptr %l9, !tbaa !24
  %t197 = load i64, ptr %l13, !tbaa !24
  %t198 = load i64, ptr %l11, !tbaa !24
  %t201 = mul i64 %t197, %t198
  %t204 = add i64 %t196, %t201
  store i64 %t204, ptr %l14, !tbaa !24
  %t206 = load i64, ptr %l14, !tbaa !24
  %t208 = add i64 4, %t206
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load i64, ptr %l14, !tbaa !24
  %t212 = getelementptr %"std/net:Addr", ptr %t209, i32 0, i32 0
  %t213 = getelementptr %"std/net:IP", ptr %t212, i32 0, i32 1
  %t215 = getelementptr [16 x i8], ptr %t213, i64 0, i64 %t210
  %t216 = load i8, ptr %t215, !tbaa !32
  %t219 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t220 = load ptr, ptr %t219, !tbaa !27
  %t221 = getelementptr i8, ptr %t220, i64 %t208
  store i8 %t216, ptr %t221, !tbaa !32
  br label %bb33
bb33:
  %t222 = load i64, ptr %l13, !tbaa !24
  %t225 = add i64 %t222, 1
  store i64 %t225, ptr %l13, !tbaa !24
  br label %bb29
bb34:
  br label %bb35
bb35:
  %t227 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t227, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @std_2fnet_2estd_2fnet_3aConn_2eRead(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l16 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l28 = alloca { i64, [2 x i64] }
  %l29 = alloca i64
  %l31 = alloca { i64, [2 x i64] }
  %l34 = alloca i1
  %l36 = alloca i32
  %l37 = alloca { i64, ptr }
  %l39 = alloca i32
  %rv = alloca { i32, { i64, ptr } }
  %t64 = alloca { i64, [2 x i64] }, align 8
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t7, ptr %l6, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  store i64 %t9, ptr %l7, !tbaa !24
  %t10 = icmp sge i64 0, 0
  br i1 %t10, label %bb3, label %bb4
bb2:
  br label %bb9
bb3:
  %t12 = icmp sle i64 0, 0
  br i1 %t12, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_3e2092b4cdfb76b1_123327579653ae5d)
  unreachable
bb5:
  %t14 = load i64, ptr %l7, !tbaa !24
  %t15 = icmp sle i64 0, %t14
  br i1 %t15, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_3e2092b4cdfb76b1_123327579653ae5d)
  unreachable
bb7:
  %t17 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr i8, ptr %t18, i64 0
  %t21 = insertvalue { i64, ptr } undef, i64 0, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t19, 1
  %t24 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t22, 1
  store { i32, { i64, ptr } } %t24, ptr %rv
  br label %ret
bb8:
  call void @__olang_check_failed(ptr @olang_loc_3e2092b4cdfb76b1_123327579653ae5d)
  unreachable
bb9:
  br label %bb10
bb10:
  %t27 = getelementptr %"std/net:Conn", ptr %a0, i32 0, i32 0
  %t28 = load i32, ptr %t27, !tbaa !23
  %t29 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t32 = call i64 @std_2fnet_2esysRecv(ptr %v1, i32 %t28, { i64, ptr } %t29)
  store i64 %t32, ptr %l16
  br label %bb11
bb11:
  %t33 = load i64, ptr %l16, !tbaa !24
  store i64 %t33, ptr %l2, !tbaa !24
  %t34 = load i64, ptr %l2, !tbaa !24
  %t36 = icmp sgt i64 %t34, 0
  br i1 %t36, label %bb12, label %bb13
bb12:
  %t38 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t38, ptr %l19, !tbaa !27
  %t39 = load i64, ptr %l2, !tbaa !24
  store i64 %t39, ptr %l20, !tbaa !24
  %t40 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 0
  store i64 %t41, ptr %l21, !tbaa !24
  %t42 = icmp sge i64 0, 0
  br i1 %t42, label %bb14, label %bb15
bb13:
  br label %bb20
bb14:
  %t44 = load i64, ptr %l20, !tbaa !24
  %t45 = icmp sle i64 0, %t44
  br i1 %t45, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_185ce8e381582544_cdbb956a2a7d6800)
  unreachable
bb16:
  %t47 = load i64, ptr %l20, !tbaa !24
  %t48 = load i64, ptr %l21, !tbaa !24
  %t49 = icmp sle i64 %t47, %t48
  br i1 %t49, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_185ce8e381582544_cdbb956a2a7d6800)
  unreachable
bb18:
  %t51 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = load i64, ptr %l20, !tbaa !24
  %t54 = getelementptr i8, ptr %t52, i64 0
  %t55 = sub i64 %t53, 0
  %t56 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t54, 1
  %t59 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t57, 1
  store { i32, { i64, ptr } } %t59, ptr %rv
  br label %ret
bb19:
  call void @__olang_check_failed(ptr @olang_loc_185ce8e381582544_cdbb956a2a7d6800)
  unreachable
bb20:
  %t60 = load i64, ptr %l2, !tbaa !24
  %t62 = icmp eq i64 %t60, 0
  br i1 %t62, label %bb21, label %bb22
bb21:
  store { i64, [2 x i64] } zeroinitializer, ptr %t64
  %t65 = getelementptr { i64, [2 x i64] }, ptr %t64, i32 0, i32 0
  store i64 7, ptr %t65
  %t66 = load { i64, [2 x i64] }, ptr %t64
  store { i64, [2 x i64] } %t66, ptr %l28
  %t67 = call ptr @__olang_errpay_push()
  %t68 = ptrtoint ptr %t67 to i64
  store i64 %t68, ptr %l29, !tbaa !24
  %t69 = load i64, ptr %l29
  %t70 = inttoptr i64 %t69 to ptr
  %t72 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fnet_3aError_24payload(ptr %t70, ptr %l28)
  store { i64, [2 x i64] } %t72, ptr %l31
  br label %bb23
bb22:
  br label %bb24
bb23:
  %t73 = load { i64, [2 x i64] }, ptr %l31
  %t74 = load i64, ptr %l29
  %t75 = inttoptr i64 %t74 to ptr
  %t76 = call ptr @__olang_scope_alloc_a(ptr %t75, i64 24, i64 8)
  store { i64, [2 x i64] } %t73, ptr %t76
  call void @__olang_errpay_set(ptr %t76)
  %t79 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65543, 0
  store { i32, { i64, ptr } } %t79, ptr %rv
  br label %ret
bb24:
  %t80 = call i1 @std_2fnet_2einterrupted()
  store i1 %t80, ptr %l34
  br label %bb25
bb25:
  %t81 = load i1, ptr %l34, !tbaa !21
  %t82 = xor i1 %t81, true
  br i1 %t82, label %bb26, label %bb27
bb26:
  %t84 = call i32 @std_2fnet_2esockErr()
  store i32 %t84, ptr %l36
  br label %bb28
bb27:
  br label %bb32
bb28:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %l37, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t86 = load i32, ptr %l36, !tbaa !23
  %t88 = call i32 @std_2fnet_2eraise(i32 %t86, { i64, ptr } %t85)
  store i32 %t88, ptr %l39
  %t89 = icmp ne i32 %t88, 0
  br i1 %t89, label %bb30, label %ok.90, !prof !99
ok.90:
  br label %bb29
bb29:
  br label %bb31
bb30:
  %t91 = load i32, ptr %l39, !tbaa !23
  %t92 = lshr i32 %t91, 16
  %t93 = and i32 %t91, 65535
  %t94 = icmp eq i32 %t92, 1
  %t95 = select i1 %t94, i32 1, i32 0
  %t96 = icmp eq i32 %t91, 0
  %t97 = shl i32 %t95, 16
  %t98 = or i32 %t97, %t93
  %t99 = select i1 %t96, i32 0, i32 %t98
  %t101 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t99, 0
  store { i32, { i64, ptr } } %t101, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  br label %bb33
bb33:
  br label %bb10
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i64, ptr } @std_2fnet_2estd_2fnet_3aIP_2eStr(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca [8 x i64]
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca %"std/prelude/text:StringBuilder"
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l34 = alloca i64
  %l37 = alloca i64
  %l46 = alloca i64
  %l49 = alloca i1
  %l88 = alloca i1
  %l106 = alloca %"std/prelude/text:StringBuilder"
  %l110 = alloca i64
  %l113 = alloca i64
  %l137 = alloca i1
  %l141 = alloca i1
  %l149 = alloca i1
  %l156 = alloca ptr
  %l158 = alloca i64
  %l159 = alloca i64
  %l160 = alloca i32
  %l161 = alloca { i64, ptr }
  %l167 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/net:IP", ptr %t1, i32 0, i32 0
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"std/net:IP", ptr %t8, i32 0, i32 1
  %t11 = getelementptr [16 x i8], ptr %t10, i64 0, i64 0
  %t12 = load i8, ptr %t11, !tbaa !32
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"std/net:IP", ptr %t13, i32 0, i32 1
  %t16 = getelementptr [16 x i8], ptr %t15, i64 0, i64 1
  %t17 = load i8, ptr %t16, !tbaa !32
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"std/net:IP", ptr %t18, i32 0, i32 1
  %t21 = getelementptr [16 x i8], ptr %t20, i64 0, i64 2
  %t22 = load i8, ptr %t21, !tbaa !32
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"std/net:IP", ptr %t23, i32 0, i32 1
  %t26 = getelementptr [16 x i8], ptr %t25, i64 0, i64 3
  %t27 = load i8, ptr %t26, !tbaa !32
  %t29 = zext i8 %t12 to i64
  %t30 = call i64 @__olang_fmt_u64(ptr null, i64 %t29)
  %t31 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t33 = add i64 %t30, %t32
  %t35 = zext i8 %t17 to i64
  %t36 = call i64 @__olang_fmt_u64(ptr null, i64 %t35)
  %t37 = add i64 %t33, %t36
  %t38 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t39 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t40 = add i64 %t37, %t39
  %t42 = zext i8 %t22 to i64
  %t43 = call i64 @__olang_fmt_u64(ptr null, i64 %t42)
  %t44 = add i64 %t40, %t43
  %t45 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t46 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t47 = add i64 %t44, %t46
  %t49 = zext i8 %t27 to i64
  %t50 = call i64 @__olang_fmt_u64(ptr null, i64 %t49)
  %t51 = add i64 %t47, %t50
  %t52 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t51)
  %t53 = call i64 @__olang_fmt_u64(ptr %t52, i64 %t29)
  %t54 = getelementptr i8, ptr %t52, i64 %t30
  call void @olang_textcopy(ptr %t54, ptr %t31, i64 %t32)
  %t55 = getelementptr i8, ptr %t54, i64 %t32
  %t56 = call i64 @__olang_fmt_u64(ptr %t55, i64 %t35)
  %t57 = getelementptr i8, ptr %t55, i64 %t36
  call void @olang_textcopy(ptr %t57, ptr %t38, i64 %t39)
  %t58 = getelementptr i8, ptr %t57, i64 %t39
  %t59 = call i64 @__olang_fmt_u64(ptr %t58, i64 %t42)
  %t60 = getelementptr i8, ptr %t58, i64 %t43
  call void @olang_textcopy(ptr %t60, ptr %t45, i64 %t46)
  %t61 = getelementptr i8, ptr %t60, i64 %t46
  %t62 = call i64 @__olang_fmt_u64(ptr %t61, i64 %t49)
  %t63 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t52, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t64, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l2, !tbaa !24
  store i64 8, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t66 = load i64, ptr %l3, !tbaa !24
  %t67 = load i64, ptr %l2, !tbaa !24
  %t70 = icmp sgt i64 %t66, %t67
  br i1 %t70, label %bb4, label %bb5
bb4:
  %t72 = load i64, ptr %l4, !tbaa !24
  %t74 = icmp sgt i64 %t72, 0
  br i1 %t74, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb9
bb6:
  %t76 = load i64, ptr %l3, !tbaa !24
  %t77 = load i64, ptr %l2, !tbaa !24
  %t80 = sub i64 %t76, %t77
  %t81 = load i64, ptr %l4, !tbaa !24
  %t84 = add i64 %t80, %t81
  %t86 = sub i64 %t84, 1
  %t87 = load i64, ptr %l4, !tbaa !24
  %t90 = sdiv i64 %t86, %t87
  store i64 %t90, ptr %l37, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb8
bb8:
  %t92 = load i64, ptr %l37, !tbaa !24
  store i64 %t92, ptr %l34, !tbaa !24
  br label %bb9
bb9:
  %t93 = load i64, ptr %l34, !tbaa !24
  store i64 %t93, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  %t94 = load i64, ptr %l5, !tbaa !24
  %t95 = sub i64 %t94, 1
  store i64 %t95, ptr %l46, !tbaa !24
  %t96 = load i64, ptr %l5, !tbaa !24
  %t97 = icmp slt i64 %t96, 2147483648
  %t98 = load i64, ptr %l6, !tbaa !24
  %t99 = icmp sge i64 %t98, 0
  %t102 = and i1 %t97, %t99
  store i1 %t102, ptr %l49, !tbaa !21
  br label %bb10
bb10:
  %t103 = load i64, ptr %l6, !tbaa !24
  %t104 = load i64, ptr %l5, !tbaa !24
  %t107 = icmp slt i64 %t103, %t104
  %t109 = xor i1 %t107, true
  br i1 %t109, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  br label %bb13
bb13:
  %t111 = load i64, ptr %l2, !tbaa !24
  %t112 = load i64, ptr %l6, !tbaa !24
  %t113 = load i64, ptr %l4, !tbaa !24
  %t116 = mul i64 %t112, %t113
  %t119 = add i64 %t111, %t116
  store i64 %t119, ptr %l7, !tbaa !24
  %t121 = load i64, ptr %l7, !tbaa !24
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load i64, ptr %l7, !tbaa !24
  %t125 = mul i64 2, %t123
  %t127 = getelementptr %"std/net:IP", ptr %t122, i32 0, i32 1
  %t129 = getelementptr [16 x i8], ptr %t127, i64 0, i64 %t125
  %t130 = load i8, ptr %t129, !tbaa !32
  %t132 = zext i8 %t130 to i64
  %t134 = shl i64 %t132, 8
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load i64, ptr %l7, !tbaa !24
  %t138 = mul i64 2, %t136
  %t140 = add i64 %t138, 1
  %t142 = getelementptr %"std/net:IP", ptr %t135, i32 0, i32 1
  %t144 = getelementptr [16 x i8], ptr %t142, i64 0, i64 %t140
  %t145 = load i8, ptr %t144, !tbaa !32
  %t147 = zext i8 %t145 to i64
  %t150 = or i64 %t134, %t147
  %t153 = getelementptr [8 x i64], ptr %l1, i64 0, i64 %t121
  store i64 %t150, ptr %t153, !tbaa !34
  br label %bb14
bb14:
  %t154 = load i64, ptr %l6, !tbaa !24
  %t157 = add i64 %t154, 1
  store i64 %t157, ptr %l6, !tbaa !24
  br label %bb10
bb15:
  store i64 -1, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb16
bb16:
  %t159 = load i64, ptr %l10, !tbaa !24
  %t161 = icmp slt i64 %t159, 8
  %t163 = xor i1 %t161, true
  br i1 %t163, label %bb17, label %bb18
bb17:
  br label %bb36
bb18:
  br label %bb19
bb19:
  %t165 = load i64, ptr %l10, !tbaa !24
  %t167 = getelementptr [8 x i64], ptr %l1, i64 0, i64 %t165
  %t168 = load i64, ptr %t167, !tbaa !34
  %t170 = icmp ne i64 %t168, 0
  br i1 %t170, label %bb20, label %bb21
bb20:
  %t172 = load i64, ptr %l10, !tbaa !24
  %t175 = add i64 %t172, 1
  store i64 %t175, ptr %l10, !tbaa !24
  br label %bb35
bb21:
  br label %bb22
bb22:
  %t177 = load i64, ptr %l10, !tbaa !24
  store i64 %t177, ptr %l11, !tbaa !24
  br label %bb23
bb23:
  %t179 = load i64, ptr %l11, !tbaa !24
  %t181 = icmp slt i64 %t179, 8
  br i1 %t181, label %bb24, label %bb25
bb24:
  %t183 = load i64, ptr %l11, !tbaa !24
  %t185 = getelementptr [8 x i64], ptr %l1, i64 0, i64 %t183
  %t186 = load i64, ptr %t185, !tbaa !34
  %t188 = icmp eq i64 %t186, 0
  store i1 %t188, ptr %l88, !tbaa !21
  br label %bb26
bb25:
  store i1 false, ptr %l88, !tbaa !21
  br label %bb26
bb26:
  %t190 = load i1, ptr %l88, !tbaa !21
  %t191 = xor i1 %t190, true
  br i1 %t191, label %bb27, label %bb28
bb27:
  br label %bb31
bb28:
  br label %bb29
bb29:
  %t193 = load i64, ptr %l11, !tbaa !24
  %t196 = add i64 %t193, 1
  store i64 %t196, ptr %l11, !tbaa !24
  br label %bb30
bb30:
  br label %bb23
bb31:
  %t198 = load i64, ptr %l11, !tbaa !24
  %t199 = load i64, ptr %l10, !tbaa !24
  %t202 = sub i64 %t198, %t199
  %t203 = load i64, ptr %l9, !tbaa !24
  %t206 = icmp sgt i64 %t202, %t203
  br i1 %t206, label %bb32, label %bb33
bb32:
  %t208 = load i64, ptr %l10, !tbaa !24
  store i64 %t208, ptr %l8, !tbaa !24
  %t210 = load i64, ptr %l11, !tbaa !24
  %t211 = load i64, ptr %l10, !tbaa !24
  %t214 = sub i64 %t210, %t211
  store i64 %t214, ptr %l9, !tbaa !24
  br label %bb34
bb33:
  br label %bb34
bb34:
  %t216 = load i64, ptr %l11, !tbaa !24
  store i64 %t216, ptr %l10, !tbaa !24
  br label %bb35
bb35:
  br label %bb16
bb36:
  %t218 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t218, ptr %l106
  br label %bb37
bb37:
  %t219 = load %"std/prelude/text:StringBuilder", ptr %l106
  store %"std/prelude/text:StringBuilder" %t219, ptr %l12
  store i64 0, ptr %l13, !tbaa !24
  store i64 8, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t220 = load i64, ptr %l14, !tbaa !24
  %t221 = load i64, ptr %l13, !tbaa !24
  %t224 = icmp sgt i64 %t220, %t221
  br i1 %t224, label %bb38, label %bb39
bb38:
  %t226 = load i64, ptr %l15, !tbaa !24
  %t228 = icmp sgt i64 %t226, 0
  br i1 %t228, label %bb40, label %bb41
bb39:
  store i64 0, ptr %l110, !tbaa !24
  br label %bb43
bb40:
  %t230 = load i64, ptr %l14, !tbaa !24
  %t231 = load i64, ptr %l13, !tbaa !24
  %t234 = sub i64 %t230, %t231
  %t235 = load i64, ptr %l15, !tbaa !24
  %t238 = add i64 %t234, %t235
  %t240 = sub i64 %t238, 1
  %t241 = load i64, ptr %l15, !tbaa !24
  %t244 = sdiv i64 %t240, %t241
  store i64 %t244, ptr %l113, !tbaa !24
  br label %bb42
bb41:
  store i64 0, ptr %l113, !tbaa !24
  br label %bb42
bb42:
  %t246 = load i64, ptr %l113, !tbaa !24
  store i64 %t246, ptr %l110, !tbaa !24
  br label %bb43
bb43:
  %t247 = load i64, ptr %l110, !tbaa !24
  store i64 %t247, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb44
bb44:
  store %olang.scope zeroinitializer, ptr %s11
  %t248 = load i64, ptr %l17, !tbaa !24
  %t249 = load i64, ptr %l16, !tbaa !24
  %t252 = icmp slt i64 %t248, %t249
  %t254 = xor i1 %t252, true
  br i1 %t254, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s11)
  br label %bb73
bb46:
  br label %bb47
bb47:
  %t256 = load i64, ptr %l13, !tbaa !24
  %t257 = load i64, ptr %l17, !tbaa !24
  %t258 = load i64, ptr %l15, !tbaa !24
  %t261 = mul i64 %t257, %t258
  %t264 = add i64 %t256, %t261
  store i64 %t264, ptr %l18, !tbaa !24
  %t266 = load i64, ptr %l18, !tbaa !24
  %t267 = load i64, ptr %l8, !tbaa !24
  %t270 = icmp eq i64 %t266, %t267
  br i1 %t270, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s12
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s12, ptr %l12, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d10, i32 0, i32 1) })
  br label %bb50
bb49:
  br label %bb51
bb50:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s11)
  br label %bb72
bb51:
  %t273 = load i64, ptr %l8, !tbaa !24
  %t275 = icmp sge i64 %t273, 0
  br i1 %t275, label %bb52, label %bb53
bb52:
  %t277 = load i64, ptr %l18, !tbaa !24
  %t278 = load i64, ptr %l8, !tbaa !24
  %t281 = icmp sgt i64 %t277, %t278
  store i1 %t281, ptr %l137, !tbaa !21
  br label %bb54
bb53:
  store i1 false, ptr %l137, !tbaa !21
  br label %bb54
bb54:
  %t283 = load i1, ptr %l137, !tbaa !21
  br i1 %t283, label %bb55, label %bb56
bb55:
  %t284 = load i64, ptr %l18, !tbaa !24
  %t285 = load i64, ptr %l8, !tbaa !24
  %t286 = load i64, ptr %l9, !tbaa !24
  %t289 = add i64 %t285, %t286
  %t292 = icmp slt i64 %t284, %t289
  store i1 %t292, ptr %l141, !tbaa !21
  br label %bb57
bb56:
  store i1 false, ptr %l141, !tbaa !21
  br label %bb57
bb57:
  %t294 = load i1, ptr %l141, !tbaa !21
  br i1 %t294, label %bb58, label %bb59
bb58:
  call void @__olang_scope_close(ptr %s11)
  br label %bb72
bb59:
  br label %bb60
bb60:
  %t295 = load i64, ptr %l18, !tbaa !24
  %t297 = icmp sgt i64 %t295, 0
  br i1 %t297, label %bb61, label %bb62
bb61:
  %t299 = load i64, ptr %l18, !tbaa !24
  %t300 = load i64, ptr %l8, !tbaa !24
  %t301 = load i64, ptr %l9, !tbaa !24
  %t304 = add i64 %t300, %t301
  %t307 = icmp ne i64 %t299, %t304
  store i1 %t307, ptr %l149, !tbaa !21
  br label %bb63
bb62:
  store i1 false, ptr %l149, !tbaa !21
  br label %bb63
bb63:
  %t309 = load i1, ptr %l149, !tbaa !21
  br i1 %t309, label %bb64, label %bb65
bb64:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l12, i8 58)
  br label %bb66
bb65:
  br label %bb67
bb66:
  br label %bb67
bb67:
  store ptr %l12, ptr %l156, !tbaa !29
  %t311 = load i64, ptr %l18, !tbaa !24
  %t313 = getelementptr [8 x i64], ptr %l1, i64 0, i64 %t311
  %t314 = load i64, ptr %t313, !tbaa !34
  store i64 %t314, ptr %l158, !tbaa !24
  %t315 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s11, i64 16)
  %t316 = extractvalue { i32, i64 } %t315, 1
  %t317 = extractvalue { i32, i64 } %t315, 0
  store i32 %t317, ptr %l160
  %t318 = icmp ne i32 %t317, 0
  br i1 %t318, label %bb69, label %ok.319, !prof !99
ok.319:
  store i64 %t316, ptr %l159
  br label %bb68
bb68:
  %t320 = load i64, ptr %l158, !tbaa !24
  %t321 = load i64, ptr %l159, !tbaa !24
  %t322 = call { i64, ptr } @std_2fprelude_2ftext_2eI64_2eFormat(ptr %s11, i64 %t320, i64 %t321)
  store { i64, ptr } %t322, ptr %l161
  br label %bb70
bb69:
  call void @__olang_check_failed(ptr @olang_loc_2226b004e1161b9e_260abf21839543b2)
  unreachable
bb70:
  %t323 = load { i64, ptr }, ptr %l161, !tbaa !27
  %t324 = load ptr, ptr %l156, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s11, ptr %t324, { i64, ptr } %t323)
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s11)
  br label %bb72
bb72:
  %t326 = load i64, ptr %l17, !tbaa !24
  %t329 = add i64 %t326, 1
  store i64 %t329, ptr %l17, !tbaa !24
  br label %bb44
bb73:
  %t332 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l12)
  store { i64, ptr } %t332, ptr %l167
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s0)
  %t333 = load { i64, ptr }, ptr %l167, !tbaa !27
  store { i64, ptr } %t333, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, { { i64, ptr }, %"std/net:Addr" } } @std_2fnet_2estd_2fnet_3aUDP_2eRecvFrom(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca [28 x i8]
  %l3 = alloca i64
  %l4 = alloca [28 x i8]
  %l10 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l19 = alloca { i64, ptr }
  %l22 = alloca %"std/net:Addr"
  %l24 = alloca i1
  %l26 = alloca i32
  %l27 = alloca { i64, ptr }
  %l29 = alloca i32
  %s1 = alloca %olang.scope
  %rv = alloca { i32, { { i64, ptr }, %"std/net:Addr" } }
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  br label %fill.4
fill.4:
  br label %fill.1
fill.1:
  %t5 = phi i64 [ 0, %fill.4 ], [ %t6, %fill.2 ]
  %t7 = icmp slt i64 %t5, 28
  br i1 %t7, label %fill.2, label %fill.3
fill.2:
  %t8 = getelementptr [28 x i8], ptr %l4, i64 0, i64 %t5
  store i8 0, ptr %t8
  %t6 = add i64 %t5, 1
  br label %fill.1
fill.3:
  %t9 = load [28 x i8], ptr %l4
  store [28 x i8] %t9, ptr %l2
  %t12 = getelementptr %"std/net:UDP", ptr %a0, i32 0, i32 0
  %t13 = load i32, ptr %t12, !tbaa !23
  %t14 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t16 = insertvalue { i64, ptr } undef, i64 28, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %l2, 1
  %t21 = call i64 @std_2fnet_2esysRecvFrom(ptr %v1, ptr %s1, i32 %t13, { i64, ptr } %t14, { i64, ptr } %t17)
  store i64 %t21, ptr %l10
  br label %bb2
bb2:
  %t22 = load i64, ptr %l10, !tbaa !24
  store i64 %t22, ptr %l3, !tbaa !24
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = icmp sge i64 %t23, 0
  br i1 %t25, label %bb3, label %bb4
bb3:
  %t27 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t27, ptr %l13, !tbaa !27
  %t28 = load i64, ptr %l3, !tbaa !24
  store i64 %t28, ptr %l14, !tbaa !24
  %t29 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 0
  store i64 %t30, ptr %l15, !tbaa !24
  %t31 = icmp sge i64 0, 0
  br i1 %t31, label %bb5, label %bb6
bb4:
  br label %bb12
bb5:
  %t33 = load i64, ptr %l14, !tbaa !24
  %t34 = icmp sle i64 0, %t33
  br i1 %t34, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_4e1638ec2ac13854_38df9045e4ebdb28)
  unreachable
bb7:
  %t36 = load i64, ptr %l14, !tbaa !24
  %t37 = load i64, ptr %l15, !tbaa !24
  %t38 = icmp sle i64 %t36, %t37
  br i1 %t38, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_4e1638ec2ac13854_38df9045e4ebdb28)
  unreachable
bb9:
  %t40 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = load i64, ptr %l14, !tbaa !24
  %t43 = getelementptr i8, ptr %t41, i64 0
  %t44 = sub i64 %t42, 0
  %t45 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t43, 1
  store { i64, ptr } %t46, ptr %l19, !tbaa !27
  %t48 = insertvalue { i64, ptr } undef, i64 28, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %l2, 1
  %t51 = call %"std/net:Addr" @std_2fnet_2eAddr_2efromSockaddr(ptr %s1, { i64, ptr } %t49)
  store %"std/net:Addr" %t51, ptr %l22
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_4e1638ec2ac13854_38df9045e4ebdb28)
  unreachable
bb11:
  %t52 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t53 = insertvalue { { i64, ptr }, %"std/net:Addr" } undef, { i64, ptr } %t52, 0
  %t54 = load %"std/net:Addr", ptr %l22
  %t55 = insertvalue { { i64, ptr }, %"std/net:Addr" } %t53, %"std/net:Addr" %t54, 1
  call void @__olang_scope_close(ptr %s1)
  %t57 = insertvalue { i32, { { i64, ptr }, %"std/net:Addr" } } zeroinitializer, { { i64, ptr }, %"std/net:Addr" } %t55, 1
  store { i32, { { i64, ptr }, %"std/net:Addr" } } %t57, ptr %rv
  br label %ret
bb12:
  %t58 = call i1 @std_2fnet_2einterrupted()
  store i1 %t58, ptr %l24
  br label %bb13
bb13:
  %t59 = load i1, ptr %l24, !tbaa !21
  %t60 = xor i1 %t59, true
  br i1 %t60, label %bb14, label %bb15
bb14:
  %t62 = call i32 @std_2fnet_2esockErr()
  store i32 %t62, ptr %l26
  br label %bb16
bb15:
  br label %bb20
bb16:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %l27, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t64 = load i32, ptr %l26, !tbaa !23
  %t66 = call i32 @std_2fnet_2eraise(i32 %t64, { i64, ptr } %t63)
  store i32 %t66, ptr %l29
  %t67 = icmp ne i32 %t66, 0
  br i1 %t67, label %bb18, label %ok.68, !prof !99
ok.68:
  br label %bb17
bb17:
  br label %bb19
bb18:
  %t69 = load i32, ptr %l29, !tbaa !23
  %t70 = lshr i32 %t69, 16
  %t71 = and i32 %t69, 65535
  %t72 = icmp eq i32 %t70, 1
  %t73 = select i1 %t72, i32 1, i32 0
  %t74 = icmp eq i32 %t69, 0
  %t75 = shl i32 %t73, 16
  %t76 = or i32 %t75, %t71
  %t77 = select i1 %t74, i32 0, i32 %t76
  call void @__olang_scope_close(ptr %s1)
  %t79 = insertvalue { i32, { { i64, ptr }, %"std/net:Addr" } } zeroinitializer, i32 %t77, 0
  store { i32, { { i64, ptr }, %"std/net:Addr" } } %t79, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s1)
  br label %bb21
bb21:
  br label %bb1
ret:
  %rr = load { i32, { { i64, ptr }, %"std/net:Addr" } }, ptr %rv
  ret { i32, { { i64, ptr }, %"std/net:Addr" } } %rr
}

define dso_local i32 @std_2fnet_2esysConnect(ptr %v0, i32 %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l7 = alloca i32
  %rv = alloca i32
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  %t7 = trunc i64 %t5 to i32
  %t10 = extractvalue { i64, ptr } %t2, 1
  %t11 = extractvalue { i64, ptr } %t2, 0
  %t13 = call i32 @connect(i32 %a0, ptr %t10, i32 %t7)
  store i32 %t13, ptr %l7
  br label %bb1
bb1:
  %t14 = load i32, ptr %l7, !tbaa !23
  store i32 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fnet_2esysListen(i32 %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i32 @listen(i32 %a0, i32 %a1)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4, !tbaa !23
  store i32 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @std_2fnet_2esysLookup(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"<netdb.h>:addrinfo"
  %l2 = alloca [1 x ptr]
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca ptr
  %l7 = alloca %"<netdb.h>:addrinfo"
  %l8 = alloca %"<netdb.h>:addrinfo"
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l17 = alloca i32
  %l22 = alloca i32
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l31 = alloca %"<netdb.h>:addrinfo"
  %l34 = alloca ptr
  %l38 = alloca i1
  %l42 = alloca i1
  %l57 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l59 = alloca i64
  %l60 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"<netdb.h>:addrinfo" @_3cnetdb_2eh_3e_3aaddrinfo_2ector(ptr %s0)
  store %"<netdb.h>:addrinfo" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = load %"<netdb.h>:addrinfo", ptr %l8
  store %"<netdb.h>:addrinfo" %t2, ptr %l1
  %t3 = load i32, ptr @G_2estd_2fnet_2esockStream, !tbaa !23
  %t5 = getelementptr %"<netdb.h>:addrinfo", ptr %l1, i32 0, i32 2
  store i32 %t3, ptr %t5, !tbaa !23
  %t6 = insertvalue [1 x ptr] undef, ptr null, 0
  store [1 x ptr] %t6, ptr %l2
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t10 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToC(ptr %v0, ptr %s0, { i64, ptr } %t8)
  store { i64, ptr } %t10, ptr %l12
  br label %bb2
bb2:
  %t11 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToC(ptr %s0, ptr %s0, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store { i64, ptr } %t11, ptr %l13
  br label %bb3
bb3:
  %t13 = insertvalue { i64, ptr } undef, i64 1, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %l2, 1
  %t15 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t15, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t18, 1
  %t20 = extractvalue { i64, ptr } %t18, 0
  %t23 = extractvalue { i64, ptr } %t14, 1
  %t24 = extractvalue { i64, ptr } %t14, 0
  %t25 = call i32 @getaddrinfo(ptr %t16, ptr %t19, ptr %l1, ptr %t23)
  store i32 %t25, ptr %l17
  br label %bb4
bb4:
  %t26 = load i32, ptr %l17, !tbaa !23
  store i32 %t26, ptr %l3, !tbaa !23
  %t27 = load i32, ptr %l3, !tbaa !23
  %t29 = icmp ne i32 %t27, 0
  br i1 %t29, label %bb5, label %bb6
bb5:
  %t31 = load i32, ptr %l3, !tbaa !23
  %t32 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t35 = call i32 @std_2fnet_2elookupFailed(ptr %v0, i32 %t31, { i64, ptr } %t32)
  store i32 %t35, ptr %l22
  %t36 = icmp ne i32 %t35, 0
  br i1 %t36, label %bb8, label %ok.37, !prof !99
ok.37:
  br label %bb7
bb6:
  br label %bb10
bb7:
  br label %bb9
bb8:
  %t38 = load i32, ptr %l22, !tbaa !23
  %t39 = lshr i32 %t38, 16
  %t40 = and i32 %t38, 65535
  %t41 = icmp eq i32 %t39, 1
  %t42 = select i1 %t41, i32 1, i32 0
  %t43 = icmp eq i32 %t38, 0
  %t44 = shl i32 %t42, 16
  %t45 = or i32 %t44, %t40
  %t46 = select i1 %t43, i32 0, i32 %t45
  call void @__olang_scope_close(ptr %s0)
  %t48 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t46, 0
  store { i32, { i64, ptr } } %t48, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t49 = getelementptr [1 x ptr], ptr %l2, i64 0, i64 0
  %t50 = load ptr, ptr %t49, !tbaa !39
  store ptr %t50, ptr %l4, !tbaa !29
  %t52 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fnet_3aIP_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t52, ptr %l25
  br label %bb11
bb11:
  %t53 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t53, ptr %l5
  %t54 = load ptr, ptr %l4, !tbaa !29
  store ptr %t54, ptr %l6, !tbaa !29
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t56 = load ptr, ptr %l6, !tbaa !29
  %t58 = icmp eq ptr %t56, null
  %t60 = xor i1 %t58, true
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb14:
  br label %bb15
bb15:
  %t64 = call %"<netdb.h>:addrinfo" @_3cnetdb_2eh_3e_3aaddrinfo_2ector(ptr %s2)
  store %"<netdb.h>:addrinfo" %t64, ptr %l31
  br label %bb16
bb16:
  %t65 = load %"<netdb.h>:addrinfo", ptr %l31
  store %"<netdb.h>:addrinfo" %t65, ptr %l7
  %t66 = load ptr, ptr %l6, !tbaa !29
  %t69 = call ptr @memcpy(ptr %l7, ptr %t66, i64 48)
  store ptr %t69, ptr %l34
  br label %bb17
bb17:
  %t70 = getelementptr %"<netdb.h>:addrinfo", ptr %l7, i32 0, i32 5
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = icmp eq ptr %t71, null
  %t75 = xor i1 %t73, true
  br i1 %t75, label %bb18, label %bb19
bb18:
  %t77 = getelementptr %"<netdb.h>:addrinfo", ptr %l7, i32 0, i32 1
  %t78 = load i32, ptr %t77, !tbaa !23
  %t79 = load i32, ptr @G_2estd_2fnet_2eafInet, !tbaa !23
  %t82 = icmp eq i32 %t78, %t79
  br i1 %t82, label %bb20, label %bb21
bb19:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb23
bb20:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb22
bb21:
  %t84 = getelementptr %"<netdb.h>:addrinfo", ptr %l7, i32 0, i32 1
  %t85 = load i32, ptr %t84, !tbaa !23
  %t86 = load i32, ptr @G_2estd_2fnet_2eafInet6, !tbaa !23
  %t89 = icmp eq i32 %t85, %t86
  store i1 %t89, ptr %l42, !tbaa !21
  br label %bb22
bb22:
  %t91 = load i1, ptr %l42, !tbaa !21
  store i1 %t91, ptr %l38, !tbaa !21
  br label %bb23
bb23:
  %t92 = load i1, ptr %l38, !tbaa !21
  br i1 %t92, label %bb24, label %bb25
bb24:
  %t93 = getelementptr %"<netdb.h>:addrinfo", ptr %l7, i32 0, i32 5
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t96 = getelementptr %"<netdb.h>:addrinfo", ptr %l7, i32 0, i32 4
  %t97 = load i32, ptr %t96, !tbaa !64
  %t99 = zext i32 %t97 to i64
  call void @std_2fnet_2eaddOnce(ptr %s0, ptr %l5, ptr %t94, i64 %t99)
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb27
bb27:
  %t103 = getelementptr %"<netdb.h>:addrinfo", ptr %l7, i32 0, i32 7
  %t104 = load ptr, ptr %t103, !tbaa !29
  store ptr %t104, ptr %l6, !tbaa !29
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb28:
  br label %bb12
bb29:
  %t106 = load ptr, ptr %l4, !tbaa !29
  %t108 = icmp eq ptr %t106, null
  %t110 = xor i1 %t108, true
  br i1 %t110, label %bb30, label %bb31
bb30:
  %t112 = load ptr, ptr %l4, !tbaa !29
  call void @freeaddrinfo(ptr %t112)
  br label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb33
bb33:
  %t115 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fnet_3aIP_3e_2eToArray_3cstd_2fnet_3aIP_3e(ptr %s0, ptr %s0, ptr %l5)
  store { i64, ptr } %t115, ptr %l57
  br label %bb34
bb34:
  %t116 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t116, ptr %l58, !tbaa !27
  %t117 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t117, 0
  store i64 %t118, ptr %l59, !tbaa !24
  %t119 = load i64, ptr %l59, !tbaa !24
  %t120 = mul i64 %t119, 17
  %t121 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t120)
  %t122 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t123 = insertvalue { i64, ptr } %t122, ptr %t121, 1
  store { i64, ptr } %t123, ptr %l60, !tbaa !27
  %t124 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = load i64, ptr %l59, !tbaa !24
  %t129 = mul i64 %t128, 17
  call void @llvm.memmove.p0.p0.i64(ptr %t125, ptr %t127, i64 %t129, i1 false)
  %t130 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t130, ptr %l58, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t131 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t132 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t131, 1
  store { i32, { i64, ptr } } %t132, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i64, ptr } @std_2fnet_2esysReadable(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l15 = alloca i64
  %l16 = alloca %"<poll.h>:pollfd"
  %l18 = alloca %"<poll.h>:pollfd"
  %l25 = alloca i64
  %l28 = alloca i1
  %l34 = alloca { i64, ptr }
  %l52 = alloca i32
  %l54 = alloca i1
  %l55 = alloca i1
  %l62 = alloca i64
  %l65 = alloca i64
  %l75 = alloca { i64, ptr }
  %l76 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t19 = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l15, !tbaa !24
  store %"<poll.h>:pollfd" zeroinitializer, ptr %l16
  %t4 = load i64, ptr %l15, !tbaa !24
  %t5 = icmp sgt i64 %t4, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = call %"<poll.h>:pollfd" @olang_2emir_2eHelperKind_2eZero_2e_3cpoll_2eh_3e_3apollfd()
  store %"<poll.h>:pollfd" %t7, ptr %l18
  br label %bb3
bb2:
  %t8 = load i64, ptr %l15, !tbaa !24
  %t9 = icmp sge i64 %t8, 0
  br i1 %t9, label %bb4, label %bb5
bb3:
  %t11 = load %"<poll.h>:pollfd", ptr %l18
  store %"<poll.h>:pollfd" %t11, ptr %l16
  br label %bb2
bb4:
  %t12 = load i64, ptr %l15, !tbaa !24
  %t13 = icmp sle i64 %t12, 1152921504606846975
  br i1 %t13, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_8995c37d5bde66ea_5787b775da029666)
  unreachable
bb6:
  %t15 = load i64, ptr %l15, !tbaa !24
  %t16 = mul i64 %t15, 8
  %t17 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t16)
  %t18 = load %"<poll.h>:pollfd", ptr %l16
  store i64 0, ptr %t19
  br label %fill.20
fill.20:
  %t23 = load i64, ptr %t19
  %t24 = icmp slt i64 %t23, %t15
  br i1 %t24, label %fillb.21, label %filld.22
fillb.21:
  %t25 = getelementptr %"<poll.h>:pollfd", ptr %t17, i64 %t23
  store %"<poll.h>:pollfd" %t18, ptr %t25
  %t26 = add i64 %t23, 1
  store i64 %t26, ptr %t19
  br label %fill.20
filld.22:
  %t27 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t17, 1
  store { i64, ptr } %t28, ptr %l2, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t30, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t32 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  store i64 %t34, ptr %l5, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t37 = sub i64 %t36, 1
  store i64 %t37, ptr %l25, !tbaa !24
  %t38 = load i64, ptr %l5, !tbaa !24
  %t39 = icmp slt i64 %t38, 2147483648
  %t40 = load i64, ptr %l4, !tbaa !24
  %t41 = icmp sge i64 %t40, 0
  %t44 = and i1 %t39, %t41
  store i1 %t44, ptr %l28, !tbaa !21
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_8995c37d5bde66ea_5787b775da029666)
  unreachable
bb8:
  %t45 = load i64, ptr %l4, !tbaa !24
  %t46 = load i64, ptr %l5, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb9, label %bb10
bb9:
  br label %bb13
bb10:
  br label %bb11
bb11:
  %t53 = load i64, ptr %l4, !tbaa !24
  store i64 %t53, ptr %l6, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t55, ptr %l34, !tbaa !27
  %t56 = load i64, ptr %l4, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr i32, ptr %t59, i64 %t56
  %t61 = load i32, ptr %t60, !tbaa !33
  %t63 = load i64, ptr %l6, !tbaa !24
  %t67 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = getelementptr %"<poll.h>:pollfd", ptr %t68, i64 %t63
  %t70 = getelementptr %"<poll.h>:pollfd", ptr %t69, i32 0, i32 0
  store i32 %t61, ptr %t70, !tbaa !23
  %t71 = load i64, ptr %l6, !tbaa !24
  %t72 = load i32, ptr @G_2e_3cpoll_2eh_3e_2ePOLLIN, !tbaa !23
  %t74 = trunc i32 %t72 to i16
  %t77 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr %"<poll.h>:pollfd", ptr %t78, i64 %t71
  %t80 = getelementptr %"<poll.h>:pollfd", ptr %t79, i32 0, i32 1
  store i16 %t74, ptr %t80, !tbaa !62
  br label %bb12
bb12:
  %t81 = load i64, ptr %l4, !tbaa !24
  %t84 = add i64 %t81, 1
  store i64 %t84, ptr %l4, !tbaa !24
  br label %bb8
bb13:
  br label %bb14
bb14:
  %t86 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t87 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t87, 0
  %t91 = trunc i64 %t89 to i32
  %t93 = zext i32 %t91 to i64
  %t96 = trunc i64 %a1 to i32
  %t98 = extractvalue { i64, ptr } %t86, 1
  %t99 = extractvalue { i64, ptr } %t86, 0
  %t102 = call i32 @poll(ptr %t98, i64 %t93, i32 %t96)
  store i32 %t102, ptr %l52
  br label %bb15
bb15:
  %t103 = load i32, ptr %l52, !tbaa !23
  %t104 = icmp slt i32 %t103, 0
  br i1 %t104, label %bb16, label %bb17
bb16:
  %t106 = call i1 @std_2fnet_2einterrupted()
  store i1 %t106, ptr %l55
  br label %bb18
bb17:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb19
bb18:
  %t107 = load i1, ptr %l55, !tbaa !21
  store i1 %t107, ptr %l54, !tbaa !21
  br label %bb19
bb19:
  %t108 = load i1, ptr %l54, !tbaa !21
  %t109 = xor i1 %t108, true
  br i1 %t109, label %bb20, label %bb21
bb20:
  br label %bb24
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  br label %bb14
bb24:
  store i64 0, ptr %l8, !tbaa !24
  %t111 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t111, 0
  store i64 %t113, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t115 = load i64, ptr %l9, !tbaa !24
  %t116 = load i64, ptr %l8, !tbaa !24
  %t119 = icmp sgt i64 %t115, %t116
  br i1 %t119, label %bb25, label %bb26
bb25:
  %t121 = load i64, ptr %l10, !tbaa !24
  %t123 = icmp sgt i64 %t121, 0
  br i1 %t123, label %bb27, label %bb28
bb26:
  store i64 0, ptr %l62, !tbaa !24
  br label %bb30
bb27:
  %t125 = load i64, ptr %l9, !tbaa !24
  %t126 = load i64, ptr %l8, !tbaa !24
  %t129 = sub i64 %t125, %t126
  %t130 = load i64, ptr %l10, !tbaa !24
  %t133 = add i64 %t129, %t130
  %t135 = sub i64 %t133, 1
  %t136 = load i64, ptr %l10, !tbaa !24
  %t139 = sdiv i64 %t135, %t136
  store i64 %t139, ptr %l65, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l65, !tbaa !24
  br label %bb29
bb29:
  %t141 = load i64, ptr %l65, !tbaa !24
  store i64 %t141, ptr %l62, !tbaa !24
  br label %bb30
bb30:
  %t142 = load i64, ptr %l62, !tbaa !24
  store i64 %t142, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  %t143 = load i64, ptr %l11, !tbaa !24
  %t145 = mul i64 %t143, 1
  %t146 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t145)
  %t147 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t146, 1
  store { i64, ptr } %t148, ptr %l75, !tbaa !27
  store i64 0, ptr %l76, !tbaa !24
  br label %bb31
bb31:
  %t149 = load i64, ptr %l12, !tbaa !24
  %t150 = load i64, ptr %l11, !tbaa !24
  %t153 = icmp slt i64 %t149, %t150
  %t155 = xor i1 %t153, true
  br i1 %t155, label %bb32, label %bb33
bb32:
  br label %bb36
bb33:
  br label %bb34
bb34:
  %t157 = load i64, ptr %l8, !tbaa !24
  %t158 = load i64, ptr %l12, !tbaa !24
  %t159 = load i64, ptr %l10, !tbaa !24
  %t162 = mul i64 %t158, %t159
  %t165 = add i64 %t157, %t162
  %t169 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !27
  %t171 = getelementptr %"<poll.h>:pollfd", ptr %t170, i64 %t165
  %t172 = getelementptr %"<poll.h>:pollfd", ptr %t171, i32 0, i32 2
  %t173 = load i16, ptr %t172, !tbaa !62
  %t175 = icmp ne i16 %t173, 0
  %t177 = load i64, ptr %l76, !tbaa !24
  %t178 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t179 = load ptr, ptr %t178, !tbaa !27
  %t180 = getelementptr i1, ptr %t179, i64 %t177
  store i1 %t175, ptr %t180, !tbaa !31
  %t181 = load i64, ptr %l76, !tbaa !24
  %t182 = add i64 %t181, 1
  store i64 %t182, ptr %l76, !tbaa !24
  br label %bb35
bb35:
  %t183 = load i64, ptr %l12, !tbaa !24
  %t186 = add i64 %t183, 1
  store i64 %t186, ptr %l12, !tbaa !24
  br label %bb31
bb36:
  call void @__olang_scope_close(ptr %s0)
  %t188 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t188, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @std_2fnet_2esysRecv(ptr %v0, i32 %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l7 = alloca i64
  %rv = alloca i64
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  %t9 = extractvalue { i64, ptr } %t2, 1
  %t10 = extractvalue { i64, ptr } %t2, 0
  %t12 = call i64 @recv(i32 %a0, ptr %t9, i64 %t5, i32 0)
  store i64 %t12, ptr %l7
  br label %bb1
bb1:
  %t13 = load i64, ptr %l7, !tbaa !24
  store i64 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2fnet_2esysRecvFrom(ptr %v0, ptr %v1, i32 %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca [1 x i32]
  %l16 = alloca i64
  %rv = alloca i64
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = trunc i64 %t3 to i32
  %t7 = insertvalue [1 x i32] undef, i32 %t5, 0
  store [1 x i32] %t7, ptr %l3
  %t10 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t17 = insertvalue { i64, ptr } undef, i64 1, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %l3, 1
  %t21 = extractvalue { i64, ptr } %t10, 1
  %t22 = extractvalue { i64, ptr } %t10, 0
  %t25 = extractvalue { i64, ptr } %t15, 1
  %t26 = extractvalue { i64, ptr } %t15, 0
  %t28 = extractvalue { i64, ptr } %t18, 1
  %t29 = extractvalue { i64, ptr } %t18, 0
  %t30 = call i64 @recvfrom(i32 %a0, ptr %t21, i64 %t13, i32 0, ptr %t25, ptr %t28)
  store i64 %t30, ptr %l16
  br label %bb1
bb1:
  %t31 = load i64, ptr %l16, !tbaa !24
  store i64 %t31, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @std_2fnet_2esysTimeout(i32 %a0, i64 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i64
  %l3 = alloca [16 x i8]
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i64
  %l35 = alloca i64
  %l38 = alloca i1
  %l51 = alloca i64
  %l59 = alloca i64
  %l70 = alloca i32
  %l76 = alloca i32
  store i32 %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [16 x i8] undef, i8 0, 0
  %t2 = insertvalue [16 x i8] %t1, i8 0, 1
  %t3 = insertvalue [16 x i8] %t2, i8 0, 2
  %t4 = insertvalue [16 x i8] %t3, i8 0, 3
  %t5 = insertvalue [16 x i8] %t4, i8 0, 4
  %t6 = insertvalue [16 x i8] %t5, i8 0, 5
  %t7 = insertvalue [16 x i8] %t6, i8 0, 6
  %t8 = insertvalue [16 x i8] %t7, i8 0, 7
  %t9 = insertvalue [16 x i8] %t8, i8 0, 8
  %t10 = insertvalue [16 x i8] %t9, i8 0, 9
  %t11 = insertvalue [16 x i8] %t10, i8 0, 10
  %t12 = insertvalue [16 x i8] %t11, i8 0, 11
  %t13 = insertvalue [16 x i8] %t12, i8 0, 12
  %t14 = insertvalue [16 x i8] %t13, i8 0, 13
  %t15 = insertvalue [16 x i8] %t14, i8 0, 14
  %t16 = insertvalue [16 x i8] %t15, i8 0, 15
  store [16 x i8] %t16, ptr %l3
  %t18 = load i64, ptr %l1, !tbaa !24
  %t21 = sdiv i64 %t18, 1000000000
  store i64 %t21, ptr %l4, !tbaa !24
  %t23 = load i64, ptr %l1, !tbaa !24
  %t26 = srem i64 %t23, 1000000000
  %t28 = sdiv i64 %t26, 1000
  store i64 %t28, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  store i64 8, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t30 = load i64, ptr %l7, !tbaa !24
  %t31 = load i64, ptr %l6, !tbaa !24
  %t34 = icmp sgt i64 %t30, %t31
  br i1 %t34, label %bb1, label %bb2
bb1:
  %t36 = load i64, ptr %l8, !tbaa !24
  %t38 = icmp sgt i64 %t36, 0
  br i1 %t38, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb6
bb3:
  %t40 = load i64, ptr %l7, !tbaa !24
  %t41 = load i64, ptr %l6, !tbaa !24
  %t44 = sub i64 %t40, %t41
  %t45 = load i64, ptr %l8, !tbaa !24
  %t48 = add i64 %t44, %t45
  %t50 = sub i64 %t48, 1
  %t51 = load i64, ptr %l8, !tbaa !24
  %t54 = sdiv i64 %t50, %t51
  store i64 %t54, ptr %l26, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb5
bb5:
  %t56 = load i64, ptr %l26, !tbaa !24
  store i64 %t56, ptr %l23, !tbaa !24
  br label %bb6
bb6:
  %t57 = load i64, ptr %l23, !tbaa !24
  store i64 %t57, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  %t58 = load i64, ptr %l9, !tbaa !24
  %t59 = sub i64 %t58, 1
  store i64 %t59, ptr %l35, !tbaa !24
  %t60 = load i64, ptr %l9, !tbaa !24
  %t61 = icmp slt i64 %t60, 2147483648
  %t62 = load i64, ptr %l10, !tbaa !24
  %t63 = icmp sge i64 %t62, 0
  %t66 = and i1 %t61, %t63
  store i1 %t66, ptr %l38, !tbaa !21
  br label %bb7
bb7:
  %t67 = load i64, ptr %l10, !tbaa !24
  %t68 = load i64, ptr %l9, !tbaa !24
  %t71 = icmp slt i64 %t67, %t68
  %t73 = xor i1 %t71, true
  br i1 %t73, label %bb8, label %bb9
bb8:
  br label %bb12
bb9:
  br label %bb10
bb10:
  %t75 = load i64, ptr %l6, !tbaa !24
  %t76 = load i64, ptr %l10, !tbaa !24
  %t77 = load i64, ptr %l8, !tbaa !24
  %t80 = mul i64 %t76, %t77
  %t83 = add i64 %t75, %t80
  store i64 %t83, ptr %l11, !tbaa !24
  %t85 = load i64, ptr %l11, !tbaa !24
  %t86 = load i64, ptr %l4, !tbaa !24
  %t87 = load i64, ptr %l11, !tbaa !24
  %t89 = mul i64 8, %t87
  store i64 %t89, ptr %l51, !tbaa !24
  %t91 = load i64, ptr %l51, !tbaa !24
  %t92 = load i64, ptr %l51, !tbaa !24
  %t93 = ashr i64 %t86, %t92
  %t95 = and i64 %t93, 255
  %t97 = trunc i64 %t95 to i8
  %t100 = getelementptr [16 x i8], ptr %l3, i64 0, i64 %t85
  store i8 %t97, ptr %t100, !tbaa !32
  %t101 = load i64, ptr %l11, !tbaa !24
  %t103 = add i64 8, %t101
  %t104 = load i64, ptr %l5, !tbaa !24
  %t105 = load i64, ptr %l11, !tbaa !24
  %t107 = mul i64 8, %t105
  store i64 %t107, ptr %l59, !tbaa !24
  %t109 = load i64, ptr %l59, !tbaa !24
  %t110 = load i64, ptr %l59, !tbaa !24
  %t111 = ashr i64 %t104, %t110
  %t113 = and i64 %t111, 255
  %t115 = trunc i64 %t113 to i8
  %t118 = getelementptr [16 x i8], ptr %l3, i64 0, i64 %t103
  store i8 %t115, ptr %t118, !tbaa !32
  br label %bb11
bb11:
  %t119 = load i64, ptr %l10, !tbaa !24
  %t122 = add i64 %t119, 1
  store i64 %t122, ptr %l10, !tbaa !24
  br label %bb7
bb12:
  %t124 = load i32, ptr %l0, !tbaa !23
  %t125 = load i32, ptr @G_2estd_2fnet_2esolSocket, !tbaa !23
  %t126 = load i32, ptr @G_2estd_2fnet_2esoRcvtimeo, !tbaa !23
  %t131 = call i32 @setsockopt(i32 %t124, i32 %t125, i32 %t126, ptr %l3, i32 16)
  store i32 %t131, ptr %l70
  br label %bb13
bb13:
  br i1 %a2, label %bb14, label %bb15
bb14:
  %t134 = load i32, ptr %l0, !tbaa !23
  %t135 = load i32, ptr @G_2estd_2fnet_2esolSocket, !tbaa !23
  %t136 = load i32, ptr @G_2estd_2fnet_2esoSndtimeo, !tbaa !23
  %t141 = call i32 @setsockopt(i32 %t134, i32 %t135, i32 %t136, ptr %l3, i32 16)
  store i32 %t141, ptr %l76
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb17
bb17:
  br label %ret
ret:
  ret void
}

define dso_local %"std/net:Listener" @std_2fnet_3aListener_2ector(ptr %v0, i32 %a0) #0 {
entry:
  %rv = alloca %"std/net:Listener"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = insertvalue %"std/net:Listener" undef, i32 %a0, 0
  store %"std/net:Listener" %t4, ptr %rv
  br label %ret
ret:
  %rr = load %"std/net:Listener", ptr %rv
  ret %"std/net:Listener" %rr
}

define dso_local %"std/net:UDP" @std_2fnet_3aUDP_2ector(ptr %v0, i32 %a0) #0 {
entry:
  %rv = alloca %"std/net:UDP"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = insertvalue %"std/net:UDP" undef, i32 %a0, 0
  store %"std/net:UDP" %t4, ptr %rv
  br label %ret
ret:
  %rr = load %"std/net:UDP", ptr %rv
  ret %"std/net:UDP" %rr
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d0 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @__olang_errpay_push() cold
define linkonce_odr { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fnet_3aError_24payload(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i64, [2 x i64] }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %rv = alloca { i64, [2 x i64] }
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, [2 x i64] }, ptr %a0
  store { i64, [2 x i64] } %t2, ptr %l1
  %t3 = load i64, ptr %l1, !range !{i64 0, i64 10}
  switch i64 %t3, label %bb1 [ i64 5, label %bb2 i64 6, label %bb3 ]
bb1:
  %t5 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t5, ptr %rv
  br label %ret
bb2:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, ptr } }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, ptr }, ptr %t7
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 0
  store i64 %t10, ptr %l4, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = mul i64 %t11, 1
  %t13 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l5, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = load i64, ptr %l4, !tbaa !24
  %t21 = mul i64 %t20, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t17, ptr %t19, i64 %t21, i1 false)
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t24 = getelementptr { { i64, ptr } }, ptr %t23, i32 0, i32 0
  store { i64, ptr } %t22, ptr %t24
  br label %bb1
bb3:
  %t25 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t26 = getelementptr { { i64, ptr } }, ptr %t25, i32 0, i32 0
  %t27 = load { i64, ptr }, ptr %t26
  store { i64, ptr } %t27, ptr %l6, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  store i64 %t29, ptr %l7, !tbaa !24
  %t30 = load i64, ptr %l7, !tbaa !24
  %t31 = mul i64 %t30, 1
  %t32 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t31)
  %t33 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  store { i64, ptr } %t34, ptr %l8, !tbaa !27
  %t35 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = load i64, ptr %l7, !tbaa !24
  %t40 = mul i64 %t39, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t36, ptr %t38, i64 %t40, i1 false)
  %t41 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t42 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t43 = getelementptr { { i64, ptr } }, ptr %t42, i32 0, i32 0
  store { i64, ptr } %t41, ptr %t43
  br label %bb1
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare void @__olang_errpay_set(ptr) cold
declare void @__olang_check_failed(ptr) cold noreturn
@.d1 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
declare void @__olang_errpay_pop()
define linkonce_odr void @olang_2emir_2eHelperKind_2eRender_2estd_2fnet_3aAddr_26(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load ptr, ptr %a0, !tbaa !29
  store ptr %t2, ptr %l2, !tbaa !29
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t4 = icmp ne ptr %t3, null
  br i1 %t4, label %bb1, label %bb3
bb1:
  %t6 = load i64, ptr %l1, !tbaa !24
  %t7 = icmp sge i64 %t6, 8
  br i1 %t7, label %bb4, label %bb5
bb2:
  br label %ret
bb3:
  %t9 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb2
bb4:
  %t11 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb2
bb5:
  %t13 = load i64, ptr %l1, !tbaa !24
  %t14 = add i64 %t13, 1
  store i64 %t14, ptr %l5, !tbaa !24
  %t15 = load ptr, ptr %l2, !tbaa !29
  store ptr %t15, ptr %l6, !tbaa !29
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr %l6, !tbaa !29
  %t17 = call ptr @__olang_scope_of(ptr %t16, ptr null)
  %t18 = call ptr @__olang_scope_hold(ptr %t17)
  %t19 = ptrtoint ptr %t18 to i64
  %t21 = inttoptr i64 %t19 to ptr
  %t22 = load ptr, ptr %l6, !tbaa !29
  %t23 = call { i64, ptr } @std_2fnet_2estd_2fnet_3aAddr_2eStr(ptr %t21, ptr %s1, ptr %t22)
  store { i64, ptr } %t23, ptr %l7
  br label %bb6
bb6:
  %t24 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t24, 1
  %t26 = extractvalue { i64, ptr } %t24, 0
  call void @__olang_sb_put(ptr %v0, ptr %t25, i64 %t26)
  call void @__olang_scope_close(ptr %s1)
  br label %bb2
ret:
  ret void
}

define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @__olang_sb_done(ptr)
@.d2 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"localhost" }>, align 8
@.d3 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"::" }>, align 8
@.d4 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"linux" }>, align 8
@.d5 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"windows" }>, align 8
@.d6 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d7 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"localhost" }>, align 8
declare ptr @memmove(ptr, ptr, i64)
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d8 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare i64 @__olang_fmt_u64(ptr, i64)
@.d9 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d10 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"::" }>, align 8
declare i32 @connect(i32, ptr, i32)
declare i32 @listen(i32, i32)
@.d11 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"0" }>, align 8
declare i32 @getaddrinfo(ptr, ptr, ptr, ptr)
declare ptr @memcpy(ptr, ptr, i64)
declare void @freeaddrinfo(ptr)
define linkonce_odr %"<poll.h>:pollfd" @olang_2emir_2eHelperKind_2eZero_2e_3cpoll_2eh_3e_3apollfd() #0 {
entry:
  %l0 = alloca %"<poll.h>:pollfd"
  %rv = alloca %"<poll.h>:pollfd"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"<poll.h>:pollfd" @_3cpoll_2eh_3e_3apollfd_2ector(ptr %t1)
  store %"<poll.h>:pollfd" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"<poll.h>:pollfd", ptr %l0
  store %"<poll.h>:pollfd" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"<poll.h>:pollfd", ptr %rv
  ret %"<poll.h>:pollfd" %rr
}

declare i32 @poll(ptr, i64, i32)
declare i64 @recv(i32, ptr, i64, i32)
declare i64 @recvfrom(i32, ptr, i64, i32, ptr, ptr)
declare i32 @setsockopt(i32, i32, i32, ptr, i32)
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@.d12 = private unnamed_addr constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
declare void @__olang_sb_put(ptr, ptr, i64)
@.d13 = private unnamed_addr constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"..." }>, align 8
declare ptr @__olang_scope_of(ptr, ptr) noinline
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@__olang_prog_scope = external thread_local(initialexec) global ptr
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
declare { i32, %"std/net:Addr" } @std_2fnet_2eAddr_2eParse(ptr %v0, { i64, ptr } %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, { i64, i64 } } @std_2fnet_2edecimalAt(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2)
@olang_loc_f1d1c13cf3902f30_d152dc4ae276584 = external constant [0 x i8]
declare %"std/net:Addr" @std_2fnet_3aAddr_2ector(ptr %v0, %"std/net:IP" %a0, i16 %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %a0, i8 %a1)
@olang_loc_7b75bbc114d81c9_eaa9ae6a6f8e790d = external constant [0 x i8]
@olang_loc_890a129ff0c26c5c_548b75716a348c30 = external constant [0 x i8]
@G_2estd_2fnet_2esockStream = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare { i32, i32 } @std_2fnet_2eopen(ptr %v0, ptr %a0, i32 %a1)
declare i32 @std_2fnet_2esockErr()
declare void @std_2fnet_2ecloseSock(i32 %a0)
declare %"std/net:Conn" @std_2fnet_3aConn_2ector(ptr %v0, i32 %a0)
declare %"std/net:IP" @std_2fnet_2eIP_2eIPv4(i8 %a0, i8 %a1, i8 %a2, i8 %a3)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, %"std/net:IP" } @std_2fnet_2eIP_2eparse4(ptr %v0, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_f002e9158933fedd_16edb23c552ec181 = external constant [0 x i8]
@olang_loc_ab8b57281d5db880_ee039328189ec414 = external constant [0 x i8]
@olang_loc_5cec024583c1c07b_b48952299688f87f = external constant [0 x i8]
declare %"std/net:IP" @std_2fnet_3aIP_2ector(ptr %v0, i1 %a0)
@G_2estd_2fnet_2esolSocket = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2estd_2fnet_2esoReuseaddr = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare void @std_2fnet_2esetInt(i32 %a0, i32 %a1, i32 %a2, i32 %a3)
@G_2estd_2fnet_2eipprotoIpv6 = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\29\00\00\00" }>, align 8
@G_2estd_2fnet_2eipv6V6only = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\1A\00\00\00" }>, align 8
declare i32 @std_2fnet_2esysBind(ptr %v0, i32 %a0, { i64, ptr } %a1)
@G_2estd_2fnet_2esockDgram = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare i64 @std_2fprelude_2fnumber_2eU64_2eMin_3cU64_3e(i64 %a0, i64 %a1)
declare %"std/net:Addr" @std_2fnet_2eAddr_2efromSockaddr(ptr %v0, { i64, ptr } %a0)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fnet_3aIP_3e_2eHas_3cstd_2fnet_3aIP_3e(ptr %v0, ptr %a0, %"std/net:IP" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fnet_3aIP_3e_2ePush_3cstd_2fnet_3aIP_3e(ptr %v0, ptr %a0, %"std/net:IP" %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
@olang_loc_8981c24167caedc7_91d5c812394e4ba3 = external constant [0 x i8]
@olang_loc_bc64e253b1e7f486_2f7ea114c0e9c0f2 = external constant [0 x i8]
@olang_loc_f53fdd983c71e658_198e9c3d6c980e94 = external constant [0 x i8]
@G_2estd_2fnet_2eafInet6 = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\0A\00\00\00" }>, align 8
@G_2estd_2fnet_2eafInet = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@olang_loc_3e2092b4cdfb76b1_123327579653ae5d = external constant [0 x i8]
@olang_loc_185ce8e381582544_cdbb956a2a7d6800 = external constant [0 x i8]
declare i1 @std_2fnet_2einterrupted()
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2eI64_2eFormat(ptr %v0, i64 %a0, i64 %a1)
@olang_loc_2226b004e1161b9e_260abf21839543b2 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_4e1638ec2ac13854_38df9045e4ebdb28 = external constant [0 x i8]
declare %"<netdb.h>:addrinfo" @_3cnetdb_2eh_3e_3aaddrinfo_2ector(ptr %v0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToC(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fnet_3aIP_3e_2ector(ptr %v0, i64 %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fnet_3aIP_3e_2eToArray_3cstd_2fnet_3aIP_3e(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_8995c37d5bde66ea_5787b775da029666 = external constant [0 x i8]
@G_2e_3cpoll_2eh_3e_2ePOLLIN = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2estd_2fnet_2esoRcvtimeo = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\14\00\00\00" }>, align 8
@G_2estd_2fnet_2esoSndtimeo = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\15\00\00\00" }>, align 8
declare { i64, ptr } @std_2fnet_2estd_2fnet_3aAddr_2eStr(ptr %v0, ptr %v1, ptr %a0)
declare %"<poll.h>:pollfd" @_3cpoll_2eh_3e_3apollfd_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
