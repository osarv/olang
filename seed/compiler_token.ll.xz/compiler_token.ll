; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%"compiler/token:Token" = type { i32, i8, i32, i32 }
@G_2ecompiler_2ftoken_2eLineBreak = global i8 zeroinitializer
@G_2ecompiler_2ftoken_2eLineStart = global i8 zeroinitializer
@G_2ecompiler_2ftoken_2eSpace = global i8 zeroinitializer
define dso_local i32 @compiler_2ftoken_2eKeyword(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i8
  %l4 = alloca i8
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i8
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca i64
  %l12 = alloca i1
  %l13 = alloca i1
  %l14 = alloca i8
  %l15 = alloca i1
  %l16 = alloca i1
  %l17 = alloca i8
  %l18 = alloca i1
  %l19 = alloca i32
  %l20 = alloca i8
  %l21 = alloca i1
  %l22 = alloca i64
  %l23 = alloca i1
  %l24 = alloca i1
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i8
  %l29 = alloca i1
  %l30 = alloca i32
  %l31 = alloca i64
  %l32 = alloca i1
  %l33 = alloca i1
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i1
  %l37 = alloca i32
  %l38 = alloca i64
  %l39 = alloca i1
  %l40 = alloca i1
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca i1
  %l44 = alloca i32
  %l45 = alloca i8
  %l46 = alloca i1
  %l47 = alloca i64
  %l48 = alloca i1
  %l49 = alloca i1
  %l50 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca i1
  %l53 = alloca i32
  %l54 = alloca i8
  %l55 = alloca i1
  %l56 = alloca i64
  %l57 = alloca i1
  %l58 = alloca i1
  %l59 = alloca { i64, ptr }
  %l60 = alloca i64
  %l61 = alloca i1
  %l62 = alloca i32
  %l63 = alloca i64
  %l64 = alloca i1
  %l65 = alloca i1
  %l66 = alloca { i64, ptr }
  %l67 = alloca i64
  %l68 = alloca i1
  %l69 = alloca i32
  %l70 = alloca i64
  %l71 = alloca i1
  %l72 = alloca i1
  %l73 = alloca { i64, ptr }
  %l74 = alloca i64
  %l75 = alloca i1
  %l76 = alloca i32
  %l77 = alloca i64
  %l78 = alloca i1
  %l79 = alloca i1
  %l80 = alloca { i64, ptr }
  %l81 = alloca i64
  %l82 = alloca i1
  %l83 = alloca i32
  %l84 = alloca i8
  %l85 = alloca i1
  %l86 = alloca i64
  %l87 = alloca i1
  %l88 = alloca i1
  %l89 = alloca { i64, ptr }
  %l90 = alloca i64
  %l91 = alloca i64
  %l92 = alloca i8
  %l93 = alloca i1
  %l94 = alloca i32
  %l95 = alloca i64
  %l96 = alloca i1
  %l97 = alloca i1
  %l98 = alloca { i64, ptr }
  %l99 = alloca i64
  %l100 = alloca i1
  %l101 = alloca i32
  %l102 = alloca i64
  %l103 = alloca i1
  %l104 = alloca i1
  %l105 = alloca { i64, ptr }
  %l106 = alloca i64
  %l107 = alloca i1
  %l108 = alloca i32
  %l109 = alloca i64
  %l110 = alloca i1
  %l111 = alloca i1
  %l112 = alloca { i64, ptr }
  %l113 = alloca i64
  %l114 = alloca i1
  %l115 = alloca i32
  %l116 = alloca i8
  %l117 = alloca i1
  %l118 = alloca i64
  %l119 = alloca i1
  %l120 = alloca i1
  %l121 = alloca { i64, ptr }
  %l122 = alloca i64
  %l123 = alloca i1
  %l124 = alloca i32
  %l125 = alloca i64
  %l126 = alloca i1
  %l127 = alloca i1
  %l128 = alloca { i64, ptr }
  %l129 = alloca i64
  %l130 = alloca i1
  %l131 = alloca i32
  %l132 = alloca i64
  %l133 = alloca i1
  %l134 = alloca i1
  %l135 = alloca { i64, ptr }
  %l136 = alloca i64
  %l137 = alloca i1
  %l138 = alloca i32
  %l139 = alloca i64
  %l140 = alloca i1
  %l141 = alloca i1
  %l142 = alloca { i64, ptr }
  %l143 = alloca i64
  %l144 = alloca i1
  %l145 = alloca i32
  %l146 = alloca i64
  %l147 = alloca i1
  %l148 = alloca i1
  %l149 = alloca { i64, ptr }
  %l150 = alloca i64
  %l151 = alloca i1
  %l152 = alloca i32
  %l153 = alloca i8
  %l154 = alloca i1
  %l155 = alloca i64
  %l156 = alloca i1
  %l157 = alloca i1
  %l158 = alloca { i64, ptr }
  %l159 = alloca i64
  %l160 = alloca i64
  %l161 = alloca i8
  %l162 = alloca i1
  %l163 = alloca i32
  %l164 = alloca i64
  %l165 = alloca i1
  %l166 = alloca i1
  %l167 = alloca { i64, ptr }
  %l168 = alloca i64
  %l169 = alloca i1
  %l170 = alloca i32
  %l171 = alloca i64
  %l172 = alloca i1
  %l173 = alloca i1
  %l174 = alloca { i64, ptr }
  %l175 = alloca i64
  %l176 = alloca i1
  %l177 = alloca i32
  %l178 = alloca i8
  %l179 = alloca i1
  %l180 = alloca i64
  %l181 = alloca i1
  %l182 = alloca { i64, ptr }
  %l183 = alloca i64
  %l184 = alloca i64
  %l185 = alloca i8
  %l186 = alloca i8
  %l187 = alloca i1
  %l188 = alloca i32
  %l189 = alloca i8
  %l190 = alloca i1
  %l191 = alloca i32
  %l192 = alloca i8
  %l193 = alloca i1
  %l194 = alloca i32
  %l195 = alloca i64
  %l196 = alloca i1
  %l197 = alloca i1
  %l198 = alloca { i64, ptr }
  %l199 = alloca i64
  %l200 = alloca i1
  %l201 = alloca i32
  %l202 = alloca i8
  %l203 = alloca i1
  %l204 = alloca i64
  %l205 = alloca i1
  %l206 = alloca i1
  %l207 = alloca { i64, ptr }
  %l208 = alloca i64
  %l209 = alloca i1
  %l210 = alloca i32
  %l211 = alloca i8
  %l212 = alloca i1
  %l213 = alloca i64
  %l214 = alloca i1
  %l215 = alloca i1
  %l216 = alloca { i64, ptr }
  %l217 = alloca i64
  %l218 = alloca i1
  %l219 = alloca i32
  %l220 = alloca i64
  %l221 = alloca i1
  %l222 = alloca i1
  %l223 = alloca { i64, ptr }
  %l224 = alloca i64
  %l225 = alloca i1
  %l226 = alloca i32
  %l227 = alloca i8
  %l228 = alloca i1
  %l229 = alloca i64
  %l230 = alloca i1
  %l231 = alloca i1
  %l232 = alloca { i64, ptr }
  %l233 = alloca i64
  %l234 = alloca i1
  %l235 = alloca i32
  %l236 = alloca i64
  %l237 = alloca i1
  %l238 = alloca i1
  %l239 = alloca { i64, ptr }
  %l240 = alloca i64
  %l241 = alloca i1
  %l242 = alloca i32
  %l243 = alloca i64
  %l244 = alloca i1
  %l245 = alloca i1
  %l246 = alloca { i64, ptr }
  %l247 = alloca i64
  %l248 = alloca i1
  %l249 = alloca i32
  %l250 = alloca i64
  %l251 = alloca i1
  %l252 = alloca i1
  %l253 = alloca { i64, ptr }
  %l254 = alloca i64
  %l255 = alloca i1
  %l256 = alloca i32
  %l257 = alloca i8
  %l258 = alloca i1
  %l259 = alloca i64
  %l260 = alloca i1
  %l261 = alloca i1
  %l262 = alloca { i64, ptr }
  %l263 = alloca i64
  %l264 = alloca i64
  %l265 = alloca i8
  %l266 = alloca i1
  %l267 = alloca i32
  %l268 = alloca i64
  %l269 = alloca i1
  %l270 = alloca i1
  %l271 = alloca { i64, ptr }
  %l272 = alloca i64
  %l273 = alloca i1
  %l274 = alloca i32
  %l275 = alloca i8
  %l276 = alloca i1
  %l277 = alloca i64
  %l278 = alloca i1
  %l279 = alloca i1
  %l280 = alloca { i64, ptr }
  %l281 = alloca i64
  %l282 = alloca i1
  %l283 = alloca i32
  %l284 = alloca i64
  %l285 = alloca i1
  %l286 = alloca i1
  %l287 = alloca { i64, ptr }
  %l288 = alloca i64
  %l289 = alloca i1
  %l290 = alloca i32
  %l291 = alloca i8
  %l292 = alloca i1
  %l293 = alloca i64
  %l294 = alloca i1
  %l295 = alloca i1
  %l296 = alloca { i64, ptr }
  %l297 = alloca i64
  %l298 = alloca i1
  %l299 = alloca i32
  %l300 = alloca i64
  %l301 = alloca i1
  %l302 = alloca i1
  %l303 = alloca { i64, ptr }
  %l304 = alloca i64
  %l305 = alloca i1
  %l306 = alloca i32
  %l307 = alloca i8
  %l308 = alloca i1
  %l309 = alloca i64
  %l310 = alloca i1
  %l311 = alloca i1
  %l312 = alloca { i64, ptr }
  %l313 = alloca i64
  %l314 = alloca i1
  %l315 = alloca i32
  %l316 = alloca i64
  %l317 = alloca i1
  %l318 = alloca { i64, ptr }
  %l319 = alloca i64
  %l320 = alloca i1
  %l321 = alloca i32
  %l322 = alloca { i64, ptr }
  %l323 = alloca i64
  %l324 = alloca i1
  %l325 = alloca i32
  %l326 = alloca { i64, ptr }
  %l327 = alloca i64
  %l328 = alloca i1
  %l329 = alloca i32
  %l330 = alloca { i64, ptr }
  %l331 = alloca i64
  %l332 = alloca i1
  %l333 = alloca i32
  %l334 = alloca i64
  %l335 = alloca i1
  %l336 = alloca i1
  %l337 = alloca { i64, ptr }
  %l338 = alloca i64
  %l339 = alloca i1
  %l340 = alloca i32
  %l341 = alloca i8
  %l342 = alloca i1
  %l343 = alloca i64
  %l344 = alloca i1
  %l345 = alloca i1
  %l346 = alloca { i64, ptr }
  %l347 = alloca i64
  %l348 = alloca i1
  %l349 = alloca i32
  %l350 = alloca i8
  %l351 = alloca i1
  %l352 = alloca i64
  %l353 = alloca i1
  %l354 = alloca i1
  %l355 = alloca { i64, ptr }
  %l356 = alloca i64
  %l357 = alloca i1
  %l358 = alloca i32
  %l359 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %s41 = alloca %olang.scope
  %s42 = alloca %olang.scope
  %s43 = alloca %olang.scope
  %s44 = alloca %olang.scope
  %s45 = alloca %olang.scope
  %s46 = alloca %olang.scope
  %s47 = alloca %olang.scope
  %s48 = alloca %olang.scope
  %s49 = alloca %olang.scope
  %s50 = alloca %olang.scope
  %s51 = alloca %olang.scope
  %s52 = alloca %olang.scope
  %s53 = alloca %olang.scope
  %s54 = alloca %olang.scope
  %s55 = alloca %olang.scope
  %s56 = alloca %olang.scope
  %s57 = alloca %olang.scope
  %s58 = alloca %olang.scope
  %s59 = alloca %olang.scope
  %s60 = alloca %olang.scope
  %s61 = alloca %olang.scope
  %s62 = alloca %olang.scope
  %s63 = alloca %olang.scope
  %s64 = alloca %olang.scope
  %s65 = alloca %olang.scope
  %rv = alloca i32
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l5
  %t2 = load i64, ptr %l1
  store i64 %t2, ptr %l6
  %t3 = load i64, ptr %l6
  %t4 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t5 = load ptr, ptr %t4
  %t6 = getelementptr i8, ptr %t5, i64 %t3
  %t7 = load i8, ptr %t6
  store i8 %t7, ptr %l7
  %t8 = load i8, ptr %l7
  store i8 %t8, ptr %l3
  %t9 = load i64, ptr %l2
  store i64 %t9, ptr %l8
  %t10 = load i64, ptr %l8
  %t11 = icmp slt i64 %t10, 2
  store i1 %t11, ptr %l9
  %t12 = load i1, ptr %l9
  br i1 %t12, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l10
  br label %bb3
bb2:
  %t13 = load i64, ptr %l2
  store i64 %t13, ptr %l11
  %t14 = load i64, ptr %l11
  %t15 = icmp sgt i64 %t14, 11
  store i1 %t15, ptr %l12
  %t16 = load i1, ptr %l12
  store i1 %t16, ptr %l10
  br label %bb3
bb3:
  %t17 = load i1, ptr %l10
  br i1 %t17, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l13
  br label %bb6
bb5:
  %t18 = load i8, ptr %l3
  store i8 %t18, ptr %l14
  %t19 = load i8, ptr %l14
  %t20 = icmp ult i8 %t19, 97
  store i1 %t20, ptr %l15
  %t21 = load i1, ptr %l15
  store i1 %t21, ptr %l13
  br label %bb6
bb6:
  %t22 = load i1, ptr %l13
  br i1 %t22, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l16
  br label %bb9
bb8:
  %t23 = load i8, ptr %l3
  store i8 %t23, ptr %l17
  %t24 = load i8, ptr %l17
  %t25 = icmp ugt i8 %t24, 120
  store i1 %t25, ptr %l18
  %t26 = load i1, ptr %l18
  store i1 %t26, ptr %l16
  br label %bb9
bb9:
  %t27 = load i1, ptr %l16
  br i1 %t27, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s1
  store i32 1, ptr %l19
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t28 = load i32, ptr %l19
  store i32 %t28, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t29 = load i8, ptr %l3
  store i8 %t29, ptr %l20
  %t30 = load i8, ptr %l20
  %t31 = icmp eq i8 %t30, 97
  store i1 %t31, ptr %l21
  %t32 = load i1, ptr %l21
  br i1 %t32, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb36
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load i64, ptr %l2
  store i64 %t33, ptr %l22
  %t34 = load i64, ptr %l22
  %t35 = icmp eq i64 %t34, 2
  store i1 %t35, ptr %l23
  %t36 = load i1, ptr %l23
  br i1 %t36, label %bb16, label %bb17
bb16:
  %t37 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t37, ptr %l25
  %t38 = load i64, ptr %l1
  store i64 %t38, ptr %l26
  %t39 = load i64, ptr %l26
  %t40 = add i64 %t39, 1
  store i64 %t40, ptr %l27
  %t41 = load i64, ptr %l27
  %t42 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t43 = load ptr, ptr %t42
  %t44 = getelementptr i8, ptr %t43, i64 %t41
  %t45 = load i8, ptr %t44
  store i8 %t45, ptr %l28
  %t46 = load i8, ptr %l28
  %t47 = icmp eq i8 %t46, 115
  store i1 %t47, ptr %l29
  %t48 = load i1, ptr %l29
  store i1 %t48, ptr %l24
  br label %bb18
bb17:
  store i1 false, ptr %l24
  br label %bb18
bb18:
  %t49 = load i1, ptr %l24
  br i1 %t49, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  store i32 28, ptr %l30
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t50 = load i32, ptr %l30
  store i32 %t50, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t51 = load i64, ptr %l2
  store i64 %t51, ptr %l31
  %t52 = load i64, ptr %l31
  %t53 = icmp eq i64 %t52, 3
  store i1 %t53, ptr %l32
  %t54 = load i1, ptr %l32
  br i1 %t54, label %bb22, label %bb23
bb22:
  %t55 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t55, ptr %l34
  %t56 = load i64, ptr %l1
  store i64 %t56, ptr %l35
  %t57 = load { i64, ptr }, ptr %l34
  %t58 = load i64, ptr %l35
  %t59 = call i1 @compiler_2ftoken_2espells(ptr %v0, ptr %s2, { i64, ptr } %t57, i64 %t58, { i64, ptr } { i64 3, ptr @.d0 })
  store i1 %t59, ptr %l36
  br label %bb24
bb23:
  store i1 false, ptr %l33
  br label %bb25
bb24:
  %t60 = load i1, ptr %l36
  store i1 %t60, ptr %l33
  br label %bb25
bb25:
  %t61 = load i1, ptr %l33
  br i1 %t61, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s4
  store i32 47, ptr %l37
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t62 = load i32, ptr %l37
  store i32 %t62, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t63 = load i64, ptr %l2
  store i64 %t63, ptr %l38
  %t64 = load i64, ptr %l38
  %t65 = icmp eq i64 %t64, 6
  store i1 %t65, ptr %l39
  %t66 = load i1, ptr %l39
  br i1 %t66, label %bb29, label %bb30
bb29:
  %t67 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t67, ptr %l41
  %t68 = load i64, ptr %l1
  store i64 %t68, ptr %l42
  %t69 = load { i64, ptr }, ptr %l41
  %t70 = load i64, ptr %l42
  %t71 = call i1 @compiler_2ftoken_2espells(ptr %v0, ptr %s2, { i64, ptr } %t69, i64 %t70, { i64, ptr } { i64 6, ptr @.d1 })
  store i1 %t71, ptr %l43
  br label %bb31
bb30:
  store i1 false, ptr %l40
  br label %bb32
bb31:
  %t72 = load i1, ptr %l43
  store i1 %t72, ptr %l40
  br label %bb32
bb32:
  %t73 = load i1, ptr %l40
  br i1 %t73, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s5
  store i32 23, ptr %l44
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t74 = load i32, ptr %l44
  store i32 %t74, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s2)
  br label %bb370
bb36:
  %t75 = load i8, ptr %l3
  store i8 %t75, ptr %l45
  %t76 = load i8, ptr %l45
  %t77 = icmp eq i8 %t76, 98
  store i1 %t77, ptr %l46
  %t78 = load i1, ptr %l46
  br i1 %t78, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb47
bb39:
  store %olang.scope zeroinitializer, ptr %s6
  %t79 = load i64, ptr %l2
  store i64 %t79, ptr %l47
  %t80 = load i64, ptr %l47
  %t81 = icmp eq i64 %t80, 5
  store i1 %t81, ptr %l48
  %t82 = load i1, ptr %l48
  br i1 %t82, label %bb40, label %bb41
bb40:
  %t83 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t83, ptr %l50
  %t84 = load i64, ptr %l1
  store i64 %t84, ptr %l51
  %t85 = load { i64, ptr }, ptr %l50
  %t86 = load i64, ptr %l51
  %t87 = call i1 @compiler_2ftoken_2espells(ptr %v0, ptr %s6, { i64, ptr } %t85, i64 %t86, { i64, ptr } { i64 5, ptr @.d2 })
  store i1 %t87, ptr %l52
  br label %bb42
bb41:
  store i1 false, ptr %l49
  br label %bb43
bb42:
  %t88 = load i1, ptr %l52
  store i1 %t88, ptr %l49
  br label %bb43
bb43:
  %t89 = load i1, ptr %l49
  br i1 %t89, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s7
  store i32 18, ptr %l53
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t90 = load i32, ptr %l53
  store i32 %t90, ptr %rv
  br label %ret
bb45:
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s6)
  br label %bb370
bb47:
  %t91 = load i8, ptr %l3
  store i8 %t91, ptr %l54
  %t92 = load i8, ptr %l54
  %t93 = icmp eq i8 %t92, 99
  store i1 %t93, ptr %l55
  %t94 = load i1, ptr %l55
  br i1 %t94, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb79
bb50:
  store %olang.scope zeroinitializer, ptr %s8
  %t95 = load i64, ptr %l2
  store i64 %t95, ptr %l56
  %t96 = load i64, ptr %l56
  %t97 = icmp eq i64 %t96, 4
  store i1 %t97, ptr %l57
  %t98 = load i1, ptr %l57
  br i1 %t98, label %bb51, label %bb52
bb51:
  %t99 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t99, ptr %l59
  %t100 = load i64, ptr %l1
  store i64 %t100, ptr %l60
  %t101 = load { i64, ptr }, ptr %l59
  %t102 = load i64, ptr %l60
  %t103 = call i1 @compiler_2ftoken_2espells(ptr %v0, ptr %s8, { i64, ptr } %t101, i64 %t102, { i64, ptr } { i64 4, ptr @.d3 })
  store i1 %t103, ptr %l61
  br label %bb53
bb52:
  store i1 false, ptr %l58
  br label %bb54
bb53:
  %t104 = load i1, ptr %l61
  store i1 %t104, ptr %l58
  br label %bb54
bb54:
  %t105 = load i1, ptr %l58
  br i1 %t105, label %bb55, label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s9
  store i32 31, ptr %l62
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t106 = load i32, ptr %l62
  store i32 %t106, ptr %rv
  br label %ret
bb56:
  br label %bb57
bb57:
  %t107 = load i64, ptr %l2
  store i64 %t107, ptr %l63
  %t108 = load i64, ptr %l63
  %t109 = icmp eq i64 %t108, 5
  store i1 %t109, ptr %l64
  %t110 = load i1, ptr %l64
  br i1 %t110, label %bb58, label %bb59
bb58:
  %t111 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t111, ptr %l66
  %t112 = load i64, ptr %l1
  store i64 %t112, ptr %l67
  %t113 = load { i64, ptr }, ptr %l66
  %t114 = load i64, ptr %l67
  %t115 = call i1 @compiler_2ftoken_2espells(ptr %v0, ptr %s8, { i64, ptr } %t113, i64 %t114, { i64, ptr } { i64 5, ptr @.d4 })
  store i1 %t115, ptr %l68
  br label %bb60
bb59:
  store i1 false, ptr %l65
  br label %bb61
bb60:
  %t116 = load i1, ptr %l68
  store i1 %t116, ptr %l65
  br label %bb61
bb61:
  %t117 = load i1, ptr %l65
  br i1 %t117, label %bb62, label %bb63
bb62:
  store %olang.scope zeroinitializer, ptr %s10
  store i32 13, ptr %l69
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t118 = load i32, ptr %l69
  store i32 %t118, ptr %rv
  br label %ret
bb63:
  br label %bb64
bb64:
  %t119 = load i64, ptr %l2
  store i64 %t119, ptr %l70
  %t120 = load i64, ptr %l70
  %t121 = icmp eq i64 %t120, 7
  store i1 %t121, ptr %l71
  %t122 = load i1, ptr %l71
  br i1 %t122, label %bb65, label %bb66
bb65:
  %t123 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t123, ptr %l73
  %t124 = load i64, ptr %l1
  store i64 %t124, ptr %l74
  %t125 = load { i64, ptr }, ptr %l73
  %t126 = load i64, ptr %l74
  %t127 = call i1 @compiler_2ftoken_2espells(ptr %v0, ptr %s8, { i64, ptr } %t125, i64 %t126, { i64, ptr } { i64 7, ptr @.d5 })
  store i1 %t127, ptr %l75
  br label %bb67
bb66:
  store i1 false, ptr %l72
  br label %bb68
bb67:
  %t128 = load i1, ptr %l75
  store i1 %t128, ptr %l72
  br label %bb68
bb68:
  %t129 = load i1, ptr %l72
  br i1 %t129, label %bb69, label %bb70
bb69:
  store %olang.scope zeroinitializer, ptr %s11
  store i32 12, ptr %l76
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t130 = load i32, ptr %l76
  store i32 %t130, ptr %rv
  br label %ret
bb70:
  br label %bb71
bb71:
  %t131 = load i64, ptr %l2
  store i64 %t131, ptr %l77
  %t132 = load i64, ptr %l77
  %t133 = icmp eq i64 %t132, 8
  store i1 %t133, ptr %l78
  %t134 = load i1, ptr %l78
  br i1 %t134, label %bb72, label %bb73
bb72:
  %t135 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t135, ptr %l80
  %t136 = load i64, ptr %l1
  store i64 %t136, ptr %l81
  %t137 = load { i64, ptr }, ptr %l80
  %t138 = load i64, ptr %l81
  %t139 = call i1 @compiler_2ftoken_2espells(ptr %v0, ptr %s8, { i64, ptr } %t137, i64 %t138, { i64, ptr } { i64 8, ptr @.d6 })
  store i1 %t139, ptr %l82
  br label %bb74
bb73:
  store i1 false, ptr %l79
  br label %bb75
bb74:
  %t140 = load i1, ptr %l82
  store i1 %t140, ptr %l79
  br label %bb75
bb75:
  %t141 = load i1, ptr %l79
  br i1 %t141, label %bb76, label %bb77
bb76:
  store %olang.scope zeroinitializer, ptr %s12
  store i32 19, ptr %l83
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t142 = load i32, ptr %l83
  store i32 %t142, ptr %rv
  br label %ret
bb77:
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s8)
  br label %bb370
bb79:
  %t143 = load i8, ptr %l3
  store i8 %t143, ptr %l84
  %t144 = load i8, ptr %l84
  %t145 = icmp eq i8 %t144, 100
  store i1 %t145, ptr %l85
  %t146 = load i1, ptr %l85
  br i1 %t146, label %bb80, label %bb81
bb80:
  br label %bb82
bb81:
  br label %bb110
bb82:
  store %olang.scope zeroinitializer, ptr %s13
  %t147 = load i64, ptr %l2
  store i64 %t147, ptr %l86
  %t148 = load i64, ptr %l86
  %t149 = icmp eq i64 %t148, 2
  store i1 %t149, ptr %l87
  %t150 = load i1, ptr %l87
  br i1 %t150, label %bb83, label %bb84
bb83:
  %t151 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t151, ptr %l89
  %t152 = load i64, ptr %l1
  store i64 %t152, ptr %l90
  %t153 = load i64, ptr %l90
  %t154 = add i64 %t153, 1
  store i64 %t154, ptr %l91
  %t155 = load i64, ptr %l91
  %t156 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t157 = load ptr, ptr %t156
  %t158 = getelementptr i8, ptr %t157, i64 %t155
  %t159 = load i8, ptr %t158
  store i8 %t159, ptr %l92
  %t160 = load i8, ptr %l92
  %t161 = icmp eq i8 %t160, 111
  store i1 %t161, ptr %l93
  %t162 = load i1, ptr %l93
  store i1 %t162, ptr %l88
  br label %bb85
bb84:
  store i1 false, ptr %l88
  br label %bb85
bb85:
  %t163 = load i1, ptr %l88
  br i1 %t163, label %bb86, label %bb87
bb86:
  store %olang.scope zeroinitializer, ptr %s14
  store i32 25, ptr %l94
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  %t164 = load i32, ptr %l94
  store i32 %t164, ptr %rv
  br label %ret
bb87:
  br label %bb88
bb88:
  %t165 = load i64, ptr %l2
  store i64 %t165, ptr %l95
  %t166 = load i64, ptr %l95
  %t167 = icmp eq i64 %t166, 5
  store i1 %t167, ptr %l96
  %t168 = load i1, ptr %l96
  br i1 %t168, label %bb89, label %bb90
bb89:
  %t169 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t169, ptr %l98
  %t170 = load i64, ptr %l1
  store i64 %t170, ptr %l99
  %t171 = load { i64, ptr }, ptr %l98
  %t172 = load i64, ptr %l99
  %t173 = call i1 @compiler_2ftoken_2espells(ptr %v0, ptr %s13, { i64, ptr } %t171, i64 %t172, { i64, ptr } { i64 5, ptr @.d7 })
  store i1 %t173, ptr %l100
  br label %bb91
bb90:
  store i1 false, ptr %l97
  br label %bb92
bb91:
  %t174 = load i1, ptr %l100
  store i1 %t174, ptr %l97
  br label %bb92
bb92:
  %t175 = load i1, ptr %l97
  br i1 %t175, label %bb93, label %bb94
bb93:
  store %olang.scope zeroinitializer, ptr %s15
  store i32 17, ptr %l101
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  %t176 = load i32, ptr %l101
  store i32 %t176, ptr %rv
  br label %ret
bb94:
  br label %bb95
bb95:
  %t177 = load i64, ptr %l2
  store i64 %t177, ptr %l102
  %t178 = load i64, ptr %l102
  %t179 = icmp eq i64 %t178, 7
  store i1 %t179, ptr %l103
  %t180 = load i1, ptr %l103
  br i1 %t180, label %bb96, label %bb97
bb96:
  %t181 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t181, ptr %l105
  %t182 = load i64, ptr %l1
  store i64 %t182, ptr %l106
  %t183 = load { i64, ptr }, ptr %l105
  %t184 = load i64, ptr %l106
  %t185 = call i1 @compiler_2ftoken_2espells(ptr %v0, ptr %s13, { i64, ptr } %t183, i64 %t184, { i64, ptr } { i64 7, ptr @.d8 })
  store i1 %t185, ptr %l107
  br label %bb98
bb97:
  store i1 false, ptr %l104
  br label %bb99
bb98:
  %t186 = load i1, ptr %l107
  store i1 %t186, ptr %l104
  br label %bb99
bb99:
  %t187 = load i1, ptr %l104
  br i1 %t187, label %bb100, label %bb101
bb100:
  store %olang.scope zeroinitializer, ptr %s16
  store i32 46, ptr %l108
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  %t188 = load i32, ptr %l108
  store i32 %t188, ptr %rv
  br label %ret
bb101:
  br label %bb102
bb102:
  %t189 = load i64, ptr %l2
  store i64 %t189, ptr %l109
  %t190 = load i64, ptr %l109
  %t191 = icmp eq i64 %t190, 8
  store i1 %t191, ptr %l110
  %t192 = load i1, ptr %l110
  br i1 %t192, label %bb103, label %bb104
bb103:
  %t193 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t193, ptr %l112
  %t194 = load i64, ptr %l1
  store i64 %t194, ptr %l113
  %t195 = load { i64, ptr }, ptr %l112
  %t196 = load i64, ptr %l113
  %t197 = call i1 @compiler_2ftoken_2espells(ptr %v0, ptr %s13, { i64, ptr } %t195, i64 %t196, { i64, ptr } { i64 8, ptr @.d9 })
  store i1 %t197, ptr %l114
  br label %bb105
bb104:
  store i1 false, ptr %l111
  br label %bb106
bb105:
  %t198 = load i1, ptr %l114
  store i1 %t198, ptr %l111
  br label %bb106
bb106:
  %t199 = load i1, ptr %l111
  br i1 %t199, label %bb107, label %bb108
bb107:
  store %olang.scope zeroinitializer, ptr %s17
  store i32 44, ptr %l115
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  %t200 = load i32, ptr %l115
  store i32 %t200, ptr %rv
  br label %ret
bb108:
  br label %bb109
bb109:
  call void @__olang_scope_close(ptr %s13)
  br label %bb370
bb110:
  %t201 = load i8, ptr %l3
  store i8 %t201, ptr %l116
  %t202 = load i8, ptr %l116
  %t203 = icmp eq i8 %t202, 101
  store i1 %t203, ptr %l117
  %t204 = load i1, ptr %l117
  br i1 %t204, label %bb111, label %bb112
bb111:
  br label %bb113
bb112:
  br label %bb149
bb113:
  store %olang.scope zeroinitializer, ptr %s18
  %t205 = load i64, ptr %l2
  store i64 %t205, ptr %l118
  %t206 = load i64, ptr %l118
  %t207 = icmp eq i64 %t206, 4
  store i1 %t207, ptr %l119
  %t208 = load i1, ptr %l119
  br i1 %t208, label %bb114, label %bb115
bb114:
  %t209 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t209, ptr %l121
  %t210 = load i64, ptr %l1
  store i64 %t210, ptr %l122
  %t211 = load { i64, ptr }, ptr %l121
  %t212 = load i64, ptr %l122
  %t213 = call i1 @compiler_2ftoken_2espells(ptr %v0, ptr %s18, { i64, ptr } %t211, i64 %t212, { i64, ptr } { i64 4, ptr @.d10 })
  store i1 %t213, ptr %l123
  br label %bb116
bb115:
  store i1 false, ptr %l120
  br label %bb117
bb116:
  %t214 = load i1, ptr %l123
  store i1 %t214, ptr %l120
  br label %bb117
bb117:
  %t215 = load i1, ptr %l120
  br i1 %t215, label %bb118, label %bb119
bb118:
  store %olang.scope zeroinitializer, ptr %s19
  store i32 10, ptr %l124
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s0)
  %t216 = load i32, ptr %l124
  store i32 %t216, ptr %rv
  br label %ret
bb119:
  br label %bb120
bb120:
  %t217 = load i64, ptr %l2
  store i64 %t217, ptr %l125
  %t218 = load i64, ptr %l125
  %t219 = icmp eq i64 %t218, 4
  store i1 %t219, ptr %l126
  %t220 = load i1, ptr %l126
  br i1 %t220, label %bb121, label %bb122
bb121:
  %t221 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t221, ptr %l128
  %t222 = load i64, ptr %l1
  store i64 %t222, ptr %l129
  %t223 = load { i64, ptr }, ptr %l128
  %t224 = load i64, ptr %l129
  %t225 = call i1 @compiler_2ftoken_2espells(ptr %v0, ptr %s18, { i64, ptr } %t223, i64 %t224, { i64, ptr } { i64 4, ptr @.d11 })
  store i1 %t225, ptr %l130
  br label %bb123
bb122:
  store i1 false, ptr %l127
  br label %bb124
bb123:
  %t226 = load i1, ptr %l130
  store i1 %t226, ptr %l127
  br label %bb124
bb124:
  %t227 = load i1, ptr %l127
  br i1 %t227, label %bb125, label %bb126
bb125:
  store %olang.scope zeroinitializer, ptr %s20
  store i32 35, ptr %l131
  call void @__olang_scope_close(ptr %s20)
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s0)
  %t228 = load i32, ptr %l131
  store i32 %t228, ptr %rv
  br label %ret
bb126:
  br label %bb127
bb127:
  %t229 = load i64, ptr %l2
  store i64 %t229, ptr %l132
  %t230 = load i64, ptr %l132
  %t231 = icmp eq i64 %t230, 5
  store i1 %t231, ptr %l133
  %t232 = load i1, ptr %l133
  br i1 %t232, label %bb128, label %bb129
bb128:
  %t233 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t233, ptr %l135
  %t234 = load i64, ptr %l1
  store i64 %t234, ptr %l136
  %t235 = load { i64, ptr }, ptr %l135
  %t236 = load i64, ptr %l136
  %t237 = call i1 @compiler_2ftoken_2espells(ptr %v0, ptr %s18, { i64, ptr } %t235, i64 %t236, { i64, ptr } { i64 5, ptr @.d12 })
  store i1 %t237, ptr %l137
  br label %bb130
bb129:
  store i1 false, ptr %l134
  br label %bb131
bb130:
  %t238 = load i1, ptr %l137
  store i1 %t238, ptr %l134
  br label %bb131
bb131:
  %t239 = load i1, ptr %l134
  br i1 %t239, label %bb132, label %bb133
bb132:
  store %olang.scope zeroinitializer, ptr %s21
  store i32 38, ptr %l138
  call void @__olang_scope_close(ptr %s21)
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s0)
  %t240 = load i32, ptr %l138
  store i32 %t240, ptr %rv
  br label %ret
bb133:
  br label %bb134
bb134:
  %t241 = load i64, ptr %l2
  store i64 %t241, ptr %l139
  %t242 = load i64, ptr %l139
  %t243 = icmp eq i64 %t242, 7
  store i1 %t243, ptr %l140
  %t244 = load i1, ptr %l140
  br i1 %t244, label %bb135, label %bb136
bb135:
  %t245 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t245, ptr %l142
  %t246 = load i64, ptr %l1
  store i64 %t246, ptr %l143
  %t247 = load { i64, ptr }, ptr %l142
  %t248 = load i64, ptr %l143
  %t249 = call i1 @compiler_2ftoken_2espells(ptr %v0, ptr %s18, { i64, ptr } %t247, i64 %t248, { i64, ptr } { i64 7, ptr @.d13 })
  store i1 %t249, ptr %l144
  br label %bb137
bb136:
  store i1 false, ptr %l141
  br label %bb138
bb137:
  %t250 = load i1, ptr %l144
  store i1 %t250, ptr %l141
  br label %bb138
bb138:
  %t251 = load i1, ptr %l141
  br i1 %t251, label %bb139, label %bb140
bb139:
  store %olang.scope zeroinitializer, ptr %s22
  store i32 21, ptr %l145
  call void @__olang_scope_close(ptr %s22)
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s0)
  %t252 = load i32, ptr %l145
  store i32 %t252, ptr %rv
  br label %ret
bb140:
  br label %bb141
bb141:
  %t253 = load i64, ptr %l2
  store i64 %t253, ptr %l146
  %t254 = load i64, ptr %l146
  %t255 = icmp eq i64 %t254, 6
  store i1 %t255, ptr %l147
  %t256 = load i1, ptr %l147
  br i1 %t256, label %bb142, label %bb143
bb142:
  %t257 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t257, ptr %l149
  %t258 = load i64, ptr %l1
  store i64 %t258, ptr %l150
  %t259 = load { i64, ptr }, ptr %l149
  %t260 = load i64, ptr %l150
  %t261 = call i1 @compiler_2ftoken_2espells(ptr %v0, ptr %s18, { i64, ptr } %t259, i64 %t260, { i64, ptr } { i64 6, ptr @.d14 })
  store i1 %t261, ptr %l151
  br label %bb144
bb143:
  store i1 false, ptr %l148
  br label %bb145
bb144:
  %t262 = load i1, ptr %l151
  store i1 %t262, ptr %l148
  br label %bb145
bb145:
  %t263 = load i1, ptr %l148
  br i1 %t263, label %bb146, label %bb147
bb146:
  store %olang.scope zeroinitializer, ptr %s23
  store i32 45, ptr %l152
  call void @__olang_scope_close(ptr %s23)
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s0)
  %t264 = load i32, ptr %l152
  store i32 %t264, ptr %rv
  br label %ret
bb147:
  br label %bb148
bb148:
  call void @__olang_scope_close(ptr %s18)
  br label %bb370
bb149:
  %t265 = load i8, ptr %l3
  store i8 %t265, ptr %l153
  %t266 = load i8, ptr %l153
  %t267 = icmp eq i8 %t266, 102
  store i1 %t267, ptr %l154
  %t268 = load i1, ptr %l154
  br i1 %t268, label %bb150, label %bb151
bb150:
  br label %bb152
bb151:
  br label %bb173
bb152:
  store %olang.scope zeroinitializer, ptr %s24
  %t269 = load i64, ptr %l2
  store i64 %t269, ptr %l155
  %t270 = load i64, ptr %l155
  %t271 = icmp eq i64 %t270, 2
  store i1 %t271, ptr %l156
  %t272 = load i1, ptr %l156
  br i1 %t272, label %bb153, label %bb154
bb153:
  %t273 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t273, ptr %l158
  %t274 = load i64, ptr %l1
  store i64 %t274, ptr %l159
  %t275 = load i64, ptr %l159
  %t276 = add i64 %t275, 1
  store i64 %t276, ptr %l160
  %t277 = load i64, ptr %l160
  %t278 = getelementptr { i64, ptr }, ptr %l158, i32 0, i32 1
  %t279 = load ptr, ptr %t278
  %t280 = getelementptr i8, ptr %t279, i64 %t277
  %t281 = load i8, ptr %t280
  store i8 %t281, ptr %l161
  %t282 = load i8, ptr %l161
  %t283 = icmp eq i8 %t282, 110
  store i1 %t283, ptr %l162
  %t284 = load i1, ptr %l162
  store i1 %t284, ptr %l157
  br label %bb155
bb154:
  store i1 false, ptr %l157
  br label %bb155
bb155:
  %t285 = load i1, ptr %l157
  br i1 %t285, label %bb156, label %bb157
bb156:
  store %olang.scope zeroinitializer, ptr %s25
  store i32 37, ptr %l163
  call void @__olang_scope_close(ptr %s25)
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s0)
  %t286 = load i32, ptr %l163
  store i32 %t286, ptr %rv
  br label %ret
bb157:
  br label %bb158
bb158:
  %t287 = load i64, ptr %l2
  store i64 %t287, ptr %l164
  %t288 = load i64, ptr %l164
  %t289 = icmp eq i64 %t288, 3
  store i1 %t289, ptr %l165
  %t290 = load i1, ptr %l165
  br i1 %t290, label %bb159, label %bb160
bb159:
  %t291 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t291, ptr %l167
  %t292 = load i64, ptr %l1
  store i64 %t292, ptr %l168
  %t293 = load { i64, ptr }, ptr %l167
  %t294 = load i64, ptr %l168
  %t295 = call i1 @compiler_2ftoken_2espells(ptr %v0, ptr %s24, { i64, ptr } %t293, i64 %t294, { i64, ptr } { i64 3, ptr @.d15 })
  store i1 %t295, ptr %l169
  br label %bb161
bb160:
  store i1 false, ptr %l166
  br label %bb162
bb161:
  %t296 = load i1, ptr %l169
  store i1 %t296, ptr %l166
  br label %bb162
bb162:
  %t297 = load i1, ptr %l166
  br i1 %t297, label %bb163, label %bb164
bb163:
  store %olang.scope zeroinitializer, ptr %s26
  store i32 24, ptr %l170
  call void @__olang_scope_close(ptr %s26)
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s0)
  %t298 = load i32, ptr %l170
  store i32 %t298, ptr %rv
  br label %ret
bb164:
  br label %bb165
bb165:
  %t299 = load i64, ptr %l2
  store i64 %t299, ptr %l171
  %t300 = load i64, ptr %l171
  %t301 = icmp eq i64 %t300, 5
  store i1 %t301, ptr %l172
  %t302 = load i1, ptr %l172
  br i1 %t302, label %bb166, label %bb167
bb166:
  %t303 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t303, ptr %l174
  %t304 = load i64, ptr %l1
  store i64 %t304, ptr %l175
  %t305 = load { i64, ptr }, ptr %l174
  %t306 = load i64, ptr %l175
  %t307 = call i1 @compiler_2ftoken_2espells(ptr %v0, ptr %s24, { i64, ptr } %t305, i64 %t306, { i64, ptr } { i64 5, ptr @.d16 })
  store i1 %t307, ptr %l176
  br label %bb168
bb167:
  store i1 false, ptr %l173
  br label %bb169
bb168:
  %t308 = load i1, ptr %l176
  store i1 %t308, ptr %l173
  br label %bb169
bb169:
  %t309 = load i1, ptr %l173
  br i1 %t309, label %bb170, label %bb171
bb170:
  store %olang.scope zeroinitializer, ptr %s27
  store i32 6, ptr %l177
  call void @__olang_scope_close(ptr %s27)
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s0)
  %t310 = load i32, ptr %l177
  store i32 %t310, ptr %rv
  br label %ret
bb171:
  br label %bb172
bb172:
  call void @__olang_scope_close(ptr %s24)
  br label %bb370
bb173:
  %t311 = load i8, ptr %l3
  store i8 %t311, ptr %l178
  %t312 = load i8, ptr %l178
  %t313 = icmp eq i8 %t312, 105
  store i1 %t313, ptr %l179
  %t314 = load i1, ptr %l179
  br i1 %t314, label %bb174, label %bb175
bb174:
  br label %bb176
bb175:
  br label %bb196
bb176:
  store %olang.scope zeroinitializer, ptr %s28
  %t315 = load i64, ptr %l2
  store i64 %t315, ptr %l180
  %t316 = load i64, ptr %l180
  %t317 = icmp eq i64 %t316, 2
  store i1 %t317, ptr %l181
  %t318 = load i1, ptr %l181
  br i1 %t318, label %bb177, label %bb178
bb177:
  store %olang.scope zeroinitializer, ptr %s29
  %t319 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t319, ptr %l182
  %t320 = load i64, ptr %l1
  store i64 %t320, ptr %l183
  %t321 = load i64, ptr %l183
  %t322 = add i64 %t321, 1
  store i64 %t322, ptr %l184
  %t323 = load i64, ptr %l184
  %t324 = getelementptr { i64, ptr }, ptr %l182, i32 0, i32 1
  %t325 = load ptr, ptr %t324
  %t326 = getelementptr i8, ptr %t325, i64 %t323
  %t327 = load i8, ptr %t326
  store i8 %t327, ptr %l185
  %t328 = load i8, ptr %l185
  store i8 %t328, ptr %l4
  %t329 = load i8, ptr %l4
  store i8 %t329, ptr %l186
  %t330 = load i8, ptr %l186
  %t331 = icmp eq i8 %t330, 102
  store i1 %t331, ptr %l187
  %t332 = load i1, ptr %l187
  br i1 %t332, label %bb179, label %bb180
bb178:
  br label %bb188
bb179:
  store %olang.scope zeroinitializer, ptr %s30
  store i32 9, ptr %l188
  call void @__olang_scope_close(ptr %s30)
  call void @__olang_scope_close(ptr %s29)
  call void @__olang_scope_close(ptr %s28)
  call void @__olang_scope_close(ptr %s0)
  %t333 = load i32, ptr %l188
  store i32 %t333, ptr %rv
  br label %ret
bb180:
  br label %bb181
bb181:
  %t334 = load i8, ptr %l4
  store i8 %t334, ptr %l189
  %t335 = load i8, ptr %l189
  %t336 = icmp eq i8 %t335, 110
  store i1 %t336, ptr %l190
  %t337 = load i1, ptr %l190
  br i1 %t337, label %bb182, label %bb183
bb182:
  store %olang.scope zeroinitializer, ptr %s31
  store i32 26, ptr %l191
  call void @__olang_scope_close(ptr %s31)
  call void @__olang_scope_close(ptr %s29)
  call void @__olang_scope_close(ptr %s28)
  call void @__olang_scope_close(ptr %s0)
  %t338 = load i32, ptr %l191
  store i32 %t338, ptr %rv
  br label %ret
bb183:
  br label %bb184
bb184:
  %t339 = load i8, ptr %l4
  store i8 %t339, ptr %l192
  %t340 = load i8, ptr %l192
  %t341 = icmp eq i8 %t340, 115
  store i1 %t341, ptr %l193
  %t342 = load i1, ptr %l193
  br i1 %t342, label %bb185, label %bb186
bb185:
  store %olang.scope zeroinitializer, ptr %s32
  store i32 27, ptr %l194
  call void @__olang_scope_close(ptr %s32)
  call void @__olang_scope_close(ptr %s29)
  call void @__olang_scope_close(ptr %s28)
  call void @__olang_scope_close(ptr %s0)
  %t343 = load i32, ptr %l194
  store i32 %t343, ptr %rv
  br label %ret
bb186:
  br label %bb187
bb187:
  call void @__olang_scope_close(ptr %s29)
  br label %bb188
bb188:
  %t344 = load i64, ptr %l2
  store i64 %t344, ptr %l195
  %t345 = load i64, ptr %l195
  %t346 = icmp eq i64 %t345, 6
  store i1 %t346, ptr %l196
  %t347 = load i1, ptr %l196
  br i1 %t347, label %bb189, label %bb190
bb189:
  %t348 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t348, ptr %l198
  %t349 = load i64, ptr %l1
  store i64 %t349, ptr %l199
  %t350 = load { i64, ptr }, ptr %l198
  %t351 = load i64, ptr %l199
  %t352 = call i1 @compiler_2ftoken_2espells(ptr %v0, ptr %s28, { i64, ptr } %t350, i64 %t351, { i64, ptr } { i64 6, ptr @.d17 })
  store i1 %t352, ptr %l200
  br label %bb191
bb190:
  store i1 false, ptr %l197
  br label %bb192
bb191:
  %t353 = load i1, ptr %l200
  store i1 %t353, ptr %l197
  br label %bb192
bb192:
  %t354 = load i1, ptr %l197
  br i1 %t354, label %bb193, label %bb194
bb193:
  store %olang.scope zeroinitializer, ptr %s33
  store i32 42, ptr %l201
  call void @__olang_scope_close(ptr %s33)
  call void @__olang_scope_close(ptr %s28)
  call void @__olang_scope_close(ptr %s0)
  %t355 = load i32, ptr %l201
  store i32 %t355, ptr %rv
  br label %ret
bb194:
  br label %bb195
bb195:
  call void @__olang_scope_close(ptr %s28)
  br label %bb370
bb196:
  %t356 = load i8, ptr %l3
  store i8 %t356, ptr %l202
  %t357 = load i8, ptr %l202
  %t358 = icmp eq i8 %t357, 106
  store i1 %t358, ptr %l203
  %t359 = load i1, ptr %l203
  br i1 %t359, label %bb197, label %bb198
bb197:
  br label %bb199
bb198:
  br label %bb207
bb199:
  store %olang.scope zeroinitializer, ptr %s34
  %t360 = load i64, ptr %l2
  store i64 %t360, ptr %l204
  %t361 = load i64, ptr %l204
  %t362 = icmp eq i64 %t361, 4
  store i1 %t362, ptr %l205
  %t363 = load i1, ptr %l205
  br i1 %t363, label %bb200, label %bb201
bb200:
  %t364 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t364, ptr %l207
  %t365 = load i64, ptr %l1
  store i64 %t365, ptr %l208
  %t366 = load { i64, ptr }, ptr %l207
  %t367 = load i64, ptr %l208
  %t368 = call i1 @compiler_2ftoken_2espells(ptr %v0, ptr %s34, { i64, ptr } %t366, i64 %t367, { i64, ptr } { i64 4, ptr @.d18 })
  store i1 %t368, ptr %l209
  br label %bb202
bb201:
  store i1 false, ptr %l206
  br label %bb203
bb202:
  %t369 = load i1, ptr %l209
  store i1 %t369, ptr %l206
  br label %bb203
bb203:
  %t370 = load i1, ptr %l206
  br i1 %t370, label %bb204, label %bb205
bb204:
  store %olang.scope zeroinitializer, ptr %s35
  store i32 15, ptr %l210
  call void @__olang_scope_close(ptr %s35)
  call void @__olang_scope_close(ptr %s34)
  call void @__olang_scope_close(ptr %s0)
  %t371 = load i32, ptr %l210
  store i32 %t371, ptr %rv
  br label %ret
bb205:
  br label %bb206
bb206:
  call void @__olang_scope_close(ptr %s34)
  br label %bb370
bb207:
  %t372 = load i8, ptr %l3
  store i8 %t372, ptr %l211
  %t373 = load i8, ptr %l211
  %t374 = icmp eq i8 %t373, 109
  store i1 %t374, ptr %l212
  %t375 = load i1, ptr %l212
  br i1 %t375, label %bb208, label %bb209
bb208:
  br label %bb210
bb209:
  br label %bb225
bb210:
  store %olang.scope zeroinitializer, ptr %s36
  %t376 = load i64, ptr %l2
  store i64 %t376, ptr %l213
  %t377 = load i64, ptr %l213
  %t378 = icmp eq i64 %t377, 3
  store i1 %t378, ptr %l214
  %t379 = load i1, ptr %l214
  br i1 %t379, label %bb211, label %bb212
bb211:
  %t380 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t380, ptr %l216
  %t381 = load i64, ptr %l1
  store i64 %t381, ptr %l217
  %t382 = load { i64, ptr }, ptr %l216
  %t383 = load i64, ptr %l217
  %t384 = call i1 @compiler_2ftoken_2espells(ptr %v0, ptr %s36, { i64, ptr } %t382, i64 %t383, { i64, ptr } { i64 3, ptr @.d19 })
  store i1 %t384, ptr %l218
  br label %bb213
bb212:
  store i1 false, ptr %l215
  br label %bb214
bb213:
  %t385 = load i1, ptr %l218
  store i1 %t385, ptr %l215
  br label %bb214
bb214:
  %t386 = load i1, ptr %l215
  br i1 %t386, label %bb215, label %bb216
bb215:
  store %olang.scope zeroinitializer, ptr %s37
  store i32 39, ptr %l219
  call void @__olang_scope_close(ptr %s37)
  call void @__olang_scope_close(ptr %s36)
  call void @__olang_scope_close(ptr %s0)
  %t387 = load i32, ptr %l219
  store i32 %t387, ptr %rv
  br label %ret
bb216:
  br label %bb217
bb217:
  %t388 = load i64, ptr %l2
  store i64 %t388, ptr %l220
  %t389 = load i64, ptr %l220
  %t390 = icmp eq i64 %t389, 5
  store i1 %t390, ptr %l221
  %t391 = load i1, ptr %l221
  br i1 %t391, label %bb218, label %bb219
bb218:
  %t392 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t392, ptr %l223
  %t393 = load i64, ptr %l1
  store i64 %t393, ptr %l224
  %t394 = load { i64, ptr }, ptr %l223
  %t395 = load i64, ptr %l224
  %t396 = call i1 @compiler_2ftoken_2espells(ptr %v0, ptr %s36, { i64, ptr } %t394, i64 %t395, { i64, ptr } { i64 5, ptr @.d20 })
  store i1 %t396, ptr %l225
  br label %bb220
bb219:
  store i1 false, ptr %l222
  br label %bb221
bb220:
  %t397 = load i1, ptr %l225
  store i1 %t397, ptr %l222
  br label %bb221
bb221:
  %t398 = load i1, ptr %l222
  br i1 %t398, label %bb222, label %bb223
bb222:
  store %olang.scope zeroinitializer, ptr %s38
  store i32 30, ptr %l226
  call void @__olang_scope_close(ptr %s38)
  call void @__olang_scope_close(ptr %s36)
  call void @__olang_scope_close(ptr %s0)
  %t399 = load i32, ptr %l226
  store i32 %t399, ptr %rv
  br label %ret
bb223:
  br label %bb224
bb224:
  call void @__olang_scope_close(ptr %s36)
  br label %bb370
bb225:
  %t400 = load i8, ptr %l3
  store i8 %t400, ptr %l227
  %t401 = load i8, ptr %l227
  %t402 = icmp eq i8 %t401, 110
  store i1 %t402, ptr %l228
  %t403 = load i1, ptr %l228
  br i1 %t403, label %bb226, label %bb227
bb226:
  br label %bb228
bb227:
  br label %bb257
bb228:
  store %olang.scope zeroinitializer, ptr %s39
  %t404 = load i64, ptr %l2
  store i64 %t404, ptr %l229
  %t405 = load i64, ptr %l229
  %t406 = icmp eq i64 %t405, 3
  store i1 %t406, ptr %l230
  %t407 = load i1, ptr %l230
  br i1 %t407, label %bb229, label %bb230
bb229:
  %t408 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t408, ptr %l232
  %t409 = load i64, ptr %l1
  store i64 %t409, ptr %l233
  %t410 = load { i64, ptr }, ptr %l232
  %t411 = load i64, ptr %l233
  %t412 = call i1 @compiler_2ftoken_2espells(ptr %v0, ptr %s39, { i64, ptr } %t410, i64 %t411, { i64, ptr } { i64 3, ptr @.d21 })
  store i1 %t412, ptr %l234
  br label %bb231
bb230:
  store i1 false, ptr %l231
  br label %bb232
bb231:
  %t413 = load i1, ptr %l234
  store i1 %t413, ptr %l231
  br label %bb232
bb232:
  %t414 = load i1, ptr %l231
  br i1 %t414, label %bb233, label %bb234
bb233:
  store %olang.scope zeroinitializer, ptr %s40
  store i32 50, ptr %l235
  call void @__olang_scope_close(ptr %s40)
  call void @__olang_scope_close(ptr %s39)
  call void @__olang_scope_close(ptr %s0)
  %t415 = load i32, ptr %l235
  store i32 %t415, ptr %rv
  br label %ret
bb234:
  br label %bb235
bb235:
  %t416 = load i64, ptr %l2
  store i64 %t416, ptr %l236
  %t417 = load i64, ptr %l236
  %t418 = icmp eq i64 %t417, 4
  store i1 %t418, ptr %l237
  %t419 = load i1, ptr %l237
  br i1 %t419, label %bb236, label %bb237
bb236:
  %t420 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t420, ptr %l239
  %t421 = load i64, ptr %l1
  store i64 %t421, ptr %l240
  %t422 = load { i64, ptr }, ptr %l239
  %t423 = load i64, ptr %l240
  %t424 = call i1 @compiler_2ftoken_2espells(ptr %v0, ptr %s39, { i64, ptr } %t422, i64 %t423, { i64, ptr } { i64 4, ptr @.d22 })
  store i1 %t424, ptr %l241
  br label %bb238
bb237:
  store i1 false, ptr %l238
  br label %bb239
bb238:
  %t425 = load i1, ptr %l241
  store i1 %t425, ptr %l238
  br label %bb239
bb239:
  %t426 = load i1, ptr %l238
  br i1 %t426, label %bb240, label %bb241
bb240:
  store %olang.scope zeroinitializer, ptr %s41
  store i32 7, ptr %l242
  call void @__olang_scope_close(ptr %s41)
  call void @__olang_scope_close(ptr %s39)
  call void @__olang_scope_close(ptr %s0)
  %t427 = load i32, ptr %l242
  store i32 %t427, ptr %rv
  br label %ret
bb241:
  br label %bb242
bb242:
  %t428 = load i64, ptr %l2
  store i64 %t428, ptr %l243
  %t429 = load i64, ptr %l243
  %t430 = icmp eq i64 %t429, 7
  store i1 %t430, ptr %l244
  %t431 = load i1, ptr %l244
  br i1 %t431, label %bb243, label %bb244
bb243:
  %t432 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t432, ptr %l246
  %t433 = load i64, ptr %l1
  store i64 %t433, ptr %l247
  %t434 = load { i64, ptr }, ptr %l246
  %t435 = load i64, ptr %l247
  %t436 = call i1 @compiler_2ftoken_2espells(ptr %v0, ptr %s39, { i64, ptr } %t434, i64 %t435, { i64, ptr } { i64 7, ptr @.d23 })
  store i1 %t436, ptr %l248
  br label %bb245
bb244:
  store i1 false, ptr %l245
  br label %bb246
bb245:
  %t437 = load i1, ptr %l248
  store i1 %t437, ptr %l245
  br label %bb246
bb246:
  %t438 = load i1, ptr %l245
  br i1 %t438, label %bb247, label %bb248
bb247:
  store %olang.scope zeroinitializer, ptr %s42
  store i32 32, ptr %l249
  call void @__olang_scope_close(ptr %s42)
  call void @__olang_scope_close(ptr %s39)
  call void @__olang_scope_close(ptr %s0)
  %t439 = load i32, ptr %l249
  store i32 %t439, ptr %rv
  br label %ret
bb248:
  br label %bb249
bb249:
  %t440 = load i64, ptr %l2
  store i64 %t440, ptr %l250
  %t441 = load i64, ptr %l250
  %t442 = icmp eq i64 %t441, 8
  store i1 %t442, ptr %l251
  %t443 = load i1, ptr %l251
  br i1 %t443, label %bb250, label %bb251
bb250:
  %t444 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t444, ptr %l253
  %t445 = load i64, ptr %l1
  store i64 %t445, ptr %l254
  %t446 = load { i64, ptr }, ptr %l253
  %t447 = load i64, ptr %l254
  %t448 = call i1 @compiler_2ftoken_2espells(ptr %v0, ptr %s39, { i64, ptr } %t446, i64 %t447, { i64, ptr } { i64 8, ptr @.d24 })
  store i1 %t448, ptr %l255
  br label %bb252
bb251:
  store i1 false, ptr %l252
  br label %bb253
bb252:
  %t449 = load i1, ptr %l255
  store i1 %t449, ptr %l252
  br label %bb253
bb253:
  %t450 = load i1, ptr %l252
  br i1 %t450, label %bb254, label %bb255
bb254:
  store %olang.scope zeroinitializer, ptr %s43
  store i32 22, ptr %l256
  call void @__olang_scope_close(ptr %s43)
  call void @__olang_scope_close(ptr %s39)
  call void @__olang_scope_close(ptr %s0)
  %t451 = load i32, ptr %l256
  store i32 %t451, ptr %rv
  br label %ret
bb255:
  br label %bb256
bb256:
  call void @__olang_scope_close(ptr %s39)
  br label %bb370
bb257:
  %t452 = load i8, ptr %l3
  store i8 %t452, ptr %l257
  %t453 = load i8, ptr %l257
  %t454 = icmp eq i8 %t453, 111
  store i1 %t454, ptr %l258
  %t455 = load i1, ptr %l258
  br i1 %t455, label %bb258, label %bb259
bb258:
  br label %bb260
bb259:
  br label %bb274
bb260:
  store %olang.scope zeroinitializer, ptr %s44
  %t456 = load i64, ptr %l2
  store i64 %t456, ptr %l259
  %t457 = load i64, ptr %l259
  %t458 = icmp eq i64 %t457, 2
  store i1 %t458, ptr %l260
  %t459 = load i1, ptr %l260
  br i1 %t459, label %bb261, label %bb262
bb261:
  %t460 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t460, ptr %l262
  %t461 = load i64, ptr %l1
  store i64 %t461, ptr %l263
  %t462 = load i64, ptr %l263
  %t463 = add i64 %t462, 1
  store i64 %t463, ptr %l264
  %t464 = load i64, ptr %l264
  %t465 = getelementptr { i64, ptr }, ptr %l262, i32 0, i32 1
  %t466 = load ptr, ptr %t465
  %t467 = getelementptr i8, ptr %t466, i64 %t464
  %t468 = load i8, ptr %t467
  store i8 %t468, ptr %l265
  %t469 = load i8, ptr %l265
  %t470 = icmp eq i8 %t469, 114
  store i1 %t470, ptr %l266
  %t471 = load i1, ptr %l266
  store i1 %t471, ptr %l261
  br label %bb263
bb262:
  store i1 false, ptr %l261
  br label %bb263
bb263:
  %t472 = load i1, ptr %l261
  br i1 %t472, label %bb264, label %bb265
bb264:
  store %olang.scope zeroinitializer, ptr %s45
  store i32 48, ptr %l267
  call void @__olang_scope_close(ptr %s45)
  call void @__olang_scope_close(ptr %s44)
  call void @__olang_scope_close(ptr %s0)
  %t473 = load i32, ptr %l267
  store i32 %t473, ptr %rv
  br label %ret
bb265:
  br label %bb266
bb266:
  %t474 = load i64, ptr %l2
  store i64 %t474, ptr %l268
  %t475 = load i64, ptr %l268
  %t476 = icmp eq i64 %t475, 3
  store i1 %t476, ptr %l269
  %t477 = load i1, ptr %l269
  br i1 %t477, label %bb267, label %bb268
bb267:
  %t478 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t478, ptr %l271
  %t479 = load i64, ptr %l1
  store i64 %t479, ptr %l272
  %t480 = load { i64, ptr }, ptr %l271
  %t481 = load i64, ptr %l272
  %t482 = call i1 @compiler_2ftoken_2espells(ptr %v0, ptr %s44, { i64, ptr } %t480, i64 %t481, { i64, ptr } { i64 3, ptr @.d25 })
  store i1 %t482, ptr %l273
  br label %bb269
bb268:
  store i1 false, ptr %l270
  br label %bb270
bb269:
  %t483 = load i1, ptr %l273
  store i1 %t483, ptr %l270
  br label %bb270
bb270:
  %t484 = load i1, ptr %l270
  br i1 %t484, label %bb271, label %bb272
bb271:
  store %olang.scope zeroinitializer, ptr %s46
  store i32 40, ptr %l274
  call void @__olang_scope_close(ptr %s46)
  call void @__olang_scope_close(ptr %s44)
  call void @__olang_scope_close(ptr %s0)
  %t485 = load i32, ptr %l274
  store i32 %t485, ptr %rv
  br label %ret
bb272:
  br label %bb273
bb273:
  call void @__olang_scope_close(ptr %s44)
  br label %bb370
bb274:
  %t486 = load i8, ptr %l3
  store i8 %t486, ptr %l275
  %t487 = load i8, ptr %l275
  %t488 = icmp eq i8 %t487, 114
  store i1 %t488, ptr %l276
  %t489 = load i1, ptr %l276
  br i1 %t489, label %bb275, label %bb276
bb275:
  br label %bb277
bb276:
  br label %bb292
bb277:
  store %olang.scope zeroinitializer, ptr %s47
  %t490 = load i64, ptr %l2
  store i64 %t490, ptr %l277
  %t491 = load i64, ptr %l277
  %t492 = icmp eq i64 %t491, 5
  store i1 %t492, ptr %l278
  %t493 = load i1, ptr %l278
  br i1 %t493, label %bb278, label %bb279
bb278:
  %t494 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t494, ptr %l280
  %t495 = load i64, ptr %l1
  store i64 %t495, ptr %l281
  %t496 = load { i64, ptr }, ptr %l280
  %t497 = load i64, ptr %l281
  %t498 = call i1 @compiler_2ftoken_2espells(ptr %v0, ptr %s47, { i64, ptr } %t496, i64 %t497, { i64, ptr } { i64 5, ptr @.d26 })
  store i1 %t498, ptr %l282
  br label %bb280
bb279:
  store i1 false, ptr %l279
  br label %bb281
bb280:
  %t499 = load i1, ptr %l282
  store i1 %t499, ptr %l279
  br label %bb281
bb281:
  %t500 = load i1, ptr %l279
  br i1 %t500, label %bb282, label %bb283
bb282:
  store %olang.scope zeroinitializer, ptr %s48
  store i32 29, ptr %l283
  call void @__olang_scope_close(ptr %s48)
  call void @__olang_scope_close(ptr %s47)
  call void @__olang_scope_close(ptr %s0)
  %t501 = load i32, ptr %l283
  store i32 %t501, ptr %rv
  br label %ret
bb283:
  br label %bb284
bb284:
  %t502 = load i64, ptr %l2
  store i64 %t502, ptr %l284
  %t503 = load i64, ptr %l284
  %t504 = icmp eq i64 %t503, 6
  store i1 %t504, ptr %l285
  %t505 = load i1, ptr %l285
  br i1 %t505, label %bb285, label %bb286
bb285:
  %t506 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t506, ptr %l287
  %t507 = load i64, ptr %l1
  store i64 %t507, ptr %l288
  %t508 = load { i64, ptr }, ptr %l287
  %t509 = load i64, ptr %l288
  %t510 = call i1 @compiler_2ftoken_2espells(ptr %v0, ptr %s47, { i64, ptr } %t508, i64 %t509, { i64, ptr } { i64 6, ptr @.d27 })
  store i1 %t510, ptr %l289
  br label %bb287
bb286:
  store i1 false, ptr %l286
  br label %bb288
bb287:
  %t511 = load i1, ptr %l289
  store i1 %t511, ptr %l286
  br label %bb288
bb288:
  %t512 = load i1, ptr %l286
  br i1 %t512, label %bb289, label %bb290
bb289:
  store %olang.scope zeroinitializer, ptr %s49
  store i32 14, ptr %l290
  call void @__olang_scope_close(ptr %s49)
  call void @__olang_scope_close(ptr %s47)
  call void @__olang_scope_close(ptr %s0)
  %t513 = load i32, ptr %l290
  store i32 %t513, ptr %rv
  br label %ret
bb290:
  br label %bb291
bb291:
  call void @__olang_scope_close(ptr %s47)
  br label %bb370
bb292:
  %t514 = load i8, ptr %l3
  store i8 %t514, ptr %l291
  %t515 = load i8, ptr %l291
  %t516 = icmp eq i8 %t515, 115
  store i1 %t516, ptr %l292
  %t517 = load i1, ptr %l292
  br i1 %t517, label %bb293, label %bb294
bb293:
  br label %bb295
bb294:
  br label %bb310
bb295:
  store %olang.scope zeroinitializer, ptr %s50
  %t518 = load i64, ptr %l2
  store i64 %t518, ptr %l293
  %t519 = load i64, ptr %l293
  %t520 = icmp eq i64 %t519, 5
  store i1 %t520, ptr %l294
  %t521 = load i1, ptr %l294
  br i1 %t521, label %bb296, label %bb297
bb296:
  %t522 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t522, ptr %l296
  %t523 = load i64, ptr %l1
  store i64 %t523, ptr %l297
  %t524 = load { i64, ptr }, ptr %l296
  %t525 = load i64, ptr %l297
  %t526 = call i1 @compiler_2ftoken_2espells(ptr %v0, ptr %s50, { i64, ptr } %t524, i64 %t525, { i64, ptr } { i64 5, ptr @.d28 })
  store i1 %t526, ptr %l298
  br label %bb298
bb297:
  store i1 false, ptr %l295
  br label %bb299
bb298:
  %t527 = load i1, ptr %l298
  store i1 %t527, ptr %l295
  br label %bb299
bb299:
  %t528 = load i1, ptr %l295
  br i1 %t528, label %bb300, label %bb301
bb300:
  store %olang.scope zeroinitializer, ptr %s51
  store i32 16, ptr %l299
  call void @__olang_scope_close(ptr %s51)
  call void @__olang_scope_close(ptr %s50)
  call void @__olang_scope_close(ptr %s0)
  %t529 = load i32, ptr %l299
  store i32 %t529, ptr %rv
  br label %ret
bb301:
  br label %bb302
bb302:
  %t530 = load i64, ptr %l2
  store i64 %t530, ptr %l300
  %t531 = load i64, ptr %l300
  %t532 = icmp eq i64 %t531, 6
  store i1 %t532, ptr %l301
  %t533 = load i1, ptr %l301
  br i1 %t533, label %bb303, label %bb304
bb303:
  %t534 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t534, ptr %l303
  %t535 = load i64, ptr %l1
  store i64 %t535, ptr %l304
  %t536 = load { i64, ptr }, ptr %l303
  %t537 = load i64, ptr %l304
  %t538 = call i1 @compiler_2ftoken_2espells(ptr %v0, ptr %s50, { i64, ptr } %t536, i64 %t537, { i64, ptr } { i64 6, ptr @.d29 })
  store i1 %t538, ptr %l305
  br label %bb305
bb304:
  store i1 false, ptr %l302
  br label %bb306
bb305:
  %t539 = load i1, ptr %l305
  store i1 %t539, ptr %l302
  br label %bb306
bb306:
  %t540 = load i1, ptr %l302
  br i1 %t540, label %bb307, label %bb308
bb307:
  store %olang.scope zeroinitializer, ptr %s52
  store i32 34, ptr %l306
  call void @__olang_scope_close(ptr %s52)
  call void @__olang_scope_close(ptr %s50)
  call void @__olang_scope_close(ptr %s0)
  %t541 = load i32, ptr %l306
  store i32 %t541, ptr %rv
  br label %ret
bb308:
  br label %bb309
bb309:
  call void @__olang_scope_close(ptr %s50)
  br label %bb370
bb310:
  %t542 = load i8, ptr %l3
  store i8 %t542, ptr %l307
  %t543 = load i8, ptr %l307
  %t544 = icmp eq i8 %t543, 116
  store i1 %t544, ptr %l308
  %t545 = load i1, ptr %l308
  br i1 %t545, label %bb311, label %bb312
bb311:
  br label %bb313
bb312:
  br label %bb347
bb313:
  store %olang.scope zeroinitializer, ptr %s53
  %t546 = load i64, ptr %l2
  store i64 %t546, ptr %l309
  %t547 = load i64, ptr %l309
  %t548 = icmp eq i64 %t547, 3
  store i1 %t548, ptr %l310
  %t549 = load i1, ptr %l310
  br i1 %t549, label %bb314, label %bb315
bb314:
  %t550 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t550, ptr %l312
  %t551 = load i64, ptr %l1
  store i64 %t551, ptr %l313
  %t552 = load { i64, ptr }, ptr %l312
  %t553 = load i64, ptr %l313
  %t554 = call i1 @compiler_2ftoken_2espells(ptr %v0, ptr %s53, { i64, ptr } %t552, i64 %t553, { i64, ptr } { i64 3, ptr @.d30 })
  store i1 %t554, ptr %l314
  br label %bb316
bb315:
  store i1 false, ptr %l311
  br label %bb317
bb316:
  %t555 = load i1, ptr %l314
  store i1 %t555, ptr %l311
  br label %bb317
bb317:
  %t556 = load i1, ptr %l311
  br i1 %t556, label %bb318, label %bb319
bb318:
  store %olang.scope zeroinitializer, ptr %s54
  store i32 11, ptr %l315
  call void @__olang_scope_close(ptr %s54)
  call void @__olang_scope_close(ptr %s53)
  call void @__olang_scope_close(ptr %s0)
  %t557 = load i32, ptr %l315
  store i32 %t557, ptr %rv
  br label %ret
bb319:
  br label %bb320
bb320:
  %t558 = load i64, ptr %l2
  store i64 %t558, ptr %l316
  %t559 = load i64, ptr %l316
  %t560 = icmp eq i64 %t559, 4
  store i1 %t560, ptr %l317
  %t561 = load i1, ptr %l317
  br i1 %t561, label %bb321, label %bb322
bb321:
  store %olang.scope zeroinitializer, ptr %s55
  %t562 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t562, ptr %l318
  %t563 = load i64, ptr %l1
  store i64 %t563, ptr %l319
  %t564 = load { i64, ptr }, ptr %l318
  %t565 = load i64, ptr %l319
  %t566 = call i1 @compiler_2ftoken_2espells(ptr %v0, ptr %s55, { i64, ptr } %t564, i64 %t565, { i64, ptr } { i64 4, ptr @.d31 })
  store i1 %t566, ptr %l320
  br label %bb323
bb322:
  br label %bb339
bb323:
  %t567 = load i1, ptr %l320
  br i1 %t567, label %bb324, label %bb325
bb324:
  store %olang.scope zeroinitializer, ptr %s56
  store i32 33, ptr %l321
  call void @__olang_scope_close(ptr %s56)
  call void @__olang_scope_close(ptr %s55)
  call void @__olang_scope_close(ptr %s53)
  call void @__olang_scope_close(ptr %s0)
  %t568 = load i32, ptr %l321
  store i32 %t568, ptr %rv
  br label %ret
bb325:
  br label %bb326
bb326:
  %t569 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t569, ptr %l322
  %t570 = load i64, ptr %l1
  store i64 %t570, ptr %l323
  %t571 = load { i64, ptr }, ptr %l322
  %t572 = load i64, ptr %l323
  %t573 = call i1 @compiler_2ftoken_2espells(ptr %v0, ptr %s55, { i64, ptr } %t571, i64 %t572, { i64, ptr } { i64 4, ptr @.d32 })
  store i1 %t573, ptr %l324
  br label %bb327
bb327:
  %t574 = load i1, ptr %l324
  br i1 %t574, label %bb328, label %bb329
bb328:
  store %olang.scope zeroinitializer, ptr %s57
  store i32 41, ptr %l325
  call void @__olang_scope_close(ptr %s57)
  call void @__olang_scope_close(ptr %s55)
  call void @__olang_scope_close(ptr %s53)
  call void @__olang_scope_close(ptr %s0)
  %t575 = load i32, ptr %l325
  store i32 %t575, ptr %rv
  br label %ret
bb329:
  br label %bb330
bb330:
  %t576 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t576, ptr %l326
  %t577 = load i64, ptr %l1
  store i64 %t577, ptr %l327
  %t578 = load { i64, ptr }, ptr %l326
  %t579 = load i64, ptr %l327
  %t580 = call i1 @compiler_2ftoken_2espells(ptr %v0, ptr %s55, { i64, ptr } %t578, i64 %t579, { i64, ptr } { i64 4, ptr @.d33 })
  store i1 %t580, ptr %l328
  br label %bb331
bb331:
  %t581 = load i1, ptr %l328
  br i1 %t581, label %bb332, label %bb333
bb332:
  store %olang.scope zeroinitializer, ptr %s58
  store i32 43, ptr %l329
  call void @__olang_scope_close(ptr %s58)
  call void @__olang_scope_close(ptr %s55)
  call void @__olang_scope_close(ptr %s53)
  call void @__olang_scope_close(ptr %s0)
  %t582 = load i32, ptr %l329
  store i32 %t582, ptr %rv
  br label %ret
bb333:
  br label %bb334
bb334:
  %t583 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t583, ptr %l330
  %t584 = load i64, ptr %l1
  store i64 %t584, ptr %l331
  %t585 = load { i64, ptr }, ptr %l330
  %t586 = load i64, ptr %l331
  %t587 = call i1 @compiler_2ftoken_2espells(ptr %v0, ptr %s55, { i64, ptr } %t585, i64 %t586, { i64, ptr } { i64 4, ptr @.d34 })
  store i1 %t587, ptr %l332
  br label %bb335
bb335:
  %t588 = load i1, ptr %l332
  br i1 %t588, label %bb336, label %bb337
bb336:
  store %olang.scope zeroinitializer, ptr %s59
  store i32 6, ptr %l333
  call void @__olang_scope_close(ptr %s59)
  call void @__olang_scope_close(ptr %s55)
  call void @__olang_scope_close(ptr %s53)
  call void @__olang_scope_close(ptr %s0)
  %t589 = load i32, ptr %l333
  store i32 %t589, ptr %rv
  br label %ret
bb337:
  br label %bb338
bb338:
  call void @__olang_scope_close(ptr %s55)
  br label %bb339
bb339:
  %t590 = load i64, ptr %l2
  store i64 %t590, ptr %l334
  %t591 = load i64, ptr %l334
  %t592 = icmp eq i64 %t591, 5
  store i1 %t592, ptr %l335
  %t593 = load i1, ptr %l335
  br i1 %t593, label %bb340, label %bb341
bb340:
  %t594 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t594, ptr %l337
  %t595 = load i64, ptr %l1
  store i64 %t595, ptr %l338
  %t596 = load { i64, ptr }, ptr %l337
  %t597 = load i64, ptr %l338
  %t598 = call i1 @compiler_2ftoken_2espells(ptr %v0, ptr %s53, { i64, ptr } %t596, i64 %t597, { i64, ptr } { i64 5, ptr @.d35 })
  store i1 %t598, ptr %l339
  br label %bb342
bb341:
  store i1 false, ptr %l336
  br label %bb343
bb342:
  %t599 = load i1, ptr %l339
  store i1 %t599, ptr %l336
  br label %bb343
bb343:
  %t600 = load i1, ptr %l336
  br i1 %t600, label %bb344, label %bb345
bb344:
  store %olang.scope zeroinitializer, ptr %s60
  store i32 36, ptr %l340
  call void @__olang_scope_close(ptr %s60)
  call void @__olang_scope_close(ptr %s53)
  call void @__olang_scope_close(ptr %s0)
  %t601 = load i32, ptr %l340
  store i32 %t601, ptr %rv
  br label %ret
bb345:
  br label %bb346
bb346:
  call void @__olang_scope_close(ptr %s53)
  br label %bb370
bb347:
  %t602 = load i8, ptr %l3
  store i8 %t602, ptr %l341
  %t603 = load i8, ptr %l341
  %t604 = icmp eq i8 %t603, 117
  store i1 %t604, ptr %l342
  %t605 = load i1, ptr %l342
  br i1 %t605, label %bb348, label %bb349
bb348:
  br label %bb350
bb349:
  br label %bb358
bb350:
  store %olang.scope zeroinitializer, ptr %s61
  %t606 = load i64, ptr %l2
  store i64 %t606, ptr %l343
  %t607 = load i64, ptr %l343
  %t608 = icmp eq i64 %t607, 11
  store i1 %t608, ptr %l344
  %t609 = load i1, ptr %l344
  br i1 %t609, label %bb351, label %bb352
bb351:
  %t610 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t610, ptr %l346
  %t611 = load i64, ptr %l1
  store i64 %t611, ptr %l347
  %t612 = load { i64, ptr }, ptr %l346
  %t613 = load i64, ptr %l347
  %t614 = call i1 @compiler_2ftoken_2espells(ptr %v0, ptr %s61, { i64, ptr } %t612, i64 %t613, { i64, ptr } { i64 11, ptr @.d36 })
  store i1 %t614, ptr %l348
  br label %bb353
bb352:
  store i1 false, ptr %l345
  br label %bb354
bb353:
  %t615 = load i1, ptr %l348
  store i1 %t615, ptr %l345
  br label %bb354
bb354:
  %t616 = load i1, ptr %l345
  br i1 %t616, label %bb355, label %bb356
bb355:
  store %olang.scope zeroinitializer, ptr %s62
  store i32 20, ptr %l349
  call void @__olang_scope_close(ptr %s62)
  call void @__olang_scope_close(ptr %s61)
  call void @__olang_scope_close(ptr %s0)
  %t617 = load i32, ptr %l349
  store i32 %t617, ptr %rv
  br label %ret
bb356:
  br label %bb357
bb357:
  call void @__olang_scope_close(ptr %s61)
  br label %bb370
bb358:
  %t618 = load i8, ptr %l3
  store i8 %t618, ptr %l350
  %t619 = load i8, ptr %l350
  %t620 = icmp eq i8 %t619, 120
  store i1 %t620, ptr %l351
  %t621 = load i1, ptr %l351
  br i1 %t621, label %bb359, label %bb360
bb359:
  br label %bb361
bb360:
  br label %bb369
bb361:
  store %olang.scope zeroinitializer, ptr %s63
  %t622 = load i64, ptr %l2
  store i64 %t622, ptr %l352
  %t623 = load i64, ptr %l352
  %t624 = icmp eq i64 %t623, 3
  store i1 %t624, ptr %l353
  %t625 = load i1, ptr %l353
  br i1 %t625, label %bb362, label %bb363
bb362:
  %t626 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t626, ptr %l355
  %t627 = load i64, ptr %l1
  store i64 %t627, ptr %l356
  %t628 = load { i64, ptr }, ptr %l355
  %t629 = load i64, ptr %l356
  %t630 = call i1 @compiler_2ftoken_2espells(ptr %v0, ptr %s63, { i64, ptr } %t628, i64 %t629, { i64, ptr } { i64 3, ptr @.d37 })
  store i1 %t630, ptr %l357
  br label %bb364
bb363:
  store i1 false, ptr %l354
  br label %bb365
bb364:
  %t631 = load i1, ptr %l357
  store i1 %t631, ptr %l354
  br label %bb365
bb365:
  %t632 = load i1, ptr %l354
  br i1 %t632, label %bb366, label %bb367
bb366:
  store %olang.scope zeroinitializer, ptr %s64
  store i32 49, ptr %l358
  call void @__olang_scope_close(ptr %s64)
  call void @__olang_scope_close(ptr %s63)
  call void @__olang_scope_close(ptr %s0)
  %t633 = load i32, ptr %l358
  store i32 %t633, ptr %rv
  br label %ret
bb367:
  br label %bb368
bb368:
  call void @__olang_scope_close(ptr %s63)
  br label %bb370
bb369:
  store %olang.scope zeroinitializer, ptr %s65
  call void @__olang_scope_close(ptr %s65)
  br label %bb370
bb370:
  store i32 1, ptr %l359
  call void @__olang_scope_close(ptr %s0)
  %t634 = load i32, ptr %l359
  store i32 %t634, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2ftoken_2eLineBreak_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i8 1, ptr @G_2ecompiler_2ftoken_2eLineBreak
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftoken_2eLineStart_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i8 4, ptr @G_2ecompiler_2ftoken_2eLineStart
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftoken_2eSpace_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i8 2, ptr @G_2ecompiler_2ftoken_2eSpace
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %v0, i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca i1
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i32
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l19 = alloca i1
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i32
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i32
  %l27 = alloca i1
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i32
  %l31 = alloca i1
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca i32
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.builder
  %s10room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l0
  store i32 %t1, ptr %l2
  %t2 = load i32, ptr %l2
  %t3 = trunc i64 0 to i32
  %t4 = icmp eq i32 %t2, %t3
  store i1 %t4, ptr %l3
  %t5 = load i1, ptr %l3
  br i1 %t5, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  store { i64, ptr } { i64 11, ptr @.d38 }, ptr %l4
  %t6 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t6, ptr %l5
  %t7 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t7, ptr %l1
  call void @__olang_scope_close(ptr %s1)
  br label %bb34
bb4:
  %t8 = load i32, ptr %l0
  store i32 %t8, ptr %l6
  %t9 = load i32, ptr %l6
  %t10 = trunc i64 1 to i32
  %t11 = icmp eq i32 %t9, %t10
  store i1 %t11, ptr %l7
  %t12 = load i1, ptr %l7
  br i1 %t12, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  store { i64, ptr } { i64 6, ptr @.d39 }, ptr %l8
  %t13 = load { i64, ptr }, ptr %l8
  store { i64, ptr } %t13, ptr %l9
  %t14 = load { i64, ptr }, ptr %l9
  store { i64, ptr } %t14, ptr %l1
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb8:
  %t15 = load i32, ptr %l0
  store i32 %t15, ptr %l10
  %t16 = load i32, ptr %l10
  %t17 = trunc i64 2 to i32
  %t18 = icmp eq i32 %t16, %t17
  store i1 %t18, ptr %l11
  %t19 = load i1, ptr %l11
  br i1 %t19, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  store { i64, ptr } { i64 18, ptr @.d40 }, ptr %l12
  %t20 = load { i64, ptr }, ptr %l12
  store { i64, ptr } %t20, ptr %l13
  %t21 = load { i64, ptr }, ptr %l13
  store { i64, ptr } %t21, ptr %l1
  call void @__olang_scope_close(ptr %s3)
  br label %bb34
bb12:
  %t22 = load i32, ptr %l0
  store i32 %t22, ptr %l14
  %t23 = load i32, ptr %l14
  %t24 = trunc i64 3 to i32
  %t25 = icmp eq i32 %t23, %t24
  store i1 %t25, ptr %l15
  %t26 = load i1, ptr %l15
  br i1 %t26, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  store { i64, ptr } { i64 15, ptr @.d41 }, ptr %l16
  %t27 = load { i64, ptr }, ptr %l16
  store { i64, ptr } %t27, ptr %l17
  %t28 = load { i64, ptr }, ptr %l17
  store { i64, ptr } %t28, ptr %l1
  call void @__olang_scope_close(ptr %s4)
  br label %bb34
bb16:
  %t29 = load i32, ptr %l0
  store i32 %t29, ptr %l18
  %t30 = load i32, ptr %l18
  %t31 = trunc i64 4 to i32
  %t32 = icmp eq i32 %t30, %t31
  store i1 %t32, ptr %l19
  %t33 = load i1, ptr %l19
  br i1 %t33, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s5
  store { i64, ptr } { i64 19, ptr @.d42 }, ptr %l20
  %t34 = load { i64, ptr }, ptr %l20
  store { i64, ptr } %t34, ptr %l21
  %t35 = load { i64, ptr }, ptr %l21
  store { i64, ptr } %t35, ptr %l1
  call void @__olang_scope_close(ptr %s5)
  br label %bb34
bb20:
  %t36 = load i32, ptr %l0
  store i32 %t36, ptr %l22
  %t37 = load i32, ptr %l22
  %t38 = trunc i64 5 to i32
  %t39 = icmp eq i32 %t37, %t38
  store i1 %t39, ptr %l23
  %t40 = load i1, ptr %l23
  br i1 %t40, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s6
  store { i64, ptr } { i64 16, ptr @.d43 }, ptr %l24
  %t41 = load { i64, ptr }, ptr %l24
  store { i64, ptr } %t41, ptr %l25
  %t42 = load { i64, ptr }, ptr %l25
  store { i64, ptr } %t42, ptr %l1
  call void @__olang_scope_close(ptr %s6)
  br label %bb34
bb24:
  %t43 = load i32, ptr %l0
  store i32 %t43, ptr %l26
  %t44 = load i32, ptr %l26
  %t45 = trunc i64 6 to i32
  %t46 = icmp eq i32 %t44, %t45
  store i1 %t46, ptr %l27
  %t47 = load i1, ptr %l27
  br i1 %t47, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s7
  store { i64, ptr } { i64 14, ptr @.d44 }, ptr %l28
  %t48 = load { i64, ptr }, ptr %l28
  store { i64, ptr } %t48, ptr %l29
  %t49 = load { i64, ptr }, ptr %l29
  store { i64, ptr } %t49, ptr %l1
  call void @__olang_scope_close(ptr %s7)
  br label %bb34
bb28:
  %t50 = load i32, ptr %l0
  store i32 %t50, ptr %l30
  %t51 = load i32, ptr %l30
  %t52 = trunc i64 8 to i32
  %t53 = icmp eq i32 %t51, %t52
  store i1 %t53, ptr %l31
  %t54 = load i1, ptr %l31
  br i1 %t54, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s8
  store { i64, ptr } { i64 11, ptr @.d45 }, ptr %l32
  %t55 = load { i64, ptr }, ptr %l32
  store { i64, ptr } %t55, ptr %l33
  %t56 = load { i64, ptr }, ptr %l33
  store { i64, ptr } %t56, ptr %l1
  call void @__olang_scope_close(ptr %s8)
  br label %bb34
bb32:
  store %olang.scope zeroinitializer, ptr %s9
  %t57 = load i32, ptr %l0
  store i32 %t57, ptr %l34
  %t58 = load i32, ptr %l34
  %t59 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s9, i32 %t58)
  store { i64, ptr } %t59, ptr %l35
  br label %bb33
bb33:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s10
  store ptr %s10room, ptr %s10
  %t60 = extractvalue { i64, ptr } { i64 1, ptr @.d46 }, 1
  %t61 = extractvalue { i64, ptr } { i64 1, ptr @.d46 }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t60, i64 %t61)
  %t62 = load { i64, ptr }, ptr %l35
  %t63 = extractvalue { i64, ptr } %t62, 1
  %t64 = extractvalue { i64, ptr } %t62, 0
  call void @__olang_sb_put(ptr %s10, ptr %t63, i64 %t64)
  %t65 = extractvalue { i64, ptr } { i64 1, ptr @.d47 }, 1
  %t66 = extractvalue { i64, ptr } { i64 1, ptr @.d47 }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t65, i64 %t66)
  %t67 = load ptr, ptr %s10
  %t68 = getelementptr %olang.builder, ptr %s10, i32 0, i32 1
  %t69 = load i64, ptr %t68
  %t70 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t69)
  call void @llvm.memcpy.p0.p0.i64(ptr %t70, ptr %t67, i64 %t69, i1 false)
  %t71 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  store { i64, ptr } %t72, ptr %l36
  call void @__olang_sb_done(ptr %s10)
  %t73 = load { i64, ptr }, ptr %l36
  store { i64, ptr } %t73, ptr %l1
  call void @__olang_scope_close(ptr %s9)
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s0)
  %t74 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t74, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eEndsStatement(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i1
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca i32
  %l5 = alloca i1
  %l6 = alloca i32
  %l7 = alloca i1
  %l8 = alloca i32
  %l9 = alloca i1
  %l10 = alloca i32
  %l11 = alloca i1
  %l12 = alloca i32
  %l13 = alloca i1
  %l14 = alloca i32
  %l15 = alloca i1
  %l16 = alloca i32
  %l17 = alloca i1
  %l18 = alloca i32
  %l19 = alloca i1
  %l20 = alloca i32
  %l21 = alloca i1
  %l22 = alloca i32
  %l23 = alloca i1
  %l24 = alloca i32
  %l25 = alloca i1
  %l26 = alloca i32
  %l27 = alloca i1
  %l28 = alloca i32
  %l29 = alloca i1
  %l30 = alloca i32
  %l31 = alloca i1
  %l32 = alloca i32
  %l33 = alloca i1
  %l34 = alloca i32
  %l35 = alloca i1
  %l36 = alloca i32
  %l37 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l0
  store i32 %t1, ptr %l2
  %t2 = load i32, ptr %l2
  %t3 = trunc i64 1 to i32
  %t4 = icmp eq i32 %t2, %t3
  store i1 %t4, ptr %l3
  %t5 = load i1, ptr %l3
  br i1 %t5, label %bb1, label %bb2
bb1:
  br label %bb15
bb2:
  %t6 = load i32, ptr %l0
  store i32 %t6, ptr %l4
  %t7 = load i32, ptr %l4
  %t8 = trunc i64 2 to i32
  %t9 = icmp eq i32 %t7, %t8
  store i1 %t9, ptr %l5
  %t10 = load i1, ptr %l5
  br i1 %t10, label %bb3, label %bb4
bb3:
  br label %bb15
bb4:
  %t11 = load i32, ptr %l0
  store i32 %t11, ptr %l6
  %t12 = load i32, ptr %l6
  %t13 = trunc i64 3 to i32
  %t14 = icmp eq i32 %t12, %t13
  store i1 %t14, ptr %l7
  %t15 = load i1, ptr %l7
  br i1 %t15, label %bb5, label %bb6
bb5:
  br label %bb15
bb6:
  %t16 = load i32, ptr %l0
  store i32 %t16, ptr %l8
  %t17 = load i32, ptr %l8
  %t18 = trunc i64 4 to i32
  %t19 = icmp eq i32 %t17, %t18
  store i1 %t19, ptr %l9
  %t20 = load i1, ptr %l9
  br i1 %t20, label %bb7, label %bb8
bb7:
  br label %bb15
bb8:
  %t21 = load i32, ptr %l0
  store i32 %t21, ptr %l10
  %t22 = load i32, ptr %l10
  %t23 = trunc i64 5 to i32
  %t24 = icmp eq i32 %t22, %t23
  store i1 %t24, ptr %l11
  %t25 = load i1, ptr %l11
  br i1 %t25, label %bb9, label %bb10
bb9:
  br label %bb15
bb10:
  %t26 = load i32, ptr %l0
  store i32 %t26, ptr %l12
  %t27 = load i32, ptr %l12
  %t28 = trunc i64 6 to i32
  %t29 = icmp eq i32 %t27, %t28
  store i1 %t29, ptr %l13
  %t30 = load i1, ptr %l13
  br i1 %t30, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  %t31 = load i32, ptr %l0
  store i32 %t31, ptr %l14
  %t32 = load i32, ptr %l14
  %t33 = trunc i64 7 to i32
  %t34 = icmp eq i32 %t32, %t33
  store i1 %t34, ptr %l15
  %t35 = load i1, ptr %l15
  br i1 %t35, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s1
  store i1 true, ptr %l1
  call void @__olang_scope_close(ptr %s1)
  br label %bb43
bb16:
  %t36 = load i32, ptr %l0
  store i32 %t36, ptr %l16
  %t37 = load i32, ptr %l16
  %t38 = trunc i64 73 to i32
  %t39 = icmp eq i32 %t37, %t38
  store i1 %t39, ptr %l17
  %t40 = load i1, ptr %l17
  br i1 %t40, label %bb17, label %bb18
bb17:
  br label %bb27
bb18:
  %t41 = load i32, ptr %l0
  store i32 %t41, ptr %l18
  %t42 = load i32, ptr %l18
  %t43 = trunc i64 74 to i32
  %t44 = icmp eq i32 %t42, %t43
  store i1 %t44, ptr %l19
  %t45 = load i1, ptr %l19
  br i1 %t45, label %bb19, label %bb20
bb19:
  br label %bb27
bb20:
  %t46 = load i32, ptr %l0
  store i32 %t46, ptr %l20
  %t47 = load i32, ptr %l20
  %t48 = trunc i64 78 to i32
  %t49 = icmp eq i32 %t47, %t48
  store i1 %t49, ptr %l21
  %t50 = load i1, ptr %l21
  br i1 %t50, label %bb21, label %bb22
bb21:
  br label %bb27
bb22:
  %t51 = load i32, ptr %l0
  store i32 %t51, ptr %l22
  %t52 = load i32, ptr %l22
  %t53 = trunc i64 91 to i32
  %t54 = icmp eq i32 %t52, %t53
  store i1 %t54, ptr %l23
  %t55 = load i1, ptr %l23
  br i1 %t55, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  %t56 = load i32, ptr %l0
  store i32 %t56, ptr %l24
  %t57 = load i32, ptr %l24
  %t58 = trunc i64 93 to i32
  %t59 = icmp eq i32 %t57, %t58
  store i1 %t59, ptr %l25
  %t60 = load i1, ptr %l25
  br i1 %t60, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s2
  store i1 true, ptr %l1
  call void @__olang_scope_close(ptr %s2)
  br label %bb43
bb28:
  %t61 = load i32, ptr %l0
  store i32 %t61, ptr %l26
  %t62 = load i32, ptr %l26
  %t63 = trunc i64 14 to i32
  %t64 = icmp eq i32 %t62, %t63
  store i1 %t64, ptr %l27
  %t65 = load i1, ptr %l27
  br i1 %t65, label %bb29, label %bb30
bb29:
  br label %bb41
bb30:
  %t66 = load i32, ptr %l0
  store i32 %t66, ptr %l28
  %t67 = load i32, ptr %l28
  %t68 = trunc i64 38 to i32
  %t69 = icmp eq i32 %t67, %t68
  store i1 %t69, ptr %l29
  %t70 = load i1, ptr %l29
  br i1 %t70, label %bb31, label %bb32
bb31:
  br label %bb41
bb32:
  %t71 = load i32, ptr %l0
  store i32 %t71, ptr %l30
  %t72 = load i32, ptr %l30
  %t73 = trunc i64 22 to i32
  %t74 = icmp eq i32 %t72, %t73
  store i1 %t74, ptr %l31
  %t75 = load i1, ptr %l31
  br i1 %t75, label %bb33, label %bb34
bb33:
  br label %bb41
bb34:
  %t76 = load i32, ptr %l0
  store i32 %t76, ptr %l32
  %t77 = load i32, ptr %l32
  %t78 = trunc i64 18 to i32
  %t79 = icmp eq i32 %t77, %t78
  store i1 %t79, ptr %l33
  %t80 = load i1, ptr %l33
  br i1 %t80, label %bb35, label %bb36
bb35:
  br label %bb41
bb36:
  %t81 = load i32, ptr %l0
  store i32 %t81, ptr %l34
  %t82 = load i32, ptr %l34
  %t83 = trunc i64 19 to i32
  %t84 = icmp eq i32 %t82, %t83
  store i1 %t84, ptr %l35
  %t85 = load i1, ptr %l35
  br i1 %t85, label %bb37, label %bb38
bb37:
  br label %bb41
bb38:
  %t86 = load i32, ptr %l0
  store i32 %t86, ptr %l36
  %t87 = load i32, ptr %l36
  %t88 = trunc i64 20 to i32
  %t89 = icmp eq i32 %t87, %t88
  store i1 %t89, ptr %l37
  %t90 = load i1, ptr %l37
  br i1 %t90, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s3
  store i1 true, ptr %l1
  call void @__olang_scope_close(ptr %s3)
  br label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s4
  store i1 false, ptr %l1
  call void @__olang_scope_close(ptr %s4)
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s0)
  %t91 = load i1, ptr %l1
  store i1 %t91, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v0, i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca i32
  %l5 = alloca i1
  %l6 = alloca i32
  %l7 = alloca i1
  %l8 = alloca i32
  %l9 = alloca i1
  %l10 = alloca i32
  %l11 = alloca i1
  %l12 = alloca i32
  %l13 = alloca i1
  %l14 = alloca i32
  %l15 = alloca i1
  %l16 = alloca i32
  %l17 = alloca i1
  %l18 = alloca i32
  %l19 = alloca i1
  %l20 = alloca i32
  %l21 = alloca i1
  %l22 = alloca i32
  %l23 = alloca i1
  %l24 = alloca i32
  %l25 = alloca i1
  %l26 = alloca i32
  %l27 = alloca i1
  %l28 = alloca i32
  %l29 = alloca i1
  %l30 = alloca i32
  %l31 = alloca i1
  %l32 = alloca i32
  %l33 = alloca i1
  %l34 = alloca i32
  %l35 = alloca i1
  %l36 = alloca i32
  %l37 = alloca i1
  %l38 = alloca i32
  %l39 = alloca i1
  %l40 = alloca i32
  %l41 = alloca i1
  %l42 = alloca i32
  %l43 = alloca i1
  %l44 = alloca i32
  %l45 = alloca i1
  %l46 = alloca i32
  %l47 = alloca i1
  %l48 = alloca i32
  %l49 = alloca i1
  %l50 = alloca i32
  %l51 = alloca i1
  %l52 = alloca i32
  %l53 = alloca i1
  %l54 = alloca i32
  %l55 = alloca i1
  %l56 = alloca i32
  %l57 = alloca i1
  %l58 = alloca i32
  %l59 = alloca i1
  %l60 = alloca i32
  %l61 = alloca i1
  %l62 = alloca i32
  %l63 = alloca i1
  %l64 = alloca i32
  %l65 = alloca i1
  %l66 = alloca i32
  %l67 = alloca i1
  %l68 = alloca i32
  %l69 = alloca i1
  %l70 = alloca i32
  %l71 = alloca i1
  %l72 = alloca i32
  %l73 = alloca i1
  %l74 = alloca i32
  %l75 = alloca i1
  %l76 = alloca i32
  %l77 = alloca i1
  %l78 = alloca i32
  %l79 = alloca i1
  %l80 = alloca i32
  %l81 = alloca i1
  %l82 = alloca i32
  %l83 = alloca i1
  %l84 = alloca i32
  %l85 = alloca i1
  %l86 = alloca i32
  %l87 = alloca i1
  %l88 = alloca i32
  %l89 = alloca i1
  %l90 = alloca i32
  %l91 = alloca i1
  %l92 = alloca i32
  %l93 = alloca i1
  %l94 = alloca i32
  %l95 = alloca i1
  %l96 = alloca i32
  %l97 = alloca i1
  %l98 = alloca i32
  %l99 = alloca i1
  %l100 = alloca i32
  %l101 = alloca i1
  %l102 = alloca i32
  %l103 = alloca i1
  %l104 = alloca i32
  %l105 = alloca i1
  %l106 = alloca i32
  %l107 = alloca i1
  %l108 = alloca i32
  %l109 = alloca i1
  %l110 = alloca i32
  %l111 = alloca i1
  %l112 = alloca i32
  %l113 = alloca i1
  %l114 = alloca i32
  %l115 = alloca i1
  %l116 = alloca i32
  %l117 = alloca i1
  %l118 = alloca i32
  %l119 = alloca i1
  %l120 = alloca i32
  %l121 = alloca i1
  %l122 = alloca i32
  %l123 = alloca i1
  %l124 = alloca i32
  %l125 = alloca i1
  %l126 = alloca i32
  %l127 = alloca i1
  %l128 = alloca i32
  %l129 = alloca i1
  %l130 = alloca i32
  %l131 = alloca i1
  %l132 = alloca i32
  %l133 = alloca i1
  %l134 = alloca i32
  %l135 = alloca i1
  %l136 = alloca i32
  %l137 = alloca i1
  %l138 = alloca i32
  %l139 = alloca i1
  %l140 = alloca i32
  %l141 = alloca i1
  %l142 = alloca i32
  %l143 = alloca i1
  %l144 = alloca i32
  %l145 = alloca i1
  %l146 = alloca i32
  %l147 = alloca i1
  %l148 = alloca i32
  %l149 = alloca i1
  %l150 = alloca i32
  %l151 = alloca i1
  %l152 = alloca i32
  %l153 = alloca i1
  %l154 = alloca i32
  %l155 = alloca i1
  %l156 = alloca i32
  %l157 = alloca i1
  %l158 = alloca i32
  %l159 = alloca i1
  %l160 = alloca i32
  %l161 = alloca i1
  %l162 = alloca i32
  %l163 = alloca i1
  %l164 = alloca i32
  %l165 = alloca i1
  %l166 = alloca i32
  %l167 = alloca i1
  %l168 = alloca i32
  %l169 = alloca i1
  %l170 = alloca i32
  %l171 = alloca i1
  %l172 = alloca i32
  %l173 = alloca i1
  %l174 = alloca i32
  %l175 = alloca i1
  %l176 = alloca i32
  %l177 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %s41 = alloca %olang.scope
  %s42 = alloca %olang.scope
  %s43 = alloca %olang.scope
  %s44 = alloca %olang.scope
  %s45 = alloca %olang.scope
  %s46 = alloca %olang.scope
  %s47 = alloca %olang.scope
  %s48 = alloca %olang.scope
  %s49 = alloca %olang.scope
  %s50 = alloca %olang.scope
  %s51 = alloca %olang.scope
  %s52 = alloca %olang.scope
  %s53 = alloca %olang.scope
  %s54 = alloca %olang.scope
  %s55 = alloca %olang.scope
  %s56 = alloca %olang.scope
  %s57 = alloca %olang.scope
  %s58 = alloca %olang.scope
  %s59 = alloca %olang.scope
  %s60 = alloca %olang.scope
  %s61 = alloca %olang.scope
  %s62 = alloca %olang.scope
  %s63 = alloca %olang.scope
  %s64 = alloca %olang.scope
  %s65 = alloca %olang.scope
  %s66 = alloca %olang.scope
  %s67 = alloca %olang.scope
  %s68 = alloca %olang.scope
  %s69 = alloca %olang.scope
  %s70 = alloca %olang.scope
  %s71 = alloca %olang.scope
  %s72 = alloca %olang.scope
  %s73 = alloca %olang.scope
  %s74 = alloca %olang.scope
  %s75 = alloca %olang.scope
  %s76 = alloca %olang.scope
  %s77 = alloca %olang.scope
  %s78 = alloca %olang.scope
  %s79 = alloca %olang.scope
  %s80 = alloca %olang.scope
  %s81 = alloca %olang.scope
  %s82 = alloca %olang.scope
  %s83 = alloca %olang.scope
  %s84 = alloca %olang.scope
  %s85 = alloca %olang.scope
  %s86 = alloca %olang.scope
  %s87 = alloca %olang.scope
  %s88 = alloca %olang.scope
  %s89 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l0
  store i32 %t1, ptr %l2
  %t2 = load i32, ptr %l2
  %t3 = trunc i64 9 to i32
  %t4 = icmp eq i32 %t2, %t3
  store i1 %t4, ptr %l3
  %t5 = load i1, ptr %l3
  br i1 %t5, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  store { i64, ptr } { i64 2, ptr @.d48 }, ptr %l1
  call void @__olang_scope_close(ptr %s1)
  br label %bb353
bb4:
  %t6 = load i32, ptr %l0
  store i32 %t6, ptr %l4
  %t7 = load i32, ptr %l4
  %t8 = trunc i64 10 to i32
  %t9 = icmp eq i32 %t7, %t8
  store i1 %t9, ptr %l5
  %t10 = load i1, ptr %l5
  br i1 %t10, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  store { i64, ptr } { i64 4, ptr @.d49 }, ptr %l1
  call void @__olang_scope_close(ptr %s2)
  br label %bb353
bb8:
  %t11 = load i32, ptr %l0
  store i32 %t11, ptr %l6
  %t12 = load i32, ptr %l6
  %t13 = trunc i64 11 to i32
  %t14 = icmp eq i32 %t12, %t13
  store i1 %t14, ptr %l7
  %t15 = load i1, ptr %l7
  br i1 %t15, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  store { i64, ptr } { i64 3, ptr @.d50 }, ptr %l1
  call void @__olang_scope_close(ptr %s3)
  br label %bb353
bb12:
  %t16 = load i32, ptr %l0
  store i32 %t16, ptr %l8
  %t17 = load i32, ptr %l8
  %t18 = trunc i64 12 to i32
  %t19 = icmp eq i32 %t17, %t18
  store i1 %t19, ptr %l9
  %t20 = load i1, ptr %l9
  br i1 %t20, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  store { i64, ptr } { i64 7, ptr @.d51 }, ptr %l1
  call void @__olang_scope_close(ptr %s4)
  br label %bb353
bb16:
  %t21 = load i32, ptr %l0
  store i32 %t21, ptr %l10
  %t22 = load i32, ptr %l10
  %t23 = trunc i64 13 to i32
  %t24 = icmp eq i32 %t22, %t23
  store i1 %t24, ptr %l11
  %t25 = load i1, ptr %l11
  br i1 %t25, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s5
  store { i64, ptr } { i64 5, ptr @.d52 }, ptr %l1
  call void @__olang_scope_close(ptr %s5)
  br label %bb353
bb20:
  %t26 = load i32, ptr %l0
  store i32 %t26, ptr %l12
  %t27 = load i32, ptr %l12
  %t28 = trunc i64 14 to i32
  %t29 = icmp eq i32 %t27, %t28
  store i1 %t29, ptr %l13
  %t30 = load i1, ptr %l13
  br i1 %t30, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s6
  store { i64, ptr } { i64 6, ptr @.d53 }, ptr %l1
  call void @__olang_scope_close(ptr %s6)
  br label %bb353
bb24:
  %t31 = load i32, ptr %l0
  store i32 %t31, ptr %l14
  %t32 = load i32, ptr %l14
  %t33 = trunc i64 15 to i32
  %t34 = icmp eq i32 %t32, %t33
  store i1 %t34, ptr %l15
  %t35 = load i1, ptr %l15
  br i1 %t35, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s7
  store { i64, ptr } { i64 4, ptr @.d54 }, ptr %l1
  call void @__olang_scope_close(ptr %s7)
  br label %bb353
bb28:
  %t36 = load i32, ptr %l0
  store i32 %t36, ptr %l16
  %t37 = load i32, ptr %l16
  %t38 = trunc i64 16 to i32
  %t39 = icmp eq i32 %t37, %t38
  store i1 %t39, ptr %l17
  %t40 = load i1, ptr %l17
  br i1 %t40, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s8
  store { i64, ptr } { i64 5, ptr @.d55 }, ptr %l1
  call void @__olang_scope_close(ptr %s8)
  br label %bb353
bb32:
  %t41 = load i32, ptr %l0
  store i32 %t41, ptr %l18
  %t42 = load i32, ptr %l18
  %t43 = trunc i64 17 to i32
  %t44 = icmp eq i32 %t42, %t43
  store i1 %t44, ptr %l19
  %t45 = load i1, ptr %l19
  br i1 %t45, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s9
  store { i64, ptr } { i64 5, ptr @.d56 }, ptr %l1
  call void @__olang_scope_close(ptr %s9)
  br label %bb353
bb36:
  %t46 = load i32, ptr %l0
  store i32 %t46, ptr %l20
  %t47 = load i32, ptr %l20
  %t48 = trunc i64 18 to i32
  %t49 = icmp eq i32 %t47, %t48
  store i1 %t49, ptr %l21
  %t50 = load i1, ptr %l21
  br i1 %t50, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  store %olang.scope zeroinitializer, ptr %s10
  store { i64, ptr } { i64 5, ptr @.d57 }, ptr %l1
  call void @__olang_scope_close(ptr %s10)
  br label %bb353
bb40:
  %t51 = load i32, ptr %l0
  store i32 %t51, ptr %l22
  %t52 = load i32, ptr %l22
  %t53 = trunc i64 19 to i32
  %t54 = icmp eq i32 %t52, %t53
  store i1 %t54, ptr %l23
  %t55 = load i1, ptr %l23
  br i1 %t55, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s11
  store { i64, ptr } { i64 8, ptr @.d58 }, ptr %l1
  call void @__olang_scope_close(ptr %s11)
  br label %bb353
bb44:
  %t56 = load i32, ptr %l0
  store i32 %t56, ptr %l24
  %t57 = load i32, ptr %l24
  %t58 = trunc i64 20 to i32
  %t59 = icmp eq i32 %t57, %t58
  store i1 %t59, ptr %l25
  %t60 = load i1, ptr %l25
  br i1 %t60, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  store %olang.scope zeroinitializer, ptr %s12
  store { i64, ptr } { i64 11, ptr @.d59 }, ptr %l1
  call void @__olang_scope_close(ptr %s12)
  br label %bb353
bb48:
  %t61 = load i32, ptr %l0
  store i32 %t61, ptr %l26
  %t62 = load i32, ptr %l26
  %t63 = trunc i64 21 to i32
  %t64 = icmp eq i32 %t62, %t63
  store i1 %t64, ptr %l27
  %t65 = load i1, ptr %l27
  br i1 %t65, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s13
  store { i64, ptr } { i64 7, ptr @.d60 }, ptr %l1
  call void @__olang_scope_close(ptr %s13)
  br label %bb353
bb52:
  %t66 = load i32, ptr %l0
  store i32 %t66, ptr %l28
  %t67 = load i32, ptr %l28
  %t68 = trunc i64 22 to i32
  %t69 = icmp eq i32 %t67, %t68
  store i1 %t69, ptr %l29
  %t70 = load i1, ptr %l29
  br i1 %t70, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s14
  store { i64, ptr } { i64 8, ptr @.d61 }, ptr %l1
  call void @__olang_scope_close(ptr %s14)
  br label %bb353
bb56:
  %t71 = load i32, ptr %l0
  store i32 %t71, ptr %l30
  %t72 = load i32, ptr %l30
  %t73 = trunc i64 23 to i32
  %t74 = icmp eq i32 %t72, %t73
  store i1 %t74, ptr %l31
  %t75 = load i1, ptr %l31
  br i1 %t75, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb60
bb59:
  store %olang.scope zeroinitializer, ptr %s15
  store { i64, ptr } { i64 6, ptr @.d62 }, ptr %l1
  call void @__olang_scope_close(ptr %s15)
  br label %bb353
bb60:
  %t76 = load i32, ptr %l0
  store i32 %t76, ptr %l32
  %t77 = load i32, ptr %l32
  %t78 = trunc i64 24 to i32
  %t79 = icmp eq i32 %t77, %t78
  store i1 %t79, ptr %l33
  %t80 = load i1, ptr %l33
  br i1 %t80, label %bb61, label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb64
bb63:
  store %olang.scope zeroinitializer, ptr %s16
  store { i64, ptr } { i64 3, ptr @.d63 }, ptr %l1
  call void @__olang_scope_close(ptr %s16)
  br label %bb353
bb64:
  %t81 = load i32, ptr %l0
  store i32 %t81, ptr %l34
  %t82 = load i32, ptr %l34
  %t83 = trunc i64 25 to i32
  %t84 = icmp eq i32 %t82, %t83
  store i1 %t84, ptr %l35
  %t85 = load i1, ptr %l35
  br i1 %t85, label %bb65, label %bb66
bb65:
  br label %bb67
bb66:
  br label %bb68
bb67:
  store %olang.scope zeroinitializer, ptr %s17
  store { i64, ptr } { i64 2, ptr @.d64 }, ptr %l1
  call void @__olang_scope_close(ptr %s17)
  br label %bb353
bb68:
  %t86 = load i32, ptr %l0
  store i32 %t86, ptr %l36
  %t87 = load i32, ptr %l36
  %t88 = trunc i64 26 to i32
  %t89 = icmp eq i32 %t87, %t88
  store i1 %t89, ptr %l37
  %t90 = load i1, ptr %l37
  br i1 %t90, label %bb69, label %bb70
bb69:
  br label %bb71
bb70:
  br label %bb72
bb71:
  store %olang.scope zeroinitializer, ptr %s18
  store { i64, ptr } { i64 2, ptr @.d65 }, ptr %l1
  call void @__olang_scope_close(ptr %s18)
  br label %bb353
bb72:
  %t91 = load i32, ptr %l0
  store i32 %t91, ptr %l38
  %t92 = load i32, ptr %l38
  %t93 = trunc i64 27 to i32
  %t94 = icmp eq i32 %t92, %t93
  store i1 %t94, ptr %l39
  %t95 = load i1, ptr %l39
  br i1 %t95, label %bb73, label %bb74
bb73:
  br label %bb75
bb74:
  br label %bb76
bb75:
  store %olang.scope zeroinitializer, ptr %s19
  store { i64, ptr } { i64 2, ptr @.d66 }, ptr %l1
  call void @__olang_scope_close(ptr %s19)
  br label %bb353
bb76:
  %t96 = load i32, ptr %l0
  store i32 %t96, ptr %l40
  %t97 = load i32, ptr %l40
  %t98 = trunc i64 28 to i32
  %t99 = icmp eq i32 %t97, %t98
  store i1 %t99, ptr %l41
  %t100 = load i1, ptr %l41
  br i1 %t100, label %bb77, label %bb78
bb77:
  br label %bb79
bb78:
  br label %bb80
bb79:
  store %olang.scope zeroinitializer, ptr %s20
  store { i64, ptr } { i64 2, ptr @.d67 }, ptr %l1
  call void @__olang_scope_close(ptr %s20)
  br label %bb353
bb80:
  %t101 = load i32, ptr %l0
  store i32 %t101, ptr %l42
  %t102 = load i32, ptr %l42
  %t103 = trunc i64 29 to i32
  %t104 = icmp eq i32 %t102, %t103
  store i1 %t104, ptr %l43
  %t105 = load i1, ptr %l43
  br i1 %t105, label %bb81, label %bb82
bb81:
  br label %bb83
bb82:
  br label %bb84
bb83:
  store %olang.scope zeroinitializer, ptr %s21
  store { i64, ptr } { i64 5, ptr @.d68 }, ptr %l1
  call void @__olang_scope_close(ptr %s21)
  br label %bb353
bb84:
  %t106 = load i32, ptr %l0
  store i32 %t106, ptr %l44
  %t107 = load i32, ptr %l44
  %t108 = trunc i64 30 to i32
  %t109 = icmp eq i32 %t107, %t108
  store i1 %t109, ptr %l45
  %t110 = load i1, ptr %l45
  br i1 %t110, label %bb85, label %bb86
bb85:
  br label %bb87
bb86:
  br label %bb88
bb87:
  store %olang.scope zeroinitializer, ptr %s22
  store { i64, ptr } { i64 5, ptr @.d69 }, ptr %l1
  call void @__olang_scope_close(ptr %s22)
  br label %bb353
bb88:
  %t111 = load i32, ptr %l0
  store i32 %t111, ptr %l46
  %t112 = load i32, ptr %l46
  %t113 = trunc i64 31 to i32
  %t114 = icmp eq i32 %t112, %t113
  store i1 %t114, ptr %l47
  %t115 = load i1, ptr %l47
  br i1 %t115, label %bb89, label %bb90
bb89:
  br label %bb91
bb90:
  br label %bb92
bb91:
  store %olang.scope zeroinitializer, ptr %s23
  store { i64, ptr } { i64 4, ptr @.d70 }, ptr %l1
  call void @__olang_scope_close(ptr %s23)
  br label %bb353
bb92:
  %t116 = load i32, ptr %l0
  store i32 %t116, ptr %l48
  %t117 = load i32, ptr %l48
  %t118 = trunc i64 32 to i32
  %t119 = icmp eq i32 %t117, %t118
  store i1 %t119, ptr %l49
  %t120 = load i1, ptr %l49
  br i1 %t120, label %bb93, label %bb94
bb93:
  br label %bb95
bb94:
  br label %bb96
bb95:
  store %olang.scope zeroinitializer, ptr %s24
  store { i64, ptr } { i64 7, ptr @.d71 }, ptr %l1
  call void @__olang_scope_close(ptr %s24)
  br label %bb353
bb96:
  %t121 = load i32, ptr %l0
  store i32 %t121, ptr %l50
  %t122 = load i32, ptr %l50
  %t123 = trunc i64 33 to i32
  %t124 = icmp eq i32 %t122, %t123
  store i1 %t124, ptr %l51
  %t125 = load i1, ptr %l51
  br i1 %t125, label %bb97, label %bb98
bb97:
  br label %bb99
bb98:
  br label %bb100
bb99:
  store %olang.scope zeroinitializer, ptr %s25
  store { i64, ptr } { i64 4, ptr @.d72 }, ptr %l1
  call void @__olang_scope_close(ptr %s25)
  br label %bb353
bb100:
  %t126 = load i32, ptr %l0
  store i32 %t126, ptr %l52
  %t127 = load i32, ptr %l52
  %t128 = trunc i64 34 to i32
  %t129 = icmp eq i32 %t127, %t128
  store i1 %t129, ptr %l53
  %t130 = load i1, ptr %l53
  br i1 %t130, label %bb101, label %bb102
bb101:
  br label %bb103
bb102:
  br label %bb104
bb103:
  store %olang.scope zeroinitializer, ptr %s26
  store { i64, ptr } { i64 6, ptr @.d73 }, ptr %l1
  call void @__olang_scope_close(ptr %s26)
  br label %bb353
bb104:
  %t131 = load i32, ptr %l0
  store i32 %t131, ptr %l54
  %t132 = load i32, ptr %l54
  %t133 = trunc i64 35 to i32
  %t134 = icmp eq i32 %t132, %t133
  store i1 %t134, ptr %l55
  %t135 = load i1, ptr %l55
  br i1 %t135, label %bb105, label %bb106
bb105:
  br label %bb107
bb106:
  br label %bb108
bb107:
  store %olang.scope zeroinitializer, ptr %s27
  store { i64, ptr } { i64 4, ptr @.d74 }, ptr %l1
  call void @__olang_scope_close(ptr %s27)
  br label %bb353
bb108:
  %t136 = load i32, ptr %l0
  store i32 %t136, ptr %l56
  %t137 = load i32, ptr %l56
  %t138 = trunc i64 36 to i32
  %t139 = icmp eq i32 %t137, %t138
  store i1 %t139, ptr %l57
  %t140 = load i1, ptr %l57
  br i1 %t140, label %bb109, label %bb110
bb109:
  br label %bb111
bb110:
  br label %bb112
bb111:
  store %olang.scope zeroinitializer, ptr %s28
  store { i64, ptr } { i64 5, ptr @.d75 }, ptr %l1
  call void @__olang_scope_close(ptr %s28)
  br label %bb353
bb112:
  %t141 = load i32, ptr %l0
  store i32 %t141, ptr %l58
  %t142 = load i32, ptr %l58
  %t143 = trunc i64 37 to i32
  %t144 = icmp eq i32 %t142, %t143
  store i1 %t144, ptr %l59
  %t145 = load i1, ptr %l59
  br i1 %t145, label %bb113, label %bb114
bb113:
  br label %bb115
bb114:
  br label %bb116
bb115:
  store %olang.scope zeroinitializer, ptr %s29
  store { i64, ptr } { i64 2, ptr @.d76 }, ptr %l1
  call void @__olang_scope_close(ptr %s29)
  br label %bb353
bb116:
  %t146 = load i32, ptr %l0
  store i32 %t146, ptr %l60
  %t147 = load i32, ptr %l60
  %t148 = trunc i64 38 to i32
  %t149 = icmp eq i32 %t147, %t148
  store i1 %t149, ptr %l61
  %t150 = load i1, ptr %l61
  br i1 %t150, label %bb117, label %bb118
bb117:
  br label %bb119
bb118:
  br label %bb120
bb119:
  store %olang.scope zeroinitializer, ptr %s30
  store { i64, ptr } { i64 5, ptr @.d77 }, ptr %l1
  call void @__olang_scope_close(ptr %s30)
  br label %bb353
bb120:
  %t151 = load i32, ptr %l0
  store i32 %t151, ptr %l62
  %t152 = load i32, ptr %l62
  %t153 = trunc i64 39 to i32
  %t154 = icmp eq i32 %t152, %t153
  store i1 %t154, ptr %l63
  %t155 = load i1, ptr %l63
  br i1 %t155, label %bb121, label %bb122
bb121:
  br label %bb123
bb122:
  br label %bb124
bb123:
  store %olang.scope zeroinitializer, ptr %s31
  store { i64, ptr } { i64 3, ptr @.d78 }, ptr %l1
  call void @__olang_scope_close(ptr %s31)
  br label %bb353
bb124:
  %t156 = load i32, ptr %l0
  store i32 %t156, ptr %l64
  %t157 = load i32, ptr %l64
  %t158 = trunc i64 40 to i32
  %t159 = icmp eq i32 %t157, %t158
  store i1 %t159, ptr %l65
  %t160 = load i1, ptr %l65
  br i1 %t160, label %bb125, label %bb126
bb125:
  br label %bb127
bb126:
  br label %bb128
bb127:
  store %olang.scope zeroinitializer, ptr %s32
  store { i64, ptr } { i64 3, ptr @.d79 }, ptr %l1
  call void @__olang_scope_close(ptr %s32)
  br label %bb353
bb128:
  %t161 = load i32, ptr %l0
  store i32 %t161, ptr %l66
  %t162 = load i32, ptr %l66
  %t163 = trunc i64 41 to i32
  %t164 = icmp eq i32 %t162, %t163
  store i1 %t164, ptr %l67
  %t165 = load i1, ptr %l67
  br i1 %t165, label %bb129, label %bb130
bb129:
  br label %bb131
bb130:
  br label %bb132
bb131:
  store %olang.scope zeroinitializer, ptr %s33
  store { i64, ptr } { i64 4, ptr @.d80 }, ptr %l1
  call void @__olang_scope_close(ptr %s33)
  br label %bb353
bb132:
  %t166 = load i32, ptr %l0
  store i32 %t166, ptr %l68
  %t167 = load i32, ptr %l68
  %t168 = trunc i64 42 to i32
  %t169 = icmp eq i32 %t167, %t168
  store i1 %t169, ptr %l69
  %t170 = load i1, ptr %l69
  br i1 %t170, label %bb133, label %bb134
bb133:
  br label %bb135
bb134:
  br label %bb136
bb135:
  store %olang.scope zeroinitializer, ptr %s34
  store { i64, ptr } { i64 6, ptr @.d81 }, ptr %l1
  call void @__olang_scope_close(ptr %s34)
  br label %bb353
bb136:
  %t171 = load i32, ptr %l0
  store i32 %t171, ptr %l70
  %t172 = load i32, ptr %l70
  %t173 = trunc i64 43 to i32
  %t174 = icmp eq i32 %t172, %t173
  store i1 %t174, ptr %l71
  %t175 = load i1, ptr %l71
  br i1 %t175, label %bb137, label %bb138
bb137:
  br label %bb139
bb138:
  br label %bb140
bb139:
  store %olang.scope zeroinitializer, ptr %s35
  store { i64, ptr } { i64 4, ptr @.d82 }, ptr %l1
  call void @__olang_scope_close(ptr %s35)
  br label %bb353
bb140:
  %t176 = load i32, ptr %l0
  store i32 %t176, ptr %l72
  %t177 = load i32, ptr %l72
  %t178 = trunc i64 44 to i32
  %t179 = icmp eq i32 %t177, %t178
  store i1 %t179, ptr %l73
  %t180 = load i1, ptr %l73
  br i1 %t180, label %bb141, label %bb142
bb141:
  br label %bb143
bb142:
  br label %bb144
bb143:
  store %olang.scope zeroinitializer, ptr %s36
  store { i64, ptr } { i64 8, ptr @.d83 }, ptr %l1
  call void @__olang_scope_close(ptr %s36)
  br label %bb353
bb144:
  %t181 = load i32, ptr %l0
  store i32 %t181, ptr %l74
  %t182 = load i32, ptr %l74
  %t183 = trunc i64 45 to i32
  %t184 = icmp eq i32 %t182, %t183
  store i1 %t184, ptr %l75
  %t185 = load i1, ptr %l75
  br i1 %t185, label %bb145, label %bb146
bb145:
  br label %bb147
bb146:
  br label %bb148
bb147:
  store %olang.scope zeroinitializer, ptr %s37
  store { i64, ptr } { i64 6, ptr @.d84 }, ptr %l1
  call void @__olang_scope_close(ptr %s37)
  br label %bb353
bb148:
  %t186 = load i32, ptr %l0
  store i32 %t186, ptr %l76
  %t187 = load i32, ptr %l76
  %t188 = trunc i64 46 to i32
  %t189 = icmp eq i32 %t187, %t188
  store i1 %t189, ptr %l77
  %t190 = load i1, ptr %l77
  br i1 %t190, label %bb149, label %bb150
bb149:
  br label %bb151
bb150:
  br label %bb152
bb151:
  store %olang.scope zeroinitializer, ptr %s38
  store { i64, ptr } { i64 7, ptr @.d85 }, ptr %l1
  call void @__olang_scope_close(ptr %s38)
  br label %bb353
bb152:
  %t191 = load i32, ptr %l0
  store i32 %t191, ptr %l78
  %t192 = load i32, ptr %l78
  %t193 = trunc i64 47 to i32
  %t194 = icmp eq i32 %t192, %t193
  store i1 %t194, ptr %l79
  %t195 = load i1, ptr %l79
  br i1 %t195, label %bb153, label %bb154
bb153:
  br label %bb155
bb154:
  br label %bb156
bb155:
  store %olang.scope zeroinitializer, ptr %s39
  store { i64, ptr } { i64 3, ptr @.d86 }, ptr %l1
  call void @__olang_scope_close(ptr %s39)
  br label %bb353
bb156:
  %t196 = load i32, ptr %l0
  store i32 %t196, ptr %l80
  %t197 = load i32, ptr %l80
  %t198 = trunc i64 48 to i32
  %t199 = icmp eq i32 %t197, %t198
  store i1 %t199, ptr %l81
  %t200 = load i1, ptr %l81
  br i1 %t200, label %bb157, label %bb158
bb157:
  br label %bb159
bb158:
  br label %bb160
bb159:
  store %olang.scope zeroinitializer, ptr %s40
  store { i64, ptr } { i64 2, ptr @.d87 }, ptr %l1
  call void @__olang_scope_close(ptr %s40)
  br label %bb353
bb160:
  %t201 = load i32, ptr %l0
  store i32 %t201, ptr %l82
  %t202 = load i32, ptr %l82
  %t203 = trunc i64 49 to i32
  %t204 = icmp eq i32 %t202, %t203
  store i1 %t204, ptr %l83
  %t205 = load i1, ptr %l83
  br i1 %t205, label %bb161, label %bb162
bb161:
  br label %bb163
bb162:
  br label %bb164
bb163:
  store %olang.scope zeroinitializer, ptr %s41
  store { i64, ptr } { i64 3, ptr @.d88 }, ptr %l1
  call void @__olang_scope_close(ptr %s41)
  br label %bb353
bb164:
  %t206 = load i32, ptr %l0
  store i32 %t206, ptr %l84
  %t207 = load i32, ptr %l84
  %t208 = trunc i64 50 to i32
  %t209 = icmp eq i32 %t207, %t208
  store i1 %t209, ptr %l85
  %t210 = load i1, ptr %l85
  br i1 %t210, label %bb165, label %bb166
bb165:
  br label %bb167
bb166:
  br label %bb168
bb167:
  store %olang.scope zeroinitializer, ptr %s42
  store { i64, ptr } { i64 3, ptr @.d89 }, ptr %l1
  call void @__olang_scope_close(ptr %s42)
  br label %bb353
bb168:
  %t211 = load i32, ptr %l0
  store i32 %t211, ptr %l86
  %t212 = load i32, ptr %l86
  %t213 = trunc i64 7 to i32
  %t214 = icmp eq i32 %t212, %t213
  store i1 %t214, ptr %l87
  %t215 = load i1, ptr %l87
  br i1 %t215, label %bb169, label %bb170
bb169:
  br label %bb171
bb170:
  br label %bb172
bb171:
  store %olang.scope zeroinitializer, ptr %s43
  store { i64, ptr } { i64 4, ptr @.d90 }, ptr %l1
  call void @__olang_scope_close(ptr %s43)
  br label %bb353
bb172:
  %t216 = load i32, ptr %l0
  store i32 %t216, ptr %l88
  %t217 = load i32, ptr %l88
  %t218 = trunc i64 51 to i32
  %t219 = icmp eq i32 %t217, %t218
  store i1 %t219, ptr %l89
  %t220 = load i1, ptr %l89
  br i1 %t220, label %bb173, label %bb174
bb173:
  br label %bb175
bb174:
  br label %bb176
bb175:
  store %olang.scope zeroinitializer, ptr %s44
  store { i64, ptr } { i64 1, ptr @.d91 }, ptr %l1
  call void @__olang_scope_close(ptr %s44)
  br label %bb353
bb176:
  %t221 = load i32, ptr %l0
  store i32 %t221, ptr %l90
  %t222 = load i32, ptr %l90
  %t223 = trunc i64 52 to i32
  %t224 = icmp eq i32 %t222, %t223
  store i1 %t224, ptr %l91
  %t225 = load i1, ptr %l91
  br i1 %t225, label %bb177, label %bb178
bb177:
  br label %bb179
bb178:
  br label %bb180
bb179:
  store %olang.scope zeroinitializer, ptr %s45
  store { i64, ptr } { i64 1, ptr @.d92 }, ptr %l1
  call void @__olang_scope_close(ptr %s45)
  br label %bb353
bb180:
  %t226 = load i32, ptr %l0
  store i32 %t226, ptr %l92
  %t227 = load i32, ptr %l92
  %t228 = trunc i64 53 to i32
  %t229 = icmp eq i32 %t227, %t228
  store i1 %t229, ptr %l93
  %t230 = load i1, ptr %l93
  br i1 %t230, label %bb181, label %bb182
bb181:
  br label %bb183
bb182:
  br label %bb184
bb183:
  store %olang.scope zeroinitializer, ptr %s46
  store { i64, ptr } { i64 1, ptr @.d93 }, ptr %l1
  call void @__olang_scope_close(ptr %s46)
  br label %bb353
bb184:
  %t231 = load i32, ptr %l0
  store i32 %t231, ptr %l94
  %t232 = load i32, ptr %l94
  %t233 = trunc i64 54 to i32
  %t234 = icmp eq i32 %t232, %t233
  store i1 %t234, ptr %l95
  %t235 = load i1, ptr %l95
  br i1 %t235, label %bb185, label %bb186
bb185:
  br label %bb187
bb186:
  br label %bb188
bb187:
  store %olang.scope zeroinitializer, ptr %s47
  store { i64, ptr } { i64 1, ptr @.d94 }, ptr %l1
  call void @__olang_scope_close(ptr %s47)
  br label %bb353
bb188:
  %t236 = load i32, ptr %l0
  store i32 %t236, ptr %l96
  %t237 = load i32, ptr %l96
  %t238 = trunc i64 55 to i32
  %t239 = icmp eq i32 %t237, %t238
  store i1 %t239, ptr %l97
  %t240 = load i1, ptr %l97
  br i1 %t240, label %bb189, label %bb190
bb189:
  br label %bb191
bb190:
  br label %bb192
bb191:
  store %olang.scope zeroinitializer, ptr %s48
  store { i64, ptr } { i64 1, ptr @.d95 }, ptr %l1
  call void @__olang_scope_close(ptr %s48)
  br label %bb353
bb192:
  %t241 = load i32, ptr %l0
  store i32 %t241, ptr %l98
  %t242 = load i32, ptr %l98
  %t243 = trunc i64 56 to i32
  %t244 = icmp eq i32 %t242, %t243
  store i1 %t244, ptr %l99
  %t245 = load i1, ptr %l99
  br i1 %t245, label %bb193, label %bb194
bb193:
  br label %bb195
bb194:
  br label %bb196
bb195:
  store %olang.scope zeroinitializer, ptr %s49
  store { i64, ptr } { i64 1, ptr @.d96 }, ptr %l1
  call void @__olang_scope_close(ptr %s49)
  br label %bb353
bb196:
  %t246 = load i32, ptr %l0
  store i32 %t246, ptr %l100
  %t247 = load i32, ptr %l100
  %t248 = trunc i64 57 to i32
  %t249 = icmp eq i32 %t247, %t248
  store i1 %t249, ptr %l101
  %t250 = load i1, ptr %l101
  br i1 %t250, label %bb197, label %bb198
bb197:
  br label %bb199
bb198:
  br label %bb200
bb199:
  store %olang.scope zeroinitializer, ptr %s50
  store { i64, ptr } { i64 1, ptr @.d97 }, ptr %l1
  call void @__olang_scope_close(ptr %s50)
  br label %bb353
bb200:
  %t251 = load i32, ptr %l0
  store i32 %t251, ptr %l102
  %t252 = load i32, ptr %l102
  %t253 = trunc i64 58 to i32
  %t254 = icmp eq i32 %t252, %t253
  store i1 %t254, ptr %l103
  %t255 = load i1, ptr %l103
  br i1 %t255, label %bb201, label %bb202
bb201:
  br label %bb203
bb202:
  br label %bb204
bb203:
  store %olang.scope zeroinitializer, ptr %s51
  store { i64, ptr } { i64 1, ptr @.d98 }, ptr %l1
  call void @__olang_scope_close(ptr %s51)
  br label %bb353
bb204:
  %t256 = load i32, ptr %l0
  store i32 %t256, ptr %l104
  %t257 = load i32, ptr %l104
  %t258 = trunc i64 59 to i32
  %t259 = icmp eq i32 %t257, %t258
  store i1 %t259, ptr %l105
  %t260 = load i1, ptr %l105
  br i1 %t260, label %bb205, label %bb206
bb205:
  br label %bb207
bb206:
  br label %bb208
bb207:
  store %olang.scope zeroinitializer, ptr %s52
  store { i64, ptr } { i64 1, ptr @.d99 }, ptr %l1
  call void @__olang_scope_close(ptr %s52)
  br label %bb353
bb208:
  %t261 = load i32, ptr %l0
  store i32 %t261, ptr %l106
  %t262 = load i32, ptr %l106
  %t263 = trunc i64 60 to i32
  %t264 = icmp eq i32 %t262, %t263
  store i1 %t264, ptr %l107
  %t265 = load i1, ptr %l107
  br i1 %t265, label %bb209, label %bb210
bb209:
  br label %bb211
bb210:
  br label %bb212
bb211:
  store %olang.scope zeroinitializer, ptr %s53
  store { i64, ptr } { i64 1, ptr @.d100 }, ptr %l1
  call void @__olang_scope_close(ptr %s53)
  br label %bb353
bb212:
  %t266 = load i32, ptr %l0
  store i32 %t266, ptr %l108
  %t267 = load i32, ptr %l108
  %t268 = trunc i64 61 to i32
  %t269 = icmp eq i32 %t267, %t268
  store i1 %t269, ptr %l109
  %t270 = load i1, ptr %l109
  br i1 %t270, label %bb213, label %bb214
bb213:
  br label %bb215
bb214:
  br label %bb216
bb215:
  store %olang.scope zeroinitializer, ptr %s54
  store { i64, ptr } { i64 1, ptr @.d101 }, ptr %l1
  call void @__olang_scope_close(ptr %s54)
  br label %bb353
bb216:
  %t271 = load i32, ptr %l0
  store i32 %t271, ptr %l110
  %t272 = load i32, ptr %l110
  %t273 = trunc i64 62 to i32
  %t274 = icmp eq i32 %t272, %t273
  store i1 %t274, ptr %l111
  %t275 = load i1, ptr %l111
  br i1 %t275, label %bb217, label %bb218
bb217:
  br label %bb219
bb218:
  br label %bb220
bb219:
  store %olang.scope zeroinitializer, ptr %s55
  store { i64, ptr } { i64 2, ptr @.d102 }, ptr %l1
  call void @__olang_scope_close(ptr %s55)
  br label %bb353
bb220:
  %t276 = load i32, ptr %l0
  store i32 %t276, ptr %l112
  %t277 = load i32, ptr %l112
  %t278 = trunc i64 63 to i32
  %t279 = icmp eq i32 %t277, %t278
  store i1 %t279, ptr %l113
  %t280 = load i1, ptr %l113
  br i1 %t280, label %bb221, label %bb222
bb221:
  br label %bb223
bb222:
  br label %bb224
bb223:
  store %olang.scope zeroinitializer, ptr %s56
  store { i64, ptr } { i64 2, ptr @.d103 }, ptr %l1
  call void @__olang_scope_close(ptr %s56)
  br label %bb353
bb224:
  %t281 = load i32, ptr %l0
  store i32 %t281, ptr %l114
  %t282 = load i32, ptr %l114
  %t283 = trunc i64 64 to i32
  %t284 = icmp eq i32 %t282, %t283
  store i1 %t284, ptr %l115
  %t285 = load i1, ptr %l115
  br i1 %t285, label %bb225, label %bb226
bb225:
  br label %bb227
bb226:
  br label %bb228
bb227:
  store %olang.scope zeroinitializer, ptr %s57
  store { i64, ptr } { i64 2, ptr @.d104 }, ptr %l1
  call void @__olang_scope_close(ptr %s57)
  br label %bb353
bb228:
  %t286 = load i32, ptr %l0
  store i32 %t286, ptr %l116
  %t287 = load i32, ptr %l116
  %t288 = trunc i64 65 to i32
  %t289 = icmp eq i32 %t287, %t288
  store i1 %t289, ptr %l117
  %t290 = load i1, ptr %l117
  br i1 %t290, label %bb229, label %bb230
bb229:
  br label %bb231
bb230:
  br label %bb232
bb231:
  store %olang.scope zeroinitializer, ptr %s58
  store { i64, ptr } { i64 2, ptr @.d105 }, ptr %l1
  call void @__olang_scope_close(ptr %s58)
  br label %bb353
bb232:
  %t291 = load i32, ptr %l0
  store i32 %t291, ptr %l118
  %t292 = load i32, ptr %l118
  %t293 = trunc i64 66 to i32
  %t294 = icmp eq i32 %t292, %t293
  store i1 %t294, ptr %l119
  %t295 = load i1, ptr %l119
  br i1 %t295, label %bb233, label %bb234
bb233:
  br label %bb235
bb234:
  br label %bb236
bb235:
  store %olang.scope zeroinitializer, ptr %s59
  store { i64, ptr } { i64 2, ptr @.d106 }, ptr %l1
  call void @__olang_scope_close(ptr %s59)
  br label %bb353
bb236:
  %t296 = load i32, ptr %l0
  store i32 %t296, ptr %l120
  %t297 = load i32, ptr %l120
  %t298 = trunc i64 67 to i32
  %t299 = icmp eq i32 %t297, %t298
  store i1 %t299, ptr %l121
  %t300 = load i1, ptr %l121
  br i1 %t300, label %bb237, label %bb238
bb237:
  br label %bb239
bb238:
  br label %bb240
bb239:
  store %olang.scope zeroinitializer, ptr %s60
  store { i64, ptr } { i64 2, ptr @.d107 }, ptr %l1
  call void @__olang_scope_close(ptr %s60)
  br label %bb353
bb240:
  %t301 = load i32, ptr %l0
  store i32 %t301, ptr %l122
  %t302 = load i32, ptr %l122
  %t303 = trunc i64 68 to i32
  %t304 = icmp eq i32 %t302, %t303
  store i1 %t304, ptr %l123
  %t305 = load i1, ptr %l123
  br i1 %t305, label %bb241, label %bb242
bb241:
  br label %bb243
bb242:
  br label %bb244
bb243:
  store %olang.scope zeroinitializer, ptr %s61
  store { i64, ptr } { i64 3, ptr @.d108 }, ptr %l1
  call void @__olang_scope_close(ptr %s61)
  br label %bb353
bb244:
  %t306 = load i32, ptr %l0
  store i32 %t306, ptr %l124
  %t307 = load i32, ptr %l124
  %t308 = trunc i64 69 to i32
  %t309 = icmp eq i32 %t307, %t308
  store i1 %t309, ptr %l125
  %t310 = load i1, ptr %l125
  br i1 %t310, label %bb245, label %bb246
bb245:
  br label %bb247
bb246:
  br label %bb248
bb247:
  store %olang.scope zeroinitializer, ptr %s62
  store { i64, ptr } { i64 3, ptr @.d109 }, ptr %l1
  call void @__olang_scope_close(ptr %s62)
  br label %bb353
bb248:
  %t311 = load i32, ptr %l0
  store i32 %t311, ptr %l126
  %t312 = load i32, ptr %l126
  %t313 = trunc i64 70 to i32
  %t314 = icmp eq i32 %t312, %t313
  store i1 %t314, ptr %l127
  %t315 = load i1, ptr %l127
  br i1 %t315, label %bb249, label %bb250
bb249:
  br label %bb251
bb250:
  br label %bb252
bb251:
  store %olang.scope zeroinitializer, ptr %s63
  store { i64, ptr } { i64 2, ptr @.d110 }, ptr %l1
  call void @__olang_scope_close(ptr %s63)
  br label %bb353
bb252:
  %t316 = load i32, ptr %l0
  store i32 %t316, ptr %l128
  %t317 = load i32, ptr %l128
  %t318 = trunc i64 71 to i32
  %t319 = icmp eq i32 %t317, %t318
  store i1 %t319, ptr %l129
  %t320 = load i1, ptr %l129
  br i1 %t320, label %bb253, label %bb254
bb253:
  br label %bb255
bb254:
  br label %bb256
bb255:
  store %olang.scope zeroinitializer, ptr %s64
  store { i64, ptr } { i64 2, ptr @.d111 }, ptr %l1
  call void @__olang_scope_close(ptr %s64)
  br label %bb353
bb256:
  %t321 = load i32, ptr %l0
  store i32 %t321, ptr %l130
  %t322 = load i32, ptr %l130
  %t323 = trunc i64 72 to i32
  %t324 = icmp eq i32 %t322, %t323
  store i1 %t324, ptr %l131
  %t325 = load i1, ptr %l131
  br i1 %t325, label %bb257, label %bb258
bb257:
  br label %bb259
bb258:
  br label %bb260
bb259:
  store %olang.scope zeroinitializer, ptr %s65
  store { i64, ptr } { i64 2, ptr @.d112 }, ptr %l1
  call void @__olang_scope_close(ptr %s65)
  br label %bb353
bb260:
  %t326 = load i32, ptr %l0
  store i32 %t326, ptr %l132
  %t327 = load i32, ptr %l132
  %t328 = trunc i64 73 to i32
  %t329 = icmp eq i32 %t327, %t328
  store i1 %t329, ptr %l133
  %t330 = load i1, ptr %l133
  br i1 %t330, label %bb261, label %bb262
bb261:
  br label %bb263
bb262:
  br label %bb264
bb263:
  store %olang.scope zeroinitializer, ptr %s66
  store { i64, ptr } { i64 2, ptr @.d113 }, ptr %l1
  call void @__olang_scope_close(ptr %s66)
  br label %bb353
bb264:
  %t331 = load i32, ptr %l0
  store i32 %t331, ptr %l134
  %t332 = load i32, ptr %l134
  %t333 = trunc i64 74 to i32
  %t334 = icmp eq i32 %t332, %t333
  store i1 %t334, ptr %l135
  %t335 = load i1, ptr %l135
  br i1 %t335, label %bb265, label %bb266
bb265:
  br label %bb267
bb266:
  br label %bb268
bb267:
  store %olang.scope zeroinitializer, ptr %s67
  store { i64, ptr } { i64 2, ptr @.d114 }, ptr %l1
  call void @__olang_scope_close(ptr %s67)
  br label %bb353
bb268:
  %t336 = load i32, ptr %l0
  store i32 %t336, ptr %l136
  %t337 = load i32, ptr %l136
  %t338 = trunc i64 75 to i32
  %t339 = icmp eq i32 %t337, %t338
  store i1 %t339, ptr %l137
  %t340 = load i1, ptr %l137
  br i1 %t340, label %bb269, label %bb270
bb269:
  br label %bb271
bb270:
  br label %bb272
bb271:
  store %olang.scope zeroinitializer, ptr %s68
  store { i64, ptr } { i64 2, ptr @.d115 }, ptr %l1
  call void @__olang_scope_close(ptr %s68)
  br label %bb353
bb272:
  %t341 = load i32, ptr %l0
  store i32 %t341, ptr %l138
  %t342 = load i32, ptr %l138
  %t343 = trunc i64 76 to i32
  %t344 = icmp eq i32 %t342, %t343
  store i1 %t344, ptr %l139
  %t345 = load i1, ptr %l139
  br i1 %t345, label %bb273, label %bb274
bb273:
  br label %bb275
bb274:
  br label %bb276
bb275:
  store %olang.scope zeroinitializer, ptr %s69
  store { i64, ptr } { i64 2, ptr @.d116 }, ptr %l1
  call void @__olang_scope_close(ptr %s69)
  br label %bb353
bb276:
  %t346 = load i32, ptr %l0
  store i32 %t346, ptr %l140
  %t347 = load i32, ptr %l140
  %t348 = trunc i64 77 to i32
  %t349 = icmp eq i32 %t347, %t348
  store i1 %t349, ptr %l141
  %t350 = load i1, ptr %l141
  br i1 %t350, label %bb277, label %bb278
bb277:
  br label %bb279
bb278:
  br label %bb280
bb279:
  store %olang.scope zeroinitializer, ptr %s70
  store { i64, ptr } { i64 2, ptr @.d117 }, ptr %l1
  call void @__olang_scope_close(ptr %s70)
  br label %bb353
bb280:
  %t351 = load i32, ptr %l0
  store i32 %t351, ptr %l142
  %t352 = load i32, ptr %l142
  %t353 = trunc i64 78 to i32
  %t354 = icmp eq i32 %t352, %t353
  store i1 %t354, ptr %l143
  %t355 = load i1, ptr %l143
  br i1 %t355, label %bb281, label %bb282
bb281:
  br label %bb283
bb282:
  br label %bb284
bb283:
  store %olang.scope zeroinitializer, ptr %s71
  store { i64, ptr } { i64 1, ptr @.d118 }, ptr %l1
  call void @__olang_scope_close(ptr %s71)
  br label %bb353
bb284:
  %t356 = load i32, ptr %l0
  store i32 %t356, ptr %l144
  %t357 = load i32, ptr %l144
  %t358 = trunc i64 79 to i32
  %t359 = icmp eq i32 %t357, %t358
  store i1 %t359, ptr %l145
  %t360 = load i1, ptr %l145
  br i1 %t360, label %bb285, label %bb286
bb285:
  br label %bb287
bb286:
  br label %bb288
bb287:
  store %olang.scope zeroinitializer, ptr %s72
  store { i64, ptr } { i64 1, ptr @.d119 }, ptr %l1
  call void @__olang_scope_close(ptr %s72)
  br label %bb353
bb288:
  %t361 = load i32, ptr %l0
  store i32 %t361, ptr %l146
  %t362 = load i32, ptr %l146
  %t363 = trunc i64 80 to i32
  %t364 = icmp eq i32 %t362, %t363
  store i1 %t364, ptr %l147
  %t365 = load i1, ptr %l147
  br i1 %t365, label %bb289, label %bb290
bb289:
  br label %bb291
bb290:
  br label %bb292
bb291:
  store %olang.scope zeroinitializer, ptr %s73
  store { i64, ptr } { i64 2, ptr @.d120 }, ptr %l1
  call void @__olang_scope_close(ptr %s73)
  br label %bb353
bb292:
  %t366 = load i32, ptr %l0
  store i32 %t366, ptr %l148
  %t367 = load i32, ptr %l148
  %t368 = trunc i64 81 to i32
  %t369 = icmp eq i32 %t367, %t368
  store i1 %t369, ptr %l149
  %t370 = load i1, ptr %l149
  br i1 %t370, label %bb293, label %bb294
bb293:
  br label %bb295
bb294:
  br label %bb296
bb295:
  store %olang.scope zeroinitializer, ptr %s74
  store { i64, ptr } { i64 1, ptr @.d121 }, ptr %l1
  call void @__olang_scope_close(ptr %s74)
  br label %bb353
bb296:
  %t371 = load i32, ptr %l0
  store i32 %t371, ptr %l150
  %t372 = load i32, ptr %l150
  %t373 = trunc i64 82 to i32
  %t374 = icmp eq i32 %t372, %t373
  store i1 %t374, ptr %l151
  %t375 = load i1, ptr %l151
  br i1 %t375, label %bb297, label %bb298
bb297:
  br label %bb299
bb298:
  br label %bb300
bb299:
  store %olang.scope zeroinitializer, ptr %s75
  store { i64, ptr } { i64 2, ptr @.d122 }, ptr %l1
  call void @__olang_scope_close(ptr %s75)
  br label %bb353
bb300:
  %t376 = load i32, ptr %l0
  store i32 %t376, ptr %l152
  %t377 = load i32, ptr %l152
  %t378 = trunc i64 83 to i32
  %t379 = icmp eq i32 %t377, %t378
  store i1 %t379, ptr %l153
  %t380 = load i1, ptr %l153
  br i1 %t380, label %bb301, label %bb302
bb301:
  br label %bb303
bb302:
  br label %bb304
bb303:
  store %olang.scope zeroinitializer, ptr %s76
  store { i64, ptr } { i64 1, ptr @.d123 }, ptr %l1
  call void @__olang_scope_close(ptr %s76)
  br label %bb353
bb304:
  %t381 = load i32, ptr %l0
  store i32 %t381, ptr %l154
  %t382 = load i32, ptr %l154
  %t383 = trunc i64 84 to i32
  %t384 = icmp eq i32 %t382, %t383
  store i1 %t384, ptr %l155
  %t385 = load i1, ptr %l155
  br i1 %t385, label %bb305, label %bb306
bb305:
  br label %bb307
bb306:
  br label %bb308
bb307:
  store %olang.scope zeroinitializer, ptr %s77
  store { i64, ptr } { i64 1, ptr @.d124 }, ptr %l1
  call void @__olang_scope_close(ptr %s77)
  br label %bb353
bb308:
  %t386 = load i32, ptr %l0
  store i32 %t386, ptr %l156
  %t387 = load i32, ptr %l156
  %t388 = trunc i64 85 to i32
  %t389 = icmp eq i32 %t387, %t388
  store i1 %t389, ptr %l157
  %t390 = load i1, ptr %l157
  br i1 %t390, label %bb309, label %bb310
bb309:
  br label %bb311
bb310:
  br label %bb312
bb311:
  store %olang.scope zeroinitializer, ptr %s78
  store { i64, ptr } { i64 1, ptr @.d125 }, ptr %l1
  call void @__olang_scope_close(ptr %s78)
  br label %bb353
bb312:
  %t391 = load i32, ptr %l0
  store i32 %t391, ptr %l158
  %t392 = load i32, ptr %l158
  %t393 = trunc i64 86 to i32
  %t394 = icmp eq i32 %t392, %t393
  store i1 %t394, ptr %l159
  %t395 = load i1, ptr %l159
  br i1 %t395, label %bb313, label %bb314
bb313:
  br label %bb315
bb314:
  br label %bb316
bb315:
  store %olang.scope zeroinitializer, ptr %s79
  store { i64, ptr } { i64 1, ptr @.d126 }, ptr %l1
  call void @__olang_scope_close(ptr %s79)
  br label %bb353
bb316:
  %t396 = load i32, ptr %l0
  store i32 %t396, ptr %l160
  %t397 = load i32, ptr %l160
  %t398 = trunc i64 87 to i32
  %t399 = icmp eq i32 %t397, %t398
  store i1 %t399, ptr %l161
  %t400 = load i1, ptr %l161
  br i1 %t400, label %bb317, label %bb318
bb317:
  br label %bb319
bb318:
  br label %bb320
bb319:
  store %olang.scope zeroinitializer, ptr %s80
  store { i64, ptr } { i64 1, ptr @.d127 }, ptr %l1
  call void @__olang_scope_close(ptr %s80)
  br label %bb353
bb320:
  %t401 = load i32, ptr %l0
  store i32 %t401, ptr %l162
  %t402 = load i32, ptr %l162
  %t403 = trunc i64 88 to i32
  %t404 = icmp eq i32 %t402, %t403
  store i1 %t404, ptr %l163
  %t405 = load i1, ptr %l163
  br i1 %t405, label %bb321, label %bb322
bb321:
  br label %bb323
bb322:
  br label %bb324
bb323:
  store %olang.scope zeroinitializer, ptr %s81
  store { i64, ptr } { i64 2, ptr @.d128 }, ptr %l1
  call void @__olang_scope_close(ptr %s81)
  br label %bb353
bb324:
  %t406 = load i32, ptr %l0
  store i32 %t406, ptr %l164
  %t407 = load i32, ptr %l164
  %t408 = trunc i64 89 to i32
  %t409 = icmp eq i32 %t407, %t408
  store i1 %t409, ptr %l165
  %t410 = load i1, ptr %l165
  br i1 %t410, label %bb325, label %bb326
bb325:
  br label %bb327
bb326:
  br label %bb328
bb327:
  store %olang.scope zeroinitializer, ptr %s82
  store { i64, ptr } { i64 2, ptr @.d129 }, ptr %l1
  call void @__olang_scope_close(ptr %s82)
  br label %bb353
bb328:
  %t411 = load i32, ptr %l0
  store i32 %t411, ptr %l166
  %t412 = load i32, ptr %l166
  %t413 = trunc i64 90 to i32
  %t414 = icmp eq i32 %t412, %t413
  store i1 %t414, ptr %l167
  %t415 = load i1, ptr %l167
  br i1 %t415, label %bb329, label %bb330
bb329:
  br label %bb331
bb330:
  br label %bb332
bb331:
  store %olang.scope zeroinitializer, ptr %s83
  store { i64, ptr } { i64 1, ptr @.d130 }, ptr %l1
  call void @__olang_scope_close(ptr %s83)
  br label %bb353
bb332:
  %t416 = load i32, ptr %l0
  store i32 %t416, ptr %l168
  %t417 = load i32, ptr %l168
  %t418 = trunc i64 91 to i32
  %t419 = icmp eq i32 %t417, %t418
  store i1 %t419, ptr %l169
  %t420 = load i1, ptr %l169
  br i1 %t420, label %bb333, label %bb334
bb333:
  br label %bb335
bb334:
  br label %bb336
bb335:
  store %olang.scope zeroinitializer, ptr %s84
  store { i64, ptr } { i64 1, ptr @.d131 }, ptr %l1
  call void @__olang_scope_close(ptr %s84)
  br label %bb353
bb336:
  %t421 = load i32, ptr %l0
  store i32 %t421, ptr %l170
  %t422 = load i32, ptr %l170
  %t423 = trunc i64 92 to i32
  %t424 = icmp eq i32 %t422, %t423
  store i1 %t424, ptr %l171
  %t425 = load i1, ptr %l171
  br i1 %t425, label %bb337, label %bb338
bb337:
  br label %bb339
bb338:
  br label %bb340
bb339:
  store %olang.scope zeroinitializer, ptr %s85
  store { i64, ptr } { i64 1, ptr @.d132 }, ptr %l1
  call void @__olang_scope_close(ptr %s85)
  br label %bb353
bb340:
  %t426 = load i32, ptr %l0
  store i32 %t426, ptr %l172
  %t427 = load i32, ptr %l172
  %t428 = trunc i64 93 to i32
  %t429 = icmp eq i32 %t427, %t428
  store i1 %t429, ptr %l173
  %t430 = load i1, ptr %l173
  br i1 %t430, label %bb341, label %bb342
bb341:
  br label %bb343
bb342:
  br label %bb344
bb343:
  store %olang.scope zeroinitializer, ptr %s86
  store { i64, ptr } { i64 1, ptr @.d133 }, ptr %l1
  call void @__olang_scope_close(ptr %s86)
  br label %bb353
bb344:
  %t431 = load i32, ptr %l0
  store i32 %t431, ptr %l174
  %t432 = load i32, ptr %l174
  %t433 = trunc i64 94 to i32
  %t434 = icmp eq i32 %t432, %t433
  store i1 %t434, ptr %l175
  %t435 = load i1, ptr %l175
  br i1 %t435, label %bb345, label %bb346
bb345:
  br label %bb347
bb346:
  br label %bb348
bb347:
  store %olang.scope zeroinitializer, ptr %s87
  store { i64, ptr } { i64 1, ptr @.d134 }, ptr %l1
  call void @__olang_scope_close(ptr %s87)
  br label %bb353
bb348:
  %t436 = load i32, ptr %l0
  store i32 %t436, ptr %l176
  %t437 = load i32, ptr %l176
  %t438 = trunc i64 95 to i32
  %t439 = icmp eq i32 %t437, %t438
  store i1 %t439, ptr %l177
  %t440 = load i1, ptr %l177
  br i1 %t440, label %bb349, label %bb350
bb349:
  br label %bb351
bb350:
  br label %bb352
bb351:
  store %olang.scope zeroinitializer, ptr %s88
  store { i64, ptr } { i64 1, ptr @.d135 }, ptr %l1
  call void @__olang_scope_close(ptr %s88)
  br label %bb353
bb352:
  store %olang.scope zeroinitializer, ptr %s89
  store { i64, ptr } { i64 0, ptr @.d136 }, ptr %l1
  call void @__olang_scope_close(ptr %s89)
  br label %bb353
bb353:
  call void @__olang_scope_close(ptr %s0)
  %t441 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t441, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %a0, i8 %a1) #0 {
entry:
  %l0 = alloca %"compiler/token:Token"
  %l1 = alloca i8
  %l2 = alloca i8
  %l3 = alloca i8
  %l4 = alloca i8
  %l5 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store %"compiler/token:Token" %a0, ptr %l0
  store i8 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/token:Token", ptr %l0, i32 0, i32 1
  %t2 = load i8, ptr %t1
  store i8 %t2, ptr %l2
  %t3 = load i8, ptr %l1
  store i8 %t3, ptr %l3
  %t4 = load i8, ptr %l2
  %t5 = load i8, ptr %l3
  %t6 = and i8 %t4, %t5
  store i8 %t6, ptr %l4
  %t7 = load i8, ptr %l4
  %t8 = icmp ne i8 %t7, 0
  store i1 %t8, ptr %l5
  call void @__olang_scope_close(ptr %s0)
  %t9 = load i1, ptr %l5
  store i1 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftoken_2espells(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i1
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i1
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i1
  %l29 = alloca i1
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i8
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca i8
  %l43 = alloca i1
  %l44 = alloca i1
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store %olang.scope zeroinitializer, ptr %s1
  store i64 1, ptr %l3
  %t1 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t1, ptr %l9
  %t2 = load { i64, ptr }, ptr %l9
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l10
  %t4 = load i64, ptr %l10
  store i64 %t4, ptr %l4
  store i64 1, ptr %l5
  %t5 = load i64, ptr %l4
  store i64 %t5, ptr %l11
  %t6 = load i64, ptr %l3
  store i64 %t6, ptr %l12
  %t7 = load i64, ptr %l11
  %t8 = load i64, ptr %l12
  %t9 = icmp sgt i64 %t7, %t8
  store i1 %t9, ptr %l13
  %t10 = load i1, ptr %l13
  br i1 %t10, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l5
  store i64 %t11, ptr %l15
  %t12 = load i64, ptr %l15
  %t13 = icmp sgt i64 %t12, 0
  store i1 %t13, ptr %l16
  %t14 = load i1, ptr %l16
  br i1 %t14, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l14
  br label %bb6
bb3:
  %t15 = load i64, ptr %l4
  store i64 %t15, ptr %l18
  %t16 = load i64, ptr %l3
  store i64 %t16, ptr %l19
  %t17 = load i64, ptr %l18
  %t18 = load i64, ptr %l19
  %t19 = sub i64 %t17, %t18
  store i64 %t19, ptr %l20
  %t20 = load i64, ptr %l5
  store i64 %t20, ptr %l21
  %t21 = load i64, ptr %l20
  %t22 = load i64, ptr %l21
  %t23 = add i64 %t21, %t22
  store i64 %t23, ptr %l22
  %t24 = load i64, ptr %l22
  %t25 = sub i64 %t24, 1
  store i64 %t25, ptr %l23
  %t26 = load i64, ptr %l5
  store i64 %t26, ptr %l24
  %t27 = load i64, ptr %l23
  %t28 = load i64, ptr %l24
  %t29 = sdiv i64 %t27, %t28
  store i64 %t29, ptr %l25
  %t30 = load i64, ptr %l25
  store i64 %t30, ptr %l17
  br label %bb5
bb4:
  store i64 0, ptr %l17
  br label %bb5
bb5:
  %t31 = load i64, ptr %l17
  store i64 %t31, ptr %l14
  br label %bb6
bb6:
  %t32 = load i64, ptr %l14
  store i64 %t32, ptr %l6
  store i64 0, ptr %l7
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load i64, ptr %l7
  store i64 %t33, ptr %l26
  %t34 = load i64, ptr %l6
  store i64 %t34, ptr %l27
  %t35 = load i64, ptr %l26
  %t36 = load i64, ptr %l27
  %t37 = icmp slt i64 %t35, %t36
  store i1 %t37, ptr %l28
  %t38 = load i1, ptr %l28
  %t39 = xor i1 %t38, true
  store i1 %t39, ptr %l29
  %t40 = load i1, ptr %l29
  br i1 %t40, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l3
  store i64 %t41, ptr %l30
  %t42 = load i64, ptr %l7
  store i64 %t42, ptr %l31
  %t43 = load i64, ptr %l5
  store i64 %t43, ptr %l32
  %t44 = load i64, ptr %l31
  %t45 = load i64, ptr %l32
  %t46 = mul i64 %t44, %t45
  store i64 %t46, ptr %l33
  %t47 = load i64, ptr %l30
  %t48 = load i64, ptr %l33
  %t49 = add i64 %t47, %t48
  store i64 %t49, ptr %l34
  %t50 = load i64, ptr %l34
  store i64 %t50, ptr %l8
  %t51 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t51, ptr %l35
  %t52 = load i64, ptr %l1
  store i64 %t52, ptr %l36
  %t53 = load i64, ptr %l8
  store i64 %t53, ptr %l37
  %t54 = load i64, ptr %l36
  %t55 = load i64, ptr %l37
  %t56 = add i64 %t54, %t55
  store i64 %t56, ptr %l38
  %t57 = load i64, ptr %l38
  %t58 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t59 = load ptr, ptr %t58
  %t60 = getelementptr i8, ptr %t59, i64 %t57
  %t61 = load i8, ptr %t60
  store i8 %t61, ptr %l39
  %t62 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t62, ptr %l40
  %t63 = load i64, ptr %l8
  store i64 %t63, ptr %l41
  %t64 = load i64, ptr %l41
  %t65 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t66 = load ptr, ptr %t65
  %t67 = getelementptr i8, ptr %t66, i64 %t64
  %t68 = load i8, ptr %t67
  store i8 %t68, ptr %l42
  %t69 = load i8, ptr %l39
  %t70 = load i8, ptr %l42
  %t71 = icmp ne i8 %t69, %t70
  store i1 %t71, ptr %l43
  %t72 = load i1, ptr %l43
  br i1 %t72, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  store i1 false, ptr %l44
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t73 = load i1, ptr %l44
  store i1 %t73, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  %t74 = load i64, ptr %l7
  store i64 %t74, ptr %l45
  %t75 = load i64, ptr %l45
  %t76 = add i64 %t75, 1
  store i64 %t76, ptr %l46
  %t77 = load i64, ptr %l46
  store i64 %t77, ptr %l7
  call void @__olang_scope_close(ptr %s4)
  br label %bb7
bb15:
  call void @__olang_scope_close(ptr %s1)
  store i1 true, ptr %l47
  call void @__olang_scope_close(ptr %s0)
  %t78 = load i1, ptr %l47
  store i1 %t78, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/token:Token" @compiler_2ftoken_3aToken_2ector(ptr %v0, i32 %a0, i8 %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i8
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i8
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i8
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca %"compiler/token:Token"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/token:Token"
  store i32 %a0, ptr %l0
  store i8 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l0
  store i32 %t1, ptr %l8
  %t2 = load i32, ptr %l8
  store i32 %t2, ptr %l4
  %t3 = load i8, ptr %l1
  store i8 %t3, ptr %l9
  %t4 = load i8, ptr %l9
  store i8 %t4, ptr %l5
  %t5 = load i32, ptr %l2
  store i32 %t5, ptr %l10
  %t6 = load i32, ptr %l10
  store i32 %t6, ptr %l6
  %t7 = load i32, ptr %l3
  store i32 %t7, ptr %l11
  %t8 = load i32, ptr %l11
  store i32 %t8, ptr %l7
  %t9 = load i32, ptr %l4
  %t10 = insertvalue %"compiler/token:Token" undef, i32 %t9, 0
  %t11 = load i8, ptr %l5
  %t12 = insertvalue %"compiler/token:Token" %t10, i8 %t11, 1
  %t13 = load i32, ptr %l6
  %t14 = insertvalue %"compiler/token:Token" %t12, i32 %t13, 2
  %t15 = load i32, ptr %l7
  %t16 = insertvalue %"compiler/token:Token" %t14, i32 %t15, 3
  store %"compiler/token:Token" %t16, ptr %l12
  call void @__olang_scope_close(ptr %s0)
  %t17 = load %"compiler/token:Token", ptr %l12
  store %"compiler/token:Token" %t17, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/token:Token", ptr %rv
  ret %"compiler/token:Token" %rr
}

define dso_local void @olang_2einit_2ecompiler_2ftoken() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @compiler_2ftoken_2eLineBreak_2einit()
  br label %bb1
bb1:
  call void @compiler_2ftoken_2eSpace_2einit()
  br label %bb2
bb2:
  call void @compiler_2ftoken_2eLineStart_2einit()
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

declare void @__olang_scope_close(ptr)
@.d0 = private constant [3 x i8] c"and"
@.d1 = private constant [6 x i8] c"assert"
@.d2 = private constant [5 x i8] c"break"
@.d3 = private constant [4 x i8] c"case"
@.d4 = private constant [5 x i8] c"catch"
@.d5 = private constant [7 x i8] c"checked"
@.d6 = private constant [8 x i8] c"continue"
@.d7 = private constant [5 x i8] c"defer"
@.d8 = private constant [7 x i8] c"default"
@.d9 = private constant [8 x i8] c"destruct"
@.d10 = private constant [4 x i8] c"else"
@.d11 = private constant [4 x i8] c"enum"
@.d12 = private constant [5 x i8] c"error"
@.d13 = private constant [7 x i8] c"extends"
@.d14 = private constant [6 x i8] c"extern"
@.d15 = private constant [3 x i8] c"for"
@.d16 = private constant [5 x i8] c"false"
@.d17 = private constant [6 x i8] c"import"
@.d18 = private constant [4 x i8] c"join"
@.d19 = private constant [3 x i8] c"mut"
@.d20 = private constant [5 x i8] c"match"
@.d21 = private constant [3 x i8] c"not"
@.d22 = private constant [4 x i8] c"null"
@.d23 = private constant [7 x i8] c"nomatch"
@.d24 = private constant [8 x i8] c"noreturn"
@.d25 = private constant [3 x i8] c"own"
@.d26 = private constant [5 x i8] c"range"
@.d27 = private constant [6 x i8] c"return"
@.d28 = private constant [5 x i8] c"spawn"
@.d29 = private constant [6 x i8] c"struct"
@.d30 = private constant [3 x i8] c"try"
@.d31 = private constant [4 x i8] c"type"
@.d32 = private constant [4 x i8] c"take"
@.d33 = private constant [4 x i8] c"test"
@.d34 = private constant [4 x i8] c"true"
@.d35 = private constant [5 x i8] c"trait"
@.d36 = private constant [11 x i8] c"unreachable"
@.d37 = private constant [3 x i8] c"xor"
@.d38 = private constant [11 x i8] c"end of file"
@.d39 = private constant [6 x i8] c"a name"
@.d40 = private constant [18 x i8] c"an integer literal"
@.d41 = private constant [15 x i8] c"a float literal"
@.d42 = private constant [19 x i8] c"a character literal"
@.d43 = private constant [16 x i8] c"a string literal"
@.d44 = private constant [14 x i8] c"a Bool literal"
@.d45 = private constant [11 x i8] c"end of line"
@.d46 = private constant [1 x i8] c"'"
declare void @__olang_sb_put(ptr, ptr, i64)
@.d47 = private constant [1 x i8] c"'"
declare ptr @__olang_scope_alloc(ptr, i64)
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare void @__olang_sb_done(ptr)
@.d48 = private constant [2 x i8] c"if"
@.d49 = private constant [4 x i8] c"else"
@.d50 = private constant [3 x i8] c"try"
@.d51 = private constant [7 x i8] c"checked"
@.d52 = private constant [5 x i8] c"catch"
@.d53 = private constant [6 x i8] c"return"
@.d54 = private constant [4 x i8] c"join"
@.d55 = private constant [5 x i8] c"spawn"
@.d56 = private constant [5 x i8] c"defer"
@.d57 = private constant [5 x i8] c"break"
@.d58 = private constant [8 x i8] c"continue"
@.d59 = private constant [11 x i8] c"unreachable"
@.d60 = private constant [7 x i8] c"extends"
@.d61 = private constant [8 x i8] c"noreturn"
@.d62 = private constant [6 x i8] c"assert"
@.d63 = private constant [3 x i8] c"for"
@.d64 = private constant [2 x i8] c"do"
@.d65 = private constant [2 x i8] c"in"
@.d66 = private constant [2 x i8] c"is"
@.d67 = private constant [2 x i8] c"as"
@.d68 = private constant [5 x i8] c"range"
@.d69 = private constant [5 x i8] c"match"
@.d70 = private constant [4 x i8] c"case"
@.d71 = private constant [7 x i8] c"nomatch"
@.d72 = private constant [4 x i8] c"type"
@.d73 = private constant [6 x i8] c"struct"
@.d74 = private constant [4 x i8] c"enum"
@.d75 = private constant [5 x i8] c"trait"
@.d76 = private constant [2 x i8] c"fn"
@.d77 = private constant [5 x i8] c"error"
@.d78 = private constant [3 x i8] c"mut"
@.d79 = private constant [3 x i8] c"own"
@.d80 = private constant [4 x i8] c"take"
@.d81 = private constant [6 x i8] c"import"
@.d82 = private constant [4 x i8] c"test"
@.d83 = private constant [8 x i8] c"destruct"
@.d84 = private constant [6 x i8] c"extern"
@.d85 = private constant [7 x i8] c"default"
@.d86 = private constant [3 x i8] c"and"
@.d87 = private constant [2 x i8] c"or"
@.d88 = private constant [3 x i8] c"xor"
@.d89 = private constant [3 x i8] c"not"
@.d90 = private constant [4 x i8] c"null"
@.d91 = private constant [1 x i8] c"+"
@.d92 = private constant [1 x i8] c"-"
@.d93 = private constant [1 x i8] c"*"
@.d94 = private constant [1 x i8] c"/"
@.d95 = private constant [1 x i8] c"%"
@.d96 = private constant [1 x i8] c"@"
@.d97 = private constant [1 x i8] c","
@.d98 = private constant [1 x i8] c"."
@.d99 = private constant [1 x i8] c"?"
@.d100 = private constant [1 x i8] c"="
@.d101 = private constant [1 x i8] c":"
@.d102 = private constant [2 x i8] c":="
@.d103 = private constant [2 x i8] c"+="
@.d104 = private constant [2 x i8] c"-="
@.d105 = private constant [2 x i8] c"*="
@.d106 = private constant [2 x i8] c"/="
@.d107 = private constant [2 x i8] c"%="
@.d108 = private constant [3 x i8] c"<<="
@.d109 = private constant [3 x i8] c">>="
@.d110 = private constant [2 x i8] c"&="
@.d111 = private constant [2 x i8] c"|="
@.d112 = private constant [2 x i8] c"^="
@.d113 = private constant [2 x i8] c"++"
@.d114 = private constant [2 x i8] c"--"
@.d115 = private constant [2 x i8] c"=="
@.d116 = private constant [2 x i8] c"=>"
@.d117 = private constant [2 x i8] c"!="
@.d118 = private constant [1 x i8] c"!"
@.d119 = private constant [1 x i8] c"<"
@.d120 = private constant [2 x i8] c"<="
@.d121 = private constant [1 x i8] c">"
@.d122 = private constant [2 x i8] c">="
@.d123 = private constant [1 x i8] c"&"
@.d124 = private constant [1 x i8] c"|"
@.d125 = private constant [1 x i8] c"^"
@.d126 = private constant [1 x i8] c"~"
@.d127 = private constant [1 x i8] c"$"
@.d128 = private constant [2 x i8] c"<<"
@.d129 = private constant [2 x i8] c">>"
@.d130 = private constant [1 x i8] c"("
@.d131 = private constant [1 x i8] c")"
@.d132 = private constant [1 x i8] c"["
@.d133 = private constant [1 x i8] c"]"
@.d134 = private constant [1 x i8] c"{"
@.d135 = private constant [1 x i8] c"}"
@.d136 = private constant [0 x i8] c""
attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
