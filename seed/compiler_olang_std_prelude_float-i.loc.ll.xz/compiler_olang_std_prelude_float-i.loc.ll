; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_4c9ca82ccc1e132f_6dfeaef935ffdb23 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_d14283d1b155ffc3_f040dd2686362a27 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:36: array length out of range\0A\00"
