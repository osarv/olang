; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_6b08325acee8d5f3_def92f7723e9aa47 = weak_odr constant [54 x i8] c"std/prelude/list.olang:54: array length out of range\0A\00"
@olang_loc_79cd4003c0496afd_ba604a707388bbf1 = weak_odr constant [54 x i8] c"std/prelude/list.olang:49: array length out of range\0A\00"
@olang_loc_92e031022dc782f3_9ca1b4555f487b67 = weak_odr constant [55 x i8] c"std/prelude/list.olang:110: array length out of range\0A\00"
@olang_loc_a1a53eab1f2817fd_b46b0cb908c22991 = weak_odr constant [55 x i8] c"std/prelude/list.olang:103: array length out of range\0A\00"
@olang_loc_bb268a7b0321b3be_44b5ab9829c44772 = weak_odr constant [55 x i8] c"std/prelude/list.olang:114: array length out of range\0A\00"
@olang_loc_bdf1050ff2c2bdd0_ba39e98a6c4a40e4 = weak_odr constant [54 x i8] c"std/prelude/list.olang:51: array length out of range\0A\00"
@olang_loc_e5c903b751a16ad0_a1d0d2f85182a884 = weak_odr constant [55 x i8] c"std/prelude/list.olang:108: array length out of range\0A\00"
