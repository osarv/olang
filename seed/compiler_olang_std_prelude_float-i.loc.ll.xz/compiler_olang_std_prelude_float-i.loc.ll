; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_4c80127648ba5d2e_65bcf202b125bf62 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
