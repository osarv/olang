; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/lineedit:Editor" = type { i1, i1, i64, { i64, ptr }, i64, i1, %"std/prelude/text:StringBuilder", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, { i64, ptr }, i64, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i1, i1, i1, i1, i1, { i64, ptr }, { i64, ptr }, i64, i1, { i64, ptr }, i64, i64, i64, i8, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"<termios.h>:termios" = type { i32, i32, i32, i32, i8, [32 x i8], i32, i32 }
define dso_local void @compiler_2flineedit_2eappendLine(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i32
  %l9 = alloca i1
  %l10 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l27 = alloca i32
  %l29 = alloca i1
  %l40 = alloca i32
  %l48 = alloca i32
  %l50 = alloca i1
  %l54 = alloca i32
  %s0 = alloca %olang.scope
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = sub i64 %t3, 1
  store i64 %t5, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sgt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t11, ptr %l10, !tbaa !27
  %t12 = load i64, ptr %l2, !tbaa !24
  %t14 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i8, ptr %t15, i64 %t12
  %t17 = load i8, ptr %t16, !tbaa !32
  %t19 = icmp ne i8 %t17, 47
  store i1 %t19, ptr %l9, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb4
bb4:
  %t21 = load i1, ptr %l9, !tbaa !21
  %t22 = xor i1 %t21, true
  br i1 %t22, label %bb5, label %bb6
bb5:
  br label %bb9
bb6:
  br label %bb7
bb7:
  %t24 = load i64, ptr %l2, !tbaa !24
  %t27 = sub i64 %t24, 1
  store i64 %t27, ptr %l2, !tbaa !24
  br label %bb8
bb8:
  br label %bb1
bb9:
  %t29 = load i64, ptr %l2, !tbaa !24
  %t31 = icmp sgt i64 %t29, 0
  br i1 %t31, label %bb10, label %bb11
bb10:
  %t33 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t33, ptr %l20, !tbaa !27
  %t34 = load i64, ptr %l2, !tbaa !24
  store i64 %t34, ptr %l21, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t35, 0
  store i64 %t36, ptr %l22, !tbaa !24
  %t37 = icmp sge i64 0, 0
  br i1 %t37, label %bb12, label %bb13
bb11:
  br label %bb24
bb12:
  %t39 = load i64, ptr %l21, !tbaa !24
  %t40 = icmp sle i64 0, %t39
  br i1 %t40, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_7dccba76dee48f7e_602c3d6b6ac3d592)
  unreachable
bb14:
  %t42 = load i64, ptr %l21, !tbaa !24
  %t43 = load i64, ptr %l22, !tbaa !24
  %t44 = icmp sle i64 %t42, %t43
  br i1 %t44, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_7dccba76dee48f7e_602c3d6b6ac3d592)
  unreachable
bb16:
  %t46 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = load i64, ptr %l21, !tbaa !24
  %t49 = getelementptr i8, ptr %t47, i64 0
  %t50 = sub i64 %t48, 0
  %t51 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t49, 1
  %t54 = call i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %t52)
  store i32 %t54, ptr %l27
  %t55 = icmp ne i32 %t54, 0
  br i1 %t55, label %bb19, label %ok.56, !prof !99
ok.56:
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_7dccba76dee48f7e_602c3d6b6ac3d592)
  unreachable
bb18:
  br label %bb23
bb19:
  %t57 = load i32, ptr %l27, !tbaa !23
  %t58 = ashr i32 %t57, 16
  %t60 = icmp eq i32 %t58, 1
  store i1 %t60, ptr %l29, !tbaa !21
  %t61 = load i32, ptr %l27, !tbaa !23
  %t62 = ashr i32 %t61, 16
  %t64 = icmp eq i32 %t62, 1
  br i1 %t64, label %bb20, label %bb21
bb20:
  call void @__olang_errpay_pop()
  br label %bb21
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t66 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t66, 1
  %t69 = extractvalue { i64, ptr } %t66, 0
  %t70 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t71 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t72 = add i64 %t69, %t71
  %t73 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t72)
  call void @olang_textcopy(ptr %t73, ptr %t68, i64 %t69)
  %t74 = getelementptr i8, ptr %t73, i64 %t69
  call void @olang_textcopy(ptr %t74, ptr %t70, i64 %t71)
  %t75 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t73, 1
  %t78 = load i32, ptr @G_2e_3cfcntl_2eh_3e_2eO__WRONLY, !tbaa !23
  %t79 = load i32, ptr @G_2e_3cfcntl_2eh_3e_2eO__CREAT, !tbaa !23
  %t82 = or i32 %t78, %t79
  %t83 = load i32, ptr @G_2e_3cfcntl_2eh_3e_2eO__APPEND, !tbaa !23
  %t86 = or i32 %t82, %t83
  %t88 = extractvalue { i64, ptr } %t76, 1
  %t89 = extractvalue { i64, ptr } %t76, 0
  %t91 = call i32 (ptr, i32, ...) @open(ptr %t88, i32 %t86, i32 384)
  store i32 %t91, ptr %l40
  br label %bb25
bb25:
  %t92 = load i32, ptr %l40, !tbaa !23
  store i32 %t92, ptr %l3, !tbaa !23
  %t93 = load i32, ptr %l3, !tbaa !23
  %t95 = icmp slt i32 %t93, 0
  br i1 %t95, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb27:
  br label %bb28
bb28:
  %t97 = load i32, ptr %l3, !tbaa !23
  %t100 = extractvalue { i64, ptr } %a1, 1
  %t101 = extractvalue { i64, ptr } %a1, 0
  %t102 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t103 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t104 = add i64 %t101, %t103
  %t105 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t104)
  call void @olang_textcopy(ptr %t105, ptr %t100, i64 %t101)
  %t106 = getelementptr i8, ptr %t105, i64 %t101
  call void @olang_textcopy(ptr %t106, ptr %t102, i64 %t103)
  %t107 = insertvalue { i64, ptr } undef, i64 %t104, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t105, 1
  %t111 = extractvalue { i64, ptr } %t108, 0
  %t112 = extractvalue { i64, ptr } %t108, 1
  %t113 = mul i64 %t111, 1
  %t114 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t113)
  call void @llvm.memcpy.p0.p0.i64(ptr %t114, ptr %t112, i64 %t113, i1 false)
  %t115 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t114, 1
  %t119 = call i32 @std_2fio_2eWrite(ptr %s0, i32 %t97, { i64, ptr } %t116)
  store i32 %t119, ptr %l48
  %t120 = icmp ne i32 %t119, 0
  br i1 %t120, label %bb30, label %ok.121, !prof !99
ok.121:
  br label %bb29
bb29:
  br label %bb34
bb30:
  %t122 = load i32, ptr %l48, !tbaa !23
  %t123 = ashr i32 %t122, 16
  %t125 = icmp eq i32 %t123, 1
  store i1 %t125, ptr %l50, !tbaa !21
  %t126 = load i32, ptr %l48, !tbaa !23
  %t127 = ashr i32 %t126, 16
  %t129 = icmp eq i32 %t127, 1
  br i1 %t129, label %bb31, label %bb32
bb31:
  call void @__olang_errpay_pop()
  br label %bb32
bb32:
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t131 = load i32, ptr %l3, !tbaa !23
  %t133 = call i32 @close(i32 %t131)
  store i32 %t133, ptr %l54
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2flineedit_2ecolumns() #0 {
entry:
  %l0 = alloca [4 x i16]
  %l6 = alloca i32
  %l8 = alloca i1
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [4 x i16] undef, i16 0, 0
  %t2 = insertvalue [4 x i16] %t1, i16 0, 1
  %t3 = insertvalue [4 x i16] %t2, i16 0, 2
  %t4 = insertvalue [4 x i16] %t3, i16 0, 3
  store [4 x i16] %t4, ptr %l0
  %t6 = load i32, ptr @G_2e_3csys_2fioctl_2eh_3e_2eTIOCGWINSZ, !tbaa !23
  %t8 = sext i32 %t6 to i64
  %t10 = insertvalue { i64, ptr } undef, i64 4, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %l0, 1
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = extractvalue { i64, ptr } %t11, 0
  %t16 = call i32 @ioctl(i32 1, i64 %t8, ptr %t14)
  store i32 %t16, ptr %l6
  br label %bb1
bb1:
  %t17 = load i32, ptr %l6, !tbaa !23
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb4
bb3:
  %t20 = getelementptr [4 x i16], ptr %l0, i64 0, i64 1
  %t21 = load i16, ptr %t20, !tbaa !83
  %t23 = icmp eq i16 %t21, 0
  store i1 %t23, ptr %l8, !tbaa !21
  br label %bb4
bb4:
  %t25 = load i1, ptr %l8, !tbaa !21
  br i1 %t25, label %bb5, label %bb6
bb5:
  store i64 80, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t27 = getelementptr [4 x i16], ptr %l0, i64 0, i64 1
  %t28 = load i16, ptr %t27, !tbaa !83
  %t30 = zext i16 %t28 to i64
  store i64 %t30, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eAccept(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lineedit:Editor", ptr %t1, i32 0, i32 21
  store i1 false, ptr %t3, !tbaa !21
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/lineedit:Editor", ptr %t5, i32 0, i32 3
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t13 = getelementptr %"compiler/lineedit:Editor", ptr %t4, i32 0, i32 4
  store i64 %t10, ptr %t13, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2edraw(ptr %v0, ptr %t14)
  br label %bb1
bb1:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/lineedit:Editor", ptr %t16, i32 0, i32 6
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t18, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d2, i32 0, i32 1) })
  br label %bb2
bb2:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/lineedit:Editor", ptr %t20, i32 0, i32 3
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  store { i64, ptr } %t23, ptr %l1, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load { i64, ptr }, ptr %l1, !tbaa !27
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eRemember(ptr %v0, ptr %v0, ptr %t25, { i64, ptr } %t26)
  br label %bb3
bb3:
  %t29 = load { i64, ptr }, ptr %l1, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t29, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eBreak(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l9 = alloca i64
  %l15 = alloca i1
  %l17 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l35 = alloca i1
  %l37 = alloca { i64, ptr }
  %l43 = alloca i1
  %l45 = alloca { i64, ptr }
  %l51 = alloca i1
  %l53 = alloca { i64, ptr }
  %l59 = alloca ptr
  %l60 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lineedit:Editor", ptr %t1, i32 0, i32 3
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/lineedit:Editor", ptr %t5, i32 0, i32 4
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = call i64 @compiler_2flineedit_2elineStart(ptr %v0, { i64, ptr } %t4, i64 %t8)
  store i64 %t11, ptr %l9
  br label %bb1
bb1:
  %t12 = load i64, ptr %l9, !tbaa !24
  store i64 %t12, ptr %l1, !tbaa !24
  %t13 = load i64, ptr %l1, !tbaa !24
  store i64 %t13, ptr %l2, !tbaa !24
  br label %bb2
bb2:
  %t15 = load i64, ptr %l2, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/lineedit:Editor", ptr %t16, i32 0, i32 4
  %t19 = load i64, ptr %t18, !tbaa !24
  %t22 = icmp slt i64 %t15, %t19
  br i1 %t22, label %bb3, label %bb4
bb3:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/lineedit:Editor", ptr %t24, i32 0, i32 3
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %l17, !tbaa !27
  %t28 = load i64, ptr %l2, !tbaa !24
  %t30 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr i8, ptr %t31, i64 %t28
  %t33 = load i8, ptr %t32, !tbaa !32
  %t35 = icmp eq i8 %t33, 32
  store i1 %t35, ptr %l15, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb5
bb5:
  %t37 = load i1, ptr %l15, !tbaa !21
  %t38 = xor i1 %t37, true
  br i1 %t38, label %bb6, label %bb7
bb6:
  br label %bb10
bb7:
  br label %bb8
bb8:
  %t40 = load i64, ptr %l2, !tbaa !24
  %t43 = add i64 %t40, 1
  store i64 %t43, ptr %l2, !tbaa !24
  br label %bb9
bb9:
  br label %bb2
bb10:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, ptr %l25, !tbaa !27
  %t45 = load i64, ptr %l2, !tbaa !24
  %t46 = load i64, ptr %l1, !tbaa !24
  %t49 = sub i64 %t45, %t46
  %t50 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t52 = call { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eRepeat_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s0, ptr %s0, { i64, ptr } %t50, i64 %t49)
  store { i64, ptr } %t52, ptr %l29
  br label %bb11
bb11:
  %t53 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t53, ptr %l3, !tbaa !27
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/lineedit:Editor", ptr %t55, i32 0, i32 4
  %t58 = load i64, ptr %t57, !tbaa !24
  %t59 = load i64, ptr %l1, !tbaa !24
  %t62 = icmp sgt i64 %t58, %t59
  br i1 %t62, label %bb12, label %bb13
bb12:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/lineedit:Editor", ptr %t64, i32 0, i32 3
  %t67 = load { i64, ptr }, ptr %t66, !tbaa !27
  store { i64, ptr } %t67, ptr %l37, !tbaa !27
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/lineedit:Editor", ptr %t68, i32 0, i32 4
  %t71 = load i64, ptr %t70, !tbaa !24
  %t73 = sub i64 %t71, 1
  %t75 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr i8, ptr %t76, i64 %t73
  %t78 = load i8, ptr %t77, !tbaa !32
  %t80 = icmp eq i8 %t78, 123
  br i1 %t80, label %bb14, label %bb15
bb13:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb20
bb14:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb16
bb15:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/lineedit:Editor", ptr %t82, i32 0, i32 3
  %t85 = load { i64, ptr }, ptr %t84, !tbaa !27
  store { i64, ptr } %t85, ptr %l45, !tbaa !27
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/lineedit:Editor", ptr %t86, i32 0, i32 4
  %t89 = load i64, ptr %t88, !tbaa !24
  %t91 = sub i64 %t89, 1
  %t93 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr i8, ptr %t94, i64 %t91
  %t96 = load i8, ptr %t95, !tbaa !32
  %t98 = icmp eq i8 %t96, 40
  store i1 %t98, ptr %l43, !tbaa !21
  br label %bb16
bb16:
  %t100 = load i1, ptr %l43, !tbaa !21
  br i1 %t100, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb19
bb18:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/lineedit:Editor", ptr %t101, i32 0, i32 3
  %t104 = load { i64, ptr }, ptr %t103, !tbaa !27
  store { i64, ptr } %t104, ptr %l53, !tbaa !27
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/lineedit:Editor", ptr %t105, i32 0, i32 4
  %t108 = load i64, ptr %t107, !tbaa !24
  %t110 = sub i64 %t108, 1
  %t112 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr i8, ptr %t113, i64 %t110
  %t115 = load i8, ptr %t114, !tbaa !32
  %t117 = icmp eq i8 %t115, 91
  store i1 %t117, ptr %l51, !tbaa !21
  br label %bb19
bb19:
  %t119 = load i1, ptr %l51, !tbaa !21
  store i1 %t119, ptr %l35, !tbaa !21
  br label %bb20
bb20:
  %t120 = load i1, ptr %l35, !tbaa !21
  %t121 = load ptr, ptr %l0, !tbaa !29
  store ptr %t121, ptr %l59, !tbaa !29
  %t122 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t122, ptr %l60, !tbaa !27
  br i1 %t120, label %bb21, label %bb22
bb21:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d4, i32 0, i32 1) }, ptr %l62, !tbaa !27
  br label %bb23
bb22:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d5, i32 0, i32 1) }, ptr %l62, !tbaa !27
  br label %bb23
bb23:
  %t125 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t126 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t127 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t127, 1
  %t129 = extractvalue { i64, ptr } %t127, 0
  %t130 = add i64 %t126, %t129
  %t131 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t131, 1
  %t133 = extractvalue { i64, ptr } %t131, 0
  %t134 = add i64 %t130, %t133
  %t135 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t134)
  call void @olang_textcopy(ptr %t135, ptr %t125, i64 %t126)
  %t136 = getelementptr i8, ptr %t135, i64 %t126
  call void @olang_textcopy(ptr %t136, ptr %t128, i64 %t129)
  %t137 = getelementptr i8, ptr %t136, i64 %t129
  call void @olang_textcopy(ptr %t137, ptr %t132, i64 %t133)
  %t138 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t135, 1
  %t141 = load ptr, ptr %l59, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2einsert(ptr %v0, ptr %s0, ptr %t141, { i64, ptr } %t139)
  br label %bb24
bb24:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/lineedit:Editor", ptr %t143, i32 0, i32 5
  store i1 false, ptr %t145, !tbaa !21
  %t146 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2edraw(ptr %v0, ptr %t146)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eIdle(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l13 = alloca i1
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lineedit:Editor", ptr %t1, i32 0, i32 15
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t4, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store i1 %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load i1, ptr %l3, !tbaa !21
  %t8 = xor i1 %t7, true
  br i1 %t8, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l5, !tbaa !29
  %t11 = load ptr, ptr %l5, !tbaa !29
  %t12 = getelementptr %"compiler/lineedit:Editor", ptr %t11, i32 0, i32 15
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l6, !tbaa !27
  %t14 = load ptr, ptr %l5, !tbaa !29
  %t15 = getelementptr %"compiler/lineedit:Editor", ptr %t14, i32 0, i32 15
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %t15, !tbaa !27
  %t16 = load i1, ptr @olang_2esole_2ecompiler_2flineedit_3aEditor_2e15
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load { i64, ptr }, ptr %l6
  %t19 = extractvalue { i64, ptr } %t18, 1
  call void @__olang_region_release(ptr %t19)
  store { i64, ptr } zeroinitializer, ptr %l6
  br label %bb6
bb6:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/lineedit:Editor", ptr %t20, i32 0, i32 21
  %t23 = load i1, ptr %t22, !tbaa !21
  br i1 %t23, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eacceptSearch(ptr %v0, ptr %t25)
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/lineedit:Editor", ptr %t27, i32 0, i32 0
  %t30 = load i1, ptr %t29, !tbaa !21
  br i1 %t30, label %bb11, label %bb12
bb11:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/lineedit:Editor", ptr %t32, i32 0, i32 21
  %t35 = load i1, ptr %t34, !tbaa !21
  %t37 = xor i1 %t35, true
  store i1 %t37, ptr %l13, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb13
bb13:
  %t39 = load i1, ptr %l13, !tbaa !21
  br i1 %t39, label %bb14, label %bb15
bb14:
  %t40 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2etoNormal(ptr %v0, ptr %t40)
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb17
bb17:
  %t42 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2edraw(ptr %v0, ptr %t42)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eLoad(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i32
  %l25 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l37 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i64
  %l43 = alloca { i64, ptr }
  %l53 = alloca i64
  %l59 = alloca i32
  %l60 = alloca ptr
  %l63 = alloca i64
  %l68 = alloca %"std/prelude/text:StringBuilder"
  %l71 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l81 = alloca ptr
  %l83 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l94 = alloca i32
  %l96 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s9 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l14, !tbaa !29
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = load ptr, ptr %l14, !tbaa !29
  %t4 = getelementptr %"compiler/lineedit:Editor", ptr %t3, i32 0, i32 8
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  store { i64, ptr } %t5, ptr %l16, !tbaa !27
  %t7 = load ptr, ptr %l14, !tbaa !29
  %t8 = getelementptr %"compiler/lineedit:Editor", ptr %t7, i32 0, i32 8
  store { i64, ptr } %t2, ptr %t8, !tbaa !27
  %t9 = load i1, ptr @olang_2esole_2ecompiler_2flineedit_3aEditor_2e8
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load { i64, ptr }, ptr %l16
  %t12 = extractvalue { i64, ptr } %t11, 1
  call void @__olang_region_release(ptr %t12)
  store { i64, ptr } zeroinitializer, ptr %l16
  br label %bb2
bb2:
  %t13 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t15 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v1, ptr %s0, { i64, ptr } %t13)
  %t16 = extractvalue { i32, { i64, ptr } } %t15, 1
  %t17 = extractvalue { i32, { i64, ptr } } %t15, 0
  store i32 %t17, ptr %l21
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb4, label %ok.19, !prof !99
ok.19:
  store { i64, ptr } %t16, ptr %l20
  br label %bb3
bb3:
  %t20 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t20, ptr %l18, !tbaa !27
  br label %bb8
bb4:
  %t21 = load i32, ptr %l21, !tbaa !23
  %t22 = ashr i32 %t21, 16
  %t24 = icmp eq i32 %t22, 1
  br i1 %t24, label %bb5, label %bb6
bb5:
  call void @__olang_errpay_pop()
  br label %bb6
bb6:
  br label %bb7
bb7:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr %l18, !tbaa !27
  br label %bb8
bb8:
  %t26 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t29 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t26, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store { i64, ptr } %t29, ptr %l25
  br label %bb9
bb9:
  %t30 = load { i64, ptr }, ptr %l25, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  store { i64, ptr } %t30, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  store i64 %t35, ptr %l7, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load i64, ptr %l7, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb12:
  br label %bb13
bb13:
  %t45 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t45, ptr %l33, !tbaa !27
  %t46 = load i64, ptr %l6, !tbaa !24
  %t48 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr { i64, ptr }, ptr %t49, i64 %t46
  %t51 = load { i64, ptr }, ptr %t50, !tbaa !37
  store { i64, ptr } %t51, ptr %l8, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t55 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s2, { i64, ptr } %t53, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store i1 %t55, ptr %l37
  br label %bb14
bb14:
  %t56 = load i1, ptr %l37, !tbaa !21
  br i1 %t56, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb16:
  br label %bb17
bb17:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/lineedit:Editor", ptr %t57, i32 0, i32 7
  store ptr %t59, ptr %l39, !tbaa !29
  %t60 = call ptr @__olang_scope_hold(ptr %v0)
  %t61 = ptrtoint ptr %t60 to i64
  store i64 %t61, ptr %l40, !tbaa !24
  %t62 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t62, label %bb18, label %bb19
bb18:
  %t64 = call ptr @__olang_region_make(ptr %v0)
  %t65 = ptrtoint ptr %t64 to i64
  store i64 %t65, ptr %l40, !tbaa !24
  br label %bb19
bb19:
  %t66 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t67 = load i64, ptr %l40
  %t68 = inttoptr i64 %t67 to ptr
  %t70 = call { i64, ptr } @compiler_2flineedit_2edecode(ptr %s0, ptr %t68, { i64, ptr } %t66)
  store { i64, ptr } %t70, ptr %l43
  br label %bb20
bb20:
  %t71 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t72 = load ptr, ptr %l39, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t72, { i64, ptr } %t71)
  br label %bb21
bb21:
  %t74 = load i64, ptr %l4, !tbaa !24
  %t77 = add i64 %t74, 1
  store i64 %t77, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb22:
  %t79 = load i64, ptr %l6, !tbaa !24
  %t82 = add i64 %t79, 1
  store i64 %t82, ptr %l6, !tbaa !24
  br label %bb10
bb23:
  br label %bb24
bb24:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/lineedit:Editor", ptr %t84, i32 0, i32 7
  %t88 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t86)
  store i64 %t88, ptr %l53
  br label %bb25
bb25:
  %t89 = load i64, ptr @G_2ecompiler_2flineedit_2eKeep, !tbaa !24
  %t90 = load i64, ptr %l53, !tbaa !24
  %t92 = icmp sgt i64 %t90, %t89
  %t94 = xor i1 %t92, true
  br i1 %t94, label %bb26, label %bb27
bb26:
  br label %bb34
bb27:
  br label %bb28
bb28:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/lineedit:Editor", ptr %t96, i32 0, i32 7
  %t100 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H9ea329edf73de23cd280575fae6d500d(ptr %v0, ptr %t98, i64 0)
  store i32 %t100, ptr %l59
  %t101 = icmp ne i32 %t100, 0
  br i1 %t101, label %bb30, label %ok.102, !prof !99
ok.102:
  br label %bb29
bb29:
  br label %bb32
bb30:
  br label %bb31
bb31:
  br label %bb32
bb32:
  br label %bb33
bb33:
  br label %bb24
bb34:
  %t103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t103, ptr %l60, !tbaa !29
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/lineedit:Editor", ptr %t104, i32 0, i32 7
  %t108 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t106)
  store i64 %t108, ptr %l63
  br label %bb35
bb35:
  %t109 = load i64, ptr %l63, !tbaa !24
  %t110 = load ptr, ptr %l60, !tbaa !29
  %t111 = getelementptr %"compiler/lineedit:Editor", ptr %t110, i32 0, i32 12
  store i64 %t109, ptr %t111, !tbaa !24
  %t112 = load i64, ptr %l4, !tbaa !24
  %t113 = load i64, ptr @G_2ecompiler_2flineedit_2eKeep, !tbaa !24
  %t115 = mul i64 2, %t113
  %t118 = icmp sle i64 %t112, %t115
  br i1 %t118, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb37:
  br label %bb38
bb38:
  %t120 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t120, ptr %l68
  br label %bb39
bb39:
  %t121 = load %"std/prelude/text:StringBuilder", ptr %l68
  store %"std/prelude/text:StringBuilder" %t121, ptr %l9
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/lineedit:Editor", ptr %t122, i32 0, i32 7
  %t126 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H563b551a62b57e684177c5454e33a204(ptr %v0, ptr %v0, ptr %t124)
  store { i64, ptr } %t126, ptr %l71
  br label %bb40
bb40:
  %t127 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t127, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t128 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t130 = extractvalue { i64, ptr } %t128, 0
  store i64 %t130, ptr %l12, !tbaa !24
  br label %bb41
bb41:
  store %olang.scope zeroinitializer, ptr %s9
  %t132 = load i64, ptr %l11, !tbaa !24
  %t133 = load i64, ptr %l12, !tbaa !24
  %t136 = icmp slt i64 %t132, %t133
  %t138 = xor i1 %t136, true
  br i1 %t138, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s9)
  br label %bb48
bb43:
  br label %bb44
bb44:
  %t140 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t140, ptr %l78, !tbaa !27
  %t141 = load i64, ptr %l11, !tbaa !24
  %t143 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !27
  %t145 = getelementptr { i64, ptr }, ptr %t144, i64 %t141
  %t146 = load { i64, ptr }, ptr %t145, !tbaa !37
  store ptr %l9, ptr %l81, !tbaa !29
  %t150 = call { i64, ptr } @compiler_2flineedit_2eencode(ptr %v0, ptr %s9, { i64, ptr } %t146)
  store { i64, ptr } %t150, ptr %l83
  br label %bb45
bb45:
  %t151 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t152 = extractvalue { i64, ptr } %t151, 1
  %t153 = extractvalue { i64, ptr } %t151, 0
  %t154 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t155 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t156 = add i64 %t153, %t155
  %t157 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t156)
  call void @olang_textcopy(ptr %t157, ptr %t152, i64 %t153)
  %t158 = getelementptr i8, ptr %t157, i64 %t153
  call void @olang_textcopy(ptr %t158, ptr %t154, i64 %t155)
  %t159 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t157, 1
  %t162 = load ptr, ptr %l81, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s9, ptr %t162, { i64, ptr } %t160)
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s9)
  br label %bb47
bb47:
  %t164 = load i64, ptr %l11, !tbaa !24
  %t167 = add i64 %t164, 1
  store i64 %t167, ptr %l11, !tbaa !24
  br label %bb41
bb48:
  %t169 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t169, ptr %l89, !tbaa !27
  %t171 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l9)
  store { i64, ptr } %t171, ptr %l91
  br label %bb49
bb49:
  %t172 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t174 = extractvalue { i64, ptr } %t172, 0
  %t175 = extractvalue { i64, ptr } %t172, 1
  %t176 = mul i64 %t174, 1
  %t177 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t176)
  call void @llvm.memcpy.p0.p0.i64(ptr %t177, ptr %t175, i64 %t176, i1 false)
  %t178 = insertvalue { i64, ptr } undef, i64 %t174, 0
  %t179 = insertvalue { i64, ptr } %t178, ptr %t177, 1
  %t180 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t182 = call i32 @std_2fos_2eWriteFile(ptr %v1, ptr %s0, { i64, ptr } %t180, { i64, ptr } %t179)
  store i32 %t182, ptr %l94
  %t183 = icmp ne i32 %t182, 0
  br i1 %t183, label %bb51, label %ok.184, !prof !99
ok.184:
  br label %bb50
bb50:
  br label %bb55
bb51:
  %t185 = load i32, ptr %l94, !tbaa !23
  %t186 = ashr i32 %t185, 16
  %t188 = icmp eq i32 %t186, 1
  store i1 %t188, ptr %l96, !tbaa !21
  %t189 = load i32, ptr %l94, !tbaa !23
  %t190 = ashr i32 %t189, 16
  %t192 = icmp eq i32 %t190, 1
  br i1 %t192, label %bb52, label %bb53
bb52:
  call void @__olang_errpay_pop()
  br label %bb53
bb53:
  br label %bb54
bb54:
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i32, { i64, ptr } } @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eRead(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1c, ptr %a1e) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"<termios.h>:termios"
  %l3 = alloca %"<termios.h>:termios"
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"<termios.h>:termios"
  %l7 = alloca i32
  %l47 = alloca i32
  %l50 = alloca ptr
  %l51 = alloca i64
  %l55 = alloca i64
  %l58 = alloca i64
  %l61 = alloca i32
  %l62 = alloca i32
  %l68 = alloca i32
  %l69 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l73 = alloca i32
  %l74 = alloca i32
  %l80 = alloca i32
  %l84 = alloca { i64, ptr }
  %l90 = alloca i32
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  %pf1 = insertvalue { ptr, ptr } undef, ptr %a1c, 0
  %pg1 = insertvalue { ptr, ptr } %pf1, ptr %a1e, 1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"<termios.h>:termios" @olang_2emir_2eHelperKind_2eZero_2e_3ctermios_2eh_3e_3atermios()
  store %"<termios.h>:termios" %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = load %"<termios.h>:termios", ptr %l5
  store %"<termios.h>:termios" %t2, ptr %l2
  %t4 = call i32 @tcgetattr(i32 0, ptr %l2)
  store i32 %t4, ptr %l7
  br label %bb2
bb2:
  %t5 = load i32, ptr %l7, !tbaa !23
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t9 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t9, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t10 = load %"<termios.h>:termios", ptr %l2
  store %"<termios.h>:termios" %t10, ptr %l3
  %t12 = getelementptr %"<termios.h>:termios", ptr %l3, i32 0, i32 0
  %t13 = load i32, ptr %t12, !tbaa !64
  %t15 = load i32, ptr @G_2e_3ctermios_2eh_3e_2eBRKINT, !tbaa !23
  %t16 = load i32, ptr @G_2e_3ctermios_2eh_3e_2eICRNL, !tbaa !23
  %t19 = or i32 %t15, %t16
  %t20 = load i32, ptr @G_2e_3ctermios_2eh_3e_2eINPCK, !tbaa !23
  %t23 = or i32 %t19, %t20
  %t24 = load i32, ptr @G_2e_3ctermios_2eh_3e_2eISTRIP, !tbaa !23
  %t27 = or i32 %t23, %t24
  %t28 = load i32, ptr @G_2e_3ctermios_2eh_3e_2eIXON, !tbaa !23
  %t31 = or i32 %t27, %t28
  %t34 = xor i32 %t31, -1
  %t37 = and i32 %t13, %t34
  %t39 = getelementptr %"<termios.h>:termios", ptr %l3, i32 0, i32 0
  store i32 %t37, ptr %t39, !tbaa !64
  %t40 = getelementptr %"<termios.h>:termios", ptr %l3, i32 0, i32 1
  %t41 = load i32, ptr %t40, !tbaa !64
  %t43 = load i32, ptr @G_2e_3ctermios_2eh_3e_2eOPOST, !tbaa !23
  %t46 = xor i32 %t43, -1
  %t49 = and i32 %t41, %t46
  %t51 = getelementptr %"<termios.h>:termios", ptr %l3, i32 0, i32 1
  store i32 %t49, ptr %t51, !tbaa !64
  %t52 = getelementptr %"<termios.h>:termios", ptr %l3, i32 0, i32 3
  %t53 = load i32, ptr %t52, !tbaa !64
  %t55 = load i32, ptr @G_2e_3ctermios_2eh_3e_2eECHO, !tbaa !23
  %t56 = load i32, ptr @G_2e_3ctermios_2eh_3e_2eICANON, !tbaa !23
  %t59 = or i32 %t55, %t56
  %t60 = load i32, ptr @G_2e_3ctermios_2eh_3e_2eIEXTEN, !tbaa !23
  %t63 = or i32 %t59, %t60
  %t64 = load i32, ptr @G_2e_3ctermios_2eh_3e_2eISIG, !tbaa !23
  %t67 = or i32 %t63, %t64
  %t70 = xor i32 %t67, -1
  %t73 = and i32 %t53, %t70
  %t75 = getelementptr %"<termios.h>:termios", ptr %l3, i32 0, i32 3
  store i32 %t73, ptr %t75, !tbaa !64
  %t76 = load i32, ptr @G_2e_3ctermios_2eh_3e_2eVMIN, !tbaa !23
  %t77 = getelementptr %"<termios.h>:termios", ptr %l3, i32 0, i32 5
  %t79 = sext i32 %t76 to i64
  %t80 = getelementptr [32 x i8], ptr %t77, i64 0, i64 %t79
  store i8 1, ptr %t80, !tbaa !32
  %t81 = load i32, ptr @G_2e_3ctermios_2eh_3e_2eVTIME, !tbaa !23
  %t82 = getelementptr %"<termios.h>:termios", ptr %l3, i32 0, i32 5
  %t84 = sext i32 %t81 to i64
  %t85 = getelementptr [32 x i8], ptr %t82, i64 0, i64 %t84
  store i8 0, ptr %t85, !tbaa !32
  %t86 = load i32, ptr @G_2e_3ctermios_2eh_3e_2eTCSANOW, !tbaa !23
  %t89 = call i32 @tcsetattr(i32 0, i32 %t86, ptr %l3)
  store i32 %t89, ptr %l47
  br label %bb6
bb6:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/lineedit:Editor", ptr %t90, i32 0, i32 6
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t92, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d13, i32 0, i32 1) })
  br label %bb7
bb7:
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l50, !tbaa !29
  %t95 = call i64 @compiler_2flineedit_2ecolumns()
  store i64 %t95, ptr %l51
  br label %bb8
bb8:
  %t96 = load i64, ptr %l51, !tbaa !24
  %t97 = load ptr, ptr %l50, !tbaa !29
  %t98 = getelementptr %"compiler/lineedit:Editor", ptr %t97, i32 0, i32 2
  store i64 %t96, ptr %t98, !tbaa !24
  %t99 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eBegin(ptr %v0, ptr %t99)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t101 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eflush(ptr %v0, ptr %t101)
  br label %bb11
bb11:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/lineedit:Editor", ptr %t103, i32 0, i32 36
  %t106 = load i64, ptr %t105, !tbaa !24
  store i64 %t106, ptr %l55, !tbaa !24
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/lineedit:Editor", ptr %t107, i32 0, i32 35
  %t111 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eLen_3cU8_3e(ptr %v0, ptr %t109)
  store i64 %t111, ptr %l58
  br label %bb12
bb12:
  %t112 = load i64, ptr %l55, !tbaa !24
  %t113 = load i64, ptr %l58, !tbaa !24
  %t114 = icmp sge i64 %t112, %t113
  br i1 %t114, label %bb13, label %bb14
bb13:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = call i32 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2efill(ptr %v0, ptr %t116)
  store i32 %t118, ptr %l61
  %t119 = icmp ne i32 %t118, 0
  br i1 %t119, label %bb16, label %ok.120, !prof !99
ok.120:
  br label %bb15
bb14:
  br label %bb21
bb15:
  br label %bb20
bb16:
  %t121 = load i32, ptr %l61, !tbaa !23
  %t122 = lshr i32 %t121, 16
  %t123 = and i32 %t121, 65535
  %t124 = icmp eq i32 %t122, 1
  %t125 = select i1 %t124, i32 1, i32 0
  %t126 = icmp eq i32 %t121, 0
  %t127 = shl i32 %t125, 16
  %t128 = or i32 %t127, %t123
  %t129 = select i1 %t126, i32 0, i32 %t128
  store i32 %t129, ptr %l62, !tbaa !23
  store %olang.scope zeroinitializer, ptr %s5
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/lineedit:Editor", ptr %t130, i32 0, i32 6
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s5, ptr %t132, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d14, i32 0, i32 1) })
  br label %bb17
bb17:
  %t134 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eflush(ptr %v0, ptr %t134)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s5)
  %t136 = load i32, ptr @G_2e_3ctermios_2eh_3e_2eTCSANOW, !tbaa !23
  %t139 = call i32 @tcsetattr(i32 0, i32 %t136, ptr %l2)
  store i32 %t139, ptr %l68
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  %t140 = load i32, ptr %l62, !tbaa !23
  %t141 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t140, 0
  store { i32, { i64, ptr } } %t141, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t146 = extractvalue { ptr, ptr } %pg1, 0
  %t147 = extractvalue { ptr, ptr } %pg1, 1
  %t148 = call { i32, { i64, ptr } } @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2efeedPending(ptr %v0, ptr %v1, ptr %v2, ptr %t142, ptr %t146, ptr %t147)
  %t149 = extractvalue { i32, { i64, ptr } } %t148, 1
  %t150 = extractvalue { i32, { i64, ptr } } %t148, 0
  store i32 %t150, ptr %l73
  %t151 = icmp ne i32 %t150, 0
  br i1 %t151, label %bb23, label %ok.152, !prof !99
ok.152:
  store { i64, ptr } %t149, ptr %l72
  br label %bb22
bb22:
  %t153 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t153, ptr %l69, !tbaa !27
  br label %bb27
bb23:
  %t154 = load i32, ptr %l73, !tbaa !23
  %t155 = lshr i32 %t154, 16
  %t156 = and i32 %t154, 65535
  %t157 = icmp eq i32 %t155, 1
  %t158 = select i1 %t157, i32 1, i32 0
  %t159 = icmp eq i32 %t154, 0
  %t160 = shl i32 %t158, 16
  %t161 = or i32 %t160, %t156
  %t162 = select i1 %t159, i32 0, i32 %t161
  store i32 %t162, ptr %l74, !tbaa !23
  store %olang.scope zeroinitializer, ptr %s8
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/lineedit:Editor", ptr %t163, i32 0, i32 6
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s8, ptr %t165, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d14, i32 0, i32 1) })
  br label %bb24
bb24:
  %t167 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eflush(ptr %v0, ptr %t167)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s8)
  %t169 = load i32, ptr @G_2e_3ctermios_2eh_3e_2eTCSANOW, !tbaa !23
  %t172 = call i32 @tcsetattr(i32 0, i32 %t169, ptr %l2)
  store i32 %t172, ptr %l80
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  %t173 = load i32, ptr %l74, !tbaa !23
  %t174 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t173, 0
  store { i32, { i64, ptr } } %t174, ptr %rv
  br label %ret
bb27:
  %t175 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t175, ptr %l4, !tbaa !27
  %t176 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t176, 0
  %t179 = extractvalue { i64, ptr } { i64 -1, ptr null }, 0
  %t180 = icmp eq i64 %t178, %t179
  %t181 = extractvalue { i64, ptr } %t176, 1
  %t182 = extractvalue { i64, ptr } { i64 -1, ptr null }, 1
  %t183 = icmp eq ptr %t181, %t182
  %t184 = and i1 %t180, %t183
  %t186 = xor i1 %t184, true
  br i1 %t186, label %bb28, label %bb29
bb28:
  %t188 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t188, ptr %l84, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s12
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/lineedit:Editor", ptr %t189, i32 0, i32 6
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s12, ptr %t191, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d14, i32 0, i32 1) })
  br label %bb30
bb29:
  br label %bb33
bb30:
  %t193 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eflush(ptr %v0, ptr %t193)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s12)
  %t195 = load i32, ptr @G_2e_3ctermios_2eh_3e_2eTCSANOW, !tbaa !23
  %t198 = call i32 @tcsetattr(i32 0, i32 %t195, ptr %l2)
  store i32 %t198, ptr %l90
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s0)
  %t199 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t200 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t199, 1
  store { i32, { i64, ptr } } %t200, ptr %rv
  br label %ret
bb33:
  br label %bb34
bb34:
  br label %bb10
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eRemember(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l7 = alloca i64
  %l9 = alloca i1
  %l11 = alloca ptr
  %l14 = alloca i64
  %l16 = alloca { i64, ptr }
  %l18 = alloca i1
  %l24 = alloca i64
  %l29 = alloca i32
  %l30 = alloca ptr
  %l33 = alloca i64
  %l36 = alloca i1
  %l39 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v1, ptr %v1, { i64, ptr } %t1)
  store { i64, ptr } %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t4, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i1 %t5, ptr %l4
  br label %bb2
bb2:
  %t6 = load i1, ptr %l4, !tbaa !21
  br i1 %t6, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  br label %bb5
bb5:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/lineedit:Editor", ptr %t7, i32 0, i32 7
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l7
  br label %bb6
bb6:
  %t12 = load i64, ptr %l7, !tbaa !24
  %t13 = icmp sgt i64 %t12, 0
  br i1 %t13, label %bb7, label %bb8
bb7:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/lineedit:Editor", ptr %t15, i32 0, i32 7
  store ptr %t17, ptr %l11, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/lineedit:Editor", ptr %t18, i32 0, i32 7
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t20)
  store i64 %t22, ptr %l14
  br label %bb9
bb8:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb12
bb9:
  %t23 = load i64, ptr %l14, !tbaa !24
  %t24 = sub i64 %t23, 1
  %t25 = load ptr, ptr %l11, !tbaa !29
  %t27 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t25, i64 %t24)
  store { i64, ptr } %t27, ptr %l16
  br label %bb10
bb10:
  %t28 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t31 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t29, { i64, ptr } %t28)
  store i1 %t31, ptr %l18
  br label %bb11
bb11:
  %t32 = load i1, ptr %l18, !tbaa !21
  store i1 %t32, ptr %l9, !tbaa !21
  br label %bb12
bb12:
  %t33 = load i1, ptr %l9, !tbaa !21
  br i1 %t33, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb14:
  br label %bb15
bb15:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/lineedit:Editor", ptr %t34, i32 0, i32 7
  %t37 = load { i64, ptr }, ptr %l1, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %t36, { i64, ptr } %t37)
  br label %bb16
bb16:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/lineedit:Editor", ptr %t40, i32 0, i32 7
  %t44 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t42)
  store i64 %t44, ptr %l24
  br label %bb17
bb17:
  %t45 = load i64, ptr @G_2ecompiler_2flineedit_2eKeep, !tbaa !24
  %t46 = load i64, ptr %l24, !tbaa !24
  %t48 = icmp sgt i64 %t46, %t45
  br i1 %t48, label %bb18, label %bb19
bb18:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/lineedit:Editor", ptr %t50, i32 0, i32 7
  %t54 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H9ea329edf73de23cd280575fae6d500d(ptr %v0, ptr %t52, i64 0)
  store i32 %t54, ptr %l29
  %t55 = icmp ne i32 %t54, 0
  br i1 %t55, label %bb21, label %ok.56, !prof !99
ok.56:
  br label %bb20
bb19:
  br label %bb24
bb20:
  br label %bb23
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l30, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/lineedit:Editor", ptr %t58, i32 0, i32 7
  %t62 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t60)
  store i64 %t62, ptr %l33
  br label %bb25
bb25:
  %t63 = load i64, ptr %l33, !tbaa !24
  %t64 = load ptr, ptr %l30, !tbaa !29
  %t65 = getelementptr %"compiler/lineedit:Editor", ptr %t64, i32 0, i32 12
  store i64 %t63, ptr %t65, !tbaa !24
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/lineedit:Editor", ptr %t66, i32 0, i32 8
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  %t71 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t69, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d16, i32 0, i32 1) })
  store i1 %t71, ptr %l36
  br label %bb26
bb26:
  %t72 = load i1, ptr %l36, !tbaa !21
  %t73 = xor i1 %t72, true
  br i1 %t73, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s5
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/lineedit:Editor", ptr %t75, i32 0, i32 8
  %t78 = load { i64, ptr }, ptr %t77, !tbaa !27
  store { i64, ptr } %t78, ptr %l39, !tbaa !27
  %t79 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t81 = call { i64, ptr } @compiler_2flineedit_2eencode(ptr %v1, ptr %s5, { i64, ptr } %t79)
  store { i64, ptr } %t81, ptr %l41
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t82 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t83 = load { i64, ptr }, ptr %l39, !tbaa !27
  call void @compiler_2flineedit_2eappendLine(ptr %v0, ptr %s5, { i64, ptr } %t83, { i64, ptr } %t82)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eagain(ptr %v0, ptr %a0, i1 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l2 = alloca i1
  %l5 = alloca i1
  %l10 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l19 = alloca i64
  %l21 = alloca i64
  %l23 = alloca ptr
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i1 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lineedit:Editor", ptr %t1, i32 0, i32 26
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t4, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d17, i32 0, i32 1) })
  store i1 %t6, ptr %l5
  br label %bb1
bb1:
  %t7 = load i1, ptr %l5, !tbaa !21
  br i1 %t7, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/lineedit:Editor", ptr %t8, i32 0, i32 24
  %t11 = load i1, ptr %t10, !tbaa !21
  %t12 = load i1, ptr %l1, !tbaa !21
  %t15 = icmp eq i1 %t11, %t12
  store i1 %t15, ptr %l2, !tbaa !21
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l10, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/lineedit:Editor", ptr %t18, i32 0, i32 26
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  %t22 = load ptr, ptr %l10, !tbaa !29
  %t23 = getelementptr %"compiler/lineedit:Editor", ptr %t22, i32 0, i32 25
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  store { i64, ptr } %t24, ptr %l13, !tbaa !27
  %t26 = load ptr, ptr %l10, !tbaa !29
  %t27 = getelementptr %"compiler/lineedit:Editor", ptr %t26, i32 0, i32 25
  store { i64, ptr } %t21, ptr %t27, !tbaa !27
  %t28 = load i1, ptr @olang_2esole_2ecompiler_2flineedit_3aEditor_2e25
  br i1 %t28, label %bb5, label %bb6
bb5:
  %t30 = load { i64, ptr }, ptr %l13
  %t31 = extractvalue { i64, ptr } %t30, 1
  call void @__olang_region_release(ptr %t31)
  store { i64, ptr } zeroinitializer, ptr %l13
  br label %bb6
bb6:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i1, ptr %l2, !tbaa !21
  %t36 = getelementptr %"compiler/lineedit:Editor", ptr %t32, i32 0, i32 24
  store i1 %t33, ptr %t36, !tbaa !21
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l17, !tbaa !29
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/lineedit:Editor", ptr %t38, i32 0, i32 12
  %t41 = load i64, ptr %t40, !tbaa !24
  store i64 %t41, ptr %l19, !tbaa !24
  %t42 = load i1, ptr %l2, !tbaa !21
  br i1 %t42, label %bb7, label %bb8
bb7:
  store i64 -1, ptr %l21, !tbaa !24
  br label %bb9
bb8:
  store i64 1, ptr %l21, !tbaa !24
  br label %bb9
bb9:
  %t44 = load i64, ptr %l19, !tbaa !24
  %t45 = load i64, ptr %l21, !tbaa !24
  %t46 = add i64 %t44, %t45
  %t47 = load ptr, ptr %l17, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2efind(ptr %v0, ptr %t47, i64 %t46)
  br label %bb10
bb10:
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l23, !tbaa !29
  %t50 = load ptr, ptr %l23, !tbaa !29
  %t51 = getelementptr %"compiler/lineedit:Editor", ptr %t50, i32 0, i32 24
  %t52 = load i1, ptr %t51, !tbaa !21
  %t54 = load i1, ptr %l1, !tbaa !21
  %t57 = icmp eq i1 %t52, %t54
  %t59 = load ptr, ptr %l23, !tbaa !29
  %t60 = getelementptr %"compiler/lineedit:Editor", ptr %t59, i32 0, i32 24
  store i1 %t57, ptr %t60, !tbaa !21
  %t61 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eclamp(ptr %v0, ptr %t61)
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2ebackBy(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l15 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l47 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lineedit:Editor", ptr %t1, i32 0, i32 4
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lineedit:Editor", ptr %t6, i32 0, i32 3
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  %t10 = load i64, ptr %l2, !tbaa !24
  %t13 = call i64 @compiler_2flineedit_2elineStart(ptr %v0, { i64, ptr } %t9, i64 %t10)
  store i64 %t13, ptr %l15
  br label %bb1
bb1:
  %t14 = load i64, ptr %l15, !tbaa !24
  store i64 %t14, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  store i64 %a1, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t17 = load i64, ptr %l5, !tbaa !24
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = icmp sgt i64 %t17, %t18
  br i1 %t21, label %bb2, label %bb3
bb2:
  %t23 = load i64, ptr %l6, !tbaa !24
  %t25 = icmp sgt i64 %t23, 0
  br i1 %t25, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb7
bb4:
  %t27 = load i64, ptr %l5, !tbaa !24
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = sub i64 %t27, %t28
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = add i64 %t31, %t32
  %t37 = sub i64 %t35, 1
  %t38 = load i64, ptr %l6, !tbaa !24
  %t41 = sdiv i64 %t37, %t38
  store i64 %t41, ptr %l23, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb6
bb6:
  %t43 = load i64, ptr %l23, !tbaa !24
  store i64 %t43, ptr %l20, !tbaa !24
  br label %bb7
bb7:
  %t44 = load i64, ptr %l20, !tbaa !24
  store i64 %t44, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  %t45 = load i64, ptr %l8, !tbaa !24
  %t46 = load i64, ptr %l7, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb9, label %bb10
bb9:
  br label %bb17
bb10:
  br label %bb11
bb11:
  %t53 = load i64, ptr %l4, !tbaa !24
  %t54 = load i64, ptr %l8, !tbaa !24
  %t55 = load i64, ptr %l6, !tbaa !24
  %t58 = mul i64 %t54, %t55
  %t61 = add i64 %t53, %t58
  store i64 %t61, ptr %l9, !tbaa !24
  %t63 = load i64, ptr %l2, !tbaa !24
  %t64 = load i64, ptr %l3, !tbaa !24
  %t67 = icmp sgt i64 %t63, %t64
  br i1 %t67, label %bb12, label %bb13
bb12:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/lineedit:Editor", ptr %t69, i32 0, i32 3
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  %t73 = load i64, ptr %l2, !tbaa !24
  %t76 = call i64 @compiler_2flineedit_2eprevAt(ptr %v0, { i64, ptr } %t72, i64 %t73)
  store i64 %t76, ptr %l47
  br label %bb14
bb13:
  br label %bb15
bb14:
  %t77 = load i64, ptr %l47, !tbaa !24
  store i64 %t77, ptr %l2, !tbaa !24
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t78 = load i64, ptr %l8, !tbaa !24
  %t81 = add i64 %t78, 1
  store i64 %t81, ptr %l8, !tbaa !24
  br label %bb8
bb17:
  %t83 = load i64, ptr %l2, !tbaa !24
  store i64 %t83, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2ebracket(ptr %v0, ptr %a0, i1 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l10 = alloca i1
  %l12 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l24 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i1 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i1, ptr %l1, !tbaa !21
  %t5 = getelementptr %"compiler/lineedit:Editor", ptr %t1, i32 0, i32 22
  store i1 %t2, ptr %t5, !tbaa !21
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i1, ptr %l1, !tbaa !21
  %t10 = getelementptr %"compiler/lineedit:Editor", ptr %t6, i32 0, i32 20
  store i1 %t7, ptr %t10, !tbaa !21
  %t11 = load i1, ptr %l1, !tbaa !21
  br i1 %t11, label %bb1, label %bb2
bb1:
  store i32 0, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/lineedit:Editor", ptr %t14, i32 0, i32 3
  %t17 = load { i64, ptr }, ptr %t16, !tbaa !27
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s2, { i64, ptr } %t17, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) })
  store i1 %t19, ptr %l10
  br label %bb5
bb5:
  %t20 = load i1, ptr %l10, !tbaa !21
  %t21 = xor i1 %t20, true
  br i1 %t21, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb7:
  br label %bb8
bb8:
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l12, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/lineedit:Editor", ptr %t24, i32 0, i32 3
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %l14, !tbaa !27
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/lineedit:Editor", ptr %t28, i32 0, i32 3
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t35 = sub i64 %t33, 1
  store i64 %t35, ptr %l18, !tbaa !24
  %t36 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 0
  store i64 %t37, ptr %l19, !tbaa !24
  %t38 = icmp sge i64 0, 0
  br i1 %t38, label %bb9, label %bb10
bb9:
  %t40 = load i64, ptr %l18, !tbaa !24
  %t41 = icmp sle i64 0, %t40
  br i1 %t41, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_d9375333dfb29074_4c1db221b9426bf0)
  unreachable
bb11:
  %t43 = load i64, ptr %l18, !tbaa !24
  %t44 = load i64, ptr %l19, !tbaa !24
  %t45 = icmp sle i64 %t43, %t44
  br i1 %t45, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_d9375333dfb29074_4c1db221b9426bf0)
  unreachable
bb13:
  %t47 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = load i64, ptr %l18, !tbaa !24
  %t50 = getelementptr i8, ptr %t48, i64 0
  %t51 = sub i64 %t49, 0
  %t52 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t50, 1
  %t54 = load ptr, ptr %l12, !tbaa !29
  %t55 = getelementptr %"compiler/lineedit:Editor", ptr %t54, i32 0, i32 3
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l24, !tbaa !27
  %t58 = load ptr, ptr %l12, !tbaa !29
  %t59 = getelementptr %"compiler/lineedit:Editor", ptr %t58, i32 0, i32 3
  store { i64, ptr } %t53, ptr %t59, !tbaa !27
  %t60 = load i1, ptr @olang_2esole_2ecompiler_2flineedit_3aEditor_2e3
  br i1 %t60, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_d9375333dfb29074_4c1db221b9426bf0)
  unreachable
bb15:
  %t62 = load { i64, ptr }, ptr %l24
  %t63 = extractvalue { i64, ptr } %t62, 1
  call void @__olang_region_release(ptr %t63)
  store { i64, ptr } zeroinitializer, ptr %l24
  br label %bb16
bb16:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/lineedit:Editor", ptr %t64, i32 0, i32 4
  %t67 = load i64, ptr %t66, !tbaa !24
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/lineedit:Editor", ptr %t68, i32 0, i32 3
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t71, 0
  %t76 = icmp sgt i64 %t67, %t73
  br i1 %t76, label %bb17, label %bb18
bb17:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/lineedit:Editor", ptr %t79, i32 0, i32 3
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t82, 0
  %t87 = getelementptr %"compiler/lineedit:Editor", ptr %t78, i32 0, i32 4
  store i64 %t84, ptr %t87, !tbaa !24
  br label %bb19
bb18:
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb20:
  br label %bb4
bb21:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/lineedit:Editor", ptr %t88, i32 0, i32 0
  %t91 = load i1, ptr %t90, !tbaa !21
  br i1 %t91, label %bb22, label %bb23
bb22:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/lineedit:Editor", ptr %t93, i32 0, i32 5
  store i1 false, ptr %t95, !tbaa !21
  br label %bb24
bb23:
  br label %bb24
bb24:
  store i32 2, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2ecommand(ptr %v0, ptr %a0, i8 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i8
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l26 = alloca i1
  %l29 = alloca i1
  %l38 = alloca ptr
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %l43 = alloca i64
  %l47 = alloca i64
  %l49 = alloca i64
  %l52 = alloca ptr
  %l55 = alloca i64
  %l60 = alloca i1
  %l63 = alloca ptr
  %l65 = alloca i64
  %l69 = alloca i64
  %l76 = alloca i64
  %l81 = alloca i64
  %l84 = alloca i64
  %l108 = alloca i1
  %l117 = alloca i64
  %l122 = alloca i64
  %l125 = alloca i64
  %l149 = alloca i64
  %l154 = alloca i64
  %l157 = alloca i64
  %l181 = alloca i1
  %l189 = alloca i1
  %l197 = alloca i1
  %l200 = alloca i1
  %l203 = alloca i1
  %l206 = alloca i1
  %l209 = alloca i1
  %l212 = alloca i1
  %l219 = alloca i1
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i8 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lineedit:Editor", ptr %t1, i32 0, i32 3
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  %t6 = load i8, ptr %l1, !tbaa !22
  %t8 = icmp eq i8 %t6, 100
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb3
bb2:
  %t10 = load i8, ptr %l1, !tbaa !22
  %t12 = icmp eq i8 %t10, 99
  store i1 %t12, ptr %l26, !tbaa !21
  br label %bb3
bb3:
  %t14 = load i1, ptr %l26, !tbaa !21
  br i1 %t14, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb6
bb5:
  %t15 = load i8, ptr %l1, !tbaa !22
  %t17 = icmp eq i8 %t15, 114
  store i1 %t17, ptr %l29, !tbaa !21
  br label %bb6
bb6:
  %t19 = load i1, ptr %l29, !tbaa !21
  br i1 %t19, label %bb7, label %bb8
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i8, ptr %l1, !tbaa !22
  %t24 = getelementptr %"compiler/lineedit:Editor", ptr %t20, i32 0, i32 33
  store i8 %t21, ptr %t24, !tbaa !22
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i64, ptr %l2, !tbaa !24
  %t29 = getelementptr %"compiler/lineedit:Editor", ptr %t25, i32 0, i32 34
  store i64 %t26, ptr %t29, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t30 = load i8, ptr %l1, !tbaa !22
  %t32 = icmp eq i8 %t30, 120
  br i1 %t32, label %bb10, label %bb11
bb10:
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l38, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/lineedit:Editor", ptr %t35, i32 0, i32 4
  %t38 = load i64, ptr %t37, !tbaa !24
  store i64 %t38, ptr %l40, !tbaa !24
  %t39 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t39, ptr %l41, !tbaa !27
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/lineedit:Editor", ptr %t40, i32 0, i32 4
  %t43 = load i64, ptr %t42, !tbaa !24
  store i64 %t43, ptr %l43, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/lineedit:Editor", ptr %t45, i32 0, i32 4
  %t48 = load i64, ptr %t47, !tbaa !24
  %t51 = call i64 @compiler_2flineedit_2elineEnd(ptr %v0, { i64, ptr } %t44, i64 %t48)
  store i64 %t51, ptr %l47
  br label %bb12
bb11:
  br label %bb15
bb12:
  %t52 = load i64, ptr %l2, !tbaa !24
  %t53 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t54 = load i64, ptr %l43, !tbaa !24
  %t55 = load i64, ptr %l47, !tbaa !24
  %t57 = call i64 @compiler_2flineedit_2eoffsetOf(ptr %v0, { i64, ptr } %t53, i64 %t54, i64 %t55, i64 %t52)
  store i64 %t57, ptr %l49
  br label %bb13
bb13:
  %t58 = load ptr, ptr %l38, !tbaa !29
  %t59 = load i64, ptr %l40, !tbaa !24
  %t60 = load i64, ptr %l49, !tbaa !24
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eremove(ptr %v0, ptr %t58, i64 %t59, i64 %t60, i1 true)
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t61 = load i8, ptr %l1, !tbaa !22
  %t63 = icmp eq i8 %t61, 88
  br i1 %t63, label %bb16, label %bb17
bb16:
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l52, !tbaa !29
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load i64, ptr %l2, !tbaa !24
  %t70 = call i64 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2ebackBy(ptr %v0, ptr %t66, i64 %t67)
  store i64 %t70, ptr %l55
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/lineedit:Editor", ptr %t71, i32 0, i32 4
  %t74 = load i64, ptr %t73, !tbaa !24
  %t75 = load ptr, ptr %l52, !tbaa !29
  %t76 = load i64, ptr %l55, !tbaa !24
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eremove(ptr %v0, ptr %t75, i64 %t76, i64 %t74, i1 true)
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t78 = load i8, ptr %l1, !tbaa !22
  %t80 = icmp eq i8 %t78, 68
  br i1 %t80, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb23
bb22:
  %t82 = load i8, ptr %l1, !tbaa !22
  %t84 = icmp eq i8 %t82, 67
  store i1 %t84, ptr %l60, !tbaa !21
  br label %bb23
bb23:
  %t86 = load i1, ptr %l60, !tbaa !21
  br i1 %t86, label %bb24, label %bb25
bb24:
  %t87 = load ptr, ptr %l0, !tbaa !29
  store ptr %t87, ptr %l63, !tbaa !29
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/lineedit:Editor", ptr %t88, i32 0, i32 4
  %t91 = load i64, ptr %t90, !tbaa !24
  store i64 %t91, ptr %l65, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/lineedit:Editor", ptr %t93, i32 0, i32 4
  %t96 = load i64, ptr %t95, !tbaa !24
  %t99 = call i64 @compiler_2flineedit_2elineEnd(ptr %v0, { i64, ptr } %t92, i64 %t96)
  store i64 %t99, ptr %l69
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t100 = load ptr, ptr %l63, !tbaa !29
  %t101 = load i64, ptr %l65, !tbaa !24
  %t102 = load i64, ptr %l69, !tbaa !24
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eremove(ptr %v0, ptr %t100, i64 %t101, i64 %t102, i1 true)
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t103 = load i8, ptr %l1, !tbaa !22
  %t105 = icmp eq i8 %t103, 126
  br i1 %t105, label %bb29, label %bb30
bb29:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2etoggle(ptr %v0, ptr %t107, i64 %t108)
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb32
bb32:
  store i64 0, ptr %l4, !tbaa !24
  %t111 = load i8, ptr %l1, !tbaa !22
  %t113 = icmp eq i8 %t111, 117
  br i1 %t113, label %bb33, label %bb34
bb33:
  %t115 = load i64, ptr %l2, !tbaa !24
  store i64 %t115, ptr %l76, !tbaa !24
  br label %bb35
bb34:
  store i64 0, ptr %l76, !tbaa !24
  br label %bb35
bb35:
  %t117 = load i64, ptr %l76, !tbaa !24
  store i64 %t117, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t118 = load i64, ptr %l5, !tbaa !24
  %t119 = load i64, ptr %l4, !tbaa !24
  %t122 = icmp sgt i64 %t118, %t119
  br i1 %t122, label %bb36, label %bb37
bb36:
  %t124 = load i64, ptr %l6, !tbaa !24
  %t126 = icmp sgt i64 %t124, 0
  br i1 %t126, label %bb38, label %bb39
bb37:
  store i64 0, ptr %l81, !tbaa !24
  br label %bb41
bb38:
  %t128 = load i64, ptr %l5, !tbaa !24
  %t129 = load i64, ptr %l4, !tbaa !24
  %t132 = sub i64 %t128, %t129
  %t133 = load i64, ptr %l6, !tbaa !24
  %t136 = add i64 %t132, %t133
  %t138 = sub i64 %t136, 1
  %t139 = load i64, ptr %l6, !tbaa !24
  %t142 = sdiv i64 %t138, %t139
  store i64 %t142, ptr %l84, !tbaa !24
  br label %bb40
bb39:
  store i64 0, ptr %l84, !tbaa !24
  br label %bb40
bb40:
  %t144 = load i64, ptr %l84, !tbaa !24
  store i64 %t144, ptr %l81, !tbaa !24
  br label %bb41
bb41:
  %t145 = load i64, ptr %l81, !tbaa !24
  store i64 %t145, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb42
bb42:
  %t146 = load i64, ptr %l8, !tbaa !24
  %t147 = load i64, ptr %l7, !tbaa !24
  %t150 = icmp slt i64 %t146, %t147
  %t152 = xor i1 %t150, true
  br i1 %t152, label %bb43, label %bb44
bb43:
  br label %bb48
bb44:
  br label %bb45
bb45:
  %t154 = load i64, ptr %l4, !tbaa !24
  %t155 = load i64, ptr %l8, !tbaa !24
  %t156 = load i64, ptr %l6, !tbaa !24
  %t159 = mul i64 %t155, %t156
  %t162 = add i64 %t154, %t159
  store i64 %t162, ptr %l9, !tbaa !24
  %t164 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eundo(ptr %v0, ptr %t164)
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t166 = load i64, ptr %l8, !tbaa !24
  %t169 = add i64 %t166, 1
  store i64 %t169, ptr %l8, !tbaa !24
  br label %bb42
bb48:
  %t171 = load i8, ptr %l1, !tbaa !22
  %t173 = icmp eq i8 %t171, 112
  br i1 %t173, label %bb49, label %bb50
bb49:
  store i1 true, ptr %l108, !tbaa !21
  br label %bb51
bb50:
  %t175 = load i8, ptr %l1, !tbaa !22
  %t177 = icmp eq i8 %t175, 80
  store i1 %t177, ptr %l108, !tbaa !21
  br label %bb51
bb51:
  %t179 = load i1, ptr %l108, !tbaa !21
  br i1 %t179, label %bb52, label %bb53
bb52:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load i8, ptr %l1, !tbaa !22
  %t183 = icmp eq i8 %t181, 112
  %t184 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2epaste(ptr %v0, ptr %t180, i1 %t183, i64 %t184)
  br label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb55
bb55:
  store i64 0, ptr %l10, !tbaa !24
  %t188 = load i8, ptr %l1, !tbaa !22
  %t190 = icmp eq i8 %t188, 106
  br i1 %t190, label %bb56, label %bb57
bb56:
  %t192 = load i64, ptr %l2, !tbaa !24
  store i64 %t192, ptr %l117, !tbaa !24
  br label %bb58
bb57:
  store i64 0, ptr %l117, !tbaa !24
  br label %bb58
bb58:
  %t194 = load i64, ptr %l117, !tbaa !24
  store i64 %t194, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t195 = load i64, ptr %l11, !tbaa !24
  %t196 = load i64, ptr %l10, !tbaa !24
  %t199 = icmp sgt i64 %t195, %t196
  br i1 %t199, label %bb59, label %bb60
bb59:
  %t201 = load i64, ptr %l12, !tbaa !24
  %t203 = icmp sgt i64 %t201, 0
  br i1 %t203, label %bb61, label %bb62
bb60:
  store i64 0, ptr %l122, !tbaa !24
  br label %bb64
bb61:
  %t205 = load i64, ptr %l11, !tbaa !24
  %t206 = load i64, ptr %l10, !tbaa !24
  %t209 = sub i64 %t205, %t206
  %t210 = load i64, ptr %l12, !tbaa !24
  %t213 = add i64 %t209, %t210
  %t215 = sub i64 %t213, 1
  %t216 = load i64, ptr %l12, !tbaa !24
  %t219 = sdiv i64 %t215, %t216
  store i64 %t219, ptr %l125, !tbaa !24
  br label %bb63
bb62:
  store i64 0, ptr %l125, !tbaa !24
  br label %bb63
bb63:
  %t221 = load i64, ptr %l125, !tbaa !24
  store i64 %t221, ptr %l122, !tbaa !24
  br label %bb64
bb64:
  %t222 = load i64, ptr %l122, !tbaa !24
  store i64 %t222, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb65
bb65:
  %t223 = load i64, ptr %l14, !tbaa !24
  %t224 = load i64, ptr %l13, !tbaa !24
  %t227 = icmp slt i64 %t223, %t224
  %t229 = xor i1 %t227, true
  br i1 %t229, label %bb66, label %bb67
bb66:
  br label %bb71
bb67:
  br label %bb68
bb68:
  %t231 = load i64, ptr %l10, !tbaa !24
  %t232 = load i64, ptr %l14, !tbaa !24
  %t233 = load i64, ptr %l12, !tbaa !24
  %t236 = mul i64 %t232, %t233
  %t239 = add i64 %t231, %t236
  store i64 %t239, ptr %l15, !tbaa !24
  %t241 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2edown(ptr %v0, ptr %t241)
  br label %bb69
bb69:
  br label %bb70
bb70:
  %t243 = load i64, ptr %l14, !tbaa !24
  %t246 = add i64 %t243, 1
  store i64 %t246, ptr %l14, !tbaa !24
  br label %bb65
bb71:
  store i64 0, ptr %l16, !tbaa !24
  %t248 = load i8, ptr %l1, !tbaa !22
  %t250 = icmp eq i8 %t248, 107
  br i1 %t250, label %bb72, label %bb73
bb72:
  %t252 = load i64, ptr %l2, !tbaa !24
  store i64 %t252, ptr %l149, !tbaa !24
  br label %bb74
bb73:
  store i64 0, ptr %l149, !tbaa !24
  br label %bb74
bb74:
  %t254 = load i64, ptr %l149, !tbaa !24
  store i64 %t254, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t255 = load i64, ptr %l17, !tbaa !24
  %t256 = load i64, ptr %l16, !tbaa !24
  %t259 = icmp sgt i64 %t255, %t256
  br i1 %t259, label %bb75, label %bb76
bb75:
  %t261 = load i64, ptr %l18, !tbaa !24
  %t263 = icmp sgt i64 %t261, 0
  br i1 %t263, label %bb77, label %bb78
bb76:
  store i64 0, ptr %l154, !tbaa !24
  br label %bb80
bb77:
  %t265 = load i64, ptr %l17, !tbaa !24
  %t266 = load i64, ptr %l16, !tbaa !24
  %t269 = sub i64 %t265, %t266
  %t270 = load i64, ptr %l18, !tbaa !24
  %t273 = add i64 %t269, %t270
  %t275 = sub i64 %t273, 1
  %t276 = load i64, ptr %l18, !tbaa !24
  %t279 = sdiv i64 %t275, %t276
  store i64 %t279, ptr %l157, !tbaa !24
  br label %bb79
bb78:
  store i64 0, ptr %l157, !tbaa !24
  br label %bb79
bb79:
  %t281 = load i64, ptr %l157, !tbaa !24
  store i64 %t281, ptr %l154, !tbaa !24
  br label %bb80
bb80:
  %t282 = load i64, ptr %l154, !tbaa !24
  store i64 %t282, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb81
bb81:
  %t283 = load i64, ptr %l20, !tbaa !24
  %t284 = load i64, ptr %l19, !tbaa !24
  %t287 = icmp slt i64 %t283, %t284
  %t289 = xor i1 %t287, true
  br i1 %t289, label %bb82, label %bb83
bb82:
  br label %bb87
bb83:
  br label %bb84
bb84:
  %t291 = load i64, ptr %l16, !tbaa !24
  %t292 = load i64, ptr %l20, !tbaa !24
  %t293 = load i64, ptr %l18, !tbaa !24
  %t296 = mul i64 %t292, %t293
  %t299 = add i64 %t291, %t296
  store i64 %t299, ptr %l21, !tbaa !24
  %t301 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eup(ptr %v0, ptr %t301)
  br label %bb85
bb85:
  br label %bb86
bb86:
  %t303 = load i64, ptr %l20, !tbaa !24
  %t306 = add i64 %t303, 1
  store i64 %t306, ptr %l20, !tbaa !24
  br label %bb81
bb87:
  %t308 = load i8, ptr %l1, !tbaa !22
  %t310 = icmp eq i8 %t308, 47
  br i1 %t310, label %bb88, label %bb89
bb88:
  store i1 true, ptr %l181, !tbaa !21
  br label %bb90
bb89:
  %t312 = load i8, ptr %l1, !tbaa !22
  %t314 = icmp eq i8 %t312, 63
  store i1 %t314, ptr %l181, !tbaa !21
  br label %bb90
bb90:
  %t316 = load i1, ptr %l181, !tbaa !21
  br i1 %t316, label %bb91, label %bb92
bb91:
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t318 = load i8, ptr %l1, !tbaa !22
  %t320 = icmp eq i8 %t318, 47
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2ebeginSearch(ptr %v0, ptr %t317, i1 %t320, i1 true)
  br label %bb93
bb92:
  br label %bb94
bb93:
  br label %bb94
bb94:
  %t323 = load i8, ptr %l1, !tbaa !22
  %t325 = icmp eq i8 %t323, 110
  br i1 %t325, label %bb95, label %bb96
bb95:
  store i1 true, ptr %l189, !tbaa !21
  br label %bb97
bb96:
  %t327 = load i8, ptr %l1, !tbaa !22
  %t329 = icmp eq i8 %t327, 78
  store i1 %t329, ptr %l189, !tbaa !21
  br label %bb97
bb97:
  %t331 = load i1, ptr %l189, !tbaa !21
  br i1 %t331, label %bb98, label %bb99
bb98:
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t333 = load i8, ptr %l1, !tbaa !22
  %t335 = icmp eq i8 %t333, 110
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eagain(ptr %v0, ptr %t332, i1 %t335)
  br label %bb100
bb99:
  br label %bb101
bb100:
  br label %bb101
bb101:
  %t338 = load i8, ptr %l1, !tbaa !22
  %t340 = icmp eq i8 %t338, 105
  br i1 %t340, label %bb102, label %bb103
bb102:
  store i1 true, ptr %l197, !tbaa !21
  br label %bb104
bb103:
  %t342 = load i8, ptr %l1, !tbaa !22
  %t344 = icmp eq i8 %t342, 97
  store i1 %t344, ptr %l197, !tbaa !21
  br label %bb104
bb104:
  %t346 = load i1, ptr %l197, !tbaa !21
  br i1 %t346, label %bb105, label %bb106
bb105:
  store i1 true, ptr %l200, !tbaa !21
  br label %bb107
bb106:
  %t347 = load i8, ptr %l1, !tbaa !22
  %t349 = icmp eq i8 %t347, 73
  store i1 %t349, ptr %l200, !tbaa !21
  br label %bb107
bb107:
  %t351 = load i1, ptr %l200, !tbaa !21
  br i1 %t351, label %bb108, label %bb109
bb108:
  store i1 true, ptr %l203, !tbaa !21
  br label %bb110
bb109:
  %t352 = load i8, ptr %l1, !tbaa !22
  %t354 = icmp eq i8 %t352, 65
  store i1 %t354, ptr %l203, !tbaa !21
  br label %bb110
bb110:
  %t356 = load i1, ptr %l203, !tbaa !21
  br i1 %t356, label %bb111, label %bb112
bb111:
  store i1 true, ptr %l206, !tbaa !21
  br label %bb113
bb112:
  %t357 = load i8, ptr %l1, !tbaa !22
  %t359 = icmp eq i8 %t357, 67
  store i1 %t359, ptr %l206, !tbaa !21
  br label %bb113
bb113:
  %t361 = load i1, ptr %l206, !tbaa !21
  br i1 %t361, label %bb114, label %bb115
bb114:
  store i1 true, ptr %l209, !tbaa !21
  br label %bb116
bb115:
  %t362 = load i8, ptr %l1, !tbaa !22
  %t364 = icmp eq i8 %t362, 111
  store i1 %t364, ptr %l209, !tbaa !21
  br label %bb116
bb116:
  %t366 = load i1, ptr %l209, !tbaa !21
  br i1 %t366, label %bb117, label %bb118
bb117:
  store i1 true, ptr %l212, !tbaa !21
  br label %bb119
bb118:
  %t367 = load i8, ptr %l1, !tbaa !22
  %t369 = icmp eq i8 %t367, 79
  store i1 %t369, ptr %l212, !tbaa !21
  br label %bb119
bb119:
  %t371 = load i1, ptr %l212, !tbaa !21
  br i1 %t371, label %bb120, label %bb121
bb120:
  %t372 = load ptr, ptr %l0, !tbaa !29
  %t373 = load i8, ptr %l1, !tbaa !22
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eenter(ptr %v0, ptr %t372, i8 %t373)
  br label %bb122
bb121:
  br label %bb123
bb122:
  br label %bb123
bb123:
  %t376 = load ptr, ptr %l0, !tbaa !29
  %t378 = getelementptr %"compiler/lineedit:Editor", ptr %t376, i32 0, i32 5
  %t379 = load i1, ptr %t378, !tbaa !21
  br i1 %t379, label %bb124, label %bb125
bb124:
  %t381 = load ptr, ptr %l0, !tbaa !29
  %t383 = getelementptr %"compiler/lineedit:Editor", ptr %t381, i32 0, i32 21
  %t384 = load i1, ptr %t383, !tbaa !21
  %t386 = xor i1 %t384, true
  store i1 %t386, ptr %l219, !tbaa !21
  br label %bb126
bb125:
  store i1 false, ptr %l219, !tbaa !21
  br label %bb126
bb126:
  %t388 = load i1, ptr %l219, !tbaa !21
  br i1 %t388, label %bb127, label %bb128
bb127:
  %t389 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eclamp(ptr %v0, ptr %t389)
  br label %bb129
bb128:
  br label %bb130
bb129:
  br label %bb130
bb130:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2edone(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call { i64, ptr } @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eAccept(ptr %v0, ptr %v1, ptr %t1)
  store { i64, ptr } %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  %t5 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eflush(ptr %v0, ptr %t5)
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t7, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2edraw(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l19 = alloca { i64, ptr }
  %l22 = alloca i64
  %l36 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l52 = alloca i64
  %l60 = alloca i64
  %l63 = alloca i64
  %l83 = alloca { i64, ptr }
  %l101 = alloca { i64, ptr }
  %l107 = alloca i64
  %l108 = alloca { i64, ptr }
  %l111 = alloca i64
  %l117 = alloca i1
  %l121 = alloca { i64, ptr }
  %l128 = alloca i64
  %l129 = alloca { i64, ptr }
  %l131 = alloca { i64, ptr }
  %l135 = alloca i64
  %l136 = alloca i64
  %l141 = alloca i64
  %l154 = alloca { i64, ptr }
  %l174 = alloca { i64, ptr }
  %l181 = alloca i64
  %l194 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s16 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lineedit:Editor", ptr %t1, i32 0, i32 14
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp sgt i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/lineedit:Editor", ptr %t8, i32 0, i32 6
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/lineedit:Editor", ptr %t11, i32 0, i32 14
  %t14 = load i64, ptr %t13, !tbaa !24
  %t15 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t18 = call i64 @__olang_fmt_i64(ptr null, i64 %t14)
  %t19 = add i64 %t16, %t18
  %t20 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t22 = add i64 %t19, %t21
  %t23 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t22)
  call void @olang_textcopy(ptr %t23, ptr %t15, i64 %t16)
  %t24 = getelementptr i8, ptr %t23, i64 %t16
  %t25 = call i64 @__olang_fmt_i64(ptr %t24, i64 %t14)
  %t26 = getelementptr i8, ptr %t24, i64 %t18
  call void @olang_textcopy(ptr %t26, ptr %t20, i64 %t21)
  %t27 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t23, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s1, ptr %t10, { i64, ptr } %t28)
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  br label %bb4
bb4:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/lineedit:Editor", ptr %t32, i32 0, i32 6
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t34, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d21, i32 0, i32 1) })
  br label %bb5
bb5:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/lineedit:Editor", ptr %t36, i32 0, i32 3
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  %t41 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %s0, ptr %s0, { i64, ptr } %t39, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) })
  store { i64, ptr } %t41, ptr %l36
  br label %bb6
bb6:
  %t42 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t42, ptr %l1, !tbaa !27
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/lineedit:Editor", ptr %t43, i32 0, i32 1
  %t46 = load i1, ptr %t45, !tbaa !21
  br i1 %t46, label %bb7, label %bb8
bb7:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/lineedit:Editor", ptr %t48, i32 0, i32 3
  %t51 = load { i64, ptr }, ptr %t50, !tbaa !27
  %t53 = call { i64, ptr } @compiler_2fpaint_2eSource(ptr %v0, ptr %s0, { i64, ptr } %t51)
  store { i64, ptr } %t53, ptr %l42
  br label %bb9
bb8:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/lineedit:Editor", ptr %t54, i32 0, i32 3
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t57, 1
  %t60 = extractvalue { i64, ptr } %t57, 0
  %t61 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t60)
  call void @olang_textcopy(ptr %t61, ptr %t59, i64 %t60)
  %t62 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t61, 1
  store { i64, ptr } %t63, ptr %l39, !tbaa !27
  br label %bb10
bb9:
  %t66 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t66, ptr %l39, !tbaa !27
  br label %bb10
bb10:
  %t68 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t69 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t68, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d23, i32 0, i32 1) })
  store { i64, ptr } %t69, ptr %l48
  br label %bb11
bb11:
  %t70 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t70, ptr %l2, !tbaa !27
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/lineedit:Editor", ptr %t71, i32 0, i32 2
  %t74 = load i64, ptr %t73, !tbaa !24
  %t76 = icmp sgt i64 %t74, 0
  br i1 %t76, label %bb12, label %bb13
bb12:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/lineedit:Editor", ptr %t78, i32 0, i32 2
  %t81 = load i64, ptr %t80, !tbaa !24
  store i64 %t81, ptr %l52, !tbaa !24
  br label %bb14
bb13:
  store i64 9223372036854775807, ptr %l52, !tbaa !24
  br label %bb14
bb14:
  %t83 = load i64, ptr %l52, !tbaa !24
  store i64 %t83, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  %t84 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t84, 0
  store i64 %t86, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t88 = load i64, ptr %l10, !tbaa !24
  %t89 = load i64, ptr %l9, !tbaa !24
  %t92 = icmp sgt i64 %t88, %t89
  br i1 %t92, label %bb15, label %bb16
bb15:
  %t94 = load i64, ptr %l11, !tbaa !24
  %t96 = icmp sgt i64 %t94, 0
  br i1 %t96, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l60, !tbaa !24
  br label %bb20
bb17:
  %t98 = load i64, ptr %l10, !tbaa !24
  %t99 = load i64, ptr %l9, !tbaa !24
  %t102 = sub i64 %t98, %t99
  %t103 = load i64, ptr %l11, !tbaa !24
  %t106 = add i64 %t102, %t103
  %t108 = sub i64 %t106, 1
  %t109 = load i64, ptr %l11, !tbaa !24
  %t112 = sdiv i64 %t108, %t109
  store i64 %t112, ptr %l63, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l63, !tbaa !24
  br label %bb19
bb19:
  %t114 = load i64, ptr %l63, !tbaa !24
  store i64 %t114, ptr %l60, !tbaa !24
  br label %bb20
bb20:
  %t115 = load i64, ptr %l60, !tbaa !24
  store i64 %t115, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s5
  %t116 = load i64, ptr %l13, !tbaa !24
  %t117 = load i64, ptr %l12, !tbaa !24
  %t120 = icmp slt i64 %t116, %t117
  %t122 = xor i1 %t120, true
  br i1 %t122, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s5)
  br label %bb51
bb23:
  br label %bb24
bb24:
  %t124 = load i64, ptr %l9, !tbaa !24
  %t125 = load i64, ptr %l13, !tbaa !24
  %t126 = load i64, ptr %l11, !tbaa !24
  %t129 = mul i64 %t125, %t126
  %t132 = add i64 %t124, %t129
  store i64 %t132, ptr %l14, !tbaa !24
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load i64, ptr %l14, !tbaa !24
  %t138 = call { i64, ptr } @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2epromptOf(ptr %v0, ptr %v0, ptr %t134, i64 %t135)
  store { i64, ptr } %t138, ptr %l83
  br label %bb25
bb25:
  %t139 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t139, ptr %l15, !tbaa !27
  %t140 = load i64, ptr %l14, !tbaa !24
  %t142 = icmp sgt i64 %t140, 0
  br i1 %t142, label %bb26, label %bb27
bb26:
  %t144 = load i64, ptr %l4, !tbaa !24
  %t146 = load i64, ptr %l8, !tbaa !24
  %t148 = sub i64 %t146, 1
  %t149 = load i64, ptr %l3, !tbaa !24
  %t152 = sdiv i64 %t148, %t149
  %t154 = add i64 %t152, 1
  %t157 = add i64 %t144, %t154
  store i64 %t157, ptr %l4, !tbaa !24
  br label %bb28
bb27:
  br label %bb28
bb28:
  %t159 = load i64, ptr %l14, !tbaa !24
  %t161 = icmp sgt i64 %t159, 0
  br i1 %t161, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s7
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/lineedit:Editor", ptr %t163, i32 0, i32 6
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s7, ptr %t165, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d24, i32 0, i32 1) })
  br label %bb31
bb30:
  br label %bb32
bb31:
  call void @__olang_scope_close(ptr %s7)
  br label %bb32
bb32:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/lineedit:Editor", ptr %t167, i32 0, i32 6
  %t170 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t171 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t171, ptr %l101, !tbaa !27
  %t172 = load i64, ptr %l14, !tbaa !24
  %t174 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t175 = load ptr, ptr %t174, !tbaa !27
  %t176 = getelementptr { i64, ptr }, ptr %t175, i64 %t172
  %t177 = load { i64, ptr }, ptr %t176, !tbaa !37
  %t179 = extractvalue { i64, ptr } %t170, 1
  %t180 = extractvalue { i64, ptr } %t170, 0
  %t182 = extractvalue { i64, ptr } %t177, 1
  %t183 = extractvalue { i64, ptr } %t177, 0
  %t184 = add i64 %t180, %t183
  %t185 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t184)
  call void @olang_textcopy(ptr %t185, ptr %t179, i64 %t180)
  %t186 = getelementptr i8, ptr %t185, i64 %t180
  call void @olang_textcopy(ptr %t186, ptr %t182, i64 %t183)
  %t187 = insertvalue { i64, ptr } undef, i64 %t184, 0
  %t188 = insertvalue { i64, ptr } %t187, ptr %t185, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s5, ptr %t169, { i64, ptr } %t188)
  br label %bb33
bb33:
  %t192 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t194 = call i64 @compiler_2flineedit_2ecells(ptr %v0, { i64, ptr } %t192)
  store i64 %t194, ptr %l107
  br label %bb34
bb34:
  %t195 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t195, ptr %l108, !tbaa !27
  %t196 = load i64, ptr %l14, !tbaa !24
  %t198 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !27
  %t200 = getelementptr { i64, ptr }, ptr %t199, i64 %t196
  %t201 = load { i64, ptr }, ptr %t200, !tbaa !37
  %t203 = call i64 @compiler_2flineedit_2ecells(ptr %s0, { i64, ptr } %t201)
  store i64 %t203, ptr %l111
  br label %bb35
bb35:
  %t204 = load i64, ptr %l107, !tbaa !24
  %t205 = load i64, ptr %l111, !tbaa !24
  %t206 = add i64 %t204, %t205
  store i64 %t206, ptr %l8, !tbaa !24
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/lineedit:Editor", ptr %t208, i32 0, i32 4
  %t211 = load i64, ptr %t210, !tbaa !24
  %t212 = load i64, ptr %l5, !tbaa !24
  %t215 = icmp sge i64 %t211, %t212
  br i1 %t215, label %bb36, label %bb37
bb36:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t219 = getelementptr %"compiler/lineedit:Editor", ptr %t217, i32 0, i32 4
  %t220 = load i64, ptr %t219, !tbaa !24
  %t221 = load i64, ptr %l5, !tbaa !24
  %t222 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t222, ptr %l121, !tbaa !27
  %t223 = load i64, ptr %l14, !tbaa !24
  %t225 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !27
  %t227 = getelementptr { i64, ptr }, ptr %t226, i64 %t223
  %t228 = load { i64, ptr }, ptr %t227, !tbaa !37
  %t230 = extractvalue { i64, ptr } %t228, 0
  %t233 = add i64 %t221, %t230
  %t236 = icmp sle i64 %t220, %t233
  store i1 %t236, ptr %l117, !tbaa !21
  br label %bb38
bb37:
  store i1 false, ptr %l117, !tbaa !21
  br label %bb38
bb38:
  %t238 = load i1, ptr %l117, !tbaa !21
  br i1 %t238, label %bb39, label %bb40
bb39:
  %t239 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t241 = call i64 @compiler_2flineedit_2ecells(ptr %v0, { i64, ptr } %t239)
  store i64 %t241, ptr %l128
  br label %bb41
bb40:
  br label %bb49
bb41:
  %t242 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t242, ptr %l129, !tbaa !27
  %t243 = load i64, ptr %l14, !tbaa !24
  %t245 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t246 = load ptr, ptr %t245, !tbaa !27
  %t247 = getelementptr { i64, ptr }, ptr %t246, i64 %t243
  %t248 = load { i64, ptr }, ptr %t247, !tbaa !37
  store { i64, ptr } %t248, ptr %l131, !tbaa !27
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t251 = getelementptr %"compiler/lineedit:Editor", ptr %t249, i32 0, i32 4
  %t252 = load i64, ptr %t251, !tbaa !24
  %t253 = load i64, ptr %l5, !tbaa !24
  %t256 = sub i64 %t252, %t253
  store i64 %t256, ptr %l135, !tbaa !24
  %t257 = load { i64, ptr }, ptr %l131, !tbaa !27
  %t258 = extractvalue { i64, ptr } %t257, 0
  store i64 %t258, ptr %l136, !tbaa !24
  %t259 = icmp sge i64 0, 0
  br i1 %t259, label %bb42, label %bb43
bb42:
  %t261 = load i64, ptr %l135, !tbaa !24
  %t262 = icmp sle i64 0, %t261
  br i1 %t262, label %bb44, label %bb45
bb43:
  call void @__olang_check_failed(ptr @olang_loc_efd16dbbcc037fb0_1aeb292baa76ec64)
  unreachable
bb44:
  %t264 = load i64, ptr %l135, !tbaa !24
  %t265 = load i64, ptr %l136, !tbaa !24
  %t266 = icmp sle i64 %t264, %t265
  br i1 %t266, label %bb46, label %bb47
bb45:
  call void @__olang_check_failed(ptr @olang_loc_efd16dbbcc037fb0_1aeb292baa76ec64)
  unreachable
bb46:
  %t268 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t269 = load ptr, ptr %t268, !tbaa !27
  %t270 = load i64, ptr %l135, !tbaa !24
  %t271 = getelementptr i8, ptr %t269, i64 0
  %t272 = sub i64 %t270, 0
  %t273 = insertvalue { i64, ptr } undef, i64 %t272, 0
  %t274 = insertvalue { i64, ptr } %t273, ptr %t271, 1
  %t276 = call i64 @compiler_2flineedit_2ecells(ptr %s0, { i64, ptr } %t274)
  store i64 %t276, ptr %l141
  br label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_efd16dbbcc037fb0_1aeb292baa76ec64)
  unreachable
bb48:
  %t277 = load i64, ptr %l128, !tbaa !24
  %t278 = load i64, ptr %l141, !tbaa !24
  %t279 = add i64 %t277, %t278
  store i64 %t279, ptr %l16, !tbaa !24
  %t281 = load i64, ptr %l4, !tbaa !24
  %t282 = load i64, ptr %l16, !tbaa !24
  %t283 = load i64, ptr %l3, !tbaa !24
  %t286 = sdiv i64 %t282, %t283
  %t289 = add i64 %t281, %t286
  %t291 = load i64, ptr %l16, !tbaa !24
  %t292 = load i64, ptr %l3, !tbaa !24
  %t295 = srem i64 %t291, %t292
  store i64 %t289, ptr %l6, !tbaa !24
  store i64 %t295, ptr %l7, !tbaa !24
  br label %bb49
bb49:
  %t301 = load i64, ptr %l5, !tbaa !24
  %t302 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t302, ptr %l154, !tbaa !27
  %t303 = load i64, ptr %l14, !tbaa !24
  %t305 = getelementptr { i64, ptr }, ptr %l154, i32 0, i32 1
  %t306 = load ptr, ptr %t305, !tbaa !27
  %t307 = getelementptr { i64, ptr }, ptr %t306, i64 %t303
  %t308 = load { i64, ptr }, ptr %t307, !tbaa !37
  %t310 = extractvalue { i64, ptr } %t308, 0
  %t312 = add i64 %t310, 1
  %t315 = add i64 %t301, %t312
  store i64 %t315, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb50
bb50:
  %t317 = load i64, ptr %l13, !tbaa !24
  %t320 = add i64 %t317, 1
  store i64 %t320, ptr %l13, !tbaa !24
  br label %bb21
bb51:
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t324 = getelementptr %"compiler/lineedit:Editor", ptr %t322, i32 0, i32 21
  %t325 = load i1, ptr %t324, !tbaa !21
  br i1 %t325, label %bb52, label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s11
  %t327 = load i64, ptr %l4, !tbaa !24
  %t329 = load i64, ptr %l8, !tbaa !24
  %t331 = sub i64 %t329, 1
  %t332 = load i64, ptr %l3, !tbaa !24
  %t335 = sdiv i64 %t331, %t332
  %t337 = add i64 %t335, 1
  %t340 = add i64 %t327, %t337
  store i64 %t340, ptr %l4, !tbaa !24
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t344 = call { i64, ptr } @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2estatus(ptr %v0, ptr %s11, ptr %t342)
  store { i64, ptr } %t344, ptr %l174
  br label %bb54
bb53:
  br label %bb57
bb54:
  %t345 = load { i64, ptr }, ptr %l174, !tbaa !27
  store { i64, ptr } %t345, ptr %l19, !tbaa !27
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t348 = getelementptr %"compiler/lineedit:Editor", ptr %t346, i32 0, i32 6
  %t349 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t350 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t351 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t353 = extractvalue { i64, ptr } %t349, 1
  %t354 = extractvalue { i64, ptr } %t349, 0
  %t355 = add i64 %t351, %t354
  %t356 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t355)
  call void @olang_textcopy(ptr %t356, ptr %t350, i64 %t351)
  %t357 = getelementptr i8, ptr %t356, i64 %t351
  call void @olang_textcopy(ptr %t357, ptr %t353, i64 %t354)
  %t358 = insertvalue { i64, ptr } undef, i64 %t355, 0
  %t359 = insertvalue { i64, ptr } %t358, ptr %t356, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s11, ptr %t348, { i64, ptr } %t359)
  br label %bb55
bb55:
  %t363 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t365 = call i64 @compiler_2flineedit_2ecells(ptr %s11, { i64, ptr } %t363)
  store i64 %t365, ptr %l181
  br label %bb56
bb56:
  %t366 = load i64, ptr %l181, !tbaa !24
  store i64 %t366, ptr %l8, !tbaa !24
  %t367 = load i64, ptr %l4, !tbaa !24
  %t368 = load i64, ptr %l8, !tbaa !24
  %t369 = load i64, ptr %l3, !tbaa !24
  %t372 = sdiv i64 %t368, %t369
  %t375 = add i64 %t367, %t372
  %t377 = load i64, ptr %l8, !tbaa !24
  %t378 = load i64, ptr %l3, !tbaa !24
  %t381 = srem i64 %t377, %t378
  store i64 %t375, ptr %l6, !tbaa !24
  store i64 %t381, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s11)
  br label %bb57
bb57:
  %t387 = load i64, ptr %l8, !tbaa !24
  %t389 = icmp sgt i64 %t387, 0
  br i1 %t389, label %bb58, label %bb59
bb58:
  %t391 = load i64, ptr %l8, !tbaa !24
  %t392 = load i64, ptr %l3, !tbaa !24
  %t395 = srem i64 %t391, %t392
  %t397 = icmp eq i64 %t395, 0
  store i1 %t397, ptr %l194, !tbaa !21
  br label %bb60
bb59:
  store i1 false, ptr %l194, !tbaa !21
  br label %bb60
bb60:
  %t399 = load i1, ptr %l194, !tbaa !21
  br i1 %t399, label %bb61, label %bb62
bb61:
  store %olang.scope zeroinitializer, ptr %s13
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t402 = getelementptr %"compiler/lineedit:Editor", ptr %t400, i32 0, i32 6
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s13, ptr %t402, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d26, i32 0, i32 1) })
  br label %bb63
bb62:
  br label %bb64
bb63:
  call void @__olang_scope_close(ptr %s13)
  br label %bb64
bb64:
  %t404 = load i64, ptr %l4, !tbaa !24
  %t405 = load i64, ptr %l8, !tbaa !24
  %t406 = load i64, ptr %l3, !tbaa !24
  %t409 = sdiv i64 %t405, %t406
  %t412 = add i64 %t404, %t409
  %t413 = load i64, ptr %l6, !tbaa !24
  %t416 = sub i64 %t412, %t413
  store i64 %t416, ptr %l22, !tbaa !24
  %t418 = load i64, ptr %l22, !tbaa !24
  %t420 = icmp sgt i64 %t418, 0
  br i1 %t420, label %bb65, label %bb66
bb65:
  store %olang.scope zeroinitializer, ptr %s14
  %t422 = load ptr, ptr %l0, !tbaa !29
  %t424 = getelementptr %"compiler/lineedit:Editor", ptr %t422, i32 0, i32 6
  %t425 = load i64, ptr %l22, !tbaa !24
  %t426 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t427 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  %t429 = call i64 @__olang_fmt_i64(ptr null, i64 %t425)
  %t430 = add i64 %t427, %t429
  %t431 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t432 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  %t433 = add i64 %t430, %t432
  %t434 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t433)
  call void @olang_textcopy(ptr %t434, ptr %t426, i64 %t427)
  %t435 = getelementptr i8, ptr %t434, i64 %t427
  %t436 = call i64 @__olang_fmt_i64(ptr %t435, i64 %t425)
  %t437 = getelementptr i8, ptr %t435, i64 %t429
  call void @olang_textcopy(ptr %t437, ptr %t431, i64 %t432)
  %t438 = insertvalue { i64, ptr } undef, i64 %t433, 0
  %t439 = insertvalue { i64, ptr } %t438, ptr %t434, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s14, ptr %t424, { i64, ptr } %t439)
  br label %bb67
bb66:
  br label %bb68
bb67:
  call void @__olang_scope_close(ptr %s14)
  br label %bb68
bb68:
  %t443 = load ptr, ptr %l0, !tbaa !29
  %t445 = getelementptr %"compiler/lineedit:Editor", ptr %t443, i32 0, i32 6
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t445, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) })
  br label %bb69
bb69:
  %t447 = load i64, ptr %l7, !tbaa !24
  %t449 = icmp sgt i64 %t447, 0
  br i1 %t449, label %bb70, label %bb71
bb70:
  store %olang.scope zeroinitializer, ptr %s16
  %t451 = load ptr, ptr %l0, !tbaa !29
  %t453 = getelementptr %"compiler/lineedit:Editor", ptr %t451, i32 0, i32 6
  %t454 = load i64, ptr %l7, !tbaa !24
  %t455 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t456 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  %t458 = call i64 @__olang_fmt_i64(ptr null, i64 %t454)
  %t459 = add i64 %t456, %t458
  %t460 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t461 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t462 = add i64 %t459, %t461
  %t463 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t462)
  call void @olang_textcopy(ptr %t463, ptr %t455, i64 %t456)
  %t464 = getelementptr i8, ptr %t463, i64 %t456
  %t465 = call i64 @__olang_fmt_i64(ptr %t464, i64 %t454)
  %t466 = getelementptr i8, ptr %t464, i64 %t458
  call void @olang_textcopy(ptr %t466, ptr %t460, i64 %t461)
  %t467 = insertvalue { i64, ptr } undef, i64 %t462, 0
  %t468 = insertvalue { i64, ptr } %t467, ptr %t463, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s16, ptr %t453, { i64, ptr } %t468)
  br label %bb72
bb71:
  br label %bb73
bb72:
  call void @__olang_scope_close(ptr %s16)
  br label %bb73
bb73:
  %t472 = load ptr, ptr %l0, !tbaa !29
  %t473 = load i64, ptr %l6, !tbaa !24
  %t476 = getelementptr %"compiler/lineedit:Editor", ptr %t472, i32 0, i32 14
  store i64 %t473, ptr %t476, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eenter(ptr %v0, ptr %a0, i8 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i8
  %l2 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l10 = alloca i64
  %l13 = alloca ptr
  %l17 = alloca i64
  %l20 = alloca ptr
  %l24 = alloca i64
  %l27 = alloca ptr
  %l31 = alloca i64
  %l35 = alloca ptr
  %l39 = alloca i64
  %l41 = alloca ptr
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i8 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lineedit:Editor", ptr %t1, i32 0, i32 3
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lineedit:Editor", ptr %t6, i32 0, i32 5
  store i1 false, ptr %t8, !tbaa !21
  %t9 = load i8, ptr %l1, !tbaa !22
  %t11 = icmp eq i8 %t9, 97
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l8, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = call i64 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eright(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l10
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t17 = load i64, ptr %l10, !tbaa !24
  %t18 = load ptr, ptr %l8, !tbaa !29
  %t19 = getelementptr %"compiler/lineedit:Editor", ptr %t18, i32 0, i32 4
  store i64 %t17, ptr %t19, !tbaa !24
  br label %bb4
bb4:
  %t20 = load i8, ptr %l1, !tbaa !22
  %t22 = icmp eq i8 %t20, 73
  br i1 %t22, label %bb5, label %bb6
bb5:
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l13, !tbaa !29
  %t25 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/lineedit:Editor", ptr %t26, i32 0, i32 4
  %t29 = load i64, ptr %t28, !tbaa !24
  %t32 = call i64 @compiler_2flineedit_2efirstWord(ptr %v0, { i64, ptr } %t25, i64 %t29)
  store i64 %t32, ptr %l17
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t33 = load i64, ptr %l17, !tbaa !24
  %t34 = load ptr, ptr %l13, !tbaa !29
  %t35 = getelementptr %"compiler/lineedit:Editor", ptr %t34, i32 0, i32 4
  store i64 %t33, ptr %t35, !tbaa !24
  br label %bb8
bb8:
  %t36 = load i8, ptr %l1, !tbaa !22
  %t38 = icmp eq i8 %t36, 65
  br i1 %t38, label %bb9, label %bb10
bb9:
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l20, !tbaa !29
  %t41 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/lineedit:Editor", ptr %t42, i32 0, i32 4
  %t45 = load i64, ptr %t44, !tbaa !24
  %t48 = call i64 @compiler_2flineedit_2elineEnd(ptr %v0, { i64, ptr } %t41, i64 %t45)
  store i64 %t48, ptr %l24
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t49 = load i64, ptr %l24, !tbaa !24
  %t50 = load ptr, ptr %l20, !tbaa !29
  %t51 = getelementptr %"compiler/lineedit:Editor", ptr %t50, i32 0, i32 4
  store i64 %t49, ptr %t51, !tbaa !24
  br label %bb12
bb12:
  %t52 = load i8, ptr %l1, !tbaa !22
  %t54 = icmp eq i8 %t52, 111
  br i1 %t54, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l27, !tbaa !29
  %t57 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/lineedit:Editor", ptr %t58, i32 0, i32 4
  %t61 = load i64, ptr %t60, !tbaa !24
  %t64 = call i64 @compiler_2flineedit_2elineEnd(ptr %v0, { i64, ptr } %t57, i64 %t61)
  store i64 %t64, ptr %l31
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t65 = load i64, ptr %l31, !tbaa !24
  %t66 = load ptr, ptr %l27, !tbaa !29
  %t67 = getelementptr %"compiler/lineedit:Editor", ptr %t66, i32 0, i32 4
  store i64 %t65, ptr %t67, !tbaa !24
  %t68 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2einsert(ptr %v0, ptr %s4, ptr %t68, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) })
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s4)
  br label %bb17
bb17:
  %t70 = load i8, ptr %l1, !tbaa !22
  %t72 = icmp eq i8 %t70, 79
  br i1 %t72, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s5
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l35, !tbaa !29
  %t75 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/lineedit:Editor", ptr %t76, i32 0, i32 4
  %t79 = load i64, ptr %t78, !tbaa !24
  %t82 = call i64 @compiler_2flineedit_2elineStart(ptr %v0, { i64, ptr } %t75, i64 %t79)
  store i64 %t82, ptr %l39
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t83 = load i64, ptr %l39, !tbaa !24
  %t84 = load ptr, ptr %l35, !tbaa !29
  %t85 = getelementptr %"compiler/lineedit:Editor", ptr %t84, i32 0, i32 4
  store i64 %t83, ptr %t85, !tbaa !24
  %t86 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2einsert(ptr %v0, ptr %s5, ptr %t86, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d33, i32 0, i32 1) })
  br label %bb21
bb21:
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l41, !tbaa !29
  %t89 = load ptr, ptr %l41, !tbaa !29
  %t90 = getelementptr %"compiler/lineedit:Editor", ptr %t89, i32 0, i32 4
  %t91 = load i64, ptr %t90, !tbaa !24
  %t94 = sub i64 %t91, 1
  %t96 = load ptr, ptr %l41, !tbaa !29
  %t97 = getelementptr %"compiler/lineedit:Editor", ptr %t96, i32 0, i32 4
  store i64 %t94, ptr %t97, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb22
bb22:
  br label %ret
ret:
  ret void
}

define dso_local { i32, { i64, ptr } } @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2efeedPending(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1c, ptr %a1e) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { ptr, ptr }
  %l2 = alloca i32
  %l4 = alloca i64
  %l7 = alloca i64
  %l10 = alloca ptr
  %l15 = alloca i8
  %l16 = alloca i32
  %l17 = alloca ptr
  %l29 = alloca i1
  %l33 = alloca i1
  %l36 = alloca { i64, ptr }
  %l44 = alloca i1
  %l47 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  %pf1 = insertvalue { ptr, ptr } undef, ptr %a1c, 0
  %pg1 = insertvalue { ptr, ptr } %pf1, ptr %a1e, 1
  store { ptr, ptr } %pg1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  br label %bb1
bb1:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lineedit:Editor", ptr %t1, i32 0, i32 36
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l4, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/lineedit:Editor", ptr %t5, i32 0, i32 35
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eLen_3cU8_3e(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l7
  br label %bb2
bb2:
  %t10 = load i64, ptr %l4, !tbaa !24
  %t11 = load i64, ptr %l7, !tbaa !24
  %t12 = icmp slt i64 %t10, %t11
  %t14 = xor i1 %t12, true
  br i1 %t14, label %bb3, label %bb4
bb3:
  br label %bb31
bb4:
  br label %bb5
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l10, !tbaa !29
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/lineedit:Editor", ptr %t17, i32 0, i32 35
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/lineedit:Editor", ptr %t20, i32 0, i32 36
  %t23 = load i64, ptr %t22, !tbaa !24
  %t26 = call i8 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eAt_3cU8_3e(ptr %v0, ptr %t19, i64 %t23)
  store i8 %t26, ptr %l15
  br label %bb6
bb6:
  %t27 = load ptr, ptr %l10, !tbaa !29
  %t28 = load i8, ptr %l15, !tbaa !22
  %t29 = call i32 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eFeed(ptr %v0, ptr %t27, i8 %t28)
  store i32 %t29, ptr %l16
  br label %bb7
bb7:
  %t30 = load i32, ptr %l16, !range !{i32 0, i32 4}
  store i32 %t30, ptr %l2
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l17, !tbaa !29
  %t32 = load ptr, ptr %l17, !tbaa !29
  %t33 = getelementptr %"compiler/lineedit:Editor", ptr %t32, i32 0, i32 36
  %t34 = load i64, ptr %t33, !tbaa !24
  %t37 = add i64 %t34, 1
  %t39 = load ptr, ptr %l17, !tbaa !29
  %t40 = getelementptr %"compiler/lineedit:Editor", ptr %t39, i32 0, i32 36
  store i64 %t37, ptr %t40, !tbaa !24
  %t41 = load i32, ptr %l2, !range !{i32 0, i32 4}
  %t43 = trunc i64 3 to i32
  %t44 = icmp eq i32 %t41, %t43
  br i1 %t44, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/lineedit:Editor", ptr %t46, i32 0, i32 6
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s2, ptr %t48, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d34, i32 0, i32 1) })
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t50 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eflush(ptr %v0, ptr %t50)
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s2)
  %t53 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t53, ptr %rv
  br label %ret
bb12:
  %t54 = load i32, ptr %l2, !range !{i32 0, i32 4}
  %t56 = trunc i64 2 to i32
  %t57 = icmp eq i32 %t54, %t56
  br i1 %t57, label %bb13, label %bb14
bb13:
  %t59 = load { ptr, ptr }, ptr %l1
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/lineedit:Editor", ptr %t60, i32 0, i32 3
  %t63 = load { i64, ptr }, ptr %t62, !tbaa !27
  %t65 = extractvalue { ptr, ptr } %t59, 0
  %t66 = extractvalue { ptr, ptr } %t59, 1
  %t68 = call i1 %t65(ptr %t66, ptr %v0, { i64, ptr } %t63)
  store i1 %t68, ptr %l33
  br label %bb15
bb14:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb16
bb15:
  %t69 = load i1, ptr %l33, !tbaa !21
  %t70 = xor i1 %t69, true
  store i1 %t70, ptr %l29, !tbaa !21
  br label %bb16
bb16:
  %t72 = load i1, ptr %l29, !tbaa !21
  br i1 %t72, label %bb17, label %bb18
bb17:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = call { i64, ptr } @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2edone(ptr %v0, ptr %v2, ptr %t73)
  store { i64, ptr } %t75, ptr %l36
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t76 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t78 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t76, 1
  store { i32, { i64, ptr } } %t78, ptr %rv
  br label %ret
bb20:
  %t79 = load i32, ptr %l2, !range !{i32 0, i32 4}
  %t81 = trunc i64 1 to i32
  %t82 = icmp eq i32 %t79, %t81
  %t84 = xor i1 %t82, true
  br i1 %t84, label %bb21, label %bb22
bb21:
  br label %bb30
bb22:
  br label %bb23
bb23:
  %t86 = load { ptr, ptr }, ptr %l1
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/lineedit:Editor", ptr %t87, i32 0, i32 3
  %t90 = load { i64, ptr }, ptr %t89, !tbaa !27
  %t92 = extractvalue { ptr, ptr } %t86, 0
  %t93 = extractvalue { ptr, ptr } %t86, 1
  %t95 = call i1 %t92(ptr %t93, ptr %v0, { i64, ptr } %t90)
  store i1 %t95, ptr %l44
  br label %bb24
bb24:
  %t96 = load i1, ptr %l44, !tbaa !21
  br i1 %t96, label %bb25, label %bb26
bb25:
  %t97 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eBreak(ptr %v0, ptr %t97)
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = call { i64, ptr } @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2edone(ptr %v0, ptr %v2, ptr %t99)
  store { i64, ptr } %t101, ptr %l47
  br label %bb29
bb29:
  %t102 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t104 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t102, 1
  store { i32, { i64, ptr } } %t104, ptr %rv
  br label %ret
bb30:
  br label %bb1
bb31:
  %t105 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eIdle(ptr %v0, ptr %t105)
  br label %bb32
bb32:
  store { i64, ptr } { i64 -1, ptr null }, ptr %l50, !tbaa !27
  %t107 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t108 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t107, 1
  store { i32, { i64, ptr } } %t108, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i32 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2efill(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca [256 x i8]
  %l2 = alloca i64
  %l3 = alloca [256 x i8]
  %l5 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  br label %fill.4
fill.4:
  br label %fill.1
fill.1:
  %t5 = phi i64 [ 0, %fill.4 ], [ %t6, %fill.2 ]
  %t7 = icmp slt i64 %t5, 256
  br i1 %t7, label %fill.2, label %fill.3
fill.2:
  %t8 = getelementptr [256 x i8], ptr %l3, i64 0, i64 %t5
  store i8 0, ptr %t8
  %t6 = add i64 %t5, 1
  br label %fill.1
fill.3:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %l3, i64 256, i1 false)
  %t10 = call i64 @read(i32 0, ptr %l1, i64 256)
  store i64 %t10, ptr %l5
  br label %bb1
bb1:
  %t11 = load i64, ptr %l5, !tbaa !24
  store i64 %t11, ptr %l2, !tbaa !24
  %t12 = load i64, ptr %l2, !tbaa !24
  %t14 = icmp sle i64 %t12, 0
  br i1 %t14, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/lineedit:Editor", ptr %t17, i32 0, i32 35
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eClear_3cU8_3e(ptr %v0, ptr %t19)
  br label %bb5
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/lineedit:Editor", ptr %t21, i32 0, i32 35
  store ptr %t23, ptr %l12, !tbaa !29
  %t24 = load i64, ptr %l2, !tbaa !24
  store i64 %t24, ptr %l13, !tbaa !24
  %t25 = load [256 x i8], ptr %l1
  store i64 256, ptr %l14, !tbaa !24
  %t26 = icmp sge i64 0, 0
  br i1 %t26, label %bb6, label %bb7
bb6:
  %t28 = load i64, ptr %l13, !tbaa !24
  %t29 = icmp sle i64 0, %t28
  br i1 %t29, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_9f82c4ae2fb92c09_610471f21aec4c45)
  unreachable
bb8:
  %t31 = load i64, ptr %l13, !tbaa !24
  %t32 = load i64, ptr %l14, !tbaa !24
  %t33 = icmp sle i64 %t31, %t32
  br i1 %t33, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_9f82c4ae2fb92c09_610471f21aec4c45)
  unreachable
bb10:
  %t35 = load i64, ptr %l13, !tbaa !24
  %t36 = getelementptr i8, ptr %l1, i64 0
  %t37 = sub i64 %t35, 0
  %t38 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t36, 1
  %t40 = load ptr, ptr %l12, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePushAll_3cU8_3e(ptr %v0, ptr %s0, ptr %t40, { i64, ptr } %t39)
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_9f82c4ae2fb92c09_610471f21aec4c45)
  unreachable
bb12:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/lineedit:Editor", ptr %t42, i32 0, i32 36
  store i64 0, ptr %t44, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2einsert(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca i1
  %l4 = alloca ptr
  %l8 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l14 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l26 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l38 = alloca { i64, ptr }
  %l40 = alloca ptr
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d35, i32 0, i32 1) })
  store i1 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i1, ptr %l3, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l4, !tbaa !29
  %t6 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  %t10 = icmp eq i64 %t8, 1
  br i1 %t10, label %bb5, label %bb6
bb5:
  store i64 1, ptr %l8, !tbaa !24
  br label %bb7
bb6:
  store i64 2, ptr %l8, !tbaa !24
  br label %bb7
bb7:
  %t12 = load ptr, ptr %l4, !tbaa !29
  %t13 = load i64, ptr %l8, !tbaa !24
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2esave(ptr %v0, ptr %t12, i64 %t13)
  br label %bb8
bb8:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/lineedit:Editor", ptr %t14, i32 0, i32 19
  store i1 true, ptr %t16, !tbaa !21
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l10, !tbaa !29
  %t18 = call ptr @__olang_scope_hold(ptr %v0)
  %t19 = ptrtoint ptr %t18 to i64
  store i64 %t19, ptr %l11, !tbaa !24
  %t20 = load i1, ptr @olang_2esole_2ecompiler_2flineedit_3aEditor_2e3
  br i1 %t20, label %bb9, label %bb10
bb9:
  %t22 = call ptr @__olang_region_make(ptr %v0)
  %t23 = ptrtoint ptr %t22 to i64
  store i64 %t23, ptr %l11, !tbaa !24
  br label %bb10
bb10:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/lineedit:Editor", ptr %t24, i32 0, i32 3
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %l14, !tbaa !27
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/lineedit:Editor", ptr %t28, i32 0, i32 4
  %t31 = load i64, ptr %t30, !tbaa !24
  store i64 %t31, ptr %l16, !tbaa !24
  %t32 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t32, 0
  store i64 %t33, ptr %l17, !tbaa !24
  %t34 = icmp sge i64 0, 0
  br i1 %t34, label %bb11, label %bb12
bb11:
  %t36 = load i64, ptr %l16, !tbaa !24
  %t37 = icmp sle i64 0, %t36
  br i1 %t37, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_126b4ead7e969a49_c70e2460580ad75)
  unreachable
bb13:
  %t39 = load i64, ptr %l16, !tbaa !24
  %t40 = load i64, ptr %l17, !tbaa !24
  %t41 = icmp sle i64 %t39, %t40
  br i1 %t41, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_126b4ead7e969a49_c70e2460580ad75)
  unreachable
bb15:
  %t43 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = load i64, ptr %l16, !tbaa !24
  %t46 = getelementptr i8, ptr %t44, i64 0
  %t47 = sub i64 %t45, 0
  %t48 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t46, 1
  store { i64, ptr } %t49, ptr %l21, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t50, ptr %l22, !tbaa !27
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/lineedit:Editor", ptr %t51, i32 0, i32 3
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  store { i64, ptr } %t54, ptr %l24, !tbaa !27
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/lineedit:Editor", ptr %t55, i32 0, i32 4
  %t58 = load i64, ptr %t57, !tbaa !24
  store i64 %t58, ptr %l26, !tbaa !24
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/lineedit:Editor", ptr %t59, i32 0, i32 3
  %t62 = load { i64, ptr }, ptr %t61, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t62, 0
  store i64 %t65, ptr %l30, !tbaa !24
  %t66 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 0
  store i64 %t67, ptr %l31, !tbaa !24
  %t68 = load i64, ptr %l26, !tbaa !24
  %t69 = icmp sge i64 %t68, 0
  br i1 %t69, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_126b4ead7e969a49_c70e2460580ad75)
  unreachable
bb17:
  %t71 = load i64, ptr %l26, !tbaa !24
  %t72 = load i64, ptr %l30, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_126b4ead7e969a49_c70e2460580ad75)
  unreachable
bb19:
  %t75 = load i64, ptr %l30, !tbaa !24
  %t76 = load i64, ptr %l31, !tbaa !24
  %t77 = icmp sle i64 %t75, %t76
  br i1 %t77, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_126b4ead7e969a49_c70e2460580ad75)
  unreachable
bb21:
  %t79 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = load i64, ptr %l26, !tbaa !24
  %t82 = load i64, ptr %l30, !tbaa !24
  %t83 = getelementptr i8, ptr %t80, i64 %t81
  %t84 = sub i64 %t82, %t81
  %t85 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t83, 1
  %t87 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 1
  %t89 = extractvalue { i64, ptr } %t87, 0
  %t90 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 1
  %t92 = extractvalue { i64, ptr } %t90, 0
  %t93 = add i64 %t89, %t92
  %t95 = extractvalue { i64, ptr } %t86, 1
  %t96 = extractvalue { i64, ptr } %t86, 0
  %t97 = add i64 %t93, %t96
  %t98 = load i64, ptr %l11
  %t99 = inttoptr i64 %t98 to ptr
  %t100 = call ptr @__olang_held_alloc(ptr %t99, i64 %t97)
  call void @olang_textcopy(ptr %t100, ptr %t88, i64 %t89)
  %t101 = getelementptr i8, ptr %t100, i64 %t89
  call void @olang_textcopy(ptr %t101, ptr %t91, i64 %t92)
  %t102 = getelementptr i8, ptr %t101, i64 %t92
  call void @olang_textcopy(ptr %t102, ptr %t95, i64 %t96)
  %t103 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t100, 1
  %t106 = load ptr, ptr %l10, !tbaa !29
  %t107 = getelementptr %"compiler/lineedit:Editor", ptr %t106, i32 0, i32 3
  %t108 = load { i64, ptr }, ptr %t107, !tbaa !27
  store { i64, ptr } %t108, ptr %l38, !tbaa !27
  %t110 = load ptr, ptr %l10, !tbaa !29
  %t111 = getelementptr %"compiler/lineedit:Editor", ptr %t110, i32 0, i32 3
  store { i64, ptr } %t104, ptr %t111, !tbaa !27
  %t112 = load i1, ptr @olang_2esole_2ecompiler_2flineedit_3aEditor_2e3
  br i1 %t112, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_126b4ead7e969a49_c70e2460580ad75)
  unreachable
bb23:
  %t114 = load { i64, ptr }, ptr %l38
  %t115 = extractvalue { i64, ptr } %t114, 1
  call void @__olang_region_release(ptr %t115)
  store { i64, ptr } zeroinitializer, ptr %l38
  br label %bb24
bb24:
  %t116 = load ptr, ptr %l0, !tbaa !29
  store ptr %t116, ptr %l40, !tbaa !29
  %t117 = load ptr, ptr %l40, !tbaa !29
  %t118 = getelementptr %"compiler/lineedit:Editor", ptr %t117, i32 0, i32 4
  %t119 = load i64, ptr %t118, !tbaa !24
  %t120 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t120, 0
  %t125 = add i64 %t119, %t122
  %t127 = load ptr, ptr %l40, !tbaa !29
  %t128 = getelementptr %"compiler/lineedit:Editor", ptr %t127, i32 0, i32 4
  store i64 %t125, ptr %t128, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2epaste(ptr %v0, ptr %a0, i1 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca i1
  %l7 = alloca i1
  %l9 = alloca i64
  %l14 = alloca i64
  %l16 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l35 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lineedit:Editor", ptr %t1, i32 0, i32 16
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t4, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d36, i32 0, i32 1) })
  store i1 %t6, ptr %l5
  br label %bb1
bb1:
  %t7 = load i1, ptr %l5, !tbaa !21
  br i1 %t7, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  br i1 %a1, label %bb5, label %bb6
bb5:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/lineedit:Editor", ptr %t10, i32 0, i32 4
  %t13 = load i64, ptr %t12, !tbaa !24
  store i64 %t13, ptr %l9, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/lineedit:Editor", ptr %t14, i32 0, i32 3
  %t17 = load { i64, ptr }, ptr %t16, !tbaa !27
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/lineedit:Editor", ptr %t18, i32 0, i32 4
  %t21 = load i64, ptr %t20, !tbaa !24
  %t24 = call i64 @compiler_2flineedit_2elineEnd(ptr %v0, { i64, ptr } %t17, i64 %t21)
  store i64 %t24, ptr %l14
  br label %bb7
bb6:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb8
bb7:
  %t25 = load i64, ptr %l9, !tbaa !24
  %t26 = load i64, ptr %l14, !tbaa !24
  %t27 = icmp slt i64 %t25, %t26
  store i1 %t27, ptr %l7, !tbaa !21
  br label %bb8
bb8:
  %t29 = load i1, ptr %l7, !tbaa !21
  br i1 %t29, label %bb9, label %bb10
bb9:
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l16, !tbaa !29
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/lineedit:Editor", ptr %t31, i32 0, i32 3
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/lineedit:Editor", ptr %t35, i32 0, i32 4
  %t38 = load i64, ptr %t37, !tbaa !24
  %t41 = call i64 @compiler_2flineedit_2enextAt(ptr %v0, { i64, ptr } %t34, i64 %t38)
  store i64 %t41, ptr %l21
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t42 = load i64, ptr %l21, !tbaa !24
  %t43 = load ptr, ptr %l16, !tbaa !29
  %t44 = getelementptr %"compiler/lineedit:Editor", ptr %t43, i32 0, i32 4
  store i64 %t42, ptr %t44, !tbaa !24
  br label %bb12
bb12:
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l22, !tbaa !29
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/lineedit:Editor", ptr %t46, i32 0, i32 16
  %t49 = load { i64, ptr }, ptr %t48, !tbaa !27
  %t54 = call { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eRepeat_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s0, { i64, ptr } %t49, i64 %a2)
  store { i64, ptr } %t54, ptr %l27
  br label %bb13
bb13:
  %t55 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t55, 0
  %t58 = extractvalue { i64, ptr } %t55, 1
  %t59 = mul i64 %t57, 1
  %t60 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t59)
  call void @llvm.memcpy.p0.p0.i64(ptr %t60, ptr %t58, i64 %t59, i1 false)
  %t61 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t60, 1
  %t63 = load ptr, ptr %l22, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2einsert(ptr %v0, ptr %s0, ptr %t63, { i64, ptr } %t62)
  br label %bb14
bb14:
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l30, !tbaa !29
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/lineedit:Editor", ptr %t66, i32 0, i32 3
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/lineedit:Editor", ptr %t70, i32 0, i32 4
  %t73 = load i64, ptr %t72, !tbaa !24
  %t76 = call i64 @compiler_2flineedit_2eprevAt(ptr %v0, { i64, ptr } %t69, i64 %t73)
  store i64 %t76, ptr %l35
  br label %bb15
bb15:
  %t77 = load i64, ptr %l35, !tbaa !24
  %t78 = load ptr, ptr %l30, !tbaa !29
  %t79 = getelementptr %"compiler/lineedit:Editor", ptr %t78, i32 0, i32 4
  store i64 %t77, ptr %t79, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2epromptOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l8 = alloca i1
  %l12 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = icmp sgt i64 %a1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/lineedit:Editor", ptr %t5, i32 0, i32 10
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/lineedit:Editor", ptr %t10, i32 0, i32 5
  %t13 = load i1, ptr %t12, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/lineedit:Editor", ptr %t15, i32 0, i32 21
  %t18 = load i1, ptr %t17, !tbaa !21
  %t20 = xor i1 %t18, true
  store i1 %t20, ptr %l8, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb6
bb6:
  %t22 = load i1, ptr %l8, !tbaa !21
  br i1 %t22, label %bb7, label %bb8
bb7:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/lineedit:Editor", ptr %t23, i32 0, i32 11
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  store { i64, ptr } %t26, ptr %l12, !tbaa !27
  br label %bb9
bb8:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/lineedit:Editor", ptr %t28, i32 0, i32 9
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  store { i64, ptr } %t31, ptr %l12, !tbaa !27
  br label %bb9
bb9:
  %t33 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t33, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eremove(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l23 = alloca { i64, ptr }
  %l25 = alloca ptr
  %l26 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l35 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l50 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = icmp sle i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2esave(ptr %v0, ptr %t7, i64 2)
  br label %bb4
bb4:
  br i1 %a3, label %bb5, label %bb6
bb5:
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l9, !tbaa !29
  %t12 = call ptr @__olang_scope_hold(ptr %v0)
  %t13 = ptrtoint ptr %t12 to i64
  store i64 %t13, ptr %l10, !tbaa !24
  %t14 = load i1, ptr @olang_2esole_2ecompiler_2flineedit_3aEditor_2e16
  br i1 %t14, label %bb7, label %bb8
bb6:
  br label %bb17
bb7:
  %t16 = call ptr @__olang_region_make(ptr %v0)
  %t17 = ptrtoint ptr %t16 to i64
  store i64 %t17, ptr %l10, !tbaa !24
  br label %bb8
bb8:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/lineedit:Editor", ptr %t18, i32 0, i32 3
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l13, !tbaa !27
  %t22 = load i64, ptr %l1, !tbaa !24
  store i64 %t22, ptr %l14, !tbaa !24
  %t23 = load i64, ptr %l2, !tbaa !24
  store i64 %t23, ptr %l15, !tbaa !24
  %t24 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t24, 0
  store i64 %t25, ptr %l16, !tbaa !24
  %t26 = load i64, ptr %l14, !tbaa !24
  %t27 = icmp sge i64 %t26, 0
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t29 = load i64, ptr %l14, !tbaa !24
  %t30 = load i64, ptr %l15, !tbaa !24
  %t31 = icmp sle i64 %t29, %t30
  br i1 %t31, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_dd36f3cf990f8aca_64500bf1420cd6c6)
  unreachable
bb11:
  %t33 = load i64, ptr %l15, !tbaa !24
  %t34 = load i64, ptr %l16, !tbaa !24
  %t35 = icmp sle i64 %t33, %t34
  br i1 %t35, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_dd36f3cf990f8aca_64500bf1420cd6c6)
  unreachable
bb13:
  %t37 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = load i64, ptr %l14, !tbaa !24
  %t40 = load i64, ptr %l15, !tbaa !24
  %t41 = getelementptr i8, ptr %t38, i64 %t39
  %t42 = sub i64 %t40, %t39
  %t43 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t41, 1
  %t46 = extractvalue { i64, ptr } %t44, 1
  %t47 = extractvalue { i64, ptr } %t44, 0
  %t48 = load i64, ptr %l10
  %t49 = inttoptr i64 %t48 to ptr
  %t50 = call ptr @__olang_held_alloc(ptr %t49, i64 %t47)
  call void @olang_textcopy(ptr %t50, ptr %t46, i64 %t47)
  %t51 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  %t54 = load ptr, ptr %l9, !tbaa !29
  %t55 = getelementptr %"compiler/lineedit:Editor", ptr %t54, i32 0, i32 16
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l23, !tbaa !27
  %t58 = load ptr, ptr %l9, !tbaa !29
  %t59 = getelementptr %"compiler/lineedit:Editor", ptr %t58, i32 0, i32 16
  store { i64, ptr } %t52, ptr %t59, !tbaa !27
  %t60 = load i1, ptr @olang_2esole_2ecompiler_2flineedit_3aEditor_2e16
  br i1 %t60, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_dd36f3cf990f8aca_64500bf1420cd6c6)
  unreachable
bb15:
  %t62 = load { i64, ptr }, ptr %l23
  %t63 = extractvalue { i64, ptr } %t62, 1
  call void @__olang_region_release(ptr %t63)
  store { i64, ptr } zeroinitializer, ptr %l23
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t64 = load ptr, ptr %l0, !tbaa !29
  store ptr %t64, ptr %l25, !tbaa !29
  %t65 = call ptr @__olang_scope_hold(ptr %v0)
  %t66 = ptrtoint ptr %t65 to i64
  store i64 %t66, ptr %l26, !tbaa !24
  %t67 = load i1, ptr @olang_2esole_2ecompiler_2flineedit_3aEditor_2e3
  br i1 %t67, label %bb18, label %bb19
bb18:
  %t69 = call ptr @__olang_region_make(ptr %v0)
  %t70 = ptrtoint ptr %t69 to i64
  store i64 %t70, ptr %l26, !tbaa !24
  br label %bb19
bb19:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/lineedit:Editor", ptr %t71, i32 0, i32 3
  %t74 = load { i64, ptr }, ptr %t73, !tbaa !27
  store { i64, ptr } %t74, ptr %l29, !tbaa !27
  %t75 = load i64, ptr %l1, !tbaa !24
  store i64 %t75, ptr %l30, !tbaa !24
  %t76 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t76, 0
  store i64 %t77, ptr %l31, !tbaa !24
  %t78 = icmp sge i64 0, 0
  br i1 %t78, label %bb20, label %bb21
bb20:
  %t80 = load i64, ptr %l30, !tbaa !24
  %t81 = icmp sle i64 0, %t80
  br i1 %t81, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_8dc6cdcca3960da7_c3faaa8d27204ea3)
  unreachable
bb22:
  %t83 = load i64, ptr %l30, !tbaa !24
  %t84 = load i64, ptr %l31, !tbaa !24
  %t85 = icmp sle i64 %t83, %t84
  br i1 %t85, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_8dc6cdcca3960da7_c3faaa8d27204ea3)
  unreachable
bb24:
  %t87 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = load i64, ptr %l30, !tbaa !24
  %t90 = getelementptr i8, ptr %t88, i64 0
  %t91 = sub i64 %t89, 0
  %t92 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t90, 1
  store { i64, ptr } %t93, ptr %l35, !tbaa !27
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/lineedit:Editor", ptr %t94, i32 0, i32 3
  %t97 = load { i64, ptr }, ptr %t96, !tbaa !27
  store { i64, ptr } %t97, ptr %l37, !tbaa !27
  %t98 = load i64, ptr %l2, !tbaa !24
  store i64 %t98, ptr %l38, !tbaa !24
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/lineedit:Editor", ptr %t99, i32 0, i32 3
  %t102 = load { i64, ptr }, ptr %t101, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t102, 0
  store i64 %t105, ptr %l42, !tbaa !24
  %t106 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t106, 0
  store i64 %t107, ptr %l43, !tbaa !24
  %t108 = load i64, ptr %l38, !tbaa !24
  %t109 = icmp sge i64 %t108, 0
  br i1 %t109, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_8dc6cdcca3960da7_c3faaa8d27204ea3)
  unreachable
bb26:
  %t111 = load i64, ptr %l38, !tbaa !24
  %t112 = load i64, ptr %l42, !tbaa !24
  %t113 = icmp sle i64 %t111, %t112
  br i1 %t113, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_8dc6cdcca3960da7_c3faaa8d27204ea3)
  unreachable
bb28:
  %t115 = load i64, ptr %l42, !tbaa !24
  %t116 = load i64, ptr %l43, !tbaa !24
  %t117 = icmp sle i64 %t115, %t116
  br i1 %t117, label %bb30, label %bb31
bb29:
  call void @__olang_check_failed(ptr @olang_loc_8dc6cdcca3960da7_c3faaa8d27204ea3)
  unreachable
bb30:
  %t119 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = load i64, ptr %l38, !tbaa !24
  %t122 = load i64, ptr %l42, !tbaa !24
  %t123 = getelementptr i8, ptr %t120, i64 %t121
  %t124 = sub i64 %t122, %t121
  %t125 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t123, 1
  %t127 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t127, 1
  %t129 = extractvalue { i64, ptr } %t127, 0
  %t131 = extractvalue { i64, ptr } %t126, 1
  %t132 = extractvalue { i64, ptr } %t126, 0
  %t133 = add i64 %t129, %t132
  %t134 = load i64, ptr %l26
  %t135 = inttoptr i64 %t134 to ptr
  %t136 = call ptr @__olang_held_alloc(ptr %t135, i64 %t133)
  call void @olang_textcopy(ptr %t136, ptr %t128, i64 %t129)
  %t137 = getelementptr i8, ptr %t136, i64 %t129
  call void @olang_textcopy(ptr %t137, ptr %t131, i64 %t132)
  %t138 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t136, 1
  %t141 = load ptr, ptr %l25, !tbaa !29
  %t142 = getelementptr %"compiler/lineedit:Editor", ptr %t141, i32 0, i32 3
  %t143 = load { i64, ptr }, ptr %t142, !tbaa !27
  store { i64, ptr } %t143, ptr %l50, !tbaa !27
  %t145 = load ptr, ptr %l25, !tbaa !29
  %t146 = getelementptr %"compiler/lineedit:Editor", ptr %t145, i32 0, i32 3
  store { i64, ptr } %t139, ptr %t146, !tbaa !27
  %t147 = load i1, ptr @olang_2esole_2ecompiler_2flineedit_3aEditor_2e3
  br i1 %t147, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @olang_loc_8dc6cdcca3960da7_c3faaa8d27204ea3)
  unreachable
bb32:
  %t149 = load { i64, ptr }, ptr %l50
  %t150 = extractvalue { i64, ptr } %t149, 1
  call void @__olang_region_release(ptr %t150)
  store { i64, ptr } zeroinitializer, ptr %l50
  br label %bb33
bb33:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load i64, ptr %l1, !tbaa !24
  %t155 = getelementptr %"compiler/lineedit:Editor", ptr %t151, i32 0, i32 4
  store i64 %t152, ptr %t155, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2esearchKey(ptr %v0, ptr %a0, i8 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i8
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i1
  %l8 = alloca i1
  %l18 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l29 = alloca ptr
  %l31 = alloca i64
  %l34 = alloca i64
  %l41 = alloca i1
  %l44 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca i64
  %l58 = alloca { i64, ptr }
  %l60 = alloca ptr
  %l62 = alloca i64
  %l65 = alloca i64
  %l70 = alloca ptr
  %l71 = alloca i64
  %l74 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l81 = alloca ptr
  %l83 = alloca i64
  %l86 = alloca i64
  %l88 = alloca i64
  %l99 = alloca i1
  %l102 = alloca i1
  %l108 = alloca i32
  %s5 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i8 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i8, ptr %l1, !tbaa !22
  %t3 = icmp eq i8 %t1, 7
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i8, ptr %l1, !tbaa !22
  %t7 = icmp eq i8 %t5, 3
  store i1 %t7, ptr %l8, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/lineedit:Editor", ptr %t10, i32 0, i32 21
  store i1 false, ptr %t12, !tbaa !21
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/lineedit:Editor", ptr %t13, i32 0, i32 29
  %t16 = load { i64, ptr }, ptr %t15, !tbaa !27
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/lineedit:Editor", ptr %t18, i32 0, i32 30
  %t21 = load i64, ptr %t20, !tbaa !24
  store i64 %t21, ptr %l3, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/lineedit:Editor", ptr %t23, i32 0, i32 31
  %t26 = load i64, ptr %t25, !tbaa !24
  store i64 %t26, ptr %l4, !tbaa !24
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l18, !tbaa !29
  %t30 = load ptr, ptr %l18, !tbaa !29
  %t31 = getelementptr %"compiler/lineedit:Editor", ptr %t30, i32 0, i32 3
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  store { i64, ptr } %t32, ptr %l20, !tbaa !27
  %t34 = load ptr, ptr %l18, !tbaa !29
  %t35 = getelementptr %"compiler/lineedit:Editor", ptr %t34, i32 0, i32 3
  store { i64, ptr } %t16, ptr %t35, !tbaa !27
  %t36 = load i1, ptr @olang_2esole_2ecompiler_2flineedit_3aEditor_2e3
  br i1 %t36, label %bb6, label %bb7
bb5:
  br label %bb8
bb6:
  %t38 = load { i64, ptr }, ptr %l20
  %t39 = extractvalue { i64, ptr } %t38, 1
  call void @__olang_region_release(ptr %t39)
  store { i64, ptr } zeroinitializer, ptr %l20
  br label %bb7
bb7:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i64, ptr %l3, !tbaa !24
  %t44 = getelementptr %"compiler/lineedit:Editor", ptr %t40, i32 0, i32 4
  store i64 %t41, ptr %t44, !tbaa !24
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load i64, ptr %l4, !tbaa !24
  %t49 = getelementptr %"compiler/lineedit:Editor", ptr %t45, i32 0, i32 12
  store i64 %t46, ptr %t49, !tbaa !24
  store i32 0, ptr %rv
  br label %ret
bb8:
  %t51 = load i8, ptr %l1, !tbaa !22
  %t53 = icmp eq i8 %t51, 18
  br i1 %t53, label %bb9, label %bb10
bb9:
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l29, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/lineedit:Editor", ptr %t56, i32 0, i32 27
  %t59 = load i64, ptr %t58, !tbaa !24
  store i64 %t59, ptr %l31, !tbaa !24
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/lineedit:Editor", ptr %t60, i32 0, i32 24
  %t63 = load i1, ptr %t62, !tbaa !21
  br i1 %t63, label %bb11, label %bb12
bb10:
  br label %bb15
bb11:
  store i64 -1, ptr %l34, !tbaa !24
  br label %bb13
bb12:
  store i64 1, ptr %l34, !tbaa !24
  br label %bb13
bb13:
  %t65 = load i64, ptr %l31, !tbaa !24
  %t66 = load i64, ptr %l34, !tbaa !24
  %t67 = add i64 %t65, %t66
  %t68 = load ptr, ptr %l29, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2efind(ptr %v0, ptr %t68, i64 %t67)
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t70 = load i8, ptr %l1, !tbaa !22
  %t72 = icmp eq i8 %t70, 18
  br i1 %t72, label %bb16, label %bb17
bb16:
  store i32 0, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t75 = load i8, ptr %l1, !tbaa !22
  %t77 = icmp eq i8 %t75, 8
  br i1 %t77, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb21
bb20:
  %t79 = load i8, ptr %l1, !tbaa !22
  %t81 = icmp eq i8 %t79, 127
  store i1 %t81, ptr %l41, !tbaa !21
  br label %bb21
bb21:
  %t83 = load i1, ptr %l41, !tbaa !21
  br i1 %t83, label %bb22, label %bb23
bb22:
  %t84 = load ptr, ptr %l0, !tbaa !29
  store ptr %t84, ptr %l44, !tbaa !29
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/lineedit:Editor", ptr %t85, i32 0, i32 25
  %t88 = load { i64, ptr }, ptr %t87, !tbaa !27
  store { i64, ptr } %t88, ptr %l46, !tbaa !27
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/lineedit:Editor", ptr %t89, i32 0, i32 25
  %t92 = load { i64, ptr }, ptr %t91, !tbaa !27
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/lineedit:Editor", ptr %t93, i32 0, i32 25
  %t96 = load { i64, ptr }, ptr %t95, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t96, 0
  %t101 = call i64 @compiler_2flineedit_2eprevAt(ptr %v0, { i64, ptr } %t92, i64 %t98)
  store i64 %t101, ptr %l52
  br label %bb24
bb23:
  br label %bb37
bb24:
  %t102 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t102, 0
  store i64 %t103, ptr %l53, !tbaa !24
  %t104 = icmp sge i64 0, 0
  br i1 %t104, label %bb25, label %bb26
bb25:
  %t106 = load i64, ptr %l52, !tbaa !24
  %t107 = icmp sle i64 0, %t106
  br i1 %t107, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_d87e059e3fca2959_92a9b8111884af55)
  unreachable
bb27:
  %t109 = load i64, ptr %l52, !tbaa !24
  %t110 = load i64, ptr %l53, !tbaa !24
  %t111 = icmp sle i64 %t109, %t110
  br i1 %t111, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_d87e059e3fca2959_92a9b8111884af55)
  unreachable
bb29:
  %t113 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = load i64, ptr %l52, !tbaa !24
  %t116 = getelementptr i8, ptr %t114, i64 0
  %t117 = sub i64 %t115, 0
  %t118 = insertvalue { i64, ptr } undef, i64 %t117, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t116, 1
  %t120 = load ptr, ptr %l44, !tbaa !29
  %t121 = getelementptr %"compiler/lineedit:Editor", ptr %t120, i32 0, i32 25
  %t122 = load { i64, ptr }, ptr %t121, !tbaa !27
  store { i64, ptr } %t122, ptr %l58, !tbaa !27
  %t124 = load ptr, ptr %l44, !tbaa !29
  %t125 = getelementptr %"compiler/lineedit:Editor", ptr %t124, i32 0, i32 25
  store { i64, ptr } %t119, ptr %t125, !tbaa !27
  %t126 = load i1, ptr @olang_2esole_2ecompiler_2flineedit_3aEditor_2e25
  br i1 %t126, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_d87e059e3fca2959_92a9b8111884af55)
  unreachable
bb31:
  %t128 = load { i64, ptr }, ptr %l58
  %t129 = extractvalue { i64, ptr } %t128, 1
  call void @__olang_region_release(ptr %t129)
  store { i64, ptr } zeroinitializer, ptr %l58
  br label %bb32
bb32:
  %t130 = load ptr, ptr %l0, !tbaa !29
  store ptr %t130, ptr %l60, !tbaa !29
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/lineedit:Editor", ptr %t131, i32 0, i32 31
  %t134 = load i64, ptr %t133, !tbaa !24
  store i64 %t134, ptr %l62, !tbaa !24
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/lineedit:Editor", ptr %t135, i32 0, i32 24
  %t138 = load i1, ptr %t137, !tbaa !21
  br i1 %t138, label %bb33, label %bb34
bb33:
  store i64 -1, ptr %l65, !tbaa !24
  br label %bb35
bb34:
  store i64 1, ptr %l65, !tbaa !24
  br label %bb35
bb35:
  %t140 = load i64, ptr %l62, !tbaa !24
  %t141 = load i64, ptr %l65, !tbaa !24
  %t142 = add i64 %t140, %t141
  %t143 = load ptr, ptr %l60, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2efind(ptr %v0, ptr %t143, i64 %t142)
  br label %bb36
bb36:
  store i32 0, ptr %rv
  br label %ret
bb37:
  %t146 = load i8, ptr %l1, !tbaa !22
  %t148 = icmp uge i8 %t146, 32
  br i1 %t148, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s5
  %t150 = load ptr, ptr %l0, !tbaa !29
  store ptr %t150, ptr %l70, !tbaa !29
  %t151 = call ptr @__olang_scope_hold(ptr %v0)
  %t152 = ptrtoint ptr %t151 to i64
  store i64 %t152, ptr %l71, !tbaa !24
  %t153 = load i1, ptr @olang_2esole_2ecompiler_2flineedit_3aEditor_2e25
  br i1 %t153, label %bb40, label %bb41
bb39:
  br label %bb50
bb40:
  %t155 = call ptr @__olang_region_make(ptr %v0)
  %t156 = ptrtoint ptr %t155 to i64
  store i64 %t156, ptr %l71, !tbaa !24
  br label %bb41
bb41:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/lineedit:Editor", ptr %t157, i32 0, i32 25
  %t160 = load { i64, ptr }, ptr %t159, !tbaa !27
  store { i64, ptr } %t160, ptr %l74, !tbaa !27
  %t161 = load i8, ptr %l1, !tbaa !22
  %t163 = call { i64, ptr } @compiler_2flineedit_2eone(ptr %s5, i8 %t161)
  store { i64, ptr } %t163, ptr %l76
  br label %bb42
bb42:
  %t164 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t164, 1
  %t166 = extractvalue { i64, ptr } %t164, 0
  %t167 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t167, 1
  %t169 = extractvalue { i64, ptr } %t167, 0
  %t170 = add i64 %t166, %t169
  %t171 = load i64, ptr %l71
  %t172 = inttoptr i64 %t171 to ptr
  %t173 = call ptr @__olang_held_alloc(ptr %t172, i64 %t170)
  call void @olang_textcopy(ptr %t173, ptr %t165, i64 %t166)
  %t174 = getelementptr i8, ptr %t173, i64 %t166
  call void @olang_textcopy(ptr %t174, ptr %t168, i64 %t169)
  %t175 = insertvalue { i64, ptr } undef, i64 %t170, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t173, 1
  %t178 = load ptr, ptr %l70, !tbaa !29
  %t179 = getelementptr %"compiler/lineedit:Editor", ptr %t178, i32 0, i32 25
  %t180 = load { i64, ptr }, ptr %t179, !tbaa !27
  store { i64, ptr } %t180, ptr %l79, !tbaa !27
  %t182 = load ptr, ptr %l70, !tbaa !29
  %t183 = getelementptr %"compiler/lineedit:Editor", ptr %t182, i32 0, i32 25
  store { i64, ptr } %t176, ptr %t183, !tbaa !27
  %t184 = load i1, ptr @olang_2esole_2ecompiler_2flineedit_3aEditor_2e25
  br i1 %t184, label %bb43, label %bb44
bb43:
  %t186 = load { i64, ptr }, ptr %l79
  %t187 = extractvalue { i64, ptr } %t186, 1
  call void @__olang_region_release(ptr %t187)
  store { i64, ptr } zeroinitializer, ptr %l79
  br label %bb44
bb44:
  %t188 = load ptr, ptr %l0, !tbaa !29
  store ptr %t188, ptr %l81, !tbaa !29
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/lineedit:Editor", ptr %t189, i32 0, i32 27
  %t192 = load i64, ptr %t191, !tbaa !24
  store i64 %t192, ptr %l83, !tbaa !24
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/lineedit:Editor", ptr %t193, i32 0, i32 7
  %t197 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t195)
  store i64 %t197, ptr %l86
  br label %bb45
bb45:
  %t198 = load i64, ptr %l83, !tbaa !24
  %t199 = load i64, ptr %l86, !tbaa !24
  %t200 = icmp slt i64 %t198, %t199
  br i1 %t200, label %bb46, label %bb47
bb46:
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = getelementptr %"compiler/lineedit:Editor", ptr %t202, i32 0, i32 27
  %t205 = load i64, ptr %t204, !tbaa !24
  store i64 %t205, ptr %l88, !tbaa !24
  br label %bb48
bb47:
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t209 = getelementptr %"compiler/lineedit:Editor", ptr %t207, i32 0, i32 27
  %t210 = load i64, ptr %t209, !tbaa !24
  %t212 = sub i64 %t210, 1
  store i64 %t212, ptr %l88, !tbaa !24
  br label %bb48
bb48:
  %t214 = load ptr, ptr %l81, !tbaa !29
  %t215 = load i64, ptr %l88, !tbaa !24
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2efind(ptr %v0, ptr %t214, i64 %t215)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s5)
  store i32 0, ptr %rv
  br label %ret
bb50:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t219 = getelementptr %"compiler/lineedit:Editor", ptr %t217, i32 0, i32 23
  %t220 = load i1, ptr %t219, !tbaa !21
  store i1 %t220, ptr %l5, !tbaa !21
  %t222 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eacceptSearch(ptr %v0, ptr %t222)
  br label %bb51
bb51:
  %t224 = load i1, ptr %l5, !tbaa !21
  br i1 %t224, label %bb52, label %bb53
bb52:
  %t226 = load i8, ptr %l1, !tbaa !22
  %t228 = icmp eq i8 %t226, 13
  br i1 %t228, label %bb54, label %bb55
bb53:
  store i1 false, ptr %l99, !tbaa !21
  br label %bb57
bb54:
  store i1 true, ptr %l102, !tbaa !21
  br label %bb56
bb55:
  %t230 = load i8, ptr %l1, !tbaa !22
  %t232 = icmp eq i8 %t230, 10
  store i1 %t232, ptr %l102, !tbaa !21
  br label %bb56
bb56:
  %t234 = load i1, ptr %l102, !tbaa !21
  store i1 %t234, ptr %l99, !tbaa !21
  br label %bb57
bb57:
  %t235 = load i1, ptr %l99, !tbaa !21
  br i1 %t235, label %bb58, label %bb59
bb58:
  store i32 0, ptr %rv
  br label %ret
bb59:
  br label %bb60
bb60:
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t238 = load i8, ptr %l1, !tbaa !22
  %t241 = call i32 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2estep(ptr %v0, ptr %t237, i8 %t238)
  store i32 %t241, ptr %l108
  br label %bb61
bb61:
  %t242 = load i32, ptr %l108, !range !{i32 0, i32 4}
  store i32 %t242, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2esequence(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i8
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l21 = alloca i1
  %l23 = alloca i1
  %l24 = alloca i1
  %l26 = alloca i1
  %l27 = alloca ptr
  %l29 = alloca i1
  %l30 = alloca i32
  %l37 = alloca i1
  %l38 = alloca { i64, ptr }
  %l44 = alloca i1
  %l55 = alloca ptr
  %l57 = alloca i64
  %l62 = alloca i64
  %l64 = alloca i64
  %l67 = alloca ptr
  %l69 = alloca i64
  %l74 = alloca i64
  %l76 = alloca i64
  %l79 = alloca i1
  %l82 = alloca i1
  %l84 = alloca i1
  %l85 = alloca i1
  %l87 = alloca i1
  %l88 = alloca ptr
  %l93 = alloca i64
  %l96 = alloca i1
  %l99 = alloca i1
  %l101 = alloca i1
  %l102 = alloca i1
  %l104 = alloca i1
  %l105 = alloca ptr
  %l110 = alloca i64
  %l113 = alloca i1
  %l115 = alloca i1
  %l116 = alloca ptr
  %l118 = alloca i64
  %l123 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l5, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t2, 0
  %t6 = sub i64 %t4, 1
  %t8 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !27
  %t10 = getelementptr i8, ptr %t9, i64 %t6
  %t11 = load i8, ptr %t10, !tbaa !32
  store i8 %t11, ptr %l2, !tbaa !22
  %t13 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t13, ptr %l10, !tbaa !27
  %t14 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  %t18 = sub i64 %t16, 1
  store i64 %t18, ptr %l13, !tbaa !24
  %t19 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 0
  store i64 %t20, ptr %l14, !tbaa !24
  %t21 = icmp sge i64 2, 0
  br i1 %t21, label %bb1, label %bb2
bb1:
  %t23 = load i64, ptr %l13, !tbaa !24
  %t24 = icmp sle i64 2, %t23
  br i1 %t24, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_c6edc95ce3a108e9_a40785e2dad47f45)
  unreachable
bb3:
  %t26 = load i64, ptr %l13, !tbaa !24
  %t27 = load i64, ptr %l14, !tbaa !24
  %t28 = icmp sle i64 %t26, %t27
  br i1 %t28, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_c6edc95ce3a108e9_a40785e2dad47f45)
  unreachable
bb5:
  %t30 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = load i64, ptr %l13, !tbaa !24
  %t33 = getelementptr i8, ptr %t31, i64 2
  %t34 = sub i64 %t32, 2
  %t35 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t33, 1
  store { i64, ptr } %t36, ptr %l3, !tbaa !27
  %t38 = load i8, ptr %l2, !tbaa !22
  %t40 = icmp eq i8 %t38, 126
  br i1 %t40, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_c6edc95ce3a108e9_a40785e2dad47f45)
  unreachable
bb7:
  %t42 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t44 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t42, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d37, i32 0, i32 1) })
  store i1 %t44, ptr %l23
  br label %bb9
bb8:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb14
bb9:
  %t45 = load i1, ptr %l23, !tbaa !21
  br i1 %t45, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb13
bb11:
  %t46 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t48 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t46, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d38, i32 0, i32 1) })
  store i1 %t48, ptr %l26
  br label %bb12
bb12:
  %t49 = load i1, ptr %l26, !tbaa !21
  store i1 %t49, ptr %l24, !tbaa !21
  br label %bb13
bb13:
  %t50 = load i1, ptr %l24, !tbaa !21
  store i1 %t50, ptr %l21, !tbaa !21
  br label %bb14
bb14:
  %t51 = load i1, ptr %l21, !tbaa !21
  br i1 %t51, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s1
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l27, !tbaa !29
  %t53 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t55 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s1, { i64, ptr } %t53, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d39, i32 0, i32 1) })
  store i1 %t55, ptr %l29
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t56 = load ptr, ptr %l27, !tbaa !29
  %t57 = load i1, ptr %l29, !tbaa !21
  %t58 = call i32 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2ebracket(ptr %v0, ptr %t56, i1 %t57)
  store i32 %t58, ptr %l30
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t59 = load i32, ptr %l30, !range !{i32 0, i32 4}
  store i32 %t59, ptr %rv
  br label %ret
bb19:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/lineedit:Editor", ptr %t60, i32 0, i32 22
  %t63 = load i1, ptr %t62, !tbaa !21
  br i1 %t63, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t66 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t66, 0
  %t70 = icmp sgt i64 %t68, 0
  br i1 %t70, label %bb23, label %bb24
bb23:
  %t72 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t72, ptr %l38, !tbaa !27
  %t73 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t73, 0
  %t77 = sub i64 %t75, 1
  %t79 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr i8, ptr %t80, i64 %t77
  %t82 = load i8, ptr %t81, !tbaa !32
  %t84 = icmp ne i8 %t82, 49
  store i1 %t84, ptr %l37, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb25
bb25:
  %t86 = load i1, ptr %l37, !tbaa !21
  br i1 %t86, label %bb26, label %bb27
bb26:
  %t87 = load i8, ptr %l2, !tbaa !22
  %t89 = icmp ne i8 %t87, 126
  store i1 %t89, ptr %l44, !tbaa !21
  br label %bb28
bb27:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb28
bb28:
  %t91 = load i1, ptr %l44, !tbaa !21
  store i1 %t91, ptr %l4, !tbaa !21
  %t92 = load i8, ptr %l2, !tbaa !22
  %t94 = icmp eq i8 %t92, 65
  br i1 %t94, label %bb29, label %bb30
bb29:
  %t96 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eup(ptr %v0, ptr %t96)
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb32
bb32:
  %t98 = load i8, ptr %l2, !tbaa !22
  %t100 = icmp eq i8 %t98, 66
  br i1 %t100, label %bb33, label %bb34
bb33:
  %t102 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2edown(ptr %v0, ptr %t102)
  br label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb36
bb36:
  %t104 = load i8, ptr %l2, !tbaa !22
  %t106 = icmp eq i8 %t104, 67
  br i1 %t106, label %bb37, label %bb38
bb37:
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l55, !tbaa !29
  %t109 = load i1, ptr %l4, !tbaa !21
  br i1 %t109, label %bb39, label %bb40
bb38:
  br label %bb44
bb39:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/lineedit:Editor", ptr %t111, i32 0, i32 3
  %t114 = load { i64, ptr }, ptr %t113, !tbaa !27
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/lineedit:Editor", ptr %t115, i32 0, i32 4
  %t118 = load i64, ptr %t117, !tbaa !24
  %t121 = call i64 @compiler_2flineedit_2ewordEnd(ptr %v0, { i64, ptr } %t114, i64 %t118)
  store i64 %t121, ptr %l62
  br label %bb41
bb40:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = call i64 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eright(ptr %v0, ptr %t122)
  store i64 %t124, ptr %l64
  br label %bb42
bb41:
  %t125 = load i64, ptr %l62, !tbaa !24
  store i64 %t125, ptr %l57, !tbaa !24
  br label %bb43
bb42:
  %t126 = load i64, ptr %l64, !tbaa !24
  store i64 %t126, ptr %l57, !tbaa !24
  br label %bb43
bb43:
  %t127 = load i64, ptr %l57, !tbaa !24
  %t128 = load ptr, ptr %l55, !tbaa !29
  %t129 = getelementptr %"compiler/lineedit:Editor", ptr %t128, i32 0, i32 4
  store i64 %t127, ptr %t129, !tbaa !24
  br label %bb44
bb44:
  %t130 = load i8, ptr %l2, !tbaa !22
  %t132 = icmp eq i8 %t130, 68
  br i1 %t132, label %bb45, label %bb46
bb45:
  %t134 = load ptr, ptr %l0, !tbaa !29
  store ptr %t134, ptr %l67, !tbaa !29
  %t135 = load i1, ptr %l4, !tbaa !21
  br i1 %t135, label %bb47, label %bb48
bb46:
  br label %bb52
bb47:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/lineedit:Editor", ptr %t137, i32 0, i32 3
  %t140 = load { i64, ptr }, ptr %t139, !tbaa !27
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/lineedit:Editor", ptr %t141, i32 0, i32 4
  %t144 = load i64, ptr %t143, !tbaa !24
  %t147 = call i64 @compiler_2flineedit_2ewordBack(ptr %v0, { i64, ptr } %t140, i64 %t144)
  store i64 %t147, ptr %l74
  br label %bb49
bb48:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = call i64 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eleft(ptr %v0, ptr %t148)
  store i64 %t150, ptr %l76
  br label %bb50
bb49:
  %t151 = load i64, ptr %l74, !tbaa !24
  store i64 %t151, ptr %l69, !tbaa !24
  br label %bb51
bb50:
  %t152 = load i64, ptr %l76, !tbaa !24
  store i64 %t152, ptr %l69, !tbaa !24
  br label %bb51
bb51:
  %t153 = load i64, ptr %l69, !tbaa !24
  %t154 = load ptr, ptr %l67, !tbaa !29
  %t155 = getelementptr %"compiler/lineedit:Editor", ptr %t154, i32 0, i32 4
  store i64 %t153, ptr %t155, !tbaa !24
  br label %bb52
bb52:
  %t156 = load i8, ptr %l2, !tbaa !22
  %t158 = icmp eq i8 %t156, 72
  br i1 %t158, label %bb53, label %bb54
bb53:
  store i1 true, ptr %l79, !tbaa !21
  br label %bb63
bb54:
  %t160 = load i8, ptr %l2, !tbaa !22
  %t162 = icmp eq i8 %t160, 126
  br i1 %t162, label %bb55, label %bb56
bb55:
  %t164 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t166 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t164, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d40, i32 0, i32 1) })
  store i1 %t166, ptr %l84
  br label %bb57
bb56:
  store i1 false, ptr %l82, !tbaa !21
  br label %bb62
bb57:
  %t167 = load i1, ptr %l84, !tbaa !21
  br i1 %t167, label %bb58, label %bb59
bb58:
  store i1 true, ptr %l85, !tbaa !21
  br label %bb61
bb59:
  %t168 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t170 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t168, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d41, i32 0, i32 1) })
  store i1 %t170, ptr %l87
  br label %bb60
bb60:
  %t171 = load i1, ptr %l87, !tbaa !21
  store i1 %t171, ptr %l85, !tbaa !21
  br label %bb61
bb61:
  %t172 = load i1, ptr %l85, !tbaa !21
  store i1 %t172, ptr %l82, !tbaa !21
  br label %bb62
bb62:
  %t173 = load i1, ptr %l82, !tbaa !21
  store i1 %t173, ptr %l79, !tbaa !21
  br label %bb63
bb63:
  %t174 = load i1, ptr %l79, !tbaa !21
  br i1 %t174, label %bb64, label %bb65
bb64:
  %t175 = load ptr, ptr %l0, !tbaa !29
  store ptr %t175, ptr %l88, !tbaa !29
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr %"compiler/lineedit:Editor", ptr %t176, i32 0, i32 3
  %t179 = load { i64, ptr }, ptr %t178, !tbaa !27
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr %"compiler/lineedit:Editor", ptr %t180, i32 0, i32 4
  %t183 = load i64, ptr %t182, !tbaa !24
  %t186 = call i64 @compiler_2flineedit_2elineStart(ptr %v0, { i64, ptr } %t179, i64 %t183)
  store i64 %t186, ptr %l93
  br label %bb66
bb65:
  br label %bb67
bb66:
  %t187 = load i64, ptr %l93, !tbaa !24
  %t188 = load ptr, ptr %l88, !tbaa !29
  %t189 = getelementptr %"compiler/lineedit:Editor", ptr %t188, i32 0, i32 4
  store i64 %t187, ptr %t189, !tbaa !24
  br label %bb67
bb67:
  %t190 = load i8, ptr %l2, !tbaa !22
  %t192 = icmp eq i8 %t190, 70
  br i1 %t192, label %bb68, label %bb69
bb68:
  store i1 true, ptr %l96, !tbaa !21
  br label %bb78
bb69:
  %t194 = load i8, ptr %l2, !tbaa !22
  %t196 = icmp eq i8 %t194, 126
  br i1 %t196, label %bb70, label %bb71
bb70:
  %t198 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t200 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t198, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) })
  store i1 %t200, ptr %l101
  br label %bb72
bb71:
  store i1 false, ptr %l99, !tbaa !21
  br label %bb77
bb72:
  %t201 = load i1, ptr %l101, !tbaa !21
  br i1 %t201, label %bb73, label %bb74
bb73:
  store i1 true, ptr %l102, !tbaa !21
  br label %bb76
bb74:
  %t202 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t204 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t202, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) })
  store i1 %t204, ptr %l104
  br label %bb75
bb75:
  %t205 = load i1, ptr %l104, !tbaa !21
  store i1 %t205, ptr %l102, !tbaa !21
  br label %bb76
bb76:
  %t206 = load i1, ptr %l102, !tbaa !21
  store i1 %t206, ptr %l99, !tbaa !21
  br label %bb77
bb77:
  %t207 = load i1, ptr %l99, !tbaa !21
  store i1 %t207, ptr %l96, !tbaa !21
  br label %bb78
bb78:
  %t208 = load i1, ptr %l96, !tbaa !21
  br i1 %t208, label %bb79, label %bb80
bb79:
  %t209 = load ptr, ptr %l0, !tbaa !29
  store ptr %t209, ptr %l105, !tbaa !29
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t212 = getelementptr %"compiler/lineedit:Editor", ptr %t210, i32 0, i32 3
  %t213 = load { i64, ptr }, ptr %t212, !tbaa !27
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/lineedit:Editor", ptr %t214, i32 0, i32 4
  %t217 = load i64, ptr %t216, !tbaa !24
  %t220 = call i64 @compiler_2flineedit_2elineEnd(ptr %v0, { i64, ptr } %t213, i64 %t217)
  store i64 %t220, ptr %l110
  br label %bb81
bb80:
  br label %bb82
bb81:
  %t221 = load i64, ptr %l110, !tbaa !24
  %t222 = load ptr, ptr %l105, !tbaa !29
  %t223 = getelementptr %"compiler/lineedit:Editor", ptr %t222, i32 0, i32 4
  store i64 %t221, ptr %t223, !tbaa !24
  br label %bb82
bb82:
  %t224 = load i8, ptr %l2, !tbaa !22
  %t226 = icmp eq i8 %t224, 126
  br i1 %t226, label %bb83, label %bb84
bb83:
  %t228 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t230 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t228, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) })
  store i1 %t230, ptr %l115
  br label %bb85
bb84:
  store i1 false, ptr %l113, !tbaa !21
  br label %bb86
bb85:
  %t231 = load i1, ptr %l115, !tbaa !21
  store i1 %t231, ptr %l113, !tbaa !21
  br label %bb86
bb86:
  %t232 = load i1, ptr %l113, !tbaa !21
  br i1 %t232, label %bb87, label %bb88
bb87:
  %t233 = load ptr, ptr %l0, !tbaa !29
  store ptr %t233, ptr %l116, !tbaa !29
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t236 = getelementptr %"compiler/lineedit:Editor", ptr %t234, i32 0, i32 4
  %t237 = load i64, ptr %t236, !tbaa !24
  store i64 %t237, ptr %l118, !tbaa !24
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = getelementptr %"compiler/lineedit:Editor", ptr %t238, i32 0, i32 3
  %t241 = load { i64, ptr }, ptr %t240, !tbaa !27
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t244 = getelementptr %"compiler/lineedit:Editor", ptr %t242, i32 0, i32 4
  %t245 = load i64, ptr %t244, !tbaa !24
  %t248 = call i64 @compiler_2flineedit_2enextAt(ptr %v0, { i64, ptr } %t241, i64 %t245)
  store i64 %t248, ptr %l123
  br label %bb89
bb88:
  br label %bb91
bb89:
  %t249 = load ptr, ptr %l116, !tbaa !29
  %t250 = load i64, ptr %l118, !tbaa !24
  %t251 = load i64, ptr %l123, !tbaa !24
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eremove(ptr %v0, ptr %t249, i64 %t250, i64 %t251, i1 false)
  br label %bb90
bb90:
  br label %bb91
bb91:
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = getelementptr %"compiler/lineedit:Editor", ptr %t252, i32 0, i32 5
  %t255 = load i1, ptr %t254, !tbaa !21
  br i1 %t255, label %bb92, label %bb93
bb92:
  %t257 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eclamp(ptr %v0, ptr %t257)
  br label %bb94
bb93:
  br label %bb95
bb94:
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2estatus(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lineedit:Editor", ptr %t1, i32 0, i32 23
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lineedit:Editor", ptr %t6, i32 0, i32 24
  %t9 = load i1, ptr %t8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb2:
  br label %bb6
bb3:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, ptr %l5, !tbaa !27
  br label %bb5
bb4:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, ptr %l5, !tbaa !27
  br label %bb5
bb5:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/lineedit:Editor", ptr %t11, i32 0, i32 25
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t15, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = extractvalue { i64, ptr } %t14, 1
  %t20 = extractvalue { i64, ptr } %t14, 0
  %t21 = add i64 %t17, %t20
  %t22 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t21)
  call void @olang_textcopy(ptr %t22, ptr %t16, i64 %t17)
  %t23 = getelementptr i8, ptr %t22, i64 %t17
  call void @olang_textcopy(ptr %t23, ptr %t19, i64 %t20)
  %t24 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t22, 1
  store { i64, ptr } %t25, ptr %rv
  br label %ret
bb6:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/lineedit:Editor", ptr %t27, i32 0, i32 28
  %t30 = load i1, ptr %t29, !tbaa !21
  br i1 %t30, label %bb7, label %bb8
bb7:
  store { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d47, i32 0, i32 1) }, ptr %l11, !tbaa !27
  br label %bb9
bb8:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d48, i32 0, i32 1) }, ptr %l11, !tbaa !27
  br label %bb9
bb9:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/lineedit:Editor", ptr %t32, i32 0, i32 25
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 1
  %t38 = extractvalue { i64, ptr } %t36, 0
  %t40 = extractvalue { i64, ptr } %t35, 1
  %t41 = extractvalue { i64, ptr } %t35, 0
  %t42 = add i64 %t38, %t41
  %t43 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t42)
  call void @olang_textcopy(ptr %t43, ptr %t37, i64 %t38)
  %t44 = getelementptr i8, ptr %t43, i64 %t38
  call void @olang_textcopy(ptr %t44, ptr %t40, i64 %t41)
  %t45 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t43, 1
  store { i64, ptr } %t46, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2etoggle(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/prelude/text:StringBuilder"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i8
  %l12 = alloca { i64, ptr }
  %l14 = alloca i64
  %l19 = alloca i64
  %l21 = alloca i64
  %l23 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l32 = alloca %"std/prelude/text:StringBuilder"
  %l40 = alloca { i64, ptr }
  %l45 = alloca i1
  %l48 = alloca i8
  %l53 = alloca i1
  %l56 = alloca i8
  %l70 = alloca ptr
  %l72 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lineedit:Editor", ptr %t1, i32 0, i32 3
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l12, !tbaa !27
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/lineedit:Editor", ptr %t5, i32 0, i32 4
  %t8 = load i64, ptr %t7, !tbaa !24
  store i64 %t8, ptr %l14, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/lineedit:Editor", ptr %t9, i32 0, i32 3
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/lineedit:Editor", ptr %t13, i32 0, i32 4
  %t16 = load i64, ptr %t15, !tbaa !24
  %t19 = call i64 @compiler_2flineedit_2elineEnd(ptr %v0, { i64, ptr } %t12, i64 %t16)
  store i64 %t19, ptr %l19
  br label %bb1
bb1:
  %t21 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t22 = load i64, ptr %l14, !tbaa !24
  %t23 = load i64, ptr %l19, !tbaa !24
  %t25 = call i64 @compiler_2flineedit_2eoffsetOf(ptr %v0, { i64, ptr } %t21, i64 %t22, i64 %t23, i64 %a1)
  store i64 %t25, ptr %l21
  br label %bb2
bb2:
  %t26 = load i64, ptr %l21, !tbaa !24
  store i64 %t26, ptr %l2, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/lineedit:Editor", ptr %t27, i32 0, i32 3
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  store { i64, ptr } %t30, ptr %l23, !tbaa !27
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/lineedit:Editor", ptr %t31, i32 0, i32 4
  %t34 = load i64, ptr %t33, !tbaa !24
  store i64 %t34, ptr %l25, !tbaa !24
  %t35 = load i64, ptr %l2, !tbaa !24
  store i64 %t35, ptr %l26, !tbaa !24
  %t36 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 0
  store i64 %t37, ptr %l27, !tbaa !24
  %t38 = load i64, ptr %l25, !tbaa !24
  %t39 = icmp sge i64 %t38, 0
  br i1 %t39, label %bb3, label %bb4
bb3:
  %t41 = load i64, ptr %l25, !tbaa !24
  %t42 = load i64, ptr %l26, !tbaa !24
  %t43 = icmp sle i64 %t41, %t42
  br i1 %t43, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_54806be5a60651c2_4a35e5984fb8c156)
  unreachable
bb5:
  %t45 = load i64, ptr %l26, !tbaa !24
  %t46 = load i64, ptr %l27, !tbaa !24
  %t47 = icmp sle i64 %t45, %t46
  br i1 %t47, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_54806be5a60651c2_4a35e5984fb8c156)
  unreachable
bb7:
  %t49 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = load i64, ptr %l25, !tbaa !24
  %t52 = load i64, ptr %l26, !tbaa !24
  %t53 = getelementptr i8, ptr %t50, i64 %t51
  %t54 = sub i64 %t52, %t51
  %t55 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t53, 1
  store { i64, ptr } %t56, ptr %l3, !tbaa !27
  %t58 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t58, ptr %l32
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_54806be5a60651c2_4a35e5984fb8c156)
  unreachable
bb9:
  %t59 = load %"std/prelude/text:StringBuilder", ptr %l32
  store %"std/prelude/text:StringBuilder" %t59, ptr %l4
  %t60 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t60, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t62 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t62, 0
  store i64 %t64, ptr %l7, !tbaa !24
  br label %bb10
bb10:
  %t66 = load i64, ptr %l6, !tbaa !24
  %t67 = load i64, ptr %l7, !tbaa !24
  %t70 = icmp slt i64 %t66, %t67
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb11, label %bb12
bb11:
  br label %bb28
bb12:
  br label %bb13
bb13:
  %t74 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t74, ptr %l40, !tbaa !27
  %t75 = load i64, ptr %l6, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr i8, ptr %t78, i64 %t75
  %t80 = load i8, ptr %t79, !tbaa !32
  store i8 %t80, ptr %l8, !tbaa !22
  %t82 = load i8, ptr %l8, !tbaa !22
  %t84 = icmp uge i8 %t82, 97
  br i1 %t84, label %bb14, label %bb15
bb14:
  %t86 = load i8, ptr %l8, !tbaa !22
  %t88 = icmp ule i8 %t86, 122
  store i1 %t88, ptr %l45, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb16
bb16:
  %t90 = load i1, ptr %l45, !tbaa !21
  br i1 %t90, label %bb17, label %bb18
bb17:
  %t91 = load i8, ptr %l8, !tbaa !22
  %t93 = sub i8 %t91, 32
  store i8 %t93, ptr %l48, !tbaa !22
  br label %bb25
bb18:
  %t95 = load i8, ptr %l8, !tbaa !22
  %t97 = icmp uge i8 %t95, 65
  br i1 %t97, label %bb19, label %bb20
bb19:
  %t99 = load i8, ptr %l8, !tbaa !22
  %t101 = icmp ule i8 %t99, 90
  store i1 %t101, ptr %l53, !tbaa !21
  br label %bb21
bb20:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb21
bb21:
  %t103 = load i1, ptr %l53, !tbaa !21
  br i1 %t103, label %bb22, label %bb23
bb22:
  %t104 = load i8, ptr %l8, !tbaa !22
  %t106 = add i8 %t104, 32
  store i8 %t106, ptr %l56, !tbaa !22
  br label %bb24
bb23:
  %t108 = load i8, ptr %l8, !tbaa !22
  store i8 %t108, ptr %l56, !tbaa !22
  br label %bb24
bb24:
  %t110 = load i8, ptr %l56, !tbaa !22
  store i8 %t110, ptr %l48, !tbaa !22
  br label %bb25
bb25:
  %t111 = load i8, ptr %l48, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l4, i8 %t111)
  br label %bb26
bb26:
  br label %bb27
bb27:
  %t115 = load i64, ptr %l6, !tbaa !24
  %t118 = add i64 %t115, 1
  store i64 %t118, ptr %l6, !tbaa !24
  br label %bb10
bb28:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/lineedit:Editor", ptr %t120, i32 0, i32 4
  %t123 = load i64, ptr %t122, !tbaa !24
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eremove(ptr %v0, ptr %t125, i64 %t123, i64 %t127, i1 false)
  br label %bb29
bb29:
  %t131 = load ptr, ptr %l0, !tbaa !29
  store ptr %t131, ptr %l70, !tbaa !29
  %t133 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l4)
  store { i64, ptr } %t133, ptr %l72
  br label %bb30
bb30:
  %t134 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t135 = load ptr, ptr %l70, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2einsert(ptr %v0, ptr %s0, ptr %t135, { i64, ptr } %t134)
  br label %bb31
bb31:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load i64, ptr %l2, !tbaa !24
  %t141 = getelementptr %"compiler/lineedit:Editor", ptr %t137, i32 0, i32 4
  store i64 %t138, ptr %t141, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2ewholeLine(ptr %v0, ptr %a0, i8 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l13 = alloca i64
  %l17 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca i64
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l38 = alloca { i64, ptr }
  %l44 = alloca i1
  %l47 = alloca i64
  %l55 = alloca i64
  %l64 = alloca ptr
  %l66 = alloca { i64, ptr }
  %l68 = alloca ptr
  %l70 = alloca { i64, ptr }
  %l77 = alloca i64
  %l83 = alloca i64
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lineedit:Editor", ptr %t1, i32 0, i32 3
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/lineedit:Editor", ptr %t7, i32 0, i32 4
  %t10 = load i64, ptr %t9, !tbaa !24
  %t13 = call i64 @compiler_2flineedit_2elineStart(ptr %v0, { i64, ptr } %t6, i64 %t10)
  store i64 %t13, ptr %l13
  br label %bb1
bb1:
  %t14 = load i64, ptr %l13, !tbaa !24
  store i64 %t14, ptr %l3, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/lineedit:Editor", ptr %t16, i32 0, i32 4
  %t19 = load i64, ptr %t18, !tbaa !24
  %t22 = call i64 @compiler_2flineedit_2elineEnd(ptr %v0, { i64, ptr } %t15, i64 %t19)
  store i64 %t22, ptr %l17
  br label %bb2
bb2:
  %t23 = load i64, ptr %l17, !tbaa !24
  store i64 %t23, ptr %l4, !tbaa !24
  %t26 = icmp eq i8 %a1, 99
  br i1 %t26, label %bb3, label %bb4
bb3:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i64, ptr %l3, !tbaa !24
  %t30 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eremove(ptr %v0, ptr %t28, i64 %t29, i64 %t30, i1 true)
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/lineedit:Editor", ptr %t34, i32 0, i32 5
  store i1 false, ptr %t36, !tbaa !21
  store i32 0, ptr %rv
  br label %ret
bb6:
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l25, !tbaa !29
  %t39 = call ptr @__olang_scope_hold(ptr %v0)
  %t40 = ptrtoint ptr %t39 to i64
  store i64 %t40, ptr %l26, !tbaa !24
  %t41 = load i1, ptr @olang_2esole_2ecompiler_2flineedit_3aEditor_2e16
  br i1 %t41, label %bb7, label %bb8
bb7:
  %t43 = call ptr @__olang_region_make(ptr %v0)
  %t44 = ptrtoint ptr %t43 to i64
  store i64 %t44, ptr %l26, !tbaa !24
  br label %bb8
bb8:
  %t45 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t45, ptr %l28, !tbaa !27
  %t46 = load i64, ptr %l3, !tbaa !24
  store i64 %t46, ptr %l29, !tbaa !24
  %t47 = load i64, ptr %l4, !tbaa !24
  store i64 %t47, ptr %l30, !tbaa !24
  %t48 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 0
  store i64 %t49, ptr %l31, !tbaa !24
  %t50 = load i64, ptr %l29, !tbaa !24
  %t51 = icmp sge i64 %t50, 0
  br i1 %t51, label %bb9, label %bb10
bb9:
  %t53 = load i64, ptr %l29, !tbaa !24
  %t54 = load i64, ptr %l30, !tbaa !24
  %t55 = icmp sle i64 %t53, %t54
  br i1 %t55, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_55814703dba0f3c7_baa829e140d7f09b)
  unreachable
bb11:
  %t57 = load i64, ptr %l30, !tbaa !24
  %t58 = load i64, ptr %l31, !tbaa !24
  %t59 = icmp sle i64 %t57, %t58
  br i1 %t59, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_55814703dba0f3c7_baa829e140d7f09b)
  unreachable
bb13:
  %t61 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = load i64, ptr %l29, !tbaa !24
  %t64 = load i64, ptr %l30, !tbaa !24
  %t65 = getelementptr i8, ptr %t62, i64 %t63
  %t66 = sub i64 %t64, %t63
  %t67 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t65, 1
  %t70 = extractvalue { i64, ptr } %t68, 1
  %t71 = extractvalue { i64, ptr } %t68, 0
  %t72 = load i64, ptr %l26
  %t73 = inttoptr i64 %t72 to ptr
  %t74 = call ptr @__olang_held_alloc(ptr %t73, i64 %t71)
  call void @olang_textcopy(ptr %t74, ptr %t70, i64 %t71)
  %t75 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  %t78 = load ptr, ptr %l25, !tbaa !29
  %t79 = getelementptr %"compiler/lineedit:Editor", ptr %t78, i32 0, i32 16
  %t80 = load { i64, ptr }, ptr %t79, !tbaa !27
  store { i64, ptr } %t80, ptr %l38, !tbaa !27
  %t82 = load ptr, ptr %l25, !tbaa !29
  %t83 = getelementptr %"compiler/lineedit:Editor", ptr %t82, i32 0, i32 16
  store { i64, ptr } %t76, ptr %t83, !tbaa !27
  %t84 = load i1, ptr @olang_2esole_2ecompiler_2flineedit_3aEditor_2e16
  br i1 %t84, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_55814703dba0f3c7_baa829e140d7f09b)
  unreachable
bb15:
  %t86 = load { i64, ptr }, ptr %l38
  %t87 = extractvalue { i64, ptr } %t86, 1
  call void @__olang_region_release(ptr %t87)
  store { i64, ptr } zeroinitializer, ptr %l38
  br label %bb16
bb16:
  %t88 = load i64, ptr %l4, !tbaa !24
  %t89 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t89, 0
  %t94 = icmp eq i64 %t88, %t91
  br i1 %t94, label %bb17, label %bb18
bb17:
  %t96 = load i64, ptr %l3, !tbaa !24
  %t98 = icmp sgt i64 %t96, 0
  store i1 %t98, ptr %l44, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb19
bb19:
  %t100 = load i1, ptr %l44, !tbaa !21
  br i1 %t100, label %bb20, label %bb21
bb20:
  %t101 = load i64, ptr %l3, !tbaa !24
  %t103 = sub i64 %t101, 1
  store i64 %t103, ptr %l47, !tbaa !24
  br label %bb22
bb21:
  %t105 = load i64, ptr %l3, !tbaa !24
  store i64 %t105, ptr %l47, !tbaa !24
  br label %bb22
bb22:
  %t107 = load i64, ptr %l47, !tbaa !24
  store i64 %t107, ptr %l5, !tbaa !24
  %t108 = load i64, ptr %l4, !tbaa !24
  %t109 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t109, 0
  %t114 = icmp slt i64 %t108, %t111
  br i1 %t114, label %bb23, label %bb24
bb23:
  %t116 = load i64, ptr %l4, !tbaa !24
  %t118 = add i64 %t116, 1
  store i64 %t118, ptr %l55, !tbaa !24
  br label %bb25
bb24:
  %t120 = load i64, ptr %l4, !tbaa !24
  store i64 %t120, ptr %l55, !tbaa !24
  br label %bb25
bb25:
  %t122 = load i64, ptr %l55, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/lineedit:Editor", ptr %t123, i32 0, i32 16
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  store { i64, ptr } %t126, ptr %l7, !tbaa !27
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load i64, ptr %l5, !tbaa !24
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eremove(ptr %v0, ptr %t128, i64 %t129, i64 %t122, i1 false)
  br label %bb26
bb26:
  %t134 = load ptr, ptr %l0, !tbaa !29
  store ptr %t134, ptr %l64, !tbaa !29
  %t135 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t136 = load ptr, ptr %l64, !tbaa !29
  %t137 = getelementptr %"compiler/lineedit:Editor", ptr %t136, i32 0, i32 16
  %t138 = load { i64, ptr }, ptr %t137, !tbaa !27
  store { i64, ptr } %t138, ptr %l66, !tbaa !27
  %t140 = load ptr, ptr %l64, !tbaa !29
  %t141 = getelementptr %"compiler/lineedit:Editor", ptr %t140, i32 0, i32 16
  store { i64, ptr } %t135, ptr %t141, !tbaa !27
  %t142 = load i1, ptr @olang_2esole_2ecompiler_2flineedit_3aEditor_2e16
  br i1 %t142, label %bb27, label %bb28
bb27:
  %t144 = load { i64, ptr }, ptr %l66
  %t145 = extractvalue { i64, ptr } %t144, 1
  call void @__olang_region_release(ptr %t145)
  store { i64, ptr } zeroinitializer, ptr %l66
  br label %bb28
bb28:
  %t146 = load ptr, ptr %l0, !tbaa !29
  store ptr %t146, ptr %l68, !tbaa !29
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/lineedit:Editor", ptr %t147, i32 0, i32 3
  %t150 = load { i64, ptr }, ptr %t149, !tbaa !27
  store { i64, ptr } %t150, ptr %l70, !tbaa !27
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/lineedit:Editor", ptr %t151, i32 0, i32 4
  %t154 = load i64, ptr %t153, !tbaa !24
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/lineedit:Editor", ptr %t155, i32 0, i32 3
  %t158 = load { i64, ptr }, ptr %t157, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t158, 0
  %t163 = icmp sle i64 %t154, %t160
  br i1 %t163, label %bb29, label %bb30
bb29:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/lineedit:Editor", ptr %t165, i32 0, i32 4
  %t168 = load i64, ptr %t167, !tbaa !24
  store i64 %t168, ptr %l77, !tbaa !24
  br label %bb31
bb30:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/lineedit:Editor", ptr %t170, i32 0, i32 3
  %t173 = load { i64, ptr }, ptr %t172, !tbaa !27
  %t175 = extractvalue { i64, ptr } %t173, 0
  store i64 %t175, ptr %l77, !tbaa !24
  br label %bb31
bb31:
  %t177 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t178 = load i64, ptr %l77, !tbaa !24
  %t179 = call i64 @compiler_2flineedit_2efirstWord(ptr %v0, { i64, ptr } %t177, i64 %t178)
  store i64 %t179, ptr %l83
  br label %bb32
bb32:
  %t180 = load i64, ptr %l83, !tbaa !24
  %t181 = load ptr, ptr %l68, !tbaa !29
  %t182 = getelementptr %"compiler/lineedit:Editor", ptr %t181, i32 0, i32 4
  store i64 %t180, ptr %t182, !tbaa !24
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2flineedit_2edecode(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca i64
  %l3 = alloca i8
  %l4 = alloca %"std/prelude/text:StringBuilder"
  %l10 = alloca { i64, ptr }
  %l15 = alloca i1
  %l24 = alloca { i64, ptr }
  %l28 = alloca i8
  %l29 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l4
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l4
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  br label %bb2
bb2:
  %t3 = load i64, ptr %l2, !tbaa !24
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t9 = icmp slt i64 %t3, %t6
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  br label %bb17
bb4:
  br label %bb5
bb5:
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t13, ptr %l10, !tbaa !27
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr i8, ptr %t17, i64 %t14
  %t19 = load i8, ptr %t18, !tbaa !32
  store i8 %t19, ptr %l3, !tbaa !22
  %t21 = load i8, ptr %l3, !tbaa !22
  %t23 = icmp eq i8 %t21, 92
  br i1 %t23, label %bb6, label %bb7
bb6:
  %t25 = load i64, ptr %l2, !tbaa !24
  %t27 = add i64 %t25, 1
  %t28 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  %t33 = icmp slt i64 %t27, %t30
  store i1 %t33, ptr %l15, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb8
bb8:
  %t35 = load i1, ptr %l15, !tbaa !21
  br i1 %t35, label %bb9, label %bb10
bb9:
  %t36 = load i64, ptr %l2, !tbaa !24
  %t39 = add i64 %t36, 1
  store i64 %t39, ptr %l2, !tbaa !24
  %t41 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t41, ptr %l24, !tbaa !27
  %t42 = load i64, ptr %l2, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr i8, ptr %t45, i64 %t42
  %t47 = load i8, ptr %t46, !tbaa !32
  %t49 = icmp eq i8 %t47, 110
  br i1 %t49, label %bb11, label %bb12
bb10:
  br label %bb14
bb11:
  store i8 10, ptr %l28, !tbaa !22
  br label %bb13
bb12:
  %t51 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t51, ptr %l29, !tbaa !27
  %t52 = load i64, ptr %l2, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i8, ptr %t55, i64 %t52
  %t57 = load i8, ptr %t56, !tbaa !32
  store i8 %t57, ptr %l28, !tbaa !22
  br label %bb13
bb13:
  %t59 = load i8, ptr %l28, !tbaa !22
  store i8 %t59, ptr %l3, !tbaa !22
  br label %bb14
bb14:
  %t60 = load i8, ptr %l3, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 %t60)
  br label %bb15
bb15:
  %t63 = load i64, ptr %l2, !tbaa !24
  %t66 = add i64 %t63, 1
  store i64 %t66, ptr %l2, !tbaa !24
  br label %bb16
bb16:
  br label %bb2
bb17:
  %t69 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t69, ptr %l38
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s0)
  %t70 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t70, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2flineedit_3aEditor_2ector(ptr %out, ptr %v0, i1 %a0, i1 %a1, i64 %a2) #0 {
entry:
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i1
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca i64
  %l22 = alloca i1
  %l23 = alloca i1
  %l24 = alloca i1
  %l25 = alloca i1
  %l26 = alloca i1
  %l27 = alloca i1
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i1
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i8
  %l37 = alloca i64
  %l43 = alloca i64
  %l45 = alloca %"std/prelude/text:StringBuilder"
  %l47 = alloca i64
  %l49 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l51 = alloca i64
  %l53 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l55 = alloca i64
  %l57 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l59 = alloca %"compiler/lineedit:Editor"
  br label %start
start:
  br label %bb0
bb0:
  store i1 %a0, ptr %l3, !tbaa !21
  store i1 %a1, ptr %l4, !tbaa !21
  store i64 %a2, ptr %l5, !tbaa !24
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d49, i32 0, i32 1) }, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  store i1 false, ptr %l8, !tbaa !21
  %t7 = call ptr @__olang_scope_hold(ptr %v0)
  %t8 = ptrtoint ptr %t7 to i64
  store i64 %t8, ptr %l43, !tbaa !24
  %t9 = load i1, ptr @olang_2esole_2ecompiler_2flineedit_3aEditor_2e6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = call ptr @__olang_region_make(ptr %v0)
  %t12 = ptrtoint ptr %t11 to i64
  store i64 %t12, ptr %l43, !tbaa !24
  br label %bb2
bb2:
  %t13 = load i64, ptr %l43
  %t14 = inttoptr i64 %t13 to ptr
  %t15 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %t14)
  store %"std/prelude/text:StringBuilder" %t15, ptr %l45
  br label %bb3
bb3:
  %t16 = load i1, ptr @olang_2esole_2ecompiler_2flineedit_3aEditor_2e6
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t18 = load i64, ptr %l43
  %t19 = inttoptr i64 %t18 to ptr
  %t20 = getelementptr %"std/prelude/text:StringBuilder", ptr %l45, i32 0, i32 0
  %t21 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t20, i32 0, i32 0
  %t22 = load { i64, ptr }, ptr %t21
  %t23 = extractvalue { i64, ptr } %t22, 1
  %t24 = call ptr @__olang_region_or(ptr %t23, ptr null)
  %t25 = call ptr @__olang_region_home(ptr %t24)
  %t26 = icmp ne ptr %t25, null
  %t27 = select i1 %t26, ptr %t25, ptr null
  call void @__olang_region_settle_in(ptr %t19, ptr %t27)
  br label %bb5
bb5:
  %t28 = load %"std/prelude/text:StringBuilder", ptr %l45
  store %"std/prelude/text:StringBuilder" %t28, ptr %l9
  %t29 = call ptr @__olang_scope_hold(ptr %v0)
  %t30 = ptrtoint ptr %t29 to i64
  store i64 %t30, ptr %l47, !tbaa !24
  %t31 = load i1, ptr @olang_2esole_2ecompiler_2flineedit_3aEditor_2e7
  br i1 %t31, label %bb6, label %bb7
bb6:
  %t33 = call ptr @__olang_region_make(ptr %v0)
  %t34 = ptrtoint ptr %t33 to i64
  store i64 %t34, ptr %l47, !tbaa !24
  br label %bb7
bb7:
  %t35 = load i64, ptr %l47
  %t36 = inttoptr i64 %t35 to ptr
  %t37 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t36, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t37, ptr %l49
  br label %bb8
bb8:
  %t38 = load i1, ptr @olang_2esole_2ecompiler_2flineedit_3aEditor_2e7
  br i1 %t38, label %bb9, label %bb10
bb9:
  %t40 = load i64, ptr %l47
  %t41 = inttoptr i64 %t40 to ptr
  %t42 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l49, i32 0, i32 0
  %t43 = load { i64, ptr }, ptr %t42
  %t44 = extractvalue { i64, ptr } %t43, 1
  %t45 = call ptr @__olang_region_or(ptr %t44, ptr null)
  %t46 = call ptr @__olang_region_home(ptr %t45)
  %t47 = icmp ne ptr %t46, null
  %t48 = select i1 %t47, ptr %t46, ptr null
  call void @__olang_region_settle_in(ptr %t41, ptr %t48)
  br label %bb10
bb10:
  %t49 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l49
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t49, ptr %l10
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d50, i32 0, i32 1) }, ptr %l11, !tbaa !27
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d51, i32 0, i32 1) }, ptr %l12, !tbaa !27
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d52, i32 0, i32 1) }, ptr %l13, !tbaa !27
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d53, i32 0, i32 1) }, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d54, i32 0, i32 1) }, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d55, i32 0, i32 1) }, ptr %l18, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d56, i32 0, i32 1) }, ptr %l19, !tbaa !27
  %t50 = call ptr @__olang_scope_hold(ptr %v0)
  %t51 = ptrtoint ptr %t50 to i64
  store i64 %t51, ptr %l51, !tbaa !24
  %t52 = load i1, ptr @olang_2esole_2ecompiler_2flineedit_3aEditor_2e17
  br i1 %t52, label %bb11, label %bb12
bb11:
  %t54 = call ptr @__olang_region_make(ptr %v0)
  %t55 = ptrtoint ptr %t54 to i64
  store i64 %t55, ptr %l51, !tbaa !24
  br label %bb12
bb12:
  %t56 = load i64, ptr %l51
  %t57 = inttoptr i64 %t56 to ptr
  %t58 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2flineedit_3asnap_3e_2ector(ptr %t57, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t58, ptr %l53
  br label %bb13
bb13:
  %t59 = load i1, ptr @olang_2esole_2ecompiler_2flineedit_3aEditor_2e17
  br i1 %t59, label %bb14, label %bb15
bb14:
  %t61 = load i64, ptr %l51
  %t62 = inttoptr i64 %t61 to ptr
  %t63 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l53, i32 0, i32 0
  %t64 = load { i64, ptr }, ptr %t63
  %t65 = extractvalue { i64, ptr } %t64, 1
  %t66 = call ptr @__olang_region_or(ptr %t65, ptr null)
  %t67 = call ptr @__olang_region_home(ptr %t66)
  %t68 = icmp ne ptr %t67, null
  %t69 = select i1 %t68, ptr %t67, ptr null
  call void @__olang_region_settle_in(ptr %t62, ptr %t69)
  br label %bb15
bb15:
  %t70 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l53
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t70, ptr %l20
  store i64 0, ptr %l21, !tbaa !24
  store i1 false, ptr %l22, !tbaa !21
  store i1 false, ptr %l23, !tbaa !21
  store i1 false, ptr %l24, !tbaa !21
  store i1 false, ptr %l25, !tbaa !21
  store i1 false, ptr %l26, !tbaa !21
  store i1 true, ptr %l27, !tbaa !21
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d57, i32 0, i32 1) }, ptr %l28, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d58, i32 0, i32 1) }, ptr %l29, !tbaa !27
  store i64 0, ptr %l30, !tbaa !24
  store i1 false, ptr %l31, !tbaa !21
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d59, i32 0, i32 1) }, ptr %l32, !tbaa !27
  store i64 0, ptr %l33, !tbaa !24
  store i64 0, ptr %l34, !tbaa !24
  store i64 0, ptr %l35, !tbaa !24
  store i8 0, ptr %l36, !tbaa !22
  store i64 1, ptr %l37, !tbaa !24
  %t71 = call ptr @__olang_scope_hold(ptr %v0)
  %t72 = ptrtoint ptr %t71 to i64
  store i64 %t72, ptr %l55, !tbaa !24
  %t73 = load i1, ptr @olang_2esole_2ecompiler_2flineedit_3aEditor_2e35
  br i1 %t73, label %bb16, label %bb17
bb16:
  %t75 = call ptr @__olang_region_make(ptr %v0)
  %t76 = ptrtoint ptr %t75 to i64
  store i64 %t76, ptr %l55, !tbaa !24
  br label %bb17
bb17:
  %t77 = load i64, ptr %l55
  %t78 = inttoptr i64 %t77 to ptr
  %t79 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cU8_3e_2ector(ptr %t78, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t79, ptr %l57
  br label %bb18
bb18:
  %t80 = load i1, ptr @olang_2esole_2ecompiler_2flineedit_3aEditor_2e35
  br i1 %t80, label %bb19, label %bb20
bb19:
  %t82 = load i64, ptr %l55
  %t83 = inttoptr i64 %t82 to ptr
  %t84 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l57, i32 0, i32 0
  %t85 = load { i64, ptr }, ptr %t84
  %t86 = extractvalue { i64, ptr } %t85, 1
  %t87 = call ptr @__olang_region_or(ptr %t86, ptr null)
  %t88 = call ptr @__olang_region_home(ptr %t87)
  %t89 = icmp ne ptr %t88, null
  %t90 = select i1 %t89, ptr %t88, ptr null
  call void @__olang_region_settle_in(ptr %t83, ptr %t90)
  br label %bb20
bb20:
  %t91 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l57
  %t92 = getelementptr %"compiler/lineedit:Editor", ptr %l59, i32 0, i32 0
  %t93 = load i1, ptr %l3, !tbaa !21
  store i1 %t93, ptr %t92, !tbaa !21
  %t94 = getelementptr %"compiler/lineedit:Editor", ptr %l59, i32 0, i32 1
  %t95 = load i1, ptr %l4, !tbaa !21
  store i1 %t95, ptr %t94, !tbaa !21
  %t96 = getelementptr %"compiler/lineedit:Editor", ptr %l59, i32 0, i32 2
  %t97 = load i64, ptr %l5, !tbaa !24
  store i64 %t97, ptr %t96, !tbaa !24
  %t98 = getelementptr %"compiler/lineedit:Editor", ptr %l59, i32 0, i32 3
  %t99 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t99, ptr %t98, !tbaa !27
  %t100 = getelementptr %"compiler/lineedit:Editor", ptr %l59, i32 0, i32 4
  %t101 = load i64, ptr %l7, !tbaa !24
  store i64 %t101, ptr %t100, !tbaa !24
  %t102 = getelementptr %"compiler/lineedit:Editor", ptr %l59, i32 0, i32 5
  %t103 = load i1, ptr %l8, !tbaa !21
  store i1 %t103, ptr %t102, !tbaa !21
  %t104 = getelementptr %"compiler/lineedit:Editor", ptr %l59, i32 0, i32 6
  %t105 = load %"std/prelude/text:StringBuilder", ptr %l9
  store %"std/prelude/text:StringBuilder" %t105, ptr %t104
  %t106 = getelementptr %"compiler/lineedit:Editor", ptr %l59, i32 0, i32 7
  %t107 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t107, ptr %t106
  %t108 = getelementptr %"compiler/lineedit:Editor", ptr %l59, i32 0, i32 8
  %t109 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t109, ptr %t108, !tbaa !27
  %t110 = getelementptr %"compiler/lineedit:Editor", ptr %l59, i32 0, i32 9
  %t111 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t111, ptr %t110, !tbaa !27
  %t112 = getelementptr %"compiler/lineedit:Editor", ptr %l59, i32 0, i32 10
  %t113 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t113, ptr %t112, !tbaa !27
  %t114 = getelementptr %"compiler/lineedit:Editor", ptr %l59, i32 0, i32 11
  %t115 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t115, ptr %t114, !tbaa !27
  %t116 = getelementptr %"compiler/lineedit:Editor", ptr %l59, i32 0, i32 12
  %t117 = load i64, ptr %l15, !tbaa !24
  store i64 %t117, ptr %t116, !tbaa !24
  %t118 = getelementptr %"compiler/lineedit:Editor", ptr %l59, i32 0, i32 13
  %t119 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t119, ptr %t118, !tbaa !27
  %t120 = getelementptr %"compiler/lineedit:Editor", ptr %l59, i32 0, i32 14
  %t121 = load i64, ptr %l17, !tbaa !24
  store i64 %t121, ptr %t120, !tbaa !24
  %t122 = getelementptr %"compiler/lineedit:Editor", ptr %l59, i32 0, i32 15
  %t123 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t123, ptr %t122, !tbaa !27
  %t124 = getelementptr %"compiler/lineedit:Editor", ptr %l59, i32 0, i32 16
  %t125 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t125, ptr %t124, !tbaa !27
  %t126 = getelementptr %"compiler/lineedit:Editor", ptr %l59, i32 0, i32 17
  %t127 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t127, ptr %t126
  %t128 = getelementptr %"compiler/lineedit:Editor", ptr %l59, i32 0, i32 18
  %t129 = load i64, ptr %l21, !tbaa !24
  store i64 %t129, ptr %t128, !tbaa !24
  %t130 = getelementptr %"compiler/lineedit:Editor", ptr %l59, i32 0, i32 19
  %t131 = load i1, ptr %l22, !tbaa !21
  store i1 %t131, ptr %t130, !tbaa !21
  %t132 = getelementptr %"compiler/lineedit:Editor", ptr %l59, i32 0, i32 20
  %t133 = load i1, ptr %l23, !tbaa !21
  store i1 %t133, ptr %t132, !tbaa !21
  %t134 = getelementptr %"compiler/lineedit:Editor", ptr %l59, i32 0, i32 21
  %t135 = load i1, ptr %l24, !tbaa !21
  store i1 %t135, ptr %t134, !tbaa !21
  %t136 = getelementptr %"compiler/lineedit:Editor", ptr %l59, i32 0, i32 22
  %t137 = load i1, ptr %l25, !tbaa !21
  store i1 %t137, ptr %t136, !tbaa !21
  %t138 = getelementptr %"compiler/lineedit:Editor", ptr %l59, i32 0, i32 23
  %t139 = load i1, ptr %l26, !tbaa !21
  store i1 %t139, ptr %t138, !tbaa !21
  %t140 = getelementptr %"compiler/lineedit:Editor", ptr %l59, i32 0, i32 24
  %t141 = load i1, ptr %l27, !tbaa !21
  store i1 %t141, ptr %t140, !tbaa !21
  %t142 = getelementptr %"compiler/lineedit:Editor", ptr %l59, i32 0, i32 25
  %t143 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t143, ptr %t142, !tbaa !27
  %t144 = getelementptr %"compiler/lineedit:Editor", ptr %l59, i32 0, i32 26
  %t145 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t145, ptr %t144, !tbaa !27
  %t146 = getelementptr %"compiler/lineedit:Editor", ptr %l59, i32 0, i32 27
  %t147 = load i64, ptr %l30, !tbaa !24
  store i64 %t147, ptr %t146, !tbaa !24
  %t148 = getelementptr %"compiler/lineedit:Editor", ptr %l59, i32 0, i32 28
  %t149 = load i1, ptr %l31, !tbaa !21
  store i1 %t149, ptr %t148, !tbaa !21
  %t150 = getelementptr %"compiler/lineedit:Editor", ptr %l59, i32 0, i32 29
  %t151 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t151, ptr %t150, !tbaa !27
  %t152 = getelementptr %"compiler/lineedit:Editor", ptr %l59, i32 0, i32 30
  %t153 = load i64, ptr %l33, !tbaa !24
  store i64 %t153, ptr %t152, !tbaa !24
  %t154 = getelementptr %"compiler/lineedit:Editor", ptr %l59, i32 0, i32 31
  %t155 = load i64, ptr %l34, !tbaa !24
  store i64 %t155, ptr %t154, !tbaa !24
  %t156 = getelementptr %"compiler/lineedit:Editor", ptr %l59, i32 0, i32 32
  %t157 = load i64, ptr %l35, !tbaa !24
  store i64 %t157, ptr %t156, !tbaa !24
  %t158 = getelementptr %"compiler/lineedit:Editor", ptr %l59, i32 0, i32 33
  %t159 = load i8, ptr %l36, !tbaa !22
  store i8 %t159, ptr %t158, !tbaa !22
  %t160 = getelementptr %"compiler/lineedit:Editor", ptr %l59, i32 0, i32 34
  %t161 = load i64, ptr %l37, !tbaa !24
  store i64 %t161, ptr %t160, !tbaa !24
  %t162 = getelementptr %"compiler/lineedit:Editor", ptr %l59, i32 0, i32 35
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t91, ptr %t162
  %t164 = getelementptr %"compiler/lineedit:Editor", ptr %l59, i32 0, i32 36
  store i64 0, ptr %t164, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l59, i64 432, i1 false)
  br label %ret
ret:
  ret void
}

declare void @__olang_check_failed(ptr) cold noreturn
declare void @__olang_errpay_pop()
@.d0 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\00" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare i32 @open(ptr, i32, ...)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d1 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare i32 @close(i32)
declare i32 @ioctl(i32, i64, ptr)
@.d2 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\0D\0A" }>, align 8
@.d3 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d4 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d5 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d6 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d7 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\1B" }>, align 8
@.d8 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2flineedit_3aEditor_2e15 = weak hidden constant i1 false
declare void @__olang_region_release(ptr) noinline
@olang_2esole_2ecompiler_2flineedit_3aEditor_2e8 = weak hidden constant i1 false
@.d9 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d10 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d11 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
@.d12 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
define linkonce_odr %"<termios.h>:termios" @olang_2emir_2eHelperKind_2eZero_2e_3ctermios_2eh_3e_3atermios() #0 {
entry:
  %l0 = alloca %"<termios.h>:termios"
  %rv = alloca %"<termios.h>:termios"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"<termios.h>:termios" @_3ctermios_2eh_3e_3atermios_2ector(ptr %t1)
  store %"<termios.h>:termios" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"<termios.h>:termios", ptr %l0
  store %"<termios.h>:termios" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"<termios.h>:termios", ptr %rv
  ret %"<termios.h>:termios" %rr
}

declare i32 @tcgetattr(i32, ptr)
declare i32 @tcsetattr(i32, i32, ptr)
@.d13 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"\1B[?2004h" }>, align 8
@.d14 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"\1B[?2004l" }>, align 8
@.d15 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d16 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d17 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2flineedit_3aEditor_2e25 = weak hidden constant i1 false
@.d18 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@olang_2esole_2ecompiler_2flineedit_3aEditor_2e3 = weak hidden constant i1 false
@.d19 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\1B[" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d20 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"A" }>, align 8
@.d21 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"\0D\1B[J" }>, align 8
@.d22 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d23 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d24 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\0D\0A" }>, align 8
@.d25 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\0D\0A" }>, align 8
@.d26 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\0D\0A" }>, align 8
@.d27 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\1B[" }>, align 8
@.d28 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"A" }>, align 8
@.d29 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0D" }>, align 8
@.d30 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\1B[" }>, align 8
@.d31 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"C" }>, align 8
@.d32 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d33 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d34 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\0D\0A" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare i64 @read(i32, ptr, i64)
@.d35 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@.d36 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2flineedit_3aEditor_2e16 = weak hidden constant i1 false
@.d37 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"200" }>, align 8
@.d38 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"201" }>, align 8
@.d39 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"200" }>, align 8
@.d40 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"1" }>, align 8
@.d41 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"7" }>, align 8
@.d42 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"4" }>, align 8
@.d43 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"8" }>, align 8
@.d44 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"3" }>, align 8
@.d45 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d46 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"?" }>, align 8
@.d47 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"(failed search) " }>, align 8
@.d48 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"(search) " }>, align 8
@.d49 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2flineedit_3aEditor_2e6 = weak hidden constant i1 false
declare ptr @__olang_region_or(ptr, ptr)
declare ptr @__olang_region_home(ptr)
declare void @__olang_region_settle_in(ptr, ptr)
@olang_2esole_2ecompiler_2flineedit_3aEditor_2e7 = weak hidden constant i1 false
@.d50 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d51 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c">>> " }>, align 8
@.d52 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"... " }>, align 8
@.d53 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"::: " }>, align 8
@.d54 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d55 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d56 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2flineedit_3aEditor_2e17 = weak hidden constant i1 false
@.d57 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d58 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d59 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2flineedit_3aEditor_2e35 = weak hidden constant i1 false
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
@__olang_prog_scope = external thread_local(initialexec) global ptr
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
@olang_loc_7dccba76dee48f7e_602c3d6b6ac3d592 = external constant [0 x i8]
declare i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %a0)
@G_2e_3cfcntl_2eh_3e_2eO__WRONLY = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eO__CREAT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\40\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eO__APPEND = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\04\00\00" }>, align 8
declare i32 @std_2fio_2eWrite(ptr %v0, i32 %a0, { i64, ptr } %a1)
@G_2e_3csys_2fioctl_2eh_3e_2eTIOCGWINSZ = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\13\54\00\00" }>, align 8
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2flineedit_2elineStart(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eRepeat_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eacceptSearch(ptr %v0, ptr %a0)
declare void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2etoNormal(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
@G_2ecompiler_2flineedit_2eKeep = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\E8\03\00\00\00\00\00\00" }>, align 8
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H9ea329edf73de23cd280575fae6d500d(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H563b551a62b57e684177c5454e33a204(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2flineedit_2eencode(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@G_2e_3ctermios_2eh_3e_2eBRKINT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2e_3ctermios_2eh_3e_2eICRNL = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\01\00\00" }>, align 8
@G_2e_3ctermios_2eh_3e_2eINPCK = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\10\00\00\00" }>, align 8
@G_2e_3ctermios_2eh_3e_2eISTRIP = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\20\00\00\00" }>, align 8
@G_2e_3ctermios_2eh_3e_2eIXON = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\04\00\00" }>, align 8
@G_2e_3ctermios_2eh_3e_2eOPOST = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2e_3ctermios_2eh_3e_2eECHO = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\08\00\00\00" }>, align 8
@G_2e_3ctermios_2eh_3e_2eICANON = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2e_3ctermios_2eh_3e_2eIEXTEN = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\80\00\00" }>, align 8
@G_2e_3ctermios_2eh_3e_2eISIG = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2e_3ctermios_2eh_3e_2eVMIN = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\06\00\00\00" }>, align 8
@G_2e_3ctermios_2eh_3e_2eVTIME = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\05\00\00\00" }>, align 8
@G_2e_3ctermios_2eh_3e_2eTCSANOW = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eBegin(ptr %v0, ptr %a0)
declare void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eflush(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eLen_3cU8_3e(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2efind(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eclamp(ptr %v0, ptr %a0)
declare i64 @compiler_2flineedit_2eprevAt(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_d9375333dfb29074_4c1db221b9426bf0 = external constant [0 x i8]
declare i64 @compiler_2flineedit_2elineEnd(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare i64 @compiler_2flineedit_2eoffsetOf(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2, i64 %a3)
declare void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eundo(ptr %v0, ptr %a0)
declare void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2edown(ptr %v0, ptr %a0)
declare void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eup(ptr %v0, ptr %a0)
declare void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2ebeginSearch(ptr %v0, ptr %a0, i1 %a1, i1 %a2)
declare { i64, ptr } @compiler_2fpaint_2eSource(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2flineedit_2ecells(ptr %v0, { i64, ptr } %a0)
@olang_loc_efd16dbbcc037fb0_1aeb292baa76ec64 = external constant [0 x i8]
declare i64 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eright(ptr %v0, ptr %a0)
declare i64 @compiler_2flineedit_2efirstWord(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare i8 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eAt_3cU8_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eFeed(ptr %v0, ptr %a0, i8 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eClear_3cU8_3e(ptr %v0, ptr %a0)
@olang_loc_9f82c4ae2fb92c09_610471f21aec4c45 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePushAll_3cU8_3e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2esave(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_126b4ead7e969a49_c70e2460580ad75 = external constant [0 x i8]
declare i64 @compiler_2flineedit_2enextAt(ptr %v0, { i64, ptr } %a0, i64 %a1)
@olang_loc_dd36f3cf990f8aca_64500bf1420cd6c6 = external constant [0 x i8]
@olang_loc_8dc6cdcca3960da7_c3faaa8d27204ea3 = external constant [0 x i8]
@olang_loc_d87e059e3fca2959_92a9b8111884af55 = external constant [0 x i8]
declare { i64, ptr } @compiler_2flineedit_2eone(ptr %v0, i8 %a0)
declare i32 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2estep(ptr %v0, ptr %a0, i8 %a1)
@olang_loc_c6edc95ce3a108e9_a40785e2dad47f45 = external constant [0 x i8]
declare i64 @compiler_2flineedit_2ewordEnd(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare i64 @compiler_2flineedit_2ewordBack(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare i64 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eleft(ptr %v0, ptr %a0)
@olang_loc_54806be5a60651c2_4a35e5984fb8c156 = external constant [0 x i8]
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
@olang_loc_55814703dba0f3c7_baa829e140d7f09b = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2flineedit_3asnap_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cU8_3e_2ector(ptr %v0, i64 %a0)
declare %"<termios.h>:termios" @_3ctermios_2eh_3e_3atermios_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
