; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" = type { { ptr, ptr } }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr } }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, ptr, i1, i1 }
%"compiler/generic:fnRow" = type { i64, ptr, i1 }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/ast:TypeParam" = type { %"compiler/source:Span", i32, ptr, { i64, ptr }, i1 }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, { i64, ptr }, i32 }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1, ptr, { i64, ptr } }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/generic:varRow" = type { i64, i32, i32, i32 }
%"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" = type { i64, i32 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:instance" = type { i64, i32, i32, { i64, ptr }, { i64, ptr }, %"compiler/generic:Origin" }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1, { i64, ptr }, i1 }
%"compiler/generic:Binding" = type { i64, i64, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:TopIf" = type { ptr, ptr, ptr, ptr }
%"compiler/generic:cursor" = type { { i64, ptr }, i64 }
%"compiler/generic:folded" = type { i64, i64, i32 }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr, { i64, ptr } }
%"compiler/names:Ref" = type { i32, i64, i64 }
%"compiler/ast:Path" = type { %"compiler/source:Span", { i64, ptr } }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" = type { ptr, i64 }
%"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" = type { i32, i32 }
%"compiler/generic:genRoots" = type { { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64 }
%"compiler/ast:Multi" = type { { i64, ptr }, i1, { i64, ptr } }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/ast:Catch" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i32, %"compiler/source:Span" }
%"compiler/ast:TopBranch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/generic:Unmet" = type { i64, i32, i32, i1, i1, i1 }
@G_2ecompiler_2fgeneric_2eArrayKey = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\02\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eDescCase = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eDescField = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eDescFunc = constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eDescNone = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eDescParam = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eDescResult = constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eFolded = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eGenFromReturn = constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2fgeneric_2eGenLocalBit = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\40" }>, align 8
@G_2ecompiler_2fgeneric_2eGenPerTurn = constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2fgeneric_2eListCases = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eListFields = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eListFunctions = constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eListMethods = constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eListParams = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eListResults = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eMaxChain = constant <{ [8 x i8] }> <{ [8 x i8] c"\E8\03\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eMaxDepth = constant <{ [8 x i8] }> <{ [8 x i8] c"\30\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eNoOrigin = constant <{ [24 x i8] }> <{ [24 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF\00\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2fgeneric_2ePending = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eRunTimeLength = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\80" }>, align 8
@G_2ecompiler_2fgeneric_2eUnfolded = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
define dso_local %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" @compiler_2fgeneric_2eFieldDecls(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l3 = alloca %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd"
  %rv = alloca %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t3 = ptrtoint ptr %t2 to i64
  %t4 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 %t3, i64 8)
  %t5 = getelementptr { ptr, ptr }, ptr %t4, i32 0, i32 0
  store ptr %a0, ptr %t5, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t7 = getelementptr { ptr, ptr }, ptr %t4, i32 0, i32 1
  store ptr %v0, ptr %t7, !tbaa !28
  %t8 = call ptr @olang_lambda_0.coro(ptr %t4, ptr %v1)
  call void @__olang_scope_register_dtor(ptr %v1, ptr %t8, ptr @olang_lambda_0.drop)
  %t9 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_0, 0
  %t10 = insertvalue { ptr, ptr } %t9, ptr %t8, 1
  %t12 = extractvalue { ptr, ptr } %t10, 0
  %t13 = extractvalue { ptr, ptr } %t10, 1
  %t14 = call %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" @std_2fprelude_2fiterator_3aViewGenerator_3ccompiler_2fast_3aVarDecl_3e_2ector(ptr %v0, ptr %v1, ptr %t12, ptr %t13)
  store %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" %t14, ptr %l3
  br label %bb1
bb1:
  %t15 = load %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd", ptr %l3
  store %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" %t15, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd", ptr %rv
  ret %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" %rr
}

define dso_local i64 @compiler_2fgeneric_2eFnOwner(i64 %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = mul i64 %a0, 2
  %t5 = add i64 %t3, 1
  store i64 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fgeneric_2eIsErrsArgOf(ptr %v0, ptr %a0) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i1 @compiler_2fgeneric_2eisErrsArg(ptr %v0, ptr %a0)
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  store i1 %t4, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fgeneric_2eLengthDecided(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i64 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i32
  %l39 = alloca i1
  %l40 = alloca { i64, ptr }
  %l44 = alloca i1
  %l45 = alloca i1
  %l46 = alloca { i64, ptr }
  %l50 = alloca i1
  %l51 = alloca i1
  %l52 = alloca { i64, ptr }
  %l57 = alloca i1
  %l58 = alloca { i64, ptr }
  %l67 = alloca i1
  %l68 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l77 = alloca i64
  %l78 = alloca i64
  %l79 = alloca i64
  %l84 = alloca { i64, ptr }
  %l86 = alloca i1
  %l87 = alloca i1
  %l89 = alloca i1
  %l90 = alloca i1
  %l92 = alloca i1
  %l93 = alloca i1
  %l95 = alloca i1
  %l99 = alloca { i64, ptr }
  %l100 = alloca i1
  %l101 = alloca i1
  %l104 = alloca { i64, ptr }
  %l105 = alloca i1
  %l106 = alloca i1
  %l108 = alloca i1
  %l109 = alloca i1
  %l112 = alloca { i64, ptr }
  %l113 = alloca i1
  %l117 = alloca { i64, ptr }
  %l118 = alloca i1
  %l119 = alloca i1
  %l122 = alloca { i64, ptr }
  %l123 = alloca i1
  %l124 = alloca i1
  %l126 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = extractvalue { i64, ptr } %a3, 1
  %t4 = extractvalue { i64, ptr } %a3, 0
  %t5 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t13 = load i64, ptr %l1, !tbaa !24
  store i64 %t13, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t15 = load i64, ptr %l5, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb93
bb3:
  br label %bb4
bb4:
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t23, ptr %l18, !tbaa !27
  %t24 = load i64, ptr %l5, !tbaa !24
  store i64 %t24, ptr %l19, !tbaa !24
  %t25 = load i64, ptr %l2, !tbaa !24
  store i64 %t25, ptr %l20, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t26, 0
  store i64 %t27, ptr %l21, !tbaa !24
  %t28 = load i64, ptr %l19, !tbaa !24
  %t29 = icmp sge i64 %t28, 0
  br i1 %t29, label %bb5, label %bb6
bb5:
  %t31 = load i64, ptr %l19, !tbaa !24
  %t32 = load i64, ptr %l20, !tbaa !24
  %t33 = icmp sle i64 %t31, %t32
  br i1 %t33, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_c152c1cd1761af15_fc7472910c385f59)
  unreachable
bb7:
  %t35 = load i64, ptr %l20, !tbaa !24
  %t36 = load i64, ptr %l21, !tbaa !24
  %t37 = icmp sle i64 %t35, %t36
  br i1 %t37, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_c152c1cd1761af15_fc7472910c385f59)
  unreachable
bb9:
  %t39 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = load i64, ptr %l19, !tbaa !24
  %t42 = load i64, ptr %l20, !tbaa !24
  %t43 = getelementptr i8, ptr %t40, i64 %t41
  %t44 = sub i64 %t42, %t41
  %t45 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t43, 1
  %t47 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t50 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s0, { i64, ptr } %t46, { i64, ptr } %t47)
  %t51 = extractvalue { i32, i64 } %t50, 1
  %t52 = extractvalue { i32, i64 } %t50, 0
  store i32 %t52, ptr %l28
  %t53 = icmp ne i32 %t52, 0
  br i1 %t53, label %bb12, label %ok.54, !prof !99
ok.54:
  store i64 %t51, ptr %l27
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_c152c1cd1761af15_fc7472910c385f59)
  unreachable
bb11:
  %t55 = load i64, ptr %l27, !tbaa !24
  store i64 %t55, ptr %l17, !tbaa !24
  br label %bb14
bb12:
  br label %bb13
bb13:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb14:
  %t57 = load i64, ptr %l17, !tbaa !24
  %t58 = load i64, ptr %l5, !tbaa !24
  %t62 = add i64 %t58, %t57
  store i64 %t62, ptr %l7, !tbaa !24
  %t64 = load i64, ptr %l7, !tbaa !24
  %t65 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t65, 0
  %t70 = add i64 %t64, %t67
  store i64 %t70, ptr %l5, !tbaa !24
  %t72 = load i64, ptr %l7, !tbaa !24
  %t74 = icmp sgt i64 %t72, 0
  br i1 %t74, label %bb15, label %bb16
bb15:
  %t76 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t76, ptr %l40, !tbaa !27
  %t77 = load i64, ptr %l7, !tbaa !24
  %t79 = sub i64 %t77, 1
  %t81 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr i8, ptr %t82, i64 %t79
  %t84 = load i8, ptr %t83, !tbaa !32
  %t86 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t84)
  store i1 %t86, ptr %l44
  br label %bb17
bb16:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb28
bb17:
  %t87 = load i1, ptr %l44, !tbaa !21
  br i1 %t87, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb21
bb19:
  %t88 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t88, ptr %l46, !tbaa !27
  %t89 = load i64, ptr %l7, !tbaa !24
  %t91 = sub i64 %t89, 1
  %t93 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr i8, ptr %t94, i64 %t91
  %t96 = load i8, ptr %t95, !tbaa !32
  %t98 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t96)
  store i1 %t98, ptr %l50
  br label %bb20
bb20:
  %t99 = load i1, ptr %l50, !tbaa !21
  store i1 %t99, ptr %l45, !tbaa !21
  br label %bb21
bb21:
  %t100 = load i1, ptr %l45, !tbaa !21
  br i1 %t100, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb24
bb23:
  %t101 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t101, ptr %l52, !tbaa !27
  %t102 = load i64, ptr %l7, !tbaa !24
  %t104 = sub i64 %t102, 1
  %t106 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = getelementptr i8, ptr %t107, i64 %t104
  %t109 = load i8, ptr %t108, !tbaa !32
  %t111 = icmp eq i8 %t109, 95
  store i1 %t111, ptr %l51, !tbaa !21
  br label %bb24
bb24:
  %t113 = load i1, ptr %l51, !tbaa !21
  br i1 %t113, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l57, !tbaa !21
  br label %bb27
bb26:
  %t114 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t114, ptr %l58, !tbaa !27
  %t115 = load i64, ptr %l7, !tbaa !24
  %t117 = sub i64 %t115, 1
  %t119 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr i8, ptr %t120, i64 %t117
  %t122 = load i8, ptr %t121, !tbaa !32
  %t124 = icmp eq i8 %t122, 46
  store i1 %t124, ptr %l57, !tbaa !21
  br label %bb27
bb27:
  %t126 = load i1, ptr %l57, !tbaa !21
  store i1 %t126, ptr %l39, !tbaa !21
  br label %bb28
bb28:
  %t127 = load i1, ptr %l39, !tbaa !21
  br i1 %t127, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s2)
  br label %bb92
bb30:
  br label %bb31
bb31:
  %t128 = load i64, ptr %l7, !tbaa !24
  store i64 %t128, ptr %l8, !tbaa !24
  br label %bb32
bb32:
  %t130 = load i64, ptr %l8, !tbaa !24
  %t131 = load i64, ptr %l1, !tbaa !24
  %t134 = icmp sgt i64 %t130, %t131
  br i1 %t134, label %bb33, label %bb34
bb33:
  %t136 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t136, ptr %l68, !tbaa !27
  %t137 = load i64, ptr %l8, !tbaa !24
  %t139 = sub i64 %t137, 1
  %t141 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !27
  %t143 = getelementptr i8, ptr %t142, i64 %t139
  %t144 = load i8, ptr %t143, !tbaa !32
  %t146 = icmp ne i8 %t144, 10
  store i1 %t146, ptr %l67, !tbaa !21
  br label %bb35
bb34:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb35
bb35:
  %t148 = load i1, ptr %l67, !tbaa !21
  %t149 = xor i1 %t148, true
  br i1 %t149, label %bb36, label %bb37
bb36:
  br label %bb40
bb37:
  br label %bb38
bb38:
  %t151 = load i64, ptr %l8, !tbaa !24
  %t153 = sub i64 %t151, 1
  store i64 %t153, ptr %l8, !tbaa !24
  br label %bb39
bb39:
  br label %bb32
bb40:
  %t155 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t155, ptr %l76, !tbaa !27
  %t156 = load i64, ptr %l8, !tbaa !24
  store i64 %t156, ptr %l77, !tbaa !24
  %t157 = load i64, ptr %l7, !tbaa !24
  store i64 %t157, ptr %l78, !tbaa !24
  %t158 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t159 = extractvalue { i64, ptr } %t158, 0
  store i64 %t159, ptr %l79, !tbaa !24
  %t160 = load i64, ptr %l77, !tbaa !24
  %t161 = icmp sge i64 %t160, 0
  br i1 %t161, label %bb41, label %bb42
bb41:
  %t163 = load i64, ptr %l77, !tbaa !24
  %t164 = load i64, ptr %l78, !tbaa !24
  %t165 = icmp sle i64 %t163, %t164
  br i1 %t165, label %bb43, label %bb44
bb42:
  call void @__olang_check_failed(ptr @olang_loc_e975feb741415938_3766dae77ababfac)
  unreachable
bb43:
  %t167 = load i64, ptr %l78, !tbaa !24
  %t168 = load i64, ptr %l79, !tbaa !24
  %t169 = icmp sle i64 %t167, %t168
  br i1 %t169, label %bb45, label %bb46
bb44:
  call void @__olang_check_failed(ptr @olang_loc_e975feb741415938_3766dae77ababfac)
  unreachable
bb45:
  %t171 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !27
  %t173 = load i64, ptr %l77, !tbaa !24
  %t174 = load i64, ptr %l78, !tbaa !24
  %t175 = getelementptr i8, ptr %t172, i64 %t173
  %t176 = sub i64 %t174, %t173
  %t177 = insertvalue { i64, ptr } undef, i64 %t176, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t175, 1
  %t180 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %v0, ptr %v0, { i64, ptr } %t178)
  store { i64, ptr } %t180, ptr %l84
  br label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_e975feb741415938_3766dae77ababfac)
  unreachable
bb47:
  %t181 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t181, ptr %l9, !tbaa !27
  %t182 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t184 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t182, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i1 %t184, ptr %l86
  br label %bb48
bb48:
  %t185 = load i1, ptr %l86, !tbaa !21
  br i1 %t185, label %bb49, label %bb50
bb49:
  store i1 true, ptr %l87, !tbaa !21
  br label %bb52
bb50:
  %t186 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t188 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t186, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i1 %t188, ptr %l89
  br label %bb51
bb51:
  %t189 = load i1, ptr %l89, !tbaa !21
  store i1 %t189, ptr %l87, !tbaa !21
  br label %bb52
bb52:
  %t190 = load i1, ptr %l87, !tbaa !21
  br i1 %t190, label %bb53, label %bb54
bb53:
  store i1 true, ptr %l90, !tbaa !21
  br label %bb56
bb54:
  %t191 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t193 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t191, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store i1 %t193, ptr %l92
  br label %bb55
bb55:
  %t194 = load i1, ptr %l92, !tbaa !21
  store i1 %t194, ptr %l90, !tbaa !21
  br label %bb56
bb56:
  %t195 = load i1, ptr %l90, !tbaa !21
  br i1 %t195, label %bb57, label %bb58
bb57:
  store i1 true, ptr %l93, !tbaa !21
  br label %bb60
bb58:
  %t196 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t198 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t196, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store i1 %t198, ptr %l95
  br label %bb59
bb59:
  %t199 = load i1, ptr %l95, !tbaa !21
  store i1 %t199, ptr %l93, !tbaa !21
  br label %bb60
bb60:
  %t200 = load i1, ptr %l93, !tbaa !21
  br i1 %t200, label %bb61, label %bb62
bb61:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb62:
  br label %bb63
bb63:
  %t202 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d6, i32 0, i32 1) }, ptr %l99, !tbaa !27
  %t205 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t206 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s2, { i64, ptr } %t202, { i64, ptr } %t205)
  store i1 %t206, ptr %l100
  br label %bb64
bb64:
  %t207 = load i1, ptr %l100, !tbaa !21
  br i1 %t207, label %bb65, label %bb66
bb65:
  store i1 true, ptr %l101, !tbaa !21
  br label %bb68
bb66:
  %t208 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr %l104, !tbaa !27
  %t211 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t212 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s2, { i64, ptr } %t208, { i64, ptr } %t211)
  store i1 %t212, ptr %l105
  br label %bb67
bb67:
  %t213 = load i1, ptr %l105, !tbaa !21
  store i1 %t213, ptr %l101, !tbaa !21
  br label %bb68
bb68:
  %t214 = load i1, ptr %l101, !tbaa !21
  br i1 %t214, label %bb69, label %bb70
bb69:
  store i1 true, ptr %l106, !tbaa !21
  br label %bb72
bb70:
  %t215 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t217 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s2, { i64, ptr } %t215, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store i1 %t217, ptr %l108
  br label %bb71
bb71:
  %t218 = load i1, ptr %l108, !tbaa !21
  store i1 %t218, ptr %l106, !tbaa !21
  br label %bb72
bb72:
  %t219 = load i1, ptr %l106, !tbaa !21
  br i1 %t219, label %bb73, label %bb74
bb73:
  store i1 true, ptr %l109, !tbaa !21
  br label %bb76
bb74:
  %t220 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr %l112, !tbaa !27
  %t223 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t224 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s2, { i64, ptr } %t220, { i64, ptr } %t223)
  store i1 %t224, ptr %l113
  br label %bb75
bb75:
  %t225 = load i1, ptr %l113, !tbaa !21
  store i1 %t225, ptr %l109, !tbaa !21
  br label %bb76
bb76:
  %t226 = load i1, ptr %l109, !tbaa !21
  br i1 %t226, label %bb77, label %bb78
bb77:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb78:
  br label %bb79
bb79:
  %t228 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d10, i32 0, i32 1) }, ptr %l117, !tbaa !27
  %t231 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t232 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s2, { i64, ptr } %t228, { i64, ptr } %t231)
  store i1 %t232, ptr %l118
  br label %bb80
bb80:
  %t233 = load i1, ptr %l118, !tbaa !21
  br i1 %t233, label %bb81, label %bb82
bb81:
  %t234 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d11, i32 0, i32 1) }, ptr %l122, !tbaa !27
  %t237 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t238 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s2, { i64, ptr } %t234, { i64, ptr } %t237)
  store i1 %t238, ptr %l123
  br label %bb83
bb82:
  store i1 false, ptr %l119, !tbaa !21
  br label %bb84
bb83:
  %t239 = load i1, ptr %l123, !tbaa !21
  store i1 %t239, ptr %l119, !tbaa !21
  br label %bb84
bb84:
  %t240 = load i1, ptr %l119, !tbaa !21
  br i1 %t240, label %bb85, label %bb86
bb85:
  %t241 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t243 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s2, { i64, ptr } %t241, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i1 %t243, ptr %l126
  br label %bb87
bb86:
  store i1 false, ptr %l124, !tbaa !21
  br label %bb88
bb87:
  %t244 = load i1, ptr %l126, !tbaa !21
  store i1 %t244, ptr %l124, !tbaa !21
  br label %bb88
bb88:
  %t245 = load i1, ptr %l124, !tbaa !21
  br i1 %t245, label %bb89, label %bb90
bb89:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb90:
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s2)
  br label %bb92
bb92:
  br label %bb1
bb93:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fgeneric_2eProjectsType(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i1
  %l8 = alloca i1
  %l9 = alloca i1
  %l11 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb5
bb3:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d14, i32 0, i32 1) })
  store i1 %t7, ptr %l5
  br label %bb4
bb4:
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb5
bb5:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb9
bb7:
  %t10 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t12 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t10, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i1 %t12, ptr %l8
  br label %bb8
bb8:
  %t13 = load i1, ptr %l8, !tbaa !21
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb9
bb9:
  %t14 = load i1, ptr %l6, !tbaa !21
  br i1 %t14, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb13
bb11:
  %t15 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t17 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t15, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d16, i32 0, i32 1) })
  store i1 %t17, ptr %l11
  br label %bb12
bb12:
  %t18 = load i1, ptr %l11, !tbaa !21
  store i1 %t18, ptr %l9, !tbaa !21
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t19 = load i1, ptr %l9, !tbaa !21
  store i1 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fgeneric_2eborrowableElem(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l13 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i1
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l26 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Func", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/ast:Sig", ptr %t4, i32 0, i32 1
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t11 = icmp ne i64 %t9, 1
  br i1 %t11, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/ast:Func", ptr %t14, i32 0, i32 3
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/ast:Sig", ptr %t17, i32 0, i32 1
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l11, !tbaa !27
  %t21 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 0
  %t24 = load ptr, ptr %t23, !tbaa !39
  store ptr %t24, ptr %l1, !tbaa !29
  %t26 = load ptr, ptr %l1, !tbaa !29
  store ptr %t26, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t27 = load ptr, ptr %l14, !tbaa !29
  %t28 = icmp ne ptr %t27, null
  br i1 %t28, label %bb4, label %bb5
bb4:
  %t30 = load ptr, ptr %l14, !tbaa !29
  %t31 = load i64, ptr %t30, !range !{i64 0, i64 8}
  %t33 = icmp eq i64 %t31, 0
  store i1 %t33, ptr %l15, !tbaa !21
  br label %bb5
bb5:
  %t34 = load i1, ptr %l15, !tbaa !21
  br i1 %t34, label %bb6, label %bb7
bb6:
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr { i64, [5 x i64] }, ptr %t35, i32 0, i32 1
  %t38 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t37, i32 0, i32 2
  %t39 = load { i64, ptr }, ptr %t38
  store { i64, ptr } %t39, ptr %l2, !tbaa !27
  br label %bb8
bb7:
  br label %bb13
bb8:
  %t41 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t45 = icmp sgt i64 %t43, 0
  br i1 %t45, label %bb9, label %bb10
bb9:
  %t47 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t47, ptr %l24, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr ptr, ptr %t49, i64 0
  %t51 = load ptr, ptr %t50, !tbaa !39
  %t53 = call i1 @compiler_2fgeneric_2erefElem(ptr %v0, ptr %t51)
  store i1 %t53, ptr %l26
  br label %bb11
bb10:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb12
bb11:
  %t54 = load i1, ptr %l26, !tbaa !21
  store i1 %t54, ptr %l23, !tbaa !21
  br label %bb12
bb12:
  %t55 = load i1, ptr %l23, !tbaa !21
  store i1 %t55, ptr %l13, !tbaa !21
  br label %bb18
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_b9fc8c34bb4a0c14_d84bd287e8577888)
  unreachable
bb18:
  %t56 = load i1, ptr %l13, !tbaa !21
  store i1 %t56, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAllFns(ptr %v0, ptr %a0) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eallFns(ptr %v0, ptr %a0)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyDefault(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l19 = alloca { i64, ptr }
  %l22 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i64
  %l50 = alloca i64
  %l54 = alloca %"compiler/generic:fnRow"
  %l62 = alloca i64
  %l72 = alloca { i64, ptr }
  %l78 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eallFns(ptr %v0, ptr %t1)
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t7 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyCovers(ptr %v0, ptr %s0, ptr %t3, i32 %a1)
  store { i64, ptr } %t7, ptr %l19
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 29
  %t13 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t11)
  store i64 %t13, ptr %l22
  br label %bb3
bb3:
  %t14 = load i64, ptr %l22, !tbaa !24
  store i64 %t14, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = icmp sgt i64 %t15, %t16
  br i1 %t19, label %bb4, label %bb5
bb4:
  %t21 = load i64, ptr %l6, !tbaa !24
  %t23 = icmp sgt i64 %t21, 0
  br i1 %t23, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb9
bb6:
  %t25 = load i64, ptr %l5, !tbaa !24
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = sub i64 %t25, %t26
  %t30 = load i64, ptr %l6, !tbaa !24
  %t33 = add i64 %t29, %t30
  %t35 = sub i64 %t33, 1
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = sdiv i64 %t35, %t36
  store i64 %t39, ptr %l29, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb8
bb8:
  %t41 = load i64, ptr %l29, !tbaa !24
  store i64 %t41, ptr %l26, !tbaa !24
  br label %bb9
bb9:
  %t42 = load i64, ptr %l26, !tbaa !24
  store i64 %t42, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t43 = load i64, ptr %l8, !tbaa !24
  %t44 = load i64, ptr %l7, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb31
bb12:
  br label %bb13
bb13:
  %t51 = load i64, ptr %l4, !tbaa !24
  %t52 = load i64, ptr %l8, !tbaa !24
  %t53 = load i64, ptr %l6, !tbaa !24
  %t56 = mul i64 %t52, %t53
  %t59 = add i64 %t51, %t56
  store i64 %t59, ptr %l9, !tbaa !24
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/generic:Program", ptr %t61, i32 0, i32 29
  %t64 = load i64, ptr %l9, !tbaa !24
  %t67 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t63, i64 %t64)
  store i64 %t67, ptr %l50
  br label %bb14
bb14:
  %t68 = load i64, ptr %l50, !tbaa !24
  store i64 %t68, ptr %l10, !tbaa !24
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/generic:Program", ptr %t69, i32 0, i32 21
  %t72 = load i64, ptr %l10, !tbaa !24
  %t75 = call %"compiler/generic:fnRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eAt_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %s2, ptr %t71, i64 %t72)
  store %"compiler/generic:fnRow" %t75, ptr %l54
  br label %bb15
bb15:
  %t76 = getelementptr %"compiler/generic:fnRow", ptr %l54, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/ast:Func", ptr %t77, i32 0, i32 2
  %t80 = load i32, ptr %t79, !tbaa !23
  %t84 = icmp ne i32 %t80, %a2
  br i1 %t84, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb30
bb17:
  br label %bb18
bb18:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 30
  %t89 = load i64, ptr %l9, !tbaa !24
  %t92 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t88, i64 %t89)
  store i64 %t92, ptr %l62
  br label %bb19
bb19:
  %t93 = load i64, ptr %l62, !tbaa !24
  %t94 = trunc i64 %t93 to i32
  store i32 %t94, ptr %l11, !tbaa !23
  %t97 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t97, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t99 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t99, 0
  store i64 %t101, ptr %l14, !tbaa !24
  br label %bb20
bb20:
  %t103 = load i64, ptr %l13, !tbaa !24
  %t104 = load i64, ptr %l14, !tbaa !24
  %t107 = icmp slt i64 %t103, %t104
  %t109 = xor i1 %t107, true
  br i1 %t109, label %bb21, label %bb22
bb21:
  br label %bb29
bb22:
  br label %bb23
bb23:
  %t111 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t111, ptr %l72, !tbaa !27
  %t112 = load i64, ptr %l13, !tbaa !24
  %t114 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr i32, ptr %t115, i64 %t112
  %t117 = load i32, ptr %t116, !tbaa !33
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/generic:Program", ptr %t119, i32 0, i32 2
  %t125 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t121, i32 %t117)
  store i32 %t125, ptr %l78
  br label %bb24
bb24:
  %t126 = load i32, ptr %l11, !tbaa !23
  %t127 = load i32, ptr %l78, !tbaa !23
  %t129 = icmp eq i32 %t127, %t126
  br i1 %t129, label %bb25, label %bb26
bb25:
  %t131 = load i64, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i64 %t131, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t133 = load i64, ptr %l13, !tbaa !24
  %t135 = add i64 %t133, 1
  store i64 %t135, ptr %l13, !tbaa !24
  br label %bb20
bb29:
  call void @__olang_scope_close(ptr %s2)
  br label %bb30
bb30:
  %t137 = load i64, ptr %l8, !tbaa !24
  %t139 = add i64 %t137, 1
  store i64 %t139, ptr %l8, !tbaa !24
  br label %bb10
bb31:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eApply(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l19 = alloca i64
  %l24 = alloca i1
  %l25 = alloca { i64, ptr }
  %l29 = alloca i1
  %l32 = alloca i1
  %l34 = alloca i64
  %l42 = alloca i1
  %l47 = alloca i64
  %l55 = alloca i64
  %l58 = alloca i64
  %l80 = alloca i1
  %l83 = alloca i1
  %l84 = alloca i64
  %l86 = alloca i32
  %l89 = alloca { i64, ptr }
  %l92 = alloca i32
  %l94 = alloca i32
  %l95 = alloca i64
  %l98 = alloca { i64, ptr }
  %l102 = alloca i32
  %l105 = alloca ptr
  %l106 = alloca i32
  %l110 = alloca i32
  %l111 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2edeclVars(ptr %v0, ptr %t1, i32 %t2)
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/generic:Program", ptr %t5, i32 0, i32 2
  %t8 = load i32, ptr %l2, !tbaa !23
  %t11 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclParams(ptr %v0, ptr %t7, i32 %t8)
  store i64 %t11, ptr %l19
  br label %bb2
bb2:
  %t12 = load i64, ptr %l19, !tbaa !24
  store i64 %t12, ptr %l4, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  store i64 %t15, ptr %l5, !tbaa !24
  %t17 = load i64, ptr %l5, !tbaa !24
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t21, ptr %l25, !tbaa !27
  %t22 = load i64, ptr %l5, !tbaa !24
  %t24 = sub i64 %t22, 1
  %t26 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr ptr, ptr %t27, i64 %t24
  %t29 = load ptr, ptr %t28, !tbaa !39
  %t31 = call i1 @compiler_2fgeneric_2eisErrsArg(ptr %v2, ptr %t29)
  store i1 %t31, ptr %l29
  br label %bb5
bb4:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb6
bb5:
  %t32 = load i1, ptr %l29, !tbaa !21
  store i1 %t32, ptr %l24, !tbaa !21
  br label %bb6
bb6:
  %t33 = load i1, ptr %l24, !tbaa !21
  store i1 %t33, ptr %l6, !tbaa !21
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i32, ptr %l2, !tbaa !23
  %t38 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eHasErrParam(ptr %v0, ptr %t34, i32 %t35)
  store i1 %t38, ptr %l32
  br label %bb7
bb7:
  %t39 = load i1, ptr %l32, !tbaa !21
  br i1 %t39, label %bb8, label %bb9
bb8:
  %t40 = load i1, ptr %l6, !tbaa !21
  br i1 %t40, label %bb10, label %bb11
bb9:
  %t42 = load i1, ptr %l6, !tbaa !21
  br i1 %t42, label %bb16, label %bb17
bb10:
  %t44 = load i64, ptr %l5, !tbaa !24
  store i64 %t44, ptr %l34, !tbaa !24
  br label %bb12
bb11:
  %t46 = load i64, ptr %l5, !tbaa !24
  %t48 = add i64 %t46, 1
  store i64 %t48, ptr %l34, !tbaa !24
  br label %bb12
bb12:
  %t50 = load i64, ptr %l4, !tbaa !24
  %t51 = load i64, ptr %l34, !tbaa !24
  %t53 = icmp ne i64 %t51, %t50
  br i1 %t53, label %bb13, label %bb14
bb13:
  %t55 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t55, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  br label %bb22
bb16:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb18
bb17:
  %t57 = load i64, ptr %l4, !tbaa !24
  %t58 = load i64, ptr %l5, !tbaa !24
  %t61 = icmp ne i64 %t57, %t58
  store i1 %t61, ptr %l42, !tbaa !21
  br label %bb18
bb18:
  %t63 = load i1, ptr %l42, !tbaa !21
  br i1 %t63, label %bb19, label %bb20
bb19:
  %t64 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t64, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t66 = load i64, ptr %l4, !tbaa !24
  store i64 %t66, ptr %l47, !tbaa !24
  %t67 = load i64, ptr %l47, !tbaa !24
  %t68 = icmp sge i64 %t67, 0
  br i1 %t68, label %bb23, label %bb24
bb23:
  %t70 = load i64, ptr %l47, !tbaa !24
  %t71 = icmp sle i64 %t70, 2305843009213693951
  br i1 %t71, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_9ad358ce4cd92925_29c80ed6090eef61)
  unreachable
bb25:
  %t73 = load i64, ptr %l47, !tbaa !24
  %t74 = mul i64 %t73, 4
  %t75 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t74)
  %t76 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t75, 1
  store { i64, ptr } %t77, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t79 = load i64, ptr %l4, !tbaa !24
  store i64 %t79, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t81 = load i64, ptr %l9, !tbaa !24
  %t82 = load i64, ptr %l8, !tbaa !24
  %t85 = icmp sgt i64 %t81, %t82
  br i1 %t85, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_9ad358ce4cd92925_29c80ed6090eef61)
  unreachable
bb27:
  %t87 = load i64, ptr %l10, !tbaa !24
  %t89 = icmp sgt i64 %t87, 0
  br i1 %t89, label %bb29, label %bb30
bb28:
  store i64 0, ptr %l55, !tbaa !24
  br label %bb32
bb29:
  %t91 = load i64, ptr %l9, !tbaa !24
  %t92 = load i64, ptr %l8, !tbaa !24
  %t95 = sub i64 %t91, %t92
  %t96 = load i64, ptr %l10, !tbaa !24
  %t99 = add i64 %t95, %t96
  %t101 = sub i64 %t99, 1
  %t102 = load i64, ptr %l10, !tbaa !24
  %t105 = sdiv i64 %t101, %t102
  store i64 %t105, ptr %l58, !tbaa !24
  br label %bb31
bb30:
  store i64 0, ptr %l58, !tbaa !24
  br label %bb31
bb31:
  %t107 = load i64, ptr %l58, !tbaa !24
  store i64 %t107, ptr %l55, !tbaa !24
  br label %bb32
bb32:
  %t108 = load i64, ptr %l55, !tbaa !24
  store i64 %t108, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb33
bb33:
  %t109 = load i64, ptr %l12, !tbaa !24
  %t110 = load i64, ptr %l11, !tbaa !24
  %t113 = icmp slt i64 %t109, %t110
  %t115 = xor i1 %t113, true
  br i1 %t115, label %bb34, label %bb35
bb34:
  br label %bb51
bb35:
  br label %bb36
bb36:
  %t117 = load i64, ptr %l8, !tbaa !24
  %t118 = load i64, ptr %l12, !tbaa !24
  %t119 = load i64, ptr %l10, !tbaa !24
  %t122 = mul i64 %t118, %t119
  %t125 = add i64 %t117, %t122
  store i64 %t125, ptr %l13, !tbaa !24
  %t127 = load i64, ptr %l13, !tbaa !24
  %t128 = load i64, ptr %l4, !tbaa !24
  %t130 = sub i64 %t128, 1
  %t133 = icmp eq i64 %t127, %t130
  br i1 %t133, label %bb37, label %bb38
bb37:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load i32, ptr %l2, !tbaa !23
  %t139 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eHasErrParam(ptr %v0, ptr %t135, i32 %t136)
  store i1 %t139, ptr %l83
  br label %bb39
bb38:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb40
bb39:
  %t140 = load i1, ptr %l83, !tbaa !21
  store i1 %t140, ptr %l80, !tbaa !21
  br label %bb40
bb40:
  %t141 = load i1, ptr %l80, !tbaa !21
  br i1 %t141, label %bb41, label %bb42
bb41:
  %t142 = load i64, ptr %l13, !tbaa !24
  store i64 %t142, ptr %l84, !tbaa !24
  %t143 = load i1, ptr %l6, !tbaa !21
  br i1 %t143, label %bb43, label %bb44
bb42:
  %t145 = load i64, ptr %l13, !tbaa !24
  store i64 %t145, ptr %l95, !tbaa !24
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load ptr, ptr %l1, !tbaa !29
  %t148 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t148, ptr %l98, !tbaa !27
  %t149 = load i64, ptr %l13, !tbaa !24
  %t151 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr ptr, ptr %t152, i64 %t149
  %t154 = load ptr, ptr %t153, !tbaa !39
  %t159 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %t146, ptr %t147, ptr %t154)
  store i32 %t159, ptr %l102
  br label %bb48
bb43:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load ptr, ptr %l1, !tbaa !29
  %t162 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t162, ptr %l89, !tbaa !27
  %t163 = load i64, ptr %l13, !tbaa !24
  %t165 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !27
  %t167 = getelementptr ptr, ptr %t166, i64 %t163
  %t168 = load ptr, ptr %t167, !tbaa !39
  %t172 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eerrsArg(ptr %v0, ptr %v1, ptr %v2, ptr %t160, ptr %t161, ptr %t168)
  store i32 %t172, ptr %l92
  br label %bb45
bb44:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrSetOf(ptr %v0, ptr %t173, i32 0)
  store i32 %t175, ptr %l94
  br label %bb46
bb45:
  %t176 = load i32, ptr %l92, !tbaa !23
  store i32 %t176, ptr %l86, !tbaa !23
  br label %bb47
bb46:
  %t177 = load i32, ptr %l94, !tbaa !23
  store i32 %t177, ptr %l86, !tbaa !23
  br label %bb47
bb47:
  %t178 = load i32, ptr %l86, !tbaa !23
  %t179 = load i64, ptr %l84, !tbaa !24
  %t180 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t181 = load ptr, ptr %t180, !tbaa !27
  %t182 = getelementptr i32, ptr %t181, i64 %t179
  store i32 %t178, ptr %t182, !tbaa !33
  br label %bb49
bb48:
  %t183 = load i32, ptr %l102, !tbaa !23
  %t184 = load i64, ptr %l95, !tbaa !24
  %t185 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !27
  %t187 = getelementptr i32, ptr %t186, i64 %t184
  store i32 %t183, ptr %t187, !tbaa !33
  br label %bb49
bb49:
  br label %bb50
bb50:
  %t188 = load i64, ptr %l12, !tbaa !24
  %t190 = add i64 %t188, 1
  store i64 %t190, ptr %l12, !tbaa !24
  br label %bb33
bb51:
  %t192 = load ptr, ptr %l0, !tbaa !29
  store ptr %t192, ptr %l105, !tbaa !29
  %t193 = load i32, ptr %l2, !tbaa !23
  store i32 %t193, ptr %l106, !tbaa !23
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/generic:Program", ptr %t194, i32 0, i32 2
  %t197 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t200 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t196, { i64, ptr } %t197)
  store i32 %t200, ptr %l110
  br label %bb52
bb52:
  %t201 = load ptr, ptr %l105, !tbaa !29
  %t202 = load i32, ptr %l106, !tbaa !23
  %t203 = load i32, ptr %l110, !tbaa !23
  %t204 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstance(ptr %v0, ptr %t201, i32 %t202, i32 %t203)
  store i32 %t204, ptr %l111
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s0)
  %t205 = load i32, ptr %l111, !tbaa !23
  store i32 %t205, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBoundOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l16 = alloca i32
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca ptr
  %l23 = alloca i32
  %l32 = alloca { i64, ptr }
  %l35 = alloca ptr
  %l40 = alloca i32
  %l44 = alloca ptr
  %l46 = alloca ptr
  %l48 = alloca { i64, ptr }
  %l49 = alloca i32
  %l50 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:TypeParam", ptr %t1, i32 0, i32 3
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp eq i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t14 = getelementptr %"compiler/ast:TypeParam", ptr %t12, i32 0, i32 2
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t19 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %t10, ptr %t11, ptr %t15)
  store i32 %t19, ptr %l16
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t20 = load i32, ptr %l16, !tbaa !23
  store i32 %t20, ptr %rv
  br label %ret
bb4:
  %t21 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l17
  br label %bb5
bb5:
  %t22 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %l3
  store ptr %l3, ptr %l18, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = getelementptr %"compiler/ast:TypeParam", ptr %t25, i32 0, i32 2
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t32 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %t23, ptr %t24, ptr %t28)
  store i32 %t32, ptr %l23
  br label %bb6
bb6:
  %t33 = load ptr, ptr %l18, !tbaa !29
  %t34 = load i32, ptr %l23, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t33, i32 %t34)
  br label %bb7
bb7:
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"compiler/ast:TypeParam", ptr %t35, i32 0, i32 3
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t40 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t40, 0
  store i64 %t42, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t44 = load i64, ptr %l5, !tbaa !24
  %t45 = load i64, ptr %l6, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb9, label %bb10
bb9:
  br label %bb15
bb10:
  br label %bb11
bb11:
  %t52 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t52, ptr %l32, !tbaa !27
  %t53 = load i64, ptr %l5, !tbaa !24
  %t55 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr ptr, ptr %t56, i64 %t53
  %t58 = load ptr, ptr %t57, !tbaa !39
  store ptr %l3, ptr %l35, !tbaa !29
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t67 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %t60, ptr %t61, ptr %t58)
  store i32 %t67, ptr %l40
  br label %bb12
bb12:
  %t68 = load ptr, ptr %l35, !tbaa !29
  %t69 = load i32, ptr %l40, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t68, i32 %t69)
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t70 = load i64, ptr %l5, !tbaa !24
  %t72 = add i64 %t70, 1
  store i64 %t72, ptr %l5, !tbaa !24
  br label %bb8
bb15:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/generic:Program", ptr %t74, i32 0, i32 2
  store ptr %t76, ptr %l44, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/generic:Program", ptr %t77, i32 0, i32 2
  store ptr %t79, ptr %l46, !tbaa !29
  %t81 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %s0, ptr %l3)
  store { i64, ptr } %t81, ptr %l48
  br label %bb16
bb16:
  %t82 = load ptr, ptr %l46, !tbaa !29
  %t83 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t84 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t82, { i64, ptr } %t83)
  store i32 %t84, ptr %l49
  br label %bb17
bb17:
  %t85 = load ptr, ptr %l44, !tbaa !29
  %t86 = load i32, ptr %l49, !tbaa !23
  %t87 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eTuple(ptr %v0, ptr %t85, i32 %t86)
  store i32 %t87, ptr %l50
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s0)
  %t88 = load i32, ptr %l50, !tbaa !23
  store i32 %t88, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l10 = alloca i32
  %l15 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca ptr
  %l23 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l38 = alloca i1
  %l44 = alloca { i64, ptr }
  %l54 = alloca i32
  %l55 = alloca ptr
  %l58 = alloca %"compiler/generic:Context"
  %l62 = alloca i32
  %s3 = alloca %olang.scope
  %rv = alloca i32
  %t106 = alloca %"compiler/generic:Context", align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l1, !tbaa !23
  %t7 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t7, ptr %l10
  br label %bb1
bb1:
  %t8 = load i32, ptr %l10, !range !{i32 0, i32 33}
  %t10 = trunc i64 18 to i32
  %t11 = icmp eq i32 %t8, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t15, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l15, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/generic:Program", ptr %t18, i32 0, i32 2
  %t21 = load i32, ptr %l1, !tbaa !23
  %t24 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t20, i32 %t21)
  store i32 %t24, ptr %l19
  br label %bb5
bb5:
  %t25 = load ptr, ptr %l15, !tbaa !29
  %t26 = load i32, ptr %l19, !tbaa !23
  %t27 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etypeDecl(ptr %v0, ptr %v0, ptr %t25, i32 %t26)
  store ptr %t27, ptr %l20
  br label %bb6
bb6:
  %t28 = load ptr, ptr %l20, !tbaa !29
  store ptr %t28, ptr %l3, !tbaa !29
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t31 = icmp eq ptr %t29, null
  br i1 %t31, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb9
bb8:
  %t33 = load ptr, ptr %l3, !tbaa !29
  %t35 = getelementptr %"compiler/ast:TypeDecl", ptr %t33, i32 0, i32 3
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = icmp eq ptr %t36, null
  store i1 %t38, ptr %l23, !tbaa !21
  br label %bb9
bb9:
  %t40 = load i1, ptr %l23, !tbaa !21
  br i1 %t40, label %bb10, label %bb11
bb10:
  %t41 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t41, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t43 = load ptr, ptr %l3, !tbaa !29
  %t45 = getelementptr %"compiler/ast:TypeDecl", ptr %t43, i32 0, i32 3
  %t46 = load ptr, ptr %t45, !tbaa !29
  store ptr %t46, ptr %l4, !tbaa !29
  %t48 = load ptr, ptr %l4, !tbaa !29
  store ptr %t48, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t49 = load ptr, ptr %l30, !tbaa !29
  %t50 = icmp ne ptr %t49, null
  br i1 %t50, label %bb13, label %bb14
bb13:
  %t52 = load ptr, ptr %l30, !tbaa !29
  %t53 = load i64, ptr %t52, !range !{i64 0, i64 5}
  %t55 = icmp eq i64 %t53, 1
  store i1 %t55, ptr %l31, !tbaa !21
  br label %bb14
bb14:
  %t56 = load i1, ptr %l31, !tbaa !21
  br i1 %t56, label %bb15, label %bb16
bb15:
  %t57 = load ptr, ptr %l4, !tbaa !29
  %t59 = getelementptr { i64, [6 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { { i64, ptr }, ptr }, ptr %t59, i32 0, i32 0
  %t61 = load { i64, ptr }, ptr %t60
  store { i64, ptr } %t61, ptr %l5, !tbaa !27
  br label %bb17
bb16:
  br label %bb30
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t63 = load i64, ptr %l2, !tbaa !24
  %t65 = icmp slt i64 %t63, 0
  br i1 %t65, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb20
bb19:
  %t67 = load i64, ptr %l2, !tbaa !24
  %t68 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t68, 0
  %t73 = icmp sge i64 %t67, %t70
  store i1 %t73, ptr %l38, !tbaa !21
  br label %bb20
bb20:
  %t75 = load i1, ptr %l38, !tbaa !21
  br i1 %t75, label %bb21, label %bb22
bb21:
  %t76 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s3)
  store i32 %t76, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t78 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t78, ptr %l44, !tbaa !27
  %t79 = load i64, ptr %l2, !tbaa !24
  %t81 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr ptr, ptr %t82, i64 %t79
  %t84 = load ptr, ptr %t83, !tbaa !39
  %t86 = getelementptr %"compiler/ast:CaseDecl", ptr %t84, i32 0, i32 2
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  store { i64, ptr } %t87, ptr %l6, !tbaa !27
  %t89 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t89, 0
  %t93 = icmp eq i64 %t91, 0
  br i1 %t93, label %bb24, label %bb25
bb24:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/generic:Program", ptr %t95, i32 0, i32 2
  %t98 = load i32, ptr %l1, !tbaa !23
  %t101 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t97, i32 0, i32 %t98, i32 0, i32 0, i64 0, i1 false, i32 0)
  store i32 %t101, ptr %l54
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_scope_close(ptr %s3)
  %t102 = load i32, ptr %l54, !tbaa !23
  store i32 %t102, ptr %rv
  br label %ret
bb27:
  %t103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t103, ptr %l55, !tbaa !29
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceContext(ptr %t106, ptr %v0, ptr %s3, ptr %t104, i32 %t105)
  call void @llvm.memmove.p0.p0.i64(ptr %l58, ptr %t106, i64 160, i1 false)
  br label %bb28
bb28:
  %t109 = call ptr @__olang_scope_alloc_a(ptr %s3, i64 160, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t109, ptr %l58, i64 160, i1 false)
  %t110 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t111 = load i32, ptr %l1, !tbaa !23
  %t112 = load ptr, ptr %l55, !tbaa !29
  %t116 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eparamsSig(ptr %v0, ptr %s3, ptr %v0, ptr %s3, ptr %t112, ptr %t109, { i64, ptr } %t110, ptr null, i32 %t111)
  store i32 %t116, ptr %l62
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s3)
  %t117 = load i32, ptr %l62, !tbaa !23
  store i32 %t117, ptr %rv
  br label %ret
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  %t118 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t118, ptr %rv
  br label %ret
bb34:
  call void @__olang_check_failed(ptr @olang_loc_ad47684fdd650b05_1c981444a6d99631)
  unreachable
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclContext(ptr %out, ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca %"compiler/generic:Context"
  %t3 = alloca %"compiler/generic:Context", align 8
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2edeclContext(ptr %t3, ptr %v0, ptr %v1, ptr %a0, i32 %a1)
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %t3, i64 160, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l4, i64 160, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/generic:Program", ptr %a0, i32 0, i32 5
  %t6 = sext i32 %a1 to i64
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t6)
  store i64 %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load i64, ptr %l6, !tbaa !24
  store i64 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclWord(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l6 = alloca i32
  %l11 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca ptr
  %l20 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l1, !tbaa !23
  %t7 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t10 = trunc i64 18 to i32
  %t11 = icmp eq i32 %t8, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  store i32 0, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l11, !tbaa !29
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/generic:Program", ptr %t17, i32 0, i32 2
  %t20 = load i32, ptr %l1, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t19, i32 %t20)
  store i32 %t23, ptr %l15
  br label %bb5
bb5:
  %t24 = load ptr, ptr %l11, !tbaa !29
  %t25 = load i32, ptr %l15, !tbaa !23
  %t26 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etypeDecl(ptr %v0, ptr %v0, ptr %t24, i32 %t25)
  store ptr %t26, ptr %l16
  br label %bb6
bb6:
  %t27 = load ptr, ptr %l16, !tbaa !29
  store ptr %t27, ptr %l2, !tbaa !29
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t30 = icmp eq ptr %t28, null
  %t32 = xor i1 %t30, true
  br i1 %t32, label %bb7, label %bb8
bb7:
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = getelementptr %"compiler/ast:TypeDecl", ptr %t34, i32 0, i32 5
  %t37 = load i32, ptr %t36, !range !{i32 0, i32 3}
  store i32 %t37, ptr %l20
  br label %bb9
bb8:
  store i32 0, ptr %l20
  br label %bb9
bb9:
  %t40 = load i32, ptr %l20, !range !{i32 0, i32 3}
  store i32 %t40, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultMethod(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca i64
  %l11 = alloca i64
  %l13 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t7 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultMethods(ptr %v0, ptr %s0, ptr %a0, i32 %a1, i32 %a2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l3
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l3)
  store i64 %t10, ptr %l9
  br label %bb2
bb2:
  %t11 = load i64, ptr %l9, !tbaa !24
  %t12 = icmp sgt i64 %t11, 0
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t15 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l3, i64 0)
  store i64 %t15, ptr %l13
  br label %bb5
bb4:
  store i64 -1, ptr %l11, !tbaa !24
  br label %bb6
bb5:
  %t16 = load i64, ptr %l13, !tbaa !24
  store i64 %t16, ptr %l11, !tbaa !24
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t17 = load i64, ptr %l11, !tbaa !24
  store i64 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultMethods(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %lp3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca i32
  %l30 = alloca i32
  %l34 = alloca i32
  %l38 = alloca i64
  %l42 = alloca i64
  %l45 = alloca i64
  %l66 = alloca i64
  %l70 = alloca %"compiler/generic:fnRow"
  %l78 = alloca i64
  %l83 = alloca ptr
  %l86 = alloca i1
  %l92 = alloca ptr
  %l93 = alloca i1
  %l103 = alloca i1
  %l104 = alloca ptr
  %l105 = alloca i32
  %l108 = alloca i32
  %l109 = alloca i1
  %l117 = alloca { i64, ptr }
  %l124 = alloca i64
  %s2 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l22
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t2, ptr %lp3
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22
  %t4 = load ptr, ptr %lp3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eallFns(ptr %v0, ptr %t5)
  br label %bb2
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 2
  %t10 = load i32, ptr %l1, !tbaa !23
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t9, i32 %t10)
  store i32 %t13, ptr %l27
  br label %bb3
bb3:
  %t14 = load i32, ptr %l27, !range !{i32 0, i32 33}
  %t16 = trunc i64 20 to i32
  %t17 = icmp eq i32 %t14, %t16
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %l1, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l34
  br label %bb6
bb5:
  %t26 = load i32, ptr %l1, !tbaa !23
  store i32 %t26, ptr %l30, !tbaa !23
  br label %bb7
bb6:
  %t28 = load i32, ptr %l34, !tbaa !23
  store i32 %t28, ptr %l30, !tbaa !23
  br label %bb7
bb7:
  %t29 = load i32, ptr %l30, !tbaa !23
  store i32 %t29, ptr %l4, !tbaa !23
  store i64 0, ptr %l5, !tbaa !24
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/generic:Program", ptr %t30, i32 0, i32 29
  %t34 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t32)
  store i64 %t34, ptr %l38
  br label %bb8
bb8:
  %t35 = load i64, ptr %l38, !tbaa !24
  store i64 %t35, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t36 = load i64, ptr %l6, !tbaa !24
  %t37 = load i64, ptr %l5, !tbaa !24
  %t40 = icmp sgt i64 %t36, %t37
  br i1 %t40, label %bb9, label %bb10
bb9:
  %t42 = load i64, ptr %l7, !tbaa !24
  %t44 = icmp sgt i64 %t42, 0
  br i1 %t44, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb14
bb11:
  %t46 = load i64, ptr %l6, !tbaa !24
  %t47 = load i64, ptr %l5, !tbaa !24
  %t50 = sub i64 %t46, %t47
  %t51 = load i64, ptr %l7, !tbaa !24
  %t54 = add i64 %t50, %t51
  %t56 = sub i64 %t54, 1
  %t57 = load i64, ptr %l7, !tbaa !24
  %t60 = sdiv i64 %t56, %t57
  store i64 %t60, ptr %l45, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb13
bb13:
  %t62 = load i64, ptr %l45, !tbaa !24
  store i64 %t62, ptr %l42, !tbaa !24
  br label %bb14
bb14:
  %t63 = load i64, ptr %l42, !tbaa !24
  store i64 %t63, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t64 = load i64, ptr %l9, !tbaa !24
  %t65 = load i64, ptr %l8, !tbaa !24
  %t68 = icmp slt i64 %t64, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb63
bb17:
  br label %bb18
bb18:
  %t72 = load i64, ptr %l5, !tbaa !24
  %t73 = load i64, ptr %l9, !tbaa !24
  %t74 = load i64, ptr %l7, !tbaa !24
  %t77 = mul i64 %t73, %t74
  %t80 = add i64 %t72, %t77
  store i64 %t80, ptr %l10, !tbaa !24
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/generic:Program", ptr %t82, i32 0, i32 29
  %t85 = load i64, ptr %l10, !tbaa !24
  %t88 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t84, i64 %t85)
  store i64 %t88, ptr %l66
  br label %bb19
bb19:
  %t89 = load i64, ptr %l66, !tbaa !24
  store i64 %t89, ptr %l11, !tbaa !24
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/generic:Program", ptr %t90, i32 0, i32 21
  %t93 = load i64, ptr %l11, !tbaa !24
  %t96 = call %"compiler/generic:fnRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eAt_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %s2, ptr %t92, i64 %t93)
  store %"compiler/generic:fnRow" %t96, ptr %l70
  br label %bb20
bb20:
  %t97 = getelementptr %"compiler/generic:fnRow", ptr %l70, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t100 = getelementptr %"compiler/ast:Func", ptr %t98, i32 0, i32 2
  %t101 = load i32, ptr %t100, !tbaa !23
  %t105 = icmp ne i32 %t101, %a2
  br i1 %t105, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb62
bb22:
  br label %bb23
bb23:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/generic:Program", ptr %t107, i32 0, i32 30
  %t110 = load i64, ptr %l10, !tbaa !24
  %t113 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t109, i64 %t110)
  store i64 %t113, ptr %l78
  br label %bb24
bb24:
  %t114 = load i64, ptr %l78, !tbaa !24
  %t115 = trunc i64 %t114 to i32
  store i32 %t115, ptr %l12, !tbaa !23
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load i32, ptr %l12, !tbaa !23
  %t122 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etypeDecl(ptr %v0, ptr %v0, ptr %t118, i32 %t119)
  store ptr %t122, ptr %l83
  br label %bb25
bb25:
  %t123 = load ptr, ptr %l83, !tbaa !29
  store ptr %t123, ptr %l13, !tbaa !29
  %t124 = load ptr, ptr %l13, !tbaa !29
  %t126 = icmp eq ptr %t124, null
  br i1 %t126, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l86, !tbaa !21
  br label %bb28
bb27:
  %t128 = load ptr, ptr %l13, !tbaa !29
  %t130 = getelementptr %"compiler/ast:TypeDecl", ptr %t128, i32 0, i32 3
  %t131 = load ptr, ptr %t130, !tbaa !29
  %t133 = icmp eq ptr %t131, null
  store i1 %t133, ptr %l86, !tbaa !21
  br label %bb28
bb28:
  %t135 = load i1, ptr %l86, !tbaa !21
  br i1 %t135, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s2)
  br label %bb62
bb30:
  br label %bb31
bb31:
  store i1 false, ptr %l14, !tbaa !21
  %t136 = load ptr, ptr %l13, !tbaa !29
  %t138 = getelementptr %"compiler/ast:TypeDecl", ptr %t136, i32 0, i32 3
  %t139 = load ptr, ptr %t138, !tbaa !29
  store ptr %t139, ptr %l15, !tbaa !29
  %t141 = load ptr, ptr %l15, !tbaa !29
  store ptr %t141, ptr %l92, !tbaa !29
  store i1 false, ptr %l93, !tbaa !21
  %t142 = load ptr, ptr %l92, !tbaa !29
  %t143 = icmp ne ptr %t142, null
  br i1 %t143, label %bb32, label %bb33
bb32:
  %t145 = load ptr, ptr %l92, !tbaa !29
  %t146 = load i64, ptr %t145, !range !{i64 0, i64 5}
  %t148 = icmp eq i64 %t146, 2
  store i1 %t148, ptr %l93, !tbaa !21
  br label %bb33
bb33:
  %t149 = load i1, ptr %l93, !tbaa !21
  br i1 %t149, label %bb34, label %bb35
bb34:
  %t150 = load ptr, ptr %l15, !tbaa !29
  %t152 = getelementptr { i64, [6 x i64] }, ptr %t150, i32 0, i32 1
  %t153 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t152, i32 0, i32 0
  %t154 = load { i64, ptr }, ptr %t153
  store { i64, ptr } %t154, ptr %l16, !tbaa !27
  %t156 = load ptr, ptr %l15, !tbaa !29
  %t158 = getelementptr { i64, [6 x i64] }, ptr %t156, i32 0, i32 1
  %t159 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t158, i32 0, i32 2
  %t160 = load { i64, ptr }, ptr %t159
  store { i64, ptr } %t160, ptr %l17, !tbaa !27
  br label %bb36
bb35:
  br label %bb52
bb36:
  %t162 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t164 = extractvalue { i64, ptr } %t162, 0
  %t166 = icmp eq i64 %t164, 0
  br i1 %t166, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l103, !tbaa !21
  br label %bb41
bb38:
  %t168 = load ptr, ptr %l0, !tbaa !29
  store ptr %t168, ptr %l104, !tbaa !29
  %t169 = load i32, ptr %l4, !tbaa !23
  store i32 %t169, ptr %l105, !tbaa !23
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load i32, ptr %l12, !tbaa !23
  %t174 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t170, i32 %t171)
  store i32 %t174, ptr %l108
  br label %bb39
bb39:
  %t175 = load ptr, ptr %l104, !tbaa !29
  %t176 = load i32, ptr %l105, !tbaa !23
  %t177 = load i32, ptr %l108, !tbaa !23
  %t178 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMember(ptr %v0, ptr %t175, i32 %t176, i32 %t177)
  store i1 %t178, ptr %l109
  br label %bb40
bb40:
  %t179 = load i1, ptr %l109, !tbaa !21
  store i1 %t179, ptr %l103, !tbaa !21
  br label %bb41
bb41:
  %t180 = load i1, ptr %l103, !tbaa !21
  store i1 %t180, ptr %l14, !tbaa !21
  %t181 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t181, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t183 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t185 = extractvalue { i64, ptr } %t183, 0
  store i64 %t185, ptr %l20, !tbaa !24
  br label %bb42
bb42:
  %t187 = load i64, ptr %l19, !tbaa !24
  %t188 = load i64, ptr %l20, !tbaa !24
  %t191 = icmp slt i64 %t187, %t188
  %t193 = xor i1 %t191, true
  br i1 %t193, label %bb43, label %bb44
bb43:
  br label %bb51
bb44:
  br label %bb45
bb45:
  %t195 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t195, ptr %l117, !tbaa !27
  %t196 = load i64, ptr %l19, !tbaa !24
  %t198 = getelementptr { i64, ptr }, ptr %l117, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !27
  %t200 = getelementptr ptr, ptr %t199, i64 %t196
  %t201 = load ptr, ptr %t200, !tbaa !39
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load i32, ptr %l4, !tbaa !23
  %t207 = getelementptr %"compiler/ast:Func", ptr %t201, i32 0, i32 2
  %t208 = load i32, ptr %t207, !tbaa !23
  %t212 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t203, i32 %t204, i32 %t208)
  store i64 %t212, ptr %l124
  br label %bb46
bb46:
  %t213 = load i64, ptr %l124, !tbaa !24
  %t214 = icmp slt i64 %t213, 0
  br i1 %t214, label %bb47, label %bb48
bb47:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb49
bb48:
  br label %bb49
bb49:
  br label %bb50
bb50:
  %t216 = load i64, ptr %l19, !tbaa !24
  %t218 = add i64 %t216, 1
  store i64 %t218, ptr %l19, !tbaa !24
  br label %bb42
bb51:
  br label %bb57
bb52:
  br i1 true, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb57
bb56:
  call void @__olang_check_failed(ptr @olang_loc_56cbe4aa8d7e920d_955f1f716de98a59)
  unreachable
bb57:
  %t220 = load i1, ptr %l14, !tbaa !21
  br i1 %t220, label %bb58, label %bb59
bb58:
  %t222 = load ptr, ptr %lp3
  %t223 = load i64, ptr %l11, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t222, i64 %t223)
  br label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s2)
  br label %bb62
bb62:
  %t226 = load i64, ptr %l9, !tbaa !24
  %t228 = add i64 %t226, 1
  store i64 %t228, ptr %l9, !tbaa !24
  br label %bb15
bb63:
  %t230 = load ptr, ptr %lp3
  %t231 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t230
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t231, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrValOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca { i64, ptr }
  %l32 = alloca i1
  %l40 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l45 = alloca i64
  %l49 = alloca i64
  %l52 = alloca i64
  %l71 = alloca ptr
  %l74 = alloca i32
  %l75 = alloca i32
  %l80 = alloca ptr
  %l83 = alloca i32
  %l84 = alloca i32
  %l85 = alloca ptr
  %l89 = alloca i32
  %l90 = alloca { i64, ptr }
  %l94 = alloca i64
  %l96 = alloca i64
  %l100 = alloca ptr
  %l103 = alloca i32
  %l104 = alloca i64
  %l115 = alloca { i64, ptr }
  %l120 = alloca ptr
  %l124 = alloca i32
  %l125 = alloca i32
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l18
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  store { i64, ptr } %a1, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l4, !tbaa !24
  %t10 = load i64, ptr %l5, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb14
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t17, ptr %l26, !tbaa !27
  %t18 = load i64, ptr %l4, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i32, ptr %t21, i64 %t18
  %t23 = load i32, ptr %t22, !tbaa !33
  store i32 %t23, ptr %l6, !tbaa !23
  %t25 = load i32, ptr %l6, !tbaa !23
  %t26 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t29 = icmp ne i32 %t25, %t26
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t31 = load i32, ptr %l6, !tbaa !23
  %t32 = load i32, ptr @G_2ecompiler_2ftypes_2eDefaultErrT, !tbaa !23
  %t35 = icmp ne i32 %t31, %t32
  store i1 %t35, ptr %l32, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb8
bb8:
  %t37 = load i1, ptr %l32, !tbaa !21
  br i1 %t37, label %bb9, label %bb10
bb9:
  %t38 = load i32, ptr %l6, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l2, i32 %t38)
  br label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t41 = load i64, ptr %l4, !tbaa !24
  %t43 = add i64 %t41, 1
  store i64 %t43, ptr %l4, !tbaa !24
  br label %bb2
bb14:
  %t45 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t45, ptr %l40
  br label %bb15
bb15:
  %t46 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l40
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t46, ptr %l7
  %t47 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emergeEntries(ptr %v0, ptr %s0, ptr %s0, ptr %t47, ptr %l2, ptr %l7)
  br label %bb16
bb16:
  store i64 0, ptr %l8, !tbaa !24
  %t52 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l7)
  store i64 %t52, ptr %l45
  br label %bb17
bb17:
  %t53 = load i64, ptr %l45, !tbaa !24
  store i64 %t53, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t54 = load i64, ptr %l9, !tbaa !24
  %t55 = load i64, ptr %l8, !tbaa !24
  %t58 = icmp sgt i64 %t54, %t55
  br i1 %t58, label %bb18, label %bb19
bb18:
  %t60 = load i64, ptr %l10, !tbaa !24
  %t62 = icmp sgt i64 %t60, 0
  br i1 %t62, label %bb20, label %bb21
bb19:
  store i64 0, ptr %l49, !tbaa !24
  br label %bb23
bb20:
  %t64 = load i64, ptr %l9, !tbaa !24
  %t65 = load i64, ptr %l8, !tbaa !24
  %t68 = sub i64 %t64, %t65
  %t69 = load i64, ptr %l10, !tbaa !24
  %t72 = add i64 %t68, %t69
  %t74 = sub i64 %t72, 1
  %t75 = load i64, ptr %l10, !tbaa !24
  %t78 = sdiv i64 %t74, %t75
  store i64 %t78, ptr %l52, !tbaa !24
  br label %bb22
bb21:
  store i64 0, ptr %l52, !tbaa !24
  br label %bb22
bb22:
  %t80 = load i64, ptr %l52, !tbaa !24
  store i64 %t80, ptr %l49, !tbaa !24
  br label %bb23
bb23:
  %t81 = load i64, ptr %l49, !tbaa !24
  store i64 %t81, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s6
  %t82 = load i64, ptr %l12, !tbaa !24
  %t83 = load i64, ptr %l11, !tbaa !24
  %t86 = icmp slt i64 %t82, %t83
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s6)
  br label %bb47
bb26:
  br label %bb27
bb27:
  %t90 = load i64, ptr %l8, !tbaa !24
  %t91 = load i64, ptr %l12, !tbaa !24
  %t92 = load i64, ptr %l10, !tbaa !24
  %t95 = mul i64 %t91, %t92
  %t98 = add i64 %t90, %t95
  store i64 %t98, ptr %l13, !tbaa !24
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Program", ptr %t100, i32 0, i32 2
  store ptr %t102, ptr %l71, !tbaa !29
  %t103 = load i64, ptr %l13, !tbaa !24
  %t106 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l7, i64 %t103)
  store i32 %t106, ptr %l74
  br label %bb28
bb28:
  %t107 = load ptr, ptr %l71, !tbaa !29
  %t108 = load i32, ptr %l74, !tbaa !23
  %t109 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t107, i32 %t108)
  store i32 %t109, ptr %l75
  br label %bb29
bb29:
  %t110 = load i32, ptr %l75, !range !{i32 0, i32 33}
  %t112 = trunc i64 28 to i32
  %t113 = icmp eq i32 %t110, %t112
  %t115 = xor i1 %t113, true
  br i1 %t115, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s6)
  br label %bb46
bb31:
  br label %bb32
bb32:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/generic:Program", ptr %t117, i32 0, i32 2
  store ptr %t119, ptr %l80, !tbaa !29
  %t120 = load i64, ptr %l13, !tbaa !24
  %t123 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l7, i64 %t120)
  store i32 %t123, ptr %l83
  br label %bb33
bb33:
  %t124 = load ptr, ptr %l80, !tbaa !29
  %t125 = load i32, ptr %l83, !tbaa !23
  %t126 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t124, i32 %t125)
  store i32 %t126, ptr %l84
  br label %bb34
bb34:
  %t127 = load i32, ptr %l84, !tbaa !23
  store i32 %t127, ptr %l14, !tbaa !23
  %t128 = load ptr, ptr %l0, !tbaa !29
  store ptr %t128, ptr %l85, !tbaa !29
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/generic:Program", ptr %t129, i32 0, i32 2
  %t132 = load i32, ptr %l14, !tbaa !23
  %t135 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t131, i32 %t132)
  store i32 %t135, ptr %l89
  br label %bb35
bb35:
  %t136 = load ptr, ptr %l85, !tbaa !29
  %t137 = load i32, ptr %l89, !tbaa !23
  %t138 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %s6, ptr %t136, i32 %t137)
  store { i64, ptr } %t138, ptr %l90
  br label %bb36
bb36:
  %t139 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t139, 0
  store i64 %t140, ptr %l15, !tbaa !24
  %t142 = load i64, ptr %l15, !tbaa !24
  %t144 = icmp sge i64 %t142, 64
  br i1 %t144, label %bb37, label %bb38
bb37:
  %t146 = sub i64 0, 1
  store i64 %t146, ptr %l94, !tbaa !65
  br label %bb39
bb38:
  %t148 = load i64, ptr %l15, !tbaa !24
  store i64 %t148, ptr %l96, !tbaa !24
  %t149 = load i64, ptr %l96, !tbaa !24
  %t150 = load i64, ptr %l96, !tbaa !24
  %t151 = shl i64 1, %t150
  %t153 = sub i64 %t151, 1
  store i64 %t153, ptr %l94, !tbaa !65
  br label %bb39
bb39:
  %t155 = load i64, ptr %l94, !tbaa !65
  store i64 %t155, ptr %l16, !tbaa !65
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/generic:Program", ptr %t156, i32 0, i32 2
  store ptr %t158, ptr %l100, !tbaa !29
  %t159 = load i64, ptr %l13, !tbaa !24
  %t162 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l7, i64 %t159)
  store i32 %t162, ptr %l103
  br label %bb40
bb40:
  %t163 = load ptr, ptr %l100, !tbaa !29
  %t164 = load i32, ptr %l103, !tbaa !23
  %t165 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t163, i32 %t164)
  store i64 %t165, ptr %l104
  br label %bb41
bb41:
  %t166 = load i64, ptr %l16, !tbaa !65
  %t167 = load i64, ptr %l104, !tbaa !65
  %t169 = and i64 %t167, %t166
  %t170 = load i64, ptr %l16, !tbaa !65
  %t173 = icmp eq i64 %t169, %t170
  br i1 %t173, label %bb42, label %bb43
bb42:
  %t175 = load i64, ptr %l13, !tbaa !24
  %t176 = load i32, ptr %l14, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eSetAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l7, i64 %t175, i32 %t176)
  br label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s6)
  br label %bb46
bb46:
  %t180 = load i64, ptr %l12, !tbaa !24
  %t182 = add i64 %t180, 1
  store i64 %t182, ptr %l12, !tbaa !24
  br label %bb24
bb47:
  %t185 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %s0, ptr %l7)
  store { i64, ptr } %t185, ptr %l115
  br label %bb48
bb48:
  %t186 = load { i64, ptr }, ptr %l115, !tbaa !27
  store { i64, ptr } %t186, ptr %l17, !tbaa !27
  %t187 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t190 = ptrtoint ptr %t189 to i64
  %t191 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 %t190, i64 8)
  %t192 = getelementptr { ptr, ptr }, ptr %t191, i32 0, i32 0
  store ptr %t188, ptr %t192, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t194 = getelementptr { ptr, ptr }, ptr %t191, i32 0, i32 1
  store ptr %v0, ptr %t194, !tbaa !28
  %t195 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_17, 0
  %t196 = insertvalue { ptr, ptr } %t195, ptr %t191, 1
  %t199 = extractvalue { ptr, ptr } %t196, 0
  %t200 = extractvalue { ptr, ptr } %t196, 1
  call void @std_2fprelude_2farray_2eArray_3ccompiler_2ftypes_3aTypeId_3e_2eSort_3ccompiler_2ftypes_3aTypeId_2c_20_3f_3e(ptr %s0, ptr %v0, { i64, ptr } %t187, ptr %t199, ptr %t200)
  br label %bb49
bb49:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"compiler/generic:Program", ptr %t201, i32 0, i32 2
  store ptr %t203, ptr %l120, !tbaa !29
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = getelementptr %"compiler/generic:Program", ptr %t204, i32 0, i32 2
  %t207 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t210 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t206, { i64, ptr } %t207)
  store i32 %t210, ptr %l124
  br label %bb50
bb50:
  %t211 = load ptr, ptr %l120, !tbaa !29
  %t212 = load i32, ptr %l124, !tbaa !23
  %t213 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrVal(ptr %v0, ptr %t211, i32 %t212)
  store i32 %t213, ptr %l125
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s0)
  %t214 = load i32, ptr %l125, !tbaa !23
  store i32 %t214, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrValOfType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca i32
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i32
  %l14 = alloca i1
  %l15 = alloca i1
  %l17 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l27 = alloca i32
  %l31 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l4
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eEntriesOf(ptr %v0, ptr %s0, ptr %t3, i32 %t4, ptr %l2)
  br label %bb2
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l8, !tbaa !29
  %t10 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %s0, ptr %l2)
  store { i64, ptr } %t10, ptr %l10
  br label %bb3
bb3:
  %t11 = load ptr, ptr %l8, !tbaa !29
  %t12 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t13 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrValOf(ptr %v0, ptr %s0, ptr %t11, { i64, ptr } %t12)
  store i32 %t13, ptr %l11
  br label %bb4
bb4:
  %t14 = load i32, ptr %l11, !tbaa !23
  store i32 %t14, ptr %l3, !tbaa !23
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l1, !tbaa !23
  %t19 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsErrorSet(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l14
  br label %bb5
bb5:
  %t20 = load i1, ptr %l14, !tbaa !21
  br i1 %t20, label %bb6, label %bb7
bb6:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/generic:Program", ptr %t21, i32 0, i32 2
  store ptr %t23, ptr %l17, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Program", ptr %t24, i32 0, i32 2
  %t27 = load i32, ptr %l3, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %t26, i32 %t27)
  store i32 %t30, ptr %l21
  br label %bb8
bb7:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb10
bb8:
  %t31 = load ptr, ptr %l17, !tbaa !29
  %t32 = load i32, ptr %l21, !tbaa !23
  %t33 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t31, i32 %t32)
  store { i64, ptr } %t33, ptr %l22
  br label %bb9
bb9:
  %t34 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 0
  %t37 = icmp sgt i64 %t35, 1
  store i1 %t37, ptr %l15, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l15, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 2
  store ptr %t42, ptr %l26, !tbaa !29
  %t43 = load i32, ptr %l3, !tbaa !23
  store i32 %t43, ptr %l27, !tbaa !23
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/generic:Program", ptr %t44, i32 0, i32 2
  %t47 = load i32, ptr %l1, !tbaa !23
  %t50 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t46, i32 %t47)
  store i32 %t50, ptr %l31
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t51 = load ptr, ptr %l26, !tbaa !29
  %t52 = load i32, ptr %l27, !tbaa !23
  %t53 = load i32, ptr %l31, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNameErrVal(ptr %v0, ptr %t51, i32 %t52, i32 %t53)
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t54 = load i32, ptr %l3, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t54, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrValWordText(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca { i64, ptr }
  %l21 = alloca i1
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l31 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l37 = alloca i32
  %l38 = alloca i32
  %l41 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l50 = alloca i64
  %l51 = alloca { i64, ptr }
  %l55 = alloca i64
  %l60 = alloca ptr
  %l68 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  store ptr %t3, ptr %l10, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l14
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l10, !tbaa !29
  %t12 = load i32, ptr %l14, !tbaa !23
  %t13 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t11, i32 %t12)
  store { i64, ptr } %t13, ptr %l15
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t14, ptr %l3, !tbaa !27
  %t15 = load i64, ptr %l2, !tbaa !24
  %t17 = ashr i64 %t15, 16
  %t19 = sub i64 %t17, 1
  store i64 %t19, ptr %l4, !tbaa !24
  %t21 = load i64, ptr %l4, !tbaa !24
  %t23 = icmp slt i64 %t21, 0
  br i1 %t23, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb5
bb4:
  %t25 = load i64, ptr %l4, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  %t31 = icmp sge i64 %t25, %t28
  store i1 %t31, ptr %l21, !tbaa !21
  br label %bb5
bb5:
  %t33 = load i1, ptr %l21, !tbaa !21
  br i1 %t33, label %bb6, label %bb7
bb6:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d18, i32 0, i32 1) }, ptr %l26, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t34, ptr %l27, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t35, 0
  store i64 %t36, ptr %l28, !tbaa !24
  %t37 = load i64, ptr %l28, !tbaa !24
  %t38 = mul i64 %t37, 1
  %t39 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t38)
  %t40 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  store { i64, ptr } %t41, ptr %l29, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = load i64, ptr %l28, !tbaa !24
  %t47 = mul i64 %t46, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t43, ptr %t45, i64 %t47, i1 false)
  %t48 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t48, ptr %l27, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t49 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t49, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/generic:Program", ptr %t50, i32 0, i32 2
  store ptr %t52, ptr %l31, !tbaa !29
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 2
  %t56 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t56, ptr %l34, !tbaa !27
  %t57 = load i64, ptr %l4, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr i32, ptr %t60, i64 %t57
  %t62 = load i32, ptr %t61, !tbaa !33
  %t65 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t55, i32 %t62)
  store i32 %t65, ptr %l37
  br label %bb9
bb9:
  %t66 = load ptr, ptr %l31, !tbaa !29
  %t67 = load i32, ptr %l37, !tbaa !23
  %t68 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t66, i32 %t67)
  store i32 %t68, ptr %l38
  br label %bb10
bb10:
  %t69 = load i32, ptr %l38, !tbaa !23
  store i32 %t69, ptr %l5, !tbaa !23
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load i32, ptr %l5, !tbaa !23
  %t74 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %s0, ptr %t70, i32 %t71)
  store { i64, ptr } %t74, ptr %l41
  br label %bb11
bb11:
  %t75 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t76 = load i64, ptr %l2, !tbaa !24
  %t78 = and i64 %t76, 65535
  store i64 %t78, ptr %l7, !tbaa !24
  %t80 = load i64, ptr %l7, !tbaa !24
  %t83 = extractvalue { i64, ptr } %t75, 0
  %t86 = icmp sge i64 %t80, %t83
  br i1 %t86, label %bb12, label %bb13
bb12:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %l48, !tbaa !27
  %t88 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t88, ptr %l49, !tbaa !27
  %t89 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t89, 0
  store i64 %t90, ptr %l50, !tbaa !24
  %t91 = load i64, ptr %l50, !tbaa !24
  %t92 = mul i64 %t91, 1
  %t93 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t92)
  %t94 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t93, 1
  store { i64, ptr } %t95, ptr %l51, !tbaa !27
  %t96 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = load i64, ptr %l50, !tbaa !24
  %t101 = mul i64 %t100, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t97, ptr %t99, i64 %t101, i1 false)
  %t102 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t102, ptr %l49, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t103 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t103, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/generic:Program", ptr %t104, i32 0, i32 2
  %t107 = load i32, ptr %l5, !tbaa !23
  %t110 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t106, i32 %t107)
  store i64 %t110, ptr %l55
  br label %bb15
bb15:
  %t111 = load i64, ptr %l55, !tbaa !24
  store i64 %t111, ptr %l8, !tbaa !24
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/generic:Program", ptr %t112, i32 0, i32 0
  %t115 = load ptr, ptr %t114, !tbaa !29
  %t117 = getelementptr %"compiler/load:Loader", ptr %t115, i32 0, i32 10
  %t118 = load i64, ptr %l8, !tbaa !24
  %t121 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t117, i64 %t118)
  store ptr %t121, ptr %l60
  br label %bb16
bb16:
  %t122 = load ptr, ptr %l60, !tbaa !29
  %t124 = getelementptr %"compiler/load:Module", ptr %t122, i32 0, i32 2
  %t125 = load { i64, ptr }, ptr %t124, !tbaa !27
  %t126 = load i64, ptr %l8, !tbaa !24
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/generic:Program", ptr %t127, i32 0, i32 0
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t132 = getelementptr %"compiler/load:Loader", ptr %t130, i32 0, i32 12
  %t133 = load i64, ptr %t132, !tbaa !24
  %t136 = icmp eq i64 %t126, %t133
  %t139 = call { i64, ptr } @compiler_2fload_2eErrQualifier(ptr %v0, ptr %s0, { i64, ptr } %t125, i1 %t136)
  store { i64, ptr } %t139, ptr %l68
  br label %bb17
bb17:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load i32, ptr %l5, !tbaa !23
  %t142 = load i64, ptr %l7, !tbaa !24
  %t146 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWordName(ptr %v0, ptr %s0, ptr %t140, i32 %t141, i64 %t142)
  store { i64, ptr } %t146, ptr %l72
  br label %bb18
bb18:
  %t147 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t147, 1
  %t149 = extractvalue { i64, ptr } %t147, 0
  %t150 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t151 = extractvalue { i64, ptr } %t150, 1
  %t152 = extractvalue { i64, ptr } %t150, 0
  %t153 = add i64 %t149, %t152
  %t154 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t153)
  call void @olang_textcopy(ptr %t154, ptr %t148, i64 %t149)
  %t155 = getelementptr i8, ptr %t154, i64 %t149
  call void @olang_textcopy(ptr %t155, ptr %t151, i64 %t152)
  %t156 = insertvalue { i64, ptr } undef, i64 %t153, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr %t154, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t157, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrVarAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l3 = alloca i1
  %l5 = alloca ptr
  %l8 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l9 = alloca i1
  %l10 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/generic:Program", ptr %a0, i32 0, i32 10
  store ptr %t3, ptr %l5, !tbaa !29
  %t8 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %a1, i64 %a2)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t8, ptr %l8
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l5, !tbaa !29
  %t10 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l8
  %t11 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H190b78e3c1eec037529224679e114a85(ptr %v0, ptr %t9, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t10)
  %t12 = extractvalue { i32, i1 } %t11, 1
  %t13 = extractvalue { i32, i1 } %t11, 0
  store i32 %t13, ptr %l10
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb3, label %ok.15, !prof !99
ok.15:
  store i1 %t12, ptr %l9
  br label %bb2
bb2:
  %t16 = load i1, ptr %l9, !tbaa !21
  store i1 %t16, ptr %l3, !tbaa !21
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  store i1 false, ptr %l3, !tbaa !21
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t17 = load i1, ptr %l3, !tbaa !21
  store i1 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorList(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i1 %a2, { i64, ptr } %a3) #0 {
entry:
  %l8 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t9 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eerrorList(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i1 %a2, { i64, ptr } %a3)
  store i32 %t9, ptr %l8
  br label %bb1
bb1:
  %t10 = load i32, ptr %l8, !tbaa !23
  store i32 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorSetEntries(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eerrorSetEntries(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWordName(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca { i64, ptr }
  %l13 = alloca i1
  %l18 = alloca { i64, ptr }
  %l21 = alloca i1
  %l29 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/generic:Program", ptr %t2, i32 0, i32 2
  %t5 = load i32, ptr %l1, !tbaa !23
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t4, i32 %t5)
  store i32 %t8, ptr %l9
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l5, !tbaa !29
  %t10 = load i32, ptr %l9, !tbaa !23
  %t11 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t9, i32 %t10)
  store { i64, ptr } %t11, ptr %l10
  br label %bb2
bb2:
  %t12 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t12, ptr %l3, !tbaa !27
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsRaisedError(ptr %v0, ptr %t13, i32 %t14)
  store i1 %t17, ptr %l13
  br label %bb3
bb3:
  %t18 = load i1, ptr %l13, !tbaa !21
  br i1 %t18, label %bb4, label %bb5
bb4:
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = extractvalue { i64, ptr } %t19, 0
  %t23 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t22)
  call void @olang_textcopy(ptr %t23, ptr %t21, i64 %t22)
  %t24 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t25, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i32, ptr %l1, !tbaa !23
  %t31 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %s0, ptr %t27, i32 %t28)
  store { i64, ptr } %t31, ptr %l18
  br label %bb7
bb7:
  %t32 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t32, ptr %l4, !tbaa !27
  %t33 = load i64, ptr %l2, !tbaa !24
  %t35 = icmp slt i64 %t33, 0
  br i1 %t35, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb10
bb9:
  %t37 = load i64, ptr %l2, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t38, 0
  %t43 = icmp sge i64 %t37, %t40
  store i1 %t43, ptr %l21, !tbaa !21
  br label %bb10
bb10:
  %t45 = load i1, ptr %l21, !tbaa !21
  br i1 %t45, label %bb11, label %bb12
bb11:
  %t46 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t47 = load i64, ptr %l2, !tbaa !24
  %t49 = extractvalue { i64, ptr } %t46, 1
  %t50 = extractvalue { i64, ptr } %t46, 0
  %t51 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t52 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t53 = add i64 %t50, %t52
  %t55 = call i64 @__olang_fmt_i64(ptr null, i64 %t47)
  %t56 = add i64 %t53, %t55
  %t57 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t56)
  call void @olang_textcopy(ptr %t57, ptr %t49, i64 %t50)
  %t58 = getelementptr i8, ptr %t57, i64 %t50
  call void @olang_textcopy(ptr %t58, ptr %t51, i64 %t52)
  %t59 = getelementptr i8, ptr %t58, i64 %t52
  %t60 = call i64 @__olang_fmt_i64(ptr %t59, i64 %t47)
  %t61 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t57, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t62, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t64 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t64, ptr %l29, !tbaa !27
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t66, ptr %l31, !tbaa !27
  %t67 = load i64, ptr %l2, !tbaa !24
  %t69 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr i32, ptr %t70, i64 %t67
  %t72 = load i32, ptr %t71, !tbaa !33
  %t75 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %s0, ptr %t65, i32 %t72)
  store { i64, ptr } %t75, ptr %l34
  br label %bb14
bb14:
  %t76 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t76, 1
  %t78 = extractvalue { i64, ptr } %t76, 0
  %t79 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t80 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t81 = add i64 %t78, %t80
  %t82 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 1
  %t84 = extractvalue { i64, ptr } %t82, 0
  %t85 = add i64 %t81, %t84
  %t86 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t85)
  call void @olang_textcopy(ptr %t86, ptr %t77, i64 %t78)
  %t87 = getelementptr i8, ptr %t86, i64 %t78
  call void @olang_textcopy(ptr %t87, ptr %t79, i64 %t80)
  %t88 = getelementptr i8, ptr %t87, i64 %t80
  call void @olang_textcopy(ptr %t88, ptr %t83, i64 %t84)
  %t89 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t86, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t90, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrsArgOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l6 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t7 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eerrsArg(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
  store i32 %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load i32, ptr %l6, !tbaa !23
  store i32 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnContext(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %lp4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i32
  %l20 = alloca %"compiler/generic:fnRow"
  %l23 = alloca %"compiler/generic:Context"
  %l27 = alloca { i64, ptr }
  %l30 = alloca i64
  %l34 = alloca i64
  %l37 = alloca i64
  %l55 = alloca ptr
  %l59 = alloca %"compiler/generic:varRow"
  %l60 = alloca i32
  %l65 = alloca i32
  %l66 = alloca { i64, ptr }
  %l74 = alloca i32
  %l77 = alloca %"compiler/generic:Context"
  %s0 = alloca %olang.scope
  %t20 = alloca %"compiler/generic:Context", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t1)
  store i64 %t3, ptr %l13
  br label %bb1
bb1:
  %t4 = load i64, ptr %l13, !tbaa !24
  store i64 %t4, ptr %l3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i64, ptr %l1, !tbaa !24
  %t9 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t5, i64 %t6)
  store i32 %t9, ptr %l16
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 21
  %t13 = load i64, ptr %l1, !tbaa !24
  %t16 = call %"compiler/generic:fnRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eAt_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %s0, ptr %t12, i64 %t13)
  store %"compiler/generic:fnRow" %t16, ptr %l20
  br label %bb3
bb3:
  %t17 = getelementptr %"compiler/generic:fnRow", ptr %l20, i32 0, i32 0
  %t18 = load i64, ptr %t17, !tbaa !24
  %t19 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fgeneric_3aContext_2ector(ptr %t20, ptr %v1, i64 %t18, i64 %t19)
  call void @llvm.memmove.p0.p0.i64(ptr %l23, ptr %t20, i64 160, i1 false)
  br label %bb4
bb4:
  %t23 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 160, i64 8)
  store ptr %t23, ptr %lp4
  %t24 = load ptr, ptr %lp4
  call void @llvm.memmove.p0.p0.i64(ptr %t24, ptr %l23, i64 160, i1 false)
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  %t31 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t27, i32 %a2)
  store { i64, ptr } %t31, ptr %l27
  br label %bb5
bb5:
  %t32 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t32, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i64, ptr %l3, !tbaa !24
  %t37 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t33, i64 %t34)
  store i64 %t37, ptr %l30
  br label %bb6
bb6:
  %t38 = load i64, ptr %l30, !tbaa !24
  store i64 %t38, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t39 = load i64, ptr %l7, !tbaa !24
  %t40 = load i64, ptr %l6, !tbaa !24
  %t43 = icmp sgt i64 %t39, %t40
  br i1 %t43, label %bb7, label %bb8
bb7:
  %t45 = load i64, ptr %l8, !tbaa !24
  %t47 = icmp sgt i64 %t45, 0
  br i1 %t47, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb12
bb9:
  %t49 = load i64, ptr %l7, !tbaa !24
  %t50 = load i64, ptr %l6, !tbaa !24
  %t53 = sub i64 %t49, %t50
  %t54 = load i64, ptr %l8, !tbaa !24
  %t57 = add i64 %t53, %t54
  %t59 = sub i64 %t57, 1
  %t60 = load i64, ptr %l8, !tbaa !24
  %t63 = sdiv i64 %t59, %t60
  store i64 %t63, ptr %l37, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb11
bb11:
  %t65 = load i64, ptr %l37, !tbaa !24
  store i64 %t65, ptr %l34, !tbaa !24
  br label %bb12
bb12:
  %t66 = load i64, ptr %l34, !tbaa !24
  store i64 %t66, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb13
bb13:
  %t67 = load i64, ptr %l10, !tbaa !24
  %t68 = load i64, ptr %l9, !tbaa !24
  %t71 = icmp slt i64 %t67, %t68
  %t73 = xor i1 %t71, true
  br i1 %t73, label %bb14, label %bb15
bb14:
  br label %bb24
bb15:
  br label %bb16
bb16:
  %t75 = load i64, ptr %l6, !tbaa !24
  %t76 = load i64, ptr %l10, !tbaa !24
  %t77 = load i64, ptr %l8, !tbaa !24
  %t80 = mul i64 %t76, %t77
  %t83 = add i64 %t75, %t80
  store i64 %t83, ptr %l11, !tbaa !24
  %t85 = load ptr, ptr %lp4
  %t86 = getelementptr %"compiler/generic:Context", ptr %t85, i32 0, i32 2
  store ptr %t86, ptr %l55, !tbaa !29
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load i64, ptr %l3, !tbaa !24
  %t89 = load i64, ptr %l11, !tbaa !24
  %t93 = call %"compiler/generic:varRow" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarAt(ptr %v0, ptr %t87, i64 %t88, i64 %t89)
  store %"compiler/generic:varRow" %t93, ptr %l59
  br label %bb17
bb17:
  %t94 = getelementptr %"compiler/generic:varRow", ptr %l59, i32 0, i32 1
  %t95 = load i32, ptr %t94, !tbaa !23
  store i32 %t95, ptr %l60, !tbaa !23
  %t96 = load i64, ptr %l11, !tbaa !24
  %t97 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t97, 0
  %t102 = icmp slt i64 %t96, %t99
  br i1 %t102, label %bb18, label %bb19
bb18:
  %t104 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t104, ptr %l66, !tbaa !27
  %t105 = load i64, ptr %l11, !tbaa !24
  %t107 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = getelementptr i32, ptr %t108, i64 %t105
  %t110 = load i32, ptr %t109, !tbaa !33
  store i32 %t110, ptr %l65, !tbaa !23
  br label %bb21
bb19:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/generic:Program", ptr %t112, i32 0, i32 2
  %t115 = load i64, ptr %l3, !tbaa !24
  %t116 = load i64, ptr %l11, !tbaa !24
  %t117 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t122 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eVar(ptr %v0, ptr %t114, i64 %t115, i64 %t116, i64 %t117)
  store i32 %t122, ptr %l74
  br label %bb20
bb20:
  %t123 = load i32, ptr %l74, !tbaa !23
  store i32 %t123, ptr %l65, !tbaa !23
  br label %bb21
bb21:
  %t124 = load ptr, ptr %l55, !tbaa !29
  %t125 = load i32, ptr %l60, !tbaa !23
  %t126 = load i32, ptr %l65, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H943a9bb03970f71acf57214091669a7d(ptr %v1, ptr %t124, i32 %t125, i32 %t126)
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t127 = load i64, ptr %l10, !tbaa !24
  %t129 = add i64 %t127, 1
  store i64 %t129, ptr %l10, !tbaa !24
  br label %bb13
bb24:
  %t131 = load ptr, ptr %lp4
  call void @llvm.memmove.p0.p0.i64(ptr %l77, ptr %t131, i64 160, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l77, i64 160, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %a0) #0 {
entry:
  %l3 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/generic:Program", ptr %a0, i32 0, i32 21
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eLen_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load i64, ptr %l3, !tbaa !24
  store i64 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i32
  %l4 = alloca %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca %"compiler/generic:fnRow"
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l21 = alloca i32
  %l24 = alloca %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20"
  %l25 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i32
  %l35 = alloca i64
  %l36 = alloca ptr
  %l39 = alloca i32
  %l42 = alloca i32
  %l46 = alloca %"compiler/generic:fnRow"
  %l47 = alloca %"std/prelude/text:StringBuilder"
  %l48 = alloca ptr
  %l53 = alloca ptr
  %l62 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l70 = alloca ptr
  %l72 = alloca ptr
  %l76 = alloca i32
  %l79 = alloca i32
  %l83 = alloca i32
  %l85 = alloca { i64, ptr }
  %l88 = alloca ptr
  %l92 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l106 = alloca i64
  %l109 = alloca i64
  %l130 = alloca ptr
  %l133 = alloca { i64, ptr }
  %l136 = alloca { i64, ptr }
  %l143 = alloca i64
  %l145 = alloca { i64, ptr }
  %l148 = alloca ptr
  %l149 = alloca i64
  %l150 = alloca i32
  %l151 = alloca i32
  %l153 = alloca { i64, ptr }
  %l158 = alloca %"compiler/generic:instance"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2einstanceArgs(ptr %v0, ptr %t1, i32 %a2)
  store i32 %t5, ptr %l21
  br label %bb1
bb1:
  %t6 = load i32, ptr %l21, !tbaa !23
  store i32 %t6, ptr %l3, !tbaa !23
  %t7 = load i64, ptr %l1, !tbaa !24
  %t8 = load i32, ptr %l3, !tbaa !23
  %t11 = call %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" @std_2fpair_3aPair_3cI64_2c_20compiler_2ftypes_3aListId_3e_2ector(ptr %s0, i64 %t7, i32 %t8)
  store %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %t11, ptr %l24
  br label %bb2
bb2:
  %t12 = load %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l24
  store %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %t12, ptr %l4
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 32
  %t16 = load %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l4
  %t19 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20compiler__Hfc7ca136f786d4bb067f513e5dea5730(ptr %v0, ptr %t15, %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %t16)
  %t20 = extractvalue { i32, i64 } %t19, 1
  %t21 = extractvalue { i32, i64 } %t19, 0
  store i32 %t21, ptr %l30
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb4, label %ok.23, !prof !99
ok.23:
  store i64 %t20, ptr %l29
  br label %bb3
bb3:
  %t24 = load i64, ptr %l29, !tbaa !24
  store i64 %t24, ptr %l25, !tbaa !24
  br label %bb6
bb4:
  br label %bb5
bb5:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l25, !tbaa !24
  br label %bb6
bb6:
  %t25 = load i64, ptr %l25, !tbaa !24
  store i64 %t25, ptr %l5, !tbaa !24
  %t26 = load i64, ptr %l5, !tbaa !24
  %t28 = icmp sge i64 %t26, 0
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t30 = load i64, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t30, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t32 = load i64, ptr %l1, !tbaa !24
  %t34 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t32)
  store i64 %t34, ptr %l35
  br label %bb10
bb10:
  %t35 = load i64, ptr %l35, !tbaa !24
  store i64 %t35, ptr %l6, !tbaa !24
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l36, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i64, ptr %l1, !tbaa !24
  %t41 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t37, i64 %t38)
  store i32 %t41, ptr %l39
  br label %bb11
bb11:
  %t42 = load i64, ptr %l6, !tbaa !24
  %t43 = load i32, ptr %l3, !tbaa !23
  %t44 = load ptr, ptr %l36, !tbaa !29
  %t45 = load i32, ptr %l39, !tbaa !23
  %t48 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %t44, i32 %t45, i64 %t42, i32 %t43)
  store i32 %t48, ptr %l42
  br label %bb12
bb12:
  %t49 = load i32, ptr %l42, !tbaa !23
  store i32 %t49, ptr %l7, !tbaa !23
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/generic:Program", ptr %t50, i32 0, i32 21
  %t53 = load i64, ptr %l1, !tbaa !24
  %t56 = call %"compiler/generic:fnRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eAt_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %v0, ptr %t52, i64 %t53)
  store %"compiler/generic:fnRow" %t56, ptr %l46
  br label %bb13
bb13:
  %t57 = load %"compiler/generic:fnRow", ptr %l46
  store %"compiler/generic:fnRow" %t57, ptr %l8
  %t58 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t58, ptr %l47
  br label %bb14
bb14:
  %t59 = load %"std/prelude/text:StringBuilder", ptr %l47
  store %"std/prelude/text:StringBuilder" %t59, ptr %l9
  store ptr %l9, ptr %l48, !tbaa !29
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/generic:Program", ptr %t60, i32 0, i32 0
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = getelementptr %"compiler/load:Loader", ptr %t63, i32 0, i32 10
  %t66 = getelementptr %"compiler/generic:fnRow", ptr %l8, i32 0, i32 0
  %t67 = load i64, ptr %t66, !tbaa !24
  %t70 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t65, i64 %t67)
  store ptr %t70, ptr %l53
  br label %bb15
bb15:
  %t71 = load ptr, ptr %l53, !tbaa !29
  %t73 = getelementptr %"compiler/load:Module", ptr %t71, i32 0, i32 2
  %t74 = load { i64, ptr }, ptr %t73, !tbaa !27
  %t75 = load ptr, ptr %l48, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t75, { i64, ptr } %t74)
  br label %bb16
bb16:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l9, i8 46)
  br label %bb17
bb17:
  %t78 = getelementptr %"compiler/generic:fnRow", ptr %l8, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = getelementptr %"compiler/ast:Func", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = icmp eq ptr %t82, null
  %t86 = xor i1 %t84, true
  br i1 %t86, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s2
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/generic:Program", ptr %t88, i32 0, i32 2
  store ptr %t90, ptr %l62, !tbaa !29
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/generic:Program", ptr %t91, i32 0, i32 2
  %t94 = load i32, ptr %l7, !tbaa !23
  %t97 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t93, i32 %t94)
  store i32 %t97, ptr %l66
  br label %bb20
bb19:
  br label %bb30
bb20:
  %t98 = load ptr, ptr %l62, !tbaa !29
  %t99 = load i32, ptr %l66, !tbaa !23
  %t100 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s2, ptr %t98, i32 %t99)
  store { i64, ptr } %t100, ptr %l67
  br label %bb21
bb21:
  %t101 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t101, ptr %l68, !tbaa !27
  %t102 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr i32, ptr %t103, i64 0
  %t105 = load i32, ptr %t104, !tbaa !33
  store i32 %t105, ptr %l10, !tbaa !23
  store ptr %l9, ptr %l70, !tbaa !29
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/generic:Program", ptr %t107, i32 0, i32 2
  store ptr %t109, ptr %l72, !tbaa !29
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/generic:Program", ptr %t110, i32 0, i32 2
  %t113 = load i32, ptr %l10, !tbaa !23
  %t116 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t112, i32 %t113)
  store i32 %t116, ptr %l76
  br label %bb22
bb22:
  %t117 = load i32, ptr %l76, !range !{i32 0, i32 33}
  %t119 = trunc i64 20 to i32
  %t120 = icmp eq i32 %t117, %t119
  br i1 %t120, label %bb23, label %bb24
bb23:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/generic:Program", ptr %t122, i32 0, i32 2
  %t125 = load i32, ptr %l10, !tbaa !23
  %t128 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t124, i32 %t125)
  store i32 %t128, ptr %l83
  br label %bb25
bb24:
  %t129 = load i32, ptr %l10, !tbaa !23
  store i32 %t129, ptr %l79, !tbaa !23
  br label %bb26
bb25:
  %t131 = load i32, ptr %l83, !tbaa !23
  store i32 %t131, ptr %l79, !tbaa !23
  br label %bb26
bb26:
  %t132 = load ptr, ptr %l72, !tbaa !29
  %t133 = load i32, ptr %l79, !tbaa !23
  %t134 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s2, ptr %t132, i32 %t133)
  store { i64, ptr } %t134, ptr %l85
  br label %bb27
bb27:
  %t135 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t135, 0
  %t137 = extractvalue { i64, ptr } %t135, 1
  %t138 = mul i64 %t136, 1
  %t139 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t138)
  call void @llvm.memcpy.p0.p0.i64(ptr %t139, ptr %t137, i64 %t138, i1 false)
  %t140 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t139, 1
  %t142 = load ptr, ptr %l70, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t142, { i64, ptr } %t141)
  br label %bb28
bb28:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l9, i8 46)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s2)
  br label %bb30
bb30:
  store ptr %l9, ptr %l88, !tbaa !29
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/generic:fnRow", ptr %l8, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !29
  %t149 = getelementptr %"compiler/ast:Func", ptr %t147, i32 0, i32 2
  %t150 = load i32, ptr %t149, !tbaa !23
  %t153 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t145, i32 %t150)
  store { i64, ptr } %t153, ptr %l92
  br label %bb31
bb31:
  %t154 = load ptr, ptr %l88, !tbaa !29
  %t155 = load { i64, ptr }, ptr %l92, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t154, { i64, ptr } %t155)
  br label %bb32
bb32:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/generic:Program", ptr %t156, i32 0, i32 2
  %t159 = load i32, ptr %l3, !tbaa !23
  %t162 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t158, i32 %t159)
  store { i64, ptr } %t162, ptr %l96
  br label %bb33
bb33:
  %t163 = load { i64, ptr }, ptr %l96, !tbaa !27
  store { i64, ptr } %t163, ptr %l11, !tbaa !27
  %t164 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t166 = extractvalue { i64, ptr } %t164, 0
  %t168 = icmp sgt i64 %t166, 0
  br i1 %t168, label %bb34, label %bb35
bb34:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l9, i8 60)
  br label %bb36
bb35:
  br label %bb56
bb36:
  store i64 0, ptr %l12, !tbaa !24
  %t171 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t173 = extractvalue { i64, ptr } %t171, 0
  store i64 %t173, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t175 = load i64, ptr %l13, !tbaa !24
  %t176 = load i64, ptr %l12, !tbaa !24
  %t179 = icmp sgt i64 %t175, %t176
  br i1 %t179, label %bb37, label %bb38
bb37:
  %t181 = load i64, ptr %l14, !tbaa !24
  %t183 = icmp sgt i64 %t181, 0
  br i1 %t183, label %bb39, label %bb40
bb38:
  store i64 0, ptr %l106, !tbaa !24
  br label %bb42
bb39:
  %t185 = load i64, ptr %l13, !tbaa !24
  %t186 = load i64, ptr %l12, !tbaa !24
  %t189 = sub i64 %t185, %t186
  %t190 = load i64, ptr %l14, !tbaa !24
  %t193 = add i64 %t189, %t190
  %t195 = sub i64 %t193, 1
  %t196 = load i64, ptr %l14, !tbaa !24
  %t199 = sdiv i64 %t195, %t196
  store i64 %t199, ptr %l109, !tbaa !24
  br label %bb41
bb40:
  store i64 0, ptr %l109, !tbaa !24
  br label %bb41
bb41:
  %t201 = load i64, ptr %l109, !tbaa !24
  store i64 %t201, ptr %l106, !tbaa !24
  br label %bb42
bb42:
  %t202 = load i64, ptr %l106, !tbaa !24
  store i64 %t202, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb43
bb43:
  store %olang.scope zeroinitializer, ptr %s5
  %t203 = load i64, ptr %l16, !tbaa !24
  %t204 = load i64, ptr %l15, !tbaa !24
  %t207 = icmp slt i64 %t203, %t204
  %t209 = xor i1 %t207, true
  br i1 %t209, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s5)
  br label %bb54
bb45:
  br label %bb46
bb46:
  %t211 = load i64, ptr %l12, !tbaa !24
  %t212 = load i64, ptr %l16, !tbaa !24
  %t213 = load i64, ptr %l14, !tbaa !24
  %t216 = mul i64 %t212, %t213
  %t219 = add i64 %t211, %t216
  store i64 %t219, ptr %l17, !tbaa !24
  %t221 = load i64, ptr %l17, !tbaa !24
  %t223 = icmp sgt i64 %t221, 0
  br i1 %t223, label %bb47, label %bb48
bb47:
  store %olang.scope zeroinitializer, ptr %s6
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %l9, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d22, i32 0, i32 1) })
  br label %bb49
bb48:
  br label %bb50
bb49:
  call void @__olang_scope_close(ptr %s6)
  br label %bb50
bb50:
  store ptr %l9, ptr %l130, !tbaa !29
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr %"compiler/generic:Program", ptr %t226, i32 0, i32 2
  %t229 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t229, ptr %l133, !tbaa !27
  %t230 = load i64, ptr %l17, !tbaa !24
  %t232 = getelementptr { i64, ptr }, ptr %l133, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !27
  %t234 = getelementptr i32, ptr %t233, i64 %t230
  %t235 = load i32, ptr %t234, !tbaa !33
  %t238 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s5, ptr %t228, i32 %t235)
  store { i64, ptr } %t238, ptr %l136
  br label %bb51
bb51:
  %t239 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t240 = extractvalue { i64, ptr } %t239, 0
  %t241 = extractvalue { i64, ptr } %t239, 1
  %t242 = mul i64 %t240, 1
  %t243 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t242)
  call void @llvm.memcpy.p0.p0.i64(ptr %t243, ptr %t241, i64 %t242, i1 false)
  %t244 = insertvalue { i64, ptr } undef, i64 %t240, 0
  %t245 = insertvalue { i64, ptr } %t244, ptr %t243, 1
  %t246 = load ptr, ptr %l130, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %t246, { i64, ptr } %t245)
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s5)
  br label %bb53
bb53:
  %t248 = load i64, ptr %l16, !tbaa !24
  %t250 = add i64 %t248, 1
  store i64 %t250, ptr %l16, !tbaa !24
  br label %bb43
bb54:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l9, i8 62)
  br label %bb55
bb55:
  br label %bb56
bb56:
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t255 = getelementptr %"compiler/generic:Program", ptr %t253, i32 0, i32 31
  %t257 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3ainstance_3e_2eLen_Hf1590ba3dea8cd8a914b2a9f5344a2c6(ptr %v0, ptr %t255)
  store i64 %t257, ptr %l143
  br label %bb57
bb57:
  %t258 = load i64, ptr %l143, !tbaa !24
  store i64 %t258, ptr %l5, !tbaa !24
  %t260 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v0, ptr %l9)
  store { i64, ptr } %t260, ptr %l145
  br label %bb58
bb58:
  %t261 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t262 = extractvalue { i64, ptr } %t261, 0
  %t263 = extractvalue { i64, ptr } %t261, 1
  %t264 = mul i64 %t262, 1
  %t265 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t264)
  call void @llvm.memcpy.p0.p0.i64(ptr %t265, ptr %t263, i64 %t264, i1 false)
  %t266 = insertvalue { i64, ptr } undef, i64 %t262, 0
  %t267 = insertvalue { i64, ptr } %t266, ptr %t265, 1
  store { i64, ptr } %t267, ptr %l18, !tbaa !27
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t271 = getelementptr %"compiler/generic:Program", ptr %t269, i32 0, i32 31
  store ptr %t271, ptr %l148, !tbaa !29
  %t272 = load i64, ptr %l1, !tbaa !24
  store i64 %t272, ptr %l149, !tbaa !24
  %t273 = load i32, ptr %l3, !tbaa !23
  store i32 %t273, ptr %l150, !tbaa !23
  %t274 = load i32, ptr %l7, !tbaa !23
  store i32 %t274, ptr %l151, !tbaa !23
  %t275 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t277 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v0, ptr %v0, { i64, ptr } %t275)
  store { i64, ptr } %t277, ptr %l153
  br label %bb59
bb59:
  %t278 = load { i64, ptr }, ptr %l153, !tbaa !27
  %t279 = extractvalue { i64, ptr } %t278, 0
  %t280 = extractvalue { i64, ptr } %t278, 1
  %t281 = mul i64 %t279, 1
  %t282 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t281)
  call void @llvm.memcpy.p0.p0.i64(ptr %t282, ptr %t280, i64 %t281, i1 false)
  %t283 = insertvalue { i64, ptr } undef, i64 %t279, 0
  %t284 = insertvalue { i64, ptr } %t283, ptr %t282, 1
  %t285 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t288 = getelementptr %"compiler/generic:Program", ptr %t286, i32 0, i32 38
  %t289 = load %"compiler/generic:Origin", ptr %t288
  %t290 = load i64, ptr %l149, !tbaa !24
  %t291 = load i32, ptr %l150, !tbaa !23
  %t292 = load i32, ptr %l151, !tbaa !23
  %t296 = call %"compiler/generic:instance" @compiler_2fgeneric_3ainstance_2ector(ptr %v0, ptr %v0, ptr %v0, i64 %t290, i32 %t291, i32 %t292, { i64, ptr } %t284, { i64, ptr } %t285, %"compiler/generic:Origin" %t289)
  store %"compiler/generic:instance" %t296, ptr %l158
  br label %bb60
bb60:
  %t297 = load ptr, ptr %l148, !tbaa !29
  %t298 = load %"compiler/generic:instance", ptr %l158
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3ainstance_3e_2ePus_Hca36cd1c69200a0db62aadeba49cf6ed(ptr %v0, ptr %v0, ptr %t297, %"compiler/generic:instance" %t298)
  br label %bb61
bb61:
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t301 = getelementptr %"compiler/generic:Program", ptr %t299, i32 0, i32 32
  %t302 = load %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l4
  %t303 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H5edca056502a242264473f986489341f(ptr %v0, ptr %t301, %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %t302, i64 %t303)
  br label %bb62
bb62:
  %t307 = load i64, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t307, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnKey(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/generic:fnRow"
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l13 = alloca %"compiler/generic:fnRow"
  %l14 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca ptr
  %l20 = alloca ptr
  %l30 = alloca i32
  %l34 = alloca i32
  %l37 = alloca ptr
  %l38 = alloca ptr
  %l40 = alloca ptr
  %l44 = alloca i32
  %l45 = alloca i32
  %l46 = alloca { i64, ptr }
  %l48 = alloca ptr
  %l52 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 21
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call %"compiler/generic:fnRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eAt_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store %"compiler/generic:fnRow" %t7, ptr %l13
  br label %bb1
bb1:
  %t8 = load %"compiler/generic:fnRow", ptr %l13
  store %"compiler/generic:fnRow" %t8, ptr %l2
  %t9 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t9, ptr %l14
  br label %bb2
bb2:
  %t10 = load %"std/prelude/text:StringBuilder", ptr %l14
  store %"std/prelude/text:StringBuilder" %t10, ptr %l3
  store ptr %l3, ptr %l15, !tbaa !29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/generic:Program", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/load:Loader", ptr %t14, i32 0, i32 10
  %t17 = getelementptr %"compiler/generic:fnRow", ptr %l2, i32 0, i32 0
  %t18 = load i64, ptr %t17, !tbaa !24
  %t21 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t16, i64 %t18)
  store ptr %t21, ptr %l20
  br label %bb3
bb3:
  %t22 = load ptr, ptr %l20, !tbaa !29
  %t24 = getelementptr %"compiler/load:Module", ptr %t22, i32 0, i32 2
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  %t26 = load ptr, ptr %l15, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t26, { i64, ptr } %t25)
  br label %bb4
bb4:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l3, i8 58)
  br label %bb5
bb5:
  %t29 = getelementptr %"compiler/generic:fnRow", ptr %l2, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"compiler/ast:Func", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = icmp eq ptr %t33, null
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb6, label %bb7
bb6:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load i64, ptr %l1, !tbaa !24
  %t43 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2erecvOf(ptr %v0, ptr %t39, i64 %t40)
  store i32 %t43, ptr %l30
  br label %bb8
bb7:
  br label %bb18
bb8:
  %t44 = load i32, ptr %l30, !tbaa !23
  store i32 %t44, ptr %l4, !tbaa !23
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/generic:Program", ptr %t45, i32 0, i32 2
  %t48 = load i32, ptr %l4, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t47, i32 %t48)
  store i32 %t51, ptr %l34
  br label %bb9
bb9:
  %t52 = load i32, ptr %l34, !range !{i32 0, i32 33}
  %t54 = trunc i64 18 to i32
  %t55 = icmp eq i32 %t52, %t54
  br i1 %t55, label %bb10, label %bb11
bb10:
  store ptr %l3, ptr %l37, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l38, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/generic:Program", ptr %t58, i32 0, i32 2
  store ptr %t60, ptr %l40, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/generic:Program", ptr %t61, i32 0, i32 2
  %t64 = load i32, ptr %l4, !tbaa !23
  %t67 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t63, i32 %t64)
  store i32 %t67, ptr %l44
  br label %bb12
bb11:
  br label %bb16
bb12:
  %t68 = load ptr, ptr %l40, !tbaa !29
  %t69 = load i32, ptr %l44, !tbaa !23
  %t70 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t68, i32 %t69)
  store i32 %t70, ptr %l45
  br label %bb13
bb13:
  %t71 = load ptr, ptr %l38, !tbaa !29
  %t72 = load i32, ptr %l45, !tbaa !23
  %t73 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t71, i32 %t72)
  store { i64, ptr } %t73, ptr %l46
  br label %bb14
bb14:
  %t74 = load ptr, ptr %l37, !tbaa !29
  %t75 = load { i64, ptr }, ptr %l46, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t74, { i64, ptr } %t75)
  br label %bb15
bb15:
  br label %bb16
bb16:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l3, i8 46)
  br label %bb17
bb17:
  br label %bb18
bb18:
  store ptr %l3, ptr %l48, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/generic:fnRow", ptr %l2, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = getelementptr %"compiler/ast:Func", ptr %t79, i32 0, i32 2
  %t82 = load i32, ptr %t81, !tbaa !23
  %t85 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t77, i32 %t82)
  store { i64, ptr } %t85, ptr %l52
  br label %bb19
bb19:
  %t86 = load ptr, ptr %l48, !tbaa !29
  %t87 = load { i64, ptr }, ptr %l52, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t86, { i64, ptr } %t87)
  br label %bb20
bb20:
  store i64 -3750763034362895579, ptr %l5, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s3
  %t89 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s3, ptr %l3)
  store { i64, ptr } %t89, ptr %l54
  br label %bb21
bb21:
  %t90 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 0
  %t92 = extractvalue { i64, ptr } %t90, 1
  %t93 = mul i64 %t91, 1
  %t94 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t93)
  call void @llvm.memcpy.p0.p0.i64(ptr %t94, ptr %t92, i64 %t93, i1 false)
  %t95 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t94, 1
  store { i64, ptr } %t96, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t98 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t98, 0
  store i64 %t100, ptr %l8, !tbaa !24
  br label %bb22
bb22:
  %t102 = load i64, ptr %l7, !tbaa !24
  %t103 = load i64, ptr %l8, !tbaa !24
  %t106 = icmp slt i64 %t102, %t103
  %t108 = xor i1 %t106, true
  br i1 %t108, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t110 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t110, ptr %l62, !tbaa !27
  %t111 = load i64, ptr %l7, !tbaa !24
  %t113 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr i8, ptr %t114, i64 %t111
  %t116 = load i8, ptr %t115, !tbaa !32
  %t118 = load i64, ptr %l5, !tbaa !24
  %t121 = zext i8 %t116 to i64
  %t124 = xor i64 %t118, %t121
  %t126 = mul i64 %t124, 1099511628211
  store i64 %t126, ptr %l5, !tbaa !24
  br label %bb26
bb26:
  %t128 = load i64, ptr %l7, !tbaa !24
  %t130 = add i64 %t128, 1
  store i64 %t130, ptr %l7, !tbaa !24
  br label %bb22
bb27:
  call void @__olang_scope_close(ptr %s3)
  %t132 = load i64, ptr %l5, !tbaa !24
  %t134 = and i64 %t132, 4611686018427387903
  call void @__olang_scope_close(ptr %s0)
  store i64 %t134, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l6 = alloca ptr
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t7 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eanyGlobal(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
  store ptr %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l6, !tbaa !29
  store ptr %t8, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalStorage(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l15 = alloca i32
  %l17 = alloca i1
  %l25 = alloca i64
  %l28 = alloca i64
  %l47 = alloca { i64, ptr }
  %l52 = alloca i1
  %l62 = alloca { i64, ptr }
  %l66 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t5 = getelementptr %"compiler/ast:VarDecl", ptr %t3, i32 0, i32 2
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t10 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %t1, ptr %t2, ptr %t6)
  store i32 %t10, ptr %l15
  br label %bb1
bb1:
  %t11 = load i32, ptr %l15, !tbaa !23
  store i32 %t11, ptr %l4, !tbaa !23
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t14 = call i1 @compiler_2fgeneric_2emutableGlobal(ptr %v2, ptr %t12)
  store i1 %t14, ptr %l17
  br label %bb2
bb2:
  %t15 = load i1, ptr %l17, !tbaa !21
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t16 = load i32, ptr %l4, !tbaa !23
  store i32 %t16, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  store i64 0, ptr %l5, !tbaa !24
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t20 = getelementptr %"compiler/ast:VarDecl", ptr %t18, i32 0, i32 0
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t25 = load i64, ptr %l6, !tbaa !24
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = icmp sgt i64 %t25, %t26
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t31 = load i64, ptr %l7, !tbaa !24
  %t33 = icmp sgt i64 %t31, 0
  br i1 %t33, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb11
bb8:
  %t35 = load i64, ptr %l6, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = sub i64 %t35, %t36
  %t40 = load i64, ptr %l7, !tbaa !24
  %t43 = add i64 %t39, %t40
  %t45 = sub i64 %t43, 1
  %t46 = load i64, ptr %l7, !tbaa !24
  %t49 = sdiv i64 %t45, %t46
  store i64 %t49, ptr %l28, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb10
bb10:
  %t51 = load i64, ptr %l28, !tbaa !24
  store i64 %t51, ptr %l25, !tbaa !24
  br label %bb11
bb11:
  %t52 = load i64, ptr %l25, !tbaa !24
  store i64 %t52, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb12
bb12:
  %t53 = load i64, ptr %l9, !tbaa !24
  %t54 = load i64, ptr %l8, !tbaa !24
  %t57 = icmp slt i64 %t53, %t54
  %t59 = xor i1 %t57, true
  br i1 %t59, label %bb13, label %bb14
bb13:
  br label %bb24
bb14:
  br label %bb15
bb15:
  %t61 = load i64, ptr %l5, !tbaa !24
  %t62 = load i64, ptr %l9, !tbaa !24
  %t63 = load i64, ptr %l7, !tbaa !24
  %t66 = mul i64 %t62, %t63
  %t69 = add i64 %t61, %t66
  store i64 %t69, ptr %l10, !tbaa !24
  %t71 = load ptr, ptr %l2, !tbaa !29
  %t73 = getelementptr %"compiler/ast:VarDecl", ptr %t71, i32 0, i32 0
  %t74 = load { i64, ptr }, ptr %t73, !tbaa !27
  store { i64, ptr } %t74, ptr %l47, !tbaa !27
  %t75 = load i64, ptr %l10, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr i32, ptr %t78, i64 %t75
  %t80 = load i32, ptr %t79, !tbaa !33
  %t84 = icmp eq i32 %t80, %a3
  br i1 %t84, label %bb16, label %bb17
bb16:
  %t86 = load i64, ptr %l10, !tbaa !24
  %t87 = load ptr, ptr %l2, !tbaa !29
  %t89 = getelementptr %"compiler/ast:VarDecl", ptr %t87, i32 0, i32 3
  %t90 = load { i64, ptr }, ptr %t89, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t90, 0
  %t95 = icmp slt i64 %t86, %t92
  store i1 %t95, ptr %l52, !tbaa !21
  br label %bb18
bb17:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb18
bb18:
  %t97 = load i1, ptr %l52, !tbaa !21
  br i1 %t97, label %bb19, label %bb20
bb19:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load ptr, ptr %l1, !tbaa !29
  %t100 = load i32, ptr %l4, !tbaa !23
  %t101 = load ptr, ptr %l2, !tbaa !29
  %t103 = getelementptr %"compiler/ast:VarDecl", ptr %t101, i32 0, i32 3
  %t104 = load { i64, ptr }, ptr %t103, !tbaa !27
  store { i64, ptr } %t104, ptr %l62, !tbaa !27
  %t105 = load i64, ptr %l10, !tbaa !24
  %t107 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = getelementptr ptr, ptr %t108, i64 %t105
  %t110 = load ptr, ptr %t109, !tbaa !39
  %t116 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eStorageOf(ptr %v0, ptr %v1, ptr %v2, ptr %t98, ptr %t99, i32 %t100, ptr %t110)
  store i32 %t116, ptr %l66
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t117 = load i32, ptr %l66, !tbaa !23
  store i32 %t117, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t118 = load i64, ptr %l9, !tbaa !24
  %t120 = add i64 %t118, 1
  store i64 %t120, ptr %l9, !tbaa !24
  br label %bb12
bb24:
  %t122 = load i32, ptr %l4, !tbaa !23
  store i32 %t122, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eHasHash(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ehasHash(ptr %v0, ptr %a0, i32 %a1, i64 0)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eImmut(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i32
  %l11 = alloca i32
  %l15 = alloca i1
  %l18 = alloca i1
  %l20 = alloca i1
  %l22 = alloca ptr
  %l26 = alloca i32
  %l27 = alloca i32
  %l32 = alloca ptr
  %l36 = alloca i32
  %l37 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclWord(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4, !range !{i32 0, i32 3}
  %t8 = trunc i64 1 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/generic:Program", ptr %t12, i32 0, i32 2
  %t15 = load i32, ptr %l1, !tbaa !23
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t14, i32 %t15)
  store i32 %t18, ptr %l11
  br label %bb5
bb5:
  %t19 = load i32, ptr %l11, !range !{i32 0, i32 33}
  %t21 = trunc i64 18 to i32
  %t22 = icmp eq i32 %t19, %t21
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb9
bb7:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load i32, ptr %l1, !tbaa !23
  %t30 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t26, i32 %t27)
  store i1 %t30, ptr %l18
  br label %bb8
bb8:
  %t31 = load i1, ptr %l18, !tbaa !21
  %t32 = xor i1 %t31, true
  store i1 %t32, ptr %l15, !tbaa !21
  br label %bb9
bb9:
  %t34 = load i1, ptr %l15, !tbaa !21
  br i1 %t34, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb14
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 2
  store ptr %t37, ptr %l22, !tbaa !29
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/generic:Program", ptr %t38, i32 0, i32 2
  %t41 = load i32, ptr %l1, !tbaa !23
  %t44 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t40, i32 %t41)
  store i32 %t44, ptr %l26
  br label %bb12
bb12:
  %t45 = load ptr, ptr %l22, !tbaa !29
  %t46 = load i32, ptr %l26, !tbaa !23
  %t47 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t45, i32 %t46)
  store i32 %t47, ptr %l27
  br label %bb13
bb13:
  %t48 = load i32, ptr %l27, !range !{i32 0, i32 6}
  %t50 = trunc i64 4 to i32
  %t51 = icmp eq i32 %t48, %t50
  %t53 = xor i1 %t51, true
  store i1 %t53, ptr %l20, !tbaa !21
  br label %bb14
bb14:
  %t55 = load i1, ptr %l20, !tbaa !21
  br i1 %t55, label %bb15, label %bb16
bb15:
  store i1 false, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l32, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/generic:Program", ptr %t58, i32 0, i32 2
  %t61 = load i32, ptr %l1, !tbaa !23
  %t64 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t60, i32 %t61)
  store i32 %t64, ptr %l36
  br label %bb18
bb18:
  %t65 = load ptr, ptr %l32, !tbaa !29
  %t66 = load i32, ptr %l36, !tbaa !23
  %t67 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eImmut(ptr %v0, ptr %t65, i32 %t66)
  store i1 %t67, ptr %l37
  br label %bb19
bb19:
  %t68 = load i1, ptr %l37, !tbaa !21
  store i1 %t68, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l5 = alloca %"compiler/generic:instance"
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/generic:Program", ptr %a0, i32 0, i32 31
  %t7 = call %"compiler/generic:instance" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3ainstance_3e_2eAt__Hf3965267bb92d0ee7aeaa2339e2e46fa(ptr %v0, ptr %s0, ptr %t3, i64 %a1)
  store %"compiler/generic:instance" %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = getelementptr %"compiler/generic:instance", ptr %l5, i32 0, i32 1
  %t9 = load i32, ptr %t8, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceContext(ptr %out, ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %lp3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l15 = alloca i32
  %l18 = alloca %"compiler/generic:Context"
  %l21 = alloca ptr
  %l23 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca { i64, ptr }
  %l32 = alloca i1
  %l43 = alloca i64
  %l46 = alloca i64
  %l70 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l79 = alloca %"compiler/generic:Context"
  %t11 = alloca %"compiler/generic:Context", align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l1, !tbaa !23
  %t7 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t7, ptr %l15
  br label %bb1
bb1:
  %t8 = load i32, ptr %l15, !tbaa !23
  store i32 %t8, ptr %l2, !tbaa !23
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2edeclContext(ptr %t11, ptr %v0, ptr %v1, ptr %t9, i32 %t10)
  call void @llvm.memmove.p0.p0.i64(ptr %l18, ptr %t11, i64 160, i1 false)
  br label %bb2
bb2:
  %t14 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 160, i64 8)
  store ptr %t14, ptr %lp3
  %t15 = load ptr, ptr %lp3
  call void @llvm.memmove.p0.p0.i64(ptr %t15, ptr %l18, i64 160, i1 false)
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etypeDecl(ptr %v0, ptr %v0, ptr %t16, i32 %t17)
  store ptr %t20, ptr %l21
  br label %bb3
bb3:
  %t21 = load ptr, ptr %l21, !tbaa !29
  store ptr %t21, ptr %l4, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 2
  store ptr %t24, ptr %l23, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  %t28 = load i32, ptr %l1, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l27
  br label %bb4
bb4:
  %t32 = load ptr, ptr %l23, !tbaa !29
  %t33 = load i32, ptr %l27, !tbaa !23
  %t34 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t32, i32 %t33)
  store { i64, ptr } %t34, ptr %l28
  br label %bb5
bb5:
  %t35 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t35, ptr %l5, !tbaa !27
  %t36 = load ptr, ptr %l4, !tbaa !29
  %t38 = icmp eq ptr %t36, null
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb6, label %bb7
bb6:
  %t42 = load ptr, ptr %l4, !tbaa !29
  %t44 = getelementptr %"compiler/ast:TypeDecl", ptr %t42, i32 0, i32 1
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t49 = icmp sgt i64 %t47, 0
  store i1 %t49, ptr %l32, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb8
bb8:
  %t51 = load i1, ptr %l32, !tbaa !21
  br i1 %t51, label %bb9, label %bb10
bb9:
  store i64 0, ptr %l6, !tbaa !24
  %t52 = load ptr, ptr %l4, !tbaa !29
  %t54 = getelementptr %"compiler/ast:TypeDecl", ptr %t52, i32 0, i32 1
  %t55 = load { i64, ptr }, ptr %t54, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t55, 0
  store i64 %t57, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t59 = load i64, ptr %l7, !tbaa !24
  %t60 = load i64, ptr %l6, !tbaa !24
  %t63 = icmp sgt i64 %t59, %t60
  br i1 %t63, label %bb11, label %bb12
bb10:
  br label %bb27
bb11:
  %t65 = load i64, ptr %l8, !tbaa !24
  %t67 = icmp sgt i64 %t65, 0
  br i1 %t67, label %bb13, label %bb14
bb12:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb16
bb13:
  %t69 = load i64, ptr %l7, !tbaa !24
  %t70 = load i64, ptr %l6, !tbaa !24
  %t73 = sub i64 %t69, %t70
  %t74 = load i64, ptr %l8, !tbaa !24
  %t77 = add i64 %t73, %t74
  %t79 = sub i64 %t77, 1
  %t80 = load i64, ptr %l8, !tbaa !24
  %t83 = sdiv i64 %t79, %t80
  store i64 %t83, ptr %l46, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l46, !tbaa !24
  br label %bb15
bb15:
  %t85 = load i64, ptr %l46, !tbaa !24
  store i64 %t85, ptr %l43, !tbaa !24
  br label %bb16
bb16:
  %t86 = load i64, ptr %l43, !tbaa !24
  store i64 %t86, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb17
bb17:
  %t87 = load i64, ptr %l10, !tbaa !24
  %t88 = load i64, ptr %l9, !tbaa !24
  %t91 = icmp slt i64 %t87, %t88
  %t93 = xor i1 %t91, true
  br i1 %t93, label %bb18, label %bb19
bb18:
  br label %bb26
bb19:
  br label %bb20
bb20:
  %t95 = load i64, ptr %l6, !tbaa !24
  %t96 = load i64, ptr %l10, !tbaa !24
  %t97 = load i64, ptr %l8, !tbaa !24
  %t100 = mul i64 %t96, %t97
  %t103 = add i64 %t95, %t100
  store i64 %t103, ptr %l11, !tbaa !24
  %t105 = load i64, ptr %l11, !tbaa !24
  %t106 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t106, 0
  %t111 = icmp slt i64 %t105, %t108
  br i1 %t111, label %bb21, label %bb22
bb21:
  %t113 = load ptr, ptr %lp3
  %t114 = getelementptr %"compiler/generic:Context", ptr %t113, i32 0, i32 2
  %t115 = load ptr, ptr %l4, !tbaa !29
  %t117 = getelementptr %"compiler/ast:TypeDecl", ptr %t115, i32 0, i32 1
  %t118 = load { i64, ptr }, ptr %t117, !tbaa !27
  store { i64, ptr } %t118, ptr %l70, !tbaa !27
  %t119 = load i64, ptr %l11, !tbaa !24
  %t121 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = getelementptr ptr, ptr %t122, i64 %t119
  %t124 = load ptr, ptr %t123, !tbaa !39
  %t126 = getelementptr %"compiler/ast:TypeParam", ptr %t124, i32 0, i32 1
  %t127 = load i32, ptr %t126, !tbaa !23
  %t128 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t128, ptr %l74, !tbaa !27
  %t129 = load i64, ptr %l11, !tbaa !24
  %t131 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr i32, ptr %t132, i64 %t129
  %t134 = load i32, ptr %t133, !tbaa !33
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H943a9bb03970f71acf57214091669a7d(ptr %v1, ptr %t114, i32 %t127, i32 %t134)
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t138 = load i64, ptr %l10, !tbaa !24
  %t140 = add i64 %t138, 1
  store i64 %t140, ptr %l10, !tbaa !24
  br label %bb17
bb26:
  br label %bb27
bb27:
  %t142 = load ptr, ptr %lp3
  call void @llvm.memmove.p0.p0.i64(ptr %l79, ptr %t142, i64 160, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l79, i64 160, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l5 = alloca %"compiler/generic:instance"
  %s0 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/generic:Program", ptr %a0, i32 0, i32 31
  %t7 = call %"compiler/generic:instance" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3ainstance_3e_2eAt__Hf3965267bb92d0ee7aeaa2339e2e46fa(ptr %v0, ptr %s0, ptr %t3, i64 %a1)
  store %"compiler/generic:instance" %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = getelementptr %"compiler/generic:instance", ptr %l5, i32 0, i32 0
  %t9 = load i64, ptr %t8, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsErrVar(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca i32
  %l8 = alloca i1
  %l9 = alloca i1
  %l11 = alloca ptr
  %l15 = alloca i64
  %l19 = alloca i64
  %l20 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l21 = alloca i1
  %l22 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l1, !tbaa !23
  %t7 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t10 = trunc i64 25 to i32
  %t11 = icmp eq i32 %t8, %t10
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 10
  store ptr %t15, ptr %l11, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %l1, !tbaa !23
  %t22 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t18, i32 %t19)
  store i64 %t22, ptr %l15
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb11
bb4:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 2
  %t26 = load i32, ptr %l1, !tbaa !23
  %t29 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t25, i32 %t26)
  store i64 %t29, ptr %l19
  br label %bb5
bb5:
  %t30 = load i64, ptr %l15, !tbaa !24
  %t31 = load i64, ptr %l19, !tbaa !24
  %t32 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t30, i64 %t31)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t32, ptr %l20
  br label %bb6
bb6:
  %t33 = load ptr, ptr %l11, !tbaa !29
  %t34 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l20
  %t35 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H190b78e3c1eec037529224679e114a85(ptr %v0, ptr %t33, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t34)
  %t36 = extractvalue { i32, i1 } %t35, 1
  %t37 = extractvalue { i32, i1 } %t35, 0
  store i32 %t37, ptr %l22
  %t38 = icmp ne i32 %t37, 0
  br i1 %t38, label %bb8, label %ok.39, !prof !99
ok.39:
  store i1 %t36, ptr %l21
  br label %bb7
bb7:
  %t40 = load i1, ptr %l21, !tbaa !21
  store i1 %t40, ptr %l9, !tbaa !21
  br label %bb10
bb8:
  br label %bb9
bb9:
  call void @__olang_ert_req_clear()
  store i1 false, ptr %l9, !tbaa !21
  br label %bb10
bb10:
  %t41 = load i1, ptr %l9, !tbaa !21
  store i1 %t41, ptr %l8, !tbaa !21
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t42 = load i1, ptr %l8, !tbaa !21
  store i1 %t42, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLenKey(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca i1
  %l23 = alloca { i64, ptr }
  %l24 = alloca i1
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l34 = alloca i1
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a2, 0
  %t5 = icmp sgt i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %l9, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t7, ptr %l10, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  store i64 %t9, ptr %l11, !tbaa !24
  %t10 = load i64, ptr %l11, !tbaa !24
  %t11 = mul i64 %t10, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l12, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = load i64, ptr %l11, !tbaa !24
  %t20 = mul i64 %t19, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t16, ptr %t18, i64 %t20, i1 false)
  %t21 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t21, ptr %l10, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t22, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t23 = load ptr, ptr %l1, !tbaa !29
  store ptr %t23, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t24 = load ptr, ptr %l13, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb4, label %bb5
bb4:
  %t27 = load ptr, ptr %l13, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 30}
  %t30 = icmp eq i64 %t28, 14
  store i1 %t30, ptr %l14, !tbaa !21
  br label %bb5
bb5:
  %t31 = load i1, ptr %l14, !tbaa !21
  br i1 %t31, label %bb6, label %bb7
bb6:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr { i64, [4 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t34, i32 0, i32 1
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l3, !tbaa !29
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t40, i32 0, i32 2
  %t42 = load i32, ptr %t41
  store i32 %t42, ptr %l4, !tbaa !23
  br label %bb8
bb7:
  br label %bb19
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load i32, ptr %l4, !tbaa !23
  %t48 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t44, i32 %t45)
  store { i64, ptr } %t48, ptr %l23
  br label %bb9
bb9:
  %t49 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t50 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t49, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d24, i32 0, i32 1) })
  store i1 %t50, ptr %l24
  br label %bb10
bb10:
  %t51 = load i1, ptr %l24, !tbaa !21
  %t52 = xor i1 %t51, true
  br i1 %t52, label %bb11, label %bb12
bb11:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d25, i32 0, i32 1) }, ptr %l26, !tbaa !27
  %t54 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t54, ptr %l27, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 0
  store i64 %t56, ptr %l28, !tbaa !24
  %t57 = load i64, ptr %l28, !tbaa !24
  %t58 = mul i64 %t57, 1
  %t59 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t58)
  %t60 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  store { i64, ptr } %t61, ptr %l29, !tbaa !27
  %t62 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = load i64, ptr %l28, !tbaa !24
  %t67 = mul i64 %t66, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t63, ptr %t65, i64 %t67, i1 false)
  %t68 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t68, ptr %l27, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  %t69 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t69, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load ptr, ptr %l3, !tbaa !29
  %t74 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2elenPath(ptr %v0, ptr %v1, ptr %s2, ptr %t70, ptr %t71, i64 0)
  store { i64, ptr } %t74, ptr %l32
  br label %bb14
bb14:
  %t75 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t75, ptr %l5, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t78 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t76, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d26, i32 0, i32 1) })
  store i1 %t78, ptr %l34
  br label %bb15
bb15:
  %t79 = load i1, ptr %l34, !tbaa !21
  br i1 %t79, label %bb16, label %bb17
bb16:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d27, i32 0, i32 1) }, ptr %l36, !tbaa !27
  %t80 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t80, ptr %l35, !tbaa !27
  br label %bb18
bb17:
  %t82 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t82, 1
  %t85 = extractvalue { i64, ptr } %t82, 0
  %t86 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t87 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  %t88 = add i64 %t85, %t87
  %t89 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t88)
  call void @olang_textcopy(ptr %t89, ptr %t84, i64 %t85)
  %t90 = getelementptr i8, ptr %t89, i64 %t85
  call void @olang_textcopy(ptr %t90, ptr %t86, i64 %t87)
  %t91 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t89, 1
  store { i64, ptr } %t92, ptr %l35, !tbaa !27
  br label %bb18
bb18:
  %t94 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 0
  store i64 %t95, ptr %l40, !tbaa !24
  %t96 = load i64, ptr %l40, !tbaa !24
  %t97 = mul i64 %t96, 1
  %t98 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t97)
  %t99 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  store { i64, ptr } %t100, ptr %l41, !tbaa !27
  %t101 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = load i64, ptr %l40, !tbaa !24
  %t106 = mul i64 %t105, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t102, ptr %t104, i64 %t106, i1 false)
  %t107 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t107, ptr %l35, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  %t108 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t108, ptr %rv
  br label %ret
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d29, i32 0, i32 1) }, ptr %l42, !tbaa !27
  %t109 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t109, ptr %l43, !tbaa !27
  %t110 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t110, 0
  store i64 %t111, ptr %l44, !tbaa !24
  %t112 = load i64, ptr %l44, !tbaa !24
  %t113 = mul i64 %t112, 1
  %t114 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t113)
  %t115 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t114, 1
  store { i64, ptr } %t116, ptr %l45, !tbaa !27
  %t117 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !27
  %t119 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = load i64, ptr %l44, !tbaa !24
  %t122 = mul i64 %t121, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t118, ptr %t120, i64 %t122, i1 false)
  %t123 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t123, ptr %l43, !tbaa !27
  %t124 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t124, ptr %rv
  br label %ret
bb23:
  call void @__olang_check_failed(ptr @olang_loc_7f496bc4f965d188_939cdcc04f80a0bc)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLengthsOnly(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l7 = alloca i1
  %l12 = alloca i32
  %l16 = alloca i1
  %l20 = alloca i32
  %l28 = alloca i32
  %l30 = alloca i1
  %l32 = alloca ptr
  %l36 = alloca i32
  %l40 = alloca i32
  %l41 = alloca i1
  %l44 = alloca ptr
  %l48 = alloca i32
  %l52 = alloca i32
  %l53 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l1, !tbaa !23
  %t5 = load i32, ptr %l2, !tbaa !23
  %t9 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t3, i32 %t4, i32 %t5)
  store i1 %t9, ptr %l7
  br label %bb1
bb1:
  %t10 = load i1, ptr %l7, !tbaa !21
  br i1 %t10, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/generic:Program", ptr %t12, i32 0, i32 2
  %t15 = load i32, ptr %l1, !tbaa !23
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t14, i32 %t15)
  store i32 %t18, ptr %l12
  br label %bb5
bb5:
  %t19 = load i32, ptr %l12, !range !{i32 0, i32 33}
  %t21 = trunc i64 19 to i32
  %t22 = icmp eq i32 %t19, %t21
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb9
bb7:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  %t29 = load i32, ptr %l2, !tbaa !23
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t32, ptr %l20
  br label %bb8
bb8:
  %t33 = load i32, ptr %l20, !range !{i32 0, i32 33}
  %t35 = trunc i64 19 to i32
  %t36 = icmp eq i32 %t33, %t35
  %t38 = xor i1 %t36, true
  store i1 %t38, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t40 = load i1, ptr %l16, !tbaa !21
  br i1 %t40, label %bb10, label %bb11
bb10:
  store i1 false, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/generic:Program", ptr %t42, i32 0, i32 2
  %t45 = load i32, ptr %l2, !tbaa !23
  %t48 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t44, i32 %t45)
  store i32 %t48, ptr %l28
  br label %bb13
bb13:
  %t49 = load i32, ptr %l28, !tbaa !23
  %t50 = icmp ne i32 %t49, 0
  br i1 %t50, label %bb14, label %bb15
bb14:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/generic:Program", ptr %t52, i32 0, i32 2
  store ptr %t54, ptr %l32, !tbaa !29
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/generic:Program", ptr %t55, i32 0, i32 2
  %t58 = load i32, ptr %l1, !tbaa !23
  %t61 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t57, i32 %t58)
  store i32 %t61, ptr %l36
  br label %bb16
bb15:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb19
bb16:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 2
  %t65 = load i32, ptr %l2, !tbaa !23
  %t68 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t64, i32 %t65)
  store i32 %t68, ptr %l40
  br label %bb17
bb17:
  %t69 = load ptr, ptr %l32, !tbaa !29
  %t70 = load i32, ptr %l36, !tbaa !23
  %t71 = load i32, ptr %l40, !tbaa !23
  %t72 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t69, i32 %t70, i32 %t71)
  store i1 %t72, ptr %l41
  br label %bb18
bb18:
  %t73 = load i1, ptr %l41, !tbaa !21
  %t74 = xor i1 %t73, true
  store i1 %t74, ptr %l30, !tbaa !21
  br label %bb19
bb19:
  %t76 = load i1, ptr %l30, !tbaa !21
  br i1 %t76, label %bb20, label %bb21
bb20:
  store i1 false, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l44, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/generic:Program", ptr %t79, i32 0, i32 2
  %t82 = load i32, ptr %l1, !tbaa !23
  %t85 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t81, i32 %t82)
  store i32 %t85, ptr %l48
  br label %bb23
bb23:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 2
  %t89 = load i32, ptr %l2, !tbaa !23
  %t92 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t88, i32 %t89)
  store i32 %t92, ptr %l52
  br label %bb24
bb24:
  %t93 = load ptr, ptr %l44, !tbaa !29
  %t94 = load i32, ptr %l48, !tbaa !23
  %t95 = load i32, ptr %l52, !tbaa !23
  %t96 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLengthsOnly(ptr %v0, ptr %t93, i32 %t94, i32 %t95)
  store i1 %t96, ptr %l53
  br label %bb25
bb25:
  %t97 = load i1, ptr %l53, !tbaa !21
  store i1 %t97, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMatches(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3, i64 %a4, i1 %a5) #0 {
entry:
  %l6 = alloca %"compiler/generic:Binding"
  %l9 = alloca %"compiler/generic:Binding"
  %l15 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t5 = call %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %s0, i64 %a3, i64 %a4)
  store %"compiler/generic:Binding" %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load %"compiler/generic:Binding", ptr %l9
  store %"compiler/generic:Binding" %t6, ptr %l6
  %t16 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnifyArg(ptr %v0, ptr %s0, ptr %a0, i32 %a1, i32 %a2, ptr %l6, i1 false, i1 %a5)
  store i32 %t16, ptr %l15
  %t17 = icmp ne i32 %t16, 0
  br i1 %t17, label %bb3, label %ok.18, !prof !99
ok.18:
  br label %bb2
bb2:
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l6 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t7 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emeetTyped(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
  store i32 %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load i32, ptr %l6, !tbaa !23
  store i32 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMember(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l13 = alloca { i64, ptr }
  %l18 = alloca i1
  %l19 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l30 = alloca i32
  %l33 = alloca i1
  %l42 = alloca { i64, ptr }
  %l49 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMembers(ptr %v0, ptr %v0, ptr %t1, i32 %t2)
  store { i64, ptr } %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  %t7 = load i32, ptr %l2, !tbaa !23
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 14
  %t15 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_H78bce58497ad959bdf5762dbe74df8e1(ptr %v0, ptr %t11, i32 %t7)
  store i1 %t15, ptr %l18
  br label %bb2
bb2:
  %t16 = load i1, ptr %l18, !tbaa !21
  br i1 %t16, label %bb3, label %bb4
bb3:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/generic:Program", ptr %t17, i32 0, i32 14
  %t20 = load i32, ptr %l2, !tbaa !23
  %t23 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_Hfa58d934e2b7178f7b33766972648144(ptr %v0, ptr %v0, ptr %t19, i32 %t20)
  %t24 = extractvalue { i32, ptr } %t23, 1
  %t25 = extractvalue { i32, ptr } %t23, 0
  store i32 %t25, ptr %l24
  %t26 = icmp ne i32 %t25, 0
  br i1 %t26, label %bb6, label %ok.27, !prof !99
ok.27:
  store ptr %t24, ptr %l23
  br label %bb5
bb4:
  br label %bb15
bb5:
  %t28 = load ptr, ptr %l23, !tbaa !29
  store ptr %t28, ptr %l19, !tbaa !29
  br label %bb9
bb6:
  br label %bb7
bb7:
  call void @__olang_ert_req_clear()
  %t29 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t29, ptr %l25
  br label %bb8
bb8:
  %t30 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l25
  %t31 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 72, i64 8)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t30, ptr %t31
  store ptr %t31, ptr %l19, !tbaa !29
  br label %bb9
bb9:
  %t33 = load ptr, ptr %l19, !tbaa !29
  store ptr %t33, ptr %l5, !tbaa !29
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/generic:Program", ptr %t34, i32 0, i32 2
  %t37 = load i32, ptr %l1, !tbaa !23
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t36, i32 %t37)
  store i32 %t40, ptr %l30
  br label %bb10
bb10:
  %t41 = load i32, ptr %l30, !tbaa !23
  %t42 = load ptr, ptr %l5, !tbaa !29
  %t46 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_Hb3133f486435530b533aaf49461c92b5(ptr %v0, ptr %t42, i32 %t41)
  store i1 %t46, ptr %l33
  br label %bb11
bb11:
  %t47 = load i1, ptr %l33, !tbaa !21
  br i1 %t47, label %bb12, label %bb13
bb12:
  store i1 true, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t49 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t49, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t51, 0
  store i64 %t53, ptr %l9, !tbaa !24
  br label %bb16
bb16:
  %t55 = load i64, ptr %l8, !tbaa !24
  %t56 = load i64, ptr %l9, !tbaa !24
  %t59 = icmp slt i64 %t55, %t56
  %t61 = xor i1 %t59, true
  br i1 %t61, label %bb17, label %bb18
bb17:
  br label %bb25
bb18:
  br label %bb19
bb19:
  %t63 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t63, ptr %l42, !tbaa !27
  %t64 = load i64, ptr %l8, !tbaa !24
  %t66 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = getelementptr i32, ptr %t67, i64 %t64
  %t69 = load i32, ptr %t68, !tbaa !33
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/generic:Program", ptr %t71, i32 0, i32 2
  %t74 = load i32, ptr %l1, !tbaa !23
  %t79 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t73, i32 %t74, i32 %t69)
  store i1 %t79, ptr %l49
  br label %bb20
bb20:
  %t80 = load i1, ptr %l49, !tbaa !21
  br i1 %t80, label %bb21, label %bb22
bb21:
  store i1 true, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t82 = load i64, ptr %l8, !tbaa !24
  %t84 = add i64 %t82, 1
  store i64 %t84, ptr %l8, !tbaa !24
  br label %bb16
bb25:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l17 = alloca i32
  %l20 = alloca i32
  %l24 = alloca i32
  %l29 = alloca i32
  %l35 = alloca i32
  %l39 = alloca i64
  %l42 = alloca i64
  %l62 = alloca i64
  %l66 = alloca i64
  %l68 = alloca ptr
  %l72 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l73 = alloca i64
  %l74 = alloca i32
  %l83 = alloca i1
  %l86 = alloca i1
  %l91 = alloca i64
  %l95 = alloca i64
  %l96 = alloca i32
  %l101 = alloca i32
  %l105 = alloca i1
  %l108 = alloca i1
  %l112 = alloca ptr
  %l116 = alloca i32
  %l117 = alloca i32
  %l121 = alloca i1
  %l122 = alloca ptr
  %l126 = alloca i32
  %l127 = alloca i1
  %l133 = alloca i32
  %s3 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eallFns(ptr %v0, ptr %t1)
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/generic:Program", ptr %t3, i32 0, i32 2
  %t6 = load i32, ptr %l1, !tbaa !23
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t5, i32 %t6)
  store i32 %t9, ptr %l17
  br label %bb2
bb2:
  %t10 = load i32, ptr %l17, !range !{i32 0, i32 33}
  %t12 = trunc i64 20 to i32
  %t13 = icmp eq i32 %t10, %t12
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  %t18 = load i32, ptr %l1, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l24
  br label %bb5
bb4:
  %t22 = load i32, ptr %l1, !tbaa !23
  store i32 %t22, ptr %l20, !tbaa !23
  br label %bb6
bb5:
  %t24 = load i32, ptr %l24, !tbaa !23
  store i32 %t24, ptr %l20, !tbaa !23
  br label %bb6
bb6:
  %t25 = load i32, ptr %l20, !tbaa !23
  store i32 %t25, ptr %l3, !tbaa !23
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  %t29 = load i32, ptr %l3, !tbaa !23
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFuncTag(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t32, ptr %l29
  br label %bb7
bb7:
  %t33 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t34 = load i32, ptr %l29, !tbaa !23
  %t36 = icmp ne i32 %t34, %t33
  br i1 %t36, label %bb8, label %bb9
bb8:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/generic:Program", ptr %t38, i32 0, i32 2
  %t41 = load i32, ptr %l3, !tbaa !23
  %t44 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFuncTag(ptr %v0, ptr %t40, i32 %t41)
  store i32 %t44, ptr %l35
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t45 = load i32, ptr %l35, !tbaa !23
  store i32 %t45, ptr %l3, !tbaa !23
  br label %bb11
bb11:
  store i64 0, ptr %l4, !tbaa !24
  store i64 16, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t46 = load i64, ptr %l5, !tbaa !24
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = icmp sgt i64 %t46, %t47
  br i1 %t50, label %bb12, label %bb13
bb12:
  %t52 = load i64, ptr %l6, !tbaa !24
  %t54 = icmp sgt i64 %t52, 0
  br i1 %t54, label %bb14, label %bb15
bb13:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb17
bb14:
  %t56 = load i64, ptr %l5, !tbaa !24
  %t57 = load i64, ptr %l4, !tbaa !24
  %t60 = sub i64 %t56, %t57
  %t61 = load i64, ptr %l6, !tbaa !24
  %t64 = add i64 %t60, %t61
  %t66 = sub i64 %t64, 1
  %t67 = load i64, ptr %l6, !tbaa !24
  %t70 = sdiv i64 %t66, %t67
  store i64 %t70, ptr %l42, !tbaa !24
  br label %bb16
bb15:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb16
bb16:
  %t72 = load i64, ptr %l42, !tbaa !24
  store i64 %t72, ptr %l39, !tbaa !24
  br label %bb17
bb17:
  %t73 = load i64, ptr %l39, !tbaa !24
  store i64 %t73, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s3
  %t74 = load i64, ptr %l8, !tbaa !24
  %t75 = load i64, ptr %l7, !tbaa !24
  %t78 = icmp slt i64 %t74, %t75
  %t80 = xor i1 %t78, true
  br i1 %t80, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s3)
  br label %bb75
bb20:
  br label %bb21
bb21:
  %t82 = load i64, ptr %l4, !tbaa !24
  %t83 = load i64, ptr %l8, !tbaa !24
  %t84 = load i64, ptr %l6, !tbaa !24
  %t87 = mul i64 %t83, %t84
  %t90 = add i64 %t82, %t87
  store i64 %t90, ptr %l9, !tbaa !24
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load i32, ptr %l3, !tbaa !23
  %t96 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etypeKey(ptr %v0, ptr %t92, i32 %t93)
  store i64 %t96, ptr %l62
  br label %bb22
bb22:
  %t97 = load i64, ptr %l62, !tbaa !24
  store i64 %t97, ptr %l10, !tbaa !24
  %t98 = load i64, ptr %l10, !tbaa !24
  %t100 = icmp slt i64 %t98, 0
  br i1 %t100, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s3)
  store i64 -1, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/generic:Program", ptr %t103, i32 0, i32 27
  store ptr %t105, ptr %l68, !tbaa !29
  %t106 = load i64, ptr %l10, !tbaa !24
  %t109 = sext i32 %a2 to i64
  %t112 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s3, i64 %t106, i64 %t109)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t112, ptr %l72
  br label %bb26
bb26:
  %t113 = load ptr, ptr %l68, !tbaa !29
  %t114 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l72
  %t115 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t113, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t114)
  %t116 = extractvalue { i32, i64 } %t115, 1
  %t117 = extractvalue { i32, i64 } %t115, 0
  store i32 %t117, ptr %l74
  %t118 = icmp ne i32 %t117, 0
  br i1 %t118, label %bb28, label %ok.119, !prof !99
ok.119:
  store i64 %t116, ptr %l73
  br label %bb27
bb27:
  %t120 = load i64, ptr %l73, !tbaa !24
  store i64 %t120, ptr %l66, !tbaa !24
  br label %bb30
bb28:
  br label %bb29
bb29:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l66, !tbaa !24
  br label %bb30
bb30:
  %t121 = load i64, ptr %l66, !tbaa !24
  store i64 %t121, ptr %l11, !tbaa !24
  %t122 = load i64, ptr %l11, !tbaa !24
  %t124 = icmp sge i64 %t122, 0
  br i1 %t124, label %bb31, label %bb32
bb31:
  store i64 -1, ptr %l12, !tbaa !24
  br label %bb33
bb32:
  br label %bb54
bb33:
  %t126 = load i64, ptr %l11, !tbaa !24
  %t128 = icmp sge i64 %t126, 0
  %t130 = xor i1 %t128, true
  br i1 %t130, label %bb34, label %bb35
bb34:
  br label %bb53
bb35:
  br label %bb36
bb36:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load i64, ptr %l11, !tbaa !24
  %t134 = load i32, ptr %l3, !tbaa !23
  %t138 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2erecvApplies(ptr %v0, ptr %t132, i64 %t133, i32 %t134)
  store i1 %t138, ptr %l83
  br label %bb37
bb37:
  %t139 = load i1, ptr %l83, !tbaa !21
  br i1 %t139, label %bb38, label %bb39
bb38:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load i64, ptr %l11, !tbaa !24
  %t144 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2erecvExact(ptr %v0, ptr %t140, i64 %t141)
  store i1 %t144, ptr %l86
  br label %bb40
bb39:
  br label %bb47
bb40:
  %t145 = load i1, ptr %l86, !tbaa !21
  br i1 %t145, label %bb41, label %bb42
bb41:
  %t146 = load i64, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  store i64 %t146, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  %t148 = load i64, ptr %l12, !tbaa !24
  %t150 = icmp slt i64 %t148, 0
  br i1 %t150, label %bb44, label %bb45
bb44:
  %t152 = load i64, ptr %l11, !tbaa !24
  store i64 %t152, ptr %l12, !tbaa !24
  br label %bb46
bb45:
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/generic:Program", ptr %t154, i32 0, i32 28
  %t157 = load i64, ptr %l11, !tbaa !24
  %t160 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t156, i64 %t157)
  %t161 = extractvalue { i32, i64 } %t160, 1
  %t162 = extractvalue { i32, i64 } %t160, 0
  store i32 %t162, ptr %l96
  %t163 = icmp ne i32 %t162, 0
  br i1 %t163, label %bb49, label %ok.164, !prof !99
ok.164:
  store i64 %t161, ptr %l95
  br label %bb48
bb48:
  %t165 = load i64, ptr %l95, !tbaa !24
  store i64 %t165, ptr %l91, !tbaa !24
  br label %bb51
bb49:
  br label %bb50
bb50:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l91, !tbaa !24
  br label %bb51
bb51:
  %t166 = load i64, ptr %l91, !tbaa !24
  store i64 %t166, ptr %l11, !tbaa !24
  br label %bb52
bb52:
  br label %bb33
bb53:
  %t167 = load i64, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  store i64 %t167, ptr %rv
  br label %ret
bb54:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/generic:Program", ptr %t169, i32 0, i32 2
  %t172 = load i32, ptr %l3, !tbaa !23
  %t175 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t171, i32 %t172)
  store i32 %t175, ptr %l101
  br label %bb55
bb55:
  %t176 = load i32, ptr %l101, !range !{i32 0, i32 33}
  %t178 = trunc i64 18 to i32
  %t179 = icmp eq i32 %t176, %t178
  %t181 = xor i1 %t179, true
  br i1 %t181, label %bb56, label %bb57
bb56:
  store i1 true, ptr %l105, !tbaa !21
  br label %bb59
bb57:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = load i32, ptr %l3, !tbaa !23
  %t187 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t183, i32 %t184)
  store i1 %t187, ptr %l108
  br label %bb58
bb58:
  %t188 = load i1, ptr %l108, !tbaa !21
  %t189 = xor i1 %t188, true
  store i1 %t189, ptr %l105, !tbaa !21
  br label %bb59
bb59:
  %t191 = load i1, ptr %l105, !tbaa !21
  br i1 %t191, label %bb60, label %bb61
bb60:
  call void @__olang_scope_close(ptr %s3)
  store i64 -1, ptr %rv
  br label %ret
bb61:
  br label %bb62
bb62:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/generic:Program", ptr %t193, i32 0, i32 2
  store ptr %t195, ptr %l112, !tbaa !29
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/generic:Program", ptr %t196, i32 0, i32 2
  %t199 = load i32, ptr %l3, !tbaa !23
  %t202 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t198, i32 %t199)
  store i32 %t202, ptr %l116
  br label %bb63
bb63:
  %t203 = load ptr, ptr %l112, !tbaa !29
  %t204 = load i32, ptr %l116, !tbaa !23
  %t205 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t203, i32 %t204)
  store i32 %t205, ptr %l117
  br label %bb64
bb64:
  %t206 = load i32, ptr %l117, !range !{i32 0, i32 6}
  %t208 = trunc i64 4 to i32
  %t209 = icmp eq i32 %t206, %t208
  %t211 = xor i1 %t209, true
  br i1 %t211, label %bb65, label %bb66
bb65:
  store i1 true, ptr %l121, !tbaa !21
  br label %bb69
bb66:
  %t213 = load ptr, ptr %l0, !tbaa !29
  store ptr %t213, ptr %l122, !tbaa !29
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/generic:Program", ptr %t214, i32 0, i32 2
  %t217 = load i32, ptr %l3, !tbaa !23
  %t220 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t216, i32 %t217)
  store i32 %t220, ptr %l126
  br label %bb67
bb67:
  %t221 = load ptr, ptr %l122, !tbaa !29
  %t222 = load i32, ptr %l126, !tbaa !23
  %t223 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eextends(ptr %v0, ptr %t221, i32 %t222)
  store i1 %t223, ptr %l127
  br label %bb68
bb68:
  %t224 = load i1, ptr %l127, !tbaa !21
  %t225 = xor i1 %t224, true
  store i1 %t225, ptr %l121, !tbaa !21
  br label %bb69
bb69:
  %t227 = load i1, ptr %l121, !tbaa !21
  br i1 %t227, label %bb70, label %bb71
bb70:
  call void @__olang_scope_close(ptr %s3)
  store i64 -1, ptr %rv
  br label %ret
bb71:
  br label %bb72
bb72:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"compiler/generic:Program", ptr %t229, i32 0, i32 2
  %t232 = load i32, ptr %l3, !tbaa !23
  %t235 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t231, i32 %t232)
  store i32 %t235, ptr %l133
  br label %bb73
bb73:
  %t236 = load i32, ptr %l133, !tbaa !23
  store i32 %t236, ptr %l3, !tbaa !23
  call void @__olang_scope_close(ptr %s3)
  br label %bb74
bb74:
  %t237 = load i64, ptr %l8, !tbaa !24
  %t239 = add i64 %t237, 1
  store i64 %t239, ptr %l8, !tbaa !24
  br label %bb18
bb75:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodSig(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca %"compiler/generic:Binding"
  %l7 = alloca { i64, ptr }
  %l10 = alloca i32
  %l12 = alloca i64
  %l15 = alloca i64
  %l21 = alloca %"compiler/generic:Binding"
  %l23 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l38 = alloca i32
  %l40 = alloca ptr
  %l41 = alloca i32
  %l42 = alloca i64
  %l46 = alloca i32
  %l47 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t1, i64 %t2)
  store i32 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i32, ptr %l10, !tbaa !23
  store i32 %t6, ptr %l3, !tbaa !23
  %t7 = load i64, ptr %l1, !tbaa !24
  %t9 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t7)
  store i64 %t9, ptr %l12
  br label %bb2
bb2:
  %t10 = load i64, ptr %l12, !tbaa !24
  store i64 %t10, ptr %l4, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i64, ptr %l4, !tbaa !24
  %t15 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t11, i64 %t12)
  store i64 %t15, ptr %l15
  br label %bb3
bb3:
  %t16 = load i64, ptr %l15, !tbaa !24
  store i64 %t16, ptr %l5, !tbaa !24
  %t17 = load i64, ptr %l5, !tbaa !24
  %t19 = icmp eq i64 %t17, 0
  br i1 %t19, label %bb4, label %bb5
bb4:
  %t21 = load i32, ptr %l3, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t21, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t23 = load i64, ptr %l4, !tbaa !24
  %t24 = load i64, ptr %l5, !tbaa !24
  %t27 = call %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %s0, i64 %t23, i64 %t24)
  store %"compiler/generic:Binding" %t27, ptr %l21
  br label %bb7
bb7:
  %t28 = load %"compiler/generic:Binding", ptr %l21
  store %"compiler/generic:Binding" %t28, ptr %l6
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/generic:Program", ptr %t29, i32 0, i32 2
  store ptr %t31, ptr %l23, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  %t35 = load i32, ptr %l3, !tbaa !23
  %t38 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t38, ptr %l27
  br label %bb8
bb8:
  %t39 = load ptr, ptr %l23, !tbaa !29
  %t40 = load i32, ptr %l27, !tbaa !23
  %t41 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t39, i32 %t40)
  store { i64, ptr } %t41, ptr %l28
  br label %bb9
bb9:
  %t42 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t42, ptr %l7, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t47 = icmp eq i64 %t45, 0
  br i1 %t47, label %bb10, label %bb11
bb10:
  %t49 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t49, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t52, ptr %l34, !tbaa !27
  %t53 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr i32, ptr %t54, i64 0
  %t56 = load i32, ptr %t55, !tbaa !33
  %t62 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnifyArg(ptr %v0, ptr %s0, ptr %t51, i32 %t56, i32 %a2, ptr %l6, i1 false, i1 true)
  store i32 %t62, ptr %l38
  %t63 = icmp ne i32 %t62, 0
  br i1 %t63, label %bb14, label %ok.64, !prof !99
ok.64:
  br label %bb13
bb13:
  br label %bb16
bb14:
  br label %bb15
bb15:
  call void @__olang_ert_req_clear()
  %t65 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t65, ptr %rv
  br label %ret
bb16:
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l40, !tbaa !29
  %t68 = load i32, ptr %l3, !tbaa !23
  store i32 %t68, ptr %l41, !tbaa !23
  %t69 = load i64, ptr %l4, !tbaa !24
  store i64 %t69, ptr %l42, !tbaa !24
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/generic:Program", ptr %t70, i32 0, i32 2
  %t73 = getelementptr %"compiler/generic:Binding", ptr %l6, i32 0, i32 2
  %t74 = load { i64, ptr }, ptr %t73, !tbaa !27
  %t77 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t72, { i64, ptr } %t74)
  store i32 %t77, ptr %l46
  br label %bb17
bb17:
  %t78 = load ptr, ptr %l40, !tbaa !29
  %t79 = load i32, ptr %l41, !tbaa !23
  %t80 = load i64, ptr %l42, !tbaa !24
  %t81 = load i32, ptr %l46, !tbaa !23
  %t82 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %t78, i32 %t79, i64 %t80, i32 %t81)
  store i32 %t82, ptr %l47
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s0)
  %t83 = load i32, ptr %l47, !tbaa !23
  store i32 %t83, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eModuleFns(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"compiler/generic:fnRow"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l44 = alloca %"compiler/generic:fnRow"
  %l48 = alloca i1
  %l50 = alloca i1
  %l55 = alloca i1
  %l63 = alloca i1
  %l67 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l70 = alloca i1
  %l77 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l79 = alloca i64
  %l80 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2efnsIn(ptr %v0, ptr %t1, i64 %t2)
  br label %bb1
bb1:
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l13
  br label %bb2
bb2:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 21
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eLen_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l16
  br label %bb3
bb3:
  %t12 = load i64, ptr %l16, !tbaa !24
  store i64 %t12, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t13 = load i64, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t19 = load i64, ptr %l6, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb9
bb6:
  %t23 = load i64, ptr %l5, !tbaa !24
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l6, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l6, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l23, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb8
bb8:
  %t39 = load i64, ptr %l23, !tbaa !24
  store i64 %t39, ptr %l20, !tbaa !24
  br label %bb9
bb9:
  %t40 = load i64, ptr %l20, !tbaa !24
  store i64 %t40, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t41 = load i64, ptr %l8, !tbaa !24
  %t42 = load i64, ptr %l7, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb37
bb12:
  br label %bb13
bb13:
  %t49 = load i64, ptr %l4, !tbaa !24
  %t50 = load i64, ptr %l8, !tbaa !24
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = mul i64 %t50, %t51
  %t57 = add i64 %t49, %t54
  store i64 %t57, ptr %l9, !tbaa !24
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 21
  %t62 = load i64, ptr %l9, !tbaa !24
  %t65 = call %"compiler/generic:fnRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eAt_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %v0, ptr %t61, i64 %t62)
  store %"compiler/generic:fnRow" %t65, ptr %l44
  br label %bb14
bb14:
  %t66 = load %"compiler/generic:fnRow", ptr %l44
  store %"compiler/generic:fnRow" %t66, ptr %l10
  %t67 = getelementptr %"compiler/generic:fnRow", ptr %l10, i32 0, i32 0
  %t68 = load i64, ptr %t67, !tbaa !24
  %t69 = load i64, ptr %l1, !tbaa !24
  %t72 = icmp ne i64 %t68, %t69
  br i1 %t72, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb17
bb16:
  %t74 = getelementptr %"compiler/generic:fnRow", ptr %l10, i32 0, i32 2
  %t75 = load i1, ptr %t74, !tbaa !21
  store i1 %t75, ptr %l48, !tbaa !21
  br label %bb17
bb17:
  %t77 = load i1, ptr %l48, !tbaa !21
  br i1 %t77, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb20
bb19:
  %t78 = getelementptr %"compiler/generic:fnRow", ptr %l10, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = getelementptr %"compiler/ast:Func", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = icmp eq ptr %t82, null
  %t86 = xor i1 %t84, true
  store i1 %t86, ptr %l50, !tbaa !21
  br label %bb20
bb20:
  %t88 = load i1, ptr %l50, !tbaa !21
  br i1 %t88, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l55, !tbaa !21
  br label %bb23
bb22:
  %t89 = getelementptr %"compiler/generic:fnRow", ptr %l10, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t92 = getelementptr %"compiler/ast:Func", ptr %t90, i32 0, i32 5
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t93, 0
  %t97 = icmp sgt i64 %t95, 0
  store i1 %t97, ptr %l55, !tbaa !21
  br label %bb23
bb23:
  %t99 = load i1, ptr %l55, !tbaa !21
  br i1 %t99, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s2)
  br label %bb36
bb25:
  br label %bb26
bb26:
  %t100 = load i64, ptr %l1, !tbaa !24
  %t104 = icmp ne i64 %t100, %a2
  br i1 %t104, label %bb27, label %bb28
bb27:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/generic:fnRow", ptr %l10, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t110 = getelementptr %"compiler/ast:Func", ptr %t108, i32 0, i32 2
  %t111 = load i32, ptr %t110, !tbaa !23
  %t114 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %s2, ptr %t106, i32 %t111)
  store { i64, ptr } %t114, ptr %l67
  br label %bb29
bb28:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb31
bb29:
  %t115 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t115, ptr %l68, !tbaa !27
  %t116 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = getelementptr i8, ptr %t117, i64 0
  %t119 = load i8, ptr %t118, !tbaa !32
  %t121 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t119)
  store i1 %t121, ptr %l70
  br label %bb30
bb30:
  %t122 = load i1, ptr %l70, !tbaa !21
  %t123 = xor i1 %t122, true
  store i1 %t123, ptr %l63, !tbaa !21
  br label %bb31
bb31:
  %t125 = load i1, ptr %l63, !tbaa !21
  br i1 %t125, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s2)
  br label %bb36
bb33:
  br label %bb34
bb34:
  %t126 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t126)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s2)
  br label %bb36
bb36:
  %t129 = load i64, ptr %l8, !tbaa !24
  %t131 = add i64 %t129, 1
  store i64 %t131, ptr %l8, !tbaa !24
  br label %bb10
bb37:
  %t134 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %s0, ptr %l3)
  store { i64, ptr } %t134, ptr %l77
  br label %bb38
bb38:
  %t135 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t135, ptr %l78, !tbaa !27
  %t136 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t136, 0
  store i64 %t137, ptr %l79, !tbaa !24
  %t138 = load i64, ptr %l79, !tbaa !24
  %t139 = mul i64 %t138, 8
  %t140 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t139)
  %t141 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t140, 1
  store { i64, ptr } %t142, ptr %l80, !tbaa !27
  %t143 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !27
  %t145 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = load i64, ptr %l79, !tbaa !24
  %t148 = mul i64 %t147, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t144, ptr %t146, i64 %t148, i1 false)
  %t149 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t149, ptr %l78, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t150 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t150, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l6 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t7 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epreludeType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
  store i32 %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load i32, ptr %l6, !tbaa !23
  store i32 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eReflName(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l3
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l3
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ereflName(ptr %v0, ptr %s0, ptr %a0, ptr %l2, i32 %a1)
  br label %bb2
bb2:
  %t9 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t9, ptr %l8
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t10 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t10, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca ptr
  %l11 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca ptr
  %l21 = alloca i1
  %l35 = alloca i32
  %l36 = alloca ptr
  %l37 = alloca i1
  %l48 = alloca i32
  %l49 = alloca ptr
  %l50 = alloca i1
  %l58 = alloca i32
  %l59 = alloca ptr
  %l60 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca ptr
  %l71 = alloca %"compiler/source:Span"
  %l76 = alloca i32
  %l78 = alloca i32
  %l79 = alloca ptr
  %l80 = alloca i1
  %l87 = alloca ptr
  %l91 = alloca i32
  %l93 = alloca i32
  %l94 = alloca ptr
  %l95 = alloca i1
  %l101 = alloca ptr
  %l106 = alloca i32
  %l107 = alloca i32
  %l108 = alloca ptr
  %l109 = alloca i1
  %l113 = alloca ptr
  %l114 = alloca i1
  %l120 = alloca ptr
  %l122 = alloca ptr
  %l127 = alloca i32
  %l128 = alloca i32
  %l130 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t5, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l2, !tbaa !29
  store ptr %t7, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t8 = load ptr, ptr %l20, !tbaa !29
  %t9 = icmp ne ptr %t8, null
  br i1 %t9, label %bb4, label %bb5
bb4:
  %t11 = load ptr, ptr %l20, !tbaa !29
  %t12 = load i64, ptr %t11, !range !{i64 0, i64 8}
  %t14 = icmp eq i64 %t12, 0
  store i1 %t14, ptr %l21, !tbaa !21
  br label %bb5
bb5:
  %t15 = load i1, ptr %l21, !tbaa !21
  br i1 %t15, label %bb6, label %bb7
bb6:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t18, i32 0, i32 0
  %t20 = load %"compiler/source:Span", ptr %t19
  store %"compiler/source:Span" %t20, ptr %l3
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = getelementptr { i64, [5 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t24, i32 0, i32 1
  %t26 = load { i64, ptr }, ptr %t25
  store { i64, ptr } %t26, ptr %l4, !tbaa !27
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t30, i32 0, i32 2
  %t32 = load { i64, ptr }, ptr %t31
  store { i64, ptr } %t32, ptr %l5, !tbaa !27
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t36 = load %"compiler/source:Span", ptr %l3
  %t37 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t44 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2enamed(ptr %v0, ptr %v1, ptr %v2, ptr %v2, ptr %t34, ptr %t35, %"compiler/source:Span" %t36, { i64, ptr } %t37, { i64, ptr } %t38)
  store i32 %t44, ptr %l35
  br label %bb9
bb9:
  %t45 = load i32, ptr %l35, !tbaa !23
  store i32 %t45, ptr %l19, !tbaa !23
  br label %bb64
bb10:
  %t46 = load ptr, ptr %l2, !tbaa !29
  store ptr %t46, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t47 = load ptr, ptr %l36, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb11, label %bb12
bb11:
  %t50 = load ptr, ptr %l36, !tbaa !29
  %t51 = load i64, ptr %t50, !range !{i64 0, i64 8}
  %t53 = icmp eq i64 %t51, 1
  store i1 %t53, ptr %l37, !tbaa !21
  br label %bb12
bb12:
  %t54 = load i1, ptr %l37, !tbaa !21
  br i1 %t54, label %bb13, label %bb14
bb13:
  %t55 = load ptr, ptr %l2, !tbaa !29
  %t57 = getelementptr { i64, [5 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", ptr }, ptr %t57, i32 0, i32 0
  %t59 = load %"compiler/source:Span", ptr %t58
  store %"compiler/source:Span" %t59, ptr %l6
  %t61 = load ptr, ptr %l2, !tbaa !29
  %t63 = getelementptr { i64, [5 x i64] }, ptr %t61, i32 0, i32 1
  %t64 = getelementptr { %"compiler/source:Span", ptr }, ptr %t63, i32 0, i32 1
  %t65 = load ptr, ptr %t64
  store ptr %t65, ptr %l7, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t69 = load %"compiler/source:Span", ptr %l6
  %t70 = load ptr, ptr %l7, !tbaa !29
  %t75 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2efuncType(ptr %v0, ptr %v1, ptr %v2, ptr %t67, ptr %t68, %"compiler/source:Span" %t69, ptr %t70)
  store i32 %t75, ptr %l48
  br label %bb16
bb16:
  %t76 = load i32, ptr %l48, !tbaa !23
  store i32 %t76, ptr %l19, !tbaa !23
  br label %bb64
bb17:
  %t77 = load ptr, ptr %l2, !tbaa !29
  store ptr %t77, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t78 = load ptr, ptr %l49, !tbaa !29
  %t79 = icmp ne ptr %t78, null
  br i1 %t79, label %bb18, label %bb19
bb18:
  %t81 = load ptr, ptr %l49, !tbaa !29
  %t82 = load i64, ptr %t81, !range !{i64 0, i64 8}
  %t84 = icmp eq i64 %t82, 2
  store i1 %t84, ptr %l50, !tbaa !21
  br label %bb19
bb19:
  %t85 = load i1, ptr %l50, !tbaa !21
  br i1 %t85, label %bb20, label %bb21
bb20:
  %t86 = load ptr, ptr %l2, !tbaa !29
  %t88 = getelementptr { i64, [5 x i64] }, ptr %t86, i32 0, i32 1
  %t89 = getelementptr { %"compiler/source:Span", ptr }, ptr %t88, i32 0, i32 1
  %t90 = load ptr, ptr %t89
  store ptr %t90, ptr %l8, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load ptr, ptr %l1, !tbaa !29
  %t94 = load ptr, ptr %l8, !tbaa !29
  %t98 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eshape(ptr %v0, ptr %v1, ptr %v2, ptr %t92, ptr %t93, ptr %t94)
  store i32 %t98, ptr %l58
  br label %bb23
bb23:
  %t99 = load i32, ptr %l58, !tbaa !23
  store i32 %t99, ptr %l19, !tbaa !23
  br label %bb64
bb24:
  %t100 = load ptr, ptr %l2, !tbaa !29
  store ptr %t100, ptr %l59, !tbaa !29
  store i1 false, ptr %l60, !tbaa !21
  %t101 = load ptr, ptr %l59, !tbaa !29
  %t102 = icmp ne ptr %t101, null
  br i1 %t102, label %bb25, label %bb26
bb25:
  %t104 = load ptr, ptr %l59, !tbaa !29
  %t105 = load i64, ptr %t104, !range !{i64 0, i64 8}
  %t107 = icmp eq i64 %t105, 3
  store i1 %t107, ptr %l60, !tbaa !21
  br label %bb26
bb26:
  %t108 = load i1, ptr %l60, !tbaa !21
  br i1 %t108, label %bb27, label %bb28
bb27:
  %t109 = load ptr, ptr %l2, !tbaa !29
  %t111 = getelementptr { i64, [5 x i64] }, ptr %t109, i32 0, i32 1
  %t112 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t111, i32 0, i32 0
  %t113 = load %"compiler/source:Span", ptr %t112
  store %"compiler/source:Span" %t113, ptr %l9
  %t115 = load ptr, ptr %l2, !tbaa !29
  %t117 = getelementptr { i64, [5 x i64] }, ptr %t115, i32 0, i32 1
  %t118 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t117, i32 0, i32 1
  %t119 = load ptr, ptr %t118
  store ptr %t119, ptr %l10, !tbaa !29
  %t121 = load ptr, ptr %l2, !tbaa !29
  %t123 = getelementptr { i64, [5 x i64] }, ptr %t121, i32 0, i32 1
  %t124 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t123, i32 0, i32 2
  %t125 = load i1, ptr %t124
  store i1 %t125, ptr %l11, !tbaa !21
  br label %bb29
bb28:
  br label %bb32
bb29:
  %t127 = load ptr, ptr %l0, !tbaa !29
  store ptr %t127, ptr %l69, !tbaa !29
  %t128 = load ptr, ptr %l1, !tbaa !29
  store ptr %t128, ptr %l70, !tbaa !29
  %t129 = load %"compiler/source:Span", ptr %l9
  store %"compiler/source:Span" %t129, ptr %l71
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t131 = load ptr, ptr %l1, !tbaa !29
  %t132 = load ptr, ptr %l10, !tbaa !29
  %t137 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %t130, ptr %t131, ptr %t132)
  store i32 %t137, ptr %l76
  br label %bb30
bb30:
  %t138 = load i1, ptr %l11, !tbaa !21
  %t139 = load ptr, ptr %l69, !tbaa !29
  %t140 = load ptr, ptr %l70, !tbaa !29
  %t141 = load %"compiler/source:Span", ptr %l71
  %t142 = load i32, ptr %l76, !tbaa !23
  %t144 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2erefType(ptr %v0, ptr %v1, ptr %t139, ptr %t140, %"compiler/source:Span" %t141, i32 %t142, i1 %t138)
  store i32 %t144, ptr %l78
  br label %bb31
bb31:
  %t145 = load i32, ptr %l78, !tbaa !23
  store i32 %t145, ptr %l19, !tbaa !23
  br label %bb64
bb32:
  %t146 = load ptr, ptr %l2, !tbaa !29
  store ptr %t146, ptr %l79, !tbaa !29
  store i1 false, ptr %l80, !tbaa !21
  %t147 = load ptr, ptr %l79, !tbaa !29
  %t148 = icmp ne ptr %t147, null
  br i1 %t148, label %bb33, label %bb34
bb33:
  %t150 = load ptr, ptr %l79, !tbaa !29
  %t151 = load i64, ptr %t150, !range !{i64 0, i64 8}
  %t153 = icmp eq i64 %t151, 4
  store i1 %t153, ptr %l80, !tbaa !21
  br label %bb34
bb34:
  %t154 = load i1, ptr %l80, !tbaa !21
  br i1 %t154, label %bb35, label %bb36
bb35:
  %t155 = load ptr, ptr %l2, !tbaa !29
  %t157 = getelementptr { i64, [5 x i64] }, ptr %t155, i32 0, i32 1
  %t158 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t157, i32 0, i32 1
  %t159 = load ptr, ptr %t158
  store ptr %t159, ptr %l12, !tbaa !29
  %t161 = load ptr, ptr %l2, !tbaa !29
  %t163 = getelementptr { i64, [5 x i64] }, ptr %t161, i32 0, i32 1
  %t164 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t163, i32 0, i32 2
  %t165 = load i1, ptr %t164
  store i1 %t165, ptr %l13, !tbaa !21
  br label %bb37
bb36:
  br label %bb40
bb37:
  %t167 = load ptr, ptr %l0, !tbaa !29
  store ptr %t167, ptr %l87, !tbaa !29
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t169 = load ptr, ptr %l1, !tbaa !29
  %t170 = load ptr, ptr %l12, !tbaa !29
  %t174 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %t168, ptr %t169, ptr %t170)
  store i32 %t174, ptr %l91
  br label %bb38
bb38:
  %t175 = load i1, ptr %l13, !tbaa !21
  %t176 = load ptr, ptr %l87, !tbaa !29
  %t177 = load i32, ptr %l91, !tbaa !23
  %t179 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eperm(ptr %v0, ptr %t176, i32 %t177, i1 %t175)
  store i32 %t179, ptr %l93
  br label %bb39
bb39:
  %t180 = load i32, ptr %l93, !tbaa !23
  store i32 %t180, ptr %l19, !tbaa !23
  br label %bb64
bb40:
  %t181 = load ptr, ptr %l2, !tbaa !29
  store ptr %t181, ptr %l94, !tbaa !29
  store i1 false, ptr %l95, !tbaa !21
  %t182 = load ptr, ptr %l94, !tbaa !29
  %t183 = icmp ne ptr %t182, null
  br i1 %t183, label %bb41, label %bb42
bb41:
  %t185 = load ptr, ptr %l94, !tbaa !29
  %t186 = load i64, ptr %t185, !range !{i64 0, i64 8}
  %t188 = icmp eq i64 %t186, 5
  store i1 %t188, ptr %l95, !tbaa !21
  br label %bb42
bb42:
  %t189 = load i1, ptr %l95, !tbaa !21
  br i1 %t189, label %bb43, label %bb44
bb43:
  %t190 = load ptr, ptr %l2, !tbaa !29
  %t192 = getelementptr { i64, [5 x i64] }, ptr %t190, i32 0, i32 1
  %t193 = getelementptr { %"compiler/source:Span", ptr }, ptr %t192, i32 0, i32 1
  %t194 = load ptr, ptr %t193
  store ptr %t194, ptr %l14, !tbaa !29
  br label %bb45
bb44:
  br label %bb48
bb45:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/generic:Program", ptr %t196, i32 0, i32 2
  store ptr %t198, ptr %l101, !tbaa !29
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = load ptr, ptr %l1, !tbaa !29
  %t201 = load ptr, ptr %l14, !tbaa !29
  %t206 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %t199, ptr %t200, ptr %t201)
  store i32 %t206, ptr %l106
  br label %bb46
bb46:
  %t207 = load ptr, ptr %l101, !tbaa !29
  %t208 = load i32, ptr %l106, !tbaa !23
  %t209 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAny(ptr %v0, ptr %t207, i32 %t208)
  store i32 %t209, ptr %l107
  br label %bb47
bb47:
  %t210 = load i32, ptr %l107, !tbaa !23
  store i32 %t210, ptr %l19, !tbaa !23
  br label %bb64
bb48:
  %t211 = load ptr, ptr %l2, !tbaa !29
  store ptr %t211, ptr %l108, !tbaa !29
  store i1 false, ptr %l109, !tbaa !21
  %t212 = load ptr, ptr %l108, !tbaa !29
  %t213 = icmp ne ptr %t212, null
  br i1 %t213, label %bb49, label %bb50
bb49:
  %t215 = load ptr, ptr %l108, !tbaa !29
  %t216 = load i64, ptr %t215, !range !{i64 0, i64 8}
  %t218 = icmp eq i64 %t216, 6
  store i1 %t218, ptr %l109, !tbaa !21
  br label %bb50
bb50:
  %t219 = load i1, ptr %l109, !tbaa !21
  br i1 %t219, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  %t220 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t220, ptr %l19, !tbaa !23
  br label %bb64
bb54:
  %t222 = load ptr, ptr %l2, !tbaa !29
  store ptr %t222, ptr %l113, !tbaa !29
  store i1 false, ptr %l114, !tbaa !21
  %t223 = load ptr, ptr %l113, !tbaa !29
  %t224 = icmp ne ptr %t223, null
  br i1 %t224, label %bb55, label %bb56
bb55:
  %t226 = load ptr, ptr %l113, !tbaa !29
  %t227 = load i64, ptr %t226, !range !{i64 0, i64 8}
  %t229 = icmp eq i64 %t227, 7
  store i1 %t229, ptr %l114, !tbaa !21
  br label %bb56
bb56:
  %t230 = load i1, ptr %l114, !tbaa !21
  br i1 %t230, label %bb57, label %bb58
bb57:
  %t231 = load ptr, ptr %l2, !tbaa !29
  %t233 = getelementptr { i64, [5 x i64] }, ptr %t231, i32 0, i32 1
  %t234 = getelementptr { %"compiler/source:Span", ptr }, ptr %t233, i32 0, i32 1
  %t235 = load ptr, ptr %t234
  store ptr %t235, ptr %l15, !tbaa !29
  br label %bb59
bb58:
  br label %bb63
bb59:
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t239 = getelementptr %"compiler/generic:Program", ptr %t237, i32 0, i32 2
  store ptr %t239, ptr %l120, !tbaa !29
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t242 = getelementptr %"compiler/generic:Program", ptr %t240, i32 0, i32 2
  store ptr %t242, ptr %l122, !tbaa !29
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t244 = load ptr, ptr %l1, !tbaa !29
  %t245 = load ptr, ptr %l15, !tbaa !29
  %t250 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %t243, ptr %t244, ptr %t245)
  store i32 %t250, ptr %l127
  br label %bb60
bb60:
  %t251 = load ptr, ptr %l122, !tbaa !29
  %t252 = load i32, ptr %l127, !tbaa !23
  %t253 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t251, i32 %t252, i32 0)
  store i32 %t253, ptr %l128
  br label %bb61
bb61:
  %t254 = load i64, ptr @G_2ecompiler_2ftypes_2eSpread, !tbaa !24
  %t255 = load ptr, ptr %l120, !tbaa !29
  %t256 = load i32, ptr %l128, !tbaa !23
  %t258 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t255, i32 %t256, i64 %t254)
  store i32 %t258, ptr %l130
  br label %bb62
bb62:
  %t259 = load i32, ptr %l130, !tbaa !23
  store i32 %t259, ptr %l19, !tbaa !23
  br label %bb64
bb63:
  call void @__olang_check_failed(ptr @olang_loc_e146017c26ab6c4e_50202815c87e77c2)
  unreachable
bb64:
  %t260 = load i32, ptr %l19, !tbaa !23
  store i32 %t260, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l11 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  store ptr %t3, ptr %l11, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l15
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l11, !tbaa !29
  %t12 = load i32, ptr %l15, !tbaa !23
  %t13 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t11, i32 %t12)
  store { i64, ptr } %t13, ptr %l16
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t14, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  store i64 %t17, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = icmp slt i64 %t19, %t20
  %t25 = xor i1 %t23, true
  br i1 %t25, label %bb4, label %bb5
bb4:
  br label %bb9
bb5:
  br label %bb6
bb6:
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t27, ptr %l23, !tbaa !27
  %t28 = load i64, ptr %l3, !tbaa !24
  %t30 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr i32, ptr %t31, i64 %t28
  %t33 = load i32, ptr %t32, !tbaa !33
  %t35 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ebodiesOf(ptr %v0, ptr %t35, i32 %t33)
  br label %bb7
bb7:
  br label %bb8
bb8:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t41 = add i64 %t39, 1
  store i64 %t41, ptr %l3, !tbaa !24
  br label %bb3
bb9:
  store %olang.scope zeroinitializer, ptr %s4
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/generic:Program", ptr %t43, i32 0, i32 2
  %t46 = load i32, ptr %l1, !tbaa !23
  %t49 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s4, ptr %t45, i32 %t46)
  store { i64, ptr } %t49, ptr %l33
  br label %bb10
bb10:
  %t50 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t50, 0
  %t52 = extractvalue { i64, ptr } %t50, 1
  %t53 = mul i64 %t51, 4
  %t54 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t53)
  call void @llvm.memcpy.p0.p0.i64(ptr %t54, ptr %t52, i64 %t53, i1 false)
  %t55 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t54, 1
  store { i64, ptr } %t56, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t58 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t58, 0
  store i64 %t60, ptr %l8, !tbaa !24
  br label %bb11
bb11:
  %t62 = load i64, ptr %l7, !tbaa !24
  %t63 = load i64, ptr %l8, !tbaa !24
  %t66 = icmp slt i64 %t62, %t63
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb12, label %bb13
bb12:
  br label %bb17
bb13:
  br label %bb14
bb14:
  %t70 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t70, ptr %l41, !tbaa !27
  %t71 = load i64, ptr %l7, !tbaa !24
  %t73 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr i32, ptr %t74, i64 %t71
  %t76 = load i32, ptr %t75, !tbaa !33
  %t78 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ebodiesOf(ptr %v0, ptr %t78, i32 %t76)
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t82 = load i64, ptr %l7, !tbaa !24
  %t84 = add i64 %t82, 1
  store i64 %t84, ptr %l7, !tbaa !24
  br label %bb11
bb17:
  call void @__olang_scope_close(ptr %s4)
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 2
  %t89 = load i32, ptr %l1, !tbaa !23
  %t92 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %t88, i32 %t89)
  store { i64, ptr } %t92, ptr %l51
  br label %bb18
bb18:
  %t93 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t93, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eStorageOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l5 = alloca i32
  %l8 = alloca i1
  %l12 = alloca i32
  %l16 = alloca i1
  %l20 = alloca i32
  %l23 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l29 = alloca i32
  %l33 = alloca i32
  %l37 = alloca i1
  %l41 = alloca i32
  %l44 = alloca ptr
  %l48 = alloca i32
  %l52 = alloca i32
  %l53 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb4
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/generic:Program", ptr %t5, i32 0, i32 2
  %t8 = load i32, ptr %l2, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l12
  br label %bb3
bb3:
  %t12 = load i32, ptr %l12, !range !{i32 0, i32 33}
  %t14 = trunc i64 19 to i32
  %t15 = icmp eq i32 %t12, %t14
  %t17 = xor i1 %t15, true
  store i1 %t17, ptr %l8, !tbaa !21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l8, !tbaa !21
  br i1 %t19, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb8
bb6:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/generic:Program", ptr %t20, i32 0, i32 2
  %t23 = load i32, ptr %l2, !tbaa !23
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t22, i32 %t23)
  store i32 %t26, ptr %l20
  br label %bb7
bb7:
  %t27 = load i32, ptr %l20, !tbaa !23
  %t28 = icmp ne i32 %t27, 0
  store i1 %t28, ptr %l16, !tbaa !21
  br label %bb8
bb8:
  %t30 = load i1, ptr %l16, !tbaa !21
  br i1 %t30, label %bb9, label %bb10
bb9:
  %t31 = load i32, ptr %l2, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t31, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t33 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t33, ptr %l23
  br label %bb12
bb12:
  %t34 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l23
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t34, ptr %l4
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = load ptr, ptr %l3, !tbaa !29
  %t43 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInfer(ptr %v0, ptr %v1, ptr %s0, ptr %v2, ptr %t35, ptr %a1, ptr %l4, ptr %t37)
  store i32 %t43, ptr %l29
  br label %bb13
bb13:
  %t44 = load i32, ptr %l29, !tbaa !23
  store i32 %t44, ptr %l5, !tbaa !23
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/generic:Program", ptr %t45, i32 0, i32 2
  %t48 = load i32, ptr %l5, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t47, i32 %t48)
  store i32 %t51, ptr %l33
  br label %bb14
bb14:
  %t52 = load i32, ptr %l33, !range !{i32 0, i32 33}
  %t54 = trunc i64 19 to i32
  %t55 = icmp eq i32 %t52, %t54
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb18
bb16:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 2
  %t62 = load i32, ptr %l5, !tbaa !23
  %t65 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t61, i32 %t62)
  store i32 %t65, ptr %l41
  br label %bb17
bb17:
  %t66 = load i32, ptr %l41, !tbaa !23
  %t67 = icmp eq i32 %t66, 0
  store i1 %t67, ptr %l37, !tbaa !21
  br label %bb18
bb18:
  %t69 = load i1, ptr %l37, !tbaa !21
  br i1 %t69, label %bb19, label %bb20
bb19:
  %t70 = load i32, ptr %l2, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t70, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t72 = load ptr, ptr %l0, !tbaa !29
  store ptr %t72, ptr %l44, !tbaa !29
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/generic:Program", ptr %t73, i32 0, i32 2
  %t76 = load i32, ptr %l5, !tbaa !23
  %t79 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t75, i32 %t76)
  store i32 %t79, ptr %l48
  br label %bb22
bb22:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/generic:Program", ptr %t80, i32 0, i32 2
  %t83 = load i32, ptr %l2, !tbaa !23
  %t86 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t82, i32 %t83)
  store i32 %t86, ptr %l52
  br label %bb23
bb23:
  %t87 = load ptr, ptr %l44, !tbaa !29
  %t88 = load i32, ptr %l48, !tbaa !23
  %t89 = load i32, ptr %l52, !tbaa !23
  %t90 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLengthsOnly(ptr %v0, ptr %t87, i32 %t88, i32 %t89)
  store i1 %t90, ptr %l53
  br label %bb24
bb24:
  %t91 = load i1, ptr %l53, !tbaa !21
  %t92 = xor i1 %t91, true
  br i1 %t92, label %bb25, label %bb26
bb25:
  %t94 = load i32, ptr %l2, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t94, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t96 = load i32, ptr %l5, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t96, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnendedDrop(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l3 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l7 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l3
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l3
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l2
  %t8 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunended(ptr %v0, ptr %s0, ptr %a0, i32 %a1, ptr %l2, i64 0)
  store i32 %t8, ptr %l7
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t9 = load i32, ptr %l7, !tbaa !23
  store i32 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnify(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3, i1 %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i32
  %l7 = alloca i32
  %l11 = alloca i1
  %l18 = alloca i32
  %l21 = alloca i1
  %l25 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l34 = alloca i64
  %l38 = alloca i32
  %l45 = alloca i32
  %l48 = alloca i1
  %l49 = alloca i32
  %l51 = alloca i32
  %l53 = alloca i1
  %l55 = alloca i1
  %l59 = alloca i32
  %l63 = alloca i32
  %l65 = alloca i1
  %l68 = alloca i1
  %l69 = alloca i1
  %l71 = alloca ptr
  %l75 = alloca i32
  %l76 = alloca i32
  %l79 = alloca ptr
  %l80 = alloca i32
  %l84 = alloca i32
  %l88 = alloca i32
  %l90 = alloca i32
  %l92 = alloca i32
  %l94 = alloca i1
  %l103 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i1 %a4, ptr %l4
  store i1 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb3
bb2:
  %t7 = load i32, ptr %l2, !tbaa !23
  %t8 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t11 = icmp eq i32 %t7, %t8
  store i1 %t11, ptr %l11, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l11, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  store i32 0, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 2
  %t17 = load i32, ptr %l1, !tbaa !23
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t16, i32 %t17)
  store i32 %t20, ptr %l18
  br label %bb7
bb7:
  %t21 = load i32, ptr %l18, !range !{i32 0, i32 33}
  store i32 %t21, ptr %l6
  %t22 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t24 = trunc i64 25 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb8, label %bb9
bb8:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Program", ptr %t27, i32 0, i32 2
  %t30 = load i32, ptr %l1, !tbaa !23
  %t33 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t29, i32 %t30)
  store i64 %t33, ptr %l25
  br label %bb10
bb9:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb11
bb10:
  %t34 = load ptr, ptr %l3, !tbaa !29
  %t36 = getelementptr %"compiler/generic:Binding", ptr %t34, i32 0, i32 0
  %t37 = load i64, ptr %t36, !tbaa !24
  %t38 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp eq i64 %t38, %t37
  store i1 %t40, ptr %l21, !tbaa !21
  br label %bb11
bb11:
  %t42 = load i1, ptr %l21, !tbaa !21
  br i1 %t42, label %bb12, label %bb13
bb12:
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l29, !tbaa !29
  %t44 = load ptr, ptr %l3, !tbaa !29
  store ptr %t44, ptr %l30, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/generic:Program", ptr %t45, i32 0, i32 2
  %t48 = load i32, ptr %l1, !tbaa !23
  %t51 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t47, i32 %t48)
  store i64 %t51, ptr %l34
  br label %bb14
bb13:
  br label %bb18
bb14:
  %t52 = load i32, ptr %l2, !tbaa !23
  %t53 = load i1, ptr %l4, !tbaa !21
  %t54 = load i1, ptr %l5, !tbaa !21
  %t55 = load ptr, ptr %l29, !tbaa !29
  %t56 = load ptr, ptr %l30, !tbaa !29
  %t57 = load i64, ptr %l34, !tbaa !24
  %t61 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ebind(ptr %v0, ptr %v1, ptr %t55, ptr %t56, i64 %t57, i32 %t52, i1 %t53, i1 %t54)
  store i32 %t61, ptr %l38
  %t62 = icmp ne i32 %t61, 0
  br i1 %t62, label %bb16, label %ok.63, !prof !99
ok.63:
  br label %bb15
bb15:
  br label %bb17
bb16:
  %t64 = load i32, ptr %l38, !tbaa !23
  %t65 = lshr i32 %t64, 16
  %t66 = and i32 %t64, 65535
  %t67 = icmp eq i32 %t65, 1
  %t68 = select i1 %t67, i32 1, i32 0
  %t69 = icmp eq i32 %t64, 0
  %t70 = shl i32 %t68, 16
  %t71 = or i32 %t70, %t66
  %t72 = select i1 %t69, i32 0, i32 %t71
  store i32 %t72, ptr %rv
  br label %ret
bb17:
  store i32 0, ptr %rv
  br label %ret
bb18:
  %t74 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t76 = trunc i64 27 to i32
  %t77 = icmp eq i32 %t74, %t76
  br i1 %t77, label %bb19, label %bb20
bb19:
  store i32 0, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/generic:Program", ptr %t79, i32 0, i32 2
  %t82 = load i32, ptr %l2, !tbaa !23
  %t85 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t81, i32 %t82)
  store i32 %t85, ptr %l45
  br label %bb22
bb22:
  %t86 = load i32, ptr %l45, !range !{i32 0, i32 33}
  store i32 %t86, ptr %l7
  %t87 = load i32, ptr %l7, !range !{i32 0, i32 33}
  %t89 = trunc i64 18 to i32
  %t90 = icmp eq i32 %t87, %t89
  br i1 %t90, label %bb23, label %bb24
bb23:
  %t92 = load i32, ptr %l6, !range !{i32 0, i32 33}
  store i32 %t92, ptr %l49
  %t93 = load i32, ptr %l7, !range !{i32 0, i32 33}
  store i32 %t93, ptr %l51
  %t96 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l49, ptr %l51)
  store i1 %t96, ptr %l53
  br label %bb25
bb24:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb31
bb25:
  %t97 = load i1, ptr %l53, !tbaa !21
  %t98 = xor i1 %t97, true
  br i1 %t98, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l55, !tbaa !21
  br label %bb30
bb27:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Program", ptr %t100, i32 0, i32 2
  %t103 = load i32, ptr %l1, !tbaa !23
  %t106 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t102, i32 %t103)
  store i32 %t106, ptr %l59
  br label %bb28
bb28:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/generic:Program", ptr %t107, i32 0, i32 2
  %t110 = load i32, ptr %l2, !tbaa !23
  %t113 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t109, i32 %t110)
  store i32 %t113, ptr %l63
  br label %bb29
bb29:
  %t114 = load i32, ptr %l59, !tbaa !23
  %t115 = load i32, ptr %l63, !tbaa !23
  %t116 = icmp ne i32 %t114, %t115
  store i1 %t116, ptr %l55, !tbaa !21
  br label %bb30
bb30:
  %t118 = load i1, ptr %l55, !tbaa !21
  store i1 %t118, ptr %l48, !tbaa !21
  br label %bb31
bb31:
  %t119 = load i1, ptr %l48, !tbaa !21
  br i1 %t119, label %bb32, label %bb33
bb32:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load i32, ptr %l2, !tbaa !23
  %t124 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t120, i32 %t121)
  store i1 %t124, ptr %l68
  br label %bb34
bb33:
  store i1 false, ptr %l65, !tbaa !21
  br label %bb35
bb34:
  %t125 = load i1, ptr %l68, !tbaa !21
  store i1 %t125, ptr %l65, !tbaa !21
  br label %bb35
bb35:
  %t126 = load i1, ptr %l65, !tbaa !21
  br i1 %t126, label %bb36, label %bb37
bb36:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/generic:Program", ptr %t127, i32 0, i32 2
  store ptr %t129, ptr %l71, !tbaa !29
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/generic:Program", ptr %t130, i32 0, i32 2
  %t133 = load i32, ptr %l2, !tbaa !23
  %t136 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t132, i32 %t133)
  store i32 %t136, ptr %l75
  br label %bb38
bb37:
  store i1 false, ptr %l69, !tbaa !21
  br label %bb40
bb38:
  %t137 = load ptr, ptr %l71, !tbaa !29
  %t138 = load i32, ptr %l75, !tbaa !23
  %t139 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t137, i32 %t138)
  store i32 %t139, ptr %l76
  br label %bb39
bb39:
  %t140 = load i32, ptr %l76, !range !{i32 0, i32 6}
  %t142 = trunc i64 4 to i32
  %t143 = icmp eq i32 %t140, %t142
  store i1 %t143, ptr %l69, !tbaa !21
  br label %bb40
bb40:
  %t145 = load i1, ptr %l69, !tbaa !21
  br i1 %t145, label %bb41, label %bb42
bb41:
  %t146 = load ptr, ptr %l0, !tbaa !29
  store ptr %t146, ptr %l79, !tbaa !29
  %t147 = load i32, ptr %l1, !tbaa !23
  store i32 %t147, ptr %l80, !tbaa !23
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/generic:Program", ptr %t148, i32 0, i32 2
  %t151 = load i32, ptr %l2, !tbaa !23
  %t154 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t150, i32 %t151)
  store i32 %t154, ptr %l84
  br label %bb43
bb42:
  br label %bb47
bb43:
  %t155 = load ptr, ptr %l3, !tbaa !29
  %t156 = load i1, ptr %l4, !tbaa !21
  %t157 = load i1, ptr %l5, !tbaa !21
  %t158 = load ptr, ptr %l79, !tbaa !29
  %t159 = load i32, ptr %l80, !tbaa !23
  %t160 = load i32, ptr %l84, !tbaa !23
  %t164 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnify(ptr %v0, ptr %v1, ptr %t158, i32 %t159, i32 %t160, ptr %t155, i1 %t156, i1 %t157)
  store i32 %t164, ptr %l88
  %t165 = icmp ne i32 %t164, 0
  br i1 %t165, label %bb45, label %ok.166, !prof !99
ok.166:
  br label %bb44
bb44:
  br label %bb46
bb45:
  %t167 = load i32, ptr %l88, !tbaa !23
  %t168 = lshr i32 %t167, 16
  %t169 = and i32 %t167, 65535
  %t170 = icmp eq i32 %t168, 1
  %t171 = select i1 %t170, i32 1, i32 0
  %t172 = icmp eq i32 %t167, 0
  %t173 = shl i32 %t171, 16
  %t174 = or i32 %t173, %t169
  %t175 = select i1 %t172, i32 0, i32 %t174
  store i32 %t175, ptr %rv
  br label %ret
bb46:
  store i32 0, ptr %rv
  br label %ret
bb47:
  %t177 = load i32, ptr %l6, !range !{i32 0, i32 33}
  store i32 %t177, ptr %l90
  %t178 = load i32, ptr %l7, !range !{i32 0, i32 33}
  store i32 %t178, ptr %l92
  %t181 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l90, ptr %l92)
  store i1 %t181, ptr %l94
  br label %bb48
bb48:
  %t182 = load i1, ptr %l94, !tbaa !21
  %t183 = xor i1 %t182, true
  br i1 %t183, label %bb49, label %bb50
bb49:
  store i32 65536, ptr %rv
  br label %ret
bb50:
  br label %bb51
bb51:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t188 = load i32, ptr %l1, !tbaa !23
  %t189 = load i32, ptr %l2, !tbaa !23
  %t190 = load ptr, ptr %l3, !tbaa !29
  %t191 = load i1, ptr %l5, !tbaa !21
  %t198 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunifyKind(ptr %v0, ptr %v1, ptr %t186, i32 %t187, i32 %t188, i32 %t189, ptr %t190, i1 %t191)
  store i32 %t198, ptr %l103
  %t199 = icmp ne i32 %t198, 0
  br i1 %t199, label %bb53, label %ok.200, !prof !99
ok.200:
  br label %bb52
bb52:
  br label %bb54
bb53:
  %t201 = load i32, ptr %l103, !tbaa !23
  %t202 = lshr i32 %t201, 16
  %t203 = and i32 %t201, 65535
  %t204 = icmp eq i32 %t202, 1
  %t205 = select i1 %t204, i32 1, i32 0
  %t206 = icmp eq i32 %t201, 0
  %t207 = shl i32 %t205, 16
  %t208 = or i32 %t207, %t203
  %t209 = select i1 %t206, i32 0, i32 %t208
  store i32 %t209, ptr %rv
  br label %ret
bb54:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnifyBound(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3) #0 {
entry:
  %l8 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t9 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunifyBound(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3, i64 0)
  store i64 %t9, ptr %l8
  br label %bb1
bb1:
  %t10 = load i64, ptr %l8, !tbaa !24
  store i64 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnknownConst(ptr %v0, ptr %a0) #0 {
entry:
  %l3 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/generic:Program", ptr %a0, i32 0, i32 2
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstExpr(ptr %v0, ptr %s0, ptr %t3, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d30, i32 0, i32 1) })
  store i32 %t5, ptr %l3
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t6 = load i32, ptr %l3, !tbaa !23
  store i32 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarArg(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i32
  %l9 = alloca i32
  %l13 = alloca i1
  %l14 = alloca i32
  %l15 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %l1, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eVar(ptr %v0, ptr %t3, i64 %t4, i64 %t5, i64 %t6)
  store i32 %t11, ptr %l9
  br label %bb1
bb1:
  %t12 = load i32, ptr %l9, !tbaa !23
  store i32 %t12, ptr %l3, !tbaa !23
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i64, ptr %l1, !tbaa !24
  %t15 = load i64, ptr %l2, !tbaa !24
  %t19 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrVarAt(ptr %v0, ptr %t13, i64 %t14, i64 %t15)
  store i1 %t19, ptr %l13
  br label %bb2
bb2:
  %t20 = load i1, ptr %l13, !tbaa !21
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l15, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 2
  %t25 = load i32, ptr %l3, !tbaa !23
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %t24, i32 %t25)
  store i32 %t28, ptr %l19
  br label %bb5
bb4:
  %t29 = load i32, ptr %l3, !tbaa !23
  store i32 %t29, ptr %l14, !tbaa !23
  br label %bb7
bb5:
  %t31 = load ptr, ptr %l15, !tbaa !29
  %t32 = load i32, ptr %l19, !tbaa !23
  %t33 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrSetOf(ptr %v0, ptr %t31, i32 %t32)
  store i32 %t33, ptr %l20
  br label %bb6
bb6:
  %t34 = load i32, ptr %l20, !tbaa !23
  store i32 %t34, ptr %l14, !tbaa !23
  br label %bb7
bb7:
  %t35 = load i32, ptr %l14, !tbaa !23
  store i32 %t35, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eaddFns(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l21 = alloca ptr
  %l22 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l48 = alloca ptr
  %l49 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca i64
  %l56 = alloca ptr
  %l58 = alloca ptr
  %l59 = alloca i64
  %l65 = alloca %"compiler/source:Span"
  %l67 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a2, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb44
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t15, ptr %l18, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l6, !tbaa !29
  %t23 = load ptr, ptr %l6, !tbaa !29
  store ptr %t23, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t24 = load ptr, ptr %l21, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t27 = load ptr, ptr %l21, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 11}
  %t30 = icmp eq i64 %t28, 0
  store i1 %t30, ptr %l22, !tbaa !21
  br label %bb6
bb6:
  %t31 = load i1, ptr %l22, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t32 = load ptr, ptr %l6, !tbaa !29
  %t34 = getelementptr { i64, [6 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { ptr }, ptr %t34, i32 0, i32 0
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l7, !tbaa !29
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i64, ptr %l1, !tbaa !24
  %t40 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eaddFn(ptr %v0, ptr %v1, ptr %t38, i64 %t39, ptr %t40, i1 false)
  br label %bb10
bb10:
  br label %bb42
bb11:
  %t44 = load ptr, ptr %l6, !tbaa !29
  store ptr %t44, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t45 = load ptr, ptr %l30, !tbaa !29
  %t46 = icmp ne ptr %t45, null
  br i1 %t46, label %bb12, label %bb13
bb12:
  %t48 = load ptr, ptr %l30, !tbaa !29
  %t49 = load i64, ptr %t48, !range !{i64 0, i64 11}
  %t51 = icmp eq i64 %t49, 1
  store i1 %t51, ptr %l31, !tbaa !21
  br label %bb13
bb13:
  %t52 = load i1, ptr %l31, !tbaa !21
  br i1 %t52, label %bb14, label %bb15
bb14:
  %t53 = load ptr, ptr %l6, !tbaa !29
  %t55 = getelementptr { i64, [6 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { ptr }, ptr %t55, i32 0, i32 0
  %t57 = load ptr, ptr %t56
  store ptr %t57, ptr %l8, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load i64, ptr %l1, !tbaa !24
  %t61 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eaddFn(ptr %v0, ptr %v1, ptr %t59, i64 %t60, ptr %t61, i1 true)
  br label %bb17
bb17:
  br label %bb42
bb18:
  %t65 = load ptr, ptr %l6, !tbaa !29
  store ptr %t65, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t66 = load ptr, ptr %l39, !tbaa !29
  %t67 = icmp ne ptr %t66, null
  br i1 %t67, label %bb19, label %bb20
bb19:
  %t69 = load ptr, ptr %l39, !tbaa !29
  %t70 = load i64, ptr %t69, !range !{i64 0, i64 11}
  %t72 = icmp eq i64 %t70, 10
  store i1 %t72, ptr %l40, !tbaa !21
  br label %bb20
bb20:
  %t73 = load i1, ptr %l40, !tbaa !21
  br i1 %t73, label %bb21, label %bb22
bb21:
  %t74 = load ptr, ptr %l6, !tbaa !29
  %t76 = getelementptr { i64, [6 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } }, ptr %t76, i32 0, i32 2
  %t78 = load { i64, ptr }, ptr %t77
  store { i64, ptr } %t78, ptr %l9, !tbaa !27
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load i64, ptr %l1, !tbaa !24
  %t82 = load { i64, ptr }, ptr %l9, !tbaa !27
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eaddFns(ptr %v0, ptr %v1, ptr %t80, i64 %t81, { i64, ptr } %t82)
  br label %bb24
bb24:
  br label %bb42
bb25:
  %t86 = load ptr, ptr %l6, !tbaa !29
  store ptr %t86, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t87 = load ptr, ptr %l48, !tbaa !29
  %t88 = icmp ne ptr %t87, null
  br i1 %t88, label %bb26, label %bb27
bb26:
  %t90 = load ptr, ptr %l48, !tbaa !29
  %t91 = load i64, ptr %t90, !range !{i64 0, i64 11}
  %t93 = icmp eq i64 %t91, 7
  store i1 %t93, ptr %l49, !tbaa !21
  br label %bb27
bb27:
  %t94 = load i1, ptr %l49, !tbaa !21
  br i1 %t94, label %bb28, label %bb29
bb28:
  %t95 = load ptr, ptr %l6, !tbaa !29
  %t97 = getelementptr { i64, [6 x i64] }, ptr %t95, i32 0, i32 1
  %t98 = getelementptr { %"compiler/source:Span", ptr }, ptr %t97, i32 0, i32 1
  %t99 = load ptr, ptr %t98
  store ptr %t99, ptr %l10, !tbaa !29
  br label %bb30
bb29:
  br label %bb37
bb30:
  %t101 = load ptr, ptr %l0, !tbaa !29
  store ptr %t101, ptr %l54, !tbaa !29
  %t102 = load i64, ptr %l1, !tbaa !24
  store i64 %t102, ptr %l55, !tbaa !24
  %t103 = load ptr, ptr %l10, !tbaa !29
  store ptr %t103, ptr %l56, !tbaa !29
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/generic:Program", ptr %t104, i32 0, i32 0
  %t107 = load ptr, ptr %t106, !tbaa !29
  store ptr %t107, ptr %l58, !tbaa !29
  %t108 = load i64, ptr %l1, !tbaa !24
  store i64 %t108, ptr %l59, !tbaa !24
  %t109 = load ptr, ptr %l10, !tbaa !29
  %t111 = getelementptr %"compiler/ast:TopIf", ptr %t109, i32 0, i32 0
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t114 = icmp eq ptr %t112, null
  br i1 %t114, label %bb31, label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_4e2b009ec27e80b_3f74010bfbf746f)
  unreachable
bb32:
  br label %bb33
bb33:
  %t116 = load ptr, ptr %l10, !tbaa !29
  %t118 = getelementptr %"compiler/ast:TopIf", ptr %t116, i32 0, i32 0
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t121 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t119)
  store %"compiler/source:Span" %t121, ptr %l65
  br label %bb34
bb34:
  %t122 = getelementptr %"compiler/source:Span", ptr %l65, i32 0, i32 0
  %t123 = load i32, ptr %t122, !tbaa !23
  %t124 = load ptr, ptr %l58, !tbaa !29
  %t125 = load i64, ptr %l59, !tbaa !24
  %t127 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eChosen(ptr %v0, ptr %t124, i64 %t125, i32 %t123)
  store i64 %t127, ptr %l67
  br label %bb35
bb35:
  %t128 = load ptr, ptr %l54, !tbaa !29
  %t129 = load i64, ptr %l55, !tbaa !24
  %t130 = load ptr, ptr %l56, !tbaa !29
  %t131 = load i64, ptr %l67, !tbaa !24
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eaddFnsIf(ptr %v0, ptr %v1, ptr %t128, i64 %t129, ptr %t130, i64 %t131, i64 0)
  br label %bb36
bb36:
  br label %bb42
bb37:
  br i1 true, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_8b73386467b8fdb3_4742e8850cea3c57)
  unreachable
bb42:
  br label %bb43
bb43:
  %t132 = load i64, ptr %l4, !tbaa !24
  %t134 = add i64 %t132, 1
  store i64 %t134, ptr %l4, !tbaa !24
  br label %bb1
bb44:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eallFns(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l11 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/load:Loader", ptr %t4, i32 0, i32 10
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l11
  br label %bb1
bb1:
  %t9 = load i64, ptr %l11, !tbaa !24
  store i64 %t9, ptr %l1, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 24
  %t13 = load i64, ptr %t12, !tbaa !24
  %t14 = load i64, ptr %l1, !tbaa !24
  %t17 = icmp eq i64 %t13, %t14
  br i1 %t17, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  store i64 0, ptr %l2, !tbaa !24
  %t19 = load i64, ptr %l1, !tbaa !24
  store i64 %t19, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t21 = load i64, ptr %l3, !tbaa !24
  %t22 = load i64, ptr %l2, !tbaa !24
  %t25 = icmp sgt i64 %t21, %t22
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t27 = load i64, ptr %l4, !tbaa !24
  %t29 = icmp sgt i64 %t27, 0
  br i1 %t29, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb10
bb7:
  %t31 = load i64, ptr %l3, !tbaa !24
  %t32 = load i64, ptr %l2, !tbaa !24
  %t35 = sub i64 %t31, %t32
  %t36 = load i64, ptr %l4, !tbaa !24
  %t39 = add i64 %t35, %t36
  %t41 = sub i64 %t39, 1
  %t42 = load i64, ptr %l4, !tbaa !24
  %t45 = sdiv i64 %t41, %t42
  store i64 %t45, ptr %l23, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb9
bb9:
  %t47 = load i64, ptr %l23, !tbaa !24
  store i64 %t47, ptr %l20, !tbaa !24
  br label %bb10
bb10:
  %t48 = load i64, ptr %l20, !tbaa !24
  store i64 %t48, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb11
bb11:
  %t49 = load i64, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l5, !tbaa !24
  %t53 = icmp slt i64 %t49, %t50
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb12, label %bb13
bb12:
  br label %bb17
bb13:
  br label %bb14
bb14:
  %t57 = load i64, ptr %l2, !tbaa !24
  %t58 = load i64, ptr %l6, !tbaa !24
  %t59 = load i64, ptr %l4, !tbaa !24
  %t62 = mul i64 %t58, %t59
  %t65 = add i64 %t57, %t62
  %t67 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2efnsIn(ptr %v0, ptr %t67, i64 %t65)
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t71 = load i64, ptr %l6, !tbaa !24
  %t73 = add i64 %t71, 1
  store i64 %t73, ptr %l6, !tbaa !24
  br label %bb11
bb17:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i64, ptr %l1, !tbaa !24
  %t79 = getelementptr %"compiler/generic:Program", ptr %t75, i32 0, i32 24
  store i64 %t76, ptr %t79, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ebind(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i32 %a3, i1 %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i1
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i64
  %l11 = alloca i64
  %l15 = alloca i32
  %l19 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l28 = alloca i1
  %l32 = alloca i32
  %l36 = alloca i32
  %l41 = alloca i32
  %l45 = alloca i32
  %l48 = alloca i32
  %l53 = alloca i32
  %l57 = alloca i1
  %l61 = alloca i32
  %l64 = alloca i1
  %l67 = alloca i1
  %l68 = alloca i1
  %l70 = alloca ptr
  %l74 = alloca i32
  %l75 = alloca i32
  %l78 = alloca i1
  %l82 = alloca i1
  %l87 = alloca i32
  %l89 = alloca { i64, ptr }
  %l95 = alloca i1
  %l97 = alloca { i64, ptr }
  %l100 = alloca i1
  %l104 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %l118 = alloca i1
  %l123 = alloca i1
  %l126 = alloca { i64, ptr }
  %l129 = alloca i1
  %l133 = alloca i1
  %l134 = alloca i1
  %l138 = alloca i1
  %l139 = alloca i1
  %l143 = alloca i1
  %l145 = alloca { i64, ptr }
  %l151 = alloca i32
  %l154 = alloca i1
  %l158 = alloca i32
  %l162 = alloca i1
  %l164 = alloca ptr
  %l168 = alloca i32
  %l169 = alloca i32
  %l175 = alloca i32
  %l178 = alloca i32
  %l180 = alloca ptr
  %l184 = alloca i32
  %l185 = alloca i32
  %l190 = alloca i32
  %l193 = alloca i1
  %l197 = alloca i32
  %l200 = alloca i1
  %l202 = alloca ptr
  %l206 = alloca i32
  %l210 = alloca i32
  %l211 = alloca i1
  %l212 = alloca i1
  %l214 = alloca { i64, ptr }
  %l221 = alloca i32
  %l223 = alloca i1
  %l227 = alloca i32
  %l231 = alloca i32
  %l234 = alloca { i64, ptr }
  %l235 = alloca i64
  %l237 = alloca ptr
  %l241 = alloca i32
  %l242 = alloca i32
  %l244 = alloca ptr
  %l247 = alloca i32
  %l248 = alloca i1
  %l249 = alloca i1
  %l251 = alloca ptr
  %l254 = alloca i32
  %l255 = alloca i1
  %l259 = alloca i1
  %l263 = alloca i1
  %l264 = alloca i1
  %l266 = alloca { i64, ptr }
  %l271 = alloca { i64, ptr }
  %l278 = alloca i32
  %l281 = alloca i1
  %l285 = alloca i32
  %l288 = alloca i1
  %l292 = alloca i32
  %l296 = alloca i32
  %l301 = alloca i64
  %l305 = alloca i64
  %l307 = alloca { i64, ptr }
  %l312 = alloca { i64, ptr }
  %l313 = alloca i64
  %l315 = alloca ptr
  %l319 = alloca i32
  %l331 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i32 %a3, ptr %l3
  store i1 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l3, !tbaa !23
  %t7 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t7, ptr %l15
  br label %bb1
bb1:
  %t8 = load i32, ptr %l15, !range !{i32 0, i32 33}
  %t10 = trunc i64 30 to i32
  %t11 = icmp eq i32 %t8, %t10
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Binding", ptr %t13, i32 0, i32 2
  %t16 = load { i64, ptr }, ptr %t15, !tbaa !27
  store { i64, ptr } %t16, ptr %l19, !tbaa !27
  %t17 = load i64, ptr %l2, !tbaa !24
  %t19 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr i32, ptr %t20, i64 %t17
  %t22 = load i32, ptr %t21, !tbaa !33
  store i32 %t22, ptr %l6, !tbaa !23
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Binding", ptr %t24, i32 0, i32 2
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %l23, !tbaa !27
  %t28 = load i64, ptr %l2, !tbaa !24
  store i64 %t28, ptr %l24, !tbaa !24
  %t29 = load i32, ptr %l6, !tbaa !23
  %t30 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t33 = icmp eq i32 %t29, %t30
  br i1 %t33, label %bb4, label %bb5
bb3:
  br label %bb12
bb4:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb7
bb5:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 2
  %t38 = load i32, ptr %l6, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l32
  br label %bb6
bb6:
  %t42 = load i32, ptr %l32, !range !{i32 0, i32 33}
  %t44 = trunc i64 30 to i32
  %t45 = icmp eq i32 %t42, %t44
  %t47 = xor i1 %t45, true
  store i1 %t47, ptr %l28, !tbaa !21
  br label %bb7
bb7:
  %t49 = load i1, ptr %l28, !tbaa !21
  br i1 %t49, label %bb8, label %bb9
bb8:
  %t50 = load i32, ptr %l3, !tbaa !23
  store i32 %t50, ptr %l36, !tbaa !23
  br label %bb11
bb9:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i32, ptr %l6, !tbaa !23
  %t54 = load i32, ptr %l3, !tbaa !23
  %t58 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrSetUnion(ptr %v0, ptr %t52, i32 %t53, i32 %t54)
  store i32 %t58, ptr %l41
  br label %bb10
bb10:
  %t59 = load i32, ptr %l41, !tbaa !23
  store i32 %t59, ptr %l36, !tbaa !23
  br label %bb11
bb11:
  %t60 = load i32, ptr %l36, !tbaa !23
  %t61 = load i64, ptr %l24, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr i32, ptr %t63, i64 %t61
  store i32 %t60, ptr %t64, !tbaa !33
  store i32 0, ptr %rv
  br label %ret
bb12:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 2
  %t68 = load i32, ptr %l3, !tbaa !23
  %t71 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t67, i32 %t68)
  store i32 %t71, ptr %l45
  br label %bb13
bb13:
  %t72 = load i32, ptr %l45, !range !{i32 0, i32 33}
  %t74 = trunc i64 21 to i32
  %t75 = icmp eq i32 %t72, %t74
  br i1 %t75, label %bb14, label %bb15
bb14:
  %t77 = load i32, ptr %l3, !tbaa !23
  store i32 %t77, ptr %l48, !tbaa !23
  br label %bb17
bb15:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/generic:Program", ptr %t79, i32 0, i32 2
  %t82 = load i32, ptr %l3, !tbaa !23
  %t85 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t81, i32 %t82)
  store i32 %t85, ptr %l53
  br label %bb16
bb16:
  %t86 = load i32, ptr %l53, !tbaa !23
  store i32 %t86, ptr %l48, !tbaa !23
  br label %bb17
bb17:
  %t87 = load i32, ptr %l48, !tbaa !23
  store i32 %t87, ptr %l7, !tbaa !23
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/generic:Program", ptr %t88, i32 0, i32 4
  %t91 = load i64, ptr %t90, !tbaa !24
  %t93 = icmp eq i64 %t91, 0
  br i1 %t93, label %bb18, label %bb19
bb18:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/generic:Program", ptr %t95, i32 0, i32 2
  %t98 = load i32, ptr %l7, !tbaa !23
  %t101 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t97, i32 %t98)
  store i32 %t101, ptr %l61
  br label %bb20
bb19:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb21
bb20:
  %t102 = load i32, ptr %l61, !range !{i32 0, i32 33}
  %t104 = trunc i64 18 to i32
  %t105 = icmp eq i32 %t102, %t104
  store i1 %t105, ptr %l57, !tbaa !21
  br label %bb21
bb21:
  %t107 = load i1, ptr %l57, !tbaa !21
  br i1 %t107, label %bb22, label %bb23
bb22:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load i32, ptr %l7, !tbaa !23
  %t112 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t108, i32 %t109)
  store i1 %t112, ptr %l67
  br label %bb24
bb23:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb25
bb24:
  %t113 = load i1, ptr %l67, !tbaa !21
  store i1 %t113, ptr %l64, !tbaa !21
  br label %bb25
bb25:
  %t114 = load i1, ptr %l64, !tbaa !21
  br i1 %t114, label %bb26, label %bb27
bb26:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/generic:Program", ptr %t115, i32 0, i32 2
  store ptr %t117, ptr %l70, !tbaa !29
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/generic:Program", ptr %t118, i32 0, i32 2
  %t121 = load i32, ptr %l7, !tbaa !23
  %t124 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t120, i32 %t121)
  store i32 %t124, ptr %l74
  br label %bb28
bb27:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb30
bb28:
  %t125 = load ptr, ptr %l70, !tbaa !29
  %t126 = load i32, ptr %l74, !tbaa !23
  %t127 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t125, i32 %t126)
  store i32 %t127, ptr %l75
  br label %bb29
bb29:
  %t128 = load i32, ptr %l75, !range !{i32 0, i32 6}
  %t130 = trunc i64 0 to i32
  %t131 = icmp eq i32 %t128, %t130
  store i1 %t131, ptr %l68, !tbaa !21
  br label %bb30
bb30:
  %t133 = load i1, ptr %l68, !tbaa !21
  br i1 %t133, label %bb31, label %bb32
bb31:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/generic:Program", ptr %t134, i32 0, i32 2
  %t137 = load i32, ptr %l7, !tbaa !23
  %t140 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %t136, i32 %t137)
  store i1 %t140, ptr %l82
  br label %bb33
bb32:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb34
bb33:
  %t141 = load i1, ptr %l82, !tbaa !21
  store i1 %t141, ptr %l78, !tbaa !21
  br label %bb34
bb34:
  %t142 = load i1, ptr %l78, !tbaa !21
  br i1 %t142, label %bb35, label %bb36
bb35:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/generic:Program", ptr %t143, i32 0, i32 2
  %t146 = load i32, ptr %l7, !tbaa !23
  %t147 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t151 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t145, i32 %t146, i64 %t147)
  store i32 %t151, ptr %l87
  br label %bb37
bb36:
  br label %bb38
bb37:
  %t152 = load i32, ptr %l87, !tbaa !23
  store i32 %t152, ptr %l7, !tbaa !23
  br label %bb38
bb38:
  %t153 = load ptr, ptr %l1, !tbaa !29
  %t155 = getelementptr %"compiler/generic:Binding", ptr %t153, i32 0, i32 2
  %t156 = load { i64, ptr }, ptr %t155, !tbaa !27
  store { i64, ptr } %t156, ptr %l89, !tbaa !27
  %t157 = load i64, ptr %l2, !tbaa !24
  %t159 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = getelementptr i32, ptr %t160, i64 %t157
  %t162 = load i32, ptr %t161, !tbaa !33
  store i32 %t162, ptr %l8, !tbaa !23
  %t164 = load i32, ptr %l8, !tbaa !23
  %t165 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t168 = icmp eq i32 %t164, %t165
  br i1 %t168, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l95, !tbaa !21
  br label %bb44
bb40:
  %t170 = load ptr, ptr %l1, !tbaa !29
  %t172 = getelementptr %"compiler/generic:Binding", ptr %t170, i32 0, i32 3
  %t173 = load { i64, ptr }, ptr %t172, !tbaa !27
  store { i64, ptr } %t173, ptr %l97, !tbaa !27
  %t174 = load i64, ptr %l2, !tbaa !24
  %t176 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr i1, ptr %t177, i64 %t174
  %t179 = load i1, ptr %t178, !tbaa !31
  br i1 %t179, label %bb41, label %bb42
bb41:
  %t181 = load i1, ptr %l4, !tbaa !21
  %t183 = xor i1 %t181, true
  store i1 %t183, ptr %l100, !tbaa !21
  br label %bb43
bb42:
  store i1 false, ptr %l100, !tbaa !21
  br label %bb43
bb43:
  %t185 = load i1, ptr %l100, !tbaa !21
  store i1 %t185, ptr %l95, !tbaa !21
  br label %bb44
bb44:
  %t186 = load i1, ptr %l95, !tbaa !21
  br i1 %t186, label %bb45, label %bb46
bb45:
  %t187 = load ptr, ptr %l1, !tbaa !29
  %t189 = getelementptr %"compiler/generic:Binding", ptr %t187, i32 0, i32 2
  %t190 = load { i64, ptr }, ptr %t189, !tbaa !27
  store { i64, ptr } %t190, ptr %l104, !tbaa !27
  %t191 = load i64, ptr %l2, !tbaa !24
  %t192 = load i32, ptr %l7, !tbaa !23
  %t195 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !27
  %t197 = getelementptr i32, ptr %t196, i64 %t191
  store i32 %t192, ptr %t197, !tbaa !33
  %t198 = load ptr, ptr %l1, !tbaa !29
  %t200 = getelementptr %"compiler/generic:Binding", ptr %t198, i32 0, i32 3
  %t201 = load { i64, ptr }, ptr %t200, !tbaa !27
  store { i64, ptr } %t201, ptr %l108, !tbaa !27
  %t202 = load i64, ptr %l2, !tbaa !24
  %t203 = load i1, ptr %l4, !tbaa !21
  %t206 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t207 = load ptr, ptr %t206, !tbaa !27
  %t208 = getelementptr i1, ptr %t207, i64 %t202
  store i1 %t203, ptr %t208, !tbaa !31
  %t209 = load ptr, ptr %l1, !tbaa !29
  %t211 = getelementptr %"compiler/generic:Binding", ptr %t209, i32 0, i32 4
  %t212 = load { i64, ptr }, ptr %t211, !tbaa !27
  store { i64, ptr } %t212, ptr %l112, !tbaa !27
  %t213 = load i64, ptr %l2, !tbaa !24
  %t217 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t218 = load ptr, ptr %t217, !tbaa !27
  %t219 = getelementptr i1, ptr %t218, i64 %t213
  store i1 %a5, ptr %t219, !tbaa !31
  store i32 0, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  %t220 = load i32, ptr %l8, !tbaa !23
  %t221 = load i32, ptr %l7, !tbaa !23
  %t224 = icmp eq i32 %t220, %t221
  br i1 %t224, label %bb48, label %bb49
bb48:
  store i1 true, ptr %l118, !tbaa !21
  br label %bb51
bb49:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr %"compiler/generic:Program", ptr %t226, i32 0, i32 2
  %t229 = load i32, ptr %l8, !tbaa !23
  %t230 = load i32, ptr %l7, !tbaa !23
  %t234 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t228, i32 %t229, i32 %t230)
  store i1 %t234, ptr %l123
  br label %bb50
bb50:
  %t235 = load i1, ptr %l123, !tbaa !21
  store i1 %t235, ptr %l118, !tbaa !21
  br label %bb51
bb51:
  %t236 = load i1, ptr %l118, !tbaa !21
  br i1 %t236, label %bb52, label %bb53
bb52:
  store i32 0, ptr %rv
  br label %ret
bb53:
  br label %bb54
bb54:
  %t237 = load i1, ptr %l4, !tbaa !21
  br i1 %t237, label %bb55, label %bb56
bb55:
  %t239 = load ptr, ptr %l1, !tbaa !29
  %t241 = getelementptr %"compiler/generic:Binding", ptr %t239, i32 0, i32 3
  %t242 = load { i64, ptr }, ptr %t241, !tbaa !27
  store { i64, ptr } %t242, ptr %l126, !tbaa !27
  %t243 = load i64, ptr %l2, !tbaa !24
  %t245 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t246 = load ptr, ptr %t245, !tbaa !27
  %t247 = getelementptr i1, ptr %t246, i64 %t243
  %t248 = load i1, ptr %t247, !tbaa !31
  br i1 %t248, label %bb57, label %bb58
bb56:
  br label %bb72
bb57:
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t251 = load i32, ptr %l8, !tbaa !23
  %t252 = load i32, ptr %l7, !tbaa !23
  %t256 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFlows(ptr %v0, ptr %t250, i32 %t251, i32 %t252)
  store i1 %t256, ptr %l133
  br label %bb59
bb58:
  store i1 false, ptr %l129, !tbaa !21
  br label %bb68
bb59:
  %t257 = load i1, ptr %l133, !tbaa !21
  br i1 %t257, label %bb60, label %bb61
bb60:
  store i1 true, ptr %l134, !tbaa !21
  br label %bb67
bb61:
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t260 = getelementptr %"compiler/generic:Program", ptr %t258, i32 0, i32 2
  %t261 = load i32, ptr %l8, !tbaa !23
  %t264 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t260, i32 %t261)
  store i1 %t264, ptr %l138
  br label %bb62
bb62:
  %t265 = load i1, ptr %l138, !tbaa !21
  br i1 %t265, label %bb63, label %bb64
bb63:
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t268 = getelementptr %"compiler/generic:Program", ptr %t266, i32 0, i32 2
  %t269 = load i32, ptr %l7, !tbaa !23
  %t272 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t268, i32 %t269)
  store i1 %t272, ptr %l143
  br label %bb65
bb64:
  store i1 false, ptr %l139, !tbaa !21
  br label %bb66
bb65:
  %t273 = load i1, ptr %l143, !tbaa !21
  store i1 %t273, ptr %l139, !tbaa !21
  br label %bb66
bb66:
  %t274 = load i1, ptr %l139, !tbaa !21
  store i1 %t274, ptr %l134, !tbaa !21
  br label %bb67
bb67:
  %t275 = load i1, ptr %l134, !tbaa !21
  store i1 %t275, ptr %l129, !tbaa !21
  br label %bb68
bb68:
  %t276 = load i1, ptr %l129, !tbaa !21
  br i1 %t276, label %bb69, label %bb70
bb69:
  %t277 = load ptr, ptr %l1, !tbaa !29
  %t279 = getelementptr %"compiler/generic:Binding", ptr %t277, i32 0, i32 2
  %t280 = load { i64, ptr }, ptr %t279, !tbaa !27
  store { i64, ptr } %t280, ptr %l145, !tbaa !27
  %t281 = load i64, ptr %l2, !tbaa !24
  %t282 = load i32, ptr %l7, !tbaa !23
  %t285 = getelementptr { i64, ptr }, ptr %l145, i32 0, i32 1
  %t286 = load ptr, ptr %t285, !tbaa !27
  %t287 = getelementptr i32, ptr %t286, i64 %t281
  store i32 %t282, ptr %t287, !tbaa !33
  br label %bb71
bb70:
  br label %bb71
bb71:
  store i32 0, ptr %rv
  br label %ret
bb72:
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t290 = getelementptr %"compiler/generic:Program", ptr %t288, i32 0, i32 2
  %t291 = load i32, ptr %l7, !tbaa !23
  %t294 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t290, i32 %t291)
  store i32 %t294, ptr %l151
  br label %bb73
bb73:
  %t295 = load i32, ptr %l151, !range !{i32 0, i32 33}
  %t297 = trunc i64 20 to i32
  %t298 = icmp eq i32 %t295, %t297
  br i1 %t298, label %bb74, label %bb75
bb74:
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t302 = getelementptr %"compiler/generic:Program", ptr %t300, i32 0, i32 2
  %t303 = load i32, ptr %l8, !tbaa !23
  %t306 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t302, i32 %t303)
  store i32 %t306, ptr %l158
  br label %bb76
bb75:
  store i1 false, ptr %l154, !tbaa !21
  br label %bb77
bb76:
  %t307 = load i32, ptr %l158, !range !{i32 0, i32 33}
  %t309 = trunc i64 20 to i32
  %t310 = icmp eq i32 %t307, %t309
  %t312 = xor i1 %t310, true
  store i1 %t312, ptr %l154, !tbaa !21
  br label %bb77
bb77:
  %t314 = load i1, ptr %l154, !tbaa !21
  br i1 %t314, label %bb78, label %bb79
bb78:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t317 = getelementptr %"compiler/generic:Program", ptr %t315, i32 0, i32 2
  store ptr %t317, ptr %l164, !tbaa !29
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t320 = getelementptr %"compiler/generic:Program", ptr %t318, i32 0, i32 2
  %t321 = load i32, ptr %l7, !tbaa !23
  %t324 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t320, i32 %t321)
  store i32 %t324, ptr %l168
  br label %bb80
bb79:
  store i1 false, ptr %l162, !tbaa !21
  br label %bb82
bb80:
  %t325 = load ptr, ptr %l164, !tbaa !29
  %t326 = load i32, ptr %l168, !tbaa !23
  %t327 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t325, i32 %t326)
  store i32 %t327, ptr %l169
  br label %bb81
bb81:
  %t328 = load i32, ptr %l8, !tbaa !23
  %t329 = load i32, ptr %l169, !tbaa !23
  %t331 = icmp eq i32 %t329, %t328
  store i1 %t331, ptr %l162, !tbaa !21
  br label %bb82
bb82:
  %t333 = load i1, ptr %l162, !tbaa !21
  br i1 %t333, label %bb83, label %bb84
bb83:
  store i32 0, ptr %rv
  br label %ret
bb84:
  br label %bb85
bb85:
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t336 = getelementptr %"compiler/generic:Program", ptr %t334, i32 0, i32 2
  %t337 = load i32, ptr %l7, !tbaa !23
  %t340 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t336, i32 %t337)
  store i32 %t340, ptr %l175
  br label %bb86
bb86:
  %t341 = load i32, ptr %l175, !range !{i32 0, i32 33}
  %t343 = trunc i64 20 to i32
  %t344 = icmp eq i32 %t341, %t343
  br i1 %t344, label %bb87, label %bb88
bb87:
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t348 = getelementptr %"compiler/generic:Program", ptr %t346, i32 0, i32 2
  store ptr %t348, ptr %l180, !tbaa !29
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t351 = getelementptr %"compiler/generic:Program", ptr %t349, i32 0, i32 2
  %t352 = load i32, ptr %l7, !tbaa !23
  %t355 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t351, i32 %t352)
  store i32 %t355, ptr %l184
  br label %bb89
bb88:
  %t356 = load i32, ptr %l7, !tbaa !23
  store i32 %t356, ptr %l178, !tbaa !23
  br label %bb91
bb89:
  %t358 = load ptr, ptr %l180, !tbaa !29
  %t359 = load i32, ptr %l184, !tbaa !23
  %t360 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t358, i32 %t359)
  store i32 %t360, ptr %l185
  br label %bb90
bb90:
  %t361 = load i32, ptr %l185, !tbaa !23
  store i32 %t361, ptr %l178, !tbaa !23
  br label %bb91
bb91:
  %t362 = load i32, ptr %l178, !tbaa !23
  store i32 %t362, ptr %l9, !tbaa !23
  %t363 = load ptr, ptr %l0, !tbaa !29
  %t365 = getelementptr %"compiler/generic:Program", ptr %t363, i32 0, i32 2
  %t366 = load i32, ptr %l8, !tbaa !23
  %t369 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t365, i32 %t366)
  store i32 %t369, ptr %l190
  br label %bb92
bb92:
  %t370 = load i32, ptr %l190, !range !{i32 0, i32 33}
  %t372 = trunc i64 19 to i32
  %t373 = icmp eq i32 %t370, %t372
  br i1 %t373, label %bb93, label %bb94
bb93:
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t377 = getelementptr %"compiler/generic:Program", ptr %t375, i32 0, i32 2
  %t378 = load i32, ptr %l9, !tbaa !23
  %t381 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t377, i32 %t378)
  store i32 %t381, ptr %l197
  br label %bb95
bb94:
  store i1 false, ptr %l193, !tbaa !21
  br label %bb96
bb95:
  %t382 = load i32, ptr %l197, !range !{i32 0, i32 33}
  %t384 = trunc i64 19 to i32
  %t385 = icmp eq i32 %t382, %t384
  store i1 %t385, ptr %l193, !tbaa !21
  br label %bb96
bb96:
  %t387 = load i1, ptr %l193, !tbaa !21
  br i1 %t387, label %bb97, label %bb98
bb97:
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t390 = getelementptr %"compiler/generic:Program", ptr %t388, i32 0, i32 2
  store ptr %t390, ptr %l202, !tbaa !29
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t393 = getelementptr %"compiler/generic:Program", ptr %t391, i32 0, i32 2
  %t394 = load i32, ptr %l8, !tbaa !23
  %t397 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t393, i32 %t394)
  store i32 %t397, ptr %l206
  br label %bb99
bb98:
  store i1 false, ptr %l200, !tbaa !21
  br label %bb102
bb99:
  %t398 = load ptr, ptr %l0, !tbaa !29
  %t400 = getelementptr %"compiler/generic:Program", ptr %t398, i32 0, i32 2
  %t401 = load i32, ptr %l9, !tbaa !23
  %t404 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t400, i32 %t401)
  store i32 %t404, ptr %l210
  br label %bb100
bb100:
  %t405 = load ptr, ptr %l202, !tbaa !29
  %t406 = load i32, ptr %l206, !tbaa !23
  %t407 = load i32, ptr %l210, !tbaa !23
  %t408 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t405, i32 %t406, i32 %t407)
  store i1 %t408, ptr %l211
  br label %bb101
bb101:
  %t409 = load i1, ptr %l211, !tbaa !21
  store i1 %t409, ptr %l200, !tbaa !21
  br label %bb102
bb102:
  %t410 = load i1, ptr %l200, !tbaa !21
  br i1 %t410, label %bb103, label %bb104
bb103:
  %t411 = load ptr, ptr %l1, !tbaa !29
  %t413 = getelementptr %"compiler/generic:Binding", ptr %t411, i32 0, i32 4
  %t414 = load { i64, ptr }, ptr %t413, !tbaa !27
  store { i64, ptr } %t414, ptr %l214, !tbaa !27
  %t415 = load i64, ptr %l2, !tbaa !24
  %t417 = getelementptr { i64, ptr }, ptr %l214, i32 0, i32 1
  %t418 = load ptr, ptr %t417, !tbaa !27
  %t419 = getelementptr i1, ptr %t418, i64 %t415
  %t420 = load i1, ptr %t419, !tbaa !31
  %t422 = xor i1 %t420, true
  store i1 %t422, ptr %l212, !tbaa !21
  br label %bb105
bb104:
  store i1 false, ptr %l212, !tbaa !21
  br label %bb105
bb105:
  %t424 = load i1, ptr %l212, !tbaa !21
  br i1 %t424, label %bb106, label %bb107
bb106:
  %t425 = load ptr, ptr %l0, !tbaa !29
  %t427 = getelementptr %"compiler/generic:Program", ptr %t425, i32 0, i32 2
  %t428 = load i32, ptr %l8, !tbaa !23
  %t431 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t427, i32 %t428)
  store i32 %t431, ptr %l221
  br label %bb108
bb107:
  br label %bb119
bb108:
  %t432 = load i32, ptr %l221, !tbaa !23
  %t433 = icmp ne i32 %t432, 0
  br i1 %t433, label %bb109, label %bb110
bb109:
  %t435 = load ptr, ptr %l0, !tbaa !29
  %t437 = getelementptr %"compiler/generic:Program", ptr %t435, i32 0, i32 2
  %t438 = load i32, ptr %l9, !tbaa !23
  %t441 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t437, i32 %t438)
  store i32 %t441, ptr %l227
  br label %bb111
bb110:
  store i1 false, ptr %l223, !tbaa !21
  br label %bb113
bb111:
  %t442 = load ptr, ptr %l0, !tbaa !29
  %t444 = getelementptr %"compiler/generic:Program", ptr %t442, i32 0, i32 2
  %t445 = load i32, ptr %l8, !tbaa !23
  %t448 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t444, i32 %t445)
  store i32 %t448, ptr %l231
  br label %bb112
bb112:
  %t449 = load i32, ptr %l227, !tbaa !23
  %t450 = load i32, ptr %l231, !tbaa !23
  %t451 = icmp ne i32 %t449, %t450
  store i1 %t451, ptr %l223, !tbaa !21
  br label %bb113
bb113:
  %t453 = load i1, ptr %l223, !tbaa !21
  br i1 %t453, label %bb114, label %bb115
bb114:
  %t454 = load ptr, ptr %l1, !tbaa !29
  %t456 = getelementptr %"compiler/generic:Binding", ptr %t454, i32 0, i32 2
  %t457 = load { i64, ptr }, ptr %t456, !tbaa !27
  store { i64, ptr } %t457, ptr %l234, !tbaa !27
  %t458 = load i64, ptr %l2, !tbaa !24
  store i64 %t458, ptr %l235, !tbaa !24
  %t459 = load ptr, ptr %l0, !tbaa !29
  %t461 = getelementptr %"compiler/generic:Program", ptr %t459, i32 0, i32 2
  store ptr %t461, ptr %l237, !tbaa !29
  %t462 = load ptr, ptr %l0, !tbaa !29
  %t464 = getelementptr %"compiler/generic:Program", ptr %t462, i32 0, i32 2
  %t465 = load i32, ptr %l8, !tbaa !23
  %t468 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t464, i32 %t465)
  store i32 %t468, ptr %l241
  br label %bb116
bb115:
  br label %bb118
bb116:
  %t469 = load ptr, ptr %l237, !tbaa !29
  %t470 = load i32, ptr %l241, !tbaa !23
  %t471 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t469, i32 %t470, i32 0)
  store i32 %t471, ptr %l242
  br label %bb117
bb117:
  %t472 = load i32, ptr %l242, !tbaa !23
  %t473 = load i64, ptr %l235, !tbaa !24
  %t474 = getelementptr { i64, ptr }, ptr %l234, i32 0, i32 1
  %t475 = load ptr, ptr %t474, !tbaa !27
  %t476 = getelementptr i32, ptr %t475, i64 %t473
  store i32 %t472, ptr %t476, !tbaa !33
  br label %bb118
bb118:
  store i32 0, ptr %rv
  br label %ret
bb119:
  %t477 = load ptr, ptr %l0, !tbaa !29
  %t479 = getelementptr %"compiler/generic:Program", ptr %t477, i32 0, i32 2
  store ptr %t479, ptr %l244, !tbaa !29
  %t480 = load ptr, ptr %l0, !tbaa !29
  %t481 = load i32, ptr %l8, !tbaa !23
  %t484 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2enumberOf(ptr %v0, ptr %t480, i32 %t481)
  store i32 %t484, ptr %l247
  br label %bb120
bb120:
  %t485 = load ptr, ptr %l244, !tbaa !29
  %t486 = load i32, ptr %l247, !tbaa !23
  %t487 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t485, i32 %t486)
  store i1 %t487, ptr %l248
  br label %bb121
bb121:
  %t488 = load i1, ptr %l248, !tbaa !21
  br i1 %t488, label %bb122, label %bb123
bb122:
  %t489 = load ptr, ptr %l0, !tbaa !29
  %t491 = getelementptr %"compiler/generic:Program", ptr %t489, i32 0, i32 2
  store ptr %t491, ptr %l251, !tbaa !29
  %t492 = load ptr, ptr %l0, !tbaa !29
  %t493 = load i32, ptr %l7, !tbaa !23
  %t496 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2enumberOf(ptr %v0, ptr %t492, i32 %t493)
  store i32 %t496, ptr %l254
  br label %bb124
bb123:
  store i1 false, ptr %l249, !tbaa !21
  br label %bb126
bb124:
  %t497 = load ptr, ptr %l251, !tbaa !29
  %t498 = load i32, ptr %l254, !tbaa !23
  %t499 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t497, i32 %t498)
  store i1 %t499, ptr %l255
  br label %bb125
bb125:
  %t500 = load i1, ptr %l255, !tbaa !21
  store i1 %t500, ptr %l249, !tbaa !21
  br label %bb126
bb126:
  %t501 = load i1, ptr %l249, !tbaa !21
  br i1 %t501, label %bb127, label %bb128
bb127:
  %t502 = load ptr, ptr %l0, !tbaa !29
  %t503 = load i32, ptr %l7, !tbaa !23
  %t504 = load i32, ptr %l8, !tbaa !23
  %t508 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFlows(ptr %v0, ptr %t502, i32 %t503, i32 %t504)
  store i1 %t508, ptr %l259
  br label %bb129
bb128:
  br label %bb140
bb129:
  %t509 = load i1, ptr %l259, !tbaa !21
  br i1 %t509, label %bb130, label %bb131
bb130:
  store i32 0, ptr %rv
  br label %ret
bb131:
  br label %bb132
bb132:
  %t510 = load ptr, ptr %l0, !tbaa !29
  %t511 = load i32, ptr %l8, !tbaa !23
  %t512 = load i32, ptr %l7, !tbaa !23
  %t516 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFlows(ptr %v0, ptr %t510, i32 %t511, i32 %t512)
  store i1 %t516, ptr %l263
  br label %bb133
bb133:
  %t517 = load i1, ptr %l263, !tbaa !21
  br i1 %t517, label %bb134, label %bb135
bb134:
  %t518 = load ptr, ptr %l1, !tbaa !29
  %t520 = getelementptr %"compiler/generic:Binding", ptr %t518, i32 0, i32 4
  %t521 = load { i64, ptr }, ptr %t520, !tbaa !27
  store { i64, ptr } %t521, ptr %l266, !tbaa !27
  %t522 = load i64, ptr %l2, !tbaa !24
  %t524 = getelementptr { i64, ptr }, ptr %l266, i32 0, i32 1
  %t525 = load ptr, ptr %t524, !tbaa !27
  %t526 = getelementptr i1, ptr %t525, i64 %t522
  %t527 = load i1, ptr %t526, !tbaa !31
  %t529 = xor i1 %t527, true
  store i1 %t529, ptr %l264, !tbaa !21
  br label %bb136
bb135:
  store i1 false, ptr %l264, !tbaa !21
  br label %bb136
bb136:
  %t531 = load i1, ptr %l264, !tbaa !21
  br i1 %t531, label %bb137, label %bb138
bb137:
  %t532 = load ptr, ptr %l1, !tbaa !29
  %t534 = getelementptr %"compiler/generic:Binding", ptr %t532, i32 0, i32 2
  %t535 = load { i64, ptr }, ptr %t534, !tbaa !27
  store { i64, ptr } %t535, ptr %l271, !tbaa !27
  %t536 = load i64, ptr %l2, !tbaa !24
  %t537 = load i32, ptr %l7, !tbaa !23
  %t540 = getelementptr { i64, ptr }, ptr %l271, i32 0, i32 1
  %t541 = load ptr, ptr %t540, !tbaa !27
  %t542 = getelementptr i32, ptr %t541, i64 %t536
  store i32 %t537, ptr %t542, !tbaa !33
  store i32 0, ptr %rv
  br label %ret
bb138:
  br label %bb139
bb139:
  store i32 65536, ptr %rv
  br label %ret
bb140:
  %t544 = load ptr, ptr %l0, !tbaa !29
  %t546 = getelementptr %"compiler/generic:Program", ptr %t544, i32 0, i32 2
  %t547 = load i32, ptr %l8, !tbaa !23
  %t550 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t546, i32 %t547)
  store i32 %t550, ptr %l278
  br label %bb141
bb141:
  %t551 = load i32, ptr %l278, !range !{i32 0, i32 33}
  %t553 = trunc i64 20 to i32
  %t554 = icmp eq i32 %t551, %t553
  br i1 %t554, label %bb142, label %bb143
bb142:
  %t556 = load ptr, ptr %l0, !tbaa !29
  %t558 = getelementptr %"compiler/generic:Program", ptr %t556, i32 0, i32 2
  %t559 = load i32, ptr %l7, !tbaa !23
  %t562 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t558, i32 %t559)
  store i32 %t562, ptr %l285
  br label %bb144
bb143:
  store i1 false, ptr %l281, !tbaa !21
  br label %bb145
bb144:
  %t563 = load i32, ptr %l285, !range !{i32 0, i32 33}
  %t565 = trunc i64 20 to i32
  %t566 = icmp eq i32 %t563, %t565
  store i1 %t566, ptr %l281, !tbaa !21
  br label %bb145
bb145:
  %t568 = load i1, ptr %l281, !tbaa !21
  br i1 %t568, label %bb146, label %bb147
bb146:
  %t569 = load ptr, ptr %l0, !tbaa !29
  %t571 = getelementptr %"compiler/generic:Program", ptr %t569, i32 0, i32 2
  %t572 = load i32, ptr %l8, !tbaa !23
  %t575 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t571, i32 %t572)
  store i32 %t575, ptr %l292
  br label %bb148
bb147:
  store i1 false, ptr %l288, !tbaa !21
  br label %bb150
bb148:
  %t576 = load ptr, ptr %l0, !tbaa !29
  %t578 = getelementptr %"compiler/generic:Program", ptr %t576, i32 0, i32 2
  %t579 = load i32, ptr %l7, !tbaa !23
  %t582 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t578, i32 %t579)
  store i32 %t582, ptr %l296
  br label %bb149
bb149:
  %t583 = load i32, ptr %l292, !tbaa !23
  %t584 = load i32, ptr %l296, !tbaa !23
  %t585 = icmp eq i32 %t583, %t584
  store i1 %t585, ptr %l288, !tbaa !21
  br label %bb150
bb150:
  %t587 = load i1, ptr %l288, !tbaa !21
  br i1 %t587, label %bb151, label %bb152
bb151:
  %t588 = load ptr, ptr %l0, !tbaa !29
  %t590 = getelementptr %"compiler/generic:Program", ptr %t588, i32 0, i32 2
  %t591 = load i32, ptr %l8, !tbaa !23
  %t594 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t590, i32 %t591)
  store i64 %t594, ptr %l301
  br label %bb153
bb152:
  br label %bb160
bb153:
  %t595 = load i64, ptr %l301, !tbaa !24
  store i64 %t595, ptr %l10, !tbaa !24
  %t596 = load ptr, ptr %l0, !tbaa !29
  %t598 = getelementptr %"compiler/generic:Program", ptr %t596, i32 0, i32 2
  %t599 = load i32, ptr %l7, !tbaa !23
  %t602 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t598, i32 %t599)
  store i64 %t602, ptr %l305
  br label %bb154
bb154:
  %t603 = load i64, ptr %l305, !tbaa !24
  store i64 %t603, ptr %l11, !tbaa !24
  %t604 = load ptr, ptr %l1, !tbaa !29
  %t606 = getelementptr %"compiler/generic:Binding", ptr %t604, i32 0, i32 4
  %t607 = load { i64, ptr }, ptr %t606, !tbaa !27
  store { i64, ptr } %t607, ptr %l307, !tbaa !27
  %t608 = load i64, ptr %l2, !tbaa !24
  %t610 = getelementptr { i64, ptr }, ptr %l307, i32 0, i32 1
  %t611 = load ptr, ptr %t610, !tbaa !27
  %t612 = getelementptr i1, ptr %t611, i64 %t608
  %t613 = load i1, ptr %t612, !tbaa !31
  %t615 = xor i1 %t613, true
  br i1 %t615, label %bb155, label %bb156
bb155:
  %t617 = load ptr, ptr %l1, !tbaa !29
  %t619 = getelementptr %"compiler/generic:Binding", ptr %t617, i32 0, i32 2
  %t620 = load { i64, ptr }, ptr %t619, !tbaa !27
  store { i64, ptr } %t620, ptr %l312, !tbaa !27
  %t621 = load i64, ptr %l2, !tbaa !24
  store i64 %t621, ptr %l313, !tbaa !24
  %t622 = load ptr, ptr %l0, !tbaa !29
  %t624 = getelementptr %"compiler/generic:Program", ptr %t622, i32 0, i32 2
  store ptr %t624, ptr %l315, !tbaa !29
  %t625 = load ptr, ptr %l0, !tbaa !29
  %t627 = getelementptr %"compiler/generic:Program", ptr %t625, i32 0, i32 2
  %t628 = load i32, ptr %l7, !tbaa !23
  %t631 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t627, i32 %t628)
  store i32 %t631, ptr %l319
  br label %bb157
bb156:
  br label %bb159
bb157:
  %t632 = load i64, ptr %l10, !tbaa !24
  %t633 = load i64, ptr %l11, !tbaa !24
  %t636 = and i64 %t632, %t633
  %t637 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t640 = and i64 %t636, %t637
  %t641 = load i64, ptr %l10, !tbaa !24
  %t642 = load i64, ptr %l11, !tbaa !24
  %t645 = or i64 %t641, %t642
  %t646 = load i64, ptr @G_2ecompiler_2ftypes_2eNullable, !tbaa !24
  %t649 = and i64 %t645, %t646
  %t652 = or i64 %t640, %t649
  %t653 = load ptr, ptr %l315, !tbaa !29
  %t654 = load i32, ptr %l319, !tbaa !23
  %t656 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t653, i32 %t654, i64 %t652)
  store i32 %t656, ptr %l331
  br label %bb158
bb158:
  %t657 = load i32, ptr %l331, !tbaa !23
  %t658 = load i64, ptr %l313, !tbaa !24
  %t659 = getelementptr { i64, ptr }, ptr %l312, i32 0, i32 1
  %t660 = load ptr, ptr %t659, !tbaa !27
  %t661 = getelementptr i32, ptr %t660, i64 %t658
  store i32 %t657, ptr %t661, !tbaa !33
  br label %bb159
bb159:
  store i32 0, ptr %rv
  br label %ret
bb160:
  store i32 65536, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ebufferUnended(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l7 = alloca i1
  %l9 = alloca i1
  %l13 = alloca i1
  %l14 = alloca i1
  %l18 = alloca i1
  %l26 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l1, !tbaa !23
  %t7 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t3, i32 %t4)
  store i1 %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load i1, ptr %l7, !tbaa !21
  %t9 = xor i1 %t8, true
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/generic:Program", ptr %t11, i32 0, i32 2
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %t13, i32 %t14)
  store i1 %t17, ptr %l13
  br label %bb4
bb3:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb5
bb4:
  %t18 = load i1, ptr %l13, !tbaa !21
  store i1 %t18, ptr %l9, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l9, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/generic:Program", ptr %t20, i32 0, i32 2
  %t23 = load i32, ptr %l1, !tbaa !23
  %t26 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnique(ptr %v0, ptr %t22, i32 %t23)
  store i1 %t26, ptr %l18
  br label %bb8
bb7:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb9
bb8:
  %t27 = load i1, ptr %l18, !tbaa !21
  %t28 = xor i1 %t27, true
  store i1 %t28, ptr %l14, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l14, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load i32, ptr %l1, !tbaa !23
  store i32 %t31, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i32, ptr %l1, !tbaa !23
  %t38 = add i64 %a3, 1
  %t43 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunended(ptr %v0, ptr %v1, ptr %t33, i32 %t34, ptr %a2, i64 %t38)
  store i32 %t43, ptr %l26
  br label %bb13
bb13:
  %t44 = load i32, ptr %l26, !tbaa !23
  store i32 %t44, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, i32 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ecanonEnum(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca i64
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca i1
  %l12 = alloca i64
  %l14 = alloca i1
  %l16 = alloca i1
  %l27 = alloca i1
  %l29 = alloca i8
  %l30 = alloca i1
  %l31 = alloca i1
  %l33 = alloca i8
  %l34 = alloca i1
  %l35 = alloca i1
  %l37 = alloca i8
  %l40 = alloca ptr
  %l43 = alloca ptr
  %l46 = alloca ptr
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l57 = alloca i32
  %l59 = alloca i1
  %l60 = alloca ptr
  %l62 = alloca ptr
  %l63 = alloca i32
  %l66 = alloca i32
  %l67 = alloca i32
  %l69 = alloca i32
  %l72 = alloca ptr
  %l74 = alloca { i64, ptr }
  %l76 = alloca ptr
  %l78 = alloca { i64, ptr }
  %l79 = alloca i32
  %l83 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i32, i32 }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l6
  br label %bb2
bb2:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l3
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2eeat(ptr %v1, ptr %s1, ptr %t5, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) })
  store i1 %t7, ptr %l8
  br label %bb4
bb4:
  %t8 = load i1, ptr %l8, !tbaa !21
  %t9 = xor i1 %t8, true
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %bb55
bb6:
  br label %bb7
bb7:
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l2)
  store i64 %t14, ptr %l12
  br label %bb8
bb8:
  %t15 = load i64, ptr %l12, !tbaa !24
  %t16 = icmp sgt i64 %t15, 0
  br i1 %t16, label %bb9, label %bb10
bb9:
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2eeat(ptr %v1, ptr %s1, ptr %t18, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) })
  store i1 %t20, ptr %l16
  br label %bb11
bb10:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb12
bb11:
  %t21 = load i1, ptr %l16, !tbaa !21
  %t22 = xor i1 %t21, true
  store i1 %t22, ptr %l14, !tbaa !21
  br label %bb12
bb12:
  %t24 = load i1, ptr %l14, !tbaa !21
  br i1 %t24, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t26 = insertvalue { i32, i32 } zeroinitializer, i32 65536, 0
  store { i32, i32 } %t26, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr %"compiler/generic:cursor", ptr %t27, i32 0, i32 1
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l4, !tbaa !24
  br label %bb16
bb16:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr %"compiler/generic:cursor", ptr %t32, i32 0, i32 1
  %t35 = load i64, ptr %t34, !tbaa !24
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t38 = getelementptr %"compiler/generic:cursor", ptr %t36, i32 0, i32 0
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t44 = icmp slt i64 %t35, %t41
  br i1 %t44, label %bb17, label %bb18
bb17:
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t48 = call i8 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2epeek(ptr %v1, ptr %t46)
  store i8 %t48, ptr %l29
  br label %bb19
bb18:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb30
bb19:
  %t49 = load i8, ptr %l29, !tbaa !22
  %t50 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t49)
  store i1 %t50, ptr %l30
  br label %bb20
bb20:
  %t51 = load i1, ptr %l30, !tbaa !21
  br i1 %t51, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb25
bb22:
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = call i8 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2epeek(ptr %v1, ptr %t52)
  store i8 %t54, ptr %l33
  br label %bb23
bb23:
  %t55 = load i8, ptr %l33, !tbaa !22
  %t56 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t55)
  store i1 %t56, ptr %l34
  br label %bb24
bb24:
  %t57 = load i1, ptr %l34, !tbaa !21
  store i1 %t57, ptr %l31, !tbaa !21
  br label %bb25
bb25:
  %t58 = load i1, ptr %l31, !tbaa !21
  br i1 %t58, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb29
bb27:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = call i8 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2epeek(ptr %v1, ptr %t59)
  store i8 %t61, ptr %l37
  br label %bb28
bb28:
  %t62 = load i8, ptr %l37, !tbaa !22
  %t63 = icmp eq i8 %t62, 95
  store i1 %t63, ptr %l35, !tbaa !21
  br label %bb29
bb29:
  %t65 = load i1, ptr %l35, !tbaa !21
  store i1 %t65, ptr %l27, !tbaa !21
  br label %bb30
bb30:
  %t66 = load i1, ptr %l27, !tbaa !21
  %t67 = xor i1 %t66, true
  br i1 %t67, label %bb31, label %bb32
bb31:
  br label %bb35
bb32:
  br label %bb33
bb33:
  %t69 = load ptr, ptr %l1, !tbaa !29
  store ptr %t69, ptr %l40, !tbaa !29
  %t70 = load ptr, ptr %l40, !tbaa !29
  %t71 = getelementptr %"compiler/generic:cursor", ptr %t70, i32 0, i32 1
  %t72 = load i64, ptr %t71, !tbaa !24
  %t74 = add i64 %t72, 1
  %t76 = load ptr, ptr %l40, !tbaa !29
  %t77 = getelementptr %"compiler/generic:cursor", ptr %t76, i32 0, i32 1
  store i64 %t74, ptr %t77, !tbaa !24
  br label %bb34
bb34:
  br label %bb16
bb35:
  store ptr %l2, ptr %l43, !tbaa !29
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/generic:Program", ptr %t78, i32 0, i32 0
  %t81 = load ptr, ptr %t80, !tbaa !29
  %t83 = getelementptr %"compiler/load:Loader", ptr %t81, i32 0, i32 3
  %t84 = load ptr, ptr %t83, !tbaa !29
  store ptr %t84, ptr %l46, !tbaa !29
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr %"compiler/generic:cursor", ptr %t85, i32 0, i32 0
  %t88 = load { i64, ptr }, ptr %t87, !tbaa !27
  store { i64, ptr } %t88, ptr %l48, !tbaa !27
  %t89 = load i64, ptr %l4, !tbaa !24
  store i64 %t89, ptr %l49, !tbaa !24
  %t90 = load ptr, ptr %l1, !tbaa !29
  %t92 = getelementptr %"compiler/generic:cursor", ptr %t90, i32 0, i32 1
  %t93 = load i64, ptr %t92, !tbaa !24
  store i64 %t93, ptr %l51, !tbaa !24
  %t94 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 0
  store i64 %t95, ptr %l52, !tbaa !24
  %t96 = load i64, ptr %l49, !tbaa !24
  %t97 = icmp sge i64 %t96, 0
  br i1 %t97, label %bb36, label %bb37
bb36:
  %t99 = load i64, ptr %l49, !tbaa !24
  %t100 = load i64, ptr %l51, !tbaa !24
  %t101 = icmp sle i64 %t99, %t100
  br i1 %t101, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_510ce85b2a9a6c03_b867f874fd10b7a7)
  unreachable
bb38:
  %t103 = load i64, ptr %l51, !tbaa !24
  %t104 = load i64, ptr %l52, !tbaa !24
  %t105 = icmp sle i64 %t103, %t104
  br i1 %t105, label %bb40, label %bb41
bb39:
  call void @__olang_check_failed(ptr @olang_loc_510ce85b2a9a6c03_b867f874fd10b7a7)
  unreachable
bb40:
  %t107 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = load i64, ptr %l49, !tbaa !24
  %t110 = load i64, ptr %l51, !tbaa !24
  %t111 = getelementptr i8, ptr %t108, i64 %t109
  %t112 = sub i64 %t110, %t109
  %t113 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t114 = insertvalue { i64, ptr } %t113, ptr %t111, 1
  %t115 = load ptr, ptr %l46, !tbaa !29
  %t117 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %t115, { i64, ptr } %t114)
  store i32 %t117, ptr %l57
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_510ce85b2a9a6c03_b867f874fd10b7a7)
  unreachable
bb42:
  %t118 = load ptr, ptr %l43, !tbaa !29
  %t119 = load i32, ptr %l57, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %t118, i32 %t119)
  br label %bb43
bb43:
  %t120 = load ptr, ptr %l1, !tbaa !29
  %t122 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2eeat(ptr %v1, ptr %s1, ptr %t120, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d33, i32 0, i32 1) })
  store i1 %t122, ptr %l59
  br label %bb44
bb44:
  %t123 = load i1, ptr %l59, !tbaa !21
  br i1 %t123, label %bb45, label %bb46
bb45:
  store %olang.scope zeroinitializer, ptr %s4
  store ptr %l3, ptr %l60, !tbaa !29
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/generic:Program", ptr %t124, i32 0, i32 2
  store ptr %t126, ptr %l62, !tbaa !29
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load ptr, ptr %l1, !tbaa !29
  %t131 = call { i32, i32 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ecanonList(ptr %v0, ptr %v1, ptr %s4, ptr %t127, ptr %t128, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) })
  %t132 = extractvalue { i32, i32 } %t131, 1
  %t133 = extractvalue { i32, i32 } %t131, 0
  store i32 %t133, ptr %l67
  %t134 = icmp ne i32 %t133, 0
  br i1 %t134, label %bb48, label %ok.135, !prof !99
ok.135:
  store i32 %t132, ptr %l66
  br label %bb47
bb46:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l3, i32 0)
  br label %bb52
bb47:
  %t137 = load i32, ptr %l66, !tbaa !23
  store i32 %t137, ptr %l63, !tbaa !23
  br label %bb49
bb48:
  %t138 = load i32, ptr %l67, !tbaa !23
  %t139 = lshr i32 %t138, 16
  %t140 = and i32 %t138, 65535
  %t141 = icmp eq i32 %t139, 1
  %t142 = select i1 %t141, i32 1, i32 0
  %t143 = icmp eq i32 %t139, 2
  %t144 = select i1 %t143, i32 2, i32 %t142
  %t145 = icmp eq i32 %t138, 0
  %t146 = shl i32 %t144, 16
  %t147 = or i32 %t146, %t140
  %t148 = select i1 %t145, i32 0, i32 %t147
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t150 = insertvalue { i32, i32 } zeroinitializer, i32 %t148, 0
  store { i32, i32 } %t150, ptr %rv
  br label %ret
bb49:
  %t151 = load ptr, ptr %l62, !tbaa !29
  %t152 = load i32, ptr %l63, !tbaa !23
  %t153 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRecord(ptr %v0, ptr %t151, i32 %t152)
  store i32 %t153, ptr %l69
  br label %bb50
bb50:
  %t154 = load ptr, ptr %l60, !tbaa !29
  %t155 = load i32, ptr %l69, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t154, i32 %t155)
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s4)
  br label %bb53
bb52:
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s1)
  br label %bb54
bb54:
  br label %bb3
bb55:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/generic:Program", ptr %t156, i32 0, i32 2
  store ptr %t158, ptr %l72, !tbaa !29
  %t160 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eToArra_H4d02a0b2e27e8f31ffc99daa43750593(ptr %s0, ptr %s0, ptr %l2)
  store { i64, ptr } %t160, ptr %l74
  br label %bb56
bb56:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/generic:Program", ptr %t161, i32 0, i32 2
  store ptr %t163, ptr %l76, !tbaa !29
  %t165 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %s0, ptr %l3)
  store { i64, ptr } %t165, ptr %l78
  br label %bb57
bb57:
  %t166 = load ptr, ptr %l76, !tbaa !29
  %t167 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t168 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t166, { i64, ptr } %t167)
  store i32 %t168, ptr %l79
  br label %bb58
bb58:
  %t169 = icmp sge i64 0, 0
  br i1 %t169, label %bb59, label %bb60
bb59:
  %t171 = icmp sle i64 0, 2305843009213693951
  br i1 %t171, label %bb61, label %bb62
bb60:
  call void @__olang_check_failed(ptr @olang_loc_3e2c33a947ef0926_eb9e7dc4e2170cd2)
  unreachable
bb61:
  %t173 = mul i64 0, 4
  %t174 = insertvalue { i64, ptr } undef, i64 0, 0
  %t175 = insertvalue { i64, ptr } %t174, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t176 = load ptr, ptr %l72, !tbaa !29
  %t177 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t178 = load i32, ptr %l79, !tbaa !23
  %t180 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnonEnum(ptr %v0, ptr %s0, ptr %s0, ptr %t176, { i64, ptr } %t177, i32 %t178, { i64, ptr } %t175)
  store i32 %t180, ptr %l83
  br label %bb63
bb62:
  call void @__olang_check_failed(ptr @olang_loc_3e2c33a947ef0926_eb9e7dc4e2170cd2)
  unreachable
bb63:
  call void @__olang_scope_close(ptr %s0)
  %t181 = load i32, ptr %l83, !tbaa !23
  %t182 = insertvalue { i32, i32 } zeroinitializer, i32 %t181, 1
  store { i32, i32 } %t182, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eentriesOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca i64
  %l13 = alloca %"compiler/generic:Context"
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l21 = alloca i32
  %l25 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l47 = alloca i1
  %l51 = alloca i32
  %l60 = alloca i32
  %l63 = alloca { i64, ptr }
  %l70 = alloca i64
  %l72 = alloca i64
  %l77 = alloca i32
  %l88 = alloca i64
  %l89 = alloca %"compiler/generic:Context"
  %l97 = alloca { i64, ptr }
  %l100 = alloca ptr
  %l104 = alloca i32
  %l109 = alloca i32
  %l111 = alloca i32
  %l112 = alloca i32
  %l118 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %t143 = alloca %"compiler/generic:Context", align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l1, !tbaa !23
  %t7 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t7, ptr %l21
  br label %bb1
bb1:
  %t8 = load i32, ptr %l21, !range !{i32 0, i32 33}
  %t10 = trunc i64 30 to i32
  %t11 = icmp eq i32 %t8, %t10
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  store ptr %t15, ptr %l25, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %l1, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l29
  br label %bb4
bb3:
  br label %bb13
bb4:
  %t23 = load ptr, ptr %l25, !tbaa !29
  %t24 = load i32, ptr %l29, !tbaa !23
  %t25 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t23, i32 %t24)
  store { i64, ptr } %t25, ptr %l30
  br label %bb5
bb5:
  %t26 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t26, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t27 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  store i64 %t29, ptr %l6, !tbaa !24
  br label %bb6
bb6:
  %t31 = load i64, ptr %l5, !tbaa !24
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb7, label %bb8
bb7:
  br label %bb12
bb8:
  br label %bb9
bb9:
  %t39 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t39, ptr %l37, !tbaa !27
  %t40 = load i64, ptr %l5, !tbaa !24
  %t42 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr i32, ptr %t43, i64 %t40
  %t45 = load i32, ptr %t44, !tbaa !33
  %t47 = load ptr, ptr %l2, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t47, i32 %t45)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t51 = load i64, ptr %l5, !tbaa !24
  %t53 = add i64 %t51, 1
  store i64 %t53, ptr %l5, !tbaa !24
  br label %bb6
bb12:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb13:
  %t55 = load i32, ptr %l1, !tbaa !23
  %t56 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t59 = icmp eq i32 %t55, %t56
  br i1 %t59, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l47, !tbaa !21
  br label %bb17
bb15:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/generic:Program", ptr %t61, i32 0, i32 2
  %t64 = load i32, ptr %l1, !tbaa !23
  %t67 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t63, i32 %t64)
  store i32 %t67, ptr %l51
  br label %bb16
bb16:
  %t68 = load i32, ptr %l51, !range !{i32 0, i32 33}
  %t70 = trunc i64 18 to i32
  %t71 = icmp eq i32 %t68, %t70
  %t73 = xor i1 %t71, true
  store i1 %t73, ptr %l47, !tbaa !21
  br label %bb17
bb17:
  %t75 = load i1, ptr %l47, !tbaa !21
  br i1 %t75, label %bb18, label %bb19
bb18:
  %t76 = load ptr, ptr %l2, !tbaa !29
  %t77 = load i32, ptr %l1, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t76, i32 %t77)
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb21:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/generic:Program", ptr %t80, i32 0, i32 2
  %t83 = load i32, ptr %l1, !tbaa !23
  %t86 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t82, i32 %t83)
  store i32 %t86, ptr %l60
  br label %bb22
bb22:
  %t87 = load i32, ptr %l60, !tbaa !23
  store i32 %t87, ptr %l8, !tbaa !23
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load i32, ptr %l8, !tbaa !23
  %t92 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorMembers(ptr %v0, ptr %v0, ptr %t88, i32 %t89)
  store { i64, ptr } %t92, ptr %l63
  br label %bb23
bb23:
  %t93 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t93, ptr %l9, !tbaa !27
  %t94 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t94, 0
  %t98 = icmp eq i64 %t96, 0
  br i1 %t98, label %bb24, label %bb25
bb24:
  %t100 = load ptr, ptr %l2, !tbaa !29
  %t101 = load i32, ptr %l1, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t100, i32 %t101)
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb27:
  %t104 = load ptr, ptr %l3, !tbaa !29
  store ptr %t104, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb28
bb28:
  %t106 = load i64, ptr %l11, !tbaa !24
  store i64 %t106, ptr %l70, !tbaa !24
  %t107 = load ptr, ptr %l10, !tbaa !29
  %t109 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aDeclId_3e_2eLen_3ccompiler_2ftypes_3aDeclId_3e(ptr %v2, ptr %t107)
  store i64 %t109, ptr %l72
  br label %bb29
bb29:
  %t110 = load i64, ptr %l70, !tbaa !24
  %t111 = load i64, ptr %l72, !tbaa !24
  %t112 = icmp slt i64 %t110, %t111
  %t114 = xor i1 %t112, true
  br i1 %t114, label %bb30, label %bb31
bb30:
  br label %bb38
bb31:
  br label %bb32
bb32:
  %t116 = load ptr, ptr %l10, !tbaa !29
  %t117 = load i64, ptr %l11, !tbaa !24
  %t120 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aDeclId_3e_2eAt_3ccompiler_2ftypes_3aDeclId_3e(ptr %v2, ptr %t116, i64 %t117)
  store i32 %t120, ptr %l77
  br label %bb33
bb33:
  %t121 = load i32, ptr %l77, !tbaa !23
  %t123 = load i32, ptr %l8, !tbaa !23
  %t126 = icmp eq i32 %t121, %t123
  br i1 %t126, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb35:
  br label %bb36
bb36:
  br label %bb37
bb37:
  %t128 = load i64, ptr %l11, !tbaa !24
  %t130 = add i64 %t128, 1
  store i64 %t130, ptr %l11, !tbaa !24
  br label %bb28
bb38:
  %t132 = load ptr, ptr %l3, !tbaa !29
  %t133 = load i32, ptr %l8, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aDeclId_3e_2ePush_3ccompiler_2ftypes_3aDeclId_3e(ptr %v2, ptr %t132, i32 %t133)
  br label %bb39
bb39:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/generic:Program", ptr %t136, i32 0, i32 2
  %t139 = load i32, ptr %l8, !tbaa !23
  %t142 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t138, i32 %t139)
  store i64 %t142, ptr %l88
  br label %bb40
bb40:
  %t144 = load i64, ptr %l88, !tbaa !24
  call void @compiler_2fgeneric_3aContext_2ector(ptr %t143, ptr %s0, i64 %t144, i64 -1)
  call void @llvm.memmove.p0.p0.i64(ptr %l89, ptr %t143, i64 160, i1 false)
  br label %bb41
bb41:
  call void @llvm.memmove.p0.p0.i64(ptr %l13, ptr %l89, i64 160, i1 false)
  %t145 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t145, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t147 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t149 = extractvalue { i64, ptr } %t147, 0
  store i64 %t149, ptr %l16, !tbaa !24
  br label %bb42
bb42:
  %t151 = load i64, ptr %l15, !tbaa !24
  %t152 = load i64, ptr %l16, !tbaa !24
  %t155 = icmp slt i64 %t151, %t152
  %t157 = xor i1 %t155, true
  br i1 %t157, label %bb43, label %bb44
bb43:
  br label %bb49
bb44:
  br label %bb45
bb45:
  %t159 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t159, ptr %l97, !tbaa !27
  %t160 = load i64, ptr %l15, !tbaa !24
  %t162 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !27
  %t164 = getelementptr ptr, ptr %t163, i64 %t160
  %t165 = load ptr, ptr %t164, !tbaa !39
  %t167 = load ptr, ptr %l0, !tbaa !29
  store ptr %t167, ptr %l100, !tbaa !29
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t173 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eerrorSetItem(ptr %v0, ptr %s0, ptr %v0, ptr %t168, ptr %l13, ptr %t165)
  store i32 %t173, ptr %l104
  br label %bb46
bb46:
  %t174 = load ptr, ptr %l2, !tbaa !29
  %t175 = load ptr, ptr %l3, !tbaa !29
  %t176 = load ptr, ptr %l100, !tbaa !29
  %t177 = load i32, ptr %l104, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eentriesOf(ptr %v0, ptr %v1, ptr %v2, ptr %t176, i32 %t177, ptr %t174, ptr %t175)
  br label %bb47
bb47:
  br label %bb48
bb48:
  %t180 = load i64, ptr %l15, !tbaa !24
  %t182 = add i64 %t180, 1
  store i64 %t182, ptr %l15, !tbaa !24
  br label %bb42
bb49:
  %t184 = load ptr, ptr %l3, !tbaa !29
  %t186 = call { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aDeclId_3e_2ePop_3ccompiler_2ftypes_3aDeclId_3e(ptr %v2, ptr %t184)
  %t187 = extractvalue { i32, i32 } %t186, 1
  %t188 = extractvalue { i32, i32 } %t186, 0
  store i32 %t188, ptr %l112
  %t189 = icmp ne i32 %t188, 0
  br i1 %t189, label %bb51, label %ok.190, !prof !99
ok.190:
  store i32 %t187, ptr %l111
  br label %bb50
bb50:
  %t191 = load i32, ptr %l111, !tbaa !23
  store i32 %t191, ptr %l109, !tbaa !23
  br label %bb58
bb51:
  %t192 = load i32, ptr %l112, !tbaa !23
  %t193 = icmp eq i32 %t192, 65536
  br i1 %t193, label %bb52, label %bb53
bb52:
  call void @__olang_bang_failed_plain(ptr @olang_loc_720125e199c24f22_e8379e985b9f3c66)
  unreachable
bb53:
  %t195 = load i32, ptr %l112, !tbaa !23
  %t196 = icmp eq i32 %t195, 65537
  br i1 %t196, label %bb54, label %bb55
bb54:
  call void @__olang_bang_failed_plain(ptr @olang_loc_227a3f0eae681c4f_61bdff3e0ec7ebb3)
  unreachable
bb55:
  %t198 = load i32, ptr %l112, !tbaa !23
  %t199 = icmp eq i32 %t198, 65538
  br i1 %t199, label %bb56, label %bb57
bb56:
  call void @__olang_bang_failed_plain(ptr @olang_loc_f703e5bec6c76f87_ea1686e8125b66ab)
  unreachable
bb57:
  call void @__olang_bang_failed_plain(ptr @olang_loc_bbb5b8b709f50d79_9796b462e6590e5d)
  unreachable
bb58:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load i32, ptr %l8, !tbaa !23
  %t205 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %s0, ptr %t201, i32 %t202)
  store { i64, ptr } %t205, ptr %l118
  br label %bb59
bb59:
  %t206 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t207 = extractvalue { i64, ptr } %t206, 0
  %t209 = icmp sgt i64 %t207, 0
  br i1 %t209, label %bb60, label %bb61
bb60:
  %t211 = load ptr, ptr %l2, !tbaa !29
  %t212 = load i32, ptr %l1, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t211, i32 %t212)
  br label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eentryHeld(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i32
  %l7 = alloca i64
  %l9 = alloca i64
  %l14 = alloca i32
  %l18 = alloca i32
  %l22 = alloca i32
  %l24 = alloca i1
  %l28 = alloca i64
  %l32 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a2, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l4, !tbaa !24
  store i64 %t3, ptr %l7, !tbaa !24
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t4)
  store i64 %t6, ptr %l9
  br label %bb2
bb2:
  %t7 = load i64, ptr %l7, !tbaa !24
  %t8 = load i64, ptr %l9, !tbaa !24
  %t9 = icmp slt i64 %t7, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  br label %bb18
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l3, !tbaa !29
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t13, i64 %t14)
  store i32 %t17, ptr %l14
  br label %bb6
bb6:
  %t18 = load i32, ptr %l14, !tbaa !23
  store i32 %t18, ptr %l5, !tbaa !23
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %l5, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l18
  br label %bb7
bb7:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  %t29 = load i32, ptr %l1, !tbaa !23
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t32, ptr %l22
  br label %bb8
bb8:
  %t33 = load i32, ptr %l18, !tbaa !23
  %t34 = load i32, ptr %l22, !tbaa !23
  %t35 = icmp eq i32 %t33, %t34
  br i1 %t35, label %bb9, label %bb10
bb9:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 2
  %t40 = load i32, ptr %l1, !tbaa !23
  %t43 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t39, i32 %t40)
  store i64 %t43, ptr %l28
  br label %bb11
bb10:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb13
bb11:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/generic:Program", ptr %t44, i32 0, i32 2
  %t47 = load i32, ptr %l5, !tbaa !23
  %t50 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t46, i32 %t47)
  store i64 %t50, ptr %l32
  br label %bb12
bb12:
  %t51 = load i64, ptr %l32, !tbaa !65
  %t52 = xor i64 %t51, -1
  %t53 = load i64, ptr %l28, !tbaa !65
  %t55 = and i64 %t53, %t52
  %t57 = icmp eq i64 %t55, 0
  store i1 %t57, ptr %l24, !tbaa !21
  br label %bb13
bb13:
  %t59 = load i1, ptr %l24, !tbaa !21
  br i1 %t59, label %bb14, label %bb15
bb14:
  store i1 true, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t61 = load i64, ptr %l4, !tbaa !24
  %t63 = add i64 %t61, 1
  store i64 %t63, ptr %l4, !tbaa !24
  br label %bb1
bb18:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eerrorList(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i1 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca i1
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca { i64, ptr }
  %l33 = alloca i1
  %l44 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l47 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l4
  %t3 = load i1, ptr %l2, !tbaa !21
  br i1 %t3, label %bb2, label %bb3
bb2:
  %t5 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t9 = icmp eq i64 %t7, 0
  store i1 %t9, ptr %l12, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb4
bb4:
  %t11 = load i1, ptr %l12, !tbaa !21
  br i1 %t11, label %bb5, label %bb6
bb5:
  %t12 = load i32, ptr @G_2ecompiler_2ftypes_2eDefaultErrT, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l4, i32 %t12)
  br label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb8
bb8:
  %t15 = load i1, ptr %l2, !tbaa !21
  br i1 %t15, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t17 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %l19
  br label %bb11
bb10:
  br label %bb21
bb11:
  %t18 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %l5
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t19, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l8, !tbaa !24
  br label %bb12
bb12:
  %t25 = load i64, ptr %l7, !tbaa !24
  %t26 = load i64, ptr %l8, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb13, label %bb14
bb13:
  br label %bb19
bb14:
  br label %bb15
bb15:
  %t33 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t33, ptr %l27, !tbaa !27
  %t34 = load i64, ptr %l7, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr ptr, ptr %t37, i64 %t34
  %t39 = load ptr, ptr %t38, !tbaa !39
  store ptr %t39, ptr %l9, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t43 = load ptr, ptr %l9, !tbaa !29
  %t47 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorItemKnown(ptr %v0, ptr %v1, ptr %v2, ptr %t41, ptr %t42, ptr %t43)
  store i1 %t47, ptr %l33
  br label %bb16
bb16:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t50 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eerrorSetEntries(ptr %v0, ptr %v1, ptr %v2, ptr %s2, ptr %t48, ptr %t49, ptr %t50, ptr %l5)
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t55 = load i64, ptr %l7, !tbaa !24
  %t57 = add i64 %t55, 1
  store i64 %t57, ptr %l7, !tbaa !24
  br label %bb12
bb19:
  %t59 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emergeEntries(ptr %v0, ptr %s2, ptr %s0, ptr %t59, ptr %l5, ptr %l4)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb21:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/generic:Program", ptr %t63, i32 0, i32 2
  store ptr %t65, ptr %l44, !tbaa !29
  %t67 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %s0, ptr %l4)
  store { i64, ptr } %t67, ptr %l46
  br label %bb22
bb22:
  %t68 = load ptr, ptr %l44, !tbaa !29
  %t69 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t70 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t68, { i64, ptr } %t69)
  store i32 %t70, ptr %l47
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  %t71 = load i32, ptr %l47, !tbaa !23
  store i32 %t71, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eerrorSetEntries(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca ptr
  %l10 = alloca i32
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aDeclId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l4
  %t3 = load ptr, ptr %l0, !tbaa !29
  store ptr %t3, ptr %l6, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t10 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eerrorSetItem(ptr %v0, ptr %v1, ptr %v2, ptr %t4, ptr %a1, ptr %a2)
  store i32 %t10, ptr %l10
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l6, !tbaa !29
  %t13 = load i32, ptr %l10, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eentriesOf(ptr %v0, ptr %v3, ptr %s0, ptr %t12, i32 %t13, ptr %a3, ptr %l4)
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eerrorType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l7 = alloca i32
  %l11 = alloca i1
  %l13 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t7 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2enamedType(ptr %v0, ptr %v1, ptr %v2, ptr %t1, ptr %a1, ptr %a2)
  store i32 %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load i32, ptr %l7, !tbaa !23
  store i32 %t8, ptr %l3, !tbaa !23
  %t9 = load i32, ptr %l3, !tbaa !23
  %t10 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t13 = icmp eq i32 %t9, %t10
  br i1 %t13, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb6
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  store ptr %t17, ptr %l13, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/generic:Program", ptr %t18, i32 0, i32 2
  %t21 = load i32, ptr %l3, !tbaa !23
  %t24 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t20, i32 %t21)
  store i32 %t24, ptr %l17
  br label %bb4
bb4:
  %t25 = load ptr, ptr %l13, !tbaa !29
  %t26 = load i32, ptr %l17, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t25, i32 %t26)
  store i32 %t27, ptr %l18
  br label %bb5
bb5:
  %t28 = load i32, ptr %l18, !range !{i32 0, i32 6}
  %t30 = trunc i64 2 to i32
  %t31 = icmp eq i32 %t28, %t30
  %t33 = xor i1 %t31, true
  store i1 %t33, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t35 = load i1, ptr %l11, !tbaa !21
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t36 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t36, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t38 = load i32, ptr %l3, !tbaa !23
  store i32 %t38, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eerrsArg(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca { i64, ptr }
  %l29 = alloca i1
  %l36 = alloca ptr
  %l38 = alloca ptr
  %l40 = alloca { i64, ptr }
  %l41 = alloca i32
  %l42 = alloca i32
  %l44 = alloca i32
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t12, i32 0, i32 1
  %t14 = load { i64, ptr }, ptr %t13
  store { i64, ptr } %t14, ptr %l3, !tbaa !27
  br label %bb5
bb4:
  br label %bb18
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %l15
  br label %bb6
bb6:
  %t17 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %l4
  %t18 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t18, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 0
  store i64 %t22, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  %t24 = load i64, ptr %l6, !tbaa !24
  %t25 = load i64, ptr %l7, !tbaa !24
  %t28 = icmp slt i64 %t24, %t25
  %t30 = xor i1 %t28, true
  br i1 %t30, label %bb8, label %bb9
bb8:
  br label %bb14
bb9:
  br label %bb10
bb10:
  %t32 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t32, ptr %l23, !tbaa !27
  %t33 = load i64, ptr %l6, !tbaa !24
  %t35 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr ptr, ptr %t36, i64 %t33
  %t38 = load ptr, ptr %t37, !tbaa !39
  store ptr %t38, ptr %l8, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t42 = load ptr, ptr %l8, !tbaa !29
  %t46 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorItemKnown(ptr %v0, ptr %v1, ptr %v2, ptr %t40, ptr %t41, ptr %t42)
  store i1 %t46, ptr %l29
  br label %bb11
bb11:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t49 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eerrorSetEntries(ptr %v0, ptr %v1, ptr %v2, ptr %s1, ptr %t47, ptr %t48, ptr %t49, ptr %l4)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t54 = load i64, ptr %l6, !tbaa !24
  %t56 = add i64 %t54, 1
  store i64 %t56, ptr %l6, !tbaa !24
  br label %bb7
bb14:
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l36, !tbaa !29
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 2
  store ptr %t61, ptr %l38, !tbaa !29
  %t63 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %s1, ptr %s1, ptr %l4)
  store { i64, ptr } %t63, ptr %l40
  br label %bb15
bb15:
  %t64 = load ptr, ptr %l38, !tbaa !29
  %t65 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t66 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s1, ptr %t64, { i64, ptr } %t65)
  store i32 %t66, ptr %l41
  br label %bb16
bb16:
  %t67 = load ptr, ptr %l36, !tbaa !29
  %t68 = load i32, ptr %l41, !tbaa !23
  %t69 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrSetOf(ptr %v0, ptr %t67, i32 %t68)
  store i32 %t69, ptr %l42
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s1)
  %t70 = load i32, ptr %l42, !tbaa !23
  store i32 %t70, ptr %rv
  br label %ret
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrSetOf(ptr %v0, ptr %t71, i32 0)
  store i32 %t73, ptr %l44
  br label %bb22
bb22:
  %t74 = load i32, ptr %l44, !tbaa !23
  store i32 %t74, ptr %rv
  br label %ret
bb23:
  call void @__olang_check_failed(ptr @olang_loc_24f0f81fc570bea6_c6e464f22cc6b362)
  unreachable
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eerrsHaveVar(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l10 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l23 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t7 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t3, i32 %a1)
  store { i64, ptr } %t7, ptr %l10
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t21, ptr %l17, !tbaa !27
  %t22 = load i64, ptr %l4, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr i32, ptr %t25, i64 %t22
  %t27 = load i32, ptr %t26, !tbaa !33
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t35 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eisVar(ptr %v0, ptr %v1, ptr %t29, i32 %t27, ptr %a2)
  store i1 %t35, ptr %l23
  br label %bb6
bb6:
  %t36 = load i1, ptr %l23, !tbaa !21
  br i1 %t36, label %bb7, label %bb8
bb7:
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t38 = load i64, ptr %l4, !tbaa !24
  %t40 = add i64 %t38, 1
  store i64 %t40, ptr %l4, !tbaa !24
  br label %bb2
bb11:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/generic:folded" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eeval(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l18 = alloca %"compiler/generic:folded"
  %l19 = alloca ptr
  %l20 = alloca i1
  %l32 = alloca %"compiler/generic:folded"
  %l33 = alloca ptr
  %l34 = alloca i1
  %l42 = alloca %"compiler/generic:folded"
  %l43 = alloca ptr
  %l44 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca ptr
  %l53 = alloca %"compiler/source:Span"
  %l54 = alloca i32
  %l58 = alloca %"compiler/generic:folded"
  %l59 = alloca ptr
  %l60 = alloca i1
  %l71 = alloca %"compiler/generic:folded"
  %l72 = alloca ptr
  %l73 = alloca i1
  %l87 = alloca %"compiler/generic:folded"
  %l88 = alloca ptr
  %l89 = alloca i1
  %l103 = alloca %"compiler/generic:folded"
  %l104 = alloca ptr
  %l105 = alloca i1
  %l116 = alloca %"compiler/generic:folded"
  %l117 = alloca %"compiler/generic:folded"
  %s3 = alloca %olang.scope
  %rv = alloca %"compiler/generic:folded"
  %t90 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t2 = load ptr, ptr %l19, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l19, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l20, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l20, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l3
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19, !range !{i32 0, i32 98}
  store i32 %t20, ptr %l4
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Context", ptr %t23, i32 0, i32 0
  %t26 = load i64, ptr %t25, !tbaa !24
  %t27 = load %"compiler/source:Span", ptr %l3
  %t28 = load i32, ptr %l4, !range !{i32 0, i32 98}
  %t33 = call %"compiler/generic:folded" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eevalLit(ptr %v0, ptr %t22, i64 %t26, %"compiler/source:Span" %t27, i32 %t28)
  store %"compiler/generic:folded" %t33, ptr %l32
  br label %bb6
bb6:
  %t34 = load %"compiler/generic:folded", ptr %l32
  store %"compiler/generic:folded" %t34, ptr %l18
  br label %bb59
bb7:
  %t35 = load ptr, ptr %l2, !tbaa !29
  store ptr %t35, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t36 = load ptr, ptr %l33, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb8, label %bb9
bb8:
  %t39 = load ptr, ptr %l33, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 30}
  %t42 = icmp eq i64 %t40, 2
  store i1 %t42, ptr %l34, !tbaa !21
  br label %bb9
bb9:
  %t43 = load i1, ptr %l34, !tbaa !21
  br i1 %t43, label %bb10, label %bb11
bb10:
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t46 = getelementptr { i64, [4 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", ptr }, ptr %t46, i32 0, i32 1
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l5, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t52 = load ptr, ptr %l5, !tbaa !29
  %t56 = call %"compiler/generic:folded" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eeval(ptr %v0, ptr %v1, ptr %v2, ptr %t50, ptr %t51, ptr %t52)
  store %"compiler/generic:folded" %t56, ptr %l42
  br label %bb13
bb13:
  %t57 = load %"compiler/generic:folded", ptr %l42
  store %"compiler/generic:folded" %t57, ptr %l18
  br label %bb59
bb14:
  %t58 = load ptr, ptr %l2, !tbaa !29
  store ptr %t58, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t59 = load ptr, ptr %l43, !tbaa !29
  %t60 = icmp ne ptr %t59, null
  br i1 %t60, label %bb15, label %bb16
bb15:
  %t62 = load ptr, ptr %l43, !tbaa !29
  %t63 = load i64, ptr %t62, !range !{i64 0, i64 30}
  %t65 = icmp eq i64 %t63, 0
  store i1 %t65, ptr %l44, !tbaa !21
  br label %bb16
bb16:
  %t66 = load i1, ptr %l44, !tbaa !21
  br i1 %t66, label %bb17, label %bb18
bb17:
  %t67 = load ptr, ptr %l2, !tbaa !29
  %t69 = getelementptr { i64, [4 x i64] }, ptr %t67, i32 0, i32 1
  %t70 = getelementptr { %"compiler/source:Span", i32 }, ptr %t69, i32 0, i32 0
  %t71 = load %"compiler/source:Span", ptr %t70
  store %"compiler/source:Span" %t71, ptr %l6
  %t73 = load ptr, ptr %l2, !tbaa !29
  %t75 = getelementptr { i64, [4 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", i32 }, ptr %t75, i32 0, i32 1
  %t77 = load i32, ptr %t76
  store i32 %t77, ptr %l7, !tbaa !23
  br label %bb19
bb18:
  br label %bb25
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l51, !tbaa !29
  %t80 = load ptr, ptr %l1, !tbaa !29
  store ptr %t80, ptr %l52, !tbaa !29
  %t81 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t81, ptr %l53
  %t82 = load i32, ptr %l7, !tbaa !23
  store i32 %t82, ptr %l54, !tbaa !23
  %t83 = icmp sge i64 1, 0
  br i1 %t83, label %bb20, label %bb21
bb20:
  %t85 = icmp sle i64 1, 2305843009213693951
  br i1 %t85, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_3e60b6dd6ea07633_1a37389903bcd17)
  unreachable
bb22:
  %t87 = mul i64 1, 4
  %t88 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t87)
  %t89 = load i32, ptr %l54, !tbaa !23
  store i64 0, ptr %t90
  br label %fill.91
fill.91:
  %t94 = load i64, ptr %t90
  %t95 = icmp slt i64 %t94, 1
  br i1 %t95, label %fillb.92, label %filld.93
fillb.92:
  %t96 = getelementptr i32, ptr %t88, i64 %t94
  store i32 %t89, ptr %t96
  %t97 = add i64 %t94, 1
  store i64 %t97, ptr %t90
  br label %fill.91
filld.93:
  %t98 = insertvalue { i64, ptr } undef, i64 1, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t88, 1
  %t100 = load ptr, ptr %l51, !tbaa !29
  %t101 = load ptr, ptr %l52, !tbaa !29
  %t102 = load %"compiler/source:Span", ptr %l53
  %t104 = call %"compiler/generic:folded" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2efoldPath(ptr %v0, ptr %v1, ptr %s3, ptr %t100, ptr %t101, %"compiler/source:Span" %t102, { i64, ptr } %t99)
  store %"compiler/generic:folded" %t104, ptr %l58
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_3e60b6dd6ea07633_1a37389903bcd17)
  unreachable
bb24:
  %t105 = load %"compiler/generic:folded", ptr %l58
  store %"compiler/generic:folded" %t105, ptr %l18
  call void @__olang_scope_close(ptr %s3)
  br label %bb59
bb25:
  %t106 = load ptr, ptr %l2, !tbaa !29
  store ptr %t106, ptr %l59, !tbaa !29
  store i1 false, ptr %l60, !tbaa !21
  %t107 = load ptr, ptr %l59, !tbaa !29
  %t108 = icmp ne ptr %t107, null
  br i1 %t108, label %bb26, label %bb27
bb26:
  %t110 = load ptr, ptr %l59, !tbaa !29
  %t111 = load i64, ptr %t110, !range !{i64 0, i64 30}
  %t113 = icmp eq i64 %t111, 3
  store i1 %t113, ptr %l60, !tbaa !21
  br label %bb27
bb27:
  %t114 = load i1, ptr %l60, !tbaa !21
  br i1 %t114, label %bb28, label %bb29
bb28:
  %t115 = load ptr, ptr %l2, !tbaa !29
  %t117 = getelementptr { i64, [4 x i64] }, ptr %t115, i32 0, i32 1
  %t118 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t117, i32 0, i32 1
  %t119 = load i32, ptr %t118, !range !{i32 0, i32 98}
  store i32 %t119, ptr %l8
  %t121 = load ptr, ptr %l2, !tbaa !29
  %t123 = getelementptr { i64, [4 x i64] }, ptr %t121, i32 0, i32 1
  %t124 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t123, i32 0, i32 2
  %t125 = load ptr, ptr %t124
  store ptr %t125, ptr %l9, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load ptr, ptr %l1, !tbaa !29
  %t129 = load i32, ptr %l8, !range !{i32 0, i32 98}
  %t130 = load ptr, ptr %l9, !tbaa !29
  %t135 = call %"compiler/generic:folded" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eevalUnary(ptr %v0, ptr %v1, ptr %v2, ptr %t127, ptr %t128, i32 %t129, ptr %t130)
  store %"compiler/generic:folded" %t135, ptr %l71
  br label %bb31
bb31:
  %t136 = load %"compiler/generic:folded", ptr %l71
  store %"compiler/generic:folded" %t136, ptr %l18
  br label %bb59
bb32:
  %t137 = load ptr, ptr %l2, !tbaa !29
  store ptr %t137, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t138 = load ptr, ptr %l72, !tbaa !29
  %t139 = icmp ne ptr %t138, null
  br i1 %t139, label %bb33, label %bb34
bb33:
  %t141 = load ptr, ptr %l72, !tbaa !29
  %t142 = load i64, ptr %t141, !range !{i64 0, i64 30}
  %t144 = icmp eq i64 %t142, 5
  store i1 %t144, ptr %l73, !tbaa !21
  br label %bb34
bb34:
  %t145 = load i1, ptr %l73, !tbaa !21
  br i1 %t145, label %bb35, label %bb36
bb35:
  %t146 = load ptr, ptr %l2, !tbaa !29
  %t148 = getelementptr { i64, [4 x i64] }, ptr %t146, i32 0, i32 1
  %t149 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t148, i32 0, i32 1
  %t150 = load i32, ptr %t149, !range !{i32 0, i32 98}
  store i32 %t150, ptr %l10
  %t152 = load ptr, ptr %l2, !tbaa !29
  %t154 = getelementptr { i64, [4 x i64] }, ptr %t152, i32 0, i32 1
  %t155 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t154, i32 0, i32 2
  %t156 = load ptr, ptr %t155
  store ptr %t156, ptr %l11, !tbaa !29
  %t158 = load ptr, ptr %l2, !tbaa !29
  %t160 = getelementptr { i64, [4 x i64] }, ptr %t158, i32 0, i32 1
  %t161 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t160, i32 0, i32 3
  %t162 = load ptr, ptr %t161
  store ptr %t162, ptr %l12, !tbaa !29
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load ptr, ptr %l1, !tbaa !29
  %t166 = load i32, ptr %l10, !range !{i32 0, i32 98}
  %t167 = load ptr, ptr %l11, !tbaa !29
  %t168 = load ptr, ptr %l12, !tbaa !29
  %t174 = call %"compiler/generic:folded" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eevalBinary(ptr %v0, ptr %v1, ptr %v2, ptr %v2, ptr %t164, ptr %t165, i32 %t166, ptr %t167, ptr %t168)
  store %"compiler/generic:folded" %t174, ptr %l87
  br label %bb38
bb38:
  %t175 = load %"compiler/generic:folded", ptr %l87
  store %"compiler/generic:folded" %t175, ptr %l18
  br label %bb59
bb39:
  %t176 = load ptr, ptr %l2, !tbaa !29
  store ptr %t176, ptr %l88, !tbaa !29
  store i1 false, ptr %l89, !tbaa !21
  %t177 = load ptr, ptr %l88, !tbaa !29
  %t178 = icmp ne ptr %t177, null
  br i1 %t178, label %bb40, label %bb41
bb40:
  %t180 = load ptr, ptr %l88, !tbaa !29
  %t181 = load i64, ptr %t180, !range !{i64 0, i64 30}
  %t183 = icmp eq i64 %t181, 8
  store i1 %t183, ptr %l89, !tbaa !21
  br label %bb41
bb41:
  %t184 = load i1, ptr %l89, !tbaa !21
  br i1 %t184, label %bb42, label %bb43
bb42:
  %t185 = load ptr, ptr %l2, !tbaa !29
  %t187 = getelementptr { i64, [4 x i64] }, ptr %t185, i32 0, i32 1
  %t188 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t187, i32 0, i32 1
  %t189 = load ptr, ptr %t188
  store ptr %t189, ptr %l13, !tbaa !29
  %t191 = load ptr, ptr %l2, !tbaa !29
  %t193 = getelementptr { i64, [4 x i64] }, ptr %t191, i32 0, i32 1
  %t194 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t193, i32 0, i32 2
  %t195 = load ptr, ptr %t194
  store ptr %t195, ptr %l14, !tbaa !29
  %t197 = load ptr, ptr %l2, !tbaa !29
  %t199 = getelementptr { i64, [4 x i64] }, ptr %t197, i32 0, i32 1
  %t200 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t199, i32 0, i32 3
  %t201 = load ptr, ptr %t200
  store ptr %t201, ptr %l15, !tbaa !29
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load ptr, ptr %l1, !tbaa !29
  %t205 = load ptr, ptr %l13, !tbaa !29
  %t206 = load ptr, ptr %l14, !tbaa !29
  %t207 = load ptr, ptr %l15, !tbaa !29
  %t213 = call %"compiler/generic:folded" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eevalCond(ptr %v0, ptr %v1, ptr %v2, ptr %v2, ptr %v2, ptr %t203, ptr %t204, ptr %t205, ptr %t206, ptr %t207)
  store %"compiler/generic:folded" %t213, ptr %l103
  br label %bb45
bb45:
  %t214 = load %"compiler/generic:folded", ptr %l103
  store %"compiler/generic:folded" %t214, ptr %l18
  br label %bb59
bb46:
  %t215 = load ptr, ptr %l2, !tbaa !29
  store ptr %t215, ptr %l104, !tbaa !29
  store i1 false, ptr %l105, !tbaa !21
  %t216 = load ptr, ptr %l104, !tbaa !29
  %t217 = icmp ne ptr %t216, null
  br i1 %t217, label %bb47, label %bb48
bb47:
  %t219 = load ptr, ptr %l104, !tbaa !29
  %t220 = load i64, ptr %t219, !range !{i64 0, i64 30}
  %t222 = icmp eq i64 %t220, 12
  store i1 %t222, ptr %l105, !tbaa !21
  br label %bb48
bb48:
  %t223 = load i1, ptr %l105, !tbaa !21
  br i1 %t223, label %bb49, label %bb50
bb49:
  %t224 = load ptr, ptr %l2, !tbaa !29
  %t226 = getelementptr { i64, [4 x i64] }, ptr %t224, i32 0, i32 1
  %t227 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t226, i32 0, i32 1
  %t228 = load ptr, ptr %t227
  store ptr %t228, ptr %l16, !tbaa !29
  %t230 = load ptr, ptr %l2, !tbaa !29
  %t232 = getelementptr { i64, [4 x i64] }, ptr %t230, i32 0, i32 1
  %t233 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t232, i32 0, i32 2
  %t234 = load { i64, ptr }, ptr %t233
  store { i64, ptr } %t234, ptr %l17, !tbaa !27
  br label %bb51
bb50:
  br label %bb53
bb51:
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t237 = load ptr, ptr %l1, !tbaa !29
  %t238 = load ptr, ptr %l16, !tbaa !29
  %t239 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t244 = call %"compiler/generic:folded" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eevalCall(ptr %v0, ptr %v1, ptr %v2, ptr %v2, ptr %t236, ptr %t237, ptr %t238, { i64, ptr } %t239)
  store %"compiler/generic:folded" %t244, ptr %l116
  br label %bb52
bb52:
  %t245 = load %"compiler/generic:folded", ptr %l116
  store %"compiler/generic:folded" %t245, ptr %l18
  br label %bb59
bb53:
  br i1 true, label %bb54, label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb58
bb56:
  %t246 = call %"compiler/generic:folded" @compiler_2fgeneric_2eunfolded()
  store %"compiler/generic:folded" %t246, ptr %l117
  br label %bb57
bb57:
  %t247 = load %"compiler/generic:folded", ptr %l117
  store %"compiler/generic:folded" %t247, ptr %l18
  br label %bb59
bb58:
  call void @__olang_check_failed(ptr @olang_loc_df0c974aeea04fc5_d4c449c0d39b6971)
  unreachable
bb59:
  %t248 = load %"compiler/generic:folded", ptr %l18
  store %"compiler/generic:folded" %t248, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/generic:folded", ptr %rv
  ret %"compiler/generic:folded" %rr
}

define dso_local %"compiler/generic:folded" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eevalCond(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l5 = alloca %"compiler/generic:folded"
  %l9 = alloca %"compiler/generic:folded"
  %l16 = alloca %"compiler/generic:folded"
  %l20 = alloca %"compiler/generic:folded"
  %l24 = alloca %"compiler/generic:folded"
  %rv = alloca %"compiler/generic:folded"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t7 = call %"compiler/generic:folded" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eeval(ptr %v0, ptr %v1, ptr %v3, ptr %t1, ptr %t2, ptr %a3)
  store %"compiler/generic:folded" %t7, ptr %l9
  br label %bb1
bb1:
  %t8 = load %"compiler/generic:folded", ptr %l9
  store %"compiler/generic:folded" %t8, ptr %l5
  %t9 = getelementptr %"compiler/generic:folded", ptr %l5, i32 0, i32 0
  %t10 = load i64, ptr %t9, !tbaa !24
  %t11 = load i64, ptr @G_2ecompiler_2fgeneric_2eFolded, !tbaa !24
  %t14 = icmp ne i64 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load %"compiler/generic:folded", ptr %l5
  store %"compiler/generic:folded" %t16, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t18 = getelementptr %"compiler/generic:folded", ptr %l5, i32 0, i32 1
  %t19 = load i64, ptr %t18, !tbaa !24
  %t21 = icmp ne i64 %t19, 0
  br i1 %t21, label %bb5, label %bb6
bb5:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t29 = call %"compiler/generic:folded" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eeval(ptr %v0, ptr %v1, ptr %v2, ptr %t23, ptr %t24, ptr %a2)
  store %"compiler/generic:folded" %t29, ptr %l20
  br label %bb7
bb6:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t36 = call %"compiler/generic:folded" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eeval(ptr %v0, ptr %v1, ptr %v4, ptr %t30, ptr %t31, ptr %a4)
  store %"compiler/generic:folded" %t36, ptr %l24
  br label %bb8
bb7:
  %t37 = load %"compiler/generic:folded", ptr %l20
  store %"compiler/generic:folded" %t37, ptr %l16
  br label %bb9
bb8:
  %t38 = load %"compiler/generic:folded", ptr %l24
  store %"compiler/generic:folded" %t38, ptr %l16
  br label %bb9
bb9:
  %t39 = load %"compiler/generic:folded", ptr %l16
  store %"compiler/generic:folded" %t39, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/generic:folded", ptr %rv
  ret %"compiler/generic:folded" %rr
}

define dso_local %"compiler/generic:folded" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eevalLit(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i32
  %l26 = alloca i64
  %l27 = alloca i32
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i32
  %l32 = alloca i64
  %l33 = alloca i32
  %l34 = alloca %"compiler/generic:folded"
  %l35 = alloca i64
  %l37 = alloca i64
  %l40 = alloca i32
  %l41 = alloca %"compiler/generic:folded"
  %l45 = alloca %"compiler/generic:folded"
  %l48 = alloca i64
  %l50 = alloca i1
  %l51 = alloca i64
  %l53 = alloca %"compiler/generic:folded"
  %l54 = alloca %"compiler/generic:folded"
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca %"compiler/generic:folded"
  store ptr %a0, ptr %l0
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/load:Loader", ptr %t4, i32 0, i32 10
  %t10 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t6, i64 %a1)
  store ptr %t10, ptr %l12
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l12, !tbaa !29
  %t13 = getelementptr %"compiler/load:Module", ptr %t11, i32 0, i32 6
  %t14 = load ptr, ptr %t13, !tbaa !29
  store ptr %t14, ptr %l4, !tbaa !29
  %t16 = load ptr, ptr %l4, !tbaa !29
  %t18 = icmp eq ptr %t16, null
  br i1 %t18, label %bb2, label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_886433b88e29f460_704fa105f63225d4)
  unreachable
bb3:
  br label %bb4
bb4:
  %t20 = load ptr, ptr %l4, !tbaa !29
  %t24 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aSource_2eTextOf(ptr %v0, ptr %v0, ptr %t20, %"compiler/source:Span" %a2)
  store { i64, ptr } %t24, ptr %l19
  br label %bb5
bb5:
  %t25 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t25, ptr %l5, !tbaa !27
  %t26 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t28 = trunc i64 2 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb25
bb8:
  store %olang.scope zeroinitializer, ptr %s1
  %t31 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t31, ptr %l23, !tbaa !27
  %t32 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s1, i64 0)
  %t33 = extractvalue { i32, i64 } %t32, 1
  %t34 = extractvalue { i32, i64 } %t32, 0
  store i32 %t34, ptr %l25
  %t35 = icmp ne i32 %t34, 0
  br i1 %t35, label %bb10, label %ok.36, !prof !99
ok.36:
  store i64 %t33, ptr %l24
  br label %bb9
bb9:
  %t37 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %t37, i64 %t38)
  %t40 = extractvalue { i32, i64 } %t39, 1
  %t41 = extractvalue { i32, i64 } %t39, 0
  store i32 %t41, ptr %l27
  %t42 = icmp ne i32 %t41, 0
  br i1 %t42, label %bb13, label %ok.43, !prof !99
ok.43:
  store i64 %t40, ptr %l26
  br label %bb12
bb10:
  br label %bb11
bb11:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s2
  %t44 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t44, ptr %l29, !tbaa !27
  %t45 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s2, i64 0)
  %t46 = extractvalue { i32, i64 } %t45, 1
  %t47 = extractvalue { i32, i64 } %t45, 0
  store i32 %t47, ptr %l31
  %t48 = icmp ne i32 %t47, 0
  br i1 %t48, label %bb15, label %ok.49, !prof !99
ok.49:
  store i64 %t46, ptr %l30
  br label %bb14
bb12:
  %t50 = load i64, ptr %l26, !tbaa !24
  store i64 %t50, ptr %l22, !tbaa !24
  br label %bb23
bb13:
  br label %bb11
bb14:
  %t51 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t52 = load i64, ptr %l30, !tbaa !24
  %t53 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseUint(ptr %v0, { i64, ptr } %t51, i64 %t52)
  %t54 = extractvalue { i32, i64 } %t53, 1
  %t55 = extractvalue { i32, i64 } %t53, 0
  store i32 %t55, ptr %l33
  %t56 = icmp ne i32 %t55, 0
  br i1 %t56, label %bb18, label %ok.57, !prof !99
ok.57:
  store i64 %t54, ptr %l32
  br label %bb17
bb15:
  br label %bb16
bb16:
  call void @__olang_ert_req_clear()
  %t58 = call %"compiler/generic:folded" @compiler_2fgeneric_2eunfolded()
  store %"compiler/generic:folded" %t58, ptr %l34
  br label %bb19
bb17:
  %t59 = load i64, ptr %l32, !tbaa !65
  store i64 %t59, ptr %l28, !tbaa !65
  br label %bb20
bb18:
  br label %bb16
bb19:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  %t60 = load %"compiler/generic:folded", ptr %l34
  store %"compiler/generic:folded" %t60, ptr %rv
  br label %ret
bb20:
  %t61 = load i64, ptr %l28, !tbaa !65
  %t62 = load i64, ptr @G_2ecompiler_2fgeneric_2eFolded, !tbaa !24
  store i64 %t62, ptr %l35, !tbaa !24
  store i64 %t61, ptr %l37, !tbaa !24
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 2
  %t69 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s2, ptr %t67, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d35, i32 0, i32 1) })
  store i32 %t69, ptr %l40
  br label %bb21
bb21:
  %t70 = load i64, ptr %l35, !tbaa !24
  %t71 = load i64, ptr %l37, !tbaa !24
  %t72 = load i32, ptr %l40, !tbaa !23
  %t73 = call %"compiler/generic:folded" @compiler_2fgeneric_3afolded_2ector(ptr %s2, i64 %t70, i64 %t71, i32 %t72)
  store %"compiler/generic:folded" %t73, ptr %l41
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  %t74 = load %"compiler/generic:folded", ptr %l41
  store %"compiler/generic:folded" %t74, ptr %rv
  br label %ret
bb23:
  %t75 = load i64, ptr %l22, !tbaa !24
  %t76 = load i64, ptr @G_2ecompiler_2fgeneric_2eFolded, !tbaa !24
  %t78 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t82 = call %"compiler/generic:folded" @compiler_2fgeneric_3afolded_2ector(ptr %s1, i64 %t76, i64 %t75, i32 %t78)
  store %"compiler/generic:folded" %t82, ptr %l45
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s1)
  %t83 = load %"compiler/generic:folded", ptr %l45
  store %"compiler/generic:folded" %t83, ptr %rv
  br label %ret
bb25:
  %t84 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t86 = trunc i64 6 to i32
  %t87 = icmp eq i32 %t84, %t86
  br i1 %t87, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb34
bb28:
  store %olang.scope zeroinitializer, ptr %s4
  %t89 = load i64, ptr @G_2ecompiler_2fgeneric_2eFolded, !tbaa !24
  store i64 %t89, ptr %l48, !tbaa !24
  %t90 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t92 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s4, { i64, ptr } %t90, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d36, i32 0, i32 1) })
  store i1 %t92, ptr %l50
  br label %bb29
bb29:
  %t93 = load i1, ptr %l50, !tbaa !21
  br i1 %t93, label %bb30, label %bb31
bb30:
  store i64 1, ptr %l51, !tbaa !24
  br label %bb32
bb31:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb32
bb32:
  %t94 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t95 = load i64, ptr %l48, !tbaa !24
  %t96 = load i64, ptr %l51, !tbaa !24
  %t98 = call %"compiler/generic:folded" @compiler_2fgeneric_3afolded_2ector(ptr %s4, i64 %t95, i64 %t96, i32 %t94)
  store %"compiler/generic:folded" %t98, ptr %l53
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s4)
  %t99 = load %"compiler/generic:folded", ptr %l53
  store %"compiler/generic:folded" %t99, ptr %rv
  br label %ret
bb34:
  br i1 true, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t100 = call %"compiler/generic:folded" @compiler_2fgeneric_2eunfolded()
  store %"compiler/generic:folded" %t100, ptr %l54
  br label %bb38
bb38:
  %t101 = load %"compiler/generic:folded", ptr %l54
  store %"compiler/generic:folded" %t101, ptr %rv
  br label %ret
bb39:
  call void @__olang_check_failed(ptr @olang_loc_cbe34de7626751c6_f090548a7d71387a)
  unreachable
ret:
  %rr = load %"compiler/generic:folded", ptr %rv
  ret %"compiler/generic:folded" %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eextends(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l5 = alloca ptr
  %l9 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etypeDecl(ptr %v0, ptr %v0, ptr %a0, i32 %a1)
  store ptr %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l5, !tbaa !29
  store ptr %t6, ptr %l2, !tbaa !29
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t15 = getelementptr %"compiler/ast:TypeDecl", ptr %t13, i32 0, i32 2
  %t16 = load i1, ptr %t15, !tbaa !21
  store i1 %t16, ptr %l9, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l9, !tbaa !21
  store i1 %t18, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2efile(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l6 = alloca ptr
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/generic:Program", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/load:Loader", ptr %t4, i32 0, i32 10
  %t10 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t6, i64 %a1)
  store ptr %t10, ptr %l6
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l6, !tbaa !29
  %t13 = getelementptr %"compiler/load:Module", ptr %t11, i32 0, i32 4
  %t14 = load i64, ptr %t13, !tbaa !24
  store i64 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eflagBans(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l34 = alloca i64
  %l37 = alloca i64
  %l59 = alloca i1
  %l67 = alloca ptr
  %l68 = alloca ptr
  %l70 = alloca i64
  %l72 = alloca { i64, ptr }
  %l75 = alloca %"compiler/source:Span"
  %l76 = alloca { i64, [3 x i64] }
  %l77 = alloca %"compiler/msgs:Msg"
  %l78 = alloca i64
  %l84 = alloca i1
  %l89 = alloca ptr
  %l93 = alloca i32
  %l94 = alloca { i64, ptr }
  %l96 = alloca i64
  %l103 = alloca i64
  %l106 = alloca i64
  %l132 = alloca i1
  %l135 = alloca { i64, ptr }
  %l138 = alloca i1
  %l140 = alloca i1
  %l143 = alloca { i64, ptr }
  %l146 = alloca i64
  %l151 = alloca { i64, ptr }
  %l156 = alloca ptr
  %l162 = alloca { i64, [3 x i64] }
  %l166 = alloca { i64, ptr }
  %l167 = alloca { i64, ptr }
  %l169 = alloca %"compiler/msgs:Msg"
  %l170 = alloca i64
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l3, !tbaa !23
  %t7 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s0, ptr %t3, i32 %t4)
  store { i64, ptr } %t7, ptr %l25
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t8, ptr %l5, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  %t13 = icmp sgt i64 %t11, 1
  br i1 %t13, label %bb2, label %bb3
bb2:
  store i64 0, ptr %l6, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  store i64 %t17, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t19 = load i64, ptr %l7, !tbaa !24
  %t20 = load i64, ptr %l6, !tbaa !24
  %t23 = icmp sgt i64 %t19, %t20
  br i1 %t23, label %bb4, label %bb5
bb3:
  br label %bb26
bb4:
  %t25 = load i64, ptr %l8, !tbaa !24
  %t27 = icmp sgt i64 %t25, 0
  br i1 %t27, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb9
bb6:
  %t29 = load i64, ptr %l7, !tbaa !24
  %t30 = load i64, ptr %l6, !tbaa !24
  %t33 = sub i64 %t29, %t30
  %t34 = load i64, ptr %l8, !tbaa !24
  %t37 = add i64 %t33, %t34
  %t39 = sub i64 %t37, 1
  %t40 = load i64, ptr %l8, !tbaa !24
  %t43 = sdiv i64 %t39, %t40
  store i64 %t43, ptr %l37, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb8
bb8:
  %t45 = load i64, ptr %l37, !tbaa !24
  store i64 %t45, ptr %l34, !tbaa !24
  br label %bb9
bb9:
  %t46 = load i64, ptr %l34, !tbaa !24
  store i64 %t46, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb10
bb10:
  %t47 = load i64, ptr %l10, !tbaa !24
  %t48 = load i64, ptr %l9, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb11, label %bb12
bb11:
  br label %bb25
bb12:
  br label %bb13
bb13:
  %t55 = load i64, ptr %l6, !tbaa !24
  %t56 = load i64, ptr %l10, !tbaa !24
  %t57 = load i64, ptr %l8, !tbaa !24
  %t60 = mul i64 %t56, %t57
  %t63 = add i64 %t55, %t60
  store i64 %t63, ptr %l11, !tbaa !24
  %t65 = load i64, ptr %l11, !tbaa !24
  %t67 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = getelementptr i32, ptr %t68, i64 %t65
  %t70 = load i32, ptr %t69, !tbaa !33
  %t71 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t74 = icmp eq i32 %t70, %t71
  br i1 %t74, label %bb14, label %bb15
bb14:
  %t76 = load i64, ptr %l11, !tbaa !24
  %t77 = load ptr, ptr %l2, !tbaa !29
  %t79 = getelementptr %"compiler/ast:Sig", ptr %t77, i32 0, i32 1
  %t80 = load { i64, ptr }, ptr %t79, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t85 = icmp slt i64 %t76, %t82
  store i1 %t85, ptr %l59, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb16
bb16:
  %t87 = load i1, ptr %l59, !tbaa !21
  br i1 %t87, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s4
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/generic:Program", ptr %t88, i32 0, i32 0
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t93 = getelementptr %"compiler/load:Loader", ptr %t91, i32 0, i32 4
  %t94 = load ptr, ptr %t93, !tbaa !29
  store ptr %t94, ptr %l67, !tbaa !29
  %t95 = load ptr, ptr %l0, !tbaa !29
  store ptr %t95, ptr %l68, !tbaa !29
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t98 = getelementptr %"compiler/generic:Context", ptr %t96, i32 0, i32 0
  %t99 = load i64, ptr %t98, !tbaa !24
  store i64 %t99, ptr %l70, !tbaa !24
  %t100 = load ptr, ptr %l2, !tbaa !29
  %t102 = getelementptr %"compiler/ast:Sig", ptr %t100, i32 0, i32 1
  %t103 = load { i64, ptr }, ptr %t102, !tbaa !27
  store { i64, ptr } %t103, ptr %l72, !tbaa !27
  %t104 = load i64, ptr %l11, !tbaa !24
  %t106 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = getelementptr ptr, ptr %t107, i64 %t104
  %t109 = load ptr, ptr %t108, !tbaa !39
  %t111 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v2, ptr %t109)
  store %"compiler/source:Span" %t111, ptr %l75
  br label %bb19
bb18:
  br label %bb23
bb19:
  %t112 = load ptr, ptr %l68, !tbaa !29
  %t113 = load i64, ptr %l70, !tbaa !24
  %t114 = load %"compiler/source:Span", ptr %l75
  %t115 = call { i64, [3 x i64] } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eat(ptr %v0, ptr %t112, i64 %t113, %"compiler/source:Span" %t114)
  store { i64, [3 x i64] } %t115, ptr %l76
  br label %bb20
bb20:
  %t116 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eFlagAmongResults(ptr %s4)
  store %"compiler/msgs:Msg" %t116, ptr %l77
  br label %bb21
bb21:
  %t117 = load ptr, ptr %l67, !tbaa !29
  %t118 = load { i64, [3 x i64] }, ptr %l76
  %t119 = load %"compiler/msgs:Msg", ptr %l77
  %t120 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorOncePerLine(ptr %v0, ptr %s4, ptr %t117, { i64, [3 x i64] } %t118, %"compiler/msgs:Msg" %t119)
  store i64 %t120, ptr %l78
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t121 = load i64, ptr %l10, !tbaa !24
  %t123 = add i64 %t121, 1
  store i64 %t123, ptr %l10, !tbaa !24
  br label %bb10
bb25:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb26:
  %t125 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t125, 0
  %t129 = icmp ne i64 %t127, 1
  br i1 %t129, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l84, !tbaa !21
  br label %bb29
bb28:
  %t131 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr i32, ptr %t132, i64 0
  %t134 = load i32, ptr %t133, !tbaa !33
  %t135 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t138 = icmp ne i32 %t134, %t135
  store i1 %t138, ptr %l84, !tbaa !21
  br label %bb29
bb29:
  %t140 = load i1, ptr %l84, !tbaa !21
  br i1 %t140, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb31:
  br label %bb32
bb32:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/generic:Program", ptr %t141, i32 0, i32 2
  store ptr %t143, ptr %l89, !tbaa !29
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/generic:Program", ptr %t144, i32 0, i32 2
  %t147 = load i32, ptr %l3, !tbaa !23
  %t150 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t146, i32 %t147)
  store i32 %t150, ptr %l93
  br label %bb33
bb33:
  %t151 = load ptr, ptr %l89, !tbaa !29
  %t152 = load i32, ptr %l93, !tbaa !23
  %t153 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t151, i32 %t152)
  store { i64, ptr } %t153, ptr %l94
  br label %bb34
bb34:
  %t154 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t154, ptr %l12, !tbaa !27
  br i1 %a4, label %bb35, label %bb36
bb35:
  store i64 1, ptr %l96, !tbaa !24
  br label %bb37
bb36:
  store i64 0, ptr %l96, !tbaa !24
  br label %bb37
bb37:
  %t157 = load i64, ptr %l96, !tbaa !24
  store i64 %t157, ptr %l13, !tbaa !24
  %t158 = load i64, ptr %l13, !tbaa !24
  store i64 %t158, ptr %l14, !tbaa !24
  %t160 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t162 = extractvalue { i64, ptr } %t160, 0
  store i64 %t162, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t164 = load i64, ptr %l15, !tbaa !24
  %t165 = load i64, ptr %l14, !tbaa !24
  %t168 = icmp sgt i64 %t164, %t165
  br i1 %t168, label %bb38, label %bb39
bb38:
  %t170 = load i64, ptr %l16, !tbaa !24
  %t172 = icmp sgt i64 %t170, 0
  br i1 %t172, label %bb40, label %bb41
bb39:
  store i64 0, ptr %l103, !tbaa !24
  br label %bb43
bb40:
  %t174 = load i64, ptr %l15, !tbaa !24
  %t175 = load i64, ptr %l14, !tbaa !24
  %t178 = sub i64 %t174, %t175
  %t179 = load i64, ptr %l16, !tbaa !24
  %t182 = add i64 %t178, %t179
  %t184 = sub i64 %t182, 1
  %t185 = load i64, ptr %l16, !tbaa !24
  %t188 = sdiv i64 %t184, %t185
  store i64 %t188, ptr %l106, !tbaa !24
  br label %bb42
bb41:
  store i64 0, ptr %l106, !tbaa !24
  br label %bb42
bb42:
  %t190 = load i64, ptr %l106, !tbaa !24
  store i64 %t190, ptr %l103, !tbaa !24
  br label %bb43
bb43:
  %t191 = load i64, ptr %l103, !tbaa !24
  store i64 %t191, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb44
bb44:
  store %olang.scope zeroinitializer, ptr %s8
  %t192 = load i64, ptr %l18, !tbaa !24
  %t193 = load i64, ptr %l17, !tbaa !24
  %t196 = icmp slt i64 %t192, %t193
  %t198 = xor i1 %t196, true
  br i1 %t198, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s8)
  br label %bb65
bb46:
  br label %bb47
bb47:
  %t200 = load i64, ptr %l14, !tbaa !24
  %t201 = load i64, ptr %l18, !tbaa !24
  %t202 = load i64, ptr %l16, !tbaa !24
  %t205 = mul i64 %t201, %t202
  %t208 = add i64 %t200, %t205
  store i64 %t208, ptr %l19, !tbaa !24
  %t210 = load i64, ptr %l19, !tbaa !24
  %t211 = load i64, ptr %l13, !tbaa !24
  %t214 = sub i64 %t210, %t211
  store i64 %t214, ptr %l20, !tbaa !24
  %t216 = load i64, ptr %l20, !tbaa !24
  %t217 = load ptr, ptr %l2, !tbaa !29
  %t219 = getelementptr %"compiler/ast:Sig", ptr %t217, i32 0, i32 0
  %t220 = load { i64, ptr }, ptr %t219, !tbaa !27
  %t222 = extractvalue { i64, ptr } %t220, 0
  %t225 = icmp sge i64 %t216, %t222
  br i1 %t225, label %bb48, label %bb49
bb48:
  store i1 true, ptr %l132, !tbaa !21
  br label %bb51
bb49:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t229 = getelementptr %"compiler/generic:Program", ptr %t227, i32 0, i32 2
  %t230 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t230, ptr %l135, !tbaa !27
  %t231 = load i64, ptr %l19, !tbaa !24
  %t233 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t234 = load ptr, ptr %t233, !tbaa !27
  %t235 = getelementptr i32, ptr %t234, i64 %t231
  %t236 = load i32, ptr %t235, !tbaa !33
  %t239 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t229, i32 %t236)
  store i1 %t239, ptr %l138
  br label %bb50
bb50:
  %t240 = load i1, ptr %l138, !tbaa !21
  %t241 = xor i1 %t240, true
  store i1 %t241, ptr %l132, !tbaa !21
  br label %bb51
bb51:
  %t243 = load i1, ptr %l132, !tbaa !21
  br i1 %t243, label %bb52, label %bb53
bb52:
  store i1 true, ptr %l140, !tbaa !21
  br label %bb55
bb53:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = getelementptr %"compiler/generic:Program", ptr %t244, i32 0, i32 2
  %t247 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t247, ptr %l143, !tbaa !27
  %t248 = load i64, ptr %l19, !tbaa !24
  %t250 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t251 = load ptr, ptr %t250, !tbaa !27
  %t252 = getelementptr i32, ptr %t251, i64 %t248
  %t253 = load i32, ptr %t252, !tbaa !33
  %t256 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t246, i32 %t253)
  store i64 %t256, ptr %l146
  br label %bb54
bb54:
  %t257 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t258 = load i64, ptr %l146, !tbaa !24
  %t260 = and i64 %t258, %t257
  %t262 = icmp eq i64 %t260, 0
  store i1 %t262, ptr %l140, !tbaa !21
  br label %bb55
bb55:
  %t264 = load i1, ptr %l140, !tbaa !21
  br i1 %t264, label %bb56, label %bb57
bb56:
  call void @__olang_scope_close(ptr %s8)
  br label %bb64
bb57:
  br label %bb58
bb58:
  %t265 = load ptr, ptr %l2, !tbaa !29
  %t267 = getelementptr %"compiler/ast:Sig", ptr %t265, i32 0, i32 0
  %t268 = load { i64, ptr }, ptr %t267, !tbaa !27
  store { i64, ptr } %t268, ptr %l151, !tbaa !27
  %t269 = load i64, ptr %l20, !tbaa !24
  %t271 = getelementptr { i64, ptr }, ptr %l151, i32 0, i32 1
  %t272 = load ptr, ptr %t271, !tbaa !27
  %t273 = getelementptr ptr, ptr %t272, i64 %t269
  %t274 = load ptr, ptr %t273, !tbaa !39
  store ptr %t274, ptr %l21, !tbaa !29
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t278 = getelementptr %"compiler/generic:Program", ptr %t276, i32 0, i32 0
  %t279 = load ptr, ptr %t278, !tbaa !29
  %t281 = getelementptr %"compiler/load:Loader", ptr %t279, i32 0, i32 4
  %t282 = load ptr, ptr %t281, !tbaa !29
  store ptr %t282, ptr %l156, !tbaa !29
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t284 = load ptr, ptr %l1, !tbaa !29
  %t286 = getelementptr %"compiler/generic:Context", ptr %t284, i32 0, i32 0
  %t287 = load i64, ptr %t286, !tbaa !24
  %t288 = load ptr, ptr %l21, !tbaa !29
  %t290 = getelementptr %"compiler/ast:Param", ptr %t288, i32 0, i32 0
  %t291 = load %"compiler/source:Span", ptr %t290
  %t295 = call { i64, [3 x i64] } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eat(ptr %v0, ptr %t283, i64 %t287, %"compiler/source:Span" %t291)
  store { i64, [3 x i64] } %t295, ptr %l162
  br label %bb59
bb59:
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t297 = load ptr, ptr %l21, !tbaa !29
  %t299 = getelementptr %"compiler/ast:Param", ptr %t297, i32 0, i32 1
  %t300 = load i32, ptr %t299, !tbaa !23
  %t303 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t296, i32 %t300)
  store { i64, ptr } %t303, ptr %l166
  br label %bb60
bb60:
  %t304 = load { i64, ptr }, ptr %l166, !tbaa !27
  %t305 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %s8, { i64, ptr } %t304)
  store { i64, ptr } %t305, ptr %l167
  br label %bb61
bb61:
  %t306 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t307 = extractvalue { i64, ptr } %t306, 0
  %t308 = extractvalue { i64, ptr } %t306, 1
  %t309 = mul i64 %t307, 1
  %t310 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t309)
  call void @llvm.memcpy.p0.p0.i64(ptr %t310, ptr %t308, i64 %t309, i1 false)
  %t311 = insertvalue { i64, ptr } undef, i64 %t307, 0
  %t312 = insertvalue { i64, ptr } %t311, ptr %t310, 1
  %t314 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eFlagWithOutParam(ptr %s8, ptr %s8, { i64, ptr } %t312)
  store %"compiler/msgs:Msg" %t314, ptr %l169
  br label %bb62
bb62:
  %t315 = load ptr, ptr %l156, !tbaa !29
  %t316 = load { i64, [3 x i64] }, ptr %l162
  %t317 = load %"compiler/msgs:Msg", ptr %l169
  %t318 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorOncePerLine(ptr %v0, ptr %s8, ptr %t315, { i64, [3 x i64] } %t316, %"compiler/msgs:Msg" %t317)
  store i64 %t318, ptr %l170
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s8)
  br label %bb64
bb64:
  %t319 = load i64, ptr %l18, !tbaa !24
  %t321 = add i64 %t319, 1
  store i64 %t321, ptr %l18, !tbaa !24
  br label %bb44
bb65:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eglobalDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l19 = alloca ptr
  %l33 = alloca { i64, ptr }
  %l36 = alloca ptr
  %l37 = alloca i1
  %l48 = alloca i64
  %l51 = alloca i64
  %l70 = alloca { i64, ptr }
  %l75 = alloca i1
  %l77 = alloca i1
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/generic:Program", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/load:Loader", ptr %t4, i32 0, i32 10
  %t10 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t6, i64 %a1)
  store ptr %t10, ptr %l19
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l19, !tbaa !29
  %t13 = getelementptr %"compiler/load:Module", ptr %t11, i32 0, i32 8
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  store { i64, ptr } %t14, ptr %l3, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  %t20 = icmp eq i64 %t18, 0
  br i1 %t20, label %bb2, label %bb3
bb2:
  store ptr null, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t23 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t23, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t25 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 0
  store i64 %t27, ptr %l6, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l5, !tbaa !24
  %t30 = load i64, ptr %l6, !tbaa !24
  %t33 = icmp slt i64 %t29, %t30
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb6, label %bb7
bb6:
  br label %bb40
bb7:
  br label %bb8
bb8:
  %t37 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t37, ptr %l33, !tbaa !27
  %t38 = load i64, ptr %l5, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr ptr, ptr %t41, i64 %t38
  %t43 = load ptr, ptr %t42, !tbaa !39
  store ptr %t43, ptr %l7, !tbaa !29
  %t45 = load ptr, ptr %l7, !tbaa !29
  store ptr %t45, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t46 = load ptr, ptr %l36, !tbaa !29
  %t47 = icmp ne ptr %t46, null
  br i1 %t47, label %bb9, label %bb10
bb9:
  %t49 = load ptr, ptr %l36, !tbaa !29
  %t50 = load i64, ptr %t49, !range !{i64 0, i64 11}
  %t52 = icmp eq i64 %t50, 3
  store i1 %t52, ptr %l37, !tbaa !21
  br label %bb10
bb10:
  %t53 = load i1, ptr %l37, !tbaa !21
  br i1 %t53, label %bb11, label %bb12
bb11:
  %t54 = load ptr, ptr %l7, !tbaa !29
  %t56 = getelementptr { i64, [6 x i64] }, ptr %t54, i32 0, i32 1
  %t57 = getelementptr { %"compiler/source:Span", ptr }, ptr %t56, i32 0, i32 1
  %t58 = load ptr, ptr %t57
  store ptr %t58, ptr %l8, !tbaa !29
  br label %bb13
bb12:
  br label %bb33
bb13:
  store i64 0, ptr %l9, !tbaa !24
  %t60 = load ptr, ptr %l8, !tbaa !29
  %t62 = getelementptr %"compiler/ast:VarDecl", ptr %t60, i32 0, i32 0
  %t63 = load { i64, ptr }, ptr %t62, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t63, 0
  store i64 %t65, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t67 = load i64, ptr %l10, !tbaa !24
  %t68 = load i64, ptr %l9, !tbaa !24
  %t71 = icmp sgt i64 %t67, %t68
  br i1 %t71, label %bb14, label %bb15
bb14:
  %t73 = load i64, ptr %l11, !tbaa !24
  %t75 = icmp sgt i64 %t73, 0
  br i1 %t75, label %bb16, label %bb17
bb15:
  store i64 0, ptr %l48, !tbaa !24
  br label %bb19
bb16:
  %t77 = load i64, ptr %l10, !tbaa !24
  %t78 = load i64, ptr %l9, !tbaa !24
  %t81 = sub i64 %t77, %t78
  %t82 = load i64, ptr %l11, !tbaa !24
  %t85 = add i64 %t81, %t82
  %t87 = sub i64 %t85, 1
  %t88 = load i64, ptr %l11, !tbaa !24
  %t91 = sdiv i64 %t87, %t88
  store i64 %t91, ptr %l51, !tbaa !24
  br label %bb18
bb17:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb18
bb18:
  %t93 = load i64, ptr %l51, !tbaa !24
  store i64 %t93, ptr %l48, !tbaa !24
  br label %bb19
bb19:
  %t94 = load i64, ptr %l48, !tbaa !24
  store i64 %t94, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb20
bb20:
  %t95 = load i64, ptr %l13, !tbaa !24
  %t96 = load i64, ptr %l12, !tbaa !24
  %t99 = icmp slt i64 %t95, %t96
  %t101 = xor i1 %t99, true
  br i1 %t101, label %bb21, label %bb22
bb21:
  br label %bb32
bb22:
  br label %bb23
bb23:
  %t103 = load i64, ptr %l9, !tbaa !24
  %t104 = load i64, ptr %l13, !tbaa !24
  %t105 = load i64, ptr %l11, !tbaa !24
  %t108 = mul i64 %t104, %t105
  %t111 = add i64 %t103, %t108
  %t113 = load ptr, ptr %l8, !tbaa !29
  %t115 = getelementptr %"compiler/ast:VarDecl", ptr %t113, i32 0, i32 0
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  store { i64, ptr } %t116, ptr %l70, !tbaa !27
  %t119 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr i32, ptr %t120, i64 %t111
  %t122 = load i32, ptr %t121, !tbaa !33
  %t126 = icmp eq i32 %t122, %a2
  br i1 %t126, label %bb24, label %bb25
bb24:
  %t128 = load ptr, ptr %l8, !tbaa !29
  %t130 = call i1 @compiler_2fgeneric_2emutableGlobal(ptr %v0, ptr %t128)
  store i1 %t130, ptr %l77
  br label %bb26
bb25:
  store i1 false, ptr %l75, !tbaa !21
  br label %bb27
bb26:
  %t131 = load i1, ptr %l77, !tbaa !21
  %t132 = xor i1 %t131, true
  store i1 %t132, ptr %l75, !tbaa !21
  br label %bb27
bb27:
  %t134 = load i1, ptr %l75, !tbaa !21
  br i1 %t134, label %bb28, label %bb29
bb28:
  %t135 = load ptr, ptr %l8, !tbaa !29
  store ptr %t135, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t138 = load i64, ptr %l13, !tbaa !24
  %t140 = add i64 %t138, 1
  store i64 %t140, ptr %l13, !tbaa !24
  br label %bb20
bb32:
  br label %bb38
bb33:
  br i1 true, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_3f6d4ec28d03c677_4b12a6ade8d65b03)
  unreachable
bb38:
  br label %bb39
bb39:
  %t142 = load i64, ptr %l5, !tbaa !24
  %t144 = add i64 %t142, 1
  store i64 %t144, ptr %l5, !tbaa !24
  br label %bb5
bb40:
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eglobalIn(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l25 = alloca ptr
  %l26 = alloca i1
  %l34 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i1
  %l43 = alloca ptr
  %l44 = alloca i64
  %l45 = alloca ptr
  %l47 = alloca ptr
  %l48 = alloca i64
  %l54 = alloca %"compiler/source:Span"
  %l56 = alloca i64
  %l58 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store ptr null, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t8, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l6, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l5, !tbaa !24
  %t15 = load i64, ptr %l6, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb39
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t22, ptr %l22, !tbaa !27
  %t23 = load i64, ptr %l5, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l7, !tbaa !29
  %t30 = load ptr, ptr %l7, !tbaa !29
  store ptr %t30, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t31 = load ptr, ptr %l25, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb8, label %bb9
bb8:
  %t34 = load ptr, ptr %l25, !tbaa !29
  %t35 = load i64, ptr %t34, !range !{i64 0, i64 11}
  %t37 = icmp eq i64 %t35, 3
  store i1 %t37, ptr %l26, !tbaa !21
  br label %bb9
bb9:
  %t38 = load i1, ptr %l26, !tbaa !21
  br i1 %t38, label %bb10, label %bb11
bb10:
  %t39 = load ptr, ptr %l7, !tbaa !29
  %t41 = getelementptr { i64, [6 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", ptr }, ptr %t41, i32 0, i32 1
  %t43 = load ptr, ptr %t42
  store ptr %t43, ptr %l8, !tbaa !29
  br label %bb12
bb11:
  br label %bb17
bb12:
  %t45 = load ptr, ptr %l8, !tbaa !29
  %t47 = getelementptr %"compiler/ast:VarDecl", ptr %t45, i32 0, i32 0
  %t48 = load { i64, ptr }, ptr %t47, !tbaa !27
  %t49 = load i32, ptr %l3, !tbaa !23
  %t52 = call i1 @std_2fprelude_2farray_2eArray_3ccompiler_2fsource_3aNameId_3e_2eHas_3ccompiler_2fsource_3aNameId_3e(ptr %v1, { i64, ptr } %t48, i32 %t49)
  store i1 %t52, ptr %l34
  br label %bb13
bb13:
  %t53 = load i1, ptr %l34, !tbaa !21
  br i1 %t53, label %bb14, label %bb15
bb14:
  %t54 = load ptr, ptr %l8, !tbaa !29
  store ptr %t54, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb37
bb17:
  %t57 = load ptr, ptr %l7, !tbaa !29
  store ptr %t57, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t58 = load ptr, ptr %l37, !tbaa !29
  %t59 = icmp ne ptr %t58, null
  br i1 %t59, label %bb18, label %bb19
bb18:
  %t61 = load ptr, ptr %l37, !tbaa !29
  %t62 = load i64, ptr %t61, !range !{i64 0, i64 11}
  %t64 = icmp eq i64 %t62, 7
  store i1 %t64, ptr %l38, !tbaa !21
  br label %bb19
bb19:
  %t65 = load i1, ptr %l38, !tbaa !21
  br i1 %t65, label %bb20, label %bb21
bb20:
  %t66 = load ptr, ptr %l7, !tbaa !29
  %t68 = getelementptr { i64, [6 x i64] }, ptr %t66, i32 0, i32 1
  %t69 = getelementptr { %"compiler/source:Span", ptr }, ptr %t68, i32 0, i32 1
  %t70 = load ptr, ptr %t69
  store ptr %t70, ptr %l9, !tbaa !29
  br label %bb22
bb21:
  br label %bb32
bb22:
  %t72 = load ptr, ptr %l0, !tbaa !29
  store ptr %t72, ptr %l43, !tbaa !29
  %t73 = load i64, ptr %l1, !tbaa !24
  store i64 %t73, ptr %l44, !tbaa !24
  %t74 = load ptr, ptr %l9, !tbaa !29
  store ptr %t74, ptr %l45, !tbaa !29
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/generic:Program", ptr %t75, i32 0, i32 0
  %t78 = load ptr, ptr %t77, !tbaa !29
  store ptr %t78, ptr %l47, !tbaa !29
  %t79 = load i64, ptr %l1, !tbaa !24
  store i64 %t79, ptr %l48, !tbaa !24
  %t80 = load ptr, ptr %l9, !tbaa !29
  %t82 = getelementptr %"compiler/ast:TopIf", ptr %t80, i32 0, i32 0
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t85 = icmp eq ptr %t83, null
  br i1 %t85, label %bb23, label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_7d389628c92035eb_c8010a4fd10bb547)
  unreachable
bb24:
  br label %bb25
bb25:
  %t87 = load ptr, ptr %l9, !tbaa !29
  %t89 = getelementptr %"compiler/ast:TopIf", ptr %t87, i32 0, i32 0
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t92 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t90)
  store %"compiler/source:Span" %t92, ptr %l54
  br label %bb26
bb26:
  %t93 = getelementptr %"compiler/source:Span", ptr %l54, i32 0, i32 0
  %t94 = load i32, ptr %t93, !tbaa !23
  %t95 = load ptr, ptr %l47, !tbaa !29
  %t96 = load i64, ptr %l48, !tbaa !24
  %t98 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eChosen(ptr %v0, ptr %t95, i64 %t96, i32 %t94)
  store i64 %t98, ptr %l56
  br label %bb27
bb27:
  %t99 = load i32, ptr %l3, !tbaa !23
  %t100 = load ptr, ptr %l43, !tbaa !29
  %t101 = load i64, ptr %l44, !tbaa !24
  %t102 = load ptr, ptr %l45, !tbaa !29
  %t103 = load i64, ptr %l56, !tbaa !24
  %t105 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eglobalInIf(ptr %v0, ptr %v1, ptr %v2, ptr %t100, i64 %t101, ptr %t102, i64 %t103, i64 0, i32 %t99)
  store ptr %t105, ptr %l58
  br label %bb28
bb28:
  %t106 = load ptr, ptr %l58, !tbaa !29
  store ptr %t106, ptr %l10, !tbaa !29
  %t107 = load ptr, ptr %l10, !tbaa !29
  %t109 = icmp eq ptr %t107, null
  %t111 = xor i1 %t109, true
  br i1 %t111, label %bb29, label %bb30
bb29:
  %t113 = load ptr, ptr %l10, !tbaa !29
  store ptr %t113, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  br label %bb37
bb32:
  br i1 true, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_a7facd254843b013_ee8f88ceeae7df5f)
  unreachable
bb37:
  br label %bb38
bb38:
  %t116 = load i64, ptr %l5, !tbaa !24
  %t118 = add i64 %t116, 1
  store i64 %t118, ptr %l5, !tbaa !24
  br label %bb4
bb39:
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ehasHash(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i32
  %l14 = alloca i32
  %l17 = alloca i1
  %l20 = alloca i1
  %l30 = alloca i32
  %l36 = alloca i32
  %l40 = alloca i32
  %l43 = alloca ptr
  %l47 = alloca i32
  %l50 = alloca i1
  %l54 = alloca i32
  %l57 = alloca i1
  %l60 = alloca i1
  %l61 = alloca i1
  %l63 = alloca ptr
  %l67 = alloca i32
  %l68 = alloca i32
  %l71 = alloca i1
  %l73 = alloca ptr
  %l77 = alloca i32
  %l78 = alloca i32
  %l81 = alloca i1
  %l84 = alloca i1
  %l86 = alloca i1
  %l90 = alloca i64
  %l92 = alloca ptr
  %l94 = alloca ptr
  %l98 = alloca i32
  %l99 = alloca i32
  %l102 = alloca i1
  %l105 = alloca i1
  %l106 = alloca i1
  %l110 = alloca i64
  %l112 = alloca i1
  %l113 = alloca ptr
  %l114 = alloca i32
  %l118 = alloca i64
  %l119 = alloca i1
  %l123 = alloca i64
  %l129 = alloca i1
  %l135 = alloca i1
  %l136 = alloca i1
  %l139 = alloca i1
  %l143 = alloca i1
  %l144 = alloca i1
  %l145 = alloca ptr
  %l146 = alloca i32
  %l150 = alloca i32
  %l151 = alloca i1
  %l158 = alloca ptr
  %l162 = alloca i32
  %l165 = alloca i1
  %l170 = alloca ptr
  %l174 = alloca i32
  %l176 = alloca i1
  %l179 = alloca ptr
  %l183 = alloca i32
  %l185 = alloca i1
  %l190 = alloca i1
  %l194 = alloca ptr
  %l198 = alloca i32
  %l199 = alloca i32
  %l202 = alloca ptr
  %l206 = alloca i32
  %l208 = alloca i1
  %l211 = alloca ptr
  %l215 = alloca i32
  %l217 = alloca i1
  %l220 = alloca i1
  %l222 = alloca ptr
  %l226 = alloca i32
  %l227 = alloca i32
  %l230 = alloca ptr
  %l234 = alloca i32
  %l237 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sgt i64 %t1, 16
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/generic:Program", ptr %t6, i32 0, i32 2
  %t9 = load i32, ptr %l1, !tbaa !23
  %t12 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t8, i32 %t9)
  store i32 %t12, ptr %l14
  br label %bb4
bb4:
  %t13 = load i32, ptr %l14, !range !{i32 0, i32 33}
  store i32 %t13, ptr %l3
  %t14 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t16 = trunc i64 0 to i32
  %t17 = icmp eq i32 %t14, %t16
  br i1 %t17, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb7
bb6:
  %t19 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t21 = trunc i64 25 to i32
  %t22 = icmp eq i32 %t19, %t21
  store i1 %t22, ptr %l17, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l17, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb10
bb9:
  %t25 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t27 = trunc i64 27 to i32
  %t28 = icmp eq i32 %t25, %t27
  store i1 %t28, ptr %l20, !tbaa !21
  br label %bb10
bb10:
  %t30 = load i1, ptr %l20, !tbaa !21
  br i1 %t30, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t32 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t34 = trunc i64 32 to i32
  %t35 = icmp eq i32 %t32, %t34
  br i1 %t35, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/generic:Program", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/load:Loader", ptr %t41, i32 0, i32 3
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t44, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d37, i32 0, i32 1) })
  store i32 %t46, ptr %l30
  br label %bb17
bb17:
  %t47 = load i32, ptr %l30, !tbaa !23
  store i32 %t47, ptr %l4, !tbaa !23
  %t48 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t50 = trunc i64 20 to i32
  %t51 = icmp eq i32 %t48, %t50
  br i1 %t51, label %bb18, label %bb19
bb18:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 2
  %t56 = load i32, ptr %l1, !tbaa !23
  %t59 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t55, i32 %t56)
  store i32 %t59, ptr %l36
  br label %bb20
bb19:
  br label %bb66
bb20:
  %t60 = load i32, ptr %l36, !tbaa !23
  store i32 %t60, ptr %l5, !tbaa !23
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/generic:Program", ptr %t61, i32 0, i32 2
  %t64 = load i32, ptr %l5, !tbaa !23
  %t67 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t63, i32 %t64)
  store i32 %t67, ptr %l40
  br label %bb21
bb21:
  %t68 = load i32, ptr %l40, !range !{i32 0, i32 33}
  %t70 = trunc i64 19 to i32
  %t71 = icmp eq i32 %t68, %t70
  br i1 %t71, label %bb22, label %bb23
bb22:
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l43, !tbaa !29
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/generic:Program", ptr %t74, i32 0, i32 2
  %t77 = load i32, ptr %l5, !tbaa !23
  %t80 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t76, i32 %t77)
  store i32 %t80, ptr %l47
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t81 = load i64, ptr %l2, !tbaa !24
  %t83 = add i64 %t81, 1
  %t84 = load ptr, ptr %l43, !tbaa !29
  %t85 = load i32, ptr %l47, !tbaa !23
  %t87 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ehasHash(ptr %v0, ptr %t84, i32 %t85, i64 %t83)
  store i1 %t87, ptr %l50
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t88 = load i1, ptr %l50, !tbaa !21
  store i1 %t88, ptr %rv
  br label %ret
bb26:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/generic:Program", ptr %t89, i32 0, i32 2
  %t92 = load i32, ptr %l5, !tbaa !23
  %t95 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t91, i32 %t92)
  store i32 %t95, ptr %l54
  br label %bb27
bb27:
  %t96 = load i32, ptr %l54, !range !{i32 0, i32 33}
  %t98 = trunc i64 18 to i32
  %t99 = icmp eq i32 %t96, %t98
  br i1 %t99, label %bb28, label %bb29
bb28:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load i32, ptr %l5, !tbaa !23
  %t105 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t101, i32 %t102)
  store i1 %t105, ptr %l60
  br label %bb30
bb29:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb31
bb30:
  %t106 = load i1, ptr %l60, !tbaa !21
  store i1 %t106, ptr %l57, !tbaa !21
  br label %bb31
bb31:
  %t107 = load i1, ptr %l57, !tbaa !21
  br i1 %t107, label %bb32, label %bb33
bb32:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/generic:Program", ptr %t108, i32 0, i32 2
  store ptr %t110, ptr %l63, !tbaa !29
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/generic:Program", ptr %t111, i32 0, i32 2
  %t114 = load i32, ptr %l5, !tbaa !23
  %t117 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t113, i32 %t114)
  store i32 %t117, ptr %l67
  br label %bb34
bb33:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb36
bb34:
  %t118 = load ptr, ptr %l63, !tbaa !29
  %t119 = load i32, ptr %l67, !tbaa !23
  %t120 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t118, i32 %t119)
  store i32 %t120, ptr %l68
  br label %bb35
bb35:
  %t121 = load i32, ptr %l68, !range !{i32 0, i32 6}
  %t123 = trunc i64 4 to i32
  %t124 = icmp eq i32 %t121, %t123
  store i1 %t124, ptr %l61, !tbaa !21
  br label %bb36
bb36:
  %t126 = load i1, ptr %l61, !tbaa !21
  br i1 %t126, label %bb37, label %bb38
bb37:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/generic:Program", ptr %t127, i32 0, i32 2
  store ptr %t129, ptr %l73, !tbaa !29
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/generic:Program", ptr %t130, i32 0, i32 2
  %t133 = load i32, ptr %l5, !tbaa !23
  %t136 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t132, i32 %t133)
  store i32 %t136, ptr %l77
  br label %bb39
bb38:
  store i1 false, ptr %l71, !tbaa !21
  br label %bb41
bb39:
  %t137 = load ptr, ptr %l73, !tbaa !29
  %t138 = load i32, ptr %l77, !tbaa !23
  %t139 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t137, i32 %t138)
  store i32 %t139, ptr %l78
  br label %bb40
bb40:
  %t140 = load i32, ptr %l78, !range !{i32 0, i32 33}
  %t142 = trunc i64 19 to i32
  %t143 = icmp eq i32 %t140, %t142
  store i1 %t143, ptr %l71, !tbaa !21
  br label %bb41
bb41:
  %t145 = load i1, ptr %l71, !tbaa !21
  br i1 %t145, label %bb42, label %bb43
bb42:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load i32, ptr %l5, !tbaa !23
  %t150 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2edeclaresEq(ptr %v0, ptr %t146, i32 %t147)
  store i1 %t150, ptr %l84
  br label %bb44
bb43:
  store i1 false, ptr %l81, !tbaa !21
  br label %bb45
bb44:
  %t151 = load i1, ptr %l84, !tbaa !21
  %t152 = xor i1 %t151, true
  store i1 %t152, ptr %l81, !tbaa !21
  br label %bb45
bb45:
  %t154 = load i1, ptr %l81, !tbaa !21
  br i1 %t154, label %bb46, label %bb47
bb46:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load i32, ptr %l5, !tbaa !23
  %t157 = load i32, ptr %l4, !tbaa !23
  %t161 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t155, i32 %t156, i32 %t157)
  store i64 %t161, ptr %l90
  br label %bb48
bb47:
  store i1 false, ptr %l86, !tbaa !21
  br label %bb49
bb48:
  %t162 = load i64, ptr %l90, !tbaa !24
  %t163 = icmp slt i64 %t162, 0
  store i1 %t163, ptr %l86, !tbaa !21
  br label %bb49
bb49:
  %t165 = load i1, ptr %l86, !tbaa !21
  br i1 %t165, label %bb50, label %bb51
bb50:
  %t166 = load ptr, ptr %l0, !tbaa !29
  store ptr %t166, ptr %l92, !tbaa !29
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/generic:Program", ptr %t167, i32 0, i32 2
  store ptr %t169, ptr %l94, !tbaa !29
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/generic:Program", ptr %t170, i32 0, i32 2
  %t173 = load i32, ptr %l5, !tbaa !23
  %t176 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t172, i32 %t173)
  store i32 %t176, ptr %l98
  br label %bb52
bb51:
  br label %bb55
bb52:
  %t177 = load ptr, ptr %l94, !tbaa !29
  %t178 = load i32, ptr %l98, !tbaa !23
  %t179 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t177, i32 %t178)
  store i32 %t179, ptr %l99
  br label %bb53
bb53:
  %t180 = load i64, ptr %l2, !tbaa !24
  %t182 = add i64 %t180, 1
  %t183 = load ptr, ptr %l92, !tbaa !29
  %t184 = load i32, ptr %l99, !tbaa !23
  %t186 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ehasHash(ptr %v0, ptr %t183, i32 %t184, i64 %t182)
  store i1 %t186, ptr %l102
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s0)
  %t187 = load i1, ptr %l102, !tbaa !21
  store i1 %t187, ptr %rv
  br label %ret
bb55:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load i32, ptr %l5, !tbaa !23
  %t192 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2edeclaresEq(ptr %v0, ptr %t188, i32 %t189)
  store i1 %t192, ptr %l105
  br label %bb56
bb56:
  %t193 = load i1, ptr %l105, !tbaa !21
  br i1 %t193, label %bb57, label %bb58
bb57:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load i32, ptr %l5, !tbaa !23
  %t196 = load i32, ptr %l4, !tbaa !23
  %t200 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t194, i32 %t195, i32 %t196)
  store i64 %t200, ptr %l110
  br label %bb59
bb58:
  store i1 false, ptr %l106, !tbaa !21
  br label %bb60
bb59:
  %t201 = load i64, ptr %l110, !tbaa !24
  %t202 = icmp sge i64 %t201, 0
  store i1 %t202, ptr %l106, !tbaa !21
  br label %bb60
bb60:
  %t204 = load i1, ptr %l106, !tbaa !21
  br i1 %t204, label %bb61, label %bb62
bb61:
  %t205 = load ptr, ptr %l0, !tbaa !29
  store ptr %t205, ptr %l113, !tbaa !29
  %t206 = load i32, ptr %l5, !tbaa !23
  store i32 %t206, ptr %l114, !tbaa !23
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load i32, ptr %l5, !tbaa !23
  %t209 = load i32, ptr %l4, !tbaa !23
  %t213 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t207, i32 %t208, i32 %t209)
  store i64 %t213, ptr %l118
  br label %bb63
bb62:
  store i1 false, ptr %l112, !tbaa !21
  br label %bb65
bb63:
  %t214 = load ptr, ptr %l113, !tbaa !29
  %t215 = load i32, ptr %l114, !tbaa !23
  %t216 = load i64, ptr %l118, !tbaa !24
  %t217 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ehashShaped(ptr %v0, ptr %t214, i32 %t215, i64 %t216)
  store i1 %t217, ptr %l119
  br label %bb64
bb64:
  %t218 = load i1, ptr %l119, !tbaa !21
  store i1 %t218, ptr %l112, !tbaa !21
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s0)
  %t219 = load i1, ptr %l112, !tbaa !21
  store i1 %t219, ptr %rv
  br label %ret
bb66:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load i32, ptr %l1, !tbaa !23
  %t222 = load i32, ptr %l4, !tbaa !23
  %t226 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t220, i32 %t221, i32 %t222)
  store i64 %t226, ptr %l123
  br label %bb67
bb67:
  %t227 = load i64, ptr %l123, !tbaa !24
  store i64 %t227, ptr %l6, !tbaa !24
  %t228 = load i64, ptr %l6, !tbaa !24
  %t230 = icmp sge i64 %t228, 0
  br i1 %t230, label %bb68, label %bb69
bb68:
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = load i32, ptr %l1, !tbaa !23
  %t234 = load i64, ptr %l6, !tbaa !24
  %t238 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ehashShaped(ptr %v0, ptr %t232, i32 %t233, i64 %t234)
  store i1 %t238, ptr %l129
  br label %bb70
bb69:
  br label %bb79
bb70:
  %t239 = load i1, ptr %l129, !tbaa !21
  %t240 = xor i1 %t239, true
  br i1 %t240, label %bb71, label %bb72
bb71:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb72:
  br label %bb73
bb73:
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t244 = load i32, ptr %l1, !tbaa !23
  %t245 = load i32, ptr %l4, !tbaa !23
  %t249 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eownMethod(ptr %v0, ptr %t243, i32 %t244, i32 %t245)
  store i1 %t249, ptr %l135
  br label %bb74
bb74:
  %t250 = load i1, ptr %l135, !tbaa !21
  br i1 %t250, label %bb75, label %bb76
bb75:
  store i1 true, ptr %l136, !tbaa !21
  br label %bb78
bb76:
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t252 = load i32, ptr %l1, !tbaa !23
  %t255 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2edeclaresEq(ptr %v0, ptr %t251, i32 %t252)
  store i1 %t255, ptr %l139
  br label %bb77
bb77:
  %t256 = load i1, ptr %l139, !tbaa !21
  %t257 = xor i1 %t256, true
  store i1 %t257, ptr %l136, !tbaa !21
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s0)
  %t259 = load i1, ptr %l136, !tbaa !21
  store i1 %t259, ptr %rv
  br label %ret
bb79:
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t261 = load i32, ptr %l1, !tbaa !23
  %t264 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2edeclaresEq(ptr %v0, ptr %t260, i32 %t261)
  store i1 %t264, ptr %l143
  br label %bb80
bb80:
  %t265 = load i1, ptr %l143, !tbaa !21
  br i1 %t265, label %bb81, label %bb82
bb81:
  store i1 true, ptr %l144, !tbaa !21
  br label %bb85
bb82:
  %t266 = load ptr, ptr %l0, !tbaa !29
  store ptr %t266, ptr %l145, !tbaa !29
  %t267 = load i32, ptr %l1, !tbaa !23
  store i32 %t267, ptr %l146, !tbaa !23
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t270 = getelementptr %"compiler/generic:Program", ptr %t268, i32 0, i32 0
  %t271 = load ptr, ptr %t270, !tbaa !29
  %t273 = getelementptr %"compiler/load:Loader", ptr %t271, i32 0, i32 3
  %t274 = load ptr, ptr %t273, !tbaa !29
  %t276 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t274, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d38, i32 0, i32 1) })
  store i32 %t276, ptr %l150
  br label %bb83
bb83:
  %t277 = load ptr, ptr %l145, !tbaa !29
  %t278 = load i32, ptr %l146, !tbaa !23
  %t279 = load i32, ptr %l150, !tbaa !23
  %t280 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eownMethod(ptr %v0, ptr %t277, i32 %t278, i32 %t279)
  store i1 %t280, ptr %l151
  br label %bb84
bb84:
  %t281 = load i1, ptr %l151, !tbaa !21
  store i1 %t281, ptr %l144, !tbaa !21
  br label %bb85
bb85:
  %t282 = load i1, ptr %l144, !tbaa !21
  br i1 %t282, label %bb86, label %bb87
bb86:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb87:
  br label %bb88
bb88:
  %t284 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t286 = trunc i64 31 to i32
  %t287 = icmp eq i32 %t284, %t286
  br i1 %t287, label %bb89, label %bb90
bb89:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb90:
  br label %bb91
bb91:
  %t290 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t292 = trunc i64 19 to i32
  %t293 = icmp eq i32 %t290, %t292
  br i1 %t293, label %bb92, label %bb93
bb92:
  br label %bb94
bb93:
  br label %bb97
bb94:
  %t295 = load ptr, ptr %l0, !tbaa !29
  store ptr %t295, ptr %l158, !tbaa !29
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t298 = getelementptr %"compiler/generic:Program", ptr %t296, i32 0, i32 2
  %t299 = load i32, ptr %l1, !tbaa !23
  %t302 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t298, i32 %t299)
  store i32 %t302, ptr %l162
  br label %bb95
bb95:
  %t303 = load i64, ptr %l2, !tbaa !24
  %t305 = add i64 %t303, 1
  %t306 = load ptr, ptr %l158, !tbaa !29
  %t307 = load i32, ptr %l162, !tbaa !23
  %t309 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ehasHash(ptr %v0, ptr %t306, i32 %t307, i64 %t305)
  store i1 %t309, ptr %l165
  br label %bb96
bb96:
  call void @__olang_scope_close(ptr %s0)
  %t310 = load i1, ptr %l165, !tbaa !21
  store i1 %t310, ptr %rv
  br label %ret
bb97:
  %t311 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t313 = trunc i64 22 to i32
  %t314 = icmp eq i32 %t311, %t313
  br i1 %t314, label %bb98, label %bb99
bb98:
  br label %bb102
bb99:
  %t316 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t318 = trunc i64 23 to i32
  %t319 = icmp eq i32 %t316, %t318
  br i1 %t319, label %bb100, label %bb101
bb100:
  br label %bb102
bb101:
  br label %bb105
bb102:
  %t321 = load ptr, ptr %l0, !tbaa !29
  store ptr %t321, ptr %l170, !tbaa !29
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t324 = getelementptr %"compiler/generic:Program", ptr %t322, i32 0, i32 2
  %t325 = load i32, ptr %l1, !tbaa !23
  %t328 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t324, i32 %t325)
  store i32 %t328, ptr %l174
  br label %bb103
bb103:
  %t329 = load i64, ptr %l2, !tbaa !24
  %t330 = load ptr, ptr %l170, !tbaa !29
  %t331 = load i32, ptr %l174, !tbaa !23
  %t333 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ehashesAll(ptr %v0, ptr %t330, i32 %t331, i64 %t329)
  store i1 %t333, ptr %l176
  br label %bb104
bb104:
  call void @__olang_scope_close(ptr %s0)
  %t334 = load i1, ptr %l176, !tbaa !21
  store i1 %t334, ptr %rv
  br label %ret
bb105:
  %t335 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t337 = trunc i64 24 to i32
  %t338 = icmp eq i32 %t335, %t337
  br i1 %t338, label %bb106, label %bb107
bb106:
  br label %bb108
bb107:
  br label %bb111
bb108:
  %t340 = load ptr, ptr %l0, !tbaa !29
  store ptr %t340, ptr %l179, !tbaa !29
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t343 = getelementptr %"compiler/generic:Program", ptr %t341, i32 0, i32 2
  %t344 = load i32, ptr %l1, !tbaa !23
  %t347 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t343, i32 %t344)
  store i32 %t347, ptr %l183
  br label %bb109
bb109:
  %t348 = load i64, ptr %l2, !tbaa !24
  %t349 = load ptr, ptr %l179, !tbaa !29
  %t350 = load i32, ptr %l183, !tbaa !23
  %t352 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ehashesAll(ptr %v0, ptr %t349, i32 %t350, i64 %t348)
  store i1 %t352, ptr %l185
  br label %bb110
bb110:
  call void @__olang_scope_close(ptr %s0)
  %t353 = load i1, ptr %l185, !tbaa !21
  store i1 %t353, ptr %rv
  br label %ret
bb111:
  %t354 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t356 = trunc i64 18 to i32
  %t357 = icmp eq i32 %t354, %t356
  br i1 %t357, label %bb112, label %bb113
bb112:
  br label %bb114
bb113:
  br label %bb141
bb114:
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t360 = load i32, ptr %l1, !tbaa !23
  %t363 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t359, i32 %t360)
  store i1 %t363, ptr %l190
  br label %bb115
bb115:
  %t364 = load i1, ptr %l190, !tbaa !21
  %t365 = xor i1 %t364, true
  br i1 %t365, label %bb116, label %bb117
bb116:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb117:
  br label %bb118
bb118:
  %t368 = load ptr, ptr %l0, !tbaa !29
  %t370 = getelementptr %"compiler/generic:Program", ptr %t368, i32 0, i32 2
  store ptr %t370, ptr %l194, !tbaa !29
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t373 = getelementptr %"compiler/generic:Program", ptr %t371, i32 0, i32 2
  %t374 = load i32, ptr %l1, !tbaa !23
  %t377 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t373, i32 %t374)
  store i32 %t377, ptr %l198
  br label %bb119
bb119:
  %t378 = load ptr, ptr %l194, !tbaa !29
  %t379 = load i32, ptr %l198, !tbaa !23
  %t380 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t378, i32 %t379)
  store i32 %t380, ptr %l199
  br label %bb120
bb120:
  %t381 = load i32, ptr %l199, !range !{i32 0, i32 6}
  store i32 %t381, ptr %l7
  %t382 = load i32, ptr %l7, !range !{i32 0, i32 6}
  %t384 = trunc i64 0 to i32
  %t385 = icmp eq i32 %t382, %t384
  br i1 %t385, label %bb121, label %bb122
bb121:
  %t387 = load ptr, ptr %l0, !tbaa !29
  store ptr %t387, ptr %l202, !tbaa !29
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t390 = getelementptr %"compiler/generic:Program", ptr %t388, i32 0, i32 2
  %t391 = load i32, ptr %l1, !tbaa !23
  %t394 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t390, i32 %t391)
  store i32 %t394, ptr %l206
  br label %bb123
bb122:
  br label %bb125
bb123:
  %t395 = load i64, ptr %l2, !tbaa !24
  %t396 = load ptr, ptr %l202, !tbaa !29
  %t397 = load i32, ptr %l206, !tbaa !23
  %t399 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ehashesAll(ptr %v0, ptr %t396, i32 %t397, i64 %t395)
  store i1 %t399, ptr %l208
  br label %bb124
bb124:
  call void @__olang_scope_close(ptr %s0)
  %t400 = load i1, ptr %l208, !tbaa !21
  store i1 %t400, ptr %rv
  br label %ret
bb125:
  %t401 = load i32, ptr %l7, !range !{i32 0, i32 6}
  %t403 = trunc i64 1 to i32
  %t404 = icmp eq i32 %t401, %t403
  br i1 %t404, label %bb126, label %bb127
bb126:
  %t406 = load ptr, ptr %l0, !tbaa !29
  store ptr %t406, ptr %l211, !tbaa !29
  %t407 = load ptr, ptr %l0, !tbaa !29
  %t409 = getelementptr %"compiler/generic:Program", ptr %t407, i32 0, i32 2
  %t410 = load i32, ptr %l1, !tbaa !23
  %t413 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t409, i32 %t410)
  store i32 %t413, ptr %l215
  br label %bb128
bb127:
  br label %bb130
bb128:
  %t414 = load i64, ptr %l2, !tbaa !24
  %t415 = load ptr, ptr %l211, !tbaa !29
  %t416 = load i32, ptr %l215, !tbaa !23
  %t418 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ehashesAll(ptr %v0, ptr %t415, i32 %t416, i64 %t414)
  store i1 %t418, ptr %l217
  br label %bb129
bb129:
  call void @__olang_scope_close(ptr %s0)
  %t419 = load i1, ptr %l217, !tbaa !21
  store i1 %t419, ptr %rv
  br label %ret
bb130:
  %t420 = load i32, ptr %l7, !range !{i32 0, i32 6}
  %t422 = trunc i64 4 to i32
  %t423 = icmp eq i32 %t420, %t422
  br i1 %t423, label %bb131, label %bb132
bb131:
  %t425 = load ptr, ptr %l0, !tbaa !29
  %t427 = getelementptr %"compiler/generic:Program", ptr %t425, i32 0, i32 2
  store ptr %t427, ptr %l222, !tbaa !29
  %t428 = load ptr, ptr %l0, !tbaa !29
  %t430 = getelementptr %"compiler/generic:Program", ptr %t428, i32 0, i32 2
  %t431 = load i32, ptr %l1, !tbaa !23
  %t434 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t430, i32 %t431)
  store i32 %t434, ptr %l226
  br label %bb133
bb132:
  store i1 false, ptr %l220, !tbaa !21
  br label %bb135
bb133:
  %t435 = load ptr, ptr %l222, !tbaa !29
  %t436 = load i32, ptr %l226, !tbaa !23
  %t437 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t435, i32 %t436)
  store i32 %t437, ptr %l227
  br label %bb134
bb134:
  %t438 = load i32, ptr %l227, !range !{i32 0, i32 33}
  %t440 = trunc i64 19 to i32
  %t441 = icmp eq i32 %t438, %t440
  store i1 %t441, ptr %l220, !tbaa !21
  br label %bb135
bb135:
  %t443 = load i1, ptr %l220, !tbaa !21
  br i1 %t443, label %bb136, label %bb137
bb136:
  %t444 = load ptr, ptr %l0, !tbaa !29
  store ptr %t444, ptr %l230, !tbaa !29
  %t445 = load ptr, ptr %l0, !tbaa !29
  %t447 = getelementptr %"compiler/generic:Program", ptr %t445, i32 0, i32 2
  %t448 = load i32, ptr %l1, !tbaa !23
  %t451 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t447, i32 %t448)
  store i32 %t451, ptr %l234
  br label %bb138
bb137:
  br label %bb140
bb138:
  %t452 = load i64, ptr %l2, !tbaa !24
  %t454 = add i64 %t452, 1
  %t455 = load ptr, ptr %l230, !tbaa !29
  %t456 = load i32, ptr %l234, !tbaa !23
  %t458 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ehasHash(ptr %v0, ptr %t455, i32 %t456, i64 %t454)
  store i1 %t458, ptr %l237
  br label %bb139
bb139:
  call void @__olang_scope_close(ptr %s0)
  %t459 = load i1, ptr %l237, !tbaa !21
  store i1 %t459, ptr %rv
  br label %ret
bb140:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb141:
  br i1 true, label %bb142, label %bb143
bb142:
  br label %bb144
bb143:
  br label %bb145
bb144:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb145:
  call void @__olang_check_failed(ptr @olang_loc_ee8d77a4a1fda3da_cc07c41aef88f656)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eheld(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca i32
  %l9 = alloca i1
  %l12 = alloca i1
  %l18 = alloca i1
  %l23 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l1, !tbaa !23
  %t7 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t10 = trunc i64 18 to i32
  %t11 = icmp eq i32 %t8, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb5
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l1, !tbaa !23
  %t19 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l12
  br label %bb4
bb4:
  %t20 = load i1, ptr %l12, !tbaa !21
  %t21 = xor i1 %t20, true
  store i1 %t21, ptr %l9, !tbaa !21
  br label %bb5
bb5:
  %t23 = load i1, ptr %l9, !tbaa !21
  br i1 %t23, label %bb6, label %bb7
bb6:
  %t24 = load i32, ptr %l1, !tbaa !23
  store i32 %t24, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  %t29 = load i32, ptr %l1, !tbaa !23
  %t32 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %t28, i32 %t29)
  store i1 %t32, ptr %l18
  br label %bb9
bb9:
  %t33 = load i1, ptr %l18, !tbaa !21
  br i1 %t33, label %bb10, label %bb11
bb10:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/generic:Program", ptr %t34, i32 0, i32 2
  %t37 = load i32, ptr %l1, !tbaa !23
  %t38 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t36, i32 %t37, i64 %t38)
  store i32 %t42, ptr %l23
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t43 = load i32, ptr %l23, !tbaa !23
  store i32 %t43, ptr %rv
  br label %ret
bb13:
  %t44 = load i32, ptr %l1, !tbaa !23
  store i32 %t44, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2einstanceLen(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l10 = alloca i1
  %l12 = alloca i1
  %l14 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t7 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLenKey(ptr %v0, ptr %v2, ptr %v3, ptr %s0, ptr %t1, ptr %a2, { i64, ptr } %a3)
  store { i64, ptr } %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t8, ptr %l4, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t11 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t9, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d39, i32 0, i32 1) })
  store i1 %t11, ptr %l10
  br label %bb2
bb2:
  %t12 = load i1, ptr %l10, !tbaa !21
  %t13 = xor i1 %t12, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t17 = getelementptr %"compiler/generic:Context", ptr %a1, i32 0, i32 2
  store ptr %t17, ptr %l14, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/generic:Program", ptr %t18, i32 0, i32 0
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/load:Loader", ptr %t21, i32 0, i32 3
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t25 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t28 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t24, { i64, ptr } %t25)
  store i32 %t28, ptr %l19
  br label %bb5
bb4:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb7
bb5:
  %t29 = load ptr, ptr %l14, !tbaa !29
  %t30 = load i32, ptr %l19, !tbaa !23
  %t31 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_He6be2b0836caba7ddc59483ff74db438(ptr %v1, ptr %t29, i32 %t30)
  store i1 %t31, ptr %l20
  br label %bb6
bb6:
  %t32 = load i1, ptr %l20, !tbaa !21
  store i1 %t32, ptr %l12, !tbaa !21
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t33 = load i1, ptr %l12, !tbaa !21
  store i1 %t33, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eisStructT(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca i32
  %l8 = alloca i1
  %l10 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i32
  %l18 = alloca i1
  %l21 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l1, !tbaa !23
  %t7 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t10 = trunc i64 18 to i32
  %t11 = icmp eq i32 %t8, %t10
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  store ptr %t15, ptr %l10, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %l1, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l14
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb6
bb4:
  %t23 = load ptr, ptr %l10, !tbaa !29
  %t24 = load i32, ptr %l14, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t25, ptr %l15
  br label %bb5
bb5:
  %t26 = load i32, ptr %l15, !range !{i32 0, i32 6}
  %t28 = trunc i64 0 to i32
  %t29 = icmp eq i32 %t26, %t28
  store i1 %t29, ptr %l8, !tbaa !21
  br label %bb6
bb6:
  %t31 = load i1, ptr %l8, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l1, !tbaa !23
  %t36 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t32, i32 %t33)
  store i1 %t36, ptr %l21
  br label %bb9
bb8:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb10
bb9:
  %t37 = load i1, ptr %l21, !tbaa !21
  store i1 %t37, ptr %l18, !tbaa !21
  br label %bb10
bb10:
  %t38 = load i1, ptr %l18, !tbaa !21
  store i1 %t38, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2elenPath(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l15 = alloca i1
  %l22 = alloca { i64, ptr }
  %l24 = alloca ptr
  %l25 = alloca i1
  %l34 = alloca { i64, ptr }
  %l35 = alloca ptr
  %l36 = alloca i1
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l56 = alloca i1
  %l57 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l62 = alloca i64
  %l63 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l66 = alloca i64
  %l67 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sgt i64 %t1, 8
  br i1 %t3, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d40, i32 0, i32 1) }, ptr %l10, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t5, ptr %l11, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l12, !tbaa !24
  %t8 = load i64, ptr %l12, !tbaa !24
  %t9 = mul i64 %t8, 1
  %t10 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l13, !tbaa !27
  %t13 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = load i64, ptr %l12, !tbaa !24
  %t18 = mul i64 %t17, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t14, ptr %t16, i64 %t18, i1 false)
  %t19 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t19, ptr %l11, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t20, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t21 = load ptr, ptr %l1, !tbaa !29
  store ptr %t21, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t22 = load ptr, ptr %l14, !tbaa !29
  %t23 = icmp ne ptr %t22, null
  br i1 %t23, label %bb4, label %bb5
bb4:
  %t25 = load ptr, ptr %l14, !tbaa !29
  %t26 = load i64, ptr %t25, !range !{i64 0, i64 30}
  %t28 = icmp eq i64 %t26, 0
  store i1 %t28, ptr %l15, !tbaa !21
  br label %bb5
bb5:
  %t29 = load i1, ptr %l15, !tbaa !21
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t32 = getelementptr { i64, [4 x i64] }, ptr %t30, i32 0, i32 1
  %t33 = getelementptr { %"compiler/source:Span", i32 }, ptr %t32, i32 0, i32 1
  %t34 = load i32, ptr %t33
  store i32 %t34, ptr %l3, !tbaa !23
  br label %bb8
bb7:
  br label %bb10
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i32, ptr %l3, !tbaa !23
  %t40 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %s2, ptr %t36, i32 %t37)
  store { i64, ptr } %t40, ptr %l22
  br label %bb9
bb9:
  %t41 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t41, 1
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t44 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t43)
  call void @olang_textcopy(ptr %t44, ptr %t42, i64 %t43)
  %t45 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t44, 1
  call void @__olang_scope_close(ptr %s2)
  store { i64, ptr } %t46, ptr %rv
  br label %ret
bb10:
  %t48 = load ptr, ptr %l1, !tbaa !29
  store ptr %t48, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t49 = load ptr, ptr %l24, !tbaa !29
  %t50 = icmp ne ptr %t49, null
  br i1 %t50, label %bb11, label %bb12
bb11:
  %t52 = load ptr, ptr %l24, !tbaa !29
  %t53 = load i64, ptr %t52, !range !{i64 0, i64 30}
  %t55 = icmp eq i64 %t53, 2
  store i1 %t55, ptr %l25, !tbaa !21
  br label %bb12
bb12:
  %t56 = load i1, ptr %l25, !tbaa !21
  br i1 %t56, label %bb13, label %bb14
bb13:
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr { i64, [4 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", ptr }, ptr %t59, i32 0, i32 1
  %t61 = load ptr, ptr %t60
  store ptr %t61, ptr %l4, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load ptr, ptr %l4, !tbaa !29
  %t65 = load i64, ptr %l2, !tbaa !24
  %t67 = add i64 %t65, 1
  %t71 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2elenPath(ptr %v0, ptr %v1, ptr %v2, ptr %t63, ptr %t64, i64 %t67)
  store { i64, ptr } %t71, ptr %l34
  br label %bb16
bb16:
  %t72 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t72, ptr %rv
  br label %ret
bb17:
  %t73 = load ptr, ptr %l1, !tbaa !29
  store ptr %t73, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t74 = load ptr, ptr %l35, !tbaa !29
  %t75 = icmp ne ptr %t74, null
  br i1 %t75, label %bb18, label %bb19
bb18:
  %t77 = load ptr, ptr %l35, !tbaa !29
  %t78 = load i64, ptr %t77, !range !{i64 0, i64 30}
  %t80 = icmp eq i64 %t78, 15
  store i1 %t80, ptr %l36, !tbaa !21
  br label %bb19
bb19:
  %t81 = load i1, ptr %l36, !tbaa !21
  br i1 %t81, label %bb20, label %bb21
bb20:
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr { i64, [4 x i64] }, ptr %t82, i32 0, i32 1
  %t85 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t84, i32 0, i32 1
  %t86 = load ptr, ptr %t85
  store ptr %t86, ptr %l5, !tbaa !29
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t90 = getelementptr { i64, [4 x i64] }, ptr %t88, i32 0, i32 1
  %t91 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t90, i32 0, i32 2
  %t92 = load { i64, ptr }, ptr %t91
  store { i64, ptr } %t92, ptr %l6, !tbaa !27
  br label %bb22
bb21:
  br label %bb31
bb22:
  store %olang.scope zeroinitializer, ptr %s5
  %t94 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t94, 0
  %t98 = icmp ne i64 %t96, 1
  br i1 %t98, label %bb23, label %bb24
bb23:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d41, i32 0, i32 1) }, ptr %l46, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t100, ptr %l47, !tbaa !27
  %t101 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 0
  store i64 %t102, ptr %l48, !tbaa !24
  %t103 = load i64, ptr %l48, !tbaa !24
  %t104 = mul i64 %t103, 1
  %t105 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t104)
  %t106 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  store { i64, ptr } %t107, ptr %l49, !tbaa !27
  %t108 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = load i64, ptr %l48, !tbaa !24
  %t113 = mul i64 %t112, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t109, ptr %t111, i64 %t113, i1 false)
  %t114 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t114, ptr %l47, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  %t115 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t115, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load ptr, ptr %l5, !tbaa !29
  %t118 = load i64, ptr %l2, !tbaa !24
  %t120 = add i64 %t118, 1
  %t124 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2elenPath(ptr %v0, ptr %v1, ptr %s5, ptr %t116, ptr %t117, i64 %t120)
  store { i64, ptr } %t124, ptr %l54
  br label %bb26
bb26:
  %t125 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t125, ptr %l7, !tbaa !27
  %t126 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t128 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s5, ptr %s5, { i64, ptr } %t126, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d42, i32 0, i32 1) })
  store i1 %t128, ptr %l56
  br label %bb27
bb27:
  %t129 = load i1, ptr %l56, !tbaa !21
  br i1 %t129, label %bb28, label %bb29
bb28:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d43, i32 0, i32 1) }, ptr %l58, !tbaa !27
  %t130 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t130, ptr %l57, !tbaa !27
  br label %bb30
bb29:
  %t132 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t132, 1
  %t135 = extractvalue { i64, ptr } %t132, 0
  %t136 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t137 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  %t138 = add i64 %t135, %t137
  %t139 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t138)
  call void @olang_textcopy(ptr %t139, ptr %t134, i64 %t135)
  %t140 = getelementptr i8, ptr %t139, i64 %t135
  call void @olang_textcopy(ptr %t140, ptr %t136, i64 %t137)
  %t141 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t139, 1
  store { i64, ptr } %t142, ptr %l57, !tbaa !27
  br label %bb30
bb30:
  %t144 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t144, 0
  store i64 %t145, ptr %l62, !tbaa !24
  %t146 = load i64, ptr %l62, !tbaa !24
  %t147 = mul i64 %t146, 1
  %t148 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t147)
  %t149 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t150 = insertvalue { i64, ptr } %t149, ptr %t148, 1
  store { i64, ptr } %t150, ptr %l63, !tbaa !27
  %t151 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = load i64, ptr %l62, !tbaa !24
  %t156 = mul i64 %t155, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t152, ptr %t154, i64 %t156, i1 false)
  %t157 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t157, ptr %l57, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  %t158 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t158, ptr %rv
  br label %ret
bb31:
  br i1 true, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d45, i32 0, i32 1) }, ptr %l64, !tbaa !27
  %t159 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t159, ptr %l65, !tbaa !27
  %t160 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t161 = extractvalue { i64, ptr } %t160, 0
  store i64 %t161, ptr %l66, !tbaa !24
  %t162 = load i64, ptr %l66, !tbaa !24
  %t163 = mul i64 %t162, 1
  %t164 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t163)
  %t165 = insertvalue { i64, ptr } undef, i64 %t162, 0
  %t166 = insertvalue { i64, ptr } %t165, ptr %t164, 1
  store { i64, ptr } %t166, ptr %l67, !tbaa !27
  %t167 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t168 = load ptr, ptr %t167, !tbaa !27
  %t169 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !27
  %t171 = load i64, ptr %l66, !tbaa !24
  %t172 = mul i64 %t171, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t168, ptr %t170, i64 %t172, i1 false)
  %t173 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t173, ptr %l65, !tbaa !27
  %t174 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t174, ptr %rv
  br label %ret
bb35:
  call void @__olang_check_failed(ptr @olang_loc_cffe0474e3afc296_35ccea70755633e2)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2elengthLevels(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, i1 %a2, i32 %a3, i64 %a4, ptr %a5, ptr %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l20 = alloca i32
  %l23 = alloca ptr
  %l27 = alloca i32
  %l35 = alloca i1
  %l39 = alloca i32
  %l41 = alloca %"std/prelude/text:StringBuilder"
  %l42 = alloca ptr
  %l45 = alloca { i64, ptr }
  %l50 = alloca i64
  %l53 = alloca i64
  %l75 = alloca ptr
  %l78 = alloca ptr
  %l80 = alloca { i64, ptr }
  %l82 = alloca i32
  %l85 = alloca ptr
  %l89 = alloca i32
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a3, ptr %l3
  store i64 %a4, ptr %l4
  store ptr %a5, ptr %l5
  store ptr %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l4, !tbaa !24
  %t3 = icmp sgt i64 %t1, 8
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/generic:Program", ptr %t5, i32 0, i32 2
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l20
  br label %bb4
bb4:
  %t12 = load i32, ptr %l20, !range !{i32 0, i32 33}
  store i32 %t12, ptr %l7
  %t13 = load i32, ptr %l7, !range !{i32 0, i32 33}
  %t15 = trunc i64 20 to i32
  %t16 = icmp eq i32 %t13, %t15
  br i1 %t16, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb10
bb7:
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l23, !tbaa !29
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %l1, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l27
  br label %bb8
bb8:
  %t26 = load i32, ptr %l3, !tbaa !23
  %t27 = load i64, ptr %l4, !tbaa !24
  %t28 = load ptr, ptr %l5, !tbaa !29
  %t29 = load ptr, ptr %l6, !tbaa !29
  %t30 = load ptr, ptr %l23, !tbaa !29
  %t31 = load i32, ptr %l27, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2elengthLevels(ptr %v0, ptr %v1, ptr %v2, ptr %t30, i32 %t31, i1 false, i32 %t26, i64 %t27, ptr %t28, ptr %t29)
  br label %bb9
bb9:
  br label %bb49
bb10:
  %t36 = load i32, ptr %l7, !range !{i32 0, i32 33}
  %t38 = trunc i64 19 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb44
bb13:
  br i1 %a2, label %bb14, label %bb15
bb14:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/generic:Program", ptr %t43, i32 0, i32 2
  %t46 = load i32, ptr %l1, !tbaa !23
  %t49 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t45, i32 %t46)
  store i32 %t49, ptr %l39
  br label %bb16
bb15:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb17
bb16:
  %t50 = load i32, ptr %l39, !tbaa !23
  %t51 = icmp eq i32 %t50, 0
  store i1 %t51, ptr %l35, !tbaa !21
  br label %bb17
bb17:
  %t53 = load i1, ptr %l35, !tbaa !21
  br i1 %t53, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s4
  %t54 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s4)
  store %"std/prelude/text:StringBuilder" %t54, ptr %l41
  br label %bb20
bb19:
  br label %bb41
bb20:
  %t55 = load %"std/prelude/text:StringBuilder", ptr %l41
  store %"std/prelude/text:StringBuilder" %t55, ptr %l8
  store ptr %l8, ptr %l42, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load i32, ptr %l3, !tbaa !23
  %t60 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t56, i32 %t57)
  store { i64, ptr } %t60, ptr %l45
  br label %bb21
bb21:
  %t61 = load ptr, ptr %l42, !tbaa !29
  %t62 = load { i64, ptr }, ptr %l45, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s4, ptr %v0, ptr %t61, { i64, ptr } %t62)
  br label %bb22
bb22:
  store i64 0, ptr %l9, !tbaa !24
  %t63 = load i64, ptr %l4, !tbaa !24
  store i64 %t63, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t65 = load i64, ptr %l10, !tbaa !24
  %t66 = load i64, ptr %l9, !tbaa !24
  %t69 = icmp sgt i64 %t65, %t66
  br i1 %t69, label %bb23, label %bb24
bb23:
  %t71 = load i64, ptr %l11, !tbaa !24
  %t73 = icmp sgt i64 %t71, 0
  br i1 %t73, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l50, !tbaa !24
  br label %bb28
bb25:
  %t75 = load i64, ptr %l10, !tbaa !24
  %t76 = load i64, ptr %l9, !tbaa !24
  %t79 = sub i64 %t75, %t76
  %t80 = load i64, ptr %l11, !tbaa !24
  %t83 = add i64 %t79, %t80
  %t85 = sub i64 %t83, 1
  %t86 = load i64, ptr %l11, !tbaa !24
  %t89 = sdiv i64 %t85, %t86
  store i64 %t89, ptr %l53, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l53, !tbaa !24
  br label %bb27
bb27:
  %t91 = load i64, ptr %l53, !tbaa !24
  store i64 %t91, ptr %l50, !tbaa !24
  br label %bb28
bb28:
  %t92 = load i64, ptr %l50, !tbaa !24
  store i64 %t92, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s6
  %t93 = load i64, ptr %l13, !tbaa !24
  %t94 = load i64, ptr %l12, !tbaa !24
  %t97 = icmp slt i64 %t93, %t94
  %t99 = xor i1 %t97, true
  br i1 %t99, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s6)
  br label %bb35
bb31:
  br label %bb32
bb32:
  %t101 = load i64, ptr %l9, !tbaa !24
  %t102 = load i64, ptr %l13, !tbaa !24
  %t103 = load i64, ptr %l11, !tbaa !24
  %t106 = mul i64 %t102, %t103
  %t109 = add i64 %t101, %t106
  store i64 %t109, ptr %l14, !tbaa !24
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s4, ptr %s6, ptr %l8, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d46, i32 0, i32 1) })
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s6)
  br label %bb34
bb34:
  %t112 = load i64, ptr %l13, !tbaa !24
  %t114 = add i64 %t112, 1
  store i64 %t114, ptr %l13, !tbaa !24
  br label %bb29
bb35:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s4, ptr %s4, ptr %l8, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d47, i32 0, i32 1) })
  br label %bb36
bb36:
  %t117 = load ptr, ptr %l5, !tbaa !29
  store ptr %t117, ptr %l75, !tbaa !29
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/generic:Program", ptr %t118, i32 0, i32 0
  %t121 = load ptr, ptr %t120, !tbaa !29
  %t123 = getelementptr %"compiler/load:Loader", ptr %t121, i32 0, i32 3
  %t124 = load ptr, ptr %t123, !tbaa !29
  store ptr %t124, ptr %l78, !tbaa !29
  %t126 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s4, ptr %s4, ptr %l8)
  store { i64, ptr } %t126, ptr %l80
  br label %bb37
bb37:
  %t127 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t127, 0
  %t129 = extractvalue { i64, ptr } %t127, 1
  %t130 = mul i64 %t128, 1
  %t131 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t130)
  call void @llvm.memcpy.p0.p0.i64(ptr %t131, ptr %t129, i64 %t130, i1 false)
  %t132 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t133 = insertvalue { i64, ptr } %t132, ptr %t131, 1
  %t134 = load ptr, ptr %l78, !tbaa !29
  %t136 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s4, ptr %t134, { i64, ptr } %t133)
  store i32 %t136, ptr %l82
  br label %bb38
bb38:
  %t137 = load ptr, ptr %l75, !tbaa !29
  %t138 = load i32, ptr %l82, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v1, ptr %t137, i32 %t138)
  br label %bb39
bb39:
  %t139 = load ptr, ptr %l6, !tbaa !29
  %t140 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t139, i64 %t140)
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s4)
  br label %bb41
bb41:
  %t143 = load ptr, ptr %l0, !tbaa !29
  store ptr %t143, ptr %l85, !tbaa !29
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/generic:Program", ptr %t144, i32 0, i32 2
  %t147 = load i32, ptr %l1, !tbaa !23
  %t150 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t146, i32 %t147)
  store i32 %t150, ptr %l89
  br label %bb42
bb42:
  %t151 = load i32, ptr %l3, !tbaa !23
  %t152 = load i64, ptr %l4, !tbaa !24
  %t154 = add i64 %t152, 1
  %t155 = load ptr, ptr %l5, !tbaa !29
  %t156 = load ptr, ptr %l6, !tbaa !29
  %t157 = load ptr, ptr %l85, !tbaa !29
  %t158 = load i32, ptr %l89, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2elengthLevels(ptr %v0, ptr %v1, ptr %v2, ptr %t157, i32 %t158, i1 true, i32 %t151, i64 %t154, ptr %t155, ptr %t156)
  br label %bb43
bb43:
  br label %bb49
bb44:
  br i1 true, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  call void @__olang_check_failed(ptr @olang_loc_e8a0dc9ccb955f9f_ce9beed0e9e57113)
  unreachable
bb49:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eliteralOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l6 = alloca %"compiler/names:Ref"
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i1
  %l17 = alloca ptr
  %l21 = alloca i64
  %l23 = alloca %"compiler/names:Ref"
  %l27 = alloca i1
  %l31 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l38 = alloca %"compiler/source:Span"
  %l39 = alloca i32
  %l42 = alloca { i64, ptr }
  %l48 = alloca i32
  %l54 = alloca ptr
  %l55 = alloca i32
  %l57 = alloca ptr
  %l60 = alloca i32
  %l63 = alloca i32
  %l64 = alloca i32
  %s1 = alloca %olang.scope
  %rv = alloca i32
  %t80 = alloca i64
  %t97 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l4
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l5, !tbaa !23
  br label %bb5
bb4:
  br label %bb32
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  store ptr %t25, ptr %l17, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Context", ptr %t27, i32 0, i32 0
  %t30 = load i64, ptr %t29, !tbaa !24
  %t33 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2efile(ptr %v0, ptr %t26, i64 %t30)
  store i64 %t33, ptr %l21
  br label %bb6
bb6:
  %t34 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 0
  %t35 = load i32, ptr %t34, !tbaa !23
  %t36 = load ptr, ptr %l17, !tbaa !29
  %t37 = load i64, ptr %l21, !tbaa !24
  %t39 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t36, i64 %t37, i32 %t35)
  store %"compiler/names:Ref" %t39, ptr %l23
  br label %bb7
bb7:
  %t40 = load %"compiler/names:Ref", ptr %l23
  store %"compiler/names:Ref" %t40, ptr %l6
  %t41 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 0
  %t42 = load i32, ptr %t41, !range !{i32 0, i32 9}
  %t44 = trunc i64 4 to i32
  %t45 = icmp eq i32 %t42, %t44
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb8, label %bb9
bb8:
  %t49 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 0
  %t50 = load i32, ptr %t49, !range !{i32 0, i32 9}
  %t52 = trunc i64 7 to i32
  %t53 = icmp eq i32 %t50, %t52
  %t55 = xor i1 %t53, true
  store i1 %t55, ptr %l27, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb10
bb10:
  %t57 = load i1, ptr %l27, !tbaa !21
  br i1 %t57, label %bb11, label %bb12
bb11:
  %t58 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 0
  %t59 = load i32, ptr %t58, !range !{i32 0, i32 9}
  %t61 = trunc i64 8 to i32
  %t62 = icmp eq i32 %t59, %t61
  %t64 = xor i1 %t62, true
  store i1 %t64, ptr %l31, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb13
bb13:
  %t66 = load i1, ptr %l31, !tbaa !21
  br i1 %t66, label %bb14, label %bb15
bb14:
  %t67 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  store i32 %t67, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t69 = load ptr, ptr %l0, !tbaa !29
  store ptr %t69, ptr %l36, !tbaa !29
  %t70 = load ptr, ptr %l1, !tbaa !29
  store ptr %t70, ptr %l37, !tbaa !29
  %t71 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t71, ptr %l38
  %t72 = load i32, ptr %l5, !tbaa !23
  store i32 %t72, ptr %l39, !tbaa !23
  %t73 = icmp sge i64 1, 0
  br i1 %t73, label %bb17, label %bb18
bb17:
  %t75 = icmp sle i64 1, 2305843009213693951
  br i1 %t75, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_2edbc1bd270558db_85d99d8e9bee4edf)
  unreachable
bb19:
  %t77 = mul i64 1, 4
  %t78 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t77)
  %t79 = load i32, ptr %l39, !tbaa !23
  store i64 0, ptr %t80
  br label %fill.81
fill.81:
  %t84 = load i64, ptr %t80
  %t85 = icmp slt i64 %t84, 1
  br i1 %t85, label %fillb.82, label %filld.83
fillb.82:
  %t86 = getelementptr i32, ptr %t78, i64 %t84
  store i32 %t79, ptr %t86
  %t87 = add i64 %t84, 1
  store i64 %t87, ptr %t80
  br label %fill.81
filld.83:
  %t88 = insertvalue { i64, ptr } undef, i64 1, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t78, 1
  store { i64, ptr } %t89, ptr %l42, !tbaa !27
  %t90 = icmp sge i64 0, 0
  br i1 %t90, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_2edbc1bd270558db_85d99d8e9bee4edf)
  unreachable
bb21:
  %t92 = icmp sle i64 0, 1152921504606846975
  br i1 %t92, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_2edbc1bd270558db_85d99d8e9bee4edf)
  unreachable
bb23:
  %t94 = mul i64 0, 8
  %t95 = insertvalue { i64, ptr } undef, i64 0, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, [5 x i64] } zeroinitializer, ptr %t97
  %t98 = getelementptr { i64, [5 x i64] }, ptr %t97, i32 0, i32 0
  store i64 0, ptr %t98
  %t99 = load %"compiler/source:Span", ptr %l38
  %t100 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } undef, %"compiler/source:Span" %t99, 0
  %t101 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t102 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t100, { i64, ptr } %t101, 1
  %t104 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t102, { i64, ptr } %t96, 2
  %t105 = getelementptr { i64, [5 x i64] }, ptr %t97, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t104, ptr %t105
  %t106 = load { i64, [5 x i64] }, ptr %t97
  %t108 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 48, i64 8)
  store { i64, [5 x i64] } %t106, ptr %t108
  %t109 = load ptr, ptr %l36, !tbaa !29
  %t110 = load ptr, ptr %l37, !tbaa !29
  %t112 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %s1, ptr %t109, ptr %t110, ptr %t108)
  store i32 %t112, ptr %l48
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_2edbc1bd270558db_85d99d8e9bee4edf)
  unreachable
bb25:
  %t113 = load i32, ptr %l48, !tbaa !23
  store i32 %t113, ptr %l7, !tbaa !23
  %t114 = load i32, ptr %l7, !tbaa !23
  %t115 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t118 = icmp eq i32 %t114, %t115
  br i1 %t118, label %bb26, label %bb27
bb26:
  %t120 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  store i32 %t120, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/generic:Program", ptr %t122, i32 0, i32 2
  store ptr %t124, ptr %l54, !tbaa !29
  %t125 = load i32, ptr %l7, !tbaa !23
  store i32 %t125, ptr %l55, !tbaa !23
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/generic:Program", ptr %t126, i32 0, i32 2
  store ptr %t128, ptr %l57, !tbaa !29
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/generic:Program", ptr %t129, i32 0, i32 2
  %t133 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s1, ptr %t131, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d48, i32 0, i32 1) })
  store i32 %t133, ptr %l60
  br label %bb29
bb29:
  %t136 = extractvalue { i64, ptr } %a3, 0
  %t137 = load ptr, ptr %l57, !tbaa !29
  %t138 = load i32, ptr %l60, !tbaa !23
  %t140 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %t137, i32 %t138, i64 %t136)
  store i32 %t140, ptr %l63
  br label %bb30
bb30:
  %t141 = load ptr, ptr %l54, !tbaa !29
  %t142 = load i32, ptr %l55, !tbaa !23
  %t143 = load i32, ptr %l63, !tbaa !23
  %t144 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t141, i32 %t142, i32 %t143)
  store i32 %t144, ptr %l64
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s1)
  %t145 = load i32, ptr %l64, !tbaa !23
  store i32 %t145, ptr %rv
  br label %ret
bb32:
  br i1 true, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  %t146 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t146, ptr %rv
  br label %ret
bb36:
  call void @__olang_check_failed(ptr @olang_loc_7a3d6db3b893cc7d_3c2a4275e29a89)
  unreachable
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emeetTyped(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l10 = alloca i1
  %l15 = alloca i1
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i32, ptr %l1, !tbaa !23
  store i32 %t7, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i32, ptr %l1, !tbaa !23
  %t11 = load i32, ptr %l2, !tbaa !23
  %t15 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFlows(ptr %v0, ptr %t9, i32 %t10, i32 %t11)
  store i1 %t15, ptr %l10
  br label %bb4
bb4:
  %t16 = load i1, ptr %l10, !tbaa !21
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t17 = load i32, ptr %l2, !tbaa !23
  store i32 %t17, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load i32, ptr %l2, !tbaa !23
  %t21 = load i32, ptr %l1, !tbaa !23
  %t25 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFlows(ptr %v0, ptr %t19, i32 %t20, i32 %t21)
  store i1 %t25, ptr %l15
  br label %bb8
bb8:
  %t26 = load i1, ptr %l15, !tbaa !21
  br i1 %t26, label %bb9, label %bb10
bb9:
  %t27 = load i32, ptr %l1, !tbaa !23
  store i32 %t27, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  store i32 -1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ementionsList(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l12 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l28 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t7 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t3, i32 %a1)
  store { i64, ptr } %t7, ptr %l12
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t8, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l7, !tbaa !24
  br label %bb2
bb2:
  %t13 = load i64, ptr %l6, !tbaa !24
  %t14 = load i64, ptr %l7, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t21 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t21, ptr %l19, !tbaa !27
  %t22 = load i64, ptr %l6, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr i32, ptr %t25, i64 %t22
  %t27 = load i32, ptr %t26, !tbaa !33
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t35 = add i64 %a4, 1
  %t41 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ementionsVar(ptr %v0, ptr %t29, i32 %t27, i64 %a2, i64 %a3, i64 %t35)
  store i1 %t41, ptr %l28
  br label %bb6
bb6:
  %t42 = load i1, ptr %l28, !tbaa !21
  br i1 %t42, label %bb7, label %bb8
bb7:
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t44 = load i64, ptr %l6, !tbaa !24
  %t46 = add i64 %t44, 1
  store i64 %t46, ptr %l6, !tbaa !24
  br label %bb2
bb11:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2enameType(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca %"compiler/names:Ref"
  %l5 = alloca ptr
  %l6 = alloca %"compiler/generic:Context"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l16 = alloca i32
  %l18 = alloca ptr
  %l22 = alloca i64
  %l24 = alloca %"compiler/names:Ref"
  %l28 = alloca i1
  %l35 = alloca ptr
  %l40 = alloca %"compiler/generic:Context"
  %l45 = alloca i1
  %l53 = alloca i32
  %l59 = alloca i1
  %l63 = alloca i1
  %l64 = alloca i32
  %l72 = alloca i64
  %l75 = alloca i64
  %l94 = alloca { i64, ptr }
  %l111 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l116 = alloca { i64, ptr }
  %l120 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  %t53 = alloca %"compiler/generic:Context", align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l18, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/generic:Context", ptr %a1, i32 0, i32 0
  %t9 = load i64, ptr %t8, !tbaa !24
  %t12 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2efile(ptr %v0, ptr %t5, i64 %t9)
  store i64 %t12, ptr %l22
  br label %bb1
bb1:
  %t13 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t14 = load i32, ptr %t13, !tbaa !23
  %t15 = load ptr, ptr %l18, !tbaa !29
  %t16 = load i64, ptr %l22, !tbaa !24
  %t18 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t15, i64 %t16, i32 %t14)
  store %"compiler/names:Ref" %t18, ptr %l24
  br label %bb2
bb2:
  %t19 = load %"compiler/names:Ref", ptr %l24
  store %"compiler/names:Ref" %t19, ptr %l4
  %t20 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 0
  %t21 = load i32, ptr %t20, !range !{i32 0, i32 9}
  %t23 = trunc i64 2 to i32
  %t24 = icmp eq i32 %t21, %t23
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb5
bb4:
  %t28 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 2
  %t29 = load i64, ptr %t28, !tbaa !24
  %t31 = icmp slt i64 %t29, 0
  store i1 %t31, ptr %l28, !tbaa !21
  br label %bb5
bb5:
  %t33 = load i1, ptr %l28, !tbaa !21
  br i1 %t33, label %bb6, label %bb7
bb6:
  %t34 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t34, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 1
  %t38 = load i64, ptr %t37, !tbaa !24
  %t39 = load i32, ptr %l3, !tbaa !23
  %t43 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eanyGlobal(ptr %v0, ptr %v0, ptr %t36, i64 %t38, i32 %t39)
  store ptr %t43, ptr %l35
  br label %bb9
bb9:
  %t44 = load ptr, ptr %l35, !tbaa !29
  store ptr %t44, ptr %l5, !tbaa !29
  %t45 = load ptr, ptr %l5, !tbaa !29
  %t47 = icmp eq ptr %t45, null
  br i1 %t47, label %bb10, label %bb11
bb10:
  %t49 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t49, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t51 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 1
  %t52 = load i64, ptr %t51, !tbaa !24
  call void @compiler_2fgeneric_3aContext_2ector(ptr %t53, ptr %s0, i64 %t52, i64 -1)
  call void @llvm.memmove.p0.p0.i64(ptr %l40, ptr %t53, i64 160, i1 false)
  br label %bb13
bb13:
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %l40, i64 160, i1 false)
  %t55 = load ptr, ptr %l5, !tbaa !29
  %t57 = getelementptr %"compiler/ast:VarDecl", ptr %t55, i32 0, i32 2
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t60 = icmp eq ptr %t58, null
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb14, label %bb15
bb14:
  %t64 = load ptr, ptr %l5, !tbaa !29
  %t66 = getelementptr %"compiler/ast:VarDecl", ptr %t64, i32 0, i32 4
  %t67 = load i1, ptr %t66, !tbaa !21
  %t69 = xor i1 %t67, true
  store i1 %t69, ptr %l45, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb16
bb16:
  %t71 = load i1, ptr %l45, !tbaa !21
  br i1 %t71, label %bb17, label %bb18
bb17:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load ptr, ptr %l5, !tbaa !29
  %t74 = load i32, ptr %l3, !tbaa !23
  %t79 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalStorage(ptr %v0, ptr %s0, ptr %v0, ptr %t72, ptr %l6, ptr %t73, i32 %t74)
  store i32 %t79, ptr %l53
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s0)
  %t80 = load i32, ptr %l53, !tbaa !23
  store i32 %t80, ptr %rv
  br label %ret
bb20:
  %t81 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 1
  %t82 = load i64, ptr %t81, !tbaa !24
  %t84 = shl i64 %t82, 32
  %t85 = load i32, ptr %l3, !tbaa !23
  %t87 = sext i32 %t85 to i64
  %t90 = or i64 %t84, %t87
  store i64 %t90, ptr %l7, !tbaa !24
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/generic:Program", ptr %t92, i32 0, i32 36
  %t95 = load i64, ptr %l7, !tbaa !24
  %t98 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %t94, i64 %t95)
  %t99 = extractvalue { i32, i1 } %t98, 1
  %t100 = extractvalue { i32, i1 } %t98, 0
  store i32 %t100, ptr %l64
  %t101 = icmp ne i32 %t100, 0
  br i1 %t101, label %bb22, label %ok.102, !prof !99
ok.102:
  store i1 %t99, ptr %l63
  br label %bb21
bb21:
  %t103 = load i1, ptr %l63, !tbaa !21
  store i1 %t103, ptr %l59, !tbaa !21
  br label %bb24
bb22:
  br label %bb23
bb23:
  call void @__olang_ert_req_clear()
  store i1 false, ptr %l59, !tbaa !21
  br label %bb24
bb24:
  %t104 = load i1, ptr %l59, !tbaa !21
  br i1 %t104, label %bb25, label %bb26
bb25:
  %t105 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t105, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  store i64 0, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  %t107 = load ptr, ptr %l5, !tbaa !29
  %t109 = getelementptr %"compiler/ast:VarDecl", ptr %t107, i32 0, i32 0
  %t110 = load { i64, ptr }, ptr %t109, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t110, 0
  store i64 %t112, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t114 = load i64, ptr %l10, !tbaa !24
  %t115 = load i64, ptr %l9, !tbaa !24
  %t118 = icmp sgt i64 %t114, %t115
  br i1 %t118, label %bb28, label %bb29
bb28:
  %t120 = load i64, ptr %l11, !tbaa !24
  %t122 = icmp sgt i64 %t120, 0
  br i1 %t122, label %bb30, label %bb31
bb29:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb33
bb30:
  %t124 = load i64, ptr %l10, !tbaa !24
  %t125 = load i64, ptr %l9, !tbaa !24
  %t128 = sub i64 %t124, %t125
  %t129 = load i64, ptr %l11, !tbaa !24
  %t132 = add i64 %t128, %t129
  %t134 = sub i64 %t132, 1
  %t135 = load i64, ptr %l11, !tbaa !24
  %t138 = sdiv i64 %t134, %t135
  store i64 %t138, ptr %l75, !tbaa !24
  br label %bb32
bb31:
  store i64 0, ptr %l75, !tbaa !24
  br label %bb32
bb32:
  %t140 = load i64, ptr %l75, !tbaa !24
  store i64 %t140, ptr %l72, !tbaa !24
  br label %bb33
bb33:
  %t141 = load i64, ptr %l72, !tbaa !24
  store i64 %t141, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb34
bb34:
  %t142 = load i64, ptr %l13, !tbaa !24
  %t143 = load i64, ptr %l12, !tbaa !24
  %t146 = icmp slt i64 %t142, %t143
  %t148 = xor i1 %t146, true
  br i1 %t148, label %bb35, label %bb36
bb35:
  br label %bb42
bb36:
  br label %bb37
bb37:
  %t150 = load i64, ptr %l9, !tbaa !24
  %t151 = load i64, ptr %l13, !tbaa !24
  %t152 = load i64, ptr %l11, !tbaa !24
  %t155 = mul i64 %t151, %t152
  %t158 = add i64 %t150, %t155
  store i64 %t158, ptr %l14, !tbaa !24
  %t160 = load ptr, ptr %l5, !tbaa !29
  %t162 = getelementptr %"compiler/ast:VarDecl", ptr %t160, i32 0, i32 0
  %t163 = load { i64, ptr }, ptr %t162, !tbaa !27
  store { i64, ptr } %t163, ptr %l94, !tbaa !27
  %t164 = load i64, ptr %l14, !tbaa !24
  %t166 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = getelementptr i32, ptr %t167, i64 %t164
  %t169 = load i32, ptr %t168, !tbaa !33
  %t170 = load i32, ptr %l3, !tbaa !23
  %t173 = icmp eq i32 %t169, %t170
  br i1 %t173, label %bb38, label %bb39
bb38:
  %t175 = load i64, ptr %l14, !tbaa !24
  store i64 %t175, ptr %l8, !tbaa !24
  br label %bb40
bb39:
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t177 = load i64, ptr %l13, !tbaa !24
  %t179 = add i64 %t177, 1
  store i64 %t179, ptr %l13, !tbaa !24
  br label %bb34
bb42:
  %t181 = load i64, ptr %l8, !tbaa !24
  %t182 = load ptr, ptr %l5, !tbaa !29
  %t184 = getelementptr %"compiler/ast:VarDecl", ptr %t182, i32 0, i32 3
  %t185 = load { i64, ptr }, ptr %t184, !tbaa !27
  %t187 = extractvalue { i64, ptr } %t185, 0
  %t190 = icmp sge i64 %t181, %t187
  br i1 %t190, label %bb43, label %bb44
bb43:
  %t192 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t192, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/generic:Program", ptr %t194, i32 0, i32 36
  %t197 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t196, i64 %t197, i1 true)
  br label %bb46
bb46:
  %t200 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t200, ptr %l111
  br label %bb47
bb47:
  %t201 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l111
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t201, ptr %l15
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load ptr, ptr %l5, !tbaa !29
  %t205 = getelementptr %"compiler/ast:VarDecl", ptr %t203, i32 0, i32 3
  %t206 = load { i64, ptr }, ptr %t205, !tbaa !27
  store { i64, ptr } %t206, ptr %l116, !tbaa !27
  %t207 = load i64, ptr %l8, !tbaa !24
  %t209 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t210 = load ptr, ptr %t209, !tbaa !27
  %t211 = getelementptr ptr, ptr %t210, i64 %t207
  %t212 = load ptr, ptr %t211, !tbaa !39
  %t218 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInfer(ptr %v0, ptr %s0, ptr %s0, ptr %v0, ptr %t202, ptr %l6, ptr %l15, ptr %t212)
  store i32 %t218, ptr %l120
  br label %bb48
bb48:
  %t219 = load i32, ptr %l120, !tbaa !23
  store i32 %t219, ptr %l16, !tbaa !23
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t222 = getelementptr %"compiler/generic:Program", ptr %t220, i32 0, i32 36
  %t223 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t222, i64 %t223, i1 false)
  br label %bb49
bb49:
  %t226 = load i32, ptr %l16, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t226, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2enamedType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/names:Ref"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i64
  %l14 = alloca ptr
  %l18 = alloca i64
  %l21 = alloca %"compiler/names:Ref"
  %l30 = alloca i1
  %l35 = alloca ptr
  %l39 = alloca i32
  %l40 = alloca i32
  %l51 = alloca i64
  %l54 = alloca i64
  %l75 = alloca { i64, ptr }
  %l78 = alloca i64
  %l87 = alloca { i64, ptr }
  %l91 = alloca i64
  %l96 = alloca ptr
  %l100 = alloca i32
  %l101 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l14, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/generic:Context", ptr %a1, i32 0, i32 0
  %t9 = load i64, ptr %t8, !tbaa !24
  %t12 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2efile(ptr %v0, ptr %t5, i64 %t9)
  store i64 %t12, ptr %l18
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t15 = getelementptr %"compiler/ast:Path", ptr %t13, i32 0, i32 0
  %t16 = getelementptr %"compiler/source:Span", ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16, !tbaa !23
  %t18 = load ptr, ptr %l14, !tbaa !29
  %t19 = load i64, ptr %l18, !tbaa !24
  %t21 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t18, i64 %t19, i32 %t17)
  store %"compiler/names:Ref" %t21, ptr %l21
  br label %bb2
bb2:
  %t22 = load %"compiler/names:Ref", ptr %l21
  store %"compiler/names:Ref" %t22, ptr %l3
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t25 = getelementptr %"compiler/ast:Path", ptr %t23, i32 0, i32 1
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  store i64 %t28, ptr %l4, !tbaa !24
  %t30 = load i64, ptr %l4, !tbaa !24
  %t32 = icmp eq i64 %t30, 1
  br i1 %t32, label %bb3, label %bb4
bb3:
  %t34 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 0
  %t35 = load i32, ptr %t34, !range !{i32 0, i32 9}
  %t37 = trunc i64 4 to i32
  %t38 = icmp eq i32 %t35, %t37
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb5, label %bb6
bb4:
  br label %bb13
bb5:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb7
bb6:
  %t42 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t45 = icmp slt i64 %t43, 0
  store i1 %t45, ptr %l30, !tbaa !21
  br label %bb7
bb7:
  %t47 = load i1, ptr %l30, !tbaa !21
  br i1 %t47, label %bb8, label %bb9
bb8:
  %t48 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t48, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/generic:Program", ptr %t50, i32 0, i32 2
  store ptr %t52, ptr %l35, !tbaa !29
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 1
  %t55 = load i64, ptr %t54, !tbaa !24
  %t56 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 2
  %t57 = load i64, ptr %t56, !tbaa !24
  %t61 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t53, i64 %t55, i64 %t57)
  store i32 %t61, ptr %l39
  br label %bb11
bb11:
  %t62 = load ptr, ptr %l35, !tbaa !29
  %t63 = load i32, ptr %l39, !tbaa !23
  %t64 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamed(ptr %v0, ptr %t62, i32 %t63, i32 0)
  store i32 %t64, ptr %l40
  br label %bb12
bb12:
  %t65 = load i32, ptr %l40, !tbaa !23
  store i32 %t65, ptr %rv
  br label %ret
bb13:
  %t66 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 0
  %t67 = load i32, ptr %t66, !range !{i32 0, i32 9}
  %t69 = trunc i64 5 to i32
  %t70 = icmp eq i32 %t67, %t69
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb14, label %bb15
bb14:
  %t74 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t74, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t76 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 1
  %t77 = load i64, ptr %t76, !tbaa !24
  store i64 %t77, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t79 = load i64, ptr %l4, !tbaa !24
  %t81 = sub i64 %t79, 1
  store i64 %t81, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t83 = load i64, ptr %l7, !tbaa !24
  %t84 = load i64, ptr %l6, !tbaa !24
  %t87 = icmp sgt i64 %t83, %t84
  br i1 %t87, label %bb17, label %bb18
bb17:
  %t89 = load i64, ptr %l8, !tbaa !24
  %t91 = icmp sgt i64 %t89, 0
  br i1 %t91, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb22
bb19:
  %t93 = load i64, ptr %l7, !tbaa !24
  %t94 = load i64, ptr %l6, !tbaa !24
  %t97 = sub i64 %t93, %t94
  %t98 = load i64, ptr %l8, !tbaa !24
  %t101 = add i64 %t97, %t98
  %t103 = sub i64 %t101, 1
  %t104 = load i64, ptr %l8, !tbaa !24
  %t107 = sdiv i64 %t103, %t104
  store i64 %t107, ptr %l54, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb21
bb21:
  %t109 = load i64, ptr %l54, !tbaa !24
  store i64 %t109, ptr %l51, !tbaa !24
  br label %bb22
bb22:
  %t110 = load i64, ptr %l51, !tbaa !24
  store i64 %t110, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb23
bb23:
  %t111 = load i64, ptr %l10, !tbaa !24
  %t112 = load i64, ptr %l9, !tbaa !24
  %t115 = icmp slt i64 %t111, %t112
  %t117 = xor i1 %t115, true
  br i1 %t117, label %bb24, label %bb25
bb24:
  br label %bb32
bb25:
  br label %bb26
bb26:
  %t119 = load i64, ptr %l6, !tbaa !24
  %t120 = load i64, ptr %l10, !tbaa !24
  %t121 = load i64, ptr %l8, !tbaa !24
  %t124 = mul i64 %t120, %t121
  %t127 = add i64 %t119, %t124
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load i64, ptr %l5, !tbaa !24
  %t131 = load ptr, ptr %l2, !tbaa !29
  %t133 = getelementptr %"compiler/ast:Path", ptr %t131, i32 0, i32 1
  %t134 = load { i64, ptr }, ptr %t133, !tbaa !27
  store { i64, ptr } %t134, ptr %l75, !tbaa !27
  %t137 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr i32, ptr %t138, i64 %t127
  %t140 = load i32, ptr %t139, !tbaa !33
  %t144 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ealiasStep(ptr %v0, ptr %t129, i64 %t130, i32 %t140)
  store i64 %t144, ptr %l78
  br label %bb27
bb27:
  %t145 = load i64, ptr %l78, !tbaa !24
  store i64 %t145, ptr %l5, !tbaa !24
  %t146 = load i64, ptr %l5, !tbaa !24
  %t148 = icmp slt i64 %t146, 0
  br i1 %t148, label %bb28, label %bb29
bb28:
  %t150 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t150, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t152 = load i64, ptr %l10, !tbaa !24
  %t154 = add i64 %t152, 1
  store i64 %t154, ptr %l10, !tbaa !24
  br label %bb23
bb32:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load i64, ptr %l5, !tbaa !24
  %t158 = load ptr, ptr %l2, !tbaa !29
  %t160 = getelementptr %"compiler/ast:Path", ptr %t158, i32 0, i32 1
  %t161 = load { i64, ptr }, ptr %t160, !tbaa !27
  store { i64, ptr } %t161, ptr %l87, !tbaa !27
  %t162 = load i64, ptr %l4, !tbaa !24
  %t164 = sub i64 %t162, 1
  %t166 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = getelementptr i32, ptr %t167, i64 %t164
  %t169 = load i32, ptr %t168, !tbaa !33
  %t173 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %t156, i64 %t157, i32 %t169)
  store i64 %t173, ptr %l91
  br label %bb33
bb33:
  %t174 = load i64, ptr %l91, !tbaa !24
  store i64 %t174, ptr %l12, !tbaa !24
  %t175 = load i64, ptr %l12, !tbaa !24
  %t177 = icmp slt i64 %t175, 0
  br i1 %t177, label %bb34, label %bb35
bb34:
  %t179 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t179, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = getelementptr %"compiler/generic:Program", ptr %t181, i32 0, i32 2
  store ptr %t183, ptr %l96, !tbaa !29
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t185 = load i64, ptr %l5, !tbaa !24
  %t186 = load i64, ptr %l12, !tbaa !24
  %t190 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t184, i64 %t185, i64 %t186)
  store i32 %t190, ptr %l100
  br label %bb37
bb37:
  %t191 = load ptr, ptr %l96, !tbaa !29
  %t192 = load i32, ptr %l100, !tbaa !23
  %t193 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamed(ptr %v0, ptr %t191, i32 %t192, i32 0)
  store i32 %t193, ptr %l101
  br label %bb38
bb38:
  %t194 = load i32, ptr %l101, !tbaa !23
  store i32 %t194, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eparamsSig(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca { i64, ptr }
  %l25 = alloca ptr
  %l30 = alloca i32
  %l36 = alloca ptr
  %l37 = alloca i64
  %l39 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca i32
  %l46 = alloca i32
  %l53 = alloca i32
  %l55 = alloca ptr
  %l57 = alloca ptr
  %l59 = alloca { i64, ptr }
  %l60 = alloca i32
  %l64 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l13
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l5
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l14
  br label %bb2
bb2:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l6
  store { i64, ptr } %a2, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l9, !tbaa !24
  br label %bb3
bb3:
  %t11 = load i64, ptr %l8, !tbaa !24
  %t12 = load i64, ptr %l9, !tbaa !24
  %t15 = icmp slt i64 %t11, %t12
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb4, label %bb5
bb4:
  br label %bb11
bb5:
  br label %bb6
bb6:
  %t19 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t19, ptr %l22, !tbaa !27
  %t20 = load i64, ptr %l8, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr ptr, ptr %t23, i64 %t20
  %t25 = load ptr, ptr %t24, !tbaa !39
  store ptr %l5, ptr %l25, !tbaa !29
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr %"compiler/ast:Param", ptr %t25, i32 0, i32 2
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t36 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %t27, ptr %t28, ptr %t32)
  store i32 %t36, ptr %l30
  br label %bb7
bb7:
  %t37 = load ptr, ptr %l25, !tbaa !29
  %t38 = load i32, ptr %l30, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t37, i32 %t38)
  br label %bb8
bb8:
  %t39 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l6, i64 %t39)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t42 = load i64, ptr %l8, !tbaa !24
  %t44 = add i64 %t42, 1
  store i64 %t44, ptr %l8, !tbaa !24
  br label %bb3
bb11:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/generic:Program", ptr %t46, i32 0, i32 2
  store ptr %t48, ptr %l36, !tbaa !29
  %t49 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  store i64 %t49, ptr %l37, !tbaa !24
  %t51 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %s0, ptr %l6)
  store { i64, ptr } %t51, ptr %l39
  br label %bb12
bb12:
  %t52 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  %t53 = mul i64 1, 8
  %t54 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t53)
  %t55 = insertvalue { i64, ptr } undef, i64 1, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t54, 1
  store { i64, ptr } %t56, ptr %l41, !tbaa !27
  %t58 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr i64, ptr %t59, i64 0
  store i64 %t52, ptr %t60, !tbaa !34
  %t61 = load ptr, ptr %l36, !tbaa !29
  %t62 = load i64, ptr %l37, !tbaa !24
  %t63 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t65 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopes(ptr %v0, ptr %s0, ptr %s0, ptr %t61, i64 %t62, { i64, ptr } %t63, { i64, ptr } %t64)
  store i32 %t65, ptr %l42
  br label %bb13
bb13:
  %t66 = load i32, ptr %l42, !tbaa !23
  store i32 %t66, ptr %l11, !tbaa !23
  %t67 = load ptr, ptr %l3, !tbaa !29
  %t69 = icmp eq ptr %t67, null
  %t71 = xor i1 %t69, true
  br i1 %t71, label %bb14, label %bb15
bb14:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t75 = load ptr, ptr %l3, !tbaa !29
  %t77 = getelementptr %"compiler/ast:Sig", ptr %t75, i32 0, i32 2
  %t78 = load i1, ptr %t77, !tbaa !21
  %t79 = load ptr, ptr %l3, !tbaa !29
  %t81 = getelementptr %"compiler/ast:Sig", ptr %t79, i32 0, i32 3
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  %t87 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eerrorList(ptr %v0, ptr %v1, ptr %v3, ptr %t73, ptr %t74, i1 %t78, { i64, ptr } %t82)
  store i32 %t87, ptr %l53
  br label %bb16
bb15:
  store i32 0, ptr %l46, !tbaa !23
  br label %bb17
bb16:
  %t88 = load i32, ptr %l53, !tbaa !23
  store i32 %t88, ptr %l46, !tbaa !23
  br label %bb17
bb17:
  %t89 = load i32, ptr %l46, !tbaa !23
  store i32 %t89, ptr %l12, !tbaa !23
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/generic:Program", ptr %t90, i32 0, i32 2
  store ptr %t92, ptr %l55, !tbaa !29
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/generic:Program", ptr %t93, i32 0, i32 2
  store ptr %t95, ptr %l57, !tbaa !29
  %t97 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %s0, ptr %l5)
  store { i64, ptr } %t97, ptr %l59
  br label %bb18
bb18:
  %t98 = load ptr, ptr %l57, !tbaa !29
  %t99 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t100 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t98, { i64, ptr } %t99)
  store i32 %t100, ptr %l60
  br label %bb19
bb19:
  %t102 = load i32, ptr %l12, !tbaa !23
  %t103 = load i32, ptr %l11, !tbaa !23
  %t104 = load ptr, ptr %l55, !tbaa !29
  %t105 = load i32, ptr %l60, !tbaa !23
  %t109 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t104, i32 %t105, i32 %a4, i32 %t102, i32 %t103, i64 0, i1 false, i32 0)
  store i32 %t109, ptr %l64
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t110 = load i32, ptr %l64, !tbaa !23
  store i32 %t110, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2erecvKey(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"compiler/names:Ref"
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l15 = alloca i1
  %l24 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca i1
  %l36 = alloca i64
  %l37 = alloca ptr
  %l38 = alloca i1
  %l46 = alloca ptr
  %l49 = alloca i64
  %l51 = alloca %"compiler/names:Ref"
  %l55 = alloca { i64, ptr }
  %l57 = alloca ptr
  %l64 = alloca i64
  %l67 = alloca i1
  %l73 = alloca i32
  %l74 = alloca i64
  %l78 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l85 = alloca i1
  %l88 = alloca i1
  %l90 = alloca i64
  %l94 = alloca i32
  %l95 = alloca i64
  %s8 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 -1, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t7 = load ptr, ptr %l14, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l14, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 8}
  %t13 = icmp eq i64 %t11, 4
  store i1 %t13, ptr %l15, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l15, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t17, i32 0, i32 1
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l4, !tbaa !29
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i64, ptr %l1, !tbaa !24
  %t23 = load ptr, ptr %l4, !tbaa !29
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t29 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2erecvKey(ptr %v0, ptr %v1, ptr %v2, ptr %t21, i64 %t22, ptr %t23, { i64, ptr } %t24)
  store i64 %t29, ptr %l24
  br label %bb9
bb9:
  %t30 = load i64, ptr %l24, !tbaa !24
  store i64 %t30, ptr %rv
  br label %ret
bb10:
  %t31 = load ptr, ptr %l2, !tbaa !29
  store ptr %t31, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t32 = load ptr, ptr %l25, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb11, label %bb12
bb11:
  %t35 = load ptr, ptr %l25, !tbaa !29
  %t36 = load i64, ptr %t35, !range !{i64 0, i64 8}
  %t38 = icmp eq i64 %t36, 3
  store i1 %t38, ptr %l26, !tbaa !21
  br label %bb12
bb12:
  %t39 = load i1, ptr %l26, !tbaa !21
  br i1 %t39, label %bb13, label %bb14
bb13:
  %t40 = load ptr, ptr %l2, !tbaa !29
  %t42 = getelementptr { i64, [5 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t42, i32 0, i32 1
  %t44 = load ptr, ptr %t43
  store ptr %t44, ptr %l5, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load i64, ptr %l1, !tbaa !24
  %t48 = load ptr, ptr %l5, !tbaa !29
  %t50 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t55 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2erecvKey(ptr %v0, ptr %v1, ptr %v2, ptr %t46, i64 %t47, ptr %t48, { i64, ptr } %t50)
  store i64 %t55, ptr %l36
  br label %bb16
bb16:
  %t56 = load i64, ptr %l36, !tbaa !24
  store i64 %t56, ptr %rv
  br label %ret
bb17:
  %t57 = load ptr, ptr %l2, !tbaa !29
  store ptr %t57, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t58 = load ptr, ptr %l37, !tbaa !29
  %t59 = icmp ne ptr %t58, null
  br i1 %t59, label %bb18, label %bb19
bb18:
  %t61 = load ptr, ptr %l37, !tbaa !29
  %t62 = load i64, ptr %t61, !range !{i64 0, i64 8}
  %t64 = icmp eq i64 %t62, 0
  store i1 %t64, ptr %l38, !tbaa !21
  br label %bb19
bb19:
  %t65 = load i1, ptr %l38, !tbaa !21
  br i1 %t65, label %bb20, label %bb21
bb20:
  %t66 = load ptr, ptr %l2, !tbaa !29
  %t68 = getelementptr { i64, [5 x i64] }, ptr %t66, i32 0, i32 1
  %t69 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t68, i32 0, i32 0
  %t70 = load %"compiler/source:Span", ptr %t69
  store %"compiler/source:Span" %t70, ptr %l6
  %t72 = load ptr, ptr %l2, !tbaa !29
  %t74 = getelementptr { i64, [5 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t74, i32 0, i32 1
  %t76 = load { i64, ptr }, ptr %t75
  store { i64, ptr } %t76, ptr %l7, !tbaa !27
  br label %bb22
bb21:
  br label %bb56
bb22:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/generic:Program", ptr %t78, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !29
  store ptr %t81, ptr %l46, !tbaa !29
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i64, ptr %l1, !tbaa !24
  %t86 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2efile(ptr %v0, ptr %t82, i64 %t83)
  store i64 %t86, ptr %l49
  br label %bb23
bb23:
  %t87 = getelementptr %"compiler/source:Span", ptr %l6, i32 0, i32 0
  %t88 = load i32, ptr %t87, !tbaa !23
  %t89 = load ptr, ptr %l46, !tbaa !29
  %t90 = load i64, ptr %l49, !tbaa !24
  %t92 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t89, i64 %t90, i32 %t88)
  store %"compiler/names:Ref" %t92, ptr %l51
  br label %bb24
bb24:
  %t93 = load %"compiler/names:Ref", ptr %l51
  store %"compiler/names:Ref" %t93, ptr %l8
  %t94 = getelementptr %"compiler/names:Ref", ptr %l8, i32 0, i32 0
  %t95 = load i32, ptr %t94, !range !{i32 0, i32 9}
  %t97 = trunc i64 8 to i32
  %t98 = icmp eq i32 %t95, %t97
  br i1 %t98, label %bb25, label %bb26
bb25:
  %t100 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t101 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t101, ptr %l55, !tbaa !27
  %t102 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr i32, ptr %t103, i64 0
  %t105 = load i32, ptr %t104, !tbaa !33
  %t108 = call ptr @compiler_2fgeneric_2elisted(ptr %v2, ptr %v2, { i64, ptr } %t100, i32 %t105)
  store ptr %t108, ptr %l57
  br label %bb27
bb26:
  br label %bb32
bb27:
  %t109 = load ptr, ptr %l57, !tbaa !29
  store ptr %t109, ptr %l9, !tbaa !29
  %t110 = load ptr, ptr %l9, !tbaa !29
  %t112 = icmp eq ptr %t110, null
  br i1 %t112, label %bb28, label %bb29
bb28:
  store i64 -1, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load i64, ptr %l1, !tbaa !24
  %t117 = load ptr, ptr %l9, !tbaa !29
  %t121 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2econstraintKey(ptr %v0, ptr %v2, ptr %t115, i64 %t116, ptr %t117)
  store i64 %t121, ptr %l64
  br label %bb31
bb31:
  %t122 = load i64, ptr %l64, !tbaa !24
  store i64 %t122, ptr %rv
  br label %ret
bb32:
  %t123 = getelementptr %"compiler/names:Ref", ptr %l8, i32 0, i32 0
  %t124 = load i32, ptr %t123, !range !{i32 0, i32 9}
  %t126 = trunc i64 4 to i32
  %t127 = icmp eq i32 %t124, %t126
  br i1 %t127, label %bb33, label %bb34
bb33:
  %t129 = getelementptr %"compiler/names:Ref", ptr %l8, i32 0, i32 2
  %t130 = load i64, ptr %t129, !tbaa !24
  %t132 = icmp sge i64 %t130, 0
  store i1 %t132, ptr %l67, !tbaa !21
  br label %bb35
bb34:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb35
bb35:
  %t134 = load i1, ptr %l67, !tbaa !21
  br i1 %t134, label %bb36, label %bb37
bb36:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/names:Ref", ptr %l8, i32 0, i32 1
  %t137 = load i64, ptr %t136, !tbaa !24
  %t138 = getelementptr %"compiler/names:Ref", ptr %l8, i32 0, i32 2
  %t139 = load i64, ptr %t138, !tbaa !24
  %t143 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t135, i64 %t137, i64 %t139)
  store i32 %t143, ptr %l73
  br label %bb38
bb37:
  br label %bb40
bb38:
  %t144 = load i32, ptr %l73, !tbaa !23
  %t145 = call i64 @compiler_2fgeneric_2ekeyDecl(i32 %t144)
  store i64 %t145, ptr %l74
  br label %bb39
bb39:
  %t146 = load i64, ptr %l74, !tbaa !24
  store i64 %t146, ptr %rv
  br label %ret
bb40:
  %t147 = getelementptr %"compiler/names:Ref", ptr %l8, i32 0, i32 0
  %t148 = load i32, ptr %t147, !range !{i32 0, i32 9}
  %t150 = trunc i64 7 to i32
  %t151 = icmp eq i32 %t148, %t150
  br i1 %t151, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s8
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t154, ptr %l78, !tbaa !27
  %t155 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t157 = extractvalue { i64, ptr } %t155, 0
  %t159 = sub i64 %t157, 1
  %t161 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !27
  %t163 = getelementptr i32, ptr %t162, i64 %t159
  %t164 = load i32, ptr %t163, !tbaa !33
  %t167 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t153, i32 %t164)
  store { i64, ptr } %t167, ptr %l83
  br label %bb43
bb42:
  br label %bb55
bb43:
  %t168 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t168, ptr %l10, !tbaa !27
  %t169 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t171 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s8, { i64, ptr } %t169, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d49, i32 0, i32 1) })
  store i1 %t171, ptr %l85
  br label %bb44
bb44:
  %t172 = load i1, ptr %l85, !tbaa !21
  br i1 %t172, label %bb45, label %bb46
bb45:
  %t173 = load i64, ptr @G_2ecompiler_2fgeneric_2eArrayKey, !tbaa !24
  call void @__olang_scope_close(ptr %s8)
  store i64 %t173, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  %t175 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t177 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s8, { i64, ptr } %t175, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d50, i32 0, i32 1) })
  store i1 %t177, ptr %l88
  br label %bb48
bb48:
  %t178 = load i1, ptr %l88, !tbaa !21
  br i1 %t178, label %bb49, label %bb50
bb49:
  %t179 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t181 = call i64 @compiler_2fgeneric_2ekeyPrim(i32 %t179)
  store i64 %t181, ptr %l90
  br label %bb51
bb50:
  br label %bb52
bb51:
  call void @__olang_scope_close(ptr %s8)
  %t182 = load i64, ptr %l90, !tbaa !24
  store i64 %t182, ptr %rv
  br label %ret
bb52:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/generic:Program", ptr %t183, i32 0, i32 2
  %t186 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t189 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v0, ptr %t185, { i64, ptr } %t186)
  store i32 %t189, ptr %l94
  br label %bb53
bb53:
  %t190 = load i32, ptr %l94, !tbaa !23
  %t191 = call i64 @compiler_2fgeneric_2ekeyPrim(i32 %t190)
  store i64 %t191, ptr %l95
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s8)
  %t192 = load i64, ptr %l95, !tbaa !24
  store i64 %t192, ptr %rv
  br label %ret
bb55:
  store i64 -1, ptr %rv
  br label %ret
bb56:
  br i1 true, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb60
bb59:
  store i64 -1, ptr %rv
  br label %ret
bb60:
  call void @__olang_check_failed(ptr @olang_loc_769954e80c04bef7_8801cb066681a71b)
  unreachable
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ereflHead(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l17 = alloca i32
  %l20 = alloca i1
  %l23 = alloca i1
  %l26 = alloca i1
  %l29 = alloca i1
  %l32 = alloca i32
  %l36 = alloca i32
  %l37 = alloca i32
  %l40 = alloca i1
  %l44 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Context", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l2, !tbaa !23
  %t7 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Hfd0413fe7fd4e5914f6cad5b418b7a6d(ptr %v1, ptr %t3, i32 %t4)
  %t8 = extractvalue { i32, i32 } %t7, 1
  %t9 = extractvalue { i32, i32 } %t7, 0
  store i32 %t9, ptr %l11
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i32 %t8, ptr %l10
  br label %bb1
bb1:
  %t12 = load i32, ptr %l10, !tbaa !23
  store i32 %t12, ptr %l6, !tbaa !23
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i32 -1, ptr %l6, !tbaa !23
  br label %bb4
bb4:
  %t13 = load i32, ptr %l6, !tbaa !23
  store i32 %t13, ptr %l3, !tbaa !23
  %t14 = load i32, ptr %l3, !tbaa !23
  %t16 = icmp sge i32 %t14, 0
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/generic:Program", ptr %t18, i32 0, i32 2
  %t21 = load i32, ptr %l3, !tbaa !23
  %t24 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t20, i32 %t21)
  store i32 %t24, ptr %l17
  br label %bb7
bb6:
  br label %bb21
bb7:
  %t25 = load i32, ptr %l17, !range !{i32 0, i32 33}
  store i32 %t25, ptr %l4
  %t26 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t28 = trunc i64 26 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb10
bb9:
  %t31 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t33 = trunc i64 27 to i32
  %t34 = icmp eq i32 %t31, %t33
  store i1 %t34, ptr %l20, !tbaa !21
  br label %bb10
bb10:
  %t36 = load i1, ptr %l20, !tbaa !21
  br i1 %t36, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb13
bb12:
  %t37 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t39 = trunc i64 30 to i32
  %t40 = icmp eq i32 %t37, %t39
  store i1 %t40, ptr %l23, !tbaa !21
  br label %bb13
bb13:
  %t42 = load i1, ptr %l23, !tbaa !21
  br i1 %t42, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb17
bb15:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load i32, ptr %l3, !tbaa !23
  %t47 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsErrVar(ptr %v0, ptr %t43, i32 %t44)
  store i1 %t47, ptr %l29
  br label %bb16
bb16:
  %t48 = load i1, ptr %l29, !tbaa !21
  store i1 %t48, ptr %l26, !tbaa !21
  br label %bb17
bb17:
  %t49 = load i1, ptr %l26, !tbaa !21
  br i1 %t49, label %bb18, label %bb19
bb18:
  store i32 -1, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t51 = load i32, ptr %l3, !tbaa !23
  store i32 %t51, ptr %rv
  br label %ret
bb21:
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Context", ptr %t53, i32 0, i32 3
  %t56 = load i32, ptr %l2, !tbaa !23
  %t59 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Hfd0413fe7fd4e5914f6cad5b418b7a6d(ptr %v1, ptr %t55, i32 %t56)
  %t60 = extractvalue { i32, i32 } %t59, 1
  %t61 = extractvalue { i32, i32 } %t59, 0
  store i32 %t61, ptr %l37
  %t62 = icmp ne i32 %t61, 0
  br i1 %t62, label %bb23, label %ok.63, !prof !99
ok.63:
  store i32 %t60, ptr %l36
  br label %bb22
bb22:
  %t64 = load i32, ptr %l36, !tbaa !23
  store i32 %t64, ptr %l32, !tbaa !23
  br label %bb25
bb23:
  br label %bb24
bb24:
  call void @__olang_ert_req_clear()
  store i32 -1, ptr %l32, !tbaa !23
  br label %bb25
bb25:
  %t65 = load i32, ptr %l32, !tbaa !23
  store i32 %t65, ptr %l5, !tbaa !23
  %t66 = load i32, ptr %l5, !tbaa !23
  %t68 = icmp sge i32 %t66, 0
  br i1 %t68, label %bb26, label %bb27
bb26:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/generic:Program", ptr %t70, i32 0, i32 2
  %t73 = load i32, ptr %l5, !tbaa !23
  %t76 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t72, i32 %t73)
  store i32 %t76, ptr %l44
  br label %bb28
bb27:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb29
bb28:
  %t77 = load i32, ptr %l44, !range !{i32 0, i32 33}
  %t79 = trunc i64 26 to i32
  %t80 = icmp eq i32 %t77, %t79
  %t82 = xor i1 %t80, true
  store i1 %t82, ptr %l40, !tbaa !21
  br label %bb29
bb29:
  %t84 = load i1, ptr %l40, !tbaa !21
  br i1 %t84, label %bb30, label %bb31
bb30:
  %t85 = load i32, ptr %l5, !tbaa !23
  store i32 %t85, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  store i32 -1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eroundTrip(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l12 = alloca { i64, ptr }
  %l15 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = call { i32, i32 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eParseCanon(ptr %v0, ptr %v1, ptr %t1, { i64, ptr } %t2)
  %t6 = extractvalue { i32, i32 } %t5, 1
  %t7 = extractvalue { i32, i32 } %t5, 0
  store i32 %t7, ptr %l7
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9, !prof !99
ok.9:
  store i32 %t6, ptr %l6
  br label %bb1
bb1:
  %t10 = load i32, ptr %l6, !tbaa !23
  store i32 %t10, ptr %l3, !tbaa !23
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb4:
  %t12 = load i32, ptr %l3, !tbaa !23
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  %t19 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s0, ptr %t15, i32 %t12)
  store { i64, ptr } %t19, ptr %l12
  br label %bb5
bb5:
  %t20 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 0
  %t22 = extractvalue { i64, ptr } %t20, 1
  %t23 = mul i64 %t21, 1
  %t24 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t23)
  call void @llvm.memcpy.p0.p0.i64(ptr %t24, ptr %t22, i64 %t23, i1 false)
  %t25 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  %t27 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t30 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %v1, { i64, ptr } %t26, { i64, ptr } %t27)
  store i1 %t30, ptr %l15
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t31 = load i1, ptr %l15, !tbaa !21
  store i1 %t31, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eshape(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i1
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca i1
  %l23 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 5}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr { i64, [6 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { { i64, ptr }, ptr }, ptr %t12, i32 0, i32 0
  %t14 = load { i64, ptr }, ptr %t13
  store { i64, ptr } %t14, ptr %l3, !tbaa !27
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t18 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t22 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eanonEnum(ptr %v0, ptr %v1, ptr %v2, ptr %t16, ptr %t17, { i64, ptr } %t18)
  store i32 %t22, ptr %l15
  br label %bb6
bb6:
  %t23 = load i32, ptr %l15, !tbaa !23
  store i32 %t23, ptr %l5, !tbaa !23
  br label %bb20
bb7:
  %t24 = load ptr, ptr %l2, !tbaa !29
  store ptr %t24, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t25 = load ptr, ptr %l16, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb8, label %bb9
bb8:
  %t28 = load ptr, ptr %l16, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 5}
  %t31 = icmp eq i64 %t29, 0
  store i1 %t31, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t32 = load i1, ptr %l17, !tbaa !21
  br i1 %t32, label %bb10, label %bb11
bb10:
  %t33 = load ptr, ptr %l2, !tbaa !29
  %t35 = getelementptr { i64, [6 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { ptr }, ptr %t35, i32 0, i32 0
  %t37 = load ptr, ptr %t36
  store ptr %t37, ptr %l4, !tbaa !29
  br label %bb12
bb11:
  br label %bb15
bb12:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/generic:Program", ptr %t39, i32 0, i32 2
  store ptr %t41, ptr %l23, !tbaa !29
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t44 = load ptr, ptr %l4, !tbaa !29
  %t46 = getelementptr %"compiler/ast:StructBody", ptr %t44, i32 0, i32 0
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !27
  %t51 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eparamTypes(ptr %v0, ptr %v1, ptr %v2, ptr %t42, ptr %t43, { i64, ptr } %t47)
  store i32 %t51, ptr %l28
  br label %bb13
bb13:
  %t52 = load ptr, ptr %l23, !tbaa !29
  %t53 = load i32, ptr %l28, !tbaa !23
  %t54 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRecord(ptr %v0, ptr %t52, i32 %t53)
  store i32 %t54, ptr %l29
  br label %bb14
bb14:
  %t55 = load i32, ptr %l29, !tbaa !23
  store i32 %t55, ptr %l5, !tbaa !23
  br label %bb20
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  %t56 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t56, ptr %l5, !tbaa !23
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_a096310d429842c5_b38f3d186616d6e9)
  unreachable
bb20:
  %t58 = load i32, ptr %l5, !tbaa !23
  store i32 %t58, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2esubstErrs(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca i32
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca { i64, ptr }
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l46 = alloca i32
  %l53 = alloca i32
  %l60 = alloca i32
  %l64 = alloca ptr
  %l68 = alloca i32
  %l69 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l91 = alloca i32
  %l94 = alloca i1
  %l98 = alloca i64
  %l101 = alloca i1
  %l105 = alloca i64
  %l109 = alloca { i64, ptr }
  %l113 = alloca i64
  %l118 = alloca i32
  %l122 = alloca ptr
  %l126 = alloca i32
  %l127 = alloca { i64, ptr }
  %l134 = alloca { i64, ptr }
  %l144 = alloca i32
  %l156 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l161 = alloca ptr
  %l163 = alloca { i64, ptr }
  %l164 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = icmp eq i32 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i32, ptr %l1, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t5, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 2
  %t10 = load i32, ptr %l3, !tbaa !23
  %t13 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t9, i32 %t10)
  store { i64, ptr } %t13, ptr %l28
  br label %bb4
bb4:
  %t14 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t14, ptr %l4, !tbaa !27
  %t15 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %l29
  br label %bb5
bb5:
  %t16 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l29
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %l5
  store i1 false, ptr %l6, !tbaa !21
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/generic:Program", ptr %t17, i32 0, i32 2
  %t20 = load i32, ptr %l1, !tbaa !23
  %t23 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t19, i32 %t20)
  store { i64, ptr } %t23, ptr %l33
  br label %bb6
bb6:
  %t24 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t24, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t25 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 0
  store i64 %t27, ptr %l9, !tbaa !24
  br label %bb7
bb7:
  %t29 = load i64, ptr %l8, !tbaa !24
  %t30 = load i64, ptr %l9, !tbaa !24
  %t33 = icmp slt i64 %t29, %t30
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb8, label %bb9
bb8:
  br label %bb69
bb9:
  br label %bb10
bb10:
  %t37 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t37, ptr %l40, !tbaa !27
  %t38 = load i64, ptr %l8, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr i32, ptr %t41, i64 %t38
  %t43 = load i32, ptr %t42, !tbaa !33
  store i32 %t43, ptr %l10, !tbaa !23
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/generic:Program", ptr %t45, i32 0, i32 2
  %t48 = load i32, ptr %l10, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t47, i32 %t48)
  store i32 %t51, ptr %l46
  br label %bb11
bb11:
  %t52 = load i32, ptr %l46, !range !{i32 0, i32 33}
  %t54 = trunc i64 27 to i32
  %t55 = icmp eq i32 %t52, %t54
  br i1 %t55, label %bb12, label %bb13
bb12:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load i32, ptr %l10, !tbaa !23
  %t59 = load i64, ptr %l2, !tbaa !24
  %t60 = load i32, ptr %l3, !tbaa !23
  %t65 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %t57, i32 %t58, i64 %t59, i32 %t60)
  store i32 %t65, ptr %l53
  br label %bb14
bb13:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 2
  %t69 = load i32, ptr %l10, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t68, i32 %t69)
  store i32 %t72, ptr %l91
  br label %bb35
bb14:
  %t73 = load i32, ptr %l53, !tbaa !23
  store i32 %t73, ptr %l11, !tbaa !23
  %t74 = load i32, ptr %l11, !tbaa !23
  %t75 = load i32, ptr %l10, !tbaa !23
  %t78 = icmp ne i32 %t74, %t75
  br i1 %t78, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb17
bb16:
  br label %bb17
bb17:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/generic:Program", ptr %t80, i32 0, i32 2
  %t83 = load i32, ptr %l11, !tbaa !23
  %t86 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t82, i32 %t83)
  store i32 %t86, ptr %l60
  br label %bb18
bb18:
  %t87 = load i32, ptr %l60, !range !{i32 0, i32 33}
  %t89 = trunc i64 30 to i32
  %t90 = icmp eq i32 %t87, %t89
  br i1 %t90, label %bb19, label %bb20
bb19:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/generic:Program", ptr %t92, i32 0, i32 2
  store ptr %t94, ptr %l64, !tbaa !29
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/generic:Program", ptr %t95, i32 0, i32 2
  %t98 = load i32, ptr %l11, !tbaa !23
  %t101 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %t97, i32 %t98)
  store i32 %t101, ptr %l68
  br label %bb21
bb20:
  %t102 = load i32, ptr %l11, !tbaa !23
  %t103 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t106 = icmp ne i32 %t102, %t103
  br i1 %t106, label %bb30, label %bb31
bb21:
  %t108 = load ptr, ptr %l64, !tbaa !29
  %t109 = load i32, ptr %l68, !tbaa !23
  %t110 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t108, i32 %t109)
  store { i64, ptr } %t110, ptr %l69
  br label %bb22
bb22:
  %t111 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t111, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t112 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t112, 0
  store i64 %t114, ptr %l14, !tbaa !24
  br label %bb23
bb23:
  %t116 = load i64, ptr %l13, !tbaa !24
  %t117 = load i64, ptr %l14, !tbaa !24
  %t120 = icmp slt i64 %t116, %t117
  %t122 = xor i1 %t120, true
  br i1 %t122, label %bb24, label %bb25
bb24:
  br label %bb29
bb25:
  br label %bb26
bb26:
  %t124 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t124, ptr %l76, !tbaa !27
  %t125 = load i64, ptr %l13, !tbaa !24
  %t127 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !27
  %t129 = getelementptr i32, ptr %t128, i64 %t125
  %t130 = load i32, ptr %t129, !tbaa !33
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l5, i32 %t130)
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t135 = load i64, ptr %l13, !tbaa !24
  %t137 = add i64 %t135, 1
  store i64 %t137, ptr %l13, !tbaa !24
  br label %bb23
bb29:
  br label %bb34
bb30:
  %t139 = load i32, ptr %l11, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l5, i32 %t139)
  br label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb33
bb33:
  br label %bb34
bb34:
  br label %bb67
bb35:
  %t142 = load i32, ptr %l91, !range !{i32 0, i32 33}
  %t144 = trunc i64 25 to i32
  %t145 = icmp eq i32 %t142, %t144
  br i1 %t145, label %bb36, label %bb37
bb36:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/generic:Program", ptr %t147, i32 0, i32 2
  %t150 = load i32, ptr %l10, !tbaa !23
  %t153 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t149, i32 %t150)
  store i64 %t153, ptr %l98
  br label %bb38
bb37:
  store i1 false, ptr %l94, !tbaa !21
  br label %bb39
bb38:
  %t154 = load i64, ptr %l2, !tbaa !24
  %t155 = load i64, ptr %l98, !tbaa !24
  %t157 = icmp eq i64 %t155, %t154
  store i1 %t157, ptr %l94, !tbaa !21
  br label %bb39
bb39:
  %t159 = load i1, ptr %l94, !tbaa !21
  br i1 %t159, label %bb40, label %bb41
bb40:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/generic:Program", ptr %t160, i32 0, i32 2
  %t163 = load i32, ptr %l10, !tbaa !23
  %t166 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t162, i32 %t163)
  store i64 %t166, ptr %l105
  br label %bb42
bb41:
  store i1 false, ptr %l101, !tbaa !21
  br label %bb43
bb42:
  %t167 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t167, 0
  %t170 = load i64, ptr %l105, !tbaa !24
  %t172 = icmp slt i64 %t170, %t169
  store i1 %t172, ptr %l101, !tbaa !21
  br label %bb43
bb43:
  %t174 = load i1, ptr %l101, !tbaa !21
  br i1 %t174, label %bb44, label %bb45
bb44:
  %t175 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t175, ptr %l109, !tbaa !27
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr %"compiler/generic:Program", ptr %t176, i32 0, i32 2
  %t179 = load i32, ptr %l10, !tbaa !23
  %t182 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t178, i32 %t179)
  store i64 %t182, ptr %l113
  br label %bb46
bb45:
  %t183 = load i32, ptr %l10, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l5, i32 %t183)
  br label %bb65
bb46:
  %t186 = load i64, ptr %l113, !tbaa !24
  %t187 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t188 = load ptr, ptr %t187, !tbaa !27
  %t189 = getelementptr i32, ptr %t188, i64 %t186
  %t190 = load i32, ptr %t189, !tbaa !33
  store i32 %t190, ptr %l16, !tbaa !23
  store i1 true, ptr %l6, !tbaa !21
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr %"compiler/generic:Program", ptr %t192, i32 0, i32 2
  %t195 = load i32, ptr %l16, !tbaa !23
  %t198 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t194, i32 %t195)
  store i32 %t198, ptr %l118
  br label %bb47
bb47:
  %t199 = load i32, ptr %l118, !range !{i32 0, i32 33}
  %t201 = trunc i64 30 to i32
  %t202 = icmp eq i32 %t199, %t201
  br i1 %t202, label %bb48, label %bb49
bb48:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = getelementptr %"compiler/generic:Program", ptr %t204, i32 0, i32 2
  store ptr %t206, ptr %l122, !tbaa !29
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t209 = getelementptr %"compiler/generic:Program", ptr %t207, i32 0, i32 2
  %t210 = load i32, ptr %l16, !tbaa !23
  %t213 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %t209, i32 %t210)
  store i32 %t213, ptr %l126
  br label %bb50
bb49:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/generic:Program", ptr %t214, i32 0, i32 2
  %t217 = load i32, ptr %l16, !tbaa !23
  %t220 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t216, i32 %t217)
  store i32 %t220, ptr %l144
  br label %bb59
bb50:
  %t221 = load ptr, ptr %l122, !tbaa !29
  %t222 = load i32, ptr %l126, !tbaa !23
  %t223 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t221, i32 %t222)
  store { i64, ptr } %t223, ptr %l127
  br label %bb51
bb51:
  %t224 = load { i64, ptr }, ptr %l127, !tbaa !27
  store { i64, ptr } %t224, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t225 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t227 = extractvalue { i64, ptr } %t225, 0
  store i64 %t227, ptr %l19, !tbaa !24
  br label %bb52
bb52:
  %t229 = load i64, ptr %l18, !tbaa !24
  %t230 = load i64, ptr %l19, !tbaa !24
  %t233 = icmp slt i64 %t229, %t230
  %t235 = xor i1 %t233, true
  br i1 %t235, label %bb53, label %bb54
bb53:
  br label %bb58
bb54:
  br label %bb55
bb55:
  %t237 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t237, ptr %l134, !tbaa !27
  %t238 = load i64, ptr %l18, !tbaa !24
  %t240 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t241 = load ptr, ptr %t240, !tbaa !27
  %t242 = getelementptr i32, ptr %t241, i64 %t238
  %t243 = load i32, ptr %t242, !tbaa !33
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l5, i32 %t243)
  br label %bb56
bb56:
  br label %bb57
bb57:
  %t248 = load i64, ptr %l18, !tbaa !24
  %t250 = add i64 %t248, 1
  store i64 %t250, ptr %l18, !tbaa !24
  br label %bb52
bb58:
  br label %bb64
bb59:
  %t252 = load i32, ptr %l144, !range !{i32 0, i32 33}
  %t254 = trunc i64 25 to i32
  %t255 = icmp eq i32 %t252, %t254
  br i1 %t255, label %bb60, label %bb61
bb60:
  %t257 = load i32, ptr %l16, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l5, i32 %t257)
  br label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb63
bb63:
  br label %bb64
bb64:
  br label %bb66
bb65:
  br label %bb66
bb66:
  br label %bb67
bb67:
  br label %bb68
bb68:
  %t260 = load i64, ptr %l8, !tbaa !24
  %t262 = add i64 %t260, 1
  store i64 %t262, ptr %l8, !tbaa !24
  br label %bb7
bb69:
  %t264 = load i1, ptr %l6, !tbaa !21
  %t266 = xor i1 %t264, true
  br i1 %t266, label %bb70, label %bb71
bb70:
  %t268 = load i32, ptr %l1, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t268, ptr %rv
  br label %ret
bb71:
  br label %bb72
bb72:
  %t270 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t270, ptr %l156
  br label %bb73
bb73:
  %t271 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l156
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t271, ptr %l21
  %t272 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emergeEntries(ptr %v0, ptr %s0, ptr %s0, ptr %t272, ptr %l5, ptr %l21)
  br label %bb74
bb74:
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t278 = getelementptr %"compiler/generic:Program", ptr %t276, i32 0, i32 2
  store ptr %t278, ptr %l161, !tbaa !29
  %t280 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %s0, ptr %l21)
  store { i64, ptr } %t280, ptr %l163
  br label %bb75
bb75:
  %t281 = load ptr, ptr %l161, !tbaa !29
  %t282 = load { i64, ptr }, ptr %l163, !tbaa !27
  %t283 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t281, { i64, ptr } %t282)
  store i32 %t283, ptr %l164
  br label %bb76
bb76:
  call void @__olang_scope_close(ptr %s0)
  %t284 = load i32, ptr %l164, !tbaa !23
  store i32 %t284, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2esubstList(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l18 = alloca { i64, ptr }
  %l20 = alloca i64
  %l29 = alloca i64
  %l32 = alloca i64
  %l50 = alloca i64
  %l52 = alloca { i64, ptr }
  %l57 = alloca i32
  %l63 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = icmp eq i32 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i32, ptr %l1, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t5, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 2
  %t10 = load i32, ptr %l1, !tbaa !23
  %t13 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t9, i32 %t10)
  store { i64, ptr } %t13, ptr %l18
  br label %bb4
bb4:
  %t14 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t14, ptr %l4, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  store i64 %t17, ptr %l20, !tbaa !24
  %t18 = load i64, ptr %l20, !tbaa !24
  %t19 = icmp sge i64 %t18, 0
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t21 = load i64, ptr %l20, !tbaa !24
  %t22 = icmp sle i64 %t21, 2305843009213693951
  br i1 %t22, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_4439a413e01d0c26_16c6d6890310944a)
  unreachable
bb7:
  %t24 = load i64, ptr %l20, !tbaa !24
  %t25 = mul i64 %t24, 4
  %t26 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t30 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t30, 0
  store i64 %t32, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t34 = load i64, ptr %l7, !tbaa !24
  %t35 = load i64, ptr %l6, !tbaa !24
  %t38 = icmp sgt i64 %t34, %t35
  br i1 %t38, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_4439a413e01d0c26_16c6d6890310944a)
  unreachable
bb9:
  %t40 = load i64, ptr %l8, !tbaa !24
  %t42 = icmp sgt i64 %t40, 0
  br i1 %t42, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb14
bb11:
  %t44 = load i64, ptr %l7, !tbaa !24
  %t45 = load i64, ptr %l6, !tbaa !24
  %t48 = sub i64 %t44, %t45
  %t49 = load i64, ptr %l8, !tbaa !24
  %t52 = add i64 %t48, %t49
  %t54 = sub i64 %t52, 1
  %t55 = load i64, ptr %l8, !tbaa !24
  %t58 = sdiv i64 %t54, %t55
  store i64 %t58, ptr %l32, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb13
bb13:
  %t60 = load i64, ptr %l32, !tbaa !24
  store i64 %t60, ptr %l29, !tbaa !24
  br label %bb14
bb14:
  %t61 = load i64, ptr %l29, !tbaa !24
  store i64 %t61, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb15
bb15:
  %t62 = load i64, ptr %l10, !tbaa !24
  %t63 = load i64, ptr %l9, !tbaa !24
  %t66 = icmp slt i64 %t62, %t63
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb16, label %bb17
bb16:
  br label %bb21
bb17:
  br label %bb18
bb18:
  %t70 = load i64, ptr %l6, !tbaa !24
  %t71 = load i64, ptr %l10, !tbaa !24
  %t72 = load i64, ptr %l8, !tbaa !24
  %t75 = mul i64 %t71, %t72
  %t78 = add i64 %t70, %t75
  store i64 %t78, ptr %l11, !tbaa !24
  %t80 = load i64, ptr %l11, !tbaa !24
  store i64 %t80, ptr %l50, !tbaa !24
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t82, ptr %l52, !tbaa !27
  %t83 = load i64, ptr %l11, !tbaa !24
  %t85 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = getelementptr i32, ptr %t86, i64 %t83
  %t88 = load i32, ptr %t87, !tbaa !33
  %t95 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %t81, i32 %t88, i64 %a2, i32 %a3)
  store i32 %t95, ptr %l57
  br label %bb19
bb19:
  %t96 = load i32, ptr %l57, !tbaa !23
  %t97 = load i64, ptr %l50, !tbaa !24
  %t98 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr i32, ptr %t99, i64 %t97
  store i32 %t96, ptr %t100, !tbaa !33
  br label %bb20
bb20:
  %t101 = load i64, ptr %l10, !tbaa !24
  %t103 = add i64 %t101, 1
  store i64 %t103, ptr %l10, !tbaa !24
  br label %bb15
bb21:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/generic:Program", ptr %t105, i32 0, i32 2
  %t108 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t111 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t107, { i64, ptr } %t108)
  store i32 %t111, ptr %l63
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t112 = load i32, ptr %l63, !tbaa !23
  store i32 %t112, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2esuppliedMeets(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i32
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i32
  %l24 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca { i64, ptr }
  %l32 = alloca i1
  %l36 = alloca i32
  %l40 = alloca i1
  %l44 = alloca i32
  %l47 = alloca i32
  %l51 = alloca i32
  %l56 = alloca i64
  %l59 = alloca i64
  %l80 = alloca i1
  %l84 = alloca i64
  %l88 = alloca i32
  %l90 = alloca ptr
  %l93 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l97 = alloca i32
  %l101 = alloca i1
  %l107 = alloca i32
  %l114 = alloca i32
  %l119 = alloca i1
  %l122 = alloca i1
  %l124 = alloca i1
  %l128 = alloca i32
  %l131 = alloca i32
  %l135 = alloca i32
  %l140 = alloca i64
  %l143 = alloca i64
  %l164 = alloca i32
  %l170 = alloca i1
  %l176 = alloca i32
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t3, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d51, i32 0, i32 1) })
  store i32 %t5, ptr %l22
  br label %bb1
bb1:
  %t6 = load i32, ptr %l22, !tbaa !23
  store i32 %t6, ptr %l4, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 2
  store ptr %t9, ptr %l24, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l28
  br label %bb2
bb2:
  %t17 = load ptr, ptr %l24, !tbaa !29
  %t18 = load i32, ptr %l28, !tbaa !23
  %t19 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t17, i32 %t18)
  store { i64, ptr } %t19, ptr %l29
  br label %bb3
bb3:
  %t20 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 0
  %t23 = icmp ne i64 %t21, 0
  br i1 %t23, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb7
bb5:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  %t28 = load i32, ptr %l3, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l36
  br label %bb6
bb6:
  %t32 = load i32, ptr %l36, !tbaa !23
  %t33 = icmp ne i32 %t32, 0
  store i1 %t33, ptr %l32, !tbaa !21
  br label %bb7
bb7:
  %t35 = load i1, ptr %l32, !tbaa !21
  br i1 %t35, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t37 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t39 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t37, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d52, i32 0, i32 1) })
  store i1 %t39, ptr %l40
  br label %bb11
bb11:
  %t40 = load i1, ptr %l40, !tbaa !21
  br i1 %t40, label %bb12, label %bb13
bb12:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/generic:Program", ptr %t41, i32 0, i32 2
  %t44 = load i32, ptr %l1, !tbaa !23
  %t47 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t43, i32 %t44)
  store i32 %t47, ptr %l44
  br label %bb14
bb13:
  br label %bb49
bb14:
  %t48 = load i32, ptr %l44, !range !{i32 0, i32 33}
  %t50 = trunc i64 20 to i32
  %t51 = icmp eq i32 %t48, %t50
  br i1 %t51, label %bb15, label %bb16
bb15:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 2
  %t56 = load i32, ptr %l1, !tbaa !23
  %t59 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t55, i32 %t56)
  store i32 %t59, ptr %l51
  br label %bb17
bb16:
  %t60 = load i32, ptr %l1, !tbaa !23
  store i32 %t60, ptr %l47, !tbaa !23
  br label %bb18
bb17:
  %t62 = load i32, ptr %l51, !tbaa !23
  store i32 %t62, ptr %l47, !tbaa !23
  br label %bb18
bb18:
  %t63 = load i32, ptr %l47, !tbaa !23
  store i32 %t63, ptr %l5, !tbaa !23
  store i64 0, ptr %l6, !tbaa !24
  store i64 16, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t64 = load i64, ptr %l7, !tbaa !24
  %t65 = load i64, ptr %l6, !tbaa !24
  %t68 = icmp sgt i64 %t64, %t65
  br i1 %t68, label %bb19, label %bb20
bb19:
  %t70 = load i64, ptr %l8, !tbaa !24
  %t72 = icmp sgt i64 %t70, 0
  br i1 %t72, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb24
bb21:
  %t74 = load i64, ptr %l7, !tbaa !24
  %t75 = load i64, ptr %l6, !tbaa !24
  %t78 = sub i64 %t74, %t75
  %t79 = load i64, ptr %l8, !tbaa !24
  %t82 = add i64 %t78, %t79
  %t84 = sub i64 %t82, 1
  %t85 = load i64, ptr %l8, !tbaa !24
  %t88 = sdiv i64 %t84, %t85
  store i64 %t88, ptr %l59, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb23
bb23:
  %t90 = load i64, ptr %l59, !tbaa !24
  store i64 %t90, ptr %l56, !tbaa !24
  br label %bb24
bb24:
  %t91 = load i64, ptr %l56, !tbaa !24
  store i64 %t91, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb25
bb25:
  %t92 = load i64, ptr %l10, !tbaa !24
  %t93 = load i64, ptr %l9, !tbaa !24
  %t96 = icmp slt i64 %t92, %t93
  %t98 = xor i1 %t96, true
  br i1 %t98, label %bb26, label %bb27
bb26:
  br label %bb48
bb27:
  br label %bb28
bb28:
  %t100 = load i64, ptr %l6, !tbaa !24
  %t101 = load i64, ptr %l10, !tbaa !24
  %t102 = load i64, ptr %l8, !tbaa !24
  %t105 = mul i64 %t101, %t102
  %t108 = add i64 %t100, %t105
  store i64 %t108, ptr %l11, !tbaa !24
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/generic:Program", ptr %t110, i32 0, i32 2
  %t113 = load i32, ptr %l5, !tbaa !23
  %t116 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t112, i32 %t113)
  store i1 %t116, ptr %l80
  br label %bb29
bb29:
  %t117 = load i1, ptr %l80, !tbaa !21
  br i1 %t117, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s5
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/generic:Program", ptr %t118, i32 0, i32 2
  %t121 = load i32, ptr %l5, !tbaa !23
  %t124 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t120, i32 %t121)
  store i64 %t124, ptr %l84
  br label %bb32
bb31:
  br label %bb41
bb32:
  %t125 = load i64, ptr %l84, !tbaa !24
  store i64 %t125, ptr %l12, !tbaa !24
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/generic:Program", ptr %t126, i32 0, i32 2
  %t129 = load i32, ptr %l3, !tbaa !23
  %t132 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t128, i32 %t129)
  store i32 %t132, ptr %l88
  br label %bb33
bb33:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/generic:Program", ptr %t133, i32 0, i32 2
  store ptr %t135, ptr %l90, !tbaa !29
  %t136 = load i64, ptr %l12, !tbaa !24
  %t138 = icmp eq i64 %t136, 64
  br i1 %t138, label %bb34, label %bb35
bb34:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d53, i32 0, i32 1) }, ptr %l93, !tbaa !27
  br label %bb39
bb35:
  %t140 = load i64, ptr %l12, !tbaa !24
  %t142 = icmp eq i64 %t140, 32
  br i1 %t142, label %bb36, label %bb37
bb36:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d54, i32 0, i32 1) }, ptr %l96, !tbaa !27
  br label %bb38
bb37:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d55, i32 0, i32 1) }, ptr %l96, !tbaa !27
  br label %bb38
bb38:
  %t144 = load { i64, ptr }, ptr %l96, !tbaa !27
  store { i64, ptr } %t144, ptr %l93, !tbaa !27
  br label %bb39
bb39:
  %t145 = load ptr, ptr %l90, !tbaa !29
  %t146 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t147 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s5, ptr %t145, { i64, ptr } %t146)
  store i32 %t147, ptr %l97
  br label %bb40
bb40:
  %t148 = load i32, ptr %l88, !tbaa !23
  %t149 = load i32, ptr %l97, !tbaa !23
  %t150 = icmp eq i32 %t148, %t149
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store i1 %t150, ptr %rv
  br label %ret
bb41:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load i32, ptr %l5, !tbaa !23
  %t156 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t152, i32 %t153)
  store i1 %t156, ptr %l101
  br label %bb42
bb42:
  %t157 = load i1, ptr %l101, !tbaa !21
  %t158 = xor i1 %t157, true
  br i1 %t158, label %bb43, label %bb44
bb43:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/generic:Program", ptr %t161, i32 0, i32 2
  %t164 = load i32, ptr %l5, !tbaa !23
  %t167 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t163, i32 %t164)
  store i32 %t167, ptr %l107
  br label %bb46
bb46:
  %t168 = load i32, ptr %l107, !tbaa !23
  store i32 %t168, ptr %l5, !tbaa !23
  br label %bb47
bb47:
  %t169 = load i64, ptr %l10, !tbaa !24
  %t171 = add i64 %t169, 1
  store i64 %t171, ptr %l10, !tbaa !24
  br label %bb25
bb48:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb49:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/generic:Program", ptr %t174, i32 0, i32 2
  %t177 = load i32, ptr %l3, !tbaa !23
  %t180 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t176, i32 %t177)
  store i32 %t180, ptr %l114
  br label %bb50
bb50:
  %t181 = load i32, ptr %l4, !tbaa !23
  %t182 = load i32, ptr %l114, !tbaa !23
  %t184 = icmp ne i32 %t182, %t181
  br i1 %t184, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb52:
  br label %bb53
bb53:
  %t187 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t189 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t187, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d56, i32 0, i32 1) })
  store i1 %t189, ptr %l119
  br label %bb54
bb54:
  %t190 = load i1, ptr %l119, !tbaa !21
  br i1 %t190, label %bb55, label %bb56
bb55:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t192 = load i32, ptr %l1, !tbaa !23
  %t195 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eHasHash(ptr %v0, ptr %t191, i32 %t192)
  store i1 %t195, ptr %l122
  br label %bb57
bb56:
  br label %bb58
bb57:
  call void @__olang_scope_close(ptr %s0)
  %t196 = load i1, ptr %l122, !tbaa !21
  store i1 %t196, ptr %rv
  br label %ret
bb58:
  %t197 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t199 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t197, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d57, i32 0, i32 1) })
  store i1 %t199, ptr %l124
  br label %bb59
bb59:
  %t200 = load i1, ptr %l124, !tbaa !21
  br i1 %t200, label %bb60, label %bb61
bb60:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"compiler/generic:Program", ptr %t201, i32 0, i32 2
  %t204 = load i32, ptr %l1, !tbaa !23
  %t207 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t203, i32 %t204)
  store i32 %t207, ptr %l128
  br label %bb62
bb61:
  br label %bb88
bb62:
  %t208 = load i32, ptr %l128, !range !{i32 0, i32 33}
  %t210 = trunc i64 20 to i32
  %t211 = icmp eq i32 %t208, %t210
  br i1 %t211, label %bb63, label %bb64
bb63:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = getelementptr %"compiler/generic:Program", ptr %t213, i32 0, i32 2
  %t216 = load i32, ptr %l1, !tbaa !23
  %t219 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t215, i32 %t216)
  store i32 %t219, ptr %l135
  br label %bb65
bb64:
  %t220 = load i32, ptr %l1, !tbaa !23
  store i32 %t220, ptr %l131, !tbaa !23
  br label %bb66
bb65:
  %t222 = load i32, ptr %l135, !tbaa !23
  store i32 %t222, ptr %l131, !tbaa !23
  br label %bb66
bb66:
  %t223 = load i32, ptr %l131, !tbaa !23
  store i32 %t223, ptr %l13, !tbaa !23
  store i64 0, ptr %l14, !tbaa !24
  store i64 16, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t224 = load i64, ptr %l15, !tbaa !24
  %t225 = load i64, ptr %l14, !tbaa !24
  %t228 = icmp sgt i64 %t224, %t225
  br i1 %t228, label %bb67, label %bb68
bb67:
  %t230 = load i64, ptr %l16, !tbaa !24
  %t232 = icmp sgt i64 %t230, 0
  br i1 %t232, label %bb69, label %bb70
bb68:
  store i64 0, ptr %l140, !tbaa !24
  br label %bb72
bb69:
  %t234 = load i64, ptr %l15, !tbaa !24
  %t235 = load i64, ptr %l14, !tbaa !24
  %t238 = sub i64 %t234, %t235
  %t239 = load i64, ptr %l16, !tbaa !24
  %t242 = add i64 %t238, %t239
  %t244 = sub i64 %t242, 1
  %t245 = load i64, ptr %l16, !tbaa !24
  %t248 = sdiv i64 %t244, %t245
  store i64 %t248, ptr %l143, !tbaa !24
  br label %bb71
bb70:
  store i64 0, ptr %l143, !tbaa !24
  br label %bb71
bb71:
  %t250 = load i64, ptr %l143, !tbaa !24
  store i64 %t250, ptr %l140, !tbaa !24
  br label %bb72
bb72:
  %t251 = load i64, ptr %l140, !tbaa !24
  store i64 %t251, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb73
bb73:
  %t252 = load i64, ptr %l18, !tbaa !24
  %t253 = load i64, ptr %l17, !tbaa !24
  %t256 = icmp slt i64 %t252, %t253
  %t258 = xor i1 %t256, true
  br i1 %t258, label %bb74, label %bb75
bb74:
  br label %bb87
bb75:
  br label %bb76
bb76:
  %t260 = load i64, ptr %l14, !tbaa !24
  %t261 = load i64, ptr %l18, !tbaa !24
  %t262 = load i64, ptr %l16, !tbaa !24
  %t265 = mul i64 %t261, %t262
  %t268 = add i64 %t260, %t265
  store i64 %t268, ptr %l19, !tbaa !24
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t272 = getelementptr %"compiler/generic:Program", ptr %t270, i32 0, i32 2
  %t273 = load i32, ptr %l13, !tbaa !23
  %t276 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t272, i32 %t273)
  store i32 %t276, ptr %l164
  br label %bb77
bb77:
  %t277 = load i32, ptr %l164, !range !{i32 0, i32 33}
  %t279 = trunc i64 19 to i32
  %t280 = icmp eq i32 %t277, %t279
  br i1 %t280, label %bb78, label %bb79
bb78:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb79:
  br label %bb80
bb80:
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t284 = load i32, ptr %l13, !tbaa !23
  %t287 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t283, i32 %t284)
  store i1 %t287, ptr %l170
  br label %bb81
bb81:
  %t288 = load i1, ptr %l170, !tbaa !21
  %t289 = xor i1 %t288, true
  br i1 %t289, label %bb82, label %bb83
bb82:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb83:
  br label %bb84
bb84:
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = getelementptr %"compiler/generic:Program", ptr %t292, i32 0, i32 2
  %t295 = load i32, ptr %l13, !tbaa !23
  %t298 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t294, i32 %t295)
  store i32 %t298, ptr %l176
  br label %bb85
bb85:
  %t299 = load i32, ptr %l176, !tbaa !23
  store i32 %t299, ptr %l13, !tbaa !23
  br label %bb86
bb86:
  %t300 = load i64, ptr %l18, !tbaa !24
  %t302 = add i64 %t300, 1
  store i64 %t302, ptr %l18, !tbaa !24
  br label %bb73
bb87:
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunaryType(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i32 %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l7 = alloca i1
  %l15 = alloca i32
  %l19 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t3 = trunc i64 53 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t8 = trunc i64 88 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l7, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l7, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t21 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInfer(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t12, ptr %a1, ptr %a2, ptr %a4)
  store i32 %t21, ptr %l15
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t22 = load i32, ptr %l15, !tbaa !23
  store i32 %t22, ptr %rv
  br label %ret
bb7:
  %t23 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t25 = trunc i64 89 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb8, label %bb9
bb8:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etextType(ptr %v0, ptr %t28)
  store i32 %t30, ptr %l19
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t31 = load i32, ptr %l19, !tbaa !23
  store i32 %t31, ptr %rv
  br label %ret
bb11:
  %t32 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t34 = trunc i64 48 to i32
  %t35 = icmp eq i32 %t32, %t34
  br i1 %t35, label %bb12, label %bb13
bb12:
  %t37 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t37, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t39 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t39, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunendedFields(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l14 = alloca i1
  %l16 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l36 = alloca i32
  %l38 = alloca i1
  %l42 = alloca i32
  %l45 = alloca i32
  %l46 = alloca ptr
  %l50 = alloca i32
  %l53 = alloca i32
  %l59 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l1, !tbaa !23
  %t7 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eEnds(ptr %v0, ptr %t3, i32 %t4)
  store i1 %t7, ptr %l14
  br label %bb1
bb1:
  %t8 = load i1, ptr %l14, !tbaa !21
  store i1 %t8, ptr %l4, !tbaa !21
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 2
  store ptr %t11, ptr %l16, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/generic:Program", ptr %t12, i32 0, i32 2
  %t15 = load i32, ptr %l1, !tbaa !23
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t14, i32 %t15)
  store i32 %t18, ptr %l20
  br label %bb2
bb2:
  %t19 = load ptr, ptr %l16, !tbaa !29
  %t20 = load i32, ptr %l20, !tbaa !23
  %t21 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t19, i32 %t20)
  store { i64, ptr } %t21, ptr %l21
  br label %bb3
bb3:
  %t22 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t22, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t23 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 0
  store i64 %t25, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  %t27 = load i64, ptr %l6, !tbaa !24
  %t28 = load i64, ptr %l7, !tbaa !24
  %t31 = icmp slt i64 %t27, %t28
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb5, label %bb6
bb5:
  br label %bb26
bb6:
  br label %bb7
bb7:
  %t35 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t35, ptr %l28, !tbaa !27
  %t36 = load i64, ptr %l6, !tbaa !24
  %t38 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr i32, ptr %t39, i64 %t36
  %t41 = load i32, ptr %t40, !tbaa !33
  store i32 %t41, ptr %l8, !tbaa !23
  %t43 = load i32, ptr %l8, !tbaa !23
  %t45 = icmp eq i32 %t43, 0
  br i1 %t45, label %bb8, label %bb9
bb8:
  br label %bb25
bb9:
  br label %bb10
bb10:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 2
  %t50 = load i32, ptr %l8, !tbaa !23
  %t53 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t49, i32 %t50)
  store i32 %t53, ptr %l36
  br label %bb11
bb11:
  %t54 = load i32, ptr %l36, !tbaa !23
  store i32 %t54, ptr %l9, !tbaa !23
  %t55 = load i1, ptr %l4, !tbaa !21
  br i1 %t55, label %bb12, label %bb13
bb12:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/generic:Program", ptr %t57, i32 0, i32 2
  %t60 = load i32, ptr %l9, !tbaa !23
  %t63 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t59, i32 %t60)
  store i32 %t63, ptr %l42
  br label %bb14
bb13:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb15
bb14:
  %t64 = load i32, ptr %l42, !range !{i32 0, i32 33}
  %t66 = trunc i64 19 to i32
  %t67 = icmp eq i32 %t64, %t66
  store i1 %t67, ptr %l38, !tbaa !21
  br label %bb15
bb15:
  %t69 = load i1, ptr %l38, !tbaa !21
  br i1 %t69, label %bb16, label %bb17
bb16:
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l46, !tbaa !29
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/generic:Program", ptr %t71, i32 0, i32 2
  %t74 = load i32, ptr %l9, !tbaa !23
  %t77 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t73, i32 %t74)
  store i32 %t77, ptr %l50
  br label %bb18
bb17:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load i32, ptr %l8, !tbaa !23
  %t80 = load ptr, ptr %l2, !tbaa !29
  %t81 = load i64, ptr %l3, !tbaa !24
  %t83 = add i64 %t81, 1
  %t88 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunended(ptr %v0, ptr %v1, ptr %t78, i32 %t79, ptr %t80, i64 %t83)
  store i32 %t88, ptr %l59
  br label %bb20
bb18:
  %t89 = load ptr, ptr %l2, !tbaa !29
  %t90 = load i64, ptr %l3, !tbaa !24
  %t91 = load ptr, ptr %l46, !tbaa !29
  %t92 = load i32, ptr %l50, !tbaa !23
  %t95 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ebufferUnended(ptr %v0, ptr %v1, ptr %t91, i32 %t92, ptr %t89, i64 %t90)
  store i32 %t95, ptr %l53
  br label %bb19
bb19:
  %t96 = load i32, ptr %l53, !tbaa !23
  store i32 %t96, ptr %l45, !tbaa !23
  br label %bb21
bb20:
  %t97 = load i32, ptr %l59, !tbaa !23
  store i32 %t97, ptr %l45, !tbaa !23
  br label %bb21
bb21:
  %t98 = load i32, ptr %l45, !tbaa !23
  store i32 %t98, ptr %l10, !tbaa !23
  %t99 = load i32, ptr %l10, !tbaa !23
  %t100 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t103 = icmp ne i32 %t99, %t100
  br i1 %t103, label %bb22, label %bb23
bb22:
  %t105 = load i32, ptr %l10, !tbaa !23
  store i32 %t105, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t107 = load i64, ptr %l6, !tbaa !24
  %t109 = add i64 %t107, 1
  store i64 %t109, ptr %l6, !tbaa !24
  br label %bb4
bb26:
  %t111 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t111, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunendedIn(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca i32
  %l16 = alloca { i64, ptr }
  %l26 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l6, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l5, !tbaa !24
  %t8 = load i64, ptr %l6, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb13
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t15, ptr %l16, !tbaa !27
  %t16 = load i64, ptr %l5, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i32, ptr %t19, i64 %t16
  %t21 = load i32, ptr %t20, !tbaa !33
  store i32 %t21, ptr %l7, !tbaa !23
  %t23 = load i32, ptr %l7, !tbaa !23
  %t25 = icmp eq i32 %t23, 0
  br i1 %t25, label %bb5, label %bb6
bb5:
  br label %bb12
bb6:
  br label %bb7
bb7:
  %t28 = load i32, ptr %l7, !tbaa !23
  %t32 = add i64 %a3, 1
  %t37 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunended(ptr %v0, ptr %v2, ptr %a0, i32 %t28, ptr %a2, i64 %t32)
  store i32 %t37, ptr %l26
  br label %bb8
bb8:
  %t38 = load i32, ptr %l26, !tbaa !23
  store i32 %t38, ptr %l8, !tbaa !23
  %t39 = load i32, ptr %l8, !tbaa !23
  %t40 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t43 = icmp ne i32 %t39, %t40
  br i1 %t43, label %bb9, label %bb10
bb9:
  %t45 = load i32, ptr %l8, !tbaa !23
  store i32 %t45, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t47 = load i64, ptr %l5, !tbaa !24
  %t49 = add i64 %t47, 1
  store i64 %t49, ptr %l5, !tbaa !24
  br label %bb1
bb13:
  %t51 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t51, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunendedNamed(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i32
  %l7 = alloca i1
  %l8 = alloca i1
  %l11 = alloca i1
  %l17 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca i32
  %l30 = alloca i32
  %l33 = alloca ptr
  %l35 = alloca ptr
  %l39 = alloca i32
  %l40 = alloca { i64, ptr }
  %l43 = alloca i32
  %l46 = alloca ptr
  %l50 = alloca i32
  %l54 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_Hb3133f486435530b533aaf49461c92b5(ptr %v1, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i1, ptr %l7, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb5
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t7, i32 %t8)
  store i1 %t11, ptr %l11
  br label %bb4
bb4:
  %t12 = load i1, ptr %l11, !tbaa !21
  %t13 = xor i1 %t12, true
  store i1 %t13, ptr %l8, !tbaa !21
  br label %bb5
bb5:
  %t15 = load i1, ptr %l8, !tbaa !21
  br i1 %t15, label %bb6, label %bb7
bb6:
  %t16 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t16, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t19 = load i32, ptr %l1, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H64d9be73b6c9bed004c541bdf7f0ca0a(ptr %v1, ptr %t18, i32 %t19, i1 true)
  br label %bb9
bb9:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 2
  store ptr %t24, ptr %l17, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  %t28 = load i32, ptr %l1, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l21
  br label %bb10
bb10:
  %t32 = load ptr, ptr %l17, !tbaa !29
  %t33 = load i32, ptr %l21, !tbaa !23
  %t34 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t32, i32 %t33)
  store i32 %t34, ptr %l22
  br label %bb11
bb11:
  %t35 = load i32, ptr %l22, !range !{i32 0, i32 6}
  store i32 %t35, ptr %l4
  %t36 = load i32, ptr %l4, !range !{i32 0, i32 6}
  %t38 = trunc i64 0 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i32, ptr %l1, !tbaa !23
  %t43 = load ptr, ptr %l2, !tbaa !29
  %t44 = load i64, ptr %l3, !tbaa !24
  %t49 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunendedFields(ptr %v0, ptr %v1, ptr %t41, i32 %t42, ptr %t43, i64 %t44)
  store i32 %t49, ptr %l30
  br label %bb15
bb15:
  %t50 = load i32, ptr %l30, !tbaa !23
  store i32 %t50, ptr %l23, !tbaa !23
  br label %bb34
bb16:
  %t51 = load i32, ptr %l4, !range !{i32 0, i32 6}
  %t53 = trunc i64 1 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb23
bb19:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l33, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/generic:Program", ptr %t57, i32 0, i32 2
  store ptr %t59, ptr %l35, !tbaa !29
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/generic:Program", ptr %t60, i32 0, i32 2
  %t63 = load i32, ptr %l1, !tbaa !23
  %t66 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t62, i32 %t63)
  store i32 %t66, ptr %l39
  br label %bb20
bb20:
  %t67 = load ptr, ptr %l35, !tbaa !29
  %t68 = load i32, ptr %l39, !tbaa !23
  %t69 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t67, i32 %t68)
  store { i64, ptr } %t69, ptr %l40
  br label %bb21
bb21:
  %t70 = load ptr, ptr %l2, !tbaa !29
  %t71 = load i64, ptr %l3, !tbaa !24
  %t72 = load ptr, ptr %l33, !tbaa !29
  %t73 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t76 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunendedIn(ptr %v0, ptr %v0, ptr %v1, ptr %t72, { i64, ptr } %t73, ptr %t70, i64 %t71)
  store i32 %t76, ptr %l43
  br label %bb22
bb22:
  %t77 = load i32, ptr %l43, !tbaa !23
  store i32 %t77, ptr %l23, !tbaa !23
  br label %bb34
bb23:
  %t78 = load i32, ptr %l4, !range !{i32 0, i32 6}
  %t80 = trunc i64 4 to i32
  %t81 = icmp eq i32 %t78, %t80
  br i1 %t81, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb29
bb26:
  %t83 = load ptr, ptr %l0, !tbaa !29
  store ptr %t83, ptr %l46, !tbaa !29
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/generic:Program", ptr %t84, i32 0, i32 2
  %t87 = load i32, ptr %l1, !tbaa !23
  %t90 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t86, i32 %t87)
  store i32 %t90, ptr %l50
  br label %bb27
bb27:
  %t91 = load ptr, ptr %l2, !tbaa !29
  %t92 = load i64, ptr %l3, !tbaa !24
  %t94 = add i64 %t92, 1
  %t95 = load ptr, ptr %l46, !tbaa !29
  %t96 = load i32, ptr %l50, !tbaa !23
  %t99 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunended(ptr %v0, ptr %v1, ptr %t95, i32 %t96, ptr %t91, i64 %t94)
  store i32 %t99, ptr %l54
  br label %bb28
bb28:
  %t100 = load i32, ptr %l54, !tbaa !23
  store i32 %t100, ptr %l23, !tbaa !23
  br label %bb34
bb29:
  br i1 true, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  %t101 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t101, ptr %l23, !tbaa !23
  br label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_c2b0e0f9c58e7130_5beafbe0f1fd477c)
  unreachable
bb34:
  %t103 = load i32, ptr %l23, !tbaa !23
  store i32 %t103, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunifyBound(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i32
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca ptr
  %l43 = alloca i64
  %l44 = alloca i32
  %l45 = alloca i32
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l60 = alloca i32
  %l64 = alloca ptr
  %l68 = alloca i32
  %l69 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l79 = alloca i64
  %l86 = alloca i64
  %l94 = alloca i32
  %l102 = alloca i32
  %l106 = alloca i32
  %l109 = alloca i32
  %l113 = alloca i32
  %l118 = alloca i32
  %l121 = alloca ptr
  %l125 = alloca i32
  %l126 = alloca { i64, ptr }
  %l134 = alloca { i64, ptr }
  %l140 = alloca i32
  %l144 = alloca i64
  %l153 = alloca i64
  %l156 = alloca i64
  %l176 = alloca { i64, ptr }
  %l181 = alloca ptr
  %l185 = alloca i32
  %l189 = alloca i32
  %l191 = alloca i32
  %l192 = alloca i64
  %l195 = alloca i64
  %l202 = alloca ptr
  %l205 = alloca i1
  %l211 = alloca i64
  %l220 = alloca i64
  %l223 = alloca i64
  %l243 = alloca { i64, ptr }
  %l250 = alloca ptr
  %l251 = alloca i1
  %l265 = alloca { i64, ptr }
  %l268 = alloca ptr
  %l269 = alloca i32
  %l270 = alloca ptr
  %l271 = alloca ptr
  %l274 = alloca %"compiler/generic:Context"
  %l278 = alloca i32
  %l280 = alloca i64
  %l284 = alloca i32
  %l285 = alloca i32
  %l289 = alloca i64
  %l299 = alloca { i64, ptr }
  %l306 = alloca i64
  %l312 = alloca i32
  %l316 = alloca ptr
  %l317 = alloca ptr
  %l320 = alloca %"compiler/generic:Context"
  %l325 = alloca i32
  %l327 = alloca i64
  %l331 = alloca i32
  %l332 = alloca i32
  %l334 = alloca ptr
  %l338 = alloca i32
  %l339 = alloca { i64, ptr }
  %l341 = alloca ptr
  %l345 = alloca i32
  %l346 = alloca { i64, ptr }
  %l358 = alloca i64
  %l361 = alloca i64
  %l380 = alloca { i64, ptr }
  %l383 = alloca { i64, ptr }
  %l388 = alloca i32
  %l391 = alloca ptr
  %l395 = alloca i32
  %l399 = alloca i32
  %l401 = alloca i32
  %l402 = alloca ptr
  %l406 = alloca i32
  %l408 = alloca i1
  %l409 = alloca ptr
  %l413 = alloca i32
  %l417 = alloca i32
  %l419 = alloca i32
  %l424 = alloca i64
  %s0 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %rv = alloca i64
  %t471 = alloca %"compiler/generic:Context", align 8
  %t565 = alloca %"compiler/generic:Context", align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l4, !tbaa !24
  %t3 = icmp sgt i64 %t1, 32
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  store i64 0, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/generic:Program", ptr %t6, i32 0, i32 2
  %t9 = load i32, ptr %l2, !tbaa !23
  %t12 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t8, i32 %t9)
  store i32 %t12, ptr %l60
  br label %bb4
bb4:
  %t13 = load i32, ptr %l60, !range !{i32 0, i32 33}
  %t15 = trunc i64 22 to i32
  %t16 = icmp eq i32 %t13, %t15
  br i1 %t16, label %bb5, label %bb6
bb5:
  store i64 0, ptr %l5, !tbaa !24
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/generic:Program", ptr %t18, i32 0, i32 2
  store ptr %t20, ptr %l64, !tbaa !29
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/generic:Program", ptr %t21, i32 0, i32 2
  %t24 = load i32, ptr %l2, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l68
  br label %bb7
bb6:
  br label %bb16
bb7:
  %t28 = load ptr, ptr %l64, !tbaa !29
  %t29 = load i32, ptr %l68, !tbaa !23
  %t30 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t28, i32 %t29)
  store { i64, ptr } %t30, ptr %l69
  br label %bb8
bb8:
  %t31 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t31, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t32 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  store i64 %t34, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  %t36 = load i64, ptr %l7, !tbaa !24
  %t37 = load i64, ptr %l8, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb10, label %bb11
bb10:
  br label %bb15
bb11:
  br label %bb12
bb12:
  %t44 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t44, ptr %l76, !tbaa !27
  %t45 = load i64, ptr %l7, !tbaa !24
  %t47 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr i32, ptr %t48, i64 %t45
  %t50 = load i32, ptr %t49, !tbaa !33
  %t52 = load i64, ptr %l5, !tbaa !24
  store i64 %t52, ptr %l79, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load i32, ptr %l1, !tbaa !23
  %t56 = load ptr, ptr %l3, !tbaa !29
  %t57 = load i64, ptr %l4, !tbaa !24
  %t59 = add i64 %t57, 1
  %t65 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunifyBound(ptr %v0, ptr %v1, ptr %t53, i32 %t54, i32 %t50, ptr %t56, i64 %t59)
  store i64 %t65, ptr %l86
  br label %bb13
bb13:
  %t66 = load i64, ptr %l79, !tbaa !24
  %t67 = load i64, ptr %l86, !tbaa !24
  %t68 = add i64 %t66, %t67
  store i64 %t68, ptr %l5, !tbaa !24
  br label %bb14
bb14:
  %t70 = load i64, ptr %l7, !tbaa !24
  %t72 = add i64 %t70, 1
  store i64 %t72, ptr %l7, !tbaa !24
  br label %bb9
bb15:
  %t74 = load i64, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t74, ptr %rv
  br label %ret
bb16:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/generic:Program", ptr %t76, i32 0, i32 2
  %t79 = load i32, ptr %l2, !tbaa !23
  %t82 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t78, i32 %t79)
  store i32 %t82, ptr %l94
  br label %bb17
bb17:
  %t83 = load i32, ptr %l94, !range !{i32 0, i32 33}
  %t85 = trunc i64 18 to i32
  %t86 = icmp eq i32 %t83, %t85
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s0)
  store i64 0, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/generic:Program", ptr %t91, i32 0, i32 2
  %t94 = load i32, ptr %l2, !tbaa !23
  %t97 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t93, i32 %t94)
  store i32 %t97, ptr %l102
  br label %bb21
bb21:
  %t98 = load i32, ptr %l102, !tbaa !23
  store i32 %t98, ptr %l10, !tbaa !23
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/generic:Program", ptr %t99, i32 0, i32 2
  %t102 = load i32, ptr %l1, !tbaa !23
  %t105 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t101, i32 %t102)
  store i32 %t105, ptr %l106
  br label %bb22
bb22:
  %t106 = load i32, ptr %l106, !range !{i32 0, i32 33}
  %t108 = trunc i64 20 to i32
  %t109 = icmp eq i32 %t106, %t108
  br i1 %t109, label %bb23, label %bb24
bb23:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/generic:Program", ptr %t111, i32 0, i32 2
  %t114 = load i32, ptr %l1, !tbaa !23
  %t117 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t113, i32 %t114)
  store i32 %t117, ptr %l113
  br label %bb25
bb24:
  %t118 = load i32, ptr %l1, !tbaa !23
  store i32 %t118, ptr %l109, !tbaa !23
  br label %bb26
bb25:
  %t120 = load i32, ptr %l113, !tbaa !23
  store i32 %t120, ptr %l109, !tbaa !23
  br label %bb26
bb26:
  %t121 = load i32, ptr %l109, !tbaa !23
  store i32 %t121, ptr %l11, !tbaa !23
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/generic:Program", ptr %t122, i32 0, i32 2
  %t125 = load i32, ptr %l11, !tbaa !23
  %t128 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t124, i32 %t125)
  store i32 %t128, ptr %l118
  br label %bb27
bb27:
  %t129 = load i32, ptr %l118, !range !{i32 0, i32 33}
  %t131 = trunc i64 29 to i32
  %t132 = icmp eq i32 %t129, %t131
  br i1 %t132, label %bb28, label %bb29
bb28:
  store i64 0, ptr %l12, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s8
  %t134 = load ptr, ptr %l0, !tbaa !29
  store ptr %t134, ptr %l121, !tbaa !29
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/generic:Program", ptr %t135, i32 0, i32 2
  %t138 = load i32, ptr %l11, !tbaa !23
  %t141 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t137, i32 %t138)
  store i32 %t141, ptr %l125
  br label %bb30
bb29:
  br label %bb65
bb30:
  %t142 = load ptr, ptr %l121, !tbaa !29
  %t143 = load i32, ptr %l125, !tbaa !23
  %t144 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyCovers(ptr %v0, ptr %s8, ptr %t142, i32 %t143)
  store { i64, ptr } %t144, ptr %l126
  br label %bb31
bb31:
  %t145 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t145, 0
  %t147 = extractvalue { i64, ptr } %t145, 1
  %t148 = mul i64 %t146, 4
  %t149 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t148)
  call void @llvm.memcpy.p0.p0.i64(ptr %t149, ptr %t147, i64 %t148, i1 false)
  %t150 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  store { i64, ptr } %t151, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t153 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t153, 0
  store i64 %t155, ptr %l15, !tbaa !24
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s9
  %t157 = load i64, ptr %l14, !tbaa !24
  %t158 = load i64, ptr %l15, !tbaa !24
  %t161 = icmp slt i64 %t157, %t158
  %t163 = xor i1 %t161, true
  br i1 %t163, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s9)
  br label %bb64
bb34:
  br label %bb35
bb35:
  %t165 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t165, ptr %l134, !tbaa !27
  %t166 = load i64, ptr %l14, !tbaa !24
  %t168 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !27
  %t170 = getelementptr i32, ptr %t169, i64 %t166
  %t171 = load i32, ptr %t170, !tbaa !33
  store i32 %t171, ptr %l16, !tbaa !23
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/generic:Program", ptr %t173, i32 0, i32 2
  %t176 = load i32, ptr %l16, !tbaa !23
  %t179 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t175, i32 %t176)
  store i32 %t179, ptr %l140
  br label %bb36
bb36:
  %t180 = load i32, ptr %l10, !tbaa !23
  %t181 = load i32, ptr %l140, !tbaa !23
  %t183 = icmp ne i32 %t181, %t180
  br i1 %t183, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s9)
  br label %bb63
bb38:
  br label %bb39
bb39:
  %t185 = load ptr, ptr %l3, !tbaa !29
  %t187 = getelementptr %"compiler/generic:Binding", ptr %t185, i32 0, i32 1
  %t188 = load i64, ptr %t187, !tbaa !24
  store i64 %t188, ptr %l144, !tbaa !24
  %t189 = load i64, ptr %l144, !tbaa !24
  %t190 = icmp sge i64 %t189, 0
  br i1 %t190, label %bb40, label %bb41
bb40:
  %t192 = load i64, ptr %l144, !tbaa !24
  %t193 = icmp sle i64 %t192, 2305843009213693951
  br i1 %t193, label %bb42, label %bb43
bb41:
  call void @__olang_check_failed(ptr @olang_loc_b3aa93c548ec796e_ac2c4500982ff6c2)
  unreachable
bb42:
  %t195 = load i64, ptr %l144, !tbaa !24
  %t196 = mul i64 %t195, 4
  %t197 = call ptr @__olang_scope_alloc_zeroed(ptr %s9, i64 %t196)
  %t198 = insertvalue { i64, ptr } undef, i64 %t195, 0
  %t199 = insertvalue { i64, ptr } %t198, ptr %t197, 1
  store { i64, ptr } %t199, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t201 = load ptr, ptr %l3, !tbaa !29
  %t203 = getelementptr %"compiler/generic:Binding", ptr %t201, i32 0, i32 1
  %t204 = load i64, ptr %t203, !tbaa !24
  store i64 %t204, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t206 = load i64, ptr %l19, !tbaa !24
  %t207 = load i64, ptr %l18, !tbaa !24
  %t210 = icmp sgt i64 %t206, %t207
  br i1 %t210, label %bb44, label %bb45
bb43:
  call void @__olang_check_failed(ptr @olang_loc_b3aa93c548ec796e_ac2c4500982ff6c2)
  unreachable
bb44:
  %t212 = load i64, ptr %l20, !tbaa !24
  %t214 = icmp sgt i64 %t212, 0
  br i1 %t214, label %bb46, label %bb47
bb45:
  store i64 0, ptr %l153, !tbaa !24
  br label %bb49
bb46:
  %t216 = load i64, ptr %l19, !tbaa !24
  %t217 = load i64, ptr %l18, !tbaa !24
  %t220 = sub i64 %t216, %t217
  %t221 = load i64, ptr %l20, !tbaa !24
  %t224 = add i64 %t220, %t221
  %t226 = sub i64 %t224, 1
  %t227 = load i64, ptr %l20, !tbaa !24
  %t230 = sdiv i64 %t226, %t227
  store i64 %t230, ptr %l156, !tbaa !24
  br label %bb48
bb47:
  store i64 0, ptr %l156, !tbaa !24
  br label %bb48
bb48:
  %t232 = load i64, ptr %l156, !tbaa !24
  store i64 %t232, ptr %l153, !tbaa !24
  br label %bb49
bb49:
  %t233 = load i64, ptr %l153, !tbaa !24
  store i64 %t233, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb50
bb50:
  %t234 = load i64, ptr %l22, !tbaa !24
  %t235 = load i64, ptr %l21, !tbaa !24
  %t238 = icmp slt i64 %t234, %t235
  %t240 = xor i1 %t238, true
  br i1 %t240, label %bb51, label %bb52
bb51:
  br label %bb55
bb52:
  br label %bb53
bb53:
  %t242 = load i64, ptr %l18, !tbaa !24
  %t243 = load i64, ptr %l22, !tbaa !24
  %t244 = load i64, ptr %l20, !tbaa !24
  %t247 = mul i64 %t243, %t244
  %t250 = add i64 %t242, %t247
  store i64 %t250, ptr %l23, !tbaa !24
  %t252 = load i64, ptr %l23, !tbaa !24
  %t253 = load ptr, ptr %l3, !tbaa !29
  %t255 = getelementptr %"compiler/generic:Binding", ptr %t253, i32 0, i32 2
  %t256 = load { i64, ptr }, ptr %t255, !tbaa !27
  store { i64, ptr } %t256, ptr %l176, !tbaa !27
  %t257 = load i64, ptr %l23, !tbaa !24
  %t259 = getelementptr { i64, ptr }, ptr %l176, i32 0, i32 1
  %t260 = load ptr, ptr %t259, !tbaa !27
  %t261 = getelementptr i32, ptr %t260, i64 %t257
  %t262 = load i32, ptr %t261, !tbaa !33
  %t265 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !27
  %t267 = getelementptr i32, ptr %t266, i64 %t252
  store i32 %t262, ptr %t267, !tbaa !33
  br label %bb54
bb54:
  %t268 = load i64, ptr %l22, !tbaa !24
  %t270 = add i64 %t268, 1
  store i64 %t270, ptr %l22, !tbaa !24
  br label %bb50
bb55:
  %t272 = load ptr, ptr %l0, !tbaa !29
  store ptr %t272, ptr %l181, !tbaa !29
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"compiler/generic:Program", ptr %t273, i32 0, i32 2
  %t276 = load i32, ptr %l2, !tbaa !23
  %t279 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t275, i32 %t276)
  store i32 %t279, ptr %l185
  br label %bb56
bb56:
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t282 = getelementptr %"compiler/generic:Program", ptr %t280, i32 0, i32 2
  %t283 = load i32, ptr %l16, !tbaa !23
  %t286 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t282, i32 %t283)
  store i32 %t286, ptr %l189
  br label %bb57
bb57:
  %t287 = load ptr, ptr %l3, !tbaa !29
  %t288 = load ptr, ptr %l181, !tbaa !29
  %t289 = load i32, ptr %l185, !tbaa !23
  %t290 = load i32, ptr %l189, !tbaa !23
  %t292 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunifyLists(ptr %v0, ptr %v1, ptr %t288, i32 %t289, i32 %t290, ptr %t287, i1 false)
  store i32 %t292, ptr %l191
  %t293 = icmp ne i32 %t292, 0
  br i1 %t293, label %bb59, label %ok.294, !prof !99
ok.294:
  br label %bb58
bb58:
  br label %bb61
bb59:
  br label %bb60
bb60:
  call void @__olang_ert_req_clear()
  br label %bb61
bb61:
  %t295 = load i64, ptr %l12, !tbaa !24
  store i64 %t295, ptr %l192, !tbaa !24
  %t296 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t297 = load ptr, ptr %l3, !tbaa !29
  %t300 = call i64 @compiler_2fgeneric_2echangedVals(ptr %s9, ptr %v1, { i64, ptr } %t296, ptr %t297)
  store i64 %t300, ptr %l195
  br label %bb62
bb62:
  %t301 = load i64, ptr %l192, !tbaa !24
  %t302 = load i64, ptr %l195, !tbaa !24
  %t303 = add i64 %t301, %t302
  store i64 %t303, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb63
bb63:
  %t305 = load i64, ptr %l14, !tbaa !24
  %t307 = add i64 %t305, 1
  store i64 %t307, ptr %l14, !tbaa !24
  br label %bb32
bb64:
  call void @__olang_scope_close(ptr %s8)
  %t309 = load i64, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t309, ptr %rv
  br label %ret
bb65:
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t312 = load i32, ptr %l10, !tbaa !23
  %t315 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etypeDecl(ptr %v0, ptr %v0, ptr %t311, i32 %t312)
  store ptr %t315, ptr %l202
  br label %bb66
bb66:
  %t316 = load ptr, ptr %l202, !tbaa !29
  store ptr %t316, ptr %l24, !tbaa !29
  %t317 = load ptr, ptr %l24, !tbaa !29
  %t319 = icmp eq ptr %t317, null
  br i1 %t319, label %bb67, label %bb68
bb67:
  store i1 true, ptr %l205, !tbaa !21
  br label %bb69
bb68:
  %t321 = load ptr, ptr %l24, !tbaa !29
  %t323 = getelementptr %"compiler/ast:TypeDecl", ptr %t321, i32 0, i32 3
  %t324 = load ptr, ptr %t323, !tbaa !29
  %t326 = icmp eq ptr %t324, null
  store i1 %t326, ptr %l205, !tbaa !21
  br label %bb69
bb69:
  %t328 = load i1, ptr %l205, !tbaa !21
  br i1 %t328, label %bb70, label %bb71
bb70:
  call void @__olang_scope_close(ptr %s0)
  store i64 0, ptr %rv
  br label %ret
bb71:
  br label %bb72
bb72:
  %t330 = load ptr, ptr %l3, !tbaa !29
  %t332 = getelementptr %"compiler/generic:Binding", ptr %t330, i32 0, i32 1
  %t333 = load i64, ptr %t332, !tbaa !24
  store i64 %t333, ptr %l211, !tbaa !24
  %t334 = load i64, ptr %l211, !tbaa !24
  %t335 = icmp sge i64 %t334, 0
  br i1 %t335, label %bb73, label %bb74
bb73:
  %t337 = load i64, ptr %l211, !tbaa !24
  %t338 = icmp sle i64 %t337, 2305843009213693951
  br i1 %t338, label %bb75, label %bb76
bb74:
  call void @__olang_check_failed(ptr @olang_loc_d067a2352cc578e3_8c11ed4f2bfcee77)
  unreachable
bb75:
  %t340 = load i64, ptr %l211, !tbaa !24
  %t341 = mul i64 %t340, 4
  %t342 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t341)
  %t343 = insertvalue { i64, ptr } undef, i64 %t340, 0
  %t344 = insertvalue { i64, ptr } %t343, ptr %t342, 1
  store { i64, ptr } %t344, ptr %l25, !tbaa !27
  store i64 0, ptr %l26, !tbaa !24
  %t346 = load ptr, ptr %l3, !tbaa !29
  %t348 = getelementptr %"compiler/generic:Binding", ptr %t346, i32 0, i32 1
  %t349 = load i64, ptr %t348, !tbaa !24
  store i64 %t349, ptr %l27, !tbaa !24
  store i64 1, ptr %l28, !tbaa !24
  %t351 = load i64, ptr %l27, !tbaa !24
  %t352 = load i64, ptr %l26, !tbaa !24
  %t355 = icmp sgt i64 %t351, %t352
  br i1 %t355, label %bb77, label %bb78
bb76:
  call void @__olang_check_failed(ptr @olang_loc_d067a2352cc578e3_8c11ed4f2bfcee77)
  unreachable
bb77:
  %t357 = load i64, ptr %l28, !tbaa !24
  %t359 = icmp sgt i64 %t357, 0
  br i1 %t359, label %bb79, label %bb80
bb78:
  store i64 0, ptr %l220, !tbaa !24
  br label %bb82
bb79:
  %t361 = load i64, ptr %l27, !tbaa !24
  %t362 = load i64, ptr %l26, !tbaa !24
  %t365 = sub i64 %t361, %t362
  %t366 = load i64, ptr %l28, !tbaa !24
  %t369 = add i64 %t365, %t366
  %t371 = sub i64 %t369, 1
  %t372 = load i64, ptr %l28, !tbaa !24
  %t375 = sdiv i64 %t371, %t372
  store i64 %t375, ptr %l223, !tbaa !24
  br label %bb81
bb80:
  store i64 0, ptr %l223, !tbaa !24
  br label %bb81
bb81:
  %t377 = load i64, ptr %l223, !tbaa !24
  store i64 %t377, ptr %l220, !tbaa !24
  br label %bb82
bb82:
  %t378 = load i64, ptr %l220, !tbaa !24
  store i64 %t378, ptr %l29, !tbaa !24
  store i64 0, ptr %l30, !tbaa !24
  br label %bb83
bb83:
  %t379 = load i64, ptr %l30, !tbaa !24
  %t380 = load i64, ptr %l29, !tbaa !24
  %t383 = icmp slt i64 %t379, %t380
  %t385 = xor i1 %t383, true
  br i1 %t385, label %bb84, label %bb85
bb84:
  br label %bb88
bb85:
  br label %bb86
bb86:
  %t387 = load i64, ptr %l26, !tbaa !24
  %t388 = load i64, ptr %l30, !tbaa !24
  %t389 = load i64, ptr %l28, !tbaa !24
  %t392 = mul i64 %t388, %t389
  %t395 = add i64 %t387, %t392
  store i64 %t395, ptr %l31, !tbaa !24
  %t397 = load i64, ptr %l31, !tbaa !24
  %t398 = load ptr, ptr %l3, !tbaa !29
  %t400 = getelementptr %"compiler/generic:Binding", ptr %t398, i32 0, i32 2
  %t401 = load { i64, ptr }, ptr %t400, !tbaa !27
  store { i64, ptr } %t401, ptr %l243, !tbaa !27
  %t402 = load i64, ptr %l31, !tbaa !24
  %t404 = getelementptr { i64, ptr }, ptr %l243, i32 0, i32 1
  %t405 = load ptr, ptr %t404, !tbaa !27
  %t406 = getelementptr i32, ptr %t405, i64 %t402
  %t407 = load i32, ptr %t406, !tbaa !33
  %t410 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t411 = load ptr, ptr %t410, !tbaa !27
  %t412 = getelementptr i32, ptr %t411, i64 %t397
  store i32 %t407, ptr %t412, !tbaa !33
  br label %bb87
bb87:
  %t413 = load i64, ptr %l30, !tbaa !24
  %t415 = add i64 %t413, 1
  store i64 %t415, ptr %l30, !tbaa !24
  br label %bb83
bb88:
  %t417 = load ptr, ptr %l24, !tbaa !29
  %t419 = getelementptr %"compiler/ast:TypeDecl", ptr %t417, i32 0, i32 3
  %t420 = load ptr, ptr %t419, !tbaa !29
  store ptr %t420, ptr %l32, !tbaa !29
  %t422 = load ptr, ptr %l32, !tbaa !29
  store ptr %t422, ptr %l250, !tbaa !29
  store i1 false, ptr %l251, !tbaa !21
  %t423 = load ptr, ptr %l250, !tbaa !29
  %t424 = icmp ne ptr %t423, null
  br i1 %t424, label %bb89, label %bb90
bb89:
  %t426 = load ptr, ptr %l250, !tbaa !29
  %t427 = load i64, ptr %t426, !range !{i64 0, i64 5}
  %t429 = icmp eq i64 %t427, 2
  store i1 %t429, ptr %l251, !tbaa !21
  br label %bb90
bb90:
  %t430 = load i1, ptr %l251, !tbaa !21
  br i1 %t430, label %bb91, label %bb92
bb91:
  %t431 = load ptr, ptr %l32, !tbaa !29
  %t433 = getelementptr { i64, [6 x i64] }, ptr %t431, i32 0, i32 1
  %t434 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t433, i32 0, i32 0
  %t435 = load { i64, ptr }, ptr %t434
  store { i64, ptr } %t435, ptr %l33, !tbaa !27
  %t437 = load ptr, ptr %l32, !tbaa !29
  %t439 = getelementptr { i64, [6 x i64] }, ptr %t437, i32 0, i32 1
  %t440 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t439, i32 0, i32 1
  %t441 = load { i64, ptr }, ptr %t440
  store { i64, ptr } %t441, ptr %l34, !tbaa !27
  br label %bb93
bb92:
  br label %bb165
bb93:
  %t443 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t443, ptr %l35, !tbaa !27
  store i64 0, ptr %l36, !tbaa !24
  %t445 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t447 = extractvalue { i64, ptr } %t445, 0
  store i64 %t447, ptr %l37, !tbaa !24
  br label %bb94
bb94:
  store %olang.scope zeroinitializer, ptr %s22
  %t449 = load i64, ptr %l36, !tbaa !24
  %t450 = load i64, ptr %l37, !tbaa !24
  %t453 = icmp slt i64 %t449, %t450
  %t455 = xor i1 %t453, true
  br i1 %t455, label %bb95, label %bb96
bb95:
  call void @__olang_scope_close(ptr %s22)
  br label %bb105
bb96:
  br label %bb97
bb97:
  %t457 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t457, ptr %l265, !tbaa !27
  %t458 = load i64, ptr %l36, !tbaa !24
  %t460 = getelementptr { i64, ptr }, ptr %l265, i32 0, i32 1
  %t461 = load ptr, ptr %t460, !tbaa !27
  %t462 = getelementptr ptr, ptr %t461, i64 %t458
  %t463 = load ptr, ptr %t462, !tbaa !39
  store ptr %t463, ptr %l38, !tbaa !29
  %t465 = load ptr, ptr %l0, !tbaa !29
  store ptr %t465, ptr %l268, !tbaa !29
  %t466 = load i32, ptr %l1, !tbaa !23
  store i32 %t466, ptr %l269, !tbaa !23
  %t467 = load ptr, ptr %l0, !tbaa !29
  store ptr %t467, ptr %l270, !tbaa !29
  %t468 = load ptr, ptr %l0, !tbaa !29
  store ptr %t468, ptr %l271, !tbaa !29
  %t469 = load ptr, ptr %l0, !tbaa !29
  %t470 = load i32, ptr %l10, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2edeclContext(ptr %t471, ptr %v0, ptr %s22, ptr %t469, i32 %t470)
  call void @llvm.memmove.p0.p0.i64(ptr %l274, ptr %t471, i64 160, i1 false)
  br label %bb98
bb98:
  %t474 = call ptr @__olang_scope_alloc_a(ptr %s22, i64 160, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t474, ptr %l274, i64 160, i1 false)
  %t475 = load ptr, ptr %l38, !tbaa !29
  %t477 = load ptr, ptr %l271, !tbaa !29
  %t480 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %s22, ptr %v0, ptr %t477, ptr %t474, ptr %t475)
  store i32 %t480, ptr %l278
  br label %bb99
bb99:
  %t481 = load i32, ptr %l10, !tbaa !23
  %t483 = call i64 @compiler_2fgeneric_2eDeclOwner(i32 %t481)
  store i64 %t483, ptr %l280
  br label %bb100
bb100:
  %t484 = load ptr, ptr %l0, !tbaa !29
  %t486 = getelementptr %"compiler/generic:Program", ptr %t484, i32 0, i32 2
  %t487 = load i32, ptr %l2, !tbaa !23
  %t490 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t486, i32 %t487)
  store i32 %t490, ptr %l284
  br label %bb101
bb101:
  %t491 = load ptr, ptr %l270, !tbaa !29
  %t492 = load i32, ptr %l278, !tbaa !23
  %t493 = load i64, ptr %l280, !tbaa !24
  %t494 = load i32, ptr %l284, !tbaa !23
  %t495 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %t491, i32 %t492, i64 %t493, i32 %t494)
  store i32 %t495, ptr %l285
  br label %bb102
bb102:
  %t496 = load ptr, ptr %l3, !tbaa !29
  %t497 = load i64, ptr %l4, !tbaa !24
  %t499 = add i64 %t497, 1
  %t500 = load ptr, ptr %l268, !tbaa !29
  %t501 = load i32, ptr %l269, !tbaa !23
  %t502 = load i32, ptr %l285, !tbaa !23
  %t505 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunifyBound(ptr %v0, ptr %v1, ptr %t500, i32 %t501, i32 %t502, ptr %t496, i64 %t499)
  store i64 %t505, ptr %l289
  br label %bb103
bb103:
  call void @__olang_scope_close(ptr %s22)
  br label %bb104
bb104:
  %t506 = load i64, ptr %l36, !tbaa !24
  %t508 = add i64 %t506, 1
  store i64 %t508, ptr %l36, !tbaa !24
  br label %bb94
bb105:
  %t510 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t510, ptr %l39, !tbaa !27
  store i64 0, ptr %l40, !tbaa !24
  %t512 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t514 = extractvalue { i64, ptr } %t512, 0
  store i64 %t514, ptr %l41, !tbaa !24
  br label %bb106
bb106:
  store %olang.scope zeroinitializer, ptr %s25
  %t516 = load i64, ptr %l40, !tbaa !24
  %t517 = load i64, ptr %l41, !tbaa !24
  %t520 = icmp slt i64 %t516, %t517
  %t522 = xor i1 %t520, true
  br i1 %t522, label %bb107, label %bb108
bb107:
  call void @__olang_scope_close(ptr %s25)
  br label %bb164
bb108:
  br label %bb109
bb109:
  %t524 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t524, ptr %l299, !tbaa !27
  %t525 = load i64, ptr %l40, !tbaa !24
  %t527 = getelementptr { i64, ptr }, ptr %l299, i32 0, i32 1
  %t528 = load ptr, ptr %t527, !tbaa !27
  %t529 = getelementptr ptr, ptr %t528, i64 %t525
  %t530 = load ptr, ptr %t529, !tbaa !39
  store ptr %t530, ptr %l42, !tbaa !29
  %t532 = load ptr, ptr %l0, !tbaa !29
  %t533 = load i32, ptr %l1, !tbaa !23
  %t534 = load ptr, ptr %l42, !tbaa !29
  %t536 = getelementptr %"compiler/ast:Func", ptr %t534, i32 0, i32 2
  %t537 = load i32, ptr %t536, !tbaa !23
  %t541 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t532, i32 %t533, i32 %t537)
  store i64 %t541, ptr %l306
  br label %bb110
bb110:
  %t542 = load i64, ptr %l306, !tbaa !24
  store i64 %t542, ptr %l43, !tbaa !24
  %t543 = load i64, ptr %l43, !tbaa !24
  %t545 = icmp slt i64 %t543, 0
  br i1 %t545, label %bb111, label %bb112
bb111:
  call void @__olang_scope_close(ptr %s25)
  br label %bb163
bb112:
  br label %bb113
bb113:
  %t547 = load ptr, ptr %l0, !tbaa !29
  %t548 = load i64, ptr %l43, !tbaa !24
  %t549 = load i32, ptr %l1, !tbaa !23
  %t553 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodSig(ptr %v0, ptr %t547, i64 %t548, i32 %t549)
  store i32 %t553, ptr %l312
  br label %bb114
bb114:
  %t554 = load i32, ptr %l312, !tbaa !23
  store i32 %t554, ptr %l44, !tbaa !23
  %t555 = load i32, ptr %l44, !tbaa !23
  %t556 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t559 = icmp eq i32 %t555, %t556
  br i1 %t559, label %bb115, label %bb116
bb115:
  call void @__olang_scope_close(ptr %s25)
  br label %bb163
bb116:
  br label %bb117
bb117:
  %t561 = load ptr, ptr %l0, !tbaa !29
  store ptr %t561, ptr %l316, !tbaa !29
  %t562 = load ptr, ptr %l0, !tbaa !29
  store ptr %t562, ptr %l317, !tbaa !29
  %t563 = load ptr, ptr %l0, !tbaa !29
  %t564 = load i32, ptr %l10, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2edeclContext(ptr %t565, ptr %v0, ptr %s25, ptr %t563, i32 %t564)
  call void @llvm.memmove.p0.p0.i64(ptr %l320, ptr %t565, i64 160, i1 false)
  br label %bb118
bb118:
  %t568 = call ptr @__olang_scope_alloc_a(ptr %s25, i64 160, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t568, ptr %l320, i64 160, i1 false)
  %t569 = load ptr, ptr %l42, !tbaa !29
  %t571 = getelementptr %"compiler/ast:Func", ptr %t569, i32 0, i32 3
  %t572 = load ptr, ptr %t571, !tbaa !29
  %t573 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t574 = load ptr, ptr %l317, !tbaa !29
  %t578 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2esigType(ptr %v0, ptr %s25, ptr %v0, ptr %t574, ptr %t568, ptr %t572, i32 %t573, i32 0)
  store i32 %t578, ptr %l325
  br label %bb119
bb119:
  %t579 = load i32, ptr %l10, !tbaa !23
  %t581 = call i64 @compiler_2fgeneric_2eDeclOwner(i32 %t579)
  store i64 %t581, ptr %l327
  br label %bb120
bb120:
  %t582 = load ptr, ptr %l0, !tbaa !29
  %t584 = getelementptr %"compiler/generic:Program", ptr %t582, i32 0, i32 2
  %t585 = load i32, ptr %l2, !tbaa !23
  %t588 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t584, i32 %t585)
  store i32 %t588, ptr %l331
  br label %bb121
bb121:
  %t589 = load ptr, ptr %l316, !tbaa !29
  %t590 = load i32, ptr %l325, !tbaa !23
  %t591 = load i64, ptr %l327, !tbaa !24
  %t592 = load i32, ptr %l331, !tbaa !23
  %t593 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %t589, i32 %t590, i64 %t591, i32 %t592)
  store i32 %t593, ptr %l332
  br label %bb122
bb122:
  %t594 = load i32, ptr %l332, !tbaa !23
  store i32 %t594, ptr %l45, !tbaa !23
  %t595 = load ptr, ptr %l0, !tbaa !29
  %t597 = getelementptr %"compiler/generic:Program", ptr %t595, i32 0, i32 2
  store ptr %t597, ptr %l334, !tbaa !29
  %t598 = load ptr, ptr %l0, !tbaa !29
  %t600 = getelementptr %"compiler/generic:Program", ptr %t598, i32 0, i32 2
  %t601 = load i32, ptr %l44, !tbaa !23
  %t604 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t600, i32 %t601)
  store i32 %t604, ptr %l338
  br label %bb123
bb123:
  %t605 = load ptr, ptr %l334, !tbaa !29
  %t606 = load i32, ptr %l338, !tbaa !23
  %t607 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t605, i32 %t606)
  store { i64, ptr } %t607, ptr %l339
  br label %bb124
bb124:
  %t608 = load { i64, ptr }, ptr %l339, !tbaa !27
  store { i64, ptr } %t608, ptr %l46, !tbaa !27
  %t609 = load ptr, ptr %l0, !tbaa !29
  %t611 = getelementptr %"compiler/generic:Program", ptr %t609, i32 0, i32 2
  store ptr %t611, ptr %l341, !tbaa !29
  %t612 = load ptr, ptr %l0, !tbaa !29
  %t614 = getelementptr %"compiler/generic:Program", ptr %t612, i32 0, i32 2
  %t615 = load i32, ptr %l45, !tbaa !23
  %t618 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t614, i32 %t615)
  store i32 %t618, ptr %l345
  br label %bb125
bb125:
  %t619 = load ptr, ptr %l341, !tbaa !29
  %t620 = load i32, ptr %l345, !tbaa !23
  %t621 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t619, i32 %t620)
  store { i64, ptr } %t621, ptr %l346
  br label %bb126
bb126:
  %t622 = load { i64, ptr }, ptr %l346, !tbaa !27
  store { i64, ptr } %t622, ptr %l47, !tbaa !27
  %t623 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t625 = extractvalue { i64, ptr } %t623, 0
  %t626 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t628 = extractvalue { i64, ptr } %t626, 0
  %t630 = add i64 %t628, 1
  %t633 = icmp ne i64 %t625, %t630
  br i1 %t633, label %bb127, label %bb128
bb127:
  call void @__olang_scope_close(ptr %s25)
  br label %bb163
bb128:
  br label %bb129
bb129:
  store i64 0, ptr %l48, !tbaa !24
  %t635 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t637 = extractvalue { i64, ptr } %t635, 0
  store i64 %t637, ptr %l49, !tbaa !24
  store i64 1, ptr %l50, !tbaa !24
  %t639 = load i64, ptr %l49, !tbaa !24
  %t640 = load i64, ptr %l48, !tbaa !24
  %t643 = icmp sgt i64 %t639, %t640
  br i1 %t643, label %bb130, label %bb131
bb130:
  %t645 = load i64, ptr %l50, !tbaa !24
  %t647 = icmp sgt i64 %t645, 0
  br i1 %t647, label %bb132, label %bb133
bb131:
  store i64 0, ptr %l358, !tbaa !24
  br label %bb135
bb132:
  %t649 = load i64, ptr %l49, !tbaa !24
  %t650 = load i64, ptr %l48, !tbaa !24
  %t653 = sub i64 %t649, %t650
  %t654 = load i64, ptr %l50, !tbaa !24
  %t657 = add i64 %t653, %t654
  %t659 = sub i64 %t657, 1
  %t660 = load i64, ptr %l50, !tbaa !24
  %t663 = sdiv i64 %t659, %t660
  store i64 %t663, ptr %l361, !tbaa !24
  br label %bb134
bb133:
  store i64 0, ptr %l361, !tbaa !24
  br label %bb134
bb134:
  %t665 = load i64, ptr %l361, !tbaa !24
  store i64 %t665, ptr %l358, !tbaa !24
  br label %bb135
bb135:
  %t666 = load i64, ptr %l358, !tbaa !24
  store i64 %t666, ptr %l51, !tbaa !24
  store i64 0, ptr %l52, !tbaa !24
  br label %bb136
bb136:
  %t667 = load i64, ptr %l52, !tbaa !24
  %t668 = load i64, ptr %l51, !tbaa !24
  %t671 = icmp slt i64 %t667, %t668
  %t673 = xor i1 %t671, true
  br i1 %t673, label %bb137, label %bb138
bb137:
  br label %bb145
bb138:
  br label %bb139
bb139:
  %t675 = load i64, ptr %l48, !tbaa !24
  %t676 = load i64, ptr %l52, !tbaa !24
  %t677 = load i64, ptr %l50, !tbaa !24
  %t680 = mul i64 %t676, %t677
  %t683 = add i64 %t675, %t680
  store i64 %t683, ptr %l53, !tbaa !24
  %t685 = load ptr, ptr %l0, !tbaa !29
  %t686 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t686, ptr %l380, !tbaa !27
  %t687 = load i64, ptr %l53, !tbaa !24
  %t689 = getelementptr { i64, ptr }, ptr %l380, i32 0, i32 1
  %t690 = load ptr, ptr %t689, !tbaa !27
  %t691 = getelementptr i32, ptr %t690, i64 %t687
  %t692 = load i32, ptr %t691, !tbaa !33
  %t693 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t693, ptr %l383, !tbaa !27
  %t694 = load i64, ptr %l53, !tbaa !24
  %t696 = add i64 %t694, 1
  %t698 = getelementptr { i64, ptr }, ptr %l383, i32 0, i32 1
  %t699 = load ptr, ptr %t698, !tbaa !27
  %t700 = getelementptr i32, ptr %t699, i64 %t696
  %t701 = load i32, ptr %t700, !tbaa !33
  %t702 = load ptr, ptr %l3, !tbaa !29
  %t707 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnifyArg(ptr %v0, ptr %v1, ptr %t685, i32 %t692, i32 %t701, ptr %t702, i1 false, i1 false)
  store i32 %t707, ptr %l388
  %t708 = icmp ne i32 %t707, 0
  br i1 %t708, label %bb141, label %ok.709, !prof !99
ok.709:
  br label %bb140
bb140:
  br label %bb143
bb141:
  br label %bb142
bb142:
  call void @__olang_ert_req_clear()
  br label %bb143
bb143:
  br label %bb144
bb144:
  %t710 = load i64, ptr %l52, !tbaa !24
  %t712 = add i64 %t710, 1
  store i64 %t712, ptr %l52, !tbaa !24
  br label %bb136
bb145:
  %t714 = load ptr, ptr %l0, !tbaa !29
  store ptr %t714, ptr %l391, !tbaa !29
  %t715 = load ptr, ptr %l0, !tbaa !29
  %t717 = getelementptr %"compiler/generic:Program", ptr %t715, i32 0, i32 2
  %t718 = load i32, ptr %l45, !tbaa !23
  %t721 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t717, i32 %t718)
  store i32 %t721, ptr %l395
  br label %bb146
bb146:
  %t722 = load ptr, ptr %l0, !tbaa !29
  %t724 = getelementptr %"compiler/generic:Program", ptr %t722, i32 0, i32 2
  %t725 = load i32, ptr %l44, !tbaa !23
  %t728 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t724, i32 %t725)
  store i32 %t728, ptr %l399
  br label %bb147
bb147:
  %t729 = load ptr, ptr %l3, !tbaa !29
  %t730 = load ptr, ptr %l391, !tbaa !29
  %t731 = load i32, ptr %l395, !tbaa !23
  %t732 = load i32, ptr %l399, !tbaa !23
  %t734 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnifyArg(ptr %v0, ptr %v1, ptr %t730, i32 %t731, i32 %t732, ptr %t729, i1 false, i1 false)
  store i32 %t734, ptr %l401
  %t735 = icmp ne i32 %t734, 0
  br i1 %t735, label %bb149, label %ok.736, !prof !99
ok.736:
  br label %bb148
bb148:
  br label %bb151
bb149:
  br label %bb150
bb150:
  call void @__olang_ert_req_clear()
  br label %bb151
bb151:
  %t737 = load ptr, ptr %l0, !tbaa !29
  store ptr %t737, ptr %l402, !tbaa !29
  %t738 = load ptr, ptr %l0, !tbaa !29
  %t740 = getelementptr %"compiler/generic:Program", ptr %t738, i32 0, i32 2
  %t741 = load i32, ptr %l45, !tbaa !23
  %t744 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t740, i32 %t741)
  store i32 %t744, ptr %l406
  br label %bb152
bb152:
  %t745 = load ptr, ptr %l3, !tbaa !29
  %t746 = load ptr, ptr %l402, !tbaa !29
  %t747 = load i32, ptr %l406, !tbaa !23
  %t749 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eerrsHaveVar(ptr %v0, ptr %v1, ptr %t746, i32 %t747, ptr %t745)
  store i1 %t749, ptr %l408
  br label %bb153
bb153:
  %t750 = load i1, ptr %l408, !tbaa !21
  br i1 %t750, label %bb154, label %bb155
bb154:
  %t751 = load ptr, ptr %l0, !tbaa !29
  store ptr %t751, ptr %l409, !tbaa !29
  %t752 = load ptr, ptr %l0, !tbaa !29
  %t754 = getelementptr %"compiler/generic:Program", ptr %t752, i32 0, i32 2
  %t755 = load i32, ptr %l45, !tbaa !23
  %t758 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t754, i32 %t755)
  store i32 %t758, ptr %l413
  br label %bb156
bb155:
  br label %bb162
bb156:
  %t759 = load ptr, ptr %l0, !tbaa !29
  %t761 = getelementptr %"compiler/generic:Program", ptr %t759, i32 0, i32 2
  %t762 = load i32, ptr %l44, !tbaa !23
  %t765 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t761, i32 %t762)
  store i32 %t765, ptr %l417
  br label %bb157
bb157:
  %t766 = load ptr, ptr %l3, !tbaa !29
  %t767 = load ptr, ptr %l409, !tbaa !29
  %t768 = load i32, ptr %l413, !tbaa !23
  %t769 = load i32, ptr %l417, !tbaa !23
  %t771 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunifyErrs(ptr %v0, ptr %v1, ptr %t767, i32 %t768, i32 %t769, ptr %t766)
  store i32 %t771, ptr %l419
  %t772 = icmp ne i32 %t771, 0
  br i1 %t772, label %bb159, label %ok.773, !prof !99
ok.773:
  br label %bb158
bb158:
  br label %bb161
bb159:
  br label %bb160
bb160:
  call void @__olang_ert_req_clear()
  br label %bb161
bb161:
  br label %bb162
bb162:
  call void @__olang_scope_close(ptr %s25)
  br label %bb163
bb163:
  %t774 = load i64, ptr %l40, !tbaa !24
  %t776 = add i64 %t774, 1
  store i64 %t776, ptr %l40, !tbaa !24
  br label %bb106
bb164:
  br label %bb170
bb165:
  br i1 true, label %bb166, label %bb167
bb166:
  br label %bb168
bb167:
  br label %bb169
bb168:
  br label %bb170
bb169:
  call void @__olang_check_failed(ptr @olang_loc_29bfa21b0ca1023f_9ac138f9a38bfc3b)
  unreachable
bb170:
  %t778 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t779 = load ptr, ptr %l3, !tbaa !29
  %t782 = call i64 @compiler_2fgeneric_2echangedVals(ptr %s0, ptr %v1, { i64, ptr } %t778, ptr %t779)
  store i64 %t782, ptr %l424
  br label %bb171
bb171:
  call void @__olang_scope_close(ptr %s0)
  %t783 = load i64, ptr %l424, !tbaa !24
  store i64 %t783, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunifyKind(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, i32 %a3, ptr %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca ptr
  %l14 = alloca i32
  %l18 = alloca i32
  %l21 = alloca ptr
  %l24 = alloca ptr
  %l28 = alloca i32
  %l32 = alloca i32
  %l35 = alloca i32
  %l37 = alloca ptr
  %l42 = alloca ptr
  %l46 = alloca i32
  %l50 = alloca i32
  %l53 = alloca i32
  %l55 = alloca ptr
  %l58 = alloca ptr
  %l62 = alloca i32
  %l66 = alloca i32
  %l69 = alloca i32
  %l71 = alloca ptr
  %l76 = alloca ptr
  %l80 = alloca i32
  %l84 = alloca i32
  %l87 = alloca i32
  %l89 = alloca ptr
  %l94 = alloca ptr
  %l98 = alloca i32
  %l102 = alloca i32
  %l104 = alloca i32
  %l106 = alloca ptr
  %l109 = alloca ptr
  %l113 = alloca i32
  %l117 = alloca i32
  %l119 = alloca i32
  %l121 = alloca ptr
  %l124 = alloca ptr
  %l128 = alloca i32
  %l132 = alloca i32
  %l134 = alloca i32
  %l136 = alloca ptr
  %l141 = alloca ptr
  %l145 = alloca i32
  %l149 = alloca i32
  %l151 = alloca i32
  %l153 = alloca ptr
  %l160 = alloca ptr
  %l164 = alloca i32
  %l168 = alloca i32
  %l170 = alloca i32
  %l172 = alloca ptr
  %l180 = alloca { i64, ptr }
  %l181 = alloca ptr
  %l185 = alloca { i64, ptr }
  %l187 = alloca i1
  %l190 = alloca ptr
  %l193 = alloca ptr
  %l197 = alloca i32
  %l201 = alloca i32
  %l203 = alloca i32
  %l205 = alloca ptr
  %l210 = alloca ptr
  %l214 = alloca i32
  %l218 = alloca i32
  %l221 = alloca i32
  %l223 = alloca ptr
  %l227 = alloca ptr
  %l230 = alloca ptr
  %s18 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  store ptr %a4, ptr %l4
  store i1 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t2, i32 0, i32 4
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = add i64 %t4, 1
  %t8 = load ptr, ptr %l6, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t8, i32 0, i32 4
  store i64 %t6, ptr %t9, !tbaa !24
  %t10 = load i32, ptr %l1, !range !{i32 0, i32 33}
  %t12 = trunc i64 18 to i32
  %t13 = icmp eq i32 %t10, %t12
  br i1 %t13, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb14
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  %t18 = load i32, ptr %l2, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l14
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 2
  %t25 = load i32, ptr %l3, !tbaa !23
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t24, i32 %t25)
  store i32 %t28, ptr %l18
  br label %bb5
bb5:
  %t29 = load i32, ptr %l14, !tbaa !23
  %t30 = load i32, ptr %l18, !tbaa !23
  %t31 = icmp ne i32 %t29, %t30
  br i1 %t31, label %bb6, label %bb7
bb6:
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l21, !tbaa !29
  %t34 = load ptr, ptr %l21, !tbaa !29
  %t35 = getelementptr %"compiler/generic:Program", ptr %t34, i32 0, i32 4
  %t36 = load i64, ptr %t35, !tbaa !24
  %t38 = sub i64 %t36, 1
  %t40 = load ptr, ptr %l21, !tbaa !29
  %t41 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 4
  store i64 %t38, ptr %t41, !tbaa !24
  store i32 65536, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l24, !tbaa !29
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/generic:Program", ptr %t44, i32 0, i32 2
  %t47 = load i32, ptr %l2, !tbaa !23
  %t50 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t46, i32 %t47)
  store i32 %t50, ptr %l28
  br label %bb9
bb9:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/generic:Program", ptr %t51, i32 0, i32 2
  %t54 = load i32, ptr %l3, !tbaa !23
  %t57 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t53, i32 %t54)
  store i32 %t57, ptr %l32
  br label %bb10
bb10:
  %t58 = load ptr, ptr %l4, !tbaa !29
  %t59 = load i1, ptr %l5, !tbaa !21
  %t60 = load ptr, ptr %l24, !tbaa !29
  %t61 = load i32, ptr %l28, !tbaa !23
  %t62 = load i32, ptr %l32, !tbaa !23
  %t65 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunifyLists(ptr %v0, ptr %v1, ptr %t60, i32 %t61, i32 %t62, ptr %t58, i1 %t59)
  store i32 %t65, ptr %l35
  %t66 = icmp ne i32 %t65, 0
  br i1 %t66, label %bb12, label %ok.67, !prof !99
ok.67:
  br label %bb11
bb11:
  br label %bb13
bb12:
  %t68 = load i32, ptr %l35, !tbaa !23
  %t69 = lshr i32 %t68, 16
  %t70 = and i32 %t68, 65535
  %t71 = icmp eq i32 %t69, 1
  %t72 = select i1 %t71, i32 1, i32 0
  %t73 = icmp eq i32 %t68, 0
  %t74 = shl i32 %t72, 16
  %t75 = or i32 %t74, %t70
  %t76 = select i1 %t73, i32 0, i32 %t75
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l37, !tbaa !29
  %t78 = load ptr, ptr %l37, !tbaa !29
  %t79 = getelementptr %"compiler/generic:Program", ptr %t78, i32 0, i32 4
  %t80 = load i64, ptr %t79, !tbaa !24
  %t82 = sub i64 %t80, 1
  %t84 = load ptr, ptr %l37, !tbaa !29
  %t85 = getelementptr %"compiler/generic:Program", ptr %t84, i32 0, i32 4
  store i64 %t82, ptr %t85, !tbaa !24
  store i32 %t76, ptr %rv
  br label %ret
bb13:
  br label %bb105
bb14:
  %t87 = load i32, ptr %l1, !range !{i32 0, i32 33}
  %t89 = trunc i64 19 to i32
  %t90 = icmp eq i32 %t87, %t89
  br i1 %t90, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb28
bb17:
  %t92 = load ptr, ptr %l0, !tbaa !29
  store ptr %t92, ptr %l42, !tbaa !29
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/generic:Program", ptr %t93, i32 0, i32 2
  %t96 = load i32, ptr %l2, !tbaa !23
  %t99 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t95, i32 %t96)
  store i32 %t99, ptr %l46
  br label %bb18
bb18:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Program", ptr %t100, i32 0, i32 2
  %t103 = load i32, ptr %l3, !tbaa !23
  %t106 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t102, i32 %t103)
  store i32 %t106, ptr %l50
  br label %bb19
bb19:
  %t107 = load ptr, ptr %l4, !tbaa !29
  %t108 = load i1, ptr %l5, !tbaa !21
  %t109 = load ptr, ptr %l42, !tbaa !29
  %t110 = load i32, ptr %l46, !tbaa !23
  %t111 = load i32, ptr %l50, !tbaa !23
  %t114 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnify(ptr %v0, ptr %v1, ptr %t109, i32 %t110, i32 %t111, ptr %t107, i1 false, i1 %t108)
  store i32 %t114, ptr %l53
  %t115 = icmp ne i32 %t114, 0
  br i1 %t115, label %bb21, label %ok.116, !prof !99
ok.116:
  br label %bb20
bb20:
  br label %bb22
bb21:
  %t117 = load i32, ptr %l53, !tbaa !23
  %t118 = lshr i32 %t117, 16
  %t119 = and i32 %t117, 65535
  %t120 = icmp eq i32 %t118, 1
  %t121 = select i1 %t120, i32 1, i32 0
  %t122 = icmp eq i32 %t117, 0
  %t123 = shl i32 %t121, 16
  %t124 = or i32 %t123, %t119
  %t125 = select i1 %t122, i32 0, i32 %t124
  %t126 = load ptr, ptr %l0, !tbaa !29
  store ptr %t126, ptr %l55, !tbaa !29
  %t127 = load ptr, ptr %l55, !tbaa !29
  %t128 = getelementptr %"compiler/generic:Program", ptr %t127, i32 0, i32 4
  %t129 = load i64, ptr %t128, !tbaa !24
  %t131 = sub i64 %t129, 1
  %t133 = load ptr, ptr %l55, !tbaa !29
  %t134 = getelementptr %"compiler/generic:Program", ptr %t133, i32 0, i32 4
  store i64 %t131, ptr %t134, !tbaa !24
  store i32 %t125, ptr %rv
  br label %ret
bb22:
  %t136 = load ptr, ptr %l0, !tbaa !29
  store ptr %t136, ptr %l58, !tbaa !29
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/generic:Program", ptr %t137, i32 0, i32 2
  %t140 = load i32, ptr %l2, !tbaa !23
  %t143 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t139, i32 %t140)
  store i32 %t143, ptr %l62
  br label %bb23
bb23:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/generic:Program", ptr %t144, i32 0, i32 2
  %t147 = load i32, ptr %l3, !tbaa !23
  %t150 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t146, i32 %t147)
  store i32 %t150, ptr %l66
  br label %bb24
bb24:
  %t151 = load ptr, ptr %l4, !tbaa !29
  %t152 = load i1, ptr %l5, !tbaa !21
  %t153 = load ptr, ptr %l58, !tbaa !29
  %t154 = load i32, ptr %l62, !tbaa !23
  %t155 = load i32, ptr %l66, !tbaa !23
  %t158 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnify(ptr %v0, ptr %v1, ptr %t153, i32 %t154, i32 %t155, ptr %t151, i1 false, i1 %t152)
  store i32 %t158, ptr %l69
  %t159 = icmp ne i32 %t158, 0
  br i1 %t159, label %bb26, label %ok.160, !prof !99
ok.160:
  br label %bb25
bb25:
  br label %bb27
bb26:
  %t161 = load i32, ptr %l69, !tbaa !23
  %t162 = lshr i32 %t161, 16
  %t163 = and i32 %t161, 65535
  %t164 = icmp eq i32 %t162, 1
  %t165 = select i1 %t164, i32 1, i32 0
  %t166 = icmp eq i32 %t161, 0
  %t167 = shl i32 %t165, 16
  %t168 = or i32 %t167, %t163
  %t169 = select i1 %t166, i32 0, i32 %t168
  %t170 = load ptr, ptr %l0, !tbaa !29
  store ptr %t170, ptr %l71, !tbaa !29
  %t171 = load ptr, ptr %l71, !tbaa !29
  %t172 = getelementptr %"compiler/generic:Program", ptr %t171, i32 0, i32 4
  %t173 = load i64, ptr %t172, !tbaa !24
  %t175 = sub i64 %t173, 1
  %t177 = load ptr, ptr %l71, !tbaa !29
  %t178 = getelementptr %"compiler/generic:Program", ptr %t177, i32 0, i32 4
  store i64 %t175, ptr %t178, !tbaa !24
  store i32 %t169, ptr %rv
  br label %ret
bb27:
  br label %bb105
bb28:
  %t180 = load i32, ptr %l1, !range !{i32 0, i32 33}
  %t182 = trunc i64 20 to i32
  %t183 = icmp eq i32 %t180, %t182
  br i1 %t183, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb37
bb31:
  %t185 = load ptr, ptr %l0, !tbaa !29
  store ptr %t185, ptr %l76, !tbaa !29
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t188 = getelementptr %"compiler/generic:Program", ptr %t186, i32 0, i32 2
  %t189 = load i32, ptr %l2, !tbaa !23
  %t192 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t188, i32 %t189)
  store i32 %t192, ptr %l80
  br label %bb32
bb32:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/generic:Program", ptr %t193, i32 0, i32 2
  %t196 = load i32, ptr %l3, !tbaa !23
  %t199 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t195, i32 %t196)
  store i32 %t199, ptr %l84
  br label %bb33
bb33:
  %t200 = load ptr, ptr %l4, !tbaa !29
  %t201 = load i1, ptr %l5, !tbaa !21
  %t202 = load ptr, ptr %l76, !tbaa !29
  %t203 = load i32, ptr %l80, !tbaa !23
  %t204 = load i32, ptr %l84, !tbaa !23
  %t207 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnify(ptr %v0, ptr %v1, ptr %t202, i32 %t203, i32 %t204, ptr %t200, i1 false, i1 %t201)
  store i32 %t207, ptr %l87
  %t208 = icmp ne i32 %t207, 0
  br i1 %t208, label %bb35, label %ok.209, !prof !99
ok.209:
  br label %bb34
bb34:
  br label %bb36
bb35:
  %t210 = load i32, ptr %l87, !tbaa !23
  %t211 = lshr i32 %t210, 16
  %t212 = and i32 %t210, 65535
  %t213 = icmp eq i32 %t211, 1
  %t214 = select i1 %t213, i32 1, i32 0
  %t215 = icmp eq i32 %t210, 0
  %t216 = shl i32 %t214, 16
  %t217 = or i32 %t216, %t212
  %t218 = select i1 %t215, i32 0, i32 %t217
  %t219 = load ptr, ptr %l0, !tbaa !29
  store ptr %t219, ptr %l89, !tbaa !29
  %t220 = load ptr, ptr %l89, !tbaa !29
  %t221 = getelementptr %"compiler/generic:Program", ptr %t220, i32 0, i32 4
  %t222 = load i64, ptr %t221, !tbaa !24
  %t224 = sub i64 %t222, 1
  %t226 = load ptr, ptr %l89, !tbaa !29
  %t227 = getelementptr %"compiler/generic:Program", ptr %t226, i32 0, i32 4
  store i64 %t224, ptr %t227, !tbaa !24
  store i32 %t218, ptr %rv
  br label %ret
bb36:
  br label %bb105
bb37:
  %t229 = load i32, ptr %l1, !range !{i32 0, i32 33}
  %t231 = trunc i64 21 to i32
  %t232 = icmp eq i32 %t229, %t231
  br i1 %t232, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb56
bb40:
  %t234 = load ptr, ptr %l0, !tbaa !29
  store ptr %t234, ptr %l94, !tbaa !29
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = getelementptr %"compiler/generic:Program", ptr %t235, i32 0, i32 2
  %t238 = load i32, ptr %l2, !tbaa !23
  %t241 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t237, i32 %t238)
  store i32 %t241, ptr %l98
  br label %bb41
bb41:
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t244 = getelementptr %"compiler/generic:Program", ptr %t242, i32 0, i32 2
  %t245 = load i32, ptr %l3, !tbaa !23
  %t248 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t244, i32 %t245)
  store i32 %t248, ptr %l102
  br label %bb42
bb42:
  %t249 = load ptr, ptr %l4, !tbaa !29
  %t250 = load ptr, ptr %l94, !tbaa !29
  %t251 = load i32, ptr %l98, !tbaa !23
  %t252 = load i32, ptr %l102, !tbaa !23
  %t254 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunifyLists(ptr %v0, ptr %v1, ptr %t250, i32 %t251, i32 %t252, ptr %t249, i1 false)
  store i32 %t254, ptr %l104
  %t255 = icmp ne i32 %t254, 0
  br i1 %t255, label %bb44, label %ok.256, !prof !99
ok.256:
  br label %bb43
bb43:
  br label %bb45
bb44:
  %t257 = load i32, ptr %l104, !tbaa !23
  %t258 = lshr i32 %t257, 16
  %t259 = and i32 %t257, 65535
  %t260 = icmp eq i32 %t258, 1
  %t261 = select i1 %t260, i32 1, i32 0
  %t262 = icmp eq i32 %t257, 0
  %t263 = shl i32 %t261, 16
  %t264 = or i32 %t263, %t259
  %t265 = select i1 %t262, i32 0, i32 %t264
  %t266 = load ptr, ptr %l0, !tbaa !29
  store ptr %t266, ptr %l106, !tbaa !29
  %t267 = load ptr, ptr %l106, !tbaa !29
  %t268 = getelementptr %"compiler/generic:Program", ptr %t267, i32 0, i32 4
  %t269 = load i64, ptr %t268, !tbaa !24
  %t271 = sub i64 %t269, 1
  %t273 = load ptr, ptr %l106, !tbaa !29
  %t274 = getelementptr %"compiler/generic:Program", ptr %t273, i32 0, i32 4
  store i64 %t271, ptr %t274, !tbaa !24
  store i32 %t265, ptr %rv
  br label %ret
bb45:
  %t276 = load ptr, ptr %l0, !tbaa !29
  store ptr %t276, ptr %l109, !tbaa !29
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t279 = getelementptr %"compiler/generic:Program", ptr %t277, i32 0, i32 2
  %t280 = load i32, ptr %l2, !tbaa !23
  %t283 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t279, i32 %t280)
  store i32 %t283, ptr %l113
  br label %bb46
bb46:
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t286 = getelementptr %"compiler/generic:Program", ptr %t284, i32 0, i32 2
  %t287 = load i32, ptr %l3, !tbaa !23
  %t290 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t286, i32 %t287)
  store i32 %t290, ptr %l117
  br label %bb47
bb47:
  %t291 = load ptr, ptr %l4, !tbaa !29
  %t292 = load ptr, ptr %l109, !tbaa !29
  %t293 = load i32, ptr %l113, !tbaa !23
  %t294 = load i32, ptr %l117, !tbaa !23
  %t296 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnify(ptr %v0, ptr %v1, ptr %t292, i32 %t293, i32 %t294, ptr %t291, i1 false, i1 false)
  store i32 %t296, ptr %l119
  %t297 = icmp ne i32 %t296, 0
  br i1 %t297, label %bb49, label %ok.298, !prof !99
ok.298:
  br label %bb48
bb48:
  br label %bb50
bb49:
  %t299 = load i32, ptr %l119, !tbaa !23
  %t300 = lshr i32 %t299, 16
  %t301 = and i32 %t299, 65535
  %t302 = icmp eq i32 %t300, 1
  %t303 = select i1 %t302, i32 1, i32 0
  %t304 = icmp eq i32 %t299, 0
  %t305 = shl i32 %t303, 16
  %t306 = or i32 %t305, %t301
  %t307 = select i1 %t304, i32 0, i32 %t306
  %t308 = load ptr, ptr %l0, !tbaa !29
  store ptr %t308, ptr %l121, !tbaa !29
  %t309 = load ptr, ptr %l121, !tbaa !29
  %t310 = getelementptr %"compiler/generic:Program", ptr %t309, i32 0, i32 4
  %t311 = load i64, ptr %t310, !tbaa !24
  %t313 = sub i64 %t311, 1
  %t315 = load ptr, ptr %l121, !tbaa !29
  %t316 = getelementptr %"compiler/generic:Program", ptr %t315, i32 0, i32 4
  store i64 %t313, ptr %t316, !tbaa !24
  store i32 %t307, ptr %rv
  br label %ret
bb50:
  %t318 = load ptr, ptr %l0, !tbaa !29
  store ptr %t318, ptr %l124, !tbaa !29
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t321 = getelementptr %"compiler/generic:Program", ptr %t319, i32 0, i32 2
  %t322 = load i32, ptr %l2, !tbaa !23
  %t325 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t321, i32 %t322)
  store i32 %t325, ptr %l128
  br label %bb51
bb51:
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t328 = getelementptr %"compiler/generic:Program", ptr %t326, i32 0, i32 2
  %t329 = load i32, ptr %l3, !tbaa !23
  %t332 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t328, i32 %t329)
  store i32 %t332, ptr %l132
  br label %bb52
bb52:
  %t333 = load ptr, ptr %l4, !tbaa !29
  %t334 = load ptr, ptr %l124, !tbaa !29
  %t335 = load i32, ptr %l128, !tbaa !23
  %t336 = load i32, ptr %l132, !tbaa !23
  %t338 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunifyErrs(ptr %v0, ptr %v1, ptr %t334, i32 %t335, i32 %t336, ptr %t333)
  store i32 %t338, ptr %l134
  %t339 = icmp ne i32 %t338, 0
  br i1 %t339, label %bb54, label %ok.340, !prof !99
ok.340:
  br label %bb53
bb53:
  br label %bb55
bb54:
  %t341 = load i32, ptr %l134, !tbaa !23
  %t342 = lshr i32 %t341, 16
  %t343 = and i32 %t341, 65535
  %t344 = icmp eq i32 %t342, 1
  %t345 = select i1 %t344, i32 1, i32 0
  %t346 = icmp eq i32 %t341, 0
  %t347 = shl i32 %t345, 16
  %t348 = or i32 %t347, %t343
  %t349 = select i1 %t346, i32 0, i32 %t348
  %t350 = load ptr, ptr %l0, !tbaa !29
  store ptr %t350, ptr %l136, !tbaa !29
  %t351 = load ptr, ptr %l136, !tbaa !29
  %t352 = getelementptr %"compiler/generic:Program", ptr %t351, i32 0, i32 4
  %t353 = load i64, ptr %t352, !tbaa !24
  %t355 = sub i64 %t353, 1
  %t357 = load ptr, ptr %l136, !tbaa !29
  %t358 = getelementptr %"compiler/generic:Program", ptr %t357, i32 0, i32 4
  store i64 %t355, ptr %t358, !tbaa !24
  store i32 %t349, ptr %rv
  br label %ret
bb55:
  br label %bb105
bb56:
  %t360 = load i32, ptr %l1, !range !{i32 0, i32 33}
  %t362 = trunc i64 30 to i32
  %t363 = icmp eq i32 %t360, %t362
  br i1 %t363, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb65
bb59:
  %t365 = load ptr, ptr %l0, !tbaa !29
  store ptr %t365, ptr %l141, !tbaa !29
  %t366 = load ptr, ptr %l0, !tbaa !29
  %t368 = getelementptr %"compiler/generic:Program", ptr %t366, i32 0, i32 2
  %t369 = load i32, ptr %l2, !tbaa !23
  %t372 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %t368, i32 %t369)
  store i32 %t372, ptr %l145
  br label %bb60
bb60:
  %t373 = load ptr, ptr %l0, !tbaa !29
  %t375 = getelementptr %"compiler/generic:Program", ptr %t373, i32 0, i32 2
  %t376 = load i32, ptr %l3, !tbaa !23
  %t379 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %t375, i32 %t376)
  store i32 %t379, ptr %l149
  br label %bb61
bb61:
  %t380 = load ptr, ptr %l4, !tbaa !29
  %t381 = load ptr, ptr %l141, !tbaa !29
  %t382 = load i32, ptr %l145, !tbaa !23
  %t383 = load i32, ptr %l149, !tbaa !23
  %t385 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunifyErrs(ptr %v0, ptr %v1, ptr %t381, i32 %t382, i32 %t383, ptr %t380)
  store i32 %t385, ptr %l151
  %t386 = icmp ne i32 %t385, 0
  br i1 %t386, label %bb63, label %ok.387, !prof !99
ok.387:
  br label %bb62
bb62:
  br label %bb64
bb63:
  %t388 = load i32, ptr %l151, !tbaa !23
  %t389 = lshr i32 %t388, 16
  %t390 = and i32 %t388, 65535
  %t391 = icmp eq i32 %t389, 1
  %t392 = select i1 %t391, i32 1, i32 0
  %t393 = icmp eq i32 %t388, 0
  %t394 = shl i32 %t392, 16
  %t395 = or i32 %t394, %t390
  %t396 = select i1 %t393, i32 0, i32 %t395
  %t397 = load ptr, ptr %l0, !tbaa !29
  store ptr %t397, ptr %l153, !tbaa !29
  %t398 = load ptr, ptr %l153, !tbaa !29
  %t399 = getelementptr %"compiler/generic:Program", ptr %t398, i32 0, i32 4
  %t400 = load i64, ptr %t399, !tbaa !24
  %t402 = sub i64 %t400, 1
  %t404 = load ptr, ptr %l153, !tbaa !29
  %t405 = getelementptr %"compiler/generic:Program", ptr %t404, i32 0, i32 4
  store i64 %t402, ptr %t405, !tbaa !24
  store i32 %t396, ptr %rv
  br label %ret
bb64:
  br label %bb105
bb65:
  %t407 = load i32, ptr %l1, !range !{i32 0, i32 33}
  %t409 = trunc i64 22 to i32
  %t410 = icmp eq i32 %t407, %t409
  br i1 %t410, label %bb66, label %bb67
bb66:
  br label %bb70
bb67:
  %t412 = load i32, ptr %l1, !range !{i32 0, i32 33}
  %t414 = trunc i64 23 to i32
  %t415 = icmp eq i32 %t412, %t414
  br i1 %t415, label %bb68, label %bb69
bb68:
  br label %bb70
bb69:
  br label %bb76
bb70:
  %t417 = load ptr, ptr %l0, !tbaa !29
  store ptr %t417, ptr %l160, !tbaa !29
  %t418 = load ptr, ptr %l0, !tbaa !29
  %t420 = getelementptr %"compiler/generic:Program", ptr %t418, i32 0, i32 2
  %t421 = load i32, ptr %l2, !tbaa !23
  %t424 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t420, i32 %t421)
  store i32 %t424, ptr %l164
  br label %bb71
bb71:
  %t425 = load ptr, ptr %l0, !tbaa !29
  %t427 = getelementptr %"compiler/generic:Program", ptr %t425, i32 0, i32 2
  %t428 = load i32, ptr %l3, !tbaa !23
  %t431 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t427, i32 %t428)
  store i32 %t431, ptr %l168
  br label %bb72
bb72:
  %t432 = load ptr, ptr %l4, !tbaa !29
  %t433 = load ptr, ptr %l160, !tbaa !29
  %t434 = load i32, ptr %l164, !tbaa !23
  %t435 = load i32, ptr %l168, !tbaa !23
  %t437 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunifyLists(ptr %v0, ptr %v1, ptr %t433, i32 %t434, i32 %t435, ptr %t432, i1 false)
  store i32 %t437, ptr %l170
  %t438 = icmp ne i32 %t437, 0
  br i1 %t438, label %bb74, label %ok.439, !prof !99
ok.439:
  br label %bb73
bb73:
  br label %bb75
bb74:
  %t440 = load i32, ptr %l170, !tbaa !23
  %t441 = lshr i32 %t440, 16
  %t442 = and i32 %t440, 65535
  %t443 = icmp eq i32 %t441, 1
  %t444 = select i1 %t443, i32 1, i32 0
  %t445 = icmp eq i32 %t440, 0
  %t446 = shl i32 %t444, 16
  %t447 = or i32 %t446, %t442
  %t448 = select i1 %t445, i32 0, i32 %t447
  %t449 = load ptr, ptr %l0, !tbaa !29
  store ptr %t449, ptr %l172, !tbaa !29
  %t450 = load ptr, ptr %l172, !tbaa !29
  %t451 = getelementptr %"compiler/generic:Program", ptr %t450, i32 0, i32 4
  %t452 = load i64, ptr %t451, !tbaa !24
  %t454 = sub i64 %t452, 1
  %t456 = load ptr, ptr %l172, !tbaa !29
  %t457 = getelementptr %"compiler/generic:Program", ptr %t456, i32 0, i32 4
  store i64 %t454, ptr %t457, !tbaa !24
  store i32 %t448, ptr %rv
  br label %ret
bb75:
  br label %bb105
bb76:
  %t459 = load i32, ptr %l1, !range !{i32 0, i32 33}
  %t461 = trunc i64 24 to i32
  %t462 = icmp eq i32 %t459, %t461
  br i1 %t462, label %bb77, label %bb78
bb77:
  br label %bb79
bb78:
  br label %bb91
bb79:
  store %olang.scope zeroinitializer, ptr %s18
  %t464 = load ptr, ptr %l0, !tbaa !29
  %t466 = getelementptr %"compiler/generic:Program", ptr %t464, i32 0, i32 2
  %t467 = load i32, ptr %l2, !tbaa !23
  %t470 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeNames(ptr %v0, ptr %s18, ptr %t466, i32 %t467)
  store { i64, ptr } %t470, ptr %l180
  br label %bb80
bb80:
  store ptr %l180, ptr %l181
  %t471 = load ptr, ptr %l0, !tbaa !29
  %t473 = getelementptr %"compiler/generic:Program", ptr %t471, i32 0, i32 2
  %t474 = load i32, ptr %l3, !tbaa !23
  %t477 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeNames(ptr %v0, ptr %s18, ptr %t473, i32 %t474)
  store { i64, ptr } %t477, ptr %l185
  br label %bb81
bb81:
  %t478 = load ptr, ptr %l181
  %t480 = call i1 @olang_2eHelperKind_2eEqual_2eArray_3ccompiler_2fsource_3aNameId_3e_26(ptr %t478, ptr %l185)
  store i1 %t480, ptr %l187
  br label %bb82
bb82:
  %t481 = load i1, ptr %l187, !tbaa !21
  %t482 = xor i1 %t481, true
  br i1 %t482, label %bb83, label %bb84
bb83:
  call void @__olang_scope_close(ptr %s18)
  %t484 = load ptr, ptr %l0, !tbaa !29
  store ptr %t484, ptr %l190, !tbaa !29
  %t485 = load ptr, ptr %l190, !tbaa !29
  %t486 = getelementptr %"compiler/generic:Program", ptr %t485, i32 0, i32 4
  %t487 = load i64, ptr %t486, !tbaa !24
  %t489 = sub i64 %t487, 1
  %t491 = load ptr, ptr %l190, !tbaa !29
  %t492 = getelementptr %"compiler/generic:Program", ptr %t491, i32 0, i32 4
  store i64 %t489, ptr %t492, !tbaa !24
  store i32 65536, ptr %rv
  br label %ret
bb84:
  br label %bb85
bb85:
  %t494 = load ptr, ptr %l0, !tbaa !29
  store ptr %t494, ptr %l193, !tbaa !29
  %t495 = load ptr, ptr %l0, !tbaa !29
  %t497 = getelementptr %"compiler/generic:Program", ptr %t495, i32 0, i32 2
  %t498 = load i32, ptr %l2, !tbaa !23
  %t501 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t497, i32 %t498)
  store i32 %t501, ptr %l197
  br label %bb86
bb86:
  %t502 = load ptr, ptr %l0, !tbaa !29
  %t504 = getelementptr %"compiler/generic:Program", ptr %t502, i32 0, i32 2
  %t505 = load i32, ptr %l3, !tbaa !23
  %t508 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t504, i32 %t505)
  store i32 %t508, ptr %l201
  br label %bb87
bb87:
  %t509 = load ptr, ptr %l4, !tbaa !29
  %t510 = load ptr, ptr %l193, !tbaa !29
  %t511 = load i32, ptr %l197, !tbaa !23
  %t512 = load i32, ptr %l201, !tbaa !23
  %t514 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunifyLists(ptr %v0, ptr %v1, ptr %t510, i32 %t511, i32 %t512, ptr %t509, i1 false)
  store i32 %t514, ptr %l203
  %t515 = icmp ne i32 %t514, 0
  br i1 %t515, label %bb89, label %ok.516, !prof !99
ok.516:
  br label %bb88
bb88:
  br label %bb90
bb89:
  %t517 = load i32, ptr %l203, !tbaa !23
  %t518 = lshr i32 %t517, 16
  %t519 = and i32 %t517, 65535
  %t520 = icmp eq i32 %t518, 1
  %t521 = select i1 %t520, i32 1, i32 0
  %t522 = icmp eq i32 %t517, 0
  %t523 = shl i32 %t521, 16
  %t524 = or i32 %t523, %t519
  %t525 = select i1 %t522, i32 0, i32 %t524
  call void @__olang_scope_close(ptr %s18)
  %t526 = load ptr, ptr %l0, !tbaa !29
  store ptr %t526, ptr %l205, !tbaa !29
  %t527 = load ptr, ptr %l205, !tbaa !29
  %t528 = getelementptr %"compiler/generic:Program", ptr %t527, i32 0, i32 4
  %t529 = load i64, ptr %t528, !tbaa !24
  %t531 = sub i64 %t529, 1
  %t533 = load ptr, ptr %l205, !tbaa !29
  %t534 = getelementptr %"compiler/generic:Program", ptr %t533, i32 0, i32 4
  store i64 %t531, ptr %t534, !tbaa !24
  store i32 %t525, ptr %rv
  br label %ret
bb90:
  call void @__olang_scope_close(ptr %s18)
  br label %bb105
bb91:
  %t536 = load i32, ptr %l1, !range !{i32 0, i32 33}
  %t538 = trunc i64 29 to i32
  %t539 = icmp eq i32 %t536, %t538
  br i1 %t539, label %bb92, label %bb93
bb92:
  br label %bb94
bb93:
  br label %bb100
bb94:
  %t541 = load ptr, ptr %l0, !tbaa !29
  store ptr %t541, ptr %l210, !tbaa !29
  %t542 = load ptr, ptr %l0, !tbaa !29
  %t544 = getelementptr %"compiler/generic:Program", ptr %t542, i32 0, i32 2
  %t545 = load i32, ptr %l2, !tbaa !23
  %t548 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t544, i32 %t545)
  store i32 %t548, ptr %l214
  br label %bb95
bb95:
  %t549 = load ptr, ptr %l0, !tbaa !29
  %t551 = getelementptr %"compiler/generic:Program", ptr %t549, i32 0, i32 2
  %t552 = load i32, ptr %l3, !tbaa !23
  %t555 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t551, i32 %t552)
  store i32 %t555, ptr %l218
  br label %bb96
bb96:
  %t556 = load ptr, ptr %l4, !tbaa !29
  %t557 = load i1, ptr %l5, !tbaa !21
  %t558 = load ptr, ptr %l210, !tbaa !29
  %t559 = load i32, ptr %l214, !tbaa !23
  %t560 = load i32, ptr %l218, !tbaa !23
  %t563 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnify(ptr %v0, ptr %v1, ptr %t558, i32 %t559, i32 %t560, ptr %t556, i1 false, i1 %t557)
  store i32 %t563, ptr %l221
  %t564 = icmp ne i32 %t563, 0
  br i1 %t564, label %bb98, label %ok.565, !prof !99
ok.565:
  br label %bb97
bb97:
  br label %bb99
bb98:
  %t566 = load i32, ptr %l221, !tbaa !23
  %t567 = lshr i32 %t566, 16
  %t568 = and i32 %t566, 65535
  %t569 = icmp eq i32 %t567, 1
  %t570 = select i1 %t569, i32 1, i32 0
  %t571 = icmp eq i32 %t566, 0
  %t572 = shl i32 %t570, 16
  %t573 = or i32 %t572, %t568
  %t574 = select i1 %t571, i32 0, i32 %t573
  %t575 = load ptr, ptr %l0, !tbaa !29
  store ptr %t575, ptr %l223, !tbaa !29
  %t576 = load ptr, ptr %l223, !tbaa !29
  %t577 = getelementptr %"compiler/generic:Program", ptr %t576, i32 0, i32 4
  %t578 = load i64, ptr %t577, !tbaa !24
  %t580 = sub i64 %t578, 1
  %t582 = load ptr, ptr %l223, !tbaa !29
  %t583 = getelementptr %"compiler/generic:Program", ptr %t582, i32 0, i32 4
  store i64 %t580, ptr %t583, !tbaa !24
  store i32 %t574, ptr %rv
  br label %ret
bb99:
  br label %bb105
bb100:
  br i1 true, label %bb101, label %bb102
bb101:
  br label %bb103
bb102:
  br label %bb104
bb103:
  %t585 = load ptr, ptr %l0, !tbaa !29
  store ptr %t585, ptr %l227, !tbaa !29
  %t586 = load ptr, ptr %l227, !tbaa !29
  %t587 = getelementptr %"compiler/generic:Program", ptr %t586, i32 0, i32 4
  %t588 = load i64, ptr %t587, !tbaa !24
  %t590 = sub i64 %t588, 1
  %t592 = load ptr, ptr %l227, !tbaa !29
  %t593 = getelementptr %"compiler/generic:Program", ptr %t592, i32 0, i32 4
  store i64 %t590, ptr %t593, !tbaa !24
  store i32 65536, ptr %rv
  br label %ret
bb104:
  call void @__olang_check_failed(ptr @olang_loc_f83e897c6289299d_c5b35c0c7cd0f831)
  unreachable
bb105:
  %t595 = load ptr, ptr %l0, !tbaa !29
  store ptr %t595, ptr %l230, !tbaa !29
  %t596 = load ptr, ptr %l230, !tbaa !29
  %t597 = getelementptr %"compiler/generic:Program", ptr %t596, i32 0, i32 4
  %t598 = load i64, ptr %t597, !tbaa !24
  %t600 = sub i64 %t598, 1
  %t602 = load ptr, ptr %l230, !tbaa !29
  %t603 = getelementptr %"compiler/generic:Program", ptr %t602, i32 0, i32 4
  store i64 %t600, ptr %t603, !tbaa !24
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunsubst(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l24 = alloca i64
  %l27 = alloca i64
  %l45 = alloca { i64, ptr }
  %l55 = alloca i32
  %l61 = alloca i32
  %l67 = alloca i32
  %l71 = alloca ptr
  %l75 = alloca i32
  %l76 = alloca { i64, ptr }
  %l78 = alloca i64
  %l87 = alloca i64
  %l90 = alloca i64
  %l108 = alloca i64
  %l110 = alloca { i64, ptr }
  %l115 = alloca i32
  %l118 = alloca ptr
  %l122 = alloca i32
  %l126 = alloca i32
  %l127 = alloca i32
  %l131 = alloca ptr
  %l132 = alloca ptr
  %l136 = alloca i32
  %l139 = alloca i32
  %l140 = alloca ptr
  %l144 = alloca i32
  %l147 = alloca i32
  %l148 = alloca i32
  %l152 = alloca ptr
  %l153 = alloca ptr
  %l157 = alloca i32
  %l160 = alloca i32
  %l164 = alloca i64
  %l165 = alloca i32
  %l169 = alloca ptr
  %l170 = alloca ptr
  %l174 = alloca i32
  %l177 = alloca i32
  %l178 = alloca i32
  %s5 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l4, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t5 = load i64, ptr %l5, !tbaa !24
  %t6 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l6, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l5, !tbaa !24
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l6, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l6, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l27, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l27, !tbaa !24
  store i64 %t31, ptr %l24, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l24, !tbaa !24
  store i64 %t32, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb7
bb7:
  %t33 = load i64, ptr %l8, !tbaa !24
  %t34 = load i64, ptr %l7, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  br label %bb16
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l4, !tbaa !24
  %t42 = load i64, ptr %l8, !tbaa !24
  %t43 = load i64, ptr %l6, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l9, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t51, ptr %l45, !tbaa !27
  %t52 = load i64, ptr %l9, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i32, ptr %t55, i64 %t52
  %t57 = load i32, ptr %t56, !tbaa !33
  %t58 = load i32, ptr %l1, !tbaa !23
  %t61 = icmp eq i32 %t57, %t58
  br i1 %t61, label %bb11, label %bb12
bb11:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/generic:Program", ptr %t63, i32 0, i32 2
  %t66 = load i64, ptr %l2, !tbaa !24
  %t67 = load i64, ptr %l9, !tbaa !24
  %t68 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eVar(ptr %v0, ptr %t65, i64 %t66, i64 %t67, i64 %t68)
  store i32 %t73, ptr %l55
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t74 = load i32, ptr %l55, !tbaa !23
  store i32 %t74, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t75 = load i64, ptr %l8, !tbaa !24
  %t77 = add i64 %t75, 1
  store i64 %t77, ptr %l8, !tbaa !24
  br label %bb7
bb16:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/generic:Program", ptr %t79, i32 0, i32 2
  %t82 = load i32, ptr %l1, !tbaa !23
  %t85 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t81, i32 %t82)
  store i32 %t85, ptr %l61
  br label %bb17
bb17:
  %t86 = load i32, ptr %l61, !range !{i32 0, i32 33}
  store i32 %t86, ptr %l10
  %t87 = load i32, ptr %l10, !range !{i32 0, i32 33}
  %t89 = trunc i64 18 to i32
  %t90 = icmp eq i32 %t87, %t89
  br i1 %t90, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb47
bb20:
  store %olang.scope zeroinitializer, ptr %s5
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/generic:Program", ptr %t92, i32 0, i32 2
  %t95 = load i32, ptr %l1, !tbaa !23
  %t98 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t94, i32 %t95)
  store i32 %t98, ptr %l67
  br label %bb21
bb21:
  %t99 = load i32, ptr %l67, !tbaa !23
  %t100 = icmp eq i32 %t99, 0
  br i1 %t100, label %bb22, label %bb23
bb22:
  %t102 = load i32, ptr %l1, !tbaa !23
  call void @__olang_scope_close(ptr %s5)
  store i32 %t102, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/generic:Program", ptr %t104, i32 0, i32 2
  store ptr %t106, ptr %l71, !tbaa !29
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/generic:Program", ptr %t107, i32 0, i32 2
  %t110 = load i32, ptr %l1, !tbaa !23
  %t113 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t109, i32 %t110)
  store i32 %t113, ptr %l75
  br label %bb25
bb25:
  %t114 = load ptr, ptr %l71, !tbaa !29
  %t115 = load i32, ptr %l75, !tbaa !23
  %t116 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t114, i32 %t115)
  store { i64, ptr } %t116, ptr %l76
  br label %bb26
bb26:
  %t117 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t117, ptr %l11, !tbaa !27
  %t118 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t118, 0
  store i64 %t120, ptr %l78, !tbaa !24
  %t121 = load i64, ptr %l78, !tbaa !24
  %t122 = icmp sge i64 %t121, 0
  br i1 %t122, label %bb27, label %bb28
bb27:
  %t124 = load i64, ptr %l78, !tbaa !24
  %t125 = icmp sle i64 %t124, 2305843009213693951
  br i1 %t125, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_dbc69524847f1d49_8831f326edbf0acd)
  unreachable
bb29:
  %t127 = load i64, ptr %l78, !tbaa !24
  %t128 = mul i64 %t127, 4
  %t129 = call ptr @__olang_scope_alloc_zeroed(ptr %s5, i64 %t128)
  %t130 = insertvalue { i64, ptr } undef, i64 %t127, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t129, 1
  store { i64, ptr } %t131, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t133 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t133, 0
  store i64 %t135, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t137 = load i64, ptr %l14, !tbaa !24
  %t138 = load i64, ptr %l13, !tbaa !24
  %t141 = icmp sgt i64 %t137, %t138
  br i1 %t141, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_dbc69524847f1d49_8831f326edbf0acd)
  unreachable
bb31:
  %t143 = load i64, ptr %l15, !tbaa !24
  %t145 = icmp sgt i64 %t143, 0
  br i1 %t145, label %bb33, label %bb34
bb32:
  store i64 0, ptr %l87, !tbaa !24
  br label %bb36
bb33:
  %t147 = load i64, ptr %l14, !tbaa !24
  %t148 = load i64, ptr %l13, !tbaa !24
  %t151 = sub i64 %t147, %t148
  %t152 = load i64, ptr %l15, !tbaa !24
  %t155 = add i64 %t151, %t152
  %t157 = sub i64 %t155, 1
  %t158 = load i64, ptr %l15, !tbaa !24
  %t161 = sdiv i64 %t157, %t158
  store i64 %t161, ptr %l90, !tbaa !24
  br label %bb35
bb34:
  store i64 0, ptr %l90, !tbaa !24
  br label %bb35
bb35:
  %t163 = load i64, ptr %l90, !tbaa !24
  store i64 %t163, ptr %l87, !tbaa !24
  br label %bb36
bb36:
  %t164 = load i64, ptr %l87, !tbaa !24
  store i64 %t164, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb37
bb37:
  %t165 = load i64, ptr %l17, !tbaa !24
  %t166 = load i64, ptr %l16, !tbaa !24
  %t169 = icmp slt i64 %t165, %t166
  %t171 = xor i1 %t169, true
  br i1 %t171, label %bb38, label %bb39
bb38:
  br label %bb43
bb39:
  br label %bb40
bb40:
  %t173 = load i64, ptr %l13, !tbaa !24
  %t174 = load i64, ptr %l17, !tbaa !24
  %t175 = load i64, ptr %l15, !tbaa !24
  %t178 = mul i64 %t174, %t175
  %t181 = add i64 %t173, %t178
  store i64 %t181, ptr %l18, !tbaa !24
  %t183 = load i64, ptr %l18, !tbaa !24
  store i64 %t183, ptr %l108, !tbaa !24
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t185 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t185, ptr %l110, !tbaa !27
  %t186 = load i64, ptr %l18, !tbaa !24
  %t188 = getelementptr { i64, ptr }, ptr %l110, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = getelementptr i32, ptr %t189, i64 %t186
  %t191 = load i32, ptr %t190, !tbaa !33
  %t192 = load i64, ptr %l2, !tbaa !24
  %t193 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t198 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunsubst(ptr %v0, ptr %v1, ptr %t184, i32 %t191, i64 %t192, { i64, ptr } %t193)
  store i32 %t198, ptr %l115
  br label %bb41
bb41:
  %t199 = load i32, ptr %l115, !tbaa !23
  %t200 = load i64, ptr %l108, !tbaa !24
  %t201 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !27
  %t203 = getelementptr i32, ptr %t202, i64 %t200
  store i32 %t199, ptr %t203, !tbaa !33
  br label %bb42
bb42:
  %t204 = load i64, ptr %l17, !tbaa !24
  %t206 = add i64 %t204, 1
  store i64 %t206, ptr %l17, !tbaa !24
  br label %bb37
bb43:
  %t208 = load ptr, ptr %l0, !tbaa !29
  store ptr %t208, ptr %l118, !tbaa !29
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr %"compiler/generic:Program", ptr %t209, i32 0, i32 2
  %t212 = load i32, ptr %l1, !tbaa !23
  %t215 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t211, i32 %t212)
  store i32 %t215, ptr %l122
  br label %bb44
bb44:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/generic:Program", ptr %t216, i32 0, i32 2
  %t219 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t222 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s5, ptr %t218, { i64, ptr } %t219)
  store i32 %t222, ptr %l126
  br label %bb45
bb45:
  %t223 = load ptr, ptr %l118, !tbaa !29
  %t224 = load i32, ptr %l122, !tbaa !23
  %t225 = load i32, ptr %l126, !tbaa !23
  %t226 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstance(ptr %v0, ptr %t223, i32 %t224, i32 %t225)
  store i32 %t226, ptr %l127
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s5)
  %t227 = load i32, ptr %l127, !tbaa !23
  store i32 %t227, ptr %rv
  br label %ret
bb47:
  %t228 = load i32, ptr %l10, !range !{i32 0, i32 33}
  %t230 = trunc i64 19 to i32
  %t231 = icmp eq i32 %t228, %t230
  br i1 %t231, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb56
bb50:
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t235 = getelementptr %"compiler/generic:Program", ptr %t233, i32 0, i32 2
  store ptr %t235, ptr %l131, !tbaa !29
  %t236 = load ptr, ptr %l0, !tbaa !29
  store ptr %t236, ptr %l132, !tbaa !29
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t239 = getelementptr %"compiler/generic:Program", ptr %t237, i32 0, i32 2
  %t240 = load i32, ptr %l1, !tbaa !23
  %t243 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t239, i32 %t240)
  store i32 %t243, ptr %l136
  br label %bb51
bb51:
  %t244 = load i64, ptr %l2, !tbaa !24
  %t245 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t246 = load ptr, ptr %l132, !tbaa !29
  %t247 = load i32, ptr %l136, !tbaa !23
  %t250 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunsubst(ptr %v0, ptr %v1, ptr %t246, i32 %t247, i64 %t244, { i64, ptr } %t245)
  store i32 %t250, ptr %l139
  br label %bb52
bb52:
  %t251 = load ptr, ptr %l0, !tbaa !29
  store ptr %t251, ptr %l140, !tbaa !29
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = getelementptr %"compiler/generic:Program", ptr %t252, i32 0, i32 2
  %t255 = load i32, ptr %l1, !tbaa !23
  %t258 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t254, i32 %t255)
  store i32 %t258, ptr %l144
  br label %bb53
bb53:
  %t259 = load i64, ptr %l2, !tbaa !24
  %t260 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t261 = load ptr, ptr %l140, !tbaa !29
  %t262 = load i32, ptr %l144, !tbaa !23
  %t265 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunsubst(ptr %v0, ptr %v1, ptr %t261, i32 %t262, i64 %t259, { i64, ptr } %t260)
  store i32 %t265, ptr %l147
  br label %bb54
bb54:
  %t266 = load ptr, ptr %l131, !tbaa !29
  %t267 = load i32, ptr %l139, !tbaa !23
  %t268 = load i32, ptr %l147, !tbaa !23
  %t269 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t266, i32 %t267, i32 %t268)
  store i32 %t269, ptr %l148
  br label %bb55
bb55:
  %t270 = load i32, ptr %l148, !tbaa !23
  store i32 %t270, ptr %rv
  br label %ret
bb56:
  %t271 = load i32, ptr %l10, !range !{i32 0, i32 33}
  %t273 = trunc i64 20 to i32
  %t274 = icmp eq i32 %t271, %t273
  br i1 %t274, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb64
bb59:
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t278 = getelementptr %"compiler/generic:Program", ptr %t276, i32 0, i32 2
  store ptr %t278, ptr %l152, !tbaa !29
  %t279 = load ptr, ptr %l0, !tbaa !29
  store ptr %t279, ptr %l153, !tbaa !29
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t282 = getelementptr %"compiler/generic:Program", ptr %t280, i32 0, i32 2
  %t283 = load i32, ptr %l1, !tbaa !23
  %t286 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t282, i32 %t283)
  store i32 %t286, ptr %l157
  br label %bb60
bb60:
  %t287 = load i64, ptr %l2, !tbaa !24
  %t288 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t289 = load ptr, ptr %l153, !tbaa !29
  %t290 = load i32, ptr %l157, !tbaa !23
  %t293 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunsubst(ptr %v0, ptr %v1, ptr %t289, i32 %t290, i64 %t287, { i64, ptr } %t288)
  store i32 %t293, ptr %l160
  br label %bb61
bb61:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t296 = getelementptr %"compiler/generic:Program", ptr %t294, i32 0, i32 2
  %t297 = load i32, ptr %l1, !tbaa !23
  %t300 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t296, i32 %t297)
  store i64 %t300, ptr %l164
  br label %bb62
bb62:
  %t301 = load ptr, ptr %l152, !tbaa !29
  %t302 = load i32, ptr %l160, !tbaa !23
  %t303 = load i64, ptr %l164, !tbaa !24
  %t304 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t301, i32 %t302, i64 %t303)
  store i32 %t304, ptr %l165
  br label %bb63
bb63:
  %t305 = load i32, ptr %l165, !tbaa !23
  store i32 %t305, ptr %rv
  br label %ret
bb64:
  %t306 = load i32, ptr %l10, !range !{i32 0, i32 33}
  %t308 = trunc i64 29 to i32
  %t309 = icmp eq i32 %t306, %t308
  br i1 %t309, label %bb65, label %bb66
bb65:
  br label %bb67
bb66:
  br label %bb71
bb67:
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t313 = getelementptr %"compiler/generic:Program", ptr %t311, i32 0, i32 2
  store ptr %t313, ptr %l169, !tbaa !29
  %t314 = load ptr, ptr %l0, !tbaa !29
  store ptr %t314, ptr %l170, !tbaa !29
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t317 = getelementptr %"compiler/generic:Program", ptr %t315, i32 0, i32 2
  %t318 = load i32, ptr %l1, !tbaa !23
  %t321 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t317, i32 %t318)
  store i32 %t321, ptr %l174
  br label %bb68
bb68:
  %t322 = load i64, ptr %l2, !tbaa !24
  %t323 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t324 = load ptr, ptr %l170, !tbaa !29
  %t325 = load i32, ptr %l174, !tbaa !23
  %t328 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunsubst(ptr %v0, ptr %v1, ptr %t324, i32 %t325, i64 %t322, { i64, ptr } %t323)
  store i32 %t328, ptr %l177
  br label %bb69
bb69:
  %t329 = load ptr, ptr %l169, !tbaa !29
  %t330 = load i32, ptr %l177, !tbaa !23
  %t331 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAny(ptr %v0, ptr %t329, i32 %t330)
  store i32 %t331, ptr %l178
  br label %bb70
bb70:
  %t332 = load i32, ptr %l178, !tbaa !23
  store i32 %t332, ptr %rv
  br label %ret
bb71:
  br i1 true, label %bb72, label %bb73
bb72:
  br label %bb74
bb73:
  br label %bb75
bb74:
  %t333 = load i32, ptr %l1, !tbaa !23
  store i32 %t333, ptr %rv
  br label %ret
bb75:
  call void @__olang_check_failed(ptr @olang_loc_737134d81da26253_60c38b193f08901f)
  unreachable
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2evarsBound(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l3 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l6 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l7 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l9 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l10 = alloca i32
  %l12 = alloca i1
  %l16 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/generic:Context", ptr %a1, i32 0, i32 2
  %t5 = call %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Ha72624ba64524ee3315305b5d1bfb369(ptr %v1, ptr %v1, ptr %t3)
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l6
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t6, ptr %l2
  br label %bb2
bb2:
  %t8 = call { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20co_H6cf169b12565f300e9fe11f1c8d55061(ptr %v1, ptr %l2)
  %t9 = extractvalue { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } %t8, 1
  %t10 = extractvalue { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } %t8, 0
  store i32 %t10, ptr %l10
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb4, label %ok.12, !prof !99
ok.12:
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t9, ptr %l9
  br label %bb3
bb3:
  %t13 = load %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l9
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t13, ptr %l7
  br label %bb6
bb4:
  %t14 = load i32, ptr %l10, !tbaa !23
  %t15 = ashr i32 %t14, 16
  %t17 = icmp eq i32 %t15, 1
  store i1 %t17, ptr %l12, !tbaa !21
  br label %bb5
bb5:
  call void @__olang_ert_req_clear()
  br label %bb12
bb6:
  %t18 = load %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l7
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t18, ptr %l3
  %t21 = getelementptr %"compiler/generic:Program", ptr %a0, i32 0, i32 2
  %t22 = getelementptr %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l3, i32 0, i32 1
  %t23 = load i32, ptr %t22, !tbaa !23
  %t26 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t21, i32 %t23)
  store i1 %t26, ptr %l16
  br label %bb7
bb7:
  %t27 = load i1, ptr %l16, !tbaa !21
  %t28 = xor i1 %t27, true
  br i1 %t28, label %bb8, label %bb9
bb8:
  store i1 false, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  br label %bb11
bb11:
  br label %bb2
bb12:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eviewGeneratorOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l17 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca { i64, ptr }
  %l26 = alloca i1
  %l29 = alloca { i64, ptr }
  %l31 = alloca i32
  %l37 = alloca i64
  %l43 = alloca { i64, ptr }
  %l45 = alloca i32
  %l51 = alloca i64
  %l54 = alloca i64
  %l73 = alloca { i64, ptr }
  %l78 = alloca ptr
  %l79 = alloca i32
  %l83 = alloca i32
  %l84 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call { i32, i32 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFindDecl(ptr %v0, ptr %s0, ptr %s0, ptr %t1, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d58, i32 0, i32 1) }, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d59, i32 0, i32 1) })
  %t4 = extractvalue { i32, i32 } %t3, 1
  %t5 = extractvalue { i32, i32 } %t3, 0
  store i32 %t5, ptr %l14
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store i32 %t4, ptr %l13
  br label %bb1
bb1:
  %t8 = load i32, ptr %l13, !tbaa !23
  store i32 %t8, ptr %l11, !tbaa !23
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  %t9 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t9, ptr %rv
  br label %ret
bb4:
  %t11 = load i32, ptr %l11, !tbaa !23
  store i32 %t11, ptr %l2, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/generic:Program", ptr %t12, i32 0, i32 2
  store ptr %t14, ptr %l17, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t17, i32 %a1)
  store i32 %t21, ptr %l21
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l17, !tbaa !29
  %t23 = load i32, ptr %l21, !tbaa !23
  %t24 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t22, i32 %t23)
  store { i64, ptr } %t24, ptr %l22
  br label %bb6
bb6:
  %t25 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t25, ptr %l3, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  %t30 = icmp eq i64 %t28, 0
  br i1 %t30, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb10
bb8:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  %t35 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t35, ptr %l29, !tbaa !27
  %t36 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr i32, ptr %t37, i64 0
  %t39 = load i32, ptr %t38, !tbaa !33
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t34, i32 %t39)
  store i32 %t42, ptr %l31
  br label %bb9
bb9:
  %t43 = load i32, ptr %l31, !range !{i32 0, i32 33}
  %t45 = trunc i64 20 to i32
  %t46 = icmp eq i32 %t43, %t45
  %t48 = xor i1 %t46, true
  store i1 %t48, ptr %l26, !tbaa !21
  br label %bb10
bb10:
  %t50 = load i1, ptr %l26, !tbaa !21
  br i1 %t50, label %bb11, label %bb12
bb11:
  %t51 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t51, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t53 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 0
  store i64 %t55, ptr %l37, !tbaa !24
  %t56 = load i64, ptr %l37, !tbaa !24
  %t57 = icmp sge i64 %t56, 0
  br i1 %t57, label %bb14, label %bb15
bb14:
  %t59 = load i64, ptr %l37, !tbaa !24
  %t60 = icmp sle i64 %t59, 2305843009213693951
  br i1 %t60, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_6b949e9fdbc9587c_5a8bb2436952ea48)
  unreachable
bb16:
  %t62 = load i64, ptr %l37, !tbaa !24
  %t63 = mul i64 %t62, 4
  %t64 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t63)
  %t65 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t64, 1
  store { i64, ptr } %t66, ptr %l4, !tbaa !27
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/generic:Program", ptr %t68, i32 0, i32 2
  %t71 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t71, ptr %l43, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr i32, ptr %t73, i64 0
  %t75 = load i32, ptr %t74, !tbaa !33
  %t78 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t70, i32 %t75)
  store i32 %t78, ptr %l45
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_6b949e9fdbc9587c_5a8bb2436952ea48)
  unreachable
bb18:
  %t79 = load i32, ptr %l45, !tbaa !23
  %t80 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr i32, ptr %t81, i64 0
  store i32 %t79, ptr %t82, !tbaa !33
  store i64 1, ptr %l5, !tbaa !24
  %t83 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t83, 0
  store i64 %t85, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t87 = load i64, ptr %l6, !tbaa !24
  %t88 = load i64, ptr %l5, !tbaa !24
  %t91 = icmp sgt i64 %t87, %t88
  br i1 %t91, label %bb19, label %bb20
bb19:
  %t93 = load i64, ptr %l7, !tbaa !24
  %t95 = icmp sgt i64 %t93, 0
  br i1 %t95, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb24
bb21:
  %t97 = load i64, ptr %l6, !tbaa !24
  %t98 = load i64, ptr %l5, !tbaa !24
  %t101 = sub i64 %t97, %t98
  %t102 = load i64, ptr %l7, !tbaa !24
  %t105 = add i64 %t101, %t102
  %t107 = sub i64 %t105, 1
  %t108 = load i64, ptr %l7, !tbaa !24
  %t111 = sdiv i64 %t107, %t108
  store i64 %t111, ptr %l54, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb23
bb23:
  %t113 = load i64, ptr %l54, !tbaa !24
  store i64 %t113, ptr %l51, !tbaa !24
  br label %bb24
bb24:
  %t114 = load i64, ptr %l51, !tbaa !24
  store i64 %t114, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb25
bb25:
  %t115 = load i64, ptr %l9, !tbaa !24
  %t116 = load i64, ptr %l8, !tbaa !24
  %t119 = icmp slt i64 %t115, %t116
  %t121 = xor i1 %t119, true
  br i1 %t121, label %bb26, label %bb27
bb26:
  br label %bb30
bb27:
  br label %bb28
bb28:
  %t123 = load i64, ptr %l5, !tbaa !24
  %t124 = load i64, ptr %l9, !tbaa !24
  %t125 = load i64, ptr %l7, !tbaa !24
  %t128 = mul i64 %t124, %t125
  %t131 = add i64 %t123, %t128
  store i64 %t131, ptr %l10, !tbaa !24
  %t133 = load i64, ptr %l10, !tbaa !24
  %t134 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t134, ptr %l73, !tbaa !27
  %t135 = load i64, ptr %l10, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr i32, ptr %t138, i64 %t135
  %t140 = load i32, ptr %t139, !tbaa !33
  %t143 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !27
  %t145 = getelementptr i32, ptr %t144, i64 %t133
  store i32 %t140, ptr %t145, !tbaa !33
  br label %bb29
bb29:
  %t146 = load i64, ptr %l9, !tbaa !24
  %t148 = add i64 %t146, 1
  store i64 %t148, ptr %l9, !tbaa !24
  br label %bb25
bb30:
  %t150 = load ptr, ptr %l0, !tbaa !29
  store ptr %t150, ptr %l78, !tbaa !29
  %t151 = load i32, ptr %l2, !tbaa !23
  store i32 %t151, ptr %l79, !tbaa !23
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/generic:Program", ptr %t152, i32 0, i32 2
  %t155 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t158 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t154, { i64, ptr } %t155)
  store i32 %t158, ptr %l83
  br label %bb31
bb31:
  %t159 = load ptr, ptr %l78, !tbaa !29
  %t160 = load i32, ptr %l79, !tbaa !23
  %t161 = load i32, ptr %l83, !tbaa !23
  %t162 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstance(ptr %v0, ptr %t159, i32 %t160, i32 %t161)
  store i32 %t162, ptr %l84
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s0)
  %t163 = load i32, ptr %l84, !tbaa !23
  store i32 %t163, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ewrap(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l9 = alloca i32
  %l13 = alloca i1
  %l19 = alloca i64
  %l23 = alloca i64
  %l32 = alloca i1
  %l34 = alloca i1
  %l37 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2enumberOf(ptr %v0, ptr %t1, i32 %a2)
  store i32 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i32, ptr %l9, !tbaa !23
  store i32 %t6, ptr %l3, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 2
  %t10 = load i32, ptr %l3, !tbaa !23
  %t13 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t9, i32 %t10)
  store i1 %t13, ptr %l13
  br label %bb2
bb2:
  %t14 = load i1, ptr %l13, !tbaa !21
  %t15 = xor i1 %t14, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load i64, ptr %l1, !tbaa !24
  store i64 %t17, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %l3, !tbaa !23
  %t25 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t21, i32 %t22)
  store i64 %t25, ptr %l19
  br label %bb6
bb6:
  %t26 = load i64, ptr %l19, !tbaa !24
  store i64 %t26, ptr %l4, !tbaa !24
  %t27 = load i64, ptr %l4, !tbaa !24
  %t29 = icmp sge i64 %t27, 64
  br i1 %t29, label %bb7, label %bb8
bb7:
  %t31 = load i64, ptr %l1, !tbaa !24
  store i64 %t31, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t33 = load i64, ptr %l4, !tbaa !24
  store i64 %t33, ptr %l23, !tbaa !24
  %t34 = load i64, ptr %l23, !tbaa !24
  %t35 = load i64, ptr %l23, !tbaa !24
  %t36 = shl i64 1, %t35
  %t38 = sub i64 %t36, 1
  store i64 %t38, ptr %l5, !tbaa !24
  %t40 = load i64, ptr %l1, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = and i64 %t40, %t41
  store i64 %t44, ptr %l6, !tbaa !24
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/generic:Program", ptr %t46, i32 0, i32 2
  %t49 = load i32, ptr %l3, !tbaa !23
  %t52 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t48, i32 %t49)
  store i1 %t52, ptr %l32
  br label %bb10
bb10:
  %t53 = load i1, ptr %l32, !tbaa !21
  %t54 = xor i1 %t53, true
  br i1 %t54, label %bb11, label %bb12
bb11:
  %t56 = load i64, ptr %l6, !tbaa !24
  %t57 = load i64, ptr %l4, !tbaa !24
  %t59 = sub i64 %t57, 1
  store i64 %t59, ptr %l37, !tbaa !24
  %t61 = load i64, ptr %l37, !tbaa !24
  %t62 = load i64, ptr %l37, !tbaa !24
  %t63 = ashr i64 %t56, %t62
  %t65 = and i64 %t63, 1
  %t67 = icmp eq i64 %t65, 1
  store i1 %t67, ptr %l34, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb13
bb13:
  %t69 = load i1, ptr %l34, !tbaa !21
  br i1 %t69, label %bb14, label %bb15
bb14:
  %t70 = load i64, ptr %l6, !tbaa !24
  %t71 = load i64, ptr %l5, !tbaa !24
  %t73 = xor i64 %t71, -1
  %t76 = or i64 %t70, %t73
  store i64 %t76, ptr %l6, !tbaa !24
  br label %bb16
bb15:
  br label %bb16
bb16:
  %t78 = load i64, ptr %l6, !tbaa !24
  store i64 %t78, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2edeclared(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l16 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l27 = alloca i32
  %l30 = alloca { i64, ptr }
  %l34 = alloca i64
  %l39 = alloca ptr
  %l40 = alloca i32
  %l43 = alloca { i64, ptr }
  %l46 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:VarDecl", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb17
bb3:
  br label %bb4
bb4:
  %t18 = load i64, ptr %l3, !tbaa !24
  store i64 %t18, ptr %l5, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t20, ptr %l16, !tbaa !27
  %t21 = load i64, ptr %l3, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr i32, ptr %t24, i64 %t21
  %t26 = load i32, ptr %t25, !tbaa !33
  store i32 %t26, ptr %l6, !tbaa !23
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr %"compiler/ast:VarDecl", ptr %t28, i32 0, i32 3
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr %"compiler/ast:VarDecl", ptr %t34, i32 0, i32 0
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  %t42 = icmp eq i64 %t33, %t39
  br i1 %t42, label %bb5, label %bb6
bb5:
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l26, !tbaa !29
  %t45 = load i32, ptr %l6, !tbaa !23
  store i32 %t45, ptr %l27, !tbaa !23
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr %"compiler/ast:VarDecl", ptr %t47, i32 0, i32 3
  %t50 = load { i64, ptr }, ptr %t49, !tbaa !27
  store { i64, ptr } %t50, ptr %l30, !tbaa !27
  %t51 = load i64, ptr %l5, !tbaa !24
  %t53 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr ptr, ptr %t54, i64 %t51
  %t56 = load ptr, ptr %t55, !tbaa !39
  %t60 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2eroot(ptr %v0, ptr %v1, ptr %t46, ptr %t56)
  store i64 %t60, ptr %l34
  br label %bb7
bb6:
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr %"compiler/ast:VarDecl", ptr %t61, i32 0, i32 3
  %t64 = load { i64, ptr }, ptr %t63, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t64, 0
  %t68 = icmp eq i64 %t66, 1
  br i1 %t68, label %bb9, label %bb10
bb7:
  %t70 = load ptr, ptr %l26, !tbaa !29
  %t71 = load i32, ptr %l27, !tbaa !23
  %t72 = load i64, ptr %l34, !tbaa !24
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2egrow(ptr %v0, ptr %t70, i32 %t71, i64 %t72)
  br label %bb8
bb8:
  br label %bb15
bb9:
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l39, !tbaa !29
  %t74 = load i32, ptr %l6, !tbaa !23
  store i32 %t74, ptr %l40, !tbaa !23
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr %"compiler/ast:VarDecl", ptr %t76, i32 0, i32 3
  %t79 = load { i64, ptr }, ptr %t78, !tbaa !27
  store { i64, ptr } %t79, ptr %l43, !tbaa !27
  %t80 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr ptr, ptr %t81, i64 0
  %t83 = load ptr, ptr %t82, !tbaa !39
  %t87 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2eroot(ptr %v0, ptr %v1, ptr %t75, ptr %t83)
  store i64 %t87, ptr %l46
  br label %bb11
bb10:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load i32, ptr %l6, !tbaa !23
  %t90 = load i64, ptr @G_2ecompiler_2fgeneric_2eGenLocalBit, !tbaa !24
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2egrow(ptr %v0, ptr %t88, i32 %t89, i64 %t90)
  br label %bb13
bb11:
  %t94 = load ptr, ptr %l39, !tbaa !29
  %t95 = load i32, ptr %l40, !tbaa !23
  %t96 = load i64, ptr %l46, !tbaa !24
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2egrow(ptr %v0, ptr %t94, i32 %t95, i64 %t96)
  br label %bb12
bb12:
  br label %bb14
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t97 = load i64, ptr %l3, !tbaa !24
  %t99 = add i64 %t97, 1
  store i64 %t99, ptr %l3, !tbaa !24
  br label %bb1
bb17:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2enameRoot(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l6 = alloca i64
  %l13 = alloca i1
  %l16 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i32
  %l27 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2eparamBit(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i64, ptr %l2, !tbaa !24
  store i64 %t11, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/generic:genRoots", ptr %t13, i32 0, i32 2
  %t16 = load i32, ptr %l1, !tbaa !23
  %t19 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hf575c52a5a9e8993bae2b73c9c2548b3(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l13
  br label %bb5
bb5:
  %t20 = load i1, ptr %l13, !tbaa !21
  %t21 = xor i1 %t20, true
  br i1 %t21, label %bb6, label %bb7
bb6:
  store i64 0, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/generic:genRoots", ptr %t24, i32 0, i32 2
  %t27 = load i32, ptr %l1, !tbaa !23
  %t30 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t26, i32 %t27)
  %t31 = extractvalue { i32, i64 } %t30, 1
  %t32 = extractvalue { i32, i64 } %t30, 0
  store i32 %t32, ptr %l21
  %t33 = icmp ne i32 %t32, 0
  br i1 %t33, label %bb10, label %ok.34, !prof !99
ok.34:
  store i64 %t31, ptr %l20
  br label %bb9
bb9:
  %t35 = load i64, ptr %l20, !tbaa !24
  store i64 %t35, ptr %l16, !tbaa !24
  br label %bb12
bb10:
  br label %bb11
bb11:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l16, !tbaa !24
  br label %bb12
bb12:
  %t36 = load i64, ptr %l16, !tbaa !24
  store i64 %t36, ptr %l3, !tbaa !24
  %t37 = load i64, ptr %l3, !tbaa !24
  %t38 = load i64, ptr @G_2ecompiler_2fgeneric_2eGenLocalBit, !tbaa !24
  %t40 = xor i64 %t38, -1
  %t43 = and i64 %t37, %t40
  %t45 = icmp ne i64 %t43, 0
  br i1 %t45, label %bb13, label %bb14
bb13:
  %t47 = load i64, ptr %l3, !tbaa !24
  store i64 %t47, ptr %l27, !tbaa !24
  br label %bb15
bb14:
  %t49 = load i64, ptr @G_2ecompiler_2fgeneric_2eGenLocalBit, !tbaa !24
  store i64 %t49, ptr %l27, !tbaa !24
  br label %bb15
bb15:
  %t51 = load i64, ptr %l27, !tbaa !24
  store i64 %t51, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i1
  %l49 = alloca { i64, ptr }
  %l52 = alloca i64
  %l56 = alloca i64
  %l68 = alloca { i64, ptr }
  %l71 = alloca ptr
  %l73 = alloca i32
  %l77 = alloca ptr
  %l78 = alloca i1
  %l85 = alloca ptr
  %l87 = alloca i32
  %l91 = alloca i64
  %l92 = alloca ptr
  %l93 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca i1
  %l106 = alloca ptr
  %l107 = alloca i64
  %l111 = alloca i64
  %l115 = alloca ptr
  %l116 = alloca i1
  %l125 = alloca i64
  %l141 = alloca { i64, ptr }
  %l149 = alloca ptr
  %l150 = alloca i1
  %l158 = alloca ptr
  %l159 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t6 = load ptr, ptr %l27, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l27, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 22}
  %t12 = icmp eq i64 %t10, 1
  store i1 %t12, ptr %l28, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l28, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", ptr }, ptr %t16, i32 0, i32 1
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2edeclared(ptr %v0, ptr %v1, ptr %t20, ptr %t21)
  br label %bb9
bb9:
  br label %bb91
bb10:
  %t24 = load ptr, ptr %l1, !tbaa !29
  store ptr %t24, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t25 = load ptr, ptr %l35, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb11, label %bb12
bb11:
  %t28 = load ptr, ptr %l35, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 22}
  %t31 = icmp eq i64 %t29, 2
  store i1 %t31, ptr %l36, !tbaa !21
  br label %bb12
bb12:
  %t32 = load i1, ptr %l36, !tbaa !21
  br i1 %t32, label %bb13, label %bb14
bb13:
  %t33 = load ptr, ptr %l1, !tbaa !29
  %t35 = getelementptr { i64, [4 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { %"compiler/source:Span", ptr }, ptr %t35, i32 0, i32 1
  %t37 = load ptr, ptr %t36
  store ptr %t37, ptr %l3, !tbaa !29
  br label %bb15
bb14:
  br label %bb31
bb15:
  store i64 0, ptr %l4, !tbaa !24
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = getelementptr %"compiler/ast:Multi", ptr %t39, i32 0, i32 2
  %t42 = load { i64, ptr }, ptr %t41, !tbaa !27
  store { i64, ptr } %t42, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  store i64 %t46, ptr %l7, !tbaa !24
  br label %bb16
bb16:
  %t48 = load i64, ptr %l6, !tbaa !24
  %t49 = load i64, ptr %l7, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb17, label %bb18
bb17:
  br label %bb22
bb18:
  br label %bb19
bb19:
  %t56 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t56, ptr %l49, !tbaa !27
  %t57 = load i64, ptr %l6, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr ptr, ptr %t60, i64 %t57
  %t62 = load ptr, ptr %t61, !tbaa !39
  %t64 = load i64, ptr %l4, !tbaa !24
  store i64 %t64, ptr %l52, !tbaa !24
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t70 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2eroot(ptr %v0, ptr %v1, ptr %t65, ptr %t62)
  store i64 %t70, ptr %l56
  br label %bb20
bb20:
  %t71 = load i64, ptr %l52, !tbaa !24
  %t72 = load i64, ptr %l56, !tbaa !24
  %t73 = or i64 %t71, %t72
  store i64 %t73, ptr %l4, !tbaa !24
  br label %bb21
bb21:
  %t75 = load i64, ptr %l6, !tbaa !24
  %t77 = add i64 %t75, 1
  store i64 %t77, ptr %l6, !tbaa !24
  br label %bb16
bb22:
  %t79 = load ptr, ptr %l3, !tbaa !29
  %t81 = getelementptr %"compiler/ast:Multi", ptr %t79, i32 0, i32 0
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  store { i64, ptr } %t82, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t84 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t84, 0
  store i64 %t86, ptr %l11, !tbaa !24
  br label %bb23
bb23:
  %t88 = load i64, ptr %l10, !tbaa !24
  %t89 = load i64, ptr %l11, !tbaa !24
  %t92 = icmp slt i64 %t88, %t89
  %t94 = xor i1 %t92, true
  br i1 %t94, label %bb24, label %bb25
bb24:
  br label %bb30
bb25:
  br label %bb26
bb26:
  %t96 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t96, ptr %l68, !tbaa !27
  %t97 = load i64, ptr %l10, !tbaa !24
  %t99 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr ptr, ptr %t100, i64 %t97
  %t102 = load ptr, ptr %t101, !tbaa !39
  %t104 = load ptr, ptr %l0, !tbaa !29
  store ptr %t104, ptr %l71, !tbaa !29
  %t107 = call i32 @compiler_2fgeneric_2ebaseName(ptr %v1, ptr %t102)
  store i32 %t107, ptr %l73
  br label %bb27
bb27:
  %t108 = load i64, ptr %l4, !tbaa !24
  %t109 = load ptr, ptr %l71, !tbaa !29
  %t110 = load i32, ptr %l73, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2egrow(ptr %v0, ptr %t109, i32 %t110, i64 %t108)
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t112 = load i64, ptr %l10, !tbaa !24
  %t114 = add i64 %t112, 1
  store i64 %t114, ptr %l10, !tbaa !24
  br label %bb23
bb30:
  br label %bb91
bb31:
  %t116 = load ptr, ptr %l1, !tbaa !29
  store ptr %t116, ptr %l77, !tbaa !29
  store i1 false, ptr %l78, !tbaa !21
  %t117 = load ptr, ptr %l77, !tbaa !29
  %t118 = icmp ne ptr %t117, null
  br i1 %t118, label %bb32, label %bb33
bb32:
  %t120 = load ptr, ptr %l77, !tbaa !29
  %t121 = load i64, ptr %t120, !range !{i64 0, i64 22}
  %t123 = icmp eq i64 %t121, 3
  store i1 %t123, ptr %l78, !tbaa !21
  br label %bb33
bb33:
  %t124 = load i1, ptr %l78, !tbaa !21
  br i1 %t124, label %bb34, label %bb35
bb34:
  %t125 = load ptr, ptr %l1, !tbaa !29
  %t127 = getelementptr { i64, [4 x i64] }, ptr %t125, i32 0, i32 1
  %t128 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t127, i32 0, i32 2
  %t129 = load ptr, ptr %t128
  store ptr %t129, ptr %l13, !tbaa !29
  %t131 = load ptr, ptr %l1, !tbaa !29
  %t133 = getelementptr { i64, [4 x i64] }, ptr %t131, i32 0, i32 1
  %t134 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t133, i32 0, i32 3
  %t135 = load ptr, ptr %t134
  store ptr %t135, ptr %l14, !tbaa !29
  br label %bb36
bb35:
  br label %bb40
bb36:
  %t137 = load ptr, ptr %l0, !tbaa !29
  store ptr %t137, ptr %l85, !tbaa !29
  %t138 = load ptr, ptr %l13, !tbaa !29
  %t140 = call i32 @compiler_2fgeneric_2ebaseName(ptr %v1, ptr %t138)
  store i32 %t140, ptr %l87
  br label %bb37
bb37:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load ptr, ptr %l14, !tbaa !29
  %t146 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2eroot(ptr %v0, ptr %v1, ptr %t141, ptr %t142)
  store i64 %t146, ptr %l91
  br label %bb38
bb38:
  %t147 = load ptr, ptr %l85, !tbaa !29
  %t148 = load i32, ptr %l87, !tbaa !23
  %t149 = load i64, ptr %l91, !tbaa !24
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2egrow(ptr %v0, ptr %t147, i32 %t148, i64 %t149)
  br label %bb39
bb39:
  br label %bb91
bb40:
  %t150 = load ptr, ptr %l1, !tbaa !29
  store ptr %t150, ptr %l92, !tbaa !29
  store i1 false, ptr %l93, !tbaa !21
  %t151 = load ptr, ptr %l92, !tbaa !29
  %t152 = icmp ne ptr %t151, null
  br i1 %t152, label %bb41, label %bb42
bb41:
  %t154 = load ptr, ptr %l92, !tbaa !29
  %t155 = load i64, ptr %t154, !range !{i64 0, i64 22}
  %t157 = icmp eq i64 %t155, 0
  store i1 %t157, ptr %l93, !tbaa !21
  br label %bb42
bb42:
  %t158 = load i1, ptr %l93, !tbaa !21
  br i1 %t158, label %bb43, label %bb44
bb43:
  %t159 = load ptr, ptr %l1, !tbaa !29
  %t161 = getelementptr { i64, [4 x i64] }, ptr %t159, i32 0, i32 1
  %t162 = getelementptr { %"compiler/source:Span", ptr }, ptr %t161, i32 0, i32 1
  %t163 = load ptr, ptr %t162
  store ptr %t163, ptr %l15, !tbaa !29
  br label %bb45
bb44:
  br label %bb47
bb45:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t166 = load ptr, ptr %l15, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estored(ptr %v0, ptr %v1, ptr %t165, ptr %t166)
  br label %bb46
bb46:
  br label %bb91
bb47:
  %t169 = load ptr, ptr %l1, !tbaa !29
  store ptr %t169, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t170 = load ptr, ptr %l100, !tbaa !29
  %t171 = icmp ne ptr %t170, null
  br i1 %t171, label %bb48, label %bb49
bb48:
  %t173 = load ptr, ptr %l100, !tbaa !29
  %t174 = load i64, ptr %t173, !range !{i64 0, i64 22}
  %t176 = icmp eq i64 %t174, 21
  store i1 %t176, ptr %l101, !tbaa !21
  br label %bb49
bb49:
  %t177 = load i1, ptr %l101, !tbaa !21
  br i1 %t177, label %bb50, label %bb51
bb50:
  %t178 = load ptr, ptr %l1, !tbaa !29
  %t180 = getelementptr { i64, [4 x i64] }, ptr %t178, i32 0, i32 1
  %t181 = getelementptr { %"compiler/source:Span", ptr }, ptr %t180, i32 0, i32 1
  %t182 = load ptr, ptr %t181
  store ptr %t182, ptr %l16, !tbaa !29
  br label %bb52
bb51:
  br label %bb55
bb52:
  %t184 = load ptr, ptr %l0, !tbaa !29
  store ptr %t184, ptr %l106, !tbaa !29
  %t185 = load ptr, ptr %l106, !tbaa !29
  %t186 = getelementptr %"compiler/generic:genRoots", ptr %t185, i32 0, i32 3
  %t187 = load i64, ptr %t186, !tbaa !24
  store i64 %t187, ptr %l107, !tbaa !24
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load ptr, ptr %l16, !tbaa !29
  %t193 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2eroot(ptr %v0, ptr %v1, ptr %t188, ptr %t189)
  store i64 %t193, ptr %l111
  br label %bb53
bb53:
  %t194 = load i64, ptr %l107, !tbaa !24
  %t195 = load i64, ptr %l111, !tbaa !24
  %t196 = or i64 %t194, %t195
  %t198 = load ptr, ptr %l106, !tbaa !29
  %t199 = getelementptr %"compiler/generic:genRoots", ptr %t198, i32 0, i32 3
  store i64 %t196, ptr %t199, !tbaa !24
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t201 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estored(ptr %v0, ptr %v1, ptr %t200, ptr %t201)
  br label %bb54
bb54:
  br label %bb91
bb55:
  %t204 = load ptr, ptr %l1, !tbaa !29
  store ptr %t204, ptr %l115, !tbaa !29
  store i1 false, ptr %l116, !tbaa !21
  %t205 = load ptr, ptr %l115, !tbaa !29
  %t206 = icmp ne ptr %t205, null
  br i1 %t206, label %bb56, label %bb57
bb56:
  %t208 = load ptr, ptr %l115, !tbaa !29
  %t209 = load i64, ptr %t208, !range !{i64 0, i64 22}
  %t211 = icmp eq i64 %t209, 9
  store i1 %t211, ptr %l116, !tbaa !21
  br label %bb57
bb57:
  %t212 = load i1, ptr %l116, !tbaa !21
  br i1 %t212, label %bb58, label %bb59
bb58:
  %t213 = load ptr, ptr %l1, !tbaa !29
  %t215 = getelementptr { i64, [4 x i64] }, ptr %t213, i32 0, i32 1
  %t216 = getelementptr { %"compiler/source:Span", ptr }, ptr %t215, i32 0, i32 1
  %t217 = load ptr, ptr %t216
  store ptr %t217, ptr %l17, !tbaa !29
  br label %bb60
bb59:
  br label %bb71
bb60:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load ptr, ptr %l17, !tbaa !29
  %t222 = getelementptr %"compiler/ast:ForIn", ptr %t220, i32 0, i32 2
  %t223 = load ptr, ptr %t222, !tbaa !29
  %t227 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2eroot(ptr %v0, ptr %v1, ptr %t219, ptr %t223)
  store i64 %t227, ptr %l125
  br label %bb61
bb61:
  %t228 = load i64, ptr %l125, !tbaa !24
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t230 = load ptr, ptr %l17, !tbaa !29
  %t232 = getelementptr %"compiler/ast:ForIn", ptr %t230, i32 0, i32 1
  %t233 = load i32, ptr %t232, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2egrow(ptr %v0, ptr %t229, i32 %t233, i64 %t228)
  br label %bb62
bb62:
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t239 = load ptr, ptr %l17, !tbaa !29
  %t241 = getelementptr %"compiler/ast:ForIn", ptr %t239, i32 0, i32 4
  %t242 = load { i64, ptr }, ptr %t241, !tbaa !27
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estmts(ptr %v0, ptr %v1, ptr %t238, { i64, ptr } %t242)
  br label %bb63
bb63:
  %t245 = load ptr, ptr %l17, !tbaa !29
  %t247 = getelementptr %"compiler/ast:ForIn", ptr %t245, i32 0, i32 5
  %t248 = load { i64, ptr }, ptr %t247, !tbaa !27
  store { i64, ptr } %t248, ptr %l19, !tbaa !27
  store i64 0, ptr %l20, !tbaa !24
  %t250 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t252 = extractvalue { i64, ptr } %t250, 0
  store i64 %t252, ptr %l21, !tbaa !24
  br label %bb64
bb64:
  %t254 = load i64, ptr %l20, !tbaa !24
  %t255 = load i64, ptr %l21, !tbaa !24
  %t258 = icmp slt i64 %t254, %t255
  %t260 = xor i1 %t258, true
  br i1 %t260, label %bb65, label %bb66
bb65:
  br label %bb70
bb66:
  br label %bb67
bb67:
  %t262 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t262, ptr %l141, !tbaa !27
  %t263 = load i64, ptr %l20, !tbaa !24
  %t265 = getelementptr { i64, ptr }, ptr %l141, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !27
  %t267 = getelementptr ptr, ptr %t266, i64 %t263
  %t268 = load ptr, ptr %t267, !tbaa !39
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t273 = getelementptr %"compiler/ast:Catch", ptr %t268, i32 0, i32 2
  %t274 = load { i64, ptr }, ptr %t273, !tbaa !27
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estmts(ptr %v0, ptr %v1, ptr %t270, { i64, ptr } %t274)
  br label %bb68
bb68:
  br label %bb69
bb69:
  %t277 = load i64, ptr %l20, !tbaa !24
  %t279 = add i64 %t277, 1
  store i64 %t279, ptr %l20, !tbaa !24
  br label %bb64
bb70:
  br label %bb91
bb71:
  %t281 = load ptr, ptr %l1, !tbaa !29
  store ptr %t281, ptr %l149, !tbaa !29
  store i1 false, ptr %l150, !tbaa !21
  %t282 = load ptr, ptr %l149, !tbaa !29
  %t283 = icmp ne ptr %t282, null
  br i1 %t283, label %bb72, label %bb73
bb72:
  %t285 = load ptr, ptr %l149, !tbaa !29
  %t286 = load i64, ptr %t285, !range !{i64 0, i64 22}
  %t288 = icmp eq i64 %t286, 5
  store i1 %t288, ptr %l150, !tbaa !21
  br label %bb73
bb73:
  %t289 = load i1, ptr %l150, !tbaa !21
  br i1 %t289, label %bb74, label %bb75
bb74:
  %t290 = load ptr, ptr %l1, !tbaa !29
  %t292 = getelementptr { i64, [4 x i64] }, ptr %t290, i32 0, i32 1
  %t293 = getelementptr { %"compiler/source:Span", ptr }, ptr %t292, i32 0, i32 1
  %t294 = load ptr, ptr %t293
  store ptr %t294, ptr %l23, !tbaa !29
  br label %bb76
bb75:
  br label %bb78
bb76:
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t297 = load ptr, ptr %l23, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2ebranches(ptr %v0, ptr %v1, ptr %t296, ptr %t297)
  br label %bb77
bb77:
  br label %bb91
bb78:
  %t301 = load ptr, ptr %l1, !tbaa !29
  store ptr %t301, ptr %l158, !tbaa !29
  store i1 false, ptr %l159, !tbaa !21
  %t302 = load ptr, ptr %l158, !tbaa !29
  %t303 = icmp ne ptr %t302, null
  br i1 %t303, label %bb79, label %bb80
bb79:
  %t305 = load ptr, ptr %l158, !tbaa !29
  %t306 = load i64, ptr %t305, !range !{i64 0, i64 22}
  %t308 = icmp eq i64 %t306, 11
  store i1 %t308, ptr %l159, !tbaa !21
  br label %bb80
bb80:
  %t309 = load i1, ptr %l159, !tbaa !21
  br i1 %t309, label %bb81, label %bb82
bb81:
  %t310 = load ptr, ptr %l1, !tbaa !29
  %t312 = getelementptr { i64, [4 x i64] }, ptr %t310, i32 0, i32 1
  %t313 = getelementptr { %"compiler/source:Span", ptr }, ptr %t312, i32 0, i32 1
  %t314 = load ptr, ptr %t313
  store ptr %t314, ptr %l24, !tbaa !29
  br label %bb83
bb82:
  br label %bb85
bb83:
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t317 = load ptr, ptr %l24, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2ematched(ptr %v0, ptr %v1, ptr %t316, ptr %t317)
  br label %bb84
bb84:
  br label %bb91
bb85:
  br i1 true, label %bb86, label %bb87
bb86:
  br label %bb88
bb87:
  br label %bb90
bb88:
  %t320 = load ptr, ptr %l0, !tbaa !29
  %t321 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2einner(ptr %v0, ptr %v1, ptr %t320, ptr %t321)
  br label %bb89
bb89:
  br label %bb91
bb90:
  call void @__olang_check_failed(ptr @olang_loc_df5307d3a8bec99f_effac078aaeab34b)
  unreachable
bb91:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estmts(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l13 = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb7
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %t21)
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t28 = load i64, ptr %l3, !tbaa !24
  %t30 = add i64 %t28, 1
  store i64 %t30, ptr %l3, !tbaa !24
  br label %bb1
bb7:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fgeneric_2eerrorDeclInIf(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l16 = alloca ptr
  %l32 = alloca ptr
  %l50 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/ast:TopIf", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  %t8 = xor i1 %t6, true
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/ast:TopIf", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = icmp eq ptr %t13, null
  br i1 %t15, label %bb3, label %bb4
bb2:
  br label %bb10
bb3:
  call void @__olang_check_failed(ptr @olang_loc_fe684dd4125d4b4d_99bf6f4db7396e79)
  unreachable
bb4:
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/ast:TopIf", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t23 = getelementptr %"compiler/ast:TopBranch", ptr %t20, i32 0, i32 1
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t25 = load i32, ptr %l1, !tbaa !23
  %t28 = call ptr @compiler_2fgeneric_2eerrorDeclIn(ptr %v0, ptr %v1, { i64, ptr } %t24, i32 %t25)
  store ptr %t28, ptr %l16
  br label %bb6
bb6:
  %t29 = load ptr, ptr %l16, !tbaa !29
  store ptr %t29, ptr %l2, !tbaa !29
  %t30 = load ptr, ptr %l2, !tbaa !29
  %t32 = icmp eq ptr %t30, null
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb7, label %bb8
bb7:
  %t36 = load ptr, ptr %l2, !tbaa !29
  store ptr %t36, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/ast:TopIf", ptr %t39, i32 0, i32 2
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = icmp eq ptr %t42, null
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb11, label %bb12
bb11:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/ast:TopIf", ptr %t48, i32 0, i32 2
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = icmp eq ptr %t51, null
  br i1 %t53, label %bb13, label %bb14
bb12:
  br label %bb20
bb13:
  call void @__olang_check_failed(ptr @olang_loc_42759df622c97166_e1be9b347935e452)
  unreachable
bb14:
  br label %bb15
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/ast:TopIf", ptr %t55, i32 0, i32 2
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t59 = load i32, ptr %l1, !tbaa !23
  %t62 = call ptr @compiler_2fgeneric_2eerrorDeclInIf(ptr %v0, ptr %v1, ptr %t58, i32 %t59)
  store ptr %t62, ptr %l32
  br label %bb16
bb16:
  %t63 = load ptr, ptr %l32, !tbaa !29
  store ptr %t63, ptr %l3, !tbaa !29
  %t64 = load ptr, ptr %l3, !tbaa !29
  %t66 = icmp eq ptr %t64, null
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb17, label %bb18
bb17:
  %t70 = load ptr, ptr %l3, !tbaa !29
  store ptr %t70, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/ast:TopIf", ptr %t73, i32 0, i32 3
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = icmp eq ptr %t76, null
  %t80 = xor i1 %t78, true
  br i1 %t80, label %bb21, label %bb22
bb21:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/ast:TopIf", ptr %t82, i32 0, i32 3
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = icmp eq ptr %t85, null
  br i1 %t87, label %bb23, label %bb24
bb22:
  br label %bb27
bb23:
  call void @__olang_check_failed(ptr @olang_loc_cc60064df4ba0b57_d35c100e8c6c7d93)
  unreachable
bb24:
  br label %bb25
bb25:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/ast:TopIf", ptr %t89, i32 0, i32 3
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t95 = getelementptr %"compiler/ast:TopBranch", ptr %t92, i32 0, i32 1
  %t96 = load { i64, ptr }, ptr %t95, !tbaa !27
  %t97 = load i32, ptr %l1, !tbaa !23
  %t100 = call ptr @compiler_2fgeneric_2eerrorDeclIn(ptr %v0, ptr %v1, { i64, ptr } %t96, i32 %t97)
  store ptr %t100, ptr %l50
  br label %bb26
bb26:
  %t101 = load ptr, ptr %l50, !tbaa !29
  store ptr %t101, ptr %rv
  br label %ret
bb27:
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fgeneric_2egenElemOf(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca %"compiler/generic:genRoots"
  %l8 = alloca i64
  %l10 = alloca i1
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca ptr
  %l27 = alloca ptr
  %l33 = alloca i1
  %l43 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l51 = alloca i1
  %l55 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l58 = alloca %"compiler/generic:genRoots"
  %l73 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i1 @compiler_2fgeneric_2eborrowableElem(ptr %v0, ptr %t1)
  store i1 %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load i1, ptr %l10, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t7 = load i64, ptr @G_2ecompiler_2fgeneric_2eGenPerTurn, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t7, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l13
  br label %bb5
bb5:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l1
  %t11 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %l14
  br label %bb6
bb6:
  %t12 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t12, ptr %l2
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/ast:Func", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = icmp eq ptr %t16, null
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb7, label %bb8
bb7:
  store ptr %l1, ptr %l19, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/ast:Func", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = icmp eq ptr %t25, null
  br i1 %t27, label %bb9, label %bb10
bb8:
  br label %bb18
bb9:
  call void @__olang_check_failed(ptr @olang_loc_2a0d238d6764ffeb_7f54c8a7a483f2b7)
  unreachable
bb10:
  br label %bb11
bb11:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/ast:Func", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t35 = getelementptr %"compiler/ast:Param", ptr %t32, i32 0, i32 1
  %t36 = load i32, ptr %t35, !tbaa !23
  %t37 = load ptr, ptr %l19, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %t37, i32 %t36)
  br label %bb12
bb12:
  store ptr %l2, ptr %l27, !tbaa !29
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/ast:Func", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = icmp eq ptr %t42, null
  br i1 %t44, label %bb13, label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_b16df8c761b5d07c_6405a14de8d58098)
  unreachable
bb14:
  br label %bb15
bb15:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/ast:Func", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = call i1 @compiler_2fgeneric_2ebyValueParam(ptr %v0, ptr %t49)
  store i1 %t51, ptr %l33
  br label %bb16
bb16:
  %t52 = load ptr, ptr %l27, !tbaa !29
  %t53 = load i1, ptr %l33, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %s0, ptr %t52, i1 %t53)
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/ast:Func", ptr %t54, i32 0, i32 3
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = getelementptr %"compiler/ast:Sig", ptr %t57, i32 0, i32 0
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !27
  store { i64, ptr } %t60, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t62 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t62, 0
  store i64 %t64, ptr %l5, !tbaa !24
  br label %bb19
bb19:
  %t66 = load i64, ptr %l4, !tbaa !24
  %t67 = load i64, ptr %l5, !tbaa !24
  %t70 = icmp slt i64 %t66, %t67
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb20, label %bb21
bb20:
  br label %bb27
bb21:
  br label %bb22
bb22:
  %t74 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t74, ptr %l43, !tbaa !27
  %t75 = load i64, ptr %l4, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr ptr, ptr %t78, i64 %t75
  %t80 = load ptr, ptr %t79, !tbaa !39
  store ptr %t80, ptr %l6, !tbaa !29
  %t82 = load ptr, ptr %l6, !tbaa !29
  %t84 = getelementptr %"compiler/ast:Param", ptr %t82, i32 0, i32 1
  %t85 = load i32, ptr %t84, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l1, i32 %t85)
  br label %bb23
bb23:
  store ptr %l2, ptr %l49, !tbaa !29
  %t88 = load ptr, ptr %l6, !tbaa !29
  %t90 = call i1 @compiler_2fgeneric_2ebyValueParam(ptr %v0, ptr %t88)
  store i1 %t90, ptr %l51
  br label %bb24
bb24:
  %t91 = load ptr, ptr %l49, !tbaa !29
  %t92 = load i1, ptr %l51, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %s0, ptr %t91, i1 %t92)
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t93 = load i64, ptr %l4, !tbaa !24
  %t95 = add i64 %t93, 1
  store i64 %t95, ptr %l4, !tbaa !24
  br label %bb19
bb27:
  %t98 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eToArra_H4d02a0b2e27e8f31ffc99daa43750593(ptr %s0, ptr %s0, ptr %l1)
  store { i64, ptr } %t98, ptr %l55
  br label %bb28
bb28:
  %t100 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eToArray_3cBool_3e(ptr %s0, ptr %s0, ptr %l2)
  store { i64, ptr } %t100, ptr %l57
  br label %bb29
bb29:
  %t101 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t103 = call %"compiler/generic:genRoots" @compiler_2fgeneric_3agenRoots_2ector(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t101, { i64, ptr } %t102)
  store %"compiler/generic:genRoots" %t103, ptr %l58
  br label %bb30
bb30:
  %t104 = load %"compiler/generic:genRoots", ptr %l58
  store %"compiler/generic:genRoots" %t104, ptr %l7
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/ast:Func", ptr %t105, i32 0, i32 4
  %t108 = load { i64, ptr }, ptr %t107, !tbaa !27
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estmts(ptr %s0, ptr %v0, ptr %l7, { i64, ptr } %t108)
  br label %bb31
bb31:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/ast:Func", ptr %t111, i32 0, i32 4
  %t114 = load { i64, ptr }, ptr %t113, !tbaa !27
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estmts(ptr %s0, ptr %v0, ptr %l7, { i64, ptr } %t114)
  br label %bb32
bb32:
  %t117 = getelementptr %"compiler/generic:genRoots", ptr %l7, i32 0, i32 3
  %t118 = load i64, ptr %t117, !tbaa !24
  store i64 %t118, ptr %l8, !tbaa !24
  %t120 = load i64, ptr %l8, !tbaa !24
  %t122 = icmp eq i64 %t120, 0
  br i1 %t122, label %bb33, label %bb34
bb33:
  %t124 = load i64, ptr @G_2ecompiler_2fgeneric_2eGenPerTurn, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t124, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t126 = load i64, ptr %l8, !tbaa !24
  %t127 = load i64, ptr @G_2ecompiler_2fgeneric_2eGenLocalBit, !tbaa !24
  %t130 = and i64 %t126, %t127
  %t132 = icmp ne i64 %t130, 0
  br i1 %t132, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l73, !tbaa !21
  br label %bb38
bb37:
  %t134 = load i64, ptr %l8, !tbaa !24
  %t136 = call i64 @llvm.ctpop.i64(i64 %t134)
  %t138 = icmp ne i64 %t136, 1
  store i1 %t138, ptr %l73, !tbaa !21
  br label %bb38
bb38:
  %t140 = load i1, ptr %l73, !tbaa !21
  br i1 %t140, label %bb39, label %bb40
bb39:
  %t141 = load i64, ptr @G_2ecompiler_2fgeneric_2eGenFromReturn, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t141, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  %t143 = load i64, ptr %l8, !tbaa !24
  %t145 = call i64 @llvm.cttz.i64(i64 %t143, i1 false)
  call void @__olang_scope_close(ptr %s0)
  store i64 %t145, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fgeneric_2eisErrsArg(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca i1
  %l2 = alloca ptr
  %l3 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_90309fa9b0fb789a_4b8ce68c657018ae)
  unreachable
bb11:
  %t10 = load i1, ptr %l1, !tbaa !21
  store i1 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fgeneric_2elisted(ptr %v0, ptr %v1, { i64, ptr } %a0, i32 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l17 = alloca { i64, ptr }
  %rv = alloca ptr
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store ptr null, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb12
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l5, !tbaa !29
  %t30 = load ptr, ptr %l5, !tbaa !29
  %t32 = getelementptr %"compiler/ast:TypeParam", ptr %t30, i32 0, i32 1
  %t33 = load i32, ptr %t32, !tbaa !23
  %t37 = icmp eq i32 %t33, %a1
  br i1 %t37, label %bb8, label %bb9
bb8:
  %t39 = load ptr, ptr %l5, !tbaa !29
  %t41 = getelementptr %"compiler/ast:TypeParam", ptr %t39, i32 0, i32 2
  %t42 = load ptr, ptr %t41, !tbaa !29
  store ptr %t42, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t44 = load i64, ptr %l3, !tbaa !24
  %t46 = add i64 %t44, 1
  store i64 %t46, ptr %l3, !tbaa !24
  br label %bb4
bb12:
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/generic:folded" @compiler_2fgeneric_2eunfolded() #0 {
entry:
  %l2 = alloca %"compiler/generic:folded"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/generic:folded"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr @G_2ecompiler_2fgeneric_2eUnfolded, !tbaa !24
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = call %"compiler/generic:folded" @compiler_2fgeneric_3afolded_2ector(ptr %s0, i64 %t1, i64 0, i32 %t2)
  store %"compiler/generic:folded" %t5, ptr %l2
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t6 = load %"compiler/generic:folded", ptr %l2
  store %"compiler/generic:folded" %t6, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/generic:folded", ptr %rv
  ret %"compiler/generic:folded" %rr
}

define dso_local i1 @compiler_2fgeneric_2eviewGenTy(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i1
  %l23 = alloca i1
  %l27 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call i1 @compiler_2fgeneric_2eviewGenTy(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i1 %t20, ptr %l13
  br label %bb6
bb6:
  %t21 = load i1, ptr %l13, !tbaa !21
  store i1 %t21, ptr %l4, !tbaa !21
  br label %bb23
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t23 = load ptr, ptr %l14, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l14, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 8}
  %t29 = icmp eq i64 %t27, 0
  store i1 %t29, ptr %l15, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l15, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [5 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t33, i32 0, i32 1
  %t35 = load { i64, ptr }, ptr %t34
  store { i64, ptr } %t35, ptr %l3, !tbaa !27
  br label %bb12
bb11:
  br label %bb18
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  %t41 = icmp eq i64 %t39, 1
  br i1 %t41, label %bb13, label %bb14
bb13:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/generic:Program", ptr %t43, i32 0, i32 0
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/load:Loader", ptr %t46, i32 0, i32 3
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t50 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t50, ptr %l27, !tbaa !27
  %t51 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr i32, ptr %t52, i64 0
  %t54 = load i32, ptr %t53, !tbaa !33
  %t57 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t49, i32 %t54)
  store { i64, ptr } %t57, ptr %l29
  br label %bb15
bb14:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb17
bb15:
  %t58 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t59 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t58, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d60, i32 0, i32 1) })
  store i1 %t59, ptr %l30
  br label %bb16
bb16:
  %t60 = load i1, ptr %l30, !tbaa !21
  store i1 %t60, ptr %l23, !tbaa !21
  br label %bb17
bb17:
  %t61 = load i1, ptr %l23, !tbaa !21
  store i1 %t61, ptr %l4, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_9e21964695e7b518_e551ec91ddd7cf74)
  unreachable
bb23:
  %t62 = load i1, ptr %l4, !tbaa !21
  store i1 %t62, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fgeneric_3aContext_2ector(ptr %out, ptr %v0, i64 %a0, i64 %a1) #0 {
entry:
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l8 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l9 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l10 = alloca %"compiler/generic:Context"
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a0, ptr %l2, !tbaa !24
  store i64 %a1, ptr %l3, !tbaa !24
  %t5 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l8
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t6, ptr %l4
  %t7 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t7, ptr %l9
  br label %bb2
bb2:
  %t8 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l9
  %t9 = getelementptr %"compiler/generic:Context", ptr %l10, i32 0, i32 0
  %t10 = load i64, ptr %l2, !tbaa !24
  store i64 %t10, ptr %t9, !tbaa !24
  %t11 = getelementptr %"compiler/generic:Context", ptr %l10, i32 0, i32 1
  %t12 = load i64, ptr %l3, !tbaa !24
  store i64 %t12, ptr %t11, !tbaa !24
  %t13 = getelementptr %"compiler/generic:Context", ptr %l10, i32 0, i32 2
  %t14 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l4
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t14, ptr %t13
  %t15 = getelementptr %"compiler/generic:Context", ptr %l10, i32 0, i32 3
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t8, ptr %t15
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l10, i64 160, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/generic:Origin" @compiler_2fgeneric_3aOrigin_2ector(ptr %v0, i64 %a0, %"compiler/source:Span" %a1, i64 %a2) #0 {
entry:
  %rv = alloca %"compiler/generic:Origin"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/generic:Origin" undef, i64 %a0, 0
  %t10 = insertvalue %"compiler/generic:Origin" %t8, %"compiler/source:Span" %a1, 1
  %t12 = insertvalue %"compiler/generic:Origin" %t10, i64 %a2, 2
  store %"compiler/generic:Origin" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/generic:Origin", ptr %rv
  ret %"compiler/generic:Origin" %rr
}

define dso_local %"compiler/generic:Unmet" @compiler_2fgeneric_3aUnmet_2ector(ptr %v0, i64 %a0, i32 %a1, i32 %a2, i1 %a3, i1 %a4, i1 %a5) #0 {
entry:
  %rv = alloca %"compiler/generic:Unmet"
  br label %start
start:
  br label %bb0
bb0:
  %t14 = insertvalue %"compiler/generic:Unmet" undef, i64 %a0, 0
  %t16 = insertvalue %"compiler/generic:Unmet" %t14, i32 %a1, 1
  %t18 = insertvalue %"compiler/generic:Unmet" %t16, i32 %a2, 2
  %t20 = insertvalue %"compiler/generic:Unmet" %t18, i1 %a3, 3
  %t22 = insertvalue %"compiler/generic:Unmet" %t20, i1 %a4, 4
  %t24 = insertvalue %"compiler/generic:Unmet" %t22, i1 %a5, 5
  store %"compiler/generic:Unmet" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/generic:Unmet", ptr %rv
  ret %"compiler/generic:Unmet" %rr
}

define dso_local %"compiler/generic:folded" @compiler_2fgeneric_3afolded_2ector(ptr %v0, i64 %a0, i64 %a1, i32 %a2) #0 {
entry:
  %rv = alloca %"compiler/generic:folded"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/generic:folded" undef, i64 %a0, 0
  %t10 = insertvalue %"compiler/generic:folded" %t8, i64 %a1, 1
  %t12 = insertvalue %"compiler/generic:folded" %t10, i32 %a2, 2
  store %"compiler/generic:folded" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/generic:folded", ptr %rv
  ret %"compiler/generic:folded" %rr
}

define dso_local %"compiler/generic:genRoots" @compiler_2fgeneric_3agenRoots_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l8 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"compiler/generic:genRoots"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store { i64, ptr } %a1, ptr %l3, !tbaa !27
  %t5 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e(ptr %v2)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l8
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = insertvalue %"compiler/generic:genRoots" undef, { i64, ptr } %t7, 0
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t10 = insertvalue %"compiler/generic:genRoots" %t8, { i64, ptr } %t9, 1
  %t12 = insertvalue %"compiler/generic:genRoots" %t10, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t6, 2
  %t14 = insertvalue %"compiler/generic:genRoots" %t12, i64 0, 3
  store %"compiler/generic:genRoots" %t14, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/generic:genRoots", ptr %rv
  ret %"compiler/generic:genRoots" %rr
}

define dso_local %"compiler/generic:instance" @compiler_2fgeneric_3ainstance_2ector(ptr %v0, ptr %v1, ptr %v2, i64 %a0, i32 %a1, i32 %a2, { i64, ptr } %a3, { i64, ptr } %a4, %"compiler/generic:Origin" %a5) #0 {
entry:
  %rv = alloca %"compiler/generic:instance"
  br label %start
start:
  br label %bb0
bb0:
  %t14 = insertvalue %"compiler/generic:instance" undef, i64 %a0, 0
  %t16 = insertvalue %"compiler/generic:instance" %t14, i32 %a1, 1
  %t18 = insertvalue %"compiler/generic:instance" %t16, i32 %a2, 2
  %t20 = insertvalue %"compiler/generic:instance" %t18, { i64, ptr } %a3, 3
  %t22 = insertvalue %"compiler/generic:instance" %t20, { i64, ptr } %a4, 4
  %t24 = insertvalue %"compiler/generic:instance" %t22, %"compiler/generic:Origin" %a5, 5
  store %"compiler/generic:instance" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/generic:instance", ptr %rv
  ret %"compiler/generic:instance" %rr
}

define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal { i32, ptr } @olang_lambda_0(ptr %env, ptr %v0) #0 {
entry:
  %p = call ptr @llvm.coro.promise(ptr %env, i32 8, i1 false)
  %pr = getelementptr { { i32, ptr }, i32, ptr, ptr }, ptr %p, i32 0, i32 1
  %running = load i32, ptr %pr
  switch i32 %running, label %again [ i32 0, label %go i32 2, label %drop ]
again:
  call void @__olang_check_failed(ptr @.c61)
  unreachable
drop:
  call void @llvm.coro.destroy(ptr %env)
  br label %over
go:
  %done = call i1 @llvm.coro.done(ptr %env)
  br i1 %done, label %over, label %run
run:
  %pv0 = getelementptr { { i32, ptr }, i32, ptr, ptr }, ptr %p, i32 0, i32 3
  store ptr %v0, ptr %pv0
  store i32 1, ptr %pr
  call void @llvm.coro.resume(ptr %env)
  store i32 0, ptr %pr
  %r = load { i32, ptr }, ptr %p
  ret { i32, ptr } %r
over:
  %x = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  ret { i32, ptr } %x
}

define internal { i32, ptr } @olang_lambda_0.wnext(ptr %env, ptr %v0) alwaysinline #0 {
entry:
  %p = call ptr @llvm.coro.promise(ptr %env, i32 8, i1 false)
  %pr = getelementptr { { i32, ptr }, i32, ptr, ptr }, ptr %p, i32 0, i32 1
  %running = load i32, ptr %pr
  %stop = icmp eq i32 %running, 2
  br i1 %stop, label %drop, label %run
drop:
  call void @llvm.coro.destroy(ptr %env)
  br label %over
run:
  %pv0 = getelementptr { { i32, ptr }, i32, ptr, ptr }, ptr %p, i32 0, i32 3
  store ptr %v0, ptr %pv0
  call void @llvm.coro.resume(ptr %env)
  %r = load { i32, ptr }, ptr %p
  ret { i32, ptr } %r
over:
  %x = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  ret { i32, ptr } %x
}

define internal ptr @olang_lambda_0.coro(ptr %env, ptr %home) presplitcoroutine alwaysinline #0 {
entry:
  %prom = alloca { { i32, ptr }, i32, ptr, ptr }, align 8
  store { { i32, ptr }, i32, ptr, ptr } zeroinitializer, ptr %prom
  %rv = getelementptr { { i32, ptr }, i32, ptr, ptr }, ptr %prom, i32 0, i32 0
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l20 = alloca i1
  %cid = call token @llvm.coro.id(i32 8, ptr %prom, ptr null, ptr null)
  %cneed = call i1 @llvm.coro.alloc(token %cid)
  br i1 %cneed, label %coro.alloc, label %coro.begin
coro.alloc:
  %csz = call i64 @llvm.coro.size.i64()
  %cal = call i64 @llvm.coro.align.i64()
  %cmem0 = call ptr @__olang_scope_alloc_a(ptr %home, i64 %csz, i64 %cal)
  br label %coro.begin
coro.begin:
  %cmem = phi ptr [ null, %entry ], [ %cmem0, %coro.alloc ]
  %hdl = call ptr @llvm.coro.begin(token %cid, ptr %cmem)
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  store ptr %cv0, ptr %l0
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  %is = call i8 @llvm.coro.suspend(token none, i1 false)
  switch i8 %is, label %gen.end [ i8 0, label %gen.go i8 1, label %gen.free ]
gen.go:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/ast:StructBody", ptr %t1, i32 0, i32 2
  %t6 = load { i64, ptr }, ptr %t5, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  store i64 %t10, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = load i64, ptr %l4, !tbaa !24
  %t16 = icmp slt i64 %t12, %t13
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb2, label %bb3
bb2:
  br label %bb21
bb3:
  br label %bb4
bb4:
  %t20 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t20, ptr %l16, !tbaa !27
  %t21 = load i64, ptr %l3, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr ptr, ptr %t24, i64 %t21
  %t26 = load ptr, ptr %t25, !tbaa !39
  store ptr %t26, ptr %l5, !tbaa !29
  %t28 = load ptr, ptr %l5, !tbaa !29
  store ptr %t28, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t29 = load ptr, ptr %l19, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb5, label %bb6
bb5:
  %t32 = load ptr, ptr %l19, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 22}
  %t35 = icmp eq i64 %t33, 1
  store i1 %t35, ptr %l20, !tbaa !21
  br label %bb6
bb6:
  %t36 = load i1, ptr %l20, !tbaa !21
  br i1 %t36, label %bb7, label %bb8
bb7:
  %t37 = load ptr, ptr %l5, !tbaa !29
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", ptr }, ptr %t39, i32 0, i32 1
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l6, !tbaa !29
  br label %bb9
bb8:
  br label %bb14
bb9:
  %t43 = load ptr, ptr %l6, !tbaa !29
  %t45 = getelementptr %"compiler/ast:VarDecl", ptr %t43, i32 0, i32 5
  %t46 = load i1, ptr %t45, !tbaa !21
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l6, !tbaa !29
  %t50 = insertvalue { i32, ptr } zeroinitializer, ptr %t48, 1
  store { i32, ptr } %t50, ptr %rv
  %t51 = call i8 @llvm.coro.suspend(token none, i1 false)
  switch i8 %t51, label %gen.end [ i8 0, label %gen.res.52 i8 1, label %gen.drop.53 ]
gen.res.52:
  br label %bb12
gen.drop.53:
  br label %gen.free
bb11:
  br label %bb13
bb12:
  br label %bb13
bb13:
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_4e9784bcac016c39_bf9d00668e70ebe5)
  unreachable
bb19:
  br label %bb20
bb20:
  %t54 = load i64, ptr %l3, !tbaa !24
  %t56 = add i64 %t54, 1
  store i64 %t56, ptr %l3, !tbaa !24
  br label %bb1
bb21:
  %t59 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t59, ptr %rv
  br label %ret
ret:
  %fs = call i8 @llvm.coro.suspend(token none, i1 true)
  switch i8 %fs, label %gen.end [ i8 0, label %gen.dead i8 1, label %gen.free ]
gen.dead:
  unreachable
gen.free:
  %fm = call ptr @llvm.coro.free(token %cid, ptr %hdl)
  br label %gen.end
gen.end:
  %ce = call i1 @llvm.coro.end(ptr %hdl, i1 false, token none)
  ret ptr %hdl
}

define internal void @olang_lambda_0.drop(ptr %h, ptr %scope) #0 {
entry:
  %p = call ptr @llvm.coro.promise(ptr %h, i32 8, i1 false)
  %pr = getelementptr { { i32, ptr }, i32, ptr, ptr }, ptr %p, i32 0, i32 1
  %r = load i32, ptr %pr
  %idle = icmp eq i32 %r, 0
  br i1 %idle, label %d, label %x
d:
  call void @llvm.coro.destroy(ptr %h)
  br label %x
x:
  ret void
}

declare void @__olang_scope_register_dtor(ptr, ptr, ptr)
@.d1 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".Len()" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr) cold noreturn
declare void @__olang_ert_req_clear()
@.d2 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"if " }>, align 8
@.d3 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"} else if " }>, align 8
@.d4 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"assert " }>, align 8
@.d5 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"match " }>, align 8
@.d6 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" if " }>, align 8
@.d7 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"comptime" }>, align 8
@.d8 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Array<" }>, align 8
@.d9 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c">(" }>, align 8
@.d10 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d11 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" for " }>, align 8
@.d12 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"range " }>, align 8
@.d13 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Type" }>, align 8
@.d14 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Base" }>, align 8
@.d15 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"Element" }>, align 8
@.d16 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Target" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define internal i1 @olang_lambda_17(ptr %env, i32 %a0, i32 %a1) #0 {
entry:
  %l6 = alloca i1
  %rv = alloca i1
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t7 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eerrBefore(ptr %vc0, ptr %cv0, i32 %a0, i32 %a1)
  store i1 %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load i1, ptr %l6, !tbaa !21
  store i1 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d18 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d19 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d20 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d21 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d22 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d23 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d24 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Len" }>, align 8
@.d25 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d26 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d27 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d28 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".Len()" }>, align 8
@.d29 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t2 = load i32, ptr %a0, !range !{i32 0, i32 33}
  %t3 = sext i32 %t2 to i64
  %t5 = load i32, ptr %a1, !range !{i32 0, i32 33}
  %t6 = sext i32 %t5 to i64
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d30 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"?" }>, align 8
@.d31 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d32 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d33 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d34 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@__olang_empty_array = external constant [16 x i64]
declare void @__olang_bang_failed_plain(ptr) cold noreturn
@.d35 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U64" }>, align 8
@.d36 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"true" }>, align 8
@.d37 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Hash" }>, align 8
@.d38 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"hash" }>, align 8
@.d39 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d40 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d41 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d42 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d43 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d44 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"[0]" }>, align 8
@.d45 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d46 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"[0]" }>, align 8
@.d47 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".Len()" }>, align 8
@.d48 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d49 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Array" }>, align 8
@.d50 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bool" }>, align 8
@.d51 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d52 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bits" }>, align 8
@.d53 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U64" }>, align 8
@.d54 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U32" }>, align 8
@.d55 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U16" }>, align 8
@.d56 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Hash" }>, align 8
@.d57 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Len" }>, align 8
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2eArray_3ccompiler_2fsource_3aNameId_3e_26(ptr %a0, ptr %a1) #0 {
entry:
  %l6 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, ptr }, ptr %a0, !tbaa !27
  %t4 = load { i64, ptr }, ptr %a1, !tbaa !27
  %t9 = call i1 @olang_2eHelperKind_2eEqual_2eArray_3ccompiler_2fsource_3aNameId_3e({ i64, ptr } %t2, { i64, ptr } %t4)
  store i1 %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load i1, ptr %l6, !tbaa !21
  store i1 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d58 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"std/prelude/iterator" }>, align 8
@.d59 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"ViewGenerator" }>, align 8
declare i64 @llvm.ctpop.i64(i64)
declare i64 @llvm.cttz.i64(i64, i1)
@.d60 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"ViewGenerator" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@__olang_self = external thread_local(initialexec) global ptr
declare ptr @llvm.coro.promise(ptr, i32, i1)
@.c61 = private unnamed_addr constant [87 x i8] c"compiler/generic.olang:2226: a generator asked for its next value inside its own walk\0A\00"
declare void @llvm.coro.destroy(ptr)
declare i1 @llvm.coro.done(ptr)
declare void @llvm.coro.resume(ptr)
declare token @llvm.coro.id(i32, ptr, ptr, ptr)
declare i1 @llvm.coro.alloc(token)
declare i64 @llvm.coro.size.i64()
declare i64 @llvm.coro.align.i64()
declare ptr @llvm.coro.begin(token, ptr)
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
declare i8 @llvm.coro.suspend(token, i1)
declare ptr @llvm.coro.free(token, ptr)
declare i1 @llvm.coro.end(ptr, i1, token)
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2eArray_3ccompiler_2fsource_3aNameId_3e({ i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca i64
  %l6 = alloca i64
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t3, 0
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb7
bb2:
  store i64 0, ptr %l6, !tbaa !24
  br label %bb3
bb3:
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t13 = load i64, ptr %l6, !tbaa !24
  %t14 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i32, ptr %t15, i64 %t13
  %t17 = load i32, ptr %t16, !tbaa !33
  %t18 = load i64, ptr %l6, !tbaa !24
  %t19 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr i32, ptr %t20, i64 %t18
  %t22 = load i32, ptr %t21, !tbaa !33
  %t25 = icmp eq i32 %t17, %t22
  br i1 %t25, label %bb6, label %bb1
bb5:
  br label %bb7
bb6:
  %t27 = load i64, ptr %l6, !tbaa !24
  %t28 = add i64 %t27, 1
  store i64 %t28, ptr %l6, !tbaa !24
  br label %bb3
bb7:
  %t29 = load i1, ptr %l2, !tbaa !21
  store i1 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@__olang_prog_scope = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare ptr @__olang_scope_mine_slow(ptr) noinline
declare %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" @std_2fprelude_2fiterator_3aViewGenerator_3ccompiler_2fast_3aVarDecl_3e_2ector(ptr %v0, ptr %v1, ptr %a0c, ptr %a0e)
@olang_loc_c152c1cd1761af15_fc7472910c385f59 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
@olang_loc_e975feb741415938_3766dae77ababfac = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fgeneric_2erefElem(ptr %v0, ptr %a0)
@olang_loc_b9fc8c34bb4a0c14_d84bd287e8577888 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyCovers(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/generic:fnRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eAt_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2edeclVars(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclParams(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eHasErrParam(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@olang_loc_9ad358ce4cd92925_29c80ed6090eef61 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrSetOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstance(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eTuple(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etypeDecl(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5, i1 %a6, i32 %a7)
@olang_loc_ad47684fdd650b05_1c981444a6d99631 = external constant [0 x i8]
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2edeclContext(ptr %out, ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_56cbe4aa8d7e920d_955f1f716de98a59 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ftypes_2eDefaultErrT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\10\00\00\00" }>, align 8
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emergeEntries(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eSetAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare void @std_2fprelude_2farray_2eArray_3ccompiler_2ftypes_3aTypeId_3e_2eSort_3ccompiler_2ftypes_3aTypeId_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrVal(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eEntriesOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsErrorSet(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNameErrVal(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fload_2eErrQualifier(ptr %v0, ptr %v1, { i64, ptr } %a0, i1 %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H190b78e3c1eec037529224679e114a85(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsRaisedError(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/generic:varRow" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eVar(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H943a9bb03970f71acf57214091669a7d(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eLen_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2einstanceArgs(ptr %v0, ptr %a0, i32 %a1)
declare %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" @std_2fpair_3aPair_3cI64_2c_20compiler_2ftypes_3aListId_3e_2ector(ptr %v0, i64 %a0, i32 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20compiler__Hfc7ca136f786d4bb067f513e5dea5730(ptr %v0, ptr %a0, %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i32 %a3)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3ainstance_3e_2eLen_Hf1590ba3dea8cd8a914b2a9f5344a2c6(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3ainstance_3e_2ePus_Hca36cd1c69200a0db62aadeba49cf6ed(ptr %v0, ptr %v1, ptr %a0, %"compiler/generic:instance" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H5edca056502a242264473f986489341f(ptr %v0, ptr %a0, %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %a1, i64 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2erecvOf(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eanyGlobal(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
declare i1 @compiler_2fgeneric_2emutableGlobal(ptr %v0, ptr %a0)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/generic:instance" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3ainstance_3e_2eAt__Hf3965267bb92d0ee7aeaa2339e2e46fa(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_7f496bc4f965d188_939cdcc04f80a0bc = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %v0, i64 %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnifyArg(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3, i1 %a4, i1 %a5)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMembers(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_H78bce58497ad959bdf5762dbe74df8e1(ptr %v0, ptr %a0, i32 %a1)
declare { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_Hfa58d934e2b7178f7b33766972648144(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %v0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_Hb3133f486435530b533aaf49461c92b5(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFuncTag(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etypeKey(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2erecvApplies(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2erecvExact(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2efnsIn(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epreludeType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ereflName(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2enamed(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2efuncType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, ptr %a3)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2erefType(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i32 %a3, i1 %a4)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eperm(ptr %v0, ptr %a0, i32 %a1, i1 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAny(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@G_2ecompiler_2ftypes_2eSpread = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\08\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_e146017c26ab6c4e_50202815c87e77c2 = external constant [0 x i8]
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ebodiesOf(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInfer(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunended(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, i64 %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstExpr(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eaddFn(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i1 %a3)
@olang_loc_4e2b009ec27e80b_3f74010bfbf746f = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eChosen(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eaddFnsIf(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3, i64 %a4)
@olang_loc_8b73386467b8fdb3_4742e8850cea3c57 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrSetUnion(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFlows(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2enumberOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eNullable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnique(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0, i64 %a0)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2eeat(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0)
declare i8 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2epeek(ptr %v0, ptr %a0)
@olang_loc_510ce85b2a9a6c03_b867f874fd10b7a7 = external constant [0 x i8]
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i32 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ecanonList(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRecord(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eToArra_H4d02a0b2e27e8f31ffc99daa43750593(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_3e2c33a947ef0926_eb9e7dc4e2170cd2 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnonEnum(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, ptr } %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorMembers(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aDeclId_3e_2eLen_3ccompiler_2ftypes_3aDeclId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aDeclId_3e_2eAt_3ccompiler_2ftypes_3aDeclId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aDeclId_3e_2ePush_3ccompiler_2ftypes_3aDeclId_3e(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eerrorSetItem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aDeclId_3e_2ePop_3ccompiler_2ftypes_3aDeclId_3e(ptr %v0, ptr %a0)
@olang_loc_720125e199c24f22_e8379e985b9f3c66 = external constant [0 x i8]
@olang_loc_227a3f0eae681c4f_61bdff3e0ec7ebb3 = external constant [0 x i8]
@olang_loc_f703e5bec6c76f87_ea1686e8125b66ab = external constant [0 x i8]
@olang_loc_bbb5b8b709f50d79_9796b462e6590e5d = external constant [0 x i8]
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorItemKnown(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aDeclId_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_24f0f81fc570bea6_c6e464f22cc6b362 = external constant [0 x i8]
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eisVar(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
@olang_loc_3e60b6dd6ea07633_1a37389903bcd17 = external constant [0 x i8]
declare %"compiler/generic:folded" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2efoldPath(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3)
declare %"compiler/generic:folded" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eevalUnary(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, ptr %a3)
declare %"compiler/generic:folded" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eevalBinary(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i32 %a2, ptr %a3, ptr %a4)
declare %"compiler/generic:folded" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eevalCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, { i64, ptr } %a3)
@olang_loc_df0c974aeea04fc5_d4c449c0d39b6971 = external constant [0 x i8]
@olang_loc_886433b88e29f460_704fa105f63225d4 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aSource_2eTextOf(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseUint(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@olang_loc_cbe34de7626751c6_f090548a7d71387a = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
declare { i64, [3 x i64] } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eat(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eFlagAmongResults(ptr %v0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorOncePerLine(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eFlagWithOutParam(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_3f6d4ec28d03c677_4b12a6ade8d65b03 = external constant [0 x i8]
declare i1 @std_2fprelude_2farray_2eArray_3ccompiler_2fsource_3aNameId_3e_2eHas_3ccompiler_2fsource_3aNameId_3e(ptr %v0, { i64, ptr } %a0, i32 %a1)
@olang_loc_7d389628c92035eb_c8010a4fd10bb547 = external constant [0 x i8]
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eglobalInIf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, i64 %a3, i64 %a4, i32 %a5)
@olang_loc_a7facd254843b013_ee8f88ceeae7df5f = external constant [0 x i8]
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2edeclaresEq(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ehashShaped(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eownMethod(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ehashesAll(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_ee8d77a4a1fda3da_cc07c41aef88f656 = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_He6be2b0836caba7ddc59483ff74db438(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_cffe0474e3afc296_35ccea70755633e2 = external constant [0 x i8]
@olang_loc_e8a0dc9ccb955f9f_ce9beed0e9e57113 = external constant [0 x i8]
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_2edbc1bd270558db_85d99d8e9bee4edf = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_7a3d6db3b893cc7d_3c2a4275e29a89 = external constant [0 x i8]
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ementionsVar(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i64 %a3, i64 %a4)
declare { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamed(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ealiasStep(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@G_2ecompiler_2ftypes_2eOwnScope = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2ftypes_2eRoleCtor = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopes(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2econstraintKey(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare i64 @compiler_2fgeneric_2ekeyDecl(i32 %a0)
declare i64 @compiler_2fgeneric_2ekeyPrim(i32 %a0)
@olang_loc_769954e80c04bef7_8801cb066681a71b = external constant [0 x i8]
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Hfd0413fe7fd4e5914f6cad5b418b7a6d(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i32 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eParseCanon(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eanonEnum(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eparamTypes(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2)
@olang_loc_a096310d429842c5_b38f3d186616d6e9 = external constant [0 x i8]
@olang_loc_4439a413e01d0c26_16c6d6890310944a = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etextType(ptr %v0, ptr %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eEnds(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H64d9be73b6c9bed004c541bdf7f0ca0a(ptr %v0, ptr %a0, i32 %a1, i1 %a2)
@olang_loc_c2b0e0f9c58e7130_5beafbe0f1fd477c = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_b3aa93c548ec796e_ac2c4500982ff6c2 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunifyLists(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3, i1 %a4)
declare i64 @compiler_2fgeneric_2echangedVals(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
@olang_loc_d067a2352cc578e3_8c11ed4f2bfcee77 = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2eDeclOwner(i32 %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2esigType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3, i32 %a4)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunifyErrs(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3)
@olang_loc_29bfa21b0ca1023f_9ac138f9a38bfc3b = external constant [0 x i8]
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_f83e897c6289299d_c5b35c0c7cd0f831 = external constant [0 x i8]
@olang_loc_dbc69524847f1d49_8831f326edbf0acd = external constant [0 x i8]
@olang_loc_737134d81da26253_60c38b193f08901f = external constant [0 x i8]
declare %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Ha72624ba64524ee3315305b5d1bfb369(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20co_H6cf169b12565f300e9fe11f1c8d55061(ptr %v0, ptr %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i32 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFindDecl(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@olang_loc_6b949e9fdbc9587c_5a8bb2436952ea48 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2eroot(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2egrow(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2eparamBit(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hf575c52a5a9e8993bae2b73c9c2548b3(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ebaseName(ptr %v0, ptr %a0)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estored(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2ebranches(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2ematched(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2einner(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_df5307d3a8bec99f_effac078aaeab34b = external constant [0 x i8]
@olang_loc_fe684dd4125d4b4d_99bf6f4db7396e79 = external constant [0 x i8]
declare ptr @compiler_2fgeneric_2eerrorDeclIn(ptr %v0, ptr %v1, { i64, ptr } %a0, i32 %a1)
@olang_loc_42759df622c97166_e1be9b347935e452 = external constant [0 x i8]
@olang_loc_cc60064df4ba0b57_d35c100e8c6c7d93 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_2a0d238d6764ffeb_7f54c8a7a483f2b7 = external constant [0 x i8]
@olang_loc_b16df8c761b5d07c_6405a14de8d58098 = external constant [0 x i8]
declare i1 @compiler_2fgeneric_2ebyValueParam(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eToArray_3cBool_3e(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_90309fa9b0fb789a_4b8ce68c657018ae = external constant [0 x i8]
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_9e21964695e7b518_e551ec91ddd7cf74 = external constant [0 x i8]
@olang_loc_4e9784bcac016c39_bf9d00668e70ebe5 = external constant [0 x i8]
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eerrBefore(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
