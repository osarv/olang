; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, ptr, i32 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, i1, i1, { i64, ptr }, i1 }
%"compiler/generic:Binding" = type { i64, i64, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/generic:varRow" = type { i64, i32, i32, i32, i32 }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"compiler/facts:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/facts:Table" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64 }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, i32, i1, ptr, i32 }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1, ptr }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, i1, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" = type { i64, i32 }
%"compiler/generic:fnRow" = type { i64, ptr, i1 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:instance" = type { i64, i32, i32, { i64, ptr }, { i64, ptr }, %"compiler/generic:Origin" }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/generic:cursor" = type { { i64, ptr }, i64 }
%"compiler/names:Ref" = type { i32, i64, i64 }
%"compiler/diagmsg:Msg" = type { i32, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Promise" = type { %"compiler/source:Span", i32, { i64, ptr } }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/generic:genRoots" = type { { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64 }
%"compiler/ast:TypeParam" = type { %"compiler/source:Span", i32, ptr, { i64, ptr }, i1, ptr }
define dso_local i1 @compiler_2fgeneric_2eLengthDecided(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i64 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i32
  %l39 = alloca i1
  %l40 = alloca { i64, ptr }
  %l44 = alloca i1
  %l45 = alloca i1
  %l46 = alloca { i64, ptr }
  %l50 = alloca i1
  %l51 = alloca i1
  %l52 = alloca { i64, ptr }
  %l57 = alloca i1
  %l58 = alloca { i64, ptr }
  %l67 = alloca i1
  %l68 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l78 = alloca i64
  %l79 = alloca i64
  %l80 = alloca i64
  %l85 = alloca { i64, ptr }
  %l87 = alloca i1
  %l88 = alloca i1
  %l90 = alloca i1
  %l91 = alloca i1
  %l93 = alloca i1
  %l94 = alloca i1
  %l96 = alloca i1
  %l100 = alloca { i64, ptr }
  %l101 = alloca i1
  %l102 = alloca i1
  %l105 = alloca { i64, ptr }
  %l106 = alloca i1
  %l107 = alloca i1
  %l109 = alloca i1
  %l110 = alloca i1
  %l113 = alloca { i64, ptr }
  %l114 = alloca i1
  %l118 = alloca { i64, ptr }
  %l119 = alloca i1
  %l120 = alloca i1
  %l123 = alloca { i64, ptr }
  %l124 = alloca i1
  %l125 = alloca i1
  %l127 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = extractvalue { i64, ptr } %a3, 1
  %t4 = extractvalue { i64, ptr } %a3, 0
  %t5 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t13 = load i64, ptr %l1, !tbaa !24
  store i64 %t13, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t15 = load i64, ptr %l5, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb93
bb3:
  br label %bb4
bb4:
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t23, ptr %l18, !tbaa !27
  %t24 = load i64, ptr %l5, !tbaa !24
  store i64 %t24, ptr %l19, !tbaa !24
  %t25 = load i64, ptr %l2, !tbaa !24
  store i64 %t25, ptr %l20, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t26, 0
  store i64 %t27, ptr %l21, !tbaa !24
  %t28 = load i64, ptr %l19, !tbaa !24
  %t29 = icmp sge i64 %t28, 0
  br i1 %t29, label %bb5, label %bb6
bb5:
  %t31 = load i64, ptr %l19, !tbaa !24
  %t32 = load i64, ptr %l20, !tbaa !24
  %t33 = icmp sle i64 %t31, %t32
  br i1 %t33, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_c152c1cd1761af15_fc7472910c385f59)
  unreachable
bb7:
  %t35 = load i64, ptr %l20, !tbaa !24
  %t36 = load i64, ptr %l21, !tbaa !24
  %t37 = icmp sle i64 %t35, %t36
  br i1 %t37, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_c152c1cd1761af15_fc7472910c385f59)
  unreachable
bb9:
  %t39 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = load i64, ptr %l19, !tbaa !24
  %t42 = load i64, ptr %l20, !tbaa !24
  %t43 = getelementptr i8, ptr %t40, i64 %t41
  %t44 = sub i64 %t42, %t41
  %t45 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t43, 1
  %t47 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t50 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s0, { i64, ptr } %t46, { i64, ptr } %t47)
  %t51 = extractvalue { i32, i64 } %t50, 1
  %t52 = extractvalue { i32, i64 } %t50, 0
  store i32 %t52, ptr %l28
  %t53 = icmp ne i32 %t52, 0
  br i1 %t53, label %bb12, label %ok.54, !prof !99
ok.54:
  store i64 %t51, ptr %l27
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_c152c1cd1761af15_fc7472910c385f59)
  unreachable
bb11:
  %t55 = load i64, ptr %l27, !tbaa !24
  store i64 %t55, ptr %l17, !tbaa !24
  br label %bb14
bb12:
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb14:
  %t57 = load i64, ptr %l17, !tbaa !24
  %t58 = load i64, ptr %l5, !tbaa !24
  %t62 = add i64 %t58, %t57
  store i64 %t62, ptr %l7, !tbaa !24
  %t64 = load i64, ptr %l7, !tbaa !24
  %t65 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t65, 0
  %t70 = add i64 %t64, %t67
  store i64 %t70, ptr %l5, !tbaa !24
  %t72 = load i64, ptr %l7, !tbaa !24
  %t74 = icmp sgt i64 %t72, 0
  br i1 %t74, label %bb15, label %bb16
bb15:
  %t76 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t76, ptr %l40, !tbaa !27
  %t77 = load i64, ptr %l7, !tbaa !24
  %t79 = sub i64 %t77, 1
  %t81 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr i8, ptr %t82, i64 %t79
  %t84 = load i8, ptr %t83, !tbaa !32
  %t86 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t84)
  store i1 %t86, ptr %l44
  br label %bb17
bb16:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb28
bb17:
  %t87 = load i1, ptr %l44, !tbaa !21
  br i1 %t87, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb21
bb19:
  %t88 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t88, ptr %l46, !tbaa !27
  %t89 = load i64, ptr %l7, !tbaa !24
  %t91 = sub i64 %t89, 1
  %t93 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr i8, ptr %t94, i64 %t91
  %t96 = load i8, ptr %t95, !tbaa !32
  %t98 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t96)
  store i1 %t98, ptr %l50
  br label %bb20
bb20:
  %t99 = load i1, ptr %l50, !tbaa !21
  store i1 %t99, ptr %l45, !tbaa !21
  br label %bb21
bb21:
  %t100 = load i1, ptr %l45, !tbaa !21
  br i1 %t100, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb24
bb23:
  %t101 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t101, ptr %l52, !tbaa !27
  %t102 = load i64, ptr %l7, !tbaa !24
  %t104 = sub i64 %t102, 1
  %t106 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = getelementptr i8, ptr %t107, i64 %t104
  %t109 = load i8, ptr %t108, !tbaa !32
  %t111 = icmp eq i8 %t109, 95
  store i1 %t111, ptr %l51, !tbaa !21
  br label %bb24
bb24:
  %t113 = load i1, ptr %l51, !tbaa !21
  br i1 %t113, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l57, !tbaa !21
  br label %bb27
bb26:
  %t114 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t114, ptr %l58, !tbaa !27
  %t115 = load i64, ptr %l7, !tbaa !24
  %t117 = sub i64 %t115, 1
  %t119 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr i8, ptr %t120, i64 %t117
  %t122 = load i8, ptr %t121, !tbaa !32
  %t124 = icmp eq i8 %t122, 46
  store i1 %t124, ptr %l57, !tbaa !21
  br label %bb27
bb27:
  %t126 = load i1, ptr %l57, !tbaa !21
  store i1 %t126, ptr %l39, !tbaa !21
  br label %bb28
bb28:
  %t127 = load i1, ptr %l39, !tbaa !21
  br i1 %t127, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s2)
  br label %bb92
bb30:
  br label %bb31
bb31:
  %t128 = load i64, ptr %l7, !tbaa !24
  store i64 %t128, ptr %l8, !tbaa !24
  br label %bb32
bb32:
  %t130 = load i64, ptr %l8, !tbaa !24
  %t131 = load i64, ptr %l1, !tbaa !24
  %t134 = icmp sgt i64 %t130, %t131
  br i1 %t134, label %bb33, label %bb34
bb33:
  %t136 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t136, ptr %l68, !tbaa !27
  %t137 = load i64, ptr %l8, !tbaa !24
  %t139 = sub i64 %t137, 1
  %t141 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !27
  %t143 = getelementptr i8, ptr %t142, i64 %t139
  %t144 = load i8, ptr %t143, !tbaa !32
  %t146 = icmp ne i8 %t144, 10
  store i1 %t146, ptr %l67, !tbaa !21
  br label %bb35
bb34:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb35
bb35:
  %t148 = load i1, ptr %l67, !tbaa !21
  %t149 = xor i1 %t148, true
  br i1 %t149, label %bb36, label %bb37
bb36:
  br label %bb40
bb37:
  br label %bb38
bb38:
  %t151 = load i64, ptr %l8, !tbaa !24
  %t154 = sub i64 %t151, 1
  store i64 %t154, ptr %l8, !tbaa !24
  br label %bb39
bb39:
  br label %bb32
bb40:
  %t156 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t156, ptr %l77, !tbaa !27
  %t157 = load i64, ptr %l8, !tbaa !24
  store i64 %t157, ptr %l78, !tbaa !24
  %t158 = load i64, ptr %l7, !tbaa !24
  store i64 %t158, ptr %l79, !tbaa !24
  %t159 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t159, 0
  store i64 %t160, ptr %l80, !tbaa !24
  %t161 = load i64, ptr %l78, !tbaa !24
  %t162 = icmp sge i64 %t161, 0
  br i1 %t162, label %bb41, label %bb42
bb41:
  %t164 = load i64, ptr %l78, !tbaa !24
  %t165 = load i64, ptr %l79, !tbaa !24
  %t166 = icmp sle i64 %t164, %t165
  br i1 %t166, label %bb43, label %bb44
bb42:
  call void @__olang_check_failed(ptr @olang_loc_e975feb741415938_3766dae77ababfac)
  unreachable
bb43:
  %t168 = load i64, ptr %l79, !tbaa !24
  %t169 = load i64, ptr %l80, !tbaa !24
  %t170 = icmp sle i64 %t168, %t169
  br i1 %t170, label %bb45, label %bb46
bb44:
  call void @__olang_check_failed(ptr @olang_loc_e975feb741415938_3766dae77ababfac)
  unreachable
bb45:
  %t172 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !27
  %t174 = load i64, ptr %l78, !tbaa !24
  %t175 = load i64, ptr %l79, !tbaa !24
  %t176 = getelementptr i8, ptr %t173, i64 %t174
  %t177 = sub i64 %t175, %t174
  %t178 = insertvalue { i64, ptr } undef, i64 %t177, 0
  %t179 = insertvalue { i64, ptr } %t178, ptr %t176, 1
  %t181 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %v0, ptr %v0, { i64, ptr } %t179)
  store { i64, ptr } %t181, ptr %l85
  br label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_e975feb741415938_3766dae77ababfac)
  unreachable
bb47:
  %t182 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t182, ptr %l9, !tbaa !27
  %t183 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t185 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t183, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i1 %t185, ptr %l87
  br label %bb48
bb48:
  %t186 = load i1, ptr %l87, !tbaa !21
  br i1 %t186, label %bb49, label %bb50
bb49:
  store i1 true, ptr %l88, !tbaa !21
  br label %bb52
bb50:
  %t187 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t189 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t187, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i1 %t189, ptr %l90
  br label %bb51
bb51:
  %t190 = load i1, ptr %l90, !tbaa !21
  store i1 %t190, ptr %l88, !tbaa !21
  br label %bb52
bb52:
  %t191 = load i1, ptr %l88, !tbaa !21
  br i1 %t191, label %bb53, label %bb54
bb53:
  store i1 true, ptr %l91, !tbaa !21
  br label %bb56
bb54:
  %t192 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t194 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t192, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i1 %t194, ptr %l93
  br label %bb55
bb55:
  %t195 = load i1, ptr %l93, !tbaa !21
  store i1 %t195, ptr %l91, !tbaa !21
  br label %bb56
bb56:
  %t196 = load i1, ptr %l91, !tbaa !21
  br i1 %t196, label %bb57, label %bb58
bb57:
  store i1 true, ptr %l94, !tbaa !21
  br label %bb60
bb58:
  %t197 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t199 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t197, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store i1 %t199, ptr %l96
  br label %bb59
bb59:
  %t200 = load i1, ptr %l96, !tbaa !21
  store i1 %t200, ptr %l94, !tbaa !21
  br label %bb60
bb60:
  %t201 = load i1, ptr %l94, !tbaa !21
  br i1 %t201, label %bb61, label %bb62
bb61:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb62:
  br label %bb63
bb63:
  %t203 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d5, i32 0, i32 1) }, ptr %l100, !tbaa !27
  %t206 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t207 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s2, { i64, ptr } %t203, { i64, ptr } %t206)
  store i1 %t207, ptr %l101
  br label %bb64
bb64:
  %t208 = load i1, ptr %l101, !tbaa !21
  br i1 %t208, label %bb65, label %bb66
bb65:
  store i1 true, ptr %l102, !tbaa !21
  br label %bb68
bb66:
  %t209 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d6, i32 0, i32 1) }, ptr %l105, !tbaa !27
  %t212 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t213 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s2, { i64, ptr } %t209, { i64, ptr } %t212)
  store i1 %t213, ptr %l106
  br label %bb67
bb67:
  %t214 = load i1, ptr %l106, !tbaa !21
  store i1 %t214, ptr %l102, !tbaa !21
  br label %bb68
bb68:
  %t215 = load i1, ptr %l102, !tbaa !21
  br i1 %t215, label %bb69, label %bb70
bb69:
  store i1 true, ptr %l107, !tbaa !21
  br label %bb72
bb70:
  %t216 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t218 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s2, { i64, ptr } %t216, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store i1 %t218, ptr %l109
  br label %bb71
bb71:
  %t219 = load i1, ptr %l109, !tbaa !21
  store i1 %t219, ptr %l107, !tbaa !21
  br label %bb72
bb72:
  %t220 = load i1, ptr %l107, !tbaa !21
  br i1 %t220, label %bb73, label %bb74
bb73:
  store i1 true, ptr %l110, !tbaa !21
  br label %bb76
bb74:
  %t221 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %l113, !tbaa !27
  %t224 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t225 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s2, { i64, ptr } %t221, { i64, ptr } %t224)
  store i1 %t225, ptr %l114
  br label %bb75
bb75:
  %t226 = load i1, ptr %l114, !tbaa !21
  store i1 %t226, ptr %l110, !tbaa !21
  br label %bb76
bb76:
  %t227 = load i1, ptr %l110, !tbaa !21
  br i1 %t227, label %bb77, label %bb78
bb77:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb78:
  br label %bb79
bb79:
  %t229 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr %l118, !tbaa !27
  %t232 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t233 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s2, { i64, ptr } %t229, { i64, ptr } %t232)
  store i1 %t233, ptr %l119
  br label %bb80
bb80:
  %t234 = load i1, ptr %l119, !tbaa !21
  br i1 %t234, label %bb81, label %bb82
bb81:
  %t235 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d10, i32 0, i32 1) }, ptr %l123, !tbaa !27
  %t238 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t239 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s2, { i64, ptr } %t235, { i64, ptr } %t238)
  store i1 %t239, ptr %l124
  br label %bb83
bb82:
  store i1 false, ptr %l120, !tbaa !21
  br label %bb84
bb83:
  %t240 = load i1, ptr %l124, !tbaa !21
  store i1 %t240, ptr %l120, !tbaa !21
  br label %bb84
bb84:
  %t241 = load i1, ptr %l120, !tbaa !21
  br i1 %t241, label %bb85, label %bb86
bb85:
  %t242 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t244 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s2, { i64, ptr } %t242, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store i1 %t244, ptr %l127
  br label %bb87
bb86:
  store i1 false, ptr %l125, !tbaa !21
  br label %bb88
bb87:
  %t245 = load i1, ptr %l127, !tbaa !21
  store i1 %t245, ptr %l125, !tbaa !21
  br label %bb88
bb88:
  %t246 = load i1, ptr %l125, !tbaa !21
  br i1 %t246, label %bb89, label %bb90
bb89:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb90:
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s2)
  br label %bb92
bb92:
  br label %bb1
bb93:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fgeneric_2eborrowableElem(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l13 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i1
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l26 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Func", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/ast:Sig", ptr %t4, i32 0, i32 1
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t11 = icmp ne i64 %t9, 1
  br i1 %t11, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/ast:Func", ptr %t14, i32 0, i32 3
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/ast:Sig", ptr %t17, i32 0, i32 1
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l11, !tbaa !27
  %t21 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 0
  %t24 = load ptr, ptr %t23, !tbaa !39
  store ptr %t24, ptr %l1, !tbaa !29
  %t26 = load ptr, ptr %l1, !tbaa !29
  store ptr %t26, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t27 = load ptr, ptr %l14, !tbaa !29
  %t28 = icmp ne ptr %t27, null
  br i1 %t28, label %bb4, label %bb5
bb4:
  %t30 = load ptr, ptr %l14, !tbaa !29
  %t31 = load i64, ptr %t30, !range !{i64 0, i64 8}
  %t33 = icmp eq i64 %t31, 0
  store i1 %t33, ptr %l15, !tbaa !21
  br label %bb5
bb5:
  %t34 = load i1, ptr %l15, !tbaa !21
  br i1 %t34, label %bb6, label %bb7
bb6:
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr { i64, [5 x i64] }, ptr %t35, i32 0, i32 1
  %t38 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t37, i32 0, i32 2
  %t39 = load { i64, ptr }, ptr %t38
  store { i64, ptr } %t39, ptr %l2, !tbaa !27
  br label %bb8
bb7:
  br label %bb13
bb8:
  %t41 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t45 = icmp sgt i64 %t43, 0
  br i1 %t45, label %bb9, label %bb10
bb9:
  %t47 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t47, ptr %l24, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr ptr, ptr %t49, i64 0
  %t51 = load ptr, ptr %t50, !tbaa !39
  %t53 = call i1 @compiler_2fgeneric_2erefElem(ptr %v0, ptr %t51)
  store i1 %t53, ptr %l26
  br label %bb11
bb10:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb12
bb11:
  %t54 = load i1, ptr %l26, !tbaa !21
  store i1 %t54, ptr %l23, !tbaa !21
  br label %bb12
bb12:
  %t55 = load i1, ptr %l23, !tbaa !21
  store i1 %t55, ptr %l13, !tbaa !21
  br label %bb18
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_b9fc8c34bb4a0c14_d84bd287e8577888)
  unreachable
bb18:
  %t56 = load i1, ptr %l13, !tbaa !21
  store i1 %t56, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { { i64, ptr }, i64 } @compiler_2fgeneric_2ecallAround(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i8
  %l7 = alloca i64
  %l8 = alloca i64
  %l15 = alloca { i64, ptr }
  %l20 = alloca i1
  %l23 = alloca i1
  %l31 = alloca i1
  %l34 = alloca i1
  %l44 = alloca i1
  %l47 = alloca { i64, ptr }
  %l49 = alloca { { i64, ptr }, i64 }
  %l50 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca { i64, ptr }
  %l55 = alloca i1
  %l67 = alloca i1
  %l68 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l74 = alloca { { i64, ptr }, i64 }
  %l75 = alloca { i64, ptr }
  %l76 = alloca i64
  %l77 = alloca { i64, ptr }
  %l83 = alloca i1
  %l84 = alloca { i64, ptr }
  %l88 = alloca i1
  %l89 = alloca i1
  %l90 = alloca { i64, ptr }
  %l94 = alloca i1
  %l95 = alloca i1
  %l96 = alloca { i64, ptr }
  %l108 = alloca i1
  %l112 = alloca i1
  %l113 = alloca { i64, ptr }
  %l118 = alloca { i64, ptr }
  %l120 = alloca { { i64, ptr }, i64 }
  %l121 = alloca { i64, ptr }
  %l122 = alloca i64
  %l123 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l125 = alloca i64
  %l126 = alloca i64
  %l127 = alloca i64
  %rv = alloca { { i64, ptr }, i64 }
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t3 = sub i64 %a2, 1
  store i64 %t3, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l5, !tbaa !24
  %t6 = load i64, ptr %l1, !tbaa !24
  %t9 = icmp sge i64 %t5, %t6
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  br label %bb39
bb3:
  br label %bb4
bb4:
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t13, ptr %l15, !tbaa !27
  %t14 = load i64, ptr %l5, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr i8, ptr %t17, i64 %t14
  %t19 = load i8, ptr %t18, !tbaa !32
  store i8 %t19, ptr %l6, !tbaa !22
  %t21 = load i8, ptr %l6, !tbaa !22
  %t23 = icmp eq i8 %t21, 41
  br i1 %t23, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb7
bb6:
  %t25 = load i8, ptr %l6, !tbaa !22
  %t27 = icmp eq i8 %t25, 93
  store i1 %t27, ptr %l20, !tbaa !21
  br label %bb7
bb7:
  %t29 = load i1, ptr %l20, !tbaa !21
  br i1 %t29, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb10
bb9:
  %t30 = load i8, ptr %l6, !tbaa !22
  %t32 = icmp eq i8 %t30, 125
  store i1 %t32, ptr %l23, !tbaa !21
  br label %bb10
bb10:
  %t34 = load i1, ptr %l23, !tbaa !21
  br i1 %t34, label %bb11, label %bb12
bb11:
  %t35 = load i64, ptr %l3, !tbaa !24
  %t38 = add i64 %t35, 1
  store i64 %t38, ptr %l3, !tbaa !24
  br label %bb13
bb12:
  br label %bb13
bb13:
  %t40 = load i8, ptr %l6, !tbaa !22
  %t42 = icmp eq i8 %t40, 40
  br i1 %t42, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb16
bb15:
  %t44 = load i8, ptr %l6, !tbaa !22
  %t46 = icmp eq i8 %t44, 91
  store i1 %t46, ptr %l31, !tbaa !21
  br label %bb16
bb16:
  %t48 = load i1, ptr %l31, !tbaa !21
  br i1 %t48, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb19
bb18:
  %t49 = load i8, ptr %l6, !tbaa !22
  %t51 = icmp eq i8 %t49, 123
  store i1 %t51, ptr %l34, !tbaa !21
  br label %bb19
bb19:
  %t53 = load i1, ptr %l34, !tbaa !21
  br i1 %t53, label %bb20, label %bb21
bb20:
  %t54 = load i64, ptr %l3, !tbaa !24
  %t56 = icmp eq i64 %t54, 0
  br i1 %t56, label %bb22, label %bb23
bb21:
  br label %bb25
bb22:
  br label %bb39
bb23:
  br label %bb24
bb24:
  %t58 = load i64, ptr %l3, !tbaa !24
  %t61 = sub i64 %t58, 1
  store i64 %t61, ptr %l3, !tbaa !24
  br label %bb25
bb25:
  %t63 = load i8, ptr %l6, !tbaa !22
  %t65 = icmp eq i8 %t63, 10
  br i1 %t65, label %bb26, label %bb27
bb26:
  %t67 = load i64, ptr %l3, !tbaa !24
  %t69 = icmp eq i64 %t67, 0
  store i1 %t69, ptr %l44, !tbaa !21
  br label %bb28
bb27:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb28
bb28:
  %t71 = load i1, ptr %l44, !tbaa !21
  br i1 %t71, label %bb29, label %bb30
bb29:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d12, i32 0, i32 1) }, ptr %l47, !tbaa !27
  %t72 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t74 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t72, 0
  %t75 = insertvalue { { i64, ptr }, i64 } %t74, i64 0, 1
  store { { i64, ptr }, i64 } %t75, ptr %l49
  %t76 = getelementptr { { i64, ptr }, i64 }, ptr %l49, i32 0, i32 0
  %t77 = load { i64, ptr }, ptr %t76, !tbaa !27
  store { i64, ptr } %t77, ptr %l50, !tbaa !27
  %t78 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 0
  store i64 %t79, ptr %l51, !tbaa !24
  %t80 = load i64, ptr %l51, !tbaa !24
  %t81 = mul i64 %t80, 1
  %t82 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t81)
  %t83 = insertvalue { i64, ptr } undef, i64 %t80, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t82, 1
  store { i64, ptr } %t84, ptr %l52, !tbaa !27
  %t85 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = load i64, ptr %l51, !tbaa !24
  %t90 = mul i64 %t89, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t86, ptr %t88, i64 %t90, i1 false)
  %t91 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t92 = getelementptr { { i64, ptr }, i64 }, ptr %l49, i32 0, i32 0
  store { i64, ptr } %t91, ptr %t92, !tbaa !27
  %t93 = load { { i64, ptr }, i64 }, ptr %l49
  store { { i64, ptr }, i64 } %t93, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  %t94 = load i8, ptr %l6, !tbaa !22
  %t96 = icmp eq i8 %t94, 44
  br i1 %t96, label %bb32, label %bb33
bb32:
  %t98 = load i64, ptr %l3, !tbaa !24
  %t100 = icmp eq i64 %t98, 0
  store i1 %t100, ptr %l55, !tbaa !21
  br label %bb34
bb33:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb34
bb34:
  %t102 = load i1, ptr %l55, !tbaa !21
  br i1 %t102, label %bb35, label %bb36
bb35:
  %t103 = load i64, ptr %l4, !tbaa !24
  %t106 = add i64 %t103, 1
  store i64 %t106, ptr %l4, !tbaa !24
  br label %bb37
bb36:
  br label %bb37
bb37:
  %t108 = load i64, ptr %l5, !tbaa !24
  %t111 = sub i64 %t108, 1
  store i64 %t111, ptr %l5, !tbaa !24
  br label %bb38
bb38:
  br label %bb1
bb39:
  %t113 = load i64, ptr %l5, !tbaa !24
  %t114 = load i64, ptr %l1, !tbaa !24
  %t117 = icmp slt i64 %t113, %t114
  br i1 %t117, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb42
bb41:
  %t119 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t119, ptr %l68, !tbaa !27
  %t120 = load i64, ptr %l5, !tbaa !24
  %t122 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = getelementptr i8, ptr %t123, i64 %t120
  %t125 = load i8, ptr %t124, !tbaa !32
  %t127 = icmp ne i8 %t125, 40
  store i1 %t127, ptr %l67, !tbaa !21
  br label %bb42
bb42:
  %t129 = load i1, ptr %l67, !tbaa !21
  br i1 %t129, label %bb43, label %bb44
bb43:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d13, i32 0, i32 1) }, ptr %l72, !tbaa !27
  %t130 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t132 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t130, 0
  %t133 = insertvalue { { i64, ptr }, i64 } %t132, i64 0, 1
  store { { i64, ptr }, i64 } %t133, ptr %l74
  %t134 = getelementptr { { i64, ptr }, i64 }, ptr %l74, i32 0, i32 0
  %t135 = load { i64, ptr }, ptr %t134, !tbaa !27
  store { i64, ptr } %t135, ptr %l75, !tbaa !27
  %t136 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t136, 0
  store i64 %t137, ptr %l76, !tbaa !24
  %t138 = load i64, ptr %l76, !tbaa !24
  %t139 = mul i64 %t138, 1
  %t140 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t139)
  %t141 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t140, 1
  store { i64, ptr } %t142, ptr %l77, !tbaa !27
  %t143 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !27
  %t145 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = load i64, ptr %l76, !tbaa !24
  %t148 = mul i64 %t147, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t144, ptr %t146, i64 %t148, i1 false)
  %t149 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t150 = getelementptr { { i64, ptr }, i64 }, ptr %l74, i32 0, i32 0
  store { i64, ptr } %t149, ptr %t150, !tbaa !27
  %t151 = load { { i64, ptr }, i64 }, ptr %l74
  store { { i64, ptr }, i64 } %t151, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  %t152 = load i64, ptr %l5, !tbaa !24
  store i64 %t152, ptr %l7, !tbaa !24
  %t154 = load i64, ptr %l7, !tbaa !24
  store i64 %t154, ptr %l8, !tbaa !24
  br label %bb46
bb46:
  %t156 = load i64, ptr %l8, !tbaa !24
  %t157 = load i64, ptr %l1, !tbaa !24
  %t160 = icmp sgt i64 %t156, %t157
  br i1 %t160, label %bb47, label %bb48
bb47:
  %t162 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t162, ptr %l84, !tbaa !27
  %t163 = load i64, ptr %l8, !tbaa !24
  %t165 = sub i64 %t163, 1
  %t167 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t168 = load ptr, ptr %t167, !tbaa !27
  %t169 = getelementptr i8, ptr %t168, i64 %t165
  %t170 = load i8, ptr %t169, !tbaa !32
  %t172 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t170)
  store i1 %t172, ptr %l88
  br label %bb49
bb48:
  store i1 false, ptr %l83, !tbaa !21
  br label %bb57
bb49:
  %t173 = load i1, ptr %l88, !tbaa !21
  br i1 %t173, label %bb50, label %bb51
bb50:
  store i1 true, ptr %l89, !tbaa !21
  br label %bb53
bb51:
  %t174 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t174, ptr %l90, !tbaa !27
  %t175 = load i64, ptr %l8, !tbaa !24
  %t177 = sub i64 %t175, 1
  %t179 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !27
  %t181 = getelementptr i8, ptr %t180, i64 %t177
  %t182 = load i8, ptr %t181, !tbaa !32
  %t184 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t182)
  store i1 %t184, ptr %l94
  br label %bb52
bb52:
  %t185 = load i1, ptr %l94, !tbaa !21
  store i1 %t185, ptr %l89, !tbaa !21
  br label %bb53
bb53:
  %t186 = load i1, ptr %l89, !tbaa !21
  br i1 %t186, label %bb54, label %bb55
bb54:
  store i1 true, ptr %l95, !tbaa !21
  br label %bb56
bb55:
  %t187 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t187, ptr %l96, !tbaa !27
  %t188 = load i64, ptr %l8, !tbaa !24
  %t190 = sub i64 %t188, 1
  %t192 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t194 = getelementptr i8, ptr %t193, i64 %t190
  %t195 = load i8, ptr %t194, !tbaa !32
  %t197 = icmp eq i8 %t195, 95
  store i1 %t197, ptr %l95, !tbaa !21
  br label %bb56
bb56:
  %t199 = load i1, ptr %l95, !tbaa !21
  store i1 %t199, ptr %l83, !tbaa !21
  br label %bb57
bb57:
  %t200 = load i1, ptr %l83, !tbaa !21
  %t201 = xor i1 %t200, true
  br i1 %t201, label %bb58, label %bb59
bb58:
  br label %bb62
bb59:
  br label %bb60
bb60:
  %t203 = load i64, ptr %l8, !tbaa !24
  %t206 = sub i64 %t203, 1
  store i64 %t206, ptr %l8, !tbaa !24
  br label %bb61
bb61:
  br label %bb46
bb62:
  %t208 = load i64, ptr %l8, !tbaa !24
  %t209 = load i64, ptr %l7, !tbaa !24
  %t212 = icmp eq i64 %t208, %t209
  br i1 %t212, label %bb63, label %bb64
bb63:
  store i1 true, ptr %l108, !tbaa !21
  br label %bb68
bb64:
  %t214 = load i64, ptr %l8, !tbaa !24
  %t215 = load i64, ptr %l1, !tbaa !24
  %t218 = icmp sgt i64 %t214, %t215
  br i1 %t218, label %bb65, label %bb66
bb65:
  %t220 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t220, ptr %l113, !tbaa !27
  %t221 = load i64, ptr %l8, !tbaa !24
  %t223 = sub i64 %t221, 1
  %t225 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !27
  %t227 = getelementptr i8, ptr %t226, i64 %t223
  %t228 = load i8, ptr %t227, !tbaa !32
  %t230 = icmp eq i8 %t228, 46
  store i1 %t230, ptr %l112, !tbaa !21
  br label %bb67
bb66:
  store i1 false, ptr %l112, !tbaa !21
  br label %bb67
bb67:
  %t232 = load i1, ptr %l112, !tbaa !21
  store i1 %t232, ptr %l108, !tbaa !21
  br label %bb68
bb68:
  %t233 = load i1, ptr %l108, !tbaa !21
  br i1 %t233, label %bb69, label %bb70
bb69:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d14, i32 0, i32 1) }, ptr %l118, !tbaa !27
  %t234 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t236 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t234, 0
  %t237 = insertvalue { { i64, ptr }, i64 } %t236, i64 0, 1
  store { { i64, ptr }, i64 } %t237, ptr %l120
  %t238 = getelementptr { { i64, ptr }, i64 }, ptr %l120, i32 0, i32 0
  %t239 = load { i64, ptr }, ptr %t238, !tbaa !27
  store { i64, ptr } %t239, ptr %l121, !tbaa !27
  %t240 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t241 = extractvalue { i64, ptr } %t240, 0
  store i64 %t241, ptr %l122, !tbaa !24
  %t242 = load i64, ptr %l122, !tbaa !24
  %t243 = mul i64 %t242, 1
  %t244 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t243)
  %t245 = insertvalue { i64, ptr } undef, i64 %t242, 0
  %t246 = insertvalue { i64, ptr } %t245, ptr %t244, 1
  store { i64, ptr } %t246, ptr %l123, !tbaa !27
  %t247 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t248 = load ptr, ptr %t247, !tbaa !27
  %t249 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t250 = load ptr, ptr %t249, !tbaa !27
  %t251 = load i64, ptr %l122, !tbaa !24
  %t252 = mul i64 %t251, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t248, ptr %t250, i64 %t252, i1 false)
  %t253 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t254 = getelementptr { { i64, ptr }, i64 }, ptr %l120, i32 0, i32 0
  store { i64, ptr } %t253, ptr %t254, !tbaa !27
  %t255 = load { { i64, ptr }, i64 }, ptr %l120
  store { { i64, ptr }, i64 } %t255, ptr %rv
  br label %ret
bb70:
  br label %bb71
bb71:
  %t256 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t256, ptr %l124, !tbaa !27
  %t257 = load i64, ptr %l8, !tbaa !24
  store i64 %t257, ptr %l125, !tbaa !24
  %t258 = load i64, ptr %l7, !tbaa !24
  store i64 %t258, ptr %l126, !tbaa !24
  %t259 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t260 = extractvalue { i64, ptr } %t259, 0
  store i64 %t260, ptr %l127, !tbaa !24
  %t261 = load i64, ptr %l125, !tbaa !24
  %t262 = icmp sge i64 %t261, 0
  br i1 %t262, label %bb72, label %bb73
bb72:
  %t264 = load i64, ptr %l125, !tbaa !24
  %t265 = load i64, ptr %l126, !tbaa !24
  %t266 = icmp sle i64 %t264, %t265
  br i1 %t266, label %bb74, label %bb75
bb73:
  call void @__olang_check_failed(ptr @olang_loc_6056ece582ef2ce2_c67ea0947e494cde)
  unreachable
bb74:
  %t268 = load i64, ptr %l126, !tbaa !24
  %t269 = load i64, ptr %l127, !tbaa !24
  %t270 = icmp sle i64 %t268, %t269
  br i1 %t270, label %bb76, label %bb77
bb75:
  call void @__olang_check_failed(ptr @olang_loc_6056ece582ef2ce2_c67ea0947e494cde)
  unreachable
bb76:
  %t272 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !27
  %t274 = load i64, ptr %l125, !tbaa !24
  %t275 = load i64, ptr %l126, !tbaa !24
  %t276 = getelementptr i8, ptr %t273, i64 %t274
  %t277 = sub i64 %t275, %t274
  %t278 = insertvalue { i64, ptr } undef, i64 %t277, 0
  %t279 = insertvalue { i64, ptr } %t278, ptr %t276, 1
  %t281 = extractvalue { i64, ptr } %t279, 1
  %t282 = extractvalue { i64, ptr } %t279, 0
  %t283 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t282)
  call void @olang_textcopy(ptr %t283, ptr %t281, i64 %t282)
  %t284 = insertvalue { i64, ptr } undef, i64 %t282, 0
  %t285 = insertvalue { i64, ptr } %t284, ptr %t283, 1
  %t286 = load i64, ptr %l4, !tbaa !24
  %t288 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t285, 0
  %t290 = insertvalue { { i64, ptr }, i64 } %t288, i64 %t286, 1
  store { { i64, ptr }, i64 } %t290, ptr %rv
  br label %ret
bb77:
  call void @__olang_check_failed(ptr @olang_loc_6056ece582ef2ce2_c67ea0947e494cde)
  unreachable
ret:
  %rr = load { { i64, ptr }, i64 }, ptr %rv
  ret { { i64, ptr }, i64 } %rr
}

define dso_local i64 @compiler_2fgeneric_2echangedVals(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i1
  %l39 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %rv = alloca i64
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Binding", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t10 = icmp sgt i64 %t6, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  %t12 = load i64, ptr %l5, !tbaa !24
  %t14 = icmp sgt i64 %t12, 0
  br i1 %t14, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb6
bb3:
  %t16 = load i64, ptr %l4, !tbaa !24
  %t17 = load i64, ptr %l3, !tbaa !24
  %t20 = sub i64 %t16, %t17
  %t21 = load i64, ptr %l5, !tbaa !24
  %t24 = add i64 %t20, %t21
  %t26 = sub i64 %t24, 1
  %t27 = load i64, ptr %l5, !tbaa !24
  %t30 = sdiv i64 %t26, %t27
  store i64 %t30, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t32 = load i64, ptr %l17, !tbaa !24
  store i64 %t32, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l14, !tbaa !24
  store i64 %t33, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  %t34 = load i64, ptr %l6, !tbaa !24
  %t35 = sub i64 %t34, 1
  store i64 %t35, ptr %l26, !tbaa !24
  %t36 = load i64, ptr %l6, !tbaa !24
  %t37 = icmp slt i64 %t36, 2147483648
  %t38 = load i64, ptr %l7, !tbaa !24
  %t39 = icmp sge i64 %t38, 0
  %t42 = and i1 %t37, %t39
  store i1 %t42, ptr %l29, !tbaa !21
  br label %bb7
bb7:
  %t43 = load i64, ptr %l7, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb8, label %bb9
bb8:
  br label %bb15
bb9:
  br label %bb10
bb10:
  %t51 = load i64, ptr %l3, !tbaa !24
  %t52 = load i64, ptr %l7, !tbaa !24
  %t53 = load i64, ptr %l5, !tbaa !24
  %t56 = mul i64 %t52, %t53
  %t59 = add i64 %t51, %t56
  store i64 %t59, ptr %l8, !tbaa !24
  store { i64, ptr } %a0, ptr %l39, !tbaa !27
  %t62 = load i64, ptr %l8, !tbaa !24
  %t64 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = getelementptr i32, ptr %t65, i64 %t62
  %t67 = load i32, ptr %t66, !tbaa !33
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr %"compiler/generic:Binding", ptr %t68, i32 0, i32 2
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  store { i64, ptr } %t71, ptr %l43, !tbaa !27
  %t72 = load i64, ptr %l8, !tbaa !24
  %t74 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr i32, ptr %t75, i64 %t72
  %t77 = load i32, ptr %t76, !tbaa !33
  %t80 = icmp ne i32 %t67, %t77
  br i1 %t80, label %bb11, label %bb12
bb11:
  %t82 = load i64, ptr %l2, !tbaa !24
  %t85 = add i64 %t82, 1
  store i64 %t85, ptr %l2, !tbaa !24
  br label %bb13
bb12:
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t87 = load i64, ptr %l7, !tbaa !24
  %t90 = add i64 %t87, 1
  store i64 %t90, ptr %l7, !tbaa !24
  br label %bb7
bb15:
  %t92 = load i64, ptr %l2, !tbaa !24
  store i64 %t92, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eApply(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i1
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l26 = alloca i64
  %l30 = alloca i1
  %l31 = alloca { i64, ptr }
  %l36 = alloca i1
  %l38 = alloca i1
  %l41 = alloca i1
  %l45 = alloca i64
  %l46 = alloca i64
  %l49 = alloca i64
  %l51 = alloca i1
  %l52 = alloca i64
  %l55 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l68 = alloca i64
  %l71 = alloca i64
  %l89 = alloca i64
  %l95 = alloca i32
  %l103 = alloca i64
  %l106 = alloca i64
  %l128 = alloca i1
  %l131 = alloca i1
  %l132 = alloca i64
  %l134 = alloca i32
  %l137 = alloca { i64, ptr }
  %l140 = alloca i32
  %l142 = alloca i32
  %l146 = alloca i64
  %l149 = alloca { i64, ptr }
  %l153 = alloca i32
  %l154 = alloca i64
  %l155 = alloca ptr
  %l159 = alloca %"compiler/generic:varRow"
  %l160 = alloca i32
  %l161 = alloca i64
  %l165 = alloca i32
  %l166 = alloca i32
  %l170 = alloca ptr
  %l171 = alloca i32
  %l175 = alloca i32
  %l176 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2edeclVars(ptr %v0, ptr %t1, i32 %t2)
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/generic:Program", ptr %t5, i32 0, i32 2
  %t8 = load i32, ptr %l2, !tbaa !23
  %t11 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclParams(ptr %v0, ptr %t7, i32 %t8)
  store i64 %t11, ptr %l26
  br label %bb2
bb2:
  %t12 = load i64, ptr %l26, !tbaa !24
  store i64 %t12, ptr %l4, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t19, ptr %l31, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 0
  %t24 = sub i64 %t22, 1
  %t26 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr ptr, ptr %t27, i64 %t24
  %t29 = load ptr, ptr %t28, !tbaa !39
  %t31 = call i1 @compiler_2fgeneric_2eisErrsArg(ptr %v2, ptr %t29)
  store i1 %t31, ptr %l36
  br label %bb5
bb4:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb6
bb5:
  %t32 = load i1, ptr %l36, !tbaa !21
  store i1 %t32, ptr %l30, !tbaa !21
  br label %bb6
bb6:
  %t33 = load i1, ptr %l30, !tbaa !21
  store i1 %t33, ptr %l5, !tbaa !21
  %t34 = load i1, ptr %l5, !tbaa !21
  br i1 %t34, label %bb7, label %bb8
bb7:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i32, ptr %l2, !tbaa !23
  %t40 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eHasErrParam(ptr %v0, ptr %t36, i32 %t37)
  store i1 %t40, ptr %l41
  br label %bb9
bb8:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb10
bb9:
  %t41 = load i1, ptr %l41, !tbaa !21
  %t42 = xor i1 %t41, true
  store i1 %t42, ptr %l38, !tbaa !21
  br label %bb10
bb10:
  %t44 = load i1, ptr %l38, !tbaa !21
  br i1 %t44, label %bb11, label %bb12
bb11:
  %t45 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t45, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t47 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t49 = call i64 @compiler_2fgeneric_2eWrittenTypes(ptr %v2, { i64, ptr } %t47)
  store i64 %t49, ptr %l45
  br label %bb14
bb14:
  %t50 = load i64, ptr %l45, !tbaa !24
  store i64 %t50, ptr %l6, !tbaa !24
  %t51 = load i64, ptr %l6, !tbaa !24
  store i64 %t51, ptr %l46, !tbaa !24
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i32, ptr %l2, !tbaa !23
  %t56 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWrittenArity(ptr %v0, ptr %t52, i32 %t53)
  store i64 %t56, ptr %l49
  br label %bb15
bb15:
  %t57 = load i64, ptr %l46, !tbaa !24
  %t58 = load i64, ptr %l49, !tbaa !24
  %t59 = icmp sgt i64 %t57, %t58
  br i1 %t59, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb19
bb17:
  %t61 = load i64, ptr %l6, !tbaa !24
  store i64 %t61, ptr %l52, !tbaa !24
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load i32, ptr %l2, !tbaa !23
  %t66 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMinArity(ptr %v0, ptr %t62, i32 %t63)
  store i64 %t66, ptr %l55
  br label %bb18
bb18:
  %t67 = load i64, ptr %l52, !tbaa !24
  %t68 = load i64, ptr %l55, !tbaa !24
  %t69 = icmp slt i64 %t67, %t68
  store i1 %t69, ptr %l51, !tbaa !21
  br label %bb19
bb19:
  %t71 = load i1, ptr %l51, !tbaa !21
  br i1 %t71, label %bb20, label %bb21
bb20:
  %t72 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t72, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t74 = load i32, ptr %l2, !tbaa !23
  %t76 = call i64 @compiler_2fgeneric_2eDeclOwner(i32 %t74)
  store i64 %t76, ptr %l59
  br label %bb23
bb23:
  %t77 = load i64, ptr %l59, !tbaa !24
  store i64 %t77, ptr %l7, !tbaa !24
  %t78 = load i64, ptr %l4, !tbaa !24
  store i64 %t78, ptr %l60, !tbaa !24
  %t79 = load i64, ptr %l60, !tbaa !24
  %t80 = icmp sge i64 %t79, 0
  br i1 %t80, label %bb24, label %bb25
bb24:
  %t82 = load i64, ptr %l60, !tbaa !24
  %t83 = icmp sle i64 %t82, 2305843009213693951
  br i1 %t83, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_9ad358ce4cd92925_29c80ed6090eef61)
  unreachable
bb26:
  %t85 = load i64, ptr %l60, !tbaa !24
  %t86 = mul i64 %t85, 4
  %t87 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t86)
  %t88 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t87, 1
  store { i64, ptr } %t89, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t91 = load i64, ptr %l4, !tbaa !24
  store i64 %t91, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t93 = load i64, ptr %l10, !tbaa !24
  %t94 = load i64, ptr %l9, !tbaa !24
  %t97 = icmp sgt i64 %t93, %t94
  br i1 %t97, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_9ad358ce4cd92925_29c80ed6090eef61)
  unreachable
bb28:
  %t99 = load i64, ptr %l11, !tbaa !24
  %t101 = icmp sgt i64 %t99, 0
  br i1 %t101, label %bb30, label %bb31
bb29:
  store i64 0, ptr %l68, !tbaa !24
  br label %bb33
bb30:
  %t103 = load i64, ptr %l10, !tbaa !24
  %t104 = load i64, ptr %l9, !tbaa !24
  %t107 = sub i64 %t103, %t104
  %t108 = load i64, ptr %l11, !tbaa !24
  %t111 = add i64 %t107, %t108
  %t113 = sub i64 %t111, 1
  %t114 = load i64, ptr %l11, !tbaa !24
  %t117 = sdiv i64 %t113, %t114
  store i64 %t117, ptr %l71, !tbaa !24
  br label %bb32
bb31:
  store i64 0, ptr %l71, !tbaa !24
  br label %bb32
bb32:
  %t119 = load i64, ptr %l71, !tbaa !24
  store i64 %t119, ptr %l68, !tbaa !24
  br label %bb33
bb33:
  %t120 = load i64, ptr %l68, !tbaa !24
  store i64 %t120, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb34
bb34:
  %t121 = load i64, ptr %l13, !tbaa !24
  %t122 = load i64, ptr %l12, !tbaa !24
  %t125 = icmp slt i64 %t121, %t122
  %t127 = xor i1 %t125, true
  br i1 %t127, label %bb35, label %bb36
bb35:
  br label %bb40
bb36:
  br label %bb37
bb37:
  %t129 = load i64, ptr %l9, !tbaa !24
  %t130 = load i64, ptr %l13, !tbaa !24
  %t131 = load i64, ptr %l11, !tbaa !24
  %t134 = mul i64 %t130, %t131
  %t137 = add i64 %t129, %t134
  store i64 %t137, ptr %l14, !tbaa !24
  %t139 = load i64, ptr %l14, !tbaa !24
  store i64 %t139, ptr %l89, !tbaa !24
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/generic:Program", ptr %t140, i32 0, i32 2
  %t143 = load i64, ptr %l7, !tbaa !24
  %t144 = load i64, ptr %l14, !tbaa !24
  %t145 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t150 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eVar(ptr %v0, ptr %t142, i64 %t143, i64 %t144, i64 %t145)
  store i32 %t150, ptr %l95
  br label %bb38
bb38:
  %t151 = load i32, ptr %l95, !tbaa !23
  %t152 = load i64, ptr %l89, !tbaa !24
  %t153 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = getelementptr i32, ptr %t154, i64 %t152
  store i32 %t151, ptr %t155, !tbaa !33
  br label %bb39
bb39:
  %t156 = load i64, ptr %l13, !tbaa !24
  %t159 = add i64 %t156, 1
  store i64 %t159, ptr %l13, !tbaa !24
  br label %bb34
bb40:
  store i64 0, ptr %l15, !tbaa !24
  %t161 = load i64, ptr %l4, !tbaa !24
  store i64 %t161, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t163 = load i64, ptr %l16, !tbaa !24
  %t164 = load i64, ptr %l15, !tbaa !24
  %t167 = icmp sgt i64 %t163, %t164
  br i1 %t167, label %bb41, label %bb42
bb41:
  %t169 = load i64, ptr %l17, !tbaa !24
  %t171 = icmp sgt i64 %t169, 0
  br i1 %t171, label %bb43, label %bb44
bb42:
  store i64 0, ptr %l103, !tbaa !24
  br label %bb46
bb43:
  %t173 = load i64, ptr %l16, !tbaa !24
  %t174 = load i64, ptr %l15, !tbaa !24
  %t177 = sub i64 %t173, %t174
  %t178 = load i64, ptr %l17, !tbaa !24
  %t181 = add i64 %t177, %t178
  %t183 = sub i64 %t181, 1
  %t184 = load i64, ptr %l17, !tbaa !24
  %t187 = sdiv i64 %t183, %t184
  store i64 %t187, ptr %l106, !tbaa !24
  br label %bb45
bb44:
  store i64 0, ptr %l106, !tbaa !24
  br label %bb45
bb45:
  %t189 = load i64, ptr %l106, !tbaa !24
  store i64 %t189, ptr %l103, !tbaa !24
  br label %bb46
bb46:
  %t190 = load i64, ptr %l103, !tbaa !24
  store i64 %t190, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb47
bb47:
  %t191 = load i64, ptr %l19, !tbaa !24
  %t192 = load i64, ptr %l18, !tbaa !24
  %t195 = icmp slt i64 %t191, %t192
  %t197 = xor i1 %t195, true
  br i1 %t197, label %bb48, label %bb49
bb48:
  br label %bb71
bb49:
  br label %bb50
bb50:
  %t199 = load i64, ptr %l15, !tbaa !24
  %t200 = load i64, ptr %l19, !tbaa !24
  %t201 = load i64, ptr %l17, !tbaa !24
  %t204 = mul i64 %t200, %t201
  %t207 = add i64 %t199, %t204
  store i64 %t207, ptr %l20, !tbaa !24
  %t209 = load i64, ptr %l20, !tbaa !24
  %t210 = load i64, ptr %l4, !tbaa !24
  %t212 = sub i64 %t210, 1
  %t215 = icmp eq i64 %t209, %t212
  br i1 %t215, label %bb51, label %bb52
bb51:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load i32, ptr %l2, !tbaa !23
  %t221 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eHasErrParam(ptr %v0, ptr %t217, i32 %t218)
  store i1 %t221, ptr %l131
  br label %bb53
bb52:
  store i1 false, ptr %l128, !tbaa !21
  br label %bb54
bb53:
  %t222 = load i1, ptr %l131, !tbaa !21
  store i1 %t222, ptr %l128, !tbaa !21
  br label %bb54
bb54:
  %t223 = load i1, ptr %l128, !tbaa !21
  br i1 %t223, label %bb55, label %bb56
bb55:
  %t224 = load i64, ptr %l20, !tbaa !24
  store i64 %t224, ptr %l132, !tbaa !24
  %t225 = load i1, ptr %l5, !tbaa !21
  br i1 %t225, label %bb57, label %bb58
bb56:
  %t227 = load i64, ptr %l20, !tbaa !24
  %t228 = load i64, ptr %l6, !tbaa !24
  %t231 = icmp slt i64 %t227, %t228
  br i1 %t231, label %bb62, label %bb63
bb57:
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t234 = load ptr, ptr %l1, !tbaa !29
  %t235 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t235, ptr %l137, !tbaa !27
  %t236 = load i64, ptr %l6, !tbaa !24
  %t238 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t239 = load ptr, ptr %t238, !tbaa !27
  %t240 = getelementptr ptr, ptr %t239, i64 %t236
  %t241 = load ptr, ptr %t240, !tbaa !39
  %t245 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eerrsArg(ptr %v0, ptr %v1, ptr %v2, ptr %t233, ptr %t234, ptr %t241)
  store i32 %t245, ptr %l140
  br label %bb59
bb58:
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t248 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrSetOf(ptr %v0, ptr %t246, i32 0)
  store i32 %t248, ptr %l142
  br label %bb60
bb59:
  %t249 = load i32, ptr %l140, !tbaa !23
  store i32 %t249, ptr %l134, !tbaa !23
  br label %bb61
bb60:
  %t250 = load i32, ptr %l142, !tbaa !23
  store i32 %t250, ptr %l134, !tbaa !23
  br label %bb61
bb61:
  %t251 = load i32, ptr %l134, !tbaa !23
  %t252 = load i64, ptr %l132, !tbaa !24
  %t253 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t254 = load ptr, ptr %t253, !tbaa !27
  %t255 = getelementptr i32, ptr %t254, i64 %t252
  store i32 %t251, ptr %t255, !tbaa !33
  br label %bb69
bb62:
  %t256 = load i64, ptr %l20, !tbaa !24
  store i64 %t256, ptr %l146, !tbaa !24
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load ptr, ptr %l1, !tbaa !29
  %t259 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t259, ptr %l149, !tbaa !27
  %t260 = load i64, ptr %l20, !tbaa !24
  %t262 = getelementptr { i64, ptr }, ptr %l149, i32 0, i32 1
  %t263 = load ptr, ptr %t262, !tbaa !27
  %t264 = getelementptr ptr, ptr %t263, i64 %t260
  %t265 = load ptr, ptr %t264, !tbaa !39
  %t270 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %t257, ptr %t258, ptr %t265)
  store i32 %t270, ptr %l153
  br label %bb64
bb63:
  %t271 = load i64, ptr %l20, !tbaa !24
  store i64 %t271, ptr %l154, !tbaa !24
  %t272 = load ptr, ptr %l0, !tbaa !29
  store ptr %t272, ptr %l155, !tbaa !29
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t274 = load i64, ptr %l7, !tbaa !24
  %t275 = load i64, ptr %l20, !tbaa !24
  %t279 = call %"compiler/generic:varRow" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarAt(ptr %v0, ptr %t273, i64 %t274, i64 %t275)
  store %"compiler/generic:varRow" %t279, ptr %l159
  br label %bb65
bb64:
  %t280 = load i32, ptr %l153, !tbaa !23
  %t281 = load i64, ptr %l146, !tbaa !24
  %t282 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t283 = load ptr, ptr %t282, !tbaa !27
  %t284 = getelementptr i32, ptr %t283, i64 %t281
  store i32 %t280, ptr %t284, !tbaa !33
  br label %bb68
bb65:
  %t285 = getelementptr %"compiler/generic:varRow", ptr %l159, i32 0, i32 4
  %t286 = load i32, ptr %t285, !tbaa !23
  store i32 %t286, ptr %l160, !tbaa !23
  %t287 = load i64, ptr %l7, !tbaa !24
  store i64 %t287, ptr %l161, !tbaa !24
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t290 = getelementptr %"compiler/generic:Program", ptr %t288, i32 0, i32 2
  %t291 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t294 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t290, { i64, ptr } %t291)
  store i32 %t294, ptr %l165
  br label %bb66
bb66:
  %t295 = load ptr, ptr %l155, !tbaa !29
  %t296 = load i32, ptr %l160, !tbaa !23
  %t297 = load i64, ptr %l161, !tbaa !24
  %t298 = load i32, ptr %l165, !tbaa !23
  %t299 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %t295, i32 %t296, i64 %t297, i32 %t298)
  store i32 %t299, ptr %l166
  br label %bb67
bb67:
  %t300 = load i32, ptr %l166, !tbaa !23
  %t301 = load i64, ptr %l154, !tbaa !24
  %t302 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t303 = load ptr, ptr %t302, !tbaa !27
  %t304 = getelementptr i32, ptr %t303, i64 %t301
  store i32 %t300, ptr %t304, !tbaa !33
  br label %bb68
bb68:
  br label %bb69
bb69:
  br label %bb70
bb70:
  %t305 = load i64, ptr %l19, !tbaa !24
  %t308 = add i64 %t305, 1
  store i64 %t308, ptr %l19, !tbaa !24
  br label %bb47
bb71:
  %t310 = load ptr, ptr %l0, !tbaa !29
  store ptr %t310, ptr %l170, !tbaa !29
  %t311 = load i32, ptr %l2, !tbaa !23
  store i32 %t311, ptr %l171, !tbaa !23
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t314 = getelementptr %"compiler/generic:Program", ptr %t312, i32 0, i32 2
  %t315 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t318 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t314, { i64, ptr } %t315)
  store i32 %t318, ptr %l175
  br label %bb72
bb72:
  %t319 = load ptr, ptr %l170, !tbaa !29
  %t320 = load i32, ptr %l171, !tbaa !23
  %t321 = load i32, ptr %l175, !tbaa !23
  %t322 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstance(ptr %v0, ptr %t319, i32 %t320, i32 %t321)
  store i32 %t322, ptr %l176
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s0)
  %t323 = load i32, ptr %l176, !tbaa !23
  store i32 %t323, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %l12 = alloca i32
  %l17 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca ptr
  %l25 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l40 = alloca i1
  %l46 = alloca { i64, ptr }
  %l56 = alloca i32
  %l57 = alloca { i64, ptr }
  %l61 = alloca i32
  %l63 = alloca ptr
  %l67 = alloca i32
  %l69 = alloca i32
  %l70 = alloca i32
  %l74 = alloca i32
  %l76 = alloca i64
  %l77 = alloca i64
  %l82 = alloca ptr
  %l83 = alloca i32
  %l84 = alloca i32
  %l90 = alloca { i64, ptr }
  %l91 = alloca i32
  %l92 = alloca i32
  %l93 = alloca ptr
  %l96 = alloca %"compiler/generic:Context"
  %l100 = alloca i32
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca i32
  %t157 = alloca i64
  %t201 = alloca %"compiler/generic:Context", align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l1, !tbaa !23
  %t7 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t7, ptr %l12
  br label %bb1
bb1:
  %t8 = load i32, ptr %l12, !range !{i32 0, i32 33}
  %t10 = trunc i64 18 to i32
  %t11 = icmp eq i32 %t8, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t15, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l17, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/generic:Program", ptr %t18, i32 0, i32 2
  %t21 = load i32, ptr %l1, !tbaa !23
  %t24 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t20, i32 %t21)
  store i32 %t24, ptr %l21
  br label %bb5
bb5:
  %t25 = load ptr, ptr %l17, !tbaa !29
  %t26 = load i32, ptr %l21, !tbaa !23
  %t27 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etypeDecl(ptr %v0, ptr %v0, ptr %t25, i32 %t26)
  store ptr %t27, ptr %l22
  br label %bb6
bb6:
  %t28 = load ptr, ptr %l22, !tbaa !29
  store ptr %t28, ptr %l3, !tbaa !29
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t31 = icmp eq ptr %t29, null
  br i1 %t31, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb9
bb8:
  %t33 = load ptr, ptr %l3, !tbaa !29
  %t35 = getelementptr %"compiler/ast:TypeDecl", ptr %t33, i32 0, i32 3
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = icmp eq ptr %t36, null
  store i1 %t38, ptr %l25, !tbaa !21
  br label %bb9
bb9:
  %t40 = load i1, ptr %l25, !tbaa !21
  br i1 %t40, label %bb10, label %bb11
bb10:
  %t41 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t41, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t43 = load ptr, ptr %l3, !tbaa !29
  %t45 = getelementptr %"compiler/ast:TypeDecl", ptr %t43, i32 0, i32 3
  %t46 = load ptr, ptr %t45, !tbaa !29
  store ptr %t46, ptr %l4, !tbaa !29
  %t48 = load ptr, ptr %l4, !tbaa !29
  store ptr %t48, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t49 = load ptr, ptr %l32, !tbaa !29
  %t50 = icmp ne ptr %t49, null
  br i1 %t50, label %bb13, label %bb14
bb13:
  %t52 = load ptr, ptr %l32, !tbaa !29
  %t53 = load i64, ptr %t52, !range !{i64 0, i64 5}
  %t55 = icmp eq i64 %t53, 1
  store i1 %t55, ptr %l33, !tbaa !21
  br label %bb14
bb14:
  %t56 = load i1, ptr %l33, !tbaa !21
  br i1 %t56, label %bb15, label %bb16
bb15:
  %t57 = load ptr, ptr %l4, !tbaa !29
  %t59 = getelementptr { i64, [6 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { { i64, ptr }, ptr }, ptr %t59, i32 0, i32 0
  %t61 = load { i64, ptr }, ptr %t60
  store { i64, ptr } %t61, ptr %l5, !tbaa !27
  br label %bb17
bb16:
  br label %bb45
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t63 = load i64, ptr %l2, !tbaa !24
  %t65 = icmp slt i64 %t63, 0
  br i1 %t65, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb20
bb19:
  %t67 = load i64, ptr %l2, !tbaa !24
  %t68 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t68, 0
  %t73 = icmp sge i64 %t67, %t70
  store i1 %t73, ptr %l40, !tbaa !21
  br label %bb20
bb20:
  %t75 = load i1, ptr %l40, !tbaa !21
  br i1 %t75, label %bb21, label %bb22
bb21:
  %t76 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s3)
  store i32 %t76, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t78 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t78, ptr %l46, !tbaa !27
  %t79 = load i64, ptr %l2, !tbaa !24
  %t81 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr ptr, ptr %t82, i64 %t79
  %t84 = load ptr, ptr %t83, !tbaa !39
  %t86 = getelementptr %"compiler/ast:CaseDecl", ptr %t84, i32 0, i32 2
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  store { i64, ptr } %t87, ptr %l6, !tbaa !27
  %t89 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t89, 0
  %t93 = icmp eq i64 %t91, 0
  br i1 %t93, label %bb24, label %bb25
bb24:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/generic:Program", ptr %t95, i32 0, i32 2
  %t98 = load i32, ptr %l1, !tbaa !23
  %t101 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t97, i32 0, i32 %t98, i32 0, i32 0, i64 0, i1 false, i32 0, i64 0)
  store i32 %t101, ptr %l56
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_scope_close(ptr %s3)
  %t102 = load i32, ptr %l56, !tbaa !23
  store i32 %t102, ptr %rv
  br label %ret
bb27:
  %t103 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t103, ptr %l57, !tbaa !27
  %t104 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr ptr, ptr %t105, i64 0
  %t107 = load ptr, ptr %t106, !tbaa !39
  %t109 = getelementptr %"compiler/ast:Param", ptr %t107, i32 0, i32 2
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = icmp eq ptr %t110, null
  br i1 %t112, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s6
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/generic:Program", ptr %t114, i32 0, i32 10
  store ptr %t116, ptr %l63, !tbaa !29
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/generic:Program", ptr %t117, i32 0, i32 2
  %t120 = load i32, ptr %l1, !tbaa !23
  %t123 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t119, i32 %t120)
  store i32 %t123, ptr %l67
  br label %bb30
bb29:
  br label %bb42
bb30:
  %t124 = load i32, ptr %l67, !tbaa !23
  %t125 = sext i32 %t124 to i64
  %t126 = load ptr, ptr %l63, !tbaa !29
  %t128 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aListId_3e__H9cb5d99387f926677a92c13412f9a8b2(ptr %v0, ptr %t126, i64 %t125)
  %t129 = extractvalue { i32, i32 } %t128, 1
  %t130 = extractvalue { i32, i32 } %t128, 0
  store i32 %t130, ptr %l70
  %t131 = icmp ne i32 %t130, 0
  br i1 %t131, label %bb32, label %ok.132, !prof !99
ok.132:
  store i32 %t129, ptr %l69
  br label %bb31
bb31:
  %t133 = load i32, ptr %l69, !tbaa !23
  store i32 %t133, ptr %l61, !tbaa !23
  br label %bb35
bb32:
  br label %bb33
bb33:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t135, 0
  %t140 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunknowns(ptr %v0, ptr %t134, i64 %t137)
  store i32 %t140, ptr %l74
  br label %bb34
bb34:
  %t141 = load i32, ptr %l74, !tbaa !23
  store i32 %t141, ptr %l61, !tbaa !23
  br label %bb35
bb35:
  %t142 = load i32, ptr %l61, !tbaa !23
  store i32 %t142, ptr %l7, !tbaa !23
  %t143 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t143, 0
  store i64 %t145, ptr %l76, !tbaa !24
  %t146 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  store i64 %t146, ptr %l77, !tbaa !24
  %t147 = load i64, ptr %l76, !tbaa !24
  %t148 = icmp sge i64 %t147, 0
  br i1 %t148, label %bb36, label %bb37
bb36:
  %t150 = load i64, ptr %l76, !tbaa !24
  %t151 = icmp sle i64 %t150, 1152921504606846975
  br i1 %t151, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_f9e5e93c78b56bbe_6af7701bc585ea2)
  unreachable
bb38:
  %t153 = load i64, ptr %l76, !tbaa !24
  %t154 = mul i64 %t153, 8
  %t155 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t154)
  %t156 = load i64, ptr %l77, !tbaa !24
  store i64 0, ptr %t157
  br label %fill.158
fill.158:
  %t161 = load i64, ptr %t157
  %t162 = icmp slt i64 %t161, %t153
  br i1 %t162, label %fillb.159, label %filld.160
fillb.159:
  %t163 = getelementptr i64, ptr %t155, i64 %t161
  store i64 %t156, ptr %t163
  %t164 = add i64 %t161, 1
  store i64 %t164, ptr %t157
  br label %fill.158
filld.160:
  %t165 = insertvalue { i64, ptr } undef, i64 %t153, 0
  %t166 = insertvalue { i64, ptr } %t165, ptr %t155, 1
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/generic:Program", ptr %t168, i32 0, i32 2
  store ptr %t170, ptr %l82, !tbaa !29
  %t171 = load i32, ptr %l7, !tbaa !23
  store i32 %t171, ptr %l83, !tbaa !23
  %t172 = load i32, ptr %l1, !tbaa !23
  store i32 %t172, ptr %l84, !tbaa !23
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/generic:Program", ptr %t173, i32 0, i32 2
  %t176 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t178 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  %t179 = mul i64 1, 8
  %t180 = call ptr @__olang_scope_alloc_zeroed(ptr %s6, i64 %t179)
  %t181 = insertvalue { i64, ptr } undef, i64 1, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t180, 1
  store { i64, ptr } %t182, ptr %l90, !tbaa !27
  %t184 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !27
  %t186 = getelementptr i64, ptr %t185, i64 0
  store i64 %t178, ptr %t186, !tbaa !34
  %t190 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t191 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopes(ptr %v0, ptr %s6, ptr %s6, ptr %t175, i64 %t176, { i64, ptr } %t166, { i64, ptr } %t190)
  store i32 %t191, ptr %l91
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_f9e5e93c78b56bbe_6af7701bc585ea2)
  unreachable
bb40:
  %t192 = load ptr, ptr %l82, !tbaa !29
  %t193 = load i32, ptr %l83, !tbaa !23
  %t194 = load i32, ptr %l84, !tbaa !23
  %t195 = load i32, ptr %l91, !tbaa !23
  %t196 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t192, i32 %t193, i32 %t194, i32 0, i32 %t195, i64 0, i1 false, i32 0, i64 0)
  store i32 %t196, ptr %l92
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s3)
  %t197 = load i32, ptr %l92, !tbaa !23
  store i32 %t197, ptr %rv
  br label %ret
bb42:
  %t198 = load ptr, ptr %l0, !tbaa !29
  store ptr %t198, ptr %l93, !tbaa !29
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceContext(ptr %t201, ptr %v0, ptr %s3, ptr %t199, i32 %t200)
  call void @llvm.memmove.p0.p0.i64(ptr %l96, ptr %t201, i64 160, i1 false)
  br label %bb43
bb43:
  %t204 = call ptr @__olang_scope_alloc_a(ptr %s3, i64 160, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t204, ptr %l96, i64 160, i1 false)
  %t205 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t206 = load i32, ptr %l1, !tbaa !23
  %t207 = load ptr, ptr %l93, !tbaa !29
  %t211 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eparamsSig(ptr %v0, ptr %s3, ptr %v0, ptr %s3, ptr %t207, ptr %t204, { i64, ptr } %t205, ptr null, i32 %t206)
  store i32 %t211, ptr %l100
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s3)
  %t212 = load i32, ptr %l100, !tbaa !23
  store i32 %t212, ptr %rv
  br label %ret
bb45:
  br i1 true, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  %t213 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t213, ptr %rv
  br label %ret
bb49:
  call void @__olang_check_failed(ptr @olang_loc_2d8c89c88aa67454_7b49ff00081a1220)
  unreachable
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrSetUnion(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l35 = alloca ptr
  %l39 = alloca i32
  %l40 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l57 = alloca ptr
  %l59 = alloca { i64, ptr }
  %l60 = alloca i32
  %l61 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l12
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l3
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/generic:Program", ptr %t3, i32 0, i32 2
  store ptr %t5, ptr %l14, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/generic:Program", ptr %t6, i32 0, i32 2
  %t12 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %t8, i32 %a1)
  store i32 %t12, ptr %l18
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l14, !tbaa !29
  %t14 = load i32, ptr %l18, !tbaa !23
  %t15 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t13, i32 %t14)
  store { i64, ptr } %t15, ptr %l19
  br label %bb3
bb3:
  %t16 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t16, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  store i64 %t19, ptr %l6, !tbaa !24
  br label %bb4
bb4:
  %t21 = load i64, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l6, !tbaa !24
  %t25 = icmp slt i64 %t21, %t22
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb5, label %bb6
bb5:
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t29 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t29, ptr %l26, !tbaa !27
  %t30 = load i64, ptr %l5, !tbaa !24
  %t32 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr i32, ptr %t33, i64 %t30
  %t35 = load i32, ptr %t34, !tbaa !33
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l3, i32 %t35)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = add i64 %t40, 1
  store i64 %t43, ptr %l5, !tbaa !24
  br label %bb4
bb10:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/generic:Program", ptr %t45, i32 0, i32 2
  store ptr %t47, ptr %l35, !tbaa !29
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/generic:Program", ptr %t48, i32 0, i32 2
  %t54 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %t50, i32 %a2)
  store i32 %t54, ptr %l39
  br label %bb11
bb11:
  %t55 = load ptr, ptr %l35, !tbaa !29
  %t56 = load i32, ptr %l39, !tbaa !23
  %t57 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t55, i32 %t56)
  store { i64, ptr } %t57, ptr %l40
  br label %bb12
bb12:
  %t58 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t58, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t59 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t59, 0
  store i64 %t61, ptr %l10, !tbaa !24
  br label %bb13
bb13:
  %t63 = load i64, ptr %l9, !tbaa !24
  %t64 = load i64, ptr %l10, !tbaa !24
  %t67 = icmp slt i64 %t63, %t64
  %t69 = xor i1 %t67, true
  br i1 %t69, label %bb14, label %bb15
bb14:
  br label %bb19
bb15:
  br label %bb16
bb16:
  %t71 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t71, ptr %l47, !tbaa !27
  %t72 = load i64, ptr %l9, !tbaa !24
  %t74 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr i32, ptr %t75, i64 %t72
  %t77 = load i32, ptr %t76, !tbaa !33
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l3, i32 %t77)
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t82 = load i64, ptr %l9, !tbaa !24
  %t85 = add i64 %t82, 1
  store i64 %t85, ptr %l9, !tbaa !24
  br label %bb13
bb19:
  %t87 = load ptr, ptr %l0, !tbaa !29
  store ptr %t87, ptr %l55, !tbaa !29
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/generic:Program", ptr %t88, i32 0, i32 2
  store ptr %t90, ptr %l57, !tbaa !29
  %t92 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %s0, ptr %l3)
  store { i64, ptr } %t92, ptr %l59
  br label %bb20
bb20:
  %t93 = load ptr, ptr %l57, !tbaa !29
  %t94 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t95 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t93, { i64, ptr } %t94)
  store i32 %t95, ptr %l60
  br label %bb21
bb21:
  %t96 = load ptr, ptr %l55, !tbaa !29
  %t97 = load i32, ptr %l60, !tbaa !23
  %t98 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrSetOf(ptr %v0, ptr %t96, i32 %t97)
  store i32 %t98, ptr %l61
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t99 = load i32, ptr %l61, !tbaa !23
  store i32 %t99, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrValOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l24 = alloca i32
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca { i64, ptr }
  %l39 = alloca i1
  %l48 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l53 = alloca i64
  %l57 = alloca i64
  %l60 = alloca i64
  %l79 = alloca ptr
  %l82 = alloca i32
  %l83 = alloca i32
  %l88 = alloca ptr
  %l91 = alloca i32
  %l92 = alloca i32
  %l93 = alloca ptr
  %l97 = alloca i32
  %l98 = alloca { i64, ptr }
  %l102 = alloca i64
  %l104 = alloca i64
  %l108 = alloca ptr
  %l111 = alloca i32
  %l112 = alloca i64
  %l124 = alloca { i64, ptr }
  %l129 = alloca ptr
  %l133 = alloca i32
  %l134 = alloca i32
  %l138 = alloca i32
  %l141 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l150 = alloca { i64, ptr }
  %l153 = alloca ptr
  %l157 = alloca i32
  %l158 = alloca i32
  %l168 = alloca i64
  %l171 = alloca ptr
  %l172 = alloca i32
  %l174 = alloca ptr
  %l176 = alloca ptr
  %l178 = alloca { i64, ptr }
  %l179 = alloca i32
  %l180 = alloca i32
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l25
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  store { i64, ptr } %a1, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l4, !tbaa !24
  %t10 = load i64, ptr %l5, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb14
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t17, ptr %l33, !tbaa !27
  %t18 = load i64, ptr %l4, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i32, ptr %t21, i64 %t18
  %t23 = load i32, ptr %t22, !tbaa !33
  store i32 %t23, ptr %l6, !tbaa !23
  %t25 = load i32, ptr %l6, !tbaa !23
  %t26 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t29 = icmp ne i32 %t25, %t26
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t31 = load i32, ptr %l6, !tbaa !23
  %t32 = load i32, ptr @G_2ecompiler_2ftypes_2eDefaultErrT, !tbaa !23
  %t35 = icmp ne i32 %t31, %t32
  store i1 %t35, ptr %l39, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb8
bb8:
  %t37 = load i1, ptr %l39, !tbaa !21
  br i1 %t37, label %bb9, label %bb10
bb9:
  %t38 = load i32, ptr %l6, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l2, i32 %t38)
  br label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t41 = load i64, ptr %l4, !tbaa !24
  %t44 = add i64 %t41, 1
  store i64 %t44, ptr %l4, !tbaa !24
  br label %bb2
bb14:
  %t46 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t46, ptr %l48
  br label %bb15
bb15:
  %t47 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l48
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t47, ptr %l7
  %t48 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emergeEntries(ptr %v0, ptr %s0, ptr %s0, ptr %t48, ptr %l2, ptr %l7)
  br label %bb16
bb16:
  store i64 0, ptr %l8, !tbaa !24
  %t53 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l7)
  store i64 %t53, ptr %l53
  br label %bb17
bb17:
  %t54 = load i64, ptr %l53, !tbaa !24
  store i64 %t54, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t55 = load i64, ptr %l9, !tbaa !24
  %t56 = load i64, ptr %l8, !tbaa !24
  %t59 = icmp sgt i64 %t55, %t56
  br i1 %t59, label %bb18, label %bb19
bb18:
  %t61 = load i64, ptr %l10, !tbaa !24
  %t63 = icmp sgt i64 %t61, 0
  br i1 %t63, label %bb20, label %bb21
bb19:
  store i64 0, ptr %l57, !tbaa !24
  br label %bb23
bb20:
  %t65 = load i64, ptr %l9, !tbaa !24
  %t66 = load i64, ptr %l8, !tbaa !24
  %t69 = sub i64 %t65, %t66
  %t70 = load i64, ptr %l10, !tbaa !24
  %t73 = add i64 %t69, %t70
  %t75 = sub i64 %t73, 1
  %t76 = load i64, ptr %l10, !tbaa !24
  %t79 = sdiv i64 %t75, %t76
  store i64 %t79, ptr %l60, !tbaa !24
  br label %bb22
bb21:
  store i64 0, ptr %l60, !tbaa !24
  br label %bb22
bb22:
  %t81 = load i64, ptr %l60, !tbaa !24
  store i64 %t81, ptr %l57, !tbaa !24
  br label %bb23
bb23:
  %t82 = load i64, ptr %l57, !tbaa !24
  store i64 %t82, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s6
  %t83 = load i64, ptr %l12, !tbaa !24
  %t84 = load i64, ptr %l11, !tbaa !24
  %t87 = icmp slt i64 %t83, %t84
  %t89 = xor i1 %t87, true
  br i1 %t89, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s6)
  br label %bb47
bb26:
  br label %bb27
bb27:
  %t91 = load i64, ptr %l8, !tbaa !24
  %t92 = load i64, ptr %l12, !tbaa !24
  %t93 = load i64, ptr %l10, !tbaa !24
  %t96 = mul i64 %t92, %t93
  %t99 = add i64 %t91, %t96
  store i64 %t99, ptr %l13, !tbaa !24
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/generic:Program", ptr %t101, i32 0, i32 2
  store ptr %t103, ptr %l79, !tbaa !29
  %t104 = load i64, ptr %l13, !tbaa !24
  %t107 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l7, i64 %t104)
  store i32 %t107, ptr %l82
  br label %bb28
bb28:
  %t108 = load ptr, ptr %l79, !tbaa !29
  %t109 = load i32, ptr %l82, !tbaa !23
  %t110 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t108, i32 %t109)
  store i32 %t110, ptr %l83
  br label %bb29
bb29:
  %t111 = load i32, ptr %l83, !range !{i32 0, i32 33}
  %t113 = trunc i64 28 to i32
  %t114 = icmp eq i32 %t111, %t113
  %t116 = xor i1 %t114, true
  br i1 %t116, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s6)
  br label %bb46
bb31:
  br label %bb32
bb32:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/generic:Program", ptr %t118, i32 0, i32 2
  store ptr %t120, ptr %l88, !tbaa !29
  %t121 = load i64, ptr %l13, !tbaa !24
  %t124 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l7, i64 %t121)
  store i32 %t124, ptr %l91
  br label %bb33
bb33:
  %t125 = load ptr, ptr %l88, !tbaa !29
  %t126 = load i32, ptr %l91, !tbaa !23
  %t127 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t125, i32 %t126)
  store i32 %t127, ptr %l92
  br label %bb34
bb34:
  %t128 = load i32, ptr %l92, !tbaa !23
  store i32 %t128, ptr %l14, !tbaa !23
  %t129 = load ptr, ptr %l0, !tbaa !29
  store ptr %t129, ptr %l93, !tbaa !29
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/generic:Program", ptr %t130, i32 0, i32 2
  %t133 = load i32, ptr %l14, !tbaa !23
  %t136 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t132, i32 %t133)
  store i32 %t136, ptr %l97
  br label %bb35
bb35:
  %t137 = load ptr, ptr %l93, !tbaa !29
  %t138 = load i32, ptr %l97, !tbaa !23
  %t139 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %s6, ptr %t137, i32 %t138)
  store { i64, ptr } %t139, ptr %l98
  br label %bb36
bb36:
  %t140 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t140, 0
  store i64 %t141, ptr %l15, !tbaa !24
  %t143 = load i64, ptr %l15, !tbaa !24
  %t145 = icmp sge i64 %t143, 64
  br i1 %t145, label %bb37, label %bb38
bb37:
  %t147 = sub i64 0, 1
  store i64 %t147, ptr %l102, !tbaa !65
  br label %bb39
bb38:
  %t149 = load i64, ptr %l15, !tbaa !24
  store i64 %t149, ptr %l104, !tbaa !24
  %t150 = load i64, ptr %l104, !tbaa !24
  %t151 = load i64, ptr %l104, !tbaa !24
  %t152 = shl i64 1, %t151
  %t154 = sub i64 %t152, 1
  store i64 %t154, ptr %l102, !tbaa !65
  br label %bb39
bb39:
  %t156 = load i64, ptr %l102, !tbaa !65
  store i64 %t156, ptr %l16, !tbaa !65
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/generic:Program", ptr %t157, i32 0, i32 2
  store ptr %t159, ptr %l108, !tbaa !29
  %t160 = load i64, ptr %l13, !tbaa !24
  %t163 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l7, i64 %t160)
  store i32 %t163, ptr %l111
  br label %bb40
bb40:
  %t164 = load ptr, ptr %l108, !tbaa !29
  %t165 = load i32, ptr %l111, !tbaa !23
  %t166 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t164, i32 %t165)
  store i64 %t166, ptr %l112
  br label %bb41
bb41:
  %t167 = load i64, ptr %l16, !tbaa !65
  %t168 = load i64, ptr %l112, !tbaa !65
  %t170 = and i64 %t168, %t167
  %t171 = load i64, ptr %l16, !tbaa !65
  %t174 = icmp eq i64 %t170, %t171
  br i1 %t174, label %bb42, label %bb43
bb42:
  %t176 = load i64, ptr %l13, !tbaa !24
  %t177 = load i32, ptr %l14, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eSetAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l7, i64 %t176, i32 %t177)
  br label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s6)
  br label %bb46
bb46:
  %t181 = load i64, ptr %l12, !tbaa !24
  %t184 = add i64 %t181, 1
  store i64 %t184, ptr %l12, !tbaa !24
  br label %bb24
bb47:
  %t187 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %s0, ptr %l7)
  store { i64, ptr } %t187, ptr %l124
  br label %bb48
bb48:
  %t188 = load { i64, ptr }, ptr %l124, !tbaa !27
  store { i64, ptr } %t188, ptr %l17, !tbaa !27
  %t189 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t192 = ptrtoint ptr %t191 to i64
  %t193 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 %t192, i64 8)
  %t194 = getelementptr { ptr, ptr }, ptr %t193, i32 0, i32 0
  store ptr %t190, ptr %t194, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t196 = call ptr @__olang_scope_hold(ptr %v0)
  %t197 = getelementptr { ptr, ptr }, ptr %t193, i32 0, i32 1
  store ptr %t196, ptr %t197, !tbaa !28
  %t198 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_15, 0
  %t199 = insertvalue { ptr, ptr } %t198, ptr %t193, 1
  %t202 = extractvalue { ptr, ptr } %t199, 0
  %t203 = extractvalue { ptr, ptr } %t199, 1
  call void @std_2fprelude_2farray_2eArray_3ccompiler_2ftypes_3aTypeId_3e_2eSort_3ccompiler_2ftypes_3aTypeId_2c_20_3f_3e(ptr %s0, ptr %v0, { i64, ptr } %t189, ptr %t202, ptr %t203)
  br label %bb49
bb49:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = getelementptr %"compiler/generic:Program", ptr %t204, i32 0, i32 2
  store ptr %t206, ptr %l129, !tbaa !29
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t209 = getelementptr %"compiler/generic:Program", ptr %t207, i32 0, i32 2
  %t210 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t213 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t209, { i64, ptr } %t210)
  store i32 %t213, ptr %l133
  br label %bb50
bb50:
  %t214 = load ptr, ptr %l129, !tbaa !29
  %t215 = load i32, ptr %l133, !tbaa !23
  %t216 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrVal(ptr %v0, ptr %t214, i32 %t215)
  store i32 %t216, ptr %l134
  br label %bb51
bb51:
  %t217 = load i32, ptr %l134, !tbaa !23
  store i32 %t217, ptr %l18, !tbaa !23
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t220 = getelementptr %"compiler/generic:Program", ptr %t218, i32 0, i32 2
  %t221 = load i32, ptr %l18, !tbaa !23
  %t224 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrRepr(ptr %v0, ptr %t220, i32 %t221)
  store i32 %t224, ptr %l138
  br label %bb52
bb52:
  %t225 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t226 = load i32, ptr %l138, !tbaa !23
  %t228 = icmp eq i32 %t226, %t225
  br i1 %t228, label %bb53, label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s10
  %t230 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s10, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t230, ptr %l141
  br label %bb55
bb54:
  br label %bb77
bb55:
  %t231 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l141
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t231, ptr %l19
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s10, ptr %l19, i32 5)
  br label %bb56
bb56:
  %t233 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t233, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t235 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t237 = extractvalue { i64, ptr } %t235, 0
  store i64 %t237, ptr %l22, !tbaa !24
  br label %bb57
bb57:
  %t239 = load i64, ptr %l21, !tbaa !24
  %t240 = load i64, ptr %l22, !tbaa !24
  %t243 = icmp slt i64 %t239, %t240
  %t245 = xor i1 %t243, true
  br i1 %t245, label %bb58, label %bb59
bb58:
  br label %bb68
bb59:
  br label %bb60
bb60:
  %t247 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t247, ptr %l150, !tbaa !27
  %t248 = load i64, ptr %l21, !tbaa !24
  %t250 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t251 = load ptr, ptr %t250, !tbaa !27
  %t252 = getelementptr i32, ptr %t251, i64 %t248
  %t253 = load i32, ptr %t252, !tbaa !33
  %t255 = load ptr, ptr %l0, !tbaa !29
  store ptr %t255, ptr %l153, !tbaa !29
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr %"compiler/generic:Program", ptr %t256, i32 0, i32 2
  %t262 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t258, i32 %t253)
  store i32 %t262, ptr %l157
  br label %bb61
bb61:
  %t263 = load ptr, ptr %l153, !tbaa !29
  %t264 = load i32, ptr %l157, !tbaa !23
  %t265 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePayloadOf(ptr %v0, ptr %t263, i32 %t264)
  store i32 %t265, ptr %l158
  br label %bb62
bb62:
  %t266 = load i32, ptr %l158, !tbaa !23
  store i32 %t266, ptr %l24, !tbaa !23
  %t267 = load i32, ptr %l24, !tbaa !23
  %t268 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t271 = icmp ne i32 %t267, %t268
  br i1 %t271, label %bb63, label %bb64
bb63:
  %t273 = load i32, ptr %l24, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s10, ptr %l19, i32 %t273)
  br label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb66
bb66:
  br label %bb67
bb67:
  %t276 = load i64, ptr %l21, !tbaa !24
  %t279 = add i64 %t276, 1
  store i64 %t279, ptr %l21, !tbaa !24
  br label %bb57
bb68:
  %t282 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s10, ptr %l19)
  store i64 %t282, ptr %l168
  br label %bb69
bb69:
  %t283 = load i64, ptr %l168, !tbaa !24
  %t284 = icmp sgt i64 %t283, 1
  br i1 %t284, label %bb70, label %bb71
bb70:
  store %olang.scope zeroinitializer, ptr %s15
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t288 = getelementptr %"compiler/generic:Program", ptr %t286, i32 0, i32 2
  store ptr %t288, ptr %l171, !tbaa !29
  %t289 = load i32, ptr %l18, !tbaa !23
  store i32 %t289, ptr %l172, !tbaa !23
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t292 = getelementptr %"compiler/generic:Program", ptr %t290, i32 0, i32 2
  store ptr %t292, ptr %l174, !tbaa !29
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t295 = getelementptr %"compiler/generic:Program", ptr %t293, i32 0, i32 2
  store ptr %t295, ptr %l176, !tbaa !29
  %t297 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %s10, ptr %s15, ptr %l19)
  store { i64, ptr } %t297, ptr %l178
  br label %bb72
bb71:
  br label %bb76
bb72:
  %t298 = load ptr, ptr %l176, !tbaa !29
  %t299 = load { i64, ptr }, ptr %l178, !tbaa !27
  %t300 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s15, ptr %t298, { i64, ptr } %t299)
  store i32 %t300, ptr %l179
  br label %bb73
bb73:
  %t301 = load ptr, ptr %l174, !tbaa !29
  %t302 = load i32, ptr %l179, !tbaa !23
  %t303 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRecord(ptr %v0, ptr %t301, i32 %t302)
  store i32 %t303, ptr %l180
  br label %bb74
bb74:
  %t304 = load ptr, ptr %l171, !tbaa !29
  %t305 = load i32, ptr %l172, !tbaa !23
  %t306 = load i32, ptr %l180, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetErrRepr(ptr %v0, ptr %t304, i32 %t305, i32 %t306)
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s15)
  br label %bb76
bb76:
  call void @__olang_scope_close(ptr %s10)
  br label %bb77
bb77:
  %t307 = load i32, ptr %l18, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t307, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrValWordText(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca { i64, ptr }
  %l21 = alloca i1
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l31 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l37 = alloca i32
  %l38 = alloca i32
  %l41 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l50 = alloca i64
  %l51 = alloca { i64, ptr }
  %l55 = alloca i64
  %l60 = alloca ptr
  %l68 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  store ptr %t3, ptr %l10, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l14
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l10, !tbaa !29
  %t12 = load i32, ptr %l14, !tbaa !23
  %t13 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t11, i32 %t12)
  store { i64, ptr } %t13, ptr %l15
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t14, ptr %l3, !tbaa !27
  %t15 = load i64, ptr %l2, !tbaa !24
  %t17 = ashr i64 %t15, 16
  %t19 = sub i64 %t17, 1
  store i64 %t19, ptr %l4, !tbaa !24
  %t21 = load i64, ptr %l4, !tbaa !24
  %t23 = icmp slt i64 %t21, 0
  br i1 %t23, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb5
bb4:
  %t25 = load i64, ptr %l4, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  %t31 = icmp sge i64 %t25, %t28
  store i1 %t31, ptr %l21, !tbaa !21
  br label %bb5
bb5:
  %t33 = load i1, ptr %l21, !tbaa !21
  br i1 %t33, label %bb6, label %bb7
bb6:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d16, i32 0, i32 1) }, ptr %l26, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t34, ptr %l27, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t35, 0
  store i64 %t36, ptr %l28, !tbaa !24
  %t37 = load i64, ptr %l28, !tbaa !24
  %t38 = mul i64 %t37, 1
  %t39 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t38)
  %t40 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  store { i64, ptr } %t41, ptr %l29, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = load i64, ptr %l28, !tbaa !24
  %t47 = mul i64 %t46, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t43, ptr %t45, i64 %t47, i1 false)
  %t48 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t48, ptr %l27, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t49 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t49, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/generic:Program", ptr %t50, i32 0, i32 2
  store ptr %t52, ptr %l31, !tbaa !29
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 2
  %t56 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t56, ptr %l34, !tbaa !27
  %t57 = load i64, ptr %l4, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr i32, ptr %t60, i64 %t57
  %t62 = load i32, ptr %t61, !tbaa !33
  %t65 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t55, i32 %t62)
  store i32 %t65, ptr %l37
  br label %bb9
bb9:
  %t66 = load ptr, ptr %l31, !tbaa !29
  %t67 = load i32, ptr %l37, !tbaa !23
  %t68 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t66, i32 %t67)
  store i32 %t68, ptr %l38
  br label %bb10
bb10:
  %t69 = load i32, ptr %l38, !tbaa !23
  store i32 %t69, ptr %l5, !tbaa !23
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load i32, ptr %l5, !tbaa !23
  %t74 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %s0, ptr %t70, i32 %t71)
  store { i64, ptr } %t74, ptr %l41
  br label %bb11
bb11:
  %t75 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t76 = load i64, ptr %l2, !tbaa !24
  %t78 = and i64 %t76, 65535
  store i64 %t78, ptr %l7, !tbaa !24
  %t80 = load i64, ptr %l7, !tbaa !24
  %t83 = extractvalue { i64, ptr } %t75, 0
  %t86 = icmp sge i64 %t80, %t83
  br i1 %t86, label %bb12, label %bb13
bb12:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d17, i32 0, i32 1) }, ptr %l48, !tbaa !27
  %t88 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t88, ptr %l49, !tbaa !27
  %t89 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t89, 0
  store i64 %t90, ptr %l50, !tbaa !24
  %t91 = load i64, ptr %l50, !tbaa !24
  %t92 = mul i64 %t91, 1
  %t93 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t92)
  %t94 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t93, 1
  store { i64, ptr } %t95, ptr %l51, !tbaa !27
  %t96 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = load i64, ptr %l50, !tbaa !24
  %t101 = mul i64 %t100, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t97, ptr %t99, i64 %t101, i1 false)
  %t102 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t102, ptr %l49, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t103 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t103, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/generic:Program", ptr %t104, i32 0, i32 2
  %t107 = load i32, ptr %l5, !tbaa !23
  %t110 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t106, i32 %t107)
  store i64 %t110, ptr %l55
  br label %bb15
bb15:
  %t111 = load i64, ptr %l55, !tbaa !24
  store i64 %t111, ptr %l8, !tbaa !24
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/generic:Program", ptr %t112, i32 0, i32 0
  %t115 = load ptr, ptr %t114, !tbaa !29
  %t117 = getelementptr %"compiler/load:Loader", ptr %t115, i32 0, i32 10
  %t118 = load i64, ptr %l8, !tbaa !24
  %t121 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t117, i64 %t118)
  store ptr %t121, ptr %l60
  br label %bb16
bb16:
  %t122 = load ptr, ptr %l60, !tbaa !29
  %t124 = getelementptr %"compiler/load:Module", ptr %t122, i32 0, i32 2
  %t125 = load { i64, ptr }, ptr %t124, !tbaa !27
  %t126 = load i64, ptr %l8, !tbaa !24
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/generic:Program", ptr %t127, i32 0, i32 0
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t132 = getelementptr %"compiler/load:Loader", ptr %t130, i32 0, i32 12
  %t133 = load i64, ptr %t132, !tbaa !24
  %t136 = icmp eq i64 %t126, %t133
  %t139 = call { i64, ptr } @compiler_2fload_2eErrQualifier(ptr %v0, ptr %s0, { i64, ptr } %t125, i1 %t136)
  store { i64, ptr } %t139, ptr %l68
  br label %bb17
bb17:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load i32, ptr %l5, !tbaa !23
  %t142 = load i64, ptr %l7, !tbaa !24
  %t146 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWordName(ptr %v0, ptr %s0, ptr %t140, i32 %t141, i64 %t142)
  store { i64, ptr } %t146, ptr %l72
  br label %bb18
bb18:
  %t147 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t147, 1
  %t149 = extractvalue { i64, ptr } %t147, 0
  %t150 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t151 = extractvalue { i64, ptr } %t150, 1
  %t152 = extractvalue { i64, ptr } %t150, 0
  %t153 = add i64 %t149, %t152
  %t154 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t153)
  call void @olang_textcopy(ptr %t154, ptr %t148, i64 %t149)
  %t155 = getelementptr i8, ptr %t154, i64 %t149
  call void @olang_textcopy(ptr %t155, ptr %t151, i64 %t152)
  %t156 = insertvalue { i64, ptr } undef, i64 %t153, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr %t154, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t157, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWordName(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca { i64, ptr }
  %l13 = alloca i1
  %l18 = alloca { i64, ptr }
  %l21 = alloca i1
  %l29 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/generic:Program", ptr %t2, i32 0, i32 2
  %t5 = load i32, ptr %l1, !tbaa !23
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t4, i32 %t5)
  store i32 %t8, ptr %l9
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l5, !tbaa !29
  %t10 = load i32, ptr %l9, !tbaa !23
  %t11 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t9, i32 %t10)
  store { i64, ptr } %t11, ptr %l10
  br label %bb2
bb2:
  %t12 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t12, ptr %l3, !tbaa !27
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsRaisedError(ptr %v0, ptr %t13, i32 %t14)
  store i1 %t17, ptr %l13
  br label %bb3
bb3:
  %t18 = load i1, ptr %l13, !tbaa !21
  br i1 %t18, label %bb4, label %bb5
bb4:
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = extractvalue { i64, ptr } %t19, 0
  %t23 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t22)
  call void @olang_textcopy(ptr %t23, ptr %t21, i64 %t22)
  %t24 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t25, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i32, ptr %l1, !tbaa !23
  %t31 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %s0, ptr %t27, i32 %t28)
  store { i64, ptr } %t31, ptr %l18
  br label %bb7
bb7:
  %t32 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t32, ptr %l4, !tbaa !27
  %t33 = load i64, ptr %l2, !tbaa !24
  %t35 = icmp slt i64 %t33, 0
  br i1 %t35, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb10
bb9:
  %t37 = load i64, ptr %l2, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t38, 0
  %t43 = icmp sge i64 %t37, %t40
  store i1 %t43, ptr %l21, !tbaa !21
  br label %bb10
bb10:
  %t45 = load i1, ptr %l21, !tbaa !21
  br i1 %t45, label %bb11, label %bb12
bb11:
  %t46 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t47 = load i64, ptr %l2, !tbaa !24
  %t49 = extractvalue { i64, ptr } %t46, 1
  %t50 = extractvalue { i64, ptr } %t46, 0
  %t51 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t52 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t53 = add i64 %t50, %t52
  %t55 = call i64 @__olang_fmt_i64(ptr null, i64 %t47)
  %t56 = add i64 %t53, %t55
  %t57 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t56)
  call void @olang_textcopy(ptr %t57, ptr %t49, i64 %t50)
  %t58 = getelementptr i8, ptr %t57, i64 %t50
  call void @olang_textcopy(ptr %t58, ptr %t51, i64 %t52)
  %t59 = getelementptr i8, ptr %t58, i64 %t52
  %t60 = call i64 @__olang_fmt_i64(ptr %t59, i64 %t47)
  %t61 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t57, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t62, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t64 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t64, ptr %l29, !tbaa !27
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t66, ptr %l31, !tbaa !27
  %t67 = load i64, ptr %l2, !tbaa !24
  %t69 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr i32, ptr %t70, i64 %t67
  %t72 = load i32, ptr %t71, !tbaa !33
  %t75 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %s0, ptr %t65, i32 %t72)
  store { i64, ptr } %t75, ptr %l34
  br label %bb14
bb14:
  %t76 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t76, 1
  %t78 = extractvalue { i64, ptr } %t76, 0
  %t79 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t80 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t81 = add i64 %t78, %t80
  %t82 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 1
  %t84 = extractvalue { i64, ptr } %t82, 0
  %t85 = add i64 %t81, %t84
  %t86 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t85)
  call void @olang_textcopy(ptr %t86, ptr %t77, i64 %t78)
  %t87 = getelementptr i8, ptr %t86, i64 %t78
  call void @olang_textcopy(ptr %t87, ptr %t79, i64 %t80)
  %t88 = getelementptr i8, ptr %t87, i64 %t80
  call void @olang_textcopy(ptr %t88, ptr %t83, i64 %t84)
  %t89 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t86, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t90, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i32
  %l4 = alloca %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca %"compiler/generic:fnRow"
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l21 = alloca i32
  %l24 = alloca %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20"
  %l25 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i32
  %l35 = alloca i64
  %l36 = alloca ptr
  %l39 = alloca i32
  %l42 = alloca i32
  %l46 = alloca %"compiler/generic:fnRow"
  %l47 = alloca %"std/prelude/text:StringBuilder"
  %l48 = alloca ptr
  %l53 = alloca ptr
  %l62 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l70 = alloca ptr
  %l72 = alloca ptr
  %l76 = alloca i32
  %l79 = alloca i32
  %l83 = alloca i32
  %l86 = alloca { i64, ptr }
  %l89 = alloca ptr
  %l93 = alloca { i64, ptr }
  %l97 = alloca { i64, ptr }
  %l107 = alloca i64
  %l110 = alloca i64
  %l131 = alloca ptr
  %l134 = alloca { i64, ptr }
  %l138 = alloca { i64, ptr }
  %l146 = alloca i64
  %l148 = alloca { i64, ptr }
  %l151 = alloca ptr
  %l152 = alloca i64
  %l153 = alloca i32
  %l154 = alloca i32
  %l155 = alloca i64
  %l158 = alloca { i64, ptr }
  %l163 = alloca %"compiler/generic:instance"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2einstanceArgs(ptr %v0, ptr %t1, i32 %a2)
  store i32 %t5, ptr %l21
  br label %bb1
bb1:
  %t6 = load i32, ptr %l21, !tbaa !23
  store i32 %t6, ptr %l3, !tbaa !23
  %t7 = load i64, ptr %l1, !tbaa !24
  %t8 = load i32, ptr %l3, !tbaa !23
  %t11 = call %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" @std_2fpair_3aPair_3cI64_2c_20compiler_2ftypes_3aListId_3e_2ector(ptr %s0, i64 %t7, i32 %t8)
  store %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %t11, ptr %l24
  br label %bb2
bb2:
  %t12 = load %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l24
  store %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %t12, ptr %l4
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 54
  %t16 = load %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l4
  %t19 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20compiler__Hfc7ca136f786d4bb067f513e5dea5730(ptr %v0, ptr %t15, %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %t16)
  %t20 = extractvalue { i32, i64 } %t19, 1
  %t21 = extractvalue { i32, i64 } %t19, 0
  store i32 %t21, ptr %l30
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb4, label %ok.23, !prof !99
ok.23:
  store i64 %t20, ptr %l29
  br label %bb3
bb3:
  %t24 = load i64, ptr %l29, !tbaa !24
  store i64 %t24, ptr %l25, !tbaa !24
  br label %bb6
bb4:
  br label %bb5
bb5:
  store i64 -1, ptr %l25, !tbaa !24
  br label %bb6
bb6:
  %t25 = load i64, ptr %l25, !tbaa !24
  store i64 %t25, ptr %l5, !tbaa !24
  %t26 = load i64, ptr %l5, !tbaa !24
  %t28 = icmp sge i64 %t26, 0
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t30 = load i64, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t30, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t32 = load i64, ptr %l1, !tbaa !24
  %t34 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t32)
  store i64 %t34, ptr %l35
  br label %bb10
bb10:
  %t35 = load i64, ptr %l35, !tbaa !24
  store i64 %t35, ptr %l6, !tbaa !24
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l36, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i64, ptr %l1, !tbaa !24
  %t41 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t37, i64 %t38)
  store i32 %t41, ptr %l39
  br label %bb11
bb11:
  %t42 = load i64, ptr %l6, !tbaa !24
  %t43 = load i32, ptr %l3, !tbaa !23
  %t44 = load ptr, ptr %l36, !tbaa !29
  %t45 = load i32, ptr %l39, !tbaa !23
  %t48 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %t44, i32 %t45, i64 %t42, i32 %t43)
  store i32 %t48, ptr %l42
  br label %bb12
bb12:
  %t49 = load i32, ptr %l42, !tbaa !23
  store i32 %t49, ptr %l7, !tbaa !23
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/generic:Program", ptr %t50, i32 0, i32 31
  %t53 = load i64, ptr %l1, !tbaa !24
  %t56 = call %"compiler/generic:fnRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eAt_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %v0, ptr %t52, i64 %t53)
  store %"compiler/generic:fnRow" %t56, ptr %l46
  br label %bb13
bb13:
  %t57 = load %"compiler/generic:fnRow", ptr %l46
  store %"compiler/generic:fnRow" %t57, ptr %l8
  %t58 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t58, ptr %l47
  br label %bb14
bb14:
  %t59 = load %"std/prelude/text:StringBuilder", ptr %l47
  store %"std/prelude/text:StringBuilder" %t59, ptr %l9
  store ptr %l9, ptr %l48, !tbaa !29
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/generic:Program", ptr %t60, i32 0, i32 0
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = getelementptr %"compiler/load:Loader", ptr %t63, i32 0, i32 10
  %t66 = getelementptr %"compiler/generic:fnRow", ptr %l8, i32 0, i32 0
  %t67 = load i64, ptr %t66, !tbaa !24
  %t70 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t65, i64 %t67)
  store ptr %t70, ptr %l53
  br label %bb15
bb15:
  %t71 = load ptr, ptr %l53, !tbaa !29
  %t73 = getelementptr %"compiler/load:Module", ptr %t71, i32 0, i32 2
  %t74 = load { i64, ptr }, ptr %t73, !tbaa !27
  %t75 = load ptr, ptr %l48, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t75, { i64, ptr } %t74)
  br label %bb16
bb16:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l9, i8 46)
  br label %bb17
bb17:
  %t78 = getelementptr %"compiler/generic:fnRow", ptr %l8, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = getelementptr %"compiler/ast:Func", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = icmp eq ptr %t82, null
  %t86 = xor i1 %t84, true
  br i1 %t86, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s2
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/generic:Program", ptr %t88, i32 0, i32 2
  store ptr %t90, ptr %l62, !tbaa !29
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/generic:Program", ptr %t91, i32 0, i32 2
  %t94 = load i32, ptr %l7, !tbaa !23
  %t97 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t93, i32 %t94)
  store i32 %t97, ptr %l66
  br label %bb20
bb19:
  br label %bb30
bb20:
  %t98 = load ptr, ptr %l62, !tbaa !29
  %t99 = load i32, ptr %l66, !tbaa !23
  %t100 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s2, ptr %t98, i32 %t99)
  store { i64, ptr } %t100, ptr %l67
  br label %bb21
bb21:
  %t101 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t101, ptr %l68, !tbaa !27
  %t102 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr i32, ptr %t103, i64 0
  %t105 = load i32, ptr %t104, !tbaa !33
  store i32 %t105, ptr %l10, !tbaa !23
  store ptr %l9, ptr %l70, !tbaa !29
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/generic:Program", ptr %t107, i32 0, i32 2
  store ptr %t109, ptr %l72, !tbaa !29
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/generic:Program", ptr %t110, i32 0, i32 2
  %t113 = load i32, ptr %l10, !tbaa !23
  %t116 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t112, i32 %t113)
  store i32 %t116, ptr %l76
  br label %bb22
bb22:
  %t117 = load i32, ptr %l76, !range !{i32 0, i32 33}
  %t119 = trunc i64 20 to i32
  %t120 = icmp eq i32 %t117, %t119
  br i1 %t120, label %bb23, label %bb24
bb23:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/generic:Program", ptr %t122, i32 0, i32 2
  %t125 = load i32, ptr %l10, !tbaa !23
  %t128 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t124, i32 %t125)
  store i32 %t128, ptr %l83
  br label %bb25
bb24:
  %t129 = load i32, ptr %l10, !tbaa !23
  store i32 %t129, ptr %l79, !tbaa !23
  br label %bb26
bb25:
  %t131 = load i32, ptr %l83, !tbaa !23
  store i32 %t131, ptr %l79, !tbaa !23
  br label %bb26
bb26:
  %t133 = inttoptr i64 0 to ptr
  %t134 = load ptr, ptr %l72, !tbaa !29
  %t135 = load i32, ptr %l79, !tbaa !23
  %t136 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s2, ptr %t133, ptr %t134, i32 %t135)
  store { i64, ptr } %t136, ptr %l86
  br label %bb27
bb27:
  %t137 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t138 = load ptr, ptr %l70, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t138, { i64, ptr } %t137)
  br label %bb28
bb28:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l9, i8 46)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s2)
  br label %bb30
bb30:
  store ptr %l9, ptr %l89, !tbaa !29
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/generic:fnRow", ptr %l8, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !29
  %t145 = getelementptr %"compiler/ast:Func", ptr %t143, i32 0, i32 2
  %t146 = load i32, ptr %t145, !tbaa !23
  %t149 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t141, i32 %t146)
  store { i64, ptr } %t149, ptr %l93
  br label %bb31
bb31:
  %t150 = load ptr, ptr %l89, !tbaa !29
  %t151 = load { i64, ptr }, ptr %l93, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t150, { i64, ptr } %t151)
  br label %bb32
bb32:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/generic:Program", ptr %t152, i32 0, i32 2
  %t155 = load i32, ptr %l3, !tbaa !23
  %t158 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t154, i32 %t155)
  store { i64, ptr } %t158, ptr %l97
  br label %bb33
bb33:
  %t159 = load { i64, ptr }, ptr %l97, !tbaa !27
  store { i64, ptr } %t159, ptr %l11, !tbaa !27
  %t160 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t162 = extractvalue { i64, ptr } %t160, 0
  %t164 = icmp sgt i64 %t162, 0
  br i1 %t164, label %bb34, label %bb35
bb34:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l9, i8 60)
  br label %bb36
bb35:
  br label %bb56
bb36:
  store i64 0, ptr %l12, !tbaa !24
  %t167 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t167, 0
  store i64 %t169, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t171 = load i64, ptr %l13, !tbaa !24
  %t172 = load i64, ptr %l12, !tbaa !24
  %t175 = icmp sgt i64 %t171, %t172
  br i1 %t175, label %bb37, label %bb38
bb37:
  %t177 = load i64, ptr %l14, !tbaa !24
  %t179 = icmp sgt i64 %t177, 0
  br i1 %t179, label %bb39, label %bb40
bb38:
  store i64 0, ptr %l107, !tbaa !24
  br label %bb42
bb39:
  %t181 = load i64, ptr %l13, !tbaa !24
  %t182 = load i64, ptr %l12, !tbaa !24
  %t185 = sub i64 %t181, %t182
  %t186 = load i64, ptr %l14, !tbaa !24
  %t189 = add i64 %t185, %t186
  %t191 = sub i64 %t189, 1
  %t192 = load i64, ptr %l14, !tbaa !24
  %t195 = sdiv i64 %t191, %t192
  store i64 %t195, ptr %l110, !tbaa !24
  br label %bb41
bb40:
  store i64 0, ptr %l110, !tbaa !24
  br label %bb41
bb41:
  %t197 = load i64, ptr %l110, !tbaa !24
  store i64 %t197, ptr %l107, !tbaa !24
  br label %bb42
bb42:
  %t198 = load i64, ptr %l107, !tbaa !24
  store i64 %t198, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb43
bb43:
  store %olang.scope zeroinitializer, ptr %s5
  %t199 = load i64, ptr %l16, !tbaa !24
  %t200 = load i64, ptr %l15, !tbaa !24
  %t203 = icmp slt i64 %t199, %t200
  %t205 = xor i1 %t203, true
  br i1 %t205, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s5)
  br label %bb54
bb45:
  br label %bb46
bb46:
  %t207 = load i64, ptr %l12, !tbaa !24
  %t208 = load i64, ptr %l16, !tbaa !24
  %t209 = load i64, ptr %l14, !tbaa !24
  %t212 = mul i64 %t208, %t209
  %t215 = add i64 %t207, %t212
  store i64 %t215, ptr %l17, !tbaa !24
  %t217 = load i64, ptr %l17, !tbaa !24
  %t219 = icmp sgt i64 %t217, 0
  br i1 %t219, label %bb47, label %bb48
bb47:
  store %olang.scope zeroinitializer, ptr %s6
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %l9, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d20, i32 0, i32 1) })
  br label %bb49
bb48:
  br label %bb50
bb49:
  call void @__olang_scope_close(ptr %s6)
  br label %bb50
bb50:
  store ptr %l9, ptr %l131, !tbaa !29
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/generic:Program", ptr %t222, i32 0, i32 2
  %t225 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t225, ptr %l134, !tbaa !27
  %t226 = load i64, ptr %l17, !tbaa !24
  %t228 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t229 = load ptr, ptr %t228, !tbaa !27
  %t230 = getelementptr i32, ptr %t229, i64 %t226
  %t231 = load i32, ptr %t230, !tbaa !33
  %t233 = inttoptr i64 0 to ptr
  %t236 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s5, ptr %t233, ptr %t224, i32 %t231)
  store { i64, ptr } %t236, ptr %l138
  br label %bb51
bb51:
  %t237 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t238 = load ptr, ptr %l131, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %t238, { i64, ptr } %t237)
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s5)
  br label %bb53
bb53:
  %t240 = load i64, ptr %l16, !tbaa !24
  %t243 = add i64 %t240, 1
  store i64 %t243, ptr %l16, !tbaa !24
  br label %bb43
bb54:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l9, i8 62)
  br label %bb55
bb55:
  br label %bb56
bb56:
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t248 = getelementptr %"compiler/generic:Program", ptr %t246, i32 0, i32 53
  %t250 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3ainstance_3e_2eLen_Hf1590ba3dea8cd8a914b2a9f5344a2c6(ptr %v0, ptr %t248)
  store i64 %t250, ptr %l146
  br label %bb57
bb57:
  %t251 = load i64, ptr %l146, !tbaa !24
  store i64 %t251, ptr %l5, !tbaa !24
  %t253 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v0, ptr %l9)
  store { i64, ptr } %t253, ptr %l148
  br label %bb58
bb58:
  %t254 = load { i64, ptr }, ptr %l148, !tbaa !27
  store { i64, ptr } %t254, ptr %l18, !tbaa !27
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr %"compiler/generic:Program", ptr %t256, i32 0, i32 53
  store ptr %t258, ptr %l151, !tbaa !29
  %t259 = load i64, ptr %l1, !tbaa !24
  store i64 %t259, ptr %l152, !tbaa !24
  %t260 = load i32, ptr %l3, !tbaa !23
  store i32 %t260, ptr %l153, !tbaa !23
  %t261 = load i32, ptr %l7, !tbaa !23
  store i32 %t261, ptr %l154, !tbaa !23
  %t262 = call ptr @__olang_scope_hold(ptr %v0)
  %t263 = ptrtoint ptr %t262 to i64
  store i64 %t263, ptr %l155, !tbaa !24
  %t264 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3ainstance_2e3
  br i1 %t264, label %bb59, label %bb60
bb59:
  %t266 = call ptr @__olang_region_make(ptr %v0)
  %t267 = ptrtoint ptr %t266 to i64
  store i64 %t267, ptr %l155, !tbaa !24
  br label %bb60
bb60:
  %t268 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t269 = load i64, ptr %l155
  %t270 = inttoptr i64 %t269 to ptr
  %t272 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v0, ptr %t270, { i64, ptr } %t268)
  store { i64, ptr } %t272, ptr %l158
  br label %bb61
bb61:
  %t273 = load { i64, ptr }, ptr %l158, !tbaa !27
  %t274 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t277 = getelementptr %"compiler/generic:Program", ptr %t275, i32 0, i32 60
  %t278 = load %"compiler/generic:Origin", ptr %t277
  %t279 = load i64, ptr %l152, !tbaa !24
  %t280 = load i32, ptr %l153, !tbaa !23
  %t281 = load i32, ptr %l154, !tbaa !23
  %t285 = call %"compiler/generic:instance" @compiler_2fgeneric_3ainstance_2ector(ptr %v0, ptr %v0, ptr %v0, i64 %t279, i32 %t280, i32 %t281, { i64, ptr } %t273, { i64, ptr } %t274, %"compiler/generic:Origin" %t278)
  store %"compiler/generic:instance" %t285, ptr %l163
  br label %bb62
bb62:
  %t286 = load ptr, ptr %l151, !tbaa !29
  %t287 = load %"compiler/generic:instance", ptr %l163
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3ainstance_3e_2ePus_Hca36cd1c69200a0db62aadeba49cf6ed(ptr %v0, ptr %v0, ptr %t286, %"compiler/generic:instance" %t287)
  br label %bb63
bb63:
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t290 = getelementptr %"compiler/generic:Program", ptr %t288, i32 0, i32 54
  %t291 = load %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l4
  %t292 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H5edca056502a242264473f986489341f(ptr %v0, ptr %t290, %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %t291, i64 %t292)
  br label %bb64
bb64:
  %t296 = load i64, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t296, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eHasHash(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ehasHash(ptr %v0, ptr %a0, i32 %a1, i64 0)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLenKey(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca i1
  %l23 = alloca { i64, ptr }
  %l24 = alloca i1
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l34 = alloca i1
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a2, 0
  %t5 = icmp sgt i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d21, i32 0, i32 1) }, ptr %l9, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t7, ptr %l10, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  store i64 %t9, ptr %l11, !tbaa !24
  %t10 = load i64, ptr %l11, !tbaa !24
  %t11 = mul i64 %t10, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l12, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = load i64, ptr %l11, !tbaa !24
  %t20 = mul i64 %t19, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t16, ptr %t18, i64 %t20, i1 false)
  %t21 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t21, ptr %l10, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t22, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t23 = load ptr, ptr %l1, !tbaa !29
  store ptr %t23, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t24 = load ptr, ptr %l13, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb4, label %bb5
bb4:
  %t27 = load ptr, ptr %l13, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 28}
  %t30 = icmp eq i64 %t28, 12
  store i1 %t30, ptr %l14, !tbaa !21
  br label %bb5
bb5:
  %t31 = load i1, ptr %l14, !tbaa !21
  br i1 %t31, label %bb6, label %bb7
bb6:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr { i64, [4 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t34, i32 0, i32 1
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l3, !tbaa !29
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t40, i32 0, i32 2
  %t42 = load i32, ptr %t41
  store i32 %t42, ptr %l4, !tbaa !23
  br label %bb8
bb7:
  br label %bb19
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load i32, ptr %l4, !tbaa !23
  %t48 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t44, i32 %t45)
  store { i64, ptr } %t48, ptr %l23
  br label %bb9
bb9:
  %t49 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t50 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t49, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d22, i32 0, i32 1) })
  store i1 %t50, ptr %l24
  br label %bb10
bb10:
  %t51 = load i1, ptr %l24, !tbaa !21
  %t52 = xor i1 %t51, true
  br i1 %t52, label %bb11, label %bb12
bb11:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %l26, !tbaa !27
  %t54 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t54, ptr %l27, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 0
  store i64 %t56, ptr %l28, !tbaa !24
  %t57 = load i64, ptr %l28, !tbaa !24
  %t58 = mul i64 %t57, 1
  %t59 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t58)
  %t60 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  store { i64, ptr } %t61, ptr %l29, !tbaa !27
  %t62 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = load i64, ptr %l28, !tbaa !24
  %t67 = mul i64 %t66, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t63, ptr %t65, i64 %t67, i1 false)
  %t68 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t68, ptr %l27, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  %t69 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t69, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load ptr, ptr %l3, !tbaa !29
  %t74 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2elenPath(ptr %v0, ptr %v1, ptr %s2, ptr %t70, ptr %t71, i64 0)
  store { i64, ptr } %t74, ptr %l32
  br label %bb14
bb14:
  %t75 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t75, ptr %l5, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t78 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t76, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d24, i32 0, i32 1) })
  store i1 %t78, ptr %l34
  br label %bb15
bb15:
  %t79 = load i1, ptr %l34, !tbaa !21
  br i1 %t79, label %bb16, label %bb17
bb16:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d25, i32 0, i32 1) }, ptr %l36, !tbaa !27
  %t80 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t80, ptr %l35, !tbaa !27
  br label %bb18
bb17:
  %t82 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t82, 1
  %t85 = extractvalue { i64, ptr } %t82, 0
  %t86 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t87 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t88 = add i64 %t85, %t87
  %t89 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t88)
  call void @olang_textcopy(ptr %t89, ptr %t84, i64 %t85)
  %t90 = getelementptr i8, ptr %t89, i64 %t85
  call void @olang_textcopy(ptr %t90, ptr %t86, i64 %t87)
  %t91 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t89, 1
  store { i64, ptr } %t92, ptr %l35, !tbaa !27
  br label %bb18
bb18:
  %t94 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 0
  store i64 %t95, ptr %l40, !tbaa !24
  %t96 = load i64, ptr %l40, !tbaa !24
  %t97 = mul i64 %t96, 1
  %t98 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t97)
  %t99 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  store { i64, ptr } %t100, ptr %l41, !tbaa !27
  %t101 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = load i64, ptr %l40, !tbaa !24
  %t106 = mul i64 %t105, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t102, ptr %t104, i64 %t106, i1 false)
  %t107 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t107, ptr %l35, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  %t108 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t108, ptr %rv
  br label %ret
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d27, i32 0, i32 1) }, ptr %l42, !tbaa !27
  %t109 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t109, ptr %l43, !tbaa !27
  %t110 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t110, 0
  store i64 %t111, ptr %l44, !tbaa !24
  %t112 = load i64, ptr %l44, !tbaa !24
  %t113 = mul i64 %t112, 1
  %t114 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t113)
  %t115 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t114, 1
  store { i64, ptr } %t116, ptr %l45, !tbaa !27
  %t117 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !27
  %t119 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = load i64, ptr %l44, !tbaa !24
  %t122 = mul i64 %t121, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t118, ptr %t120, i64 %t122, i1 false)
  %t123 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t123, ptr %l43, !tbaa !27
  %t124 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t124, ptr %rv
  br label %ret
bb23:
  call void @__olang_check_failed(ptr @olang_loc_7f496bc4f965d188_939cdcc04f80a0bc)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l17 = alloca i32
  %l20 = alloca i32
  %l24 = alloca i32
  %l29 = alloca i32
  %l35 = alloca i32
  %l39 = alloca i64
  %l42 = alloca i64
  %l62 = alloca i64
  %l66 = alloca i64
  %l68 = alloca ptr
  %l72 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l73 = alloca i64
  %l74 = alloca i32
  %l83 = alloca i1
  %l86 = alloca i1
  %l91 = alloca i64
  %l95 = alloca i64
  %l96 = alloca i32
  %l101 = alloca i32
  %l105 = alloca i1
  %l108 = alloca i1
  %l112 = alloca ptr
  %l116 = alloca i32
  %l117 = alloca i32
  %l121 = alloca i1
  %l122 = alloca ptr
  %l126 = alloca i32
  %l127 = alloca i1
  %l133 = alloca i32
  %s3 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eallFns(ptr %v0, ptr %t1)
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/generic:Program", ptr %t3, i32 0, i32 2
  %t6 = load i32, ptr %l1, !tbaa !23
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t5, i32 %t6)
  store i32 %t9, ptr %l17
  br label %bb2
bb2:
  %t10 = load i32, ptr %l17, !range !{i32 0, i32 33}
  %t12 = trunc i64 20 to i32
  %t13 = icmp eq i32 %t10, %t12
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  %t18 = load i32, ptr %l1, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l24
  br label %bb5
bb4:
  %t22 = load i32, ptr %l1, !tbaa !23
  store i32 %t22, ptr %l20, !tbaa !23
  br label %bb6
bb5:
  %t24 = load i32, ptr %l24, !tbaa !23
  store i32 %t24, ptr %l20, !tbaa !23
  br label %bb6
bb6:
  %t25 = load i32, ptr %l20, !tbaa !23
  store i32 %t25, ptr %l3, !tbaa !23
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  %t29 = load i32, ptr %l3, !tbaa !23
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFuncTag(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t32, ptr %l29
  br label %bb7
bb7:
  %t33 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t34 = load i32, ptr %l29, !tbaa !23
  %t36 = icmp ne i32 %t34, %t33
  br i1 %t36, label %bb8, label %bb9
bb8:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/generic:Program", ptr %t38, i32 0, i32 2
  %t41 = load i32, ptr %l3, !tbaa !23
  %t44 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFuncTag(ptr %v0, ptr %t40, i32 %t41)
  store i32 %t44, ptr %l35
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t45 = load i32, ptr %l35, !tbaa !23
  store i32 %t45, ptr %l3, !tbaa !23
  br label %bb11
bb11:
  store i64 0, ptr %l4, !tbaa !24
  store i64 16, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t46 = load i64, ptr %l5, !tbaa !24
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = icmp sgt i64 %t46, %t47
  br i1 %t50, label %bb12, label %bb13
bb12:
  %t52 = load i64, ptr %l6, !tbaa !24
  %t54 = icmp sgt i64 %t52, 0
  br i1 %t54, label %bb14, label %bb15
bb13:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb17
bb14:
  %t56 = load i64, ptr %l5, !tbaa !24
  %t57 = load i64, ptr %l4, !tbaa !24
  %t60 = sub i64 %t56, %t57
  %t61 = load i64, ptr %l6, !tbaa !24
  %t64 = add i64 %t60, %t61
  %t66 = sub i64 %t64, 1
  %t67 = load i64, ptr %l6, !tbaa !24
  %t70 = sdiv i64 %t66, %t67
  store i64 %t70, ptr %l42, !tbaa !24
  br label %bb16
bb15:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb16
bb16:
  %t72 = load i64, ptr %l42, !tbaa !24
  store i64 %t72, ptr %l39, !tbaa !24
  br label %bb17
bb17:
  %t73 = load i64, ptr %l39, !tbaa !24
  store i64 %t73, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s3
  %t74 = load i64, ptr %l8, !tbaa !24
  %t75 = load i64, ptr %l7, !tbaa !24
  %t78 = icmp slt i64 %t74, %t75
  %t80 = xor i1 %t78, true
  br i1 %t80, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s3)
  br label %bb75
bb20:
  br label %bb21
bb21:
  %t82 = load i64, ptr %l4, !tbaa !24
  %t83 = load i64, ptr %l8, !tbaa !24
  %t84 = load i64, ptr %l6, !tbaa !24
  %t87 = mul i64 %t83, %t84
  %t90 = add i64 %t82, %t87
  store i64 %t90, ptr %l9, !tbaa !24
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load i32, ptr %l3, !tbaa !23
  %t96 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etypeKey(ptr %v0, ptr %t92, i32 %t93)
  store i64 %t96, ptr %l62
  br label %bb22
bb22:
  %t97 = load i64, ptr %l62, !tbaa !24
  store i64 %t97, ptr %l10, !tbaa !24
  %t98 = load i64, ptr %l10, !tbaa !24
  %t100 = icmp slt i64 %t98, 0
  br i1 %t100, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s3)
  store i64 -1, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/generic:Program", ptr %t103, i32 0, i32 38
  store ptr %t105, ptr %l68, !tbaa !29
  %t106 = load i64, ptr %l10, !tbaa !24
  %t109 = sext i32 %a2 to i64
  %t112 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s3, i64 %t106, i64 %t109)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t112, ptr %l72
  br label %bb26
bb26:
  %t113 = load ptr, ptr %l68, !tbaa !29
  %t114 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l72
  %t115 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t113, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t114)
  %t116 = extractvalue { i32, i64 } %t115, 1
  %t117 = extractvalue { i32, i64 } %t115, 0
  store i32 %t117, ptr %l74
  %t118 = icmp ne i32 %t117, 0
  br i1 %t118, label %bb28, label %ok.119, !prof !99
ok.119:
  store i64 %t116, ptr %l73
  br label %bb27
bb27:
  %t120 = load i64, ptr %l73, !tbaa !24
  store i64 %t120, ptr %l66, !tbaa !24
  br label %bb30
bb28:
  br label %bb29
bb29:
  store i64 -1, ptr %l66, !tbaa !24
  br label %bb30
bb30:
  %t121 = load i64, ptr %l66, !tbaa !24
  store i64 %t121, ptr %l11, !tbaa !24
  %t122 = load i64, ptr %l11, !tbaa !24
  %t124 = icmp sge i64 %t122, 0
  br i1 %t124, label %bb31, label %bb32
bb31:
  store i64 -1, ptr %l12, !tbaa !24
  br label %bb33
bb32:
  br label %bb54
bb33:
  %t126 = load i64, ptr %l11, !tbaa !24
  %t128 = icmp sge i64 %t126, 0
  %t130 = xor i1 %t128, true
  br i1 %t130, label %bb34, label %bb35
bb34:
  br label %bb53
bb35:
  br label %bb36
bb36:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load i64, ptr %l11, !tbaa !24
  %t134 = load i32, ptr %l3, !tbaa !23
  %t138 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2erecvApplies(ptr %v0, ptr %t132, i64 %t133, i32 %t134)
  store i1 %t138, ptr %l83
  br label %bb37
bb37:
  %t139 = load i1, ptr %l83, !tbaa !21
  br i1 %t139, label %bb38, label %bb39
bb38:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load i64, ptr %l11, !tbaa !24
  %t144 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2erecvExact(ptr %v0, ptr %t140, i64 %t141)
  store i1 %t144, ptr %l86
  br label %bb40
bb39:
  br label %bb47
bb40:
  %t145 = load i1, ptr %l86, !tbaa !21
  br i1 %t145, label %bb41, label %bb42
bb41:
  %t146 = load i64, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  store i64 %t146, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  %t148 = load i64, ptr %l12, !tbaa !24
  %t150 = icmp slt i64 %t148, 0
  br i1 %t150, label %bb44, label %bb45
bb44:
  %t152 = load i64, ptr %l11, !tbaa !24
  store i64 %t152, ptr %l12, !tbaa !24
  br label %bb46
bb45:
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/generic:Program", ptr %t154, i32 0, i32 39
  %t157 = load i64, ptr %l11, !tbaa !24
  %t160 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t156, i64 %t157)
  %t161 = extractvalue { i32, i64 } %t160, 1
  %t162 = extractvalue { i32, i64 } %t160, 0
  store i32 %t162, ptr %l96
  %t163 = icmp ne i32 %t162, 0
  br i1 %t163, label %bb49, label %ok.164, !prof !99
ok.164:
  store i64 %t161, ptr %l95
  br label %bb48
bb48:
  %t165 = load i64, ptr %l95, !tbaa !24
  store i64 %t165, ptr %l91, !tbaa !24
  br label %bb51
bb49:
  br label %bb50
bb50:
  store i64 -1, ptr %l91, !tbaa !24
  br label %bb51
bb51:
  %t166 = load i64, ptr %l91, !tbaa !24
  store i64 %t166, ptr %l11, !tbaa !24
  br label %bb52
bb52:
  br label %bb33
bb53:
  %t167 = load i64, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  store i64 %t167, ptr %rv
  br label %ret
bb54:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/generic:Program", ptr %t169, i32 0, i32 2
  %t172 = load i32, ptr %l3, !tbaa !23
  %t175 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t171, i32 %t172)
  store i32 %t175, ptr %l101
  br label %bb55
bb55:
  %t176 = load i32, ptr %l101, !range !{i32 0, i32 33}
  %t178 = trunc i64 18 to i32
  %t179 = icmp eq i32 %t176, %t178
  %t181 = xor i1 %t179, true
  br i1 %t181, label %bb56, label %bb57
bb56:
  store i1 true, ptr %l105, !tbaa !21
  br label %bb59
bb57:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = load i32, ptr %l3, !tbaa !23
  %t187 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t183, i32 %t184)
  store i1 %t187, ptr %l108
  br label %bb58
bb58:
  %t188 = load i1, ptr %l108, !tbaa !21
  %t189 = xor i1 %t188, true
  store i1 %t189, ptr %l105, !tbaa !21
  br label %bb59
bb59:
  %t191 = load i1, ptr %l105, !tbaa !21
  br i1 %t191, label %bb60, label %bb61
bb60:
  call void @__olang_scope_close(ptr %s3)
  store i64 -1, ptr %rv
  br label %ret
bb61:
  br label %bb62
bb62:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/generic:Program", ptr %t193, i32 0, i32 2
  store ptr %t195, ptr %l112, !tbaa !29
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/generic:Program", ptr %t196, i32 0, i32 2
  %t199 = load i32, ptr %l3, !tbaa !23
  %t202 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t198, i32 %t199)
  store i32 %t202, ptr %l116
  br label %bb63
bb63:
  %t203 = load ptr, ptr %l112, !tbaa !29
  %t204 = load i32, ptr %l116, !tbaa !23
  %t205 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t203, i32 %t204)
  store i32 %t205, ptr %l117
  br label %bb64
bb64:
  %t206 = load i32, ptr %l117, !range !{i32 0, i32 6}
  %t208 = trunc i64 4 to i32
  %t209 = icmp eq i32 %t206, %t208
  %t211 = xor i1 %t209, true
  br i1 %t211, label %bb65, label %bb66
bb65:
  store i1 true, ptr %l121, !tbaa !21
  br label %bb69
bb66:
  %t213 = load ptr, ptr %l0, !tbaa !29
  store ptr %t213, ptr %l122, !tbaa !29
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/generic:Program", ptr %t214, i32 0, i32 2
  %t217 = load i32, ptr %l3, !tbaa !23
  %t220 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t216, i32 %t217)
  store i32 %t220, ptr %l126
  br label %bb67
bb67:
  %t221 = load ptr, ptr %l122, !tbaa !29
  %t222 = load i32, ptr %l126, !tbaa !23
  %t223 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eextends(ptr %v0, ptr %t221, i32 %t222)
  store i1 %t223, ptr %l127
  br label %bb68
bb68:
  %t224 = load i1, ptr %l127, !tbaa !21
  %t225 = xor i1 %t224, true
  store i1 %t225, ptr %l121, !tbaa !21
  br label %bb69
bb69:
  %t227 = load i1, ptr %l121, !tbaa !21
  br i1 %t227, label %bb70, label %bb71
bb70:
  call void @__olang_scope_close(ptr %s3)
  store i64 -1, ptr %rv
  br label %ret
bb71:
  br label %bb72
bb72:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"compiler/generic:Program", ptr %t229, i32 0, i32 2
  %t232 = load i32, ptr %l3, !tbaa !23
  %t235 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t231, i32 %t232)
  store i32 %t235, ptr %l133
  br label %bb73
bb73:
  %t236 = load i32, ptr %l133, !tbaa !23
  store i32 %t236, ptr %l3, !tbaa !23
  call void @__olang_scope_close(ptr %s3)
  br label %bb74
bb74:
  %t237 = load i64, ptr %l8, !tbaa !24
  %t240 = add i64 %t237, 1
  store i64 %t240, ptr %l8, !tbaa !24
  br label %bb18
bb75:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnify(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3, i1 %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i32
  %l7 = alloca i32
  %l11 = alloca i1
  %l18 = alloca i32
  %l21 = alloca i1
  %l25 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l34 = alloca i64
  %l38 = alloca i32
  %l45 = alloca i32
  %l48 = alloca i1
  %l49 = alloca i32
  %l51 = alloca i32
  %l53 = alloca i1
  %l55 = alloca i1
  %l59 = alloca i32
  %l63 = alloca i32
  %l65 = alloca i1
  %l68 = alloca i1
  %l69 = alloca i1
  %l71 = alloca ptr
  %l75 = alloca i32
  %l76 = alloca i32
  %l79 = alloca ptr
  %l80 = alloca i32
  %l84 = alloca i32
  %l88 = alloca i32
  %l90 = alloca i32
  %l92 = alloca i32
  %l94 = alloca i1
  %l103 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i1 %a4, ptr %l4
  store i1 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb3
bb2:
  %t7 = load i32, ptr %l2, !tbaa !23
  %t8 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t11 = icmp eq i32 %t7, %t8
  store i1 %t11, ptr %l11, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l11, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  store i32 0, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 2
  %t17 = load i32, ptr %l1, !tbaa !23
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t16, i32 %t17)
  store i32 %t20, ptr %l18
  br label %bb7
bb7:
  %t21 = load i32, ptr %l18, !range !{i32 0, i32 33}
  store i32 %t21, ptr %l6
  %t22 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t24 = trunc i64 25 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb8, label %bb9
bb8:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Program", ptr %t27, i32 0, i32 2
  %t30 = load i32, ptr %l1, !tbaa !23
  %t33 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t29, i32 %t30)
  store i64 %t33, ptr %l25
  br label %bb10
bb9:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb11
bb10:
  %t34 = load ptr, ptr %l3, !tbaa !29
  %t36 = getelementptr %"compiler/generic:Binding", ptr %t34, i32 0, i32 0
  %t37 = load i64, ptr %t36, !tbaa !24
  %t38 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp eq i64 %t38, %t37
  store i1 %t40, ptr %l21, !tbaa !21
  br label %bb11
bb11:
  %t42 = load i1, ptr %l21, !tbaa !21
  br i1 %t42, label %bb12, label %bb13
bb12:
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l29, !tbaa !29
  %t44 = load ptr, ptr %l3, !tbaa !29
  store ptr %t44, ptr %l30, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/generic:Program", ptr %t45, i32 0, i32 2
  %t48 = load i32, ptr %l1, !tbaa !23
  %t51 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t47, i32 %t48)
  store i64 %t51, ptr %l34
  br label %bb14
bb13:
  br label %bb18
bb14:
  %t52 = load i32, ptr %l2, !tbaa !23
  %t53 = load i1, ptr %l4, !tbaa !21
  %t54 = load i1, ptr %l5, !tbaa !21
  %t55 = load ptr, ptr %l29, !tbaa !29
  %t56 = load ptr, ptr %l30, !tbaa !29
  %t57 = load i64, ptr %l34, !tbaa !24
  %t61 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ebind(ptr %v0, ptr %v1, ptr %t55, ptr %t56, i64 %t57, i32 %t52, i1 %t53, i1 %t54)
  store i32 %t61, ptr %l38
  %t62 = icmp ne i32 %t61, 0
  br i1 %t62, label %bb16, label %ok.63, !prof !99
ok.63:
  br label %bb15
bb15:
  br label %bb17
bb16:
  %t64 = load i32, ptr %l38, !tbaa !23
  %t65 = lshr i32 %t64, 16
  %t66 = and i32 %t64, 65535
  %t67 = icmp eq i32 %t65, 1
  %t68 = select i1 %t67, i32 1, i32 0
  %t69 = icmp eq i32 %t64, 0
  %t70 = shl i32 %t68, 16
  %t71 = or i32 %t70, %t66
  %t72 = select i1 %t69, i32 0, i32 %t71
  store i32 %t72, ptr %rv
  br label %ret
bb17:
  store i32 0, ptr %rv
  br label %ret
bb18:
  %t74 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t76 = trunc i64 27 to i32
  %t77 = icmp eq i32 %t74, %t76
  br i1 %t77, label %bb19, label %bb20
bb19:
  store i32 0, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/generic:Program", ptr %t79, i32 0, i32 2
  %t82 = load i32, ptr %l2, !tbaa !23
  %t85 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t81, i32 %t82)
  store i32 %t85, ptr %l45
  br label %bb22
bb22:
  %t86 = load i32, ptr %l45, !range !{i32 0, i32 33}
  store i32 %t86, ptr %l7
  %t87 = load i32, ptr %l7, !range !{i32 0, i32 33}
  %t89 = trunc i64 18 to i32
  %t90 = icmp eq i32 %t87, %t89
  br i1 %t90, label %bb23, label %bb24
bb23:
  %t92 = load i32, ptr %l6, !range !{i32 0, i32 33}
  store i32 %t92, ptr %l49
  %t93 = load i32, ptr %l7, !range !{i32 0, i32 33}
  store i32 %t93, ptr %l51
  %t96 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l49, ptr %l51)
  store i1 %t96, ptr %l53
  br label %bb25
bb24:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb31
bb25:
  %t97 = load i1, ptr %l53, !tbaa !21
  %t98 = xor i1 %t97, true
  br i1 %t98, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l55, !tbaa !21
  br label %bb30
bb27:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Program", ptr %t100, i32 0, i32 2
  %t103 = load i32, ptr %l1, !tbaa !23
  %t106 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t102, i32 %t103)
  store i32 %t106, ptr %l59
  br label %bb28
bb28:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/generic:Program", ptr %t107, i32 0, i32 2
  %t110 = load i32, ptr %l2, !tbaa !23
  %t113 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t109, i32 %t110)
  store i32 %t113, ptr %l63
  br label %bb29
bb29:
  %t114 = load i32, ptr %l59, !tbaa !23
  %t115 = load i32, ptr %l63, !tbaa !23
  %t116 = icmp ne i32 %t114, %t115
  store i1 %t116, ptr %l55, !tbaa !21
  br label %bb30
bb30:
  %t118 = load i1, ptr %l55, !tbaa !21
  store i1 %t118, ptr %l48, !tbaa !21
  br label %bb31
bb31:
  %t119 = load i1, ptr %l48, !tbaa !21
  br i1 %t119, label %bb32, label %bb33
bb32:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load i32, ptr %l2, !tbaa !23
  %t124 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t120, i32 %t121)
  store i1 %t124, ptr %l68
  br label %bb34
bb33:
  store i1 false, ptr %l65, !tbaa !21
  br label %bb35
bb34:
  %t125 = load i1, ptr %l68, !tbaa !21
  store i1 %t125, ptr %l65, !tbaa !21
  br label %bb35
bb35:
  %t126 = load i1, ptr %l65, !tbaa !21
  br i1 %t126, label %bb36, label %bb37
bb36:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/generic:Program", ptr %t127, i32 0, i32 2
  store ptr %t129, ptr %l71, !tbaa !29
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/generic:Program", ptr %t130, i32 0, i32 2
  %t133 = load i32, ptr %l2, !tbaa !23
  %t136 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t132, i32 %t133)
  store i32 %t136, ptr %l75
  br label %bb38
bb37:
  store i1 false, ptr %l69, !tbaa !21
  br label %bb40
bb38:
  %t137 = load ptr, ptr %l71, !tbaa !29
  %t138 = load i32, ptr %l75, !tbaa !23
  %t139 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t137, i32 %t138)
  store i32 %t139, ptr %l76
  br label %bb39
bb39:
  %t140 = load i32, ptr %l76, !range !{i32 0, i32 6}
  %t142 = trunc i64 4 to i32
  %t143 = icmp eq i32 %t140, %t142
  store i1 %t143, ptr %l69, !tbaa !21
  br label %bb40
bb40:
  %t145 = load i1, ptr %l69, !tbaa !21
  br i1 %t145, label %bb41, label %bb42
bb41:
  %t146 = load ptr, ptr %l0, !tbaa !29
  store ptr %t146, ptr %l79, !tbaa !29
  %t147 = load i32, ptr %l1, !tbaa !23
  store i32 %t147, ptr %l80, !tbaa !23
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/generic:Program", ptr %t148, i32 0, i32 2
  %t151 = load i32, ptr %l2, !tbaa !23
  %t154 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t150, i32 %t151)
  store i32 %t154, ptr %l84
  br label %bb43
bb42:
  br label %bb47
bb43:
  %t155 = load ptr, ptr %l3, !tbaa !29
  %t156 = load i1, ptr %l4, !tbaa !21
  %t157 = load i1, ptr %l5, !tbaa !21
  %t158 = load ptr, ptr %l79, !tbaa !29
  %t159 = load i32, ptr %l80, !tbaa !23
  %t160 = load i32, ptr %l84, !tbaa !23
  %t164 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnify(ptr %v0, ptr %v1, ptr %t158, i32 %t159, i32 %t160, ptr %t155, i1 %t156, i1 %t157)
  store i32 %t164, ptr %l88
  %t165 = icmp ne i32 %t164, 0
  br i1 %t165, label %bb45, label %ok.166, !prof !99
ok.166:
  br label %bb44
bb44:
  br label %bb46
bb45:
  %t167 = load i32, ptr %l88, !tbaa !23
  %t168 = lshr i32 %t167, 16
  %t169 = and i32 %t167, 65535
  %t170 = icmp eq i32 %t168, 1
  %t171 = select i1 %t170, i32 1, i32 0
  %t172 = icmp eq i32 %t167, 0
  %t173 = shl i32 %t171, 16
  %t174 = or i32 %t173, %t169
  %t175 = select i1 %t172, i32 0, i32 %t174
  store i32 %t175, ptr %rv
  br label %ret
bb46:
  store i32 0, ptr %rv
  br label %ret
bb47:
  %t177 = load i32, ptr %l6, !range !{i32 0, i32 33}
  store i32 %t177, ptr %l90
  %t178 = load i32, ptr %l7, !range !{i32 0, i32 33}
  store i32 %t178, ptr %l92
  %t181 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l90, ptr %l92)
  store i1 %t181, ptr %l94
  br label %bb48
bb48:
  %t182 = load i1, ptr %l94, !tbaa !21
  %t183 = xor i1 %t182, true
  br i1 %t183, label %bb49, label %bb50
bb49:
  store i32 65536, ptr %rv
  br label %ret
bb50:
  br label %bb51
bb51:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t188 = load i32, ptr %l1, !tbaa !23
  %t189 = load i32, ptr %l2, !tbaa !23
  %t190 = load ptr, ptr %l3, !tbaa !29
  %t191 = load i1, ptr %l5, !tbaa !21
  %t198 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunifyKind(ptr %v0, ptr %v1, ptr %t186, i32 %t187, i32 %t188, i32 %t189, ptr %t190, i1 %t191)
  store i32 %t198, ptr %l103
  %t199 = icmp ne i32 %t198, 0
  br i1 %t199, label %bb53, label %ok.200, !prof !99
ok.200:
  br label %bb52
bb52:
  br label %bb54
bb53:
  %t201 = load i32, ptr %l103, !tbaa !23
  %t202 = lshr i32 %t201, 16
  %t203 = and i32 %t201, 65535
  %t204 = icmp eq i32 %t202, 1
  %t205 = select i1 %t204, i32 1, i32 0
  %t206 = icmp eq i32 %t201, 0
  %t207 = shl i32 %t205, 16
  %t208 = or i32 %t207, %t203
  %t209 = select i1 %t206, i32 0, i32 %t208
  store i32 %t209, ptr %rv
  br label %ret
bb54:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ebind(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i32 %a3, i1 %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i1
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i64
  %l11 = alloca i64
  %l15 = alloca i32
  %l19 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l28 = alloca i1
  %l32 = alloca i32
  %l36 = alloca i32
  %l41 = alloca i32
  %l45 = alloca i32
  %l48 = alloca i32
  %l53 = alloca i32
  %l57 = alloca i1
  %l61 = alloca i32
  %l64 = alloca i1
  %l67 = alloca i1
  %l68 = alloca i1
  %l70 = alloca ptr
  %l74 = alloca i32
  %l75 = alloca i32
  %l78 = alloca i1
  %l82 = alloca i1
  %l87 = alloca i32
  %l89 = alloca { i64, ptr }
  %l95 = alloca i1
  %l97 = alloca { i64, ptr }
  %l100 = alloca i1
  %l104 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %l118 = alloca i1
  %l123 = alloca i1
  %l126 = alloca { i64, ptr }
  %l129 = alloca i1
  %l133 = alloca i1
  %l134 = alloca i1
  %l138 = alloca i1
  %l139 = alloca i1
  %l143 = alloca i1
  %l145 = alloca { i64, ptr }
  %l151 = alloca i32
  %l154 = alloca i1
  %l158 = alloca i32
  %l162 = alloca i1
  %l164 = alloca ptr
  %l168 = alloca i32
  %l169 = alloca i32
  %l175 = alloca i32
  %l178 = alloca i32
  %l180 = alloca ptr
  %l184 = alloca i32
  %l185 = alloca i32
  %l190 = alloca i32
  %l193 = alloca i1
  %l197 = alloca i32
  %l200 = alloca i1
  %l202 = alloca ptr
  %l206 = alloca i32
  %l210 = alloca i32
  %l211 = alloca i1
  %l212 = alloca i1
  %l214 = alloca { i64, ptr }
  %l221 = alloca i32
  %l223 = alloca i1
  %l227 = alloca i32
  %l231 = alloca i32
  %l234 = alloca { i64, ptr }
  %l235 = alloca i64
  %l237 = alloca ptr
  %l241 = alloca i32
  %l242 = alloca i32
  %l244 = alloca ptr
  %l247 = alloca i32
  %l248 = alloca i1
  %l249 = alloca i1
  %l251 = alloca ptr
  %l254 = alloca i32
  %l255 = alloca i1
  %l259 = alloca i1
  %l263 = alloca i1
  %l264 = alloca i1
  %l266 = alloca { i64, ptr }
  %l271 = alloca { i64, ptr }
  %l278 = alloca i32
  %l281 = alloca i1
  %l285 = alloca i32
  %l288 = alloca i1
  %l292 = alloca i32
  %l296 = alloca i32
  %l301 = alloca i64
  %l305 = alloca i64
  %l307 = alloca { i64, ptr }
  %l312 = alloca { i64, ptr }
  %l313 = alloca i64
  %l315 = alloca ptr
  %l319 = alloca i32
  %l331 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i32 %a3, ptr %l3
  store i1 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l3, !tbaa !23
  %t7 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t7, ptr %l15
  br label %bb1
bb1:
  %t8 = load i32, ptr %l15, !range !{i32 0, i32 33}
  %t10 = trunc i64 30 to i32
  %t11 = icmp eq i32 %t8, %t10
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Binding", ptr %t13, i32 0, i32 2
  %t16 = load { i64, ptr }, ptr %t15, !tbaa !27
  store { i64, ptr } %t16, ptr %l19, !tbaa !27
  %t17 = load i64, ptr %l2, !tbaa !24
  %t19 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr i32, ptr %t20, i64 %t17
  %t22 = load i32, ptr %t21, !tbaa !33
  store i32 %t22, ptr %l6, !tbaa !23
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Binding", ptr %t24, i32 0, i32 2
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %l23, !tbaa !27
  %t28 = load i64, ptr %l2, !tbaa !24
  store i64 %t28, ptr %l24, !tbaa !24
  %t29 = load i32, ptr %l6, !tbaa !23
  %t30 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t33 = icmp eq i32 %t29, %t30
  br i1 %t33, label %bb4, label %bb5
bb3:
  br label %bb12
bb4:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb7
bb5:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 2
  %t38 = load i32, ptr %l6, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l32
  br label %bb6
bb6:
  %t42 = load i32, ptr %l32, !range !{i32 0, i32 33}
  %t44 = trunc i64 30 to i32
  %t45 = icmp eq i32 %t42, %t44
  %t47 = xor i1 %t45, true
  store i1 %t47, ptr %l28, !tbaa !21
  br label %bb7
bb7:
  %t49 = load i1, ptr %l28, !tbaa !21
  br i1 %t49, label %bb8, label %bb9
bb8:
  %t50 = load i32, ptr %l3, !tbaa !23
  store i32 %t50, ptr %l36, !tbaa !23
  br label %bb11
bb9:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i32, ptr %l6, !tbaa !23
  %t54 = load i32, ptr %l3, !tbaa !23
  %t58 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrSetUnion(ptr %v0, ptr %t52, i32 %t53, i32 %t54)
  store i32 %t58, ptr %l41
  br label %bb10
bb10:
  %t59 = load i32, ptr %l41, !tbaa !23
  store i32 %t59, ptr %l36, !tbaa !23
  br label %bb11
bb11:
  %t60 = load i32, ptr %l36, !tbaa !23
  %t61 = load i64, ptr %l24, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr i32, ptr %t63, i64 %t61
  store i32 %t60, ptr %t64, !tbaa !33
  store i32 0, ptr %rv
  br label %ret
bb12:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 2
  %t68 = load i32, ptr %l3, !tbaa !23
  %t71 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t67, i32 %t68)
  store i32 %t71, ptr %l45
  br label %bb13
bb13:
  %t72 = load i32, ptr %l45, !range !{i32 0, i32 33}
  %t74 = trunc i64 21 to i32
  %t75 = icmp eq i32 %t72, %t74
  br i1 %t75, label %bb14, label %bb15
bb14:
  %t77 = load i32, ptr %l3, !tbaa !23
  store i32 %t77, ptr %l48, !tbaa !23
  br label %bb17
bb15:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/generic:Program", ptr %t79, i32 0, i32 2
  %t82 = load i32, ptr %l3, !tbaa !23
  %t85 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t81, i32 %t82)
  store i32 %t85, ptr %l53
  br label %bb16
bb16:
  %t86 = load i32, ptr %l53, !tbaa !23
  store i32 %t86, ptr %l48, !tbaa !23
  br label %bb17
bb17:
  %t87 = load i32, ptr %l48, !tbaa !23
  store i32 %t87, ptr %l7, !tbaa !23
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/generic:Program", ptr %t88, i32 0, i32 11
  %t91 = load i64, ptr %t90, !tbaa !24
  %t93 = icmp eq i64 %t91, 0
  br i1 %t93, label %bb18, label %bb19
bb18:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/generic:Program", ptr %t95, i32 0, i32 2
  %t98 = load i32, ptr %l7, !tbaa !23
  %t101 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t97, i32 %t98)
  store i32 %t101, ptr %l61
  br label %bb20
bb19:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb21
bb20:
  %t102 = load i32, ptr %l61, !range !{i32 0, i32 33}
  %t104 = trunc i64 18 to i32
  %t105 = icmp eq i32 %t102, %t104
  store i1 %t105, ptr %l57, !tbaa !21
  br label %bb21
bb21:
  %t107 = load i1, ptr %l57, !tbaa !21
  br i1 %t107, label %bb22, label %bb23
bb22:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load i32, ptr %l7, !tbaa !23
  %t112 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t108, i32 %t109)
  store i1 %t112, ptr %l67
  br label %bb24
bb23:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb25
bb24:
  %t113 = load i1, ptr %l67, !tbaa !21
  store i1 %t113, ptr %l64, !tbaa !21
  br label %bb25
bb25:
  %t114 = load i1, ptr %l64, !tbaa !21
  br i1 %t114, label %bb26, label %bb27
bb26:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/generic:Program", ptr %t115, i32 0, i32 2
  store ptr %t117, ptr %l70, !tbaa !29
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/generic:Program", ptr %t118, i32 0, i32 2
  %t121 = load i32, ptr %l7, !tbaa !23
  %t124 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t120, i32 %t121)
  store i32 %t124, ptr %l74
  br label %bb28
bb27:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb30
bb28:
  %t125 = load ptr, ptr %l70, !tbaa !29
  %t126 = load i32, ptr %l74, !tbaa !23
  %t127 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t125, i32 %t126)
  store i32 %t127, ptr %l75
  br label %bb29
bb29:
  %t128 = load i32, ptr %l75, !range !{i32 0, i32 6}
  %t130 = trunc i64 0 to i32
  %t131 = icmp eq i32 %t128, %t130
  store i1 %t131, ptr %l68, !tbaa !21
  br label %bb30
bb30:
  %t133 = load i1, ptr %l68, !tbaa !21
  br i1 %t133, label %bb31, label %bb32
bb31:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/generic:Program", ptr %t134, i32 0, i32 2
  %t137 = load i32, ptr %l7, !tbaa !23
  %t140 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %t136, i32 %t137)
  store i1 %t140, ptr %l82
  br label %bb33
bb32:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb34
bb33:
  %t141 = load i1, ptr %l82, !tbaa !21
  store i1 %t141, ptr %l78, !tbaa !21
  br label %bb34
bb34:
  %t142 = load i1, ptr %l78, !tbaa !21
  br i1 %t142, label %bb35, label %bb36
bb35:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/generic:Program", ptr %t143, i32 0, i32 2
  %t146 = load i32, ptr %l7, !tbaa !23
  %t147 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t151 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t145, i32 %t146, i64 %t147)
  store i32 %t151, ptr %l87
  br label %bb37
bb36:
  br label %bb38
bb37:
  %t152 = load i32, ptr %l87, !tbaa !23
  store i32 %t152, ptr %l7, !tbaa !23
  br label %bb38
bb38:
  %t153 = load ptr, ptr %l1, !tbaa !29
  %t155 = getelementptr %"compiler/generic:Binding", ptr %t153, i32 0, i32 2
  %t156 = load { i64, ptr }, ptr %t155, !tbaa !27
  store { i64, ptr } %t156, ptr %l89, !tbaa !27
  %t157 = load i64, ptr %l2, !tbaa !24
  %t159 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = getelementptr i32, ptr %t160, i64 %t157
  %t162 = load i32, ptr %t161, !tbaa !33
  store i32 %t162, ptr %l8, !tbaa !23
  %t164 = load i32, ptr %l8, !tbaa !23
  %t165 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t168 = icmp eq i32 %t164, %t165
  br i1 %t168, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l95, !tbaa !21
  br label %bb44
bb40:
  %t170 = load ptr, ptr %l1, !tbaa !29
  %t172 = getelementptr %"compiler/generic:Binding", ptr %t170, i32 0, i32 3
  %t173 = load { i64, ptr }, ptr %t172, !tbaa !27
  store { i64, ptr } %t173, ptr %l97, !tbaa !27
  %t174 = load i64, ptr %l2, !tbaa !24
  %t176 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr i1, ptr %t177, i64 %t174
  %t179 = load i1, ptr %t178, !tbaa !31
  br i1 %t179, label %bb41, label %bb42
bb41:
  %t181 = load i1, ptr %l4, !tbaa !21
  %t183 = xor i1 %t181, true
  store i1 %t183, ptr %l100, !tbaa !21
  br label %bb43
bb42:
  store i1 false, ptr %l100, !tbaa !21
  br label %bb43
bb43:
  %t185 = load i1, ptr %l100, !tbaa !21
  store i1 %t185, ptr %l95, !tbaa !21
  br label %bb44
bb44:
  %t186 = load i1, ptr %l95, !tbaa !21
  br i1 %t186, label %bb45, label %bb46
bb45:
  %t187 = load ptr, ptr %l1, !tbaa !29
  %t189 = getelementptr %"compiler/generic:Binding", ptr %t187, i32 0, i32 2
  %t190 = load { i64, ptr }, ptr %t189, !tbaa !27
  store { i64, ptr } %t190, ptr %l104, !tbaa !27
  %t191 = load i64, ptr %l2, !tbaa !24
  %t192 = load i32, ptr %l7, !tbaa !23
  %t195 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !27
  %t197 = getelementptr i32, ptr %t196, i64 %t191
  store i32 %t192, ptr %t197, !tbaa !33
  %t198 = load ptr, ptr %l1, !tbaa !29
  %t200 = getelementptr %"compiler/generic:Binding", ptr %t198, i32 0, i32 3
  %t201 = load { i64, ptr }, ptr %t200, !tbaa !27
  store { i64, ptr } %t201, ptr %l108, !tbaa !27
  %t202 = load i64, ptr %l2, !tbaa !24
  %t203 = load i1, ptr %l4, !tbaa !21
  %t206 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t207 = load ptr, ptr %t206, !tbaa !27
  %t208 = getelementptr i1, ptr %t207, i64 %t202
  store i1 %t203, ptr %t208, !tbaa !31
  %t209 = load ptr, ptr %l1, !tbaa !29
  %t211 = getelementptr %"compiler/generic:Binding", ptr %t209, i32 0, i32 4
  %t212 = load { i64, ptr }, ptr %t211, !tbaa !27
  store { i64, ptr } %t212, ptr %l112, !tbaa !27
  %t213 = load i64, ptr %l2, !tbaa !24
  %t217 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t218 = load ptr, ptr %t217, !tbaa !27
  %t219 = getelementptr i1, ptr %t218, i64 %t213
  store i1 %a5, ptr %t219, !tbaa !31
  store i32 0, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  %t220 = load i32, ptr %l8, !tbaa !23
  %t221 = load i32, ptr %l7, !tbaa !23
  %t224 = icmp eq i32 %t220, %t221
  br i1 %t224, label %bb48, label %bb49
bb48:
  store i1 true, ptr %l118, !tbaa !21
  br label %bb51
bb49:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr %"compiler/generic:Program", ptr %t226, i32 0, i32 2
  %t229 = load i32, ptr %l8, !tbaa !23
  %t230 = load i32, ptr %l7, !tbaa !23
  %t234 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t228, i32 %t229, i32 %t230)
  store i1 %t234, ptr %l123
  br label %bb50
bb50:
  %t235 = load i1, ptr %l123, !tbaa !21
  store i1 %t235, ptr %l118, !tbaa !21
  br label %bb51
bb51:
  %t236 = load i1, ptr %l118, !tbaa !21
  br i1 %t236, label %bb52, label %bb53
bb52:
  store i32 0, ptr %rv
  br label %ret
bb53:
  br label %bb54
bb54:
  %t237 = load i1, ptr %l4, !tbaa !21
  br i1 %t237, label %bb55, label %bb56
bb55:
  %t239 = load ptr, ptr %l1, !tbaa !29
  %t241 = getelementptr %"compiler/generic:Binding", ptr %t239, i32 0, i32 3
  %t242 = load { i64, ptr }, ptr %t241, !tbaa !27
  store { i64, ptr } %t242, ptr %l126, !tbaa !27
  %t243 = load i64, ptr %l2, !tbaa !24
  %t245 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t246 = load ptr, ptr %t245, !tbaa !27
  %t247 = getelementptr i1, ptr %t246, i64 %t243
  %t248 = load i1, ptr %t247, !tbaa !31
  br i1 %t248, label %bb57, label %bb58
bb56:
  br label %bb72
bb57:
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t251 = load i32, ptr %l8, !tbaa !23
  %t252 = load i32, ptr %l7, !tbaa !23
  %t256 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFlows(ptr %v0, ptr %t250, i32 %t251, i32 %t252)
  store i1 %t256, ptr %l133
  br label %bb59
bb58:
  store i1 false, ptr %l129, !tbaa !21
  br label %bb68
bb59:
  %t257 = load i1, ptr %l133, !tbaa !21
  br i1 %t257, label %bb60, label %bb61
bb60:
  store i1 true, ptr %l134, !tbaa !21
  br label %bb67
bb61:
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t260 = getelementptr %"compiler/generic:Program", ptr %t258, i32 0, i32 2
  %t261 = load i32, ptr %l8, !tbaa !23
  %t264 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t260, i32 %t261)
  store i1 %t264, ptr %l138
  br label %bb62
bb62:
  %t265 = load i1, ptr %l138, !tbaa !21
  br i1 %t265, label %bb63, label %bb64
bb63:
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t268 = getelementptr %"compiler/generic:Program", ptr %t266, i32 0, i32 2
  %t269 = load i32, ptr %l7, !tbaa !23
  %t272 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t268, i32 %t269)
  store i1 %t272, ptr %l143
  br label %bb65
bb64:
  store i1 false, ptr %l139, !tbaa !21
  br label %bb66
bb65:
  %t273 = load i1, ptr %l143, !tbaa !21
  store i1 %t273, ptr %l139, !tbaa !21
  br label %bb66
bb66:
  %t274 = load i1, ptr %l139, !tbaa !21
  store i1 %t274, ptr %l134, !tbaa !21
  br label %bb67
bb67:
  %t275 = load i1, ptr %l134, !tbaa !21
  store i1 %t275, ptr %l129, !tbaa !21
  br label %bb68
bb68:
  %t276 = load i1, ptr %l129, !tbaa !21
  br i1 %t276, label %bb69, label %bb70
bb69:
  %t277 = load ptr, ptr %l1, !tbaa !29
  %t279 = getelementptr %"compiler/generic:Binding", ptr %t277, i32 0, i32 2
  %t280 = load { i64, ptr }, ptr %t279, !tbaa !27
  store { i64, ptr } %t280, ptr %l145, !tbaa !27
  %t281 = load i64, ptr %l2, !tbaa !24
  %t282 = load i32, ptr %l7, !tbaa !23
  %t285 = getelementptr { i64, ptr }, ptr %l145, i32 0, i32 1
  %t286 = load ptr, ptr %t285, !tbaa !27
  %t287 = getelementptr i32, ptr %t286, i64 %t281
  store i32 %t282, ptr %t287, !tbaa !33
  br label %bb71
bb70:
  br label %bb71
bb71:
  store i32 0, ptr %rv
  br label %ret
bb72:
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t290 = getelementptr %"compiler/generic:Program", ptr %t288, i32 0, i32 2
  %t291 = load i32, ptr %l7, !tbaa !23
  %t294 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t290, i32 %t291)
  store i32 %t294, ptr %l151
  br label %bb73
bb73:
  %t295 = load i32, ptr %l151, !range !{i32 0, i32 33}
  %t297 = trunc i64 20 to i32
  %t298 = icmp eq i32 %t295, %t297
  br i1 %t298, label %bb74, label %bb75
bb74:
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t302 = getelementptr %"compiler/generic:Program", ptr %t300, i32 0, i32 2
  %t303 = load i32, ptr %l8, !tbaa !23
  %t306 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t302, i32 %t303)
  store i32 %t306, ptr %l158
  br label %bb76
bb75:
  store i1 false, ptr %l154, !tbaa !21
  br label %bb77
bb76:
  %t307 = load i32, ptr %l158, !range !{i32 0, i32 33}
  %t309 = trunc i64 20 to i32
  %t310 = icmp eq i32 %t307, %t309
  %t312 = xor i1 %t310, true
  store i1 %t312, ptr %l154, !tbaa !21
  br label %bb77
bb77:
  %t314 = load i1, ptr %l154, !tbaa !21
  br i1 %t314, label %bb78, label %bb79
bb78:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t317 = getelementptr %"compiler/generic:Program", ptr %t315, i32 0, i32 2
  store ptr %t317, ptr %l164, !tbaa !29
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t320 = getelementptr %"compiler/generic:Program", ptr %t318, i32 0, i32 2
  %t321 = load i32, ptr %l7, !tbaa !23
  %t324 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t320, i32 %t321)
  store i32 %t324, ptr %l168
  br label %bb80
bb79:
  store i1 false, ptr %l162, !tbaa !21
  br label %bb82
bb80:
  %t325 = load ptr, ptr %l164, !tbaa !29
  %t326 = load i32, ptr %l168, !tbaa !23
  %t327 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t325, i32 %t326)
  store i32 %t327, ptr %l169
  br label %bb81
bb81:
  %t328 = load i32, ptr %l8, !tbaa !23
  %t329 = load i32, ptr %l169, !tbaa !23
  %t331 = icmp eq i32 %t329, %t328
  store i1 %t331, ptr %l162, !tbaa !21
  br label %bb82
bb82:
  %t333 = load i1, ptr %l162, !tbaa !21
  br i1 %t333, label %bb83, label %bb84
bb83:
  store i32 0, ptr %rv
  br label %ret
bb84:
  br label %bb85
bb85:
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t336 = getelementptr %"compiler/generic:Program", ptr %t334, i32 0, i32 2
  %t337 = load i32, ptr %l7, !tbaa !23
  %t340 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t336, i32 %t337)
  store i32 %t340, ptr %l175
  br label %bb86
bb86:
  %t341 = load i32, ptr %l175, !range !{i32 0, i32 33}
  %t343 = trunc i64 20 to i32
  %t344 = icmp eq i32 %t341, %t343
  br i1 %t344, label %bb87, label %bb88
bb87:
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t348 = getelementptr %"compiler/generic:Program", ptr %t346, i32 0, i32 2
  store ptr %t348, ptr %l180, !tbaa !29
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t351 = getelementptr %"compiler/generic:Program", ptr %t349, i32 0, i32 2
  %t352 = load i32, ptr %l7, !tbaa !23
  %t355 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t351, i32 %t352)
  store i32 %t355, ptr %l184
  br label %bb89
bb88:
  %t356 = load i32, ptr %l7, !tbaa !23
  store i32 %t356, ptr %l178, !tbaa !23
  br label %bb91
bb89:
  %t358 = load ptr, ptr %l180, !tbaa !29
  %t359 = load i32, ptr %l184, !tbaa !23
  %t360 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t358, i32 %t359)
  store i32 %t360, ptr %l185
  br label %bb90
bb90:
  %t361 = load i32, ptr %l185, !tbaa !23
  store i32 %t361, ptr %l178, !tbaa !23
  br label %bb91
bb91:
  %t362 = load i32, ptr %l178, !tbaa !23
  store i32 %t362, ptr %l9, !tbaa !23
  %t363 = load ptr, ptr %l0, !tbaa !29
  %t365 = getelementptr %"compiler/generic:Program", ptr %t363, i32 0, i32 2
  %t366 = load i32, ptr %l8, !tbaa !23
  %t369 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t365, i32 %t366)
  store i32 %t369, ptr %l190
  br label %bb92
bb92:
  %t370 = load i32, ptr %l190, !range !{i32 0, i32 33}
  %t372 = trunc i64 19 to i32
  %t373 = icmp eq i32 %t370, %t372
  br i1 %t373, label %bb93, label %bb94
bb93:
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t377 = getelementptr %"compiler/generic:Program", ptr %t375, i32 0, i32 2
  %t378 = load i32, ptr %l9, !tbaa !23
  %t381 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t377, i32 %t378)
  store i32 %t381, ptr %l197
  br label %bb95
bb94:
  store i1 false, ptr %l193, !tbaa !21
  br label %bb96
bb95:
  %t382 = load i32, ptr %l197, !range !{i32 0, i32 33}
  %t384 = trunc i64 19 to i32
  %t385 = icmp eq i32 %t382, %t384
  store i1 %t385, ptr %l193, !tbaa !21
  br label %bb96
bb96:
  %t387 = load i1, ptr %l193, !tbaa !21
  br i1 %t387, label %bb97, label %bb98
bb97:
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t390 = getelementptr %"compiler/generic:Program", ptr %t388, i32 0, i32 2
  store ptr %t390, ptr %l202, !tbaa !29
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t393 = getelementptr %"compiler/generic:Program", ptr %t391, i32 0, i32 2
  %t394 = load i32, ptr %l8, !tbaa !23
  %t397 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t393, i32 %t394)
  store i32 %t397, ptr %l206
  br label %bb99
bb98:
  store i1 false, ptr %l200, !tbaa !21
  br label %bb102
bb99:
  %t398 = load ptr, ptr %l0, !tbaa !29
  %t400 = getelementptr %"compiler/generic:Program", ptr %t398, i32 0, i32 2
  %t401 = load i32, ptr %l9, !tbaa !23
  %t404 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t400, i32 %t401)
  store i32 %t404, ptr %l210
  br label %bb100
bb100:
  %t405 = load ptr, ptr %l202, !tbaa !29
  %t406 = load i32, ptr %l206, !tbaa !23
  %t407 = load i32, ptr %l210, !tbaa !23
  %t408 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t405, i32 %t406, i32 %t407)
  store i1 %t408, ptr %l211
  br label %bb101
bb101:
  %t409 = load i1, ptr %l211, !tbaa !21
  store i1 %t409, ptr %l200, !tbaa !21
  br label %bb102
bb102:
  %t410 = load i1, ptr %l200, !tbaa !21
  br i1 %t410, label %bb103, label %bb104
bb103:
  %t411 = load ptr, ptr %l1, !tbaa !29
  %t413 = getelementptr %"compiler/generic:Binding", ptr %t411, i32 0, i32 4
  %t414 = load { i64, ptr }, ptr %t413, !tbaa !27
  store { i64, ptr } %t414, ptr %l214, !tbaa !27
  %t415 = load i64, ptr %l2, !tbaa !24
  %t417 = getelementptr { i64, ptr }, ptr %l214, i32 0, i32 1
  %t418 = load ptr, ptr %t417, !tbaa !27
  %t419 = getelementptr i1, ptr %t418, i64 %t415
  %t420 = load i1, ptr %t419, !tbaa !31
  %t422 = xor i1 %t420, true
  store i1 %t422, ptr %l212, !tbaa !21
  br label %bb105
bb104:
  store i1 false, ptr %l212, !tbaa !21
  br label %bb105
bb105:
  %t424 = load i1, ptr %l212, !tbaa !21
  br i1 %t424, label %bb106, label %bb107
bb106:
  %t425 = load ptr, ptr %l0, !tbaa !29
  %t427 = getelementptr %"compiler/generic:Program", ptr %t425, i32 0, i32 2
  %t428 = load i32, ptr %l8, !tbaa !23
  %t431 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t427, i32 %t428)
  store i32 %t431, ptr %l221
  br label %bb108
bb107:
  br label %bb119
bb108:
  %t432 = load i32, ptr %l221, !tbaa !23
  %t433 = icmp ne i32 %t432, 0
  br i1 %t433, label %bb109, label %bb110
bb109:
  %t435 = load ptr, ptr %l0, !tbaa !29
  %t437 = getelementptr %"compiler/generic:Program", ptr %t435, i32 0, i32 2
  %t438 = load i32, ptr %l9, !tbaa !23
  %t441 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t437, i32 %t438)
  store i32 %t441, ptr %l227
  br label %bb111
bb110:
  store i1 false, ptr %l223, !tbaa !21
  br label %bb113
bb111:
  %t442 = load ptr, ptr %l0, !tbaa !29
  %t444 = getelementptr %"compiler/generic:Program", ptr %t442, i32 0, i32 2
  %t445 = load i32, ptr %l8, !tbaa !23
  %t448 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t444, i32 %t445)
  store i32 %t448, ptr %l231
  br label %bb112
bb112:
  %t449 = load i32, ptr %l227, !tbaa !23
  %t450 = load i32, ptr %l231, !tbaa !23
  %t451 = icmp ne i32 %t449, %t450
  store i1 %t451, ptr %l223, !tbaa !21
  br label %bb113
bb113:
  %t453 = load i1, ptr %l223, !tbaa !21
  br i1 %t453, label %bb114, label %bb115
bb114:
  %t454 = load ptr, ptr %l1, !tbaa !29
  %t456 = getelementptr %"compiler/generic:Binding", ptr %t454, i32 0, i32 2
  %t457 = load { i64, ptr }, ptr %t456, !tbaa !27
  store { i64, ptr } %t457, ptr %l234, !tbaa !27
  %t458 = load i64, ptr %l2, !tbaa !24
  store i64 %t458, ptr %l235, !tbaa !24
  %t459 = load ptr, ptr %l0, !tbaa !29
  %t461 = getelementptr %"compiler/generic:Program", ptr %t459, i32 0, i32 2
  store ptr %t461, ptr %l237, !tbaa !29
  %t462 = load ptr, ptr %l0, !tbaa !29
  %t464 = getelementptr %"compiler/generic:Program", ptr %t462, i32 0, i32 2
  %t465 = load i32, ptr %l8, !tbaa !23
  %t468 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t464, i32 %t465)
  store i32 %t468, ptr %l241
  br label %bb116
bb115:
  br label %bb118
bb116:
  %t469 = load ptr, ptr %l237, !tbaa !29
  %t470 = load i32, ptr %l241, !tbaa !23
  %t471 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t469, i32 %t470, i32 0)
  store i32 %t471, ptr %l242
  br label %bb117
bb117:
  %t472 = load i32, ptr %l242, !tbaa !23
  %t473 = load i64, ptr %l235, !tbaa !24
  %t474 = getelementptr { i64, ptr }, ptr %l234, i32 0, i32 1
  %t475 = load ptr, ptr %t474, !tbaa !27
  %t476 = getelementptr i32, ptr %t475, i64 %t473
  store i32 %t472, ptr %t476, !tbaa !33
  br label %bb118
bb118:
  store i32 0, ptr %rv
  br label %ret
bb119:
  %t477 = load ptr, ptr %l0, !tbaa !29
  %t479 = getelementptr %"compiler/generic:Program", ptr %t477, i32 0, i32 2
  store ptr %t479, ptr %l244, !tbaa !29
  %t480 = load ptr, ptr %l0, !tbaa !29
  %t481 = load i32, ptr %l8, !tbaa !23
  %t484 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2enumberOf(ptr %v0, ptr %t480, i32 %t481)
  store i32 %t484, ptr %l247
  br label %bb120
bb120:
  %t485 = load ptr, ptr %l244, !tbaa !29
  %t486 = load i32, ptr %l247, !tbaa !23
  %t487 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t485, i32 %t486)
  store i1 %t487, ptr %l248
  br label %bb121
bb121:
  %t488 = load i1, ptr %l248, !tbaa !21
  br i1 %t488, label %bb122, label %bb123
bb122:
  %t489 = load ptr, ptr %l0, !tbaa !29
  %t491 = getelementptr %"compiler/generic:Program", ptr %t489, i32 0, i32 2
  store ptr %t491, ptr %l251, !tbaa !29
  %t492 = load ptr, ptr %l0, !tbaa !29
  %t493 = load i32, ptr %l7, !tbaa !23
  %t496 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2enumberOf(ptr %v0, ptr %t492, i32 %t493)
  store i32 %t496, ptr %l254
  br label %bb124
bb123:
  store i1 false, ptr %l249, !tbaa !21
  br label %bb126
bb124:
  %t497 = load ptr, ptr %l251, !tbaa !29
  %t498 = load i32, ptr %l254, !tbaa !23
  %t499 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t497, i32 %t498)
  store i1 %t499, ptr %l255
  br label %bb125
bb125:
  %t500 = load i1, ptr %l255, !tbaa !21
  store i1 %t500, ptr %l249, !tbaa !21
  br label %bb126
bb126:
  %t501 = load i1, ptr %l249, !tbaa !21
  br i1 %t501, label %bb127, label %bb128
bb127:
  %t502 = load ptr, ptr %l0, !tbaa !29
  %t503 = load i32, ptr %l7, !tbaa !23
  %t504 = load i32, ptr %l8, !tbaa !23
  %t508 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFlows(ptr %v0, ptr %t502, i32 %t503, i32 %t504)
  store i1 %t508, ptr %l259
  br label %bb129
bb128:
  br label %bb140
bb129:
  %t509 = load i1, ptr %l259, !tbaa !21
  br i1 %t509, label %bb130, label %bb131
bb130:
  store i32 0, ptr %rv
  br label %ret
bb131:
  br label %bb132
bb132:
  %t510 = load ptr, ptr %l0, !tbaa !29
  %t511 = load i32, ptr %l8, !tbaa !23
  %t512 = load i32, ptr %l7, !tbaa !23
  %t516 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFlows(ptr %v0, ptr %t510, i32 %t511, i32 %t512)
  store i1 %t516, ptr %l263
  br label %bb133
bb133:
  %t517 = load i1, ptr %l263, !tbaa !21
  br i1 %t517, label %bb134, label %bb135
bb134:
  %t518 = load ptr, ptr %l1, !tbaa !29
  %t520 = getelementptr %"compiler/generic:Binding", ptr %t518, i32 0, i32 4
  %t521 = load { i64, ptr }, ptr %t520, !tbaa !27
  store { i64, ptr } %t521, ptr %l266, !tbaa !27
  %t522 = load i64, ptr %l2, !tbaa !24
  %t524 = getelementptr { i64, ptr }, ptr %l266, i32 0, i32 1
  %t525 = load ptr, ptr %t524, !tbaa !27
  %t526 = getelementptr i1, ptr %t525, i64 %t522
  %t527 = load i1, ptr %t526, !tbaa !31
  %t529 = xor i1 %t527, true
  store i1 %t529, ptr %l264, !tbaa !21
  br label %bb136
bb135:
  store i1 false, ptr %l264, !tbaa !21
  br label %bb136
bb136:
  %t531 = load i1, ptr %l264, !tbaa !21
  br i1 %t531, label %bb137, label %bb138
bb137:
  %t532 = load ptr, ptr %l1, !tbaa !29
  %t534 = getelementptr %"compiler/generic:Binding", ptr %t532, i32 0, i32 2
  %t535 = load { i64, ptr }, ptr %t534, !tbaa !27
  store { i64, ptr } %t535, ptr %l271, !tbaa !27
  %t536 = load i64, ptr %l2, !tbaa !24
  %t537 = load i32, ptr %l7, !tbaa !23
  %t540 = getelementptr { i64, ptr }, ptr %l271, i32 0, i32 1
  %t541 = load ptr, ptr %t540, !tbaa !27
  %t542 = getelementptr i32, ptr %t541, i64 %t536
  store i32 %t537, ptr %t542, !tbaa !33
  store i32 0, ptr %rv
  br label %ret
bb138:
  br label %bb139
bb139:
  store i32 65536, ptr %rv
  br label %ret
bb140:
  %t544 = load ptr, ptr %l0, !tbaa !29
  %t546 = getelementptr %"compiler/generic:Program", ptr %t544, i32 0, i32 2
  %t547 = load i32, ptr %l8, !tbaa !23
  %t550 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t546, i32 %t547)
  store i32 %t550, ptr %l278
  br label %bb141
bb141:
  %t551 = load i32, ptr %l278, !range !{i32 0, i32 33}
  %t553 = trunc i64 20 to i32
  %t554 = icmp eq i32 %t551, %t553
  br i1 %t554, label %bb142, label %bb143
bb142:
  %t556 = load ptr, ptr %l0, !tbaa !29
  %t558 = getelementptr %"compiler/generic:Program", ptr %t556, i32 0, i32 2
  %t559 = load i32, ptr %l7, !tbaa !23
  %t562 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t558, i32 %t559)
  store i32 %t562, ptr %l285
  br label %bb144
bb143:
  store i1 false, ptr %l281, !tbaa !21
  br label %bb145
bb144:
  %t563 = load i32, ptr %l285, !range !{i32 0, i32 33}
  %t565 = trunc i64 20 to i32
  %t566 = icmp eq i32 %t563, %t565
  store i1 %t566, ptr %l281, !tbaa !21
  br label %bb145
bb145:
  %t568 = load i1, ptr %l281, !tbaa !21
  br i1 %t568, label %bb146, label %bb147
bb146:
  %t569 = load ptr, ptr %l0, !tbaa !29
  %t571 = getelementptr %"compiler/generic:Program", ptr %t569, i32 0, i32 2
  %t572 = load i32, ptr %l8, !tbaa !23
  %t575 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t571, i32 %t572)
  store i32 %t575, ptr %l292
  br label %bb148
bb147:
  store i1 false, ptr %l288, !tbaa !21
  br label %bb150
bb148:
  %t576 = load ptr, ptr %l0, !tbaa !29
  %t578 = getelementptr %"compiler/generic:Program", ptr %t576, i32 0, i32 2
  %t579 = load i32, ptr %l7, !tbaa !23
  %t582 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t578, i32 %t579)
  store i32 %t582, ptr %l296
  br label %bb149
bb149:
  %t583 = load i32, ptr %l292, !tbaa !23
  %t584 = load i32, ptr %l296, !tbaa !23
  %t585 = icmp eq i32 %t583, %t584
  store i1 %t585, ptr %l288, !tbaa !21
  br label %bb150
bb150:
  %t587 = load i1, ptr %l288, !tbaa !21
  br i1 %t587, label %bb151, label %bb152
bb151:
  %t588 = load ptr, ptr %l0, !tbaa !29
  %t590 = getelementptr %"compiler/generic:Program", ptr %t588, i32 0, i32 2
  %t591 = load i32, ptr %l8, !tbaa !23
  %t594 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t590, i32 %t591)
  store i64 %t594, ptr %l301
  br label %bb153
bb152:
  br label %bb160
bb153:
  %t595 = load i64, ptr %l301, !tbaa !24
  store i64 %t595, ptr %l10, !tbaa !24
  %t596 = load ptr, ptr %l0, !tbaa !29
  %t598 = getelementptr %"compiler/generic:Program", ptr %t596, i32 0, i32 2
  %t599 = load i32, ptr %l7, !tbaa !23
  %t602 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t598, i32 %t599)
  store i64 %t602, ptr %l305
  br label %bb154
bb154:
  %t603 = load i64, ptr %l305, !tbaa !24
  store i64 %t603, ptr %l11, !tbaa !24
  %t604 = load ptr, ptr %l1, !tbaa !29
  %t606 = getelementptr %"compiler/generic:Binding", ptr %t604, i32 0, i32 4
  %t607 = load { i64, ptr }, ptr %t606, !tbaa !27
  store { i64, ptr } %t607, ptr %l307, !tbaa !27
  %t608 = load i64, ptr %l2, !tbaa !24
  %t610 = getelementptr { i64, ptr }, ptr %l307, i32 0, i32 1
  %t611 = load ptr, ptr %t610, !tbaa !27
  %t612 = getelementptr i1, ptr %t611, i64 %t608
  %t613 = load i1, ptr %t612, !tbaa !31
  %t615 = xor i1 %t613, true
  br i1 %t615, label %bb155, label %bb156
bb155:
  %t617 = load ptr, ptr %l1, !tbaa !29
  %t619 = getelementptr %"compiler/generic:Binding", ptr %t617, i32 0, i32 2
  %t620 = load { i64, ptr }, ptr %t619, !tbaa !27
  store { i64, ptr } %t620, ptr %l312, !tbaa !27
  %t621 = load i64, ptr %l2, !tbaa !24
  store i64 %t621, ptr %l313, !tbaa !24
  %t622 = load ptr, ptr %l0, !tbaa !29
  %t624 = getelementptr %"compiler/generic:Program", ptr %t622, i32 0, i32 2
  store ptr %t624, ptr %l315, !tbaa !29
  %t625 = load ptr, ptr %l0, !tbaa !29
  %t627 = getelementptr %"compiler/generic:Program", ptr %t625, i32 0, i32 2
  %t628 = load i32, ptr %l7, !tbaa !23
  %t631 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t627, i32 %t628)
  store i32 %t631, ptr %l319
  br label %bb157
bb156:
  br label %bb159
bb157:
  %t632 = load i64, ptr %l10, !tbaa !24
  %t633 = load i64, ptr %l11, !tbaa !24
  %t636 = and i64 %t632, %t633
  %t637 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t640 = and i64 %t636, %t637
  %t641 = load i64, ptr %l10, !tbaa !24
  %t642 = load i64, ptr %l11, !tbaa !24
  %t645 = or i64 %t641, %t642
  %t646 = load i64, ptr @G_2ecompiler_2ftypes_2eNullable, !tbaa !24
  %t649 = and i64 %t645, %t646
  %t652 = or i64 %t640, %t649
  %t653 = load ptr, ptr %l315, !tbaa !29
  %t654 = load i32, ptr %l319, !tbaa !23
  %t656 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t653, i32 %t654, i64 %t652)
  store i32 %t656, ptr %l331
  br label %bb158
bb158:
  %t657 = load i32, ptr %l331, !tbaa !23
  %t658 = load i64, ptr %l313, !tbaa !24
  %t659 = getelementptr { i64, ptr }, ptr %l312, i32 0, i32 1
  %t660 = load ptr, ptr %t659, !tbaa !27
  %t661 = getelementptr i32, ptr %t660, i64 %t658
  store i32 %t657, ptr %t661, !tbaa !33
  br label %bb159
bb159:
  store i32 0, ptr %rv
  br label %ret
bb160:
  store i32 65536, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, i32 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ecanonEnum(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca i64
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca i1
  %l12 = alloca i64
  %l14 = alloca i1
  %l16 = alloca i1
  %l27 = alloca i1
  %l29 = alloca i8
  %l30 = alloca i1
  %l31 = alloca i1
  %l33 = alloca i8
  %l34 = alloca i1
  %l35 = alloca i1
  %l37 = alloca i8
  %l40 = alloca ptr
  %l44 = alloca ptr
  %l47 = alloca ptr
  %l49 = alloca { i64, ptr }
  %l50 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l58 = alloca i32
  %l60 = alloca i1
  %l61 = alloca ptr
  %l63 = alloca ptr
  %l64 = alloca i32
  %l67 = alloca i32
  %l68 = alloca i32
  %l70 = alloca i32
  %l73 = alloca ptr
  %l75 = alloca { i64, ptr }
  %l77 = alloca ptr
  %l79 = alloca { i64, ptr }
  %l80 = alloca i32
  %l84 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i32, i32 }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l6
  br label %bb2
bb2:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l3
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2eeat(ptr %v1, ptr %s1, ptr %t5, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) })
  store i1 %t7, ptr %l8
  br label %bb4
bb4:
  %t8 = load i1, ptr %l8, !tbaa !21
  %t9 = xor i1 %t8, true
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %bb55
bb6:
  br label %bb7
bb7:
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l2)
  store i64 %t14, ptr %l12
  br label %bb8
bb8:
  %t15 = load i64, ptr %l12, !tbaa !24
  %t16 = icmp sgt i64 %t15, 0
  br i1 %t16, label %bb9, label %bb10
bb9:
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2eeat(ptr %v1, ptr %s1, ptr %t18, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) })
  store i1 %t20, ptr %l16
  br label %bb11
bb10:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb12
bb11:
  %t21 = load i1, ptr %l16, !tbaa !21
  %t22 = xor i1 %t21, true
  store i1 %t22, ptr %l14, !tbaa !21
  br label %bb12
bb12:
  %t24 = load i1, ptr %l14, !tbaa !21
  br i1 %t24, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t26 = insertvalue { i32, i32 } zeroinitializer, i32 65536, 0
  store { i32, i32 } %t26, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr %"compiler/generic:cursor", ptr %t27, i32 0, i32 1
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l4, !tbaa !24
  br label %bb16
bb16:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr %"compiler/generic:cursor", ptr %t32, i32 0, i32 1
  %t35 = load i64, ptr %t34, !tbaa !24
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t38 = getelementptr %"compiler/generic:cursor", ptr %t36, i32 0, i32 0
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t44 = icmp slt i64 %t35, %t41
  br i1 %t44, label %bb17, label %bb18
bb17:
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t48 = call i8 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2epeek(ptr %v1, ptr %t46)
  store i8 %t48, ptr %l29
  br label %bb19
bb18:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb30
bb19:
  %t49 = load i8, ptr %l29, !tbaa !22
  %t50 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t49)
  store i1 %t50, ptr %l30
  br label %bb20
bb20:
  %t51 = load i1, ptr %l30, !tbaa !21
  br i1 %t51, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb25
bb22:
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = call i8 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2epeek(ptr %v1, ptr %t52)
  store i8 %t54, ptr %l33
  br label %bb23
bb23:
  %t55 = load i8, ptr %l33, !tbaa !22
  %t56 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t55)
  store i1 %t56, ptr %l34
  br label %bb24
bb24:
  %t57 = load i1, ptr %l34, !tbaa !21
  store i1 %t57, ptr %l31, !tbaa !21
  br label %bb25
bb25:
  %t58 = load i1, ptr %l31, !tbaa !21
  br i1 %t58, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb29
bb27:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = call i8 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2epeek(ptr %v1, ptr %t59)
  store i8 %t61, ptr %l37
  br label %bb28
bb28:
  %t62 = load i8, ptr %l37, !tbaa !22
  %t63 = icmp eq i8 %t62, 95
  store i1 %t63, ptr %l35, !tbaa !21
  br label %bb29
bb29:
  %t65 = load i1, ptr %l35, !tbaa !21
  store i1 %t65, ptr %l27, !tbaa !21
  br label %bb30
bb30:
  %t66 = load i1, ptr %l27, !tbaa !21
  %t67 = xor i1 %t66, true
  br i1 %t67, label %bb31, label %bb32
bb31:
  br label %bb35
bb32:
  br label %bb33
bb33:
  %t69 = load ptr, ptr %l1, !tbaa !29
  store ptr %t69, ptr %l40, !tbaa !29
  %t70 = load ptr, ptr %l40, !tbaa !29
  %t71 = getelementptr %"compiler/generic:cursor", ptr %t70, i32 0, i32 1
  %t72 = load i64, ptr %t71, !tbaa !24
  %t75 = add i64 %t72, 1
  %t77 = load ptr, ptr %l40, !tbaa !29
  %t78 = getelementptr %"compiler/generic:cursor", ptr %t77, i32 0, i32 1
  store i64 %t75, ptr %t78, !tbaa !24
  br label %bb34
bb34:
  br label %bb16
bb35:
  store ptr %l2, ptr %l44, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/generic:Program", ptr %t79, i32 0, i32 0
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = getelementptr %"compiler/load:Loader", ptr %t82, i32 0, i32 3
  %t85 = load ptr, ptr %t84, !tbaa !29
  store ptr %t85, ptr %l47, !tbaa !29
  %t86 = load ptr, ptr %l1, !tbaa !29
  %t88 = getelementptr %"compiler/generic:cursor", ptr %t86, i32 0, i32 0
  %t89 = load { i64, ptr }, ptr %t88, !tbaa !27
  store { i64, ptr } %t89, ptr %l49, !tbaa !27
  %t90 = load i64, ptr %l4, !tbaa !24
  store i64 %t90, ptr %l50, !tbaa !24
  %t91 = load ptr, ptr %l1, !tbaa !29
  %t93 = getelementptr %"compiler/generic:cursor", ptr %t91, i32 0, i32 1
  %t94 = load i64, ptr %t93, !tbaa !24
  store i64 %t94, ptr %l52, !tbaa !24
  %t95 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t95, 0
  store i64 %t96, ptr %l53, !tbaa !24
  %t97 = load i64, ptr %l50, !tbaa !24
  %t98 = icmp sge i64 %t97, 0
  br i1 %t98, label %bb36, label %bb37
bb36:
  %t100 = load i64, ptr %l50, !tbaa !24
  %t101 = load i64, ptr %l52, !tbaa !24
  %t102 = icmp sle i64 %t100, %t101
  br i1 %t102, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_510ce85b2a9a6c03_b867f874fd10b7a7)
  unreachable
bb38:
  %t104 = load i64, ptr %l52, !tbaa !24
  %t105 = load i64, ptr %l53, !tbaa !24
  %t106 = icmp sle i64 %t104, %t105
  br i1 %t106, label %bb40, label %bb41
bb39:
  call void @__olang_check_failed(ptr @olang_loc_510ce85b2a9a6c03_b867f874fd10b7a7)
  unreachable
bb40:
  %t108 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = load i64, ptr %l50, !tbaa !24
  %t111 = load i64, ptr %l52, !tbaa !24
  %t112 = getelementptr i8, ptr %t109, i64 %t110
  %t113 = sub i64 %t111, %t110
  %t114 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t112, 1
  %t116 = load ptr, ptr %l47, !tbaa !29
  %t118 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %t116, { i64, ptr } %t115)
  store i32 %t118, ptr %l58
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_510ce85b2a9a6c03_b867f874fd10b7a7)
  unreachable
bb42:
  %t119 = load ptr, ptr %l44, !tbaa !29
  %t120 = load i32, ptr %l58, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %t119, i32 %t120)
  br label %bb43
bb43:
  %t121 = load ptr, ptr %l1, !tbaa !29
  %t123 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2eeat(ptr %v1, ptr %s1, ptr %t121, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d30, i32 0, i32 1) })
  store i1 %t123, ptr %l60
  br label %bb44
bb44:
  %t124 = load i1, ptr %l60, !tbaa !21
  br i1 %t124, label %bb45, label %bb46
bb45:
  store %olang.scope zeroinitializer, ptr %s4
  store ptr %l3, ptr %l61, !tbaa !29
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/generic:Program", ptr %t125, i32 0, i32 2
  store ptr %t127, ptr %l63, !tbaa !29
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load ptr, ptr %l1, !tbaa !29
  %t132 = call { i32, i32 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ecanonList(ptr %v0, ptr %v1, ptr %s4, ptr %t128, ptr %t129, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) })
  %t133 = extractvalue { i32, i32 } %t132, 1
  %t134 = extractvalue { i32, i32 } %t132, 0
  store i32 %t134, ptr %l68
  %t135 = icmp ne i32 %t134, 0
  br i1 %t135, label %bb48, label %ok.136, !prof !99
ok.136:
  store i32 %t133, ptr %l67
  br label %bb47
bb46:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l3, i32 0)
  br label %bb52
bb47:
  %t138 = load i32, ptr %l67, !tbaa !23
  store i32 %t138, ptr %l64, !tbaa !23
  br label %bb49
bb48:
  %t139 = load i32, ptr %l68, !tbaa !23
  %t140 = lshr i32 %t139, 16
  %t141 = and i32 %t139, 65535
  %t142 = icmp eq i32 %t140, 1
  %t143 = select i1 %t142, i32 1, i32 0
  %t144 = icmp eq i32 %t140, 2
  %t145 = select i1 %t144, i32 2, i32 %t143
  %t146 = icmp eq i32 %t139, 0
  %t147 = shl i32 %t145, 16
  %t148 = or i32 %t147, %t141
  %t149 = select i1 %t146, i32 0, i32 %t148
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t151 = insertvalue { i32, i32 } zeroinitializer, i32 %t149, 0
  store { i32, i32 } %t151, ptr %rv
  br label %ret
bb49:
  %t152 = load ptr, ptr %l63, !tbaa !29
  %t153 = load i32, ptr %l64, !tbaa !23
  %t154 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRecord(ptr %v0, ptr %t152, i32 %t153)
  store i32 %t154, ptr %l70
  br label %bb50
bb50:
  %t155 = load ptr, ptr %l61, !tbaa !29
  %t156 = load i32, ptr %l70, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t155, i32 %t156)
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s4)
  br label %bb53
bb52:
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s1)
  br label %bb54
bb54:
  br label %bb3
bb55:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/generic:Program", ptr %t157, i32 0, i32 2
  store ptr %t159, ptr %l73, !tbaa !29
  %t161 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eToArra_H4d02a0b2e27e8f31ffc99daa43750593(ptr %s0, ptr %s0, ptr %l2)
  store { i64, ptr } %t161, ptr %l75
  br label %bb56
bb56:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/generic:Program", ptr %t162, i32 0, i32 2
  store ptr %t164, ptr %l77, !tbaa !29
  %t166 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %s0, ptr %l3)
  store { i64, ptr } %t166, ptr %l79
  br label %bb57
bb57:
  %t167 = load ptr, ptr %l77, !tbaa !29
  %t168 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t169 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t167, { i64, ptr } %t168)
  store i32 %t169, ptr %l80
  br label %bb58
bb58:
  %t170 = icmp sge i64 0, 0
  br i1 %t170, label %bb59, label %bb60
bb59:
  %t172 = icmp sle i64 0, 2305843009213693951
  br i1 %t172, label %bb61, label %bb62
bb60:
  call void @__olang_check_failed(ptr @olang_loc_3e2c33a947ef0926_eb9e7dc4e2170cd2)
  unreachable
bb61:
  %t174 = mul i64 0, 4
  %t175 = insertvalue { i64, ptr } undef, i64 0, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t177 = load ptr, ptr %l73, !tbaa !29
  %t178 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t179 = load i32, ptr %l80, !tbaa !23
  %t181 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnonEnum(ptr %v0, ptr %s0, ptr %s0, ptr %t177, { i64, ptr } %t178, i32 %t179, { i64, ptr } %t176)
  store i32 %t181, ptr %l84
  br label %bb63
bb62:
  call void @__olang_check_failed(ptr @olang_loc_3e2c33a947ef0926_eb9e7dc4e2170cd2)
  unreachable
bb63:
  call void @__olang_scope_close(ptr %s0)
  %t182 = load i32, ptr %l84, !tbaa !23
  %t183 = insertvalue { i32, i32 } zeroinitializer, i32 %t182, 1
  store { i32, i32 } %t183, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local { i32, i64 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ecanonPromises(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l21 = alloca i1
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i32
  %l35 = alloca i1
  %l36 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i32
  %l43 = alloca i1
  %l44 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i32
  %l50 = alloca i1
  %l59 = alloca i1
  %l61 = alloca i8
  %l62 = alloca i1
  %l63 = alloca i1
  %l65 = alloca i8
  %l66 = alloca i1
  %l67 = alloca i1
  %l69 = alloca i8
  %l72 = alloca ptr
  %l78 = alloca ptr
  %l80 = alloca { i64, ptr }
  %l81 = alloca i64
  %l83 = alloca i64
  %l84 = alloca i64
  %l89 = alloca i32
  %l115 = alloca i64
  %l118 = alloca i64
  %l138 = alloca i1
  %l142 = alloca i1
  %l152 = alloca i64
  %l156 = alloca i1
  %l158 = alloca i1
  %l162 = alloca ptr
  %l163 = alloca i64
  %l165 = alloca { i64, ptr }
  %l167 = alloca { i64, ptr }
  %l168 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca { i32, i64 }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2eeat(ptr %v1, ptr %s0, ptr %t1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d32, i32 0, i32 1) })
  store i1 %t3, ptr %l21
  br label %bb1
bb1:
  %t4 = load i1, ptr %l21, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t8 = insertvalue { i32, i64 } zeroinitializer, i64 0, 1
  store { i32, i64 } %t8, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store i64 0, ptr %l2, !tbaa !24
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l24
  br label %bb5
bb5:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l3
  %t11 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %l25
  br label %bb6
bb6:
  %t12 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t12, ptr %l4
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2eeat(ptr %v1, ptr %s2, ptr %t13, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d33, i32 0, i32 1) })
  store i1 %t15, ptr %l27
  br label %bb8
bb8:
  %t16 = load i1, ptr %l27, !tbaa !21
  br i1 %t16, label %bb9, label %bb10
bb9:
  store ptr %l3, ptr %l28, !tbaa !29
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t19 = call { i32, i64 } @compiler_2fgeneric_2ecanonNumber(ptr %v1, ptr %t17)
  %t20 = extractvalue { i32, i64 } %t19, 1
  %t21 = extractvalue { i32, i64 } %t19, 0
  store i32 %t21, ptr %l32
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb12, label %ok.23, !prof !99
ok.23:
  store i64 %t20, ptr %l31
  br label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2eeat(ptr %v1, ptr %s4, ptr %t24, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d34, i32 0, i32 1) })
  store i1 %t26, ptr %l35
  br label %bb15
bb11:
  %t27 = load i64, ptr %l31, !tbaa !24
  store i64 %t27, ptr %l29, !tbaa !24
  br label %bb13
bb12:
  %t28 = load i32, ptr %l32, !tbaa !23
  %t29 = lshr i32 %t28, 16
  %t30 = and i32 %t28, 65535
  %t31 = icmp eq i32 %t29, 1
  %t32 = select i1 %t31, i32 1, i32 0
  %t33 = icmp eq i32 %t28, 0
  %t34 = shl i32 %t32, 16
  %t35 = or i32 %t34, %t30
  %t36 = select i1 %t33, i32 0, i32 %t35
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t38 = insertvalue { i32, i64 } zeroinitializer, i32 %t36, 0
  store { i32, i64 } %t38, ptr %rv
  br label %ret
bb13:
  %t39 = load ptr, ptr %l28, !tbaa !29
  %t40 = load i64, ptr %l29, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t39, i64 %t40)
  br label %bb14
bb14:
  br label %bb89
bb15:
  %t41 = load i1, ptr %l35, !tbaa !21
  br i1 %t41, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s5
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t44 = call { i32, i64 } @compiler_2fgeneric_2ecanonNumber(ptr %v1, ptr %t42)
  %t45 = extractvalue { i32, i64 } %t44, 1
  %t46 = extractvalue { i32, i64 } %t44, 0
  store i32 %t46, ptr %l39
  %t47 = icmp ne i32 %t46, 0
  br i1 %t47, label %bb19, label %ok.48, !prof !99
ok.48:
  store i64 %t45, ptr %l38
  br label %bb18
bb17:
  store i64 -1, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  %t49 = load [8 x { i64, ptr }], ptr @G_2ecompiler_2ftypes_2ePromiseNames
  store i64 8, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t52 = load i64, ptr %l15, !tbaa !24
  %t53 = load i64, ptr %l14, !tbaa !24
  %t56 = icmp sgt i64 %t52, %t53
  br i1 %t56, label %bb66, label %bb67
bb18:
  %t58 = load i64, ptr %l38, !tbaa !24
  store i64 %t58, ptr %l36, !tbaa !24
  br label %bb20
bb19:
  %t59 = load i32, ptr %l39, !tbaa !23
  %t60 = lshr i32 %t59, 16
  %t61 = and i32 %t59, 65535
  %t62 = icmp eq i32 %t60, 1
  %t63 = select i1 %t62, i32 1, i32 0
  %t64 = icmp eq i32 %t59, 0
  %t65 = shl i32 %t63, 16
  %t66 = or i32 %t65, %t61
  %t67 = select i1 %t64, i32 0, i32 %t66
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t69 = insertvalue { i32, i64 } zeroinitializer, i32 %t67, 0
  store { i32, i64 } %t69, ptr %rv
  br label %ret
bb20:
  %t70 = load i64, ptr %l36, !tbaa !24
  store i64 %t70, ptr %l5, !tbaa !24
  %t71 = load i64, ptr @G_2ecompiler_2ftypes_2eKeepsHome, !tbaa !24
  store i64 %t71, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2eeat(ptr %v1, ptr %s5, ptr %t73, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d35, i32 0, i32 1) })
  store i1 %t75, ptr %l43
  br label %bb21
bb21:
  %t76 = load i1, ptr %l43, !tbaa !21
  br i1 %t76, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s6
  %t77 = load ptr, ptr %l1, !tbaa !29
  %t79 = call { i32, i64 } @compiler_2fgeneric_2ecanonNumber(ptr %v1, ptr %t77)
  %t80 = extractvalue { i32, i64 } %t79, 1
  %t81 = extractvalue { i32, i64 } %t79, 0
  store i32 %t81, ptr %l47
  %t82 = icmp ne i32 %t81, 0
  br i1 %t82, label %bb25, label %ok.83, !prof !99
ok.83:
  store i64 %t80, ptr %l46
  br label %bb24
bb23:
  br label %bb58
bb24:
  %t84 = load i64, ptr %l46, !tbaa !24
  store i64 %t84, ptr %l44, !tbaa !24
  br label %bb26
bb25:
  %t85 = load i32, ptr %l47, !tbaa !23
  %t86 = lshr i32 %t85, 16
  %t87 = and i32 %t85, 65535
  %t88 = icmp eq i32 %t86, 1
  %t89 = select i1 %t88, i32 1, i32 0
  %t90 = icmp eq i32 %t85, 0
  %t91 = shl i32 %t89, 16
  %t92 = or i32 %t91, %t87
  %t93 = select i1 %t90, i32 0, i32 %t92
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t95 = insertvalue { i32, i64 } zeroinitializer, i32 %t93, 0
  store { i32, i64 } %t95, ptr %rv
  br label %ret
bb26:
  %t96 = load i64, ptr %l44, !tbaa !24
  store i64 %t96, ptr %l6, !tbaa !24
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2eeat(ptr %v1, ptr %s6, ptr %t97, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) })
  store i1 %t99, ptr %l50
  br label %bb27
bb27:
  %t100 = load i1, ptr %l50, !tbaa !21
  br i1 %t100, label %bb28, label %bb29
bb28:
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t103 = getelementptr %"compiler/generic:cursor", ptr %t101, i32 0, i32 1
  %t104 = load i64, ptr %t103, !tbaa !24
  store i64 %t104, ptr %l8, !tbaa !24
  br label %bb30
bb29:
  br label %bb57
bb30:
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr %"compiler/generic:cursor", ptr %t106, i32 0, i32 1
  %t109 = load i64, ptr %t108, !tbaa !24
  %t110 = load ptr, ptr %l1, !tbaa !29
  %t112 = getelementptr %"compiler/generic:cursor", ptr %t110, i32 0, i32 0
  %t113 = load { i64, ptr }, ptr %t112, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t113, 0
  %t118 = icmp slt i64 %t109, %t115
  br i1 %t118, label %bb31, label %bb32
bb31:
  %t120 = load ptr, ptr %l1, !tbaa !29
  %t122 = call i8 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2epeek(ptr %v1, ptr %t120)
  store i8 %t122, ptr %l61
  br label %bb33
bb32:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb44
bb33:
  %t123 = load i8, ptr %l61, !tbaa !22
  %t124 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t123)
  store i1 %t124, ptr %l62
  br label %bb34
bb34:
  %t125 = load i1, ptr %l62, !tbaa !21
  br i1 %t125, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l63, !tbaa !21
  br label %bb39
bb36:
  %t126 = load ptr, ptr %l1, !tbaa !29
  %t128 = call i8 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2epeek(ptr %v1, ptr %t126)
  store i8 %t128, ptr %l65
  br label %bb37
bb37:
  %t129 = load i8, ptr %l65, !tbaa !22
  %t130 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t129)
  store i1 %t130, ptr %l66
  br label %bb38
bb38:
  %t131 = load i1, ptr %l66, !tbaa !21
  store i1 %t131, ptr %l63, !tbaa !21
  br label %bb39
bb39:
  %t132 = load i1, ptr %l63, !tbaa !21
  br i1 %t132, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb43
bb41:
  %t133 = load ptr, ptr %l1, !tbaa !29
  %t135 = call i8 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2epeek(ptr %v1, ptr %t133)
  store i8 %t135, ptr %l69
  br label %bb42
bb42:
  %t136 = load i8, ptr %l69, !tbaa !22
  %t137 = icmp eq i8 %t136, 95
  store i1 %t137, ptr %l67, !tbaa !21
  br label %bb43
bb43:
  %t139 = load i1, ptr %l67, !tbaa !21
  store i1 %t139, ptr %l59, !tbaa !21
  br label %bb44
bb44:
  %t140 = load i1, ptr %l59, !tbaa !21
  %t141 = xor i1 %t140, true
  br i1 %t141, label %bb45, label %bb46
bb45:
  br label %bb49
bb46:
  br label %bb47
bb47:
  %t143 = load ptr, ptr %l1, !tbaa !29
  store ptr %t143, ptr %l72, !tbaa !29
  %t144 = load ptr, ptr %l72, !tbaa !29
  %t145 = getelementptr %"compiler/generic:cursor", ptr %t144, i32 0, i32 1
  %t146 = load i64, ptr %t145, !tbaa !24
  %t149 = add i64 %t146, 1
  %t151 = load ptr, ptr %l72, !tbaa !29
  %t152 = getelementptr %"compiler/generic:cursor", ptr %t151, i32 0, i32 1
  store i64 %t149, ptr %t152, !tbaa !24
  br label %bb48
bb48:
  br label %bb30
bb49:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t155 = getelementptr %"compiler/generic:Program", ptr %t153, i32 0, i32 0
  %t156 = load ptr, ptr %t155, !tbaa !29
  %t158 = getelementptr %"compiler/load:Loader", ptr %t156, i32 0, i32 3
  %t159 = load ptr, ptr %t158, !tbaa !29
  store ptr %t159, ptr %l78, !tbaa !29
  %t160 = load ptr, ptr %l1, !tbaa !29
  %t162 = getelementptr %"compiler/generic:cursor", ptr %t160, i32 0, i32 0
  %t163 = load { i64, ptr }, ptr %t162, !tbaa !27
  store { i64, ptr } %t163, ptr %l80, !tbaa !27
  %t164 = load i64, ptr %l8, !tbaa !24
  store i64 %t164, ptr %l81, !tbaa !24
  %t165 = load ptr, ptr %l1, !tbaa !29
  %t167 = getelementptr %"compiler/generic:cursor", ptr %t165, i32 0, i32 1
  %t168 = load i64, ptr %t167, !tbaa !24
  store i64 %t168, ptr %l83, !tbaa !24
  %t169 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t170 = extractvalue { i64, ptr } %t169, 0
  store i64 %t170, ptr %l84, !tbaa !24
  %t171 = load i64, ptr %l81, !tbaa !24
  %t172 = icmp sge i64 %t171, 0
  br i1 %t172, label %bb50, label %bb51
bb50:
  %t174 = load i64, ptr %l81, !tbaa !24
  %t175 = load i64, ptr %l83, !tbaa !24
  %t176 = icmp sle i64 %t174, %t175
  br i1 %t176, label %bb52, label %bb53
bb51:
  call void @__olang_check_failed(ptr @olang_loc_50b66d83acd8516e_d3bb6f86efb3445a)
  unreachable
bb52:
  %t178 = load i64, ptr %l83, !tbaa !24
  %t179 = load i64, ptr %l84, !tbaa !24
  %t180 = icmp sle i64 %t178, %t179
  br i1 %t180, label %bb54, label %bb55
bb53:
  call void @__olang_check_failed(ptr @olang_loc_50b66d83acd8516e_d3bb6f86efb3445a)
  unreachable
bb54:
  %t182 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !27
  %t184 = load i64, ptr %l81, !tbaa !24
  %t185 = load i64, ptr %l83, !tbaa !24
  %t186 = getelementptr i8, ptr %t183, i64 %t184
  %t187 = sub i64 %t185, %t184
  %t188 = insertvalue { i64, ptr } undef, i64 %t187, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t186, 1
  %t190 = load ptr, ptr %l78, !tbaa !29
  %t192 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %t190, { i64, ptr } %t189)
  store i32 %t192, ptr %l89
  br label %bb56
bb55:
  call void @__olang_check_failed(ptr @olang_loc_50b66d83acd8516e_d3bb6f86efb3445a)
  unreachable
bb56:
  %t193 = load i32, ptr %l89, !tbaa !23
  %t194 = sext i32 %t193 to i64
  store i64 %t194, ptr %l7, !tbaa !24
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s6)
  br label %bb58
bb58:
  store %olang.scope zeroinitializer, ptr %s9
  %t196 = load i64, ptr %l5, !tbaa !24
  %t197 = load i64, ptr %l6, !tbaa !24
  %t198 = load i64, ptr %l7, !tbaa !24
  %t200 = insertvalue [3 x i64] undef, i64 %t196, 0
  %t202 = insertvalue [3 x i64] %t200, i64 %t197, 1
  %t204 = insertvalue [3 x i64] %t202, i64 %t198, 2
  %t206 = call ptr @__olang_scope_alloc_a(ptr %s9, i64 24, i64 8)
  store [3 x i64] %t204, ptr %t206
  store ptr %t206, ptr %l9
  store i64 0, ptr %l10, !tbaa !24
  %t208 = load ptr, ptr %l9
  store i64 3, ptr %l11, !tbaa !24
  br label %bb59
bb59:
  %t211 = load i64, ptr %l10, !tbaa !24
  %t212 = load i64, ptr %l11, !tbaa !24
  %t215 = icmp slt i64 %t211, %t212
  %t217 = xor i1 %t215, true
  br i1 %t217, label %bb60, label %bb61
bb60:
  br label %bb65
bb61:
  br label %bb62
bb62:
  %t219 = load ptr, ptr %l9
  %t220 = load i64, ptr %l10, !tbaa !24
  %t223 = getelementptr [3 x i64], ptr %t219, i64 0, i64 %t220
  %t224 = load i64, ptr %t223, !tbaa !34
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l4, i64 %t224)
  br label %bb63
bb63:
  br label %bb64
bb64:
  %t229 = load i64, ptr %l10, !tbaa !24
  %t232 = add i64 %t229, 1
  store i64 %t232, ptr %l10, !tbaa !24
  br label %bb59
bb65:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s5)
  br label %bb88
bb66:
  %t234 = load i64, ptr %l16, !tbaa !24
  %t236 = icmp sgt i64 %t234, 0
  br i1 %t236, label %bb68, label %bb69
bb67:
  store i64 0, ptr %l115, !tbaa !24
  br label %bb71
bb68:
  %t238 = load i64, ptr %l15, !tbaa !24
  %t239 = load i64, ptr %l14, !tbaa !24
  %t242 = sub i64 %t238, %t239
  %t243 = load i64, ptr %l16, !tbaa !24
  %t246 = add i64 %t242, %t243
  %t248 = sub i64 %t246, 1
  %t249 = load i64, ptr %l16, !tbaa !24
  %t252 = sdiv i64 %t248, %t249
  store i64 %t252, ptr %l118, !tbaa !24
  br label %bb70
bb69:
  store i64 0, ptr %l118, !tbaa !24
  br label %bb70
bb70:
  %t254 = load i64, ptr %l118, !tbaa !24
  store i64 %t254, ptr %l115, !tbaa !24
  br label %bb71
bb71:
  %t255 = load i64, ptr %l115, !tbaa !24
  store i64 %t255, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb72
bb72:
  %t256 = load i64, ptr %l18, !tbaa !24
  %t257 = load i64, ptr %l17, !tbaa !24
  %t260 = icmp slt i64 %t256, %t257
  %t262 = xor i1 %t260, true
  br i1 %t262, label %bb73, label %bb74
bb73:
  br label %bb84
bb74:
  br label %bb75
bb75:
  %t264 = load i64, ptr %l14, !tbaa !24
  %t265 = load i64, ptr %l18, !tbaa !24
  %t266 = load i64, ptr %l16, !tbaa !24
  %t269 = mul i64 %t265, %t266
  %t272 = add i64 %t264, %t269
  store i64 %t272, ptr %l19, !tbaa !24
  %t274 = load i64, ptr %l13, !tbaa !24
  %t276 = icmp slt i64 %t274, 0
  br i1 %t276, label %bb76, label %bb77
bb76:
  %t278 = load ptr, ptr %l1, !tbaa !29
  %t279 = load i64, ptr %l19, !tbaa !24
  %t281 = getelementptr [8 x { i64, ptr }], ptr @G_2ecompiler_2ftypes_2ePromiseNames, i64 0, i64 %t279
  %t282 = load { i64, ptr }, ptr %t281, !tbaa !37
  %t283 = load ptr, ptr @__olang_prog_scope
  %t286 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2eeat(ptr %v1, ptr %t283, ptr %t278, { i64, ptr } %t282)
  store i1 %t286, ptr %l142
  br label %bb78
bb77:
  store i1 false, ptr %l138, !tbaa !21
  br label %bb79
bb78:
  %t287 = load i1, ptr %l142, !tbaa !21
  store i1 %t287, ptr %l138, !tbaa !21
  br label %bb79
bb79:
  %t288 = load i1, ptr %l138, !tbaa !21
  br i1 %t288, label %bb80, label %bb81
bb80:
  %t289 = load i64, ptr %l19, !tbaa !24
  store i64 %t289, ptr %l13, !tbaa !24
  br label %bb82
bb81:
  br label %bb82
bb82:
  br label %bb83
bb83:
  %t291 = load i64, ptr %l18, !tbaa !24
  %t294 = add i64 %t291, 1
  store i64 %t294, ptr %l18, !tbaa !24
  br label %bb72
bb84:
  %t296 = load i64, ptr %l13, !tbaa !24
  %t298 = icmp slt i64 %t296, 0
  br i1 %t298, label %bb85, label %bb86
bb85:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t301 = insertvalue { i32, i64 } zeroinitializer, i32 65536, 0
  store { i32, i64 } %t301, ptr %rv
  br label %ret
bb86:
  br label %bb87
bb87:
  %t302 = load i64, ptr %l2, !tbaa !24
  %t304 = load i64, ptr %l13, !tbaa !24
  store i64 %t304, ptr %l152, !tbaa !24
  %t305 = load i64, ptr %l152, !tbaa !24
  %t306 = load i64, ptr %l152, !tbaa !24
  %t307 = shl i64 1, %t306
  %t310 = or i64 %t302, %t307
  store i64 %t310, ptr %l2, !tbaa !24
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s4)
  br label %bb89
bb89:
  %t312 = load ptr, ptr %l1, !tbaa !29
  %t314 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2eeat(ptr %v1, ptr %s2, ptr %t312, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) })
  store i1 %t314, ptr %l156
  br label %bb90
bb90:
  %t315 = load i1, ptr %l156, !tbaa !21
  br i1 %t315, label %bb91, label %bb92
bb91:
  call void @__olang_scope_close(ptr %s2)
  br label %bb99
bb92:
  br label %bb93
bb93:
  %t316 = load ptr, ptr %l1, !tbaa !29
  %t318 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2eeat(ptr %v1, ptr %s2, ptr %t316, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d38, i32 0, i32 1) })
  store i1 %t318, ptr %l158
  br label %bb94
bb94:
  %t319 = load i1, ptr %l158, !tbaa !21
  %t320 = xor i1 %t319, true
  br i1 %t320, label %bb95, label %bb96
bb95:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t323 = insertvalue { i32, i64 } zeroinitializer, i32 65536, 0
  store { i32, i64 } %t323, ptr %rv
  br label %ret
bb96:
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s2)
  br label %bb98
bb98:
  br label %bb7
bb99:
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t326 = getelementptr %"compiler/generic:Program", ptr %t324, i32 0, i32 2
  store ptr %t326, ptr %l162, !tbaa !29
  %t327 = load i64, ptr %l2, !tbaa !24
  store i64 %t327, ptr %l163, !tbaa !24
  %t329 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %s0, ptr %l3)
  store { i64, ptr } %t329, ptr %l165
  br label %bb100
bb100:
  %t331 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %s0, ptr %l4)
  store { i64, ptr } %t331, ptr %l167
  br label %bb101
bb101:
  %t332 = load ptr, ptr %l162, !tbaa !29
  %t333 = load i64, ptr %l163, !tbaa !24
  %t334 = load { i64, ptr }, ptr %l165, !tbaa !27
  %t335 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t336 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePromises(ptr %v0, ptr %s0, ptr %s0, ptr %t332, i64 %t333, { i64, ptr } %t334, { i64, ptr } %t335)
  store i64 %t336, ptr %l168
  br label %bb102
bb102:
  call void @__olang_scope_close(ptr %s0)
  %t337 = load i64, ptr %l168, !tbaa !24
  %t338 = insertvalue { i32, i64 } zeroinitializer, i64 %t337, 1
  store { i32, i64 } %t338, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2econstraintKey(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/names:Ref"
  %l5 = alloca ptr
  %l6 = alloca i1
  %l12 = alloca ptr
  %l15 = alloca i64
  %l17 = alloca %"compiler/names:Ref"
  %l20 = alloca i1
  %l26 = alloca i32
  %l27 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l3
  br label %bb5
bb4:
  br label %bb16
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  store ptr %t19, ptr %l12, !tbaa !29
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t24 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2efile(ptr %v0, ptr %t20, i64 %a1)
  store i64 %t24, ptr %l15
  br label %bb6
bb6:
  %t25 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t26 = load i32, ptr %t25, !tbaa !23
  %t27 = load ptr, ptr %l12, !tbaa !29
  %t28 = load i64, ptr %l15, !tbaa !24
  %t30 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t27, i64 %t28, i32 %t26)
  store %"compiler/names:Ref" %t30, ptr %l17
  br label %bb7
bb7:
  %t31 = load %"compiler/names:Ref", ptr %l17
  store %"compiler/names:Ref" %t31, ptr %l4
  %t32 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 0
  %t33 = load i32, ptr %t32, !range !{i32 0, i32 9}
  %t35 = trunc i64 4 to i32
  %t36 = icmp eq i32 %t33, %t35
  br i1 %t36, label %bb8, label %bb9
bb8:
  %t38 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 2
  %t39 = load i64, ptr %t38, !tbaa !24
  %t41 = icmp sge i64 %t39, 0
  store i1 %t41, ptr %l20, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb10
bb10:
  %t43 = load i1, ptr %l20, !tbaa !21
  br i1 %t43, label %bb11, label %bb12
bb11:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 1
  %t46 = load i64, ptr %t45, !tbaa !24
  %t47 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 2
  %t48 = load i64, ptr %t47, !tbaa !24
  %t52 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t44, i64 %t46, i64 %t48)
  store i32 %t52, ptr %l26
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t53 = load i32, ptr %l26, !tbaa !23
  %t54 = call i64 @compiler_2fgeneric_2ekeyTrait(i32 %t53)
  store i64 %t54, ptr %l27
  br label %bb14
bb14:
  %t55 = load i64, ptr %l27, !tbaa !24
  store i64 %t55, ptr %rv
  br label %ret
bb15:
  store i64 -1, ptr %rv
  br label %ret
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i64 -1, ptr %rv
  br label %ret
bb20:
  call void @__olang_check_failed(ptr @olang_loc_6254d719be644cb8_ecba73ecf161ba54)
  unreachable
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eentriesOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca i64
  %l13 = alloca %"compiler/generic:Context"
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l21 = alloca i32
  %l25 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l48 = alloca i1
  %l52 = alloca i32
  %l61 = alloca i32
  %l64 = alloca { i64, ptr }
  %l71 = alloca i64
  %l73 = alloca i64
  %l78 = alloca i32
  %l90 = alloca i64
  %l91 = alloca %"compiler/generic:Context"
  %l99 = alloca { i64, ptr }
  %l102 = alloca ptr
  %l103 = alloca ptr
  %l104 = alloca i64
  %l109 = alloca i32
  %l115 = alloca i32
  %l117 = alloca i32
  %l118 = alloca i32
  %l124 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %t145 = alloca %"compiler/generic:Context", align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l1, !tbaa !23
  %t7 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t7, ptr %l21
  br label %bb1
bb1:
  %t8 = load i32, ptr %l21, !range !{i32 0, i32 33}
  %t10 = trunc i64 30 to i32
  %t11 = icmp eq i32 %t8, %t10
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  store ptr %t15, ptr %l25, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %l1, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l29
  br label %bb4
bb3:
  br label %bb13
bb4:
  %t23 = load ptr, ptr %l25, !tbaa !29
  %t24 = load i32, ptr %l29, !tbaa !23
  %t25 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t23, i32 %t24)
  store { i64, ptr } %t25, ptr %l30
  br label %bb5
bb5:
  %t26 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t26, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t27 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  store i64 %t29, ptr %l6, !tbaa !24
  br label %bb6
bb6:
  %t31 = load i64, ptr %l5, !tbaa !24
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb7, label %bb8
bb7:
  br label %bb12
bb8:
  br label %bb9
bb9:
  %t39 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t39, ptr %l37, !tbaa !27
  %t40 = load i64, ptr %l5, !tbaa !24
  %t42 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr i32, ptr %t43, i64 %t40
  %t45 = load i32, ptr %t44, !tbaa !33
  %t47 = load ptr, ptr %l2, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t47, i32 %t45)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = add i64 %t51, 1
  store i64 %t54, ptr %l5, !tbaa !24
  br label %bb6
bb12:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb13:
  %t56 = load i32, ptr %l1, !tbaa !23
  %t57 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t60 = icmp eq i32 %t56, %t57
  br i1 %t60, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb17
bb15:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 2
  %t65 = load i32, ptr %l1, !tbaa !23
  %t68 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t64, i32 %t65)
  store i32 %t68, ptr %l52
  br label %bb16
bb16:
  %t69 = load i32, ptr %l52, !range !{i32 0, i32 33}
  %t71 = trunc i64 18 to i32
  %t72 = icmp eq i32 %t69, %t71
  %t74 = xor i1 %t72, true
  store i1 %t74, ptr %l48, !tbaa !21
  br label %bb17
bb17:
  %t76 = load i1, ptr %l48, !tbaa !21
  br i1 %t76, label %bb18, label %bb19
bb18:
  %t77 = load ptr, ptr %l2, !tbaa !29
  %t78 = load i32, ptr %l1, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t77, i32 %t78)
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb21:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/generic:Program", ptr %t81, i32 0, i32 2
  %t84 = load i32, ptr %l1, !tbaa !23
  %t87 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t83, i32 %t84)
  store i32 %t87, ptr %l61
  br label %bb22
bb22:
  %t88 = load i32, ptr %l61, !tbaa !23
  store i32 %t88, ptr %l8, !tbaa !23
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load i32, ptr %l8, !tbaa !23
  %t93 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorMembers(ptr %v0, ptr %v0, ptr %t89, i32 %t90)
  store { i64, ptr } %t93, ptr %l64
  br label %bb23
bb23:
  %t94 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t94, ptr %l9, !tbaa !27
  %t95 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t95, 0
  %t99 = icmp eq i64 %t97, 0
  br i1 %t99, label %bb24, label %bb25
bb24:
  %t101 = load ptr, ptr %l2, !tbaa !29
  %t102 = load i32, ptr %l1, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t101, i32 %t102)
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb27:
  %t105 = load ptr, ptr %l3, !tbaa !29
  store ptr %t105, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb28
bb28:
  %t107 = load i64, ptr %l11, !tbaa !24
  store i64 %t107, ptr %l71, !tbaa !24
  %t108 = load ptr, ptr %l10, !tbaa !29
  %t110 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aDeclId_3e_2eLen_3ccompiler_2ftypes_3aDeclId_3e(ptr %v2, ptr %t108)
  store i64 %t110, ptr %l73
  br label %bb29
bb29:
  %t111 = load i64, ptr %l71, !tbaa !24
  %t112 = load i64, ptr %l73, !tbaa !24
  %t113 = icmp slt i64 %t111, %t112
  %t115 = xor i1 %t113, true
  br i1 %t115, label %bb30, label %bb31
bb30:
  br label %bb38
bb31:
  br label %bb32
bb32:
  %t117 = load ptr, ptr %l10, !tbaa !29
  %t118 = load i64, ptr %l11, !tbaa !24
  %t121 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aDeclId_3e_2eAt_3ccompiler_2ftypes_3aDeclId_3e(ptr %v2, ptr %t117, i64 %t118)
  store i32 %t121, ptr %l78
  br label %bb33
bb33:
  %t122 = load i32, ptr %l78, !tbaa !23
  %t124 = load i32, ptr %l8, !tbaa !23
  %t127 = icmp eq i32 %t122, %t124
  br i1 %t127, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb35:
  br label %bb36
bb36:
  br label %bb37
bb37:
  %t129 = load i64, ptr %l11, !tbaa !24
  %t132 = add i64 %t129, 1
  store i64 %t132, ptr %l11, !tbaa !24
  br label %bb28
bb38:
  %t134 = load ptr, ptr %l3, !tbaa !29
  %t135 = load i32, ptr %l8, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aDeclId_3e_2ePush_3ccompiler_2ftypes_3aDeclId_3e(ptr %v2, ptr %t134, i32 %t135)
  br label %bb39
bb39:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/generic:Program", ptr %t138, i32 0, i32 2
  %t141 = load i32, ptr %l8, !tbaa !23
  %t144 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t140, i32 %t141)
  store i64 %t144, ptr %l90
  br label %bb40
bb40:
  %t146 = load i64, ptr %l90, !tbaa !24
  call void @compiler_2fgeneric_3aContext_2ector(ptr %t145, ptr %s0, i64 %t146, i64 -1)
  call void @llvm.memmove.p0.p0.i64(ptr %l91, ptr %t145, i64 160, i1 false)
  br label %bb41
bb41:
  call void @llvm.memmove.p0.p0.i64(ptr %l13, ptr %l91, i64 160, i1 false)
  %t147 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t147, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t149 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t151 = extractvalue { i64, ptr } %t149, 0
  store i64 %t151, ptr %l16, !tbaa !24
  br label %bb42
bb42:
  %t153 = load i64, ptr %l15, !tbaa !24
  %t154 = load i64, ptr %l16, !tbaa !24
  %t157 = icmp slt i64 %t153, %t154
  %t159 = xor i1 %t157, true
  br i1 %t159, label %bb43, label %bb44
bb43:
  br label %bb51
bb44:
  br label %bb45
bb45:
  %t161 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t161, ptr %l99, !tbaa !27
  %t162 = load i64, ptr %l15, !tbaa !24
  %t164 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !27
  %t166 = getelementptr ptr, ptr %t165, i64 %t162
  %t167 = load ptr, ptr %t166, !tbaa !39
  store ptr %t167, ptr %l17, !tbaa !29
  %t169 = load ptr, ptr %l0, !tbaa !29
  store ptr %t169, ptr %l102, !tbaa !29
  %t170 = load ptr, ptr %l17, !tbaa !29
  store ptr %t170, ptr %l103, !tbaa !29
  %t171 = call ptr @__olang_scope_hold(ptr %v0)
  %t172 = ptrtoint ptr %t171 to i64
  store i64 %t172, ptr %l104, !tbaa !24
  %t173 = load i1, ptr @olang_2esole_2eArray_3ccompiler_2fast_3aPath_26_3e_2e_2d1
  br i1 %t173, label %bb46, label %bb47
bb46:
  %t175 = load ptr, ptr %l103, !tbaa !29
  %t176 = call ptr @__olang_region_or(ptr %t175, ptr %v0)
  %t177 = call ptr @__olang_scope_hold(ptr %t176)
  %t178 = ptrtoint ptr %t177 to i64
  store i64 %t178, ptr %l104, !tbaa !24
  br label %bb47
bb47:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load ptr, ptr %l17, !tbaa !29
  %t181 = load i64, ptr %l104
  %t182 = inttoptr i64 %t181 to ptr
  %t186 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eerrorSetItem(ptr %v0, ptr %s0, ptr %t182, ptr %t179, ptr %l13, ptr %t180)
  store i32 %t186, ptr %l109
  br label %bb48
bb48:
  %t187 = load ptr, ptr %l2, !tbaa !29
  %t188 = load ptr, ptr %l3, !tbaa !29
  %t189 = load ptr, ptr %l102, !tbaa !29
  %t190 = load i32, ptr %l109, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eentriesOf(ptr %v0, ptr %v1, ptr %v2, ptr %t189, i32 %t190, ptr %t187, ptr %t188)
  br label %bb49
bb49:
  br label %bb50
bb50:
  %t193 = load i64, ptr %l15, !tbaa !24
  %t196 = add i64 %t193, 1
  store i64 %t196, ptr %l15, !tbaa !24
  br label %bb42
bb51:
  %t198 = load ptr, ptr %l3, !tbaa !29
  %t200 = call { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aDeclId_3e_2ePop_3ccompiler_2ftypes_3aDeclId_3e(ptr %v2, ptr %t198)
  %t201 = extractvalue { i32, i32 } %t200, 1
  %t202 = extractvalue { i32, i32 } %t200, 0
  store i32 %t202, ptr %l118
  %t203 = icmp ne i32 %t202, 0
  br i1 %t203, label %bb53, label %ok.204, !prof !99
ok.204:
  store i32 %t201, ptr %l117
  br label %bb52
bb52:
  %t205 = load i32, ptr %l117, !tbaa !23
  store i32 %t205, ptr %l115, !tbaa !23
  br label %bb60
bb53:
  %t206 = load i32, ptr %l118, !tbaa !23
  %t207 = icmp eq i32 %t206, 65536
  br i1 %t207, label %bb54, label %bb55
bb54:
  call void @__olang_bang_failed_plain(ptr @olang_loc_720125e199c24f22_e8379e985b9f3c66)
  unreachable
bb55:
  %t209 = load i32, ptr %l118, !tbaa !23
  %t210 = icmp eq i32 %t209, 65537
  br i1 %t210, label %bb56, label %bb57
bb56:
  call void @__olang_bang_failed_plain(ptr @olang_loc_227a3f0eae681c4f_61bdff3e0ec7ebb3)
  unreachable
bb57:
  %t212 = load i32, ptr %l118, !tbaa !23
  %t213 = icmp eq i32 %t212, 65538
  br i1 %t213, label %bb58, label %bb59
bb58:
  call void @__olang_bang_failed_plain(ptr @olang_loc_f703e5bec6c76f87_ea1686e8125b66ab)
  unreachable
bb59:
  call void @__olang_bang_failed_plain(ptr @olang_loc_bbb5b8b709f50d79_9796b462e6590e5d)
  unreachable
bb60:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = load i32, ptr %l8, !tbaa !23
  %t219 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %s0, ptr %t215, i32 %t216)
  store { i64, ptr } %t219, ptr %l124
  br label %bb61
bb61:
  %t220 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t221 = extractvalue { i64, ptr } %t220, 0
  %t223 = icmp sgt i64 %t221, 0
  br i1 %t223, label %bb62, label %bb63
bb62:
  %t225 = load ptr, ptr %l2, !tbaa !29
  %t226 = load i32, ptr %l1, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t225, i32 %t226)
  br label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eflagBans(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l34 = alloca i64
  %l37 = alloca i64
  %l59 = alloca i1
  %l67 = alloca ptr
  %l68 = alloca ptr
  %l70 = alloca i64
  %l72 = alloca { i64, ptr }
  %l75 = alloca %"compiler/source:Span"
  %l76 = alloca { i64, [3 x i64] }
  %l77 = alloca %"compiler/diagmsg:Msg"
  %l78 = alloca i64
  %l85 = alloca i1
  %l90 = alloca ptr
  %l94 = alloca i32
  %l95 = alloca { i64, ptr }
  %l97 = alloca i64
  %l104 = alloca i64
  %l107 = alloca i64
  %l133 = alloca i1
  %l136 = alloca { i64, ptr }
  %l139 = alloca i1
  %l141 = alloca i1
  %l144 = alloca { i64, ptr }
  %l147 = alloca i64
  %l152 = alloca { i64, ptr }
  %l157 = alloca ptr
  %l163 = alloca { i64, [3 x i64] }
  %l167 = alloca { i64, ptr }
  %l168 = alloca { i64, ptr }
  %l170 = alloca %"compiler/diagmsg:Msg"
  %l171 = alloca i64
  %s0 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l3, !tbaa !23
  %t7 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s0, ptr %t3, i32 %t4)
  store { i64, ptr } %t7, ptr %l25
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t8, ptr %l5, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  %t13 = icmp sgt i64 %t11, 1
  br i1 %t13, label %bb2, label %bb3
bb2:
  store i64 0, ptr %l6, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  store i64 %t17, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t19 = load i64, ptr %l7, !tbaa !24
  %t20 = load i64, ptr %l6, !tbaa !24
  %t23 = icmp sgt i64 %t19, %t20
  br i1 %t23, label %bb4, label %bb5
bb3:
  br label %bb26
bb4:
  %t25 = load i64, ptr %l8, !tbaa !24
  %t27 = icmp sgt i64 %t25, 0
  br i1 %t27, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb9
bb6:
  %t29 = load i64, ptr %l7, !tbaa !24
  %t30 = load i64, ptr %l6, !tbaa !24
  %t33 = sub i64 %t29, %t30
  %t34 = load i64, ptr %l8, !tbaa !24
  %t37 = add i64 %t33, %t34
  %t39 = sub i64 %t37, 1
  %t40 = load i64, ptr %l8, !tbaa !24
  %t43 = sdiv i64 %t39, %t40
  store i64 %t43, ptr %l37, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb8
bb8:
  %t45 = load i64, ptr %l37, !tbaa !24
  store i64 %t45, ptr %l34, !tbaa !24
  br label %bb9
bb9:
  %t46 = load i64, ptr %l34, !tbaa !24
  store i64 %t46, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb10
bb10:
  %t47 = load i64, ptr %l10, !tbaa !24
  %t48 = load i64, ptr %l9, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb11, label %bb12
bb11:
  br label %bb25
bb12:
  br label %bb13
bb13:
  %t55 = load i64, ptr %l6, !tbaa !24
  %t56 = load i64, ptr %l10, !tbaa !24
  %t57 = load i64, ptr %l8, !tbaa !24
  %t60 = mul i64 %t56, %t57
  %t63 = add i64 %t55, %t60
  store i64 %t63, ptr %l11, !tbaa !24
  %t65 = load i64, ptr %l11, !tbaa !24
  %t67 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = getelementptr i32, ptr %t68, i64 %t65
  %t70 = load i32, ptr %t69, !tbaa !33
  %t71 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t74 = icmp eq i32 %t70, %t71
  br i1 %t74, label %bb14, label %bb15
bb14:
  %t76 = load i64, ptr %l11, !tbaa !24
  %t77 = load ptr, ptr %l2, !tbaa !29
  %t79 = getelementptr %"compiler/ast:Sig", ptr %t77, i32 0, i32 1
  %t80 = load { i64, ptr }, ptr %t79, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t85 = icmp slt i64 %t76, %t82
  store i1 %t85, ptr %l59, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb16
bb16:
  %t87 = load i1, ptr %l59, !tbaa !21
  br i1 %t87, label %bb17, label %bb18
bb17:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/generic:Program", ptr %t88, i32 0, i32 0
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t93 = getelementptr %"compiler/load:Loader", ptr %t91, i32 0, i32 4
  %t94 = load ptr, ptr %t93, !tbaa !29
  store ptr %t94, ptr %l67, !tbaa !29
  %t95 = load ptr, ptr %l0, !tbaa !29
  store ptr %t95, ptr %l68, !tbaa !29
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t98 = getelementptr %"compiler/generic:Context", ptr %t96, i32 0, i32 0
  %t99 = load i64, ptr %t98, !tbaa !24
  store i64 %t99, ptr %l70, !tbaa !24
  %t100 = load ptr, ptr %l2, !tbaa !29
  %t102 = getelementptr %"compiler/ast:Sig", ptr %t100, i32 0, i32 1
  %t103 = load { i64, ptr }, ptr %t102, !tbaa !27
  store { i64, ptr } %t103, ptr %l72, !tbaa !27
  %t104 = load i64, ptr %l11, !tbaa !24
  %t106 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = getelementptr ptr, ptr %t107, i64 %t104
  %t109 = load ptr, ptr %t108, !tbaa !39
  %t111 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v2, ptr %t109)
  store %"compiler/source:Span" %t111, ptr %l75
  br label %bb19
bb18:
  br label %bb23
bb19:
  %t112 = load ptr, ptr %l68, !tbaa !29
  %t113 = load i64, ptr %l70, !tbaa !24
  %t114 = load %"compiler/source:Span", ptr %l75
  %t115 = call { i64, [3 x i64] } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eat(ptr %v0, ptr %t112, i64 %t113, %"compiler/source:Span" %t114)
  store { i64, [3 x i64] } %t115, ptr %l76
  br label %bb20
bb20:
  %t116 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eFlagAmongResults(ptr %v0)
  store %"compiler/diagmsg:Msg" %t116, ptr %l77
  br label %bb21
bb21:
  %t117 = load ptr, ptr %l67, !tbaa !29
  %t118 = load { i64, [3 x i64] }, ptr %l76
  %t119 = load %"compiler/diagmsg:Msg", ptr %l77
  %t120 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorOncePerLine(ptr %v0, ptr %v0, ptr %t117, { i64, [3 x i64] } %t118, %"compiler/diagmsg:Msg" %t119)
  store i64 %t120, ptr %l78
  br label %bb22
bb22:
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t121 = load i64, ptr %l10, !tbaa !24
  %t124 = add i64 %t121, 1
  store i64 %t124, ptr %l10, !tbaa !24
  br label %bb10
bb25:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb26:
  %t126 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t126, 0
  %t130 = icmp ne i64 %t128, 1
  br i1 %t130, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l85, !tbaa !21
  br label %bb29
bb28:
  %t132 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr i32, ptr %t133, i64 0
  %t135 = load i32, ptr %t134, !tbaa !33
  %t136 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t139 = icmp ne i32 %t135, %t136
  store i1 %t139, ptr %l85, !tbaa !21
  br label %bb29
bb29:
  %t141 = load i1, ptr %l85, !tbaa !21
  br i1 %t141, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb31:
  br label %bb32
bb32:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/generic:Program", ptr %t142, i32 0, i32 2
  store ptr %t144, ptr %l90, !tbaa !29
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/generic:Program", ptr %t145, i32 0, i32 2
  %t148 = load i32, ptr %l3, !tbaa !23
  %t151 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t147, i32 %t148)
  store i32 %t151, ptr %l94
  br label %bb33
bb33:
  %t152 = load ptr, ptr %l90, !tbaa !29
  %t153 = load i32, ptr %l94, !tbaa !23
  %t154 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t152, i32 %t153)
  store { i64, ptr } %t154, ptr %l95
  br label %bb34
bb34:
  %t155 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t155, ptr %l12, !tbaa !27
  br i1 %a4, label %bb35, label %bb36
bb35:
  store i64 1, ptr %l97, !tbaa !24
  br label %bb37
bb36:
  store i64 0, ptr %l97, !tbaa !24
  br label %bb37
bb37:
  %t158 = load i64, ptr %l97, !tbaa !24
  store i64 %t158, ptr %l13, !tbaa !24
  %t159 = load i64, ptr %l13, !tbaa !24
  store i64 %t159, ptr %l14, !tbaa !24
  %t161 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t163 = extractvalue { i64, ptr } %t161, 0
  store i64 %t163, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t165 = load i64, ptr %l15, !tbaa !24
  %t166 = load i64, ptr %l14, !tbaa !24
  %t169 = icmp sgt i64 %t165, %t166
  br i1 %t169, label %bb38, label %bb39
bb38:
  %t171 = load i64, ptr %l16, !tbaa !24
  %t173 = icmp sgt i64 %t171, 0
  br i1 %t173, label %bb40, label %bb41
bb39:
  store i64 0, ptr %l104, !tbaa !24
  br label %bb43
bb40:
  %t175 = load i64, ptr %l15, !tbaa !24
  %t176 = load i64, ptr %l14, !tbaa !24
  %t179 = sub i64 %t175, %t176
  %t180 = load i64, ptr %l16, !tbaa !24
  %t183 = add i64 %t179, %t180
  %t185 = sub i64 %t183, 1
  %t186 = load i64, ptr %l16, !tbaa !24
  %t189 = sdiv i64 %t185, %t186
  store i64 %t189, ptr %l107, !tbaa !24
  br label %bb42
bb41:
  store i64 0, ptr %l107, !tbaa !24
  br label %bb42
bb42:
  %t191 = load i64, ptr %l107, !tbaa !24
  store i64 %t191, ptr %l104, !tbaa !24
  br label %bb43
bb43:
  %t192 = load i64, ptr %l104, !tbaa !24
  store i64 %t192, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb44
bb44:
  store %olang.scope zeroinitializer, ptr %s8
  %t193 = load i64, ptr %l18, !tbaa !24
  %t194 = load i64, ptr %l17, !tbaa !24
  %t197 = icmp slt i64 %t193, %t194
  %t199 = xor i1 %t197, true
  br i1 %t199, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s8)
  br label %bb65
bb46:
  br label %bb47
bb47:
  %t201 = load i64, ptr %l14, !tbaa !24
  %t202 = load i64, ptr %l18, !tbaa !24
  %t203 = load i64, ptr %l16, !tbaa !24
  %t206 = mul i64 %t202, %t203
  %t209 = add i64 %t201, %t206
  store i64 %t209, ptr %l19, !tbaa !24
  %t211 = load i64, ptr %l19, !tbaa !24
  %t212 = load i64, ptr %l13, !tbaa !24
  %t215 = sub i64 %t211, %t212
  store i64 %t215, ptr %l20, !tbaa !24
  %t217 = load i64, ptr %l20, !tbaa !24
  %t218 = load ptr, ptr %l2, !tbaa !29
  %t220 = getelementptr %"compiler/ast:Sig", ptr %t218, i32 0, i32 0
  %t221 = load { i64, ptr }, ptr %t220, !tbaa !27
  %t223 = extractvalue { i64, ptr } %t221, 0
  %t226 = icmp sge i64 %t217, %t223
  br i1 %t226, label %bb48, label %bb49
bb48:
  store i1 true, ptr %l133, !tbaa !21
  br label %bb51
bb49:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = getelementptr %"compiler/generic:Program", ptr %t228, i32 0, i32 2
  %t231 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t231, ptr %l136, !tbaa !27
  %t232 = load i64, ptr %l19, !tbaa !24
  %t234 = getelementptr { i64, ptr }, ptr %l136, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !27
  %t236 = getelementptr i32, ptr %t235, i64 %t232
  %t237 = load i32, ptr %t236, !tbaa !33
  %t240 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t230, i32 %t237)
  store i1 %t240, ptr %l139
  br label %bb50
bb50:
  %t241 = load i1, ptr %l139, !tbaa !21
  %t242 = xor i1 %t241, true
  store i1 %t242, ptr %l133, !tbaa !21
  br label %bb51
bb51:
  %t244 = load i1, ptr %l133, !tbaa !21
  br i1 %t244, label %bb52, label %bb53
bb52:
  store i1 true, ptr %l141, !tbaa !21
  br label %bb55
bb53:
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t247 = getelementptr %"compiler/generic:Program", ptr %t245, i32 0, i32 2
  %t248 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t248, ptr %l144, !tbaa !27
  %t249 = load i64, ptr %l19, !tbaa !24
  %t251 = getelementptr { i64, ptr }, ptr %l144, i32 0, i32 1
  %t252 = load ptr, ptr %t251, !tbaa !27
  %t253 = getelementptr i32, ptr %t252, i64 %t249
  %t254 = load i32, ptr %t253, !tbaa !33
  %t257 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t247, i32 %t254)
  store i64 %t257, ptr %l147
  br label %bb54
bb54:
  %t258 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t259 = load i64, ptr %l147, !tbaa !24
  %t261 = and i64 %t259, %t258
  %t263 = icmp eq i64 %t261, 0
  store i1 %t263, ptr %l141, !tbaa !21
  br label %bb55
bb55:
  %t265 = load i1, ptr %l141, !tbaa !21
  br i1 %t265, label %bb56, label %bb57
bb56:
  call void @__olang_scope_close(ptr %s8)
  br label %bb64
bb57:
  br label %bb58
bb58:
  %t266 = load ptr, ptr %l2, !tbaa !29
  %t268 = getelementptr %"compiler/ast:Sig", ptr %t266, i32 0, i32 0
  %t269 = load { i64, ptr }, ptr %t268, !tbaa !27
  store { i64, ptr } %t269, ptr %l152, !tbaa !27
  %t270 = load i64, ptr %l20, !tbaa !24
  %t272 = getelementptr { i64, ptr }, ptr %l152, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !27
  %t274 = getelementptr ptr, ptr %t273, i64 %t270
  %t275 = load ptr, ptr %t274, !tbaa !39
  store ptr %t275, ptr %l21, !tbaa !29
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t279 = getelementptr %"compiler/generic:Program", ptr %t277, i32 0, i32 0
  %t280 = load ptr, ptr %t279, !tbaa !29
  %t282 = getelementptr %"compiler/load:Loader", ptr %t280, i32 0, i32 4
  %t283 = load ptr, ptr %t282, !tbaa !29
  store ptr %t283, ptr %l157, !tbaa !29
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t285 = load ptr, ptr %l1, !tbaa !29
  %t287 = getelementptr %"compiler/generic:Context", ptr %t285, i32 0, i32 0
  %t288 = load i64, ptr %t287, !tbaa !24
  %t289 = load ptr, ptr %l21, !tbaa !29
  %t291 = getelementptr %"compiler/ast:Param", ptr %t289, i32 0, i32 0
  %t292 = load %"compiler/source:Span", ptr %t291
  %t296 = call { i64, [3 x i64] } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eat(ptr %v0, ptr %t284, i64 %t288, %"compiler/source:Span" %t292)
  store { i64, [3 x i64] } %t296, ptr %l163
  br label %bb59
bb59:
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t298 = load ptr, ptr %l21, !tbaa !29
  %t300 = getelementptr %"compiler/ast:Param", ptr %t298, i32 0, i32 1
  %t301 = load i32, ptr %t300, !tbaa !23
  %t304 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t297, i32 %t301)
  store { i64, ptr } %t304, ptr %l167
  br label %bb60
bb60:
  %t305 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t306 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %s8, { i64, ptr } %t305)
  store { i64, ptr } %t306, ptr %l168
  br label %bb61
bb61:
  %t307 = load { i64, ptr }, ptr %l168, !tbaa !27
  %t309 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eFlagWithOutParam(ptr %s8, ptr %v0, { i64, ptr } %t307)
  store %"compiler/diagmsg:Msg" %t309, ptr %l170
  br label %bb62
bb62:
  %t310 = load ptr, ptr %l157, !tbaa !29
  %t311 = load { i64, [3 x i64] }, ptr %l163
  %t312 = load %"compiler/diagmsg:Msg", ptr %l170
  %t313 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorOncePerLine(ptr %v0, ptr %v0, ptr %t310, { i64, [3 x i64] } %t311, %"compiler/diagmsg:Msg" %t312)
  store i64 %t313, ptr %l171
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s8)
  br label %bb64
bb64:
  %t314 = load i64, ptr %l18, !tbaa !24
  %t317 = add i64 %t314, 1
  store i64 %t317, ptr %l18, !tbaa !24
  br label %bb44
bb65:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ehasHash(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i32
  %l14 = alloca i32
  %l17 = alloca i1
  %l20 = alloca i1
  %l30 = alloca i32
  %l36 = alloca i32
  %l40 = alloca i32
  %l43 = alloca ptr
  %l47 = alloca i32
  %l50 = alloca i1
  %l54 = alloca i32
  %l57 = alloca i1
  %l60 = alloca i1
  %l61 = alloca i1
  %l63 = alloca ptr
  %l67 = alloca i32
  %l68 = alloca i32
  %l71 = alloca i1
  %l73 = alloca ptr
  %l77 = alloca i32
  %l78 = alloca i32
  %l81 = alloca i1
  %l84 = alloca i1
  %l86 = alloca i1
  %l90 = alloca i64
  %l92 = alloca ptr
  %l94 = alloca ptr
  %l98 = alloca i32
  %l99 = alloca i32
  %l102 = alloca i1
  %l105 = alloca i1
  %l106 = alloca i1
  %l110 = alloca i64
  %l112 = alloca i1
  %l113 = alloca ptr
  %l114 = alloca i32
  %l118 = alloca i64
  %l119 = alloca i1
  %l123 = alloca i64
  %l129 = alloca i1
  %l135 = alloca i1
  %l136 = alloca i1
  %l139 = alloca i1
  %l143 = alloca i1
  %l144 = alloca i1
  %l145 = alloca ptr
  %l146 = alloca i32
  %l150 = alloca i32
  %l151 = alloca i1
  %l158 = alloca ptr
  %l162 = alloca i32
  %l165 = alloca i1
  %l170 = alloca ptr
  %l174 = alloca i32
  %l176 = alloca i1
  %l179 = alloca ptr
  %l183 = alloca i32
  %l185 = alloca i1
  %l190 = alloca i1
  %l194 = alloca ptr
  %l198 = alloca i32
  %l199 = alloca i32
  %l202 = alloca ptr
  %l206 = alloca i32
  %l208 = alloca i1
  %l211 = alloca ptr
  %l215 = alloca i32
  %l217 = alloca i1
  %l220 = alloca i1
  %l222 = alloca ptr
  %l226 = alloca i32
  %l227 = alloca i32
  %l230 = alloca ptr
  %l234 = alloca i32
  %l237 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sgt i64 %t1, 16
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/generic:Program", ptr %t6, i32 0, i32 2
  %t9 = load i32, ptr %l1, !tbaa !23
  %t12 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t8, i32 %t9)
  store i32 %t12, ptr %l14
  br label %bb4
bb4:
  %t13 = load i32, ptr %l14, !range !{i32 0, i32 33}
  store i32 %t13, ptr %l3
  %t14 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t16 = trunc i64 0 to i32
  %t17 = icmp eq i32 %t14, %t16
  br i1 %t17, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb7
bb6:
  %t19 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t21 = trunc i64 25 to i32
  %t22 = icmp eq i32 %t19, %t21
  store i1 %t22, ptr %l17, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l17, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb10
bb9:
  %t25 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t27 = trunc i64 27 to i32
  %t28 = icmp eq i32 %t25, %t27
  store i1 %t28, ptr %l20, !tbaa !21
  br label %bb10
bb10:
  %t30 = load i1, ptr %l20, !tbaa !21
  br i1 %t30, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t32 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t34 = trunc i64 32 to i32
  %t35 = icmp eq i32 %t32, %t34
  br i1 %t35, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/generic:Program", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/load:Loader", ptr %t41, i32 0, i32 3
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t44, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d39, i32 0, i32 1) })
  store i32 %t46, ptr %l30
  br label %bb17
bb17:
  %t47 = load i32, ptr %l30, !tbaa !23
  store i32 %t47, ptr %l4, !tbaa !23
  %t48 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t50 = trunc i64 20 to i32
  %t51 = icmp eq i32 %t48, %t50
  br i1 %t51, label %bb18, label %bb19
bb18:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 2
  %t56 = load i32, ptr %l1, !tbaa !23
  %t59 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t55, i32 %t56)
  store i32 %t59, ptr %l36
  br label %bb20
bb19:
  br label %bb66
bb20:
  %t60 = load i32, ptr %l36, !tbaa !23
  store i32 %t60, ptr %l5, !tbaa !23
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/generic:Program", ptr %t61, i32 0, i32 2
  %t64 = load i32, ptr %l5, !tbaa !23
  %t67 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t63, i32 %t64)
  store i32 %t67, ptr %l40
  br label %bb21
bb21:
  %t68 = load i32, ptr %l40, !range !{i32 0, i32 33}
  %t70 = trunc i64 19 to i32
  %t71 = icmp eq i32 %t68, %t70
  br i1 %t71, label %bb22, label %bb23
bb22:
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l43, !tbaa !29
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/generic:Program", ptr %t74, i32 0, i32 2
  %t77 = load i32, ptr %l5, !tbaa !23
  %t80 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t76, i32 %t77)
  store i32 %t80, ptr %l47
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t81 = load i64, ptr %l2, !tbaa !24
  %t83 = add i64 %t81, 1
  %t84 = load ptr, ptr %l43, !tbaa !29
  %t85 = load i32, ptr %l47, !tbaa !23
  %t87 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ehasHash(ptr %v0, ptr %t84, i32 %t85, i64 %t83)
  store i1 %t87, ptr %l50
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t88 = load i1, ptr %l50, !tbaa !21
  store i1 %t88, ptr %rv
  br label %ret
bb26:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/generic:Program", ptr %t89, i32 0, i32 2
  %t92 = load i32, ptr %l5, !tbaa !23
  %t95 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t91, i32 %t92)
  store i32 %t95, ptr %l54
  br label %bb27
bb27:
  %t96 = load i32, ptr %l54, !range !{i32 0, i32 33}
  %t98 = trunc i64 18 to i32
  %t99 = icmp eq i32 %t96, %t98
  br i1 %t99, label %bb28, label %bb29
bb28:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load i32, ptr %l5, !tbaa !23
  %t105 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t101, i32 %t102)
  store i1 %t105, ptr %l60
  br label %bb30
bb29:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb31
bb30:
  %t106 = load i1, ptr %l60, !tbaa !21
  store i1 %t106, ptr %l57, !tbaa !21
  br label %bb31
bb31:
  %t107 = load i1, ptr %l57, !tbaa !21
  br i1 %t107, label %bb32, label %bb33
bb32:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/generic:Program", ptr %t108, i32 0, i32 2
  store ptr %t110, ptr %l63, !tbaa !29
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/generic:Program", ptr %t111, i32 0, i32 2
  %t114 = load i32, ptr %l5, !tbaa !23
  %t117 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t113, i32 %t114)
  store i32 %t117, ptr %l67
  br label %bb34
bb33:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb36
bb34:
  %t118 = load ptr, ptr %l63, !tbaa !29
  %t119 = load i32, ptr %l67, !tbaa !23
  %t120 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t118, i32 %t119)
  store i32 %t120, ptr %l68
  br label %bb35
bb35:
  %t121 = load i32, ptr %l68, !range !{i32 0, i32 6}
  %t123 = trunc i64 4 to i32
  %t124 = icmp eq i32 %t121, %t123
  store i1 %t124, ptr %l61, !tbaa !21
  br label %bb36
bb36:
  %t126 = load i1, ptr %l61, !tbaa !21
  br i1 %t126, label %bb37, label %bb38
bb37:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/generic:Program", ptr %t127, i32 0, i32 2
  store ptr %t129, ptr %l73, !tbaa !29
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/generic:Program", ptr %t130, i32 0, i32 2
  %t133 = load i32, ptr %l5, !tbaa !23
  %t136 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t132, i32 %t133)
  store i32 %t136, ptr %l77
  br label %bb39
bb38:
  store i1 false, ptr %l71, !tbaa !21
  br label %bb41
bb39:
  %t137 = load ptr, ptr %l73, !tbaa !29
  %t138 = load i32, ptr %l77, !tbaa !23
  %t139 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t137, i32 %t138)
  store i32 %t139, ptr %l78
  br label %bb40
bb40:
  %t140 = load i32, ptr %l78, !range !{i32 0, i32 33}
  %t142 = trunc i64 19 to i32
  %t143 = icmp eq i32 %t140, %t142
  store i1 %t143, ptr %l71, !tbaa !21
  br label %bb41
bb41:
  %t145 = load i1, ptr %l71, !tbaa !21
  br i1 %t145, label %bb42, label %bb43
bb42:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load i32, ptr %l5, !tbaa !23
  %t150 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2edeclaresEq(ptr %v0, ptr %t146, i32 %t147)
  store i1 %t150, ptr %l84
  br label %bb44
bb43:
  store i1 false, ptr %l81, !tbaa !21
  br label %bb45
bb44:
  %t151 = load i1, ptr %l84, !tbaa !21
  %t152 = xor i1 %t151, true
  store i1 %t152, ptr %l81, !tbaa !21
  br label %bb45
bb45:
  %t154 = load i1, ptr %l81, !tbaa !21
  br i1 %t154, label %bb46, label %bb47
bb46:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load i32, ptr %l5, !tbaa !23
  %t157 = load i32, ptr %l4, !tbaa !23
  %t161 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t155, i32 %t156, i32 %t157)
  store i64 %t161, ptr %l90
  br label %bb48
bb47:
  store i1 false, ptr %l86, !tbaa !21
  br label %bb49
bb48:
  %t162 = load i64, ptr %l90, !tbaa !24
  %t163 = icmp slt i64 %t162, 0
  store i1 %t163, ptr %l86, !tbaa !21
  br label %bb49
bb49:
  %t165 = load i1, ptr %l86, !tbaa !21
  br i1 %t165, label %bb50, label %bb51
bb50:
  %t166 = load ptr, ptr %l0, !tbaa !29
  store ptr %t166, ptr %l92, !tbaa !29
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/generic:Program", ptr %t167, i32 0, i32 2
  store ptr %t169, ptr %l94, !tbaa !29
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/generic:Program", ptr %t170, i32 0, i32 2
  %t173 = load i32, ptr %l5, !tbaa !23
  %t176 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t172, i32 %t173)
  store i32 %t176, ptr %l98
  br label %bb52
bb51:
  br label %bb55
bb52:
  %t177 = load ptr, ptr %l94, !tbaa !29
  %t178 = load i32, ptr %l98, !tbaa !23
  %t179 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t177, i32 %t178)
  store i32 %t179, ptr %l99
  br label %bb53
bb53:
  %t180 = load i64, ptr %l2, !tbaa !24
  %t182 = add i64 %t180, 1
  %t183 = load ptr, ptr %l92, !tbaa !29
  %t184 = load i32, ptr %l99, !tbaa !23
  %t186 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ehasHash(ptr %v0, ptr %t183, i32 %t184, i64 %t182)
  store i1 %t186, ptr %l102
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s0)
  %t187 = load i1, ptr %l102, !tbaa !21
  store i1 %t187, ptr %rv
  br label %ret
bb55:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load i32, ptr %l5, !tbaa !23
  %t192 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2edeclaresEq(ptr %v0, ptr %t188, i32 %t189)
  store i1 %t192, ptr %l105
  br label %bb56
bb56:
  %t193 = load i1, ptr %l105, !tbaa !21
  br i1 %t193, label %bb57, label %bb58
bb57:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load i32, ptr %l5, !tbaa !23
  %t196 = load i32, ptr %l4, !tbaa !23
  %t200 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t194, i32 %t195, i32 %t196)
  store i64 %t200, ptr %l110
  br label %bb59
bb58:
  store i1 false, ptr %l106, !tbaa !21
  br label %bb60
bb59:
  %t201 = load i64, ptr %l110, !tbaa !24
  %t202 = icmp sge i64 %t201, 0
  store i1 %t202, ptr %l106, !tbaa !21
  br label %bb60
bb60:
  %t204 = load i1, ptr %l106, !tbaa !21
  br i1 %t204, label %bb61, label %bb62
bb61:
  %t205 = load ptr, ptr %l0, !tbaa !29
  store ptr %t205, ptr %l113, !tbaa !29
  %t206 = load i32, ptr %l5, !tbaa !23
  store i32 %t206, ptr %l114, !tbaa !23
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load i32, ptr %l5, !tbaa !23
  %t209 = load i32, ptr %l4, !tbaa !23
  %t213 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t207, i32 %t208, i32 %t209)
  store i64 %t213, ptr %l118
  br label %bb63
bb62:
  store i1 false, ptr %l112, !tbaa !21
  br label %bb65
bb63:
  %t214 = load ptr, ptr %l113, !tbaa !29
  %t215 = load i32, ptr %l114, !tbaa !23
  %t216 = load i64, ptr %l118, !tbaa !24
  %t217 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ehashShaped(ptr %v0, ptr %t214, i32 %t215, i64 %t216)
  store i1 %t217, ptr %l119
  br label %bb64
bb64:
  %t218 = load i1, ptr %l119, !tbaa !21
  store i1 %t218, ptr %l112, !tbaa !21
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s0)
  %t219 = load i1, ptr %l112, !tbaa !21
  store i1 %t219, ptr %rv
  br label %ret
bb66:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load i32, ptr %l1, !tbaa !23
  %t222 = load i32, ptr %l4, !tbaa !23
  %t226 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t220, i32 %t221, i32 %t222)
  store i64 %t226, ptr %l123
  br label %bb67
bb67:
  %t227 = load i64, ptr %l123, !tbaa !24
  store i64 %t227, ptr %l6, !tbaa !24
  %t228 = load i64, ptr %l6, !tbaa !24
  %t230 = icmp sge i64 %t228, 0
  br i1 %t230, label %bb68, label %bb69
bb68:
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = load i32, ptr %l1, !tbaa !23
  %t234 = load i64, ptr %l6, !tbaa !24
  %t238 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ehashShaped(ptr %v0, ptr %t232, i32 %t233, i64 %t234)
  store i1 %t238, ptr %l129
  br label %bb70
bb69:
  br label %bb79
bb70:
  %t239 = load i1, ptr %l129, !tbaa !21
  %t240 = xor i1 %t239, true
  br i1 %t240, label %bb71, label %bb72
bb71:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb72:
  br label %bb73
bb73:
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t244 = load i32, ptr %l1, !tbaa !23
  %t245 = load i32, ptr %l4, !tbaa !23
  %t249 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eownMethod(ptr %v0, ptr %t243, i32 %t244, i32 %t245)
  store i1 %t249, ptr %l135
  br label %bb74
bb74:
  %t250 = load i1, ptr %l135, !tbaa !21
  br i1 %t250, label %bb75, label %bb76
bb75:
  store i1 true, ptr %l136, !tbaa !21
  br label %bb78
bb76:
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t252 = load i32, ptr %l1, !tbaa !23
  %t255 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2edeclaresEq(ptr %v0, ptr %t251, i32 %t252)
  store i1 %t255, ptr %l139
  br label %bb77
bb77:
  %t256 = load i1, ptr %l139, !tbaa !21
  %t257 = xor i1 %t256, true
  store i1 %t257, ptr %l136, !tbaa !21
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s0)
  %t259 = load i1, ptr %l136, !tbaa !21
  store i1 %t259, ptr %rv
  br label %ret
bb79:
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t261 = load i32, ptr %l1, !tbaa !23
  %t264 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2edeclaresEq(ptr %v0, ptr %t260, i32 %t261)
  store i1 %t264, ptr %l143
  br label %bb80
bb80:
  %t265 = load i1, ptr %l143, !tbaa !21
  br i1 %t265, label %bb81, label %bb82
bb81:
  store i1 true, ptr %l144, !tbaa !21
  br label %bb85
bb82:
  %t266 = load ptr, ptr %l0, !tbaa !29
  store ptr %t266, ptr %l145, !tbaa !29
  %t267 = load i32, ptr %l1, !tbaa !23
  store i32 %t267, ptr %l146, !tbaa !23
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t270 = getelementptr %"compiler/generic:Program", ptr %t268, i32 0, i32 0
  %t271 = load ptr, ptr %t270, !tbaa !29
  %t273 = getelementptr %"compiler/load:Loader", ptr %t271, i32 0, i32 3
  %t274 = load ptr, ptr %t273, !tbaa !29
  %t276 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t274, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d40, i32 0, i32 1) })
  store i32 %t276, ptr %l150
  br label %bb83
bb83:
  %t277 = load ptr, ptr %l145, !tbaa !29
  %t278 = load i32, ptr %l146, !tbaa !23
  %t279 = load i32, ptr %l150, !tbaa !23
  %t280 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eownMethod(ptr %v0, ptr %t277, i32 %t278, i32 %t279)
  store i1 %t280, ptr %l151
  br label %bb84
bb84:
  %t281 = load i1, ptr %l151, !tbaa !21
  store i1 %t281, ptr %l144, !tbaa !21
  br label %bb85
bb85:
  %t282 = load i1, ptr %l144, !tbaa !21
  br i1 %t282, label %bb86, label %bb87
bb86:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb87:
  br label %bb88
bb88:
  %t284 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t286 = trunc i64 31 to i32
  %t287 = icmp eq i32 %t284, %t286
  br i1 %t287, label %bb89, label %bb90
bb89:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb90:
  br label %bb91
bb91:
  %t290 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t292 = trunc i64 19 to i32
  %t293 = icmp eq i32 %t290, %t292
  br i1 %t293, label %bb92, label %bb93
bb92:
  br label %bb94
bb93:
  br label %bb97
bb94:
  %t295 = load ptr, ptr %l0, !tbaa !29
  store ptr %t295, ptr %l158, !tbaa !29
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t298 = getelementptr %"compiler/generic:Program", ptr %t296, i32 0, i32 2
  %t299 = load i32, ptr %l1, !tbaa !23
  %t302 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t298, i32 %t299)
  store i32 %t302, ptr %l162
  br label %bb95
bb95:
  %t303 = load i64, ptr %l2, !tbaa !24
  %t305 = add i64 %t303, 1
  %t306 = load ptr, ptr %l158, !tbaa !29
  %t307 = load i32, ptr %l162, !tbaa !23
  %t309 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ehasHash(ptr %v0, ptr %t306, i32 %t307, i64 %t305)
  store i1 %t309, ptr %l165
  br label %bb96
bb96:
  call void @__olang_scope_close(ptr %s0)
  %t310 = load i1, ptr %l165, !tbaa !21
  store i1 %t310, ptr %rv
  br label %ret
bb97:
  %t311 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t313 = trunc i64 22 to i32
  %t314 = icmp eq i32 %t311, %t313
  br i1 %t314, label %bb98, label %bb99
bb98:
  br label %bb102
bb99:
  %t316 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t318 = trunc i64 23 to i32
  %t319 = icmp eq i32 %t316, %t318
  br i1 %t319, label %bb100, label %bb101
bb100:
  br label %bb102
bb101:
  br label %bb105
bb102:
  %t321 = load ptr, ptr %l0, !tbaa !29
  store ptr %t321, ptr %l170, !tbaa !29
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t324 = getelementptr %"compiler/generic:Program", ptr %t322, i32 0, i32 2
  %t325 = load i32, ptr %l1, !tbaa !23
  %t328 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t324, i32 %t325)
  store i32 %t328, ptr %l174
  br label %bb103
bb103:
  %t329 = load i64, ptr %l2, !tbaa !24
  %t330 = load ptr, ptr %l170, !tbaa !29
  %t331 = load i32, ptr %l174, !tbaa !23
  %t333 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ehashesAll(ptr %v0, ptr %t330, i32 %t331, i64 %t329)
  store i1 %t333, ptr %l176
  br label %bb104
bb104:
  call void @__olang_scope_close(ptr %s0)
  %t334 = load i1, ptr %l176, !tbaa !21
  store i1 %t334, ptr %rv
  br label %ret
bb105:
  %t335 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t337 = trunc i64 24 to i32
  %t338 = icmp eq i32 %t335, %t337
  br i1 %t338, label %bb106, label %bb107
bb106:
  br label %bb108
bb107:
  br label %bb111
bb108:
  %t340 = load ptr, ptr %l0, !tbaa !29
  store ptr %t340, ptr %l179, !tbaa !29
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t343 = getelementptr %"compiler/generic:Program", ptr %t341, i32 0, i32 2
  %t344 = load i32, ptr %l1, !tbaa !23
  %t347 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t343, i32 %t344)
  store i32 %t347, ptr %l183
  br label %bb109
bb109:
  %t348 = load i64, ptr %l2, !tbaa !24
  %t349 = load ptr, ptr %l179, !tbaa !29
  %t350 = load i32, ptr %l183, !tbaa !23
  %t352 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ehashesAll(ptr %v0, ptr %t349, i32 %t350, i64 %t348)
  store i1 %t352, ptr %l185
  br label %bb110
bb110:
  call void @__olang_scope_close(ptr %s0)
  %t353 = load i1, ptr %l185, !tbaa !21
  store i1 %t353, ptr %rv
  br label %ret
bb111:
  %t354 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t356 = trunc i64 18 to i32
  %t357 = icmp eq i32 %t354, %t356
  br i1 %t357, label %bb112, label %bb113
bb112:
  br label %bb114
bb113:
  br label %bb141
bb114:
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t360 = load i32, ptr %l1, !tbaa !23
  %t363 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t359, i32 %t360)
  store i1 %t363, ptr %l190
  br label %bb115
bb115:
  %t364 = load i1, ptr %l190, !tbaa !21
  %t365 = xor i1 %t364, true
  br i1 %t365, label %bb116, label %bb117
bb116:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb117:
  br label %bb118
bb118:
  %t368 = load ptr, ptr %l0, !tbaa !29
  %t370 = getelementptr %"compiler/generic:Program", ptr %t368, i32 0, i32 2
  store ptr %t370, ptr %l194, !tbaa !29
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t373 = getelementptr %"compiler/generic:Program", ptr %t371, i32 0, i32 2
  %t374 = load i32, ptr %l1, !tbaa !23
  %t377 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t373, i32 %t374)
  store i32 %t377, ptr %l198
  br label %bb119
bb119:
  %t378 = load ptr, ptr %l194, !tbaa !29
  %t379 = load i32, ptr %l198, !tbaa !23
  %t380 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t378, i32 %t379)
  store i32 %t380, ptr %l199
  br label %bb120
bb120:
  %t381 = load i32, ptr %l199, !range !{i32 0, i32 6}
  store i32 %t381, ptr %l7
  %t382 = load i32, ptr %l7, !range !{i32 0, i32 6}
  %t384 = trunc i64 0 to i32
  %t385 = icmp eq i32 %t382, %t384
  br i1 %t385, label %bb121, label %bb122
bb121:
  %t387 = load ptr, ptr %l0, !tbaa !29
  store ptr %t387, ptr %l202, !tbaa !29
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t390 = getelementptr %"compiler/generic:Program", ptr %t388, i32 0, i32 2
  %t391 = load i32, ptr %l1, !tbaa !23
  %t394 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t390, i32 %t391)
  store i32 %t394, ptr %l206
  br label %bb123
bb122:
  br label %bb125
bb123:
  %t395 = load i64, ptr %l2, !tbaa !24
  %t396 = load ptr, ptr %l202, !tbaa !29
  %t397 = load i32, ptr %l206, !tbaa !23
  %t399 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ehashesAll(ptr %v0, ptr %t396, i32 %t397, i64 %t395)
  store i1 %t399, ptr %l208
  br label %bb124
bb124:
  call void @__olang_scope_close(ptr %s0)
  %t400 = load i1, ptr %l208, !tbaa !21
  store i1 %t400, ptr %rv
  br label %ret
bb125:
  %t401 = load i32, ptr %l7, !range !{i32 0, i32 6}
  %t403 = trunc i64 1 to i32
  %t404 = icmp eq i32 %t401, %t403
  br i1 %t404, label %bb126, label %bb127
bb126:
  %t406 = load ptr, ptr %l0, !tbaa !29
  store ptr %t406, ptr %l211, !tbaa !29
  %t407 = load ptr, ptr %l0, !tbaa !29
  %t409 = getelementptr %"compiler/generic:Program", ptr %t407, i32 0, i32 2
  %t410 = load i32, ptr %l1, !tbaa !23
  %t413 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t409, i32 %t410)
  store i32 %t413, ptr %l215
  br label %bb128
bb127:
  br label %bb130
bb128:
  %t414 = load i64, ptr %l2, !tbaa !24
  %t415 = load ptr, ptr %l211, !tbaa !29
  %t416 = load i32, ptr %l215, !tbaa !23
  %t418 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ehashesAll(ptr %v0, ptr %t415, i32 %t416, i64 %t414)
  store i1 %t418, ptr %l217
  br label %bb129
bb129:
  call void @__olang_scope_close(ptr %s0)
  %t419 = load i1, ptr %l217, !tbaa !21
  store i1 %t419, ptr %rv
  br label %ret
bb130:
  %t420 = load i32, ptr %l7, !range !{i32 0, i32 6}
  %t422 = trunc i64 4 to i32
  %t423 = icmp eq i32 %t420, %t422
  br i1 %t423, label %bb131, label %bb132
bb131:
  %t425 = load ptr, ptr %l0, !tbaa !29
  %t427 = getelementptr %"compiler/generic:Program", ptr %t425, i32 0, i32 2
  store ptr %t427, ptr %l222, !tbaa !29
  %t428 = load ptr, ptr %l0, !tbaa !29
  %t430 = getelementptr %"compiler/generic:Program", ptr %t428, i32 0, i32 2
  %t431 = load i32, ptr %l1, !tbaa !23
  %t434 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t430, i32 %t431)
  store i32 %t434, ptr %l226
  br label %bb133
bb132:
  store i1 false, ptr %l220, !tbaa !21
  br label %bb135
bb133:
  %t435 = load ptr, ptr %l222, !tbaa !29
  %t436 = load i32, ptr %l226, !tbaa !23
  %t437 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t435, i32 %t436)
  store i32 %t437, ptr %l227
  br label %bb134
bb134:
  %t438 = load i32, ptr %l227, !range !{i32 0, i32 33}
  %t440 = trunc i64 19 to i32
  %t441 = icmp eq i32 %t438, %t440
  store i1 %t441, ptr %l220, !tbaa !21
  br label %bb135
bb135:
  %t443 = load i1, ptr %l220, !tbaa !21
  br i1 %t443, label %bb136, label %bb137
bb136:
  %t444 = load ptr, ptr %l0, !tbaa !29
  store ptr %t444, ptr %l230, !tbaa !29
  %t445 = load ptr, ptr %l0, !tbaa !29
  %t447 = getelementptr %"compiler/generic:Program", ptr %t445, i32 0, i32 2
  %t448 = load i32, ptr %l1, !tbaa !23
  %t451 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t447, i32 %t448)
  store i32 %t451, ptr %l234
  br label %bb138
bb137:
  br label %bb140
bb138:
  %t452 = load i64, ptr %l2, !tbaa !24
  %t454 = add i64 %t452, 1
  %t455 = load ptr, ptr %l230, !tbaa !29
  %t456 = load i32, ptr %l234, !tbaa !23
  %t458 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ehasHash(ptr %v0, ptr %t455, i32 %t456, i64 %t454)
  store i1 %t458, ptr %l237
  br label %bb139
bb139:
  call void @__olang_scope_close(ptr %s0)
  %t459 = load i1, ptr %l237, !tbaa !21
  store i1 %t459, ptr %rv
  br label %ret
bb140:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb141:
  br i1 true, label %bb142, label %bb143
bb142:
  br label %bb144
bb143:
  br label %bb145
bb144:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb145:
  call void @__olang_check_failed(ptr @olang_loc_ee8d77a4a1fda3da_cc07c41aef88f656)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ehashShaped(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l7 = alloca i32
  %l11 = alloca i1
  %l13 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca { i64, ptr }
  %l21 = alloca i1
  %l25 = alloca i32
  %l28 = alloca i32
  %l30 = alloca i1
  %l34 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t7 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodSig(ptr %v0, ptr %t1, i64 %a2, i32 %a1)
  store i32 %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load i32, ptr %l7, !tbaa !23
  store i32 %t8, ptr %l3, !tbaa !23
  %t9 = load i32, ptr %l3, !tbaa !23
  %t10 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t13 = icmp ne i32 %t9, %t10
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  store ptr %t17, ptr %l13, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/generic:Program", ptr %t18, i32 0, i32 2
  %t21 = load i32, ptr %l3, !tbaa !23
  %t24 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t20, i32 %t21)
  store i32 %t24, ptr %l17
  br label %bb4
bb3:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb6
bb4:
  %t25 = load ptr, ptr %l13, !tbaa !29
  %t26 = load i32, ptr %l17, !tbaa !23
  %t27 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t25, i32 %t26)
  store { i64, ptr } %t27, ptr %l18
  br label %bb5
bb5:
  %t28 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  %t31 = icmp eq i64 %t29, 1
  store i1 %t31, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t33 = load i1, ptr %l11, !tbaa !21
  br i1 %t33, label %bb7, label %bb8
bb7:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/generic:Program", ptr %t34, i32 0, i32 2
  %t37 = load i32, ptr %l3, !tbaa !23
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t36, i32 %t37)
  store i32 %t40, ptr %l25
  br label %bb9
bb8:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb11
bb9:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/generic:Program", ptr %t41, i32 0, i32 2
  %t45 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t43, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d41, i32 0, i32 1) })
  store i32 %t45, ptr %l28
  br label %bb10
bb10:
  %t46 = load i32, ptr %l25, !tbaa !23
  %t47 = load i32, ptr %l28, !tbaa !23
  %t48 = icmp eq i32 %t46, %t47
  store i1 %t48, ptr %l21, !tbaa !21
  br label %bb11
bb11:
  %t50 = load i1, ptr %l21, !tbaa !21
  br i1 %t50, label %bb12, label %bb13
bb12:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/generic:Program", ptr %t51, i32 0, i32 2
  %t54 = load i32, ptr %l3, !tbaa !23
  %t57 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t53, i32 %t54)
  store i32 %t57, ptr %l34
  br label %bb14
bb13:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb15
bb14:
  %t58 = load i32, ptr %l34, !tbaa !23
  %t59 = icmp eq i32 %t58, 0
  store i1 %t59, ptr %l30, !tbaa !21
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  %t61 = load i1, ptr %l30, !tbaa !21
  store i1 %t61, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ehashesAll(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l10 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l22 = alloca i1
  %l27 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t7 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t3, i32 %a1)
  store { i64, ptr } %t7, ptr %l10
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  br label %bb14
bb4:
  br label %bb5
bb5:
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t21, ptr %l17, !tbaa !27
  %t22 = load i64, ptr %l4, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr i32, ptr %t25, i64 %t22
  %t27 = load i32, ptr %t26, !tbaa !33
  store i32 %t27, ptr %l6, !tbaa !23
  %t29 = load i32, ptr %l6, !tbaa !23
  %t31 = icmp ne i32 %t29, 0
  br i1 %t31, label %bb6, label %bb7
bb6:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i32, ptr %l6, !tbaa !23
  %t37 = add i64 %a2, 1
  %t41 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ehasHash(ptr %v0, ptr %t33, i32 %t34, i64 %t37)
  store i1 %t41, ptr %l27
  br label %bb8
bb7:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb9
bb8:
  %t42 = load i1, ptr %l27, !tbaa !21
  %t43 = xor i1 %t42, true
  store i1 %t43, ptr %l22, !tbaa !21
  br label %bb9
bb9:
  %t45 = load i1, ptr %l22, !tbaa !21
  br i1 %t45, label %bb10, label %bb11
bb10:
  store i1 false, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = add i64 %t47, 1
  store i64 %t50, ptr %l4, !tbaa !24
  br label %bb2
bb14:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ekeepsPromise(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, i32 %a3, ptr %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca [0 x i64]
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l21 = alloca ptr
  %l25 = alloca i32
  %l26 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l31 = alloca i1
  %l33 = alloca i1
  %l36 = alloca { i64, ptr }
  %l39 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l43 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca %"compiler/diagmsg:Msg"
  %l50 = alloca [0 x i64]
  %l51 = alloca { i64, ptr }
  %l58 = alloca [3 x i64]
  %l59 = alloca { i64, ptr }
  %l64 = alloca i64
  %l67 = alloca [0 x i64]
  %l68 = alloca { i64, ptr }
  %l72 = alloca ptr
  %l73 = alloca ptr
  %l74 = alloca ptr
  %l77 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l80 = alloca %"compiler/diagmsg:Msg"
  %l81 = alloca [0 x i64]
  %l82 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l87 = alloca i1
  %l89 = alloca ptr
  %l90 = alloca ptr
  %l91 = alloca ptr
  %l94 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l97 = alloca %"compiler/diagmsg:Msg"
  %l98 = alloca [0 x i64]
  %l99 = alloca { i64, ptr }
  %l106 = alloca [3 x i64]
  %l107 = alloca { i64, ptr }
  %l112 = alloca ptr
  %l113 = alloca ptr
  %l114 = alloca ptr
  %l117 = alloca { i64, ptr }
  %l119 = alloca { i64, ptr }
  %l122 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l125 = alloca %"compiler/diagmsg:Msg"
  %l126 = alloca [0 x i64]
  %l127 = alloca { i64, ptr }
  %l129 = alloca { i64, ptr }
  %l131 = alloca { i64, ptr }
  %l137 = alloca i1
  %l141 = alloca i32
  %l145 = alloca i32
  %l152 = alloca [3 x i64]
  %l153 = alloca { i64, ptr }
  %l156 = alloca { i64, ptr }
  %l159 = alloca i1
  %l161 = alloca ptr
  %l162 = alloca ptr
  %l163 = alloca ptr
  %l166 = alloca { i64, ptr }
  %l169 = alloca { i64, ptr }
  %l171 = alloca { i64, ptr }
  %l172 = alloca %"compiler/diagmsg:Msg"
  %l173 = alloca [0 x i64]
  %l174 = alloca { i64, ptr }
  %l178 = alloca i1
  %l179 = alloca i1
  %l181 = alloca ptr
  %l185 = alloca i32
  %l186 = alloca i32
  %l190 = alloca ptr
  %l194 = alloca i32
  %l195 = alloca { i64, ptr }
  %l201 = alloca i64
  %l204 = alloca i64
  %l226 = alloca i1
  %l231 = alloca i1
  %l233 = alloca { i64, ptr }
  %l236 = alloca i1
  %l238 = alloca ptr
  %l239 = alloca ptr
  %l240 = alloca ptr
  %l243 = alloca { i64, ptr }
  %l245 = alloca { i64, ptr }
  %l248 = alloca { i64, ptr }
  %l251 = alloca %"compiler/diagmsg:Msg"
  %l252 = alloca [0 x i64]
  %l253 = alloca { i64, ptr }
  %l261 = alloca [3 x i64]
  %l262 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a4, ptr %l4
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store [0 x i64] zeroinitializer, ptr %l6
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/generic:Program", ptr %t2, i32 0, i32 2
  store ptr %t4, ptr %l21, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/generic:Program", ptr %t5, i32 0, i32 2
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t7, i32 %a3)
  store i32 %t11, ptr %l25
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l21, !tbaa !29
  %t13 = load i32, ptr %l25, !tbaa !23
  %t14 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t12, i32 %t13)
  store { i64, ptr } %t14, ptr %l26
  br label %bb2
bb2:
  %t15 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t15, ptr %l7, !tbaa !27
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t17, ptr %l28, !tbaa !27
  %t18 = load i64, ptr %l5, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i32, ptr %t21, i64 %t18
  %t23 = load i32, ptr %t22, !tbaa !33
  %t26 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emayHold(ptr %v0, ptr %t16, i32 %t23)
  store i1 %t26, ptr %l31
  br label %bb3
bb3:
  %t27 = load i1, ptr %l31, !tbaa !21
  %t28 = xor i1 %t27, true
  br i1 %t28, label %bb4, label %bb5
bb4:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/generic:Program", ptr %t30, i32 0, i32 2
  %t33 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t33, ptr %l36, !tbaa !27
  %t34 = load i64, ptr %l5, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr i32, ptr %t37, i64 %t34
  %t39 = load i32, ptr %t38, !tbaa !33
  %t42 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnique(ptr %v0, ptr %t32, i32 %t39)
  store i1 %t42, ptr %l39
  br label %bb6
bb5:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb7
bb6:
  %t43 = load i1, ptr %l39, !tbaa !21
  %t44 = xor i1 %t43, true
  store i1 %t44, ptr %l33, !tbaa !21
  br label %bb7
bb7:
  %t46 = load i1, ptr %l33, !tbaa !21
  br i1 %t46, label %bb8, label %bb9
bb8:
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l41, !tbaa !29
  %t48 = load ptr, ptr %l1, !tbaa !29
  store ptr %t48, ptr %l42, !tbaa !29
  %t49 = load ptr, ptr %l4, !tbaa !29
  store ptr %t49, ptr %l43, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load ptr, ptr %l4, !tbaa !29
  %t53 = getelementptr %"compiler/ast:Promise", ptr %t51, i32 0, i32 2
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  store { i64, ptr } %t54, ptr %l46, !tbaa !27
  %t55 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr i32, ptr %t56, i64 0
  %t58 = load i32, ptr %t57, !tbaa !33
  %t61 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t50, i32 %t58)
  store { i64, ptr } %t61, ptr %l48
  br label %bb10
bb9:
  br label %bb13
bb10:
  %t62 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t63 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseKeepsValue(ptr %v0, ptr %v0, { i64, ptr } %t62)
  store %"compiler/diagmsg:Msg" %t63, ptr %l49
  br label %bb11
bb11:
  %t64 = load ptr, ptr %l41, !tbaa !29
  %t65 = load ptr, ptr %l42, !tbaa !29
  %t66 = load ptr, ptr %l43, !tbaa !29
  %t67 = load %"compiler/diagmsg:Msg", ptr %l49
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epromiseErr(ptr %v0, ptr %v1, ptr %v3, ptr %v0, ptr %t64, ptr %t65, ptr %t66, %"compiler/diagmsg:Msg" %t67)
  br label %bb12
bb12:
  %t68 = load [0 x i64], ptr %l6
  store [0 x i64] %t68, ptr %l50
  %t69 = mul i64 0, 8
  %t70 = insertvalue { i64, ptr } undef, i64 0, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t71, ptr %l51, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = mul i64 0, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t73, ptr %l50, i64 %t74, i1 false)
  call void @__olang_scope_close(ptr %s0)
  %t75 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t75, ptr %rv
  br label %ret
bb13:
  %t76 = load ptr, ptr %l4, !tbaa !29
  %t78 = getelementptr %"compiler/ast:Promise", ptr %t76, i32 0, i32 2
  %t79 = load { i64, ptr }, ptr %t78, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t83 = icmp eq i64 %t81, 1
  br i1 %t83, label %bb14, label %bb15
bb14:
  %t85 = load i64, ptr %l5, !tbaa !24
  %t86 = load i64, ptr @G_2ecompiler_2ftypes_2eKeepsHome, !tbaa !24
  %t88 = insertvalue [3 x i64] undef, i64 %t85, 0
  %t90 = insertvalue [3 x i64] %t88, i64 %t86, 1
  %t91 = insertvalue [3 x i64] %t90, i64 0, 2
  store [3 x i64] %t91, ptr %l58
  %t92 = mul i64 3, 8
  %t93 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t92)
  %t94 = insertvalue { i64, ptr } undef, i64 3, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t93, 1
  store { i64, ptr } %t95, ptr %l59, !tbaa !27
  %t96 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = mul i64 3, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t97, ptr %l58, i64 %t98, i1 false)
  call void @__olang_scope_close(ptr %s0)
  %t99 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t99, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t103 = load ptr, ptr %l4, !tbaa !29
  %t108 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epromiseParam(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t100, ptr %t101, ptr %a2, ptr %t103, i64 1)
  store i64 %t108, ptr %l64
  br label %bb17
bb17:
  %t109 = load i64, ptr %l64, !tbaa !24
  store i64 %t109, ptr %l8, !tbaa !24
  %t110 = load i64, ptr %l8, !tbaa !24
  %t112 = icmp slt i64 %t110, 0
  br i1 %t112, label %bb18, label %bb19
bb18:
  %t114 = load [0 x i64], ptr %l6
  store [0 x i64] %t114, ptr %l67
  %t115 = mul i64 0, 8
  %t116 = insertvalue { i64, ptr } undef, i64 0, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t117, ptr %l68, !tbaa !27
  %t118 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = mul i64 0, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t119, ptr %l67, i64 %t120, i1 false)
  call void @__olang_scope_close(ptr %s0)
  %t121 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t121, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t122 = load i64, ptr %l8, !tbaa !24
  %t123 = load i64, ptr %l5, !tbaa !24
  %t126 = icmp eq i64 %t122, %t123
  br i1 %t126, label %bb21, label %bb22
bb21:
  %t128 = load ptr, ptr %l0, !tbaa !29
  store ptr %t128, ptr %l72, !tbaa !29
  %t129 = load ptr, ptr %l1, !tbaa !29
  store ptr %t129, ptr %l73, !tbaa !29
  %t130 = load ptr, ptr %l4, !tbaa !29
  store ptr %t130, ptr %l74, !tbaa !29
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load ptr, ptr %l4, !tbaa !29
  %t134 = getelementptr %"compiler/ast:Promise", ptr %t132, i32 0, i32 2
  %t135 = load { i64, ptr }, ptr %t134, !tbaa !27
  store { i64, ptr } %t135, ptr %l77, !tbaa !27
  %t136 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !27
  %t138 = getelementptr i32, ptr %t137, i64 0
  %t139 = load i32, ptr %t138, !tbaa !33
  %t142 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t131, i32 %t139)
  store { i64, ptr } %t142, ptr %l79
  br label %bb23
bb22:
  br label %bb26
bb23:
  %t143 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t144 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseKeepsSelf(ptr %v0, ptr %v0, { i64, ptr } %t143)
  store %"compiler/diagmsg:Msg" %t144, ptr %l80
  br label %bb24
bb24:
  %t145 = load ptr, ptr %l72, !tbaa !29
  %t146 = load ptr, ptr %l73, !tbaa !29
  %t147 = load ptr, ptr %l74, !tbaa !29
  %t148 = load %"compiler/diagmsg:Msg", ptr %l80
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epromiseErr(ptr %v0, ptr %v1, ptr %v3, ptr %v0, ptr %t145, ptr %t146, ptr %t147, %"compiler/diagmsg:Msg" %t148)
  br label %bb25
bb25:
  %t149 = load [0 x i64], ptr %l6
  store [0 x i64] %t149, ptr %l81
  %t150 = mul i64 0, 8
  %t151 = insertvalue { i64, ptr } undef, i64 0, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t152, ptr %l82, !tbaa !27
  %t153 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = mul i64 0, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t154, ptr %l81, i64 %t155, i1 false)
  call void @__olang_scope_close(ptr %s0)
  %t156 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t156, ptr %rv
  br label %ret
bb26:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t158, ptr %l84, !tbaa !27
  %t159 = load i64, ptr %l8, !tbaa !24
  %t161 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !27
  %t163 = getelementptr i32, ptr %t162, i64 %t159
  %t164 = load i32, ptr %t163, !tbaa !33
  %t167 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emayHold(ptr %v0, ptr %t157, i32 %t164)
  store i1 %t167, ptr %l87
  br label %bb27
bb27:
  %t168 = load i1, ptr %l87, !tbaa !21
  %t169 = xor i1 %t168, true
  br i1 %t169, label %bb28, label %bb29
bb28:
  %t171 = load ptr, ptr %l0, !tbaa !29
  store ptr %t171, ptr %l89, !tbaa !29
  %t172 = load ptr, ptr %l1, !tbaa !29
  store ptr %t172, ptr %l90, !tbaa !29
  %t173 = load ptr, ptr %l4, !tbaa !29
  store ptr %t173, ptr %l91, !tbaa !29
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load ptr, ptr %l4, !tbaa !29
  %t177 = getelementptr %"compiler/ast:Promise", ptr %t175, i32 0, i32 2
  %t178 = load { i64, ptr }, ptr %t177, !tbaa !27
  store { i64, ptr } %t178, ptr %l94, !tbaa !27
  %t179 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !27
  %t181 = getelementptr i32, ptr %t180, i64 1
  %t182 = load i32, ptr %t181, !tbaa !33
  %t185 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t174, i32 %t182)
  store { i64, ptr } %t185, ptr %l96
  br label %bb30
bb29:
  br label %bb33
bb30:
  %t186 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t187 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseKeepsInValue(ptr %v0, ptr %v0, { i64, ptr } %t186)
  store %"compiler/diagmsg:Msg" %t187, ptr %l97
  br label %bb31
bb31:
  %t188 = load ptr, ptr %l89, !tbaa !29
  %t189 = load ptr, ptr %l90, !tbaa !29
  %t190 = load ptr, ptr %l91, !tbaa !29
  %t191 = load %"compiler/diagmsg:Msg", ptr %l97
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epromiseErr(ptr %v0, ptr %v1, ptr %v3, ptr %v0, ptr %t188, ptr %t189, ptr %t190, %"compiler/diagmsg:Msg" %t191)
  br label %bb32
bb32:
  %t192 = load [0 x i64], ptr %l6
  store [0 x i64] %t192, ptr %l98
  %t193 = mul i64 0, 8
  %t194 = insertvalue { i64, ptr } undef, i64 0, 0
  %t195 = insertvalue { i64, ptr } %t194, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t195, ptr %l99, !tbaa !27
  %t196 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !27
  %t198 = mul i64 0, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t197, ptr %l98, i64 %t198, i1 false)
  call void @__olang_scope_close(ptr %s0)
  %t199 = load { i64, ptr }, ptr %l99, !tbaa !27
  store { i64, ptr } %t199, ptr %rv
  br label %ret
bb33:
  %t200 = load ptr, ptr %l4, !tbaa !29
  %t202 = getelementptr %"compiler/ast:Promise", ptr %t200, i32 0, i32 2
  %t203 = load { i64, ptr }, ptr %t202, !tbaa !27
  %t205 = extractvalue { i64, ptr } %t203, 0
  %t207 = icmp eq i64 %t205, 2
  br i1 %t207, label %bb34, label %bb35
bb34:
  %t209 = load i64, ptr %l5, !tbaa !24
  %t210 = load i64, ptr %l8, !tbaa !24
  %t212 = insertvalue [3 x i64] undef, i64 %t209, 0
  %t214 = insertvalue [3 x i64] %t212, i64 %t210, 1
  %t215 = insertvalue [3 x i64] %t214, i64 0, 2
  store [3 x i64] %t215, ptr %l106
  %t216 = mul i64 3, 8
  %t217 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t216)
  %t218 = insertvalue { i64, ptr } undef, i64 3, 0
  %t219 = insertvalue { i64, ptr } %t218, ptr %t217, 1
  store { i64, ptr } %t219, ptr %l107, !tbaa !27
  %t220 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t221 = load ptr, ptr %t220, !tbaa !27
  %t222 = mul i64 3, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t221, ptr %l106, i64 %t222, i1 false)
  call void @__olang_scope_close(ptr %s0)
  %t223 = load { i64, ptr }, ptr %l107, !tbaa !27
  store { i64, ptr } %t223, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  %t224 = load ptr, ptr %l4, !tbaa !29
  %t226 = getelementptr %"compiler/ast:Promise", ptr %t224, i32 0, i32 2
  %t227 = load { i64, ptr }, ptr %t226, !tbaa !27
  %t229 = extractvalue { i64, ptr } %t227, 0
  %t231 = icmp sgt i64 %t229, 3
  br i1 %t231, label %bb37, label %bb38
bb37:
  %t233 = load ptr, ptr %l0, !tbaa !29
  store ptr %t233, ptr %l112, !tbaa !29
  %t234 = load ptr, ptr %l1, !tbaa !29
  store ptr %t234, ptr %l113, !tbaa !29
  %t235 = load ptr, ptr %l4, !tbaa !29
  store ptr %t235, ptr %l114, !tbaa !29
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t237 = load ptr, ptr %l4, !tbaa !29
  %t239 = getelementptr %"compiler/ast:Promise", ptr %t237, i32 0, i32 2
  %t240 = load { i64, ptr }, ptr %t239, !tbaa !27
  store { i64, ptr } %t240, ptr %l117, !tbaa !27
  %t241 = getelementptr { i64, ptr }, ptr %l117, i32 0, i32 1
  %t242 = load ptr, ptr %t241, !tbaa !27
  %t243 = getelementptr i32, ptr %t242, i64 1
  %t244 = load i32, ptr %t243, !tbaa !33
  %t247 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t236, i32 %t244)
  store { i64, ptr } %t247, ptr %l119
  br label %bb39
bb38:
  br label %bb43
bb39:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load ptr, ptr %l4, !tbaa !29
  %t251 = getelementptr %"compiler/ast:Promise", ptr %t249, i32 0, i32 2
  %t252 = load { i64, ptr }, ptr %t251, !tbaa !27
  store { i64, ptr } %t252, ptr %l122, !tbaa !27
  %t253 = getelementptr { i64, ptr }, ptr %l122, i32 0, i32 1
  %t254 = load ptr, ptr %t253, !tbaa !27
  %t255 = getelementptr i32, ptr %t254, i64 2
  %t256 = load i32, ptr %t255, !tbaa !33
  %t259 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t248, i32 %t256)
  store { i64, ptr } %t259, ptr %l124
  br label %bb40
bb40:
  %t260 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t261 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t262 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseKeepsPath(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t260, { i64, ptr } %t261)
  store %"compiler/diagmsg:Msg" %t262, ptr %l125
  br label %bb41
bb41:
  %t263 = load ptr, ptr %l112, !tbaa !29
  %t264 = load ptr, ptr %l113, !tbaa !29
  %t265 = load ptr, ptr %l114, !tbaa !29
  %t266 = load %"compiler/diagmsg:Msg", ptr %l125
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epromiseErr(ptr %v0, ptr %v1, ptr %v3, ptr %v0, ptr %t263, ptr %t264, ptr %t265, %"compiler/diagmsg:Msg" %t266)
  br label %bb42
bb42:
  %t267 = load [0 x i64], ptr %l6
  store [0 x i64] %t267, ptr %l126
  %t268 = mul i64 0, 8
  %t269 = insertvalue { i64, ptr } undef, i64 0, 0
  %t270 = insertvalue { i64, ptr } %t269, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t270, ptr %l127, !tbaa !27
  %t271 = getelementptr { i64, ptr }, ptr %l127, i32 0, i32 1
  %t272 = load ptr, ptr %t271, !tbaa !27
  %t273 = mul i64 0, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t272, ptr %l126, i64 %t273, i1 false)
  call void @__olang_scope_close(ptr %s0)
  %t274 = load { i64, ptr }, ptr %l127, !tbaa !27
  store { i64, ptr } %t274, ptr %rv
  br label %ret
bb43:
  %t275 = load ptr, ptr %l4, !tbaa !29
  %t277 = getelementptr %"compiler/ast:Promise", ptr %t275, i32 0, i32 2
  %t278 = load { i64, ptr }, ptr %t277, !tbaa !27
  store { i64, ptr } %t278, ptr %l129, !tbaa !27
  %t279 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t280 = load ptr, ptr %t279, !tbaa !27
  %t281 = getelementptr i32, ptr %t280, i64 2
  %t282 = load i32, ptr %t281, !tbaa !33
  store i32 %t282, ptr %l9, !tbaa !23
  %t284 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t284, ptr %l131, !tbaa !27
  %t285 = load i64, ptr %l8, !tbaa !24
  %t287 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t288 = load ptr, ptr %t287, !tbaa !27
  %t289 = getelementptr i32, ptr %t288, i64 %t285
  %t290 = load i32, ptr %t289, !tbaa !33
  store i32 %t290, ptr %l10, !tbaa !23
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = getelementptr %"compiler/generic:Program", ptr %t292, i32 0, i32 2
  %t295 = load i32, ptr %l10, !tbaa !23
  %t298 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t294, i32 %t295)
  store i1 %t298, ptr %l137
  br label %bb44
bb44:
  %t299 = load i1, ptr %l137, !tbaa !21
  br i1 %t299, label %bb45, label %bb46
bb45:
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t302 = getelementptr %"compiler/generic:Program", ptr %t300, i32 0, i32 2
  %t303 = load i32, ptr %l10, !tbaa !23
  %t306 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t302, i32 %t303)
  store i32 %t306, ptr %l141
  br label %bb47
bb46:
  br label %bb48
bb47:
  %t307 = load i32, ptr %l141, !tbaa !23
  store i32 %t307, ptr %l10, !tbaa !23
  br label %bb48
bb48:
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t310 = getelementptr %"compiler/generic:Program", ptr %t308, i32 0, i32 2
  %t311 = load i32, ptr %l10, !tbaa !23
  %t314 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t310, i32 %t311)
  store i32 %t314, ptr %l145
  br label %bb49
bb49:
  %t315 = load i32, ptr %l145, !range !{i32 0, i32 33}
  %t317 = trunc i64 25 to i32
  %t318 = icmp eq i32 %t315, %t317
  br i1 %t318, label %bb50, label %bb51
bb50:
  %t320 = load i64, ptr %l5, !tbaa !24
  %t321 = load i64, ptr %l8, !tbaa !24
  %t322 = load i32, ptr %l9, !tbaa !23
  %t324 = sext i32 %t322 to i64
  %t326 = insertvalue [3 x i64] undef, i64 %t320, 0
  %t328 = insertvalue [3 x i64] %t326, i64 %t321, 1
  %t330 = insertvalue [3 x i64] %t328, i64 %t324, 2
  store [3 x i64] %t330, ptr %l152
  %t331 = mul i64 3, 8
  %t332 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t331)
  %t333 = insertvalue { i64, ptr } undef, i64 3, 0
  %t334 = insertvalue { i64, ptr } %t333, ptr %t332, 1
  store { i64, ptr } %t334, ptr %l153, !tbaa !27
  %t335 = getelementptr { i64, ptr }, ptr %l153, i32 0, i32 1
  %t336 = load ptr, ptr %t335, !tbaa !27
  %t337 = mul i64 3, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t336, ptr %l152, i64 %t337, i1 false)
  call void @__olang_scope_close(ptr %s0)
  %t338 = load { i64, ptr }, ptr %l153, !tbaa !27
  store { i64, ptr } %t338, ptr %rv
  br label %ret
bb51:
  br label %bb52
bb52:
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t340 = load i32, ptr %l10, !tbaa !23
  %t343 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFieldNames(ptr %v0, ptr %s0, ptr %t339, i32 %t340)
  store { i64, ptr } %t343, ptr %l156
  br label %bb53
bb53:
  %t344 = load { i64, ptr }, ptr %l156, !tbaa !27
  store { i64, ptr } %t344, ptr %l11, !tbaa !27
  %t345 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t346 = load i32, ptr %l9, !tbaa !23
  %t349 = call i1 @std_2fprelude_2farray_2eArray_3ccompiler_2fsource_3aNameId_3e_2eHas_3ccompiler_2fsource_3aNameId_3e(ptr %s0, { i64, ptr } %t345, i32 %t346)
  store i1 %t349, ptr %l159
  br label %bb54
bb54:
  %t350 = load i1, ptr %l159, !tbaa !21
  %t351 = xor i1 %t350, true
  br i1 %t351, label %bb55, label %bb56
bb55:
  %t353 = load ptr, ptr %l0, !tbaa !29
  store ptr %t353, ptr %l161, !tbaa !29
  %t354 = load ptr, ptr %l1, !tbaa !29
  store ptr %t354, ptr %l162, !tbaa !29
  %t355 = load ptr, ptr %l4, !tbaa !29
  store ptr %t355, ptr %l163, !tbaa !29
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t357 = load i32, ptr %l9, !tbaa !23
  %t360 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t356, i32 %t357)
  store { i64, ptr } %t360, ptr %l166
  br label %bb57
bb56:
  br label %bb61
bb57:
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t362 = load ptr, ptr %l4, !tbaa !29
  %t364 = getelementptr %"compiler/ast:Promise", ptr %t362, i32 0, i32 2
  %t365 = load { i64, ptr }, ptr %t364, !tbaa !27
  store { i64, ptr } %t365, ptr %l169, !tbaa !27
  %t366 = getelementptr { i64, ptr }, ptr %l169, i32 0, i32 1
  %t367 = load ptr, ptr %t366, !tbaa !27
  %t368 = getelementptr i32, ptr %t367, i64 1
  %t369 = load i32, ptr %t368, !tbaa !33
  %t372 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t361, i32 %t369)
  store { i64, ptr } %t372, ptr %l171
  br label %bb58
bb58:
  %t373 = load { i64, ptr }, ptr %l166, !tbaa !27
  %t374 = load { i64, ptr }, ptr %l171, !tbaa !27
  %t375 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseKeepsField(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t373, { i64, ptr } %t374)
  store %"compiler/diagmsg:Msg" %t375, ptr %l172
  br label %bb59
bb59:
  %t376 = load ptr, ptr %l161, !tbaa !29
  %t377 = load ptr, ptr %l162, !tbaa !29
  %t378 = load ptr, ptr %l163, !tbaa !29
  %t379 = load %"compiler/diagmsg:Msg", ptr %l172
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epromiseErr(ptr %v0, ptr %v1, ptr %v3, ptr %v0, ptr %t376, ptr %t377, ptr %t378, %"compiler/diagmsg:Msg" %t379)
  br label %bb60
bb60:
  %t380 = load [0 x i64], ptr %l6
  store [0 x i64] %t380, ptr %l173
  %t381 = mul i64 0, 8
  %t382 = insertvalue { i64, ptr } undef, i64 0, 0
  %t383 = insertvalue { i64, ptr } %t382, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t383, ptr %l174, !tbaa !27
  %t384 = getelementptr { i64, ptr }, ptr %l174, i32 0, i32 1
  %t385 = load ptr, ptr %t384, !tbaa !27
  %t386 = mul i64 0, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t385, ptr %l173, i64 %t386, i1 false)
  call void @__olang_scope_close(ptr %s0)
  %t387 = load { i64, ptr }, ptr %l174, !tbaa !27
  store { i64, ptr } %t387, ptr %rv
  br label %ret
bb61:
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t390 = getelementptr %"compiler/generic:Program", ptr %t388, i32 0, i32 2
  %t391 = load i32, ptr %l10, !tbaa !23
  %t394 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t390, i32 %t391)
  store i1 %t394, ptr %l178
  br label %bb62
bb62:
  %t395 = load i1, ptr %l178, !tbaa !21
  br i1 %t395, label %bb63, label %bb64
bb63:
  %t396 = load ptr, ptr %l0, !tbaa !29
  %t398 = getelementptr %"compiler/generic:Program", ptr %t396, i32 0, i32 2
  store ptr %t398, ptr %l181, !tbaa !29
  %t399 = load ptr, ptr %l0, !tbaa !29
  %t401 = getelementptr %"compiler/generic:Program", ptr %t399, i32 0, i32 2
  %t402 = load i32, ptr %l10, !tbaa !23
  %t405 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t401, i32 %t402)
  store i32 %t405, ptr %l185
  br label %bb65
bb64:
  store i1 false, ptr %l179, !tbaa !21
  br label %bb67
bb65:
  %t406 = load ptr, ptr %l181, !tbaa !29
  %t407 = load i32, ptr %l185, !tbaa !23
  %t408 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t406, i32 %t407)
  store i32 %t408, ptr %l186
  br label %bb66
bb66:
  %t409 = load i32, ptr %l186, !range !{i32 0, i32 6}
  %t411 = trunc i64 0 to i32
  %t412 = icmp eq i32 %t409, %t411
  store i1 %t412, ptr %l179, !tbaa !21
  br label %bb67
bb67:
  %t414 = load i1, ptr %l179, !tbaa !21
  br i1 %t414, label %bb68, label %bb69
bb68:
  %t415 = load ptr, ptr %l0, !tbaa !29
  %t417 = getelementptr %"compiler/generic:Program", ptr %t415, i32 0, i32 2
  store ptr %t417, ptr %l190, !tbaa !29
  %t418 = load ptr, ptr %l0, !tbaa !29
  %t420 = getelementptr %"compiler/generic:Program", ptr %t418, i32 0, i32 2
  %t421 = load i32, ptr %l10, !tbaa !23
  %t424 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t420, i32 %t421)
  store i32 %t424, ptr %l194
  br label %bb70
bb69:
  br label %bb98
bb70:
  %t425 = load ptr, ptr %l190, !tbaa !29
  %t426 = load i32, ptr %l194, !tbaa !23
  %t427 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t425, i32 %t426)
  store { i64, ptr } %t427, ptr %l195
  br label %bb71
bb71:
  %t428 = load { i64, ptr }, ptr %l195, !tbaa !27
  store { i64, ptr } %t428, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t429 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t431 = extractvalue { i64, ptr } %t429, 0
  store i64 %t431, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t433 = load i64, ptr %l14, !tbaa !24
  %t434 = load i64, ptr %l13, !tbaa !24
  %t437 = icmp sgt i64 %t433, %t434
  br i1 %t437, label %bb72, label %bb73
bb72:
  %t439 = load i64, ptr %l15, !tbaa !24
  %t441 = icmp sgt i64 %t439, 0
  br i1 %t441, label %bb74, label %bb75
bb73:
  store i64 0, ptr %l201, !tbaa !24
  br label %bb77
bb74:
  %t443 = load i64, ptr %l14, !tbaa !24
  %t444 = load i64, ptr %l13, !tbaa !24
  %t447 = sub i64 %t443, %t444
  %t448 = load i64, ptr %l15, !tbaa !24
  %t451 = add i64 %t447, %t448
  %t453 = sub i64 %t451, 1
  %t454 = load i64, ptr %l15, !tbaa !24
  %t457 = sdiv i64 %t453, %t454
  store i64 %t457, ptr %l204, !tbaa !24
  br label %bb76
bb75:
  store i64 0, ptr %l204, !tbaa !24
  br label %bb76
bb76:
  %t459 = load i64, ptr %l204, !tbaa !24
  store i64 %t459, ptr %l201, !tbaa !24
  br label %bb77
bb77:
  %t460 = load i64, ptr %l201, !tbaa !24
  store i64 %t460, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb78
bb78:
  %t461 = load i64, ptr %l17, !tbaa !24
  %t462 = load i64, ptr %l16, !tbaa !24
  %t465 = icmp slt i64 %t461, %t462
  %t467 = xor i1 %t465, true
  br i1 %t467, label %bb79, label %bb80
bb79:
  br label %bb97
bb80:
  br label %bb81
bb81:
  %t469 = load i64, ptr %l13, !tbaa !24
  %t470 = load i64, ptr %l17, !tbaa !24
  %t471 = load i64, ptr %l15, !tbaa !24
  %t474 = mul i64 %t470, %t471
  %t477 = add i64 %t469, %t474
  store i64 %t477, ptr %l18, !tbaa !24
  %t479 = load i64, ptr %l18, !tbaa !24
  %t481 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t482 = load ptr, ptr %t481, !tbaa !27
  %t483 = getelementptr i32, ptr %t482, i64 %t479
  %t484 = load i32, ptr %t483, !tbaa !33
  %t485 = load i32, ptr %l9, !tbaa !23
  %t488 = icmp eq i32 %t484, %t485
  br i1 %t488, label %bb82, label %bb83
bb82:
  %t490 = load i64, ptr %l18, !tbaa !24
  %t491 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t493 = extractvalue { i64, ptr } %t491, 0
  %t496 = icmp slt i64 %t490, %t493
  store i1 %t496, ptr %l226, !tbaa !21
  br label %bb84
bb83:
  store i1 false, ptr %l226, !tbaa !21
  br label %bb84
bb84:
  %t498 = load i1, ptr %l226, !tbaa !21
  br i1 %t498, label %bb85, label %bb86
bb85:
  %t499 = load ptr, ptr %l0, !tbaa !29
  %t500 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t500, ptr %l233, !tbaa !27
  %t501 = load i64, ptr %l18, !tbaa !24
  %t503 = getelementptr { i64, ptr }, ptr %l233, i32 0, i32 1
  %t504 = load ptr, ptr %t503, !tbaa !27
  %t505 = getelementptr i32, ptr %t504, i64 %t501
  %t506 = load i32, ptr %t505, !tbaa !33
  %t509 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emayHold(ptr %v0, ptr %t499, i32 %t506)
  store i1 %t509, ptr %l236
  br label %bb87
bb86:
  store i1 false, ptr %l231, !tbaa !21
  br label %bb88
bb87:
  %t510 = load i1, ptr %l236, !tbaa !21
  %t511 = xor i1 %t510, true
  store i1 %t511, ptr %l231, !tbaa !21
  br label %bb88
bb88:
  %t513 = load i1, ptr %l231, !tbaa !21
  br i1 %t513, label %bb89, label %bb90
bb89:
  store %olang.scope zeroinitializer, ptr %s14
  %t514 = load ptr, ptr %l0, !tbaa !29
  store ptr %t514, ptr %l238, !tbaa !29
  %t515 = load ptr, ptr %l1, !tbaa !29
  store ptr %t515, ptr %l239, !tbaa !29
  %t516 = load ptr, ptr %l4, !tbaa !29
  store ptr %t516, ptr %l240, !tbaa !29
  %t517 = load ptr, ptr %l0, !tbaa !29
  %t518 = load ptr, ptr %l4, !tbaa !29
  %t520 = getelementptr %"compiler/ast:Promise", ptr %t518, i32 0, i32 2
  %t521 = load { i64, ptr }, ptr %t520, !tbaa !27
  store { i64, ptr } %t521, ptr %l243, !tbaa !27
  %t522 = getelementptr { i64, ptr }, ptr %l243, i32 0, i32 1
  %t523 = load ptr, ptr %t522, !tbaa !27
  %t524 = getelementptr i32, ptr %t523, i64 1
  %t525 = load i32, ptr %t524, !tbaa !33
  %t528 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %s14, ptr %t517, i32 %t525)
  store { i64, ptr } %t528, ptr %l245
  br label %bb91
bb90:
  br label %bb95
bb91:
  %t529 = load ptr, ptr %l0, !tbaa !29
  %t530 = load i32, ptr %l9, !tbaa !23
  %t533 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %s14, ptr %t529, i32 %t530)
  store { i64, ptr } %t533, ptr %l248
  br label %bb92
bb92:
  %t534 = load { i64, ptr }, ptr %l245, !tbaa !27
  %t535 = extractvalue { i64, ptr } %t534, 1
  %t536 = extractvalue { i64, ptr } %t534, 0
  %t537 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t538 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t539 = add i64 %t536, %t538
  %t540 = load { i64, ptr }, ptr %l248, !tbaa !27
  %t541 = extractvalue { i64, ptr } %t540, 1
  %t542 = extractvalue { i64, ptr } %t540, 0
  %t543 = add i64 %t539, %t542
  %t544 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t543)
  call void @olang_textcopy(ptr %t544, ptr %t535, i64 %t536)
  %t545 = getelementptr i8, ptr %t544, i64 %t536
  call void @olang_textcopy(ptr %t545, ptr %t537, i64 %t538)
  %t546 = getelementptr i8, ptr %t545, i64 %t538
  call void @olang_textcopy(ptr %t546, ptr %t541, i64 %t542)
  %t547 = insertvalue { i64, ptr } undef, i64 %t543, 0
  %t548 = insertvalue { i64, ptr } %t547, ptr %t544, 1
  %t551 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseKeepsInValue(ptr %s14, ptr %v0, { i64, ptr } %t548)
  store %"compiler/diagmsg:Msg" %t551, ptr %l251
  br label %bb93
bb93:
  %t552 = load ptr, ptr %l238, !tbaa !29
  %t553 = load ptr, ptr %l239, !tbaa !29
  %t554 = load ptr, ptr %l240, !tbaa !29
  %t555 = load %"compiler/diagmsg:Msg", ptr %l251
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epromiseErr(ptr %v0, ptr %v1, ptr %v3, ptr %v0, ptr %t552, ptr %t553, ptr %t554, %"compiler/diagmsg:Msg" %t555)
  br label %bb94
bb94:
  %t556 = load [0 x i64], ptr %l6
  store [0 x i64] %t556, ptr %l252
  %t557 = mul i64 0, 8
  %t558 = insertvalue { i64, ptr } undef, i64 0, 0
  %t559 = insertvalue { i64, ptr } %t558, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t559, ptr %l253, !tbaa !27
  %t560 = getelementptr { i64, ptr }, ptr %l253, i32 0, i32 1
  %t561 = load ptr, ptr %t560, !tbaa !27
  %t562 = mul i64 0, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t561, ptr %l252, i64 %t562, i1 false)
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s0)
  %t563 = load { i64, ptr }, ptr %l253, !tbaa !27
  store { i64, ptr } %t563, ptr %rv
  br label %ret
bb95:
  br label %bb96
bb96:
  %t564 = load i64, ptr %l17, !tbaa !24
  %t567 = add i64 %t564, 1
  store i64 %t567, ptr %l17, !tbaa !24
  br label %bb78
bb97:
  br label %bb98
bb98:
  %t569 = load i64, ptr %l5, !tbaa !24
  %t570 = load i64, ptr %l8, !tbaa !24
  %t571 = load i32, ptr %l9, !tbaa !23
  %t573 = sext i32 %t571 to i64
  %t575 = insertvalue [3 x i64] undef, i64 %t569, 0
  %t577 = insertvalue [3 x i64] %t575, i64 %t570, 1
  %t579 = insertvalue [3 x i64] %t577, i64 %t573, 2
  store [3 x i64] %t579, ptr %l261
  %t580 = mul i64 3, 8
  %t581 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t580)
  %t582 = insertvalue { i64, ptr } undef, i64 3, 0
  %t583 = insertvalue { i64, ptr } %t582, ptr %t581, 1
  store { i64, ptr } %t583, ptr %l262, !tbaa !27
  %t584 = getelementptr { i64, ptr }, ptr %l262, i32 0, i32 1
  %t585 = load ptr, ptr %t584, !tbaa !27
  %t586 = mul i64 3, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t585, ptr %l261, i64 %t586, i1 false)
  call void @__olang_scope_close(ptr %s0)
  %t587 = load { i64, ptr }, ptr %l262, !tbaa !27
  store { i64, ptr } %t587, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2elenPath(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l15 = alloca i1
  %l22 = alloca { i64, ptr }
  %l24 = alloca ptr
  %l25 = alloca i1
  %l34 = alloca { i64, ptr }
  %l35 = alloca ptr
  %l36 = alloca i1
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l56 = alloca i1
  %l57 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l62 = alloca i64
  %l63 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l66 = alloca i64
  %l67 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sgt i64 %t1, 8
  br i1 %t3, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d43, i32 0, i32 1) }, ptr %l10, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t5, ptr %l11, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l12, !tbaa !24
  %t8 = load i64, ptr %l12, !tbaa !24
  %t9 = mul i64 %t8, 1
  %t10 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l13, !tbaa !27
  %t13 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = load i64, ptr %l12, !tbaa !24
  %t18 = mul i64 %t17, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t14, ptr %t16, i64 %t18, i1 false)
  %t19 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t19, ptr %l11, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t20, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t21 = load ptr, ptr %l1, !tbaa !29
  store ptr %t21, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t22 = load ptr, ptr %l14, !tbaa !29
  %t23 = icmp ne ptr %t22, null
  br i1 %t23, label %bb4, label %bb5
bb4:
  %t25 = load ptr, ptr %l14, !tbaa !29
  %t26 = load i64, ptr %t25, !range !{i64 0, i64 28}
  %t28 = icmp eq i64 %t26, 0
  store i1 %t28, ptr %l15, !tbaa !21
  br label %bb5
bb5:
  %t29 = load i1, ptr %l15, !tbaa !21
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t32 = getelementptr { i64, [4 x i64] }, ptr %t30, i32 0, i32 1
  %t33 = getelementptr { %"compiler/source:Span", i32 }, ptr %t32, i32 0, i32 1
  %t34 = load i32, ptr %t33
  store i32 %t34, ptr %l3, !tbaa !23
  br label %bb8
bb7:
  br label %bb10
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i32, ptr %l3, !tbaa !23
  %t40 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %s2, ptr %t36, i32 %t37)
  store { i64, ptr } %t40, ptr %l22
  br label %bb9
bb9:
  %t41 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t41, 1
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t44 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t43)
  call void @olang_textcopy(ptr %t44, ptr %t42, i64 %t43)
  %t45 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t44, 1
  call void @__olang_scope_close(ptr %s2)
  store { i64, ptr } %t46, ptr %rv
  br label %ret
bb10:
  %t48 = load ptr, ptr %l1, !tbaa !29
  store ptr %t48, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t49 = load ptr, ptr %l24, !tbaa !29
  %t50 = icmp ne ptr %t49, null
  br i1 %t50, label %bb11, label %bb12
bb11:
  %t52 = load ptr, ptr %l24, !tbaa !29
  %t53 = load i64, ptr %t52, !range !{i64 0, i64 28}
  %t55 = icmp eq i64 %t53, 2
  store i1 %t55, ptr %l25, !tbaa !21
  br label %bb12
bb12:
  %t56 = load i1, ptr %l25, !tbaa !21
  br i1 %t56, label %bb13, label %bb14
bb13:
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr { i64, [4 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", ptr }, ptr %t59, i32 0, i32 1
  %t61 = load ptr, ptr %t60
  store ptr %t61, ptr %l4, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load ptr, ptr %l4, !tbaa !29
  %t65 = load i64, ptr %l2, !tbaa !24
  %t67 = add i64 %t65, 1
  %t71 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2elenPath(ptr %v0, ptr %v1, ptr %v2, ptr %t63, ptr %t64, i64 %t67)
  store { i64, ptr } %t71, ptr %l34
  br label %bb16
bb16:
  %t72 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t72, ptr %rv
  br label %ret
bb17:
  %t73 = load ptr, ptr %l1, !tbaa !29
  store ptr %t73, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t74 = load ptr, ptr %l35, !tbaa !29
  %t75 = icmp ne ptr %t74, null
  br i1 %t75, label %bb18, label %bb19
bb18:
  %t77 = load ptr, ptr %l35, !tbaa !29
  %t78 = load i64, ptr %t77, !range !{i64 0, i64 28}
  %t80 = icmp eq i64 %t78, 13
  store i1 %t80, ptr %l36, !tbaa !21
  br label %bb19
bb19:
  %t81 = load i1, ptr %l36, !tbaa !21
  br i1 %t81, label %bb20, label %bb21
bb20:
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr { i64, [4 x i64] }, ptr %t82, i32 0, i32 1
  %t85 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t84, i32 0, i32 1
  %t86 = load ptr, ptr %t85
  store ptr %t86, ptr %l5, !tbaa !29
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t90 = getelementptr { i64, [4 x i64] }, ptr %t88, i32 0, i32 1
  %t91 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t90, i32 0, i32 2
  %t92 = load { i64, ptr }, ptr %t91
  store { i64, ptr } %t92, ptr %l6, !tbaa !27
  br label %bb22
bb21:
  br label %bb31
bb22:
  store %olang.scope zeroinitializer, ptr %s5
  %t94 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t94, 0
  %t98 = icmp ne i64 %t96, 1
  br i1 %t98, label %bb23, label %bb24
bb23:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d44, i32 0, i32 1) }, ptr %l46, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t100, ptr %l47, !tbaa !27
  %t101 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 0
  store i64 %t102, ptr %l48, !tbaa !24
  %t103 = load i64, ptr %l48, !tbaa !24
  %t104 = mul i64 %t103, 1
  %t105 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t104)
  %t106 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  store { i64, ptr } %t107, ptr %l49, !tbaa !27
  %t108 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = load i64, ptr %l48, !tbaa !24
  %t113 = mul i64 %t112, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t109, ptr %t111, i64 %t113, i1 false)
  %t114 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t114, ptr %l47, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  %t115 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t115, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load ptr, ptr %l5, !tbaa !29
  %t118 = load i64, ptr %l2, !tbaa !24
  %t120 = add i64 %t118, 1
  %t124 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2elenPath(ptr %v0, ptr %v1, ptr %s5, ptr %t116, ptr %t117, i64 %t120)
  store { i64, ptr } %t124, ptr %l54
  br label %bb26
bb26:
  %t125 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t125, ptr %l7, !tbaa !27
  %t126 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t128 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s5, ptr %s5, { i64, ptr } %t126, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d45, i32 0, i32 1) })
  store i1 %t128, ptr %l56
  br label %bb27
bb27:
  %t129 = load i1, ptr %l56, !tbaa !21
  br i1 %t129, label %bb28, label %bb29
bb28:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d46, i32 0, i32 1) }, ptr %l58, !tbaa !27
  %t130 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t130, ptr %l57, !tbaa !27
  br label %bb30
bb29:
  %t132 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t132, 1
  %t135 = extractvalue { i64, ptr } %t132, 0
  %t136 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t137 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  %t138 = add i64 %t135, %t137
  %t139 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t138)
  call void @olang_textcopy(ptr %t139, ptr %t134, i64 %t135)
  %t140 = getelementptr i8, ptr %t139, i64 %t135
  call void @olang_textcopy(ptr %t140, ptr %t136, i64 %t137)
  %t141 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t139, 1
  store { i64, ptr } %t142, ptr %l57, !tbaa !27
  br label %bb30
bb30:
  %t144 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t144, 0
  store i64 %t145, ptr %l62, !tbaa !24
  %t146 = load i64, ptr %l62, !tbaa !24
  %t147 = mul i64 %t146, 1
  %t148 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t147)
  %t149 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t150 = insertvalue { i64, ptr } %t149, ptr %t148, 1
  store { i64, ptr } %t150, ptr %l63, !tbaa !27
  %t151 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = load i64, ptr %l62, !tbaa !24
  %t156 = mul i64 %t155, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t152, ptr %t154, i64 %t156, i1 false)
  %t157 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t157, ptr %l57, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  %t158 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t158, ptr %rv
  br label %ret
bb31:
  br i1 true, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d48, i32 0, i32 1) }, ptr %l64, !tbaa !27
  %t159 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t159, ptr %l65, !tbaa !27
  %t160 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t161 = extractvalue { i64, ptr } %t160, 0
  store i64 %t161, ptr %l66, !tbaa !24
  %t162 = load i64, ptr %l66, !tbaa !24
  %t163 = mul i64 %t162, 1
  %t164 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t163)
  %t165 = insertvalue { i64, ptr } undef, i64 %t162, 0
  %t166 = insertvalue { i64, ptr } %t165, ptr %t164, 1
  store { i64, ptr } %t166, ptr %l67, !tbaa !27
  %t167 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t168 = load ptr, ptr %t167, !tbaa !27
  %t169 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !27
  %t171 = load i64, ptr %l66, !tbaa !24
  %t172 = mul i64 %t171, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t168, ptr %t170, i64 %t172, i1 false)
  %t173 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t173, ptr %l65, !tbaa !27
  %t174 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t174, ptr %rv
  br label %ret
bb35:
  call void @__olang_check_failed(ptr @olang_loc_cffe0474e3afc296_35ccea70755633e2)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eliteralOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l6 = alloca %"compiler/names:Ref"
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i1
  %l17 = alloca ptr
  %l21 = alloca i64
  %l23 = alloca %"compiler/names:Ref"
  %l27 = alloca i1
  %l31 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l38 = alloca %"compiler/source:Span"
  %l39 = alloca i32
  %l42 = alloca { i64, ptr }
  %l48 = alloca i32
  %l52 = alloca i32
  %l56 = alloca i32
  %rv = alloca i32
  %t80 = alloca i64
  %t97 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 28}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l4
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l5, !tbaa !23
  br label %bb5
bb4:
  br label %bb30
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  store ptr %t25, ptr %l17, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Context", ptr %t27, i32 0, i32 0
  %t30 = load i64, ptr %t29, !tbaa !24
  %t33 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2efile(ptr %v0, ptr %t26, i64 %t30)
  store i64 %t33, ptr %l21
  br label %bb6
bb6:
  %t34 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 0
  %t35 = load i32, ptr %t34, !tbaa !23
  %t36 = load ptr, ptr %l17, !tbaa !29
  %t37 = load i64, ptr %l21, !tbaa !24
  %t39 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t36, i64 %t37, i32 %t35)
  store %"compiler/names:Ref" %t39, ptr %l23
  br label %bb7
bb7:
  %t40 = load %"compiler/names:Ref", ptr %l23
  store %"compiler/names:Ref" %t40, ptr %l6
  %t41 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 0
  %t42 = load i32, ptr %t41, !range !{i32 0, i32 9}
  %t44 = trunc i64 4 to i32
  %t45 = icmp eq i32 %t42, %t44
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb8, label %bb9
bb8:
  %t49 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 0
  %t50 = load i32, ptr %t49, !range !{i32 0, i32 9}
  %t52 = trunc i64 7 to i32
  %t53 = icmp eq i32 %t50, %t52
  %t55 = xor i1 %t53, true
  store i1 %t55, ptr %l27, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb10
bb10:
  %t57 = load i1, ptr %l27, !tbaa !21
  br i1 %t57, label %bb11, label %bb12
bb11:
  %t58 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 0
  %t59 = load i32, ptr %t58, !range !{i32 0, i32 9}
  %t61 = trunc i64 8 to i32
  %t62 = icmp eq i32 %t59, %t61
  %t64 = xor i1 %t62, true
  store i1 %t64, ptr %l31, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb13
bb13:
  %t66 = load i1, ptr %l31, !tbaa !21
  br i1 %t66, label %bb14, label %bb15
bb14:
  %t67 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t67, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t69 = load ptr, ptr %l0, !tbaa !29
  store ptr %t69, ptr %l36, !tbaa !29
  %t70 = load ptr, ptr %l1, !tbaa !29
  store ptr %t70, ptr %l37, !tbaa !29
  %t71 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t71, ptr %l38
  %t72 = load i32, ptr %l5, !tbaa !23
  store i32 %t72, ptr %l39, !tbaa !23
  %t73 = icmp sge i64 1, 0
  br i1 %t73, label %bb17, label %bb18
bb17:
  %t75 = icmp sle i64 1, 2305843009213693951
  br i1 %t75, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_2edbc1bd270558db_85d99d8e9bee4edf)
  unreachable
bb19:
  %t77 = mul i64 1, 4
  %t78 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t77)
  %t79 = load i32, ptr %l39, !tbaa !23
  store i64 0, ptr %t80
  br label %fill.81
fill.81:
  %t84 = load i64, ptr %t80
  %t85 = icmp slt i64 %t84, 1
  br i1 %t85, label %fillb.82, label %filld.83
fillb.82:
  %t86 = getelementptr i32, ptr %t78, i64 %t84
  store i32 %t79, ptr %t86
  %t87 = add i64 %t84, 1
  store i64 %t87, ptr %t80
  br label %fill.81
filld.83:
  %t88 = insertvalue { i64, ptr } undef, i64 1, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t78, 1
  store { i64, ptr } %t89, ptr %l42, !tbaa !27
  %t90 = icmp sge i64 0, 0
  br i1 %t90, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_2edbc1bd270558db_85d99d8e9bee4edf)
  unreachable
bb21:
  %t92 = icmp sle i64 0, 1152921504606846975
  br i1 %t92, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_2edbc1bd270558db_85d99d8e9bee4edf)
  unreachable
bb23:
  %t94 = mul i64 0, 8
  %t95 = insertvalue { i64, ptr } undef, i64 0, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, [5 x i64] } zeroinitializer, ptr %t97
  %t98 = getelementptr { i64, [5 x i64] }, ptr %t97, i32 0, i32 0
  store i64 0, ptr %t98
  %t99 = load %"compiler/source:Span", ptr %l38
  %t100 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } undef, %"compiler/source:Span" %t99, 0
  %t101 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t102 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t100, { i64, ptr } %t101, 1
  %t104 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t102, { i64, ptr } %t96, 2
  %t105 = getelementptr { i64, [5 x i64] }, ptr %t97, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t104, ptr %t105
  %t106 = load { i64, [5 x i64] }, ptr %t97
  %t108 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t106, ptr %t108
  %t109 = load ptr, ptr %l36, !tbaa !29
  %t110 = load ptr, ptr %l37, !tbaa !29
  %t112 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v0, ptr %t109, ptr %t110, ptr %t108)
  store i32 %t112, ptr %l48
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_2edbc1bd270558db_85d99d8e9bee4edf)
  unreachable
bb25:
  %t113 = load i32, ptr %l48, !tbaa !23
  store i32 %t113, ptr %l7, !tbaa !23
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/generic:Program", ptr %t114, i32 0, i32 2
  %t117 = load i32, ptr %l7, !tbaa !23
  %t120 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t116, i32 %t117)
  store i32 %t120, ptr %l52
  br label %bb26
bb26:
  %t121 = load i32, ptr %l52, !range !{i32 0, i32 33}
  %t123 = trunc i64 19 to i32
  %t124 = icmp eq i32 %t121, %t123
  %t126 = xor i1 %t124, true
  br i1 %t126, label %bb27, label %bb28
bb27:
  %t128 = load i32, ptr %l7, !tbaa !23
  store i32 %t128, ptr %l56, !tbaa !23
  br label %bb29
bb28:
  %t130 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t130, ptr %l56, !tbaa !23
  br label %bb29
bb29:
  %t132 = load i32, ptr %l56, !tbaa !23
  store i32 %t132, ptr %rv
  br label %ret
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  %t133 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t133, ptr %rv
  br label %ret
bb34:
  call void @__olang_check_failed(ptr @olang_loc_7a3d6db3b893cc7d_3c2a4275e29a89)
  unreachable
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2enameType(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca %"compiler/names:Ref"
  %l5 = alloca ptr
  %l6 = alloca %"compiler/generic:Context"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l16 = alloca i32
  %l18 = alloca ptr
  %l22 = alloca i64
  %l24 = alloca %"compiler/names:Ref"
  %l28 = alloca i1
  %l35 = alloca ptr
  %l40 = alloca %"compiler/generic:Context"
  %l45 = alloca i1
  %l53 = alloca i32
  %l59 = alloca i1
  %l63 = alloca i1
  %l64 = alloca i32
  %l72 = alloca i64
  %l75 = alloca i64
  %l84 = alloca i64
  %l87 = alloca i1
  %l98 = alloca { i64, ptr }
  %l116 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l121 = alloca { i64, ptr }
  %l125 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  %t53 = alloca %"compiler/generic:Context", align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l18, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/generic:Context", ptr %a1, i32 0, i32 0
  %t9 = load i64, ptr %t8, !tbaa !24
  %t12 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2efile(ptr %v0, ptr %t5, i64 %t9)
  store i64 %t12, ptr %l22
  br label %bb1
bb1:
  %t13 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t14 = load i32, ptr %t13, !tbaa !23
  %t15 = load ptr, ptr %l18, !tbaa !29
  %t16 = load i64, ptr %l22, !tbaa !24
  %t18 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t15, i64 %t16, i32 %t14)
  store %"compiler/names:Ref" %t18, ptr %l24
  br label %bb2
bb2:
  %t19 = load %"compiler/names:Ref", ptr %l24
  store %"compiler/names:Ref" %t19, ptr %l4
  %t20 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 0
  %t21 = load i32, ptr %t20, !range !{i32 0, i32 9}
  %t23 = trunc i64 2 to i32
  %t24 = icmp eq i32 %t21, %t23
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb5
bb4:
  %t28 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 2
  %t29 = load i64, ptr %t28, !tbaa !24
  %t31 = icmp slt i64 %t29, 0
  store i1 %t31, ptr %l28, !tbaa !21
  br label %bb5
bb5:
  %t33 = load i1, ptr %l28, !tbaa !21
  br i1 %t33, label %bb6, label %bb7
bb6:
  %t34 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t34, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 1
  %t38 = load i64, ptr %t37, !tbaa !24
  %t39 = load i32, ptr %l3, !tbaa !23
  %t43 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eanyGlobal(ptr %v0, ptr %v0, ptr %t36, i64 %t38, i32 %t39)
  store ptr %t43, ptr %l35
  br label %bb9
bb9:
  %t44 = load ptr, ptr %l35, !tbaa !29
  store ptr %t44, ptr %l5, !tbaa !29
  %t45 = load ptr, ptr %l5, !tbaa !29
  %t47 = icmp eq ptr %t45, null
  br i1 %t47, label %bb10, label %bb11
bb10:
  %t49 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t49, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t51 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 1
  %t52 = load i64, ptr %t51, !tbaa !24
  call void @compiler_2fgeneric_3aContext_2ector(ptr %t53, ptr %s0, i64 %t52, i64 -1)
  call void @llvm.memmove.p0.p0.i64(ptr %l40, ptr %t53, i64 160, i1 false)
  br label %bb13
bb13:
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %l40, i64 160, i1 false)
  %t55 = load ptr, ptr %l5, !tbaa !29
  %t57 = getelementptr %"compiler/ast:VarDecl", ptr %t55, i32 0, i32 2
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t60 = icmp eq ptr %t58, null
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb14, label %bb15
bb14:
  %t64 = load ptr, ptr %l5, !tbaa !29
  %t66 = getelementptr %"compiler/ast:VarDecl", ptr %t64, i32 0, i32 4
  %t67 = load i1, ptr %t66, !tbaa !21
  %t69 = xor i1 %t67, true
  store i1 %t69, ptr %l45, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb16
bb16:
  %t71 = load i1, ptr %l45, !tbaa !21
  br i1 %t71, label %bb17, label %bb18
bb17:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load ptr, ptr %l5, !tbaa !29
  %t74 = load i32, ptr %l3, !tbaa !23
  %t79 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalStorage(ptr %v0, ptr %s0, ptr %v0, ptr %t72, ptr %l6, ptr %t73, i32 %t74)
  store i32 %t79, ptr %l53
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s0)
  %t80 = load i32, ptr %l53, !tbaa !23
  store i32 %t80, ptr %rv
  br label %ret
bb20:
  %t81 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 1
  %t82 = load i64, ptr %t81, !tbaa !24
  %t84 = shl i64 %t82, 32
  %t85 = load i32, ptr %l3, !tbaa !23
  %t87 = sext i32 %t85 to i64
  %t90 = or i64 %t84, %t87
  store i64 %t90, ptr %l7, !tbaa !24
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/generic:Program", ptr %t92, i32 0, i32 58
  %t95 = load i64, ptr %l7, !tbaa !24
  %t98 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %t94, i64 %t95)
  %t99 = extractvalue { i32, i1 } %t98, 1
  %t100 = extractvalue { i32, i1 } %t98, 0
  store i32 %t100, ptr %l64
  %t101 = icmp ne i32 %t100, 0
  br i1 %t101, label %bb22, label %ok.102, !prof !99
ok.102:
  store i1 %t99, ptr %l63
  br label %bb21
bb21:
  %t103 = load i1, ptr %l63, !tbaa !21
  store i1 %t103, ptr %l59, !tbaa !21
  br label %bb24
bb22:
  br label %bb23
bb23:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb24
bb24:
  %t104 = load i1, ptr %l59, !tbaa !21
  br i1 %t104, label %bb25, label %bb26
bb25:
  %t105 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t105, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  store i64 0, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  %t107 = load ptr, ptr %l5, !tbaa !29
  %t109 = getelementptr %"compiler/ast:VarDecl", ptr %t107, i32 0, i32 0
  %t110 = load { i64, ptr }, ptr %t109, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t110, 0
  store i64 %t112, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t114 = load i64, ptr %l10, !tbaa !24
  %t115 = load i64, ptr %l9, !tbaa !24
  %t118 = icmp sgt i64 %t114, %t115
  br i1 %t118, label %bb28, label %bb29
bb28:
  %t120 = load i64, ptr %l11, !tbaa !24
  %t122 = icmp sgt i64 %t120, 0
  br i1 %t122, label %bb30, label %bb31
bb29:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb33
bb30:
  %t124 = load i64, ptr %l10, !tbaa !24
  %t125 = load i64, ptr %l9, !tbaa !24
  %t128 = sub i64 %t124, %t125
  %t129 = load i64, ptr %l11, !tbaa !24
  %t132 = add i64 %t128, %t129
  %t134 = sub i64 %t132, 1
  %t135 = load i64, ptr %l11, !tbaa !24
  %t138 = sdiv i64 %t134, %t135
  store i64 %t138, ptr %l75, !tbaa !24
  br label %bb32
bb31:
  store i64 0, ptr %l75, !tbaa !24
  br label %bb32
bb32:
  %t140 = load i64, ptr %l75, !tbaa !24
  store i64 %t140, ptr %l72, !tbaa !24
  br label %bb33
bb33:
  %t141 = load i64, ptr %l72, !tbaa !24
  store i64 %t141, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  %t142 = load i64, ptr %l12, !tbaa !24
  %t143 = sub i64 %t142, 1
  store i64 %t143, ptr %l84, !tbaa !24
  %t144 = load i64, ptr %l12, !tbaa !24
  %t145 = icmp slt i64 %t144, 2147483648
  %t146 = load i64, ptr %l13, !tbaa !24
  %t147 = icmp sge i64 %t146, 0
  %t150 = and i1 %t145, %t147
  store i1 %t150, ptr %l87, !tbaa !21
  br label %bb34
bb34:
  %t151 = load i64, ptr %l13, !tbaa !24
  %t152 = load i64, ptr %l12, !tbaa !24
  %t155 = icmp slt i64 %t151, %t152
  %t157 = xor i1 %t155, true
  br i1 %t157, label %bb35, label %bb36
bb35:
  br label %bb42
bb36:
  br label %bb37
bb37:
  %t159 = load i64, ptr %l9, !tbaa !24
  %t160 = load i64, ptr %l13, !tbaa !24
  %t161 = load i64, ptr %l11, !tbaa !24
  %t164 = mul i64 %t160, %t161
  %t167 = add i64 %t159, %t164
  store i64 %t167, ptr %l14, !tbaa !24
  %t169 = load ptr, ptr %l5, !tbaa !29
  %t171 = getelementptr %"compiler/ast:VarDecl", ptr %t169, i32 0, i32 0
  %t172 = load { i64, ptr }, ptr %t171, !tbaa !27
  store { i64, ptr } %t172, ptr %l98, !tbaa !27
  %t173 = load i64, ptr %l14, !tbaa !24
  %t175 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !27
  %t177 = getelementptr i32, ptr %t176, i64 %t173
  %t178 = load i32, ptr %t177, !tbaa !33
  %t179 = load i32, ptr %l3, !tbaa !23
  %t182 = icmp eq i32 %t178, %t179
  br i1 %t182, label %bb38, label %bb39
bb38:
  %t184 = load i64, ptr %l14, !tbaa !24
  store i64 %t184, ptr %l8, !tbaa !24
  br label %bb40
bb39:
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t186 = load i64, ptr %l13, !tbaa !24
  %t189 = add i64 %t186, 1
  store i64 %t189, ptr %l13, !tbaa !24
  br label %bb34
bb42:
  %t191 = load i64, ptr %l8, !tbaa !24
  %t192 = load ptr, ptr %l5, !tbaa !29
  %t194 = getelementptr %"compiler/ast:VarDecl", ptr %t192, i32 0, i32 3
  %t195 = load { i64, ptr }, ptr %t194, !tbaa !27
  %t197 = extractvalue { i64, ptr } %t195, 0
  %t200 = icmp sge i64 %t191, %t197
  br i1 %t200, label %bb43, label %bb44
bb43:
  %t202 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t202, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = getelementptr %"compiler/generic:Program", ptr %t204, i32 0, i32 58
  %t207 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t206, i64 %t207, i1 true)
  br label %bb46
bb46:
  %t210 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_Hcd3bbe8e64537e19c3182f51d0fe16c9(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t210, ptr %l116
  br label %bb47
bb47:
  %t211 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l116
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t211, ptr %l15
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load ptr, ptr %l5, !tbaa !29
  %t215 = getelementptr %"compiler/ast:VarDecl", ptr %t213, i32 0, i32 3
  %t216 = load { i64, ptr }, ptr %t215, !tbaa !27
  store { i64, ptr } %t216, ptr %l121, !tbaa !27
  %t217 = load i64, ptr %l8, !tbaa !24
  %t219 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t220 = load ptr, ptr %t219, !tbaa !27
  %t221 = getelementptr ptr, ptr %t220, i64 %t217
  %t222 = load ptr, ptr %t221, !tbaa !39
  %t228 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInfer(ptr %v0, ptr %s0, ptr %s0, ptr %v0, ptr %t212, ptr %l6, ptr %l15, ptr %t222)
  store i32 %t228, ptr %l125
  br label %bb48
bb48:
  %t229 = load i32, ptr %l125, !tbaa !23
  store i32 %t229, ptr %l16, !tbaa !23
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t232 = getelementptr %"compiler/generic:Program", ptr %t230, i32 0, i32 58
  %t233 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t232, i64 %t233, i1 false)
  br label %bb49
bb49:
  %t236 = load i32, ptr %l16, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t236, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eownLiteral(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca i1
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i32
  %l30 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l34 = alloca i1
  %l51 = alloca i32
  %l56 = alloca ptr
  %l57 = alloca i1
  %l60 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca i1
  %l67 = alloca i1
  %l73 = alloca i1
  %l79 = alloca i1
  %l83 = alloca i1
  %l84 = alloca i1
  %l88 = alloca i1
  %l89 = alloca i1
  %l93 = alloca i32
  %l98 = alloca i32
  %l100 = alloca i1
  %l105 = alloca i1
  %l107 = alloca i1
  %l111 = alloca i1
  %l112 = alloca i1
  %l116 = alloca i1
  %l125 = alloca i32
  %l128 = alloca i1
  %l130 = alloca ptr
  %l134 = alloca i32
  %l135 = alloca i32
  %l138 = alloca ptr
  %l139 = alloca ptr
  %l140 = alloca ptr
  %l142 = alloca ptr
  %l146 = alloca i32
  %l147 = alloca i32
  %l149 = alloca i32
  %l151 = alloca ptr
  %l152 = alloca i32
  %l154 = alloca ptr
  %l157 = alloca i32
  %l160 = alloca i32
  %l161 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t7, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t9, ptr %l4, !tbaa !23
  store i1 true, ptr %l5, !tbaa !21
  %t11 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t11, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  store i64 %t15, ptr %l8, !tbaa !24
  br label %bb4
bb4:
  %t17 = load i64, ptr %l7, !tbaa !24
  %t18 = load i64, ptr %l8, !tbaa !24
  %t21 = icmp slt i64 %t17, %t18
  %t23 = xor i1 %t21, true
  br i1 %t23, label %bb5, label %bb6
bb5:
  br label %bb68
bb6:
  br label %bb7
bb7:
  %t25 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t25, ptr %l30, !tbaa !27
  %t26 = load i64, ptr %l7, !tbaa !24
  %t28 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr ptr, ptr %t29, i64 %t26
  %t31 = load ptr, ptr %t30, !tbaa !39
  store ptr %t31, ptr %l9, !tbaa !29
  %t33 = load ptr, ptr %l9, !tbaa !29
  store ptr %t33, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t34 = load ptr, ptr %l33, !tbaa !29
  %t35 = icmp ne ptr %t34, null
  br i1 %t35, label %bb8, label %bb9
bb8:
  %t37 = load ptr, ptr %l33, !tbaa !29
  %t38 = load i64, ptr %t37, !range !{i64 0, i64 28}
  %t40 = icmp eq i64 %t38, 5
  store i1 %t40, ptr %l34, !tbaa !21
  br label %bb9
bb9:
  %t41 = load i1, ptr %l34, !tbaa !21
  br i1 %t41, label %bb10, label %bb11
bb10:
  %t42 = load ptr, ptr %l9, !tbaa !29
  %t44 = getelementptr { i64, [4 x i64] }, ptr %t42, i32 0, i32 1
  %t45 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t44, i32 0, i32 0
  %t46 = load %"compiler/source:Span", ptr %t45
  store %"compiler/source:Span" %t46, ptr %l10
  %t48 = load ptr, ptr %l9, !tbaa !29
  %t50 = getelementptr { i64, [4 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t50, i32 0, i32 1
  %t52 = load i32, ptr %t51, !range !{i32 0, i32 116}
  store i32 %t52, ptr %l11
  %t54 = load ptr, ptr %l9, !tbaa !29
  %t56 = getelementptr { i64, [4 x i64] }, ptr %t54, i32 0, i32 1
  %t57 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t56, i32 0, i32 2
  %t58 = load ptr, ptr %t57
  store ptr %t58, ptr %l12, !tbaa !29
  %t60 = load ptr, ptr %l9, !tbaa !29
  %t62 = getelementptr { i64, [4 x i64] }, ptr %t60, i32 0, i32 1
  %t63 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t62, i32 0, i32 3
  %t64 = load ptr, ptr %t63
  store ptr %t64, ptr %l13, !tbaa !29
  %t66 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t66, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t70 = load ptr, ptr %l2, !tbaa !29
  %t71 = load ptr, ptr %l9, !tbaa !29
  %t77 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInfer(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t68, ptr %t69, ptr %t70, ptr %t71)
  store i32 %t77, ptr %l51
  br label %bb13
bb13:
  %t78 = load i32, ptr %l51, !tbaa !23
  store i32 %t78, ptr %l14, !tbaa !23
  %t79 = load i32, ptr %l14, !tbaa !23
  %t80 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t83 = icmp eq i32 %t79, %t80
  br i1 %t83, label %bb14, label %bb15
bb14:
  %t85 = load i32, ptr %l14, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t85, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t87 = load ptr, ptr %l9, !tbaa !29
  store ptr %t87, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t88 = load ptr, ptr %l56, !tbaa !29
  %t89 = icmp ne ptr %t88, null
  br i1 %t89, label %bb17, label %bb18
bb17:
  %t91 = load ptr, ptr %l56, !tbaa !29
  %t92 = load i64, ptr %t91, !range !{i64 0, i64 28}
  %t94 = icmp eq i64 %t92, 1
  store i1 %t94, ptr %l57, !tbaa !21
  br label %bb18
bb18:
  %t95 = load i1, ptr %l57, !tbaa !21
  br i1 %t95, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb23
bb20:
  %t96 = load ptr, ptr %l9, !tbaa !29
  store ptr %t96, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t97 = load ptr, ptr %l61, !tbaa !29
  %t98 = icmp ne ptr %t97, null
  br i1 %t98, label %bb21, label %bb22
bb21:
  %t100 = load ptr, ptr %l61, !tbaa !29
  %t101 = load i64, ptr %t100, !range !{i64 0, i64 28}
  %t103 = icmp eq i64 %t101, 3
  store i1 %t103, ptr %l62, !tbaa !21
  br label %bb22
bb22:
  %t104 = load i1, ptr %l62, !tbaa !21
  store i1 %t104, ptr %l60, !tbaa !21
  br label %bb23
bb23:
  %t105 = load i1, ptr %l60, !tbaa !21
  %t108 = xor i1 %t105, true
  br i1 %t108, label %bb24, label %bb25
bb24:
  %t110 = load i1, ptr %l5, !tbaa !21
  store i1 %t110, ptr %l67, !tbaa !21
  br label %bb26
bb25:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb26
bb26:
  %t112 = load i1, ptr %l67, !tbaa !21
  br i1 %t112, label %bb27, label %bb28
bb27:
  %t113 = load i32, ptr %l14, !tbaa !23
  store i32 %t113, ptr %l4, !tbaa !23
  store i1 false, ptr %l5, !tbaa !21
  br label %bb66
bb28:
  %t119 = load i1, ptr %l5, !tbaa !21
  br i1 %t119, label %bb29, label %bb30
bb29:
  %t121 = load i32, ptr %l4, !tbaa !23
  %t122 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t125 = icmp eq i32 %t121, %t122
  store i1 %t125, ptr %l73, !tbaa !21
  br label %bb31
bb30:
  store i1 false, ptr %l73, !tbaa !21
  br label %bb31
bb31:
  %t127 = load i1, ptr %l73, !tbaa !21
  br i1 %t127, label %bb32, label %bb33
bb32:
  %t128 = load i32, ptr %l14, !tbaa !23
  store i32 %t128, ptr %l4, !tbaa !23
  br label %bb65
bb33:
  %t130 = load i1, ptr %l5, !tbaa !21
  br i1 %t130, label %bb34, label %bb35
bb34:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/generic:Program", ptr %t132, i32 0, i32 2
  %t135 = load i32, ptr %l4, !tbaa !23
  %t138 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t134, i32 %t135)
  store i1 %t138, ptr %l83
  br label %bb36
bb35:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb37
bb36:
  %t139 = load i1, ptr %l83, !tbaa !21
  store i1 %t139, ptr %l79, !tbaa !21
  br label %bb37
bb37:
  %t140 = load i1, ptr %l79, !tbaa !21
  br i1 %t140, label %bb38, label %bb39
bb38:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/generic:Program", ptr %t141, i32 0, i32 2
  %t144 = load i32, ptr %l14, !tbaa !23
  %t147 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t143, i32 %t144)
  store i1 %t147, ptr %l88
  br label %bb40
bb39:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb41
bb40:
  %t148 = load i1, ptr %l88, !tbaa !21
  store i1 %t148, ptr %l84, !tbaa !21
  br label %bb41
bb41:
  %t149 = load i1, ptr %l84, !tbaa !21
  br i1 %t149, label %bb42, label %bb43
bb42:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load i32, ptr %l4, !tbaa !23
  %t152 = load i32, ptr %l14, !tbaa !23
  %t156 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %t150, i32 %t151, i32 %t152)
  store i32 %t156, ptr %l93
  br label %bb44
bb43:
  store i1 false, ptr %l89, !tbaa !21
  br label %bb45
bb44:
  %t157 = load i32, ptr %l93, !tbaa !23
  %t158 = icmp sge i32 %t157, 0
  store i1 %t158, ptr %l89, !tbaa !21
  br label %bb45
bb45:
  %t160 = load i1, ptr %l89, !tbaa !21
  br i1 %t160, label %bb46, label %bb47
bb46:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load i32, ptr %l4, !tbaa !23
  %t163 = load i32, ptr %l14, !tbaa !23
  %t167 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %t161, i32 %t162, i32 %t163)
  store i32 %t167, ptr %l98
  br label %bb48
bb47:
  %t168 = load i1, ptr %l5, !tbaa !21
  br i1 %t168, label %bb49, label %bb50
bb48:
  %t170 = load i32, ptr %l98, !tbaa !23
  store i32 %t170, ptr %l4, !tbaa !23
  br label %bb64
bb49:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = getelementptr %"compiler/generic:Program", ptr %t171, i32 0, i32 2
  %t174 = load i32, ptr %l4, !tbaa !23
  %t175 = load i32, ptr %l14, !tbaa !23
  %t179 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t173, i32 %t174, i32 %t175)
  store i1 %t179, ptr %l105
  br label %bb51
bb50:
  store i1 false, ptr %l100, !tbaa !21
  br label %bb52
bb51:
  %t180 = load i1, ptr %l105, !tbaa !21
  %t181 = xor i1 %t180, true
  store i1 %t181, ptr %l100, !tbaa !21
  br label %bb52
bb52:
  %t183 = load i1, ptr %l100, !tbaa !21
  br i1 %t183, label %bb53, label %bb54
bb53:
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/generic:Program", ptr %t184, i32 0, i32 2
  %t187 = load i32, ptr %l4, !tbaa !23
  %t190 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t186, i32 %t187)
  store i1 %t190, ptr %l111
  br label %bb55
bb54:
  store i1 false, ptr %l107, !tbaa !21
  br label %bb60
bb55:
  %t191 = load i1, ptr %l111, !tbaa !21
  br i1 %t191, label %bb56, label %bb57
bb56:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr %"compiler/generic:Program", ptr %t192, i32 0, i32 2
  %t195 = load i32, ptr %l14, !tbaa !23
  %t198 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t194, i32 %t195)
  store i1 %t198, ptr %l116
  br label %bb58
bb57:
  store i1 false, ptr %l112, !tbaa !21
  br label %bb59
bb58:
  %t199 = load i1, ptr %l116, !tbaa !21
  store i1 %t199, ptr %l112, !tbaa !21
  br label %bb59
bb59:
  %t200 = load i1, ptr %l112, !tbaa !21
  %t201 = xor i1 %t200, true
  store i1 %t201, ptr %l107, !tbaa !21
  br label %bb60
bb60:
  %t203 = load i1, ptr %l107, !tbaa !21
  br i1 %t203, label %bb61, label %bb62
bb61:
  %t204 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t204, ptr %rv
  br label %ret
bb62:
  br label %bb63
bb63:
  br label %bb64
bb64:
  br label %bb65
bb65:
  br label %bb66
bb66:
  br label %bb67
bb67:
  %t206 = load i64, ptr %l7, !tbaa !24
  %t209 = add i64 %t206, 1
  store i64 %t209, ptr %l7, !tbaa !24
  br label %bb4
bb68:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/generic:Program", ptr %t211, i32 0, i32 2
  %t214 = load i32, ptr %l4, !tbaa !23
  %t217 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t213, i32 %t214)
  store i32 %t217, ptr %l125
  br label %bb69
bb69:
  %t218 = load i32, ptr %l125, !range !{i32 0, i32 33}
  %t220 = trunc i64 19 to i32
  %t221 = icmp eq i32 %t218, %t220
  br i1 %t221, label %bb70, label %bb71
bb70:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t225 = getelementptr %"compiler/generic:Program", ptr %t223, i32 0, i32 2
  store ptr %t225, ptr %l130, !tbaa !29
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr %"compiler/generic:Program", ptr %t226, i32 0, i32 2
  %t229 = load i32, ptr %l4, !tbaa !23
  %t232 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t228, i32 %t229)
  store i32 %t232, ptr %l134
  br label %bb72
bb71:
  store i1 false, ptr %l128, !tbaa !21
  br label %bb74
bb72:
  %t233 = load ptr, ptr %l130, !tbaa !29
  %t234 = load i32, ptr %l134, !tbaa !23
  %t235 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t233, i32 %t234)
  store i32 %t235, ptr %l135
  br label %bb73
bb73:
  %t236 = load i32, ptr %l135, !range !{i32 0, i32 33}
  %t238 = trunc i64 26 to i32
  %t239 = icmp eq i32 %t236, %t238
  store i1 %t239, ptr %l128, !tbaa !21
  br label %bb74
bb74:
  %t241 = load i1, ptr %l128, !tbaa !21
  br i1 %t241, label %bb75, label %bb76
bb75:
  %t242 = load ptr, ptr %l0, !tbaa !29
  store ptr %t242, ptr %l138, !tbaa !29
  %t243 = load ptr, ptr %l1, !tbaa !29
  store ptr %t243, ptr %l139, !tbaa !29
  %t244 = load ptr, ptr %l2, !tbaa !29
  store ptr %t244, ptr %l140, !tbaa !29
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t247 = getelementptr %"compiler/generic:Program", ptr %t245, i32 0, i32 2
  store ptr %t247, ptr %l142, !tbaa !29
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t250 = getelementptr %"compiler/generic:Program", ptr %t248, i32 0, i32 2
  %t251 = load i32, ptr %l4, !tbaa !23
  %t254 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t250, i32 %t251)
  store i32 %t254, ptr %l146
  br label %bb77
bb76:
  br label %bb80
bb77:
  %t255 = load ptr, ptr %l142, !tbaa !29
  %t256 = load i32, ptr %l146, !tbaa !23
  %t257 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t255, i32 %t256, i32 0)
  store i32 %t257, ptr %l147
  br label %bb78
bb78:
  %t258 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t259 = load ptr, ptr %l138, !tbaa !29
  %t260 = load ptr, ptr %l139, !tbaa !29
  %t261 = load ptr, ptr %l140, !tbaa !29
  %t262 = load i32, ptr %l147, !tbaa !23
  %t264 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eitemsElem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t259, ptr %t260, ptr %t261, i32 %t262, { i64, ptr } %t258)
  store i32 %t264, ptr %l149
  br label %bb79
bb79:
  %t265 = load i32, ptr %l149, !tbaa !23
  store i32 %t265, ptr %l4, !tbaa !23
  br label %bb80
bb80:
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t268 = getelementptr %"compiler/generic:Program", ptr %t266, i32 0, i32 2
  store ptr %t268, ptr %l151, !tbaa !29
  %t269 = load i32, ptr %l4, !tbaa !23
  store i32 %t269, ptr %l152, !tbaa !23
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t272 = getelementptr %"compiler/generic:Program", ptr %t270, i32 0, i32 2
  store ptr %t272, ptr %l154, !tbaa !29
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"compiler/generic:Program", ptr %t273, i32 0, i32 2
  %t277 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t275, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d49, i32 0, i32 1) })
  store i32 %t277, ptr %l157
  br label %bb81
bb81:
  %t278 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t280 = extractvalue { i64, ptr } %t278, 0
  %t281 = load ptr, ptr %l154, !tbaa !29
  %t282 = load i32, ptr %l157, !tbaa !23
  %t284 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %t281, i32 %t282, i64 %t280)
  store i32 %t284, ptr %l160
  br label %bb82
bb82:
  %t285 = load ptr, ptr %l151, !tbaa !29
  %t286 = load i32, ptr %l152, !tbaa !23
  %t287 = load i32, ptr %l160, !tbaa !23
  %t288 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t285, i32 %t286, i32 %t287)
  store i32 %t288, ptr %l161
  br label %bb83
bb83:
  call void @__olang_scope_close(ptr %s0)
  %t289 = load i32, ptr %l161, !tbaa !23
  store i32 %t289, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2erecvKey(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"compiler/names:Ref"
  %l9 = alloca ptr
  %l10 = alloca %"compiler/names:Ref"
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l18 = alloca i1
  %l27 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca i1
  %l39 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca i1
  %l49 = alloca ptr
  %l52 = alloca i64
  %l54 = alloca %"compiler/names:Ref"
  %l58 = alloca { i64, ptr }
  %l60 = alloca ptr
  %l67 = alloca i64
  %l72 = alloca ptr
  %l75 = alloca i64
  %l76 = alloca i32
  %l78 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l84 = alloca %"compiler/names:Ref"
  %l86 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l96 = alloca i1
  %l99 = alloca i64
  %l100 = alloca ptr
  %l101 = alloca i64
  %l106 = alloca i32
  %l107 = alloca i64
  %l113 = alloca i32
  %l114 = alloca i64
  %l117 = alloca i1
  %l123 = alloca i32
  %l124 = alloca i64
  %l128 = alloca { i64, ptr }
  %l133 = alloca { i64, ptr }
  %l135 = alloca i1
  %l138 = alloca i1
  %l140 = alloca i64
  %l144 = alloca i32
  %l145 = alloca i64
  %s7 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 -1, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t7 = load ptr, ptr %l17, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l17, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 8}
  %t13 = icmp eq i64 %t11, 4
  store i1 %t13, ptr %l18, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l18, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t17, i32 0, i32 1
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l4, !tbaa !29
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i64, ptr %l1, !tbaa !24
  %t23 = load ptr, ptr %l4, !tbaa !29
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t29 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2erecvKey(ptr %v0, ptr %v1, ptr %v2, ptr %t21, i64 %t22, ptr %t23, { i64, ptr } %t24)
  store i64 %t29, ptr %l27
  br label %bb9
bb9:
  %t30 = load i64, ptr %l27, !tbaa !24
  store i64 %t30, ptr %rv
  br label %ret
bb10:
  %t31 = load ptr, ptr %l2, !tbaa !29
  store ptr %t31, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t32 = load ptr, ptr %l28, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb11, label %bb12
bb11:
  %t35 = load ptr, ptr %l28, !tbaa !29
  %t36 = load i64, ptr %t35, !range !{i64 0, i64 8}
  %t38 = icmp eq i64 %t36, 3
  store i1 %t38, ptr %l29, !tbaa !21
  br label %bb12
bb12:
  %t39 = load i1, ptr %l29, !tbaa !21
  br i1 %t39, label %bb13, label %bb14
bb13:
  %t40 = load ptr, ptr %l2, !tbaa !29
  %t42 = getelementptr { i64, [5 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t42, i32 0, i32 1
  %t44 = load ptr, ptr %t43
  store ptr %t44, ptr %l5, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load i64, ptr %l1, !tbaa !24
  %t48 = load ptr, ptr %l5, !tbaa !29
  %t50 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t55 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2erecvKey(ptr %v0, ptr %v1, ptr %v2, ptr %t46, i64 %t47, ptr %t48, { i64, ptr } %t50)
  store i64 %t55, ptr %l39
  br label %bb16
bb16:
  %t56 = load i64, ptr %l39, !tbaa !24
  store i64 %t56, ptr %rv
  br label %ret
bb17:
  %t57 = load ptr, ptr %l2, !tbaa !29
  store ptr %t57, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t58 = load ptr, ptr %l40, !tbaa !29
  %t59 = icmp ne ptr %t58, null
  br i1 %t59, label %bb18, label %bb19
bb18:
  %t61 = load ptr, ptr %l40, !tbaa !29
  %t62 = load i64, ptr %t61, !range !{i64 0, i64 8}
  %t64 = icmp eq i64 %t62, 0
  store i1 %t64, ptr %l41, !tbaa !21
  br label %bb19
bb19:
  %t65 = load i1, ptr %l41, !tbaa !21
  br i1 %t65, label %bb20, label %bb21
bb20:
  %t66 = load ptr, ptr %l2, !tbaa !29
  %t68 = getelementptr { i64, [5 x i64] }, ptr %t66, i32 0, i32 1
  %t69 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t68, i32 0, i32 0
  %t70 = load %"compiler/source:Span", ptr %t69
  store %"compiler/source:Span" %t70, ptr %l6
  %t72 = load ptr, ptr %l2, !tbaa !29
  %t74 = getelementptr { i64, [5 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t74, i32 0, i32 1
  %t76 = load { i64, ptr }, ptr %t75
  store { i64, ptr } %t76, ptr %l7, !tbaa !27
  br label %bb22
bb21:
  br label %bb77
bb22:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/generic:Program", ptr %t78, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !29
  store ptr %t81, ptr %l49, !tbaa !29
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i64, ptr %l1, !tbaa !24
  %t86 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2efile(ptr %v0, ptr %t82, i64 %t83)
  store i64 %t86, ptr %l52
  br label %bb23
bb23:
  %t87 = getelementptr %"compiler/source:Span", ptr %l6, i32 0, i32 0
  %t88 = load i32, ptr %t87, !tbaa !23
  %t89 = load ptr, ptr %l49, !tbaa !29
  %t90 = load i64, ptr %l52, !tbaa !24
  %t92 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t89, i64 %t90, i32 %t88)
  store %"compiler/names:Ref" %t92, ptr %l54
  br label %bb24
bb24:
  %t93 = load %"compiler/names:Ref", ptr %l54
  store %"compiler/names:Ref" %t93, ptr %l8
  %t94 = getelementptr %"compiler/names:Ref", ptr %l8, i32 0, i32 0
  %t95 = load i32, ptr %t94, !range !{i32 0, i32 9}
  %t97 = trunc i64 8 to i32
  %t98 = icmp eq i32 %t95, %t97
  br i1 %t98, label %bb25, label %bb26
bb25:
  %t100 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t101 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t101, ptr %l58, !tbaa !27
  %t102 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr i32, ptr %t103, i64 0
  %t105 = load i32, ptr %t104, !tbaa !33
  %t108 = call ptr @compiler_2fgeneric_2elisted(ptr %v2, ptr %v2, { i64, ptr } %t100, i32 %t105)
  store ptr %t108, ptr %l60
  br label %bb27
bb26:
  br label %bb32
bb27:
  %t109 = load ptr, ptr %l60, !tbaa !29
  store ptr %t109, ptr %l9, !tbaa !29
  %t110 = load ptr, ptr %l9, !tbaa !29
  %t112 = icmp eq ptr %t110, null
  br i1 %t112, label %bb28, label %bb29
bb28:
  store i64 -1, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load i64, ptr %l1, !tbaa !24
  %t117 = load ptr, ptr %l9, !tbaa !29
  %t121 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2econstraintKey(ptr %v0, ptr %v2, ptr %t115, i64 %t116, ptr %t117)
  store i64 %t121, ptr %l67
  br label %bb31
bb31:
  %t122 = load i64, ptr %l67, !tbaa !24
  store i64 %t122, ptr %rv
  br label %ret
bb32:
  %t123 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t123, 0
  %t127 = icmp eq i64 %t125, 2
  br i1 %t127, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s7
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/generic:Program", ptr %t129, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !29
  store ptr %t132, ptr %l72, !tbaa !29
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load i64, ptr %l1, !tbaa !24
  %t137 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2efile(ptr %v0, ptr %t133, i64 %t134)
  store i64 %t137, ptr %l75
  br label %bb35
bb34:
  br label %bb53
bb35:
  %t138 = getelementptr %"compiler/source:Span", ptr %l6, i32 0, i32 0
  %t139 = load i32, ptr %t138, !tbaa !23
  store i32 %t139, ptr %l76, !tbaa !23
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t141, ptr %l78, !tbaa !27
  %t142 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = getelementptr i32, ptr %t143, i64 0
  %t145 = load i32, ptr %t144, !tbaa !33
  %t148 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %s7, ptr %t140, i32 %t145)
  store { i64, ptr } %t148, ptr %l80
  br label %bb36
bb36:
  %t149 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t150 = extractvalue { i64, ptr } %t149, 0
  %t152 = trunc i64 %t150 to i32
  %t153 = load i32, ptr %l76, !tbaa !23
  %t155 = add i32 %t153, %t152
  %t156 = load ptr, ptr %l72, !tbaa !29
  %t157 = load i64, ptr %l75, !tbaa !24
  %t159 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %t156, i64 %t157, i32 %t155)
  store %"compiler/names:Ref" %t159, ptr %l84
  br label %bb37
bb37:
  %t160 = load %"compiler/names:Ref", ptr %l84
  store %"compiler/names:Ref" %t160, ptr %l10
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t162, ptr %l86, !tbaa !27
  %t163 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !27
  %t165 = getelementptr i32, ptr %t164, i64 0
  %t166 = load i32, ptr %t165, !tbaa !33
  %t169 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %s7, ptr %t161, i32 %t166)
  store { i64, ptr } %t169, ptr %l88
  br label %bb38
bb38:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t171, ptr %l90, !tbaa !27
  %t172 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !27
  %t174 = getelementptr i32, ptr %t173, i64 1
  %t175 = load i32, ptr %t174, !tbaa !33
  %t178 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %s7, ptr %t170, i32 %t175)
  store { i64, ptr } %t178, ptr %l92
  br label %bb39
bb39:
  %t179 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t179, 1
  %t181 = extractvalue { i64, ptr } %t179, 0
  %t182 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t183 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  %t184 = add i64 %t181, %t183
  %t185 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t186 = extractvalue { i64, ptr } %t185, 1
  %t187 = extractvalue { i64, ptr } %t185, 0
  %t188 = add i64 %t184, %t187
  %t189 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t188)
  call void @olang_textcopy(ptr %t189, ptr %t180, i64 %t181)
  %t190 = getelementptr i8, ptr %t189, i64 %t181
  call void @olang_textcopy(ptr %t190, ptr %t182, i64 %t183)
  %t191 = getelementptr i8, ptr %t190, i64 %t183
  call void @olang_textcopy(ptr %t191, ptr %t186, i64 %t187)
  %t192 = insertvalue { i64, ptr } undef, i64 %t188, 0
  %t193 = insertvalue { i64, ptr } %t192, ptr %t189, 1
  store { i64, ptr } %t193, ptr %l11, !tbaa !27
  %t195 = getelementptr %"compiler/names:Ref", ptr %l10, i32 0, i32 0
  %t196 = load i32, ptr %t195, !range !{i32 0, i32 9}
  %t198 = trunc i64 4 to i32
  %t199 = icmp eq i32 %t196, %t198
  br i1 %t199, label %bb40, label %bb41
bb40:
  %t201 = getelementptr %"compiler/names:Ref", ptr %l10, i32 0, i32 2
  %t202 = load i64, ptr %t201, !tbaa !24
  %t204 = icmp sge i64 %t202, 0
  store i1 %t204, ptr %l96, !tbaa !21
  br label %bb42
bb41:
  store i1 false, ptr %l96, !tbaa !21
  br label %bb42
bb42:
  %t206 = load i1, ptr %l96, !tbaa !21
  br i1 %t206, label %bb43, label %bb44
bb43:
  %t207 = load ptr, ptr %l0, !tbaa !29
  store ptr %t207, ptr %l100, !tbaa !29
  %t208 = getelementptr %"compiler/names:Ref", ptr %l10, i32 0, i32 1
  %t209 = load i64, ptr %t208, !tbaa !24
  store i64 %t209, ptr %l101, !tbaa !24
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t212 = getelementptr %"compiler/generic:Program", ptr %t210, i32 0, i32 0
  %t213 = load ptr, ptr %t212, !tbaa !29
  %t215 = getelementptr %"compiler/load:Loader", ptr %t213, i32 0, i32 3
  %t216 = load ptr, ptr %t215, !tbaa !29
  %t217 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t220 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s7, ptr %t216, { i64, ptr } %t217)
  store i32 %t220, ptr %l106
  br label %bb45
bb44:
  store i64 -1, ptr %l99, !tbaa !24
  br label %bb47
bb45:
  %t221 = load ptr, ptr %l100, !tbaa !29
  %t222 = load i64, ptr %l101, !tbaa !24
  %t223 = load i32, ptr %l106, !tbaa !23
  %t224 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %t221, i64 %t222, i32 %t223)
  store i64 %t224, ptr %l107
  br label %bb46
bb46:
  %t225 = load i64, ptr %l107, !tbaa !24
  store i64 %t225, ptr %l99, !tbaa !24
  br label %bb47
bb47:
  %t226 = load i64, ptr %l99, !tbaa !24
  store i64 %t226, ptr %l12, !tbaa !24
  %t227 = load i64, ptr %l12, !tbaa !24
  %t229 = icmp sge i64 %t227, 0
  br i1 %t229, label %bb48, label %bb49
bb48:
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t232 = getelementptr %"compiler/names:Ref", ptr %l10, i32 0, i32 1
  %t233 = load i64, ptr %t232, !tbaa !24
  %t234 = load i64, ptr %l12, !tbaa !24
  %t238 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t231, i64 %t233, i64 %t234)
  store i32 %t238, ptr %l113
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t239 = load i32, ptr %l113, !tbaa !23
  %t240 = call i64 @compiler_2fgeneric_2ekeyDecl(i32 %t239)
  store i64 %t240, ptr %l114
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s7)
  %t241 = load i64, ptr %l114, !tbaa !24
  store i64 %t241, ptr %rv
  br label %ret
bb52:
  call void @__olang_scope_close(ptr %s7)
  br label %bb53
bb53:
  %t242 = getelementptr %"compiler/names:Ref", ptr %l8, i32 0, i32 0
  %t243 = load i32, ptr %t242, !range !{i32 0, i32 9}
  %t245 = trunc i64 4 to i32
  %t246 = icmp eq i32 %t243, %t245
  br i1 %t246, label %bb54, label %bb55
bb54:
  %t248 = getelementptr %"compiler/names:Ref", ptr %l8, i32 0, i32 2
  %t249 = load i64, ptr %t248, !tbaa !24
  %t251 = icmp sge i64 %t249, 0
  store i1 %t251, ptr %l117, !tbaa !21
  br label %bb56
bb55:
  store i1 false, ptr %l117, !tbaa !21
  br label %bb56
bb56:
  %t253 = load i1, ptr %l117, !tbaa !21
  br i1 %t253, label %bb57, label %bb58
bb57:
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t255 = getelementptr %"compiler/names:Ref", ptr %l8, i32 0, i32 1
  %t256 = load i64, ptr %t255, !tbaa !24
  %t257 = getelementptr %"compiler/names:Ref", ptr %l8, i32 0, i32 2
  %t258 = load i64, ptr %t257, !tbaa !24
  %t262 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t254, i64 %t256, i64 %t258)
  store i32 %t262, ptr %l123
  br label %bb59
bb58:
  br label %bb61
bb59:
  %t263 = load i32, ptr %l123, !tbaa !23
  %t264 = call i64 @compiler_2fgeneric_2ekeyDecl(i32 %t263)
  store i64 %t264, ptr %l124
  br label %bb60
bb60:
  %t265 = load i64, ptr %l124, !tbaa !24
  store i64 %t265, ptr %rv
  br label %ret
bb61:
  %t266 = getelementptr %"compiler/names:Ref", ptr %l8, i32 0, i32 0
  %t267 = load i32, ptr %t266, !range !{i32 0, i32 9}
  %t269 = trunc i64 7 to i32
  %t270 = icmp eq i32 %t267, %t269
  br i1 %t270, label %bb62, label %bb63
bb62:
  store %olang.scope zeroinitializer, ptr %s11
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t273 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t273, ptr %l128, !tbaa !27
  %t274 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t276 = extractvalue { i64, ptr } %t274, 0
  %t278 = sub i64 %t276, 1
  %t280 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t281 = load ptr, ptr %t280, !tbaa !27
  %t282 = getelementptr i32, ptr %t281, i64 %t278
  %t283 = load i32, ptr %t282, !tbaa !33
  %t286 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t272, i32 %t283)
  store { i64, ptr } %t286, ptr %l133
  br label %bb64
bb63:
  br label %bb76
bb64:
  %t287 = load { i64, ptr }, ptr %l133, !tbaa !27
  store { i64, ptr } %t287, ptr %l13, !tbaa !27
  %t288 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t290 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s11, { i64, ptr } %t288, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d51, i32 0, i32 1) })
  store i1 %t290, ptr %l135
  br label %bb65
bb65:
  %t291 = load i1, ptr %l135, !tbaa !21
  br i1 %t291, label %bb66, label %bb67
bb66:
  %t292 = load i64, ptr @G_2ecompiler_2fgeneric_2eArrayKey, !tbaa !24
  call void @__olang_scope_close(ptr %s11)
  store i64 %t292, ptr %rv
  br label %ret
bb67:
  br label %bb68
bb68:
  %t294 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t296 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s11, { i64, ptr } %t294, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d52, i32 0, i32 1) })
  store i1 %t296, ptr %l138
  br label %bb69
bb69:
  %t297 = load i1, ptr %l138, !tbaa !21
  br i1 %t297, label %bb70, label %bb71
bb70:
  %t298 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t300 = call i64 @compiler_2fgeneric_2ekeyPrim(i32 %t298)
  store i64 %t300, ptr %l140
  br label %bb72
bb71:
  br label %bb73
bb72:
  call void @__olang_scope_close(ptr %s11)
  %t301 = load i64, ptr %l140, !tbaa !24
  store i64 %t301, ptr %rv
  br label %ret
bb73:
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t304 = getelementptr %"compiler/generic:Program", ptr %t302, i32 0, i32 2
  %t305 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t308 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v0, ptr %t304, { i64, ptr } %t305)
  store i32 %t308, ptr %l144
  br label %bb74
bb74:
  %t309 = load i32, ptr %l144, !tbaa !23
  %t310 = call i64 @compiler_2fgeneric_2ekeyPrim(i32 %t309)
  store i64 %t310, ptr %l145
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s11)
  %t311 = load i64, ptr %l145, !tbaa !24
  store i64 %t311, ptr %rv
  br label %ret
bb76:
  store i64 -1, ptr %rv
  br label %ret
bb77:
  br i1 true, label %bb78, label %bb79
bb78:
  br label %bb80
bb79:
  br label %bb81
bb80:
  store i64 -1, ptr %rv
  br label %ret
bb81:
  call void @__olang_check_failed(ptr @olang_loc_769954e80c04bef7_8801cb066681a71b)
  unreachable
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2esubstErrs(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca i32
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca { i64, ptr }
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l46 = alloca i32
  %l53 = alloca i32
  %l60 = alloca i32
  %l64 = alloca ptr
  %l68 = alloca i32
  %l69 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l92 = alloca i32
  %l95 = alloca i1
  %l99 = alloca i64
  %l102 = alloca i1
  %l106 = alloca i64
  %l110 = alloca { i64, ptr }
  %l114 = alloca i64
  %l119 = alloca i32
  %l123 = alloca ptr
  %l127 = alloca i32
  %l128 = alloca { i64, ptr }
  %l135 = alloca { i64, ptr }
  %l146 = alloca i32
  %l159 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l164 = alloca ptr
  %l166 = alloca { i64, ptr }
  %l167 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = icmp eq i32 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i32, ptr %l1, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t5, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 2
  %t10 = load i32, ptr %l3, !tbaa !23
  %t13 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t9, i32 %t10)
  store { i64, ptr } %t13, ptr %l28
  br label %bb4
bb4:
  %t14 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t14, ptr %l4, !tbaa !27
  %t15 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %l29
  br label %bb5
bb5:
  %t16 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l29
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %l5
  store i1 false, ptr %l6, !tbaa !21
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/generic:Program", ptr %t17, i32 0, i32 2
  %t20 = load i32, ptr %l1, !tbaa !23
  %t23 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t19, i32 %t20)
  store { i64, ptr } %t23, ptr %l33
  br label %bb6
bb6:
  %t24 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t24, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t25 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 0
  store i64 %t27, ptr %l9, !tbaa !24
  br label %bb7
bb7:
  %t29 = load i64, ptr %l8, !tbaa !24
  %t30 = load i64, ptr %l9, !tbaa !24
  %t33 = icmp slt i64 %t29, %t30
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb8, label %bb9
bb8:
  br label %bb69
bb9:
  br label %bb10
bb10:
  %t37 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t37, ptr %l40, !tbaa !27
  %t38 = load i64, ptr %l8, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr i32, ptr %t41, i64 %t38
  %t43 = load i32, ptr %t42, !tbaa !33
  store i32 %t43, ptr %l10, !tbaa !23
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/generic:Program", ptr %t45, i32 0, i32 2
  %t48 = load i32, ptr %l10, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t47, i32 %t48)
  store i32 %t51, ptr %l46
  br label %bb11
bb11:
  %t52 = load i32, ptr %l46, !range !{i32 0, i32 33}
  %t54 = trunc i64 27 to i32
  %t55 = icmp eq i32 %t52, %t54
  br i1 %t55, label %bb12, label %bb13
bb12:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load i32, ptr %l10, !tbaa !23
  %t59 = load i64, ptr %l2, !tbaa !24
  %t60 = load i32, ptr %l3, !tbaa !23
  %t65 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %t57, i32 %t58, i64 %t59, i32 %t60)
  store i32 %t65, ptr %l53
  br label %bb14
bb13:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 2
  %t69 = load i32, ptr %l10, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t68, i32 %t69)
  store i32 %t72, ptr %l92
  br label %bb35
bb14:
  %t73 = load i32, ptr %l53, !tbaa !23
  store i32 %t73, ptr %l11, !tbaa !23
  %t74 = load i32, ptr %l11, !tbaa !23
  %t75 = load i32, ptr %l10, !tbaa !23
  %t78 = icmp ne i32 %t74, %t75
  br i1 %t78, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb17
bb16:
  br label %bb17
bb17:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/generic:Program", ptr %t80, i32 0, i32 2
  %t83 = load i32, ptr %l11, !tbaa !23
  %t86 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t82, i32 %t83)
  store i32 %t86, ptr %l60
  br label %bb18
bb18:
  %t87 = load i32, ptr %l60, !range !{i32 0, i32 33}
  %t89 = trunc i64 30 to i32
  %t90 = icmp eq i32 %t87, %t89
  br i1 %t90, label %bb19, label %bb20
bb19:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/generic:Program", ptr %t92, i32 0, i32 2
  store ptr %t94, ptr %l64, !tbaa !29
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/generic:Program", ptr %t95, i32 0, i32 2
  %t98 = load i32, ptr %l11, !tbaa !23
  %t101 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %t97, i32 %t98)
  store i32 %t101, ptr %l68
  br label %bb21
bb20:
  %t102 = load i32, ptr %l11, !tbaa !23
  %t103 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t106 = icmp ne i32 %t102, %t103
  br i1 %t106, label %bb30, label %bb31
bb21:
  %t108 = load ptr, ptr %l64, !tbaa !29
  %t109 = load i32, ptr %l68, !tbaa !23
  %t110 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t108, i32 %t109)
  store { i64, ptr } %t110, ptr %l69
  br label %bb22
bb22:
  %t111 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t111, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t112 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t112, 0
  store i64 %t114, ptr %l14, !tbaa !24
  br label %bb23
bb23:
  %t116 = load i64, ptr %l13, !tbaa !24
  %t117 = load i64, ptr %l14, !tbaa !24
  %t120 = icmp slt i64 %t116, %t117
  %t122 = xor i1 %t120, true
  br i1 %t122, label %bb24, label %bb25
bb24:
  br label %bb29
bb25:
  br label %bb26
bb26:
  %t124 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t124, ptr %l76, !tbaa !27
  %t125 = load i64, ptr %l13, !tbaa !24
  %t127 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !27
  %t129 = getelementptr i32, ptr %t128, i64 %t125
  %t130 = load i32, ptr %t129, !tbaa !33
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l5, i32 %t130)
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t135 = load i64, ptr %l13, !tbaa !24
  %t138 = add i64 %t135, 1
  store i64 %t138, ptr %l13, !tbaa !24
  br label %bb23
bb29:
  br label %bb34
bb30:
  %t140 = load i32, ptr %l11, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l5, i32 %t140)
  br label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb33
bb33:
  br label %bb34
bb34:
  br label %bb67
bb35:
  %t143 = load i32, ptr %l92, !range !{i32 0, i32 33}
  %t145 = trunc i64 25 to i32
  %t146 = icmp eq i32 %t143, %t145
  br i1 %t146, label %bb36, label %bb37
bb36:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/generic:Program", ptr %t148, i32 0, i32 2
  %t151 = load i32, ptr %l10, !tbaa !23
  %t154 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t150, i32 %t151)
  store i64 %t154, ptr %l99
  br label %bb38
bb37:
  store i1 false, ptr %l95, !tbaa !21
  br label %bb39
bb38:
  %t155 = load i64, ptr %l2, !tbaa !24
  %t156 = load i64, ptr %l99, !tbaa !24
  %t158 = icmp eq i64 %t156, %t155
  store i1 %t158, ptr %l95, !tbaa !21
  br label %bb39
bb39:
  %t160 = load i1, ptr %l95, !tbaa !21
  br i1 %t160, label %bb40, label %bb41
bb40:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/generic:Program", ptr %t161, i32 0, i32 2
  %t164 = load i32, ptr %l10, !tbaa !23
  %t167 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t163, i32 %t164)
  store i64 %t167, ptr %l106
  br label %bb42
bb41:
  store i1 false, ptr %l102, !tbaa !21
  br label %bb43
bb42:
  %t168 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t170 = extractvalue { i64, ptr } %t168, 0
  %t171 = load i64, ptr %l106, !tbaa !24
  %t173 = icmp slt i64 %t171, %t170
  store i1 %t173, ptr %l102, !tbaa !21
  br label %bb43
bb43:
  %t175 = load i1, ptr %l102, !tbaa !21
  br i1 %t175, label %bb44, label %bb45
bb44:
  %t176 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t176, ptr %l110, !tbaa !27
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/generic:Program", ptr %t177, i32 0, i32 2
  %t180 = load i32, ptr %l10, !tbaa !23
  %t183 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t179, i32 %t180)
  store i64 %t183, ptr %l114
  br label %bb46
bb45:
  %t184 = load i32, ptr %l10, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l5, i32 %t184)
  br label %bb65
bb46:
  %t187 = load i64, ptr %l114, !tbaa !24
  %t188 = getelementptr { i64, ptr }, ptr %l110, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = getelementptr i32, ptr %t189, i64 %t187
  %t191 = load i32, ptr %t190, !tbaa !33
  store i32 %t191, ptr %l16, !tbaa !23
  store i1 true, ptr %l6, !tbaa !21
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/generic:Program", ptr %t193, i32 0, i32 2
  %t196 = load i32, ptr %l16, !tbaa !23
  %t199 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t195, i32 %t196)
  store i32 %t199, ptr %l119
  br label %bb47
bb47:
  %t200 = load i32, ptr %l119, !range !{i32 0, i32 33}
  %t202 = trunc i64 30 to i32
  %t203 = icmp eq i32 %t200, %t202
  br i1 %t203, label %bb48, label %bb49
bb48:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/generic:Program", ptr %t205, i32 0, i32 2
  store ptr %t207, ptr %l123, !tbaa !29
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/generic:Program", ptr %t208, i32 0, i32 2
  %t211 = load i32, ptr %l16, !tbaa !23
  %t214 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %t210, i32 %t211)
  store i32 %t214, ptr %l127
  br label %bb50
bb49:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t217 = getelementptr %"compiler/generic:Program", ptr %t215, i32 0, i32 2
  %t218 = load i32, ptr %l16, !tbaa !23
  %t221 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t217, i32 %t218)
  store i32 %t221, ptr %l146
  br label %bb59
bb50:
  %t222 = load ptr, ptr %l123, !tbaa !29
  %t223 = load i32, ptr %l127, !tbaa !23
  %t224 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t222, i32 %t223)
  store { i64, ptr } %t224, ptr %l128
  br label %bb51
bb51:
  %t225 = load { i64, ptr }, ptr %l128, !tbaa !27
  store { i64, ptr } %t225, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t226 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t228 = extractvalue { i64, ptr } %t226, 0
  store i64 %t228, ptr %l19, !tbaa !24
  br label %bb52
bb52:
  %t230 = load i64, ptr %l18, !tbaa !24
  %t231 = load i64, ptr %l19, !tbaa !24
  %t234 = icmp slt i64 %t230, %t231
  %t236 = xor i1 %t234, true
  br i1 %t236, label %bb53, label %bb54
bb53:
  br label %bb58
bb54:
  br label %bb55
bb55:
  %t238 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t238, ptr %l135, !tbaa !27
  %t239 = load i64, ptr %l18, !tbaa !24
  %t241 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t242 = load ptr, ptr %t241, !tbaa !27
  %t243 = getelementptr i32, ptr %t242, i64 %t239
  %t244 = load i32, ptr %t243, !tbaa !33
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l5, i32 %t244)
  br label %bb56
bb56:
  br label %bb57
bb57:
  %t249 = load i64, ptr %l18, !tbaa !24
  %t252 = add i64 %t249, 1
  store i64 %t252, ptr %l18, !tbaa !24
  br label %bb52
bb58:
  br label %bb64
bb59:
  %t254 = load i32, ptr %l146, !range !{i32 0, i32 33}
  %t256 = trunc i64 25 to i32
  %t257 = icmp eq i32 %t254, %t256
  br i1 %t257, label %bb60, label %bb61
bb60:
  %t259 = load i32, ptr %l16, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l5, i32 %t259)
  br label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb63
bb63:
  br label %bb64
bb64:
  br label %bb66
bb65:
  br label %bb66
bb66:
  br label %bb67
bb67:
  br label %bb68
bb68:
  %t262 = load i64, ptr %l8, !tbaa !24
  %t265 = add i64 %t262, 1
  store i64 %t265, ptr %l8, !tbaa !24
  br label %bb7
bb69:
  %t267 = load i1, ptr %l6, !tbaa !21
  %t269 = xor i1 %t267, true
  br i1 %t269, label %bb70, label %bb71
bb70:
  %t271 = load i32, ptr %l1, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t271, ptr %rv
  br label %ret
bb71:
  br label %bb72
bb72:
  %t273 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t273, ptr %l159
  br label %bb73
bb73:
  %t274 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l159
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t274, ptr %l21
  %t275 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emergeEntries(ptr %v0, ptr %s0, ptr %s0, ptr %t275, ptr %l5, ptr %l21)
  br label %bb74
bb74:
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t281 = getelementptr %"compiler/generic:Program", ptr %t279, i32 0, i32 2
  store ptr %t281, ptr %l164, !tbaa !29
  %t283 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %s0, ptr %l21)
  store { i64, ptr } %t283, ptr %l166
  br label %bb75
bb75:
  %t284 = load ptr, ptr %l164, !tbaa !29
  %t285 = load { i64, ptr }, ptr %l166, !tbaa !27
  %t286 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t284, { i64, ptr } %t285)
  store i32 %t286, ptr %l167
  br label %bb76
bb76:
  call void @__olang_scope_close(ptr %s0)
  %t287 = load i32, ptr %l167, !tbaa !23
  store i32 %t287, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2esuppliedMeets(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i32
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i32
  %l24 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca { i64, ptr }
  %l32 = alloca i1
  %l36 = alloca i32
  %l40 = alloca i1
  %l44 = alloca i32
  %l47 = alloca i32
  %l51 = alloca i32
  %l56 = alloca i64
  %l59 = alloca i64
  %l80 = alloca i1
  %l84 = alloca i64
  %l88 = alloca i32
  %l90 = alloca ptr
  %l93 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l97 = alloca i32
  %l101 = alloca i1
  %l107 = alloca i32
  %l115 = alloca i32
  %l120 = alloca i1
  %l123 = alloca i1
  %l125 = alloca i1
  %l129 = alloca i32
  %l132 = alloca i32
  %l136 = alloca i32
  %l141 = alloca i64
  %l144 = alloca i64
  %l165 = alloca i32
  %l171 = alloca i1
  %l177 = alloca i32
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t3, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d53, i32 0, i32 1) })
  store i32 %t5, ptr %l22
  br label %bb1
bb1:
  %t6 = load i32, ptr %l22, !tbaa !23
  store i32 %t6, ptr %l4, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 2
  store ptr %t9, ptr %l24, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l28
  br label %bb2
bb2:
  %t17 = load ptr, ptr %l24, !tbaa !29
  %t18 = load i32, ptr %l28, !tbaa !23
  %t19 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t17, i32 %t18)
  store { i64, ptr } %t19, ptr %l29
  br label %bb3
bb3:
  %t20 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 0
  %t23 = icmp ne i64 %t21, 0
  br i1 %t23, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb7
bb5:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  %t28 = load i32, ptr %l3, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l36
  br label %bb6
bb6:
  %t32 = load i32, ptr %l36, !tbaa !23
  %t33 = icmp ne i32 %t32, 0
  store i1 %t33, ptr %l32, !tbaa !21
  br label %bb7
bb7:
  %t35 = load i1, ptr %l32, !tbaa !21
  br i1 %t35, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t37 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t39 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t37, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d54, i32 0, i32 1) })
  store i1 %t39, ptr %l40
  br label %bb11
bb11:
  %t40 = load i1, ptr %l40, !tbaa !21
  br i1 %t40, label %bb12, label %bb13
bb12:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/generic:Program", ptr %t41, i32 0, i32 2
  %t44 = load i32, ptr %l1, !tbaa !23
  %t47 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t43, i32 %t44)
  store i32 %t47, ptr %l44
  br label %bb14
bb13:
  br label %bb49
bb14:
  %t48 = load i32, ptr %l44, !range !{i32 0, i32 33}
  %t50 = trunc i64 20 to i32
  %t51 = icmp eq i32 %t48, %t50
  br i1 %t51, label %bb15, label %bb16
bb15:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 2
  %t56 = load i32, ptr %l1, !tbaa !23
  %t59 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t55, i32 %t56)
  store i32 %t59, ptr %l51
  br label %bb17
bb16:
  %t60 = load i32, ptr %l1, !tbaa !23
  store i32 %t60, ptr %l47, !tbaa !23
  br label %bb18
bb17:
  %t62 = load i32, ptr %l51, !tbaa !23
  store i32 %t62, ptr %l47, !tbaa !23
  br label %bb18
bb18:
  %t63 = load i32, ptr %l47, !tbaa !23
  store i32 %t63, ptr %l5, !tbaa !23
  store i64 0, ptr %l6, !tbaa !24
  store i64 16, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t64 = load i64, ptr %l7, !tbaa !24
  %t65 = load i64, ptr %l6, !tbaa !24
  %t68 = icmp sgt i64 %t64, %t65
  br i1 %t68, label %bb19, label %bb20
bb19:
  %t70 = load i64, ptr %l8, !tbaa !24
  %t72 = icmp sgt i64 %t70, 0
  br i1 %t72, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb24
bb21:
  %t74 = load i64, ptr %l7, !tbaa !24
  %t75 = load i64, ptr %l6, !tbaa !24
  %t78 = sub i64 %t74, %t75
  %t79 = load i64, ptr %l8, !tbaa !24
  %t82 = add i64 %t78, %t79
  %t84 = sub i64 %t82, 1
  %t85 = load i64, ptr %l8, !tbaa !24
  %t88 = sdiv i64 %t84, %t85
  store i64 %t88, ptr %l59, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb23
bb23:
  %t90 = load i64, ptr %l59, !tbaa !24
  store i64 %t90, ptr %l56, !tbaa !24
  br label %bb24
bb24:
  %t91 = load i64, ptr %l56, !tbaa !24
  store i64 %t91, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb25
bb25:
  %t92 = load i64, ptr %l10, !tbaa !24
  %t93 = load i64, ptr %l9, !tbaa !24
  %t96 = icmp slt i64 %t92, %t93
  %t98 = xor i1 %t96, true
  br i1 %t98, label %bb26, label %bb27
bb26:
  br label %bb48
bb27:
  br label %bb28
bb28:
  %t100 = load i64, ptr %l6, !tbaa !24
  %t101 = load i64, ptr %l10, !tbaa !24
  %t102 = load i64, ptr %l8, !tbaa !24
  %t105 = mul i64 %t101, %t102
  %t108 = add i64 %t100, %t105
  store i64 %t108, ptr %l11, !tbaa !24
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/generic:Program", ptr %t110, i32 0, i32 2
  %t113 = load i32, ptr %l5, !tbaa !23
  %t116 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t112, i32 %t113)
  store i1 %t116, ptr %l80
  br label %bb29
bb29:
  %t117 = load i1, ptr %l80, !tbaa !21
  br i1 %t117, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s5
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/generic:Program", ptr %t118, i32 0, i32 2
  %t121 = load i32, ptr %l5, !tbaa !23
  %t124 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t120, i32 %t121)
  store i64 %t124, ptr %l84
  br label %bb32
bb31:
  br label %bb41
bb32:
  %t125 = load i64, ptr %l84, !tbaa !24
  store i64 %t125, ptr %l12, !tbaa !24
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/generic:Program", ptr %t126, i32 0, i32 2
  %t129 = load i32, ptr %l3, !tbaa !23
  %t132 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t128, i32 %t129)
  store i32 %t132, ptr %l88
  br label %bb33
bb33:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/generic:Program", ptr %t133, i32 0, i32 2
  store ptr %t135, ptr %l90, !tbaa !29
  %t136 = load i64, ptr %l12, !tbaa !24
  %t138 = icmp eq i64 %t136, 64
  br i1 %t138, label %bb34, label %bb35
bb34:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d55, i32 0, i32 1) }, ptr %l93, !tbaa !27
  br label %bb39
bb35:
  %t140 = load i64, ptr %l12, !tbaa !24
  %t142 = icmp eq i64 %t140, 32
  br i1 %t142, label %bb36, label %bb37
bb36:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d56, i32 0, i32 1) }, ptr %l96, !tbaa !27
  br label %bb38
bb37:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d57, i32 0, i32 1) }, ptr %l96, !tbaa !27
  br label %bb38
bb38:
  %t144 = load { i64, ptr }, ptr %l96, !tbaa !27
  store { i64, ptr } %t144, ptr %l93, !tbaa !27
  br label %bb39
bb39:
  %t145 = load ptr, ptr %l90, !tbaa !29
  %t146 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t147 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s5, ptr %t145, { i64, ptr } %t146)
  store i32 %t147, ptr %l97
  br label %bb40
bb40:
  %t148 = load i32, ptr %l88, !tbaa !23
  %t149 = load i32, ptr %l97, !tbaa !23
  %t150 = icmp eq i32 %t148, %t149
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store i1 %t150, ptr %rv
  br label %ret
bb41:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load i32, ptr %l5, !tbaa !23
  %t156 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t152, i32 %t153)
  store i1 %t156, ptr %l101
  br label %bb42
bb42:
  %t157 = load i1, ptr %l101, !tbaa !21
  %t158 = xor i1 %t157, true
  br i1 %t158, label %bb43, label %bb44
bb43:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/generic:Program", ptr %t161, i32 0, i32 2
  %t164 = load i32, ptr %l5, !tbaa !23
  %t167 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t163, i32 %t164)
  store i32 %t167, ptr %l107
  br label %bb46
bb46:
  %t168 = load i32, ptr %l107, !tbaa !23
  store i32 %t168, ptr %l5, !tbaa !23
  br label %bb47
bb47:
  %t169 = load i64, ptr %l10, !tbaa !24
  %t172 = add i64 %t169, 1
  store i64 %t172, ptr %l10, !tbaa !24
  br label %bb25
bb48:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb49:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/generic:Program", ptr %t175, i32 0, i32 2
  %t178 = load i32, ptr %l3, !tbaa !23
  %t181 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t177, i32 %t178)
  store i32 %t181, ptr %l115
  br label %bb50
bb50:
  %t182 = load i32, ptr %l4, !tbaa !23
  %t183 = load i32, ptr %l115, !tbaa !23
  %t185 = icmp ne i32 %t183, %t182
  br i1 %t185, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb52:
  br label %bb53
bb53:
  %t188 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t190 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t188, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d58, i32 0, i32 1) })
  store i1 %t190, ptr %l120
  br label %bb54
bb54:
  %t191 = load i1, ptr %l120, !tbaa !21
  br i1 %t191, label %bb55, label %bb56
bb55:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t193 = load i32, ptr %l1, !tbaa !23
  %t196 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eHasHash(ptr %v0, ptr %t192, i32 %t193)
  store i1 %t196, ptr %l123
  br label %bb57
bb56:
  br label %bb58
bb57:
  call void @__olang_scope_close(ptr %s0)
  %t197 = load i1, ptr %l123, !tbaa !21
  store i1 %t197, ptr %rv
  br label %ret
bb58:
  %t198 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t200 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t198, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d59, i32 0, i32 1) })
  store i1 %t200, ptr %l125
  br label %bb59
bb59:
  %t201 = load i1, ptr %l125, !tbaa !21
  br i1 %t201, label %bb60, label %bb61
bb60:
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = getelementptr %"compiler/generic:Program", ptr %t202, i32 0, i32 2
  %t205 = load i32, ptr %l1, !tbaa !23
  %t208 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t204, i32 %t205)
  store i32 %t208, ptr %l129
  br label %bb62
bb61:
  br label %bb88
bb62:
  %t209 = load i32, ptr %l129, !range !{i32 0, i32 33}
  %t211 = trunc i64 20 to i32
  %t212 = icmp eq i32 %t209, %t211
  br i1 %t212, label %bb63, label %bb64
bb63:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/generic:Program", ptr %t214, i32 0, i32 2
  %t217 = load i32, ptr %l1, !tbaa !23
  %t220 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t216, i32 %t217)
  store i32 %t220, ptr %l136
  br label %bb65
bb64:
  %t221 = load i32, ptr %l1, !tbaa !23
  store i32 %t221, ptr %l132, !tbaa !23
  br label %bb66
bb65:
  %t223 = load i32, ptr %l136, !tbaa !23
  store i32 %t223, ptr %l132, !tbaa !23
  br label %bb66
bb66:
  %t224 = load i32, ptr %l132, !tbaa !23
  store i32 %t224, ptr %l13, !tbaa !23
  store i64 0, ptr %l14, !tbaa !24
  store i64 16, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t225 = load i64, ptr %l15, !tbaa !24
  %t226 = load i64, ptr %l14, !tbaa !24
  %t229 = icmp sgt i64 %t225, %t226
  br i1 %t229, label %bb67, label %bb68
bb67:
  %t231 = load i64, ptr %l16, !tbaa !24
  %t233 = icmp sgt i64 %t231, 0
  br i1 %t233, label %bb69, label %bb70
bb68:
  store i64 0, ptr %l141, !tbaa !24
  br label %bb72
bb69:
  %t235 = load i64, ptr %l15, !tbaa !24
  %t236 = load i64, ptr %l14, !tbaa !24
  %t239 = sub i64 %t235, %t236
  %t240 = load i64, ptr %l16, !tbaa !24
  %t243 = add i64 %t239, %t240
  %t245 = sub i64 %t243, 1
  %t246 = load i64, ptr %l16, !tbaa !24
  %t249 = sdiv i64 %t245, %t246
  store i64 %t249, ptr %l144, !tbaa !24
  br label %bb71
bb70:
  store i64 0, ptr %l144, !tbaa !24
  br label %bb71
bb71:
  %t251 = load i64, ptr %l144, !tbaa !24
  store i64 %t251, ptr %l141, !tbaa !24
  br label %bb72
bb72:
  %t252 = load i64, ptr %l141, !tbaa !24
  store i64 %t252, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb73
bb73:
  %t253 = load i64, ptr %l18, !tbaa !24
  %t254 = load i64, ptr %l17, !tbaa !24
  %t257 = icmp slt i64 %t253, %t254
  %t259 = xor i1 %t257, true
  br i1 %t259, label %bb74, label %bb75
bb74:
  br label %bb87
bb75:
  br label %bb76
bb76:
  %t261 = load i64, ptr %l14, !tbaa !24
  %t262 = load i64, ptr %l18, !tbaa !24
  %t263 = load i64, ptr %l16, !tbaa !24
  %t266 = mul i64 %t262, %t263
  %t269 = add i64 %t261, %t266
  store i64 %t269, ptr %l19, !tbaa !24
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t273 = getelementptr %"compiler/generic:Program", ptr %t271, i32 0, i32 2
  %t274 = load i32, ptr %l13, !tbaa !23
  %t277 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t273, i32 %t274)
  store i32 %t277, ptr %l165
  br label %bb77
bb77:
  %t278 = load i32, ptr %l165, !range !{i32 0, i32 33}
  %t280 = trunc i64 19 to i32
  %t281 = icmp eq i32 %t278, %t280
  br i1 %t281, label %bb78, label %bb79
bb78:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb79:
  br label %bb80
bb80:
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t285 = load i32, ptr %l13, !tbaa !23
  %t288 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t284, i32 %t285)
  store i1 %t288, ptr %l171
  br label %bb81
bb81:
  %t289 = load i1, ptr %l171, !tbaa !21
  %t290 = xor i1 %t289, true
  br i1 %t290, label %bb82, label %bb83
bb82:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb83:
  br label %bb84
bb84:
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t295 = getelementptr %"compiler/generic:Program", ptr %t293, i32 0, i32 2
  %t296 = load i32, ptr %l13, !tbaa !23
  %t299 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t295, i32 %t296)
  store i32 %t299, ptr %l177
  br label %bb85
bb85:
  %t300 = load i32, ptr %l177, !tbaa !23
  store i32 %t300, ptr %l13, !tbaa !23
  br label %bb86
bb86:
  %t301 = load i64, ptr %l18, !tbaa !24
  %t304 = add i64 %t301, 1
  store i64 %t304, ptr %l18, !tbaa !24
  br label %bb73
bb87:
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunifyBound(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i32
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca ptr
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca ptr
  %l44 = alloca i64
  %l45 = alloca i32
  %l46 = alloca i32
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l61 = alloca i32
  %l65 = alloca ptr
  %l69 = alloca i32
  %l70 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l80 = alloca i64
  %l87 = alloca i64
  %l96 = alloca i32
  %l104 = alloca i32
  %l108 = alloca i32
  %l111 = alloca i32
  %l115 = alloca i32
  %l120 = alloca i32
  %l123 = alloca ptr
  %l127 = alloca i32
  %l128 = alloca { i64, ptr }
  %l136 = alloca { i64, ptr }
  %l142 = alloca i32
  %l146 = alloca i64
  %l155 = alloca i64
  %l158 = alloca i64
  %l167 = alloca i64
  %l170 = alloca i1
  %l182 = alloca { i64, ptr }
  %l188 = alloca ptr
  %l192 = alloca i32
  %l196 = alloca i32
  %l198 = alloca i32
  %l199 = alloca i64
  %l202 = alloca i64
  %l210 = alloca ptr
  %l213 = alloca i1
  %l219 = alloca i64
  %l228 = alloca i64
  %l231 = alloca i64
  %l240 = alloca i64
  %l243 = alloca i1
  %l255 = alloca { i64, ptr }
  %l266 = alloca ptr
  %l267 = alloca i1
  %l273 = alloca i64
  %l287 = alloca { i64, ptr }
  %l290 = alloca ptr
  %l291 = alloca i32
  %l292 = alloca ptr
  %l293 = alloca ptr
  %l296 = alloca %"compiler/generic:Context"
  %l300 = alloca i32
  %l302 = alloca i64
  %l306 = alloca i32
  %l307 = alloca i32
  %l311 = alloca i64
  %l322 = alloca { i64, ptr }
  %l326 = alloca i1
  %l331 = alloca i64
  %l337 = alloca i32
  %l341 = alloca ptr
  %l342 = alloca ptr
  %l345 = alloca %"compiler/generic:Context"
  %l350 = alloca i32
  %l352 = alloca i64
  %l356 = alloca i32
  %l357 = alloca i32
  %l359 = alloca ptr
  %l363 = alloca i32
  %l364 = alloca { i64, ptr }
  %l366 = alloca ptr
  %l370 = alloca i32
  %l371 = alloca { i64, ptr }
  %l383 = alloca i64
  %l386 = alloca i64
  %l405 = alloca { i64, ptr }
  %l408 = alloca { i64, ptr }
  %l413 = alloca i32
  %l417 = alloca ptr
  %l421 = alloca i32
  %l425 = alloca i32
  %l427 = alloca i32
  %l428 = alloca ptr
  %l432 = alloca i32
  %l434 = alloca i1
  %l435 = alloca ptr
  %l439 = alloca i32
  %l443 = alloca i32
  %l445 = alloca i32
  %l451 = alloca i64
  %s0 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %rv = alloca i64
  %t508 = alloca %"compiler/generic:Context", align 8
  %t607 = alloca %"compiler/generic:Context", align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l4, !tbaa !24
  %t3 = icmp sgt i64 %t1, 32
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  store i64 0, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/generic:Program", ptr %t6, i32 0, i32 2
  %t9 = load i32, ptr %l2, !tbaa !23
  %t12 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t8, i32 %t9)
  store i32 %t12, ptr %l61
  br label %bb4
bb4:
  %t13 = load i32, ptr %l61, !range !{i32 0, i32 33}
  %t15 = trunc i64 22 to i32
  %t16 = icmp eq i32 %t13, %t15
  br i1 %t16, label %bb5, label %bb6
bb5:
  store i64 0, ptr %l5, !tbaa !24
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/generic:Program", ptr %t18, i32 0, i32 2
  store ptr %t20, ptr %l65, !tbaa !29
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/generic:Program", ptr %t21, i32 0, i32 2
  %t24 = load i32, ptr %l2, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l69
  br label %bb7
bb6:
  br label %bb16
bb7:
  %t28 = load ptr, ptr %l65, !tbaa !29
  %t29 = load i32, ptr %l69, !tbaa !23
  %t30 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t28, i32 %t29)
  store { i64, ptr } %t30, ptr %l70
  br label %bb8
bb8:
  %t31 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t31, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t32 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  store i64 %t34, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  %t36 = load i64, ptr %l7, !tbaa !24
  %t37 = load i64, ptr %l8, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb10, label %bb11
bb10:
  br label %bb15
bb11:
  br label %bb12
bb12:
  %t44 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t44, ptr %l77, !tbaa !27
  %t45 = load i64, ptr %l7, !tbaa !24
  %t47 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr i32, ptr %t48, i64 %t45
  %t50 = load i32, ptr %t49, !tbaa !33
  %t52 = load i64, ptr %l5, !tbaa !24
  store i64 %t52, ptr %l80, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load i32, ptr %l1, !tbaa !23
  %t56 = load ptr, ptr %l3, !tbaa !29
  %t57 = load i64, ptr %l4, !tbaa !24
  %t59 = add i64 %t57, 1
  %t65 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunifyBound(ptr %v0, ptr %v1, ptr %t53, i32 %t54, i32 %t50, ptr %t56, i64 %t59)
  store i64 %t65, ptr %l87
  br label %bb13
bb13:
  %t66 = load i64, ptr %l80, !tbaa !24
  %t67 = load i64, ptr %l87, !tbaa !24
  %t68 = add i64 %t66, %t67
  store i64 %t68, ptr %l5, !tbaa !24
  br label %bb14
bb14:
  %t70 = load i64, ptr %l7, !tbaa !24
  %t73 = add i64 %t70, 1
  store i64 %t73, ptr %l7, !tbaa !24
  br label %bb9
bb15:
  %t75 = load i64, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t75, ptr %rv
  br label %ret
bb16:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/generic:Program", ptr %t77, i32 0, i32 2
  %t80 = load i32, ptr %l2, !tbaa !23
  %t83 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t79, i32 %t80)
  store i32 %t83, ptr %l96
  br label %bb17
bb17:
  %t84 = load i32, ptr %l96, !range !{i32 0, i32 33}
  %t86 = trunc i64 18 to i32
  %t87 = icmp eq i32 %t84, %t86
  %t89 = xor i1 %t87, true
  br i1 %t89, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s0)
  store i64 0, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/generic:Program", ptr %t92, i32 0, i32 2
  %t95 = load i32, ptr %l2, !tbaa !23
  %t98 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t94, i32 %t95)
  store i32 %t98, ptr %l104
  br label %bb21
bb21:
  %t99 = load i32, ptr %l104, !tbaa !23
  store i32 %t99, ptr %l10, !tbaa !23
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Program", ptr %t100, i32 0, i32 2
  %t103 = load i32, ptr %l1, !tbaa !23
  %t106 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t102, i32 %t103)
  store i32 %t106, ptr %l108
  br label %bb22
bb22:
  %t107 = load i32, ptr %l108, !range !{i32 0, i32 33}
  %t109 = trunc i64 20 to i32
  %t110 = icmp eq i32 %t107, %t109
  br i1 %t110, label %bb23, label %bb24
bb23:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/generic:Program", ptr %t112, i32 0, i32 2
  %t115 = load i32, ptr %l1, !tbaa !23
  %t118 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t114, i32 %t115)
  store i32 %t118, ptr %l115
  br label %bb25
bb24:
  %t119 = load i32, ptr %l1, !tbaa !23
  store i32 %t119, ptr %l111, !tbaa !23
  br label %bb26
bb25:
  %t121 = load i32, ptr %l115, !tbaa !23
  store i32 %t121, ptr %l111, !tbaa !23
  br label %bb26
bb26:
  %t122 = load i32, ptr %l111, !tbaa !23
  store i32 %t122, ptr %l11, !tbaa !23
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/generic:Program", ptr %t123, i32 0, i32 2
  %t126 = load i32, ptr %l11, !tbaa !23
  %t129 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t125, i32 %t126)
  store i32 %t129, ptr %l120
  br label %bb27
bb27:
  %t130 = load i32, ptr %l120, !range !{i32 0, i32 33}
  %t132 = trunc i64 29 to i32
  %t133 = icmp eq i32 %t130, %t132
  br i1 %t133, label %bb28, label %bb29
bb28:
  store i64 0, ptr %l12, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s8
  %t135 = load ptr, ptr %l0, !tbaa !29
  store ptr %t135, ptr %l123, !tbaa !29
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/generic:Program", ptr %t136, i32 0, i32 2
  %t139 = load i32, ptr %l11, !tbaa !23
  %t142 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t138, i32 %t139)
  store i32 %t142, ptr %l127
  br label %bb30
bb29:
  br label %bb65
bb30:
  %t143 = load ptr, ptr %l123, !tbaa !29
  %t144 = load i32, ptr %l127, !tbaa !23
  %t145 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyCovers(ptr %v0, ptr %s8, ptr %t143, i32 %t144)
  store { i64, ptr } %t145, ptr %l128
  br label %bb31
bb31:
  %t146 = load { i64, ptr }, ptr %l128, !tbaa !27
  store { i64, ptr } %t146, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t148 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t150 = extractvalue { i64, ptr } %t148, 0
  store i64 %t150, ptr %l15, !tbaa !24
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s9
  %t152 = load i64, ptr %l14, !tbaa !24
  %t153 = load i64, ptr %l15, !tbaa !24
  %t156 = icmp slt i64 %t152, %t153
  %t158 = xor i1 %t156, true
  br i1 %t158, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s9)
  br label %bb64
bb34:
  br label %bb35
bb35:
  %t160 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t160, ptr %l136, !tbaa !27
  %t161 = load i64, ptr %l14, !tbaa !24
  %t163 = getelementptr { i64, ptr }, ptr %l136, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !27
  %t165 = getelementptr i32, ptr %t164, i64 %t161
  %t166 = load i32, ptr %t165, !tbaa !33
  store i32 %t166, ptr %l16, !tbaa !23
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/generic:Program", ptr %t168, i32 0, i32 2
  %t171 = load i32, ptr %l16, !tbaa !23
  %t174 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t170, i32 %t171)
  store i32 %t174, ptr %l142
  br label %bb36
bb36:
  %t175 = load i32, ptr %l10, !tbaa !23
  %t176 = load i32, ptr %l142, !tbaa !23
  %t178 = icmp ne i32 %t176, %t175
  br i1 %t178, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s9)
  br label %bb63
bb38:
  br label %bb39
bb39:
  %t180 = load ptr, ptr %l3, !tbaa !29
  %t182 = getelementptr %"compiler/generic:Binding", ptr %t180, i32 0, i32 1
  %t183 = load i64, ptr %t182, !tbaa !24
  store i64 %t183, ptr %l146, !tbaa !24
  %t184 = load i64, ptr %l146, !tbaa !24
  %t185 = icmp sge i64 %t184, 0
  br i1 %t185, label %bb40, label %bb41
bb40:
  %t187 = load i64, ptr %l146, !tbaa !24
  %t188 = icmp sle i64 %t187, 2305843009213693951
  br i1 %t188, label %bb42, label %bb43
bb41:
  call void @__olang_check_failed(ptr @olang_loc_b3aa93c548ec796e_ac2c4500982ff6c2)
  unreachable
bb42:
  %t190 = load i64, ptr %l146, !tbaa !24
  %t191 = mul i64 %t190, 4
  %t192 = call ptr @__olang_scope_alloc_zeroed(ptr %s9, i64 %t191)
  %t193 = insertvalue { i64, ptr } undef, i64 %t190, 0
  %t194 = insertvalue { i64, ptr } %t193, ptr %t192, 1
  store { i64, ptr } %t194, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t196 = load ptr, ptr %l3, !tbaa !29
  %t198 = getelementptr %"compiler/generic:Binding", ptr %t196, i32 0, i32 1
  %t199 = load i64, ptr %t198, !tbaa !24
  store i64 %t199, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t201 = load i64, ptr %l19, !tbaa !24
  %t202 = load i64, ptr %l18, !tbaa !24
  %t205 = icmp sgt i64 %t201, %t202
  br i1 %t205, label %bb44, label %bb45
bb43:
  call void @__olang_check_failed(ptr @olang_loc_b3aa93c548ec796e_ac2c4500982ff6c2)
  unreachable
bb44:
  %t207 = load i64, ptr %l20, !tbaa !24
  %t209 = icmp sgt i64 %t207, 0
  br i1 %t209, label %bb46, label %bb47
bb45:
  store i64 0, ptr %l155, !tbaa !24
  br label %bb49
bb46:
  %t211 = load i64, ptr %l19, !tbaa !24
  %t212 = load i64, ptr %l18, !tbaa !24
  %t215 = sub i64 %t211, %t212
  %t216 = load i64, ptr %l20, !tbaa !24
  %t219 = add i64 %t215, %t216
  %t221 = sub i64 %t219, 1
  %t222 = load i64, ptr %l20, !tbaa !24
  %t225 = sdiv i64 %t221, %t222
  store i64 %t225, ptr %l158, !tbaa !24
  br label %bb48
bb47:
  store i64 0, ptr %l158, !tbaa !24
  br label %bb48
bb48:
  %t227 = load i64, ptr %l158, !tbaa !24
  store i64 %t227, ptr %l155, !tbaa !24
  br label %bb49
bb49:
  %t228 = load i64, ptr %l155, !tbaa !24
  store i64 %t228, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  %t229 = load i64, ptr %l21, !tbaa !24
  %t230 = sub i64 %t229, 1
  store i64 %t230, ptr %l167, !tbaa !24
  %t231 = load i64, ptr %l21, !tbaa !24
  %t232 = icmp slt i64 %t231, 2147483648
  %t233 = load i64, ptr %l22, !tbaa !24
  %t234 = icmp sge i64 %t233, 0
  %t237 = and i1 %t232, %t234
  store i1 %t237, ptr %l170, !tbaa !21
  br label %bb50
bb50:
  %t238 = load i64, ptr %l22, !tbaa !24
  %t239 = load i64, ptr %l21, !tbaa !24
  %t242 = icmp slt i64 %t238, %t239
  %t244 = xor i1 %t242, true
  br i1 %t244, label %bb51, label %bb52
bb51:
  br label %bb55
bb52:
  br label %bb53
bb53:
  %t246 = load i64, ptr %l18, !tbaa !24
  %t247 = load i64, ptr %l22, !tbaa !24
  %t248 = load i64, ptr %l20, !tbaa !24
  %t251 = mul i64 %t247, %t248
  %t254 = add i64 %t246, %t251
  store i64 %t254, ptr %l23, !tbaa !24
  %t256 = load i64, ptr %l23, !tbaa !24
  %t257 = load ptr, ptr %l3, !tbaa !29
  %t259 = getelementptr %"compiler/generic:Binding", ptr %t257, i32 0, i32 2
  %t260 = load { i64, ptr }, ptr %t259, !tbaa !27
  store { i64, ptr } %t260, ptr %l182, !tbaa !27
  %t261 = load i64, ptr %l23, !tbaa !24
  %t263 = getelementptr { i64, ptr }, ptr %l182, i32 0, i32 1
  %t264 = load ptr, ptr %t263, !tbaa !27
  %t265 = getelementptr i32, ptr %t264, i64 %t261
  %t266 = load i32, ptr %t265, !tbaa !33
  %t269 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t270 = load ptr, ptr %t269, !tbaa !27
  %t271 = getelementptr i32, ptr %t270, i64 %t256
  store i32 %t266, ptr %t271, !tbaa !33
  br label %bb54
bb54:
  %t272 = load i64, ptr %l22, !tbaa !24
  %t275 = add i64 %t272, 1
  store i64 %t275, ptr %l22, !tbaa !24
  br label %bb50
bb55:
  %t277 = load ptr, ptr %l0, !tbaa !29
  store ptr %t277, ptr %l188, !tbaa !29
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t280 = getelementptr %"compiler/generic:Program", ptr %t278, i32 0, i32 2
  %t281 = load i32, ptr %l2, !tbaa !23
  %t284 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t280, i32 %t281)
  store i32 %t284, ptr %l192
  br label %bb56
bb56:
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t287 = getelementptr %"compiler/generic:Program", ptr %t285, i32 0, i32 2
  %t288 = load i32, ptr %l16, !tbaa !23
  %t291 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t287, i32 %t288)
  store i32 %t291, ptr %l196
  br label %bb57
bb57:
  %t292 = load ptr, ptr %l3, !tbaa !29
  %t293 = load ptr, ptr %l188, !tbaa !29
  %t294 = load i32, ptr %l192, !tbaa !23
  %t295 = load i32, ptr %l196, !tbaa !23
  %t297 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunifyLists(ptr %v0, ptr %v1, ptr %t293, i32 %t294, i32 %t295, ptr %t292, i1 false)
  store i32 %t297, ptr %l198
  %t298 = icmp ne i32 %t297, 0
  br i1 %t298, label %bb59, label %ok.299, !prof !99
ok.299:
  br label %bb58
bb58:
  br label %bb61
bb59:
  br label %bb60
bb60:
  br label %bb61
bb61:
  %t300 = load i64, ptr %l12, !tbaa !24
  store i64 %t300, ptr %l199, !tbaa !24
  %t301 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t302 = load ptr, ptr %l3, !tbaa !29
  %t305 = call i64 @compiler_2fgeneric_2echangedVals(ptr %s9, ptr %v1, { i64, ptr } %t301, ptr %t302)
  store i64 %t305, ptr %l202
  br label %bb62
bb62:
  %t306 = load i64, ptr %l199, !tbaa !24
  %t307 = load i64, ptr %l202, !tbaa !24
  %t308 = add i64 %t306, %t307
  store i64 %t308, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb63
bb63:
  %t310 = load i64, ptr %l14, !tbaa !24
  %t313 = add i64 %t310, 1
  store i64 %t313, ptr %l14, !tbaa !24
  br label %bb32
bb64:
  call void @__olang_scope_close(ptr %s8)
  %t315 = load i64, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t315, ptr %rv
  br label %ret
bb65:
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t318 = load i32, ptr %l10, !tbaa !23
  %t321 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etypeDecl(ptr %v0, ptr %v0, ptr %t317, i32 %t318)
  store ptr %t321, ptr %l210
  br label %bb66
bb66:
  %t322 = load ptr, ptr %l210, !tbaa !29
  store ptr %t322, ptr %l24, !tbaa !29
  %t323 = load ptr, ptr %l24, !tbaa !29
  %t325 = icmp eq ptr %t323, null
  br i1 %t325, label %bb67, label %bb68
bb67:
  store i1 true, ptr %l213, !tbaa !21
  br label %bb69
bb68:
  %t327 = load ptr, ptr %l24, !tbaa !29
  %t329 = getelementptr %"compiler/ast:TypeDecl", ptr %t327, i32 0, i32 3
  %t330 = load ptr, ptr %t329, !tbaa !29
  %t332 = icmp eq ptr %t330, null
  store i1 %t332, ptr %l213, !tbaa !21
  br label %bb69
bb69:
  %t334 = load i1, ptr %l213, !tbaa !21
  br i1 %t334, label %bb70, label %bb71
bb70:
  call void @__olang_scope_close(ptr %s0)
  store i64 0, ptr %rv
  br label %ret
bb71:
  br label %bb72
bb72:
  %t336 = load ptr, ptr %l3, !tbaa !29
  %t338 = getelementptr %"compiler/generic:Binding", ptr %t336, i32 0, i32 1
  %t339 = load i64, ptr %t338, !tbaa !24
  store i64 %t339, ptr %l219, !tbaa !24
  %t340 = load i64, ptr %l219, !tbaa !24
  %t341 = icmp sge i64 %t340, 0
  br i1 %t341, label %bb73, label %bb74
bb73:
  %t343 = load i64, ptr %l219, !tbaa !24
  %t344 = icmp sle i64 %t343, 2305843009213693951
  br i1 %t344, label %bb75, label %bb76
bb74:
  call void @__olang_check_failed(ptr @olang_loc_d067a2352cc578e3_8c11ed4f2bfcee77)
  unreachable
bb75:
  %t346 = load i64, ptr %l219, !tbaa !24
  %t347 = mul i64 %t346, 4
  %t348 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t347)
  %t349 = insertvalue { i64, ptr } undef, i64 %t346, 0
  %t350 = insertvalue { i64, ptr } %t349, ptr %t348, 1
  store { i64, ptr } %t350, ptr %l25, !tbaa !27
  store i64 0, ptr %l26, !tbaa !24
  %t352 = load ptr, ptr %l3, !tbaa !29
  %t354 = getelementptr %"compiler/generic:Binding", ptr %t352, i32 0, i32 1
  %t355 = load i64, ptr %t354, !tbaa !24
  store i64 %t355, ptr %l27, !tbaa !24
  store i64 1, ptr %l28, !tbaa !24
  %t357 = load i64, ptr %l27, !tbaa !24
  %t358 = load i64, ptr %l26, !tbaa !24
  %t361 = icmp sgt i64 %t357, %t358
  br i1 %t361, label %bb77, label %bb78
bb76:
  call void @__olang_check_failed(ptr @olang_loc_d067a2352cc578e3_8c11ed4f2bfcee77)
  unreachable
bb77:
  %t363 = load i64, ptr %l28, !tbaa !24
  %t365 = icmp sgt i64 %t363, 0
  br i1 %t365, label %bb79, label %bb80
bb78:
  store i64 0, ptr %l228, !tbaa !24
  br label %bb82
bb79:
  %t367 = load i64, ptr %l27, !tbaa !24
  %t368 = load i64, ptr %l26, !tbaa !24
  %t371 = sub i64 %t367, %t368
  %t372 = load i64, ptr %l28, !tbaa !24
  %t375 = add i64 %t371, %t372
  %t377 = sub i64 %t375, 1
  %t378 = load i64, ptr %l28, !tbaa !24
  %t381 = sdiv i64 %t377, %t378
  store i64 %t381, ptr %l231, !tbaa !24
  br label %bb81
bb80:
  store i64 0, ptr %l231, !tbaa !24
  br label %bb81
bb81:
  %t383 = load i64, ptr %l231, !tbaa !24
  store i64 %t383, ptr %l228, !tbaa !24
  br label %bb82
bb82:
  %t384 = load i64, ptr %l228, !tbaa !24
  store i64 %t384, ptr %l29, !tbaa !24
  store i64 0, ptr %l30, !tbaa !24
  %t385 = load i64, ptr %l29, !tbaa !24
  %t386 = sub i64 %t385, 1
  store i64 %t386, ptr %l240, !tbaa !24
  %t387 = load i64, ptr %l29, !tbaa !24
  %t388 = icmp slt i64 %t387, 2147483648
  %t389 = load i64, ptr %l30, !tbaa !24
  %t390 = icmp sge i64 %t389, 0
  %t393 = and i1 %t388, %t390
  store i1 %t393, ptr %l243, !tbaa !21
  br label %bb83
bb83:
  %t394 = load i64, ptr %l30, !tbaa !24
  %t395 = load i64, ptr %l29, !tbaa !24
  %t398 = icmp slt i64 %t394, %t395
  %t400 = xor i1 %t398, true
  br i1 %t400, label %bb84, label %bb85
bb84:
  br label %bb88
bb85:
  br label %bb86
bb86:
  %t402 = load i64, ptr %l26, !tbaa !24
  %t403 = load i64, ptr %l30, !tbaa !24
  %t404 = load i64, ptr %l28, !tbaa !24
  %t407 = mul i64 %t403, %t404
  %t410 = add i64 %t402, %t407
  store i64 %t410, ptr %l31, !tbaa !24
  %t412 = load i64, ptr %l31, !tbaa !24
  %t413 = load ptr, ptr %l3, !tbaa !29
  %t415 = getelementptr %"compiler/generic:Binding", ptr %t413, i32 0, i32 2
  %t416 = load { i64, ptr }, ptr %t415, !tbaa !27
  store { i64, ptr } %t416, ptr %l255, !tbaa !27
  %t417 = load i64, ptr %l31, !tbaa !24
  %t419 = getelementptr { i64, ptr }, ptr %l255, i32 0, i32 1
  %t420 = load ptr, ptr %t419, !tbaa !27
  %t421 = getelementptr i32, ptr %t420, i64 %t417
  %t422 = load i32, ptr %t421, !tbaa !33
  %t425 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t426 = load ptr, ptr %t425, !tbaa !27
  %t427 = getelementptr i32, ptr %t426, i64 %t412
  store i32 %t422, ptr %t427, !tbaa !33
  br label %bb87
bb87:
  %t428 = load i64, ptr %l30, !tbaa !24
  %t431 = add i64 %t428, 1
  store i64 %t431, ptr %l30, !tbaa !24
  br label %bb83
bb88:
  %t433 = load ptr, ptr %l24, !tbaa !29
  %t435 = getelementptr %"compiler/ast:TypeDecl", ptr %t433, i32 0, i32 3
  %t436 = load ptr, ptr %t435, !tbaa !29
  %t438 = icmp eq ptr %t436, null
  br i1 %t438, label %bb89, label %bb90
bb89:
  call void @__olang_check_failed(ptr @olang_loc_daff0119e8e7a208_cf3c54c8cae97514)
  unreachable
bb90:
  br label %bb91
bb91:
  %t440 = load ptr, ptr %l24, !tbaa !29
  %t442 = getelementptr %"compiler/ast:TypeDecl", ptr %t440, i32 0, i32 3
  %t443 = load ptr, ptr %t442, !tbaa !29
  store ptr %t443, ptr %l32, !tbaa !29
  %t445 = load ptr, ptr %l32, !tbaa !29
  store ptr %t445, ptr %l266, !tbaa !29
  store i1 false, ptr %l267, !tbaa !21
  %t446 = load ptr, ptr %l266, !tbaa !29
  %t447 = icmp ne ptr %t446, null
  br i1 %t447, label %bb92, label %bb93
bb92:
  %t449 = load ptr, ptr %l266, !tbaa !29
  %t450 = load i64, ptr %t449, !range !{i64 0, i64 5}
  %t452 = icmp eq i64 %t450, 2
  store i1 %t452, ptr %l267, !tbaa !21
  br label %bb93
bb93:
  %t453 = load i1, ptr %l267, !tbaa !21
  %t454 = xor i1 %t453, true
  br i1 %t454, label %bb94, label %bb95
bb94:
  %t456 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t457 = load ptr, ptr %l3, !tbaa !29
  %t460 = call i64 @compiler_2fgeneric_2echangedVals(ptr %s0, ptr %v1, { i64, ptr } %t456, ptr %t457)
  store i64 %t460, ptr %l273
  br label %bb96
bb95:
  br label %bb97
bb96:
  call void @__olang_scope_close(ptr %s0)
  %t461 = load i64, ptr %l273, !tbaa !24
  store i64 %t461, ptr %rv
  br label %ret
bb97:
  %t462 = load ptr, ptr %l32, !tbaa !29
  %t464 = getelementptr { i64, [6 x i64] }, ptr %t462, i32 0, i32 1
  %t465 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t464, i32 0, i32 0
  %t466 = load { i64, ptr }, ptr %t465
  store { i64, ptr } %t466, ptr %l33, !tbaa !27
  %t468 = load ptr, ptr %l32, !tbaa !29
  %t470 = getelementptr { i64, [6 x i64] }, ptr %t468, i32 0, i32 1
  %t471 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t470, i32 0, i32 1
  %t472 = load { i64, ptr }, ptr %t471
  %t474 = load ptr, ptr %l32, !tbaa !29
  %t476 = getelementptr { i64, [6 x i64] }, ptr %t474, i32 0, i32 1
  %t477 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t476, i32 0, i32 2
  %t478 = load { i64, ptr }, ptr %t477
  store { i64, ptr } %t478, ptr %l35, !tbaa !27
  store { i64, ptr } %t472, ptr %l36, !tbaa !27
  store i64 0, ptr %l37, !tbaa !24
  %t482 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t484 = extractvalue { i64, ptr } %t482, 0
  store i64 %t484, ptr %l38, !tbaa !24
  br label %bb98
bb98:
  store %olang.scope zeroinitializer, ptr %s22
  %t486 = load i64, ptr %l37, !tbaa !24
  %t487 = load i64, ptr %l38, !tbaa !24
  %t490 = icmp slt i64 %t486, %t487
  %t492 = xor i1 %t490, true
  br i1 %t492, label %bb99, label %bb100
bb99:
  call void @__olang_scope_close(ptr %s22)
  br label %bb109
bb100:
  br label %bb101
bb101:
  %t494 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t494, ptr %l287, !tbaa !27
  %t495 = load i64, ptr %l37, !tbaa !24
  %t497 = getelementptr { i64, ptr }, ptr %l287, i32 0, i32 1
  %t498 = load ptr, ptr %t497, !tbaa !27
  %t499 = getelementptr ptr, ptr %t498, i64 %t495
  %t500 = load ptr, ptr %t499, !tbaa !39
  store ptr %t500, ptr %l39, !tbaa !29
  %t502 = load ptr, ptr %l0, !tbaa !29
  store ptr %t502, ptr %l290, !tbaa !29
  %t503 = load i32, ptr %l1, !tbaa !23
  store i32 %t503, ptr %l291, !tbaa !23
  %t504 = load ptr, ptr %l0, !tbaa !29
  store ptr %t504, ptr %l292, !tbaa !29
  %t505 = load ptr, ptr %l0, !tbaa !29
  store ptr %t505, ptr %l293, !tbaa !29
  %t506 = load ptr, ptr %l0, !tbaa !29
  %t507 = load i32, ptr %l10, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2edeclContext(ptr %t508, ptr %v0, ptr %s22, ptr %t506, i32 %t507)
  call void @llvm.memmove.p0.p0.i64(ptr %l296, ptr %t508, i64 160, i1 false)
  br label %bb102
bb102:
  %t511 = call ptr @__olang_scope_alloc_a(ptr %s22, i64 160, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t511, ptr %l296, i64 160, i1 false)
  %t512 = load ptr, ptr %l39, !tbaa !29
  %t514 = load ptr, ptr %l293, !tbaa !29
  %t517 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %s22, ptr %v0, ptr %t514, ptr %t511, ptr %t512)
  store i32 %t517, ptr %l300
  br label %bb103
bb103:
  %t518 = load i32, ptr %l10, !tbaa !23
  %t520 = call i64 @compiler_2fgeneric_2eDeclOwner(i32 %t518)
  store i64 %t520, ptr %l302
  br label %bb104
bb104:
  %t521 = load ptr, ptr %l0, !tbaa !29
  %t523 = getelementptr %"compiler/generic:Program", ptr %t521, i32 0, i32 2
  %t524 = load i32, ptr %l2, !tbaa !23
  %t527 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t523, i32 %t524)
  store i32 %t527, ptr %l306
  br label %bb105
bb105:
  %t528 = load ptr, ptr %l292, !tbaa !29
  %t529 = load i32, ptr %l300, !tbaa !23
  %t530 = load i64, ptr %l302, !tbaa !24
  %t531 = load i32, ptr %l306, !tbaa !23
  %t532 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %t528, i32 %t529, i64 %t530, i32 %t531)
  store i32 %t532, ptr %l307
  br label %bb106
bb106:
  %t533 = load ptr, ptr %l3, !tbaa !29
  %t534 = load i64, ptr %l4, !tbaa !24
  %t536 = add i64 %t534, 1
  %t537 = load ptr, ptr %l290, !tbaa !29
  %t538 = load i32, ptr %l291, !tbaa !23
  %t539 = load i32, ptr %l307, !tbaa !23
  %t542 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunifyBound(ptr %v0, ptr %v1, ptr %t537, i32 %t538, i32 %t539, ptr %t533, i64 %t536)
  store i64 %t542, ptr %l311
  br label %bb107
bb107:
  call void @__olang_scope_close(ptr %s22)
  br label %bb108
bb108:
  %t543 = load i64, ptr %l37, !tbaa !24
  %t546 = add i64 %t543, 1
  store i64 %t546, ptr %l37, !tbaa !24
  br label %bb98
bb109:
  %t548 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t548, ptr %l40, !tbaa !27
  store i64 0, ptr %l41, !tbaa !24
  %t550 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t552 = extractvalue { i64, ptr } %t550, 0
  store i64 %t552, ptr %l42, !tbaa !24
  br label %bb110
bb110:
  store %olang.scope zeroinitializer, ptr %s25
  %t554 = load i64, ptr %l41, !tbaa !24
  %t555 = load i64, ptr %l42, !tbaa !24
  %t558 = icmp slt i64 %t554, %t555
  %t560 = xor i1 %t558, true
  br i1 %t560, label %bb111, label %bb112
bb111:
  call void @__olang_scope_close(ptr %s25)
  br label %bb172
bb112:
  br label %bb113
bb113:
  %t562 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t562, ptr %l322, !tbaa !27
  %t563 = load i64, ptr %l41, !tbaa !24
  %t565 = getelementptr { i64, ptr }, ptr %l322, i32 0, i32 1
  %t566 = load ptr, ptr %t565, !tbaa !27
  %t567 = getelementptr ptr, ptr %t566, i64 %t563
  %t568 = load ptr, ptr %t567, !tbaa !39
  store ptr %t568, ptr %l43, !tbaa !29
  %t570 = load ptr, ptr %l43, !tbaa !29
  %t572 = call i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v0, ptr %t570)
  store i1 %t572, ptr %l326
  br label %bb114
bb114:
  %t573 = load i1, ptr %l326, !tbaa !21
  br i1 %t573, label %bb115, label %bb116
bb115:
  call void @__olang_scope_close(ptr %s25)
  br label %bb171
bb116:
  br label %bb117
bb117:
  %t574 = load ptr, ptr %l0, !tbaa !29
  %t575 = load i32, ptr %l1, !tbaa !23
  %t576 = load ptr, ptr %l43, !tbaa !29
  %t578 = getelementptr %"compiler/ast:Func", ptr %t576, i32 0, i32 2
  %t579 = load i32, ptr %t578, !tbaa !23
  %t583 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t574, i32 %t575, i32 %t579)
  store i64 %t583, ptr %l331
  br label %bb118
bb118:
  %t584 = load i64, ptr %l331, !tbaa !24
  store i64 %t584, ptr %l44, !tbaa !24
  %t585 = load i64, ptr %l44, !tbaa !24
  %t587 = icmp slt i64 %t585, 0
  br i1 %t587, label %bb119, label %bb120
bb119:
  call void @__olang_scope_close(ptr %s25)
  br label %bb171
bb120:
  br label %bb121
bb121:
  %t589 = load ptr, ptr %l0, !tbaa !29
  %t590 = load i64, ptr %l44, !tbaa !24
  %t591 = load i32, ptr %l1, !tbaa !23
  %t595 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodSig(ptr %v0, ptr %t589, i64 %t590, i32 %t591)
  store i32 %t595, ptr %l337
  br label %bb122
bb122:
  %t596 = load i32, ptr %l337, !tbaa !23
  store i32 %t596, ptr %l45, !tbaa !23
  %t597 = load i32, ptr %l45, !tbaa !23
  %t598 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t601 = icmp eq i32 %t597, %t598
  br i1 %t601, label %bb123, label %bb124
bb123:
  call void @__olang_scope_close(ptr %s25)
  br label %bb171
bb124:
  br label %bb125
bb125:
  %t603 = load ptr, ptr %l0, !tbaa !29
  store ptr %t603, ptr %l341, !tbaa !29
  %t604 = load ptr, ptr %l0, !tbaa !29
  store ptr %t604, ptr %l342, !tbaa !29
  %t605 = load ptr, ptr %l0, !tbaa !29
  %t606 = load i32, ptr %l10, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2edeclContext(ptr %t607, ptr %v0, ptr %s25, ptr %t605, i32 %t606)
  call void @llvm.memmove.p0.p0.i64(ptr %l345, ptr %t607, i64 160, i1 false)
  br label %bb126
bb126:
  %t610 = call ptr @__olang_scope_alloc_a(ptr %s25, i64 160, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t610, ptr %l345, i64 160, i1 false)
  %t611 = load ptr, ptr %l43, !tbaa !29
  %t613 = getelementptr %"compiler/ast:Func", ptr %t611, i32 0, i32 3
  %t614 = load ptr, ptr %t613, !tbaa !29
  %t615 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t616 = load ptr, ptr %l342, !tbaa !29
  %t620 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2esigType(ptr %v0, ptr %s25, ptr %v0, ptr %t616, ptr %t610, ptr %t614, i32 %t615, i32 0)
  store i32 %t620, ptr %l350
  br label %bb127
bb127:
  %t621 = load i32, ptr %l10, !tbaa !23
  %t623 = call i64 @compiler_2fgeneric_2eDeclOwner(i32 %t621)
  store i64 %t623, ptr %l352
  br label %bb128
bb128:
  %t624 = load ptr, ptr %l0, !tbaa !29
  %t626 = getelementptr %"compiler/generic:Program", ptr %t624, i32 0, i32 2
  %t627 = load i32, ptr %l2, !tbaa !23
  %t630 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t626, i32 %t627)
  store i32 %t630, ptr %l356
  br label %bb129
bb129:
  %t631 = load ptr, ptr %l341, !tbaa !29
  %t632 = load i32, ptr %l350, !tbaa !23
  %t633 = load i64, ptr %l352, !tbaa !24
  %t634 = load i32, ptr %l356, !tbaa !23
  %t635 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %t631, i32 %t632, i64 %t633, i32 %t634)
  store i32 %t635, ptr %l357
  br label %bb130
bb130:
  %t636 = load i32, ptr %l357, !tbaa !23
  store i32 %t636, ptr %l46, !tbaa !23
  %t637 = load ptr, ptr %l0, !tbaa !29
  %t639 = getelementptr %"compiler/generic:Program", ptr %t637, i32 0, i32 2
  store ptr %t639, ptr %l359, !tbaa !29
  %t640 = load ptr, ptr %l0, !tbaa !29
  %t642 = getelementptr %"compiler/generic:Program", ptr %t640, i32 0, i32 2
  %t643 = load i32, ptr %l45, !tbaa !23
  %t646 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t642, i32 %t643)
  store i32 %t646, ptr %l363
  br label %bb131
bb131:
  %t647 = load ptr, ptr %l359, !tbaa !29
  %t648 = load i32, ptr %l363, !tbaa !23
  %t649 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t647, i32 %t648)
  store { i64, ptr } %t649, ptr %l364
  br label %bb132
bb132:
  %t650 = load { i64, ptr }, ptr %l364, !tbaa !27
  store { i64, ptr } %t650, ptr %l47, !tbaa !27
  %t651 = load ptr, ptr %l0, !tbaa !29
  %t653 = getelementptr %"compiler/generic:Program", ptr %t651, i32 0, i32 2
  store ptr %t653, ptr %l366, !tbaa !29
  %t654 = load ptr, ptr %l0, !tbaa !29
  %t656 = getelementptr %"compiler/generic:Program", ptr %t654, i32 0, i32 2
  %t657 = load i32, ptr %l46, !tbaa !23
  %t660 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t656, i32 %t657)
  store i32 %t660, ptr %l370
  br label %bb133
bb133:
  %t661 = load ptr, ptr %l366, !tbaa !29
  %t662 = load i32, ptr %l370, !tbaa !23
  %t663 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t661, i32 %t662)
  store { i64, ptr } %t663, ptr %l371
  br label %bb134
bb134:
  %t664 = load { i64, ptr }, ptr %l371, !tbaa !27
  store { i64, ptr } %t664, ptr %l48, !tbaa !27
  %t665 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t667 = extractvalue { i64, ptr } %t665, 0
  %t668 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t670 = extractvalue { i64, ptr } %t668, 0
  %t672 = add i64 %t670, 1
  %t675 = icmp ne i64 %t667, %t672
  br i1 %t675, label %bb135, label %bb136
bb135:
  call void @__olang_scope_close(ptr %s25)
  br label %bb171
bb136:
  br label %bb137
bb137:
  store i64 0, ptr %l49, !tbaa !24
  %t677 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t679 = extractvalue { i64, ptr } %t677, 0
  store i64 %t679, ptr %l50, !tbaa !24
  store i64 1, ptr %l51, !tbaa !24
  %t681 = load i64, ptr %l50, !tbaa !24
  %t682 = load i64, ptr %l49, !tbaa !24
  %t685 = icmp sgt i64 %t681, %t682
  br i1 %t685, label %bb138, label %bb139
bb138:
  %t687 = load i64, ptr %l51, !tbaa !24
  %t689 = icmp sgt i64 %t687, 0
  br i1 %t689, label %bb140, label %bb141
bb139:
  store i64 0, ptr %l383, !tbaa !24
  br label %bb143
bb140:
  %t691 = load i64, ptr %l50, !tbaa !24
  %t692 = load i64, ptr %l49, !tbaa !24
  %t695 = sub i64 %t691, %t692
  %t696 = load i64, ptr %l51, !tbaa !24
  %t699 = add i64 %t695, %t696
  %t701 = sub i64 %t699, 1
  %t702 = load i64, ptr %l51, !tbaa !24
  %t705 = sdiv i64 %t701, %t702
  store i64 %t705, ptr %l386, !tbaa !24
  br label %bb142
bb141:
  store i64 0, ptr %l386, !tbaa !24
  br label %bb142
bb142:
  %t707 = load i64, ptr %l386, !tbaa !24
  store i64 %t707, ptr %l383, !tbaa !24
  br label %bb143
bb143:
  %t708 = load i64, ptr %l383, !tbaa !24
  store i64 %t708, ptr %l52, !tbaa !24
  store i64 0, ptr %l53, !tbaa !24
  br label %bb144
bb144:
  %t709 = load i64, ptr %l53, !tbaa !24
  %t710 = load i64, ptr %l52, !tbaa !24
  %t713 = icmp slt i64 %t709, %t710
  %t715 = xor i1 %t713, true
  br i1 %t715, label %bb145, label %bb146
bb145:
  br label %bb153
bb146:
  br label %bb147
bb147:
  %t717 = load i64, ptr %l49, !tbaa !24
  %t718 = load i64, ptr %l53, !tbaa !24
  %t719 = load i64, ptr %l51, !tbaa !24
  %t722 = mul i64 %t718, %t719
  %t725 = add i64 %t717, %t722
  store i64 %t725, ptr %l54, !tbaa !24
  %t727 = load ptr, ptr %l0, !tbaa !29
  %t728 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t728, ptr %l405, !tbaa !27
  %t729 = load i64, ptr %l54, !tbaa !24
  %t731 = getelementptr { i64, ptr }, ptr %l405, i32 0, i32 1
  %t732 = load ptr, ptr %t731, !tbaa !27
  %t733 = getelementptr i32, ptr %t732, i64 %t729
  %t734 = load i32, ptr %t733, !tbaa !33
  %t735 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t735, ptr %l408, !tbaa !27
  %t736 = load i64, ptr %l54, !tbaa !24
  %t738 = add i64 %t736, 1
  %t740 = getelementptr { i64, ptr }, ptr %l408, i32 0, i32 1
  %t741 = load ptr, ptr %t740, !tbaa !27
  %t742 = getelementptr i32, ptr %t741, i64 %t738
  %t743 = load i32, ptr %t742, !tbaa !33
  %t744 = load ptr, ptr %l3, !tbaa !29
  %t749 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnifyArg(ptr %v0, ptr %v1, ptr %t727, i32 %t734, i32 %t743, ptr %t744, i1 false, i1 false)
  store i32 %t749, ptr %l413
  %t750 = icmp ne i32 %t749, 0
  br i1 %t750, label %bb149, label %ok.751, !prof !99
ok.751:
  br label %bb148
bb148:
  br label %bb151
bb149:
  br label %bb150
bb150:
  br label %bb151
bb151:
  br label %bb152
bb152:
  %t752 = load i64, ptr %l53, !tbaa !24
  %t755 = add i64 %t752, 1
  store i64 %t755, ptr %l53, !tbaa !24
  br label %bb144
bb153:
  %t757 = load ptr, ptr %l0, !tbaa !29
  store ptr %t757, ptr %l417, !tbaa !29
  %t758 = load ptr, ptr %l0, !tbaa !29
  %t760 = getelementptr %"compiler/generic:Program", ptr %t758, i32 0, i32 2
  %t761 = load i32, ptr %l46, !tbaa !23
  %t764 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t760, i32 %t761)
  store i32 %t764, ptr %l421
  br label %bb154
bb154:
  %t765 = load ptr, ptr %l0, !tbaa !29
  %t767 = getelementptr %"compiler/generic:Program", ptr %t765, i32 0, i32 2
  %t768 = load i32, ptr %l45, !tbaa !23
  %t771 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t767, i32 %t768)
  store i32 %t771, ptr %l425
  br label %bb155
bb155:
  %t772 = load ptr, ptr %l3, !tbaa !29
  %t773 = load ptr, ptr %l417, !tbaa !29
  %t774 = load i32, ptr %l421, !tbaa !23
  %t775 = load i32, ptr %l425, !tbaa !23
  %t777 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnifyArg(ptr %v0, ptr %v1, ptr %t773, i32 %t774, i32 %t775, ptr %t772, i1 false, i1 false)
  store i32 %t777, ptr %l427
  %t778 = icmp ne i32 %t777, 0
  br i1 %t778, label %bb157, label %ok.779, !prof !99
ok.779:
  br label %bb156
bb156:
  br label %bb159
bb157:
  br label %bb158
bb158:
  br label %bb159
bb159:
  %t780 = load ptr, ptr %l0, !tbaa !29
  store ptr %t780, ptr %l428, !tbaa !29
  %t781 = load ptr, ptr %l0, !tbaa !29
  %t783 = getelementptr %"compiler/generic:Program", ptr %t781, i32 0, i32 2
  %t784 = load i32, ptr %l46, !tbaa !23
  %t787 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t783, i32 %t784)
  store i32 %t787, ptr %l432
  br label %bb160
bb160:
  %t788 = load ptr, ptr %l3, !tbaa !29
  %t789 = load ptr, ptr %l428, !tbaa !29
  %t790 = load i32, ptr %l432, !tbaa !23
  %t792 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eerrsHaveVar(ptr %v0, ptr %v1, ptr %t789, i32 %t790, ptr %t788)
  store i1 %t792, ptr %l434
  br label %bb161
bb161:
  %t793 = load i1, ptr %l434, !tbaa !21
  br i1 %t793, label %bb162, label %bb163
bb162:
  %t794 = load ptr, ptr %l0, !tbaa !29
  store ptr %t794, ptr %l435, !tbaa !29
  %t795 = load ptr, ptr %l0, !tbaa !29
  %t797 = getelementptr %"compiler/generic:Program", ptr %t795, i32 0, i32 2
  %t798 = load i32, ptr %l46, !tbaa !23
  %t801 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t797, i32 %t798)
  store i32 %t801, ptr %l439
  br label %bb164
bb163:
  br label %bb170
bb164:
  %t802 = load ptr, ptr %l0, !tbaa !29
  %t804 = getelementptr %"compiler/generic:Program", ptr %t802, i32 0, i32 2
  %t805 = load i32, ptr %l45, !tbaa !23
  %t808 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t804, i32 %t805)
  store i32 %t808, ptr %l443
  br label %bb165
bb165:
  %t809 = load ptr, ptr %l3, !tbaa !29
  %t810 = load ptr, ptr %l435, !tbaa !29
  %t811 = load i32, ptr %l439, !tbaa !23
  %t812 = load i32, ptr %l443, !tbaa !23
  %t814 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunifyErrs(ptr %v0, ptr %v1, ptr %t810, i32 %t811, i32 %t812, ptr %t809)
  store i32 %t814, ptr %l445
  %t815 = icmp ne i32 %t814, 0
  br i1 %t815, label %bb167, label %ok.816, !prof !99
ok.816:
  br label %bb166
bb166:
  br label %bb169
bb167:
  br label %bb168
bb168:
  br label %bb169
bb169:
  br label %bb170
bb170:
  call void @__olang_scope_close(ptr %s25)
  br label %bb171
bb171:
  %t817 = load i64, ptr %l41, !tbaa !24
  %t820 = add i64 %t817, 1
  store i64 %t820, ptr %l41, !tbaa !24
  br label %bb110
bb172:
  %t822 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t823 = load ptr, ptr %l3, !tbaa !29
  %t826 = call i64 @compiler_2fgeneric_2echangedVals(ptr %s0, ptr %v1, { i64, ptr } %t822, ptr %t823)
  store i64 %t826, ptr %l451
  br label %bb173
bb173:
  call void @__olang_scope_close(ptr %s0)
  %t827 = load i64, ptr %l451, !tbaa !24
  store i64 %t827, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunifyKind(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, i32 %a3, ptr %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca ptr
  %l15 = alloca i32
  %l19 = alloca i32
  %l22 = alloca ptr
  %l26 = alloca ptr
  %l30 = alloca i32
  %l34 = alloca i32
  %l37 = alloca i32
  %l39 = alloca ptr
  %l45 = alloca ptr
  %l49 = alloca i32
  %l53 = alloca i32
  %l56 = alloca i32
  %l58 = alloca ptr
  %l62 = alloca ptr
  %l66 = alloca i32
  %l70 = alloca i32
  %l73 = alloca i32
  %l75 = alloca ptr
  %l81 = alloca ptr
  %l85 = alloca i32
  %l89 = alloca i32
  %l92 = alloca i32
  %l94 = alloca ptr
  %l100 = alloca ptr
  %l104 = alloca i32
  %l108 = alloca i32
  %l110 = alloca i32
  %l112 = alloca ptr
  %l116 = alloca ptr
  %l120 = alloca i32
  %l124 = alloca i32
  %l126 = alloca i32
  %l128 = alloca ptr
  %l132 = alloca ptr
  %l136 = alloca i32
  %l140 = alloca i32
  %l142 = alloca i32
  %l144 = alloca ptr
  %l150 = alloca ptr
  %l154 = alloca i32
  %l158 = alloca i32
  %l160 = alloca i32
  %l162 = alloca ptr
  %l170 = alloca ptr
  %l174 = alloca i32
  %l178 = alloca i32
  %l180 = alloca i32
  %l182 = alloca ptr
  %l191 = alloca { i64, ptr }
  %l192 = alloca ptr
  %l196 = alloca { i64, ptr }
  %l198 = alloca i1
  %l201 = alloca ptr
  %l205 = alloca ptr
  %l209 = alloca i32
  %l213 = alloca i32
  %l215 = alloca i32
  %l217 = alloca ptr
  %l223 = alloca ptr
  %l227 = alloca i32
  %l231 = alloca i32
  %l234 = alloca i32
  %l236 = alloca ptr
  %l241 = alloca ptr
  %l245 = alloca ptr
  %s18 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  store ptr %a4, ptr %l4
  store i1 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t2, i32 0, i32 11
  %t4 = load i64, ptr %t3, !tbaa !24
  %t7 = add i64 %t4, 1
  %t9 = load ptr, ptr %l6, !tbaa !29
  %t10 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 11
  store i64 %t7, ptr %t10, !tbaa !24
  %t11 = load i32, ptr %l1, !range !{i32 0, i32 33}
  %t13 = trunc i64 18 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb14
bb3:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %l2, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l15
  br label %bb4
bb4:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 2
  %t26 = load i32, ptr %l3, !tbaa !23
  %t29 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t25, i32 %t26)
  store i32 %t29, ptr %l19
  br label %bb5
bb5:
  %t30 = load i32, ptr %l15, !tbaa !23
  %t31 = load i32, ptr %l19, !tbaa !23
  %t32 = icmp ne i32 %t30, %t31
  br i1 %t32, label %bb6, label %bb7
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l22, !tbaa !29
  %t35 = load ptr, ptr %l22, !tbaa !29
  %t36 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 11
  %t37 = load i64, ptr %t36, !tbaa !24
  %t40 = sub i64 %t37, 1
  %t42 = load ptr, ptr %l22, !tbaa !29
  %t43 = getelementptr %"compiler/generic:Program", ptr %t42, i32 0, i32 11
  store i64 %t40, ptr %t43, !tbaa !24
  store i32 65536, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l26, !tbaa !29
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/generic:Program", ptr %t46, i32 0, i32 2
  %t49 = load i32, ptr %l2, !tbaa !23
  %t52 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t48, i32 %t49)
  store i32 %t52, ptr %l30
  br label %bb9
bb9:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 2
  %t56 = load i32, ptr %l3, !tbaa !23
  %t59 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t55, i32 %t56)
  store i32 %t59, ptr %l34
  br label %bb10
bb10:
  %t60 = load ptr, ptr %l4, !tbaa !29
  %t61 = load i1, ptr %l5, !tbaa !21
  %t62 = load ptr, ptr %l26, !tbaa !29
  %t63 = load i32, ptr %l30, !tbaa !23
  %t64 = load i32, ptr %l34, !tbaa !23
  %t67 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunifyLists(ptr %v0, ptr %v1, ptr %t62, i32 %t63, i32 %t64, ptr %t60, i1 %t61)
  store i32 %t67, ptr %l37
  %t68 = icmp ne i32 %t67, 0
  br i1 %t68, label %bb12, label %ok.69, !prof !99
ok.69:
  br label %bb11
bb11:
  br label %bb13
bb12:
  %t70 = load i32, ptr %l37, !tbaa !23
  %t71 = lshr i32 %t70, 16
  %t72 = and i32 %t70, 65535
  %t73 = icmp eq i32 %t71, 1
  %t74 = select i1 %t73, i32 1, i32 0
  %t75 = icmp eq i32 %t70, 0
  %t76 = shl i32 %t74, 16
  %t77 = or i32 %t76, %t72
  %t78 = select i1 %t75, i32 0, i32 %t77
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l39, !tbaa !29
  %t80 = load ptr, ptr %l39, !tbaa !29
  %t81 = getelementptr %"compiler/generic:Program", ptr %t80, i32 0, i32 11
  %t82 = load i64, ptr %t81, !tbaa !24
  %t85 = sub i64 %t82, 1
  %t87 = load ptr, ptr %l39, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t87, i32 0, i32 11
  store i64 %t85, ptr %t88, !tbaa !24
  store i32 %t78, ptr %rv
  br label %ret
bb13:
  br label %bb105
bb14:
  %t90 = load i32, ptr %l1, !range !{i32 0, i32 33}
  %t92 = trunc i64 19 to i32
  %t93 = icmp eq i32 %t90, %t92
  br i1 %t93, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb28
bb17:
  %t95 = load ptr, ptr %l0, !tbaa !29
  store ptr %t95, ptr %l45, !tbaa !29
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/generic:Program", ptr %t96, i32 0, i32 2
  %t99 = load i32, ptr %l2, !tbaa !23
  %t102 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t98, i32 %t99)
  store i32 %t102, ptr %l49
  br label %bb18
bb18:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/generic:Program", ptr %t103, i32 0, i32 2
  %t106 = load i32, ptr %l3, !tbaa !23
  %t109 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t105, i32 %t106)
  store i32 %t109, ptr %l53
  br label %bb19
bb19:
  %t110 = load ptr, ptr %l4, !tbaa !29
  %t111 = load i1, ptr %l5, !tbaa !21
  %t112 = load ptr, ptr %l45, !tbaa !29
  %t113 = load i32, ptr %l49, !tbaa !23
  %t114 = load i32, ptr %l53, !tbaa !23
  %t117 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnify(ptr %v0, ptr %v1, ptr %t112, i32 %t113, i32 %t114, ptr %t110, i1 false, i1 %t111)
  store i32 %t117, ptr %l56
  %t118 = icmp ne i32 %t117, 0
  br i1 %t118, label %bb21, label %ok.119, !prof !99
ok.119:
  br label %bb20
bb20:
  br label %bb22
bb21:
  %t120 = load i32, ptr %l56, !tbaa !23
  %t121 = lshr i32 %t120, 16
  %t122 = and i32 %t120, 65535
  %t123 = icmp eq i32 %t121, 1
  %t124 = select i1 %t123, i32 1, i32 0
  %t125 = icmp eq i32 %t120, 0
  %t126 = shl i32 %t124, 16
  %t127 = or i32 %t126, %t122
  %t128 = select i1 %t125, i32 0, i32 %t127
  %t129 = load ptr, ptr %l0, !tbaa !29
  store ptr %t129, ptr %l58, !tbaa !29
  %t130 = load ptr, ptr %l58, !tbaa !29
  %t131 = getelementptr %"compiler/generic:Program", ptr %t130, i32 0, i32 11
  %t132 = load i64, ptr %t131, !tbaa !24
  %t135 = sub i64 %t132, 1
  %t137 = load ptr, ptr %l58, !tbaa !29
  %t138 = getelementptr %"compiler/generic:Program", ptr %t137, i32 0, i32 11
  store i64 %t135, ptr %t138, !tbaa !24
  store i32 %t128, ptr %rv
  br label %ret
bb22:
  %t140 = load ptr, ptr %l0, !tbaa !29
  store ptr %t140, ptr %l62, !tbaa !29
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/generic:Program", ptr %t141, i32 0, i32 2
  %t144 = load i32, ptr %l2, !tbaa !23
  %t147 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t143, i32 %t144)
  store i32 %t147, ptr %l66
  br label %bb23
bb23:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/generic:Program", ptr %t148, i32 0, i32 2
  %t151 = load i32, ptr %l3, !tbaa !23
  %t154 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t150, i32 %t151)
  store i32 %t154, ptr %l70
  br label %bb24
bb24:
  %t155 = load ptr, ptr %l4, !tbaa !29
  %t156 = load i1, ptr %l5, !tbaa !21
  %t157 = load ptr, ptr %l62, !tbaa !29
  %t158 = load i32, ptr %l66, !tbaa !23
  %t159 = load i32, ptr %l70, !tbaa !23
  %t162 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnify(ptr %v0, ptr %v1, ptr %t157, i32 %t158, i32 %t159, ptr %t155, i1 false, i1 %t156)
  store i32 %t162, ptr %l73
  %t163 = icmp ne i32 %t162, 0
  br i1 %t163, label %bb26, label %ok.164, !prof !99
ok.164:
  br label %bb25
bb25:
  br label %bb27
bb26:
  %t165 = load i32, ptr %l73, !tbaa !23
  %t166 = lshr i32 %t165, 16
  %t167 = and i32 %t165, 65535
  %t168 = icmp eq i32 %t166, 1
  %t169 = select i1 %t168, i32 1, i32 0
  %t170 = icmp eq i32 %t165, 0
  %t171 = shl i32 %t169, 16
  %t172 = or i32 %t171, %t167
  %t173 = select i1 %t170, i32 0, i32 %t172
  %t174 = load ptr, ptr %l0, !tbaa !29
  store ptr %t174, ptr %l75, !tbaa !29
  %t175 = load ptr, ptr %l75, !tbaa !29
  %t176 = getelementptr %"compiler/generic:Program", ptr %t175, i32 0, i32 11
  %t177 = load i64, ptr %t176, !tbaa !24
  %t180 = sub i64 %t177, 1
  %t182 = load ptr, ptr %l75, !tbaa !29
  %t183 = getelementptr %"compiler/generic:Program", ptr %t182, i32 0, i32 11
  store i64 %t180, ptr %t183, !tbaa !24
  store i32 %t173, ptr %rv
  br label %ret
bb27:
  br label %bb105
bb28:
  %t185 = load i32, ptr %l1, !range !{i32 0, i32 33}
  %t187 = trunc i64 20 to i32
  %t188 = icmp eq i32 %t185, %t187
  br i1 %t188, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb37
bb31:
  %t190 = load ptr, ptr %l0, !tbaa !29
  store ptr %t190, ptr %l81, !tbaa !29
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = getelementptr %"compiler/generic:Program", ptr %t191, i32 0, i32 2
  %t194 = load i32, ptr %l2, !tbaa !23
  %t197 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t193, i32 %t194)
  store i32 %t197, ptr %l85
  br label %bb32
bb32:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/generic:Program", ptr %t198, i32 0, i32 2
  %t201 = load i32, ptr %l3, !tbaa !23
  %t204 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t200, i32 %t201)
  store i32 %t204, ptr %l89
  br label %bb33
bb33:
  %t205 = load ptr, ptr %l4, !tbaa !29
  %t206 = load i1, ptr %l5, !tbaa !21
  %t207 = load ptr, ptr %l81, !tbaa !29
  %t208 = load i32, ptr %l85, !tbaa !23
  %t209 = load i32, ptr %l89, !tbaa !23
  %t212 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnify(ptr %v0, ptr %v1, ptr %t207, i32 %t208, i32 %t209, ptr %t205, i1 false, i1 %t206)
  store i32 %t212, ptr %l92
  %t213 = icmp ne i32 %t212, 0
  br i1 %t213, label %bb35, label %ok.214, !prof !99
ok.214:
  br label %bb34
bb34:
  br label %bb36
bb35:
  %t215 = load i32, ptr %l92, !tbaa !23
  %t216 = lshr i32 %t215, 16
  %t217 = and i32 %t215, 65535
  %t218 = icmp eq i32 %t216, 1
  %t219 = select i1 %t218, i32 1, i32 0
  %t220 = icmp eq i32 %t215, 0
  %t221 = shl i32 %t219, 16
  %t222 = or i32 %t221, %t217
  %t223 = select i1 %t220, i32 0, i32 %t222
  %t224 = load ptr, ptr %l0, !tbaa !29
  store ptr %t224, ptr %l94, !tbaa !29
  %t225 = load ptr, ptr %l94, !tbaa !29
  %t226 = getelementptr %"compiler/generic:Program", ptr %t225, i32 0, i32 11
  %t227 = load i64, ptr %t226, !tbaa !24
  %t230 = sub i64 %t227, 1
  %t232 = load ptr, ptr %l94, !tbaa !29
  %t233 = getelementptr %"compiler/generic:Program", ptr %t232, i32 0, i32 11
  store i64 %t230, ptr %t233, !tbaa !24
  store i32 %t223, ptr %rv
  br label %ret
bb36:
  br label %bb105
bb37:
  %t235 = load i32, ptr %l1, !range !{i32 0, i32 33}
  %t237 = trunc i64 21 to i32
  %t238 = icmp eq i32 %t235, %t237
  br i1 %t238, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb56
bb40:
  %t240 = load ptr, ptr %l0, !tbaa !29
  store ptr %t240, ptr %l100, !tbaa !29
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr %"compiler/generic:Program", ptr %t241, i32 0, i32 2
  %t244 = load i32, ptr %l2, !tbaa !23
  %t247 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t243, i32 %t244)
  store i32 %t247, ptr %l104
  br label %bb41
bb41:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t250 = getelementptr %"compiler/generic:Program", ptr %t248, i32 0, i32 2
  %t251 = load i32, ptr %l3, !tbaa !23
  %t254 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t250, i32 %t251)
  store i32 %t254, ptr %l108
  br label %bb42
bb42:
  %t255 = load ptr, ptr %l4, !tbaa !29
  %t256 = load ptr, ptr %l100, !tbaa !29
  %t257 = load i32, ptr %l104, !tbaa !23
  %t258 = load i32, ptr %l108, !tbaa !23
  %t260 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunifyLists(ptr %v0, ptr %v1, ptr %t256, i32 %t257, i32 %t258, ptr %t255, i1 false)
  store i32 %t260, ptr %l110
  %t261 = icmp ne i32 %t260, 0
  br i1 %t261, label %bb44, label %ok.262, !prof !99
ok.262:
  br label %bb43
bb43:
  br label %bb45
bb44:
  %t263 = load i32, ptr %l110, !tbaa !23
  %t264 = lshr i32 %t263, 16
  %t265 = and i32 %t263, 65535
  %t266 = icmp eq i32 %t264, 1
  %t267 = select i1 %t266, i32 1, i32 0
  %t268 = icmp eq i32 %t263, 0
  %t269 = shl i32 %t267, 16
  %t270 = or i32 %t269, %t265
  %t271 = select i1 %t268, i32 0, i32 %t270
  %t272 = load ptr, ptr %l0, !tbaa !29
  store ptr %t272, ptr %l112, !tbaa !29
  %t273 = load ptr, ptr %l112, !tbaa !29
  %t274 = getelementptr %"compiler/generic:Program", ptr %t273, i32 0, i32 11
  %t275 = load i64, ptr %t274, !tbaa !24
  %t278 = sub i64 %t275, 1
  %t280 = load ptr, ptr %l112, !tbaa !29
  %t281 = getelementptr %"compiler/generic:Program", ptr %t280, i32 0, i32 11
  store i64 %t278, ptr %t281, !tbaa !24
  store i32 %t271, ptr %rv
  br label %ret
bb45:
  %t283 = load ptr, ptr %l0, !tbaa !29
  store ptr %t283, ptr %l116, !tbaa !29
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t286 = getelementptr %"compiler/generic:Program", ptr %t284, i32 0, i32 2
  %t287 = load i32, ptr %l2, !tbaa !23
  %t290 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t286, i32 %t287)
  store i32 %t290, ptr %l120
  br label %bb46
bb46:
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t293 = getelementptr %"compiler/generic:Program", ptr %t291, i32 0, i32 2
  %t294 = load i32, ptr %l3, !tbaa !23
  %t297 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t293, i32 %t294)
  store i32 %t297, ptr %l124
  br label %bb47
bb47:
  %t298 = load ptr, ptr %l4, !tbaa !29
  %t299 = load ptr, ptr %l116, !tbaa !29
  %t300 = load i32, ptr %l120, !tbaa !23
  %t301 = load i32, ptr %l124, !tbaa !23
  %t303 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnify(ptr %v0, ptr %v1, ptr %t299, i32 %t300, i32 %t301, ptr %t298, i1 false, i1 false)
  store i32 %t303, ptr %l126
  %t304 = icmp ne i32 %t303, 0
  br i1 %t304, label %bb49, label %ok.305, !prof !99
ok.305:
  br label %bb48
bb48:
  br label %bb50
bb49:
  %t306 = load i32, ptr %l126, !tbaa !23
  %t307 = lshr i32 %t306, 16
  %t308 = and i32 %t306, 65535
  %t309 = icmp eq i32 %t307, 1
  %t310 = select i1 %t309, i32 1, i32 0
  %t311 = icmp eq i32 %t306, 0
  %t312 = shl i32 %t310, 16
  %t313 = or i32 %t312, %t308
  %t314 = select i1 %t311, i32 0, i32 %t313
  %t315 = load ptr, ptr %l0, !tbaa !29
  store ptr %t315, ptr %l128, !tbaa !29
  %t316 = load ptr, ptr %l128, !tbaa !29
  %t317 = getelementptr %"compiler/generic:Program", ptr %t316, i32 0, i32 11
  %t318 = load i64, ptr %t317, !tbaa !24
  %t321 = sub i64 %t318, 1
  %t323 = load ptr, ptr %l128, !tbaa !29
  %t324 = getelementptr %"compiler/generic:Program", ptr %t323, i32 0, i32 11
  store i64 %t321, ptr %t324, !tbaa !24
  store i32 %t314, ptr %rv
  br label %ret
bb50:
  %t326 = load ptr, ptr %l0, !tbaa !29
  store ptr %t326, ptr %l132, !tbaa !29
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t329 = getelementptr %"compiler/generic:Program", ptr %t327, i32 0, i32 2
  %t330 = load i32, ptr %l2, !tbaa !23
  %t333 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t329, i32 %t330)
  store i32 %t333, ptr %l136
  br label %bb51
bb51:
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t336 = getelementptr %"compiler/generic:Program", ptr %t334, i32 0, i32 2
  %t337 = load i32, ptr %l3, !tbaa !23
  %t340 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t336, i32 %t337)
  store i32 %t340, ptr %l140
  br label %bb52
bb52:
  %t341 = load ptr, ptr %l4, !tbaa !29
  %t342 = load ptr, ptr %l132, !tbaa !29
  %t343 = load i32, ptr %l136, !tbaa !23
  %t344 = load i32, ptr %l140, !tbaa !23
  %t346 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunifyErrs(ptr %v0, ptr %v1, ptr %t342, i32 %t343, i32 %t344, ptr %t341)
  store i32 %t346, ptr %l142
  %t347 = icmp ne i32 %t346, 0
  br i1 %t347, label %bb54, label %ok.348, !prof !99
ok.348:
  br label %bb53
bb53:
  br label %bb55
bb54:
  %t349 = load i32, ptr %l142, !tbaa !23
  %t350 = lshr i32 %t349, 16
  %t351 = and i32 %t349, 65535
  %t352 = icmp eq i32 %t350, 1
  %t353 = select i1 %t352, i32 1, i32 0
  %t354 = icmp eq i32 %t349, 0
  %t355 = shl i32 %t353, 16
  %t356 = or i32 %t355, %t351
  %t357 = select i1 %t354, i32 0, i32 %t356
  %t358 = load ptr, ptr %l0, !tbaa !29
  store ptr %t358, ptr %l144, !tbaa !29
  %t359 = load ptr, ptr %l144, !tbaa !29
  %t360 = getelementptr %"compiler/generic:Program", ptr %t359, i32 0, i32 11
  %t361 = load i64, ptr %t360, !tbaa !24
  %t364 = sub i64 %t361, 1
  %t366 = load ptr, ptr %l144, !tbaa !29
  %t367 = getelementptr %"compiler/generic:Program", ptr %t366, i32 0, i32 11
  store i64 %t364, ptr %t367, !tbaa !24
  store i32 %t357, ptr %rv
  br label %ret
bb55:
  br label %bb105
bb56:
  %t369 = load i32, ptr %l1, !range !{i32 0, i32 33}
  %t371 = trunc i64 30 to i32
  %t372 = icmp eq i32 %t369, %t371
  br i1 %t372, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb65
bb59:
  %t374 = load ptr, ptr %l0, !tbaa !29
  store ptr %t374, ptr %l150, !tbaa !29
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t377 = getelementptr %"compiler/generic:Program", ptr %t375, i32 0, i32 2
  %t378 = load i32, ptr %l2, !tbaa !23
  %t381 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %t377, i32 %t378)
  store i32 %t381, ptr %l154
  br label %bb60
bb60:
  %t382 = load ptr, ptr %l0, !tbaa !29
  %t384 = getelementptr %"compiler/generic:Program", ptr %t382, i32 0, i32 2
  %t385 = load i32, ptr %l3, !tbaa !23
  %t388 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %t384, i32 %t385)
  store i32 %t388, ptr %l158
  br label %bb61
bb61:
  %t389 = load ptr, ptr %l4, !tbaa !29
  %t390 = load ptr, ptr %l150, !tbaa !29
  %t391 = load i32, ptr %l154, !tbaa !23
  %t392 = load i32, ptr %l158, !tbaa !23
  %t394 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunifyErrs(ptr %v0, ptr %v1, ptr %t390, i32 %t391, i32 %t392, ptr %t389)
  store i32 %t394, ptr %l160
  %t395 = icmp ne i32 %t394, 0
  br i1 %t395, label %bb63, label %ok.396, !prof !99
ok.396:
  br label %bb62
bb62:
  br label %bb64
bb63:
  %t397 = load i32, ptr %l160, !tbaa !23
  %t398 = lshr i32 %t397, 16
  %t399 = and i32 %t397, 65535
  %t400 = icmp eq i32 %t398, 1
  %t401 = select i1 %t400, i32 1, i32 0
  %t402 = icmp eq i32 %t397, 0
  %t403 = shl i32 %t401, 16
  %t404 = or i32 %t403, %t399
  %t405 = select i1 %t402, i32 0, i32 %t404
  %t406 = load ptr, ptr %l0, !tbaa !29
  store ptr %t406, ptr %l162, !tbaa !29
  %t407 = load ptr, ptr %l162, !tbaa !29
  %t408 = getelementptr %"compiler/generic:Program", ptr %t407, i32 0, i32 11
  %t409 = load i64, ptr %t408, !tbaa !24
  %t412 = sub i64 %t409, 1
  %t414 = load ptr, ptr %l162, !tbaa !29
  %t415 = getelementptr %"compiler/generic:Program", ptr %t414, i32 0, i32 11
  store i64 %t412, ptr %t415, !tbaa !24
  store i32 %t405, ptr %rv
  br label %ret
bb64:
  br label %bb105
bb65:
  %t417 = load i32, ptr %l1, !range !{i32 0, i32 33}
  %t419 = trunc i64 22 to i32
  %t420 = icmp eq i32 %t417, %t419
  br i1 %t420, label %bb66, label %bb67
bb66:
  br label %bb70
bb67:
  %t422 = load i32, ptr %l1, !range !{i32 0, i32 33}
  %t424 = trunc i64 23 to i32
  %t425 = icmp eq i32 %t422, %t424
  br i1 %t425, label %bb68, label %bb69
bb68:
  br label %bb70
bb69:
  br label %bb76
bb70:
  %t427 = load ptr, ptr %l0, !tbaa !29
  store ptr %t427, ptr %l170, !tbaa !29
  %t428 = load ptr, ptr %l0, !tbaa !29
  %t430 = getelementptr %"compiler/generic:Program", ptr %t428, i32 0, i32 2
  %t431 = load i32, ptr %l2, !tbaa !23
  %t434 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t430, i32 %t431)
  store i32 %t434, ptr %l174
  br label %bb71
bb71:
  %t435 = load ptr, ptr %l0, !tbaa !29
  %t437 = getelementptr %"compiler/generic:Program", ptr %t435, i32 0, i32 2
  %t438 = load i32, ptr %l3, !tbaa !23
  %t441 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t437, i32 %t438)
  store i32 %t441, ptr %l178
  br label %bb72
bb72:
  %t442 = load ptr, ptr %l4, !tbaa !29
  %t443 = load ptr, ptr %l170, !tbaa !29
  %t444 = load i32, ptr %l174, !tbaa !23
  %t445 = load i32, ptr %l178, !tbaa !23
  %t447 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunifyLists(ptr %v0, ptr %v1, ptr %t443, i32 %t444, i32 %t445, ptr %t442, i1 false)
  store i32 %t447, ptr %l180
  %t448 = icmp ne i32 %t447, 0
  br i1 %t448, label %bb74, label %ok.449, !prof !99
ok.449:
  br label %bb73
bb73:
  br label %bb75
bb74:
  %t450 = load i32, ptr %l180, !tbaa !23
  %t451 = lshr i32 %t450, 16
  %t452 = and i32 %t450, 65535
  %t453 = icmp eq i32 %t451, 1
  %t454 = select i1 %t453, i32 1, i32 0
  %t455 = icmp eq i32 %t450, 0
  %t456 = shl i32 %t454, 16
  %t457 = or i32 %t456, %t452
  %t458 = select i1 %t455, i32 0, i32 %t457
  %t459 = load ptr, ptr %l0, !tbaa !29
  store ptr %t459, ptr %l182, !tbaa !29
  %t460 = load ptr, ptr %l182, !tbaa !29
  %t461 = getelementptr %"compiler/generic:Program", ptr %t460, i32 0, i32 11
  %t462 = load i64, ptr %t461, !tbaa !24
  %t465 = sub i64 %t462, 1
  %t467 = load ptr, ptr %l182, !tbaa !29
  %t468 = getelementptr %"compiler/generic:Program", ptr %t467, i32 0, i32 11
  store i64 %t465, ptr %t468, !tbaa !24
  store i32 %t458, ptr %rv
  br label %ret
bb75:
  br label %bb105
bb76:
  %t470 = load i32, ptr %l1, !range !{i32 0, i32 33}
  %t472 = trunc i64 24 to i32
  %t473 = icmp eq i32 %t470, %t472
  br i1 %t473, label %bb77, label %bb78
bb77:
  br label %bb79
bb78:
  br label %bb91
bb79:
  store %olang.scope zeroinitializer, ptr %s18
  %t475 = load ptr, ptr %l0, !tbaa !29
  %t477 = getelementptr %"compiler/generic:Program", ptr %t475, i32 0, i32 2
  %t478 = load i32, ptr %l2, !tbaa !23
  %t481 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeNames(ptr %v0, ptr %s18, ptr %t477, i32 %t478)
  store { i64, ptr } %t481, ptr %l191
  br label %bb80
bb80:
  store ptr %l191, ptr %l192
  %t482 = load ptr, ptr %l0, !tbaa !29
  %t484 = getelementptr %"compiler/generic:Program", ptr %t482, i32 0, i32 2
  %t485 = load i32, ptr %l3, !tbaa !23
  %t488 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeNames(ptr %v0, ptr %s18, ptr %t484, i32 %t485)
  store { i64, ptr } %t488, ptr %l196
  br label %bb81
bb81:
  %t489 = load ptr, ptr %l192
  %t491 = call i1 @olang_2emir_2eHelperKind_2eEqual_2eArray_3ccompiler_2fsource_3aNameId_3e_26(ptr %t489, ptr %l196)
  store i1 %t491, ptr %l198
  br label %bb82
bb82:
  %t492 = load i1, ptr %l198, !tbaa !21
  %t493 = xor i1 %t492, true
  br i1 %t493, label %bb83, label %bb84
bb83:
  call void @__olang_scope_close(ptr %s18)
  %t495 = load ptr, ptr %l0, !tbaa !29
  store ptr %t495, ptr %l201, !tbaa !29
  %t496 = load ptr, ptr %l201, !tbaa !29
  %t497 = getelementptr %"compiler/generic:Program", ptr %t496, i32 0, i32 11
  %t498 = load i64, ptr %t497, !tbaa !24
  %t501 = sub i64 %t498, 1
  %t503 = load ptr, ptr %l201, !tbaa !29
  %t504 = getelementptr %"compiler/generic:Program", ptr %t503, i32 0, i32 11
  store i64 %t501, ptr %t504, !tbaa !24
  store i32 65536, ptr %rv
  br label %ret
bb84:
  br label %bb85
bb85:
  %t506 = load ptr, ptr %l0, !tbaa !29
  store ptr %t506, ptr %l205, !tbaa !29
  %t507 = load ptr, ptr %l0, !tbaa !29
  %t509 = getelementptr %"compiler/generic:Program", ptr %t507, i32 0, i32 2
  %t510 = load i32, ptr %l2, !tbaa !23
  %t513 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t509, i32 %t510)
  store i32 %t513, ptr %l209
  br label %bb86
bb86:
  %t514 = load ptr, ptr %l0, !tbaa !29
  %t516 = getelementptr %"compiler/generic:Program", ptr %t514, i32 0, i32 2
  %t517 = load i32, ptr %l3, !tbaa !23
  %t520 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t516, i32 %t517)
  store i32 %t520, ptr %l213
  br label %bb87
bb87:
  %t521 = load ptr, ptr %l4, !tbaa !29
  %t522 = load ptr, ptr %l205, !tbaa !29
  %t523 = load i32, ptr %l209, !tbaa !23
  %t524 = load i32, ptr %l213, !tbaa !23
  %t526 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunifyLists(ptr %v0, ptr %v1, ptr %t522, i32 %t523, i32 %t524, ptr %t521, i1 false)
  store i32 %t526, ptr %l215
  %t527 = icmp ne i32 %t526, 0
  br i1 %t527, label %bb89, label %ok.528, !prof !99
ok.528:
  br label %bb88
bb88:
  br label %bb90
bb89:
  %t529 = load i32, ptr %l215, !tbaa !23
  %t530 = lshr i32 %t529, 16
  %t531 = and i32 %t529, 65535
  %t532 = icmp eq i32 %t530, 1
  %t533 = select i1 %t532, i32 1, i32 0
  %t534 = icmp eq i32 %t529, 0
  %t535 = shl i32 %t533, 16
  %t536 = or i32 %t535, %t531
  %t537 = select i1 %t534, i32 0, i32 %t536
  call void @__olang_scope_close(ptr %s18)
  %t538 = load ptr, ptr %l0, !tbaa !29
  store ptr %t538, ptr %l217, !tbaa !29
  %t539 = load ptr, ptr %l217, !tbaa !29
  %t540 = getelementptr %"compiler/generic:Program", ptr %t539, i32 0, i32 11
  %t541 = load i64, ptr %t540, !tbaa !24
  %t544 = sub i64 %t541, 1
  %t546 = load ptr, ptr %l217, !tbaa !29
  %t547 = getelementptr %"compiler/generic:Program", ptr %t546, i32 0, i32 11
  store i64 %t544, ptr %t547, !tbaa !24
  store i32 %t537, ptr %rv
  br label %ret
bb90:
  call void @__olang_scope_close(ptr %s18)
  br label %bb105
bb91:
  %t549 = load i32, ptr %l1, !range !{i32 0, i32 33}
  %t551 = trunc i64 29 to i32
  %t552 = icmp eq i32 %t549, %t551
  br i1 %t552, label %bb92, label %bb93
bb92:
  br label %bb94
bb93:
  br label %bb100
bb94:
  %t554 = load ptr, ptr %l0, !tbaa !29
  store ptr %t554, ptr %l223, !tbaa !29
  %t555 = load ptr, ptr %l0, !tbaa !29
  %t557 = getelementptr %"compiler/generic:Program", ptr %t555, i32 0, i32 2
  %t558 = load i32, ptr %l2, !tbaa !23
  %t561 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t557, i32 %t558)
  store i32 %t561, ptr %l227
  br label %bb95
bb95:
  %t562 = load ptr, ptr %l0, !tbaa !29
  %t564 = getelementptr %"compiler/generic:Program", ptr %t562, i32 0, i32 2
  %t565 = load i32, ptr %l3, !tbaa !23
  %t568 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t564, i32 %t565)
  store i32 %t568, ptr %l231
  br label %bb96
bb96:
  %t569 = load ptr, ptr %l4, !tbaa !29
  %t570 = load i1, ptr %l5, !tbaa !21
  %t571 = load ptr, ptr %l223, !tbaa !29
  %t572 = load i32, ptr %l227, !tbaa !23
  %t573 = load i32, ptr %l231, !tbaa !23
  %t576 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnify(ptr %v0, ptr %v1, ptr %t571, i32 %t572, i32 %t573, ptr %t569, i1 false, i1 %t570)
  store i32 %t576, ptr %l234
  %t577 = icmp ne i32 %t576, 0
  br i1 %t577, label %bb98, label %ok.578, !prof !99
ok.578:
  br label %bb97
bb97:
  br label %bb99
bb98:
  %t579 = load i32, ptr %l234, !tbaa !23
  %t580 = lshr i32 %t579, 16
  %t581 = and i32 %t579, 65535
  %t582 = icmp eq i32 %t580, 1
  %t583 = select i1 %t582, i32 1, i32 0
  %t584 = icmp eq i32 %t579, 0
  %t585 = shl i32 %t583, 16
  %t586 = or i32 %t585, %t581
  %t587 = select i1 %t584, i32 0, i32 %t586
  %t588 = load ptr, ptr %l0, !tbaa !29
  store ptr %t588, ptr %l236, !tbaa !29
  %t589 = load ptr, ptr %l236, !tbaa !29
  %t590 = getelementptr %"compiler/generic:Program", ptr %t589, i32 0, i32 11
  %t591 = load i64, ptr %t590, !tbaa !24
  %t594 = sub i64 %t591, 1
  %t596 = load ptr, ptr %l236, !tbaa !29
  %t597 = getelementptr %"compiler/generic:Program", ptr %t596, i32 0, i32 11
  store i64 %t594, ptr %t597, !tbaa !24
  store i32 %t587, ptr %rv
  br label %ret
bb99:
  br label %bb105
bb100:
  br i1 true, label %bb101, label %bb102
bb101:
  br label %bb103
bb102:
  br label %bb104
bb103:
  %t599 = load ptr, ptr %l0, !tbaa !29
  store ptr %t599, ptr %l241, !tbaa !29
  %t600 = load ptr, ptr %l241, !tbaa !29
  %t601 = getelementptr %"compiler/generic:Program", ptr %t600, i32 0, i32 11
  %t602 = load i64, ptr %t601, !tbaa !24
  %t605 = sub i64 %t602, 1
  %t607 = load ptr, ptr %l241, !tbaa !29
  %t608 = getelementptr %"compiler/generic:Program", ptr %t607, i32 0, i32 11
  store i64 %t605, ptr %t608, !tbaa !24
  store i32 65536, ptr %rv
  br label %ret
bb104:
  call void @__olang_check_failed(ptr @olang_loc_f83e897c6289299d_c5b35c0c7cd0f831)
  unreachable
bb105:
  %t610 = load ptr, ptr %l0, !tbaa !29
  store ptr %t610, ptr %l245, !tbaa !29
  %t611 = load ptr, ptr %l245, !tbaa !29
  %t612 = getelementptr %"compiler/generic:Program", ptr %t611, i32 0, i32 11
  %t613 = load i64, ptr %t612, !tbaa !24
  %t616 = sub i64 %t613, 1
  %t618 = load ptr, ptr %l245, !tbaa !29
  %t619 = getelementptr %"compiler/generic:Program", ptr %t618, i32 0, i32 11
  store i64 %t616, ptr %t619, !tbaa !24
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunsubst(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l24 = alloca i64
  %l27 = alloca i64
  %l45 = alloca { i64, ptr }
  %l55 = alloca i32
  %l62 = alloca i32
  %l68 = alloca i32
  %l72 = alloca ptr
  %l76 = alloca i32
  %l77 = alloca { i64, ptr }
  %l79 = alloca i64
  %l88 = alloca i64
  %l91 = alloca i64
  %l109 = alloca i64
  %l111 = alloca { i64, ptr }
  %l116 = alloca i32
  %l120 = alloca ptr
  %l124 = alloca i32
  %l128 = alloca i32
  %l129 = alloca i32
  %l133 = alloca ptr
  %l134 = alloca ptr
  %l138 = alloca i32
  %l141 = alloca i32
  %l142 = alloca ptr
  %l146 = alloca i32
  %l149 = alloca i32
  %l150 = alloca i32
  %l154 = alloca ptr
  %l155 = alloca ptr
  %l159 = alloca i32
  %l162 = alloca i32
  %l166 = alloca i64
  %l167 = alloca i32
  %l171 = alloca ptr
  %l172 = alloca ptr
  %l176 = alloca i32
  %l179 = alloca i32
  %l180 = alloca i32
  %s5 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l4, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t5 = load i64, ptr %l5, !tbaa !24
  %t6 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l6, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l5, !tbaa !24
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l6, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l6, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l27, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l27, !tbaa !24
  store i64 %t31, ptr %l24, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l24, !tbaa !24
  store i64 %t32, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb7
bb7:
  %t33 = load i64, ptr %l8, !tbaa !24
  %t34 = load i64, ptr %l7, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  br label %bb16
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l4, !tbaa !24
  %t42 = load i64, ptr %l8, !tbaa !24
  %t43 = load i64, ptr %l6, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l9, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t51, ptr %l45, !tbaa !27
  %t52 = load i64, ptr %l9, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i32, ptr %t55, i64 %t52
  %t57 = load i32, ptr %t56, !tbaa !33
  %t58 = load i32, ptr %l1, !tbaa !23
  %t61 = icmp eq i32 %t57, %t58
  br i1 %t61, label %bb11, label %bb12
bb11:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/generic:Program", ptr %t63, i32 0, i32 2
  %t66 = load i64, ptr %l2, !tbaa !24
  %t67 = load i64, ptr %l9, !tbaa !24
  %t68 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eVar(ptr %v0, ptr %t65, i64 %t66, i64 %t67, i64 %t68)
  store i32 %t73, ptr %l55
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t74 = load i32, ptr %l55, !tbaa !23
  store i32 %t74, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t75 = load i64, ptr %l8, !tbaa !24
  %t78 = add i64 %t75, 1
  store i64 %t78, ptr %l8, !tbaa !24
  br label %bb7
bb16:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/generic:Program", ptr %t80, i32 0, i32 2
  %t83 = load i32, ptr %l1, !tbaa !23
  %t86 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t82, i32 %t83)
  store i32 %t86, ptr %l62
  br label %bb17
bb17:
  %t87 = load i32, ptr %l62, !range !{i32 0, i32 33}
  store i32 %t87, ptr %l10
  %t88 = load i32, ptr %l10, !range !{i32 0, i32 33}
  %t90 = trunc i64 18 to i32
  %t91 = icmp eq i32 %t88, %t90
  br i1 %t91, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb47
bb20:
  store %olang.scope zeroinitializer, ptr %s5
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/generic:Program", ptr %t93, i32 0, i32 2
  %t96 = load i32, ptr %l1, !tbaa !23
  %t99 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t95, i32 %t96)
  store i32 %t99, ptr %l68
  br label %bb21
bb21:
  %t100 = load i32, ptr %l68, !tbaa !23
  %t101 = icmp eq i32 %t100, 0
  br i1 %t101, label %bb22, label %bb23
bb22:
  %t103 = load i32, ptr %l1, !tbaa !23
  call void @__olang_scope_close(ptr %s5)
  store i32 %t103, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/generic:Program", ptr %t105, i32 0, i32 2
  store ptr %t107, ptr %l72, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/generic:Program", ptr %t108, i32 0, i32 2
  %t111 = load i32, ptr %l1, !tbaa !23
  %t114 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t110, i32 %t111)
  store i32 %t114, ptr %l76
  br label %bb25
bb25:
  %t115 = load ptr, ptr %l72, !tbaa !29
  %t116 = load i32, ptr %l76, !tbaa !23
  %t117 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t115, i32 %t116)
  store { i64, ptr } %t117, ptr %l77
  br label %bb26
bb26:
  %t118 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t118, ptr %l11, !tbaa !27
  %t119 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t119, 0
  store i64 %t121, ptr %l79, !tbaa !24
  %t122 = load i64, ptr %l79, !tbaa !24
  %t123 = icmp sge i64 %t122, 0
  br i1 %t123, label %bb27, label %bb28
bb27:
  %t125 = load i64, ptr %l79, !tbaa !24
  %t126 = icmp sle i64 %t125, 2305843009213693951
  br i1 %t126, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_dbc69524847f1d49_8831f326edbf0acd)
  unreachable
bb29:
  %t128 = load i64, ptr %l79, !tbaa !24
  %t129 = mul i64 %t128, 4
  %t130 = call ptr @__olang_scope_alloc_zeroed(ptr %s5, i64 %t129)
  %t131 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t130, 1
  store { i64, ptr } %t132, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t134 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t134, 0
  store i64 %t136, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t138 = load i64, ptr %l14, !tbaa !24
  %t139 = load i64, ptr %l13, !tbaa !24
  %t142 = icmp sgt i64 %t138, %t139
  br i1 %t142, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_dbc69524847f1d49_8831f326edbf0acd)
  unreachable
bb31:
  %t144 = load i64, ptr %l15, !tbaa !24
  %t146 = icmp sgt i64 %t144, 0
  br i1 %t146, label %bb33, label %bb34
bb32:
  store i64 0, ptr %l88, !tbaa !24
  br label %bb36
bb33:
  %t148 = load i64, ptr %l14, !tbaa !24
  %t149 = load i64, ptr %l13, !tbaa !24
  %t152 = sub i64 %t148, %t149
  %t153 = load i64, ptr %l15, !tbaa !24
  %t156 = add i64 %t152, %t153
  %t158 = sub i64 %t156, 1
  %t159 = load i64, ptr %l15, !tbaa !24
  %t162 = sdiv i64 %t158, %t159
  store i64 %t162, ptr %l91, !tbaa !24
  br label %bb35
bb34:
  store i64 0, ptr %l91, !tbaa !24
  br label %bb35
bb35:
  %t164 = load i64, ptr %l91, !tbaa !24
  store i64 %t164, ptr %l88, !tbaa !24
  br label %bb36
bb36:
  %t165 = load i64, ptr %l88, !tbaa !24
  store i64 %t165, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb37
bb37:
  %t166 = load i64, ptr %l17, !tbaa !24
  %t167 = load i64, ptr %l16, !tbaa !24
  %t170 = icmp slt i64 %t166, %t167
  %t172 = xor i1 %t170, true
  br i1 %t172, label %bb38, label %bb39
bb38:
  br label %bb43
bb39:
  br label %bb40
bb40:
  %t174 = load i64, ptr %l13, !tbaa !24
  %t175 = load i64, ptr %l17, !tbaa !24
  %t176 = load i64, ptr %l15, !tbaa !24
  %t179 = mul i64 %t175, %t176
  %t182 = add i64 %t174, %t179
  store i64 %t182, ptr %l18, !tbaa !24
  %t184 = load i64, ptr %l18, !tbaa !24
  store i64 %t184, ptr %l109, !tbaa !24
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t186, ptr %l111, !tbaa !27
  %t187 = load i64, ptr %l18, !tbaa !24
  %t189 = getelementptr { i64, ptr }, ptr %l111, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !27
  %t191 = getelementptr i32, ptr %t190, i64 %t187
  %t192 = load i32, ptr %t191, !tbaa !33
  %t193 = load i64, ptr %l2, !tbaa !24
  %t194 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t199 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunsubst(ptr %v0, ptr %v1, ptr %t185, i32 %t192, i64 %t193, { i64, ptr } %t194)
  store i32 %t199, ptr %l116
  br label %bb41
bb41:
  %t200 = load i32, ptr %l116, !tbaa !23
  %t201 = load i64, ptr %l109, !tbaa !24
  %t202 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !27
  %t204 = getelementptr i32, ptr %t203, i64 %t201
  store i32 %t200, ptr %t204, !tbaa !33
  br label %bb42
bb42:
  %t205 = load i64, ptr %l17, !tbaa !24
  %t208 = add i64 %t205, 1
  store i64 %t208, ptr %l17, !tbaa !24
  br label %bb37
bb43:
  %t210 = load ptr, ptr %l0, !tbaa !29
  store ptr %t210, ptr %l120, !tbaa !29
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/generic:Program", ptr %t211, i32 0, i32 2
  %t214 = load i32, ptr %l1, !tbaa !23
  %t217 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t213, i32 %t214)
  store i32 %t217, ptr %l124
  br label %bb44
bb44:
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t220 = getelementptr %"compiler/generic:Program", ptr %t218, i32 0, i32 2
  %t221 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t224 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s5, ptr %t220, { i64, ptr } %t221)
  store i32 %t224, ptr %l128
  br label %bb45
bb45:
  %t225 = load ptr, ptr %l120, !tbaa !29
  %t226 = load i32, ptr %l124, !tbaa !23
  %t227 = load i32, ptr %l128, !tbaa !23
  %t228 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstance(ptr %v0, ptr %t225, i32 %t226, i32 %t227)
  store i32 %t228, ptr %l129
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s5)
  %t229 = load i32, ptr %l129, !tbaa !23
  store i32 %t229, ptr %rv
  br label %ret
bb47:
  %t230 = load i32, ptr %l10, !range !{i32 0, i32 33}
  %t232 = trunc i64 19 to i32
  %t233 = icmp eq i32 %t230, %t232
  br i1 %t233, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb56
bb50:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = getelementptr %"compiler/generic:Program", ptr %t235, i32 0, i32 2
  store ptr %t237, ptr %l133, !tbaa !29
  %t238 = load ptr, ptr %l0, !tbaa !29
  store ptr %t238, ptr %l134, !tbaa !29
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = getelementptr %"compiler/generic:Program", ptr %t239, i32 0, i32 2
  %t242 = load i32, ptr %l1, !tbaa !23
  %t245 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t241, i32 %t242)
  store i32 %t245, ptr %l138
  br label %bb51
bb51:
  %t246 = load i64, ptr %l2, !tbaa !24
  %t247 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t248 = load ptr, ptr %l134, !tbaa !29
  %t249 = load i32, ptr %l138, !tbaa !23
  %t252 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunsubst(ptr %v0, ptr %v1, ptr %t248, i32 %t249, i64 %t246, { i64, ptr } %t247)
  store i32 %t252, ptr %l141
  br label %bb52
bb52:
  %t253 = load ptr, ptr %l0, !tbaa !29
  store ptr %t253, ptr %l142, !tbaa !29
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = getelementptr %"compiler/generic:Program", ptr %t254, i32 0, i32 2
  %t257 = load i32, ptr %l1, !tbaa !23
  %t260 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t256, i32 %t257)
  store i32 %t260, ptr %l146
  br label %bb53
bb53:
  %t261 = load i64, ptr %l2, !tbaa !24
  %t262 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t263 = load ptr, ptr %l142, !tbaa !29
  %t264 = load i32, ptr %l146, !tbaa !23
  %t267 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunsubst(ptr %v0, ptr %v1, ptr %t263, i32 %t264, i64 %t261, { i64, ptr } %t262)
  store i32 %t267, ptr %l149
  br label %bb54
bb54:
  %t268 = load ptr, ptr %l133, !tbaa !29
  %t269 = load i32, ptr %l141, !tbaa !23
  %t270 = load i32, ptr %l149, !tbaa !23
  %t271 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t268, i32 %t269, i32 %t270)
  store i32 %t271, ptr %l150
  br label %bb55
bb55:
  %t272 = load i32, ptr %l150, !tbaa !23
  store i32 %t272, ptr %rv
  br label %ret
bb56:
  %t273 = load i32, ptr %l10, !range !{i32 0, i32 33}
  %t275 = trunc i64 20 to i32
  %t276 = icmp eq i32 %t273, %t275
  br i1 %t276, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb64
bb59:
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t280 = getelementptr %"compiler/generic:Program", ptr %t278, i32 0, i32 2
  store ptr %t280, ptr %l154, !tbaa !29
  %t281 = load ptr, ptr %l0, !tbaa !29
  store ptr %t281, ptr %l155, !tbaa !29
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t284 = getelementptr %"compiler/generic:Program", ptr %t282, i32 0, i32 2
  %t285 = load i32, ptr %l1, !tbaa !23
  %t288 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t284, i32 %t285)
  store i32 %t288, ptr %l159
  br label %bb60
bb60:
  %t289 = load i64, ptr %l2, !tbaa !24
  %t290 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t291 = load ptr, ptr %l155, !tbaa !29
  %t292 = load i32, ptr %l159, !tbaa !23
  %t295 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunsubst(ptr %v0, ptr %v1, ptr %t291, i32 %t292, i64 %t289, { i64, ptr } %t290)
  store i32 %t295, ptr %l162
  br label %bb61
bb61:
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t298 = getelementptr %"compiler/generic:Program", ptr %t296, i32 0, i32 2
  %t299 = load i32, ptr %l1, !tbaa !23
  %t302 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t298, i32 %t299)
  store i64 %t302, ptr %l166
  br label %bb62
bb62:
  %t303 = load ptr, ptr %l154, !tbaa !29
  %t304 = load i32, ptr %l162, !tbaa !23
  %t305 = load i64, ptr %l166, !tbaa !24
  %t306 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t303, i32 %t304, i64 %t305)
  store i32 %t306, ptr %l167
  br label %bb63
bb63:
  %t307 = load i32, ptr %l167, !tbaa !23
  store i32 %t307, ptr %rv
  br label %ret
bb64:
  %t308 = load i32, ptr %l10, !range !{i32 0, i32 33}
  %t310 = trunc i64 29 to i32
  %t311 = icmp eq i32 %t308, %t310
  br i1 %t311, label %bb65, label %bb66
bb65:
  br label %bb67
bb66:
  br label %bb71
bb67:
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t315 = getelementptr %"compiler/generic:Program", ptr %t313, i32 0, i32 2
  store ptr %t315, ptr %l171, !tbaa !29
  %t316 = load ptr, ptr %l0, !tbaa !29
  store ptr %t316, ptr %l172, !tbaa !29
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t319 = getelementptr %"compiler/generic:Program", ptr %t317, i32 0, i32 2
  %t320 = load i32, ptr %l1, !tbaa !23
  %t323 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t319, i32 %t320)
  store i32 %t323, ptr %l176
  br label %bb68
bb68:
  %t324 = load i64, ptr %l2, !tbaa !24
  %t325 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t326 = load ptr, ptr %l172, !tbaa !29
  %t327 = load i32, ptr %l176, !tbaa !23
  %t330 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunsubst(ptr %v0, ptr %v1, ptr %t326, i32 %t327, i64 %t324, { i64, ptr } %t325)
  store i32 %t330, ptr %l179
  br label %bb69
bb69:
  %t331 = load ptr, ptr %l171, !tbaa !29
  %t332 = load i32, ptr %l179, !tbaa !23
  %t333 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAny(ptr %v0, ptr %t331, i32 %t332)
  store i32 %t333, ptr %l180
  br label %bb70
bb70:
  %t334 = load i32, ptr %l180, !tbaa !23
  store i32 %t334, ptr %rv
  br label %ret
bb71:
  br i1 true, label %bb72, label %bb73
bb72:
  br label %bb74
bb73:
  br label %bb75
bb74:
  %t335 = load i32, ptr %l1, !tbaa !23
  store i32 %t335, ptr %rv
  br label %ret
bb75:
  call void @__olang_check_failed(ptr @olang_loc_737134d81da26253_60c38b193f08901f)
  unreachable
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eviewGeneratorOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l17 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca { i64, ptr }
  %l26 = alloca i1
  %l29 = alloca { i64, ptr }
  %l31 = alloca i32
  %l37 = alloca i64
  %l43 = alloca { i64, ptr }
  %l45 = alloca i32
  %l51 = alloca i64
  %l54 = alloca i64
  %l63 = alloca i64
  %l66 = alloca i1
  %l77 = alloca { i64, ptr }
  %l83 = alloca ptr
  %l84 = alloca i32
  %l88 = alloca i32
  %l89 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call { i32, i32 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFindDecl(ptr %v0, ptr %s0, ptr %s0, ptr %t1, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d60, i32 0, i32 1) }, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d61, i32 0, i32 1) })
  %t4 = extractvalue { i32, i32 } %t3, 1
  %t5 = extractvalue { i32, i32 } %t3, 0
  store i32 %t5, ptr %l14
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store i32 %t4, ptr %l13
  br label %bb1
bb1:
  %t8 = load i32, ptr %l13, !tbaa !23
  store i32 %t8, ptr %l11, !tbaa !23
  br label %bb4
bb2:
  br label %bb3
bb3:
  %t9 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t9, ptr %rv
  br label %ret
bb4:
  %t11 = load i32, ptr %l11, !tbaa !23
  store i32 %t11, ptr %l2, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/generic:Program", ptr %t12, i32 0, i32 2
  store ptr %t14, ptr %l17, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t17, i32 %a1)
  store i32 %t21, ptr %l21
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l17, !tbaa !29
  %t23 = load i32, ptr %l21, !tbaa !23
  %t24 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t22, i32 %t23)
  store { i64, ptr } %t24, ptr %l22
  br label %bb6
bb6:
  %t25 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t25, ptr %l3, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  %t30 = icmp eq i64 %t28, 0
  br i1 %t30, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb10
bb8:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  %t35 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t35, ptr %l29, !tbaa !27
  %t36 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr i32, ptr %t37, i64 0
  %t39 = load i32, ptr %t38, !tbaa !33
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t34, i32 %t39)
  store i32 %t42, ptr %l31
  br label %bb9
bb9:
  %t43 = load i32, ptr %l31, !range !{i32 0, i32 33}
  %t45 = trunc i64 20 to i32
  %t46 = icmp eq i32 %t43, %t45
  %t48 = xor i1 %t46, true
  store i1 %t48, ptr %l26, !tbaa !21
  br label %bb10
bb10:
  %t50 = load i1, ptr %l26, !tbaa !21
  br i1 %t50, label %bb11, label %bb12
bb11:
  %t51 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t51, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t53 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 0
  store i64 %t55, ptr %l37, !tbaa !24
  %t56 = load i64, ptr %l37, !tbaa !24
  %t57 = icmp sge i64 %t56, 0
  br i1 %t57, label %bb14, label %bb15
bb14:
  %t59 = load i64, ptr %l37, !tbaa !24
  %t60 = icmp sle i64 %t59, 2305843009213693951
  br i1 %t60, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_6b949e9fdbc9587c_5a8bb2436952ea48)
  unreachable
bb16:
  %t62 = load i64, ptr %l37, !tbaa !24
  %t63 = mul i64 %t62, 4
  %t64 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t63)
  %t65 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t64, 1
  store { i64, ptr } %t66, ptr %l4, !tbaa !27
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/generic:Program", ptr %t68, i32 0, i32 2
  %t71 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t71, ptr %l43, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr i32, ptr %t73, i64 0
  %t75 = load i32, ptr %t74, !tbaa !33
  %t78 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t70, i32 %t75)
  store i32 %t78, ptr %l45
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_6b949e9fdbc9587c_5a8bb2436952ea48)
  unreachable
bb18:
  %t79 = load i32, ptr %l45, !tbaa !23
  %t80 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr i32, ptr %t81, i64 0
  store i32 %t79, ptr %t82, !tbaa !33
  store i64 1, ptr %l5, !tbaa !24
  %t83 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t83, 0
  store i64 %t85, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t87 = load i64, ptr %l6, !tbaa !24
  %t88 = load i64, ptr %l5, !tbaa !24
  %t91 = icmp sgt i64 %t87, %t88
  br i1 %t91, label %bb19, label %bb20
bb19:
  %t93 = load i64, ptr %l7, !tbaa !24
  %t95 = icmp sgt i64 %t93, 0
  br i1 %t95, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb24
bb21:
  %t97 = load i64, ptr %l6, !tbaa !24
  %t98 = load i64, ptr %l5, !tbaa !24
  %t101 = sub i64 %t97, %t98
  %t102 = load i64, ptr %l7, !tbaa !24
  %t105 = add i64 %t101, %t102
  %t107 = sub i64 %t105, 1
  %t108 = load i64, ptr %l7, !tbaa !24
  %t111 = sdiv i64 %t107, %t108
  store i64 %t111, ptr %l54, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb23
bb23:
  %t113 = load i64, ptr %l54, !tbaa !24
  store i64 %t113, ptr %l51, !tbaa !24
  br label %bb24
bb24:
  %t114 = load i64, ptr %l51, !tbaa !24
  store i64 %t114, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  %t115 = load i64, ptr %l8, !tbaa !24
  %t116 = sub i64 %t115, 1
  store i64 %t116, ptr %l63, !tbaa !24
  %t117 = load i64, ptr %l8, !tbaa !24
  %t118 = icmp slt i64 %t117, 2147483648
  %t119 = load i64, ptr %l9, !tbaa !24
  %t120 = icmp sge i64 %t119, 0
  %t123 = and i1 %t118, %t120
  store i1 %t123, ptr %l66, !tbaa !21
  br label %bb25
bb25:
  %t124 = load i64, ptr %l9, !tbaa !24
  %t125 = load i64, ptr %l8, !tbaa !24
  %t128 = icmp slt i64 %t124, %t125
  %t130 = xor i1 %t128, true
  br i1 %t130, label %bb26, label %bb27
bb26:
  br label %bb30
bb27:
  br label %bb28
bb28:
  %t132 = load i64, ptr %l5, !tbaa !24
  %t133 = load i64, ptr %l9, !tbaa !24
  %t134 = load i64, ptr %l7, !tbaa !24
  %t137 = mul i64 %t133, %t134
  %t140 = add i64 %t132, %t137
  store i64 %t140, ptr %l10, !tbaa !24
  %t142 = load i64, ptr %l10, !tbaa !24
  %t143 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t143, ptr %l77, !tbaa !27
  %t144 = load i64, ptr %l10, !tbaa !24
  %t146 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr i32, ptr %t147, i64 %t144
  %t149 = load i32, ptr %t148, !tbaa !33
  %t152 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = getelementptr i32, ptr %t153, i64 %t142
  store i32 %t149, ptr %t154, !tbaa !33
  br label %bb29
bb29:
  %t155 = load i64, ptr %l9, !tbaa !24
  %t158 = add i64 %t155, 1
  store i64 %t158, ptr %l9, !tbaa !24
  br label %bb25
bb30:
  %t160 = load ptr, ptr %l0, !tbaa !29
  store ptr %t160, ptr %l83, !tbaa !29
  %t161 = load i32, ptr %l2, !tbaa !23
  store i32 %t161, ptr %l84, !tbaa !23
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/generic:Program", ptr %t162, i32 0, i32 2
  %t165 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t168 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t164, { i64, ptr } %t165)
  store i32 %t168, ptr %l88
  br label %bb31
bb31:
  %t169 = load ptr, ptr %l83, !tbaa !29
  %t170 = load i32, ptr %l84, !tbaa !23
  %t171 = load i32, ptr %l88, !tbaa !23
  %t172 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstance(ptr %v0, ptr %t169, i32 %t170, i32 %t171)
  store i32 %t172, ptr %l89
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s0)
  %t173 = load i32, ptr %l89, !tbaa !23
  store i32 %t173, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2fgeneric_2egenElemOf(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca %"compiler/generic:genRoots"
  %l8 = alloca i64
  %l10 = alloca i1
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca ptr
  %l27 = alloca ptr
  %l33 = alloca i1
  %l43 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l51 = alloca i1
  %l55 = alloca i64
  %l58 = alloca { i64, ptr }
  %l59 = alloca i64
  %l62 = alloca { i64, ptr }
  %l63 = alloca %"compiler/generic:genRoots"
  %l78 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i1 @compiler_2fgeneric_2eborrowableElem(ptr %v0, ptr %t1)
  store i1 %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load i1, ptr %l10, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t7 = load i64, ptr @G_2ecompiler_2fgeneric_2eGenPerTurn, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t7, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l13
  br label %bb5
bb5:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l1
  %t11 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %l14
  br label %bb6
bb6:
  %t12 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t12, ptr %l2
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/ast:Func", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = icmp eq ptr %t16, null
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb7, label %bb8
bb7:
  store ptr %l1, ptr %l19, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/ast:Func", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = icmp eq ptr %t25, null
  br i1 %t27, label %bb9, label %bb10
bb8:
  br label %bb18
bb9:
  call void @__olang_check_failed(ptr @olang_loc_2a0d238d6764ffeb_7f54c8a7a483f2b7)
  unreachable
bb10:
  br label %bb11
bb11:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/ast:Func", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t35 = getelementptr %"compiler/ast:Param", ptr %t32, i32 0, i32 1
  %t36 = load i32, ptr %t35, !tbaa !23
  %t37 = load ptr, ptr %l19, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %t37, i32 %t36)
  br label %bb12
bb12:
  store ptr %l2, ptr %l27, !tbaa !29
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/ast:Func", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = icmp eq ptr %t42, null
  br i1 %t44, label %bb13, label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_b16df8c761b5d07c_6405a14de8d58098)
  unreachable
bb14:
  br label %bb15
bb15:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/ast:Func", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = call i1 @compiler_2fgeneric_2ebyValueParam(ptr %v0, ptr %t49)
  store i1 %t51, ptr %l33
  br label %bb16
bb16:
  %t52 = load ptr, ptr %l27, !tbaa !29
  %t53 = load i1, ptr %l33, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %s0, ptr %t52, i1 %t53)
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/ast:Func", ptr %t54, i32 0, i32 3
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = getelementptr %"compiler/ast:Sig", ptr %t57, i32 0, i32 0
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !27
  store { i64, ptr } %t60, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t62 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t62, 0
  store i64 %t64, ptr %l5, !tbaa !24
  br label %bb19
bb19:
  %t66 = load i64, ptr %l4, !tbaa !24
  %t67 = load i64, ptr %l5, !tbaa !24
  %t70 = icmp slt i64 %t66, %t67
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb20, label %bb21
bb20:
  br label %bb27
bb21:
  br label %bb22
bb22:
  %t74 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t74, ptr %l43, !tbaa !27
  %t75 = load i64, ptr %l4, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr ptr, ptr %t78, i64 %t75
  %t80 = load ptr, ptr %t79, !tbaa !39
  store ptr %t80, ptr %l6, !tbaa !29
  %t82 = load ptr, ptr %l6, !tbaa !29
  %t84 = getelementptr %"compiler/ast:Param", ptr %t82, i32 0, i32 1
  %t85 = load i32, ptr %t84, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l1, i32 %t85)
  br label %bb23
bb23:
  store ptr %l2, ptr %l49, !tbaa !29
  %t88 = load ptr, ptr %l6, !tbaa !29
  %t90 = call i1 @compiler_2fgeneric_2ebyValueParam(ptr %v0, ptr %t88)
  store i1 %t90, ptr %l51
  br label %bb24
bb24:
  %t91 = load ptr, ptr %l49, !tbaa !29
  %t92 = load i1, ptr %l51, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %s0, ptr %t91, i1 %t92)
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t93 = load i64, ptr %l4, !tbaa !24
  %t96 = add i64 %t93, 1
  store i64 %t96, ptr %l4, !tbaa !24
  br label %bb19
bb27:
  %t98 = call ptr @__olang_scope_hold(ptr %s0)
  %t99 = ptrtoint ptr %t98 to i64
  store i64 %t99, ptr %l55, !tbaa !24
  %t100 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3agenRoots_2e0
  br i1 %t100, label %bb28, label %bb29
bb28:
  %t102 = call ptr @__olang_region_make(ptr %s0)
  %t103 = ptrtoint ptr %t102 to i64
  store i64 %t103, ptr %l55, !tbaa !24
  br label %bb29
bb29:
  %t104 = load i64, ptr %l55
  %t105 = inttoptr i64 %t104 to ptr
  %t107 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eToArra_H4d02a0b2e27e8f31ffc99daa43750593(ptr %s0, ptr %t105, ptr %l1)
  store { i64, ptr } %t107, ptr %l58
  br label %bb30
bb30:
  %t108 = call ptr @__olang_scope_hold(ptr %s0)
  %t109 = ptrtoint ptr %t108 to i64
  store i64 %t109, ptr %l59, !tbaa !24
  %t110 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3agenRoots_2e1
  br i1 %t110, label %bb31, label %bb32
bb31:
  %t112 = call ptr @__olang_region_make(ptr %s0)
  %t113 = ptrtoint ptr %t112 to i64
  store i64 %t113, ptr %l59, !tbaa !24
  br label %bb32
bb32:
  %t114 = load i64, ptr %l59
  %t115 = inttoptr i64 %t114 to ptr
  %t117 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eToArray_3cBool_3e(ptr %s0, ptr %t115, ptr %l2)
  store { i64, ptr } %t117, ptr %l62
  br label %bb33
bb33:
  %t118 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t119 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t120 = call %"compiler/generic:genRoots" @compiler_2fgeneric_3agenRoots_2ector(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t118, { i64, ptr } %t119)
  store %"compiler/generic:genRoots" %t120, ptr %l63
  br label %bb34
bb34:
  %t121 = load %"compiler/generic:genRoots", ptr %l63
  store %"compiler/generic:genRoots" %t121, ptr %l7
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/ast:Func", ptr %t122, i32 0, i32 4
  %t125 = load { i64, ptr }, ptr %t124, !tbaa !27
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estmts(ptr %s0, ptr %v0, ptr %l7, { i64, ptr } %t125)
  br label %bb35
bb35:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/ast:Func", ptr %t128, i32 0, i32 4
  %t131 = load { i64, ptr }, ptr %t130, !tbaa !27
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estmts(ptr %s0, ptr %v0, ptr %l7, { i64, ptr } %t131)
  br label %bb36
bb36:
  %t134 = getelementptr %"compiler/generic:genRoots", ptr %l7, i32 0, i32 3
  %t135 = load i64, ptr %t134, !tbaa !24
  store i64 %t135, ptr %l8, !tbaa !24
  %t137 = load i64, ptr %l8, !tbaa !24
  %t139 = icmp eq i64 %t137, 0
  br i1 %t139, label %bb37, label %bb38
bb37:
  %t141 = load i64, ptr @G_2ecompiler_2fgeneric_2eGenPerTurn, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t141, ptr %rv
  br label %ret
bb38:
  br label %bb39
bb39:
  %t143 = load i64, ptr %l8, !tbaa !24
  %t144 = load i64, ptr @G_2ecompiler_2fgeneric_2eGenLocalBit, !tbaa !24
  %t147 = and i64 %t143, %t144
  %t149 = icmp ne i64 %t147, 0
  br i1 %t149, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l78, !tbaa !21
  br label %bb42
bb41:
  %t151 = load i64, ptr %l8, !tbaa !24
  %t153 = call i64 @llvm.ctpop.i64(i64 %t151)
  %t155 = icmp ne i64 %t153, 1
  store i1 %t155, ptr %l78, !tbaa !21
  br label %bb42
bb42:
  %t157 = load i1, ptr %l78, !tbaa !21
  br i1 %t157, label %bb43, label %bb44
bb43:
  %t158 = load i64, ptr @G_2ecompiler_2fgeneric_2eGenFromReturn, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t158, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  %t160 = load i64, ptr %l8, !tbaa !24
  %t162 = call i64 @llvm.cttz.i64(i64 %t160, i1 false)
  call void @__olang_scope_close(ptr %s0)
  store i64 %t162, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fgeneric_2eheldElemOf(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca %"compiler/generic:genRoots"
  %l10 = alloca i64
  %l19 = alloca { i64, ptr }
  %l21 = alloca ptr
  %l22 = alloca i1
  %l30 = alloca i1
  %l31 = alloca { i64, ptr }
  %l33 = alloca i1
  %l36 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l37 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l42 = alloca ptr
  %l50 = alloca ptr
  %l56 = alloca i1
  %l66 = alloca { i64, ptr }
  %l72 = alloca ptr
  %l74 = alloca i1
  %l78 = alloca i64
  %l81 = alloca { i64, ptr }
  %l82 = alloca i64
  %l85 = alloca { i64, ptr }
  %l86 = alloca %"compiler/generic:genRoots"
  %l96 = alloca i1
  %l101 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Func", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/ast:Sig", ptr %t4, i32 0, i32 1
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t11 = icmp ne i64 %t9, 1
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load i64, ptr @G_2ecompiler_2fgeneric_2eGenPerTurn, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t13, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/ast:Func", ptr %t15, i32 0, i32 3
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/ast:Sig", ptr %t18, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l19, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr ptr, ptr %t23, i64 0
  %t25 = load ptr, ptr %t24, !tbaa !39
  store ptr %t25, ptr %l1, !tbaa !29
  %t27 = load ptr, ptr %l1, !tbaa !29
  store ptr %t27, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t28 = load ptr, ptr %l21, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb4, label %bb5
bb4:
  %t31 = load ptr, ptr %l21, !tbaa !29
  %t32 = load i64, ptr %t31, !range !{i64 0, i64 8}
  %t34 = icmp eq i64 %t32, 0
  store i1 %t34, ptr %l22, !tbaa !21
  br label %bb5
bb5:
  %t35 = load i1, ptr %l22, !tbaa !21
  br i1 %t35, label %bb6, label %bb7
bb6:
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t38 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t38, i32 0, i32 2
  %t40 = load { i64, ptr }, ptr %t39
  store { i64, ptr } %t40, ptr %l2, !tbaa !27
  br label %bb8
bb7:
  br label %bb16
bb8:
  %t42 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t46 = icmp eq i64 %t44, 0
  br i1 %t46, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb12
bb10:
  %t48 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t48, ptr %l31, !tbaa !27
  %t49 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr ptr, ptr %t50, i64 0
  %t52 = load ptr, ptr %t51, !tbaa !39
  %t54 = call i1 @compiler_2fgeneric_2erefElem(ptr %v0, ptr %t52)
  store i1 %t54, ptr %l33
  br label %bb11
bb11:
  %t55 = load i1, ptr %l33, !tbaa !21
  store i1 %t55, ptr %l30, !tbaa !21
  br label %bb12
bb12:
  %t56 = load i1, ptr %l30, !tbaa !21
  br i1 %t56, label %bb13, label %bb14
bb13:
  %t57 = load i64, ptr @G_2ecompiler_2fgeneric_2eGenPerTurn, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t57, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  br label %bb21
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t59 = load i64, ptr @G_2ecompiler_2fgeneric_2eGenPerTurn, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t59, ptr %rv
  br label %ret
bb20:
  call void @__olang_check_failed(ptr @olang_loc_f8bd867a16b9b73d_12b0dbd7172768b1)
  unreachable
bb21:
  %t61 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t61, ptr %l36
  br label %bb22
bb22:
  %t62 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t62, ptr %l3
  %t63 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t63, ptr %l37
  br label %bb23
bb23:
  %t64 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l37
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t64, ptr %l4
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/ast:Func", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = icmp eq ptr %t68, null
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb24, label %bb25
bb24:
  store ptr %l3, ptr %l42, !tbaa !29
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/ast:Func", ptr %t74, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = icmp eq ptr %t77, null
  br i1 %t79, label %bb26, label %bb27
bb25:
  br label %bb35
bb26:
  call void @__olang_check_failed(ptr @olang_loc_c1de3a385d82fbd5_70f4c0ded3022369)
  unreachable
bb27:
  br label %bb28
bb28:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/ast:Func", ptr %t81, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t87 = getelementptr %"compiler/ast:Param", ptr %t84, i32 0, i32 1
  %t88 = load i32, ptr %t87, !tbaa !23
  %t89 = load ptr, ptr %l42, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %t89, i32 %t88)
  br label %bb29
bb29:
  store ptr %l4, ptr %l50, !tbaa !29
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/ast:Func", ptr %t91, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t96 = icmp eq ptr %t94, null
  br i1 %t96, label %bb30, label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_5fb2273fcd9661c0_d1cbefb31b02b074)
  unreachable
bb31:
  br label %bb32
bb32:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/ast:Func", ptr %t98, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t103 = call i1 @compiler_2fgeneric_2ebyValueParam(ptr %v0, ptr %t101)
  store i1 %t103, ptr %l56
  br label %bb33
bb33:
  %t104 = load ptr, ptr %l50, !tbaa !29
  %t105 = load i1, ptr %l56, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %s0, ptr %t104, i1 %t105)
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/ast:Func", ptr %t106, i32 0, i32 3
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/ast:Sig", ptr %t109, i32 0, i32 0
  %t112 = load { i64, ptr }, ptr %t111, !tbaa !27
  store { i64, ptr } %t112, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t114 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t114, 0
  store i64 %t116, ptr %l7, !tbaa !24
  br label %bb36
bb36:
  %t118 = load i64, ptr %l6, !tbaa !24
  %t119 = load i64, ptr %l7, !tbaa !24
  %t122 = icmp slt i64 %t118, %t119
  %t124 = xor i1 %t122, true
  br i1 %t124, label %bb37, label %bb38
bb37:
  br label %bb44
bb38:
  br label %bb39
bb39:
  %t126 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t126, ptr %l66, !tbaa !27
  %t127 = load i64, ptr %l6, !tbaa !24
  %t129 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr ptr, ptr %t130, i64 %t127
  %t132 = load ptr, ptr %t131, !tbaa !39
  store ptr %t132, ptr %l8, !tbaa !29
  %t134 = load ptr, ptr %l8, !tbaa !29
  %t136 = getelementptr %"compiler/ast:Param", ptr %t134, i32 0, i32 1
  %t137 = load i32, ptr %t136, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l3, i32 %t137)
  br label %bb40
bb40:
  store ptr %l4, ptr %l72, !tbaa !29
  %t140 = load ptr, ptr %l8, !tbaa !29
  %t142 = call i1 @compiler_2fgeneric_2ebyValueParam(ptr %v0, ptr %t140)
  store i1 %t142, ptr %l74
  br label %bb41
bb41:
  %t143 = load ptr, ptr %l72, !tbaa !29
  %t144 = load i1, ptr %l74, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %s0, ptr %t143, i1 %t144)
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t145 = load i64, ptr %l6, !tbaa !24
  %t148 = add i64 %t145, 1
  store i64 %t148, ptr %l6, !tbaa !24
  br label %bb36
bb44:
  %t150 = call ptr @__olang_scope_hold(ptr %s0)
  %t151 = ptrtoint ptr %t150 to i64
  store i64 %t151, ptr %l78, !tbaa !24
  %t152 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3agenRoots_2e0
  br i1 %t152, label %bb45, label %bb46
bb45:
  %t154 = call ptr @__olang_region_make(ptr %s0)
  %t155 = ptrtoint ptr %t154 to i64
  store i64 %t155, ptr %l78, !tbaa !24
  br label %bb46
bb46:
  %t156 = load i64, ptr %l78
  %t157 = inttoptr i64 %t156 to ptr
  %t159 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eToArra_H4d02a0b2e27e8f31ffc99daa43750593(ptr %s0, ptr %t157, ptr %l3)
  store { i64, ptr } %t159, ptr %l81
  br label %bb47
bb47:
  %t160 = call ptr @__olang_scope_hold(ptr %s0)
  %t161 = ptrtoint ptr %t160 to i64
  store i64 %t161, ptr %l82, !tbaa !24
  %t162 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3agenRoots_2e1
  br i1 %t162, label %bb48, label %bb49
bb48:
  %t164 = call ptr @__olang_region_make(ptr %s0)
  %t165 = ptrtoint ptr %t164 to i64
  store i64 %t165, ptr %l82, !tbaa !24
  br label %bb49
bb49:
  %t166 = load i64, ptr %l82
  %t167 = inttoptr i64 %t166 to ptr
  %t169 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eToArray_3cBool_3e(ptr %s0, ptr %t167, ptr %l4)
  store { i64, ptr } %t169, ptr %l85
  br label %bb50
bb50:
  %t170 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t171 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t172 = call %"compiler/generic:genRoots" @compiler_2fgeneric_3agenRoots_2ector(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t170, { i64, ptr } %t171)
  store %"compiler/generic:genRoots" %t172, ptr %l86
  br label %bb51
bb51:
  %t173 = load %"compiler/generic:genRoots", ptr %l86
  store %"compiler/generic:genRoots" %t173, ptr %l9
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/ast:Func", ptr %t174, i32 0, i32 4
  %t177 = load { i64, ptr }, ptr %t176, !tbaa !27
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estmts(ptr %s0, ptr %v0, ptr %l9, { i64, ptr } %t177)
  br label %bb52
bb52:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr %"compiler/ast:Func", ptr %t180, i32 0, i32 4
  %t183 = load { i64, ptr }, ptr %t182, !tbaa !27
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estmts(ptr %s0, ptr %v0, ptr %l9, { i64, ptr } %t183)
  br label %bb53
bb53:
  %t186 = getelementptr %"compiler/generic:genRoots", ptr %l9, i32 0, i32 3
  %t187 = load i64, ptr %t186, !tbaa !24
  store i64 %t187, ptr %l10, !tbaa !24
  %t189 = load i64, ptr %l10, !tbaa !24
  %t191 = icmp eq i64 %t189, 0
  br i1 %t191, label %bb54, label %bb55
bb54:
  store i1 true, ptr %l96, !tbaa !21
  br label %bb56
bb55:
  %t193 = load i64, ptr %l10, !tbaa !24
  %t194 = load i64, ptr @G_2ecompiler_2fgeneric_2eGenLocalBit, !tbaa !24
  %t197 = and i64 %t193, %t194
  %t199 = icmp ne i64 %t197, 0
  store i1 %t199, ptr %l96, !tbaa !21
  br label %bb56
bb56:
  %t201 = load i1, ptr %l96, !tbaa !21
  br i1 %t201, label %bb57, label %bb58
bb57:
  store i1 true, ptr %l101, !tbaa !21
  br label %bb59
bb58:
  %t202 = load i64, ptr %l10, !tbaa !24
  %t204 = call i64 @llvm.ctpop.i64(i64 %t202)
  %t206 = icmp ne i64 %t204, 1
  store i1 %t206, ptr %l101, !tbaa !21
  br label %bb59
bb59:
  %t208 = load i1, ptr %l101, !tbaa !21
  br i1 %t208, label %bb60, label %bb61
bb60:
  %t209 = load i64, ptr @G_2ecompiler_2fgeneric_2eGenPerTurn, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t209, ptr %rv
  br label %ret
bb61:
  br label %bb62
bb62:
  %t211 = load i64, ptr %l10, !tbaa !24
  %t213 = call i64 @llvm.cttz.i64(i64 %t211, i1 false)
  call void @__olang_scope_close(ptr %s0)
  store i64 %t213, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fgeneric_2ekeyTrait(i32 %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t1 = shl i64 4, 40
  %t4 = sext i32 %a0 to i64
  %t7 = or i64 %t1, %t4
  store i64 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fgeneric_2elisted(ptr %v0, ptr %v1, { i64, ptr } %a0, i32 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l13 = alloca i64
  %l16 = alloca i1
  %l21 = alloca { i64, ptr }
  %rv = alloca ptr
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store ptr null, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = sub i64 %t14, 1
  store i64 %t15, ptr %l13, !tbaa !24
  %t16 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp slt i64 %t16, 2147483648
  %t18 = load i64, ptr %l3, !tbaa !24
  %t19 = icmp sge i64 %t18, 0
  %t22 = and i1 %t17, %t19
  store i1 %t22, ptr %l16, !tbaa !21
  br label %bb4
bb4:
  %t23 = load i64, ptr %l3, !tbaa !24
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = icmp slt i64 %t23, %t24
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb5, label %bb6
bb5:
  br label %bb12
bb6:
  br label %bb7
bb7:
  %t31 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t31, ptr %l21, !tbaa !27
  %t32 = load i64, ptr %l3, !tbaa !24
  %t34 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr ptr, ptr %t35, i64 %t32
  %t37 = load ptr, ptr %t36, !tbaa !39
  store ptr %t37, ptr %l5, !tbaa !29
  %t39 = load ptr, ptr %l5, !tbaa !29
  %t41 = getelementptr %"compiler/ast:TypeParam", ptr %t39, i32 0, i32 1
  %t42 = load i32, ptr %t41, !tbaa !23
  %t46 = icmp eq i32 %t42, %a1
  br i1 %t46, label %bb8, label %bb9
bb8:
  %t48 = load ptr, ptr %l5, !tbaa !29
  %t50 = getelementptr %"compiler/ast:TypeParam", ptr %t48, i32 0, i32 2
  %t51 = load ptr, ptr %t50, !tbaa !29
  store ptr %t51, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t53 = load i64, ptr %l3, !tbaa !24
  %t56 = add i64 %t53, 1
  store i64 %t56, ptr %l3, !tbaa !24
  br label %bb4
bb12:
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/generic:instance" @compiler_2fgeneric_3ainstance_2ector(ptr %v0, ptr %v1, ptr %v2, i64 %a0, i32 %a1, i32 %a2, { i64, ptr } %a3, { i64, ptr } %a4, %"compiler/generic:Origin" %a5) #0 {
entry:
  %rv = alloca %"compiler/generic:instance"
  br label %start
start:
  br label %bb0
bb0:
  %t14 = insertvalue %"compiler/generic:instance" undef, i64 %a0, 0
  %t16 = insertvalue %"compiler/generic:instance" %t14, i32 %a1, 1
  %t18 = insertvalue %"compiler/generic:instance" %t16, i32 %a2, 2
  %t20 = insertvalue %"compiler/generic:instance" %t18, { i64, ptr } %a3, 3
  %t22 = insertvalue %"compiler/generic:instance" %t20, { i64, ptr } %a4, 4
  %t24 = insertvalue %"compiler/generic:instance" %t22, %"compiler/generic:Origin" %a5, 5
  store %"compiler/generic:instance" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/generic:instance", ptr %rv
  ret %"compiler/generic:instance" %rr
}

@.d0 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".Len()" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr) cold noreturn
@.d1 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"if " }>, align 8
@.d2 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"} else if " }>, align 8
@.d3 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"assert " }>, align 8
@.d4 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"match " }>, align 8
@.d5 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" if " }>, align 8
@.d6 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"comptime" }>, align 8
@.d7 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Array<" }>, align 8
@.d8 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c">(" }>, align 8
@.d9 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d10 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" for " }>, align 8
@.d11 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"range " }>, align 8
@.d12 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d13 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d14 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
define internal i1 @olang_lambda_15(ptr %env, i32 %a0, i32 %a1) #0 {
entry:
  %l6 = alloca i1
  %rv = alloca i1
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t7 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eerrBefore(ptr %vc0, ptr %cv0, i32 %a0, i32 %a1)
  store i1 %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load i1, ptr %l6, !tbaa !21
  store i1 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d16 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d17 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d18 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d19 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d20 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@olang_2esole_2ecompiler_2fgeneric_3ainstance_2e3 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
@.d21 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d22 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Len" }>, align 8
@.d23 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d24 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d25 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d26 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".Len()" }>, align 8
@.d27 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t2 = load i32, ptr %a0, !range !{i32 0, i32 33}
  %t3 = sext i32 %t2 to i64
  %t5 = load i32, ptr %a1, !range !{i32 0, i32 33}
  %t6 = sext i32 %t5 to i64
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d28 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d29 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d30 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d31 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@__olang_empty_array = external constant [16 x i64]
@.d32 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" ![" }>, align 8
@.d33 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"borrows " }>, align 8
@.d34 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"keeps " }>, align 8
@.d35 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" in " }>, align 8
@.d36 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d37 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d38 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@olang_2esole_2eArray_3ccompiler_2fast_3aPath_26_3e_2e_2d1 = weak hidden constant i1 false
declare ptr @__olang_region_or(ptr, ptr)
declare void @__olang_bang_failed_plain(ptr) cold noreturn
@.d39 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Hash" }>, align 8
@.d40 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"hash" }>, align 8
@.d41 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d42 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d43 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d44 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d45 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d46 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d47 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"[0]" }>, align 8
@.d48 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_Hcd3bbe8e64537e19c3182f51d0fe16c9(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d49 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d50 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d51 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Array" }>, align 8
@.d52 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bool" }>, align 8
@.d53 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d54 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bits" }>, align 8
@.d55 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U64" }>, align 8
@.d56 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U32" }>, align 8
@.d57 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U16" }>, align 8
@.d58 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Hash" }>, align 8
@.d59 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Len" }>, align 8
define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2eArray_3ccompiler_2fsource_3aNameId_3e_26(ptr %a0, ptr %a1) #0 {
entry:
  %l6 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, ptr }, ptr %a0, !tbaa !27
  %t4 = load { i64, ptr }, ptr %a1, !tbaa !27
  %t9 = call i1 @olang_2emir_2eHelperKind_2eEqual_2eArray_3ccompiler_2fsource_3aNameId_3e({ i64, ptr } %t2, { i64, ptr } %t4)
  store i1 %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load i1, ptr %l6, !tbaa !21
  store i1 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d60 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"std/prelude/iterator" }>, align 8
@.d61 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"ViewGenerator" }>, align 8
@olang_2esole_2ecompiler_2fgeneric_3agenRoots_2e0 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fgeneric_3agenRoots_2e1 = weak hidden constant i1 false
declare i64 @llvm.ctpop.i64(i64)
declare i64 @llvm.cttz.i64(i64, i1)
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@__olang_self = external thread_local(initialexec) global ptr
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2eArray_3ccompiler_2fsource_3aNameId_3e({ i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca i64
  %l6 = alloca i64
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t3, 0
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb7
bb2:
  store i64 0, ptr %l6, !tbaa !24
  br label %bb3
bb3:
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t13 = load i64, ptr %l6, !tbaa !24
  %t14 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i32, ptr %t15, i64 %t13
  %t17 = load i32, ptr %t16, !tbaa !33
  %t18 = load i64, ptr %l6, !tbaa !24
  %t19 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr i32, ptr %t20, i64 %t18
  %t22 = load i32, ptr %t21, !tbaa !33
  %t25 = icmp eq i32 %t17, %t22
  br i1 %t25, label %bb6, label %bb1
bb5:
  br label %bb7
bb6:
  %t27 = load i64, ptr %l6, !tbaa !24
  %t28 = add i64 %t27, 1
  store i64 %t28, ptr %l6, !tbaa !24
  br label %bb3
bb7:
  %t29 = load i1, ptr %l2, !tbaa !21
  store i1 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare ptr @__olang_scope_mine_slow(ptr) noinline
@olang_loc_c152c1cd1761af15_fc7472910c385f59 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
@olang_loc_e975feb741415938_3766dae77ababfac = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fgeneric_2erefElem(ptr %v0, ptr %a0)
@olang_loc_b9fc8c34bb4a0c14_d84bd287e8577888 = external constant [0 x i8]
@olang_loc_6056ece582ef2ce2_c67ea0947e494cde = external constant [0 x i8]
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2edeclVars(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclParams(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2eisErrsArg(ptr %v0, ptr %a0)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eHasErrParam(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i64 @compiler_2fgeneric_2eWrittenTypes(ptr %v0, { i64, ptr } %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWrittenArity(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMinArity(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2eDeclOwner(i32 %a0)
@olang_loc_9ad358ce4cd92925_29c80ed6090eef61 = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eVar(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eerrsArg(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrSetOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare %"compiler/generic:varRow" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i32 %a3)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstance(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etypeDecl(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5, i1 %a6, i32 %a7, i64 %a8)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aListId_3e__H9cb5d99387f926677a92c13412f9a8b2(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunknowns(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ftypes_2eOwnScope = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@olang_loc_f9e5e93c78b56bbe_6af7701bc585ea2 = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eRoleCtor = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopes(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceContext(ptr %out, ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eparamsSig(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3, i32 %a4)
@olang_loc_2d8c89c88aa67454_7b49ff00081a1220 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %v1, ptr %a0)
@G_2ecompiler_2ftypes_2eDefaultErrT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\10\00\00\00" }>, align 8
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emergeEntries(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eSetAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare void @std_2fprelude_2farray_2eArray_3ccompiler_2ftypes_3aTypeId_3e_2eSort_3ccompiler_2ftypes_3aTypeId_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrVal(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePayloadOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRecord(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetErrRepr(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fload_2eErrQualifier(ptr %v0, ptr %v1, { i64, ptr } %a0, i1 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsRaisedError(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2einstanceArgs(ptr %v0, ptr %a0, i32 %a1)
declare %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" @std_2fpair_3aPair_3cI64_2c_20compiler_2ftypes_3aListId_3e_2ector(ptr %v0, i64 %a0, i32 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20compiler__Hfc7ca136f786d4bb067f513e5dea5730(ptr %v0, ptr %a0, %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %a1)
declare i64 @compiler_2fgeneric_2eFnOwner(i64 %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/generic:fnRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eAt_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3ainstance_3e_2eLen_Hf1590ba3dea8cd8a914b2a9f5344a2c6(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3ainstance_3e_2ePus_Hca36cd1c69200a0db62aadeba49cf6ed(ptr %v0, ptr %v1, ptr %a0, %"compiler/generic:instance" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H5edca056502a242264473f986489341f(ptr %v0, ptr %a0, %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %a1, i64 %a2)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_7f496bc4f965d188_939cdcc04f80a0bc = external constant [0 x i8]
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eallFns(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFuncTag(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etypeKey(ptr %v0, ptr %a0, i32 %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2erecvApplies(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2erecvExact(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eextends(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFlows(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2enumberOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eNullable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0, i64 %a0)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2eeat(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0)
declare i8 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2epeek(ptr %v0, ptr %a0)
@olang_loc_510ce85b2a9a6c03_b867f874fd10b7a7 = external constant [0 x i8]
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i32 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ecanonList(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eToArra_H4d02a0b2e27e8f31ffc99daa43750593(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_3e2c33a947ef0926_eb9e7dc4e2170cd2 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnonEnum(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, ptr } %a3)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare { i32, i64 } @compiler_2fgeneric_2ecanonNumber(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ftypes_2ePromiseNames = external constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }>
@G_2ecompiler_2ftypes_2eKeepsHome = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@olang_loc_50b66d83acd8516e_d3bb6f86efb3445a = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePromises(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2efile(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_6254d719be644cb8_ecba73ecf161ba54 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorMembers(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aDeclId_3e_2eLen_3ccompiler_2ftypes_3aDeclId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aDeclId_3e_2eAt_3ccompiler_2ftypes_3aDeclId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aDeclId_3e_2ePush_3ccompiler_2ftypes_3aDeclId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fgeneric_3aContext_2ector(ptr %out, ptr %v0, i64 %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eerrorSetItem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aDeclId_3e_2ePop_3ccompiler_2ftypes_3aDeclId_3e(ptr %v0, ptr %a0)
@olang_loc_720125e199c24f22_e8379e985b9f3c66 = external constant [0 x i8]
@olang_loc_227a3f0eae681c4f_61bdff3e0ec7ebb3 = external constant [0 x i8]
@olang_loc_f703e5bec6c76f87_ea1686e8125b66ab = external constant [0 x i8]
@olang_loc_bbb5b8b709f50d79_9796b462e6590e5d = external constant [0 x i8]
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
declare { i64, [3 x i64] } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eat(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eFlagAmongResults(ptr %v0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorOncePerLine(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/diagmsg:Msg" %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eFlagWithOutParam(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2edeclaresEq(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eownMethod(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_ee8d77a4a1fda3da_cc07c41aef88f656 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodSig(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emayHold(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnique(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseKeepsValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epromiseErr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, %"compiler/diagmsg:Msg" %a3)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epromiseParam(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3, i64 %a4)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseKeepsSelf(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseKeepsInValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseKeepsPath(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFieldNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2farray_2eArray_3ccompiler_2fsource_3aNameId_3e_2eHas_3ccompiler_2fsource_3aNameId_3e(ptr %v0, { i64, ptr } %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseKeepsField(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_cffe0474e3afc296_35ccea70755633e2 = external constant [0 x i8]
@olang_loc_2edbc1bd270558db_85d99d8e9bee4edf = external constant [0 x i8]
@olang_loc_7a3d6db3b893cc7d_3c2a4275e29a89 = external constant [0 x i8]
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eanyGlobal(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalStorage(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
declare { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInfer(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eitemsElem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i32 %a3, { i64, ptr } %a4)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2fgeneric_2ekeyDecl(i32 %a0)
@G_2ecompiler_2fgeneric_2eArrayKey = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\02\00\00" }>, align 8
declare i64 @compiler_2fgeneric_2ekeyPrim(i32 %a0)
@olang_loc_769954e80c04bef7_8801cb066681a71b = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyCovers(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_b3aa93c548ec796e_ac2c4500982ff6c2 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunifyLists(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3, i1 %a4)
@olang_loc_d067a2352cc578e3_8c11ed4f2bfcee77 = external constant [0 x i8]
@olang_loc_daff0119e8e7a208_cf3c54c8cae97514 = external constant [0 x i8]
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2edeclContext(ptr %out, ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v0, ptr %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2esigType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3, i32 %a4)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnifyArg(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3, i1 %a4, i1 %a5)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eerrsHaveVar(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunifyErrs(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_f83e897c6289299d_c5b35c0c7cd0f831 = external constant [0 x i8]
@olang_loc_dbc69524847f1d49_8831f326edbf0acd = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAny(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_737134d81da26253_60c38b193f08901f = external constant [0 x i8]
declare { i32, i32 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFindDecl(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@olang_loc_6b949e9fdbc9587c_5a8bb2436952ea48 = external constant [0 x i8]
@G_2ecompiler_2fgeneric_2eGenPerTurn = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_2a0d238d6764ffeb_7f54c8a7a483f2b7 = external constant [0 x i8]
@olang_loc_b16df8c761b5d07c_6405a14de8d58098 = external constant [0 x i8]
declare i1 @compiler_2fgeneric_2ebyValueParam(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eToArray_3cBool_3e(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/generic:genRoots" @compiler_2fgeneric_3agenRoots_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estmts(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2fgeneric_2eGenLocalBit = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\40" }>, align 8
@G_2ecompiler_2fgeneric_2eGenFromReturn = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@olang_loc_f8bd867a16b9b73d_12b0dbd7172768b1 = external constant [0 x i8]
@olang_loc_c1de3a385d82fbd5_70f4c0ded3022369 = external constant [0 x i8]
@olang_loc_5fb2273fcd9661c0_d1cbefb31b02b074 = external constant [0 x i8]
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eerrBefore(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
