; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/source:Names" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/diag:Diagnostics" = type { i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/parse:Oracle" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/scan:Tokens" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/scan:Diag" = type { i32, i32, i32, i8 }
%"compiler/parse:Parser" = type { ptr, ptr, ptr, ptr, ptr, i64, i64, i32, i32, i32, i32, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i64, i1, i1, i64, i1, i64, i1, i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, i1 }
%"compiler/diagmsg:Msg" = type { i32, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"std/io:Writer" = type { i32, { i64, ptr }, i64, { i32, { i64, [1 x i64] } } }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/fmt:formatter" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/text:StringBuilder", i1, i64, i64, { i64, ptr }, i64, i1, i64, i64, i64, i64, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/fmt:loader" = type { { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/token:Token" = type { i32, i8, i32, i32 }
define dso_local { i32, { i64, ptr } } @compiler_2ffmt_2eFileLayout(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca %"compiler/source:Source"
  %l6 = alloca %"compiler/source:Names"
  %l7 = alloca %"compiler/diag:Diagnostics"
  %l8 = alloca %"compiler/parse:Oracle"
  %l9 = alloca i64
  %l10 = alloca %"compiler/scan:Tokens"
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca %"compiler/scan:Diag"
  %l15 = alloca %"compiler/parse:Parser"
  %l16 = alloca { i64, ptr }
  %l22 = alloca %"compiler/source:Source"
  %l23 = alloca %"compiler/source:Names"
  %l25 = alloca %"compiler/diag:Diagnostics"
  %l30 = alloca %"compiler/parse:Oracle"
  %l34 = alloca i64
  %l36 = alloca %"compiler/scan:Tokens"
  %l44 = alloca { i64, ptr }
  %l47 = alloca ptr
  %l53 = alloca { i64, [3 x i64] }
  %l54 = alloca i32
  %l56 = alloca { i64, ptr }
  %l57 = alloca i64
  %l60 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l62 = alloca i64
  %l65 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l67 = alloca i64
  %l70 = alloca { i64, ptr }
  %l72 = alloca %"compiler/diagmsg:Msg"
  %l73 = alloca i64
  %l83 = alloca %"compiler/parse:Parser"
  %l85 = alloca { i64, ptr }
  %l89 = alloca i1
  %l91 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l93 = alloca i64
  %l95 = alloca ptr
  %l97 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %t16 = alloca %"compiler/diag:Diagnostics", align 8
  %t22 = alloca %"compiler/parse:Oracle", align 8
  %t73 = alloca { i64, [3 x i64] }, align 8
  %t162 = alloca %"compiler/parse:Parser", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/source:Source", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/source:Source", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t11 = call %"compiler/source:Source" @compiler_2fsource_3aSource_2ector(ptr %v0, ptr %v0, ptr %s0, { i64, ptr } %t4, { i64, ptr } %t8)
  store %"compiler/source:Source" %t11, ptr %l22
  br label %bb1
bb1:
  %t12 = load %"compiler/source:Source", ptr %l22
  store %"compiler/source:Source" %t12, ptr %l5
  %t13 = call %"compiler/source:Names" @compiler_2fsource_3aNames_2ector(ptr %s0)
  store %"compiler/source:Names" %t13, ptr %l23
  br label %bb2
bb2:
  %t14 = load %"compiler/source:Names", ptr %l23
  store %"compiler/source:Names" %t14, ptr %l6
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t16, ptr %s0, i1 %a3)
  call void @llvm.memmove.p0.p0.i64(ptr %l25, ptr %t16, i64 704, i1 false)
  br label %bb3
bb3:
  call void @llvm.memmove.p0.p0.i64(ptr %l7, ptr %l25, i64 704, i1 false)
  %t18 = getelementptr %"compiler/source:Source", ptr %l5, i32 0, i32 0
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  call void @compiler_2ffmt_2eOracleFor(ptr %t22, ptr %s0, ptr %v1, ptr %v2, ptr %s0, ptr %s0, { i64, ptr } %t19, { i64, ptr } %a1, { i64, ptr } %a2, ptr %l6)
  call void @llvm.memmove.p0.p0.i64(ptr %l30, ptr %t22, i64 288, i1 false)
  br label %bb4
bb4:
  call void @llvm.memmove.p0.p0.i64(ptr %l8, ptr %l30, i64 288, i1 false)
  %t27 = getelementptr %"compiler/source:Source", ptr %l5, i32 0, i32 0
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  %t29 = getelementptr %"compiler/source:Source", ptr %l5, i32 0, i32 1
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  %t34 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAddFile(ptr %s0, ptr %s0, ptr %s0, ptr %l7, { i64, ptr } %t28, { i64, ptr } %t30, i1 false)
  store i64 %t34, ptr %l34
  br label %bb5
bb5:
  %t35 = load i64, ptr %l34, !tbaa !24
  store i64 %t35, ptr %l9, !tbaa !24
  %t36 = getelementptr %"compiler/source:Source", ptr %l5, i32 0, i32 1
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  %t39 = call %"compiler/scan:Tokens" @compiler_2fscan_2eTokens_2eScan(ptr %s0, ptr %s0, { i64, ptr } %t37)
  store %"compiler/scan:Tokens" %t39, ptr %l36
  br label %bb6
bb6:
  %t40 = load %"compiler/scan:Tokens", ptr %l36
  store %"compiler/scan:Tokens" %t40, ptr %l10
  %t41 = getelementptr %"compiler/scan:Tokens", ptr %l10, i32 0, i32 3
  %t42 = load { i64, ptr }, ptr %t41, !tbaa !27
  store { i64, ptr } %t42, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  store i64 %t46, ptr %l13, !tbaa !24
  br label %bb7
bb7:
  %t48 = load i64, ptr %l12, !tbaa !24
  %t49 = load i64, ptr %l13, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb8, label %bb9
bb8:
  br label %bb24
bb9:
  br label %bb10
bb10:
  %t56 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t56, ptr %l44, !tbaa !27
  %t57 = load i64, ptr %l12, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr %"compiler/scan:Diag", ptr %t60, i64 %t57
  %t62 = load %"compiler/scan:Diag", ptr %t61
  store %"compiler/scan:Diag" %t62, ptr %l14
  store ptr %l7, ptr %l47, !tbaa !29
  %t64 = load i64, ptr %l9, !tbaa !24
  %t65 = getelementptr %"compiler/scan:Diag", ptr %l14, i32 0, i32 1
  %t66 = load i32, ptr %t65, !tbaa !23
  %t68 = sext i32 %t66 to i64
  %t69 = getelementptr %"compiler/scan:Diag", ptr %l14, i32 0, i32 2
  %t70 = load i32, ptr %t69, !tbaa !23
  %t72 = sext i32 %t70 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t73
  %t74 = getelementptr { i64, [3 x i64] }, ptr %t73, i32 0, i32 0
  store i64 3, ptr %t74
  %t76 = insertvalue { i64, i64, i64 } undef, i64 %t64, 0
  %t78 = insertvalue { i64, i64, i64 } %t76, i64 %t68, 1
  %t80 = insertvalue { i64, i64, i64 } %t78, i64 %t72, 2
  %t81 = getelementptr { i64, [3 x i64] }, ptr %t73, i32 0, i32 1
  store { i64, i64, i64 } %t80, ptr %t81
  %t82 = load { i64, [3 x i64] }, ptr %t73
  store { i64, [3 x i64] } %t82, ptr %l53
  store i32 67, ptr %l54
  %t83 = load %"compiler/scan:Diag", ptr %l14
  %t85 = call { i64, ptr } @compiler_2fscan_2ecompiler_2fscan_3aDiag_2eRule(ptr %s0, %"compiler/scan:Diag" %t83)
  store { i64, ptr } %t85, ptr %l56
  br label %bb11
bb11:
  %t86 = call ptr @__olang_scope_hold(ptr %s0)
  %t87 = ptrtoint ptr %t86 to i64
  store i64 %t87, ptr %l57, !tbaa !24
  %t88 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t88, label %bb12, label %bb13
bb12:
  %t90 = call ptr @__olang_region_make(ptr %s0)
  %t91 = ptrtoint ptr %t90 to i64
  store i64 %t91, ptr %l57, !tbaa !24
  br label %bb13
bb13:
  %t92 = load %"compiler/scan:Diag", ptr %l14
  %t93 = load i64, ptr %l57
  %t94 = inttoptr i64 %t93 to ptr
  %t96 = call { i64, ptr } @compiler_2fscan_2ecompiler_2fscan_3aDiag_2eMessage(ptr %t94, %"compiler/scan:Diag" %t92)
  store { i64, ptr } %t96, ptr %l60
  br label %bb14
bb14:
  %t97 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t98 = load i64, ptr %l57
  %t99 = inttoptr i64 %t98 to ptr
  %t100 = extractvalue { i64, ptr } %t97, 0
  %t101 = extractvalue { i64, ptr } %t97, 1
  %t102 = mul i64 %t100, 1
  %t103 = call ptr @__olang_held_alloc(ptr %t99, i64 %t102)
  call void @llvm.memcpy.p0.p0.i64(ptr %t103, ptr %t101, i64 %t102, i1 false)
  %t104 = insertvalue { i64, ptr } undef, i64 %t100, 0
  %t105 = insertvalue { i64, ptr } %t104, ptr %t103, 1
  store { i64, ptr } %t105, ptr %l61, !tbaa !27
  %t106 = call ptr @__olang_scope_hold(ptr %s0)
  %t107 = ptrtoint ptr %t106 to i64
  store i64 %t107, ptr %l62, !tbaa !24
  %t108 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t108, label %bb15, label %bb16
bb15:
  %t110 = call ptr @__olang_region_make(ptr %s0)
  %t111 = ptrtoint ptr %t110 to i64
  store i64 %t111, ptr %l62, !tbaa !24
  br label %bb16
bb16:
  %t112 = load %"compiler/scan:Diag", ptr %l14
  %t113 = load i64, ptr %l62
  %t114 = inttoptr i64 %t113 to ptr
  %t116 = call { i64, ptr } @compiler_2fscan_2ecompiler_2fscan_3aDiag_2eNote(ptr %t114, %"compiler/scan:Diag" %t112)
  store { i64, ptr } %t116, ptr %l65
  br label %bb17
bb17:
  %t117 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t118 = load i64, ptr %l62
  %t119 = inttoptr i64 %t118 to ptr
  %t120 = extractvalue { i64, ptr } %t117, 0
  %t121 = extractvalue { i64, ptr } %t117, 1
  %t122 = mul i64 %t120, 1
  %t123 = call ptr @__olang_held_alloc(ptr %t119, i64 %t122)
  call void @llvm.memcpy.p0.p0.i64(ptr %t123, ptr %t121, i64 %t122, i1 false)
  %t124 = insertvalue { i64, ptr } undef, i64 %t120, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t123, 1
  store { i64, ptr } %t125, ptr %l66, !tbaa !27
  %t126 = call ptr @__olang_scope_hold(ptr %s0)
  %t127 = ptrtoint ptr %t126 to i64
  store i64 %t127, ptr %l67, !tbaa !24
  %t128 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t128, label %bb18, label %bb19
bb18:
  %t130 = call ptr @__olang_region_make(ptr %s0)
  %t131 = ptrtoint ptr %t130 to i64
  store i64 %t131, ptr %l67, !tbaa !24
  br label %bb19
bb19:
  %t132 = load %"compiler/scan:Diag", ptr %l14
  %t133 = load i64, ptr %l67
  %t134 = inttoptr i64 %t133 to ptr
  %t136 = call { i64, ptr } @compiler_2fscan_2ecompiler_2fscan_3aDiag_2eHelp(ptr %t134, %"compiler/scan:Diag" %t132)
  store { i64, ptr } %t136, ptr %l70
  br label %bb20
bb20:
  %t137 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t138 = load i64, ptr %l67
  %t139 = inttoptr i64 %t138 to ptr
  %t140 = extractvalue { i64, ptr } %t137, 0
  %t141 = extractvalue { i64, ptr } %t137, 1
  %t142 = mul i64 %t140, 1
  %t143 = call ptr @__olang_held_alloc(ptr %t139, i64 %t142)
  call void @llvm.memcpy.p0.p0.i64(ptr %t143, ptr %t141, i64 %t142, i1 false)
  %t144 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t143, 1
  %t146 = load i32, ptr %l54, !range !{i32 0, i32 949}
  %t147 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t148 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t149 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t151 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, i32 %t146, { i64, ptr } %t147, { i64, ptr } %t148, { i64, ptr } %t149, { i64, ptr } %t145)
  store %"compiler/diagmsg:Msg" %t151, ptr %l72
  br label %bb21
bb21:
  %t152 = load ptr, ptr %l47, !tbaa !29
  %t153 = load { i64, [3 x i64] }, ptr %l53
  %t154 = load %"compiler/diagmsg:Msg", ptr %l72
  %t155 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %s0, ptr %s0, ptr %t152, { i64, [3 x i64] } %t153, %"compiler/diagmsg:Msg" %t154)
  store i64 %t155, ptr %l73
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t156 = load i64, ptr %l12, !tbaa !24
  %t159 = add i64 %t156, 1
  store i64 %t159, ptr %l12, !tbaa !24
  br label %bb7
bb24:
  %t161 = load i64, ptr %l9, !tbaa !24
  call void @compiler_2fparse_3aParser_2ector(ptr %t162, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %l5, ptr %l10, ptr %l6, ptr %l8, ptr %l7, i64 %t161)
  call void @llvm.memmove.p0.p0.i64(ptr %l83, ptr %t162, i64 1016, i1 false)
  br label %bb25
bb25:
  call void @llvm.memmove.p0.p0.i64(ptr %l15, ptr %l83, i64 1016, i1 false)
  %t170 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eFile(ptr %s0, ptr %s0, ptr %l15)
  store { i64, ptr } %t170, ptr %l85
  br label %bb26
bb26:
  %t171 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t171, ptr %l16, !tbaa !27
  %t172 = getelementptr %"compiler/scan:Tokens", ptr %l10, i32 0, i32 3
  %t173 = load { i64, ptr }, ptr %t172, !tbaa !27
  %t175 = extractvalue { i64, ptr } %t173, 0
  %t177 = icmp sgt i64 %t175, 0
  br i1 %t177, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l89, !tbaa !21
  br label %bb31
bb28:
  %t180 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAllSaid(ptr %s0, ptr %s0, ptr %l7)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t180, ptr %l91
  br label %bb29
bb29:
  %t182 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3aSaid_3e_2eLen_3ccompiler_2fdiag_3aSaid_3e(ptr %s0, ptr %l91)
  store i64 %t182, ptr %l93
  br label %bb30
bb30:
  %t183 = load i64, ptr %l93, !tbaa !24
  %t184 = icmp sgt i64 %t183, 0
  store i1 %t184, ptr %l89, !tbaa !21
  br label %bb31
bb31:
  %t186 = load i1, ptr %l89, !tbaa !21
  br i1 %t186, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s4
  store ptr %a4, ptr %l95, !tbaa !29
  %t189 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %s0, ptr %s4, ptr %l7)
  store { i64, ptr } %t189, ptr %l97
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t190 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t191 = load ptr, ptr %l95, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v3, ptr %s4, ptr %t191, { i64, ptr } %t190)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t194 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t194, ptr %rv
  br label %ret
bb36:
  %t195 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t196 = getelementptr %"compiler/source:Source", ptr %l5, i32 0, i32 1
  %t197 = load { i64, ptr }, ptr %t196, !tbaa !27
  %t202 = call { i64, ptr } @compiler_2funparse_2eHeldBranches(ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t195, ptr %l6, { i64, ptr } %t197, ptr %l7)
  store { i64, ptr } %t202, ptr %l104
  br label %bb37
bb37:
  %t203 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t204 = getelementptr %"compiler/source:Source", ptr %l5, i32 0, i32 1
  %t205 = load { i64, ptr }, ptr %t204, !tbaa !27
  %t206 = getelementptr %"compiler/parse:Parser", ptr %l15, i32 0, i32 44
  %t207 = getelementptr %"compiler/parse:Parser", ptr %l15, i32 0, i32 45
  %t209 = getelementptr %"compiler/parse:Parser", ptr %l15, i32 0, i32 47
  %t210 = getelementptr %"compiler/parse:Parser", ptr %l15, i32 0, i32 46
  %t218 = call { i64, ptr } @compiler_2ffmt_2eFormat(ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %v4, { i64, ptr } %t205, ptr %l10, ptr %t206, ptr %t207, { i64, ptr } %t203, ptr %t209, ptr %t210)
  store { i64, ptr } %t218, ptr %l112
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s0)
  %t219 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t220 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t219, 1
  store { i32, { i64, ptr } } %t220, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i32 @compiler_2ffmt_2eFiles(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/io:Writer"
  %l4 = alloca %"std/io:Writer"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca %"compiler/source:Source"
  %l12 = alloca %"std/prelude/text:StringBuilder"
  %l13 = alloca { i64, ptr }
  %l17 = alloca %"std/io:Writer"
  %l21 = alloca %"std/io:Writer"
  %l23 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l34 = alloca %"compiler/source:Source"
  %l36 = alloca %"compiler/source:Source"
  %l37 = alloca i32
  %l39 = alloca i1
  %l47 = alloca %"std/prelude/text:StringBuilder"
  %l48 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l52 = alloca i1
  %l54 = alloca { i64, ptr }
  %l55 = alloca i32
  %l56 = alloca ptr
  %l58 = alloca { i64, ptr }
  %l62 = alloca i1
  %l65 = alloca i1
  %l69 = alloca i32
  %l71 = alloca i1
  %l80 = alloca i1
  %l85 = alloca i1
  %l96 = alloca i32
  %l98 = alloca i1
  %l103 = alloca i32
  %l105 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca i32
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr @G_2estd_2fio_2eStdout, !tbaa !23
  %t3 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 4, i64 8)
  store i32 %t1, ptr %t3
  %t5 = insertvalue { ptr, ptr } undef, ptr %t3, 0
  %t6 = icmp ne ptr %t3, null
  %t7 = select i1 %t6, ptr @olang_2etable_2eI32_7cstd_2fio_3aDescriptor, ptr null
  %t8 = insertvalue { ptr, ptr } %t5, ptr %t7, 1
  %t10 = call %"std/io:Writer" @std_2fio_3aWriter_2ector(ptr %s0, ptr %s0, { ptr, ptr } %t8, i64 65536)
  store %"std/io:Writer" %t10, ptr %l17
  br label %bb1
bb1:
  %t11 = load %"std/io:Writer", ptr %l17
  store %"std/io:Writer" %t11, ptr %l3
  %t12 = load i32, ptr @G_2estd_2fio_2eStderr, !tbaa !23
  %t14 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 4, i64 8)
  store i32 %t12, ptr %t14
  %t16 = insertvalue { ptr, ptr } undef, ptr %t14, 0
  %t17 = icmp ne ptr %t14, null
  %t18 = select i1 %t17, ptr @olang_2etable_2eI32_7cstd_2fio_3aDescriptor, ptr null
  %t19 = insertvalue { ptr, ptr } %t16, ptr %t18, 1
  %t21 = call %"std/io:Writer" @std_2fio_3aWriter_2ector(ptr %s0, ptr %s0, { ptr, ptr } %t19, i64 65536)
  store %"std/io:Writer" %t21, ptr %l21
  br label %bb2
bb2:
  %t22 = load %"std/io:Writer", ptr %l21
  store %"std/io:Writer" %t22, ptr %l4
  %t23 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t25 = call { i64, ptr } @compiler_2ffmt_2ePreludeTypes(ptr %v2, ptr %s0, { i64, ptr } %t23)
  store { i64, ptr } %t25, ptr %l23
  br label %bb3
bb3:
  %t26 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t26, ptr %l5, !tbaa !27
  store i32 0, ptr %l6, !tbaa !23
  store { i64, ptr } %a1, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t29 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t29, 0
  store i64 %t31, ptr %l9, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load i64, ptr %l8, !tbaa !24
  %t34 = load i64, ptr %l9, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb49
bb6:
  br label %bb7
bb7:
  %t41 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t41, ptr %l31, !tbaa !27
  %t42 = load i64, ptr %l8, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %t45, i64 %t42
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !37
  store { i64, ptr } %t47, ptr %l10, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t51 = call { i32, %"compiler/source:Source" } @compiler_2fsource_2eSource_2eRead(ptr %v1, ptr %s2, { i64, ptr } %t49)
  %t52 = extractvalue { i32, %"compiler/source:Source" } %t51, 1
  %t53 = extractvalue { i32, %"compiler/source:Source" } %t51, 0
  store i32 %t53, ptr %l37
  %t54 = icmp ne i32 %t53, 0
  br i1 %t54, label %bb9, label %ok.55, !prof !99
ok.55:
  store %"compiler/source:Source" %t52, ptr %l36
  br label %bb8
bb8:
  %t56 = load %"compiler/source:Source", ptr %l36
  store %"compiler/source:Source" %t56, ptr %l34
  br label %bb14
bb9:
  %t57 = load i32, ptr %l37, !tbaa !23
  %t58 = ashr i32 %t57, 16
  %t60 = icmp eq i32 %t58, 1
  store i1 %t60, ptr %l39, !tbaa !21
  %t61 = load i32, ptr %l37, !tbaa !23
  %t62 = ashr i32 %t61, 16
  %t64 = icmp eq i32 %t62, 1
  br i1 %t64, label %bb10, label %bb11
bb10:
  call void @__olang_errpay_pop()
  br label %bb11
bb11:
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t66 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t67 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t68 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t70 = extractvalue { i64, ptr } %t66, 1
  %t71 = extractvalue { i64, ptr } %t66, 0
  %t72 = add i64 %t68, %t71
  %t73 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t74 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t75 = add i64 %t72, %t74
  %t76 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t75)
  call void @olang_textcopy(ptr %t76, ptr %t67, i64 %t68)
  %t77 = getelementptr i8, ptr %t76, i64 %t68
  call void @olang_textcopy(ptr %t77, ptr %t70, i64 %t71)
  %t78 = getelementptr i8, ptr %t77, i64 %t71
  call void @olang_textcopy(ptr %t78, ptr %t73, i64 %t74)
  %t79 = insertvalue { i64, ptr } undef, i64 %t75, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t76, 1
  %t83 = extractvalue { i64, ptr } %t80, 0
  %t84 = extractvalue { i64, ptr } %t80, 1
  %t85 = mul i64 %t83, 1
  %t86 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t85)
  call void @llvm.memcpy.p0.p0.i64(ptr %t86, ptr %t84, i64 %t85, i1 false)
  %t87 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t86, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s3, ptr %l4, { i64, ptr } %t88)
  br label %bb13
bb13:
  store i32 1, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  br label %bb48
bb14:
  %t91 = load %"compiler/source:Source", ptr %l34
  store %"compiler/source:Source" %t91, ptr %l11
  %t92 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s2)
  store %"std/prelude/text:StringBuilder" %t92, ptr %l47
  br label %bb15
bb15:
  %t93 = load %"std/prelude/text:StringBuilder", ptr %l47
  store %"std/prelude/text:StringBuilder" %t93, ptr %l12
  store ptr %l11, ptr %l49, !tbaa !29
  %t94 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t94, ptr %l50, !tbaa !27
  %t95 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t95, ptr %l51, !tbaa !27
  %t96 = call i1 @compiler_2fdiag_2eColorWanted()
  store i1 %t96, ptr %l52
  br label %bb16
bb16:
  %t97 = load ptr, ptr %l49, !tbaa !29
  %t98 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t99 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t100 = load i1, ptr %l52, !tbaa !21
  %t102 = call { i32, { i64, ptr } } @compiler_2ffmt_2eFileLayout(ptr %s2, ptr %v2, ptr %s0, ptr %s2, ptr %s2, ptr %t97, { i64, ptr } %t98, { i64, ptr } %t99, i1 %t100, ptr %l12)
  %t103 = extractvalue { i32, { i64, ptr } } %t102, 1
  %t104 = extractvalue { i32, { i64, ptr } } %t102, 0
  store i32 %t104, ptr %l55
  %t105 = icmp ne i32 %t104, 0
  br i1 %t105, label %bb18, label %ok.106, !prof !99
ok.106:
  store { i64, ptr } %t103, ptr %l54
  br label %bb17
bb17:
  %t107 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t107, ptr %l48, !tbaa !27
  br label %bb22
bb18:
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s5
  store ptr %l4, ptr %l56, !tbaa !29
  %t109 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s2, ptr %s5, ptr %l12)
  store { i64, ptr } %t109, ptr %l58
  br label %bb20
bb20:
  %t110 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t110, 0
  %t113 = extractvalue { i64, ptr } %t110, 1
  %t114 = mul i64 %t112, 1
  %t115 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t114)
  call void @llvm.memcpy.p0.p0.i64(ptr %t115, ptr %t113, i64 %t114, i1 false)
  %t116 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t115, 1
  %t118 = load ptr, ptr %l56, !tbaa !29
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s5, ptr %t118, { i64, ptr } %t117)
  br label %bb21
bb21:
  store i32 1, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s2)
  br label %bb48
bb22:
  %t120 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t120, ptr %l13, !tbaa !27
  %t121 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t123 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t121, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i1 %t123, ptr %l62
  br label %bb23
bb23:
  %t124 = load i1, ptr %l62, !tbaa !21
  br i1 %t124, label %bb24, label %bb25
bb24:
  %t125 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t126 = getelementptr %"compiler/source:Source", ptr %l11, i32 0, i32 1
  %t127 = load { i64, ptr }, ptr %t126, !tbaa !27
  %t130 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t125, { i64, ptr } %t127)
  store i1 %t130, ptr %l65
  br label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s10
  %t131 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t133 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s10, { i64, ptr } %t131, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i1 %t133, ptr %l80
  br label %bb37
bb26:
  %t134 = load i1, ptr %l65, !tbaa !21
  %t135 = xor i1 %t134, true
  br i1 %t135, label %bb27, label %bb28
bb27:
  %t137 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t138 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t141 = call i32 @std_2fos_2eWriteFile(ptr %v1, ptr %s2, { i64, ptr } %t137, { i64, ptr } %t138)
  store i32 %t141, ptr %l69
  %t142 = icmp ne i32 %t141, 0
  br i1 %t142, label %bb30, label %ok.143, !prof !99
ok.143:
  br label %bb29
bb28:
  br label %bb36
bb29:
  br label %bb35
bb30:
  %t144 = load i32, ptr %l69, !tbaa !23
  %t145 = ashr i32 %t144, 16
  %t147 = icmp eq i32 %t145, 1
  store i1 %t147, ptr %l71, !tbaa !21
  %t148 = load i32, ptr %l69, !tbaa !23
  %t149 = ashr i32 %t148, 16
  %t151 = icmp eq i32 %t149, 1
  br i1 %t151, label %bb31, label %bb32
bb31:
  call void @__olang_errpay_pop()
  br label %bb32
bb32:
  br label %bb33
bb33:
  store %olang.scope zeroinitializer, ptr %s8
  %t153 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t154 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t155 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t157 = extractvalue { i64, ptr } %t153, 1
  %t158 = extractvalue { i64, ptr } %t153, 0
  %t159 = add i64 %t155, %t158
  %t160 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t161 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t162 = add i64 %t159, %t161
  %t163 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t162)
  call void @olang_textcopy(ptr %t163, ptr %t154, i64 %t155)
  %t164 = getelementptr i8, ptr %t163, i64 %t155
  call void @olang_textcopy(ptr %t164, ptr %t157, i64 %t158)
  %t165 = getelementptr i8, ptr %t164, i64 %t158
  call void @olang_textcopy(ptr %t165, ptr %t160, i64 %t161)
  %t166 = insertvalue { i64, ptr } undef, i64 %t162, 0
  %t167 = insertvalue { i64, ptr } %t166, ptr %t163, 1
  %t170 = extractvalue { i64, ptr } %t167, 0
  %t171 = extractvalue { i64, ptr } %t167, 1
  %t172 = mul i64 %t170, 1
  %t173 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t172)
  call void @llvm.memcpy.p0.p0.i64(ptr %t173, ptr %t171, i64 %t172, i1 false)
  %t174 = insertvalue { i64, ptr } undef, i64 %t170, 0
  %t175 = insertvalue { i64, ptr } %t174, ptr %t173, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s8, ptr %l4, { i64, ptr } %t175)
  br label %bb34
bb34:
  store i32 1, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s8)
  br label %bb35
bb35:
  br label %bb36
bb36:
  br label %bb47
bb37:
  %t178 = load i1, ptr %l80, !tbaa !21
  br i1 %t178, label %bb38, label %bb39
bb38:
  %t179 = load { i64, ptr }, ptr %l13, !tbaa !27
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s2, ptr %l3, { i64, ptr } %t179)
  br label %bb40
bb39:
  %t182 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t183 = getelementptr %"compiler/source:Source", ptr %l11, i32 0, i32 1
  %t184 = load { i64, ptr }, ptr %t183, !tbaa !27
  %t187 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t182, { i64, ptr } %t184)
  store i1 %t187, ptr %l85
  br label %bb41
bb40:
  br label %bb46
bb41:
  %t188 = load i1, ptr %l85, !tbaa !21
  %t189 = xor i1 %t188, true
  br i1 %t189, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s13
  %t191 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t191, 1
  %t194 = extractvalue { i64, ptr } %t191, 0
  %t195 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t196 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t197 = add i64 %t194, %t196
  %t198 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t197)
  call void @olang_textcopy(ptr %t198, ptr %t193, i64 %t194)
  %t199 = getelementptr i8, ptr %t198, i64 %t194
  call void @olang_textcopy(ptr %t199, ptr %t195, i64 %t196)
  %t200 = insertvalue { i64, ptr } undef, i64 %t197, 0
  %t201 = insertvalue { i64, ptr } %t200, ptr %t198, 1
  %t204 = extractvalue { i64, ptr } %t201, 0
  %t205 = extractvalue { i64, ptr } %t201, 1
  %t206 = mul i64 %t204, 1
  %t207 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t206)
  call void @llvm.memcpy.p0.p0.i64(ptr %t207, ptr %t205, i64 %t206, i1 false)
  %t208 = insertvalue { i64, ptr } undef, i64 %t204, 0
  %t209 = insertvalue { i64, ptr } %t208, ptr %t207, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s13, ptr %l3, { i64, ptr } %t209)
  br label %bb44
bb43:
  br label %bb45
bb44:
  store i32 1, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s13)
  br label %bb45
bb45:
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s10)
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s2)
  br label %bb48
bb48:
  %t212 = load i64, ptr %l8, !tbaa !24
  %t215 = add i64 %t212, 1
  store i64 %t215, ptr %l8, !tbaa !24
  br label %bb4
bb49:
  %t218 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %l3)
  store i32 %t218, ptr %l96
  %t219 = icmp ne i32 %t218, 0
  br i1 %t219, label %bb51, label %ok.220, !prof !99
ok.220:
  br label %bb50
bb50:
  br label %bb55
bb51:
  %t221 = load i32, ptr %l96, !tbaa !23
  %t222 = ashr i32 %t221, 16
  %t224 = icmp eq i32 %t222, 1
  store i1 %t224, ptr %l98, !tbaa !21
  %t225 = load i32, ptr %l96, !tbaa !23
  %t226 = ashr i32 %t225, 16
  %t228 = icmp eq i32 %t226, 1
  br i1 %t228, label %bb52, label %bb53
bb52:
  call void @__olang_errpay_pop()
  br label %bb53
bb53:
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb55:
  %t232 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %l4)
  store i32 %t232, ptr %l103
  %t233 = icmp ne i32 %t232, 0
  br i1 %t233, label %bb57, label %ok.234, !prof !99
ok.234:
  br label %bb56
bb56:
  br label %bb61
bb57:
  %t235 = load i32, ptr %l103, !tbaa !23
  %t236 = ashr i32 %t235, 16
  %t238 = icmp eq i32 %t236, 1
  store i1 %t238, ptr %l105, !tbaa !21
  %t239 = load i32, ptr %l103, !tbaa !23
  %t240 = ashr i32 %t239, 16
  %t242 = icmp eq i32 %t240, 1
  br i1 %t242, label %bb58, label %bb59
bb58:
  call void @__olang_errpay_pop()
  br label %bb59
bb59:
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb61:
  %t245 = load i32, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t245, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2ffmt_2eFormat(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %v7, { i64, ptr } %a0, ptr %a1, ptr %a2, ptr %a3, { i64, ptr } %a4, ptr %a5, ptr %a6) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l7 = alloca %"compiler/fmt:formatter"
  %l8 = alloca ptr
  %l9 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca %"compiler/source:Span"
  %l27 = alloca %"compiler/fmt:formatter"
  %l29 = alloca i64
  %l31 = alloca i64
  %l36 = alloca i64
  %l37 = alloca { i64, ptr }
  %l43 = alloca i64
  %l45 = alloca i64
  %l50 = alloca i64
  %l51 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l61 = alloca i64
  %l63 = alloca i64
  %l68 = alloca i64
  %l69 = alloca { i64, ptr }
  %l75 = alloca i64
  %l77 = alloca i64
  %l82 = alloca i64
  %l83 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l102 = alloca ptr
  %l106 = alloca i64
  %l107 = alloca ptr
  %l112 = alloca i64
  %l118 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t6 = alloca %"compiler/fmt:formatter", align 8
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t4 = getelementptr %"compiler/scan:Tokens", ptr %a1, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  call void @compiler_2ffmt_3aformatter_2ector(ptr %t6, ptr %v0, ptr %v1, ptr %s0, { i64, ptr } %t1, { i64, ptr } %t5)
  call void @llvm.memmove.p0.p0.i64(ptr %l27, ptr %t6, i64 720, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %l7, ptr %l27, i64 720, i1 false)
  store ptr %a6, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l9, !tbaa !24
  store i64 %t11, ptr %l29, !tbaa !24
  %t12 = load ptr, ptr %l8, !tbaa !29
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v6, ptr %t12)
  store i64 %t14, ptr %l31
  br label %bb3
bb3:
  %t15 = load i64, ptr %l29, !tbaa !24
  %t16 = load i64, ptr %l31, !tbaa !24
  %t17 = icmp slt i64 %t15, %t16
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb4, label %bb5
bb4:
  br label %bb9
bb5:
  br label %bb6
bb6:
  %t21 = load ptr, ptr %l8, !tbaa !29
  %t22 = load i64, ptr %l9, !tbaa !24
  %t25 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v6, ptr %t21, i64 %t22)
  store i64 %t25, ptr %l36
  br label %bb7
bb7:
  %t26 = load i64, ptr %l36, !tbaa !24
  %t27 = getelementptr %"compiler/fmt:formatter", ptr %l7, i32 0, i32 7
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  store { i64, ptr } %t28, ptr %l37, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr i1, ptr %t32, i64 %t26
  store i1 true, ptr %t33, !tbaa !31
  br label %bb8
bb8:
  %t34 = load i64, ptr %l9, !tbaa !24
  %t37 = add i64 %t34, 1
  store i64 %t37, ptr %l9, !tbaa !24
  br label %bb2
bb9:
  store ptr %a2, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb10
bb10:
  %t41 = load i64, ptr %l12, !tbaa !24
  store i64 %t41, ptr %l43, !tbaa !24
  %t42 = load ptr, ptr %l11, !tbaa !29
  %t44 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v2, ptr %t42)
  store i64 %t44, ptr %l45
  br label %bb11
bb11:
  %t45 = load i64, ptr %l43, !tbaa !24
  %t46 = load i64, ptr %l45, !tbaa !24
  %t47 = icmp slt i64 %t45, %t46
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb12, label %bb13
bb12:
  br label %bb17
bb13:
  br label %bb14
bb14:
  %t51 = load ptr, ptr %l11, !tbaa !29
  %t52 = load i64, ptr %l12, !tbaa !24
  %t55 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t51, i64 %t52)
  store i64 %t55, ptr %l50
  br label %bb15
bb15:
  %t56 = load i64, ptr %l50, !tbaa !24
  store i64 %t56, ptr %l13, !tbaa !24
  %t57 = getelementptr %"compiler/fmt:formatter", ptr %l7, i32 0, i32 2
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  store { i64, ptr } %t58, ptr %l51, !tbaa !27
  %t59 = load i64, ptr %l13, !tbaa !24
  %t60 = getelementptr %"compiler/fmt:formatter", ptr %l7, i32 0, i32 2
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !27
  store { i64, ptr } %t61, ptr %l53, !tbaa !27
  %t62 = load i64, ptr %l13, !tbaa !24
  %t64 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = getelementptr i64, ptr %t65, i64 %t62
  %t67 = load i64, ptr %t66, !tbaa !34
  %t69 = add i64 %t67, 1
  %t72 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr i64, ptr %t73, i64 %t59
  store i64 %t69, ptr %t74, !tbaa !34
  br label %bb16
bb16:
  %t75 = load i64, ptr %l12, !tbaa !24
  %t78 = add i64 %t75, 1
  store i64 %t78, ptr %l12, !tbaa !24
  br label %bb10
bb17:
  store ptr %a5, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb18
bb18:
  %t82 = load i64, ptr %l15, !tbaa !24
  store i64 %t82, ptr %l61, !tbaa !24
  %t83 = load ptr, ptr %l14, !tbaa !29
  %t85 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v5, ptr %t83)
  store i64 %t85, ptr %l63
  br label %bb19
bb19:
  %t86 = load i64, ptr %l61, !tbaa !24
  %t87 = load i64, ptr %l63, !tbaa !24
  %t88 = icmp slt i64 %t86, %t87
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb20, label %bb21
bb20:
  br label %bb25
bb21:
  br label %bb22
bb22:
  %t92 = load ptr, ptr %l14, !tbaa !29
  %t93 = load i64, ptr %l15, !tbaa !24
  %t96 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v5, ptr %t92, i64 %t93)
  store i64 %t96, ptr %l68
  br label %bb23
bb23:
  %t97 = load i64, ptr %l68, !tbaa !24
  %t98 = getelementptr %"compiler/fmt:formatter", ptr %l7, i32 0, i32 3
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  store { i64, ptr } %t99, ptr %l69, !tbaa !27
  %t102 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr i1, ptr %t103, i64 %t97
  store i1 true, ptr %t104, !tbaa !31
  br label %bb24
bb24:
  %t105 = load i64, ptr %l15, !tbaa !24
  %t108 = add i64 %t105, 1
  store i64 %t108, ptr %l15, !tbaa !24
  br label %bb18
bb25:
  store ptr %a3, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb26
bb26:
  %t112 = load i64, ptr %l18, !tbaa !24
  store i64 %t112, ptr %l75, !tbaa !24
  %t113 = load ptr, ptr %l17, !tbaa !29
  %t115 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v3, ptr %t113)
  store i64 %t115, ptr %l77
  br label %bb27
bb27:
  %t116 = load i64, ptr %l75, !tbaa !24
  %t117 = load i64, ptr %l77, !tbaa !24
  %t118 = icmp slt i64 %t116, %t117
  %t120 = xor i1 %t118, true
  br i1 %t120, label %bb28, label %bb29
bb28:
  br label %bb33
bb29:
  br label %bb30
bb30:
  %t122 = load ptr, ptr %l17, !tbaa !29
  %t123 = load i64, ptr %l18, !tbaa !24
  %t126 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v3, ptr %t122, i64 %t123)
  store i64 %t126, ptr %l82
  br label %bb31
bb31:
  %t127 = load i64, ptr %l82, !tbaa !24
  store i64 %t127, ptr %l19, !tbaa !24
  %t128 = getelementptr %"compiler/fmt:formatter", ptr %l7, i32 0, i32 4
  %t129 = load { i64, ptr }, ptr %t128, !tbaa !27
  store { i64, ptr } %t129, ptr %l83, !tbaa !27
  %t130 = load i64, ptr %l19, !tbaa !24
  %t131 = getelementptr %"compiler/fmt:formatter", ptr %l7, i32 0, i32 4
  %t132 = load { i64, ptr }, ptr %t131, !tbaa !27
  store { i64, ptr } %t132, ptr %l85, !tbaa !27
  %t133 = load i64, ptr %l19, !tbaa !24
  %t135 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !27
  %t137 = getelementptr i64, ptr %t136, i64 %t133
  %t138 = load i64, ptr %t137, !tbaa !34
  %t140 = add i64 %t138, 1
  %t143 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !27
  %t145 = getelementptr i64, ptr %t144, i64 %t130
  store i64 %t140, ptr %t145, !tbaa !34
  br label %bb32
bb32:
  %t146 = load i64, ptr %l18, !tbaa !24
  %t149 = add i64 %t146, 1
  store i64 %t149, ptr %l18, !tbaa !24
  br label %bb26
bb33:
  store { i64, ptr } %a4, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t153 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t153, 0
  store i64 %t155, ptr %l22, !tbaa !24
  br label %bb34
bb34:
  %t157 = load i64, ptr %l21, !tbaa !24
  %t158 = load i64, ptr %l22, !tbaa !24
  %t161 = icmp slt i64 %t157, %t158
  %t163 = xor i1 %t161, true
  br i1 %t163, label %bb35, label %bb36
bb35:
  br label %bb43
bb36:
  br label %bb37
bb37:
  %t165 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t165, ptr %l99, !tbaa !27
  %t166 = load i64, ptr %l21, !tbaa !24
  %t168 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !27
  %t170 = getelementptr %"compiler/source:Span", ptr %t169, i64 %t166
  %t171 = load %"compiler/source:Span", ptr %t170
  store %"compiler/source:Span" %t171, ptr %l23
  %t173 = getelementptr %"compiler/fmt:formatter", ptr %l7, i32 0, i32 33
  store ptr %t173, ptr %l102, !tbaa !29
  %t174 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t175 = getelementptr %"compiler/source:Span", ptr %l23, i32 0, i32 0
  %t176 = load i32, ptr %t175, !tbaa !23
  %t178 = sext i32 %t176 to i64
  %t181 = call i64 @compiler_2ffmt_2elineStartOf(ptr %v0, { i64, ptr } %t174, i64 %t178)
  store i64 %t181, ptr %l106
  br label %bb38
bb38:
  %t182 = load ptr, ptr %l102, !tbaa !29
  %t183 = load i64, ptr %l106, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t182, i64 %t183)
  br label %bb39
bb39:
  %t184 = getelementptr %"compiler/fmt:formatter", ptr %l7, i32 0, i32 34
  store ptr %t184, ptr %l107, !tbaa !29
  %t185 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t186 = getelementptr %"compiler/source:Span", ptr %l23, i32 0, i32 1
  %t187 = load i32, ptr %t186, !tbaa !23
  %t189 = sext i32 %t187 to i64
  %t191 = sub i64 %t189, 1
  %t194 = call i64 @compiler_2ffmt_2elineEndOf(ptr %v0, { i64, ptr } %t185, i64 %t191)
  store i64 %t194, ptr %l112
  br label %bb40
bb40:
  %t195 = load ptr, ptr %l107, !tbaa !29
  %t196 = load i64, ptr %l112, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t195, i64 %t196)
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t197 = load i64, ptr %l21, !tbaa !24
  %t200 = add i64 %t197, 1
  store i64 %t200, ptr %l21, !tbaa !24
  br label %bb34
bb43:
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2erun(ptr %s0, ptr %l7)
  br label %bb44
bb44:
  %t204 = call { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ewrite(ptr %s0, ptr %v7, ptr %l7)
  store { i64, ptr } %t204, ptr %l118
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s0)
  %t205 = load { i64, ptr }, ptr %l118, !tbaa !27
  store { i64, ptr } %t205, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ffmt_2eOracleFor(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l4 = alloca %"compiler/fmt:loader"
  %l5 = alloca i64
  %lp6 = alloca ptr
  %l8 = alloca %"compiler/fmt:loader"
  %l11 = alloca i64
  %l12 = alloca %"compiler/parse:Oracle"
  %l20 = alloca %"compiler/parse:Oracle"
  %s0 = alloca %olang.scope
  %t2 = alloca %"compiler/fmt:loader", align 8
  %t9 = alloca %"compiler/parse:Oracle", align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @compiler_2ffmt_3aloader_2ector(ptr %t2, ptr %v1, ptr %s0, { i64, ptr } %a1)
  call void @llvm.memmove.p0.p0.i64(ptr %l8, ptr %t2, i64 176, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %l8, i64 176, i1 false)
  %t7 = call i64 @compiler_2ffmt_2ecompiler_2ffmt_3aloader_2eload(ptr %s0, ptr %v0, ptr %l4, { i64, ptr } %a0)
  store i64 %t7, ptr %l11
  br label %bb2
bb2:
  %t8 = load i64, ptr %l11, !tbaa !24
  store i64 %t8, ptr %l5, !tbaa !24
  call void @compiler_2fparse_3aOracle_2ector(ptr %t9, ptr %v4)
  call void @llvm.memmove.p0.p0.i64(ptr %l12, ptr %t9, i64 288, i1 false)
  br label %bb3
bb3:
  %t10 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 288, i64 8)
  store ptr %t10, ptr %lp6
  %t11 = load ptr, ptr %lp6
  call void @llvm.memmove.p0.p0.i64(ptr %t11, ptr %l12, i64 288, i1 false)
  %t12 = load i64, ptr %l5, !tbaa !24
  %t14 = icmp sge i64 %t12, 0
  br i1 %t14, label %bb4, label %bb5
bb4:
  %t16 = load ptr, ptr %lp6
  %t18 = load i64, ptr %l5, !tbaa !24
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aloader_2eoracle(ptr %s0, ptr %v4, ptr %v3, ptr %v2, ptr %l4, ptr %t16, ptr %a3, i64 %t18, { i64, ptr } %a2)
  br label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb7
bb7:
  %t25 = load ptr, ptr %lp6
  call void @llvm.memmove.p0.p0.i64(ptr %l20, ptr %t25, i64 288, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l20, i64 288, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2easWritten(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l7 = alloca i1
  %l8 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/fmt:formatter", ptr %a0, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  %t7 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !27
  %t9 = getelementptr %"compiler/token:Token", ptr %t8, i64 %a1
  %t10 = load %"compiler/token:Token", ptr %t9
  %t11 = load i8, ptr @G_2ecompiler_2ftoken_2eSpace, !tbaa !22
  %t14 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t10, i8 %t11)
  store i1 %t14, ptr %l7
  br label %bb1
bb1:
  %t15 = load i1, ptr %l7, !tbaa !21
  br i1 %t15, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr %l8, !tbaa !27
  br label %bb4
bb3:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %l8, !tbaa !27
  br label %bb4
bb4:
  %t16 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t16, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ebefore(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l10 = alloca i64
  %l12 = alloca { i64, ptr }
  %l16 = alloca i64
  %l19 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp sle i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 -1, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/fmt:formatter", ptr %t6, i32 0, i32 8
  %t9 = load i64, ptr %l1, !tbaa !24
  %t11 = sub i64 %t9, 1
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t8, i64 %t11)
  store i64 %t14, ptr %l10
  br label %bb4
bb4:
  %t15 = load i64, ptr %l10, !tbaa !24
  store i64 %t15, ptr %l2, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/fmt:formatter", ptr %t16, i32 0, i32 1
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  store { i64, ptr } %t19, ptr %l12, !tbaa !27
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/fmt:formatter", ptr %t20, i32 0, i32 8
  %t23 = load i64, ptr %l1, !tbaa !24
  %t26 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t22, i64 %t23)
  store i64 %t26, ptr %l16
  br label %bb5
bb5:
  %t27 = load i64, ptr %l16, !tbaa !24
  %t28 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr %"compiler/token:Token", ptr %t29, i64 %t27
  %t31 = load %"compiler/token:Token", ptr %t30
  %t32 = load i8, ptr @G_2ecompiler_2ftoken_2eLineBreak, !tbaa !22
  %t35 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t31, i8 %t32)
  store i1 %t35, ptr %l19
  br label %bb6
bb6:
  %t36 = load i1, ptr %l19, !tbaa !21
  br i1 %t36, label %bb7, label %bb8
bb7:
  store i64 -1, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t38 = load i64, ptr %l2, !tbaa !24
  store i64 %t38, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ecomment(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i1 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l16 = alloca i1
  %l18 = alloca { i64, ptr }
  %l23 = alloca i1
  %l25 = alloca { i64, ptr }
  %l37 = alloca ptr
  %l40 = alloca i64
  %l48 = alloca ptr
  %l51 = alloca i64
  %l62 = alloca i64
  %l65 = alloca i64
  %l74 = alloca i64
  %l77 = alloca i1
  %l88 = alloca { i64, ptr }
  %l97 = alloca ptr
  %l99 = alloca { i64, ptr }
  %l100 = alloca i64
  %l101 = alloca i64
  %l102 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t3 = xor i1 %a3, true
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb20
bb3:
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load i64, ptr %l1, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb4, label %bb5
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/fmt:formatter", ptr %t11, i32 0, i32 0
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  store { i64, ptr } %t14, ptr %l18, !tbaa !27
  %t15 = load i64, ptr %l2, !tbaa !24
  %t17 = sub i64 %t15, 1
  %t19 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr i8, ptr %t20, i64 %t17
  %t22 = load i8, ptr %t21, !tbaa !32
  %t24 = icmp eq i8 %t22, 32
  br i1 %t24, label %bb6, label %bb7
bb5:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb9
bb6:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb8
bb7:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/fmt:formatter", ptr %t26, i32 0, i32 0
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  store { i64, ptr } %t29, ptr %l25, !tbaa !27
  %t30 = load i64, ptr %l2, !tbaa !24
  %t32 = sub i64 %t30, 1
  %t34 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr i8, ptr %t35, i64 %t32
  %t37 = load i8, ptr %t36, !tbaa !32
  %t39 = icmp eq i8 %t37, 9
  store i1 %t39, ptr %l23, !tbaa !21
  br label %bb8
bb8:
  %t41 = load i1, ptr %l23, !tbaa !21
  store i1 %t41, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t42 = load i1, ptr %l16, !tbaa !21
  %t43 = xor i1 %t42, true
  br i1 %t43, label %bb10, label %bb11
bb10:
  br label %bb14
bb11:
  br label %bb12
bb12:
  %t45 = load i64, ptr %l2, !tbaa !24
  %t48 = sub i64 %t45, 1
  store i64 %t48, ptr %l2, !tbaa !24
  br label %bb13
bb13:
  br label %bb3
bb14:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/fmt:formatter", ptr %t50, i32 0, i32 21
  %t53 = load i1, ptr %t52, !tbaa !21
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb15, label %bb16
bb15:
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l37, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i64, ptr %l4, !tbaa !24
  %t62 = call i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2elevelAt(ptr %v0, ptr %t58, i64 %t59)
  store i64 %t62, ptr %l40
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t63 = load ptr, ptr %l37, !tbaa !29
  %t64 = load i64, ptr %l40, !tbaa !24
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ebegin(ptr %v0, ptr %t63, i64 %t64)
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load i64, ptr %l1, !tbaa !24
  %t69 = getelementptr %"compiler/fmt:formatter", ptr %t65, i32 0, i32 27
  store i64 %t66, ptr %t69, !tbaa !24
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load i64, ptr %l2, !tbaa !24
  %t74 = getelementptr %"compiler/fmt:formatter", ptr %t70, i32 0, i32 28
  store i64 %t71, ptr %t74, !tbaa !24
  br label %ret
bb20:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/fmt:formatter", ptr %t75, i32 0, i32 21
  %t78 = load i1, ptr %t77, !tbaa !21
  %t80 = xor i1 %t78, true
  br i1 %t80, label %bb21, label %bb22
bb21:
  %t82 = load ptr, ptr %l0, !tbaa !29
  store ptr %t82, ptr %l48, !tbaa !29
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load i64, ptr %l4, !tbaa !24
  %t87 = call i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2elevelAt(ptr %v0, ptr %t83, i64 %t84)
  store i64 %t87, ptr %l51
  br label %bb23
bb22:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/fmt:formatter", ptr %t88, i32 0, i32 29
  %t91 = load i64, ptr %t90, !tbaa !24
  %t93 = icmp ne i64 %t91, 0
  br i1 %t93, label %bb25, label %bb26
bb23:
  %t95 = load ptr, ptr %l48, !tbaa !29
  %t96 = load i64, ptr %l51, !tbaa !24
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ebegin(ptr %v0, ptr %t95, i64 %t96)
  br label %bb24
bb24:
  br label %bb29
bb25:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/fmt:formatter", ptr %t97, i32 0, i32 20
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t99, i8 32)
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t101 = load i64, ptr %l1, !tbaa !24
  store i64 %t101, ptr %l5, !tbaa !24
  %t103 = load i64, ptr %l2, !tbaa !24
  store i64 %t103, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t105 = load i64, ptr %l6, !tbaa !24
  %t106 = load i64, ptr %l5, !tbaa !24
  %t109 = icmp sgt i64 %t105, %t106
  br i1 %t109, label %bb30, label %bb31
bb30:
  %t111 = load i64, ptr %l7, !tbaa !24
  %t113 = icmp sgt i64 %t111, 0
  br i1 %t113, label %bb32, label %bb33
bb31:
  store i64 0, ptr %l62, !tbaa !24
  br label %bb35
bb32:
  %t115 = load i64, ptr %l6, !tbaa !24
  %t116 = load i64, ptr %l5, !tbaa !24
  %t119 = sub i64 %t115, %t116
  %t120 = load i64, ptr %l7, !tbaa !24
  %t123 = add i64 %t119, %t120
  %t125 = sub i64 %t123, 1
  %t126 = load i64, ptr %l7, !tbaa !24
  %t129 = sdiv i64 %t125, %t126
  store i64 %t129, ptr %l65, !tbaa !24
  br label %bb34
bb33:
  store i64 0, ptr %l65, !tbaa !24
  br label %bb34
bb34:
  %t131 = load i64, ptr %l65, !tbaa !24
  store i64 %t131, ptr %l62, !tbaa !24
  br label %bb35
bb35:
  %t132 = load i64, ptr %l62, !tbaa !24
  store i64 %t132, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  %t133 = load i64, ptr %l8, !tbaa !24
  %t134 = sub i64 %t133, 1
  store i64 %t134, ptr %l74, !tbaa !24
  %t135 = load i64, ptr %l8, !tbaa !24
  %t136 = icmp slt i64 %t135, 2147483648
  %t137 = load i64, ptr %l9, !tbaa !24
  %t138 = icmp sge i64 %t137, 0
  %t141 = and i1 %t136, %t138
  store i1 %t141, ptr %l77, !tbaa !21
  br label %bb36
bb36:
  %t142 = load i64, ptr %l9, !tbaa !24
  %t143 = load i64, ptr %l8, !tbaa !24
  %t146 = icmp slt i64 %t142, %t143
  %t148 = xor i1 %t146, true
  br i1 %t148, label %bb37, label %bb38
bb37:
  br label %bb44
bb38:
  br label %bb39
bb39:
  %t150 = load i64, ptr %l5, !tbaa !24
  %t151 = load i64, ptr %l9, !tbaa !24
  %t152 = load i64, ptr %l7, !tbaa !24
  %t155 = mul i64 %t151, %t152
  %t158 = add i64 %t150, %t155
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/fmt:formatter", ptr %t160, i32 0, i32 0
  %t163 = load { i64, ptr }, ptr %t162, !tbaa !27
  store { i64, ptr } %t163, ptr %l88, !tbaa !27
  %t166 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = getelementptr i8, ptr %t167, i64 %t158
  %t169 = load i8, ptr %t168, !tbaa !32
  %t171 = icmp eq i8 %t169, 10
  br i1 %t171, label %bb40, label %bb41
bb40:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/fmt:formatter", ptr %t173, i32 0, i32 26
  store i1 true, ptr %t175, !tbaa !21
  br label %bb42
bb41:
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t176 = load i64, ptr %l9, !tbaa !24
  %t179 = add i64 %t176, 1
  store i64 %t179, ptr %l9, !tbaa !24
  br label %bb36
bb44:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = getelementptr %"compiler/fmt:formatter", ptr %t181, i32 0, i32 20
  store ptr %t183, ptr %l97, !tbaa !29
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/fmt:formatter", ptr %t184, i32 0, i32 0
  %t187 = load { i64, ptr }, ptr %t186, !tbaa !27
  store { i64, ptr } %t187, ptr %l99, !tbaa !27
  %t188 = load i64, ptr %l1, !tbaa !24
  store i64 %t188, ptr %l100, !tbaa !24
  %t189 = load i64, ptr %l2, !tbaa !24
  store i64 %t189, ptr %l101, !tbaa !24
  %t190 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t190, 0
  store i64 %t191, ptr %l102, !tbaa !24
  %t192 = load i64, ptr %l100, !tbaa !24
  %t193 = icmp sge i64 %t192, 0
  br i1 %t193, label %bb45, label %bb46
bb45:
  %t195 = load i64, ptr %l100, !tbaa !24
  %t196 = load i64, ptr %l101, !tbaa !24
  %t197 = icmp sle i64 %t195, %t196
  br i1 %t197, label %bb47, label %bb48
bb46:
  call void @__olang_check_failed(ptr @olang_loc_efe0301a0eee46c_f87ee963c45aa130)
  unreachable
bb47:
  %t199 = load i64, ptr %l101, !tbaa !24
  %t200 = load i64, ptr %l102, !tbaa !24
  %t201 = icmp sle i64 %t199, %t200
  br i1 %t201, label %bb49, label %bb50
bb48:
  call void @__olang_check_failed(ptr @olang_loc_efe0301a0eee46c_f87ee963c45aa130)
  unreachable
bb49:
  %t203 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t204 = load ptr, ptr %t203, !tbaa !27
  %t205 = load i64, ptr %l100, !tbaa !24
  %t206 = load i64, ptr %l101, !tbaa !24
  %t207 = getelementptr i8, ptr %t204, i64 %t205
  %t208 = sub i64 %t206, %t205
  %t209 = insertvalue { i64, ptr } undef, i64 %t208, 0
  %t210 = insertvalue { i64, ptr } %t209, ptr %t207, 1
  %t211 = load ptr, ptr %l97, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v0, ptr %t211, { i64, ptr } %t210)
  br label %bb51
bb50:
  call void @__olang_check_failed(ptr @olang_loc_efe0301a0eee46c_f87ee963c45aa130)
  unreachable
bb51:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = getelementptr %"compiler/fmt:formatter", ptr %t213, i32 0, i32 29
  store i64 2, ptr %t215, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2edropBlank(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i64
  %l7 = alloca i1
  %l12 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/fmt:formatter", ptr %t1, i32 0, i32 13
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  store i64 %t6, ptr %l1, !tbaa !24
  %t7 = load i64, ptr %l1, !tbaa !24
  %t9 = icmp eq i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb5
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/fmt:formatter", ptr %t11, i32 0, i32 13
  %t14 = load i64, ptr %l1, !tbaa !24
  %t16 = sub i64 %t14, 1
  %t19 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t13, i64 %t16)
  store i64 %t19, ptr %l12
  br label %bb4
bb4:
  %t20 = load i64, ptr %l12, !tbaa !24
  %t21 = icmp ne i64 %t20, 1
  store i1 %t21, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t23 = load i1, ptr %l7, !tbaa !21
  br i1 %t23, label %bb6, label %bb7
bb6:
  br label %ret
bb7:
  br label %bb8
bb8:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/fmt:formatter", ptr %t24, i32 0, i32 13
  %t27 = load i64, ptr %l1, !tbaa !24
  %t29 = sub i64 %t27, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t26, i64 %t29)
  br label %bb9
bb9:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/fmt:formatter", ptr %t32, i32 0, i32 14
  %t35 = load i64, ptr %l1, !tbaa !24
  %t37 = sub i64 %t35, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t34, i64 %t37)
  br label %bb10
bb10:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/fmt:formatter", ptr %t40, i32 0, i32 15
  %t43 = load i64, ptr %l1, !tbaa !24
  %t45 = sub i64 %t43, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t42, i64 %t45)
  br label %bb11
bb11:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/fmt:formatter", ptr %t48, i32 0, i32 16
  %t51 = load i64, ptr %l1, !tbaa !24
  %t53 = sub i64 %t51, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t50, i64 %t53)
  br label %bb12
bb12:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/fmt:formatter", ptr %t56, i32 0, i32 17
  %t59 = load i64, ptr %l1, !tbaa !24
  %t61 = sub i64 %t59, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t58, i64 %t61)
  br label %bb13
bb13:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/fmt:formatter", ptr %t64, i32 0, i32 18
  %t67 = load i64, ptr %l1, !tbaa !24
  %t69 = sub i64 %t67, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t66, i64 %t69)
  br label %bb14
bb14:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/fmt:formatter", ptr %t72, i32 0, i32 19
  %t75 = load i64, ptr %l1, !tbaa !24
  %t77 = sub i64 %t75, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eTruncate_3cBool_3e(ptr %v0, ptr %t74, i64 %t77)
  br label %bb15
bb15:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2eellipsisAt(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l8 = alloca i1
  %l11 = alloca i1
  %l15 = alloca i32
  %l22 = alloca i32
  %l26 = alloca i1
  %l30 = alloca i32
  %l36 = alloca { i64, ptr }
  %l41 = alloca i1
  %l43 = alloca i1
  %l45 = alloca { i64, ptr }
  %l50 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = add i64 %t1, 2
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/fmt:formatter", ptr %t4, i32 0, i32 1
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t12 = icmp sge i64 %t3, %t9
  br i1 %t12, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb7
bb2:
  %t14 = load i64, ptr %l1, !tbaa !24
  %t16 = icmp sgt i64 %t14, 0
  br i1 %t16, label %bb3, label %bb4
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i64, ptr %l1, !tbaa !24
  %t21 = sub i64 %t19, 1
  %t24 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t18, i64 %t21)
  store i32 %t24, ptr %l15
  br label %bb5
bb4:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb6
bb5:
  %t25 = load i32, ptr %l15, !range !{i32 0, i32 116}
  %t27 = trunc i64 76 to i32
  %t28 = icmp eq i32 %t25, %t27
  store i1 %t28, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t30 = load i1, ptr %l11, !tbaa !21
  store i1 %t30, ptr %l8, !tbaa !21
  br label %bb7
bb7:
  %t31 = load i1, ptr %l8, !tbaa !21
  br i1 %t31, label %bb8, label %bb9
bb8:
  store i1 false, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i64, ptr %l1, !tbaa !24
  %t36 = add i64 %t34, 1
  %t39 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t33, i64 %t36)
  store i32 %t39, ptr %l22
  br label %bb11
bb11:
  %t40 = load i32, ptr %l22, !range !{i32 0, i32 116}
  %t42 = trunc i64 76 to i32
  %t43 = icmp eq i32 %t40, %t42
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb15
bb13:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i64, ptr %l1, !tbaa !24
  %t50 = add i64 %t48, 2
  %t53 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t47, i64 %t50)
  store i32 %t53, ptr %l30
  br label %bb14
bb14:
  %t54 = load i32, ptr %l30, !range !{i32 0, i32 116}
  %t56 = trunc i64 76 to i32
  %t57 = icmp eq i32 %t54, %t56
  %t59 = xor i1 %t57, true
  store i1 %t59, ptr %l26, !tbaa !21
  br label %bb15
bb15:
  %t61 = load i1, ptr %l26, !tbaa !21
  br i1 %t61, label %bb16, label %bb17
bb16:
  store i1 false, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/fmt:formatter", ptr %t63, i32 0, i32 1
  %t66 = load { i64, ptr }, ptr %t65, !tbaa !27
  store { i64, ptr } %t66, ptr %l36, !tbaa !27
  %t67 = load i64, ptr %l1, !tbaa !24
  %t69 = add i64 %t67, 1
  %t71 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr %"compiler/token:Token", ptr %t72, i64 %t69
  %t74 = load %"compiler/token:Token", ptr %t73
  %t75 = load i8, ptr @G_2ecompiler_2ftoken_2eSpace, !tbaa !22
  %t78 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t74, i8 %t75)
  store i1 %t78, ptr %l41
  br label %bb19
bb19:
  %t79 = load i1, ptr %l41, !tbaa !21
  %t80 = xor i1 %t79, true
  br i1 %t80, label %bb20, label %bb21
bb20:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/fmt:formatter", ptr %t82, i32 0, i32 1
  %t85 = load { i64, ptr }, ptr %t84, !tbaa !27
  store { i64, ptr } %t85, ptr %l45, !tbaa !27
  %t86 = load i64, ptr %l1, !tbaa !24
  %t88 = add i64 %t86, 2
  %t90 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr %"compiler/token:Token", ptr %t91, i64 %t88
  %t93 = load %"compiler/token:Token", ptr %t92
  %t94 = load i8, ptr @G_2ecompiler_2ftoken_2eSpace, !tbaa !22
  %t97 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t93, i8 %t94)
  store i1 %t97, ptr %l50
  br label %bb22
bb21:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb23
bb22:
  %t98 = load i1, ptr %l50, !tbaa !21
  %t99 = xor i1 %t98, true
  store i1 %t99, ptr %l43, !tbaa !21
  br label %bb23
bb23:
  %t101 = load i1, ptr %l43, !tbaa !21
  store i1 %t101, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2egap(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i8
  %l7 = alloca i64
  %l8 = alloca i1
  %l16 = alloca { i64, ptr }
  %l24 = alloca ptr
  %l38 = alloca i1
  %l39 = alloca { i64, ptr }
  %l51 = alloca i1
  %l52 = alloca { i64, ptr }
  %l56 = alloca i1
  %l57 = alloca { i64, ptr }
  %l67 = alloca i64
  %l72 = alloca i64
  %l79 = alloca i1
  %l80 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/fmt:formatter", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l4, !tbaa !27
  store i64 %a1, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l5, !tbaa !24
  %t9 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp slt i64 %t8, %t9
  %t14 = xor i1 %t12, true
  br i1 %t14, label %bb2, label %bb3
bb2:
  br label %bb47
bb3:
  br label %bb4
bb4:
  %t16 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t16, ptr %l16, !tbaa !27
  %t17 = load i64, ptr %l5, !tbaa !24
  %t19 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr i8, ptr %t20, i64 %t17
  %t22 = load i8, ptr %t21, !tbaa !32
  store i8 %t22, ptr %l6, !tbaa !22
  %t24 = load i8, ptr %l6, !tbaa !22
  %t26 = icmp eq i8 %t24, 10
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/fmt:formatter", ptr %t28, i32 0, i32 21
  %t31 = load i1, ptr %t30, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb6:
  %t33 = load i8, ptr %l6, !tbaa !22
  %t35 = icmp eq i8 %t33, 35
  br i1 %t35, label %bb11, label %bb12
bb7:
  %t37 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2efinish(ptr %v0, ptr %t37)
  br label %bb9
bb8:
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l24, !tbaa !29
  %t40 = load ptr, ptr %l24, !tbaa !29
  %t41 = getelementptr %"compiler/fmt:formatter", ptr %t40, i32 0, i32 31
  %t42 = load i64, ptr %t41, !tbaa !24
  %t45 = add i64 %t42, 1
  %t47 = load ptr, ptr %l24, !tbaa !29
  %t48 = getelementptr %"compiler/fmt:formatter", ptr %t47, i32 0, i32 31
  store i64 %t45, ptr %t48, !tbaa !24
  br label %bb10
bb9:
  br label %bb10
bb10:
  %t49 = load i64, ptr %l5, !tbaa !24
  %t52 = add i64 %t49, 1
  store i64 %t52, ptr %l5, !tbaa !24
  br label %bb45
bb11:
  %t54 = load i64, ptr %l5, !tbaa !24
  %t56 = add i64 %t54, 1
  store i64 %t56, ptr %l7, !tbaa !24
  %t58 = load i64, ptr %l7, !tbaa !24
  %t59 = load i64, ptr %l2, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  br i1 %t62, label %bb13, label %bb14
bb12:
  %t64 = load i64, ptr %l5, !tbaa !24
  %t67 = add i64 %t64, 1
  store i64 %t67, ptr %l5, !tbaa !24
  br label %bb44
bb13:
  %t69 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t69, ptr %l39, !tbaa !27
  %t70 = load i64, ptr %l7, !tbaa !24
  %t72 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr i8, ptr %t73, i64 %t70
  %t75 = load i8, ptr %t74, !tbaa !32
  %t77 = icmp eq i8 %t75, 35
  store i1 %t77, ptr %l38, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb15
bb15:
  %t79 = load i1, ptr %l38, !tbaa !21
  store i1 %t79, ptr %l8, !tbaa !21
  %t80 = load i1, ptr %l8, !tbaa !21
  br i1 %t80, label %bb16, label %bb17
bb16:
  %t82 = load i64, ptr %l7, !tbaa !24
  %t85 = add i64 %t82, 1
  store i64 %t85, ptr %l7, !tbaa !24
  br label %bb18
bb17:
  br label %bb33
bb18:
  %t87 = load i64, ptr %l7, !tbaa !24
  %t89 = add i64 %t87, 1
  %t90 = load i64, ptr %l2, !tbaa !24
  %t93 = icmp slt i64 %t89, %t90
  br i1 %t93, label %bb19, label %bb20
bb19:
  %t95 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t95, ptr %l52, !tbaa !27
  %t96 = load i64, ptr %l7, !tbaa !24
  %t98 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr i8, ptr %t99, i64 %t96
  %t101 = load i8, ptr %t100, !tbaa !32
  %t103 = icmp eq i8 %t101, 35
  br i1 %t103, label %bb21, label %bb22
bb20:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb24
bb21:
  %t105 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t105, ptr %l57, !tbaa !27
  %t106 = load i64, ptr %l7, !tbaa !24
  %t108 = add i64 %t106, 1
  %t110 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr i8, ptr %t111, i64 %t108
  %t113 = load i8, ptr %t112, !tbaa !32
  %t115 = icmp eq i8 %t113, 35
  store i1 %t115, ptr %l56, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb23
bb23:
  %t117 = load i1, ptr %l56, !tbaa !21
  %t118 = xor i1 %t117, true
  store i1 %t118, ptr %l51, !tbaa !21
  br label %bb24
bb24:
  %t120 = load i1, ptr %l51, !tbaa !21
  %t121 = xor i1 %t120, true
  br i1 %t121, label %bb25, label %bb26
bb25:
  br label %bb29
bb26:
  br label %bb27
bb27:
  %t123 = load i64, ptr %l7, !tbaa !24
  %t126 = add i64 %t123, 1
  store i64 %t126, ptr %l7, !tbaa !24
  br label %bb28
bb28:
  br label %bb18
bb29:
  %t128 = load i64, ptr %l7, !tbaa !24
  store i64 %t128, ptr %l67, !tbaa !24
  %t129 = load i64, ptr %l67, !tbaa !24
  %t131 = add i64 %t129, 1
  %t132 = load i64, ptr %l2, !tbaa !24
  %t135 = icmp slt i64 %t131, %t132
  br i1 %t135, label %bb30, label %bb31
bb30:
  %t137 = load i64, ptr %l67, !tbaa !24
  %t139 = add i64 %t137, 2
  store i64 %t139, ptr %l72, !tbaa !24
  br label %bb32
bb31:
  %t141 = load i64, ptr %l2, !tbaa !24
  store i64 %t141, ptr %l72, !tbaa !24
  br label %bb32
bb32:
  %t143 = load i64, ptr %l72, !tbaa !24
  store i64 %t143, ptr %l7, !tbaa !24
  br label %bb42
bb33:
  %t144 = load i64, ptr %l7, !tbaa !24
  %t145 = load i64, ptr %l2, !tbaa !24
  %t148 = icmp slt i64 %t144, %t145
  br i1 %t148, label %bb34, label %bb35
bb34:
  %t150 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t150, ptr %l80, !tbaa !27
  %t151 = load i64, ptr %l7, !tbaa !24
  %t153 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = getelementptr i8, ptr %t154, i64 %t151
  %t156 = load i8, ptr %t155, !tbaa !32
  %t158 = icmp ne i8 %t156, 10
  store i1 %t158, ptr %l79, !tbaa !21
  br label %bb36
bb35:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb36
bb36:
  %t160 = load i1, ptr %l79, !tbaa !21
  %t161 = xor i1 %t160, true
  br i1 %t161, label %bb37, label %bb38
bb37:
  br label %bb41
bb38:
  br label %bb39
bb39:
  %t163 = load i64, ptr %l7, !tbaa !24
  %t166 = add i64 %t163, 1
  store i64 %t166, ptr %l7, !tbaa !24
  br label %bb40
bb40:
  br label %bb33
bb41:
  br label %bb42
bb42:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t169 = load i64, ptr %l5, !tbaa !24
  %t170 = load i64, ptr %l7, !tbaa !24
  %t171 = load i1, ptr %l8, !tbaa !21
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ecomment(ptr %v0, ptr %t168, i64 %t169, i64 %t170, i1 %t171, i64 %a3)
  br label %bb43
bb43:
  %t178 = load i64, ptr %l7, !tbaa !24
  store i64 %t178, ptr %l5, !tbaa !24
  br label %bb44
bb44:
  br label %bb45
bb45:
  br label %bb46
bb46:
  br label %bb1
bb47:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2eheldAt(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l38 = alloca i64
  %l41 = alloca i1
  %l42 = alloca i64
  %l46 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/fmt:formatter", ptr %t1, i32 0, i32 33
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i64, ptr %l10, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l3, !tbaa !24
  %t18 = load i64, ptr %l2, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l17, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l17, !tbaa !24
  store i64 %t33, ptr %l14, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l14, !tbaa !24
  store i64 %t34, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l6, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb21
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l2, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l7, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/fmt:formatter", ptr %t53, i32 0, i32 33
  %t56 = load i64, ptr %l7, !tbaa !24
  %t59 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t55, i64 %t56)
  store i64 %t59, ptr %l38
  br label %bb12
bb12:
  %t60 = load i64, ptr %l1, !tbaa !24
  %t61 = load i64, ptr %l38, !tbaa !24
  %t63 = icmp sle i64 %t61, %t60
  br i1 %t63, label %bb13, label %bb14
bb13:
  %t65 = load i64, ptr %l1, !tbaa !24
  store i64 %t65, ptr %l42, !tbaa !24
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/fmt:formatter", ptr %t66, i32 0, i32 34
  %t69 = load i64, ptr %l7, !tbaa !24
  %t72 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t68, i64 %t69)
  store i64 %t72, ptr %l46
  br label %bb15
bb14:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb16
bb15:
  %t73 = load i64, ptr %l42, !tbaa !24
  %t74 = load i64, ptr %l46, !tbaa !24
  %t75 = icmp sle i64 %t73, %t74
  store i1 %t75, ptr %l41, !tbaa !21
  br label %bb16
bb16:
  %t77 = load i1, ptr %l41, !tbaa !21
  br i1 %t77, label %bb17, label %bb18
bb17:
  %t78 = load i64, ptr %l7, !tbaa !24
  store i64 %t78, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t80 = load i64, ptr %l6, !tbaa !24
  %t83 = add i64 %t80, 1
  store i64 %t83, ptr %l6, !tbaa !24
  br label %bb8
bb21:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2elevelAt(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca i64
  %l8 = alloca i64
  %l11 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2echild(ptr %v0, ptr %t1)
  store i64 %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load i64, ptr %l4, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = icmp slt i64 %t5, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load i64, ptr %l2, !tbaa !24
  store i64 %t9, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load i64, ptr %l2, !tbaa !24
  store i64 %t11, ptr %l8, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i64, ptr %l1, !tbaa !24
  %t16 = call i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2econt(ptr %v0, ptr %t12, i64 %t13)
  store i64 %t16, ptr %l11
  br label %bb5
bb5:
  %t17 = load i64, ptr %l8, !tbaa !24
  %t18 = load i64, ptr %l11, !tbaa !24
  %t19 = add i64 %t17, %t18
  store i64 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2emarkEntries(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i32
  %l19 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i64
  %l47 = alloca i64
  %l50 = alloca i32
  %l54 = alloca i1
  %l56 = alloca { i64, ptr }
  %l63 = alloca i64
  %l67 = alloca i64
  %l70 = alloca i64
  %l91 = alloca i64
  %l94 = alloca i32
  %l97 = alloca i1
  %l100 = alloca i1
  %l108 = alloca i1
  %l111 = alloca i1
  %l114 = alloca i1
  %l119 = alloca i1
  %l122 = alloca i1
  %l130 = alloca i1
  %l134 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/fmt:formatter", ptr %t1, i32 0, i32 8
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l19
  br label %bb1
bb1:
  %t6 = load i64, ptr %l19, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load i64, ptr %l1, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l3, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l2, !tbaa !24
  %t18 = load i64, ptr %l1, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l26, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l26, !tbaa !24
  store i64 %t33, ptr %l23, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l23, !tbaa !24
  store i64 %t34, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l5, !tbaa !24
  %t36 = load i64, ptr %l4, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb72
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l1, !tbaa !24
  %t44 = load i64, ptr %l5, !tbaa !24
  %t45 = load i64, ptr %l3, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l6, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/fmt:formatter", ptr %t53, i32 0, i32 8
  %t56 = load i64, ptr %l6, !tbaa !24
  %t59 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t55, i64 %t56)
  store i64 %t59, ptr %l47
  br label %bb12
bb12:
  %t60 = load i64, ptr %l47, !tbaa !24
  store i64 %t60, ptr %l7, !tbaa !24
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load i64, ptr %l7, !tbaa !24
  %t65 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t61, i64 %t62)
  store i32 %t65, ptr %l50
  br label %bb13
bb13:
  %t66 = load i32, ptr %l50, !range !{i32 0, i32 116}
  %t68 = trunc i64 112 to i32
  %t69 = icmp eq i32 %t66, %t68
  %t71 = xor i1 %t69, true
  br i1 %t71, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l54, !tbaa !21
  br label %bb16
bb15:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/fmt:formatter", ptr %t73, i32 0, i32 7
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  store { i64, ptr } %t76, ptr %l56, !tbaa !27
  %t77 = load i64, ptr %l7, !tbaa !24
  %t79 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr i1, ptr %t80, i64 %t77
  %t82 = load i1, ptr %t81, !tbaa !31
  store i1 %t82, ptr %l54, !tbaa !21
  br label %bb16
bb16:
  %t84 = load i1, ptr %l54, !tbaa !21
  br i1 %t84, label %bb17, label %bb18
bb17:
  br label %bb71
bb18:
  br label %bb19
bb19:
  store i64 0, ptr %l8, !tbaa !24
  %t85 = load i64, ptr %l6, !tbaa !24
  %t87 = add i64 %t85, 1
  store i64 %t87, ptr %l9, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/fmt:formatter", ptr %t89, i32 0, i32 8
  %t93 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t91)
  store i64 %t93, ptr %l63
  br label %bb20
bb20:
  %t94 = load i64, ptr %l63, !tbaa !24
  store i64 %t94, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t95 = load i64, ptr %l10, !tbaa !24
  %t96 = load i64, ptr %l9, !tbaa !24
  %t99 = icmp sgt i64 %t95, %t96
  br i1 %t99, label %bb21, label %bb22
bb21:
  %t101 = load i64, ptr %l11, !tbaa !24
  %t103 = icmp sgt i64 %t101, 0
  br i1 %t103, label %bb23, label %bb24
bb22:
  store i64 0, ptr %l67, !tbaa !24
  br label %bb26
bb23:
  %t105 = load i64, ptr %l10, !tbaa !24
  %t106 = load i64, ptr %l9, !tbaa !24
  %t109 = sub i64 %t105, %t106
  %t110 = load i64, ptr %l11, !tbaa !24
  %t113 = add i64 %t109, %t110
  %t115 = sub i64 %t113, 1
  %t116 = load i64, ptr %l11, !tbaa !24
  %t119 = sdiv i64 %t115, %t116
  store i64 %t119, ptr %l70, !tbaa !24
  br label %bb25
bb24:
  store i64 0, ptr %l70, !tbaa !24
  br label %bb25
bb25:
  %t121 = load i64, ptr %l70, !tbaa !24
  store i64 %t121, ptr %l67, !tbaa !24
  br label %bb26
bb26:
  %t122 = load i64, ptr %l67, !tbaa !24
  store i64 %t122, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb27
bb27:
  %t123 = load i64, ptr %l13, !tbaa !24
  %t124 = load i64, ptr %l12, !tbaa !24
  %t127 = icmp slt i64 %t123, %t124
  %t129 = xor i1 %t127, true
  br i1 %t129, label %bb28, label %bb29
bb28:
  br label %bb70
bb29:
  br label %bb30
bb30:
  %t131 = load i64, ptr %l9, !tbaa !24
  %t132 = load i64, ptr %l13, !tbaa !24
  %t133 = load i64, ptr %l11, !tbaa !24
  %t136 = mul i64 %t132, %t133
  %t139 = add i64 %t131, %t136
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/fmt:formatter", ptr %t141, i32 0, i32 8
  %t147 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t143, i64 %t139)
  store i64 %t147, ptr %l91
  br label %bb31
bb31:
  %t148 = load i64, ptr %l91, !tbaa !24
  store i64 %t148, ptr %l15, !tbaa !24
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load i64, ptr %l15, !tbaa !24
  %t153 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t149, i64 %t150)
  store i32 %t153, ptr %l94
  br label %bb32
bb32:
  %t154 = load i32, ptr %l94, !range !{i32 0, i32 116}
  store i32 %t154, ptr %l16
  %t155 = load i32, ptr %l16, !range !{i32 0, i32 116}
  %t157 = trunc i64 110 to i32
  %t158 = icmp eq i32 %t155, %t157
  br i1 %t158, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l97, !tbaa !21
  br label %bb35
bb34:
  %t160 = load i32, ptr %l16, !range !{i32 0, i32 116}
  %t162 = trunc i64 112 to i32
  %t163 = icmp eq i32 %t160, %t162
  store i1 %t163, ptr %l97, !tbaa !21
  br label %bb35
bb35:
  %t165 = load i1, ptr %l97, !tbaa !21
  br i1 %t165, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l100, !tbaa !21
  br label %bb38
bb37:
  %t166 = load i32, ptr %l16, !range !{i32 0, i32 116}
  %t168 = trunc i64 114 to i32
  %t169 = icmp eq i32 %t166, %t168
  store i1 %t169, ptr %l100, !tbaa !21
  br label %bb38
bb38:
  %t171 = load i1, ptr %l100, !tbaa !21
  br i1 %t171, label %bb39, label %bb40
bb39:
  %t172 = load i64, ptr %l8, !tbaa !24
  %t175 = add i64 %t172, 1
  store i64 %t175, ptr %l8, !tbaa !24
  br label %bb41
bb40:
  br label %bb41
bb41:
  %t177 = load i32, ptr %l16, !range !{i32 0, i32 116}
  %t179 = trunc i64 111 to i32
  %t180 = icmp eq i32 %t177, %t179
  br i1 %t180, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l108, !tbaa !21
  br label %bb44
bb43:
  %t182 = load i32, ptr %l16, !range !{i32 0, i32 116}
  %t184 = trunc i64 113 to i32
  %t185 = icmp eq i32 %t182, %t184
  store i1 %t185, ptr %l108, !tbaa !21
  br label %bb44
bb44:
  %t187 = load i1, ptr %l108, !tbaa !21
  br i1 %t187, label %bb45, label %bb46
bb45:
  store i1 true, ptr %l111, !tbaa !21
  br label %bb47
bb46:
  %t188 = load i32, ptr %l16, !range !{i32 0, i32 116}
  %t190 = trunc i64 115 to i32
  %t191 = icmp eq i32 %t188, %t190
  store i1 %t191, ptr %l111, !tbaa !21
  br label %bb47
bb47:
  %t193 = load i1, ptr %l111, !tbaa !21
  br i1 %t193, label %bb48, label %bb49
bb48:
  %t194 = load i64, ptr %l8, !tbaa !24
  %t196 = icmp eq i64 %t194, 0
  store i1 %t196, ptr %l114, !tbaa !21
  br label %bb50
bb49:
  store i1 false, ptr %l114, !tbaa !21
  br label %bb50
bb50:
  %t198 = load i1, ptr %l114, !tbaa !21
  br i1 %t198, label %bb51, label %bb52
bb51:
  br label %bb70
bb52:
  br label %bb53
bb53:
  %t199 = load i32, ptr %l16, !range !{i32 0, i32 116}
  %t201 = trunc i64 111 to i32
  %t202 = icmp eq i32 %t199, %t201
  br i1 %t202, label %bb54, label %bb55
bb54:
  store i1 true, ptr %l119, !tbaa !21
  br label %bb56
bb55:
  %t204 = load i32, ptr %l16, !range !{i32 0, i32 116}
  %t206 = trunc i64 113 to i32
  %t207 = icmp eq i32 %t204, %t206
  store i1 %t207, ptr %l119, !tbaa !21
  br label %bb56
bb56:
  %t209 = load i1, ptr %l119, !tbaa !21
  br i1 %t209, label %bb57, label %bb58
bb57:
  store i1 true, ptr %l122, !tbaa !21
  br label %bb59
bb58:
  %t210 = load i32, ptr %l16, !range !{i32 0, i32 116}
  %t212 = trunc i64 115 to i32
  %t213 = icmp eq i32 %t210, %t212
  store i1 %t213, ptr %l122, !tbaa !21
  br label %bb59
bb59:
  %t215 = load i1, ptr %l122, !tbaa !21
  br i1 %t215, label %bb60, label %bb61
bb60:
  %t216 = load i64, ptr %l8, !tbaa !24
  %t219 = sub i64 %t216, 1
  store i64 %t219, ptr %l8, !tbaa !24
  br label %bb62
bb61:
  br label %bb62
bb62:
  %t221 = load i64, ptr %l8, !tbaa !24
  %t223 = icmp eq i64 %t221, 0
  br i1 %t223, label %bb63, label %bb64
bb63:
  %t225 = load i32, ptr %l16, !range !{i32 0, i32 116}
  %t227 = trunc i64 79 to i32
  %t228 = icmp eq i32 %t225, %t227
  store i1 %t228, ptr %l130, !tbaa !21
  br label %bb65
bb64:
  store i1 false, ptr %l130, !tbaa !21
  br label %bb65
bb65:
  %t230 = load i1, ptr %l130, !tbaa !21
  br i1 %t230, label %bb66, label %bb67
bb66:
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t233 = getelementptr %"compiler/fmt:formatter", ptr %t231, i32 0, i32 6
  %t234 = load { i64, ptr }, ptr %t233, !tbaa !27
  store { i64, ptr } %t234, ptr %l134, !tbaa !27
  %t235 = load i64, ptr %l15, !tbaa !24
  %t237 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t238 = load ptr, ptr %t237, !tbaa !27
  %t239 = getelementptr i1, ptr %t238, i64 %t235
  store i1 true, ptr %t239, !tbaa !31
  br label %bb68
bb67:
  br label %bb68
bb68:
  br label %bb69
bb69:
  %t240 = load i64, ptr %l13, !tbaa !24
  %t243 = add i64 %t240, 1
  store i64 %t243, ptr %l13, !tbaa !24
  br label %bb27
bb70:
  br label %bb71
bb71:
  %t245 = load i64, ptr %l5, !tbaa !24
  %t248 = add i64 %t245, 1
  store i64 %t248, ptr %l5, !tbaa !24
  br label %bb8
bb72:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2eparams(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l10 = alloca i1
  %l13 = alloca i32
  %l25 = alloca i32
  %l28 = alloca i1
  %l35 = alloca i1
  %l38 = alloca i1
  %l45 = alloca i1
  %l48 = alloca i32
  %l57 = alloca i1
  %l60 = alloca i32
  %l66 = alloca i1
  %l69 = alloca i32
  %l73 = alloca { i64, ptr }
  %l79 = alloca i1
  %l82 = alloca i32
  %l91 = alloca i1
  %l94 = alloca i32
  %l100 = alloca i1
  %l103 = alloca i32
  %l106 = alloca i1
  %l108 = alloca { i64, ptr }
  %l112 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = sub i64 %a1, 1
  store i64 %t3, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l2, !tbaa !24
  %t7 = icmp sge i64 %t5, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i64, ptr %l2, !tbaa !24
  %t13 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t9, i64 %t10)
  store i32 %t13, ptr %l13
  br label %bb4
bb3:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb5
bb4:
  %t14 = load i32, ptr %l13, !range !{i32 0, i32 116}
  %t16 = trunc i64 8 to i32
  %t17 = icmp eq i32 %t14, %t16
  store i1 %t17, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l10, !tbaa !21
  %t20 = xor i1 %t19, true
  br i1 %t20, label %bb6, label %bb7
bb6:
  br label %bb10
bb7:
  br label %bb8
bb8:
  %t22 = load i64, ptr %l2, !tbaa !24
  %t25 = sub i64 %t22, 1
  store i64 %t25, ptr %l2, !tbaa !24
  br label %bb9
bb9:
  br label %bb1
bb10:
  %t27 = load i64, ptr %l2, !tbaa !24
  %t29 = icmp slt i64 %t27, 0
  br i1 %t29, label %bb11, label %bb12
bb11:
  store i64 0, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i64, ptr %l2, !tbaa !24
  %t36 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t32, i64 %t33)
  store i32 %t36, ptr %l25
  br label %bb14
bb14:
  %t37 = load i32, ptr %l25, !range !{i32 0, i32 116}
  store i32 %t37, ptr %l3
  %t38 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t40 = trunc i64 37 to i32
  %t41 = icmp eq i32 %t38, %t40
  br i1 %t41, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb17
bb16:
  %t43 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t45 = trunc i64 34 to i32
  %t46 = icmp eq i32 %t43, %t45
  store i1 %t46, ptr %l28, !tbaa !21
  br label %bb17
bb17:
  %t48 = load i1, ptr %l28, !tbaa !21
  br i1 %t48, label %bb18, label %bb19
bb18:
  store i64 1, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t50 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t52 = trunc i64 1 to i32
  %t53 = icmp eq i32 %t50, %t52
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb21, label %bb22
bb21:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load i64, ptr %l2, !tbaa !24
  %t61 = call i1 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekeyword(ptr %v0, ptr %t57, i64 %t58)
  store i1 %t61, ptr %l38
  br label %bb23
bb22:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb24
bb23:
  %t62 = load i1, ptr %l38, !tbaa !21
  %t63 = xor i1 %t62, true
  store i1 %t63, ptr %l35, !tbaa !21
  br label %bb24
bb24:
  %t65 = load i1, ptr %l35, !tbaa !21
  br i1 %t65, label %bb25, label %bb26
bb25:
  store i64 0, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t67 = load i64, ptr %l2, !tbaa !24
  %t69 = sub i64 %t67, 1
  store i64 %t69, ptr %l4, !tbaa !24
  br label %bb28
bb28:
  %t71 = load i64, ptr %l4, !tbaa !24
  %t73 = icmp sge i64 %t71, 0
  br i1 %t73, label %bb29, label %bb30
bb29:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i64, ptr %l4, !tbaa !24
  %t79 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t75, i64 %t76)
  store i32 %t79, ptr %l48
  br label %bb31
bb30:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb32
bb31:
  %t80 = load i32, ptr %l48, !range !{i32 0, i32 116}
  %t82 = trunc i64 8 to i32
  %t83 = icmp eq i32 %t80, %t82
  store i1 %t83, ptr %l45, !tbaa !21
  br label %bb32
bb32:
  %t85 = load i1, ptr %l45, !tbaa !21
  %t86 = xor i1 %t85, true
  br i1 %t86, label %bb33, label %bb34
bb33:
  br label %bb37
bb34:
  br label %bb35
bb35:
  %t88 = load i64, ptr %l4, !tbaa !24
  %t91 = sub i64 %t88, 1
  store i64 %t91, ptr %l4, !tbaa !24
  br label %bb36
bb36:
  br label %bb28
bb37:
  %t93 = load i64, ptr %l4, !tbaa !24
  %t95 = icmp sge i64 %t93, 0
  br i1 %t95, label %bb38, label %bb39
bb38:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load i64, ptr %l4, !tbaa !24
  %t101 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t97, i64 %t98)
  store i32 %t101, ptr %l60
  br label %bb40
bb39:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb41
bb40:
  %t102 = load i32, ptr %l60, !range !{i32 0, i32 116}
  %t104 = trunc i64 37 to i32
  %t105 = icmp eq i32 %t102, %t104
  store i1 %t105, ptr %l57, !tbaa !21
  br label %bb41
bb41:
  %t107 = load i1, ptr %l57, !tbaa !21
  br i1 %t107, label %bb42, label %bb43
bb42:
  store i64 1, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  %t109 = load i64, ptr %l4, !tbaa !24
  %t111 = icmp sge i64 %t109, 0
  br i1 %t111, label %bb45, label %bb46
bb45:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load i64, ptr %l4, !tbaa !24
  %t117 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t113, i64 %t114)
  store i32 %t117, ptr %l69
  br label %bb47
bb46:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb48
bb47:
  %t118 = load i32, ptr %l69, !range !{i32 0, i32 116}
  %t120 = trunc i64 111 to i32
  %t121 = icmp eq i32 %t118, %t120
  store i1 %t121, ptr %l66, !tbaa !21
  br label %bb48
bb48:
  %t123 = load i1, ptr %l66, !tbaa !21
  br i1 %t123, label %bb49, label %bb50
bb49:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/fmt:formatter", ptr %t124, i32 0, i32 24
  %t127 = load { i64, ptr }, ptr %t126, !tbaa !27
  store { i64, ptr } %t127, ptr %l73, !tbaa !27
  %t128 = load i64, ptr %l4, !tbaa !24
  %t130 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr i64, ptr %t131, i64 %t128
  %t133 = load i64, ptr %t132, !tbaa !34
  %t135 = sub i64 %t133, 1
  store i64 %t135, ptr %l5, !tbaa !24
  br label %bb51
bb50:
  br label %bb68
bb51:
  %t137 = load i64, ptr %l5, !tbaa !24
  %t139 = icmp sge i64 %t137, 0
  br i1 %t139, label %bb52, label %bb53
bb52:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load i64, ptr %l5, !tbaa !24
  %t145 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t141, i64 %t142)
  store i32 %t145, ptr %l82
  br label %bb54
bb53:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb55
bb54:
  %t146 = load i32, ptr %l82, !range !{i32 0, i32 116}
  %t148 = trunc i64 8 to i32
  %t149 = icmp eq i32 %t146, %t148
  store i1 %t149, ptr %l79, !tbaa !21
  br label %bb55
bb55:
  %t151 = load i1, ptr %l79, !tbaa !21
  %t152 = xor i1 %t151, true
  br i1 %t152, label %bb56, label %bb57
bb56:
  br label %bb60
bb57:
  br label %bb58
bb58:
  %t154 = load i64, ptr %l5, !tbaa !24
  %t157 = sub i64 %t154, 1
  store i64 %t157, ptr %l5, !tbaa !24
  br label %bb59
bb59:
  br label %bb51
bb60:
  %t159 = load i64, ptr %l5, !tbaa !24
  %t161 = icmp sge i64 %t159, 0
  br i1 %t161, label %bb61, label %bb62
bb61:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load i64, ptr %l5, !tbaa !24
  %t167 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t163, i64 %t164)
  store i32 %t167, ptr %l94
  br label %bb63
bb62:
  store i1 false, ptr %l91, !tbaa !21
  br label %bb64
bb63:
  %t168 = load i32, ptr %l94, !range !{i32 0, i32 116}
  %t170 = trunc i64 37 to i32
  %t171 = icmp eq i32 %t168, %t170
  store i1 %t171, ptr %l91, !tbaa !21
  br label %bb64
bb64:
  %t173 = load i1, ptr %l91, !tbaa !21
  br i1 %t173, label %bb65, label %bb66
bb65:
  store i64 1, ptr %rv
  br label %ret
bb66:
  br label %bb67
bb67:
  br label %bb68
bb68:
  %t175 = load i64, ptr %l4, !tbaa !24
  %t177 = icmp slt i64 %t175, 0
  br i1 %t177, label %bb69, label %bb70
bb69:
  store i1 true, ptr %l100, !tbaa !21
  br label %bb72
bb70:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load i64, ptr %l4, !tbaa !24
  %t183 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t179, i64 %t180)
  store i32 %t183, ptr %l103
  br label %bb71
bb71:
  %t184 = load i32, ptr %l103, !range !{i32 0, i32 116}
  %t186 = trunc i64 114 to i32
  %t187 = icmp eq i32 %t184, %t186
  store i1 %t187, ptr %l100, !tbaa !21
  br label %bb72
bb72:
  %t189 = load i1, ptr %l100, !tbaa !21
  br i1 %t189, label %bb73, label %bb74
bb73:
  store i1 true, ptr %l106, !tbaa !21
  br label %bb76
bb74:
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t192 = getelementptr %"compiler/fmt:formatter", ptr %t190, i32 0, i32 1
  %t193 = load { i64, ptr }, ptr %t192, !tbaa !27
  store { i64, ptr } %t193, ptr %l108, !tbaa !27
  %t194 = load i64, ptr %l2, !tbaa !24
  %t196 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !27
  %t198 = getelementptr %"compiler/token:Token", ptr %t197, i64 %t194
  %t199 = load %"compiler/token:Token", ptr %t198
  %t200 = load i8, ptr @G_2ecompiler_2ftoken_2eLineBreak, !tbaa !22
  %t203 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t199, i8 %t200)
  store i1 %t203, ptr %l112
  br label %bb75
bb75:
  %t204 = load i1, ptr %l112, !tbaa !21
  store i1 %t204, ptr %l106, !tbaa !21
  br label %bb76
bb76:
  %t205 = load i1, ptr %l106, !tbaa !21
  br i1 %t205, label %bb77, label %bb78
bb77:
  store i64 2, ptr %rv
  br label %ret
bb78:
  br label %bb79
bb79:
  store i64 0, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2eprefix(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l7 = alloca i32
  %l14 = alloca i1
  %l18 = alloca i1
  %l22 = alloca i1
  %l29 = alloca i64
  %l32 = alloca i1
  %l35 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t1, i64 %a1)
  store i32 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i32, ptr %l7, !range !{i32 0, i32 116}
  store i32 %t6, ptr %l3
  %t7 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t9 = trunc i64 107 to i32
  %t10 = icmp eq i32 %t7, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t13 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t15 = trunc i64 69 to i32
  %t16 = icmp eq i32 %t13, %t15
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t22 = trunc i64 105 to i32
  %t23 = icmp eq i32 %t20, %t22
  %t25 = xor i1 %t23, true
  store i1 %t25, ptr %l14, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb7
bb7:
  %t27 = load i1, ptr %l14, !tbaa !21
  br i1 %t27, label %bb8, label %bb9
bb8:
  %t28 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t30 = trunc i64 93 to i32
  %t31 = icmp eq i32 %t28, %t30
  %t33 = xor i1 %t31, true
  store i1 %t33, ptr %l18, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb10
bb10:
  %t35 = load i1, ptr %l18, !tbaa !21
  br i1 %t35, label %bb11, label %bb12
bb11:
  %t36 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t38 = trunc i64 94 to i32
  %t39 = icmp eq i32 %t36, %t38
  %t41 = xor i1 %t39, true
  store i1 %t41, ptr %l22, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb13
bb13:
  %t43 = load i1, ptr %l22, !tbaa !21
  br i1 %t43, label %bb14, label %bb15
bb14:
  store i1 false, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t49 = call i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ebefore(ptr %v0, ptr %t45, i64 %a2)
  store i64 %t49, ptr %l29
  br label %bb17
bb17:
  %t50 = load i64, ptr %l29, !tbaa !24
  store i64 %t50, ptr %l4, !tbaa !24
  %t51 = load i64, ptr %l4, !tbaa !24
  %t53 = icmp slt i64 %t51, 0
  br i1 %t53, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb21
bb19:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load i64, ptr %l4, !tbaa !24
  %t59 = call i1 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2eoperandEnd(ptr %v0, ptr %t55, i64 %t56)
  store i1 %t59, ptr %l35
  br label %bb20
bb20:
  %t60 = load i1, ptr %l35, !tbaa !21
  %t61 = xor i1 %t60, true
  store i1 %t61, ptr %l32, !tbaa !21
  br label %bb21
bb21:
  %t63 = load i1, ptr %l32, !tbaa !21
  store i1 %t63, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2epush(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/fmt:formatter", ptr %t1, i32 0, i32 10
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t3, i64 %a1)
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/fmt:formatter", ptr %t7, i32 0, i32 11
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t9, i64 %a2)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/fmt:formatter", ptr %t13, i32 0, i32 12
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t15, i64 %a3)
  br label %bb3
bb3:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ereceiver(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  %l12 = alloca i64
  %l15 = alloca i64
  %l18 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca i32
  %l40 = alloca i64
  %l43 = alloca i64
  %l50 = alloca i64
  %l53 = alloca i32
  %l56 = alloca i1
  %l59 = alloca i1
  %l64 = alloca ptr
  %l68 = alloca i64
  %l69 = alloca i32
  %l72 = alloca i64
  %l75 = alloca i64
  %l78 = alloca ptr
  %l82 = alloca i64
  %l83 = alloca i32
  %l104 = alloca i64
  %l107 = alloca i64
  %l110 = alloca ptr
  %l114 = alloca i64
  %l115 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  %t3 = add i64 %a2, 1
  store i64 %t3, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l4, !tbaa !24
  store i64 %t5, ptr %l12, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/fmt:formatter", ptr %t6, i32 0, i32 8
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l15
  br label %bb2
bb2:
  %t11 = load i64, ptr %l12, !tbaa !24
  %t12 = load i64, ptr %l15, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb18
bb4:
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l18, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/fmt:formatter", ptr %t18, i32 0, i32 8
  %t21 = load i64, ptr %l4, !tbaa !24
  %t24 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t20, i64 %t21)
  store i64 %t24, ptr %l22
  br label %bb6
bb6:
  %t25 = load ptr, ptr %l18, !tbaa !29
  %t26 = load i64, ptr %l22, !tbaa !24
  %t27 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t25, i64 %t26)
  store i32 %t27, ptr %l23
  br label %bb7
bb7:
  %t28 = load i32, ptr %l23, !range !{i32 0, i32 116}
  store i32 %t28, ptr %l5
  %t29 = load i32, ptr %l5, !range !{i32 0, i32 116}
  %t31 = trunc i64 110 to i32
  %t32 = icmp eq i32 %t29, %t31
  br i1 %t32, label %bb8, label %bb9
bb8:
  %t34 = load i64, ptr %l3, !tbaa !24
  %t37 = add i64 %t34, 1
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb10
bb9:
  br label %bb10
bb10:
  %t39 = load i32, ptr %l5, !range !{i32 0, i32 116}
  %t41 = trunc i64 111 to i32
  %t42 = icmp eq i32 %t39, %t41
  br i1 %t42, label %bb11, label %bb12
bb11:
  %t44 = load i64, ptr %l3, !tbaa !24
  %t47 = sub i64 %t44, 1
  store i64 %t47, ptr %l3, !tbaa !24
  %t49 = load i64, ptr %l3, !tbaa !24
  %t51 = icmp eq i64 %t49, 0
  br i1 %t51, label %bb13, label %bb14
bb12:
  br label %bb16
bb13:
  br label %bb18
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t53 = load i64, ptr %l4, !tbaa !24
  %t56 = add i64 %t53, 1
  store i64 %t56, ptr %l4, !tbaa !24
  br label %bb17
bb17:
  br label %bb1
bb18:
  %t58 = load i64, ptr %l4, !tbaa !24
  %t60 = add i64 %t58, 2
  store i64 %t60, ptr %l40, !tbaa !24
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/fmt:formatter", ptr %t61, i32 0, i32 8
  %t65 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t63)
  store i64 %t65, ptr %l43
  br label %bb19
bb19:
  %t66 = load i64, ptr %l40, !tbaa !24
  %t67 = load i64, ptr %l43, !tbaa !24
  %t68 = icmp sge i64 %t66, %t67
  br i1 %t68, label %bb20, label %bb21
bb20:
  store i1 false, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/fmt:formatter", ptr %t71, i32 0, i32 8
  %t74 = load i64, ptr %l4, !tbaa !24
  %t76 = add i64 %t74, 1
  %t79 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t73, i64 %t76)
  store i64 %t79, ptr %l50
  br label %bb23
bb23:
  %t80 = load i64, ptr %l50, !tbaa !24
  store i64 %t80, ptr %l6, !tbaa !24
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load i64, ptr %l6, !tbaa !24
  %t85 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t81, i64 %t82)
  store i32 %t85, ptr %l53
  br label %bb24
bb24:
  %t86 = load i32, ptr %l53, !range !{i32 0, i32 116}
  %t88 = trunc i64 1 to i32
  %t89 = icmp eq i32 %t86, %t88
  br i1 %t89, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l56, !tbaa !21
  br label %bb28
bb26:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load i64, ptr %l6, !tbaa !24
  %t95 = call i1 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekeyword(ptr %v0, ptr %t91, i64 %t92)
  store i1 %t95, ptr %l59
  br label %bb27
bb27:
  %t96 = load i1, ptr %l59, !tbaa !21
  store i1 %t96, ptr %l56, !tbaa !21
  br label %bb28
bb28:
  %t97 = load i1, ptr %l56, !tbaa !21
  %t98 = xor i1 %t97, true
  br i1 %t98, label %bb29, label %bb30
bb29:
  store i1 false, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  %t101 = load i64, ptr %l4, !tbaa !24
  %t103 = add i64 %t101, 2
  store i64 %t103, ptr %l7, !tbaa !24
  %t105 = load ptr, ptr %l0, !tbaa !29
  store ptr %t105, ptr %l64, !tbaa !29
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/fmt:formatter", ptr %t106, i32 0, i32 8
  %t109 = load i64, ptr %l7, !tbaa !24
  %t112 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t108, i64 %t109)
  store i64 %t112, ptr %l68
  br label %bb32
bb32:
  %t113 = load ptr, ptr %l64, !tbaa !29
  %t114 = load i64, ptr %l68, !tbaa !24
  %t115 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t113, i64 %t114)
  store i32 %t115, ptr %l69
  br label %bb33
bb33:
  %t116 = load i32, ptr %l69, !range !{i32 0, i32 116}
  %t118 = trunc i64 98 to i32
  %t119 = icmp eq i32 %t116, %t118
  br i1 %t119, label %bb34, label %bb35
bb34:
  store i64 0, ptr %l8, !tbaa !24
  br label %bb36
bb35:
  br label %bb61
bb36:
  %t121 = load i64, ptr %l7, !tbaa !24
  store i64 %t121, ptr %l72, !tbaa !24
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/fmt:formatter", ptr %t122, i32 0, i32 8
  %t126 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t124)
  store i64 %t126, ptr %l75
  br label %bb37
bb37:
  %t127 = load i64, ptr %l72, !tbaa !24
  %t128 = load i64, ptr %l75, !tbaa !24
  %t129 = icmp slt i64 %t127, %t128
  %t131 = xor i1 %t129, true
  br i1 %t131, label %bb38, label %bb39
bb38:
  br label %bb56
bb39:
  br label %bb40
bb40:
  %t133 = load ptr, ptr %l0, !tbaa !29
  store ptr %t133, ptr %l78, !tbaa !29
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/fmt:formatter", ptr %t134, i32 0, i32 8
  %t137 = load i64, ptr %l7, !tbaa !24
  %t140 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t136, i64 %t137)
  store i64 %t140, ptr %l82
  br label %bb41
bb41:
  %t141 = load ptr, ptr %l78, !tbaa !29
  %t142 = load i64, ptr %l82, !tbaa !24
  %t143 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t141, i64 %t142)
  store i32 %t143, ptr %l83
  br label %bb42
bb42:
  %t144 = load i32, ptr %l83, !range !{i32 0, i32 116}
  store i32 %t144, ptr %l9
  %t145 = load i32, ptr %l9, !range !{i32 0, i32 116}
  %t147 = trunc i64 98 to i32
  %t148 = icmp eq i32 %t145, %t147
  br i1 %t148, label %bb43, label %bb44
bb43:
  %t150 = load i64, ptr %l8, !tbaa !24
  %t153 = add i64 %t150, 1
  store i64 %t153, ptr %l8, !tbaa !24
  br label %bb45
bb44:
  br label %bb45
bb45:
  %t155 = load i32, ptr %l9, !range !{i32 0, i32 116}
  %t157 = trunc i64 100 to i32
  %t158 = icmp eq i32 %t155, %t157
  br i1 %t158, label %bb46, label %bb47
bb46:
  %t160 = load i64, ptr %l8, !tbaa !24
  %t163 = sub i64 %t160, 1
  store i64 %t163, ptr %l8, !tbaa !24
  br label %bb48
bb47:
  br label %bb48
bb48:
  %t165 = load i32, ptr %l9, !range !{i32 0, i32 116}
  %t167 = trunc i64 109 to i32
  %t168 = icmp eq i32 %t165, %t167
  br i1 %t168, label %bb49, label %bb50
bb49:
  %t170 = load i64, ptr %l8, !tbaa !24
  %t173 = sub i64 %t170, 2
  store i64 %t173, ptr %l8, !tbaa !24
  br label %bb51
bb50:
  br label %bb51
bb51:
  %t175 = load i64, ptr %l7, !tbaa !24
  %t178 = add i64 %t175, 1
  store i64 %t178, ptr %l7, !tbaa !24
  %t180 = load i64, ptr %l8, !tbaa !24
  %t182 = icmp sle i64 %t180, 0
  br i1 %t182, label %bb52, label %bb53
bb52:
  br label %bb56
bb53:
  br label %bb54
bb54:
  br label %bb55
bb55:
  br label %bb36
bb56:
  %t184 = load i64, ptr %l7, !tbaa !24
  store i64 %t184, ptr %l104, !tbaa !24
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/fmt:formatter", ptr %t185, i32 0, i32 8
  %t189 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t187)
  store i64 %t189, ptr %l107
  br label %bb57
bb57:
  %t190 = load i64, ptr %l104, !tbaa !24
  %t191 = load i64, ptr %l107, !tbaa !24
  %t192 = icmp sge i64 %t190, %t191
  br i1 %t192, label %bb58, label %bb59
bb58:
  store i1 false, ptr %rv
  br label %ret
bb59:
  br label %bb60
bb60:
  br label %bb61
bb61:
  %t195 = load ptr, ptr %l0, !tbaa !29
  store ptr %t195, ptr %l110, !tbaa !29
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/fmt:formatter", ptr %t196, i32 0, i32 8
  %t199 = load i64, ptr %l7, !tbaa !24
  %t202 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t198, i64 %t199)
  store i64 %t202, ptr %l114
  br label %bb62
bb62:
  %t203 = load ptr, ptr %l110, !tbaa !29
  %t204 = load i64, ptr %l114, !tbaa !24
  %t205 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t203, i64 %t204)
  store i32 %t205, ptr %l115
  br label %bb63
bb63:
  %t206 = load i32, ptr %l115, !range !{i32 0, i32 116}
  %t208 = trunc i64 110 to i32
  %t209 = icmp eq i32 %t206, %t208
  store i1 %t209, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2erun(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i32
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i32
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i1
  %l40 = alloca i64
  %l43 = alloca i64
  %l62 = alloca { i64, ptr }
  %l79 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l82 = alloca i64
  %l84 = alloca i64
  %l89 = alloca i64
  %l92 = alloca i32
  %l99 = alloca i1
  %l101 = alloca i64
  %l104 = alloca { i64, ptr }
  %l105 = alloca i64
  %l106 = alloca i64
  %l108 = alloca i64
  %l109 = alloca i32
  %l113 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l116 = alloca i64
  %l118 = alloca i64
  %l123 = alloca i64
  %l126 = alloca i32
  %l129 = alloca i1
  %l132 = alloca i1
  %l139 = alloca i1
  %l142 = alloca i1
  %l145 = alloca i1
  %l147 = alloca i64
  %l149 = alloca i32
  %l151 = alloca i32
  %l152 = alloca i32
  %l159 = alloca { i64, ptr }
  %l160 = alloca i64
  %l162 = alloca i64
  %l164 = alloca i1
  %l165 = alloca i32
  %l167 = alloca i32
  %l168 = alloca i32
  %l177 = alloca i64
  %l180 = alloca i64
  %l186 = alloca i64
  %l189 = alloca { i64, ptr }
  %l193 = alloca i64
  %l199 = alloca i64
  %l203 = alloca i64
  %l206 = alloca i64
  %l210 = alloca i64
  %l213 = alloca i64
  %l234 = alloca i64
  %l237 = alloca i1
  %l241 = alloca i64
  %l247 = alloca i64
  %l262 = alloca i1
  %l273 = alloca i64
  %l277 = alloca ptr
  %l279 = alloca { i64, ptr }
  %l280 = alloca i64
  %l281 = alloca i64
  %l282 = alloca i64
  %l287 = alloca i64
  %l290 = alloca i64
  %l292 = alloca i1
  %l294 = alloca { i64, ptr }
  %l298 = alloca i64
  %l307 = alloca i64
  %l308 = alloca ptr
  %l312 = alloca i64
  %l313 = alloca ptr
  %l317 = alloca i64
  %l329 = alloca i64
  %l337 = alloca { i64, ptr }
  %l345 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i1 false, ptr %l1, !tbaa !21
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/fmt:formatter", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  store i64 %t6, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp sgt i64 %t8, %t9
  br i1 %t12, label %bb1, label %bb2
bb1:
  %t14 = load i64, ptr %l4, !tbaa !24
  %t16 = icmp sgt i64 %t14, 0
  br i1 %t16, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb6
bb3:
  %t18 = load i64, ptr %l3, !tbaa !24
  %t19 = load i64, ptr %l2, !tbaa !24
  %t22 = sub i64 %t18, %t19
  %t23 = load i64, ptr %l4, !tbaa !24
  %t26 = add i64 %t22, %t23
  %t28 = sub i64 %t26, 1
  %t29 = load i64, ptr %l4, !tbaa !24
  %t32 = sdiv i64 %t28, %t29
  store i64 %t32, ptr %l43, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb5
bb5:
  %t34 = load i64, ptr %l43, !tbaa !24
  store i64 %t34, ptr %l40, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l40, !tbaa !24
  store i64 %t35, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  %t36 = load i64, ptr %l6, !tbaa !24
  %t37 = load i64, ptr %l5, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb8, label %bb9
bb8:
  br label %bb20
bb9:
  br label %bb10
bb10:
  %t44 = load i64, ptr %l2, !tbaa !24
  %t45 = load i64, ptr %l6, !tbaa !24
  %t46 = load i64, ptr %l4, !tbaa !24
  %t49 = mul i64 %t45, %t46
  %t52 = add i64 %t44, %t49
  store i64 %t52, ptr %l7, !tbaa !24
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/fmt:formatter", ptr %t54, i32 0, i32 1
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  store { i64, ptr } %t57, ptr %l62, !tbaa !27
  %t58 = load i64, ptr %l7, !tbaa !24
  %t60 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr %"compiler/token:Token", ptr %t61, i64 %t58
  %t63 = getelementptr %"compiler/token:Token", ptr %t62, i32 0, i32 0
  %t64 = load i32, ptr %t63, !range !{i32 0, i32 116}
  store i32 %t64, ptr %l8
  %t66 = load i32, ptr %l8, !range !{i32 0, i32 116}
  %t68 = trunc i64 8 to i32
  %t69 = icmp eq i32 %t66, %t68
  br i1 %t69, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb18
bb12:
  %t71 = load i32, ptr %l8, !range !{i32 0, i32 116}
  %t73 = trunc i64 0 to i32
  %t74 = icmp eq i32 %t71, %t73
  %t76 = xor i1 %t74, true
  br i1 %t76, label %bb13, label %bb14
bb13:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/fmt:formatter", ptr %t78, i32 0, i32 8
  %t81 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t80, i64 %t81)
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/fmt:formatter", ptr %t84, i32 0, i32 9
  %t87 = load i1, ptr %l1, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t86, i1 %t87)
  br label %bb16
bb16:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb17
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t90 = load i64, ptr %l6, !tbaa !24
  %t93 = add i64 %t90, 1
  store i64 %t93, ptr %l6, !tbaa !24
  br label %bb7
bb20:
  %t95 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t95, ptr %l79
  br label %bb21
bb21:
  %t96 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l79
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t96, ptr %l9
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/fmt:formatter", ptr %t97, i32 0, i32 8
  store ptr %t99, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb22
bb22:
  %t101 = load i64, ptr %l11, !tbaa !24
  store i64 %t101, ptr %l82, !tbaa !24
  %t102 = load ptr, ptr %l10, !tbaa !29
  %t104 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t102)
  store i64 %t104, ptr %l84
  br label %bb23
bb23:
  %t105 = load i64, ptr %l82, !tbaa !24
  %t106 = load i64, ptr %l84, !tbaa !24
  %t107 = icmp slt i64 %t105, %t106
  %t109 = xor i1 %t107, true
  br i1 %t109, label %bb24, label %bb25
bb24:
  br label %bb45
bb25:
  br label %bb26
bb26:
  %t111 = load ptr, ptr %l10, !tbaa !29
  %t112 = load i64, ptr %l11, !tbaa !24
  %t115 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t111, i64 %t112)
  store i64 %t115, ptr %l89
  br label %bb27
bb27:
  %t116 = load i64, ptr %l89, !tbaa !24
  store i64 %t116, ptr %l12, !tbaa !24
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load i64, ptr %l12, !tbaa !24
  %t121 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t117, i64 %t118)
  store i32 %t121, ptr %l92
  br label %bb28
bb28:
  %t122 = load i32, ptr %l92, !range !{i32 0, i32 116}
  store i32 %t122, ptr %l13
  %t123 = load i32, ptr %l13, !range !{i32 0, i32 116}
  %t125 = trunc i64 110 to i32
  %t126 = icmp eq i32 %t123, %t125
  br i1 %t126, label %bb29, label %bb30
bb29:
  %t128 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l9, i64 %t128)
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb32
bb32:
  %t131 = load i32, ptr %l13, !range !{i32 0, i32 116}
  %t133 = trunc i64 111 to i32
  %t134 = icmp eq i32 %t131, %t133
  br i1 %t134, label %bb33, label %bb34
bb33:
  %t137 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l9)
  store i64 %t137, ptr %l101
  br label %bb35
bb34:
  store i1 false, ptr %l99, !tbaa !21
  br label %bb36
bb35:
  %t138 = load i64, ptr %l101, !tbaa !24
  %t139 = icmp sgt i64 %t138, 0
  store i1 %t139, ptr %l99, !tbaa !21
  br label %bb36
bb36:
  %t141 = load i1, ptr %l99, !tbaa !21
  br i1 %t141, label %bb37, label %bb38
bb37:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/fmt:formatter", ptr %t142, i32 0, i32 24
  %t145 = load { i64, ptr }, ptr %t144, !tbaa !27
  store { i64, ptr } %t145, ptr %l104, !tbaa !27
  %t146 = load i64, ptr %l12, !tbaa !24
  store i64 %t146, ptr %l105, !tbaa !24
  %t148 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %s0, ptr %l9)
  %t149 = extractvalue { i32, i64 } %t148, 1
  %t150 = extractvalue { i32, i64 } %t148, 0
  store i32 %t150, ptr %l109
  %t151 = icmp ne i32 %t150, 0
  br i1 %t151, label %bb40, label %ok.152, !prof !99
ok.152:
  store i64 %t149, ptr %l108
  br label %bb39
bb38:
  br label %bb43
bb39:
  %t153 = load i64, ptr %l108, !tbaa !24
  store i64 %t153, ptr %l106, !tbaa !24
  br label %bb42
bb40:
  br label %bb41
bb41:
  store i64 0, ptr %l106, !tbaa !24
  br label %bb42
bb42:
  %t154 = load i64, ptr %l106, !tbaa !24
  %t155 = load i64, ptr %l105, !tbaa !24
  %t156 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !27
  %t158 = getelementptr i64, ptr %t157, i64 %t155
  store i64 %t154, ptr %t158, !tbaa !34
  br label %bb43
bb43:
  br label %bb44
bb44:
  %t159 = load i64, ptr %l11, !tbaa !24
  %t162 = add i64 %t159, 1
  store i64 %t162, ptr %l11, !tbaa !24
  br label %bb22
bb45:
  %t164 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftoken_3aTok_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t164, ptr %l113
  br label %bb46
bb46:
  %t165 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l113
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t165, ptr %l14
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/fmt:formatter", ptr %t166, i32 0, i32 8
  store ptr %t168, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  br label %bb47
bb47:
  %t170 = load i64, ptr %l16, !tbaa !24
  store i64 %t170, ptr %l116, !tbaa !24
  %t171 = load ptr, ptr %l15, !tbaa !29
  %t173 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t171)
  store i64 %t173, ptr %l118
  br label %bb48
bb48:
  %t174 = load i64, ptr %l116, !tbaa !24
  %t175 = load i64, ptr %l118, !tbaa !24
  %t176 = icmp slt i64 %t174, %t175
  %t178 = xor i1 %t176, true
  br i1 %t178, label %bb49, label %bb50
bb49:
  br label %bb98
bb50:
  br label %bb51
bb51:
  %t180 = load ptr, ptr %l15, !tbaa !29
  %t181 = load i64, ptr %l16, !tbaa !24
  %t184 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t180, i64 %t181)
  store i64 %t184, ptr %l123
  br label %bb52
bb52:
  %t185 = load i64, ptr %l123, !tbaa !24
  store i64 %t185, ptr %l17, !tbaa !24
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load i64, ptr %l17, !tbaa !24
  %t190 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t186, i64 %t187)
  store i32 %t190, ptr %l126
  br label %bb53
bb53:
  %t191 = load i32, ptr %l126, !range !{i32 0, i32 116}
  store i32 %t191, ptr %l18
  %t192 = load i32, ptr %l18, !range !{i32 0, i32 116}
  %t194 = trunc i64 110 to i32
  %t195 = icmp eq i32 %t192, %t194
  br i1 %t195, label %bb54, label %bb55
bb54:
  store i1 true, ptr %l129, !tbaa !21
  br label %bb56
bb55:
  %t197 = load i32, ptr %l18, !range !{i32 0, i32 116}
  %t199 = trunc i64 112 to i32
  %t200 = icmp eq i32 %t197, %t199
  store i1 %t200, ptr %l129, !tbaa !21
  br label %bb56
bb56:
  %t202 = load i1, ptr %l129, !tbaa !21
  br i1 %t202, label %bb57, label %bb58
bb57:
  store i1 true, ptr %l132, !tbaa !21
  br label %bb59
bb58:
  %t203 = load i32, ptr %l18, !range !{i32 0, i32 116}
  %t205 = trunc i64 114 to i32
  %t206 = icmp eq i32 %t203, %t205
  store i1 %t206, ptr %l132, !tbaa !21
  br label %bb59
bb59:
  %t208 = load i1, ptr %l132, !tbaa !21
  br i1 %t208, label %bb60, label %bb61
bb60:
  %t209 = load i32, ptr %l18, !range !{i32 0, i32 116}
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftoken_3aTok_3e_2ePush_3ccompiler_2ftoken_3aTok_3e(ptr %s0, ptr %l14, i32 %t209)
  br label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb63
bb63:
  %t212 = load i32, ptr %l18, !range !{i32 0, i32 116}
  %t214 = trunc i64 111 to i32
  %t215 = icmp eq i32 %t212, %t214
  br i1 %t215, label %bb64, label %bb65
bb64:
  store i1 true, ptr %l139, !tbaa !21
  br label %bb66
bb65:
  %t217 = load i32, ptr %l18, !range !{i32 0, i32 116}
  %t219 = trunc i64 113 to i32
  %t220 = icmp eq i32 %t217, %t219
  store i1 %t220, ptr %l139, !tbaa !21
  br label %bb66
bb66:
  %t222 = load i1, ptr %l139, !tbaa !21
  br i1 %t222, label %bb67, label %bb68
bb67:
  store i1 true, ptr %l142, !tbaa !21
  br label %bb69
bb68:
  %t223 = load i32, ptr %l18, !range !{i32 0, i32 116}
  %t225 = trunc i64 115 to i32
  %t226 = icmp eq i32 %t223, %t225
  store i1 %t226, ptr %l142, !tbaa !21
  br label %bb69
bb69:
  %t228 = load i1, ptr %l142, !tbaa !21
  br i1 %t228, label %bb70, label %bb71
bb70:
  %t230 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftoken_3aTok_3e_2eLen_3ccompiler_2ftoken_3aTok_3e(ptr %s0, ptr %l14)
  store i64 %t230, ptr %l147
  br label %bb72
bb71:
  store i1 false, ptr %l145, !tbaa !21
  br label %bb73
bb72:
  %t231 = load i64, ptr %l147, !tbaa !24
  %t232 = icmp sgt i64 %t231, 0
  store i1 %t232, ptr %l145, !tbaa !21
  br label %bb73
bb73:
  %t234 = load i1, ptr %l145, !tbaa !21
  br i1 %t234, label %bb74, label %bb75
bb74:
  %t236 = call { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftoken_3aTok_3e_2ePop_3ccompiler_2ftoken_3aTok_3e(ptr %s0, ptr %l14)
  %t237 = extractvalue { i32, i32 } %t236, 1
  %t238 = extractvalue { i32, i32 } %t236, 0
  store i32 %t238, ptr %l152
  %t239 = icmp ne i32 %t238, 0
  br i1 %t239, label %bb77, label %ok.240, !prof !99
ok.240:
  store i32 %t237, ptr %l151
  br label %bb76
bb75:
  br label %bb85
bb76:
  %t241 = load i32, ptr %l151, !range !{i32 0, i32 116}
  store i32 %t241, ptr %l149
  br label %bb84
bb77:
  %t242 = load i32, ptr %l152, !tbaa !23
  %t243 = icmp eq i32 %t242, 65536
  br i1 %t243, label %bb78, label %bb79
bb78:
  call void @__olang_bang_failed_plain(ptr @olang_loc_35c4bcbe8a179434_4b4275954f9faef0)
  unreachable
bb79:
  %t245 = load i32, ptr %l152, !tbaa !23
  %t246 = icmp eq i32 %t245, 65537
  br i1 %t246, label %bb80, label %bb81
bb80:
  call void @__olang_bang_failed_plain(ptr @olang_loc_60c6fb5a9e323c49_a95dbf77cbddce25)
  unreachable
bb81:
  %t248 = load i32, ptr %l152, !tbaa !23
  %t249 = icmp eq i32 %t248, 65538
  br i1 %t249, label %bb82, label %bb83
bb82:
  call void @__olang_bang_failed_plain(ptr @olang_loc_951b69446ffbaf49_31d81fa88f191745)
  unreachable
bb83:
  call void @__olang_bang_failed_plain(ptr @olang_loc_e1e0026cb6156c8f_cc49873f28a42c4b)
  unreachable
bb84:
  br label %bb85
bb85:
  %t251 = load i32, ptr %l18, !range !{i32 0, i32 116}
  %t253 = trunc i64 79 to i32
  %t254 = icmp eq i32 %t251, %t253
  br i1 %t254, label %bb86, label %bb87
bb86:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr %"compiler/fmt:formatter", ptr %t256, i32 0, i32 5
  %t259 = load { i64, ptr }, ptr %t258, !tbaa !27
  store { i64, ptr } %t259, ptr %l159, !tbaa !27
  %t260 = load i64, ptr %l17, !tbaa !24
  store i64 %t260, ptr %l160, !tbaa !24
  %t262 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftoken_3aTok_3e_2eLen_3ccompiler_2ftoken_3aTok_3e(ptr %s0, ptr %l14)
  store i64 %t262, ptr %l162
  br label %bb88
bb87:
  br label %bb96
bb88:
  %t263 = load i64, ptr %l162, !tbaa !24
  %t264 = icmp eq i64 %t263, 0
  br i1 %t264, label %bb89, label %bb90
bb89:
  store i1 true, ptr %l164, !tbaa !21
  br label %bb95
bb90:
  %t267 = call { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftoken_3aTok_3e_2eLast_3ccompiler_2ftoken_3aTok_3e(ptr %s0, ptr %l14)
  %t268 = extractvalue { i32, i32 } %t267, 1
  %t269 = extractvalue { i32, i32 } %t267, 0
  store i32 %t269, ptr %l168
  %t270 = icmp ne i32 %t269, 0
  br i1 %t270, label %bb92, label %ok.271, !prof !99
ok.271:
  store i32 %t268, ptr %l167
  br label %bb91
bb91:
  %t272 = load i32, ptr %l167, !range !{i32 0, i32 116}
  store i32 %t272, ptr %l165
  br label %bb94
bb92:
  br label %bb93
bb93:
  store i32 114, ptr %l165
  br label %bb94
bb94:
  %t274 = load i32, ptr %l165, !range !{i32 0, i32 116}
  %t276 = trunc i64 112 to i32
  %t277 = icmp eq i32 %t274, %t276
  %t279 = xor i1 %t277, true
  store i1 %t279, ptr %l164, !tbaa !21
  br label %bb95
bb95:
  %t281 = load i1, ptr %l164, !tbaa !21
  %t282 = load i64, ptr %l160, !tbaa !24
  %t283 = getelementptr { i64, ptr }, ptr %l159, i32 0, i32 1
  %t284 = load ptr, ptr %t283, !tbaa !27
  %t285 = getelementptr i1, ptr %t284, i64 %t282
  store i1 %t281, ptr %t285, !tbaa !31
  br label %bb96
bb96:
  br label %bb97
bb97:
  %t286 = load i64, ptr %l16, !tbaa !24
  %t289 = add i64 %t286, 1
  store i64 %t289, ptr %l16, !tbaa !24
  br label %bb47
bb98:
  %t291 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2emarkEntries(ptr %v0, ptr %t291)
  br label %bb99
bb99:
  store i64 0, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb100
bb100:
  %t293 = load i64, ptr %l20, !tbaa !24
  store i64 %t293, ptr %l177, !tbaa !24
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t296 = getelementptr %"compiler/fmt:formatter", ptr %t294, i32 0, i32 8
  %t298 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t296)
  store i64 %t298, ptr %l180
  br label %bb101
bb101:
  %t299 = load i64, ptr %l177, !tbaa !24
  %t300 = load i64, ptr %l180, !tbaa !24
  %t301 = icmp slt i64 %t299, %t300
  %t303 = xor i1 %t301, true
  br i1 %t303, label %bb102, label %bb103
bb102:
  br label %bb182
bb103:
  br label %bb104
bb104:
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t307 = getelementptr %"compiler/fmt:formatter", ptr %t305, i32 0, i32 8
  %t308 = load i64, ptr %l20, !tbaa !24
  %t311 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t307, i64 %t308)
  store i64 %t311, ptr %l186
  br label %bb105
bb105:
  %t312 = load i64, ptr %l186, !tbaa !24
  store i64 %t312, ptr %l21, !tbaa !24
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t314 = load ptr, ptr %l0, !tbaa !29
  %t316 = getelementptr %"compiler/fmt:formatter", ptr %t314, i32 0, i32 1
  %t317 = load { i64, ptr }, ptr %t316, !tbaa !27
  store { i64, ptr } %t317, ptr %l189, !tbaa !27
  %t318 = load i64, ptr %l21, !tbaa !24
  %t320 = getelementptr { i64, ptr }, ptr %l189, i32 0, i32 1
  %t321 = load ptr, ptr %t320, !tbaa !27
  %t322 = getelementptr %"compiler/token:Token", ptr %t321, i64 %t318
  %t323 = getelementptr %"compiler/token:Token", ptr %t322, i32 0, i32 2
  %t324 = load i32, ptr %t323, !tbaa !23
  %t326 = sext i32 %t324 to i64
  %t329 = call i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2eheldAt(ptr %v0, ptr %t313, i64 %t326)
  store i64 %t329, ptr %l193
  br label %bb106
bb106:
  %t330 = load i64, ptr %l193, !tbaa !24
  store i64 %t330, ptr %l22, !tbaa !24
  %t331 = load i64, ptr %l22, !tbaa !24
  %t333 = icmp sge i64 %t331, 0
  br i1 %t333, label %bb107, label %bb108
bb107:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t337 = getelementptr %"compiler/fmt:formatter", ptr %t335, i32 0, i32 33
  %t338 = load i64, ptr %l22, !tbaa !24
  %t341 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t337, i64 %t338)
  store i64 %t341, ptr %l199
  br label %bb109
bb108:
  br label %bb178
bb109:
  %t342 = load i64, ptr %l199, !tbaa !24
  store i64 %t342, ptr %l23, !tbaa !24
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t345 = getelementptr %"compiler/fmt:formatter", ptr %t343, i32 0, i32 34
  %t346 = load i64, ptr %l22, !tbaa !24
  %t349 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t345, i64 %t346)
  store i64 %t349, ptr %l203
  br label %bb110
bb110:
  %t350 = load i64, ptr %l203, !tbaa !24
  store i64 %t350, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t353 = getelementptr %"compiler/fmt:formatter", ptr %t351, i32 0, i32 33
  %t355 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t353)
  store i64 %t355, ptr %l206
  br label %bb111
bb111:
  %t356 = load i64, ptr %l206, !tbaa !24
  store i64 %t356, ptr %l26, !tbaa !24
  store i64 1, ptr %l27, !tbaa !24
  %t357 = load i64, ptr %l26, !tbaa !24
  %t358 = load i64, ptr %l25, !tbaa !24
  %t361 = icmp sgt i64 %t357, %t358
  br i1 %t361, label %bb112, label %bb113
bb112:
  %t363 = load i64, ptr %l27, !tbaa !24
  %t365 = icmp sgt i64 %t363, 0
  br i1 %t365, label %bb114, label %bb115
bb113:
  store i64 0, ptr %l210, !tbaa !24
  br label %bb117
bb114:
  %t367 = load i64, ptr %l26, !tbaa !24
  %t368 = load i64, ptr %l25, !tbaa !24
  %t371 = sub i64 %t367, %t368
  %t372 = load i64, ptr %l27, !tbaa !24
  %t375 = add i64 %t371, %t372
  %t377 = sub i64 %t375, 1
  %t378 = load i64, ptr %l27, !tbaa !24
  %t381 = sdiv i64 %t377, %t378
  store i64 %t381, ptr %l213, !tbaa !24
  br label %bb116
bb115:
  store i64 0, ptr %l213, !tbaa !24
  br label %bb116
bb116:
  %t383 = load i64, ptr %l213, !tbaa !24
  store i64 %t383, ptr %l210, !tbaa !24
  br label %bb117
bb117:
  %t384 = load i64, ptr %l210, !tbaa !24
  store i64 %t384, ptr %l28, !tbaa !24
  store i64 0, ptr %l29, !tbaa !24
  br label %bb118
bb118:
  %t385 = load i64, ptr %l29, !tbaa !24
  %t386 = load i64, ptr %l28, !tbaa !24
  %t389 = icmp slt i64 %t385, %t386
  %t391 = xor i1 %t389, true
  br i1 %t391, label %bb119, label %bb120
bb119:
  br label %bb132
bb120:
  br label %bb121
bb121:
  %t393 = load i64, ptr %l25, !tbaa !24
  %t394 = load i64, ptr %l29, !tbaa !24
  %t395 = load i64, ptr %l27, !tbaa !24
  %t398 = mul i64 %t394, %t395
  %t401 = add i64 %t393, %t398
  store i64 %t401, ptr %l30, !tbaa !24
  %t403 = load ptr, ptr %l0, !tbaa !29
  %t405 = getelementptr %"compiler/fmt:formatter", ptr %t403, i32 0, i32 33
  %t406 = load i64, ptr %l30, !tbaa !24
  %t409 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t405, i64 %t406)
  store i64 %t409, ptr %l234
  br label %bb122
bb122:
  %t410 = load i64, ptr %l24, !tbaa !24
  %t411 = load i64, ptr %l234, !tbaa !24
  %t413 = icmp sle i64 %t411, %t410
  br i1 %t413, label %bb123, label %bb124
bb123:
  %t415 = load ptr, ptr %l0, !tbaa !29
  %t417 = getelementptr %"compiler/fmt:formatter", ptr %t415, i32 0, i32 34
  %t418 = load i64, ptr %l30, !tbaa !24
  %t421 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t417, i64 %t418)
  store i64 %t421, ptr %l241
  br label %bb125
bb124:
  store i1 false, ptr %l237, !tbaa !21
  br label %bb126
bb125:
  %t422 = load i64, ptr %l24, !tbaa !24
  %t423 = load i64, ptr %l241, !tbaa !24
  %t425 = icmp sgt i64 %t423, %t422
  store i1 %t425, ptr %l237, !tbaa !21
  br label %bb126
bb126:
  %t427 = load i1, ptr %l237, !tbaa !21
  br i1 %t427, label %bb127, label %bb128
bb127:
  %t428 = load ptr, ptr %l0, !tbaa !29
  %t430 = getelementptr %"compiler/fmt:formatter", ptr %t428, i32 0, i32 34
  %t431 = load i64, ptr %l30, !tbaa !24
  %t434 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t430, i64 %t431)
  store i64 %t434, ptr %l247
  br label %bb129
bb128:
  br label %bb130
bb129:
  %t435 = load i64, ptr %l247, !tbaa !24
  store i64 %t435, ptr %l24, !tbaa !24
  br label %bb130
bb130:
  br label %bb131
bb131:
  %t436 = load i64, ptr %l29, !tbaa !24
  %t439 = add i64 %t436, 1
  store i64 %t439, ptr %l29, !tbaa !24
  br label %bb118
bb132:
  %t441 = load ptr, ptr %l0, !tbaa !29
  %t442 = load i64, ptr %l19, !tbaa !24
  %t443 = load i64, ptr %l23, !tbaa !24
  %t444 = load i64, ptr %l20, !tbaa !24
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2egap(ptr %v0, ptr %t441, i64 %t442, i64 %t443, i64 %t444)
  br label %bb133
bb133:
  %t449 = load ptr, ptr %l0, !tbaa !29
  %t451 = getelementptr %"compiler/fmt:formatter", ptr %t449, i32 0, i32 21
  %t452 = load i1, ptr %t451, !tbaa !21
  br i1 %t452, label %bb134, label %bb135
bb134:
  %t454 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2efinish(ptr %v0, ptr %t454)
  br label %bb136
bb135:
  br label %bb137
bb136:
  br label %bb137
bb137:
  %t456 = load i64, ptr %l23, !tbaa !24
  store i64 %t456, ptr %l31, !tbaa !24
  br label %bb138
bb138:
  %t458 = load i64, ptr %l31, !tbaa !24
  %t459 = load i64, ptr %l24, !tbaa !24
  %t462 = icmp sle i64 %t458, %t459
  br i1 %t462, label %bb139, label %bb140
bb139:
  %t464 = load i64, ptr %l31, !tbaa !24
  %t465 = load ptr, ptr %l0, !tbaa !29
  %t467 = getelementptr %"compiler/fmt:formatter", ptr %t465, i32 0, i32 0
  %t468 = load { i64, ptr }, ptr %t467, !tbaa !27
  %t470 = extractvalue { i64, ptr } %t468, 0
  %t472 = add i64 %t470, 1
  %t475 = icmp slt i64 %t464, %t472
  store i1 %t475, ptr %l262, !tbaa !21
  br label %bb141
bb140:
  store i1 false, ptr %l262, !tbaa !21
  br label %bb141
bb141:
  %t477 = load i1, ptr %l262, !tbaa !21
  %t478 = xor i1 %t477, true
  br i1 %t478, label %bb142, label %bb143
bb142:
  br label %bb174
bb143:
  br label %bb144
bb144:
  %t480 = load ptr, ptr %l0, !tbaa !29
  %t482 = getelementptr %"compiler/fmt:formatter", ptr %t480, i32 0, i32 0
  %t483 = load { i64, ptr }, ptr %t482, !tbaa !27
  %t484 = load i64, ptr %l31, !tbaa !24
  %t487 = call i64 @compiler_2ffmt_2elineEndOf(ptr %v0, { i64, ptr } %t483, i64 %t484)
  store i64 %t487, ptr %l273
  br label %bb145
bb145:
  %t488 = load i64, ptr %l273, !tbaa !24
  store i64 %t488, ptr %l32, !tbaa !24
  %t489 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ebegin(ptr %v0, ptr %t489, i64 0)
  br label %bb146
bb146:
  %t491 = load ptr, ptr %l0, !tbaa !29
  %t493 = getelementptr %"compiler/fmt:formatter", ptr %t491, i32 0, i32 35
  store i1 true, ptr %t493, !tbaa !21
  %t494 = load ptr, ptr %l0, !tbaa !29
  %t496 = getelementptr %"compiler/fmt:formatter", ptr %t494, i32 0, i32 20
  store ptr %t496, ptr %l277, !tbaa !29
  %t497 = load ptr, ptr %l0, !tbaa !29
  %t499 = getelementptr %"compiler/fmt:formatter", ptr %t497, i32 0, i32 0
  %t500 = load { i64, ptr }, ptr %t499, !tbaa !27
  store { i64, ptr } %t500, ptr %l279, !tbaa !27
  %t501 = load i64, ptr %l31, !tbaa !24
  store i64 %t501, ptr %l280, !tbaa !24
  %t502 = load i64, ptr %l32, !tbaa !24
  store i64 %t502, ptr %l281, !tbaa !24
  %t503 = load { i64, ptr }, ptr %l279, !tbaa !27
  %t504 = extractvalue { i64, ptr } %t503, 0
  store i64 %t504, ptr %l282, !tbaa !24
  %t505 = load i64, ptr %l280, !tbaa !24
  %t506 = icmp sge i64 %t505, 0
  br i1 %t506, label %bb147, label %bb148
bb147:
  %t508 = load i64, ptr %l280, !tbaa !24
  %t509 = load i64, ptr %l281, !tbaa !24
  %t510 = icmp sle i64 %t508, %t509
  br i1 %t510, label %bb149, label %bb150
bb148:
  call void @__olang_check_failed(ptr @olang_loc_aa98af033dba4568_940e94a7ebea1854)
  unreachable
bb149:
  %t512 = load i64, ptr %l281, !tbaa !24
  %t513 = load i64, ptr %l282, !tbaa !24
  %t514 = icmp sle i64 %t512, %t513
  br i1 %t514, label %bb151, label %bb152
bb150:
  call void @__olang_check_failed(ptr @olang_loc_aa98af033dba4568_940e94a7ebea1854)
  unreachable
bb151:
  %t516 = getelementptr { i64, ptr }, ptr %l279, i32 0, i32 1
  %t517 = load ptr, ptr %t516, !tbaa !27
  %t518 = load i64, ptr %l280, !tbaa !24
  %t519 = load i64, ptr %l281, !tbaa !24
  %t520 = getelementptr i8, ptr %t517, i64 %t518
  %t521 = sub i64 %t519, %t518
  %t522 = insertvalue { i64, ptr } undef, i64 %t521, 0
  %t523 = insertvalue { i64, ptr } %t522, ptr %t520, 1
  %t524 = load ptr, ptr %l277, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v0, ptr %t524, { i64, ptr } %t523)
  br label %bb153
bb152:
  call void @__olang_check_failed(ptr @olang_loc_aa98af033dba4568_940e94a7ebea1854)
  unreachable
bb153:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb154
bb154:
  %t526 = load i64, ptr %l20, !tbaa !24
  store i64 %t526, ptr %l287, !tbaa !24
  %t527 = load ptr, ptr %l0, !tbaa !29
  %t529 = getelementptr %"compiler/fmt:formatter", ptr %t527, i32 0, i32 8
  %t531 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t529)
  store i64 %t531, ptr %l290
  br label %bb155
bb155:
  %t532 = load i64, ptr %l287, !tbaa !24
  %t533 = load i64, ptr %l290, !tbaa !24
  %t534 = icmp slt i64 %t532, %t533
  br i1 %t534, label %bb156, label %bb157
bb156:
  %t536 = load ptr, ptr %l0, !tbaa !29
  %t538 = getelementptr %"compiler/fmt:formatter", ptr %t536, i32 0, i32 1
  %t539 = load { i64, ptr }, ptr %t538, !tbaa !27
  store { i64, ptr } %t539, ptr %l294, !tbaa !27
  %t540 = load ptr, ptr %l0, !tbaa !29
  %t542 = getelementptr %"compiler/fmt:formatter", ptr %t540, i32 0, i32 8
  %t543 = load i64, ptr %l20, !tbaa !24
  %t546 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t542, i64 %t543)
  store i64 %t546, ptr %l298
  br label %bb158
bb157:
  store i1 false, ptr %l292, !tbaa !21
  br label %bb159
bb158:
  %t547 = load i64, ptr %l298, !tbaa !24
  %t548 = getelementptr { i64, ptr }, ptr %l294, i32 0, i32 1
  %t549 = load ptr, ptr %t548, !tbaa !27
  %t550 = getelementptr %"compiler/token:Token", ptr %t549, i64 %t547
  %t551 = getelementptr %"compiler/token:Token", ptr %t550, i32 0, i32 2
  %t552 = load i32, ptr %t551, !tbaa !23
  %t554 = sext i32 %t552 to i64
  %t555 = load i64, ptr %l32, !tbaa !24
  %t558 = icmp slt i64 %t554, %t555
  store i1 %t558, ptr %l292, !tbaa !21
  br label %bb159
bb159:
  %t560 = load i1, ptr %l292, !tbaa !21
  %t561 = xor i1 %t560, true
  br i1 %t561, label %bb160, label %bb161
bb160:
  br label %bb171
bb161:
  br label %bb162
bb162:
  %t563 = load i1, ptr %l33, !tbaa !21
  br i1 %t563, label %bb163, label %bb164
bb163:
  %t565 = load ptr, ptr %l0, !tbaa !29
  %t566 = load i64, ptr %l20, !tbaa !24
  %t569 = call i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2elevel(ptr %v0, ptr %t565, i64 %t566)
  store i64 %t569, ptr %l307
  br label %bb165
bb164:
  br label %bb166
bb165:
  br label %bb166
bb166:
  store i1 false, ptr %l33, !tbaa !21
  %t570 = load ptr, ptr %l0, !tbaa !29
  store ptr %t570, ptr %l308, !tbaa !29
  %t571 = load ptr, ptr %l0, !tbaa !29
  %t573 = getelementptr %"compiler/fmt:formatter", ptr %t571, i32 0, i32 8
  %t574 = load i64, ptr %l20, !tbaa !24
  %t577 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t573, i64 %t574)
  store i64 %t577, ptr %l312
  br label %bb167
bb167:
  %t578 = load i64, ptr %l312, !tbaa !24
  %t579 = load ptr, ptr %l308, !tbaa !29
  %t580 = getelementptr %"compiler/fmt:formatter", ptr %t579, i32 0, i32 30
  store i64 %t578, ptr %t580, !tbaa !24
  %t581 = load ptr, ptr %l0, !tbaa !29
  store ptr %t581, ptr %l313, !tbaa !29
  %t582 = load ptr, ptr %l0, !tbaa !29
  %t584 = getelementptr %"compiler/fmt:formatter", ptr %t582, i32 0, i32 8
  %t585 = load i64, ptr %l20, !tbaa !24
  %t588 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t584, i64 %t585)
  store i64 %t588, ptr %l317
  br label %bb168
bb168:
  %t589 = load ptr, ptr %l313, !tbaa !29
  %t590 = load i64, ptr %l317, !tbaa !24
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2etrack(ptr %v0, ptr %t589, i64 %t590)
  br label %bb169
bb169:
  %t591 = load i64, ptr %l20, !tbaa !24
  %t594 = add i64 %t591, 1
  store i64 %t594, ptr %l20, !tbaa !24
  br label %bb170
bb170:
  br label %bb154
bb171:
  %t596 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2efinish(ptr %v0, ptr %t596)
  br label %bb172
bb172:
  %t598 = load i64, ptr %l32, !tbaa !24
  %t600 = add i64 %t598, 1
  store i64 %t600, ptr %l31, !tbaa !24
  br label %bb173
bb173:
  br label %bb138
bb174:
  %t602 = load i64, ptr %l31, !tbaa !24
  %t603 = load ptr, ptr %l0, !tbaa !29
  %t605 = getelementptr %"compiler/fmt:formatter", ptr %t603, i32 0, i32 0
  %t606 = load { i64, ptr }, ptr %t605, !tbaa !27
  %t608 = extractvalue { i64, ptr } %t606, 0
  %t611 = icmp sle i64 %t602, %t608
  br i1 %t611, label %bb175, label %bb176
bb175:
  %t613 = load i64, ptr %l31, !tbaa !24
  store i64 %t613, ptr %l329, !tbaa !24
  br label %bb177
bb176:
  %t615 = load ptr, ptr %l0, !tbaa !29
  %t617 = getelementptr %"compiler/fmt:formatter", ptr %t615, i32 0, i32 0
  %t618 = load { i64, ptr }, ptr %t617, !tbaa !27
  %t620 = extractvalue { i64, ptr } %t618, 0
  store i64 %t620, ptr %l329, !tbaa !24
  br label %bb177
bb177:
  %t622 = load i64, ptr %l329, !tbaa !24
  store i64 %t622, ptr %l19, !tbaa !24
  br label %bb181
bb178:
  %t623 = load ptr, ptr %l0, !tbaa !29
  %t624 = load i64, ptr %l19, !tbaa !24
  %t625 = load ptr, ptr %l0, !tbaa !29
  %t627 = getelementptr %"compiler/fmt:formatter", ptr %t625, i32 0, i32 1
  %t628 = load { i64, ptr }, ptr %t627, !tbaa !27
  store { i64, ptr } %t628, ptr %l337, !tbaa !27
  %t629 = load i64, ptr %l21, !tbaa !24
  %t631 = getelementptr { i64, ptr }, ptr %l337, i32 0, i32 1
  %t632 = load ptr, ptr %t631, !tbaa !27
  %t633 = getelementptr %"compiler/token:Token", ptr %t632, i64 %t629
  %t634 = getelementptr %"compiler/token:Token", ptr %t633, i32 0, i32 2
  %t635 = load i32, ptr %t634, !tbaa !23
  %t637 = sext i32 %t635 to i64
  %t638 = load i64, ptr %l20, !tbaa !24
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2egap(ptr %v0, ptr %t623, i64 %t624, i64 %t637, i64 %t638)
  br label %bb179
bb179:
  %t643 = load ptr, ptr %l0, !tbaa !29
  %t644 = load i64, ptr %l20, !tbaa !24
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2etoken(ptr %v0, ptr %t643, i64 %t644)
  br label %bb180
bb180:
  %t647 = load ptr, ptr %l0, !tbaa !29
  %t649 = getelementptr %"compiler/fmt:formatter", ptr %t647, i32 0, i32 1
  %t650 = load { i64, ptr }, ptr %t649, !tbaa !27
  store { i64, ptr } %t650, ptr %l345, !tbaa !27
  %t651 = load i64, ptr %l21, !tbaa !24
  %t653 = getelementptr { i64, ptr }, ptr %l345, i32 0, i32 1
  %t654 = load ptr, ptr %t653, !tbaa !27
  %t655 = getelementptr %"compiler/token:Token", ptr %t654, i64 %t651
  %t656 = getelementptr %"compiler/token:Token", ptr %t655, i32 0, i32 3
  %t657 = load i32, ptr %t656, !tbaa !23
  %t659 = sext i32 %t657 to i64
  store i64 %t659, ptr %l19, !tbaa !24
  %t661 = load i64, ptr %l20, !tbaa !24
  %t664 = add i64 %t661, 1
  store i64 %t664, ptr %l20, !tbaa !24
  br label %bb181
bb181:
  br label %bb100
bb182:
  %t666 = load ptr, ptr %l0, !tbaa !29
  %t667 = load i64, ptr %l19, !tbaa !24
  %t668 = load ptr, ptr %l0, !tbaa !29
  %t670 = getelementptr %"compiler/fmt:formatter", ptr %t668, i32 0, i32 0
  %t671 = load { i64, ptr }, ptr %t670, !tbaa !27
  %t673 = extractvalue { i64, ptr } %t671, 0
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2egap(ptr %v0, ptr %t666, i64 %t667, i64 %t673, i64 -1)
  br label %bb183
bb183:
  %t677 = load ptr, ptr %l0, !tbaa !29
  %t679 = getelementptr %"compiler/fmt:formatter", ptr %t677, i32 0, i32 21
  %t680 = load i1, ptr %t679, !tbaa !21
  br i1 %t680, label %bb184, label %bb185
bb184:
  %t682 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2efinish(ptr %v0, ptr %t682)
  br label %bb186
bb185:
  br label %bb187
bb186:
  br label %bb187
bb187:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2espace(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l11 = alloca i32
  %l14 = alloca i32
  %l17 = alloca { i64, ptr }
  %l20 = alloca i1
  %l23 = alloca { i64, ptr }
  %l26 = alloca i1
  %l29 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l44 = alloca i1
  %l47 = alloca { i64, ptr }
  %l50 = alloca i1
  %l52 = alloca { i64, ptr }
  %l56 = alloca i1
  %l60 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l68 = alloca i1
  %l70 = alloca i64
  %l73 = alloca i64
  %l75 = alloca i1
  %l76 = alloca ptr
  %l81 = alloca i64
  %l82 = alloca i32
  %l85 = alloca { i64, ptr }
  %l88 = alloca i1
  %l91 = alloca i1
  %l94 = alloca i1
  %l96 = alloca { i64, ptr }
  %l100 = alloca i1
  %l102 = alloca i1
  %l110 = alloca i64
  %l113 = alloca i32
  %l116 = alloca i1
  %l118 = alloca { i64, ptr }
  %l122 = alloca i1
  %l126 = alloca { i64, ptr }
  %l129 = alloca i1
  %l132 = alloca i1
  %l133 = alloca { i64, ptr }
  %l136 = alloca i1
  %l139 = alloca { i64, ptr }
  %l142 = alloca { i64, ptr }
  %l145 = alloca i1
  %l147 = alloca { i64, ptr }
  %l150 = alloca i1
  %l152 = alloca { i64, ptr }
  %l155 = alloca { i64, ptr }
  %l158 = alloca i1
  %l161 = alloca { i64, ptr }
  %l164 = alloca i1
  %l167 = alloca { i64, ptr }
  %l172 = alloca i1
  %l175 = alloca i1
  %l178 = alloca i1
  %l181 = alloca i1
  %l184 = alloca i1
  %l187 = alloca { i64, ptr }
  %l188 = alloca { i64, ptr }
  %l191 = alloca i1
  %l194 = alloca i1
  %l197 = alloca i1
  %l198 = alloca { i64, ptr }
  %l202 = alloca { i64, ptr }
  %l205 = alloca { i64, ptr }
  %l212 = alloca i1
  %l213 = alloca { i64, ptr }
  %l216 = alloca { i64, ptr }
  %l221 = alloca { i64, ptr }
  %l224 = alloca i1
  %l225 = alloca i1
  %l228 = alloca i1
  %l229 = alloca ptr
  %l234 = alloca i64
  %l235 = alloca i32
  %l239 = alloca { i64, ptr }
  %l244 = alloca i64
  %l248 = alloca i1
  %l252 = alloca i32
  %l255 = alloca { i64, ptr }
  %l260 = alloca { i64, ptr }
  %l263 = alloca i64
  %l266 = alloca { i64, ptr }
  %l271 = alloca { i64, ptr }
  %l274 = alloca i1
  %l275 = alloca i1
  %l279 = alloca i1
  %l283 = alloca { i64, ptr }
  %l284 = alloca { i64, ptr }
  %l291 = alloca { i64, ptr }
  %l294 = alloca i1
  %l295 = alloca i1
  %l299 = alloca i1
  %l303 = alloca i1
  %l307 = alloca i1
  %l311 = alloca { i64, ptr }
  %l312 = alloca { i64, ptr }
  %l314 = alloca { i64, ptr }
  %l318 = alloca { i64, ptr }
  %l319 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t1, i64 %t2)
  store i32 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i32, ptr %l11, !range !{i32 0, i32 116}
  store i32 %t6, ptr %l4
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i64, ptr %l2, !tbaa !24
  %t11 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t7, i64 %t8)
  store i32 %t11, ptr %l14
  br label %bb2
bb2:
  %t12 = load i32, ptr %l14, !range !{i32 0, i32 116}
  store i32 %t12, ptr %l5
  %t13 = load i32, ptr %l5, !range !{i32 0, i32 116}
  %t15 = trunc i64 75 to i32
  %t16 = icmp eq i32 %t13, %t15
  br i1 %t16, label %bb3, label %bb4
bb3:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr %l17, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t19 = load i32, ptr %l5, !range !{i32 0, i32 116}
  %t21 = trunc i64 111 to i32
  %t22 = icmp eq i32 %t19, %t21
  br i1 %t22, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb8
bb7:
  %t24 = load i32, ptr %l5, !range !{i32 0, i32 116}
  %t26 = trunc i64 113 to i32
  %t27 = icmp eq i32 %t24, %t26
  store i1 %t27, ptr %l20, !tbaa !21
  br label %bb8
bb8:
  %t29 = load i1, ptr %l20, !tbaa !21
  br i1 %t29, label %bb9, label %bb10
bb9:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d10, i32 0, i32 1) }, ptr %l23, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t30, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t31 = load i32, ptr %l4, !range !{i32 0, i32 116}
  %t33 = trunc i64 110 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb14
bb13:
  %t36 = load i32, ptr %l4, !range !{i32 0, i32 116}
  %t38 = trunc i64 112 to i32
  %t39 = icmp eq i32 %t36, %t38
  store i1 %t39, ptr %l26, !tbaa !21
  br label %bb14
bb14:
  %t41 = load i1, ptr %l26, !tbaa !21
  br i1 %t41, label %bb15, label %bb16
bb15:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d11, i32 0, i32 1) }, ptr %l29, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t42, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/fmt:formatter", ptr %t43, i32 0, i32 4
  %t46 = load { i64, ptr }, ptr %t45, !tbaa !27
  store { i64, ptr } %t46, ptr %l31, !tbaa !27
  %t47 = load i64, ptr %l2, !tbaa !24
  %t49 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr i64, ptr %t50, i64 %t47
  %t52 = load i64, ptr %t51, !tbaa !34
  %t54 = icmp sgt i64 %t52, 0
  br i1 %t54, label %bb18, label %bb19
bb18:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d12, i32 0, i32 1) }, ptr %l35, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t56, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/fmt:formatter", ptr %t57, i32 0, i32 2
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !27
  store { i64, ptr } %t60, ptr %l37, !tbaa !27
  %t61 = load i64, ptr %l1, !tbaa !24
  %t63 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr i64, ptr %t64, i64 %t61
  %t66 = load i64, ptr %t65, !tbaa !34
  %t68 = icmp sgt i64 %t66, 0
  br i1 %t68, label %bb21, label %bb22
bb21:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d13, i32 0, i32 1) }, ptr %l41, !tbaa !27
  %t70 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t70, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t71 = load i32, ptr %l4, !range !{i32 0, i32 116}
  %t73 = trunc i64 102 to i32
  %t74 = icmp eq i32 %t71, %t73
  br i1 %t74, label %bb24, label %bb25
bb24:
  %t76 = load i32, ptr %l5, !range !{i32 0, i32 116}
  %t78 = trunc i64 114 to i32
  %t79 = icmp eq i32 %t76, %t78
  store i1 %t79, ptr %l44, !tbaa !21
  br label %bb26
bb25:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb26
bb26:
  %t81 = load i1, ptr %l44, !tbaa !21
  br i1 %t81, label %bb27, label %bb28
bb27:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, ptr %l47, !tbaa !27
  %t82 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t82, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t83 = load i32, ptr %l4, !range !{i32 0, i32 116}
  %t85 = trunc i64 102 to i32
  %t86 = icmp eq i32 %t83, %t85
  br i1 %t86, label %bb30, label %bb31
bb30:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/fmt:formatter", ptr %t88, i32 0, i32 1
  %t91 = load { i64, ptr }, ptr %t90, !tbaa !27
  store { i64, ptr } %t91, ptr %l52, !tbaa !27
  %t92 = load i64, ptr %l1, !tbaa !24
  %t94 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr %"compiler/token:Token", ptr %t95, i64 %t92
  %t97 = load %"compiler/token:Token", ptr %t96
  %t98 = load i8, ptr @G_2ecompiler_2ftoken_2eSpace, !tbaa !22
  %t101 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t97, i8 %t98)
  store i1 %t101, ptr %l56
  br label %bb32
bb31:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb33
bb32:
  %t102 = load i1, ptr %l56, !tbaa !21
  %t103 = xor i1 %t102, true
  store i1 %t103, ptr %l50, !tbaa !21
  br label %bb33
bb33:
  %t105 = load i1, ptr %l50, !tbaa !21
  br i1 %t105, label %bb34, label %bb35
bb34:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load i64, ptr %l2, !tbaa !24
  %t110 = call { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2easWritten(ptr %v0, ptr %v1, ptr %t106, i64 %t107)
  store { i64, ptr } %t110, ptr %l60
  br label %bb36
bb35:
  br label %bb37
bb36:
  %t111 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t111, ptr %rv
  br label %ret
bb37:
  %t112 = load i32, ptr %l5, !range !{i32 0, i32 116}
  %t114 = trunc i64 102 to i32
  %t115 = icmp eq i32 %t112, %t114
  br i1 %t115, label %bb38, label %bb39
bb38:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load i64, ptr %l2, !tbaa !24
  %t121 = call { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2easWritten(ptr %v0, ptr %v1, ptr %t117, i64 %t118)
  store { i64, ptr } %t121, ptr %l65
  br label %bb40
bb39:
  br label %bb41
bb40:
  %t122 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t122, ptr %rv
  br label %ret
bb41:
  %t123 = load i32, ptr %l5, !range !{i32 0, i32 116}
  %t125 = trunc i64 77 to i32
  %t126 = icmp eq i32 %t123, %t125
  br i1 %t126, label %bb42, label %bb43
bb42:
  %t128 = load i64, ptr %l3, !tbaa !24
  %t130 = add i64 %t128, 1
  store i64 %t130, ptr %l70, !tbaa !24
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/fmt:formatter", ptr %t131, i32 0, i32 8
  %t135 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t133)
  store i64 %t135, ptr %l73
  br label %bb44
bb43:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb45
bb44:
  %t136 = load i64, ptr %l70, !tbaa !24
  %t137 = load i64, ptr %l73, !tbaa !24
  %t138 = icmp slt i64 %t136, %t137
  store i1 %t138, ptr %l68, !tbaa !21
  br label %bb45
bb45:
  %t140 = load i1, ptr %l68, !tbaa !21
  br i1 %t140, label %bb46, label %bb47
bb46:
  %t141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t141, ptr %l76, !tbaa !29
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/fmt:formatter", ptr %t142, i32 0, i32 8
  %t145 = load i64, ptr %l3, !tbaa !24
  %t147 = add i64 %t145, 1
  %t150 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t144, i64 %t147)
  store i64 %t150, ptr %l81
  br label %bb48
bb47:
  store i1 false, ptr %l75, !tbaa !21
  br label %bb50
bb48:
  %t151 = load ptr, ptr %l76, !tbaa !29
  %t152 = load i64, ptr %l81, !tbaa !24
  %t153 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t151, i64 %t152)
  store i32 %t153, ptr %l82
  br label %bb49
bb49:
  %t154 = load i32, ptr %l82, !range !{i32 0, i32 116}
  %t156 = trunc i64 102 to i32
  %t157 = icmp eq i32 %t154, %t156
  store i1 %t157, ptr %l75, !tbaa !21
  br label %bb50
bb50:
  %t159 = load i1, ptr %l75, !tbaa !21
  br i1 %t159, label %bb51, label %bb52
bb51:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d15, i32 0, i32 1) }, ptr %l85, !tbaa !27
  %t160 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t160, ptr %rv
  br label %ret
bb52:
  br label %bb53
bb53:
  %t161 = load i32, ptr %l4, !range !{i32 0, i32 116}
  %t163 = trunc i64 1 to i32
  %t164 = icmp eq i32 %t161, %t163
  br i1 %t164, label %bb54, label %bb55
bb54:
  store i1 true, ptr %l88, !tbaa !21
  br label %bb56
bb55:
  %t166 = load i32, ptr %l4, !range !{i32 0, i32 116}
  %t168 = trunc i64 13 to i32
  %t169 = icmp eq i32 %t166, %t168
  store i1 %t169, ptr %l88, !tbaa !21
  br label %bb56
bb56:
  %t171 = load i1, ptr %l88, !tbaa !21
  br i1 %t171, label %bb57, label %bb58
bb57:
  %t172 = load i64, ptr %l3, !tbaa !24
  %t174 = icmp sge i64 %t172, 2
  store i1 %t174, ptr %l91, !tbaa !21
  br label %bb59
bb58:
  store i1 false, ptr %l91, !tbaa !21
  br label %bb59
bb59:
  %t176 = load i1, ptr %l91, !tbaa !21
  br i1 %t176, label %bb60, label %bb61
bb60:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/fmt:formatter", ptr %t177, i32 0, i32 1
  %t180 = load { i64, ptr }, ptr %t179, !tbaa !27
  store { i64, ptr } %t180, ptr %l96, !tbaa !27
  %t181 = load i64, ptr %l1, !tbaa !24
  %t183 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t184 = load ptr, ptr %t183, !tbaa !27
  %t185 = getelementptr %"compiler/token:Token", ptr %t184, i64 %t181
  %t186 = load %"compiler/token:Token", ptr %t185
  %t187 = load i8, ptr @G_2ecompiler_2ftoken_2eSpace, !tbaa !22
  %t190 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t186, i8 %t187)
  store i1 %t190, ptr %l100
  br label %bb62
bb61:
  store i1 false, ptr %l94, !tbaa !21
  br label %bb63
bb62:
  %t191 = load i1, ptr %l100, !tbaa !21
  %t192 = xor i1 %t191, true
  store i1 %t192, ptr %l94, !tbaa !21
  br label %bb63
bb63:
  %t194 = load i1, ptr %l94, !tbaa !21
  br i1 %t194, label %bb64, label %bb65
bb64:
  %t195 = load i32, ptr %l5, !range !{i32 0, i32 116}
  %t197 = trunc i64 114 to i32
  %t198 = icmp eq i32 %t195, %t197
  %t200 = xor i1 %t198, true
  store i1 %t200, ptr %l102, !tbaa !21
  br label %bb66
bb65:
  store i1 false, ptr %l102, !tbaa !21
  br label %bb66
bb66:
  %t202 = load i1, ptr %l102, !tbaa !21
  br i1 %t202, label %bb67, label %bb68
bb67:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"compiler/fmt:formatter", ptr %t203, i32 0, i32 8
  %t206 = load i64, ptr %l3, !tbaa !24
  %t208 = sub i64 %t206, 2
  %t211 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t205, i64 %t208)
  store i64 %t211, ptr %l110
  br label %bb69
bb68:
  br label %bb79
bb69:
  %t212 = load i64, ptr %l110, !tbaa !24
  store i64 %t212, ptr %l6, !tbaa !24
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t214 = load i64, ptr %l6, !tbaa !24
  %t217 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t213, i64 %t214)
  store i32 %t217, ptr %l113
  br label %bb70
bb70:
  %t218 = load i32, ptr %l113, !range !{i32 0, i32 116}
  %t220 = trunc i64 102 to i32
  %t221 = icmp eq i32 %t218, %t220
  br i1 %t221, label %bb71, label %bb72
bb71:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t225 = getelementptr %"compiler/fmt:formatter", ptr %t223, i32 0, i32 1
  %t226 = load { i64, ptr }, ptr %t225, !tbaa !27
  store { i64, ptr } %t226, ptr %l118, !tbaa !27
  %t227 = load i64, ptr %l6, !tbaa !24
  %t229 = getelementptr { i64, ptr }, ptr %l118, i32 0, i32 1
  %t230 = load ptr, ptr %t229, !tbaa !27
  %t231 = getelementptr %"compiler/token:Token", ptr %t230, i64 %t227
  %t232 = load %"compiler/token:Token", ptr %t231
  %t233 = load i8, ptr @G_2ecompiler_2ftoken_2eSpace, !tbaa !22
  %t236 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t232, i8 %t233)
  store i1 %t236, ptr %l122
  br label %bb73
bb72:
  store i1 false, ptr %l116, !tbaa !21
  br label %bb74
bb73:
  %t237 = load i1, ptr %l122, !tbaa !21
  %t238 = xor i1 %t237, true
  store i1 %t238, ptr %l116, !tbaa !21
  br label %bb74
bb74:
  %t240 = load i1, ptr %l116, !tbaa !21
  br i1 %t240, label %bb75, label %bb76
bb75:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t242 = load i64, ptr %l2, !tbaa !24
  %t245 = call { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2easWritten(ptr %v0, ptr %v1, ptr %t241, i64 %t242)
  store { i64, ptr } %t245, ptr %l126
  br label %bb77
bb76:
  br label %bb78
bb77:
  %t246 = load { i64, ptr }, ptr %l126, !tbaa !27
  store { i64, ptr } %t246, ptr %rv
  br label %ret
bb78:
  br label %bb79
bb79:
  %t247 = load i32, ptr %l5, !range !{i32 0, i32 116}
  %t249 = trunc i64 76 to i32
  %t250 = icmp eq i32 %t247, %t249
  br i1 %t250, label %bb80, label %bb81
bb80:
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t253 = load i64, ptr %l2, !tbaa !24
  %t256 = call i1 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2eellipsisAt(ptr %v0, ptr %t252, i64 %t253)
  store i1 %t256, ptr %l132
  br label %bb82
bb81:
  store i1 false, ptr %l129, !tbaa !21
  br label %bb83
bb82:
  %t257 = load i1, ptr %l132, !tbaa !21
  store i1 %t257, ptr %l129, !tbaa !21
  br label %bb83
bb83:
  %t258 = load i1, ptr %l129, !tbaa !21
  br i1 %t258, label %bb84, label %bb85
bb84:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, ptr %l133, !tbaa !27
  %t259 = load { i64, ptr }, ptr %l133, !tbaa !27
  store { i64, ptr } %t259, ptr %rv
  br label %ret
bb85:
  br label %bb86
bb86:
  %t260 = load i32, ptr %l4, !range !{i32 0, i32 116}
  %t262 = trunc i64 76 to i32
  %t263 = icmp eq i32 %t260, %t262
  br i1 %t263, label %bb87, label %bb88
bb87:
  store i1 true, ptr %l136, !tbaa !21
  br label %bb89
bb88:
  %t265 = load i32, ptr %l5, !range !{i32 0, i32 116}
  %t267 = trunc i64 76 to i32
  %t268 = icmp eq i32 %t265, %t267
  store i1 %t268, ptr %l136, !tbaa !21
  br label %bb89
bb89:
  %t270 = load i1, ptr %l136, !tbaa !21
  br i1 %t270, label %bb90, label %bb91
bb90:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d17, i32 0, i32 1) }, ptr %l139, !tbaa !27
  %t271 = load { i64, ptr }, ptr %l139, !tbaa !27
  store { i64, ptr } %t271, ptr %rv
  br label %ret
bb91:
  br label %bb92
bb92:
  %t272 = load i32, ptr %l5, !range !{i32 0, i32 116}
  %t274 = trunc i64 97 to i32
  %t275 = icmp eq i32 %t272, %t274
  br i1 %t275, label %bb93, label %bb94
bb93:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d18, i32 0, i32 1) }, ptr %l142, !tbaa !27
  %t277 = load { i64, ptr }, ptr %l142, !tbaa !27
  store { i64, ptr } %t277, ptr %rv
  br label %ret
bb94:
  br label %bb95
bb95:
  %t278 = load i32, ptr %l4, !range !{i32 0, i32 116}
  %t280 = trunc i64 79 to i32
  %t281 = icmp eq i32 %t278, %t280
  br i1 %t281, label %bb96, label %bb97
bb96:
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t285 = getelementptr %"compiler/fmt:formatter", ptr %t283, i32 0, i32 5
  %t286 = load { i64, ptr }, ptr %t285, !tbaa !27
  store { i64, ptr } %t286, ptr %l147, !tbaa !27
  %t287 = load i64, ptr %l1, !tbaa !24
  %t289 = getelementptr { i64, ptr }, ptr %l147, i32 0, i32 1
  %t290 = load ptr, ptr %t289, !tbaa !27
  %t291 = getelementptr i1, ptr %t290, i64 %t287
  %t292 = load i1, ptr %t291, !tbaa !31
  br i1 %t292, label %bb98, label %bb99
bb97:
  store i1 false, ptr %l145, !tbaa !21
  br label %bb101
bb98:
  store i1 true, ptr %l150, !tbaa !21
  br label %bb100
bb99:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t296 = getelementptr %"compiler/fmt:formatter", ptr %t294, i32 0, i32 6
  %t297 = load { i64, ptr }, ptr %t296, !tbaa !27
  store { i64, ptr } %t297, ptr %l152, !tbaa !27
  %t298 = load i64, ptr %l1, !tbaa !24
  %t300 = getelementptr { i64, ptr }, ptr %l152, i32 0, i32 1
  %t301 = load ptr, ptr %t300, !tbaa !27
  %t302 = getelementptr i1, ptr %t301, i64 %t298
  %t303 = load i1, ptr %t302, !tbaa !31
  store i1 %t303, ptr %l150, !tbaa !21
  br label %bb100
bb100:
  %t305 = load i1, ptr %l150, !tbaa !21
  store i1 %t305, ptr %l145, !tbaa !21
  br label %bb101
bb101:
  %t306 = load i1, ptr %l145, !tbaa !21
  br i1 %t306, label %bb102, label %bb103
bb102:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %l155, !tbaa !27
  %t307 = load { i64, ptr }, ptr %l155, !tbaa !27
  store { i64, ptr } %t307, ptr %rv
  br label %ret
bb103:
  br label %bb104
bb104:
  %t308 = load i32, ptr %l4, !range !{i32 0, i32 116}
  %t310 = trunc i64 75 to i32
  %t311 = icmp eq i32 %t308, %t310
  br i1 %t311, label %bb105, label %bb106
bb105:
  %t313 = load i32, ptr %l5, !range !{i32 0, i32 116}
  %t315 = trunc i64 79 to i32
  %t316 = icmp eq i32 %t313, %t315
  store i1 %t316, ptr %l158, !tbaa !21
  br label %bb107
bb106:
  store i1 false, ptr %l158, !tbaa !21
  br label %bb107
bb107:
  %t318 = load i1, ptr %l158, !tbaa !21
  br i1 %t318, label %bb108, label %bb109
bb108:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, ptr %l161, !tbaa !27
  %t319 = load { i64, ptr }, ptr %l161, !tbaa !27
  store { i64, ptr } %t319, ptr %rv
  br label %ret
bb109:
  br label %bb110
bb110:
  %t320 = load i32, ptr %l4, !range !{i32 0, i32 116}
  %t322 = trunc i64 79 to i32
  %t323 = icmp eq i32 %t320, %t322
  br i1 %t323, label %bb111, label %bb112
bb111:
  store i1 true, ptr %l164, !tbaa !21
  br label %bb113
bb112:
  %t325 = load i32, ptr %l5, !range !{i32 0, i32 116}
  %t327 = trunc i64 79 to i32
  %t328 = icmp eq i32 %t325, %t327
  store i1 %t328, ptr %l164, !tbaa !21
  br label %bb113
bb113:
  %t330 = load i1, ptr %l164, !tbaa !21
  br i1 %t330, label %bb114, label %bb115
bb114:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d21, i32 0, i32 1) }, ptr %l167, !tbaa !27
  %t331 = load { i64, ptr }, ptr %l167, !tbaa !27
  store { i64, ptr } %t331, ptr %rv
  br label %ret
bb115:
  br label %bb116
bb116:
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t333 = load i64, ptr %l1, !tbaa !24
  %t334 = load i64, ptr %l3, !tbaa !24
  %t336 = sub i64 %t334, 1
  %t340 = call i1 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2eprefix(ptr %v0, ptr %t332, i64 %t333, i64 %t336)
  store i1 %t340, ptr %l172
  br label %bb117
bb117:
  %t341 = load i1, ptr %l172, !tbaa !21
  br i1 %t341, label %bb118, label %bb119
bb118:
  %t342 = load i32, ptr %l4, !range !{i32 0, i32 116}
  %t344 = trunc i64 69 to i32
  %t345 = icmp eq i32 %t342, %t344
  br i1 %t345, label %bb120, label %bb121
bb119:
  br label %bb135
bb120:
  %t347 = load i32, ptr %l5, !range !{i32 0, i32 116}
  %t349 = trunc i64 69 to i32
  %t350 = icmp eq i32 %t347, %t349
  br i1 %t350, label %bb122, label %bb123
bb121:
  store i1 false, ptr %l175, !tbaa !21
  br label %bb125
bb122:
  store i1 true, ptr %l178, !tbaa !21
  br label %bb124
bb123:
  %t352 = load i32, ptr %l5, !range !{i32 0, i32 116}
  %t354 = trunc i64 94 to i32
  %t355 = icmp eq i32 %t352, %t354
  store i1 %t355, ptr %l178, !tbaa !21
  br label %bb124
bb124:
  %t357 = load i1, ptr %l178, !tbaa !21
  store i1 %t357, ptr %l175, !tbaa !21
  br label %bb125
bb125:
  %t358 = load i1, ptr %l175, !tbaa !21
  br i1 %t358, label %bb126, label %bb127
bb126:
  store i1 true, ptr %l181, !tbaa !21
  br label %bb131
bb127:
  %t359 = load i32, ptr %l4, !range !{i32 0, i32 116}
  %t361 = trunc i64 94 to i32
  %t362 = icmp eq i32 %t359, %t361
  br i1 %t362, label %bb128, label %bb129
bb128:
  %t364 = load i32, ptr %l5, !range !{i32 0, i32 116}
  %t366 = trunc i64 69 to i32
  %t367 = icmp eq i32 %t364, %t366
  store i1 %t367, ptr %l184, !tbaa !21
  br label %bb130
bb129:
  store i1 false, ptr %l184, !tbaa !21
  br label %bb130
bb130:
  %t369 = load i1, ptr %l184, !tbaa !21
  store i1 %t369, ptr %l181, !tbaa !21
  br label %bb131
bb131:
  %t370 = load i1, ptr %l181, !tbaa !21
  br i1 %t370, label %bb132, label %bb133
bb132:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) }, ptr %l187, !tbaa !27
  %t371 = load { i64, ptr }, ptr %l187, !tbaa !27
  store { i64, ptr } %t371, ptr %rv
  br label %ret
bb133:
  br label %bb134
bb134:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %l188, !tbaa !27
  %t372 = load { i64, ptr }, ptr %l188, !tbaa !27
  store { i64, ptr } %t372, ptr %rv
  br label %ret
bb135:
  %t373 = load i32, ptr %l5, !range !{i32 0, i32 116}
  %t375 = trunc i64 93 to i32
  %t376 = icmp eq i32 %t373, %t375
  br i1 %t376, label %bb136, label %bb137
bb136:
  store i1 true, ptr %l191, !tbaa !21
  br label %bb138
bb137:
  %t378 = load i32, ptr %l5, !range !{i32 0, i32 116}
  %t380 = trunc i64 94 to i32
  %t381 = icmp eq i32 %t378, %t380
  store i1 %t381, ptr %l191, !tbaa !21
  br label %bb138
bb138:
  %t383 = load i1, ptr %l191, !tbaa !21
  br i1 %t383, label %bb139, label %bb140
bb139:
  %t384 = load ptr, ptr %l0, !tbaa !29
  %t385 = load i64, ptr %l1, !tbaa !24
  %t388 = call i1 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2eoperandEnd(ptr %v0, ptr %t384, i64 %t385)
  store i1 %t388, ptr %l197
  br label %bb141
bb140:
  store i1 false, ptr %l194, !tbaa !21
  br label %bb142
bb141:
  %t389 = load i1, ptr %l197, !tbaa !21
  store i1 %t389, ptr %l194, !tbaa !21
  br label %bb142
bb142:
  %t390 = load i1, ptr %l194, !tbaa !21
  br i1 %t390, label %bb143, label %bb144
bb143:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d24, i32 0, i32 1) }, ptr %l198, !tbaa !27
  %t391 = load { i64, ptr }, ptr %l198, !tbaa !27
  store { i64, ptr } %t391, ptr %rv
  br label %ret
bb144:
  br label %bb145
bb145:
  %t392 = load i32, ptr %l5, !range !{i32 0, i32 116}
  %t394 = trunc i64 110 to i32
  %t395 = icmp eq i32 %t392, %t394
  br i1 %t395, label %bb146, label %bb147
bb146:
  %t397 = load ptr, ptr %l0, !tbaa !29
  %t399 = getelementptr %"compiler/fmt:formatter", ptr %t397, i32 0, i32 3
  %t400 = load { i64, ptr }, ptr %t399, !tbaa !27
  store { i64, ptr } %t400, ptr %l202, !tbaa !27
  %t401 = load i64, ptr %l2, !tbaa !24
  %t403 = getelementptr { i64, ptr }, ptr %l202, i32 0, i32 1
  %t404 = load ptr, ptr %t403, !tbaa !27
  %t405 = getelementptr i1, ptr %t404, i64 %t401
  %t406 = load i1, ptr %t405, !tbaa !31
  br i1 %t406, label %bb148, label %bb149
bb147:
  br label %bb206
bb148:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, ptr %l205, !tbaa !27
  %t408 = load { i64, ptr }, ptr %l205, !tbaa !27
  store { i64, ptr } %t408, ptr %rv
  br label %ret
bb149:
  br label %bb150
bb150:
  %t409 = load i32, ptr %l4, !range !{i32 0, i32 116}
  %t411 = trunc i64 37 to i32
  %t412 = icmp eq i32 %t409, %t411
  br i1 %t412, label %bb151, label %bb152
bb151:
  %t414 = load ptr, ptr %l0, !tbaa !29
  %t415 = load i64, ptr %l1, !tbaa !24
  %t416 = load i64, ptr %l3, !tbaa !24
  %t418 = sub i64 %t416, 1
  %t422 = call i1 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ereceiver(ptr %v0, ptr %t414, i64 %t415, i64 %t418)
  store i1 %t422, ptr %l212
  br label %bb153
bb152:
  br label %bb157
bb153:
  %t423 = load i1, ptr %l212, !tbaa !21
  br i1 %t423, label %bb154, label %bb155
bb154:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d26, i32 0, i32 1) }, ptr %l213, !tbaa !27
  br label %bb156
bb155:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d27, i32 0, i32 1) }, ptr %l213, !tbaa !27
  br label %bb156
bb156:
  %t424 = load { i64, ptr }, ptr %l213, !tbaa !27
  store { i64, ptr } %t424, ptr %rv
  br label %ret
bb157:
  %t425 = load i32, ptr %l4, !range !{i32 0, i32 116}
  %t427 = trunc i64 34 to i32
  %t428 = icmp eq i32 %t425, %t427
  br i1 %t428, label %bb158, label %bb159
bb158:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d28, i32 0, i32 1) }, ptr %l216, !tbaa !27
  %t430 = load { i64, ptr }, ptr %l216, !tbaa !27
  store { i64, ptr } %t430, ptr %rv
  br label %ret
bb159:
  br label %bb160
bb160:
  %t431 = load i32, ptr %l4, !range !{i32 0, i32 116}
  %t433 = trunc i64 115 to i32
  %t434 = icmp eq i32 %t431, %t433
  br i1 %t434, label %bb161, label %bb162
bb161:
  %t436 = load ptr, ptr %l0, !tbaa !29
  %t437 = load i64, ptr %l2, !tbaa !24
  %t440 = call { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2easWritten(ptr %v0, ptr %v1, ptr %t436, i64 %t437)
  store { i64, ptr } %t440, ptr %l221
  br label %bb163
bb162:
  br label %bb164
bb163:
  %t441 = load { i64, ptr }, ptr %l221, !tbaa !27
  store { i64, ptr } %t441, ptr %rv
  br label %ret
bb164:
  %t442 = load ptr, ptr %l0, !tbaa !29
  %t443 = load i64, ptr %l1, !tbaa !24
  %t446 = call i1 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekeyword(ptr %v0, ptr %t442, i64 %t443)
  store i1 %t446, ptr %l224
  br label %bb165
bb165:
  %t447 = load i1, ptr %l224, !tbaa !21
  br i1 %t447, label %bb166, label %bb167
bb166:
  %t448 = load i64, ptr %l3, !tbaa !24
  %t450 = icmp sge i64 %t448, 2
  store i1 %t450, ptr %l225, !tbaa !21
  br label %bb168
bb167:
  store i1 false, ptr %l225, !tbaa !21
  br label %bb168
bb168:
  %t452 = load i1, ptr %l225, !tbaa !21
  br i1 %t452, label %bb169, label %bb170
bb169:
  %t453 = load ptr, ptr %l0, !tbaa !29
  store ptr %t453, ptr %l229, !tbaa !29
  %t454 = load ptr, ptr %l0, !tbaa !29
  %t456 = getelementptr %"compiler/fmt:formatter", ptr %t454, i32 0, i32 8
  %t457 = load i64, ptr %l3, !tbaa !24
  %t459 = sub i64 %t457, 2
  %t462 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t456, i64 %t459)
  store i64 %t462, ptr %l234
  br label %bb171
bb170:
  store i1 false, ptr %l228, !tbaa !21
  br label %bb173
bb171:
  %t463 = load ptr, ptr %l229, !tbaa !29
  %t464 = load i64, ptr %l234, !tbaa !24
  %t465 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t463, i64 %t464)
  store i32 %t465, ptr %l235
  br label %bb172
bb172:
  %t466 = load i32, ptr %l235, !range !{i32 0, i32 116}
  %t468 = trunc i64 111 to i32
  %t469 = icmp eq i32 %t466, %t468
  store i1 %t469, ptr %l228, !tbaa !21
  br label %bb173
bb173:
  %t471 = load i1, ptr %l228, !tbaa !21
  br i1 %t471, label %bb174, label %bb175
bb174:
  %t472 = load ptr, ptr %l0, !tbaa !29
  %t474 = getelementptr %"compiler/fmt:formatter", ptr %t472, i32 0, i32 24
  %t475 = load { i64, ptr }, ptr %t474, !tbaa !27
  store { i64, ptr } %t475, ptr %l239, !tbaa !27
  %t476 = load ptr, ptr %l0, !tbaa !29
  %t478 = getelementptr %"compiler/fmt:formatter", ptr %t476, i32 0, i32 8
  %t479 = load i64, ptr %l3, !tbaa !24
  %t481 = sub i64 %t479, 2
  %t484 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t478, i64 %t481)
  store i64 %t484, ptr %l244
  br label %bb176
bb175:
  br label %bb184
bb176:
  %t485 = load i64, ptr %l244, !tbaa !24
  %t486 = getelementptr { i64, ptr }, ptr %l239, i32 0, i32 1
  %t487 = load ptr, ptr %t486, !tbaa !27
  %t488 = getelementptr i64, ptr %t487, i64 %t485
  %t489 = load i64, ptr %t488, !tbaa !34
  store i64 %t489, ptr %l7, !tbaa !24
  %t491 = load i64, ptr %l7, !tbaa !24
  %t493 = icmp sgt i64 %t491, 0
  br i1 %t493, label %bb177, label %bb178
bb177:
  %t495 = load ptr, ptr %l0, !tbaa !29
  %t496 = load i64, ptr %l7, !tbaa !24
  %t498 = sub i64 %t496, 1
  %t501 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t495, i64 %t498)
  store i32 %t501, ptr %l252
  br label %bb179
bb178:
  store i1 false, ptr %l248, !tbaa !21
  br label %bb180
bb179:
  %t502 = load i32, ptr %l252, !range !{i32 0, i32 116}
  %t504 = trunc i64 37 to i32
  %t505 = icmp eq i32 %t502, %t504
  store i1 %t505, ptr %l248, !tbaa !21
  br label %bb180
bb180:
  %t507 = load i1, ptr %l248, !tbaa !21
  br i1 %t507, label %bb181, label %bb182
bb181:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d29, i32 0, i32 1) }, ptr %l255, !tbaa !27
  %t508 = load { i64, ptr }, ptr %l255, !tbaa !27
  store { i64, ptr } %t508, ptr %rv
  br label %ret
bb182:
  br label %bb183
bb183:
  br label %bb184
bb184:
  %t509 = load i32, ptr %l4, !range !{i32 0, i32 116}
  %t511 = trunc i64 111 to i32
  %t512 = icmp eq i32 %t509, %t511
  br i1 %t512, label %bb185, label %bb186
bb185:
  %t514 = load ptr, ptr %l0, !tbaa !29
  %t515 = load ptr, ptr %l0, !tbaa !29
  %t517 = getelementptr %"compiler/fmt:formatter", ptr %t515, i32 0, i32 24
  %t518 = load { i64, ptr }, ptr %t517, !tbaa !27
  store { i64, ptr } %t518, ptr %l260, !tbaa !27
  %t519 = load i64, ptr %l1, !tbaa !24
  %t521 = getelementptr { i64, ptr }, ptr %l260, i32 0, i32 1
  %t522 = load ptr, ptr %t521, !tbaa !27
  %t523 = getelementptr i64, ptr %t522, i64 %t519
  %t524 = load i64, ptr %t523, !tbaa !34
  %t527 = call i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2eparams(ptr %v0, ptr %t514, i64 %t524)
  store i64 %t527, ptr %l263
  br label %bb187
bb186:
  br label %bb195
bb187:
  %t528 = load i64, ptr %l263, !tbaa !24
  store i64 %t528, ptr %l8, !tbaa !24
  %t529 = load i64, ptr %l8, !tbaa !24
  %t531 = icmp eq i64 %t529, 1
  br i1 %t531, label %bb188, label %bb189
bb188:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d30, i32 0, i32 1) }, ptr %l266, !tbaa !27
  %t533 = load { i64, ptr }, ptr %l266, !tbaa !27
  store { i64, ptr } %t533, ptr %rv
  br label %ret
bb189:
  br label %bb190
bb190:
  %t534 = load i64, ptr %l8, !tbaa !24
  %t536 = icmp eq i64 %t534, 2
  br i1 %t536, label %bb191, label %bb192
bb191:
  %t538 = load ptr, ptr %l0, !tbaa !29
  %t539 = load i64, ptr %l2, !tbaa !24
  %t542 = call { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2easWritten(ptr %v0, ptr %v1, ptr %t538, i64 %t539)
  store { i64, ptr } %t542, ptr %l271
  br label %bb193
bb192:
  br label %bb194
bb193:
  %t543 = load { i64, ptr }, ptr %l271, !tbaa !27
  store { i64, ptr } %t543, ptr %rv
  br label %ret
bb194:
  br label %bb195
bb195:
  %t544 = load ptr, ptr %l0, !tbaa !29
  %t545 = load i64, ptr %l1, !tbaa !24
  %t548 = call i1 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2eoperandEnd(ptr %v0, ptr %t544, i64 %t545)
  store i1 %t548, ptr %l274
  br label %bb196
bb196:
  %t549 = load i1, ptr %l274, !tbaa !21
  br i1 %t549, label %bb197, label %bb198
bb197:
  %t550 = load i32, ptr %l4, !range !{i32 0, i32 116}
  %t552 = trunc i64 93 to i32
  %t553 = icmp eq i32 %t550, %t552
  %t555 = xor i1 %t553, true
  store i1 %t555, ptr %l275, !tbaa !21
  br label %bb199
bb198:
  store i1 false, ptr %l275, !tbaa !21
  br label %bb199
bb199:
  %t557 = load i1, ptr %l275, !tbaa !21
  br i1 %t557, label %bb200, label %bb201
bb200:
  %t558 = load i32, ptr %l4, !range !{i32 0, i32 116}
  %t560 = trunc i64 94 to i32
  %t561 = icmp eq i32 %t558, %t560
  %t563 = xor i1 %t561, true
  store i1 %t563, ptr %l279, !tbaa !21
  br label %bb202
bb201:
  store i1 false, ptr %l279, !tbaa !21
  br label %bb202
bb202:
  %t565 = load i1, ptr %l279, !tbaa !21
  br i1 %t565, label %bb203, label %bb204
bb203:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d31, i32 0, i32 1) }, ptr %l283, !tbaa !27
  %t566 = load { i64, ptr }, ptr %l283, !tbaa !27
  store { i64, ptr } %t566, ptr %rv
  br label %ret
bb204:
  br label %bb205
bb205:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, ptr %l284, !tbaa !27
  %t567 = load { i64, ptr }, ptr %l284, !tbaa !27
  store { i64, ptr } %t567, ptr %rv
  br label %ret
bb206:
  %t568 = load i32, ptr %l5, !range !{i32 0, i32 116}
  %t570 = trunc i64 112 to i32
  %t571 = icmp eq i32 %t568, %t570
  br i1 %t571, label %bb207, label %bb208
bb207:
  %t573 = load i32, ptr %l4, !range !{i32 0, i32 116}
  %t575 = trunc i64 115 to i32
  %t576 = icmp eq i32 %t573, %t575
  br i1 %t576, label %bb209, label %bb210
bb208:
  br label %bb229
bb209:
  %t578 = load ptr, ptr %l0, !tbaa !29
  %t579 = load i64, ptr %l2, !tbaa !24
  %t582 = call { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2easWritten(ptr %v0, ptr %v1, ptr %t578, i64 %t579)
  store { i64, ptr } %t582, ptr %l291
  br label %bb211
bb210:
  br label %bb212
bb211:
  %t583 = load { i64, ptr }, ptr %l291, !tbaa !27
  store { i64, ptr } %t583, ptr %rv
  br label %ret
bb212:
  %t584 = load ptr, ptr %l0, !tbaa !29
  %t585 = load i64, ptr %l1, !tbaa !24
  %t588 = call i1 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2eoperandEnd(ptr %v0, ptr %t584, i64 %t585)
  store i1 %t588, ptr %l294
  br label %bb213
bb213:
  %t589 = load i1, ptr %l294, !tbaa !21
  br i1 %t589, label %bb214, label %bb215
bb214:
  %t590 = load i32, ptr %l4, !range !{i32 0, i32 116}
  %t592 = trunc i64 93 to i32
  %t593 = icmp eq i32 %t590, %t592
  %t595 = xor i1 %t593, true
  store i1 %t595, ptr %l295, !tbaa !21
  br label %bb216
bb215:
  store i1 false, ptr %l295, !tbaa !21
  br label %bb216
bb216:
  %t597 = load i1, ptr %l295, !tbaa !21
  br i1 %t597, label %bb217, label %bb218
bb217:
  %t598 = load i32, ptr %l4, !range !{i32 0, i32 116}
  %t600 = trunc i64 94 to i32
  %t601 = icmp eq i32 %t598, %t600
  %t603 = xor i1 %t601, true
  store i1 %t603, ptr %l299, !tbaa !21
  br label %bb219
bb218:
  store i1 false, ptr %l299, !tbaa !21
  br label %bb219
bb219:
  %t605 = load i1, ptr %l299, !tbaa !21
  br i1 %t605, label %bb220, label %bb221
bb220:
  %t606 = load i32, ptr %l4, !range !{i32 0, i32 116}
  %t608 = trunc i64 2 to i32
  %t609 = icmp eq i32 %t606, %t608
  %t611 = xor i1 %t609, true
  store i1 %t611, ptr %l303, !tbaa !21
  br label %bb222
bb221:
  store i1 false, ptr %l303, !tbaa !21
  br label %bb222
bb222:
  %t613 = load i1, ptr %l303, !tbaa !21
  br i1 %t613, label %bb223, label %bb224
bb223:
  %t614 = load i32, ptr %l4, !range !{i32 0, i32 116}
  %t616 = trunc i64 3 to i32
  %t617 = icmp eq i32 %t614, %t616
  %t619 = xor i1 %t617, true
  store i1 %t619, ptr %l307, !tbaa !21
  br label %bb225
bb224:
  store i1 false, ptr %l307, !tbaa !21
  br label %bb225
bb225:
  %t621 = load i1, ptr %l307, !tbaa !21
  br i1 %t621, label %bb226, label %bb227
bb226:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d33, i32 0, i32 1) }, ptr %l311, !tbaa !27
  %t622 = load { i64, ptr }, ptr %l311, !tbaa !27
  store { i64, ptr } %t622, ptr %rv
  br label %ret
bb227:
  br label %bb228
bb228:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) }, ptr %l312, !tbaa !27
  %t623 = load { i64, ptr }, ptr %l312, !tbaa !27
  store { i64, ptr } %t623, ptr %rv
  br label %ret
bb229:
  %t624 = load ptr, ptr %l0, !tbaa !29
  %t626 = getelementptr %"compiler/fmt:formatter", ptr %t624, i32 0, i32 2
  %t627 = load { i64, ptr }, ptr %t626, !tbaa !27
  store { i64, ptr } %t627, ptr %l314, !tbaa !27
  %t628 = load i64, ptr %l2, !tbaa !24
  %t630 = getelementptr { i64, ptr }, ptr %l314, i32 0, i32 1
  %t631 = load ptr, ptr %t630, !tbaa !27
  %t632 = getelementptr i64, ptr %t631, i64 %t628
  %t633 = load i64, ptr %t632, !tbaa !34
  %t635 = icmp sgt i64 %t633, 0
  br i1 %t635, label %bb230, label %bb231
bb230:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d35, i32 0, i32 1) }, ptr %l318, !tbaa !27
  %t637 = load { i64, ptr }, ptr %l318, !tbaa !27
  store { i64, ptr } %t637, ptr %rv
  br label %ret
bb231:
  br label %bb232
bb232:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, ptr %l319, !tbaa !27
  %t638 = load { i64, ptr }, ptr %l319, !tbaa !27
  store { i64, ptr } %t638, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2etokText(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l8 = alloca i64
  %l10 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/fmt:formatter", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/fmt:formatter", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l5, !tbaa !27
  %t9 = load i64, ptr %l1, !tbaa !24
  %t11 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !27
  %t13 = getelementptr %"compiler/token:Token", ptr %t12, i64 %t9
  %t14 = getelementptr %"compiler/token:Token", ptr %t13, i32 0, i32 2
  %t15 = load i32, ptr %t14, !tbaa !23
  %t17 = sext i32 %t15 to i64
  store i64 %t17, ptr %l8, !tbaa !24
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/fmt:formatter", ptr %t18, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l10, !tbaa !27
  %t22 = load i64, ptr %l1, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr %"compiler/token:Token", ptr %t25, i64 %t22
  %t27 = getelementptr %"compiler/token:Token", ptr %t26, i32 0, i32 3
  %t28 = load i32, ptr %t27, !tbaa !23
  %t30 = sext i32 %t28 to i64
  store i64 %t30, ptr %l13, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l14, !tbaa !24
  %t33 = load i64, ptr %l8, !tbaa !24
  %t34 = icmp sge i64 %t33, 0
  br i1 %t34, label %bb1, label %bb2
bb1:
  %t36 = load i64, ptr %l8, !tbaa !24
  %t37 = load i64, ptr %l13, !tbaa !24
  %t38 = icmp sle i64 %t36, %t37
  br i1 %t38, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_bcfa8bcb194c4d3c_b6a77a733196e698)
  unreachable
bb3:
  %t40 = load i64, ptr %l13, !tbaa !24
  %t41 = load i64, ptr %l14, !tbaa !24
  %t42 = icmp sle i64 %t40, %t41
  br i1 %t42, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_bcfa8bcb194c4d3c_b6a77a733196e698)
  unreachable
bb5:
  %t44 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = load i64, ptr %l8, !tbaa !24
  %t47 = load i64, ptr %l13, !tbaa !24
  %t48 = getelementptr i8, ptr %t45, i64 %t46
  %t49 = sub i64 %t47, %t46
  %t50 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t48, 1
  store { i64, ptr } %t51, ptr %rv
  br label %ret
bb6:
  call void @__olang_check_failed(ptr @olang_loc_bcfa8bcb194c4d3c_b6a77a733196e698)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2etoken(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca { i64, ptr }
  %l8 = alloca i64
  %l14 = alloca i64
  %l19 = alloca i1
  %l30 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l45 = alloca i1
  %l47 = alloca { i64, ptr }
  %l53 = alloca i1
  %l54 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l58 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l67 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l74 = alloca i64
  %l75 = alloca i64
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/fmt:formatter", ptr %t1, i32 0, i32 8
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t4)
  store i64 %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load i64, ptr %l8, !tbaa !24
  store i64 %t8, ptr %l2, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/fmt:formatter", ptr %t9, i32 0, i32 21
  %t12 = load i1, ptr %t11, !tbaa !21
  %t14 = xor i1 %t12, true
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i64, ptr %l1, !tbaa !24
  %t20 = call i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2elevel(ptr %v0, ptr %t16, i64 %t17)
  store i64 %t20, ptr %l14
  br label %bb4
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/fmt:formatter", ptr %t21, i32 0, i32 29
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = icmp eq i64 %t24, 2
  br i1 %t26, label %bb11, label %bb12
bb4:
  %t28 = load i64, ptr %l14, !tbaa !24
  %t29 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ebegin(ptr %v0, ptr %t29, i64 %t28)
  br label %bb5
bb5:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i64, ptr %l2, !tbaa !24
  %t37 = call i1 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2eclosing(ptr %v0, ptr %t33, i64 %t34)
  store i1 %t37, ptr %l19
  br label %bb6
bb6:
  %t38 = load i1, ptr %l19, !tbaa !21
  br i1 %t38, label %bb7, label %bb8
bb7:
  %t39 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2edropBlank(ptr %v0, ptr %t39)
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  br label %bb20
bb11:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/fmt:formatter", ptr %t41, i32 0, i32 20
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t43, i8 32)
  br label %bb13
bb12:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/fmt:formatter", ptr %t45, i32 0, i32 29
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = icmp eq i64 %t48, 1
  br i1 %t50, label %bb14, label %bb15
bb13:
  br label %bb19
bb14:
  store %olang.scope zeroinitializer, ptr %s6
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/fmt:formatter", ptr %t52, i32 0, i32 20
  store ptr %t54, ptr %l30, !tbaa !29
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/fmt:formatter", ptr %t56, i32 0, i32 30
  %t59 = load i64, ptr %t58, !tbaa !24
  %t60 = load i64, ptr %l2, !tbaa !24
  %t61 = load i64, ptr %l1, !tbaa !24
  %t66 = call { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2espace(ptr %v0, ptr %s6, ptr %t55, i64 %t59, i64 %t60, i64 %t61)
  store { i64, ptr } %t66, ptr %l36
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t67 = load ptr, ptr %l30, !tbaa !29
  %t68 = load { i64, ptr }, ptr %l36, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s6, ptr %t67, { i64, ptr } %t68)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s6)
  br label %bb18
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i64, ptr %l2, !tbaa !24
  %t73 = call { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2etokText(ptr %v0, ptr %v0, ptr %t69, i64 %t70)
  store { i64, ptr } %t73, ptr %l39
  br label %bb21
bb21:
  %t74 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t74, ptr %l4, !tbaa !27
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/fmt:formatter", ptr %t75, i32 0, i32 4
  %t78 = load { i64, ptr }, ptr %t77, !tbaa !27
  store { i64, ptr } %t78, ptr %l41, !tbaa !27
  %t79 = load i64, ptr %l2, !tbaa !24
  %t81 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr i64, ptr %t82, i64 %t79
  %t84 = load i64, ptr %t83, !tbaa !34
  %t86 = icmp sgt i64 %t84, 0
  br i1 %t86, label %bb22, label %bb23
bb22:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/fmt:formatter", ptr %t88, i32 0, i32 4
  %t91 = load { i64, ptr }, ptr %t90, !tbaa !27
  store { i64, ptr } %t91, ptr %l47, !tbaa !27
  %t92 = load i64, ptr %l2, !tbaa !24
  %t94 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr i64, ptr %t95, i64 %t92
  %t97 = load i64, ptr %t96, !tbaa !34
  %t98 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t98, 0
  %t103 = icmp slt i64 %t97, %t100
  store i1 %t103, ptr %l45, !tbaa !21
  br label %bb24
bb23:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb24
bb24:
  %t105 = load i1, ptr %l45, !tbaa !21
  br i1 %t105, label %bb25, label %bb26
bb25:
  %t106 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t106, ptr %l54, !tbaa !27
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/fmt:formatter", ptr %t107, i32 0, i32 4
  %t110 = load { i64, ptr }, ptr %t109, !tbaa !27
  store { i64, ptr } %t110, ptr %l56, !tbaa !27
  %t111 = load i64, ptr %l2, !tbaa !24
  %t113 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr i64, ptr %t114, i64 %t111
  %t116 = load i64, ptr %t115, !tbaa !34
  store i64 %t116, ptr %l58, !tbaa !24
  %t117 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t117, 0
  store i64 %t120, ptr %l61, !tbaa !24
  %t121 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t121, 0
  store i64 %t122, ptr %l62, !tbaa !24
  %t123 = load i64, ptr %l58, !tbaa !24
  %t124 = icmp sge i64 %t123, 0
  br i1 %t124, label %bb27, label %bb28
bb26:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb34
bb27:
  %t126 = load i64, ptr %l58, !tbaa !24
  %t127 = load i64, ptr %l61, !tbaa !24
  %t128 = icmp sle i64 %t126, %t127
  br i1 %t128, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_c72ec7e8dfc94dc_53a73ed146206d80)
  unreachable
bb29:
  %t130 = load i64, ptr %l61, !tbaa !24
  %t131 = load i64, ptr %l62, !tbaa !24
  %t132 = icmp sle i64 %t130, %t131
  br i1 %t132, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_c72ec7e8dfc94dc_53a73ed146206d80)
  unreachable
bb31:
  %t134 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = load i64, ptr %l58, !tbaa !24
  %t137 = load i64, ptr %l61, !tbaa !24
  %t138 = getelementptr i8, ptr %t135, i64 %t136
  %t139 = sub i64 %t137, %t136
  %t140 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t138, 1
  %t143 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t141, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) })
  store i1 %t143, ptr %l67
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_c72ec7e8dfc94dc_53a73ed146206d80)
  unreachable
bb33:
  %t144 = load i1, ptr %l67, !tbaa !21
  store i1 %t144, ptr %l53, !tbaa !21
  br label %bb34
bb34:
  %t145 = load i1, ptr %l53, !tbaa !21
  br i1 %t145, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s7
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/fmt:formatter", ptr %t146, i32 0, i32 20
  store ptr %t148, ptr %l69, !tbaa !29
  %t149 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t149, ptr %l70, !tbaa !27
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/fmt:formatter", ptr %t150, i32 0, i32 4
  %t153 = load { i64, ptr }, ptr %t152, !tbaa !27
  store { i64, ptr } %t153, ptr %l72, !tbaa !27
  %t154 = load i64, ptr %l2, !tbaa !24
  %t156 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !27
  %t158 = getelementptr i64, ptr %t157, i64 %t154
  %t159 = load i64, ptr %t158, !tbaa !34
  store i64 %t159, ptr %l74, !tbaa !24
  %t160 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t161 = extractvalue { i64, ptr } %t160, 0
  store i64 %t161, ptr %l75, !tbaa !24
  %t162 = icmp sge i64 0, 0
  br i1 %t162, label %bb37, label %bb38
bb36:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/fmt:formatter", ptr %t164, i32 0, i32 20
  %t167 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v0, ptr %t166, { i64, ptr } %t167)
  br label %bb45
bb37:
  %t170 = load i64, ptr %l74, !tbaa !24
  %t171 = icmp sle i64 0, %t170
  br i1 %t171, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_8b20359aae87aa49_981ed0beb1f6b3dd)
  unreachable
bb39:
  %t173 = load i64, ptr %l74, !tbaa !24
  %t174 = load i64, ptr %l75, !tbaa !24
  %t175 = icmp sle i64 %t173, %t174
  br i1 %t175, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_8b20359aae87aa49_981ed0beb1f6b3dd)
  unreachable
bb41:
  %t177 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = load i64, ptr %l74, !tbaa !24
  %t180 = getelementptr i8, ptr %t178, i64 0
  %t181 = sub i64 %t179, 0
  %t182 = insertvalue { i64, ptr } undef, i64 %t181, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t180, 1
  %t184 = load ptr, ptr %l69, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v0, ptr %t184, { i64, ptr } %t183)
  br label %bb43
bb42:
  call void @__olang_check_failed(ptr @olang_loc_8b20359aae87aa49_981ed0beb1f6b3dd)
  unreachable
bb43:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t188 = getelementptr %"compiler/fmt:formatter", ptr %t186, i32 0, i32 20
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s7, ptr %t188, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d38, i32 0, i32 1) })
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s7)
  br label %bb46
bb45:
  br label %bb46
bb46:
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t192 = getelementptr %"compiler/fmt:formatter", ptr %t190, i32 0, i32 29
  store i64 1, ptr %t192, !tbaa !24
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load i64, ptr %l2, !tbaa !24
  %t197 = getelementptr %"compiler/fmt:formatter", ptr %t193, i32 0, i32 30
  store i64 %t194, ptr %t197, !tbaa !24
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t199 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2etrack(ptr %v0, ptr %t198, i64 %t199)
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2etrack(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l20 = alloca i32
  %l22 = alloca { i64, ptr }
  %l26 = alloca i1
  %l31 = alloca i64
  %l34 = alloca i64
  %l54 = alloca i64
  %l76 = alloca i64
  %l79 = alloca i1
  %l84 = alloca i64
  %l100 = alloca i1
  %l110 = alloca { i64, ptr }
  %l116 = alloca i64
  %l119 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %t1, i64 %t2)
  store i32 %t5, ptr %l20
  br label %bb1
bb1:
  %t6 = load i32, ptr %l20, !range !{i32 0, i32 116}
  store i32 %t6, ptr %l2
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/fmt:formatter", ptr %t7, i32 0, i32 4
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  store { i64, ptr } %t10, ptr %l22, !tbaa !27
  %t11 = load i64, ptr %l1, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr i64, ptr %t14, i64 %t11
  %t16 = load i64, ptr %t15, !tbaa !34
  store i64 %t16, ptr %l3, !tbaa !24
  %t18 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t20 = call i1 @compiler_2ffmt_2eisCloser(i32 %t18)
  store i1 %t20, ptr %l26
  br label %bb2
bb2:
  %t21 = load i1, ptr %l26, !tbaa !21
  br i1 %t21, label %bb3, label %bb4
bb3:
  store i64 1, ptr %l3, !tbaa !24
  br label %bb5
bb4:
  br label %bb5
bb5:
  store i64 0, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l3, !tbaa !24
  store i64 %t22, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l5, !tbaa !24
  %t25 = load i64, ptr %l4, !tbaa !24
  %t28 = icmp sgt i64 %t24, %t25
  br i1 %t28, label %bb6, label %bb7
bb6:
  %t30 = load i64, ptr %l6, !tbaa !24
  %t32 = icmp sgt i64 %t30, 0
  br i1 %t32, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb11
bb8:
  %t34 = load i64, ptr %l5, !tbaa !24
  %t35 = load i64, ptr %l4, !tbaa !24
  %t38 = sub i64 %t34, %t35
  %t39 = load i64, ptr %l6, !tbaa !24
  %t42 = add i64 %t38, %t39
  %t44 = sub i64 %t42, 1
  %t45 = load i64, ptr %l6, !tbaa !24
  %t48 = sdiv i64 %t44, %t45
  store i64 %t48, ptr %l34, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb10
bb10:
  %t50 = load i64, ptr %l34, !tbaa !24
  store i64 %t50, ptr %l31, !tbaa !24
  br label %bb11
bb11:
  %t51 = load i64, ptr %l31, !tbaa !24
  store i64 %t51, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb12
bb12:
  %t52 = load i64, ptr %l8, !tbaa !24
  %t53 = load i64, ptr %l7, !tbaa !24
  %t56 = icmp slt i64 %t52, %t53
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb13, label %bb14
bb13:
  br label %bb24
bb14:
  br label %bb15
bb15:
  %t60 = load i64, ptr %l4, !tbaa !24
  %t61 = load i64, ptr %l8, !tbaa !24
  %t62 = load i64, ptr %l6, !tbaa !24
  %t65 = mul i64 %t61, %t62
  %t68 = add i64 %t60, %t65
  store i64 %t68, ptr %l9, !tbaa !24
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/fmt:formatter", ptr %t70, i32 0, i32 10
  %t74 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t72)
  store i64 %t74, ptr %l54
  br label %bb16
bb16:
  %t75 = load i64, ptr %l54, !tbaa !24
  store i64 %t75, ptr %l10, !tbaa !24
  %t76 = load i64, ptr %l10, !tbaa !24
  %t78 = icmp sgt i64 %t76, 0
  br i1 %t78, label %bb17, label %bb18
bb17:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/fmt:formatter", ptr %t80, i32 0, i32 10
  %t83 = load i64, ptr %l10, !tbaa !24
  %t85 = sub i64 %t83, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t82, i64 %t85)
  br label %bb19
bb18:
  br label %bb22
bb19:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/fmt:formatter", ptr %t88, i32 0, i32 11
  %t91 = load i64, ptr %l10, !tbaa !24
  %t93 = sub i64 %t91, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t90, i64 %t93)
  br label %bb20
bb20:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/fmt:formatter", ptr %t96, i32 0, i32 12
  %t99 = load i64, ptr %l10, !tbaa !24
  %t101 = sub i64 %t99, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t98, i64 %t101)
  br label %bb21
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t104 = load i64, ptr %l8, !tbaa !24
  %t107 = add i64 %t104, 1
  store i64 %t107, ptr %l8, !tbaa !24
  br label %bb12
bb24:
  %t109 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t111 = trunc i64 114 to i32
  %t112 = icmp eq i32 %t109, %t111
  br i1 %t112, label %bb25, label %bb26
bb25:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/fmt:formatter", ptr %t114, i32 0, i32 10
  %t118 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t116)
  store i64 %t118, ptr %l76
  br label %bb27
bb26:
  %t119 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t121 = trunc i64 110 to i32
  %t122 = icmp eq i32 %t119, %t121
  br i1 %t122, label %bb37, label %bb38
bb27:
  %t124 = load i64, ptr %l76, !tbaa !24
  store i64 %t124, ptr %l11, !tbaa !24
  %t125 = load i64, ptr %l11, !tbaa !24
  %t127 = icmp eq i64 %t125, 0
  br i1 %t127, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l79, !tbaa !21
  br label %bb31
bb29:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/fmt:formatter", ptr %t129, i32 0, i32 10
  %t132 = load i64, ptr %l11, !tbaa !24
  %t134 = sub i64 %t132, 1
  %t137 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t131, i64 %t134)
  store i64 %t137, ptr %l84
  br label %bb30
bb30:
  %t138 = load i64, ptr %l84, !tbaa !24
  %t139 = icmp eq i64 %t138, 0
  store i1 %t139, ptr %l79, !tbaa !21
  br label %bb31
bb31:
  %t141 = load i1, ptr %l79, !tbaa !21
  br i1 %t141, label %bb32, label %bb33
bb32:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/fmt:formatter", ptr %t143, i32 0, i32 23
  %t146 = load i64, ptr %t145, !tbaa !24
  %t148 = add i64 %t146, 1
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/fmt:formatter", ptr %t149, i32 0, i32 23
  %t152 = load i64, ptr %t151, !tbaa !24
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2epush(ptr %v0, ptr %t142, i64 0, i64 %t148, i64 %t152)
  br label %bb34
bb33:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/fmt:formatter", ptr %t157, i32 0, i32 22
  %t160 = load i64, ptr %t159, !tbaa !24
  %t162 = add i64 %t160, 1
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/fmt:formatter", ptr %t163, i32 0, i32 22
  %t166 = load i64, ptr %t165, !tbaa !24
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2epush(ptr %v0, ptr %t156, i64 0, i64 %t162, i64 %t166)
  br label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb36
bb36:
  br label %bb57
bb37:
  store i1 true, ptr %l100, !tbaa !21
  br label %bb39
bb38:
  %t170 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t172 = trunc i64 112 to i32
  %t173 = icmp eq i32 %t170, %t172
  store i1 %t173, ptr %l100, !tbaa !21
  br label %bb39
bb39:
  %t175 = load i1, ptr %l100, !tbaa !21
  br i1 %t175, label %bb40, label %bb41
bb40:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/fmt:formatter", ptr %t177, i32 0, i32 22
  %t180 = load i64, ptr %t179, !tbaa !24
  %t182 = add i64 %t180, 1
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/fmt:formatter", ptr %t183, i32 0, i32 22
  %t186 = load i64, ptr %t185, !tbaa !24
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2epush(ptr %v0, ptr %t176, i64 1, i64 %t182, i64 %t186)
  br label %bb42
bb41:
  store i64 0, ptr %l12, !tbaa !24
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t192 = getelementptr %"compiler/fmt:formatter", ptr %t190, i32 0, i32 2
  %t193 = load { i64, ptr }, ptr %t192, !tbaa !27
  store { i64, ptr } %t193, ptr %l110, !tbaa !27
  %t194 = load i64, ptr %l1, !tbaa !24
  %t196 = getelementptr { i64, ptr }, ptr %l110, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !27
  %t198 = getelementptr i64, ptr %t197, i64 %t194
  %t199 = load i64, ptr %t198, !tbaa !34
  store i64 %t199, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t201 = load i64, ptr %l13, !tbaa !24
  %t202 = load i64, ptr %l12, !tbaa !24
  %t205 = icmp sgt i64 %t201, %t202
  br i1 %t205, label %bb43, label %bb44
bb42:
  br label %bb56
bb43:
  %t207 = load i64, ptr %l14, !tbaa !24
  %t209 = icmp sgt i64 %t207, 0
  br i1 %t209, label %bb45, label %bb46
bb44:
  store i64 0, ptr %l116, !tbaa !24
  br label %bb48
bb45:
  %t211 = load i64, ptr %l13, !tbaa !24
  %t212 = load i64, ptr %l12, !tbaa !24
  %t215 = sub i64 %t211, %t212
  %t216 = load i64, ptr %l14, !tbaa !24
  %t219 = add i64 %t215, %t216
  %t221 = sub i64 %t219, 1
  %t222 = load i64, ptr %l14, !tbaa !24
  %t225 = sdiv i64 %t221, %t222
  store i64 %t225, ptr %l119, !tbaa !24
  br label %bb47
bb46:
  store i64 0, ptr %l119, !tbaa !24
  br label %bb47
bb47:
  %t227 = load i64, ptr %l119, !tbaa !24
  store i64 %t227, ptr %l116, !tbaa !24
  br label %bb48
bb48:
  %t228 = load i64, ptr %l116, !tbaa !24
  store i64 %t228, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb49
bb49:
  %t229 = load i64, ptr %l16, !tbaa !24
  %t230 = load i64, ptr %l15, !tbaa !24
  %t233 = icmp slt i64 %t229, %t230
  %t235 = xor i1 %t233, true
  br i1 %t235, label %bb50, label %bb51
bb50:
  br label %bb55
bb51:
  br label %bb52
bb52:
  %t237 = load i64, ptr %l12, !tbaa !24
  %t238 = load i64, ptr %l16, !tbaa !24
  %t239 = load i64, ptr %l14, !tbaa !24
  %t242 = mul i64 %t238, %t239
  %t245 = add i64 %t237, %t242
  store i64 %t245, ptr %l17, !tbaa !24
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t250 = getelementptr %"compiler/fmt:formatter", ptr %t248, i32 0, i32 22
  %t251 = load i64, ptr %t250, !tbaa !24
  %t253 = add i64 %t251, 1
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = getelementptr %"compiler/fmt:formatter", ptr %t254, i32 0, i32 22
  %t257 = load i64, ptr %t256, !tbaa !24
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2epush(ptr %v0, ptr %t247, i64 1, i64 %t253, i64 %t257)
  br label %bb53
bb53:
  br label %bb54
bb54:
  %t261 = load i64, ptr %l16, !tbaa !24
  %t264 = add i64 %t261, 1
  store i64 %t264, ptr %l16, !tbaa !24
  br label %bb49
bb55:
  br label %bb56
bb56:
  br label %bb57
bb57:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ewrite(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca %"std/prelude/text:StringBuilder"
  %l20 = alloca i64
  %l23 = alloca i1
  %l28 = alloca i64
  %l42 = alloca i1
  %l46 = alloca i64
  %l48 = alloca i1
  %l52 = alloca i64
  %l54 = alloca i1
  %l58 = alloca i64
  %l62 = alloca i64
  %l64 = alloca i1
  %l68 = alloca i1
  %l74 = alloca i64
  %l75 = alloca i64
  %l79 = alloca i64
  %l83 = alloca i64
  %l84 = alloca i64
  %l89 = alloca i64
  %l108 = alloca i64
  %l111 = alloca i64
  %l139 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/fmt:formatter", ptr %t1, i32 0, i32 20
  %t5 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %s0, ptr %t3)
  store { i64, ptr } %t5, ptr %l16
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t6, ptr %l1, !tbaa !27
  %t7 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t7, ptr %l17
  br label %bb2
bb2:
  %t8 = load %"std/prelude/text:StringBuilder", ptr %l17
  store %"std/prelude/text:StringBuilder" %t8, ptr %l2
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/fmt:formatter", ptr %t9, i32 0, i32 13
  %t13 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t11)
  store i64 %t13, ptr %l20
  br label %bb3
bb3:
  %t14 = load i64, ptr %l20, !tbaa !24
  store i64 %t14, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb5, label %bb6
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/fmt:formatter", ptr %t19, i32 0, i32 13
  %t22 = load i64, ptr %l3, !tbaa !24
  %t24 = sub i64 %t22, 1
  %t27 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t21, i64 %t24)
  store i64 %t27, ptr %l28
  br label %bb7
bb6:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb8
bb7:
  %t28 = load i64, ptr %l28, !tbaa !24
  %t29 = icmp eq i64 %t28, 1
  store i1 %t29, ptr %l23, !tbaa !21
  br label %bb8
bb8:
  %t31 = load i1, ptr %l23, !tbaa !21
  %t32 = xor i1 %t31, true
  br i1 %t32, label %bb9, label %bb10
bb9:
  br label %bb13
bb10:
  br label %bb11
bb11:
  %t34 = load i64, ptr %l3, !tbaa !24
  %t37 = sub i64 %t34, 1
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb12
bb12:
  br label %bb4
bb13:
  store i64 0, ptr %l4, !tbaa !24
  br label %bb14
bb14:
  %t39 = load i64, ptr %l4, !tbaa !24
  %t40 = load i64, ptr %l3, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb15, label %bb16
bb15:
  br label %bb71
bb16:
  br label %bb17
bb17:
  %t47 = load i64, ptr %l4, !tbaa !24
  store i64 %t47, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb18
bb18:
  %t49 = load i64, ptr %l5, !tbaa !24
  %t50 = load i64, ptr %l3, !tbaa !24
  %t53 = icmp slt i64 %t49, %t50
  br i1 %t53, label %bb19, label %bb20
bb19:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/fmt:formatter", ptr %t55, i32 0, i32 13
  %t58 = load i64, ptr %l5, !tbaa !24
  %t61 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t57, i64 %t58)
  store i64 %t61, ptr %l46
  br label %bb21
bb20:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb22
bb21:
  %t62 = load i64, ptr %l46, !tbaa !24
  %t63 = icmp eq i64 %t62, 0
  store i1 %t63, ptr %l42, !tbaa !21
  br label %bb22
bb22:
  %t65 = load i1, ptr %l42, !tbaa !21
  br i1 %t65, label %bb23, label %bb24
bb23:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/fmt:formatter", ptr %t66, i32 0, i32 17
  %t69 = load i64, ptr %l5, !tbaa !24
  %t72 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t68, i64 %t69)
  store i64 %t72, ptr %l52
  br label %bb25
bb24:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb26
bb25:
  %t73 = load i64, ptr %l52, !tbaa !24
  %t74 = icmp sge i64 %t73, 0
  store i1 %t74, ptr %l48, !tbaa !21
  br label %bb26
bb26:
  %t76 = load i1, ptr %l48, !tbaa !21
  br i1 %t76, label %bb27, label %bb28
bb27:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/fmt:formatter", ptr %t77, i32 0, i32 16
  %t80 = load i64, ptr %l5, !tbaa !24
  %t83 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t79, i64 %t80)
  store i64 %t83, ptr %l58
  br label %bb29
bb28:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb31
bb29:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/fmt:formatter", ptr %t84, i32 0, i32 15
  %t87 = load i64, ptr %l5, !tbaa !24
  %t90 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t86, i64 %t87)
  store i64 %t90, ptr %l62
  br label %bb30
bb30:
  %t91 = load i64, ptr %l58, !tbaa !24
  %t92 = load i64, ptr %l62, !tbaa !24
  %t93 = icmp sgt i64 %t91, %t92
  store i1 %t93, ptr %l54, !tbaa !21
  br label %bb31
bb31:
  %t95 = load i1, ptr %l54, !tbaa !21
  br i1 %t95, label %bb32, label %bb33
bb32:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/fmt:formatter", ptr %t96, i32 0, i32 19
  %t99 = load i64, ptr %l5, !tbaa !24
  %t102 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t98, i64 %t99)
  store i1 %t102, ptr %l68
  br label %bb34
bb33:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb35
bb34:
  %t103 = load i1, ptr %l68, !tbaa !21
  %t104 = xor i1 %t103, true
  store i1 %t104, ptr %l64, !tbaa !21
  br label %bb35
bb35:
  %t106 = load i1, ptr %l64, !tbaa !21
  %t107 = xor i1 %t106, true
  br i1 %t107, label %bb36, label %bb37
bb36:
  br label %bb53
bb37:
  br label %bb38
bb38:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/fmt:formatter", ptr %t109, i32 0, i32 14
  %t112 = load i64, ptr %l5, !tbaa !24
  %t115 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t111, i64 %t112)
  store i64 %t115, ptr %l74
  br label %bb39
bb39:
  %t116 = load i64, ptr %l74, !tbaa !24
  %t117 = mul i64 %t116, 4
  store i64 %t117, ptr %l75, !tbaa !24
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/fmt:formatter", ptr %t118, i32 0, i32 15
  %t121 = load i64, ptr %l5, !tbaa !24
  %t124 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t120, i64 %t121)
  store i64 %t124, ptr %l79
  br label %bb40
bb40:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/fmt:formatter", ptr %t125, i32 0, i32 16
  %t128 = load i64, ptr %l5, !tbaa !24
  %t131 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t127, i64 %t128)
  store i64 %t131, ptr %l83
  br label %bb41
bb41:
  %t132 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t132, 0
  store i64 %t133, ptr %l84, !tbaa !24
  %t134 = load i64, ptr %l79, !tbaa !24
  %t135 = icmp sge i64 %t134, 0
  br i1 %t135, label %bb42, label %bb43
bb42:
  %t137 = load i64, ptr %l79, !tbaa !24
  %t138 = load i64, ptr %l83, !tbaa !24
  %t139 = icmp sle i64 %t137, %t138
  br i1 %t139, label %bb44, label %bb45
bb43:
  call void @__olang_check_failed(ptr @olang_loc_66958b60b9b09f2a_a21c6753724927b6)
  unreachable
bb44:
  %t141 = load i64, ptr %l83, !tbaa !24
  %t142 = load i64, ptr %l84, !tbaa !24
  %t143 = icmp sle i64 %t141, %t142
  br i1 %t143, label %bb46, label %bb47
bb45:
  call void @__olang_check_failed(ptr @olang_loc_66958b60b9b09f2a_a21c6753724927b6)
  unreachable
bb46:
  %t145 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = load i64, ptr %l79, !tbaa !24
  %t148 = load i64, ptr %l83, !tbaa !24
  %t149 = getelementptr i8, ptr %t146, i64 %t147
  %t150 = sub i64 %t148, %t147
  %t151 = insertvalue { i64, ptr } undef, i64 %t150, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr %t149, 1
  %t154 = call i64 @compiler_2ffmt_2ewidth(ptr %s0, { i64, ptr } %t152)
  store i64 %t154, ptr %l89
  br label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_66958b60b9b09f2a_a21c6753724927b6)
  unreachable
bb48:
  %t155 = load i64, ptr %l75, !tbaa !24
  %t156 = load i64, ptr %l89, !tbaa !24
  %t157 = add i64 %t155, %t156
  store i64 %t157, ptr %l7, !tbaa !24
  %t159 = load i64, ptr %l7, !tbaa !24
  %t160 = load i64, ptr %l6, !tbaa !24
  %t163 = icmp sgt i64 %t159, %t160
  br i1 %t163, label %bb49, label %bb50
bb49:
  %t165 = load i64, ptr %l7, !tbaa !24
  store i64 %t165, ptr %l6, !tbaa !24
  br label %bb51
bb50:
  br label %bb51
bb51:
  %t167 = load i64, ptr %l5, !tbaa !24
  %t170 = add i64 %t167, 1
  store i64 %t170, ptr %l5, !tbaa !24
  br label %bb52
bb52:
  br label %bb18
bb53:
  %t172 = load i64, ptr %l5, !tbaa !24
  %t173 = load i64, ptr %l4, !tbaa !24
  %t176 = icmp eq i64 %t172, %t173
  br i1 %t176, label %bb54, label %bb55
bb54:
  %t178 = load i64, ptr %l4, !tbaa !24
  %t180 = add i64 %t178, 1
  store i64 %t180, ptr %l5, !tbaa !24
  br label %bb56
bb55:
  br label %bb56
bb56:
  %t182 = load i64, ptr %l4, !tbaa !24
  store i64 %t182, ptr %l8, !tbaa !24
  %t184 = load i64, ptr %l5, !tbaa !24
  store i64 %t184, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t186 = load i64, ptr %l9, !tbaa !24
  %t187 = load i64, ptr %l8, !tbaa !24
  %t190 = icmp sgt i64 %t186, %t187
  br i1 %t190, label %bb57, label %bb58
bb57:
  %t192 = load i64, ptr %l10, !tbaa !24
  %t194 = icmp sgt i64 %t192, 0
  br i1 %t194, label %bb59, label %bb60
bb58:
  store i64 0, ptr %l108, !tbaa !24
  br label %bb62
bb59:
  %t196 = load i64, ptr %l9, !tbaa !24
  %t197 = load i64, ptr %l8, !tbaa !24
  %t200 = sub i64 %t196, %t197
  %t201 = load i64, ptr %l10, !tbaa !24
  %t204 = add i64 %t200, %t201
  %t206 = sub i64 %t204, 1
  %t207 = load i64, ptr %l10, !tbaa !24
  %t210 = sdiv i64 %t206, %t207
  store i64 %t210, ptr %l111, !tbaa !24
  br label %bb61
bb60:
  store i64 0, ptr %l111, !tbaa !24
  br label %bb61
bb61:
  %t212 = load i64, ptr %l111, !tbaa !24
  store i64 %t212, ptr %l108, !tbaa !24
  br label %bb62
bb62:
  %t213 = load i64, ptr %l108, !tbaa !24
  store i64 %t213, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb63
bb63:
  %t214 = load i64, ptr %l12, !tbaa !24
  %t215 = load i64, ptr %l11, !tbaa !24
  %t218 = icmp slt i64 %t214, %t215
  %t220 = xor i1 %t218, true
  br i1 %t220, label %bb64, label %bb65
bb64:
  br label %bb69
bb65:
  br label %bb66
bb66:
  %t222 = load i64, ptr %l8, !tbaa !24
  %t223 = load i64, ptr %l12, !tbaa !24
  %t224 = load i64, ptr %l10, !tbaa !24
  %t227 = mul i64 %t223, %t224
  %t230 = add i64 %t222, %t227
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t235 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ewriteLine(ptr %v0, ptr %s0, ptr %s0, ptr %t232, ptr %l2, { i64, ptr } %t233, i64 %t230, i64 %t235)
  br label %bb67
bb67:
  br label %bb68
bb68:
  %t241 = load i64, ptr %l12, !tbaa !24
  %t244 = add i64 %t241, 1
  store i64 %t244, ptr %l12, !tbaa !24
  br label %bb63
bb69:
  %t246 = load i64, ptr %l5, !tbaa !24
  store i64 %t246, ptr %l4, !tbaa !24
  br label %bb70
bb70:
  br label %bb14
bb71:
  %t249 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t249, ptr %l139
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s0)
  %t250 = load { i64, ptr }, ptr %l139, !tbaa !27
  store { i64, ptr } %t250, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ewriteLine(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l23 = alloca i64
  %l26 = alloca { i64, ptr }
  %l30 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l43 = alloca i1
  %l47 = alloca i64
  %l52 = alloca i64
  %l56 = alloca i64
  %l59 = alloca i64
  %l86 = alloca i64
  %l94 = alloca i64
  %l95 = alloca i64
  %l97 = alloca i64
  %l101 = alloca i64
  %l110 = alloca i64
  %l113 = alloca i64
  %l135 = alloca ptr
  %l137 = alloca { i64, ptr }
  %l141 = alloca i64
  %l145 = alloca i64
  %l146 = alloca i64
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/fmt:formatter", ptr %t1, i32 0, i32 13
  %t4 = load i64, ptr %l3, !tbaa !24
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t4)
  store i64 %t7, ptr %l23
  br label %bb1
bb1:
  %t8 = load i64, ptr %l23, !tbaa !24
  %t9 = icmp ne i64 %t8, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t11, i8 10)
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %ret
bb5:
  store { i64, ptr } %a2, ptr %l26, !tbaa !27
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/fmt:formatter", ptr %t14, i32 0, i32 15
  %t17 = load i64, ptr %l3, !tbaa !24
  %t20 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t16, i64 %t17)
  store i64 %t20, ptr %l30
  br label %bb6
bb6:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/fmt:formatter", ptr %t21, i32 0, i32 16
  %t24 = load i64, ptr %l3, !tbaa !24
  %t27 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t23, i64 %t24)
  store i64 %t27, ptr %l34
  br label %bb7
bb7:
  %t28 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  store i64 %t29, ptr %l35, !tbaa !24
  %t30 = load i64, ptr %l30, !tbaa !24
  %t31 = icmp sge i64 %t30, 0
  br i1 %t31, label %bb8, label %bb9
bb8:
  %t33 = load i64, ptr %l30, !tbaa !24
  %t34 = load i64, ptr %l34, !tbaa !24
  %t35 = icmp sle i64 %t33, %t34
  br i1 %t35, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_1f023a932aff5454_c8fa03de0f87b198)
  unreachable
bb10:
  %t37 = load i64, ptr %l34, !tbaa !24
  %t38 = load i64, ptr %l35, !tbaa !24
  %t39 = icmp sle i64 %t37, %t38
  br i1 %t39, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_1f023a932aff5454_c8fa03de0f87b198)
  unreachable
bb12:
  %t41 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = load i64, ptr %l30, !tbaa !24
  %t44 = load i64, ptr %l34, !tbaa !24
  %t45 = getelementptr i8, ptr %t42, i64 %t43
  %t46 = sub i64 %t44, %t43
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l5, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t50, 0
  %t54 = icmp sgt i64 %t52, 0
  br i1 %t54, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_1f023a932aff5454_c8fa03de0f87b198)
  unreachable
bb14:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb17
bb15:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/fmt:formatter", ptr %t56, i32 0, i32 17
  %t59 = load i64, ptr %l3, !tbaa !24
  %t62 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t58, i64 %t59)
  store i64 %t62, ptr %l47
  br label %bb16
bb16:
  %t63 = load i64, ptr %l47, !tbaa !24
  %t64 = icmp sge i64 %t63, 0
  store i1 %t64, ptr %l43, !tbaa !21
  br label %bb17
bb17:
  %t66 = load i1, ptr %l43, !tbaa !21
  br i1 %t66, label %bb18, label %bb19
bb18:
  store i64 0, ptr %l6, !tbaa !24
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/fmt:formatter", ptr %t67, i32 0, i32 14
  %t70 = load i64, ptr %l3, !tbaa !24
  %t73 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t69, i64 %t70)
  store i64 %t73, ptr %l52
  br label %bb20
bb19:
  br label %bb34
bb20:
  %t74 = load i64, ptr %l52, !tbaa !24
  store i64 %t74, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t75 = load i64, ptr %l7, !tbaa !24
  %t76 = load i64, ptr %l6, !tbaa !24
  %t79 = icmp sgt i64 %t75, %t76
  br i1 %t79, label %bb21, label %bb22
bb21:
  %t81 = load i64, ptr %l8, !tbaa !24
  %t83 = icmp sgt i64 %t81, 0
  br i1 %t83, label %bb23, label %bb24
bb22:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb26
bb23:
  %t85 = load i64, ptr %l7, !tbaa !24
  %t86 = load i64, ptr %l6, !tbaa !24
  %t89 = sub i64 %t85, %t86
  %t90 = load i64, ptr %l8, !tbaa !24
  %t93 = add i64 %t89, %t90
  %t95 = sub i64 %t93, 1
  %t96 = load i64, ptr %l8, !tbaa !24
  %t99 = sdiv i64 %t95, %t96
  store i64 %t99, ptr %l59, !tbaa !24
  br label %bb25
bb24:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb25
bb25:
  %t101 = load i64, ptr %l59, !tbaa !24
  store i64 %t101, ptr %l56, !tbaa !24
  br label %bb26
bb26:
  %t102 = load i64, ptr %l56, !tbaa !24
  store i64 %t102, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s4
  %t103 = load i64, ptr %l10, !tbaa !24
  %t104 = load i64, ptr %l9, !tbaa !24
  %t107 = icmp slt i64 %t103, %t104
  %t109 = xor i1 %t107, true
  br i1 %t109, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s4)
  br label %bb33
bb29:
  br label %bb30
bb30:
  %t111 = load i64, ptr %l6, !tbaa !24
  %t112 = load i64, ptr %l10, !tbaa !24
  %t113 = load i64, ptr %l8, !tbaa !24
  %t116 = mul i64 %t112, %t113
  %t119 = add i64 %t111, %t116
  store i64 %t119, ptr %l11, !tbaa !24
  %t121 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s4, ptr %t121, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d39, i32 0, i32 1) })
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s4)
  br label %bb32
bb32:
  %t123 = load i64, ptr %l10, !tbaa !24
  %t126 = add i64 %t123, 1
  store i64 %t126, ptr %l10, !tbaa !24
  br label %bb27
bb33:
  br label %bb34
bb34:
  %t128 = load ptr, ptr %l1, !tbaa !29
  %t129 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %v2, ptr %t128, { i64, ptr } %t129)
  br label %bb35
bb35:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/fmt:formatter", ptr %t132, i32 0, i32 17
  %t135 = load i64, ptr %l3, !tbaa !24
  %t138 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t134, i64 %t135)
  store i64 %t138, ptr %l86
  br label %bb36
bb36:
  %t139 = load i64, ptr %l86, !tbaa !24
  %t140 = icmp sge i64 %t139, 0
  br i1 %t140, label %bb37, label %bb38
bb37:
  %t142 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t144 = extractvalue { i64, ptr } %t142, 0
  %t146 = icmp sgt i64 %t144, 0
  br i1 %t146, label %bb39, label %bb40
bb38:
  br label %bb69
bb39:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/fmt:formatter", ptr %t148, i32 0, i32 14
  %t151 = load i64, ptr %l3, !tbaa !24
  %t154 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t150, i64 %t151)
  store i64 %t154, ptr %l94
  br label %bb41
bb40:
  br label %bb59
bb41:
  %t155 = load i64, ptr %l94, !tbaa !24
  %t156 = mul i64 %t155, 4
  store i64 %t156, ptr %l95, !tbaa !24
  %t157 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t159 = call i64 @compiler_2ffmt_2ewidth(ptr %v2, { i64, ptr } %t157)
  store i64 %t159, ptr %l97
  br label %bb42
bb42:
  %t160 = load i64, ptr %l95, !tbaa !24
  %t161 = load i64, ptr %l97, !tbaa !24
  %t162 = add i64 %t160, %t161
  store i64 %t162, ptr %l12, !tbaa !24
  %t164 = load i64, ptr %l4, !tbaa !24
  %t166 = icmp sgt i64 %t164, 0
  br i1 %t166, label %bb43, label %bb44
bb43:
  %t168 = load i64, ptr %l4, !tbaa !24
  %t169 = load i64, ptr %l12, !tbaa !24
  %t172 = sub i64 %t168, %t169
  %t174 = add i64 %t172, 1
  store i64 %t174, ptr %l101, !tbaa !24
  br label %bb45
bb44:
  store i64 1, ptr %l101, !tbaa !24
  br label %bb45
bb45:
  %t176 = load i64, ptr %l101, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  store i64 %t176, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t179 = load i64, ptr %l15, !tbaa !24
  %t180 = load i64, ptr %l14, !tbaa !24
  %t183 = icmp sgt i64 %t179, %t180
  br i1 %t183, label %bb46, label %bb47
bb46:
  %t185 = load i64, ptr %l16, !tbaa !24
  %t187 = icmp sgt i64 %t185, 0
  br i1 %t187, label %bb48, label %bb49
bb47:
  store i64 0, ptr %l110, !tbaa !24
  br label %bb51
bb48:
  %t189 = load i64, ptr %l15, !tbaa !24
  %t190 = load i64, ptr %l14, !tbaa !24
  %t193 = sub i64 %t189, %t190
  %t194 = load i64, ptr %l16, !tbaa !24
  %t197 = add i64 %t193, %t194
  %t199 = sub i64 %t197, 1
  %t200 = load i64, ptr %l16, !tbaa !24
  %t203 = sdiv i64 %t199, %t200
  store i64 %t203, ptr %l113, !tbaa !24
  br label %bb50
bb49:
  store i64 0, ptr %l113, !tbaa !24
  br label %bb50
bb50:
  %t205 = load i64, ptr %l113, !tbaa !24
  store i64 %t205, ptr %l110, !tbaa !24
  br label %bb51
bb51:
  %t206 = load i64, ptr %l110, !tbaa !24
  store i64 %t206, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb52
bb52:
  %t207 = load i64, ptr %l18, !tbaa !24
  %t208 = load i64, ptr %l17, !tbaa !24
  %t211 = icmp slt i64 %t207, %t208
  %t213 = xor i1 %t211, true
  br i1 %t213, label %bb53, label %bb54
bb53:
  br label %bb58
bb54:
  br label %bb55
bb55:
  %t215 = load i64, ptr %l14, !tbaa !24
  %t216 = load i64, ptr %l18, !tbaa !24
  %t217 = load i64, ptr %l16, !tbaa !24
  %t220 = mul i64 %t216, %t217
  %t223 = add i64 %t215, %t220
  store i64 %t223, ptr %l19, !tbaa !24
  %t225 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t225, i8 32)
  br label %bb56
bb56:
  br label %bb57
bb57:
  %t227 = load i64, ptr %l18, !tbaa !24
  %t230 = add i64 %t227, 1
  store i64 %t230, ptr %l18, !tbaa !24
  br label %bb52
bb58:
  br label %bb59
bb59:
  %t232 = load ptr, ptr %l1, !tbaa !29
  store ptr %t232, ptr %l135, !tbaa !29
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t235 = getelementptr %"compiler/fmt:formatter", ptr %t233, i32 0, i32 0
  %t236 = load { i64, ptr }, ptr %t235, !tbaa !27
  store { i64, ptr } %t236, ptr %l137, !tbaa !27
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t239 = getelementptr %"compiler/fmt:formatter", ptr %t237, i32 0, i32 17
  %t240 = load i64, ptr %l3, !tbaa !24
  %t243 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t239, i64 %t240)
  store i64 %t243, ptr %l141
  br label %bb60
bb60:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = getelementptr %"compiler/fmt:formatter", ptr %t244, i32 0, i32 18
  %t247 = load i64, ptr %l3, !tbaa !24
  %t250 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t246, i64 %t247)
  store i64 %t250, ptr %l145
  br label %bb61
bb61:
  %t251 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t252 = extractvalue { i64, ptr } %t251, 0
  store i64 %t252, ptr %l146, !tbaa !24
  %t253 = load i64, ptr %l141, !tbaa !24
  %t254 = icmp sge i64 %t253, 0
  br i1 %t254, label %bb62, label %bb63
bb62:
  %t256 = load i64, ptr %l141, !tbaa !24
  %t257 = load i64, ptr %l145, !tbaa !24
  %t258 = icmp sle i64 %t256, %t257
  br i1 %t258, label %bb64, label %bb65
bb63:
  call void @__olang_check_failed(ptr @olang_loc_259a09fa35ee14c1_c921ceba7167c8f5)
  unreachable
bb64:
  %t260 = load i64, ptr %l145, !tbaa !24
  %t261 = load i64, ptr %l146, !tbaa !24
  %t262 = icmp sle i64 %t260, %t261
  br i1 %t262, label %bb66, label %bb67
bb65:
  call void @__olang_check_failed(ptr @olang_loc_259a09fa35ee14c1_c921ceba7167c8f5)
  unreachable
bb66:
  %t264 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t265 = load ptr, ptr %t264, !tbaa !27
  %t266 = load i64, ptr %l141, !tbaa !24
  %t267 = load i64, ptr %l145, !tbaa !24
  %t268 = getelementptr i8, ptr %t265, i64 %t266
  %t269 = sub i64 %t267, %t266
  %t270 = insertvalue { i64, ptr } undef, i64 %t269, 0
  %t271 = insertvalue { i64, ptr } %t270, ptr %t268, 1
  %t272 = load ptr, ptr %l135, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %v0, ptr %t272, { i64, ptr } %t271)
  br label %bb68
bb67:
  call void @__olang_check_failed(ptr @olang_loc_259a09fa35ee14c1_c921ceba7167c8f5)
  unreachable
bb68:
  br label %bb69
bb69:
  %t274 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t274, i8 10)
  br label %bb70
bb70:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffmt_2ecompiler_2ffmt_3aloader_2echains(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l17 = alloca i64
  %l21 = alloca i64
  %l24 = alloca i64
  %l45 = alloca i64
  %l48 = alloca i1
  %l52 = alloca i64
  %l54 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l60 = alloca ptr
  %l61 = alloca ptr
  %l62 = alloca ptr
  %l63 = alloca { i64, ptr }
  %l65 = alloca ptr
  %l69 = alloca i64
  %l70 = alloca { i64, ptr }
  %l71 = alloca ptr
  %l72 = alloca ptr
  %l73 = alloca ptr
  %l77 = alloca i64
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l5, !tbaa !24
  %t3 = icmp sge i64 %t1, 4
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l6, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/fmt:loader", ptr %t5, i32 0, i32 3
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l17
  br label %bb4
bb4:
  %t10 = load i64, ptr %l17, !tbaa !24
  store i64 %t10, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t11 = load i64, ptr %l7, !tbaa !24
  %t12 = load i64, ptr %l6, !tbaa !24
  %t15 = icmp sgt i64 %t11, %t12
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t17 = load i64, ptr %l8, !tbaa !24
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb10
bb7:
  %t21 = load i64, ptr %l7, !tbaa !24
  %t22 = load i64, ptr %l6, !tbaa !24
  %t25 = sub i64 %t21, %t22
  %t26 = load i64, ptr %l8, !tbaa !24
  %t29 = add i64 %t25, %t26
  %t31 = sub i64 %t29, 1
  %t32 = load i64, ptr %l8, !tbaa !24
  %t35 = sdiv i64 %t31, %t32
  store i64 %t35, ptr %l24, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb9
bb9:
  %t37 = load i64, ptr %l24, !tbaa !24
  store i64 %t37, ptr %l21, !tbaa !24
  br label %bb10
bb10:
  %t38 = load i64, ptr %l21, !tbaa !24
  store i64 %t38, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t39 = load i64, ptr %l10, !tbaa !24
  %t40 = load i64, ptr %l9, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb13:
  br label %bb14
bb14:
  %t47 = load i64, ptr %l6, !tbaa !24
  %t48 = load i64, ptr %l10, !tbaa !24
  %t49 = load i64, ptr %l8, !tbaa !24
  %t52 = mul i64 %t48, %t49
  %t55 = add i64 %t47, %t52
  store i64 %t55, ptr %l11, !tbaa !24
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/fmt:loader", ptr %t57, i32 0, i32 3
  %t60 = load i64, ptr %l11, !tbaa !24
  %t63 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t59, i64 %t60)
  store i64 %t63, ptr %l45
  br label %bb15
bb15:
  %t65 = load i64, ptr %l45, !tbaa !24
  %t67 = icmp ne i64 %t65, %a3
  br i1 %t67, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb19
bb17:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/fmt:loader", ptr %t69, i32 0, i32 5
  %t72 = load i64, ptr %l11, !tbaa !24
  %t75 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t71, i64 %t72)
  store i64 %t75, ptr %l52
  br label %bb18
bb18:
  %t76 = load i64, ptr %l52, !tbaa !24
  %t77 = icmp slt i64 %t76, 0
  store i1 %t77, ptr %l48, !tbaa !21
  br label %bb19
bb19:
  %t79 = load i1, ptr %l48, !tbaa !21
  br i1 %t79, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s3)
  br label %bb29
bb21:
  br label %bb22
bb22:
  store { i64, ptr } %a4, ptr %l54, !tbaa !27
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/fmt:loader", ptr %t81, i32 0, i32 4
  %t84 = load i64, ptr %l11, !tbaa !24
  %t87 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %s3, ptr %t83, i64 %t84)
  store { i64, ptr } %t87, ptr %l58
  br label %bb23
bb23:
  %t88 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t88, 1
  %t90 = extractvalue { i64, ptr } %t88, 0
  %t91 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t91, 1
  %t93 = extractvalue { i64, ptr } %t91, 0
  %t94 = add i64 %t90, %t93
  %t95 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t94)
  call void @olang_textcopy(ptr %t95, ptr %t89, i64 %t90)
  %t96 = getelementptr i8, ptr %t95, i64 %t90
  call void @olang_textcopy(ptr %t96, ptr %t92, i64 %t93)
  %t97 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t95, 1
  store { i64, ptr } %t98, ptr %l12, !tbaa !27
  %t100 = load ptr, ptr %l0, !tbaa !29
  store ptr %t100, ptr %l60, !tbaa !29
  %t101 = load ptr, ptr %l1, !tbaa !29
  store ptr %t101, ptr %l61, !tbaa !29
  %t102 = load ptr, ptr %l2, !tbaa !29
  store ptr %t102, ptr %l62, !tbaa !29
  %t103 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t103, ptr %l63, !tbaa !27
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/fmt:loader", ptr %t104, i32 0, i32 2
  store ptr %t106, ptr %l65, !tbaa !29
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/fmt:loader", ptr %t107, i32 0, i32 5
  %t110 = load i64, ptr %l11, !tbaa !24
  %t113 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t109, i64 %t110)
  store i64 %t113, ptr %l69
  br label %bb24
bb24:
  %t114 = load ptr, ptr %l65, !tbaa !29
  %t115 = load i64, ptr %l69, !tbaa !24
  %t116 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t114, i64 %t115)
  store { i64, ptr } %t116, ptr %l70
  br label %bb25
bb25:
  %t117 = load ptr, ptr %l60, !tbaa !29
  %t118 = load ptr, ptr %l61, !tbaa !29
  %t119 = load ptr, ptr %l62, !tbaa !29
  %t120 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t121 = load { i64, ptr }, ptr %l70, !tbaa !27
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aloader_2eaddNames(ptr %v0, ptr %v1, ptr %v2, ptr %s3, ptr %v0, ptr %t117, ptr %t118, ptr %t119, { i64, ptr } %t120, { i64, ptr } %t121)
  br label %bb26
bb26:
  %t122 = load ptr, ptr %l0, !tbaa !29
  store ptr %t122, ptr %l71, !tbaa !29
  %t123 = load ptr, ptr %l1, !tbaa !29
  store ptr %t123, ptr %l72, !tbaa !29
  %t124 = load ptr, ptr %l2, !tbaa !29
  store ptr %t124, ptr %l73, !tbaa !29
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/fmt:loader", ptr %t125, i32 0, i32 5
  %t128 = load i64, ptr %l11, !tbaa !24
  %t131 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t127, i64 %t128)
  store i64 %t131, ptr %l77
  br label %bb27
bb27:
  %t132 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t132, 1
  %t135 = extractvalue { i64, ptr } %t132, 0
  %t136 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d40, i32 0, i32 1) }, 1
  %t137 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d40, i32 0, i32 1) }, 0
  %t138 = add i64 %t135, %t137
  %t139 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t138)
  call void @olang_textcopy(ptr %t139, ptr %t134, i64 %t135)
  %t140 = getelementptr i8, ptr %t139, i64 %t135
  call void @olang_textcopy(ptr %t140, ptr %t136, i64 %t137)
  %t141 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t139, 1
  %t144 = load i64, ptr %l5, !tbaa !24
  %t146 = add i64 %t144, 1
  %t147 = load ptr, ptr %l71, !tbaa !29
  %t148 = load ptr, ptr %l72, !tbaa !29
  %t149 = load ptr, ptr %l73, !tbaa !29
  %t150 = load i64, ptr %l77, !tbaa !24
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aloader_2echains(ptr %v0, ptr %v1, ptr %v2, ptr %s3, ptr %t147, ptr %t148, ptr %t149, i64 %t150, { i64, ptr } %t142, i64 %t146)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s3)
  br label %bb29
bb29:
  %t153 = load i64, ptr %l10, !tbaa !24
  %t156 = add i64 %t153, 1
  store i64 %t156, ptr %l10, !tbaa !24
  br label %bb11
bb30:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ffmt_2ecompiler_2ffmt_3aloader_2eload(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"compiler/source:Source"
  %l10 = alloca %"compiler/scan:Tokens"
  %l11 = alloca i64
  %l12 = alloca %"std/prelude/text:StringBuilder"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i32
  %l24 = alloca i1
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca i32
  %l41 = alloca i1
  %l47 = alloca i64
  %l51 = alloca i64
  %l54 = alloca i64
  %l75 = alloca { i64, ptr }
  %l77 = alloca i1
  %l82 = alloca %"compiler/source:Source"
  %l84 = alloca %"compiler/source:Source"
  %l85 = alloca i32
  %l87 = alloca i1
  %l92 = alloca %"compiler/scan:Tokens"
  %l95 = alloca i64
  %l99 = alloca %"std/prelude/text:StringBuilder"
  %l101 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l102 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l110 = alloca i64
  %l113 = alloca i64
  %l131 = alloca { i64, ptr }
  %l138 = alloca i1
  %l139 = alloca { i64, ptr }
  %l146 = alloca i1
  %l148 = alloca i1
  %l151 = alloca i1
  %l153 = alloca i1
  %l158 = alloca i1
  %l159 = alloca { i64, ptr }
  %l164 = alloca ptr
  %l165 = alloca { i64, ptr }
  %l166 = alloca { i64, ptr }
  %l170 = alloca i64
  %l171 = alloca { i64, ptr }
  %l175 = alloca i64
  %l176 = alloca i64
  %l184 = alloca i1
  %l186 = alloca i1
  %l191 = alloca i1
  %l192 = alloca { i64, ptr }
  %l197 = alloca ptr
  %l198 = alloca { i64, ptr }
  %l199 = alloca { i64, ptr }
  %l203 = alloca i64
  %l204 = alloca { i64, ptr }
  %l208 = alloca i64
  %l209 = alloca i64
  %l224 = alloca i1
  %l225 = alloca { i64, ptr }
  %l229 = alloca { i64, ptr }
  %l230 = alloca { i64, ptr }
  %l233 = alloca i64
  %l234 = alloca { i64, ptr }
  %l237 = alloca i64
  %l238 = alloca i64
  %l251 = alloca i1
  %l252 = alloca { i64, ptr }
  %l256 = alloca { i64, ptr }
  %l257 = alloca { i64, ptr }
  %l260 = alloca i64
  %l261 = alloca { i64, ptr }
  %l264 = alloca i64
  %l265 = alloca i64
  %l270 = alloca { i64, ptr }
  %l271 = alloca { i64, ptr }
  %l273 = alloca i1
  %l275 = alloca { i64, ptr }
  %l279 = alloca { i64, ptr }
  %l287 = alloca ptr
  %l288 = alloca i64
  %l291 = alloca { i64, ptr }
  %l294 = alloca i64
  %l298 = alloca i64
  %l301 = alloca i64
  %l319 = alloca ptr
  %l320 = alloca { i64, ptr }
  %l323 = alloca { i64, ptr }
  %l324 = alloca { i64, ptr }
  %l326 = alloca i1
  %l330 = alloca i64
  %l335 = alloca ptr
  %l336 = alloca i64
  %l340 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v1, ptr %v0, { i64, ptr } %a1)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l39
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store { i64, ptr } %t4, ptr %l38
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t8, ptr %l36, !tbaa !27
  br label %bb6
bb2:
  %t9 = load i32, ptr %l39, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  store i1 %t12, ptr %l41, !tbaa !21
  %t13 = load i32, ptr %l39, !tbaa !23
  %t14 = ashr i32 %t13, 16
  %t16 = icmp eq i32 %t14, 1
  br i1 %t16, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb6:
  %t19 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t19, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/fmt:loader", ptr %t20, i32 0, i32 1
  %t24 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t22)
  store i64 %t24, ptr %l47
  br label %bb7
bb7:
  %t25 = load i64, ptr %l47, !tbaa !24
  store i64 %t25, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t26 = load i64, ptr %l4, !tbaa !24
  %t27 = load i64, ptr %l3, !tbaa !24
  %t30 = icmp sgt i64 %t26, %t27
  br i1 %t30, label %bb8, label %bb9
bb8:
  %t32 = load i64, ptr %l5, !tbaa !24
  %t34 = icmp sgt i64 %t32, 0
  br i1 %t34, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb13
bb10:
  %t36 = load i64, ptr %l4, !tbaa !24
  %t37 = load i64, ptr %l3, !tbaa !24
  %t40 = sub i64 %t36, %t37
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = add i64 %t40, %t41
  %t46 = sub i64 %t44, 1
  %t47 = load i64, ptr %l5, !tbaa !24
  %t50 = sdiv i64 %t46, %t47
  store i64 %t50, ptr %l54, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb12
bb12:
  %t52 = load i64, ptr %l54, !tbaa !24
  store i64 %t52, ptr %l51, !tbaa !24
  br label %bb13
bb13:
  %t53 = load i64, ptr %l51, !tbaa !24
  store i64 %t53, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb14
bb14:
  %t54 = load i64, ptr %l7, !tbaa !24
  %t55 = load i64, ptr %l6, !tbaa !24
  %t58 = icmp slt i64 %t54, %t55
  %t60 = xor i1 %t58, true
  br i1 %t60, label %bb15, label %bb16
bb15:
  br label %bb24
bb16:
  br label %bb17
bb17:
  %t62 = load i64, ptr %l3, !tbaa !24
  %t63 = load i64, ptr %l7, !tbaa !24
  %t64 = load i64, ptr %l5, !tbaa !24
  %t67 = mul i64 %t63, %t64
  %t70 = add i64 %t62, %t67
  store i64 %t70, ptr %l8, !tbaa !24
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/fmt:loader", ptr %t72, i32 0, i32 1
  %t75 = load i64, ptr %l8, !tbaa !24
  %t78 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t74, i64 %t75)
  store { i64, ptr } %t78, ptr %l75
  br label %bb18
bb18:
  %t79 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t80 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t82 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v0, { i64, ptr } %t80, { i64, ptr } %t79)
  store i1 %t82, ptr %l77
  br label %bb19
bb19:
  %t83 = load i1, ptr %l77, !tbaa !21
  br i1 %t83, label %bb20, label %bb21
bb20:
  %t84 = load i64, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t84, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t86 = load i64, ptr %l7, !tbaa !24
  %t89 = add i64 %t86, 1
  store i64 %t89, ptr %l7, !tbaa !24
  br label %bb14
bb24:
  %t91 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t93 = call { i32, %"compiler/source:Source" } @compiler_2fsource_2eSource_2eRead(ptr %v0, ptr %s0, { i64, ptr } %t91)
  %t94 = extractvalue { i32, %"compiler/source:Source" } %t93, 1
  %t95 = extractvalue { i32, %"compiler/source:Source" } %t93, 0
  store i32 %t95, ptr %l85
  %t96 = icmp ne i32 %t95, 0
  br i1 %t96, label %bb26, label %ok.97, !prof !99
ok.97:
  store %"compiler/source:Source" %t94, ptr %l84
  br label %bb25
bb25:
  %t98 = load %"compiler/source:Source", ptr %l84
  store %"compiler/source:Source" %t98, ptr %l82
  br label %bb30
bb26:
  %t99 = load i32, ptr %l85, !tbaa !23
  %t100 = ashr i32 %t99, 16
  %t102 = icmp eq i32 %t100, 1
  store i1 %t102, ptr %l87, !tbaa !21
  %t103 = load i32, ptr %l85, !tbaa !23
  %t104 = ashr i32 %t103, 16
  %t106 = icmp eq i32 %t104, 1
  br i1 %t106, label %bb27, label %bb28
bb27:
  call void @__olang_errpay_pop()
  br label %bb28
bb28:
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb30:
  %t109 = load %"compiler/source:Source", ptr %l82
  store %"compiler/source:Source" %t109, ptr %l9
  %t110 = getelementptr %"compiler/source:Source", ptr %l9, i32 0, i32 1
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  %t113 = call %"compiler/scan:Tokens" @compiler_2fscan_2eTokens_2eScan(ptr %s0, ptr %s0, { i64, ptr } %t111)
  store %"compiler/scan:Tokens" %t113, ptr %l92
  br label %bb31
bb31:
  %t114 = load %"compiler/scan:Tokens", ptr %l92
  store %"compiler/scan:Tokens" %t114, ptr %l10
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/fmt:loader", ptr %t115, i32 0, i32 1
  %t119 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t117)
  store i64 %t119, ptr %l95
  br label %bb32
bb32:
  %t120 = load i64, ptr %l95, !tbaa !24
  store i64 %t120, ptr %l11, !tbaa !24
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/fmt:loader", ptr %t121, i32 0, i32 1
  %t124 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t123, { i64, ptr } %t124)
  br label %bb33
bb33:
  %t127 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t127, ptr %l99
  br label %bb34
bb34:
  %t128 = load %"std/prelude/text:StringBuilder", ptr %l99
  store %"std/prelude/text:StringBuilder" %t128, ptr %l12
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l12, i8 32)
  br label %bb35
bb35:
  %t130 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t130, ptr %l101
  br label %bb36
bb36:
  %t131 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l101
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t131, ptr %l13
  %t132 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t132, ptr %l102
  br label %bb37
bb37:
  %t133 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l102
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t133, ptr %l14
  %t134 = getelementptr %"compiler/scan:Tokens", ptr %l10, i32 0, i32 0
  %t135 = load { i64, ptr }, ptr %t134, !tbaa !27
  store { i64, ptr } %t135, ptr %l15, !tbaa !27
  %t137 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t137, 0
  store i64 %t139, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  %t141 = load i64, ptr %l16, !tbaa !24
  store i64 %t141, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t143 = load i64, ptr %l18, !tbaa !24
  %t144 = load i64, ptr %l17, !tbaa !24
  %t147 = icmp sgt i64 %t143, %t144
  br i1 %t147, label %bb38, label %bb39
bb38:
  %t149 = load i64, ptr %l19, !tbaa !24
  %t151 = icmp sgt i64 %t149, 0
  br i1 %t151, label %bb40, label %bb41
bb39:
  store i64 0, ptr %l110, !tbaa !24
  br label %bb43
bb40:
  %t153 = load i64, ptr %l18, !tbaa !24
  %t154 = load i64, ptr %l17, !tbaa !24
  %t157 = sub i64 %t153, %t154
  %t158 = load i64, ptr %l19, !tbaa !24
  %t161 = add i64 %t157, %t158
  %t163 = sub i64 %t161, 1
  %t164 = load i64, ptr %l19, !tbaa !24
  %t167 = sdiv i64 %t163, %t164
  store i64 %t167, ptr %l113, !tbaa !24
  br label %bb42
bb41:
  store i64 0, ptr %l113, !tbaa !24
  br label %bb42
bb42:
  %t169 = load i64, ptr %l113, !tbaa !24
  store i64 %t169, ptr %l110, !tbaa !24
  br label %bb43
bb43:
  %t170 = load i64, ptr %l110, !tbaa !24
  store i64 %t170, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb44
bb44:
  %t171 = load i64, ptr %l21, !tbaa !24
  %t172 = load i64, ptr %l20, !tbaa !24
  %t175 = icmp slt i64 %t171, %t172
  %t177 = xor i1 %t175, true
  br i1 %t177, label %bb45, label %bb46
bb45:
  br label %bb133
bb46:
  br label %bb47
bb47:
  %t179 = load i64, ptr %l17, !tbaa !24
  %t180 = load i64, ptr %l21, !tbaa !24
  %t181 = load i64, ptr %l19, !tbaa !24
  %t184 = mul i64 %t180, %t181
  %t187 = add i64 %t179, %t184
  store i64 %t187, ptr %l22, !tbaa !24
  %t189 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t189, ptr %l131, !tbaa !27
  %t190 = load i64, ptr %l22, !tbaa !24
  %t192 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t194 = getelementptr %"compiler/token:Token", ptr %t193, i64 %t190
  %t195 = getelementptr %"compiler/token:Token", ptr %t194, i32 0, i32 0
  %t196 = load i32, ptr %t195, !range !{i32 0, i32 116}
  store i32 %t196, ptr %l23
  %t198 = load i64, ptr %l22, !tbaa !24
  %t200 = add i64 %t198, 1
  %t201 = load i64, ptr %l16, !tbaa !24
  %t204 = icmp slt i64 %t200, %t201
  br i1 %t204, label %bb48, label %bb49
bb48:
  %t206 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t206, ptr %l139, !tbaa !27
  %t207 = load i64, ptr %l22, !tbaa !24
  %t209 = add i64 %t207, 1
  %t211 = getelementptr { i64, ptr }, ptr %l139, i32 0, i32 1
  %t212 = load ptr, ptr %t211, !tbaa !27
  %t213 = getelementptr %"compiler/token:Token", ptr %t212, i64 %t209
  %t214 = getelementptr %"compiler/token:Token", ptr %t213, i32 0, i32 0
  %t215 = load i32, ptr %t214, !range !{i32 0, i32 116}
  %t217 = trunc i64 1 to i32
  %t218 = icmp eq i32 %t215, %t217
  store i1 %t218, ptr %l138, !tbaa !21
  br label %bb50
bb49:
  store i1 false, ptr %l138, !tbaa !21
  br label %bb50
bb50:
  %t220 = load i1, ptr %l138, !tbaa !21
  store i1 %t220, ptr %l24, !tbaa !21
  %t221 = load i32, ptr %l23, !range !{i32 0, i32 116}
  %t223 = trunc i64 33 to i32
  %t224 = icmp eq i32 %t221, %t223
  br i1 %t224, label %bb51, label %bb52
bb51:
  %t226 = load i1, ptr %l24, !tbaa !21
  store i1 %t226, ptr %l146, !tbaa !21
  br label %bb53
bb52:
  store i1 false, ptr %l146, !tbaa !21
  br label %bb53
bb53:
  %t228 = load i1, ptr %l146, !tbaa !21
  br i1 %t228, label %bb54, label %bb55
bb54:
  store i1 true, ptr %l148, !tbaa !21
  br label %bb65
bb55:
  %t229 = load i32, ptr %l23, !range !{i32 0, i32 116}
  %t231 = trunc i64 38 to i32
  %t232 = icmp eq i32 %t229, %t231
  br i1 %t232, label %bb56, label %bb57
bb56:
  %t234 = load i1, ptr %l24, !tbaa !21
  store i1 %t234, ptr %l151, !tbaa !21
  br label %bb58
bb57:
  store i1 false, ptr %l151, !tbaa !21
  br label %bb58
bb58:
  %t236 = load i1, ptr %l151, !tbaa !21
  br i1 %t236, label %bb59, label %bb60
bb59:
  %t237 = load i64, ptr %l22, !tbaa !24
  %t239 = add i64 %t237, 2
  %t240 = load i64, ptr %l16, !tbaa !24
  %t243 = icmp slt i64 %t239, %t240
  store i1 %t243, ptr %l153, !tbaa !21
  br label %bb61
bb60:
  store i1 false, ptr %l153, !tbaa !21
  br label %bb61
bb61:
  %t245 = load i1, ptr %l153, !tbaa !21
  br i1 %t245, label %bb62, label %bb63
bb62:
  %t246 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t246, ptr %l159, !tbaa !27
  %t247 = load i64, ptr %l22, !tbaa !24
  %t249 = add i64 %t247, 2
  %t251 = getelementptr { i64, ptr }, ptr %l159, i32 0, i32 1
  %t252 = load ptr, ptr %t251, !tbaa !27
  %t253 = getelementptr %"compiler/token:Token", ptr %t252, i64 %t249
  %t254 = getelementptr %"compiler/token:Token", ptr %t253, i32 0, i32 0
  %t255 = load i32, ptr %t254, !range !{i32 0, i32 116}
  %t257 = trunc i64 114 to i32
  %t258 = icmp eq i32 %t255, %t257
  store i1 %t258, ptr %l158, !tbaa !21
  br label %bb64
bb63:
  store i1 false, ptr %l158, !tbaa !21
  br label %bb64
bb64:
  %t260 = load i1, ptr %l158, !tbaa !21
  store i1 %t260, ptr %l148, !tbaa !21
  br label %bb65
bb65:
  %t261 = load i1, ptr %l148, !tbaa !21
  br i1 %t261, label %bb66, label %bb67
bb66:
  store ptr %l12, ptr %l164, !tbaa !29
  %t262 = getelementptr %"compiler/source:Source", ptr %l9, i32 0, i32 1
  %t263 = load { i64, ptr }, ptr %t262, !tbaa !27
  store { i64, ptr } %t263, ptr %l165, !tbaa !27
  %t264 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t264, ptr %l166, !tbaa !27
  %t265 = load i64, ptr %l22, !tbaa !24
  %t267 = add i64 %t265, 1
  %t269 = getelementptr { i64, ptr }, ptr %l166, i32 0, i32 1
  %t270 = load ptr, ptr %t269, !tbaa !27
  %t271 = getelementptr %"compiler/token:Token", ptr %t270, i64 %t267
  %t272 = getelementptr %"compiler/token:Token", ptr %t271, i32 0, i32 2
  %t273 = load i32, ptr %t272, !tbaa !23
  %t275 = sext i32 %t273 to i64
  store i64 %t275, ptr %l170, !tbaa !24
  %t276 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t276, ptr %l171, !tbaa !27
  %t277 = load i64, ptr %l22, !tbaa !24
  %t279 = add i64 %t277, 1
  %t281 = getelementptr { i64, ptr }, ptr %l171, i32 0, i32 1
  %t282 = load ptr, ptr %t281, !tbaa !27
  %t283 = getelementptr %"compiler/token:Token", ptr %t282, i64 %t279
  %t284 = getelementptr %"compiler/token:Token", ptr %t283, i32 0, i32 3
  %t285 = load i32, ptr %t284, !tbaa !23
  %t287 = sext i32 %t285 to i64
  store i64 %t287, ptr %l175, !tbaa !24
  %t288 = load { i64, ptr }, ptr %l165, !tbaa !27
  %t289 = extractvalue { i64, ptr } %t288, 0
  store i64 %t289, ptr %l176, !tbaa !24
  %t290 = load i64, ptr %l170, !tbaa !24
  %t291 = icmp sge i64 %t290, 0
  br i1 %t291, label %bb68, label %bb69
bb67:
  br label %bb76
bb68:
  %t293 = load i64, ptr %l170, !tbaa !24
  %t294 = load i64, ptr %l175, !tbaa !24
  %t295 = icmp sle i64 %t293, %t294
  br i1 %t295, label %bb70, label %bb71
bb69:
  call void @__olang_check_failed(ptr @olang_loc_b45f67b0c13c7f92_d3bc8c6077d2e8ee)
  unreachable
bb70:
  %t297 = load i64, ptr %l175, !tbaa !24
  %t298 = load i64, ptr %l176, !tbaa !24
  %t299 = icmp sle i64 %t297, %t298
  br i1 %t299, label %bb72, label %bb73
bb71:
  call void @__olang_check_failed(ptr @olang_loc_b45f67b0c13c7f92_d3bc8c6077d2e8ee)
  unreachable
bb72:
  %t301 = getelementptr { i64, ptr }, ptr %l165, i32 0, i32 1
  %t302 = load ptr, ptr %t301, !tbaa !27
  %t303 = load i64, ptr %l170, !tbaa !24
  %t304 = load i64, ptr %l175, !tbaa !24
  %t305 = getelementptr i8, ptr %t302, i64 %t303
  %t306 = sub i64 %t304, %t303
  %t307 = insertvalue { i64, ptr } undef, i64 %t306, 0
  %t308 = insertvalue { i64, ptr } %t307, ptr %t305, 1
  %t309 = load ptr, ptr %l164, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t309, { i64, ptr } %t308)
  br label %bb74
bb73:
  call void @__olang_check_failed(ptr @olang_loc_b45f67b0c13c7f92_d3bc8c6077d2e8ee)
  unreachable
bb74:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l12, i8 32)
  br label %bb75
bb75:
  br label %bb76
bb76:
  %t312 = load i32, ptr %l23, !range !{i32 0, i32 116}
  %t314 = trunc i64 37 to i32
  %t315 = icmp eq i32 %t312, %t314
  br i1 %t315, label %bb77, label %bb78
bb77:
  %t317 = load i1, ptr %l24, !tbaa !21
  store i1 %t317, ptr %l184, !tbaa !21
  br label %bb79
bb78:
  store i1 false, ptr %l184, !tbaa !21
  br label %bb79
bb79:
  %t319 = load i1, ptr %l184, !tbaa !21
  br i1 %t319, label %bb80, label %bb81
bb80:
  %t320 = load i64, ptr %l22, !tbaa !24
  %t322 = add i64 %t320, 2
  %t323 = load i64, ptr %l16, !tbaa !24
  %t326 = icmp slt i64 %t322, %t323
  store i1 %t326, ptr %l186, !tbaa !21
  br label %bb82
bb81:
  store i1 false, ptr %l186, !tbaa !21
  br label %bb82
bb82:
  %t328 = load i1, ptr %l186, !tbaa !21
  br i1 %t328, label %bb83, label %bb84
bb83:
  %t329 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t329, ptr %l192, !tbaa !27
  %t330 = load i64, ptr %l22, !tbaa !24
  %t332 = add i64 %t330, 2
  %t334 = getelementptr { i64, ptr }, ptr %l192, i32 0, i32 1
  %t335 = load ptr, ptr %t334, !tbaa !27
  %t336 = getelementptr %"compiler/token:Token", ptr %t335, i64 %t332
  %t337 = getelementptr %"compiler/token:Token", ptr %t336, i32 0, i32 0
  %t338 = load i32, ptr %t337, !range !{i32 0, i32 116}
  %t340 = trunc i64 98 to i32
  %t341 = icmp eq i32 %t338, %t340
  store i1 %t341, ptr %l191, !tbaa !21
  br label %bb85
bb84:
  store i1 false, ptr %l191, !tbaa !21
  br label %bb85
bb85:
  %t343 = load i1, ptr %l191, !tbaa !21
  br i1 %t343, label %bb86, label %bb87
bb86:
  store %olang.scope zeroinitializer, ptr %s10
  store ptr %l12, ptr %l197, !tbaa !29
  %t344 = getelementptr %"compiler/source:Source", ptr %l9, i32 0, i32 1
  %t345 = load { i64, ptr }, ptr %t344, !tbaa !27
  store { i64, ptr } %t345, ptr %l198, !tbaa !27
  %t346 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t346, ptr %l199, !tbaa !27
  %t347 = load i64, ptr %l22, !tbaa !24
  %t349 = add i64 %t347, 1
  %t351 = getelementptr { i64, ptr }, ptr %l199, i32 0, i32 1
  %t352 = load ptr, ptr %t351, !tbaa !27
  %t353 = getelementptr %"compiler/token:Token", ptr %t352, i64 %t349
  %t354 = getelementptr %"compiler/token:Token", ptr %t353, i32 0, i32 2
  %t355 = load i32, ptr %t354, !tbaa !23
  %t357 = sext i32 %t355 to i64
  store i64 %t357, ptr %l203, !tbaa !24
  %t358 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t358, ptr %l204, !tbaa !27
  %t359 = load i64, ptr %l22, !tbaa !24
  %t361 = add i64 %t359, 1
  %t363 = getelementptr { i64, ptr }, ptr %l204, i32 0, i32 1
  %t364 = load ptr, ptr %t363, !tbaa !27
  %t365 = getelementptr %"compiler/token:Token", ptr %t364, i64 %t361
  %t366 = getelementptr %"compiler/token:Token", ptr %t365, i32 0, i32 3
  %t367 = load i32, ptr %t366, !tbaa !23
  %t369 = sext i32 %t367 to i64
  store i64 %t369, ptr %l208, !tbaa !24
  %t370 = load { i64, ptr }, ptr %l198, !tbaa !27
  %t371 = extractvalue { i64, ptr } %t370, 0
  store i64 %t371, ptr %l209, !tbaa !24
  %t372 = load i64, ptr %l203, !tbaa !24
  %t373 = icmp sge i64 %t372, 0
  br i1 %t373, label %bb88, label %bb89
bb87:
  br label %bb96
bb88:
  %t375 = load i64, ptr %l203, !tbaa !24
  %t376 = load i64, ptr %l208, !tbaa !24
  %t377 = icmp sle i64 %t375, %t376
  br i1 %t377, label %bb90, label %bb91
bb89:
  call void @__olang_check_failed(ptr @olang_loc_bf801ccf4339d98f_a7f4482671f796eb)
  unreachable
bb90:
  %t379 = load i64, ptr %l208, !tbaa !24
  %t380 = load i64, ptr %l209, !tbaa !24
  %t381 = icmp sle i64 %t379, %t380
  br i1 %t381, label %bb92, label %bb93
bb91:
  call void @__olang_check_failed(ptr @olang_loc_bf801ccf4339d98f_a7f4482671f796eb)
  unreachable
bb92:
  %t383 = getelementptr { i64, ptr }, ptr %l198, i32 0, i32 1
  %t384 = load ptr, ptr %t383, !tbaa !27
  %t385 = load i64, ptr %l203, !tbaa !24
  %t386 = load i64, ptr %l208, !tbaa !24
  %t387 = getelementptr i8, ptr %t384, i64 %t385
  %t388 = sub i64 %t386, %t385
  %t389 = insertvalue { i64, ptr } undef, i64 %t388, 0
  %t390 = insertvalue { i64, ptr } %t389, ptr %t387, 1
  %t391 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t392 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  %t394 = extractvalue { i64, ptr } %t390, 1
  %t395 = extractvalue { i64, ptr } %t390, 0
  %t396 = add i64 %t392, %t395
  %t397 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t396)
  call void @olang_textcopy(ptr %t397, ptr %t391, i64 %t392)
  %t398 = getelementptr i8, ptr %t397, i64 %t392
  call void @olang_textcopy(ptr %t398, ptr %t394, i64 %t395)
  %t399 = insertvalue { i64, ptr } undef, i64 %t396, 0
  %t400 = insertvalue { i64, ptr } %t399, ptr %t397, 1
  %t402 = load ptr, ptr %l197, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s10, ptr %t402, { i64, ptr } %t400)
  br label %bb94
bb93:
  call void @__olang_check_failed(ptr @olang_loc_bf801ccf4339d98f_a7f4482671f796eb)
  unreachable
bb94:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l12, i8 32)
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s10)
  br label %bb96
bb96:
  %t405 = load i32, ptr %l23, !range !{i32 0, i32 116}
  %t407 = trunc i64 40 to i32
  %t408 = icmp eq i32 %t405, %t407
  br i1 %t408, label %bb97, label %bb98
bb97:
  %t410 = load i64, ptr %l22, !tbaa !24
  %t412 = add i64 %t410, 1
  store i64 %t412, ptr %l25, !tbaa !24
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d42, i32 0, i32 1) }, ptr %l26, !tbaa !27
  %t414 = load i64, ptr %l25, !tbaa !24
  %t415 = load i64, ptr %l16, !tbaa !24
  %t418 = icmp slt i64 %t414, %t415
  br i1 %t418, label %bb99, label %bb100
bb98:
  br label %bb131
bb99:
  %t420 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t420, ptr %l225, !tbaa !27
  %t421 = load i64, ptr %l25, !tbaa !24
  %t423 = getelementptr { i64, ptr }, ptr %l225, i32 0, i32 1
  %t424 = load ptr, ptr %t423, !tbaa !27
  %t425 = getelementptr %"compiler/token:Token", ptr %t424, i64 %t421
  %t426 = getelementptr %"compiler/token:Token", ptr %t425, i32 0, i32 0
  %t427 = load i32, ptr %t426, !range !{i32 0, i32 116}
  %t429 = trunc i64 1 to i32
  %t430 = icmp eq i32 %t427, %t429
  store i1 %t430, ptr %l224, !tbaa !21
  br label %bb101
bb100:
  store i1 false, ptr %l224, !tbaa !21
  br label %bb101
bb101:
  %t432 = load i1, ptr %l224, !tbaa !21
  br i1 %t432, label %bb102, label %bb103
bb102:
  %t433 = getelementptr %"compiler/source:Source", ptr %l9, i32 0, i32 1
  %t434 = load { i64, ptr }, ptr %t433, !tbaa !27
  store { i64, ptr } %t434, ptr %l229, !tbaa !27
  %t435 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t435, ptr %l230, !tbaa !27
  %t436 = load i64, ptr %l25, !tbaa !24
  %t438 = getelementptr { i64, ptr }, ptr %l230, i32 0, i32 1
  %t439 = load ptr, ptr %t438, !tbaa !27
  %t440 = getelementptr %"compiler/token:Token", ptr %t439, i64 %t436
  %t441 = getelementptr %"compiler/token:Token", ptr %t440, i32 0, i32 2
  %t442 = load i32, ptr %t441, !tbaa !23
  %t444 = sext i32 %t442 to i64
  store i64 %t444, ptr %l233, !tbaa !24
  %t445 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t445, ptr %l234, !tbaa !27
  %t446 = load i64, ptr %l25, !tbaa !24
  %t448 = getelementptr { i64, ptr }, ptr %l234, i32 0, i32 1
  %t449 = load ptr, ptr %t448, !tbaa !27
  %t450 = getelementptr %"compiler/token:Token", ptr %t449, i64 %t446
  %t451 = getelementptr %"compiler/token:Token", ptr %t450, i32 0, i32 3
  %t452 = load i32, ptr %t451, !tbaa !23
  %t454 = sext i32 %t452 to i64
  store i64 %t454, ptr %l237, !tbaa !24
  %t455 = load { i64, ptr }, ptr %l229, !tbaa !27
  %t456 = extractvalue { i64, ptr } %t455, 0
  store i64 %t456, ptr %l238, !tbaa !24
  %t457 = load i64, ptr %l233, !tbaa !24
  %t458 = icmp sge i64 %t457, 0
  br i1 %t458, label %bb104, label %bb105
bb103:
  br label %bb110
bb104:
  %t460 = load i64, ptr %l233, !tbaa !24
  %t461 = load i64, ptr %l237, !tbaa !24
  %t462 = icmp sle i64 %t460, %t461
  br i1 %t462, label %bb106, label %bb107
bb105:
  call void @__olang_check_failed(ptr @olang_loc_31ba00d857a48a4_d72415852a995970)
  unreachable
bb106:
  %t464 = load i64, ptr %l237, !tbaa !24
  %t465 = load i64, ptr %l238, !tbaa !24
  %t466 = icmp sle i64 %t464, %t465
  br i1 %t466, label %bb108, label %bb109
bb107:
  call void @__olang_check_failed(ptr @olang_loc_31ba00d857a48a4_d72415852a995970)
  unreachable
bb108:
  %t468 = getelementptr { i64, ptr }, ptr %l229, i32 0, i32 1
  %t469 = load ptr, ptr %t468, !tbaa !27
  %t470 = load i64, ptr %l233, !tbaa !24
  %t471 = load i64, ptr %l237, !tbaa !24
  %t472 = getelementptr i8, ptr %t469, i64 %t470
  %t473 = sub i64 %t471, %t470
  %t474 = insertvalue { i64, ptr } undef, i64 %t473, 0
  %t475 = insertvalue { i64, ptr } %t474, ptr %t472, 1
  %t477 = extractvalue { i64, ptr } %t475, 1
  %t478 = extractvalue { i64, ptr } %t475, 0
  %t479 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t478)
  call void @olang_textcopy(ptr %t479, ptr %t477, i64 %t478)
  %t480 = insertvalue { i64, ptr } undef, i64 %t478, 0
  %t481 = insertvalue { i64, ptr } %t480, ptr %t479, 1
  store { i64, ptr } %t481, ptr %l26, !tbaa !27
  %t484 = load i64, ptr %l25, !tbaa !24
  %t487 = add i64 %t484, 1
  store i64 %t487, ptr %l25, !tbaa !24
  br label %bb110
bb109:
  call void @__olang_check_failed(ptr @olang_loc_31ba00d857a48a4_d72415852a995970)
  unreachable
bb110:
  %t489 = load i64, ptr %l25, !tbaa !24
  %t490 = load i64, ptr %l16, !tbaa !24
  %t493 = icmp slt i64 %t489, %t490
  br i1 %t493, label %bb111, label %bb112
bb111:
  %t495 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t495, ptr %l252, !tbaa !27
  %t496 = load i64, ptr %l25, !tbaa !24
  %t498 = getelementptr { i64, ptr }, ptr %l252, i32 0, i32 1
  %t499 = load ptr, ptr %t498, !tbaa !27
  %t500 = getelementptr %"compiler/token:Token", ptr %t499, i64 %t496
  %t501 = getelementptr %"compiler/token:Token", ptr %t500, i32 0, i32 0
  %t502 = load i32, ptr %t501, !range !{i32 0, i32 116}
  %t504 = trunc i64 5 to i32
  %t505 = icmp eq i32 %t502, %t504
  store i1 %t505, ptr %l251, !tbaa !21
  br label %bb113
bb112:
  store i1 false, ptr %l251, !tbaa !21
  br label %bb113
bb113:
  %t507 = load i1, ptr %l251, !tbaa !21
  br i1 %t507, label %bb114, label %bb115
bb114:
  store %olang.scope zeroinitializer, ptr %s15
  %t508 = getelementptr %"compiler/source:Source", ptr %l9, i32 0, i32 1
  %t509 = load { i64, ptr }, ptr %t508, !tbaa !27
  store { i64, ptr } %t509, ptr %l256, !tbaa !27
  %t510 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t510, ptr %l257, !tbaa !27
  %t511 = load i64, ptr %l25, !tbaa !24
  %t513 = getelementptr { i64, ptr }, ptr %l257, i32 0, i32 1
  %t514 = load ptr, ptr %t513, !tbaa !27
  %t515 = getelementptr %"compiler/token:Token", ptr %t514, i64 %t511
  %t516 = getelementptr %"compiler/token:Token", ptr %t515, i32 0, i32 2
  %t517 = load i32, ptr %t516, !tbaa !23
  %t519 = sext i32 %t517 to i64
  store i64 %t519, ptr %l260, !tbaa !24
  %t520 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t520, ptr %l261, !tbaa !27
  %t521 = load i64, ptr %l25, !tbaa !24
  %t523 = getelementptr { i64, ptr }, ptr %l261, i32 0, i32 1
  %t524 = load ptr, ptr %t523, !tbaa !27
  %t525 = getelementptr %"compiler/token:Token", ptr %t524, i64 %t521
  %t526 = getelementptr %"compiler/token:Token", ptr %t525, i32 0, i32 3
  %t527 = load i32, ptr %t526, !tbaa !23
  %t529 = sext i32 %t527 to i64
  store i64 %t529, ptr %l264, !tbaa !24
  %t530 = load { i64, ptr }, ptr %l256, !tbaa !27
  %t531 = extractvalue { i64, ptr } %t530, 0
  store i64 %t531, ptr %l265, !tbaa !24
  %t532 = load i64, ptr %l260, !tbaa !24
  %t533 = icmp sge i64 %t532, 0
  br i1 %t533, label %bb116, label %bb117
bb115:
  br label %bb130
bb116:
  %t535 = load i64, ptr %l260, !tbaa !24
  %t536 = load i64, ptr %l264, !tbaa !24
  %t537 = icmp sle i64 %t535, %t536
  br i1 %t537, label %bb118, label %bb119
bb117:
  call void @__olang_check_failed(ptr @olang_loc_f328ac53cd348991_ee2d20c1cf12bb4d)
  unreachable
bb118:
  %t539 = load i64, ptr %l264, !tbaa !24
  %t540 = load i64, ptr %l265, !tbaa !24
  %t541 = icmp sle i64 %t539, %t540
  br i1 %t541, label %bb120, label %bb121
bb119:
  call void @__olang_check_failed(ptr @olang_loc_f328ac53cd348991_ee2d20c1cf12bb4d)
  unreachable
bb120:
  %t543 = getelementptr { i64, ptr }, ptr %l256, i32 0, i32 1
  %t544 = load ptr, ptr %t543, !tbaa !27
  %t545 = load i64, ptr %l260, !tbaa !24
  %t546 = load i64, ptr %l264, !tbaa !24
  %t547 = getelementptr i8, ptr %t544, i64 %t545
  %t548 = sub i64 %t546, %t545
  %t549 = insertvalue { i64, ptr } undef, i64 %t548, 0
  %t550 = insertvalue { i64, ptr } %t549, ptr %t547, 1
  %t552 = call { i64, ptr } @compiler_2fscan_2eLiteralText(ptr %s0, ptr %s0, { i64, ptr } %t550)
  store { i64, ptr } %t552, ptr %l270
  br label %bb122
bb121:
  call void @__olang_check_failed(ptr @olang_loc_f328ac53cd348991_ee2d20c1cf12bb4d)
  unreachable
bb122:
  %t553 = load { i64, ptr }, ptr %l270, !tbaa !27
  store { i64, ptr } %t553, ptr %l27, !tbaa !27
  %t554 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t554, ptr %l271, !tbaa !27
  %t555 = load { i64, ptr }, ptr %l271, !tbaa !27
  %t556 = extractvalue { i64, ptr } %t555, 1
  %t557 = call ptr @__olang_scope_of(ptr %t556, ptr null)
  %t558 = call ptr @__olang_scope_hold(ptr %t557)
  %t559 = ptrtoint ptr %t558 to i64
  %t561 = inttoptr i64 %t559 to ptr
  %t562 = load { i64, ptr }, ptr %l271, !tbaa !27
  %t563 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t561, ptr %s15, { i64, ptr } %t562, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d43, i32 0, i32 1) })
  store i1 %t563, ptr %l273
  br label %bb123
bb123:
  %t564 = load i1, ptr %l273, !tbaa !21
  br i1 %t564, label %bb124, label %bb125
bb124:
  store %olang.scope zeroinitializer, ptr %s16
  %t565 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t567 = call { i64, ptr } @std_2ffilepath_2eBase(ptr %s0, ptr %s16, { i64, ptr } %t565)
  store { i64, ptr } %t567, ptr %l275
  br label %bb126
bb125:
  br label %bb127
bb126:
  %t568 = load { i64, ptr }, ptr %l275, !tbaa !27
  %t569 = extractvalue { i64, ptr } %t568, 1
  %t570 = extractvalue { i64, ptr } %t568, 0
  %t571 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t570)
  call void @olang_textcopy(ptr %t571, ptr %t569, i64 %t570)
  %t572 = insertvalue { i64, ptr } undef, i64 %t570, 0
  %t573 = insertvalue { i64, ptr } %t572, ptr %t571, 1
  store { i64, ptr } %t573, ptr %l26, !tbaa !27
  call void @__olang_scope_close(ptr %s16)
  br label %bb127
bb127:
  %t576 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t576, ptr %l279, !tbaa !27
  %t577 = load { i64, ptr }, ptr %l279, !tbaa !27
  %t578 = extractvalue { i64, ptr } %t577, 1
  %t579 = call ptr @__olang_scope_of(ptr %t578, ptr null)
  %t580 = call ptr @__olang_scope_hold(ptr %t579)
  %t581 = ptrtoint ptr %t580 to i64
  %t583 = inttoptr i64 %t581 to ptr
  %t585 = load { i64, ptr }, ptr %l279, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %t583, ptr %l13, { i64, ptr } %t585)
  br label %bb128
bb128:
  %t586 = load { i64, ptr }, ptr %l27, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l14, { i64, ptr } %t586)
  br label %bb129
bb129:
  call void @__olang_scope_close(ptr %s15)
  br label %bb130
bb130:
  br label %bb131
bb131:
  br label %bb132
bb132:
  %t589 = load i64, ptr %l21, !tbaa !24
  %t592 = add i64 %t589, 1
  store i64 %t592, ptr %l21, !tbaa !24
  br label %bb44
bb133:
  %t594 = load ptr, ptr %l0, !tbaa !29
  %t596 = getelementptr %"compiler/fmt:loader", ptr %t594, i32 0, i32 2
  store ptr %t596, ptr %l287, !tbaa !29
  %t597 = call ptr @__olang_scope_hold(ptr %v0)
  %t598 = ptrtoint ptr %t597 to i64
  store i64 %t598, ptr %l288, !tbaa !24
  %t599 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t599, label %bb134, label %bb135
bb134:
  %t601 = call ptr @__olang_region_make(ptr %v0)
  %t602 = ptrtoint ptr %t601 to i64
  store i64 %t602, ptr %l288, !tbaa !24
  br label %bb135
bb135:
  %t603 = load i64, ptr %l288
  %t604 = inttoptr i64 %t603 to ptr
  %t606 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %t604, ptr %l12)
  store { i64, ptr } %t606, ptr %l291
  br label %bb136
bb136:
  %t607 = load { i64, ptr }, ptr %l291, !tbaa !27
  %t608 = load ptr, ptr %l287, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t608, { i64, ptr } %t607)
  br label %bb137
bb137:
  store i64 0, ptr %l28, !tbaa !24
  %t611 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l13)
  store i64 %t611, ptr %l294
  br label %bb138
bb138:
  %t612 = load i64, ptr %l294, !tbaa !24
  store i64 %t612, ptr %l29, !tbaa !24
  store i64 1, ptr %l30, !tbaa !24
  %t613 = load i64, ptr %l29, !tbaa !24
  %t614 = load i64, ptr %l28, !tbaa !24
  %t617 = icmp sgt i64 %t613, %t614
  br i1 %t617, label %bb139, label %bb140
bb139:
  %t619 = load i64, ptr %l30, !tbaa !24
  %t621 = icmp sgt i64 %t619, 0
  br i1 %t621, label %bb141, label %bb142
bb140:
  store i64 0, ptr %l298, !tbaa !24
  br label %bb144
bb141:
  %t623 = load i64, ptr %l29, !tbaa !24
  %t624 = load i64, ptr %l28, !tbaa !24
  %t627 = sub i64 %t623, %t624
  %t628 = load i64, ptr %l30, !tbaa !24
  %t631 = add i64 %t627, %t628
  %t633 = sub i64 %t631, 1
  %t634 = load i64, ptr %l30, !tbaa !24
  %t637 = sdiv i64 %t633, %t634
  store i64 %t637, ptr %l301, !tbaa !24
  br label %bb143
bb142:
  store i64 0, ptr %l301, !tbaa !24
  br label %bb143
bb143:
  %t639 = load i64, ptr %l301, !tbaa !24
  store i64 %t639, ptr %l298, !tbaa !24
  br label %bb144
bb144:
  %t640 = load i64, ptr %l298, !tbaa !24
  store i64 %t640, ptr %l31, !tbaa !24
  store i64 0, ptr %l32, !tbaa !24
  br label %bb145
bb145:
  store %olang.scope zeroinitializer, ptr %s20
  %t641 = load i64, ptr %l32, !tbaa !24
  %t642 = load i64, ptr %l31, !tbaa !24
  %t645 = icmp slt i64 %t641, %t642
  %t647 = xor i1 %t645, true
  br i1 %t647, label %bb146, label %bb147
bb146:
  call void @__olang_scope_close(ptr %s20)
  br label %bb163
bb147:
  br label %bb148
bb148:
  %t649 = load i64, ptr %l28, !tbaa !24
  %t650 = load i64, ptr %l32, !tbaa !24
  %t651 = load i64, ptr %l30, !tbaa !24
  %t654 = mul i64 %t650, %t651
  %t657 = add i64 %t649, %t654
  store i64 %t657, ptr %l33, !tbaa !24
  %t659 = load ptr, ptr %l0, !tbaa !29
  store ptr %t659, ptr %l319, !tbaa !29
  %t660 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t660, ptr %l320, !tbaa !27
  %t661 = load i64, ptr %l33, !tbaa !24
  %t664 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l14, i64 %t661)
  store { i64, ptr } %t664, ptr %l323
  br label %bb149
bb149:
  %t665 = load ptr, ptr %l319, !tbaa !29
  %t666 = load { i64, ptr }, ptr %l320, !tbaa !27
  %t667 = load { i64, ptr }, ptr %l323, !tbaa !27
  %t668 = call { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aloader_2etarget(ptr %v0, ptr %v0, ptr %s0, ptr %s20, ptr %t665, { i64, ptr } %t666, { i64, ptr } %t667)
  store { i64, ptr } %t668, ptr %l324
  br label %bb150
bb150:
  %t669 = load { i64, ptr }, ptr %l324, !tbaa !27
  store { i64, ptr } %t669, ptr %l34, !tbaa !27
  store i64 -1, ptr %l35, !tbaa !24
  %t670 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t672 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s20, ptr %s20, { i64, ptr } %t670, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d44, i32 0, i32 1) })
  store i1 %t672, ptr %l326
  br label %bb151
bb151:
  %t673 = load i1, ptr %l326, !tbaa !21
  %t674 = xor i1 %t673, true
  br i1 %t674, label %bb152, label %bb153
bb152:
  %t676 = load ptr, ptr %l0, !tbaa !29
  %t677 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t680 = call i64 @compiler_2ffmt_2ecompiler_2ffmt_3aloader_2eload(ptr %v0, ptr %s20, ptr %t676, { i64, ptr } %t677)
  store i64 %t680, ptr %l330
  br label %bb154
bb153:
  br label %bb155
bb154:
  %t681 = load i64, ptr %l330, !tbaa !24
  store i64 %t681, ptr %l35, !tbaa !24
  br label %bb155
bb155:
  %t682 = load ptr, ptr %l0, !tbaa !29
  %t684 = getelementptr %"compiler/fmt:loader", ptr %t682, i32 0, i32 3
  %t685 = load i64, ptr %l11, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t684, i64 %t685)
  br label %bb156
bb156:
  %t688 = load ptr, ptr %l0, !tbaa !29
  %t690 = getelementptr %"compiler/fmt:loader", ptr %t688, i32 0, i32 4
  store ptr %t690, ptr %l335, !tbaa !29
  %t691 = call ptr @__olang_scope_hold(ptr %v0)
  %t692 = ptrtoint ptr %t691 to i64
  store i64 %t692, ptr %l336, !tbaa !24
  %t693 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t693, label %bb157, label %bb158
bb157:
  %t695 = call ptr @__olang_region_make(ptr %v0)
  %t696 = ptrtoint ptr %t695 to i64
  store i64 %t696, ptr %l336, !tbaa !24
  br label %bb158
bb158:
  %t697 = load i64, ptr %l33, !tbaa !24
  %t700 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s20, ptr %l13, i64 %t697)
  store { i64, ptr } %t700, ptr %l340
  br label %bb159
bb159:
  %t701 = load { i64, ptr }, ptr %l340, !tbaa !27
  %t702 = extractvalue { i64, ptr } %t701, 1
  %t703 = extractvalue { i64, ptr } %t701, 0
  %t704 = load i64, ptr %l336
  %t705 = inttoptr i64 %t704 to ptr
  %t706 = call ptr @__olang_held_alloc(ptr %t705, i64 %t703)
  call void @olang_textcopy(ptr %t706, ptr %t702, i64 %t703)
  %t707 = insertvalue { i64, ptr } undef, i64 %t703, 0
  %t708 = insertvalue { i64, ptr } %t707, ptr %t706, 1
  %t710 = load ptr, ptr %l335, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t710, { i64, ptr } %t708)
  br label %bb160
bb160:
  %t712 = load ptr, ptr %l0, !tbaa !29
  %t714 = getelementptr %"compiler/fmt:loader", ptr %t712, i32 0, i32 5
  %t715 = load i64, ptr %l35, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t714, i64 %t715)
  br label %bb161
bb161:
  call void @__olang_scope_close(ptr %s20)
  br label %bb162
bb162:
  %t718 = load i64, ptr %l32, !tbaa !24
  %t721 = add i64 %t718, 1
  store i64 %t721, ptr %l32, !tbaa !24
  br label %bb145
bb163:
  %t723 = load i64, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t723, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffmt_2ecompiler_2ffmt_3aloader_2eoracle(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l28 = alloca i1
  %l30 = alloca i1
  %l31 = alloca { i64, ptr }
  %l33 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  store ptr %t2, ptr %l10, !tbaa !29
  %t3 = load ptr, ptr %l2, !tbaa !29
  store ptr %t3, ptr %l11, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/fmt:loader", ptr %t4, i32 0, i32 2
  %t7 = load i64, ptr %l3, !tbaa !24
  %t10 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t6, i64 %t7)
  store { i64, ptr } %t10, ptr %l15
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l9, !tbaa !29
  %t12 = load ptr, ptr %l10, !tbaa !29
  %t13 = load ptr, ptr %l11, !tbaa !29
  %t14 = load { i64, ptr }, ptr %l15, !tbaa !27
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aloader_2eaddNames(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %v0, ptr %t11, ptr %t12, ptr %t13, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d45, i32 0, i32 1) }, { i64, ptr } %t14)
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v3, ptr %s1, ptr %s1, { i64, ptr } %a4, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) })
  store { i64, ptr } %t17, ptr %l17
  br label %bb3
bb3:
  %t18 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t18, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t19 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 0
  store i64 %t21, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t23 = load i64, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l7, !tbaa !24
  %t27 = icmp slt i64 %t23, %t24
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb6:
  br label %bb7
bb7:
  %t31 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t31, ptr %l24, !tbaa !27
  %t32 = load i64, ptr %l6, !tbaa !24
  %t34 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr { i64, ptr }, ptr %t35, i64 %t32
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !37
  store { i64, ptr } %t37, ptr %l8, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t41 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s2, { i64, ptr } %t39, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d47, i32 0, i32 1) })
  store i1 %t41, ptr %l28
  br label %bb8
bb8:
  %t42 = load i1, ptr %l28, !tbaa !21
  %t43 = xor i1 %t42, true
  br i1 %t43, label %bb9, label %bb10
bb9:
  %t45 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t45, ptr %l31, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr i8, ptr %t47, i64 0
  %t49 = load i8, ptr %t48, !tbaa !32
  %t51 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t49)
  store i1 %t51, ptr %l33
  br label %bb11
bb10:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb12
bb11:
  %t52 = load i1, ptr %l33, !tbaa !21
  store i1 %t52, ptr %l30, !tbaa !21
  br label %bb12
bb12:
  %t53 = load i1, ptr %l30, !tbaa !21
  br i1 %t53, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t55 = load ptr, ptr %l2, !tbaa !29
  %t56 = load { i64, ptr }, ptr %l8, !tbaa !27
  call void @compiler_2fparse_2ecompiler_2fparse_3aOracle_2eAdd(ptr %v1, ptr %v2, ptr %s3, ptr %s1, ptr %t54, ptr %t55, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d48, i32 0, i32 1) }, { i64, ptr } %t56)
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  %t60 = load i64, ptr %l6, !tbaa !24
  %t63 = add i64 %t60, 1
  store i64 %t63, ptr %l6, !tbaa !24
  br label %bb4
bb18:
  call void @__olang_scope_close(ptr %s1)
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t66 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aOracle_2eAdd(ptr %v1, ptr %v2, ptr %s0, ptr %s0, ptr %t65, ptr %t66, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d49, i32 0, i32 1) }, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d50, i32 0, i32 1) })
  br label %bb19
bb19:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t71 = load ptr, ptr %l2, !tbaa !29
  %t72 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2ffmt_2ecompiler_2ffmt_3aloader_2echains(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t69, ptr %t70, ptr %t71, i64 %t72, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d51, i32 0, i32 1) }, i64 0)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aloader_2eprelude(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca [2 x { i64, ptr }]
  %l3 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca [2 x { i64, ptr }]
  %l10 = alloca i64
  %l11 = alloca %"std/prelude/text:StringBuilder"
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i32
  %l24 = alloca i1
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l42 = alloca i1
  %l44 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l52 = alloca i64
  %l55 = alloca ptr
  %l59 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l67 = alloca i64
  %l68 = alloca i64
  %l77 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l11
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 32)
  br label %bb2
bb2:
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/fmt:loader", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  %t9 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t7, 0
  %t10 = insertvalue [2 x { i64, ptr }] %t9, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  store [2 x { i64, ptr }] %t10, ptr %l2
  %t13 = insertvalue { i64, ptr } undef, i64 2, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %l2, 1
  %t16 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, { i64, ptr } %t14)
  store { i64, ptr } %t16, ptr %l18
  br label %bb3
bb3:
  %t17 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t17, ptr %l3, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t20 = call { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %s0, ptr %s0, { i64, ptr } %t18)
  %t21 = extractvalue { i32, { i64, ptr } } %t20, 1
  %t22 = extractvalue { i32, { i64, ptr } } %t20, 0
  store i32 %t22, ptr %l22
  %t23 = icmp ne i32 %t22, 0
  br i1 %t23, label %bb5, label %ok.24, !prof !99
ok.24:
  store { i64, ptr } %t21, ptr %l21
  br label %bb4
bb4:
  %t25 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t25, ptr %l19, !tbaa !27
  br label %bb9
bb5:
  %t26 = load i32, ptr %l22, !tbaa !23
  %t27 = ashr i32 %t26, 16
  %t29 = icmp eq i32 %t27, 1
  store i1 %t29, ptr %l24, !tbaa !21
  %t30 = load i32, ptr %l22, !tbaa !23
  %t31 = ashr i32 %t30, 16
  %t33 = icmp eq i32 %t31, 1
  br i1 %t33, label %bb6, label %bb7
bb6:
  call void @__olang_errpay_pop()
  br label %bb7
bb7:
  br label %bb8
bb8:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d53, i32 0, i32 1) }, ptr %l27, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t35, ptr %l28, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 0
  store i64 %t37, ptr %l29, !tbaa !24
  %t38 = load i64, ptr %l29, !tbaa !24
  %t39 = mul i64 %t38, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t39)
  %t41 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  store { i64, ptr } %t42, ptr %l30, !tbaa !27
  %t43 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = load i64, ptr %l29, !tbaa !24
  %t48 = mul i64 %t47, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t44, ptr %t46, i64 %t48, i1 false)
  %t49 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t49, ptr %l28, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t50 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t50, ptr %rv
  br label %ret
bb9:
  %t51 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t51, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t54 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t54, 0
  store i64 %t56, ptr %l7, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t58 = load i64, ptr %l6, !tbaa !24
  %t59 = load i64, ptr %l7, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb33
bb12:
  br label %bb13
bb13:
  %t66 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t66, ptr %l38, !tbaa !27
  %t67 = load i64, ptr %l6, !tbaa !24
  %t69 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr { i64, ptr }, ptr %t70, i64 %t67
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !37
  store { i64, ptr } %t72, ptr %l8, !tbaa !27
  %t74 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t76 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s0, ptr %s3, { i64, ptr } %t74, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d54, i32 0, i32 1) })
  store i1 %t76, ptr %l42
  br label %bb14
bb14:
  %t77 = load i1, ptr %l42, !tbaa !21
  %t78 = xor i1 %t77, true
  br i1 %t78, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb32
bb16:
  br label %bb17
bb17:
  %t80 = load ptr, ptr %l0, !tbaa !29
  store ptr %t80, ptr %l44, !tbaa !29
  %t81 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t82 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t84 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t81, 0
  %t86 = insertvalue [2 x { i64, ptr }] %t84, { i64, ptr } %t82, 1
  store [2 x { i64, ptr }] %t86, ptr %l9
  %t89 = insertvalue { i64, ptr } undef, i64 2, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %l9, 1
  %t92 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s3, ptr %s3, { i64, ptr } %t90)
  store { i64, ptr } %t92, ptr %l50
  br label %bb18
bb18:
  %t93 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t93, 0
  %t95 = extractvalue { i64, ptr } %t93, 1
  %t96 = mul i64 %t94, 1
  %t97 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t96)
  call void @llvm.memcpy.p0.p0.i64(ptr %t97, ptr %t95, i64 %t96, i1 false)
  %t98 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t97, 1
  %t100 = load ptr, ptr %l44, !tbaa !29
  %t102 = call i64 @compiler_2ffmt_2ecompiler_2ffmt_3aloader_2eload(ptr %v0, ptr %s3, ptr %t100, { i64, ptr } %t99)
  store i64 %t102, ptr %l52
  br label %bb19
bb19:
  %t103 = load i64, ptr %l52, !tbaa !24
  store i64 %t103, ptr %l10, !tbaa !24
  %t104 = load i64, ptr %l10, !tbaa !24
  %t106 = icmp sge i64 %t104, 0
  br i1 %t106, label %bb20, label %bb21
bb20:
  store ptr %l1, ptr %l55, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/fmt:loader", ptr %t108, i32 0, i32 2
  %t111 = load i64, ptr %l10, !tbaa !24
  %t114 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t110, i64 %t111)
  store { i64, ptr } %t114, ptr %l59
  br label %bb22
bb21:
  br label %bb31
bb22:
  %t115 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t115, ptr %l60, !tbaa !27
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/fmt:loader", ptr %t116, i32 0, i32 2
  %t119 = load i64, ptr %l10, !tbaa !24
  %t122 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t118, i64 %t119)
  store { i64, ptr } %t122, ptr %l64
  br label %bb23
bb23:
  %t123 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t123, 0
  store i64 %t126, ptr %l67, !tbaa !24
  %t127 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t127, 0
  store i64 %t128, ptr %l68, !tbaa !24
  %t129 = icmp sge i64 1, 0
  br i1 %t129, label %bb24, label %bb25
bb24:
  %t131 = load i64, ptr %l67, !tbaa !24
  %t132 = icmp sle i64 1, %t131
  br i1 %t132, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_1c96c695fa9cb803_60711cea71b32ee7)
  unreachable
bb26:
  %t134 = load i64, ptr %l67, !tbaa !24
  %t135 = load i64, ptr %l68, !tbaa !24
  %t136 = icmp sle i64 %t134, %t135
  br i1 %t136, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_1c96c695fa9cb803_60711cea71b32ee7)
  unreachable
bb28:
  %t138 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !27
  %t140 = load i64, ptr %l67, !tbaa !24
  %t141 = getelementptr i8, ptr %t139, i64 1
  %t142 = sub i64 %t140, 1
  %t143 = insertvalue { i64, ptr } undef, i64 %t142, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr %t141, 1
  %t145 = load ptr, ptr %l55, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t145, { i64, ptr } %t144)
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_1c96c695fa9cb803_60711cea71b32ee7)
  unreachable
bb30:
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s3)
  br label %bb32
bb32:
  %t147 = load i64, ptr %l6, !tbaa !24
  %t150 = add i64 %t147, 1
  store i64 %t150, ptr %l6, !tbaa !24
  br label %bb10
bb33:
  %t153 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t153, ptr %l77
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s0)
  %t154 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t154, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ffmt_2ecompiler_2ffmt_3aloader_2etarget(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca [2 x { i64, ptr }]
  %l6 = alloca [2 x { i64, ptr }]
  %l8 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca i1
  %l26 = alloca i1
  %l28 = alloca i1
  %l30 = alloca i1
  %l32 = alloca i1
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca { i64, ptr }
  %l39 = alloca i1
  %l41 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca i64
  %l54 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t1, ptr %l3, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v2, { i64, ptr } %t3, i8 47)
  %t7 = extractvalue { i32, i64 } %t6, 1
  %t8 = extractvalue { i32, i64 } %t6, 0
  store i32 %t8, ptr %l12
  %t9 = icmp ne i32 %t8, 0
  br i1 %t9, label %bb2, label %ok.10, !prof !99
ok.10:
  store i64 %t7, ptr %l11
  br label %bb1
bb1:
  %t11 = load i64, ptr %l11, !tbaa !24
  store i64 %t11, ptr %l8, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l8, !tbaa !24
  br label %bb4
bb4:
  %t12 = load i64, ptr %l8, !tbaa !24
  store i64 %t12, ptr %l4, !tbaa !24
  %t13 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp sge i64 %t13, 0
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t17, ptr %l15, !tbaa !27
  %t18 = load i64, ptr %l4, !tbaa !24
  store i64 %t18, ptr %l16, !tbaa !24
  %t19 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 0
  store i64 %t20, ptr %l17, !tbaa !24
  %t21 = icmp sge i64 0, 0
  br i1 %t21, label %bb7, label %bb8
bb6:
  br label %bb13
bb7:
  %t23 = load i64, ptr %l16, !tbaa !24
  %t24 = icmp sle i64 0, %t23
  br i1 %t24, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_3df0b8839dc54179_133a546f9cf2d20d)
  unreachable
bb9:
  %t26 = load i64, ptr %l16, !tbaa !24
  %t27 = load i64, ptr %l17, !tbaa !24
  %t28 = icmp sle i64 %t26, %t27
  br i1 %t28, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_3df0b8839dc54179_133a546f9cf2d20d)
  unreachable
bb11:
  %t30 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = load i64, ptr %l16, !tbaa !24
  %t33 = getelementptr i8, ptr %t31, i64 0
  %t34 = sub i64 %t32, 0
  %t35 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t33, 1
  store { i64, ptr } %t36, ptr %l3, !tbaa !27
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_3df0b8839dc54179_133a546f9cf2d20d)
  unreachable
bb13:
  %t38 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d55, i32 0, i32 1) }, ptr %l24, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t42 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v2, ptr %s0, { i64, ptr } %t38, { i64, ptr } %t41)
  store i1 %t42, ptr %l25
  br label %bb14
bb14:
  %t43 = load i1, ptr %l25, !tbaa !21
  br i1 %t43, label %bb15, label %bb16
bb15:
  %t44 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t46 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t44, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) })
  store i1 %t46, ptr %l28
  br label %bb17
bb16:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb18
bb17:
  %t47 = load i1, ptr %l28, !tbaa !21
  %t48 = xor i1 %t47, true
  store i1 %t48, ptr %l26, !tbaa !21
  br label %bb18
bb18:
  %t50 = load i1, ptr %l26, !tbaa !21
  br i1 %t50, label %bb19, label %bb20
bb19:
  %t51 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t53 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t51, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d57, i32 0, i32 1) })
  store i1 %t53, ptr %l32
  br label %bb21
bb20:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb22
bb21:
  %t54 = load i1, ptr %l32, !tbaa !21
  %t55 = xor i1 %t54, true
  store i1 %t55, ptr %l30, !tbaa !21
  br label %bb22
bb22:
  %t57 = load i1, ptr %l30, !tbaa !21
  br i1 %t57, label %bb23, label %bb24
bb23:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d58, i32 0, i32 1) }, ptr %l34, !tbaa !27
  %t58 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t58, ptr %l35, !tbaa !27
  %t59 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t59, 0
  store i64 %t60, ptr %l36, !tbaa !24
  %t61 = load i64, ptr %l36, !tbaa !24
  %t62 = mul i64 %t61, 1
  %t63 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t62)
  %t64 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  store { i64, ptr } %t65, ptr %l37, !tbaa !27
  %t66 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = load i64, ptr %l36, !tbaa !24
  %t71 = mul i64 %t70, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t67, ptr %t69, i64 %t71, i1 false)
  %t72 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t72, ptr %l35, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t73 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t73, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t74 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t76 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v2, ptr %s0, { i64, ptr } %t74, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d59, i32 0, i32 1) })
  store i1 %t76, ptr %l39
  br label %bb26
bb26:
  %t77 = load i1, ptr %l39, !tbaa !21
  br i1 %t77, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s3
  %t80 = getelementptr %"compiler/fmt:loader", ptr %a0, i32 0, i32 0
  %t81 = load { i64, ptr }, ptr %t80, !tbaa !27
  store { i64, ptr } %t81, ptr %l41, !tbaa !27
  %t82 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t82, ptr %l42, !tbaa !27
  %t83 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t83, 0
  store i64 %t86, ptr %l45, !tbaa !24
  %t87 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 0
  store i64 %t88, ptr %l46, !tbaa !24
  %t89 = icmp sge i64 4, 0
  br i1 %t89, label %bb29, label %bb30
bb28:
  br label %bb36
bb29:
  %t91 = load i64, ptr %l45, !tbaa !24
  %t92 = icmp sle i64 4, %t91
  br i1 %t92, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_9121eab1d44cad4c_7d1c1b769798e530)
  unreachable
bb31:
  %t94 = load i64, ptr %l45, !tbaa !24
  %t95 = load i64, ptr %l46, !tbaa !24
  %t96 = icmp sle i64 %t94, %t95
  br i1 %t96, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @olang_loc_9121eab1d44cad4c_7d1c1b769798e530)
  unreachable
bb33:
  %t98 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = load i64, ptr %l45, !tbaa !24
  %t101 = getelementptr i8, ptr %t99, i64 4
  %t102 = sub i64 %t100, 4
  %t103 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t101, 1
  %t105 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t106 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t105, 0
  %t108 = insertvalue [2 x { i64, ptr }] %t106, { i64, ptr } %t104, 1
  store [2 x { i64, ptr }] %t108, ptr %l5
  %t111 = insertvalue { i64, ptr } undef, i64 2, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %l5, 1
  %t114 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s3, ptr %s3, { i64, ptr } %t112)
  store { i64, ptr } %t114, ptr %l54
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_9121eab1d44cad4c_7d1c1b769798e530)
  unreachable
bb35:
  %t115 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t115, 1
  %t117 = extractvalue { i64, ptr } %t115, 0
  %t118 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t119 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  %t120 = add i64 %t117, %t119
  %t121 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t120)
  call void @olang_textcopy(ptr %t121, ptr %t116, i64 %t117)
  %t122 = getelementptr i8, ptr %t121, i64 %t117
  call void @olang_textcopy(ptr %t122, ptr %t118, i64 %t119)
  %t123 = insertvalue { i64, ptr } undef, i64 %t120, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t121, 1
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t124, ptr %rv
  br label %ret
bb36:
  %t128 = call { i64, ptr } @std_2ffilepath_2eDir(ptr %v1, ptr %s0, { i64, ptr } %a1)
  store { i64, ptr } %t128, ptr %l57
  br label %bb37
bb37:
  %t129 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t130 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t131 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t130, 0
  %t133 = insertvalue [2 x { i64, ptr }] %t131, { i64, ptr } %t129, 1
  store [2 x { i64, ptr }] %t133, ptr %l6
  %t136 = insertvalue { i64, ptr } undef, i64 2, 0
  %t137 = insertvalue { i64, ptr } %t136, ptr %l6, 1
  %t139 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, { i64, ptr } %t137)
  store { i64, ptr } %t139, ptr %l62
  br label %bb38
bb38:
  %t140 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t140, 1
  %t142 = extractvalue { i64, ptr } %t140, 0
  %t143 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d61, i32 0, i32 1) }, 1
  %t144 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d61, i32 0, i32 1) }, 0
  %t145 = add i64 %t142, %t144
  %t146 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t145)
  call void @olang_textcopy(ptr %t146, ptr %t141, i64 %t142)
  %t147 = getelementptr i8, ptr %t146, i64 %t142
  call void @olang_textcopy(ptr %t147, ptr %t143, i64 %t144)
  %t148 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t146, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t149, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2ffmt_2elineStartOf(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l2 = alloca i64
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l2, !tbaa !24
  %t5 = icmp sgt i64 %t3, 0
  br i1 %t5, label %bb2, label %bb3
bb2:
  store { i64, ptr } %a0, ptr %l7, !tbaa !27
  %t8 = load i64, ptr %l2, !tbaa !24
  %t10 = sub i64 %t8, 1
  %t12 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr i8, ptr %t13, i64 %t10
  %t15 = load i8, ptr %t14, !tbaa !32
  %t17 = icmp ne i8 %t15, 10
  store i1 %t17, ptr %l6, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l6, !tbaa !21
  %t20 = xor i1 %t19, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb9
bb6:
  br label %bb7
bb7:
  %t22 = load i64, ptr %l2, !tbaa !24
  %t25 = sub i64 %t22, 1
  store i64 %t25, ptr %l2, !tbaa !24
  br label %bb8
bb8:
  br label %bb1
bb9:
  %t27 = load i64, ptr %l2, !tbaa !24
  store i64 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffmt_3aformatter_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca %"std/prelude/text:StringBuilder"
  %l23 = alloca i1
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i1
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l40 = alloca i64
  %l43 = alloca i64
  %l47 = alloca i64
  %l50 = alloca i64
  %l53 = alloca i64
  %l56 = alloca i64
  %l60 = alloca i64
  %l63 = alloca i64
  %l66 = alloca i64
  %l69 = alloca i64
  %l72 = alloca i64
  %l75 = alloca i64
  %l78 = alloca i64
  %l80 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l82 = alloca i64
  %l84 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l86 = alloca i64
  %l88 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l90 = alloca i64
  %l92 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l94 = alloca i64
  %l96 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l98 = alloca i64
  %l100 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l102 = alloca i64
  %l104 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l106 = alloca i64
  %l108 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l110 = alloca i64
  %l112 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l114 = alloca i64
  %l116 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l118 = alloca i64
  %l120 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l122 = alloca i64
  %l124 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l126 = alloca i64
  %l128 = alloca %"std/prelude/text:StringBuilder"
  %l130 = alloca i64
  %l133 = alloca i64
  %l137 = alloca i64
  %l139 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l141 = alloca i64
  %l143 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l145 = alloca %"compiler/fmt:formatter"
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t3, ptr %l3, !tbaa !27
  %t5 = call ptr @__olang_scope_hold(ptr %v2)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l40, !tbaa !24
  %t7 = load i1, ptr @olang_2esole_2ecompiler_2ffmt_3aformatter_2e2
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = call ptr @__olang_region_make(ptr %v2)
  %t10 = ptrtoint ptr %t9 to i64
  store i64 %t10, ptr %l40, !tbaa !24
  br label %bb2
bb2:
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l43, !tbaa !24
  %t14 = load i64, ptr %l43, !tbaa !24
  %t15 = icmp sge i64 %t14, 0
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load i64, ptr %l43, !tbaa !24
  %t18 = icmp sle i64 %t17, 1152921504606846975
  br i1 %t18, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_ce709d7b9ef8b1fc_3d0b2a4c89679e00)
  unreachable
bb5:
  %t20 = load i64, ptr %l43, !tbaa !24
  %t21 = mul i64 %t20, 8
  %t22 = load i64, ptr %l40
  %t23 = inttoptr i64 %t22 to ptr
  %t24 = call ptr @__olang_scope_alloc_zeroed(ptr %t23, i64 %t21)
  %t25 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  store { i64, ptr } %t26, ptr %l4, !tbaa !27
  %t28 = call ptr @__olang_scope_hold(ptr %v2)
  %t29 = ptrtoint ptr %t28 to i64
  store i64 %t29, ptr %l47, !tbaa !24
  %t30 = load i1, ptr @olang_2esole_2ecompiler_2ffmt_3aformatter_2e3
  br i1 %t30, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_ce709d7b9ef8b1fc_3d0b2a4c89679e00)
  unreachable
bb7:
  %t32 = call ptr @__olang_region_make(ptr %v2)
  %t33 = ptrtoint ptr %t32 to i64
  store i64 %t33, ptr %l47, !tbaa !24
  br label %bb8
bb8:
  %t34 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t34, 0
  store i64 %t36, ptr %l50, !tbaa !24
  %t37 = load i64, ptr %l50, !tbaa !24
  %t38 = icmp sge i64 %t37, 0
  br i1 %t38, label %bb9, label %bb10
bb9:
  %t40 = load i64, ptr %l50, !tbaa !24
  %t41 = mul i64 %t40, 1
  %t42 = load i64, ptr %l47
  %t43 = inttoptr i64 %t42 to ptr
  %t44 = call ptr @__olang_scope_alloc_zeroed(ptr %t43, i64 %t41)
  %t45 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t44, 1
  store { i64, ptr } %t46, ptr %l5, !tbaa !27
  %t48 = call ptr @__olang_scope_hold(ptr %v2)
  %t49 = ptrtoint ptr %t48 to i64
  store i64 %t49, ptr %l53, !tbaa !24
  %t50 = load i1, ptr @olang_2esole_2ecompiler_2ffmt_3aformatter_2e4
  br i1 %t50, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_d589fc983080be49_a3fac9ed8d21e52d)
  unreachable
bb11:
  %t52 = call ptr @__olang_region_make(ptr %v2)
  %t53 = ptrtoint ptr %t52 to i64
  store i64 %t53, ptr %l53, !tbaa !24
  br label %bb12
bb12:
  %t54 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t54, 0
  store i64 %t56, ptr %l56, !tbaa !24
  %t57 = load i64, ptr %l56, !tbaa !24
  %t58 = icmp sge i64 %t57, 0
  br i1 %t58, label %bb13, label %bb14
bb13:
  %t60 = load i64, ptr %l56, !tbaa !24
  %t61 = icmp sle i64 %t60, 1152921504606846975
  br i1 %t61, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_5014c5e33980418a_6c70c79ebb210b2e)
  unreachable
bb15:
  %t63 = load i64, ptr %l56, !tbaa !24
  %t64 = mul i64 %t63, 8
  %t65 = load i64, ptr %l53
  %t66 = inttoptr i64 %t65 to ptr
  %t67 = call ptr @__olang_scope_alloc_zeroed(ptr %t66, i64 %t64)
  %t68 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  store { i64, ptr } %t69, ptr %l6, !tbaa !27
  %t71 = call ptr @__olang_scope_hold(ptr %v2)
  %t72 = ptrtoint ptr %t71 to i64
  store i64 %t72, ptr %l60, !tbaa !24
  %t73 = load i1, ptr @olang_2esole_2ecompiler_2ffmt_3aformatter_2e5
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_5014c5e33980418a_6c70c79ebb210b2e)
  unreachable
bb17:
  %t75 = call ptr @__olang_region_make(ptr %v2)
  %t76 = ptrtoint ptr %t75 to i64
  store i64 %t76, ptr %l60, !tbaa !24
  br label %bb18
bb18:
  %t77 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t77, 0
  store i64 %t79, ptr %l63, !tbaa !24
  %t80 = load i64, ptr %l63, !tbaa !24
  %t81 = icmp sge i64 %t80, 0
  br i1 %t81, label %bb19, label %bb20
bb19:
  %t83 = load i64, ptr %l63, !tbaa !24
  %t84 = mul i64 %t83, 1
  %t85 = load i64, ptr %l60
  %t86 = inttoptr i64 %t85 to ptr
  %t87 = call ptr @__olang_scope_alloc_zeroed(ptr %t86, i64 %t84)
  %t88 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t87, 1
  store { i64, ptr } %t89, ptr %l7, !tbaa !27
  %t91 = call ptr @__olang_scope_hold(ptr %v2)
  %t92 = ptrtoint ptr %t91 to i64
  store i64 %t92, ptr %l66, !tbaa !24
  %t93 = load i1, ptr @olang_2esole_2ecompiler_2ffmt_3aformatter_2e6
  br i1 %t93, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_b2eb5d9479cf4f5f_182504dbd1c367a3)
  unreachable
bb21:
  %t95 = call ptr @__olang_region_make(ptr %v2)
  %t96 = ptrtoint ptr %t95 to i64
  store i64 %t96, ptr %l66, !tbaa !24
  br label %bb22
bb22:
  %t97 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t97, 0
  store i64 %t99, ptr %l69, !tbaa !24
  %t100 = load i64, ptr %l69, !tbaa !24
  %t101 = icmp sge i64 %t100, 0
  br i1 %t101, label %bb23, label %bb24
bb23:
  %t103 = load i64, ptr %l69, !tbaa !24
  %t104 = mul i64 %t103, 1
  %t105 = load i64, ptr %l66
  %t106 = inttoptr i64 %t105 to ptr
  %t107 = call ptr @__olang_scope_alloc_zeroed(ptr %t106, i64 %t104)
  %t108 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t107, 1
  store { i64, ptr } %t109, ptr %l8, !tbaa !27
  %t111 = call ptr @__olang_scope_hold(ptr %v2)
  %t112 = ptrtoint ptr %t111 to i64
  store i64 %t112, ptr %l72, !tbaa !24
  %t113 = load i1, ptr @olang_2esole_2ecompiler_2ffmt_3aformatter_2e7
  br i1 %t113, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_bfaf8ae940299f30_3213b1cd9190eecc)
  unreachable
bb25:
  %t115 = call ptr @__olang_region_make(ptr %v2)
  %t116 = ptrtoint ptr %t115 to i64
  store i64 %t116, ptr %l72, !tbaa !24
  br label %bb26
bb26:
  %t117 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t117, 0
  store i64 %t119, ptr %l75, !tbaa !24
  %t120 = load i64, ptr %l75, !tbaa !24
  %t121 = icmp sge i64 %t120, 0
  br i1 %t121, label %bb27, label %bb28
bb27:
  %t123 = load i64, ptr %l75, !tbaa !24
  %t124 = mul i64 %t123, 1
  %t125 = load i64, ptr %l72
  %t126 = inttoptr i64 %t125 to ptr
  %t127 = call ptr @__olang_scope_alloc_zeroed(ptr %t126, i64 %t124)
  %t128 = insertvalue { i64, ptr } undef, i64 %t123, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  store { i64, ptr } %t129, ptr %l9, !tbaa !27
  %t131 = call ptr @__olang_scope_hold(ptr %v2)
  %t132 = ptrtoint ptr %t131 to i64
  store i64 %t132, ptr %l78, !tbaa !24
  %t133 = load i1, ptr @olang_2esole_2ecompiler_2ffmt_3aformatter_2e8
  br i1 %t133, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_f8370207eae072dd_4bf9c30e1d6aa1d9)
  unreachable
bb29:
  %t135 = call ptr @__olang_region_make(ptr %v2)
  %t136 = ptrtoint ptr %t135 to i64
  store i64 %t136, ptr %l78, !tbaa !24
  br label %bb30
bb30:
  %t137 = load i64, ptr %l78
  %t138 = inttoptr i64 %t137 to ptr
  %t139 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t138, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t139, ptr %l80
  br label %bb31
bb31:
  %t140 = load i1, ptr @olang_2esole_2ecompiler_2ffmt_3aformatter_2e8
  br i1 %t140, label %bb32, label %bb33
bb32:
  %t142 = load i64, ptr %l78
  %t143 = inttoptr i64 %t142 to ptr
  %t144 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l80, i32 0, i32 0
  %t145 = load { i64, ptr }, ptr %t144
  %t146 = extractvalue { i64, ptr } %t145, 1
  %t147 = call ptr @__olang_region_or(ptr %t146, ptr null)
  %t148 = call ptr @__olang_region_home(ptr %t147)
  %t149 = icmp ne ptr %t148, null
  %t150 = select i1 %t149, ptr %t148, ptr null
  call void @__olang_region_settle_in(ptr %t143, ptr %t150)
  br label %bb33
bb33:
  %t151 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l80
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t151, ptr %l10
  %t152 = call ptr @__olang_scope_hold(ptr %v2)
  %t153 = ptrtoint ptr %t152 to i64
  store i64 %t153, ptr %l82, !tbaa !24
  %t154 = load i1, ptr @olang_2esole_2ecompiler_2ffmt_3aformatter_2e9
  br i1 %t154, label %bb34, label %bb35
bb34:
  %t156 = call ptr @__olang_region_make(ptr %v2)
  %t157 = ptrtoint ptr %t156 to i64
  store i64 %t157, ptr %l82, !tbaa !24
  br label %bb35
bb35:
  %t158 = load i64, ptr %l82
  %t159 = inttoptr i64 %t158 to ptr
  %t160 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %t159, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t160, ptr %l84
  br label %bb36
bb36:
  %t161 = load i1, ptr @olang_2esole_2ecompiler_2ffmt_3aformatter_2e9
  br i1 %t161, label %bb37, label %bb38
bb37:
  %t163 = load i64, ptr %l82
  %t164 = inttoptr i64 %t163 to ptr
  %t165 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l84, i32 0, i32 0
  %t166 = load { i64, ptr }, ptr %t165
  %t167 = extractvalue { i64, ptr } %t166, 1
  %t168 = call ptr @__olang_region_or(ptr %t167, ptr null)
  %t169 = call ptr @__olang_region_home(ptr %t168)
  %t170 = icmp ne ptr %t169, null
  %t171 = select i1 %t170, ptr %t169, ptr null
  call void @__olang_region_settle_in(ptr %t164, ptr %t171)
  br label %bb38
bb38:
  %t172 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l84
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t172, ptr %l11
  %t173 = call ptr @__olang_scope_hold(ptr %v2)
  %t174 = ptrtoint ptr %t173 to i64
  store i64 %t174, ptr %l86, !tbaa !24
  %t175 = load i1, ptr @olang_2esole_2ecompiler_2ffmt_3aformatter_2e10
  br i1 %t175, label %bb39, label %bb40
bb39:
  %t177 = call ptr @__olang_region_make(ptr %v2)
  %t178 = ptrtoint ptr %t177 to i64
  store i64 %t178, ptr %l86, !tbaa !24
  br label %bb40
bb40:
  %t179 = load i64, ptr %l86
  %t180 = inttoptr i64 %t179 to ptr
  %t181 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t180, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t181, ptr %l88
  br label %bb41
bb41:
  %t182 = load i1, ptr @olang_2esole_2ecompiler_2ffmt_3aformatter_2e10
  br i1 %t182, label %bb42, label %bb43
bb42:
  %t184 = load i64, ptr %l86
  %t185 = inttoptr i64 %t184 to ptr
  %t186 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l88, i32 0, i32 0
  %t187 = load { i64, ptr }, ptr %t186
  %t188 = extractvalue { i64, ptr } %t187, 1
  %t189 = call ptr @__olang_region_or(ptr %t188, ptr null)
  %t190 = call ptr @__olang_region_home(ptr %t189)
  %t191 = icmp ne ptr %t190, null
  %t192 = select i1 %t191, ptr %t190, ptr null
  call void @__olang_region_settle_in(ptr %t185, ptr %t192)
  br label %bb43
bb43:
  %t193 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l88
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t193, ptr %l12
  %t194 = call ptr @__olang_scope_hold(ptr %v2)
  %t195 = ptrtoint ptr %t194 to i64
  store i64 %t195, ptr %l90, !tbaa !24
  %t196 = load i1, ptr @olang_2esole_2ecompiler_2ffmt_3aformatter_2e11
  br i1 %t196, label %bb44, label %bb45
bb44:
  %t198 = call ptr @__olang_region_make(ptr %v2)
  %t199 = ptrtoint ptr %t198 to i64
  store i64 %t199, ptr %l90, !tbaa !24
  br label %bb45
bb45:
  %t200 = load i64, ptr %l90
  %t201 = inttoptr i64 %t200 to ptr
  %t202 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t201, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t202, ptr %l92
  br label %bb46
bb46:
  %t203 = load i1, ptr @olang_2esole_2ecompiler_2ffmt_3aformatter_2e11
  br i1 %t203, label %bb47, label %bb48
bb47:
  %t205 = load i64, ptr %l90
  %t206 = inttoptr i64 %t205 to ptr
  %t207 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l92, i32 0, i32 0
  %t208 = load { i64, ptr }, ptr %t207
  %t209 = extractvalue { i64, ptr } %t208, 1
  %t210 = call ptr @__olang_region_or(ptr %t209, ptr null)
  %t211 = call ptr @__olang_region_home(ptr %t210)
  %t212 = icmp ne ptr %t211, null
  %t213 = select i1 %t212, ptr %t211, ptr null
  call void @__olang_region_settle_in(ptr %t206, ptr %t213)
  br label %bb48
bb48:
  %t214 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l92
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t214, ptr %l13
  %t215 = call ptr @__olang_scope_hold(ptr %v2)
  %t216 = ptrtoint ptr %t215 to i64
  store i64 %t216, ptr %l94, !tbaa !24
  %t217 = load i1, ptr @olang_2esole_2ecompiler_2ffmt_3aformatter_2e12
  br i1 %t217, label %bb49, label %bb50
bb49:
  %t219 = call ptr @__olang_region_make(ptr %v2)
  %t220 = ptrtoint ptr %t219 to i64
  store i64 %t220, ptr %l94, !tbaa !24
  br label %bb50
bb50:
  %t221 = load i64, ptr %l94
  %t222 = inttoptr i64 %t221 to ptr
  %t223 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t222, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t223, ptr %l96
  br label %bb51
bb51:
  %t224 = load i1, ptr @olang_2esole_2ecompiler_2ffmt_3aformatter_2e12
  br i1 %t224, label %bb52, label %bb53
bb52:
  %t226 = load i64, ptr %l94
  %t227 = inttoptr i64 %t226 to ptr
  %t228 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l96, i32 0, i32 0
  %t229 = load { i64, ptr }, ptr %t228
  %t230 = extractvalue { i64, ptr } %t229, 1
  %t231 = call ptr @__olang_region_or(ptr %t230, ptr null)
  %t232 = call ptr @__olang_region_home(ptr %t231)
  %t233 = icmp ne ptr %t232, null
  %t234 = select i1 %t233, ptr %t232, ptr null
  call void @__olang_region_settle_in(ptr %t227, ptr %t234)
  br label %bb53
bb53:
  %t235 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l96
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t235, ptr %l14
  %t236 = call ptr @__olang_scope_hold(ptr %v2)
  %t237 = ptrtoint ptr %t236 to i64
  store i64 %t237, ptr %l98, !tbaa !24
  %t238 = load i1, ptr @olang_2esole_2ecompiler_2ffmt_3aformatter_2e13
  br i1 %t238, label %bb54, label %bb55
bb54:
  %t240 = call ptr @__olang_region_make(ptr %v2)
  %t241 = ptrtoint ptr %t240 to i64
  store i64 %t241, ptr %l98, !tbaa !24
  br label %bb55
bb55:
  %t242 = load i64, ptr %l98
  %t243 = inttoptr i64 %t242 to ptr
  %t244 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t243, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t244, ptr %l100
  br label %bb56
bb56:
  %t245 = load i1, ptr @olang_2esole_2ecompiler_2ffmt_3aformatter_2e13
  br i1 %t245, label %bb57, label %bb58
bb57:
  %t247 = load i64, ptr %l98
  %t248 = inttoptr i64 %t247 to ptr
  %t249 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l100, i32 0, i32 0
  %t250 = load { i64, ptr }, ptr %t249
  %t251 = extractvalue { i64, ptr } %t250, 1
  %t252 = call ptr @__olang_region_or(ptr %t251, ptr null)
  %t253 = call ptr @__olang_region_home(ptr %t252)
  %t254 = icmp ne ptr %t253, null
  %t255 = select i1 %t254, ptr %t253, ptr null
  call void @__olang_region_settle_in(ptr %t248, ptr %t255)
  br label %bb58
bb58:
  %t256 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l100
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t256, ptr %l15
  %t257 = call ptr @__olang_scope_hold(ptr %v2)
  %t258 = ptrtoint ptr %t257 to i64
  store i64 %t258, ptr %l102, !tbaa !24
  %t259 = load i1, ptr @olang_2esole_2ecompiler_2ffmt_3aformatter_2e14
  br i1 %t259, label %bb59, label %bb60
bb59:
  %t261 = call ptr @__olang_region_make(ptr %v2)
  %t262 = ptrtoint ptr %t261 to i64
  store i64 %t262, ptr %l102, !tbaa !24
  br label %bb60
bb60:
  %t263 = load i64, ptr %l102
  %t264 = inttoptr i64 %t263 to ptr
  %t265 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t264, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t265, ptr %l104
  br label %bb61
bb61:
  %t266 = load i1, ptr @olang_2esole_2ecompiler_2ffmt_3aformatter_2e14
  br i1 %t266, label %bb62, label %bb63
bb62:
  %t268 = load i64, ptr %l102
  %t269 = inttoptr i64 %t268 to ptr
  %t270 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l104, i32 0, i32 0
  %t271 = load { i64, ptr }, ptr %t270
  %t272 = extractvalue { i64, ptr } %t271, 1
  %t273 = call ptr @__olang_region_or(ptr %t272, ptr null)
  %t274 = call ptr @__olang_region_home(ptr %t273)
  %t275 = icmp ne ptr %t274, null
  %t276 = select i1 %t275, ptr %t274, ptr null
  call void @__olang_region_settle_in(ptr %t269, ptr %t276)
  br label %bb63
bb63:
  %t277 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l104
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t277, ptr %l16
  %t278 = call ptr @__olang_scope_hold(ptr %v2)
  %t279 = ptrtoint ptr %t278 to i64
  store i64 %t279, ptr %l106, !tbaa !24
  %t280 = load i1, ptr @olang_2esole_2ecompiler_2ffmt_3aformatter_2e15
  br i1 %t280, label %bb64, label %bb65
bb64:
  %t282 = call ptr @__olang_region_make(ptr %v2)
  %t283 = ptrtoint ptr %t282 to i64
  store i64 %t283, ptr %l106, !tbaa !24
  br label %bb65
bb65:
  %t284 = load i64, ptr %l106
  %t285 = inttoptr i64 %t284 to ptr
  %t286 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t285, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t286, ptr %l108
  br label %bb66
bb66:
  %t287 = load i1, ptr @olang_2esole_2ecompiler_2ffmt_3aformatter_2e15
  br i1 %t287, label %bb67, label %bb68
bb67:
  %t289 = load i64, ptr %l106
  %t290 = inttoptr i64 %t289 to ptr
  %t291 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l108, i32 0, i32 0
  %t292 = load { i64, ptr }, ptr %t291
  %t293 = extractvalue { i64, ptr } %t292, 1
  %t294 = call ptr @__olang_region_or(ptr %t293, ptr null)
  %t295 = call ptr @__olang_region_home(ptr %t294)
  %t296 = icmp ne ptr %t295, null
  %t297 = select i1 %t296, ptr %t295, ptr null
  call void @__olang_region_settle_in(ptr %t290, ptr %t297)
  br label %bb68
bb68:
  %t298 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l108
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t298, ptr %l17
  %t299 = call ptr @__olang_scope_hold(ptr %v2)
  %t300 = ptrtoint ptr %t299 to i64
  store i64 %t300, ptr %l110, !tbaa !24
  %t301 = load i1, ptr @olang_2esole_2ecompiler_2ffmt_3aformatter_2e16
  br i1 %t301, label %bb69, label %bb70
bb69:
  %t303 = call ptr @__olang_region_make(ptr %v2)
  %t304 = ptrtoint ptr %t303 to i64
  store i64 %t304, ptr %l110, !tbaa !24
  br label %bb70
bb70:
  %t305 = load i64, ptr %l110
  %t306 = inttoptr i64 %t305 to ptr
  %t307 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t306, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t307, ptr %l112
  br label %bb71
bb71:
  %t308 = load i1, ptr @olang_2esole_2ecompiler_2ffmt_3aformatter_2e16
  br i1 %t308, label %bb72, label %bb73
bb72:
  %t310 = load i64, ptr %l110
  %t311 = inttoptr i64 %t310 to ptr
  %t312 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l112, i32 0, i32 0
  %t313 = load { i64, ptr }, ptr %t312
  %t314 = extractvalue { i64, ptr } %t313, 1
  %t315 = call ptr @__olang_region_or(ptr %t314, ptr null)
  %t316 = call ptr @__olang_region_home(ptr %t315)
  %t317 = icmp ne ptr %t316, null
  %t318 = select i1 %t317, ptr %t316, ptr null
  call void @__olang_region_settle_in(ptr %t311, ptr %t318)
  br label %bb73
bb73:
  %t319 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l112
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t319, ptr %l18
  %t320 = call ptr @__olang_scope_hold(ptr %v2)
  %t321 = ptrtoint ptr %t320 to i64
  store i64 %t321, ptr %l114, !tbaa !24
  %t322 = load i1, ptr @olang_2esole_2ecompiler_2ffmt_3aformatter_2e17
  br i1 %t322, label %bb74, label %bb75
bb74:
  %t324 = call ptr @__olang_region_make(ptr %v2)
  %t325 = ptrtoint ptr %t324 to i64
  store i64 %t325, ptr %l114, !tbaa !24
  br label %bb75
bb75:
  %t326 = load i64, ptr %l114
  %t327 = inttoptr i64 %t326 to ptr
  %t328 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t327, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t328, ptr %l116
  br label %bb76
bb76:
  %t329 = load i1, ptr @olang_2esole_2ecompiler_2ffmt_3aformatter_2e17
  br i1 %t329, label %bb77, label %bb78
bb77:
  %t331 = load i64, ptr %l114
  %t332 = inttoptr i64 %t331 to ptr
  %t333 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l116, i32 0, i32 0
  %t334 = load { i64, ptr }, ptr %t333
  %t335 = extractvalue { i64, ptr } %t334, 1
  %t336 = call ptr @__olang_region_or(ptr %t335, ptr null)
  %t337 = call ptr @__olang_region_home(ptr %t336)
  %t338 = icmp ne ptr %t337, null
  %t339 = select i1 %t338, ptr %t337, ptr null
  call void @__olang_region_settle_in(ptr %t332, ptr %t339)
  br label %bb78
bb78:
  %t340 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l116
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t340, ptr %l19
  %t341 = call ptr @__olang_scope_hold(ptr %v2)
  %t342 = ptrtoint ptr %t341 to i64
  store i64 %t342, ptr %l118, !tbaa !24
  %t343 = load i1, ptr @olang_2esole_2ecompiler_2ffmt_3aformatter_2e18
  br i1 %t343, label %bb79, label %bb80
bb79:
  %t345 = call ptr @__olang_region_make(ptr %v2)
  %t346 = ptrtoint ptr %t345 to i64
  store i64 %t346, ptr %l118, !tbaa !24
  br label %bb80
bb80:
  %t347 = load i64, ptr %l118
  %t348 = inttoptr i64 %t347 to ptr
  %t349 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t348, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t349, ptr %l120
  br label %bb81
bb81:
  %t350 = load i1, ptr @olang_2esole_2ecompiler_2ffmt_3aformatter_2e18
  br i1 %t350, label %bb82, label %bb83
bb82:
  %t352 = load i64, ptr %l118
  %t353 = inttoptr i64 %t352 to ptr
  %t354 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l120, i32 0, i32 0
  %t355 = load { i64, ptr }, ptr %t354
  %t356 = extractvalue { i64, ptr } %t355, 1
  %t357 = call ptr @__olang_region_or(ptr %t356, ptr null)
  %t358 = call ptr @__olang_region_home(ptr %t357)
  %t359 = icmp ne ptr %t358, null
  %t360 = select i1 %t359, ptr %t358, ptr null
  call void @__olang_region_settle_in(ptr %t353, ptr %t360)
  br label %bb83
bb83:
  %t361 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l120
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t361, ptr %l20
  %t362 = call ptr @__olang_scope_hold(ptr %v2)
  %t363 = ptrtoint ptr %t362 to i64
  store i64 %t363, ptr %l122, !tbaa !24
  %t364 = load i1, ptr @olang_2esole_2ecompiler_2ffmt_3aformatter_2e19
  br i1 %t364, label %bb84, label %bb85
bb84:
  %t366 = call ptr @__olang_region_make(ptr %v2)
  %t367 = ptrtoint ptr %t366 to i64
  store i64 %t367, ptr %l122, !tbaa !24
  br label %bb85
bb85:
  %t368 = load i64, ptr %l122
  %t369 = inttoptr i64 %t368 to ptr
  %t370 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %t369, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t370, ptr %l124
  br label %bb86
bb86:
  %t371 = load i1, ptr @olang_2esole_2ecompiler_2ffmt_3aformatter_2e19
  br i1 %t371, label %bb87, label %bb88
bb87:
  %t373 = load i64, ptr %l122
  %t374 = inttoptr i64 %t373 to ptr
  %t375 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l124, i32 0, i32 0
  %t376 = load { i64, ptr }, ptr %t375
  %t377 = extractvalue { i64, ptr } %t376, 1
  %t378 = call ptr @__olang_region_or(ptr %t377, ptr null)
  %t379 = call ptr @__olang_region_home(ptr %t378)
  %t380 = icmp ne ptr %t379, null
  %t381 = select i1 %t380, ptr %t379, ptr null
  call void @__olang_region_settle_in(ptr %t374, ptr %t381)
  br label %bb88
bb88:
  %t382 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l124
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t382, ptr %l21
  %t383 = call ptr @__olang_scope_hold(ptr %v2)
  %t384 = ptrtoint ptr %t383 to i64
  store i64 %t384, ptr %l126, !tbaa !24
  %t385 = load i1, ptr @olang_2esole_2ecompiler_2ffmt_3aformatter_2e20
  br i1 %t385, label %bb89, label %bb90
bb89:
  %t387 = call ptr @__olang_region_make(ptr %v2)
  %t388 = ptrtoint ptr %t387 to i64
  store i64 %t388, ptr %l126, !tbaa !24
  br label %bb90
bb90:
  %t389 = load i64, ptr %l126
  %t390 = inttoptr i64 %t389 to ptr
  %t391 = call %"std/prelude/text:StringBuilder" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %t390)
  store %"std/prelude/text:StringBuilder" %t391, ptr %l128
  br label %bb91
bb91:
  %t392 = load i1, ptr @olang_2esole_2ecompiler_2ffmt_3aformatter_2e20
  br i1 %t392, label %bb92, label %bb93
bb92:
  %t394 = load i64, ptr %l126
  %t395 = inttoptr i64 %t394 to ptr
  %t396 = getelementptr %"std/prelude/text:StringBuilder", ptr %l128, i32 0, i32 0
  %t397 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t396, i32 0, i32 0
  %t398 = load { i64, ptr }, ptr %t397
  %t399 = extractvalue { i64, ptr } %t398, 1
  %t400 = call ptr @__olang_region_or(ptr %t399, ptr null)
  %t401 = call ptr @__olang_region_home(ptr %t400)
  %t402 = icmp ne ptr %t401, null
  %t403 = select i1 %t402, ptr %t401, ptr null
  call void @__olang_region_settle_in(ptr %t395, ptr %t403)
  br label %bb93
bb93:
  %t404 = load %"std/prelude/text:StringBuilder", ptr %l128
  store %"std/prelude/text:StringBuilder" %t404, ptr %l22
  store i1 false, ptr %l23, !tbaa !21
  store i64 0, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  %t405 = call ptr @__olang_scope_hold(ptr %v2)
  %t406 = ptrtoint ptr %t405 to i64
  store i64 %t406, ptr %l130, !tbaa !24
  %t407 = load i1, ptr @olang_2esole_2ecompiler_2ffmt_3aformatter_2e24
  br i1 %t407, label %bb94, label %bb95
bb94:
  %t409 = call ptr @__olang_region_make(ptr %v2)
  %t410 = ptrtoint ptr %t409 to i64
  store i64 %t410, ptr %l130, !tbaa !24
  br label %bb95
bb95:
  %t411 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t413 = extractvalue { i64, ptr } %t411, 0
  store i64 %t413, ptr %l133, !tbaa !24
  %t414 = load i64, ptr %l133, !tbaa !24
  %t415 = icmp sge i64 %t414, 0
  br i1 %t415, label %bb96, label %bb97
bb96:
  %t417 = load i64, ptr %l133, !tbaa !24
  %t418 = icmp sle i64 %t417, 1152921504606846975
  br i1 %t418, label %bb98, label %bb99
bb97:
  call void @__olang_check_failed(ptr @olang_loc_52035349e3e5249e_39ce4f5cc5469c5a)
  unreachable
bb98:
  %t420 = load i64, ptr %l133, !tbaa !24
  %t421 = mul i64 %t420, 8
  %t422 = load i64, ptr %l130
  %t423 = inttoptr i64 %t422 to ptr
  %t424 = call ptr @__olang_scope_alloc_zeroed(ptr %t423, i64 %t421)
  %t425 = insertvalue { i64, ptr } undef, i64 %t420, 0
  %t426 = insertvalue { i64, ptr } %t425, ptr %t424, 1
  store { i64, ptr } %t426, ptr %l26, !tbaa !27
  store i64 0, ptr %l27, !tbaa !24
  store i1 false, ptr %l28, !tbaa !21
  store i64 -1, ptr %l29, !tbaa !24
  store i64 -1, ptr %l30, !tbaa !24
  store i64 0, ptr %l31, !tbaa !24
  store i64 -1, ptr %l32, !tbaa !24
  store i64 0, ptr %l33, !tbaa !24
  store i64 -1, ptr %l34, !tbaa !24
  %t428 = call ptr @__olang_scope_hold(ptr %v2)
  %t429 = ptrtoint ptr %t428 to i64
  store i64 %t429, ptr %l137, !tbaa !24
  %t430 = load i1, ptr @olang_2esole_2ecompiler_2ffmt_3aformatter_2e33
  br i1 %t430, label %bb100, label %bb101
bb99:
  call void @__olang_check_failed(ptr @olang_loc_52035349e3e5249e_39ce4f5cc5469c5a)
  unreachable
bb100:
  %t432 = call ptr @__olang_region_make(ptr %v2)
  %t433 = ptrtoint ptr %t432 to i64
  store i64 %t433, ptr %l137, !tbaa !24
  br label %bb101
bb101:
  %t434 = load i64, ptr %l137
  %t435 = inttoptr i64 %t434 to ptr
  %t436 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t435, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t436, ptr %l139
  br label %bb102
bb102:
  %t437 = load i1, ptr @olang_2esole_2ecompiler_2ffmt_3aformatter_2e33
  br i1 %t437, label %bb103, label %bb104
bb103:
  %t439 = load i64, ptr %l137
  %t440 = inttoptr i64 %t439 to ptr
  %t441 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l139, i32 0, i32 0
  %t442 = load { i64, ptr }, ptr %t441
  %t443 = extractvalue { i64, ptr } %t442, 1
  %t444 = call ptr @__olang_region_or(ptr %t443, ptr null)
  %t445 = call ptr @__olang_region_home(ptr %t444)
  %t446 = icmp ne ptr %t445, null
  %t447 = select i1 %t446, ptr %t445, ptr null
  call void @__olang_region_settle_in(ptr %t440, ptr %t447)
  br label %bb104
bb104:
  %t448 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l139
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t448, ptr %l35
  %t449 = call ptr @__olang_scope_hold(ptr %v2)
  %t450 = ptrtoint ptr %t449 to i64
  store i64 %t450, ptr %l141, !tbaa !24
  %t451 = load i1, ptr @olang_2esole_2ecompiler_2ffmt_3aformatter_2e34
  br i1 %t451, label %bb105, label %bb106
bb105:
  %t453 = call ptr @__olang_region_make(ptr %v2)
  %t454 = ptrtoint ptr %t453 to i64
  store i64 %t454, ptr %l141, !tbaa !24
  br label %bb106
bb106:
  %t455 = load i64, ptr %l141
  %t456 = inttoptr i64 %t455 to ptr
  %t457 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t456, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t457, ptr %l143
  br label %bb107
bb107:
  %t458 = load i1, ptr @olang_2esole_2ecompiler_2ffmt_3aformatter_2e34
  br i1 %t458, label %bb108, label %bb109
bb108:
  %t460 = load i64, ptr %l141
  %t461 = inttoptr i64 %t460 to ptr
  %t462 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l143, i32 0, i32 0
  %t463 = load { i64, ptr }, ptr %t462
  %t464 = extractvalue { i64, ptr } %t463, 1
  %t465 = call ptr @__olang_region_or(ptr %t464, ptr null)
  %t466 = call ptr @__olang_region_home(ptr %t465)
  %t467 = icmp ne ptr %t466, null
  %t468 = select i1 %t467, ptr %t466, ptr null
  call void @__olang_region_settle_in(ptr %t461, ptr %t468)
  br label %bb109
bb109:
  %t469 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l143
  %t470 = getelementptr %"compiler/fmt:formatter", ptr %l145, i32 0, i32 0
  %t471 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t471, ptr %t470, !tbaa !27
  %t472 = getelementptr %"compiler/fmt:formatter", ptr %l145, i32 0, i32 1
  %t473 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t473, ptr %t472, !tbaa !27
  %t474 = getelementptr %"compiler/fmt:formatter", ptr %l145, i32 0, i32 2
  %t475 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t475, ptr %t474, !tbaa !27
  %t476 = getelementptr %"compiler/fmt:formatter", ptr %l145, i32 0, i32 3
  %t477 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t477, ptr %t476, !tbaa !27
  %t478 = getelementptr %"compiler/fmt:formatter", ptr %l145, i32 0, i32 4
  %t479 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t479, ptr %t478, !tbaa !27
  %t480 = getelementptr %"compiler/fmt:formatter", ptr %l145, i32 0, i32 5
  %t481 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t481, ptr %t480, !tbaa !27
  %t482 = getelementptr %"compiler/fmt:formatter", ptr %l145, i32 0, i32 6
  %t483 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t483, ptr %t482, !tbaa !27
  %t484 = getelementptr %"compiler/fmt:formatter", ptr %l145, i32 0, i32 7
  %t485 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t485, ptr %t484, !tbaa !27
  %t486 = getelementptr %"compiler/fmt:formatter", ptr %l145, i32 0, i32 8
  %t487 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t487, ptr %t486
  %t488 = getelementptr %"compiler/fmt:formatter", ptr %l145, i32 0, i32 9
  %t489 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t489, ptr %t488
  %t490 = getelementptr %"compiler/fmt:formatter", ptr %l145, i32 0, i32 10
  %t491 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t491, ptr %t490
  %t492 = getelementptr %"compiler/fmt:formatter", ptr %l145, i32 0, i32 11
  %t493 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t493, ptr %t492
  %t494 = getelementptr %"compiler/fmt:formatter", ptr %l145, i32 0, i32 12
  %t495 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t495, ptr %t494
  %t496 = getelementptr %"compiler/fmt:formatter", ptr %l145, i32 0, i32 13
  %t497 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t497, ptr %t496
  %t498 = getelementptr %"compiler/fmt:formatter", ptr %l145, i32 0, i32 14
  %t499 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t499, ptr %t498
  %t500 = getelementptr %"compiler/fmt:formatter", ptr %l145, i32 0, i32 15
  %t501 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t501, ptr %t500
  %t502 = getelementptr %"compiler/fmt:formatter", ptr %l145, i32 0, i32 16
  %t503 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t503, ptr %t502
  %t504 = getelementptr %"compiler/fmt:formatter", ptr %l145, i32 0, i32 17
  %t505 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t505, ptr %t504
  %t506 = getelementptr %"compiler/fmt:formatter", ptr %l145, i32 0, i32 18
  %t507 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t507, ptr %t506
  %t508 = getelementptr %"compiler/fmt:formatter", ptr %l145, i32 0, i32 19
  %t509 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t509, ptr %t508
  %t510 = getelementptr %"compiler/fmt:formatter", ptr %l145, i32 0, i32 20
  %t511 = load %"std/prelude/text:StringBuilder", ptr %l22
  store %"std/prelude/text:StringBuilder" %t511, ptr %t510
  %t512 = getelementptr %"compiler/fmt:formatter", ptr %l145, i32 0, i32 21
  %t513 = load i1, ptr %l23, !tbaa !21
  store i1 %t513, ptr %t512, !tbaa !21
  %t514 = getelementptr %"compiler/fmt:formatter", ptr %l145, i32 0, i32 22
  %t515 = load i64, ptr %l24, !tbaa !24
  store i64 %t515, ptr %t514, !tbaa !24
  %t516 = getelementptr %"compiler/fmt:formatter", ptr %l145, i32 0, i32 23
  %t517 = load i64, ptr %l25, !tbaa !24
  store i64 %t517, ptr %t516, !tbaa !24
  %t518 = getelementptr %"compiler/fmt:formatter", ptr %l145, i32 0, i32 24
  %t519 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t519, ptr %t518, !tbaa !27
  %t520 = getelementptr %"compiler/fmt:formatter", ptr %l145, i32 0, i32 25
  %t521 = load i64, ptr %l27, !tbaa !24
  store i64 %t521, ptr %t520, !tbaa !24
  %t522 = getelementptr %"compiler/fmt:formatter", ptr %l145, i32 0, i32 26
  %t523 = load i1, ptr %l28, !tbaa !21
  store i1 %t523, ptr %t522, !tbaa !21
  %t524 = getelementptr %"compiler/fmt:formatter", ptr %l145, i32 0, i32 27
  %t525 = load i64, ptr %l29, !tbaa !24
  store i64 %t525, ptr %t524, !tbaa !24
  %t526 = getelementptr %"compiler/fmt:formatter", ptr %l145, i32 0, i32 28
  %t527 = load i64, ptr %l30, !tbaa !24
  store i64 %t527, ptr %t526, !tbaa !24
  %t528 = getelementptr %"compiler/fmt:formatter", ptr %l145, i32 0, i32 29
  %t529 = load i64, ptr %l31, !tbaa !24
  store i64 %t529, ptr %t528, !tbaa !24
  %t530 = getelementptr %"compiler/fmt:formatter", ptr %l145, i32 0, i32 30
  %t531 = load i64, ptr %l32, !tbaa !24
  store i64 %t531, ptr %t530, !tbaa !24
  %t532 = getelementptr %"compiler/fmt:formatter", ptr %l145, i32 0, i32 31
  %t533 = load i64, ptr %l33, !tbaa !24
  store i64 %t533, ptr %t532, !tbaa !24
  %t534 = getelementptr %"compiler/fmt:formatter", ptr %l145, i32 0, i32 32
  %t535 = load i64, ptr %l34, !tbaa !24
  store i64 %t535, ptr %t534, !tbaa !24
  %t536 = getelementptr %"compiler/fmt:formatter", ptr %l145, i32 0, i32 33
  %t537 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l35
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t537, ptr %t536
  %t538 = getelementptr %"compiler/fmt:formatter", ptr %l145, i32 0, i32 34
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t469, ptr %t538
  %t540 = getelementptr %"compiler/fmt:formatter", ptr %l145, i32 0, i32 35
  store i1 false, ptr %t540, !tbaa !21
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l145, i64 720, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffmt_3aloader_2ector(ptr %out, ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca i64
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca i64
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca i64
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca i64
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca i64
  %l26 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca %"compiler/fmt:loader"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l1, !tbaa !27
  %t3 = call ptr @__olang_scope_hold(ptr %v1)
  %t4 = ptrtoint ptr %t3 to i64
  store i64 %t4, ptr %l8, !tbaa !24
  %t5 = load i1, ptr @olang_2esole_2ecompiler_2ffmt_3aloader_2e1
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = call ptr @__olang_region_make(ptr %v1)
  %t8 = ptrtoint ptr %t7 to i64
  store i64 %t8, ptr %l8, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l8
  %t10 = inttoptr i64 %t9 to ptr
  %t11 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t10, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %l10
  br label %bb3
bb3:
  %t12 = load i1, ptr @olang_2esole_2ecompiler_2ffmt_3aloader_2e1
  br i1 %t12, label %bb4, label %bb5
bb4:
  %t14 = load i64, ptr %l8
  %t15 = inttoptr i64 %t14 to ptr
  %t16 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10, i32 0, i32 0
  %t17 = load { i64, ptr }, ptr %t16
  %t18 = extractvalue { i64, ptr } %t17, 1
  %t19 = call ptr @__olang_region_or(ptr %t18, ptr null)
  %t20 = call ptr @__olang_region_home(ptr %t19)
  %t21 = icmp ne ptr %t20, null
  %t22 = select i1 %t21, ptr %t20, ptr null
  call void @__olang_region_settle_in(ptr %t15, ptr %t22)
  br label %bb5
bb5:
  %t23 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %l2
  %t24 = call ptr @__olang_scope_hold(ptr %v1)
  %t25 = ptrtoint ptr %t24 to i64
  store i64 %t25, ptr %l12, !tbaa !24
  %t26 = load i1, ptr @olang_2esole_2ecompiler_2ffmt_3aloader_2e2
  br i1 %t26, label %bb6, label %bb7
bb6:
  %t28 = call ptr @__olang_region_make(ptr %v1)
  %t29 = ptrtoint ptr %t28 to i64
  store i64 %t29, ptr %l12, !tbaa !24
  br label %bb7
bb7:
  %t30 = load i64, ptr %l12
  %t31 = inttoptr i64 %t30 to ptr
  %t32 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t31, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t32, ptr %l14
  br label %bb8
bb8:
  %t33 = load i1, ptr @olang_2esole_2ecompiler_2ffmt_3aloader_2e2
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load i64, ptr %l12
  %t36 = inttoptr i64 %t35 to ptr
  %t37 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14, i32 0, i32 0
  %t38 = load { i64, ptr }, ptr %t37
  %t39 = extractvalue { i64, ptr } %t38, 1
  %t40 = call ptr @__olang_region_or(ptr %t39, ptr null)
  %t41 = call ptr @__olang_region_home(ptr %t40)
  %t42 = icmp ne ptr %t41, null
  %t43 = select i1 %t42, ptr %t41, ptr null
  call void @__olang_region_settle_in(ptr %t36, ptr %t43)
  br label %bb10
bb10:
  %t44 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t44, ptr %l3
  %t45 = call ptr @__olang_scope_hold(ptr %v1)
  %t46 = ptrtoint ptr %t45 to i64
  store i64 %t46, ptr %l16, !tbaa !24
  %t47 = load i1, ptr @olang_2esole_2ecompiler_2ffmt_3aloader_2e3
  br i1 %t47, label %bb11, label %bb12
bb11:
  %t49 = call ptr @__olang_region_make(ptr %v1)
  %t50 = ptrtoint ptr %t49 to i64
  store i64 %t50, ptr %l16, !tbaa !24
  br label %bb12
bb12:
  %t51 = load i64, ptr %l16
  %t52 = inttoptr i64 %t51 to ptr
  %t53 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t52, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t53, ptr %l18
  br label %bb13
bb13:
  %t54 = load i1, ptr @olang_2esole_2ecompiler_2ffmt_3aloader_2e3
  br i1 %t54, label %bb14, label %bb15
bb14:
  %t56 = load i64, ptr %l16
  %t57 = inttoptr i64 %t56 to ptr
  %t58 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18, i32 0, i32 0
  %t59 = load { i64, ptr }, ptr %t58
  %t60 = extractvalue { i64, ptr } %t59, 1
  %t61 = call ptr @__olang_region_or(ptr %t60, ptr null)
  %t62 = call ptr @__olang_region_home(ptr %t61)
  %t63 = icmp ne ptr %t62, null
  %t64 = select i1 %t63, ptr %t62, ptr null
  call void @__olang_region_settle_in(ptr %t57, ptr %t64)
  br label %bb15
bb15:
  %t65 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t65, ptr %l4
  %t66 = call ptr @__olang_scope_hold(ptr %v1)
  %t67 = ptrtoint ptr %t66 to i64
  store i64 %t67, ptr %l20, !tbaa !24
  %t68 = load i1, ptr @olang_2esole_2ecompiler_2ffmt_3aloader_2e4
  br i1 %t68, label %bb16, label %bb17
bb16:
  %t70 = call ptr @__olang_region_make(ptr %v1)
  %t71 = ptrtoint ptr %t70 to i64
  store i64 %t71, ptr %l20, !tbaa !24
  br label %bb17
bb17:
  %t72 = load i64, ptr %l20
  %t73 = inttoptr i64 %t72 to ptr
  %t74 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t73, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t74, ptr %l22
  br label %bb18
bb18:
  %t75 = load i1, ptr @olang_2esole_2ecompiler_2ffmt_3aloader_2e4
  br i1 %t75, label %bb19, label %bb20
bb19:
  %t77 = load i64, ptr %l20
  %t78 = inttoptr i64 %t77 to ptr
  %t79 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22, i32 0, i32 0
  %t80 = load { i64, ptr }, ptr %t79
  %t81 = extractvalue { i64, ptr } %t80, 1
  %t82 = call ptr @__olang_region_or(ptr %t81, ptr null)
  %t83 = call ptr @__olang_region_home(ptr %t82)
  %t84 = icmp ne ptr %t83, null
  %t85 = select i1 %t84, ptr %t83, ptr null
  call void @__olang_region_settle_in(ptr %t78, ptr %t85)
  br label %bb20
bb20:
  %t86 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t86, ptr %l5
  %t87 = call ptr @__olang_scope_hold(ptr %v1)
  %t88 = ptrtoint ptr %t87 to i64
  store i64 %t88, ptr %l24, !tbaa !24
  %t89 = load i1, ptr @olang_2esole_2ecompiler_2ffmt_3aloader_2e5
  br i1 %t89, label %bb21, label %bb22
bb21:
  %t91 = call ptr @__olang_region_make(ptr %v1)
  %t92 = ptrtoint ptr %t91 to i64
  store i64 %t92, ptr %l24, !tbaa !24
  br label %bb22
bb22:
  %t93 = load i64, ptr %l24
  %t94 = inttoptr i64 %t93 to ptr
  %t95 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t94, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t95, ptr %l26
  br label %bb23
bb23:
  %t96 = load i1, ptr @olang_2esole_2ecompiler_2ffmt_3aloader_2e5
  br i1 %t96, label %bb24, label %bb25
bb24:
  %t98 = load i64, ptr %l24
  %t99 = inttoptr i64 %t98 to ptr
  %t100 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l26, i32 0, i32 0
  %t101 = load { i64, ptr }, ptr %t100
  %t102 = extractvalue { i64, ptr } %t101, 1
  %t103 = call ptr @__olang_region_or(ptr %t102, ptr null)
  %t104 = call ptr @__olang_region_home(ptr %t103)
  %t105 = icmp ne ptr %t104, null
  %t106 = select i1 %t105, ptr %t104, ptr null
  call void @__olang_region_settle_in(ptr %t99, ptr %t106)
  br label %bb25
bb25:
  %t107 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l26
  %t108 = getelementptr %"compiler/fmt:loader", ptr %l28, i32 0, i32 0
  %t109 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t109, ptr %t108, !tbaa !27
  %t110 = getelementptr %"compiler/fmt:loader", ptr %l28, i32 0, i32 1
  %t111 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t111, ptr %t110
  %t112 = getelementptr %"compiler/fmt:loader", ptr %l28, i32 0, i32 2
  %t113 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t113, ptr %t112
  %t114 = getelementptr %"compiler/fmt:loader", ptr %l28, i32 0, i32 3
  %t115 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t115, ptr %t114
  %t116 = getelementptr %"compiler/fmt:loader", ptr %l28, i32 0, i32 4
  %t117 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t117, ptr %t116
  %t118 = getelementptr %"compiler/fmt:loader", ptr %l28, i32 0, i32 5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t107, ptr %t118
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l28, i64 176, i1 false)
  br label %ret
ret:
  ret void
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4 = weak hidden constant i1 false
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@olang_2etable_2eI32_7cstd_2fio_3aDescriptor = linkonce_odr constant [4 x ptr] [ptr @olang_2etypeid_2eI32, ptr @olang_2eanyrender_2eI32_7cstd_2fio_3aDescriptor, ptr @olang_2eanyrender_2etop_2eI32_7cstd_2fio_3aDescriptor, ptr @olang_2eslot_2eI32_7cstd_2fio_3aDescriptor_2e0]
declare void @__olang_errpay_pop()
@.d0 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"olang: " }>, align 8
@.d1 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c": cannot be read\0A" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d2 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-f" }>, align 8
@.d3 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-p" }>, align 8
@.d4 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"olang: " }>, align 8
@.d5 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c": cannot be written\0A" }>, align 8
@.d6 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d7 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d8 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
declare void @__olang_bang_failed_plain(ptr) cold noreturn
@.d9 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d10 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d11 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d12 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d13 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d14 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d15 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d16 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d17 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d18 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d19 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d20 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d21 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d22 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d23 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d24 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d25 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d26 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d27 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d28 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d29 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d30 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d31 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d32 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d33 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d34 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d35 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d36 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d37 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"=" }>, align 8
@.d38 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" =" }>, align 8
@.d39 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d40 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d41 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn:" }>, align 8
@.d42 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare ptr @__olang_scope_of(ptr, ptr) noinline
@.d43 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1 = weak hidden constant i1 false
@.d44 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d45 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d46 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d47 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d48 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d49 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d50 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Array" }>, align 8
@.d51 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d52 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"prelude" }>, align 8
@.d53 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d54 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
@.d55 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d56 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d57 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".." }>, align 8
@.d58 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d59 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"std/" }>, align 8
@.d60 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
@.d61 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
@olang_2esole_2ecompiler_2ffmt_3aformatter_2e2 = weak hidden constant i1 false
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@olang_2esole_2ecompiler_2ffmt_3aformatter_2e3 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ffmt_3aformatter_2e4 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ffmt_3aformatter_2e5 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ffmt_3aformatter_2e6 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ffmt_3aformatter_2e7 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ffmt_3aformatter_2e8 = weak hidden constant i1 false
declare ptr @__olang_region_or(ptr, ptr)
declare ptr @__olang_region_home(ptr)
declare void @__olang_region_settle_in(ptr, ptr)
@olang_2esole_2ecompiler_2ffmt_3aformatter_2e9 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ffmt_3aformatter_2e10 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ffmt_3aformatter_2e11 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ffmt_3aformatter_2e12 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ffmt_3aformatter_2e13 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ffmt_3aformatter_2e14 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ffmt_3aformatter_2e15 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ffmt_3aformatter_2e16 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ffmt_3aformatter_2e17 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ffmt_3aformatter_2e18 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ffmt_3aformatter_2e19 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ffmt_3aformatter_2e20 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/text:StringBuilder" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/text:StringBuilder"
  %rv = alloca %"std/prelude/text:StringBuilder"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l0
  store %"std/prelude/text:StringBuilder" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/text:StringBuilder", ptr %rv
  ret %"std/prelude/text:StringBuilder" %rr
}

@olang_2esole_2ecompiler_2ffmt_3aformatter_2e24 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ffmt_3aformatter_2e33 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ffmt_3aformatter_2e34 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ffmt_3aloader_2e1 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ffmt_3aloader_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ffmt_3aloader_2e3 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ffmt_3aloader_2e4 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ffmt_3aloader_2e5 = weak hidden constant i1 false
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@olang_2etypeid_2eI32 = linkonce_odr constant i8 0
define linkonce_odr void @olang_2eanyrender_2eI32_7cstd_2fio_3aDescriptor(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0, !tbaa !23
  %t4 = sext i32 %t2 to i64
  %t5 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t6 = call i64 @__olang_fmt_i64(ptr %t5, i64 %t4)
  call void @__olang_sb_add(ptr %v0, i64 %t6)
  br label %ret
ret:
  ret void
}

define linkonce_odr void @olang_2eanyrender_2etop_2eI32_7cstd_2fio_3aDescriptor(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0, !tbaa !23
  %t3 = sext i32 %t2 to i64
  %t4 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t5 = call i64 @__olang_fmt_i64(ptr %t4, i64 %t3)
  call void @__olang_sb_add(ptr %v0, i64 %t5)
  br label %ret
ret:
  ret void
}

@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
define available_externally ptr @__olang_sb_room(ptr %sb, i64 %need) alwaysinline {
entry:
  %lenp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 1
  %capp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 2
  %len = load i64, ptr %lenp
  %cap = load i64, ptr %capp
  %want = add i64 %len, %need
  %fits = icmp ule i64 %want, %cap
  br i1 %fits, label %ok, label %grow
ok:
  %data = load ptr, ptr %sb
  %p = getelementptr i8, ptr %data, i64 %len
  ret ptr %p
grow:
  %g = call ptr @__olang_sb_grow(ptr %sb, i64 %need)
  ret ptr %g
}
declare i64 @__olang_fmt_i64(ptr, i64)
declare void @__olang_sb_add(ptr, i64)
declare ptr @__olang_sb_grow(ptr, i64) noinline
declare %"compiler/source:Source" @compiler_2fsource_3aSource_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/source:Names" @compiler_2fsource_3aNames_2ector(ptr %v0)
declare void @compiler_2fdiag_3aDiagnostics_2ector(ptr %out, ptr %v0, i1 %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAddFile(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3)
declare %"compiler/scan:Tokens" @compiler_2fscan_2eTokens_2eScan(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fscan_2ecompiler_2fscan_3aDiag_2eRule(ptr %v0, %"compiler/scan:Diag" %a0)
declare { i64, ptr } @compiler_2fscan_2ecompiler_2fscan_3aDiag_2eMessage(ptr %v0, %"compiler/scan:Diag" %a0)
declare { i64, ptr } @compiler_2fscan_2ecompiler_2fscan_3aDiag_2eNote(ptr %v0, %"compiler/scan:Diag" %a0)
declare { i64, ptr } @compiler_2fscan_2ecompiler_2fscan_3aDiag_2eHelp(ptr %v0, %"compiler/scan:Diag" %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, i32 %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/diagmsg:Msg" %a2)
declare void @compiler_2fparse_3aParser_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, i64 %a5)
declare { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eFile(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAllSaid(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3aSaid_3e_2eLen_3ccompiler_2fdiag_3aSaid_3e(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2funparse_2eHeldBranches(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, ptr %a1, { i64, ptr } %a2, ptr %a3)
@G_2estd_2fio_2eStdout = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare %"std/io:Writer" @std_2fio_3aWriter_2ector(ptr %v0, ptr %v1, { ptr, ptr } %a0, i64 %a1)
@G_2estd_2fio_2eStderr = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2ffmt_2ePreludeTypes(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, %"compiler/source:Source" } @compiler_2fsource_2eSource_2eRead(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare i1 @compiler_2fdiag_2eColorWanted()
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ffmt_2elineEndOf(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare void @compiler_2fparse_3aOracle_2ector(ptr %out, ptr %v0)
@G_2ecompiler_2ftoken_2eSpace = available_externally constant <{ [1 x i8] }> <{ [1 x i8] c"\02" }>, align 8
declare i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %a0, i8 %a1)
@G_2ecompiler_2ftoken_2eLineBreak = available_externally constant <{ [1 x i8] }> <{ [1 x i8] c"\01" }>, align 8
declare void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ebegin(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
@olang_loc_efe0301a0eee46c_f87ee963c45aa130 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eTruncate_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekind(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2efinish(ptr %v0, ptr %a0)
declare i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2echild(ptr %v0, ptr %a0)
declare i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2econt(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2ekeyword(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2eoperandEnd(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftoken_3aTok_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftoken_3aTok_3e_2ePush_3ccompiler_2ftoken_3aTok_3e(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftoken_3aTok_3e_2eLen_3ccompiler_2ftoken_3aTok_3e(ptr %v0, ptr %a0)
declare { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftoken_3aTok_3e_2ePop_3ccompiler_2ftoken_3aTok_3e(ptr %v0, ptr %a0)
@olang_loc_35c4bcbe8a179434_4b4275954f9faef0 = external constant [0 x i8]
@olang_loc_60c6fb5a9e323c49_a95dbf77cbddce25 = external constant [0 x i8]
@olang_loc_951b69446ffbaf49_31d81fa88f191745 = external constant [0 x i8]
@olang_loc_e1e0026cb6156c8f_cc49873f28a42c4b = external constant [0 x i8]
declare { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftoken_3aTok_3e_2eLast_3ccompiler_2ftoken_3aTok_3e(ptr %v0, ptr %a0)
@olang_loc_aa98af033dba4568_940e94a7ebea1854 = external constant [0 x i8]
declare i64 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2elevel(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_bcfa8bcb194c4d3c_b6a77a733196e698 = external constant [0 x i8]
declare i1 @compiler_2ffmt_2ecompiler_2ffmt_3aformatter_2eclosing(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_c72ec7e8dfc94dc_53a73ed146206d80 = external constant [0 x i8]
@olang_loc_8b20359aae87aa49_981ed0beb1f6b3dd = external constant [0 x i8]
declare i1 @compiler_2ffmt_2eisCloser(i32 %a0)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_66958b60b9b09f2a_a21c6753724927b6 = external constant [0 x i8]
declare i64 @compiler_2ffmt_2ewidth(ptr %v0, { i64, ptr } %a0)
@olang_loc_1f023a932aff5454_c8fa03de0f87b198 = external constant [0 x i8]
@olang_loc_259a09fa35ee14c1_c921ceba7167c8f5 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2ffmt_2ecompiler_2ffmt_3aloader_2eaddNames(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_b45f67b0c13c7f92_d3bc8c6077d2e8ee = external constant [0 x i8]
@olang_loc_bf801ccf4339d98f_a7f4482671f796eb = external constant [0 x i8]
@olang_loc_31ba00d857a48a4_d72415852a995970 = external constant [0 x i8]
@olang_loc_f328ac53cd348991_ee2d20c1cf12bb4d = external constant [0 x i8]
declare { i64, ptr } @compiler_2fscan_2eLiteralText(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2ffilepath_2eBase(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %a0)
declare void @compiler_2fparse_2ecompiler_2fparse_3aOracle_2eAdd(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare { i64, ptr } @std_2ffilepath_2eJoin(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_1c96c695fa9cb803_60711cea71b32ee7 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %a0, i8 %a1)
@olang_loc_3df0b8839dc54179_133a546f9cf2d20d = external constant [0 x i8]
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_9121eab1d44cad4c_7d1c1b769798e530 = external constant [0 x i8]
declare { i64, ptr } @std_2ffilepath_2eDir(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_ce709d7b9ef8b1fc_3d0b2a4c89679e00 = external constant [0 x i8]
@olang_loc_d589fc983080be49_a3fac9ed8d21e52d = external constant [0 x i8]
@olang_loc_5014c5e33980418a_6c70c79ebb210b2e = external constant [0 x i8]
@olang_loc_b2eb5d9479cf4f5f_182504dbd1c367a3 = external constant [0 x i8]
@olang_loc_bfaf8ae940299f30_3213b1cd9190eecc = external constant [0 x i8]
@olang_loc_f8370207eae072dd_4bf9c30e1d6aa1d9 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_52035349e3e5249e_39ce4f5cc5469c5a = external constant [0 x i8]
declare i32 @olang_2eslot_2eI32_7cstd_2fio_3aDescriptor_2e0(ptr %v0, ptr %a0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
