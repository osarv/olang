; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List<std/prelude/text:Char>" }
%"std/prelude/list:List<std/prelude/text:Char>" = type { ptr }
@G_2ecompiler_2fmsgs_2eEndOfFile = global { i64, ptr } zeroinitializer
@G_2ecompiler_2fmsgs_2eEndOfLine = global { i64, ptr } zeroinitializer
define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAltBindingType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 425, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = load { i64, ptr }, ptr %l3
  %t4 = extractvalue { i64, ptr } %t3, 1
  %t5 = extractvalue { i64, ptr } %t3, 0
  call void @__olang_sb_put(ptr %s1, ptr %t4, i64 %t5)
  %t6 = extractvalue { i64, ptr } { i64 13, ptr @.d0 }, 1
  %t7 = extractvalue { i64, ptr } { i64 13, ptr @.d0 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = load { i64, ptr }, ptr %l4
  %t9 = extractvalue { i64, ptr } %t8, 1
  %t10 = extractvalue { i64, ptr } %t8, 0
  call void @__olang_sb_put(ptr %s1, ptr %t9, i64 %t10)
  %t11 = extractvalue { i64, ptr } { i64 43, ptr @.d1 }, 1
  %t12 = extractvalue { i64, ptr } { i64 43, ptr @.d1 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = load ptr, ptr %s1
  %t14 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t15 = load i64, ptr %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t13, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t19 = load { i64, ptr }, ptr %l5
  %t20 = extractvalue { i64, ptr } %t19, 0
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = mul i64 %t20, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t22)
  call void @llvm.memcpy.p0.p0.i64(ptr %t23, ptr %t21, i64 %t22, i1 false)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l6
  %t26 = load i32, ptr %l2
  %t27 = load { i64, ptr }, ptr %l6
  %t28 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t26, { i64, ptr } { i64 4, ptr @.d2 }, { i64, ptr } %t27)
  store %"compiler/msgs:Msg" %t28, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t29, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAltBindsOtherNames(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 423, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 4, ptr @.d3 }, { i64, ptr } { i64 86, ptr @.d4 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCount(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store i64 %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 254, ptr %l3
  %t1 = load i64, ptr %l0
  store i64 %t1, ptr %l4
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l5
  %t3 = load i64, ptr %l2
  store i64 %t3, ptr %l6
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t4 = extractvalue { i64, ptr } { i64 9, ptr @.d5 }, 1
  %t5 = extractvalue { i64, ptr } { i64 9, ptr @.d5 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t4, i64 %t5)
  %t6 = load i64, ptr %l4
  %t7 = call ptr @__olang_sb_room(ptr %s1, i64 24)
  %t8 = call i64 @__olang_fmt_i64(ptr %t7, i64 %t6)
  call void @__olang_sb_add(ptr %s1, i64 %t8)
  %t9 = extractvalue { i64, ptr } { i64 9, ptr @.d6 }, 1
  %t10 = extractvalue { i64, ptr } { i64 9, ptr @.d6 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t9, i64 %t10)
  %t11 = load { i64, ptr }, ptr %l5
  %t12 = extractvalue { i64, ptr } %t11, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  call void @__olang_sb_put(ptr %s1, ptr %t12, i64 %t13)
  %t14 = extractvalue { i64, ptr } { i64 8, ptr @.d7 }, 1
  %t15 = extractvalue { i64, ptr } { i64 8, ptr @.d7 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t14, i64 %t15)
  %t16 = load i64, ptr %l6
  %t17 = call ptr @__olang_sb_room(ptr %s1, i64 24)
  %t18 = call i64 @__olang_fmt_i64(ptr %t17, i64 %t16)
  call void @__olang_sb_add(ptr %s1, i64 %t18)
  %t19 = load ptr, ptr %s1
  %t20 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t21 = load i64, ptr %t20
  %t22 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t19, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  store { i64, ptr } %t24, ptr %l7
  call void @__olang_sb_done(ptr %s1)
  %t25 = load { i64, ptr }, ptr %l7
  %t26 = extractvalue { i64, ptr } %t25, 0
  %t27 = extractvalue { i64, ptr } %t25, 1
  %t28 = mul i64 %t26, 1
  %t29 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t28)
  call void @llvm.memcpy.p0.p0.i64(ptr %t29, ptr %t27, i64 %t28, i1 false)
  %t30 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  store { i64, ptr } %t31, ptr %l8
  %t32 = load i32, ptr %l3
  %t33 = load { i64, ptr }, ptr %l8
  %t34 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t32, { i64, ptr } { i64 3, ptr @.d8 }, { i64, ptr } %t33)
  store %"compiler/msgs:Msg" %t34, ptr %l9
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t35 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t35, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCountRange(ptr %v0, i64 %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 255, ptr %l3
  %t1 = load i64, ptr %l0
  store i64 %t1, ptr %l4
  %t2 = load i64, ptr %l1
  store i64 %t2, ptr %l5
  %t3 = load i64, ptr %l2
  store i64 %t3, ptr %l6
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t4 = extractvalue { i64, ptr } { i64 9, ptr @.d9 }, 1
  %t5 = extractvalue { i64, ptr } { i64 9, ptr @.d9 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t4, i64 %t5)
  %t6 = load i64, ptr %l4
  %t7 = call ptr @__olang_sb_room(ptr %s1, i64 24)
  %t8 = call i64 @__olang_fmt_i64(ptr %t7, i64 %t6)
  call void @__olang_sb_add(ptr %s1, i64 %t8)
  %t9 = extractvalue { i64, ptr } { i64 4, ptr @.d10 }, 1
  %t10 = extractvalue { i64, ptr } { i64 4, ptr @.d10 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t9, i64 %t10)
  %t11 = load i64, ptr %l5
  %t12 = call ptr @__olang_sb_room(ptr %s1, i64 24)
  %t13 = call i64 @__olang_fmt_i64(ptr %t12, i64 %t11)
  call void @__olang_sb_add(ptr %s1, i64 %t13)
  %t14 = extractvalue { i64, ptr } { i64 18, ptr @.d11 }, 1
  %t15 = extractvalue { i64, ptr } { i64 18, ptr @.d11 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t14, i64 %t15)
  %t16 = load i64, ptr %l6
  %t17 = call ptr @__olang_sb_room(ptr %s1, i64 24)
  %t18 = call i64 @__olang_fmt_i64(ptr %t17, i64 %t16)
  call void @__olang_sb_add(ptr %s1, i64 %t18)
  %t19 = load ptr, ptr %s1
  %t20 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t21 = load i64, ptr %t20
  %t22 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t19, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  store { i64, ptr } %t24, ptr %l7
  call void @__olang_sb_done(ptr %s1)
  %t25 = load { i64, ptr }, ptr %l7
  %t26 = extractvalue { i64, ptr } %t25, 0
  %t27 = extractvalue { i64, ptr } %t25, 1
  %t28 = mul i64 %t26, 1
  %t29 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t28)
  call void @llvm.memcpy.p0.p0.i64(ptr %t29, ptr %t27, i64 %t28, i1 false)
  %t30 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  store { i64, ptr } %t31, ptr %l8
  %t32 = load i32, ptr %l3
  %t33 = load { i64, ptr }, ptr %l8
  %t34 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t32, { i64, ptr } { i64 3, ptr @.d12 }, { i64, ptr } %t33)
  store %"compiler/msgs:Msg" %t34, ptr %l9
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t35 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t35, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayLengthRange(ptr %v0, i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 148, ptr %l1
  %t1 = load i64, ptr %l0
  store i64 %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 73, ptr @.d13 }, 1
  %t3 = extractvalue { i64, ptr } { i64 73, ptr @.d13 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load i64, ptr %l2
  %t5 = call ptr @__olang_sb_room(ptr %s1, i64 24)
  %t6 = call i64 @__olang_fmt_i64(ptr %t5, i64 %t4)
  call void @__olang_sb_add(ptr %s1, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t20, { i64, ptr } { i64 3, ptr @.d14 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayNestedByValue(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 157, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 66, ptr @.d15 }, 1
  %t3 = extractvalue { i64, ptr } { i64 66, ptr @.d15 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 48, ptr @.d16 }, 1
  %t8 = extractvalue { i64, ptr } { i64 48, ptr @.d16 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 8, ptr @.d17 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayOneIndex(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 188, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 61, ptr @.d18 }, 1
  %t6 = extractvalue { i64, ptr } { i64 61, ptr @.d18 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 3, ptr @.d19 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayParamByValue(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 170, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = extractvalue { i64, ptr } { i64 16, ptr @.d20 }, 1
  %t4 = extractvalue { i64, ptr } { i64 16, ptr @.d20 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = load { i64, ptr }, ptr %l3
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 32, ptr @.d21 }, 1
  %t9 = extractvalue { i64, ptr } { i64 32, ptr @.d21 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load { i64, ptr }, ptr %l4
  %t11 = extractvalue { i64, ptr } %t10, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = extractvalue { i64, ptr } { i64 1, ptr @.d22 }, 1
  %t14 = extractvalue { i64, ptr } { i64 1, ptr @.d22 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t13, i64 %t14)
  %t15 = load ptr, ptr %s1
  %t16 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t17 = load i64, ptr %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t15, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t21 = load { i64, ptr }, ptr %l5
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l6
  %t28 = load i32, ptr %l2
  %t29 = load { i64, ptr }, ptr %l6
  %t30 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t28, { i64, ptr } { i64 3, ptr @.d23 }, { i64, ptr } %t29)
  store %"compiler/msgs:Msg" %t30, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t31 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t31, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eArraySizeMismatch(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 223, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = load { i64, ptr }, ptr %l3
  %t4 = extractvalue { i64, ptr } %t3, 1
  %t5 = extractvalue { i64, ptr } %t3, 0
  call void @__olang_sb_put(ptr %s1, ptr %t4, i64 %t5)
  %t6 = extractvalue { i64, ptr } { i64 14, ptr @.d24 }, 1
  %t7 = extractvalue { i64, ptr } { i64 14, ptr @.d24 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = load { i64, ptr }, ptr %l4
  %t9 = extractvalue { i64, ptr } %t8, 1
  %t10 = extractvalue { i64, ptr } %t8, 0
  call void @__olang_sb_put(ptr %s1, ptr %t9, i64 %t10)
  %t11 = extractvalue { i64, ptr } { i64 37, ptr @.d25 }, 1
  %t12 = extractvalue { i64, ptr } { i64 37, ptr @.d25 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = load ptr, ptr %s1
  %t14 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t15 = load i64, ptr %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t13, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t19 = load { i64, ptr }, ptr %l5
  %t20 = extractvalue { i64, ptr } %t19, 0
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = mul i64 %t20, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t22)
  call void @llvm.memcpy.p0.p0.i64(ptr %t23, ptr %t21, i64 %t22, i1 false)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l6
  %t26 = load i32, ptr %l2
  %t27 = load { i64, ptr }, ptr %l6
  %t28 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t26, { i64, ptr } { i64 3, ptr @.d26 }, { i64, ptr } %t27)
  store %"compiler/msgs:Msg" %t28, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t29, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayTypeHoldsItself(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 128, ptr %l3
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l4
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l5
  %t3 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t3, ptr %l6
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t4 = load { i64, ptr }, ptr %l4
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 88, ptr @.d27 }, 1
  %t8 = extractvalue { i64, ptr } { i64 88, ptr @.d27 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load { i64, ptr }, ptr %l5
  %t10 = extractvalue { i64, ptr } %t9, 1
  %t11 = extractvalue { i64, ptr } %t9, 0
  call void @__olang_sb_put(ptr %s1, ptr %t10, i64 %t11)
  %t12 = extractvalue { i64, ptr } { i64 14, ptr @.d28 }, 1
  %t13 = extractvalue { i64, ptr } { i64 14, ptr @.d28 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t12, i64 %t13)
  %t14 = load { i64, ptr }, ptr %l6
  %t15 = extractvalue { i64, ptr } %t14, 1
  %t16 = extractvalue { i64, ptr } %t14, 0
  call void @__olang_sb_put(ptr %s1, ptr %t15, i64 %t16)
  %t17 = extractvalue { i64, ptr } { i64 3, ptr @.d29 }, 1
  %t18 = extractvalue { i64, ptr } { i64 3, ptr @.d29 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t17, i64 %t18)
  %t19 = load ptr, ptr %s1
  %t20 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t21 = load i64, ptr %t20
  %t22 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t19, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  store { i64, ptr } %t24, ptr %l7
  call void @__olang_sb_done(ptr %s1)
  %t25 = load { i64, ptr }, ptr %l7
  %t26 = extractvalue { i64, ptr } %t25, 0
  %t27 = extractvalue { i64, ptr } %t25, 1
  %t28 = mul i64 %t26, 1
  %t29 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t28)
  call void @llvm.memcpy.p0.p0.i64(ptr %t29, ptr %t27, i64 %t28, i1 false)
  %t30 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  store { i64, ptr } %t31, ptr %l8
  %t32 = load i32, ptr %l3
  %t33 = load { i64, ptr }, ptr %l8
  %t34 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 %t32, { i64, ptr } { i64 3, ptr @.d30 }, { i64, ptr } %t33)
  store %"compiler/msgs:Msg" %t34, ptr %l9
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t35 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t35, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrowInStatement(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 428, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 4, ptr @.d31 }, { i64, ptr } { i64 94, ptr @.d32 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrowLeaves(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 429, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = extractvalue { i64, ptr } { i64 24, ptr @.d33 }, 1
  %t4 = extractvalue { i64, ptr } { i64 24, ptr @.d33 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = load { i64, ptr }, ptr %l3
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 50, ptr @.d34 }, 1
  %t9 = extractvalue { i64, ptr } { i64 50, ptr @.d34 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load { i64, ptr }, ptr %l4
  %t11 = extractvalue { i64, ptr } %t10, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = extractvalue { i64, ptr } { i64 3, ptr @.d35 }, 1
  %t14 = extractvalue { i64, ptr } { i64 3, ptr @.d35 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t13, i64 %t14)
  %t15 = load ptr, ptr %s1
  %t16 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t17 = load i64, ptr %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t15, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t21 = load { i64, ptr }, ptr %l5
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l6
  %t28 = load i32, ptr %l2
  %t29 = load { i64, ptr }, ptr %l6
  %t30 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t28, { i64, ptr } { i64 4, ptr @.d36 }, { i64, ptr } %t29)
  store %"compiler/msgs:Msg" %t30, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t31 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t31, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAsArrayLength(ptr %v0, i64 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 150, ptr %l2
  %t1 = load i64, ptr %l0
  store i64 %t1, ptr %l3
  %t2 = load i64, ptr %l1
  store i64 %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = extractvalue { i64, ptr } { i64 23, ptr @.d37 }, 1
  %t4 = extractvalue { i64, ptr } { i64 23, ptr @.d37 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = load i64, ptr %l3
  %t6 = call ptr @__olang_sb_room(ptr %s1, i64 24)
  %t7 = call i64 @__olang_fmt_i64(ptr %t6, i64 %t5)
  call void @__olang_sb_add(ptr %s1, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 6, ptr @.d38 }, 1
  %t9 = extractvalue { i64, ptr } { i64 6, ptr @.d38 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load i64, ptr %l4
  %t11 = call ptr @__olang_sb_room(ptr %s1, i64 24)
  %t12 = call i64 @__olang_fmt_i64(ptr %t11, i64 %t10)
  call void @__olang_sb_add(ptr %s1, i64 %t12)
  %t13 = load ptr, ptr %s1
  %t14 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t15 = load i64, ptr %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t13, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t19 = load { i64, ptr }, ptr %l5
  %t20 = extractvalue { i64, ptr } %t19, 0
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = mul i64 %t20, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t22)
  call void @llvm.memcpy.p0.p0.i64(ptr %t23, ptr %t21, i64 %t22, i1 false)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l6
  %t26 = load i32, ptr %l2
  %t27 = load { i64, ptr }, ptr %l6
  %t28 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t26, { i64, ptr } { i64 4, ptr @.d39 }, { i64, ptr } %t27)
  store %"compiler/msgs:Msg" %t28, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t29, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAsNeedsCase(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 346, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = extractvalue { i64, ptr } { i64 35, ptr @.d40 }, 1
  %t4 = extractvalue { i64, ptr } { i64 35, ptr @.d40 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = load { i64, ptr }, ptr %l3
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 8, ptr @.d41 }, 1
  %t9 = extractvalue { i64, ptr } { i64 8, ptr @.d41 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load { i64, ptr }, ptr %l4
  %t11 = extractvalue { i64, ptr } %t10, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = load ptr, ptr %s1
  %t14 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t15 = load i64, ptr %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t13, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t19 = load { i64, ptr }, ptr %l5
  %t20 = extractvalue { i64, ptr } %t19, 0
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = mul i64 %t20, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t22)
  call void @llvm.memcpy.p0.p0.i64(ptr %t23, ptr %t21, i64 %t22, i1 false)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l6
  %t26 = load i32, ptr %l2
  %t27 = load { i64, ptr }, ptr %l6
  %t28 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t26, { i64, ptr } { i64 3, ptr @.d42 }, { i64, ptr } %t27)
  store %"compiler/msgs:Msg" %t28, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t29, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAsNothing(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 350, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 5, ptr @.d43 }, 1
  %t3 = extractvalue { i64, ptr } { i64 5, ptr @.d43 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 49, ptr @.d44 }, 1
  %t8 = extractvalue { i64, ptr } { i64 49, ptr @.d44 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 3, ptr @.d45 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertAborts(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 515, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 62, ptr @.d46 }, 1
  %t3 = extractvalue { i64, ptr } { i64 62, ptr @.d46 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 4, ptr @.d47 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertFalse(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 509, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 4, ptr @.d48 }, { i64, ptr } { i64 50, ptr @.d49 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertFalseMessage(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 510, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 52, ptr @.d50 }, 1
  %t3 = extractvalue { i64, ptr } { i64 52, ptr @.d50 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 4, ptr @.d51 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertMessageNotText(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 514, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 38, ptr @.d52 }, 1
  %t3 = extractvalue { i64, ptr } { i64 38, ptr @.d52 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 31, ptr @.d53 }, 1
  %t8 = extractvalue { i64, ptr } { i64 31, ptr @.d53 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 4, ptr @.d54 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertMsgError(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 512, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d55 }, { i64, ptr } { i64 58, ptr @.d56 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertMsgLoopJump(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 513, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 79, ptr @.d57 }, 1
  %t6 = extractvalue { i64, ptr } { i64 79, ptr @.d57 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 3, ptr @.d58 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertMsgReturns(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 511, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d59 }, { i64, ptr } { i64 95, ptr @.d60 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssignIntoTried(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 287, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d61 }, { i64, ptr } { i64 164, ptr @.d62 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssignListCount(ptr %v0, i64 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 395, ptr %l2
  %t1 = load i64, ptr %l0
  store i64 %t1, ptr %l3
  %t2 = load i64, ptr %l1
  store i64 %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = load i64, ptr %l3
  %t4 = call ptr @__olang_sb_room(ptr %s1, i64 24)
  %t5 = call i64 @__olang_fmt_i64(ptr %t4, i64 %t3)
  call void @__olang_sb_add(ptr %s1, i64 %t5)
  %t6 = extractvalue { i64, ptr } { i64 36, ptr @.d63 }, 1
  %t7 = extractvalue { i64, ptr } { i64 36, ptr @.d63 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = load i64, ptr %l4
  %t9 = call ptr @__olang_sb_room(ptr %s1, i64 24)
  %t10 = call i64 @__olang_fmt_i64(ptr %t9, i64 %t8)
  call void @__olang_sb_add(ptr %s1, i64 %t10)
  %t11 = load ptr, ptr %s1
  %t12 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t13 = load i64, ptr %t12
  %t14 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t13)
  call void @llvm.memcpy.p0.p0.i64(ptr %t14, ptr %t11, i64 %t13, i1 false)
  %t15 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t17 = load { i64, ptr }, ptr %l5
  %t18 = extractvalue { i64, ptr } %t17, 0
  %t19 = extractvalue { i64, ptr } %t17, 1
  %t20 = mul i64 %t18, 1
  %t21 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t20)
  call void @llvm.memcpy.p0.p0.i64(ptr %t21, ptr %t19, i64 %t20, i1 false)
  %t22 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l6
  %t24 = load i32, ptr %l2
  %t25 = load { i64, ptr }, ptr %l6
  %t26 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t24, { i64, ptr } { i64 3, ptr @.d64 }, { i64, ptr } %t25)
  store %"compiler/msgs:Msg" %t26, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t27 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t27, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAtUndeclared(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 355, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 52, ptr @.d65 }, 1
  %t6 = extractvalue { i64, ptr } { i64 52, ptr @.d65 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 3, ptr @.d66 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAtomicNotInteger(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 367, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 60, ptr @.d67 }, 1
  %t3 = extractvalue { i64, ptr } { i64 60, ptr @.d67 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 8, ptr @.d68 }, 1
  %t8 = extractvalue { i64, ptr } { i64 8, ptr @.d68 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 2, ptr @.d69 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAtomicNotPlace(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 275, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 2, ptr @.d70 }, { i64, ptr } { i64 71, ptr @.d71 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAtomicNotWritable(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 276, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 2, ptr @.d72 }, { i64, ptr } { i64 62, ptr @.d73 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBangNothingFails(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 381, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d74 }, { i64, ptr } { i64 44, ptr @.d75 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBlockNotClosed(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store i64 %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 64, ptr %l2
  %t1 = load i64, ptr %l0
  store i64 %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = extractvalue { i64, ptr } { i64 25, ptr @.d76 }, 1
  %t4 = extractvalue { i64, ptr } { i64 25, ptr @.d76 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = load i64, ptr %l3
  %t6 = call ptr @__olang_sb_room(ptr %s1, i64 24)
  %t7 = call i64 @__olang_fmt_i64(ptr %t6, i64 %t5)
  call void @__olang_sb_add(ptr %s1, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 20, ptr @.d77 }, 1
  %t9 = extractvalue { i64, ptr } { i64 20, ptr @.d77 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load { i64, ptr }, ptr %l4
  %t11 = extractvalue { i64, ptr } %t10, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = load ptr, ptr %s1
  %t14 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t15 = load i64, ptr %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t13, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t19 = load { i64, ptr }, ptr %l5
  %t20 = extractvalue { i64, ptr } %t19, 0
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = mul i64 %t20, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t22)
  call void @llvm.memcpy.p0.p0.i64(ptr %t23, ptr %t21, i64 %t22, i1 false)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l6
  %t26 = load i32, ptr %l2
  %t27 = load { i64, ptr }, ptr %l6
  %t28 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t26, { i64, ptr } { i64 0, ptr @.d78 }, { i64, ptr } %t27)
  store %"compiler/msgs:Msg" %t28, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t29, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBorrowSplitScopes(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 259, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d79 }, { i64, ptr } { i64 153, ptr @.d80 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBorrowSplitValue(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 261, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 4, ptr @.d81 }, { i64, ptr } { i64 114, ptr @.d82 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBreakOutsideLoop(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 500, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 51, ptr @.d83 }, 1
  %t6 = extractvalue { i64, ptr } { i64 51, ptr @.d83 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 3, ptr @.d84 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuildConstRedeclared(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 113, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 42, ptr @.d85 }, 1
  %t6 = extractvalue { i64, ptr } { i64 42, ptr @.d85 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 3, ptr @.d86 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuildDefaultFit(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 116, ptr %l4
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l5
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l6
  %t3 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t3, ptr %l7
  %t4 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t4, ptr %l8
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t5 = extractvalue { i64, ptr } { i64 8, ptr @.d87 }, 1
  %t6 = extractvalue { i64, ptr } { i64 8, ptr @.d87 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load { i64, ptr }, ptr %l5
  %t8 = extractvalue { i64, ptr } %t7, 1
  %t9 = extractvalue { i64, ptr } %t7, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = extractvalue { i64, ptr } { i64 1, ptr @.d88 }, 1
  %t11 = extractvalue { i64, ptr } { i64 1, ptr @.d88 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t10, i64 %t11)
  %t12 = load { i64, ptr }, ptr %l6
  %t13 = extractvalue { i64, ptr } %t12, 1
  %t14 = extractvalue { i64, ptr } %t12, 0
  call void @__olang_sb_put(ptr %s1, ptr %t13, i64 %t14)
  %t15 = extractvalue { i64, ptr } { i64 14, ptr @.d89 }, 1
  %t16 = extractvalue { i64, ptr } { i64 14, ptr @.d89 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t15, i64 %t16)
  %t17 = load { i64, ptr }, ptr %l7
  %t18 = extractvalue { i64, ptr } %t17, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  call void @__olang_sb_put(ptr %s1, ptr %t18, i64 %t19)
  %t20 = extractvalue { i64, ptr } { i64 11, ptr @.d90 }, 1
  %t21 = extractvalue { i64, ptr } { i64 11, ptr @.d90 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t20, i64 %t21)
  %t22 = load { i64, ptr }, ptr %l8
  %t23 = extractvalue { i64, ptr } %t22, 1
  %t24 = extractvalue { i64, ptr } %t22, 0
  call void @__olang_sb_put(ptr %s1, ptr %t23, i64 %t24)
  %t25 = load ptr, ptr %s1
  %t26 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t27 = load i64, ptr %t26
  %t28 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t27)
  call void @llvm.memcpy.p0.p0.i64(ptr %t28, ptr %t25, i64 %t27, i1 false)
  %t29 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  store { i64, ptr } %t30, ptr %l9
  call void @__olang_sb_done(ptr %s1)
  %t31 = load { i64, ptr }, ptr %l9
  %t32 = extractvalue { i64, ptr } %t31, 0
  %t33 = extractvalue { i64, ptr } %t31, 1
  %t34 = mul i64 %t32, 1
  %t35 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t34)
  call void @llvm.memcpy.p0.p0.i64(ptr %t35, ptr %t33, i64 %t34, i1 false)
  %t36 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  store { i64, ptr } %t37, ptr %l10
  %t38 = load i32, ptr %l4
  %t39 = load { i64, ptr }, ptr %l10
  %t40 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, i32 %t38, { i64, ptr } { i64 4, ptr @.d91 }, { i64, ptr } %t39)
  store %"compiler/msgs:Msg" %t40, ptr %l11
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t41 = load %"compiler/msgs:Msg", ptr %l11
  store %"compiler/msgs:Msg" %t41, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuildDefaultMut(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 114, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 85, ptr @.d92 }, 1
  %t6 = extractvalue { i64, ptr } { i64 85, ptr @.d92 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 4, ptr @.d93 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuildDefaultType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 115, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = load { i64, ptr }, ptr %l3
  %t4 = extractvalue { i64, ptr } %t3, 1
  %t5 = extractvalue { i64, ptr } %t3, 0
  call void @__olang_sb_put(ptr %s1, ptr %t4, i64 %t5)
  %t6 = extractvalue { i64, ptr } { i64 91, ptr @.d94 }, 1
  %t7 = extractvalue { i64, ptr } { i64 91, ptr @.d94 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = load { i64, ptr }, ptr %l4
  %t9 = extractvalue { i64, ptr } %t8, 1
  %t10 = extractvalue { i64, ptr } %t8, 0
  call void @__olang_sb_put(ptr %s1, ptr %t9, i64 %t10)
  %t11 = load ptr, ptr %s1
  %t12 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t13 = load i64, ptr %t12
  %t14 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t13)
  call void @llvm.memcpy.p0.p0.i64(ptr %t14, ptr %t11, i64 %t13, i1 false)
  %t15 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t17 = load { i64, ptr }, ptr %l5
  %t18 = extractvalue { i64, ptr } %t17, 0
  %t19 = extractvalue { i64, ptr } %t17, 1
  %t20 = mul i64 %t18, 1
  %t21 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t20)
  call void @llvm.memcpy.p0.p0.i64(ptr %t21, ptr %t19, i64 %t20, i1 false)
  %t22 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l6
  %t24 = load i32, ptr %l2
  %t25 = load { i64, ptr }, ptr %l6
  %t26 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t24, { i64, ptr } { i64 4, ptr @.d95 }, { i64, ptr } %t25)
  store %"compiler/msgs:Msg" %t26, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t27 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t27, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuildIntoUnknownScope(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 248, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 8, ptr @.d96 }, { i64, ptr } { i64 113, ptr @.d97 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuildThroughUnknownScope(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 251, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d98 }, { i64, ptr } { i64 113, ptr @.d99 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuiltinTypeRedeclared(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 111, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 43, ptr @.d100 }, 1
  %t6 = extractvalue { i64, ptr } { i64 43, ptr @.d100 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 3, ptr @.d101 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCallValueObligations(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 493, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 107, ptr @.d102 }, 1
  %t6 = extractvalue { i64, ptr } { i64 107, ptr @.d102 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 9, ptr @.d103 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 35, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 0, ptr @.d104 }, { i64, ptr } { i64 21, ptr @.d105 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotRun(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 13, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 27, ptr @.d106 }, 1
  %t3 = extractvalue { i64, ptr } { i64 27, ptr @.d106 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 3, ptr @.d107 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaptureReadOnly(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 289, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 4, ptr @.d108 }, { i64, ptr } { i64 84, ptr @.d109 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseAfterWildcard(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 441, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 4, ptr @.d110 }, { i64, ptr } { i64 73, ptr @.d111 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseBlockStays(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 431, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 4, ptr @.d112 }, { i64, ptr } { i64 66, ptr @.d113 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseIsSubject(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 443, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 115, ptr @.d114 }, 1
  %t6 = extractvalue { i64, ptr } { i64 115, ptr @.d114 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 4, ptr @.d115 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseUnknownName(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 442, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 13, ptr @.d116 }, 1
  %t3 = extractvalue { i64, ptr } { i64 13, ptr @.d116 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 101, ptr @.d117 }, 1
  %t8 = extractvalue { i64, ptr } { i64 101, ptr @.d117 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 4, ptr @.d118 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseValueType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 426, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = extractvalue { i64, ptr } { i64 21, ptr @.d119 }, 1
  %t4 = extractvalue { i64, ptr } { i64 21, ptr @.d119 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = load { i64, ptr }, ptr %l3
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 8, ptr @.d120 }, 1
  %t9 = extractvalue { i64, ptr } { i64 8, ptr @.d120 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load { i64, ptr }, ptr %l4
  %t11 = extractvalue { i64, ptr } %t10, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = load ptr, ptr %s1
  %t14 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t15 = load i64, ptr %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t13, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t19 = load { i64, ptr }, ptr %l5
  %t20 = extractvalue { i64, ptr } %t19, 0
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = mul i64 %t20, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t22)
  call void @llvm.memcpy.p0.p0.i64(ptr %t23, ptr %t21, i64 %t22, i1 false)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l6
  %t26 = load i32, ptr %l2
  %t27 = load { i64, ptr }, ptr %l6
  %t28 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t26, { i64, ptr } { i64 3, ptr @.d121 }, { i64, ptr } %t27)
  store %"compiler/msgs:Msg" %t28, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t29, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCatchAfterCatchAll(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 372, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 4, ptr @.d122 }, { i64, ptr } { i64 78, ptr @.d123 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCatchMustLeave(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 376, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d124 }, { i64, ptr } { i64 57, ptr @.d125 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCatchNotProduced(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 502, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 28, ptr @.d126 }, 1
  %t3 = extractvalue { i64, ptr } { i64 28, ptr @.d126 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 3, ptr @.d127 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCatchUnreachable(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 373, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 4, ptr @.d128 }, { i64, ptr } { i64 58, ptr @.d129 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCatchWordNotProduced(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 460, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = extractvalue { i64, ptr } { i64 28, ptr @.d130 }, 1
  %t4 = extractvalue { i64, ptr } { i64 28, ptr @.d130 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = load { i64, ptr }, ptr %l3
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 17, ptr @.d131 }, 1
  %t9 = extractvalue { i64, ptr } { i64 17, ptr @.d131 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load { i64, ptr }, ptr %l4
  %t11 = extractvalue { i64, ptr } %t10, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = load ptr, ptr %s1
  %t14 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t15 = load i64, ptr %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t13, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t19 = load { i64, ptr }, ptr %l5
  %t20 = extractvalue { i64, ptr } %t19, 0
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = mul i64 %t20, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t22)
  call void @llvm.memcpy.p0.p0.i64(ptr %t23, ptr %t21, i64 %t22, i1 false)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l6
  %t26 = load i32, ptr %l2
  %t27 = load { i64, ptr }, ptr %l6
  %t28 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t26, { i64, ptr } { i64 3, ptr @.d132 }, { i64, ptr } %t27)
  store %"compiler/msgs:Msg" %t28, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t29, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCheckedNotSuperset(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 192, ptr %l4
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l5
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l6
  %t3 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t3, ptr %l7
  %t4 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t4, ptr %l8
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t5 = load { i64, ptr }, ptr %l5
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 4, ptr @.d133 }, 1
  %t9 = extractvalue { i64, ptr } { i64 4, ptr @.d133 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load { i64, ptr }, ptr %l6
  %t11 = extractvalue { i64, ptr } %t10, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = extractvalue { i64, ptr } { i64 46, ptr @.d134 }, 1
  %t14 = extractvalue { i64, ptr } { i64 46, ptr @.d134 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t13, i64 %t14)
  %t15 = load { i64, ptr }, ptr %l7
  %t16 = extractvalue { i64, ptr } %t15, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  call void @__olang_sb_put(ptr %s1, ptr %t16, i64 %t17)
  %t18 = extractvalue { i64, ptr } { i64 11, ptr @.d135 }, 1
  %t19 = extractvalue { i64, ptr } { i64 11, ptr @.d135 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t18, i64 %t19)
  %t20 = load { i64, ptr }, ptr %l8
  %t21 = extractvalue { i64, ptr } %t20, 1
  %t22 = extractvalue { i64, ptr } %t20, 0
  call void @__olang_sb_put(ptr %s1, ptr %t21, i64 %t22)
  %t23 = extractvalue { i64, ptr } { i64 14, ptr @.d136 }, 1
  %t24 = extractvalue { i64, ptr } { i64 14, ptr @.d136 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t23, i64 %t24)
  %t25 = load ptr, ptr %s1
  %t26 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t27 = load i64, ptr %t26
  %t28 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t27)
  call void @llvm.memcpy.p0.p0.i64(ptr %t28, ptr %t25, i64 %t27, i1 false)
  %t29 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  store { i64, ptr } %t30, ptr %l9
  call void @__olang_sb_done(ptr %s1)
  %t31 = load { i64, ptr }, ptr %l9
  %t32 = extractvalue { i64, ptr } %t31, 0
  %t33 = extractvalue { i64, ptr } %t31, 1
  %t34 = mul i64 %t32, 1
  %t35 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t34)
  call void @llvm.memcpy.p0.p0.i64(ptr %t35, ptr %t33, i64 %t34, i1 false)
  %t36 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  store { i64, ptr } %t37, ptr %l10
  %t38 = load i32, ptr %l4
  %t39 = load { i64, ptr }, ptr %l10
  %t40 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, i32 %t38, { i64, ptr } { i64 4, ptr @.d137 }, { i64, ptr } %t39)
  store %"compiler/msgs:Msg" %t40, ptr %l11
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t41 = load %"compiler/msgs:Msg", ptr %l11
  store %"compiler/msgs:Msg" %t41, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCheckedWithoutPlain(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 191, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = load { i64, ptr }, ptr %l3
  %t4 = extractvalue { i64, ptr } %t3, 1
  %t5 = extractvalue { i64, ptr } %t3, 0
  call void @__olang_sb_put(ptr %s1, ptr %t4, i64 %t5)
  %t6 = extractvalue { i64, ptr } { i64 71, ptr @.d138 }, 1
  %t7 = extractvalue { i64, ptr } { i64 71, ptr @.d138 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = load { i64, ptr }, ptr %l4
  %t9 = extractvalue { i64, ptr } %t8, 1
  %t10 = extractvalue { i64, ptr } %t8, 0
  call void @__olang_sb_put(ptr %s1, ptr %t9, i64 %t10)
  %t11 = extractvalue { i64, ptr } { i64 10, ptr @.d139 }, 1
  %t12 = extractvalue { i64, ptr } { i64 10, ptr @.d139 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = load ptr, ptr %s1
  %t14 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t15 = load i64, ptr %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t13, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t19 = load { i64, ptr }, ptr %l5
  %t20 = extractvalue { i64, ptr } %t19, 0
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = mul i64 %t20, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t22)
  call void @llvm.memcpy.p0.p0.i64(ptr %t23, ptr %t21, i64 %t22, i1 false)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l6
  %t26 = load i32, ptr %l2
  %t27 = load { i64, ptr }, ptr %l6
  %t28 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t26, { i64, ptr } { i64 4, ptr @.d140 }, { i64, ptr } %t27)
  store %"compiler/msgs:Msg" %t28, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t29, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eClangFailed(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 40, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 24, ptr @.d141 }, 1
  %t3 = extractvalue { i64, ptr } { i64 24, ptr @.d141 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 0, ptr @.d142 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eClauseLastValue(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 377, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 66, ptr @.d143 }, 1
  %t3 = extractvalue { i64, ptr } { i64 66, ptr @.d143 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 17, ptr @.d144 }, 1
  %t8 = extractvalue { i64, ptr } { i64 17, ptr @.d144 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 3, ptr @.d145 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eComprNeedsTry(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 417, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 8, ptr @.d146 }, { i64, ptr } { i64 69, ptr @.d147 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eComprehensionReferences(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 386, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d148 }, { i64, ptr } { i64 90, ptr @.d149 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondBranchTypes(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 335, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = extractvalue { i64, ptr } { i64 52, ptr @.d150 }, 1
  %t4 = extractvalue { i64, ptr } { i64 52, ptr @.d150 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = load { i64, ptr }, ptr %l3
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 5, ptr @.d151 }, 1
  %t9 = extractvalue { i64, ptr } { i64 5, ptr @.d151 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load { i64, ptr }, ptr %l4
  %t11 = extractvalue { i64, ptr } %t10, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = load ptr, ptr %s1
  %t14 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t15 = load i64, ptr %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t13, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t19 = load { i64, ptr }, ptr %l5
  %t20 = extractvalue { i64, ptr } %t19, 0
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = mul i64 %t20, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t22)
  call void @llvm.memcpy.p0.p0.i64(ptr %t23, ptr %t21, i64 %t22, i1 false)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l6
  %t26 = load i32, ptr %l2
  %t27 = load { i64, ptr }, ptr %l6
  %t28 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t26, { i64, ptr } { i64 3, ptr @.d152 }, { i64, ptr } %t27)
  store %"compiler/msgs:Msg" %t28, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t29, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondCycle(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 77, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 30, ptr @.d153 }, 1
  %t6 = extractvalue { i64, ptr } { i64 30, ptr @.d153 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 3, ptr @.d154 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondGlobalInit(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 76, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 56, ptr @.d155 }, 1
  %t6 = extractvalue { i64, ptr } { i64 56, ptr @.d155 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 3, ptr @.d156 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondLentWritable(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 359, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d157 }, { i64, ptr } { i64 190, ptr @.d158 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondMutable(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 75, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 52, ptr @.d159 }, 1
  %t6 = extractvalue { i64, ptr } { i64 52, ptr @.d159 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 3, ptr @.d160 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondName(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 74, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 62, ptr @.d161 }, 1
  %t6 = extractvalue { i64, ptr } { i64 62, ptr @.d161 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 3, ptr @.d162 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondNoMeet(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 79, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 59, ptr @.d163 }, 1
  %t6 = extractvalue { i64, ptr } { i64 59, ptr @.d163 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 3, ptr @.d164 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondNotBool(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 80, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 24, ptr @.d165 }, 1
  %t3 = extractvalue { i64, ptr } { i64 24, ptr @.d165 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 14, ptr @.d166 }, 1
  %t8 = extractvalue { i64, ptr } { i64 14, ptr @.d166 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 2, ptr @.d167 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondNotBoolType(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 334, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 29, ptr @.d168 }, 1
  %t3 = extractvalue { i64, ptr } { i64 29, ptr @.d168 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 0, ptr @.d169 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondTypes(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 78, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 28, ptr @.d170 }, 1
  %t6 = extractvalue { i64, ptr } { i64 28, ptr @.d170 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 2, ptr @.d171 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eConstArgParen(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 152, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 111, ptr @.d172 }, 1
  %t6 = extractvalue { i64, ptr } { i64 111, ptr @.d172 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 3, ptr @.d173 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eConstVarOnlyInExpr(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 145, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 18, ptr @.d174 }, 1
  %t3 = extractvalue { i64, ptr } { i64 18, ptr @.d174 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 146, ptr @.d175 }, 1
  %t8 = extractvalue { i64, ptr } { i64 146, ptr @.d175 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 7, ptr @.d176 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eConstVarShadowed(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 151, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 88, ptr @.d177 }, 1
  %t6 = extractvalue { i64, ptr } { i64 88, ptr @.d177 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 8, ptr @.d178 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eConstraintNotTrait(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 159, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 55, ptr @.d179 }, 1
  %t6 = extractvalue { i64, ptr } { i64 55, ptr @.d179 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 3, ptr @.d180 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eConstraintSealed(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 124, ptr %l5
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l6
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l7
  %t3 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t3, ptr %l8
  %t4 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t4, ptr %l9
  %t5 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t5, ptr %l10
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t6 = load { i64, ptr }, ptr %l6
  %t7 = extractvalue { i64, ptr } %t6, 1
  %t8 = extractvalue { i64, ptr } %t6, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = extractvalue { i64, ptr } { i64 33, ptr @.d181 }, 1
  %t10 = extractvalue { i64, ptr } { i64 33, ptr @.d181 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t9, i64 %t10)
  %t11 = load { i64, ptr }, ptr %l7
  %t12 = extractvalue { i64, ptr } %t11, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  call void @__olang_sb_put(ptr %s1, ptr %t12, i64 %t13)
  %t14 = extractvalue { i64, ptr } { i64 4, ptr @.d182 }, 1
  %t15 = extractvalue { i64, ptr } { i64 4, ptr @.d182 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t14, i64 %t15)
  %t16 = load { i64, ptr }, ptr %l8
  %t17 = extractvalue { i64, ptr } %t16, 1
  %t18 = extractvalue { i64, ptr } %t16, 0
  call void @__olang_sb_put(ptr %s1, ptr %t17, i64 %t18)
  %t19 = extractvalue { i64, ptr } { i64 2, ptr @.d183 }, 1
  %t20 = extractvalue { i64, ptr } { i64 2, ptr @.d183 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t19, i64 %t20)
  %t21 = load { i64, ptr }, ptr %l9
  %t22 = extractvalue { i64, ptr } %t21, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  call void @__olang_sb_put(ptr %s1, ptr %t22, i64 %t23)
  %t24 = extractvalue { i64, ptr } { i64 50, ptr @.d184 }, 1
  %t25 = extractvalue { i64, ptr } { i64 50, ptr @.d184 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t24, i64 %t25)
  %t26 = load { i64, ptr }, ptr %l10
  %t27 = extractvalue { i64, ptr } %t26, 1
  %t28 = extractvalue { i64, ptr } %t26, 0
  call void @__olang_sb_put(ptr %s1, ptr %t27, i64 %t28)
  %t29 = extractvalue { i64, ptr } { i64 12, ptr @.d185 }, 1
  %t30 = extractvalue { i64, ptr } { i64 12, ptr @.d185 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t29, i64 %t30)
  %t31 = load ptr, ptr %s1
  %t32 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t33 = load i64, ptr %t32
  %t34 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t33)
  call void @llvm.memcpy.p0.p0.i64(ptr %t34, ptr %t31, i64 %t33, i1 false)
  %t35 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  store { i64, ptr } %t36, ptr %l11
  call void @__olang_sb_done(ptr %s1)
  %t37 = load { i64, ptr }, ptr %l11
  %t38 = extractvalue { i64, ptr } %t37, 0
  %t39 = extractvalue { i64, ptr } %t37, 1
  %t40 = mul i64 %t38, 1
  %t41 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t40)
  call void @llvm.memcpy.p0.p0.i64(ptr %t41, ptr %t39, i64 %t40, i1 false)
  %t42 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t41, 1
  store { i64, ptr } %t43, ptr %l12
  %t44 = load i32, ptr %l5
  %t45 = load { i64, ptr }, ptr %l12
  %t46 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v5, ptr %v5, ptr %v5, i32 %t44, { i64, ptr } { i64 8, ptr @.d186 }, { i64, ptr } %t45)
  store %"compiler/msgs:Msg" %t46, ptr %l13
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t47 = load %"compiler/msgs:Msg", ptr %l13
  store %"compiler/msgs:Msg" %t47, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eConstraintUnmet(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 122, ptr %l3
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l4
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l5
  %t3 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t3, ptr %l6
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t4 = load { i64, ptr }, ptr %l4
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 33, ptr @.d187 }, 1
  %t8 = extractvalue { i64, ptr } { i64 33, ptr @.d187 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load { i64, ptr }, ptr %l5
  %t10 = extractvalue { i64, ptr } %t9, 1
  %t11 = extractvalue { i64, ptr } %t9, 0
  call void @__olang_sb_put(ptr %s1, ptr %t10, i64 %t11)
  %t12 = extractvalue { i64, ptr } { i64 4, ptr @.d188 }, 1
  %t13 = extractvalue { i64, ptr } { i64 4, ptr @.d188 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t12, i64 %t13)
  %t14 = load { i64, ptr }, ptr %l6
  %t15 = extractvalue { i64, ptr } %t14, 1
  %t16 = extractvalue { i64, ptr } %t14, 0
  call void @__olang_sb_put(ptr %s1, ptr %t15, i64 %t16)
  %t17 = load ptr, ptr %s1
  %t18 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t19 = load i64, ptr %t18
  %t20 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t17, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  store { i64, ptr } %t22, ptr %l7
  call void @__olang_sb_done(ptr %s1)
  %t23 = load { i64, ptr }, ptr %l7
  %t24 = extractvalue { i64, ptr } %t23, 0
  %t25 = extractvalue { i64, ptr } %t23, 1
  %t26 = mul i64 %t24, 1
  %t27 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t26)
  call void @llvm.memcpy.p0.p0.i64(ptr %t27, ptr %t25, i64 %t26, i1 false)
  %t28 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  store { i64, ptr } %t29, ptr %l8
  %t30 = load i32, ptr %l3
  %t31 = load { i64, ptr }, ptr %l8
  %t32 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 %t30, { i64, ptr } { i64 3, ptr @.d189 }, { i64, ptr } %t31)
  store %"compiler/msgs:Msg" %t32, ptr %l9
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t33 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t33, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eConstraintUnmetHash(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 125, ptr %l3
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l4
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l5
  %t3 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t3, ptr %l6
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t4 = load { i64, ptr }, ptr %l4
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 33, ptr @.d190 }, 1
  %t8 = extractvalue { i64, ptr } { i64 33, ptr @.d190 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load { i64, ptr }, ptr %l5
  %t10 = extractvalue { i64, ptr } %t9, 1
  %t11 = extractvalue { i64, ptr } %t9, 0
  call void @__olang_sb_put(ptr %s1, ptr %t10, i64 %t11)
  %t12 = extractvalue { i64, ptr } { i64 4, ptr @.d191 }, 1
  %t13 = extractvalue { i64, ptr } { i64 4, ptr @.d191 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t12, i64 %t13)
  %t14 = load { i64, ptr }, ptr %l6
  %t15 = extractvalue { i64, ptr } %t14, 1
  %t16 = extractvalue { i64, ptr } %t14, 0
  call void @__olang_sb_put(ptr %s1, ptr %t15, i64 %t16)
  %t17 = extractvalue { i64, ptr } { i64 59, ptr @.d192 }, 1
  %t18 = extractvalue { i64, ptr } { i64 59, ptr @.d192 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t17, i64 %t18)
  %t19 = load ptr, ptr %s1
  %t20 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t21 = load i64, ptr %t20
  %t22 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t19, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  store { i64, ptr } %t24, ptr %l7
  call void @__olang_sb_done(ptr %s1)
  %t25 = load { i64, ptr }, ptr %l7
  %t26 = extractvalue { i64, ptr } %t25, 0
  %t27 = extractvalue { i64, ptr } %t25, 1
  %t28 = mul i64 %t26, 1
  %t29 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t28)
  call void @llvm.memcpy.p0.p0.i64(ptr %t29, ptr %t27, i64 %t28, i1 false)
  %t30 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  store { i64, ptr } %t31, ptr %l8
  %t32 = load i32, ptr %l3
  %t33 = load { i64, ptr }, ptr %l8
  %t34 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 %t32, { i64, ptr } { i64 9, ptr @.d193 }, { i64, ptr } %t33)
  store %"compiler/msgs:Msg" %t34, ptr %l9
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t35 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t35, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eConstraintUnmetMethod(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 123, ptr %l4
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l5
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l6
  %t3 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t3, ptr %l7
  %t4 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t4, ptr %l8
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t5 = load { i64, ptr }, ptr %l5
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 33, ptr @.d194 }, 1
  %t9 = extractvalue { i64, ptr } { i64 33, ptr @.d194 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load { i64, ptr }, ptr %l6
  %t11 = extractvalue { i64, ptr } %t10, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = extractvalue { i64, ptr } { i64 4, ptr @.d195 }, 1
  %t14 = extractvalue { i64, ptr } { i64 4, ptr @.d195 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t13, i64 %t14)
  %t15 = load { i64, ptr }, ptr %l7
  %t16 = extractvalue { i64, ptr } %t15, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  call void @__olang_sb_put(ptr %s1, ptr %t16, i64 %t17)
  %t18 = extractvalue { i64, ptr } { i64 19, ptr @.d196 }, 1
  %t19 = extractvalue { i64, ptr } { i64 19, ptr @.d196 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t18, i64 %t19)
  %t20 = load { i64, ptr }, ptr %l8
  %t21 = extractvalue { i64, ptr } %t20, 1
  %t22 = extractvalue { i64, ptr } %t20, 0
  call void @__olang_sb_put(ptr %s1, ptr %t21, i64 %t22)
  %t23 = extractvalue { i64, ptr } { i64 10, ptr @.d197 }, 1
  %t24 = extractvalue { i64, ptr } { i64 10, ptr @.d197 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t23, i64 %t24)
  %t25 = load ptr, ptr %s1
  %t26 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t27 = load i64, ptr %t26
  %t28 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t27)
  call void @llvm.memcpy.p0.p0.i64(ptr %t28, ptr %t25, i64 %t27, i1 false)
  %t29 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  store { i64, ptr } %t30, ptr %l9
  call void @__olang_sb_done(ptr %s1)
  %t31 = load { i64, ptr }, ptr %l9
  %t32 = extractvalue { i64, ptr } %t31, 0
  %t33 = extractvalue { i64, ptr } %t31, 1
  %t34 = mul i64 %t32, 1
  %t35 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t34)
  call void @llvm.memcpy.p0.p0.i64(ptr %t35, ptr %t33, i64 %t34, i1 false)
  %t36 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  store { i64, ptr } %t37, ptr %l10
  %t38 = load i32, ptr %l4
  %t39 = load { i64, ptr }, ptr %l10
  %t40 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, i32 %t38, { i64, ptr } { i64 3, ptr @.d198 }, { i64, ptr } %t39)
  store %"compiler/msgs:Msg" %t40, ptr %l11
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t41 = load %"compiler/msgs:Msg", ptr %l11
  store %"compiler/msgs:Msg" %t41, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCtorFieldNamesVar(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 271, ptr %l4
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l5
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l6
  %t3 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t3, ptr %l7
  %t4 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t4, ptr %l8
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t5 = extractvalue { i64, ptr } { i64 18, ptr @.d199 }, 1
  %t6 = extractvalue { i64, ptr } { i64 18, ptr @.d199 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load { i64, ptr }, ptr %l5
  %t8 = extractvalue { i64, ptr } %t7, 1
  %t9 = extractvalue { i64, ptr } %t7, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = extractvalue { i64, ptr } { i64 7, ptr @.d200 }, 1
  %t11 = extractvalue { i64, ptr } { i64 7, ptr @.d200 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t10, i64 %t11)
  %t12 = load { i64, ptr }, ptr %l6
  %t13 = extractvalue { i64, ptr } %t12, 1
  %t14 = extractvalue { i64, ptr } %t12, 0
  call void @__olang_sb_put(ptr %s1, ptr %t13, i64 %t14)
  %t15 = extractvalue { i64, ptr } { i64 105, ptr @.d201 }, 1
  %t16 = extractvalue { i64, ptr } { i64 105, ptr @.d201 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t15, i64 %t16)
  %t17 = load { i64, ptr }, ptr %l7
  %t18 = extractvalue { i64, ptr } %t17, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  call void @__olang_sb_put(ptr %s1, ptr %t18, i64 %t19)
  %t20 = extractvalue { i64, ptr } { i64 1, ptr @.d202 }, 1
  %t21 = extractvalue { i64, ptr } { i64 1, ptr @.d202 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t20, i64 %t21)
  %t22 = load { i64, ptr }, ptr %l8
  %t23 = extractvalue { i64, ptr } %t22, 1
  %t24 = extractvalue { i64, ptr } %t22, 0
  call void @__olang_sb_put(ptr %s1, ptr %t23, i64 %t24)
  %t25 = extractvalue { i64, ptr } { i64 2, ptr @.d203 }, 1
  %t26 = extractvalue { i64, ptr } { i64 2, ptr @.d203 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t25, i64 %t26)
  %t27 = load ptr, ptr %s1
  %t28 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t29 = load i64, ptr %t28
  %t30 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t27, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  store { i64, ptr } %t32, ptr %l9
  call void @__olang_sb_done(ptr %s1)
  %t33 = load { i64, ptr }, ptr %l9
  %t34 = extractvalue { i64, ptr } %t33, 0
  %t35 = extractvalue { i64, ptr } %t33, 1
  %t36 = mul i64 %t34, 1
  %t37 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t36)
  call void @llvm.memcpy.p0.p0.i64(ptr %t37, ptr %t35, i64 %t36, i1 false)
  %t38 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l10
  %t40 = load i32, ptr %l4
  %t41 = load { i64, ptr }, ptr %l10
  %t42 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, i32 %t40, { i64, ptr } { i64 4, ptr @.d204 }, { i64, ptr } %t41)
  store %"compiler/msgs:Msg" %t42, ptr %l11
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t43 = load %"compiler/msgs:Msg", ptr %l11
  store %"compiler/msgs:Msg" %t43, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCtorGenericInferredField(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 272, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = extractvalue { i64, ptr } { i64 6, ptr @.d205 }, 1
  %t4 = extractvalue { i64, ptr } { i64 6, ptr @.d205 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = load { i64, ptr }, ptr %l3
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 58, ptr @.d206 }, 1
  %t9 = extractvalue { i64, ptr } { i64 58, ptr @.d206 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load { i64, ptr }, ptr %l4
  %t11 = extractvalue { i64, ptr } %t10, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = extractvalue { i64, ptr } { i64 58, ptr @.d207 }, 1
  %t14 = extractvalue { i64, ptr } { i64 58, ptr @.d207 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t13, i64 %t14)
  %t15 = load ptr, ptr %s1
  %t16 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t17 = load i64, ptr %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t15, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t21 = load { i64, ptr }, ptr %l5
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l6
  %t28 = load i32, ptr %l2
  %t29 = load { i64, ptr }, ptr %l6
  %t30 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t28, { i64, ptr } { i64 4, ptr @.d208 }, { i64, ptr } %t29)
  store %"compiler/msgs:Msg" %t30, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t31 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t31, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCtorTypeArgsNotInferable(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 269, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = extractvalue { i64, ptr } { i64 22, ptr @.d209 }, 1
  %t4 = extractvalue { i64, ptr } { i64 22, ptr @.d209 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = load { i64, ptr }, ptr %l3
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 55, ptr @.d210 }, 1
  %t9 = extractvalue { i64, ptr } { i64 55, ptr @.d210 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load { i64, ptr }, ptr %l4
  %t11 = extractvalue { i64, ptr } %t10, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = extractvalue { i64, ptr } { i64 10, ptr @.d211 }, 1
  %t14 = extractvalue { i64, ptr } { i64 10, ptr @.d211 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t13, i64 %t14)
  %t15 = load ptr, ptr %s1
  %t16 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t17 = load i64, ptr %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t15, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t21 = load { i64, ptr }, ptr %l5
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l6
  %t28 = load i32, ptr %l2
  %t29 = load { i64, ptr }, ptr %l6
  %t30 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t28, { i64, ptr } { i64 4, ptr @.d212 }, { i64, ptr } %t29)
  store %"compiler/msgs:Msg" %t30, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t31 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t31, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCtorVarOfGeneric(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 273, ptr %l3
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l4
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l5
  %t3 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t3, ptr %l6
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t4 = load { i64, ptr }, ptr %l4
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 15, ptr @.d213 }, 1
  %t8 = extractvalue { i64, ptr } { i64 15, ptr @.d213 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load { i64, ptr }, ptr %l5
  %t10 = extractvalue { i64, ptr } %t9, 1
  %t11 = extractvalue { i64, ptr } %t9, 0
  call void @__olang_sb_put(ptr %s1, ptr %t10, i64 %t11)
  %t12 = extractvalue { i64, ptr } { i64 81, ptr @.d214 }, 1
  %t13 = extractvalue { i64, ptr } { i64 81, ptr @.d214 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t12, i64 %t13)
  %t14 = load { i64, ptr }, ptr %l6
  %t15 = extractvalue { i64, ptr } %t14, 1
  %t16 = extractvalue { i64, ptr } %t14, 0
  call void @__olang_sb_put(ptr %s1, ptr %t15, i64 %t16)
  %t17 = extractvalue { i64, ptr } { i64 19, ptr @.d215 }, 1
  %t18 = extractvalue { i64, ptr } { i64 19, ptr @.d215 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t17, i64 %t18)
  %t19 = load ptr, ptr %s1
  %t20 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t21 = load i64, ptr %t20
  %t22 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t19, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  store { i64, ptr } %t24, ptr %l7
  call void @__olang_sb_done(ptr %s1)
  %t25 = load { i64, ptr }, ptr %l7
  %t26 = extractvalue { i64, ptr } %t25, 0
  %t27 = extractvalue { i64, ptr } %t25, 1
  %t28 = mul i64 %t26, 1
  %t29 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t28)
  call void @llvm.memcpy.p0.p0.i64(ptr %t29, ptr %t27, i64 %t28, i1 false)
  %t30 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  store { i64, ptr } %t31, ptr %l8
  %t32 = load i32, ptr %l3
  %t33 = load { i64, ptr }, ptr %l8
  %t34 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 %t32, { i64, ptr } { i64 4, ptr @.d216 }, { i64, ptr } %t33)
  store %"compiler/msgs:Msg" %t34, ptr %l9
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t35 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t35, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCtorVarsNotInferable(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 270, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 5, ptr @.d217 }, 1
  %t3 = extractvalue { i64, ptr } { i64 5, ptr @.d217 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 65, ptr @.d218 }, 1
  %t8 = extractvalue { i64, ptr } { i64 65, ptr @.d218 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 4, ptr @.d219 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeclFromNoreturn(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 454, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d220 }, { i64, ptr } { i64 61, ptr @.d221 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeclFromNull(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 246, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d222 }, { i64, ptr } { i64 91, ptr @.d223 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeclaredOverAggregate(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 185, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 55, ptr @.d224 }, 1
  %t3 = extractvalue { i64, ptr } { i64 55, ptr @.d224 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 38, ptr @.d225 }, 1
  %t8 = extractvalue { i64, ptr } { i64 38, ptr @.d225 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 3, ptr @.d226 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeclaredTwice(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 166, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 18, ptr @.d227 }, 1
  %t6 = extractvalue { i64, ptr } { i64 18, ptr @.d227 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 0, ptr @.d228 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultAmbiguous(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 391, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = extractvalue { i64, ptr } { i64 11, ptr @.d229 }, 1
  %t4 = extractvalue { i64, ptr } { i64 11, ptr @.d229 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = load { i64, ptr }, ptr %l3
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 34, ptr @.d230 }, 1
  %t9 = extractvalue { i64, ptr } { i64 34, ptr @.d230 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load { i64, ptr }, ptr %l4
  %t11 = extractvalue { i64, ptr } %t10, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = extractvalue { i64, ptr } { i64 25, ptr @.d231 }, 1
  %t14 = extractvalue { i64, ptr } { i64 25, ptr @.d231 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t13, i64 %t14)
  %t15 = load ptr, ptr %s1
  %t16 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t17 = load i64, ptr %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t15, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t21 = load { i64, ptr }, ptr %l5
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l6
  %t28 = load i32, ptr %l2
  %t29 = load { i64, ptr }, ptr %l6
  %t30 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t28, { i64, ptr } { i64 4, ptr @.d232 }, { i64, ptr } %t29)
  store %"compiler/msgs:Msg" %t30, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t31 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t31, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultCount(ptr %v0, i64 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 369, ptr %l2
  %t1 = load i64, ptr %l0
  store i64 %t1, ptr %l3
  %t2 = load i64, ptr %l1
  store i64 %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = extractvalue { i64, ptr } { i64 9, ptr @.d233 }, 1
  %t4 = extractvalue { i64, ptr } { i64 9, ptr @.d233 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = load i64, ptr %l3
  %t6 = call ptr @__olang_sb_room(ptr %s1, i64 24)
  %t7 = call i64 @__olang_fmt_i64(ptr %t6, i64 %t5)
  call void @__olang_sb_add(ptr %s1, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 33, ptr @.d234 }, 1
  %t9 = extractvalue { i64, ptr } { i64 33, ptr @.d234 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load i64, ptr %l4
  %t11 = call ptr @__olang_sb_room(ptr %s1, i64 24)
  %t12 = call i64 @__olang_fmt_i64(ptr %t11, i64 %t10)
  call void @__olang_sb_add(ptr %s1, i64 %t12)
  %t13 = load ptr, ptr %s1
  %t14 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t15 = load i64, ptr %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t13, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t19 = load { i64, ptr }, ptr %l5
  %t20 = extractvalue { i64, ptr } %t19, 0
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = mul i64 %t20, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t22)
  call void @llvm.memcpy.p0.p0.i64(ptr %t23, ptr %t21, i64 %t22, i1 false)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l6
  %t26 = load i32, ptr %l2
  %t27 = load { i64, ptr }, ptr %l6
  %t28 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t26, { i64, ptr } { i64 3, ptr @.d235 }, { i64, ptr } %t27)
  store %"compiler/msgs:Msg" %t28, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t29, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultDead(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 375, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d236 }, { i64, ptr } { i64 80, ptr @.d237 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultHoldsReferences(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 370, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d238 }, { i64, ptr } { i64 131, ptr @.d239 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultInStatement(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 374, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d240 }, { i64, ptr } { i64 67, ptr @.d241 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultNoValue(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 378, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d242 }, { i64, ptr } { i64 77, ptr @.d243 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultNotComputable(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 508, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 63, ptr @.d244 }, 1
  %t3 = extractvalue { i64, ptr } { i64 63, ptr @.d244 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 3, ptr @.d245 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultScope(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 371, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 8, ptr @.d246 }, { i64, ptr } { i64 83, ptr @.d247 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeferErrorEscapes(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 362, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 4, ptr @.d248 }, { i64, ptr } { i64 52, ptr @.d249 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeferLoopJump(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 501, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 62, ptr @.d250 }, 1
  %t6 = extractvalue { i64, ptr } { i64 62, ptr @.d250 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 4, ptr @.d251 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeferReturns(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 446, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 4, ptr @.d252 }, { i64, ptr } { i64 62, ptr @.d253 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineBadNumber(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 30, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = extractvalue { i64, ptr } { i64 8, ptr @.d254 }, 1
  %t4 = extractvalue { i64, ptr } { i64 8, ptr @.d254 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = load { i64, ptr }, ptr %l3
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 1, ptr @.d255 }, 1
  %t9 = extractvalue { i64, ptr } { i64 1, ptr @.d255 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load { i64, ptr }, ptr %l4
  %t11 = extractvalue { i64, ptr } %t10, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = extractvalue { i64, ptr } { i64 60, ptr @.d256 }, 1
  %t14 = extractvalue { i64, ptr } { i64 60, ptr @.d256 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t13, i64 %t14)
  %t15 = load ptr, ptr %s1
  %t16 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t17 = load i64, ptr %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t15, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t21 = load { i64, ptr }, ptr %l5
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l6
  %t28 = load i32, ptr %l2
  %t29 = load { i64, ptr }, ptr %l6
  %t30 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t28, { i64, ptr } { i64 3, ptr @.d257 }, { i64, ptr } %t29)
  store %"compiler/msgs:Msg" %t30, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t31 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t31, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineBuiltin(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 34, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 46, ptr @.d258 }, 1
  %t3 = extractvalue { i64, ptr } { i64 46, ptr @.d258 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 4, ptr @.d259 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineFloatRange(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 33, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = extractvalue { i64, ptr } { i64 8, ptr @.d260 }, 1
  %t4 = extractvalue { i64, ptr } { i64 8, ptr @.d260 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = load { i64, ptr }, ptr %l3
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 1, ptr @.d261 }, 1
  %t9 = extractvalue { i64, ptr } { i64 1, ptr @.d261 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load { i64, ptr }, ptr %l4
  %t11 = extractvalue { i64, ptr } %t10, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = extractvalue { i64, ptr } { i64 20, ptr @.d262 }, 1
  %t14 = extractvalue { i64, ptr } { i64 20, ptr @.d262 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t13, i64 %t14)
  %t15 = load ptr, ptr %s1
  %t16 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t17 = load i64, ptr %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t15, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t21 = load { i64, ptr }, ptr %l5
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l6
  %t28 = load i32, ptr %l2
  %t29 = load { i64, ptr }, ptr %l6
  %t30 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t28, { i64, ptr } { i64 3, ptr @.d263 }, { i64, ptr } %t29)
  store %"compiler/msgs:Msg" %t30, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t31 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t31, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineIntRange(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 31, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = extractvalue { i64, ptr } { i64 8, ptr @.d264 }, 1
  %t4 = extractvalue { i64, ptr } { i64 8, ptr @.d264 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = load { i64, ptr }, ptr %l3
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 1, ptr @.d265 }, 1
  %t9 = extractvalue { i64, ptr } { i64 1, ptr @.d265 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load { i64, ptr }, ptr %l4
  %t11 = extractvalue { i64, ptr } %t10, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = extractvalue { i64, ptr } { i64 16, ptr @.d266 }, 1
  %t14 = extractvalue { i64, ptr } { i64 16, ptr @.d266 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t13, i64 %t14)
  %t15 = load ptr, ptr %s1
  %t16 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t17 = load i64, ptr %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t15, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t21 = load { i64, ptr }, ptr %l5
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l6
  %t28 = load i32, ptr %l2
  %t29 = load { i64, ptr }, ptr %l6
  %t30 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t28, { i64, ptr } { i64 3, ptr @.d267 }, { i64, ptr } %t29)
  store %"compiler/msgs:Msg" %t30, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t31 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t31, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineNegRange(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 32, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = extractvalue { i64, ptr } { i64 8, ptr @.d268 }, 1
  %t4 = extractvalue { i64, ptr } { i64 8, ptr @.d268 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = load { i64, ptr }, ptr %l3
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 1, ptr @.d269 }, 1
  %t9 = extractvalue { i64, ptr } { i64 1, ptr @.d269 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load { i64, ptr }, ptr %l4
  %t11 = extractvalue { i64, ptr } %t10, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = extractvalue { i64, ptr } { i64 21, ptr @.d270 }, 1
  %t14 = extractvalue { i64, ptr } { i64 21, ptr @.d270 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t13, i64 %t14)
  %t15 = load ptr, ptr %s1
  %t16 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t17 = load i64, ptr %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t15, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t21 = load { i64, ptr }, ptr %l5
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l6
  %t28 = load i32, ptr %l2
  %t29 = load { i64, ptr }, ptr %l6
  %t30 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t28, { i64, ptr } { i64 3, ptr @.d271 }, { i64, ptr } %t29)
  store %"compiler/msgs:Msg" %t30, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t31 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t31, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineNotName(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 28, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = extractvalue { i64, ptr } { i64 8, ptr @.d272 }, 1
  %t4 = extractvalue { i64, ptr } { i64 8, ptr @.d272 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = load { i64, ptr }, ptr %l3
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 1, ptr @.d273 }, 1
  %t9 = extractvalue { i64, ptr } { i64 1, ptr @.d273 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load { i64, ptr }, ptr %l4
  %t11 = extractvalue { i64, ptr } %t10, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = extractvalue { i64, ptr } { i64 31, ptr @.d274 }, 1
  %t14 = extractvalue { i64, ptr } { i64 31, ptr @.d274 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t13, i64 %t14)
  %t15 = load ptr, ptr %s1
  %t16 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t17 = load i64, ptr %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t15, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t21 = load { i64, ptr }, ptr %l5
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l6
  %t28 = load i32, ptr %l2
  %t29 = load { i64, ptr }, ptr %l6
  %t30 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t28, { i64, ptr } { i64 3, ptr @.d275 }, { i64, ptr } %t29)
  store %"compiler/msgs:Msg" %t30, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t31 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t31, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineShape(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 27, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 33, ptr @.d276 }, 1
  %t3 = extractvalue { i64, ptr } { i64 33, ptr @.d276 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 1, ptr @.d277 }, 1
  %t8 = extractvalue { i64, ptr } { i64 1, ptr @.d277 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 3, ptr @.d278 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineTwice(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 29, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = extractvalue { i64, ptr } { i64 8, ptr @.d279 }, 1
  %t4 = extractvalue { i64, ptr } { i64 8, ptr @.d279 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = load { i64, ptr }, ptr %l3
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 1, ptr @.d280 }, 1
  %t9 = extractvalue { i64, ptr } { i64 1, ptr @.d280 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load { i64, ptr }, ptr %l4
  %t11 = extractvalue { i64, ptr } %t10, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = extractvalue { i64, ptr } { i64 15, ptr @.d281 }, 1
  %t14 = extractvalue { i64, ptr } { i64 15, ptr @.d281 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t13, i64 %t14)
  %t15 = load ptr, ptr %s1
  %t16 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t17 = load i64, ptr %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t15, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t21 = load { i64, ptr }, ptr %l5
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l6
  %t28 = load i32, ptr %l2
  %t29 = load { i64, ptr }, ptr %l6
  %t30 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t28, { i64, ptr } { i64 3, ptr @.d282 }, { i64, ptr } %t29)
  store %"compiler/msgs:Msg" %t30, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t31 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t31, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestructCount(ptr %v0, i64 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 398, ptr %l2
  %t1 = load i64, ptr %l0
  store i64 %t1, ptr %l3
  %t2 = load i64, ptr %l1
  store i64 %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = load i64, ptr %l3
  %t4 = call ptr @__olang_sb_room(ptr %s1, i64 24)
  %t5 = call i64 @__olang_fmt_i64(ptr %t4, i64 %t3)
  call void @__olang_sb_add(ptr %s1, i64 %t5)
  %t6 = extractvalue { i64, ptr } { i64 13, ptr @.d283 }, 1
  %t7 = extractvalue { i64, ptr } { i64 13, ptr @.d283 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = load i64, ptr %l4
  %t9 = call ptr @__olang_sb_room(ptr %s1, i64 24)
  %t10 = call i64 @__olang_fmt_i64(ptr %t9, i64 %t8)
  call void @__olang_sb_add(ptr %s1, i64 %t10)
  %t11 = extractvalue { i64, ptr } { i64 39, ptr @.d284 }, 1
  %t12 = extractvalue { i64, ptr } { i64 39, ptr @.d284 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = load ptr, ptr %s1
  %t14 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t15 = load i64, ptr %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t13, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t19 = load { i64, ptr }, ptr %l5
  %t20 = extractvalue { i64, ptr } %t19, 0
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = mul i64 %t20, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t22)
  call void @llvm.memcpy.p0.p0.i64(ptr %t23, ptr %t21, i64 %t22, i1 false)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l6
  %t26 = load i32, ptr %l2
  %t27 = load { i64, ptr }, ptr %l6
  %t28 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t26, { i64, ptr } { i64 3, ptr @.d285 }, { i64, ptr } %t27)
  store %"compiler/msgs:Msg" %t28, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t29, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestructInBody(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 68, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 2, ptr @.d286 }, { i64, ptr } { i64 111, ptr @.d287 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestructNotName(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 396, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d288 }, { i64, ptr } { i64 83, ptr @.d289 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestructOneValue(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 397, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 58, ptr @.d290 }, 1
  %t3 = extractvalue { i64, ptr } { i64 58, ptr @.d290 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 3, ptr @.d291 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDivideByZero(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 324, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d292 }, { i64, ptr } { i64 16, ptr @.d293 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eElemNotInArrayScope(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 401, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 4, ptr @.d294 }, { i64, ptr } { i64 95, ptr @.d295 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eElemOutlived(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 402, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 4, ptr @.d296 }, { i64, ptr } { i64 87, ptr @.d297 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eEmptyDestructor(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 504, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d298 }, { i64, ptr } { i64 40, ptr @.d299 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local void @compiler_2fmsgs_2eEndOfFile_2einit() #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, ptr } { i64 11, ptr @.d300 }, ptr %l0
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l1
  %t2 = load { i64, ptr }, ptr @G_2ecompiler_2fmsgs_2eEndOfFile
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l2
  %t4 = load { i64, ptr }, ptr %l1
  %t5 = extractvalue { i64, ptr } %t4, 0
  store i64 %t5, ptr %l3
  %t6 = load i64, ptr %l2
  %t7 = load i64, ptr %l3
  %t8 = icmp eq i64 %t6, %t7
  store i1 %t8, ptr %l4
  %t9 = load i1, ptr %l4
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t10 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2fmsgs_2eEndOfFile, i32 0, i32 1
  %t11 = load ptr, ptr %t10
  %t12 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t13 = load ptr, ptr %t12
  %t14 = load i64, ptr %l3
  %t15 = mul i64 %t14, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t11, ptr %t13, i64 %t15, i1 false)
  br label %bb3
bb2:
  %t16 = load { i64, ptr }, ptr %l1
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l5
  %t18 = load i64, ptr %l5
  %t19 = mul i64 %t18, 1
  %t20 = load ptr, ptr @__olang_prog_scope
  %t21 = call ptr @__olang_scope_alloc_zeroed(ptr %t20, i64 %t19)
  %t22 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l6
  %t24 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t25 = load ptr, ptr %t24
  %t26 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t27 = load ptr, ptr %t26
  %t28 = load i64, ptr %l5
  %t29 = mul i64 %t28, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t25, ptr %t27, i64 %t29, i1 false)
  %t30 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t30, ptr @G_2ecompiler_2fmsgs_2eEndOfFile
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmsgs_2eEndOfLine_2einit() #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, ptr } { i64 11, ptr @.d301 }, ptr %l0
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l1
  %t2 = load { i64, ptr }, ptr @G_2ecompiler_2fmsgs_2eEndOfLine
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l2
  %t4 = load { i64, ptr }, ptr %l1
  %t5 = extractvalue { i64, ptr } %t4, 0
  store i64 %t5, ptr %l3
  %t6 = load i64, ptr %l2
  %t7 = load i64, ptr %l3
  %t8 = icmp eq i64 %t6, %t7
  store i1 %t8, ptr %l4
  %t9 = load i1, ptr %l4
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t10 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2fmsgs_2eEndOfLine, i32 0, i32 1
  %t11 = load ptr, ptr %t10
  %t12 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t13 = load ptr, ptr %t12
  %t14 = load i64, ptr %l3
  %t15 = mul i64 %t14, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t11, ptr %t13, i64 %t15, i1 false)
  br label %bb3
bb2:
  %t16 = load { i64, ptr }, ptr %l1
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l5
  %t18 = load i64, ptr %l5
  %t19 = mul i64 %t18, 1
  %t20 = load ptr, ptr @__olang_prog_scope
  %t21 = call ptr @__olang_scope_alloc_zeroed(ptr %t20, i64 %t19)
  %t22 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l6
  %t24 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t25 = load ptr, ptr %t24
  %t26 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t27 = load ptr, ptr %t26
  %t28 = load i64, ptr %l5
  %t29 = mul i64 %t28, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t25, ptr %t27, i64 %t29, i1 false)
  %t30 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t30, ptr @G_2ecompiler_2fmsgs_2eEndOfLine
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eEqShape(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 196, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 4, ptr @.d302 }, { i64, ptr } { i64 66, ptr @.d303 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eEqStrWrites(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 198, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 85, ptr @.d304 }, 1
  %t6 = extractvalue { i64, ptr } { i64 85, ptr @.d304 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 10, ptr @.d305 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrorAfterQuestion(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 72, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d306 }, { i64, ptr } { i64 84, ptr @.d307 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrorTypeAsValue(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 385, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = load { i64, ptr }, ptr %l3
  %t4 = extractvalue { i64, ptr } %t3, 1
  %t5 = extractvalue { i64, ptr } %t3, 0
  call void @__olang_sb_put(ptr %s1, ptr %t4, i64 %t5)
  %t6 = extractvalue { i64, ptr } { i64 132, ptr @.d308 }, 1
  %t7 = extractvalue { i64, ptr } { i64 132, ptr @.d308 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = load { i64, ptr }, ptr %l4
  %t9 = extractvalue { i64, ptr } %t8, 1
  %t10 = extractvalue { i64, ptr } %t8, 0
  call void @__olang_sb_put(ptr %s1, ptr %t9, i64 %t10)
  %t11 = extractvalue { i64, ptr } { i64 11, ptr @.d309 }, 1
  %t12 = extractvalue { i64, ptr } { i64 11, ptr @.d309 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = load ptr, ptr %s1
  %t14 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t15 = load i64, ptr %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t13, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t19 = load { i64, ptr }, ptr %l5
  %t20 = extractvalue { i64, ptr } %t19, 0
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = mul i64 %t20, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t22)
  call void @llvm.memcpy.p0.p0.i64(ptr %t23, ptr %t21, i64 %t22, i1 false)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l6
  %t26 = load i32, ptr %l2
  %t27 = load { i64, ptr }, ptr %l6
  %t28 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t26, { i64, ptr } { i64 3, ptr @.d310 }, { i64, ptr } %t27)
  store %"compiler/msgs:Msg" %t28, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t29, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrorUndeclared(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 462, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 31, ptr @.d311 }, 1
  %t3 = extractvalue { i64, ptr } { i64 31, ptr @.d311 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 19, ptr @.d312 }, 1
  %t8 = extractvalue { i64, ptr } { i64 19, ptr @.d312 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 2, ptr @.d313 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrorWordAsValue(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 388, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = extractvalue { i64, ptr } { i64 1, ptr @.d314 }, 1
  %t4 = extractvalue { i64, ptr } { i64 1, ptr @.d314 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = load { i64, ptr }, ptr %l3
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 55, ptr @.d315 }, 1
  %t9 = extractvalue { i64, ptr } { i64 55, ptr @.d315 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load { i64, ptr }, ptr %l4
  %t11 = extractvalue { i64, ptr } %t10, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = extractvalue { i64, ptr } { i64 36, ptr @.d316 }, 1
  %t14 = extractvalue { i64, ptr } { i64 36, ptr @.d316 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t13, i64 %t14)
  %t15 = load ptr, ptr %s1
  %t16 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t17 = load i64, ptr %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t15, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t21 = load { i64, ptr }, ptr %l5
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l6
  %t28 = load i32, ptr %l2
  %t29 = load { i64, ptr }, ptr %l6
  %t30 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t28, { i64, ptr } { i64 3, ptr @.d317 }, { i64, ptr } %t29)
  store %"compiler/msgs:Msg" %t30, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t31 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t31, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrorWordNotInSet(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 459, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 26, ptr @.d318 }, 1
  %t3 = extractvalue { i64, ptr } { i64 26, ptr @.d318 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 34, ptr @.d319 }, 1
  %t8 = extractvalue { i64, ptr } { i64 34, ptr @.d319 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 2, ptr @.d320 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local { i64, ptr } @compiler_2fmsgs_2eEsc(ptr %v0, i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i8
  %l4 = alloca i1
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i8
  %l10 = alloca i1
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i8
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i8
  %l22 = alloca i1
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca i8
  %l28 = alloca i8
  %l29 = alloca i1
  %l30 = alloca i1
  %l31 = alloca i8
  %l32 = alloca i8
  %l33 = alloca i1
  %l34 = alloca i8
  %l35 = alloca i8
  %l36 = alloca i64
  %l37 = alloca i32
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca %"std/prelude/text:StringBuilder"
  %l43 = alloca ptr
  %l44 = alloca i8
  %l45 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.builder
  %s6room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i8, ptr %l0
  store i8 %t1, ptr %l3
  %t2 = load i8, ptr %l3
  %t3 = icmp eq i8 %t2, 9
  store i1 %t3, ptr %l4
  %t4 = load i1, ptr %l4
  br i1 %t4, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  store { i64, ptr } { i64 2, ptr @.d321 }, ptr %l5
  %t5 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t5, ptr %l6
  %t6 = load { i64, ptr }, ptr %l6
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l7
  %t8 = load i64, ptr %l7
  %t9 = mul i64 %t8, 1
  %t10 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l8
  %t13 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  %t15 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t16 = load ptr, ptr %t15
  %t17 = load i64, ptr %l7
  %t18 = mul i64 %t17, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t14, ptr %t16, i64 %t18, i1 false)
  %t19 = load { i64, ptr }, ptr %l8
  store { i64, ptr } %t19, ptr %l6
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t20 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t20, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t21 = load i8, ptr %l0
  store i8 %t21, ptr %l9
  %t22 = load i8, ptr %l9
  %t23 = icmp eq i8 %t22, 10
  store i1 %t23, ptr %l10
  %t24 = load i1, ptr %l10
  br i1 %t24, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  store { i64, ptr } { i64 2, ptr @.d322 }, ptr %l11
  %t25 = load { i64, ptr }, ptr %l11
  store { i64, ptr } %t25, ptr %l12
  %t26 = load { i64, ptr }, ptr %l12
  %t27 = extractvalue { i64, ptr } %t26, 0
  store i64 %t27, ptr %l13
  %t28 = load i64, ptr %l13
  %t29 = mul i64 %t28, 1
  %t30 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t29)
  %t31 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  store { i64, ptr } %t32, ptr %l14
  %t33 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t34 = load ptr, ptr %t33
  %t35 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t36 = load ptr, ptr %t35
  %t37 = load i64, ptr %l13
  %t38 = mul i64 %t37, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t34, ptr %t36, i64 %t38, i1 false)
  %t39 = load { i64, ptr }, ptr %l14
  store { i64, ptr } %t39, ptr %l12
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t40 = load { i64, ptr }, ptr %l12
  store { i64, ptr } %t40, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t41 = load i8, ptr %l0
  store i8 %t41, ptr %l15
  %t42 = load i8, ptr %l15
  %t43 = icmp eq i8 %t42, 13
  store i1 %t43, ptr %l16
  %t44 = load i1, ptr %l16
  br i1 %t44, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  store { i64, ptr } { i64 2, ptr @.d323 }, ptr %l17
  %t45 = load { i64, ptr }, ptr %l17
  store { i64, ptr } %t45, ptr %l18
  %t46 = load { i64, ptr }, ptr %l18
  %t47 = extractvalue { i64, ptr } %t46, 0
  store i64 %t47, ptr %l19
  %t48 = load i64, ptr %l19
  %t49 = mul i64 %t48, 1
  %t50 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t49)
  %t51 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  store { i64, ptr } %t52, ptr %l20
  %t53 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t54 = load ptr, ptr %t53
  %t55 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t56 = load ptr, ptr %t55
  %t57 = load i64, ptr %l19
  %t58 = mul i64 %t57, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t54, ptr %t56, i64 %t58, i1 false)
  %t59 = load { i64, ptr }, ptr %l20
  store { i64, ptr } %t59, ptr %l18
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t60 = load { i64, ptr }, ptr %l18
  store { i64, ptr } %t60, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t61 = load i8, ptr %l0
  store i8 %t61, ptr %l21
  %t62 = load i8, ptr %l21
  %t63 = icmp eq i8 %t62, 0
  store i1 %t63, ptr %l22
  %t64 = load i1, ptr %l22
  br i1 %t64, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  store { i64, ptr } { i64 2, ptr @.d324 }, ptr %l23
  %t65 = load { i64, ptr }, ptr %l23
  store { i64, ptr } %t65, ptr %l24
  %t66 = load { i64, ptr }, ptr %l24
  %t67 = extractvalue { i64, ptr } %t66, 0
  store i64 %t67, ptr %l25
  %t68 = load i64, ptr %l25
  %t69 = mul i64 %t68, 1
  %t70 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t69)
  %t71 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  store { i64, ptr } %t72, ptr %l26
  %t73 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t74 = load ptr, ptr %t73
  %t75 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t76 = load ptr, ptr %t75
  %t77 = load i64, ptr %l25
  %t78 = mul i64 %t77, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t74, ptr %t76, i64 %t78, i1 false)
  %t79 = load { i64, ptr }, ptr %l26
  store { i64, ptr } %t79, ptr %l24
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t80 = load { i64, ptr }, ptr %l24
  store { i64, ptr } %t80, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t81 = load i8, ptr %l0
  store i8 %t81, ptr %l27
  %t82 = load i8, ptr %l27
  store i8 %t82, ptr %l28
  %t83 = load i8, ptr %l28
  %t84 = icmp ult i8 %t83, 32
  store i1 %t84, ptr %l29
  %t85 = load i1, ptr %l29
  br i1 %t85, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l30
  br label %bb15
bb14:
  %t86 = load i8, ptr %l0
  store i8 %t86, ptr %l31
  %t87 = load i8, ptr %l31
  store i8 %t87, ptr %l32
  %t88 = load i8, ptr %l32
  %t89 = icmp uge i8 %t88, 127
  store i1 %t89, ptr %l33
  %t90 = load i1, ptr %l33
  store i1 %t90, ptr %l30
  br label %bb15
bb15:
  %t91 = load i1, ptr %l30
  br i1 %t91, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s5
  %t92 = load i8, ptr %l0
  store i8 %t92, ptr %l34
  %t93 = load i8, ptr %l34
  store i8 %t93, ptr %l35
  %t94 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s5, i64 16)
  %t95 = extractvalue { i32, i64 } %t94, 1
  %t96 = extractvalue { i32, i64 } %t94, 0
  store i32 %t96, ptr %l37
  %t97 = icmp ne i32 %t96, 0
  br i1 %t97, label %bb19, label %ok.98
ok.98:
  store i64 %t95, ptr %l36
  br label %bb18
bb17:
  br label %bb22
bb18:
  %t99 = load i8, ptr %l35
  %t100 = load i64, ptr %l36
  %t101 = call { i64, ptr } @std_2fprelude_2ftext_2eU8_2eFormat(ptr %s5, i8 %t99, i64 %t100)
  store { i64, ptr } %t101, ptr %l38
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @.c325)
  unreachable
bb20:
  %t102 = load { i64, ptr }, ptr %l38
  store { i64, ptr } %t102, ptr %l1
  %t103 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t103, ptr %l39
  %t104 = load { i64, ptr }, ptr %l39
  %t105 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %s5, ptr %s5, { i64, ptr } %t104, i64 2, i8 48)
  store { i64, ptr } %t105, ptr %l40
  br label %bb21
bb21:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s6
  store ptr %s6room, ptr %s6
  %t106 = extractvalue { i64, ptr } { i64 2, ptr @.d326 }, 1
  %t107 = extractvalue { i64, ptr } { i64 2, ptr @.d326 }, 0
  call void @__olang_sb_put(ptr %s6, ptr %t106, i64 %t107)
  %t108 = load { i64, ptr }, ptr %l40
  %t109 = extractvalue { i64, ptr } %t108, 1
  %t110 = extractvalue { i64, ptr } %t108, 0
  call void @__olang_sb_put(ptr %s6, ptr %t109, i64 %t110)
  %t111 = load ptr, ptr %s6
  %t112 = getelementptr %olang.builder, ptr %s6, i32 0, i32 1
  %t113 = load i64, ptr %t112
  %t114 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t113)
  call void @llvm.memcpy.p0.p0.i64(ptr %t114, ptr %t111, i64 %t113, i1 false)
  %t115 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t114, 1
  store { i64, ptr } %t116, ptr %l41
  call void @__olang_sb_done(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t117 = load { i64, ptr }, ptr %l41
  store { i64, ptr } %t117, ptr %rv
  br label %ret
bb22:
  %t118 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t118, ptr %l42
  br label %bb23
bb23:
  %t119 = load %"std/prelude/text:StringBuilder", ptr %l42
  store %"std/prelude/text:StringBuilder" %t119, ptr %l2
  store ptr %l2, ptr %l43
  %t120 = load i8, ptr %l0
  store i8 %t120, ptr %l44
  %t121 = load ptr, ptr %l43
  %t122 = load i8, ptr %l44
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t121, i8 %t122)
  br label %bb24
bb24:
  store ptr %l2, ptr %l45
  %t123 = load ptr, ptr %l45
  %t124 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v0, ptr %t123)
  store { i64, ptr } %t124, ptr %l46
  br label %bb25
bb25:
  %t125 = load { i64, ptr }, ptr %l46
  store { i64, ptr } %t125, ptr %l47
  %t126 = load { i64, ptr }, ptr %l47
  %t127 = extractvalue { i64, ptr } %t126, 0
  store i64 %t127, ptr %l48
  %t128 = load i64, ptr %l48
  %t129 = mul i64 %t128, 1
  %t130 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t129)
  %t131 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t130, 1
  store { i64, ptr } %t132, ptr %l49
  %t133 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t134 = load ptr, ptr %t133
  %t135 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t136 = load ptr, ptr %t135
  %t137 = load i64, ptr %l48
  %t138 = mul i64 %t137, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t134, ptr %t136, i64 %t138, i1 false)
  %t139 = load { i64, ptr }, ptr %l49
  store { i64, ptr } %t139, ptr %l47
  call void @__olang_scope_close(ptr %s0)
  %t140 = load { i64, ptr }, ptr %l47
  store { i64, ptr } %t140, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eExpected(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 63, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = extractvalue { i64, ptr } { i64 9, ptr @.d327 }, 1
  %t4 = extractvalue { i64, ptr } { i64 9, ptr @.d327 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = load { i64, ptr }, ptr %l3
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 8, ptr @.d328 }, 1
  %t9 = extractvalue { i64, ptr } { i64 8, ptr @.d328 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load { i64, ptr }, ptr %l4
  %t11 = extractvalue { i64, ptr } %t10, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = load ptr, ptr %s1
  %t14 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t15 = load i64, ptr %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t13, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t19 = load { i64, ptr }, ptr %l5
  %t20 = extractvalue { i64, ptr } %t19, 0
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = mul i64 %t20, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t22)
  call void @llvm.memcpy.p0.p0.i64(ptr %t23, ptr %t21, i64 %t22, i1 false)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l6
  %t26 = load i32, ptr %l2
  %t27 = load { i64, ptr }, ptr %l6
  %t28 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t26, { i64, ptr } { i64 0, ptr @.d329 }, { i64, ptr } %t27)
  store %"compiler/msgs:Msg" %t28, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t29, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eExplainNeedsRule(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 23, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 4, ptr @.d330 }, { i64, ptr } { i64 45, ptr @.d331 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eExtendsNotBase(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 183, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 4, ptr @.d332 }, { i64, ptr } { i64 54, ptr @.d333 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eExternType(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 175, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 108, ptr @.d334 }, 1
  %t6 = extractvalue { i64, ptr } { i64 108, ptr @.d334 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 2, ptr @.d335 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eFieldBindingUnknown(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 262, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 8, ptr @.d336 }, { i64, ptr } { i64 122, ptr @.d337 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eFieldHasParamName(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 167, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 6, ptr @.d338 }, 1
  %t3 = extractvalue { i64, ptr } { i64 6, ptr @.d338 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 87, ptr @.d339 }, 1
  %t8 = extractvalue { i64, ptr } { i64 87, ptr @.d339 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 3, ptr @.d340 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eFixedArrayCall(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 154, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 2, ptr @.d341 }, { i64, ptr } { i64 94, ptr @.d342 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eFloatLiteralRange(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 327, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 22, ptr @.d343 }, 1
  %t6 = extractvalue { i64, ptr } { i64 22, ptr @.d343 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 4, ptr @.d344 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eForInClauseExit(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 420, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d345 }, { i64, ptr } { i64 104, ptr @.d346 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eForInNameExists(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 421, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = load { i64, ptr }, ptr %l3
  %t4 = extractvalue { i64, ptr } %t3, 1
  %t5 = extractvalue { i64, ptr } %t3, 0
  call void @__olang_sb_put(ptr %s1, ptr %t4, i64 %t5)
  %t6 = extractvalue { i64, ptr } { i64 116, ptr @.d347 }, 1
  %t7 = extractvalue { i64, ptr } { i64 116, ptr @.d347 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = load { i64, ptr }, ptr %l4
  %t9 = extractvalue { i64, ptr } %t8, 1
  %t10 = extractvalue { i64, ptr } %t8, 0
  call void @__olang_sb_put(ptr %s1, ptr %t9, i64 %t10)
  %t11 = extractvalue { i64, ptr } { i64 22, ptr @.d348 }, 1
  %t12 = extractvalue { i64, ptr } { i64 22, ptr @.d348 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = load ptr, ptr %s1
  %t14 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t15 = load i64, ptr %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t13, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t19 = load { i64, ptr }, ptr %l5
  %t20 = extractvalue { i64, ptr } %t19, 0
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = mul i64 %t20, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t22)
  call void @llvm.memcpy.p0.p0.i64(ptr %t23, ptr %t21, i64 %t22, i1 false)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l6
  %t26 = load i32, ptr %l2
  %t27 = load { i64, ptr }, ptr %l6
  %t28 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t26, { i64, ptr } { i64 8, ptr @.d349 }, { i64, ptr } %t27)
  store %"compiler/msgs:Msg" %t28, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t29, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eForInNeedsTry(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 418, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d350 }, { i64, ptr } { i64 90, ptr @.d351 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eForInTryNothing(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 419, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d352 }, { i64, ptr } { i64 59, ptr @.d353 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eFromBitsReceiver(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 368, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 95, ptr @.d354 }, 1
  %t6 = extractvalue { i64, ptr } { i64 95, ptr @.d354 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 3, ptr @.d355 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eFuncTypeErrsUnwritten(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 107, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d356 }, { i64, ptr } { i64 82, ptr @.d357 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eFuncValueObligations(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 490, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 1, ptr @.d358 }, 1
  %t3 = extractvalue { i64, ptr } { i64 1, ptr @.d358 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 102, ptr @.d359 }, 1
  %t8 = extractvalue { i64, ptr } { i64 102, ptr @.d359 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 4, ptr @.d360 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eGenericNotAValue(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 393, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 17, ptr @.d361 }, 1
  %t3 = extractvalue { i64, ptr } { i64 17, ptr @.d361 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 25, ptr @.d362 }, 1
  %t8 = extractvalue { i64, ptr } { i64 25, ptr @.d362 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 3, ptr @.d363 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eGenericNotStruct(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 184, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 2, ptr @.d364 }, { i64, ptr } { i64 46, ptr @.d365 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eGlobalHoldsShorter(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 406, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d366 }, { i64, ptr } { i64 103, ptr @.d367 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eGuardNotBool(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 432, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 25, ptr @.d368 }, 1
  %t3 = extractvalue { i64, ptr } { i64 25, ptr @.d368 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 4, ptr @.d369 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eHelpOneMode(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 9, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 2, ptr @.d370 }, { i64, ptr } { i64 27, ptr @.d371 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eImmutable(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 292, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 68, ptr @.d372 }, 1
  %t6 = extractvalue { i64, ptr } { i64 68, ptr @.d372 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 2, ptr @.d373 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportAliasConflict(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 91, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 48, ptr @.d374 }, 1
  %t3 = extractvalue { i64, ptr } { i64 48, ptr @.d374 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 32, ptr @.d375 }, 1
  %t8 = extractvalue { i64, ptr } { i64 32, ptr @.d375 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 2, ptr @.d376 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportAliasInvalid(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 90, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 1, ptr @.d377 }, 1
  %t3 = extractvalue { i64, ptr } { i64 1, ptr @.d377 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 86, ptr @.d378 }, 1
  %t8 = extractvalue { i64, ptr } { i64 86, ptr @.d378 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 2, ptr @.d379 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportFetchFailed(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 83, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 16, ptr @.d380 }, 1
  %t3 = extractvalue { i64, ptr } { i64 16, ptr @.d380 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 45, ptr @.d381 }, 1
  %t8 = extractvalue { i64, ptr } { i64 45, ptr @.d381 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 4, ptr @.d382 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportFileNotFound(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 86, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 18, ptr @.d383 }, 1
  %t3 = extractvalue { i64, ptr } { i64 18, ptr @.d383 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 3, ptr @.d384 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportHasExtension(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 87, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d385 }, { i64, ptr } { i64 41, ptr @.d386 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportIsPrivate(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 94, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 7, ptr @.d387 }, 1
  %t3 = extractvalue { i64, ptr } { i64 7, ptr @.d387 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 67, ptr @.d388 }, 1
  %t8 = extractvalue { i64, ptr } { i64 67, ptr @.d388 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 3, ptr @.d389 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportLeavesRoot(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 88, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 28, ptr @.d390 }, 1
  %t3 = extractvalue { i64, ptr } { i64 28, ptr @.d390 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 43, ptr @.d391 }, 1
  %t8 = extractvalue { i64, ptr } { i64 43, ptr @.d391 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 3, ptr @.d392 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportLockNotACommit(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 82, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 31, ptr @.d393 }, 1
  %t3 = extractvalue { i64, ptr } { i64 31, ptr @.d393 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 41, ptr @.d394 }, 1
  %t8 = extractvalue { i64, ptr } { i64 41, ptr @.d394 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 4, ptr @.d395 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportLockedFetchFailed(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 84, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 48, ptr @.d396 }, 1
  %t3 = extractvalue { i64, ptr } { i64 48, ptr @.d396 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 41, ptr @.d397 }, 1
  %t8 = extractvalue { i64, ptr } { i64 41, ptr @.d397 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 10, ptr @.d398 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportPathTooLong(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 85, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d399 }, { i64, ptr } { i64 43, ptr @.d400 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportReachedTwice(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 96, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 61, ptr @.d401 }, 1
  %t6 = extractvalue { i64, ptr } { i64 61, ptr @.d401 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 3, ptr @.d402 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportRemoteBadName(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 81, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 4, ptr @.d403 }, { i64, ptr } { i64 97, ptr @.d404 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportRemoteNeedsFile(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 89, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d405 }, { i64, ptr } { i64 74, ptr @.d406 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eIncdecInExpression(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 339, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 55, ptr @.d407 }, 1
  %t6 = extractvalue { i64, ptr } { i64 55, ptr @.d407 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 3, ptr @.d408 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eIndexNotInt(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 280, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 30, ptr @.d409 }, 1
  %t3 = extractvalue { i64, ptr } { i64 30, ptr @.d409 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 3, ptr @.d410 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eIndexOutOfRange(ptr %v0, i64 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 281, ptr %l2
  %t1 = load i64, ptr %l0
  store i64 %t1, ptr %l3
  %t2 = load i64, ptr %l1
  store i64 %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = extractvalue { i64, ptr } { i64 6, ptr @.d411 }, 1
  %t4 = extractvalue { i64, ptr } { i64 6, ptr @.d411 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = load i64, ptr %l3
  %t6 = call ptr @__olang_sb_room(ptr %s1, i64 24)
  %t7 = call i64 @__olang_fmt_i64(ptr %t6, i64 %t5)
  call void @__olang_sb_add(ptr %s1, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 24, ptr @.d412 }, 1
  %t9 = extractvalue { i64, ptr } { i64 24, ptr @.d412 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load i64, ptr %l4
  %t11 = call ptr @__olang_sb_room(ptr %s1, i64 24)
  %t12 = call i64 @__olang_fmt_i64(ptr %t11, i64 %t10)
  call void @__olang_sb_add(ptr %s1, i64 %t12)
  %t13 = extractvalue { i64, ptr } { i64 9, ptr @.d413 }, 1
  %t14 = extractvalue { i64, ptr } { i64 9, ptr @.d413 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t13, i64 %t14)
  %t15 = load ptr, ptr %s1
  %t16 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t17 = load i64, ptr %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t15, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t21 = load { i64, ptr }, ptr %l5
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l6
  %t28 = load i32, ptr %l2
  %t29 = load { i64, ptr }, ptr %l6
  %t30 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t28, { i64, ptr } { i64 3, ptr @.d414 }, { i64, ptr } %t29)
  store %"compiler/msgs:Msg" %t30, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t31 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t31, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eInstanceOutlivesArg(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 405, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d415 }, { i64, ptr } { i64 162, ptr @.d416 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eInstanceOutlivesReferent(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 404, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d417 }, { i64, ptr } { i64 113, ptr @.d418 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eIntLiteralTooLarge(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 315, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 78, ptr @.d419 }, 1
  %t6 = extractvalue { i64, ptr } { i64 78, ptr @.d419 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 3, ptr @.d420 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eInvalidReferenceTarget(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 161, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 63, ptr @.d421 }, 1
  %t6 = extractvalue { i64, ptr } { i64 63, ptr @.d421 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 3, ptr @.d422 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eIsAsMarker(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 349, ptr %l3
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l4
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l5
  %t3 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t3, ptr %l6
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t4 = extractvalue { i64, ptr } { i64 2, ptr @.d423 }, 1
  %t5 = extractvalue { i64, ptr } { i64 2, ptr @.d423 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t4, i64 %t5)
  %t6 = load { i64, ptr }, ptr %l4
  %t7 = extractvalue { i64, ptr } %t6, 1
  %t8 = extractvalue { i64, ptr } %t6, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = extractvalue { i64, ptr } { i64 89, ptr @.d424 }, 1
  %t10 = extractvalue { i64, ptr } { i64 89, ptr @.d424 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t9, i64 %t10)
  %t11 = load { i64, ptr }, ptr %l5
  %t12 = extractvalue { i64, ptr } %t11, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  call void @__olang_sb_put(ptr %s1, ptr %t12, i64 %t13)
  %t14 = extractvalue { i64, ptr } { i64 6, ptr @.d425 }, 1
  %t15 = extractvalue { i64, ptr } { i64 6, ptr @.d425 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t14, i64 %t15)
  %t16 = load { i64, ptr }, ptr %l6
  %t17 = extractvalue { i64, ptr } %t16, 1
  %t18 = extractvalue { i64, ptr } %t16, 0
  call void @__olang_sb_put(ptr %s1, ptr %t17, i64 %t18)
  %t19 = extractvalue { i64, ptr } { i64 1, ptr @.d426 }, 1
  %t20 = extractvalue { i64, ptr } { i64 1, ptr @.d426 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t19, i64 %t20)
  %t21 = load ptr, ptr %s1
  %t22 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t23 = load i64, ptr %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t23)
  call void @llvm.memcpy.p0.p0.i64(ptr %t24, ptr %t21, i64 %t23, i1 false)
  %t25 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  store { i64, ptr } %t26, ptr %l7
  call void @__olang_sb_done(ptr %s1)
  %t27 = load { i64, ptr }, ptr %l7
  %t28 = extractvalue { i64, ptr } %t27, 0
  %t29 = extractvalue { i64, ptr } %t27, 1
  %t30 = mul i64 %t28, 1
  %t31 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t30)
  call void @llvm.memcpy.p0.p0.i64(ptr %t31, ptr %t29, i64 %t30, i1 false)
  %t32 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  store { i64, ptr } %t33, ptr %l8
  %t34 = load i32, ptr %l3
  %t35 = load { i64, ptr }, ptr %l8
  %t36 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 %t34, { i64, ptr } { i64 3, ptr @.d427 }, { i64, ptr } %t35)
  store %"compiler/msgs:Msg" %t36, ptr %l9
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t37 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t37, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eIsAsNotEnum(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 351, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 59, ptr @.d428 }, 1
  %t3 = extractvalue { i64, ptr } { i64 59, ptr @.d428 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 3, ptr @.d429 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eIsDirectory(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 37, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 2, ptr @.d430 }, { i64, ptr } { i64 41, ptr @.d431 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eIsNotOneType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 345, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = load { i64, ptr }, ptr %l3
  %t4 = extractvalue { i64, ptr } %t3, 1
  %t5 = extractvalue { i64, ptr } %t3, 0
  call void @__olang_sb_put(ptr %s1, ptr %t4, i64 %t5)
  %t6 = extractvalue { i64, ptr } { i64 5, ptr @.d432 }, 1
  %t7 = extractvalue { i64, ptr } { i64 5, ptr @.d432 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = load { i64, ptr }, ptr %l4
  %t9 = extractvalue { i64, ptr } %t8, 1
  %t10 = extractvalue { i64, ptr } %t8, 0
  call void @__olang_sb_put(ptr %s1, ptr %t9, i64 %t10)
  %t11 = extractvalue { i64, ptr } { i64 53, ptr @.d433 }, 1
  %t12 = extractvalue { i64, ptr } { i64 53, ptr @.d433 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = load ptr, ptr %s1
  %t14 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t15 = load i64, ptr %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t13, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t19 = load { i64, ptr }, ptr %l5
  %t20 = extractvalue { i64, ptr } %t19, 0
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = mul i64 %t20, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t22)
  call void @llvm.memcpy.p0.p0.i64(ptr %t23, ptr %t21, i64 %t22, i1 false)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l6
  %t26 = load i32, ptr %l2
  %t27 = load { i64, ptr }, ptr %l6
  %t28 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t26, { i64, ptr } { i64 4, ptr @.d434 }, { i64, ptr } %t27)
  store %"compiler/msgs:Msg" %t28, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t29, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eIsNotReferences(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 344, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = extractvalue { i64, ptr } { i64 60, ptr @.d435 }, 1
  %t4 = extractvalue { i64, ptr } { i64 60, ptr @.d435 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = load { i64, ptr }, ptr %l3
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 5, ptr @.d436 }, 1
  %t9 = extractvalue { i64, ptr } { i64 5, ptr @.d436 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load { i64, ptr }, ptr %l4
  %t11 = extractvalue { i64, ptr } %t10, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = extractvalue { i64, ptr } { i64 24, ptr @.d437 }, 1
  %t14 = extractvalue { i64, ptr } { i64 24, ptr @.d437 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t13, i64 %t14)
  %t15 = load ptr, ptr %s1
  %t16 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t17 = load i64, ptr %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t15, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t21 = load { i64, ptr }, ptr %l5
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l6
  %t28 = load i32, ptr %l2
  %t29 = load { i64, ptr }, ptr %l6
  %t30 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t28, { i64, ptr } { i64 4, ptr @.d438 }, { i64, ptr } %t29)
  store %"compiler/msgs:Msg" %t30, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t31 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t31, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinCannotFail(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 478, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d439 }, { i64, ptr } { i64 46, ptr @.d440 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinCatchNeedsTry(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 479, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d441 }, { i64, ptr } { i64 79, ptr @.d442 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinClauseMustLeave(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 480, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d443 }, { i64, ptr } { i64 93, ptr @.d444 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinNextLine(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 413, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 8, ptr @.d445 }, { i64, ptr } { i64 100, ptr @.d446 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinNotTried(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 477, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 32, ptr @.d447 }, 1
  %t3 = extractvalue { i64, ptr } { i64 32, ptr @.d447 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 64, ptr @.d448 }, 1
  %t8 = extractvalue { i64, ptr } { i64 64, ptr @.d448 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 3, ptr @.d449 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinPiece(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 69, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 60, ptr @.d450 }, 1
  %t3 = extractvalue { i64, ptr } { i64 60, ptr @.d450 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 1, ptr @.d451 }, 1
  %t8 = extractvalue { i64, ptr } { i64 1, ptr @.d451 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 4, ptr @.d452 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinPieceCalled(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 341, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 4, ptr @.d453 }, { i64, ptr } { i64 77, ptr @.d454 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinWithoutSpawn(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 463, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d455 }, { i64, ptr } { i64 49, ptr @.d456 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eKeywordAsName(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 66, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 42, ptr @.d457 }, 1
  %t6 = extractvalue { i64, ptr } { i64 42, ptr @.d457 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 2, ptr @.d458 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eKeywordFieldRead(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 67, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 99, ptr @.d459 }, 1
  %t6 = extractvalue { i64, ptr } { i64 99, ptr @.d459 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 3, ptr @.d460 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLambdaArity(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i64 %a1, { i64, ptr } %a2, i64 %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 495, ptr %l4
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l5
  %t2 = load i64, ptr %l1
  store i64 %t2, ptr %l6
  %t3 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t3, ptr %l7
  %t4 = load i64, ptr %l3
  store i64 %t4, ptr %l8
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t5 = load { i64, ptr }, ptr %l5
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 7, ptr @.d461 }, 1
  %t9 = extractvalue { i64, ptr } { i64 7, ptr @.d461 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load i64, ptr %l6
  %t11 = call ptr @__olang_sb_room(ptr %s1, i64 24)
  %t12 = call i64 @__olang_fmt_i64(ptr %t11, i64 %t10)
  call void @__olang_sb_add(ptr %s1, i64 %t12)
  %t13 = extractvalue { i64, ptr } { i64 10, ptr @.d462 }, 1
  %t14 = extractvalue { i64, ptr } { i64 10, ptr @.d462 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t13, i64 %t14)
  %t15 = load { i64, ptr }, ptr %l7
  %t16 = extractvalue { i64, ptr } %t15, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  call void @__olang_sb_put(ptr %s1, ptr %t16, i64 %t17)
  %t18 = extractvalue { i64, ptr } { i64 18, ptr @.d463 }, 1
  %t19 = extractvalue { i64, ptr } { i64 18, ptr @.d463 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t18, i64 %t19)
  %t20 = load i64, ptr %l8
  %t21 = call ptr @__olang_sb_room(ptr %s1, i64 24)
  %t22 = call i64 @__olang_fmt_i64(ptr %t21, i64 %t20)
  call void @__olang_sb_add(ptr %s1, i64 %t22)
  %t23 = load ptr, ptr %s1
  %t24 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t25 = load i64, ptr %t24
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t23, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l9
  call void @__olang_sb_done(ptr %s1)
  %t29 = load { i64, ptr }, ptr %l9
  %t30 = extractvalue { i64, ptr } %t29, 0
  %t31 = extractvalue { i64, ptr } %t29, 1
  %t32 = mul i64 %t30, 1
  %t33 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t32)
  call void @llvm.memcpy.p0.p0.i64(ptr %t33, ptr %t31, i64 %t32, i1 false)
  %t34 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t33, 1
  store { i64, ptr } %t35, ptr %l10
  %t36 = load i32, ptr %l4
  %t37 = load { i64, ptr }, ptr %l10
  %t38 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t36, { i64, ptr } { i64 4, ptr @.d464 }, { i64, ptr } %t37)
  store %"compiler/msgs:Msg" %t38, ptr %l11
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t39 = load %"compiler/msgs:Msg", ptr %l11
  store %"compiler/msgs:Msg" %t39, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLambdaParamUntyped(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 497, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 17, ptr @.d465 }, 1
  %t3 = extractvalue { i64, ptr } { i64 17, ptr @.d465 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 49, ptr @.d466 }, 1
  %t8 = extractvalue { i64, ptr } { i64 49, ptr @.d466 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 4, ptr @.d467 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLambdaResultHeld(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 158, ptr %l3
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l4
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l5
  %t3 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t3, ptr %l6
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t4 = extractvalue { i64, ptr } { i64 18, ptr @.d468 }, 1
  %t5 = extractvalue { i64, ptr } { i64 18, ptr @.d468 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t4, i64 %t5)
  %t6 = load { i64, ptr }, ptr %l4
  %t7 = extractvalue { i64, ptr } %t6, 1
  %t8 = extractvalue { i64, ptr } %t6, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = extractvalue { i64, ptr } { i64 4, ptr @.d469 }, 1
  %t10 = extractvalue { i64, ptr } { i64 4, ptr @.d469 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t9, i64 %t10)
  %t11 = load { i64, ptr }, ptr %l5
  %t12 = extractvalue { i64, ptr } %t11, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  call void @__olang_sb_put(ptr %s1, ptr %t12, i64 %t13)
  %t14 = extractvalue { i64, ptr } { i64 94, ptr @.d470 }, 1
  %t15 = extractvalue { i64, ptr } { i64 94, ptr @.d470 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t14, i64 %t15)
  %t16 = load { i64, ptr }, ptr %l6
  %t17 = extractvalue { i64, ptr } %t16, 1
  %t18 = extractvalue { i64, ptr } %t16, 0
  call void @__olang_sb_put(ptr %s1, ptr %t17, i64 %t18)
  %t19 = extractvalue { i64, ptr } { i64 1, ptr @.d471 }, 1
  %t20 = extractvalue { i64, ptr } { i64 1, ptr @.d471 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t19, i64 %t20)
  %t21 = load ptr, ptr %s1
  %t22 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t23 = load i64, ptr %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t23)
  call void @llvm.memcpy.p0.p0.i64(ptr %t24, ptr %t21, i64 %t23, i1 false)
  %t25 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  store { i64, ptr } %t26, ptr %l7
  call void @__olang_sb_done(ptr %s1)
  %t27 = load { i64, ptr }, ptr %l7
  %t28 = extractvalue { i64, ptr } %t27, 0
  %t29 = extractvalue { i64, ptr } %t27, 1
  %t30 = mul i64 %t28, 1
  %t31 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t30)
  call void @llvm.memcpy.p0.p0.i64(ptr %t31, ptr %t29, i64 %t30, i1 false)
  %t32 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  store { i64, ptr } %t33, ptr %l8
  %t34 = load i32, ptr %l3
  %t35 = load { i64, ptr }, ptr %l8
  %t36 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 %t34, { i64, ptr } { i64 3, ptr @.d472 }, { i64, ptr } %t35)
  store %"compiler/msgs:Msg" %t36, ptr %l9
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t37 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t37, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLambdaResultUninferable(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 494, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 4, ptr @.d473 }, { i64, ptr } { i64 54, ptr @.d474 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLambdaSignature(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 496, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 39, ptr @.d475 }, 1
  %t3 = extractvalue { i64, ptr } { i64 39, ptr @.d475 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 42, ptr @.d476 }, 1
  %t8 = extractvalue { i64, ptr } { i64 42, ptr @.d476 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 4, ptr @.d477 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLambdaValueObligations(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 491, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 19, ptr @.d478 }, 1
  %t3 = extractvalue { i64, ptr } { i64 19, ptr @.d478 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 91, ptr @.d479 }, 1
  %t8 = extractvalue { i64, ptr } { i64 91, ptr @.d479 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 4, ptr @.d480 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLambdaValueRelates(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 492, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 4, ptr @.d481 }, { i64, ptr } { i64 93, ptr @.d482 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLenShape(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 195, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d483 }, { i64, ptr } { i64 16, ptr @.d484 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLessNotBool(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 194, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d485 }, { i64, ptr } { i64 35, ptr @.d486 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLineStartsWithOperator(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 430, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = extractvalue { i64, ptr } { i64 25, ptr @.d487 }, 1
  %t4 = extractvalue { i64, ptr } { i64 25, ptr @.d487 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = load { i64, ptr }, ptr %l3
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 59, ptr @.d488 }, 1
  %t9 = extractvalue { i64, ptr } { i64 59, ptr @.d488 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load { i64, ptr }, ptr %l4
  %t11 = extractvalue { i64, ptr } %t10, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = extractvalue { i64, ptr } { i64 38, ptr @.d489 }, 1
  %t14 = extractvalue { i64, ptr } { i64 38, ptr @.d489 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t13, i64 %t14)
  %t15 = load ptr, ptr %s1
  %t16 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t17 = load i64, ptr %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t15, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t21 = load { i64, ptr }, ptr %l5
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l6
  %t28 = load i32, ptr %l2
  %t29 = load { i64, ptr }, ptr %l6
  %t30 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t28, { i64, ptr } { i64 3, ptr @.d490 }, { i64, ptr } %t29)
  store %"compiler/msgs:Msg" %t30, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t31 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t31, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLinkFailed(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 41, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 8, ptr @.d491 }, 1
  %t3 = extractvalue { i64, ptr } { i64 8, ptr @.d491 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 7, ptr @.d492 }, 1
  %t8 = extractvalue { i64, ptr } { i64 7, ptr @.d492 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 0, ptr @.d493 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLiteralDoesNotMeet(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 322, ptr %l3
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l4
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l5
  %t3 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t3, ptr %l6
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t4 = extractvalue { i64, ptr } { i64 26, ptr @.d494 }, 1
  %t5 = extractvalue { i64, ptr } { i64 26, ptr @.d494 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t4, i64 %t5)
  %t6 = load { i64, ptr }, ptr %l4
  %t7 = extractvalue { i64, ptr } %t6, 1
  %t8 = extractvalue { i64, ptr } %t6, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = extractvalue { i64, ptr } { i64 6, ptr @.d495 }, 1
  %t10 = extractvalue { i64, ptr } { i64 6, ptr @.d495 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t9, i64 %t10)
  %t11 = load { i64, ptr }, ptr %l5
  %t12 = extractvalue { i64, ptr } %t11, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  call void @__olang_sb_put(ptr %s1, ptr %t12, i64 %t13)
  %t14 = extractvalue { i64, ptr } { i64 20, ptr @.d496 }, 1
  %t15 = extractvalue { i64, ptr } { i64 20, ptr @.d496 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t14, i64 %t15)
  %t16 = load { i64, ptr }, ptr %l6
  %t17 = extractvalue { i64, ptr } %t16, 1
  %t18 = extractvalue { i64, ptr } %t16, 0
  call void @__olang_sb_put(ptr %s1, ptr %t17, i64 %t18)
  %t19 = extractvalue { i64, ptr } { i64 14, ptr @.d497 }, 1
  %t20 = extractvalue { i64, ptr } { i64 14, ptr @.d497 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t19, i64 %t20)
  %t21 = load ptr, ptr %s1
  %t22 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t23 = load i64, ptr %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t23)
  call void @llvm.memcpy.p0.p0.i64(ptr %t24, ptr %t21, i64 %t23, i1 false)
  %t25 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  store { i64, ptr } %t26, ptr %l7
  call void @__olang_sb_done(ptr %s1)
  %t27 = load { i64, ptr }, ptr %l7
  %t28 = extractvalue { i64, ptr } %t27, 0
  %t29 = extractvalue { i64, ptr } %t27, 1
  %t30 = mul i64 %t28, 1
  %t31 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t30)
  call void @llvm.memcpy.p0.p0.i64(ptr %t31, ptr %t29, i64 %t30, i1 false)
  %t32 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  store { i64, ptr } %t33, ptr %l8
  %t34 = load i32, ptr %l3
  %t35 = load { i64, ptr }, ptr %l8
  %t36 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 %t34, { i64, ptr } { i64 3, ptr @.d498 }, { i64, ptr } %t35)
  store %"compiler/msgs:Msg" %t36, ptr %l9
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t37 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t37, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLiteralExprRange(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 228, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 45, ptr @.d499 }, 1
  %t3 = extractvalue { i64, ptr } { i64 45, ptr @.d499 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 3, ptr @.d500 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLiteralRange(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 224, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = load { i64, ptr }, ptr %l3
  %t4 = extractvalue { i64, ptr } %t3, 1
  %t5 = extractvalue { i64, ptr } %t3, 0
  call void @__olang_sb_put(ptr %s1, ptr %t4, i64 %t5)
  %t6 = extractvalue { i64, ptr } { i64 14, ptr @.d501 }, 1
  %t7 = extractvalue { i64, ptr } { i64 14, ptr @.d501 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = load { i64, ptr }, ptr %l4
  %t9 = extractvalue { i64, ptr } %t8, 1
  %t10 = extractvalue { i64, ptr } %t8, 0
  call void @__olang_sb_put(ptr %s1, ptr %t9, i64 %t10)
  %t11 = load ptr, ptr %s1
  %t12 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t13 = load i64, ptr %t12
  %t14 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t13)
  call void @llvm.memcpy.p0.p0.i64(ptr %t14, ptr %t11, i64 %t13, i1 false)
  %t15 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t17 = load { i64, ptr }, ptr %l5
  %t18 = extractvalue { i64, ptr } %t17, 0
  %t19 = extractvalue { i64, ptr } %t17, 1
  %t20 = mul i64 %t18, 1
  %t21 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t20)
  call void @llvm.memcpy.p0.p0.i64(ptr %t21, ptr %t19, i64 %t20, i1 false)
  %t22 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l6
  %t24 = load i32, ptr %l2
  %t25 = load { i64, ptr }, ptr %l6
  %t26 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t24, { i64, ptr } { i64 2, ptr @.d502 }, { i64, ptr } %t25)
  store %"compiler/msgs:Msg" %t26, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t27 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t27, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMatchNotExhaustive(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 437, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = extractvalue { i64, ptr } { i64 5, ptr @.d503 }, 1
  %t4 = extractvalue { i64, ptr } { i64 5, ptr @.d503 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = load { i64, ptr }, ptr %l3
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 4, ptr @.d504 }, 1
  %t9 = extractvalue { i64, ptr } { i64 4, ptr @.d504 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load { i64, ptr }, ptr %l4
  %t11 = extractvalue { i64, ptr } %t10, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = extractvalue { i64, ptr } { i64 42, ptr @.d505 }, 1
  %t14 = extractvalue { i64, ptr } { i64 42, ptr @.d505 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t13, i64 %t14)
  %t15 = load ptr, ptr %s1
  %t16 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t17 = load i64, ptr %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t15, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t21 = load { i64, ptr }, ptr %l5
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l6
  %t28 = load i32, ptr %l2
  %t29 = load { i64, ptr }, ptr %l6
  %t30 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t28, { i64, ptr } { i64 4, ptr @.d506 }, { i64, ptr } %t29)
  store %"compiler/msgs:Msg" %t30, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t31 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t31, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMatchValueNeedsNomatch(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 438, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 13, ptr @.d507 }, 1
  %t3 = extractvalue { i64, ptr } { i64 13, ptr @.d507 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 73, ptr @.d508 }, 1
  %t8 = extractvalue { i64, ptr } { i64 73, ptr @.d508 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 4, ptr @.d509 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMatchValueOne(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 439, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 9, ptr @.d510 }, { i64, ptr } { i64 116, ptr @.d511 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMatchValueTypes(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 436, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = extractvalue { i64, ptr } { i64 29, ptr @.d512 }, 1
  %t4 = extractvalue { i64, ptr } { i64 29, ptr @.d512 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = load { i64, ptr }, ptr %l3
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 8, ptr @.d513 }, 1
  %t9 = extractvalue { i64, ptr } { i64 8, ptr @.d513 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load { i64, ptr }, ptr %l4
  %t11 = extractvalue { i64, ptr } %t10, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = load ptr, ptr %s1
  %t14 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t15 = load i64, ptr %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t13, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t19 = load { i64, ptr }, ptr %l5
  %t20 = extractvalue { i64, ptr } %t19, 0
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = mul i64 %t20, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t22)
  call void @llvm.memcpy.p0.p0.i64(ptr %t23, ptr %t21, i64 %t22, i1 false)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l6
  %t26 = load i32, ptr %l2
  %t27 = load { i64, ptr }, ptr %l6
  %t28 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t26, { i64, ptr } { i64 4, ptr @.d514 }, { i64, ptr } %t27)
  store %"compiler/msgs:Msg" %t28, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t29, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMatmulUndeclared(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 332, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 33, ptr @.d515 }, 1
  %t3 = extractvalue { i64, ptr } { i64 33, ptr @.d515 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 19, ptr @.d516 }, 1
  %t8 = extractvalue { i64, ptr } { i64 19, ptr @.d516 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 3, ptr @.d517 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMembershipNeedsTry(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 338, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 37, ptr @.d518 }, 1
  %t6 = extractvalue { i64, ptr } { i64 37, ptr @.d518 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 3, ptr @.d519 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMembershipNoMethod(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 336, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = extractvalue { i64, ptr } { i64 15, ptr @.d520 }, 1
  %t4 = extractvalue { i64, ptr } { i64 15, ptr @.d520 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = load { i64, ptr }, ptr %l3
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 6, ptr @.d521 }, 1
  %t9 = extractvalue { i64, ptr } { i64 6, ptr @.d521 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load { i64, ptr }, ptr %l4
  %t11 = extractvalue { i64, ptr } %t10, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = extractvalue { i64, ptr } { i64 9, ptr @.d522 }, 1
  %t14 = extractvalue { i64, ptr } { i64 9, ptr @.d522 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t13, i64 %t14)
  %t15 = load ptr, ptr %s1
  %t16 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t17 = load i64, ptr %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t15, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t21 = load { i64, ptr }, ptr %l5
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l6
  %t28 = load i32, ptr %l2
  %t29 = load { i64, ptr }, ptr %l6
  %t30 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t28, { i64, ptr } { i64 3, ptr @.d523 }, { i64, ptr } %t29)
  store %"compiler/msgs:Msg" %t30, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t31 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t31, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodCannotFail(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 193, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 70, ptr @.d524 }, 1
  %t6 = extractvalue { i64, ptr } { i64 70, ptr @.d524 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 3, ptr @.d525 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodClashesInherited(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 205, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = load { i64, ptr }, ptr %l3
  %t4 = extractvalue { i64, ptr } %t3, 1
  %t5 = extractvalue { i64, ptr } %t3, 0
  call void @__olang_sb_put(ptr %s1, ptr %t4, i64 %t5)
  %t6 = extractvalue { i64, ptr } { i64 19, ptr @.d526 }, 1
  %t7 = extractvalue { i64, ptr } { i64 19, ptr @.d526 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = load { i64, ptr }, ptr %l4
  %t9 = extractvalue { i64, ptr } %t8, 1
  %t10 = extractvalue { i64, ptr } %t8, 0
  call void @__olang_sb_put(ptr %s1, ptr %t9, i64 %t10)
  %t11 = extractvalue { i64, ptr } { i64 36, ptr @.d527 }, 1
  %t12 = extractvalue { i64, ptr } { i64 36, ptr @.d527 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = load ptr, ptr %s1
  %t14 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t15 = load i64, ptr %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t13, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t19 = load { i64, ptr }, ptr %l5
  %t20 = extractvalue { i64, ptr } %t19, 0
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = mul i64 %t20, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t22)
  call void @llvm.memcpy.p0.p0.i64(ptr %t23, ptr %t21, i64 %t22, i1 false)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l6
  %t26 = load i32, ptr %l2
  %t27 = load { i64, ptr }, ptr %l6
  %t28 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t26, { i64, ptr } { i64 4, ptr @.d528 }, { i64, ptr } %t27)
  store %"compiler/msgs:Msg" %t28, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t29, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodClashesSupplied(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 206, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = extractvalue { i64, ptr } { i64 22, ptr @.d529 }, 1
  %t4 = extractvalue { i64, ptr } { i64 22, ptr @.d529 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = load { i64, ptr }, ptr %l3
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 5, ptr @.d530 }, 1
  %t9 = extractvalue { i64, ptr } { i64 5, ptr @.d530 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load { i64, ptr }, ptr %l4
  %t11 = extractvalue { i64, ptr } %t10, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = extractvalue { i64, ptr } { i64 22, ptr @.d531 }, 1
  %t14 = extractvalue { i64, ptr } { i64 22, ptr @.d531 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t13, i64 %t14)
  %t15 = load ptr, ptr %s1
  %t16 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t17 = load i64, ptr %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t15, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t21 = load { i64, ptr }, ptr %l5
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l6
  %t28 = load i32, ptr %l2
  %t29 = load { i64, ptr }, ptr %l6
  %t30 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t28, { i64, ptr } { i64 12, ptr @.d532 }, { i64, ptr } %t29)
  store %"compiler/msgs:Msg" %t30, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t31 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t31, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodNotInherited(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 366, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = load { i64, ptr }, ptr %l3
  %t4 = extractvalue { i64, ptr } %t3, 1
  %t5 = extractvalue { i64, ptr } %t3, 0
  call void @__olang_sb_put(ptr %s1, ptr %t4, i64 %t5)
  %t6 = extractvalue { i64, ptr } { i64 13, ptr @.d533 }, 1
  %t7 = extractvalue { i64, ptr } { i64 13, ptr @.d533 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = load { i64, ptr }, ptr %l4
  %t9 = extractvalue { i64, ptr } %t8, 1
  %t10 = extractvalue { i64, ptr } %t8, 0
  call void @__olang_sb_put(ptr %s1, ptr %t9, i64 %t10)
  %t11 = extractvalue { i64, ptr } { i64 73, ptr @.d534 }, 1
  %t12 = extractvalue { i64, ptr } { i64 73, ptr @.d534 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = load ptr, ptr %s1
  %t14 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t15 = load i64, ptr %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t13, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t19 = load { i64, ptr }, ptr %l5
  %t20 = extractvalue { i64, ptr } %t19, 0
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = mul i64 %t20, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t22)
  call void @llvm.memcpy.p0.p0.i64(ptr %t23, ptr %t21, i64 %t22, i1 false)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l6
  %t26 = load i32, ptr %l2
  %t27 = load { i64, ptr }, ptr %l6
  %t28 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t26, { i64, ptr } { i64 4, ptr @.d535 }, { i64, ptr } %t27)
  store %"compiler/msgs:Msg" %t28, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t29, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodOnBuiltinType(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 207, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 37, ptr @.d536 }, 1
  %t3 = extractvalue { i64, ptr } { i64 37, ptr @.d536 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 59, ptr @.d537 }, 1
  %t8 = extractvalue { i64, ptr } { i64 59, ptr @.d537 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 4, ptr @.d538 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMissingReturn(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 499, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 41, ptr @.d539 }, 1
  %t3 = extractvalue { i64, ptr } { i64 41, ptr @.d539 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 53, ptr @.d540 }, 1
  %t8 = extractvalue { i64, ptr } { i64 53, ptr @.d540 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 4, ptr @.d541 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeFirst(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 8, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 29, ptr @.d542 }, 1
  %t3 = extractvalue { i64, ptr } { i64 29, ptr @.d542 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 22, ptr @.d543 }, 1
  %t8 = extractvalue { i64, ptr } { i64 22, ptr @.d543 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 2, ptr @.d544 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeNeedsFile(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 3, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 13, ptr @.d545 }, 1
  %t6 = extractvalue { i64, ptr } { i64 13, ptr @.d545 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 2, ptr @.d546 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeOneFile(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 2, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 23, ptr @.d547 }, 1
  %t6 = extractvalue { i64, ptr } { i64 23, ptr @.d547 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 2, ptr @.d548 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMutOnInferredLocal(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 410, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 4, ptr @.d549 }, { i64, ptr } { i64 99, ptr @.d550 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMutOnLocal(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 409, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 59, ptr @.d551 }, 1
  %t3 = extractvalue { i64, ptr } { i64 59, ptr @.d551 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 8, ptr @.d552 }, 1
  %t8 = extractvalue { i64, ptr } { i64 8, ptr @.d552 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 4, ptr @.d553 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMutOnValueField(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 178, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 77, ptr @.d554 }, 1
  %t3 = extractvalue { i64, ptr } { i64 77, ptr @.d554 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 8, ptr @.d555 }, 1
  %t8 = extractvalue { i64, ptr } { i64 8, ptr @.d555 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 2, ptr @.d556 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMutOnValueParam(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 177, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 95, ptr @.d557 }, 1
  %t3 = extractvalue { i64, ptr } { i64 95, ptr @.d557 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 8, ptr @.d558 }, 1
  %t8 = extractvalue { i64, ptr } { i64 8, ptr @.d558 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 2, ptr @.d559 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMutOnValueType(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 176, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 38, ptr @.d560 }, 1
  %t3 = extractvalue { i64, ptr } { i64 38, ptr @.d560 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 16, ptr @.d561 }, 1
  %t8 = extractvalue { i64, ptr } { i64 16, ptr @.d561 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 4, ptr @.d562 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNameClashesWithImport(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 97, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 57, ptr @.d563 }, 1
  %t6 = extractvalue { i64, ptr } { i64 57, ptr @.d563 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 3, ptr @.d564 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNameInUse(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 118, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 35, ptr @.d565 }, 1
  %t6 = extractvalue { i64, ptr } { i64 35, ptr @.d565 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 2, ptr @.d566 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNameIsType(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 112, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 57, ptr @.d567 }, 1
  %t6 = extractvalue { i64, ptr } { i64 57, ptr @.d567 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 2, ptr @.d568 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNamedScopeOnElement(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 156, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d569 }, { i64, ptr } { i64 73, ptr @.d570 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNesting(ptr %v0, i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 65, ptr %l1
  %t1 = load i64, ptr %l0
  store i64 %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 17, ptr @.d571 }, 1
  %t3 = extractvalue { i64, ptr } { i64 17, ptr @.d571 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load i64, ptr %l2
  %t5 = call ptr @__olang_sb_room(ptr %s1, i64 24)
  %t6 = call i64 @__olang_fmt_i64(ptr %t5, i64 %t4)
  call void @__olang_sb_add(ptr %s1, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 48, ptr @.d572 }, 1
  %t8 = extractvalue { i64, ptr } { i64 48, ptr @.d572 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t22, { i64, ptr } { i64 3, ptr @.d573 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoClang(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 39, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 57, ptr @.d574 }, 1
  %t3 = extractvalue { i64, ptr } { i64 57, ptr @.d574 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 1, ptr @.d575 }, 1
  %t8 = extractvalue { i64, ptr } { i64 1, ptr @.d575 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 0, ptr @.d576 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoRule(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 25, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 30, ptr @.d577 }, 1
  %t3 = extractvalue { i64, ptr } { i64 30, ptr @.d577 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 4, ptr @.d578 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSpec(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 24, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 20, ptr @.d579 }, 1
  %t3 = extractvalue { i64, ptr } { i64 20, ptr @.d579 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 4, ptr @.d580 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSuchCase(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 329, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = load { i64, ptr }, ptr %l3
  %t4 = extractvalue { i64, ptr } %t3, 1
  %t5 = extractvalue { i64, ptr } %t3, 0
  call void @__olang_sb_put(ptr %s1, ptr %t4, i64 %t5)
  %t6 = extractvalue { i64, ptr } { i64 13, ptr @.d581 }, 1
  %t7 = extractvalue { i64, ptr } { i64 13, ptr @.d581 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = load { i64, ptr }, ptr %l4
  %t9 = extractvalue { i64, ptr } %t8, 1
  %t10 = extractvalue { i64, ptr } %t8, 0
  call void @__olang_sb_put(ptr %s1, ptr %t9, i64 %t10)
  %t11 = load ptr, ptr %s1
  %t12 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t13 = load i64, ptr %t12
  %t14 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t13)
  call void @llvm.memcpy.p0.p0.i64(ptr %t14, ptr %t11, i64 %t13, i1 false)
  %t15 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t17 = load { i64, ptr }, ptr %l5
  %t18 = extractvalue { i64, ptr } %t17, 0
  %t19 = extractvalue { i64, ptr } %t17, 1
  %t20 = mul i64 %t18, 1
  %t21 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t20)
  call void @llvm.memcpy.p0.p0.i64(ptr %t21, ptr %t19, i64 %t20, i1 false)
  %t22 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l6
  %t24 = load i32, ptr %l2
  %t25 = load { i64, ptr }, ptr %l6
  %t26 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t24, { i64, ptr } { i64 3, ptr @.d582 }, { i64, ptr } %t25)
  store %"compiler/msgs:Msg" %t26, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t27 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t27, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSuchCaseMeant(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 330, ptr %l3
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l4
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l5
  %t3 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t3, ptr %l6
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t4 = load { i64, ptr }, ptr %l4
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 13, ptr @.d583 }, 1
  %t8 = extractvalue { i64, ptr } { i64 13, ptr @.d583 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load { i64, ptr }, ptr %l5
  %t10 = extractvalue { i64, ptr } %t9, 1
  %t11 = extractvalue { i64, ptr } %t9, 0
  call void @__olang_sb_put(ptr %s1, ptr %t10, i64 %t11)
  %t12 = extractvalue { i64, ptr } { i64 17, ptr @.d584 }, 1
  %t13 = extractvalue { i64, ptr } { i64 17, ptr @.d584 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t12, i64 %t13)
  %t14 = load { i64, ptr }, ptr %l6
  %t15 = extractvalue { i64, ptr } %t14, 1
  %t16 = extractvalue { i64, ptr } %t14, 0
  call void @__olang_sb_put(ptr %s1, ptr %t15, i64 %t16)
  %t17 = extractvalue { i64, ptr } { i64 2, ptr @.d585 }, 1
  %t18 = extractvalue { i64, ptr } { i64 2, ptr @.d585 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t17, i64 %t18)
  %t19 = load ptr, ptr %s1
  %t20 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t21 = load i64, ptr %t20
  %t22 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t19, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  store { i64, ptr } %t24, ptr %l7
  call void @__olang_sb_done(ptr %s1)
  %t25 = load { i64, ptr }, ptr %l7
  %t26 = extractvalue { i64, ptr } %t25, 0
  %t27 = extractvalue { i64, ptr } %t25, 1
  %t28 = mul i64 %t26, 1
  %t29 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t28)
  call void @llvm.memcpy.p0.p0.i64(ptr %t29, ptr %t27, i64 %t28, i1 false)
  %t30 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  store { i64, ptr } %t31, ptr %l8
  %t32 = load i32, ptr %l3
  %t33 = load { i64, ptr }, ptr %l8
  %t34 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 %t32, { i64, ptr } { i64 3, ptr @.d586 }, { i64, ptr } %t33)
  store %"compiler/msgs:Msg" %t34, ptr %l9
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t35 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t35, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSuchMember(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 284, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = load { i64, ptr }, ptr %l3
  %t4 = extractvalue { i64, ptr } %t3, 1
  %t5 = extractvalue { i64, ptr } %t3, 0
  call void @__olang_sb_put(ptr %s1, ptr %t4, i64 %t5)
  %t6 = extractvalue { i64, ptr } { i64 16, ptr @.d587 }, 1
  %t7 = extractvalue { i64, ptr } { i64 16, ptr @.d587 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = load { i64, ptr }, ptr %l4
  %t9 = extractvalue { i64, ptr } %t8, 1
  %t10 = extractvalue { i64, ptr } %t8, 0
  call void @__olang_sb_put(ptr %s1, ptr %t9, i64 %t10)
  %t11 = extractvalue { i64, ptr } { i64 1, ptr @.d588 }, 1
  %t12 = extractvalue { i64, ptr } { i64 1, ptr @.d588 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = load ptr, ptr %s1
  %t14 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t15 = load i64, ptr %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t13, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t19 = load { i64, ptr }, ptr %l5
  %t20 = extractvalue { i64, ptr } %t19, 0
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = mul i64 %t20, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t22)
  call void @llvm.memcpy.p0.p0.i64(ptr %t23, ptr %t21, i64 %t22, i1 false)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l6
  %t26 = load i32, ptr %l2
  %t27 = load { i64, ptr }, ptr %l6
  %t28 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t26, { i64, ptr } { i64 0, ptr @.d589 }, { i64, ptr } %t27)
  store %"compiler/msgs:Msg" %t28, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t29, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoreturnErrors(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 452, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d590 }, { i64, ptr } { i64 90, ptr @.d591 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoreturnFallsOff(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 451, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d592 }, { i64, ptr } { i64 109, ptr @.d593 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoreturnHere(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 453, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 21, ptr @.d594 }, 1
  %t6 = extractvalue { i64, ptr } { i64 21, ptr @.d594 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 3, ptr @.d595 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotAMode(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 1, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 1, ptr @.d596 }, 1
  %t3 = extractvalue { i64, ptr } { i64 1, ptr @.d596 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 135, ptr @.d597 }, 1
  %t8 = extractvalue { i64, ptr } { i64 135, ptr @.d597 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 2, ptr @.d598 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotASource(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 7, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 1, ptr @.d599 }, 1
  %t3 = extractvalue { i64, ptr } { i64 1, ptr @.d599 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 56, ptr @.d600 }, 1
  %t8 = extractvalue { i64, ptr } { i64 56, ptr @.d600 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 2, ptr @.d601 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotAStatement(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 412, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 2, ptr @.d602 }, { i64, ptr } { i64 78, ptr @.d603 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotAssignable(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 286, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 2, ptr @.d604 }, { i64, ptr } { i64 63, ptr @.d605 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotCallable(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 340, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 40, ptr @.d606 }, 1
  %t6 = extractvalue { i64, ptr } { i64 40, ptr @.d606 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 4, ptr @.d607 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotExtendedOp(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 333, ptr %l3
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l4
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l5
  %t3 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t3, ptr %l6
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t4 = load { i64, ptr }, ptr %l4
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 42, ptr @.d608 }, 1
  %t8 = extractvalue { i64, ptr } { i64 42, ptr @.d608 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load { i64, ptr }, ptr %l5
  %t10 = extractvalue { i64, ptr } %t9, 1
  %t11 = extractvalue { i64, ptr } %t9, 0
  call void @__olang_sb_put(ptr %s1, ptr %t10, i64 %t11)
  %t12 = extractvalue { i64, ptr } { i64 22, ptr @.d609 }, 1
  %t13 = extractvalue { i64, ptr } { i64 22, ptr @.d609 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t12, i64 %t13)
  %t14 = load { i64, ptr }, ptr %l6
  %t15 = extractvalue { i64, ptr } %t14, 1
  %t16 = extractvalue { i64, ptr } %t14, 0
  call void @__olang_sb_put(ptr %s1, ptr %t15, i64 %t16)
  %t17 = extractvalue { i64, ptr } { i64 30, ptr @.d610 }, 1
  %t18 = extractvalue { i64, ptr } { i64 30, ptr @.d610 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t17, i64 %t18)
  %t19 = load ptr, ptr %s1
  %t20 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t21 = load i64, ptr %t20
  %t22 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t19, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  store { i64, ptr } %t24, ptr %l7
  call void @__olang_sb_done(ptr %s1)
  %t25 = load { i64, ptr }, ptr %l7
  %t26 = extractvalue { i64, ptr } %t25, 0
  %t27 = extractvalue { i64, ptr } %t25, 1
  %t28 = mul i64 %t26, 1
  %t29 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t28)
  call void @llvm.memcpy.p0.p0.i64(ptr %t29, ptr %t27, i64 %t28, i1 false)
  %t30 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  store { i64, ptr } %t31, ptr %l8
  %t32 = load i32, ptr %l3
  %t33 = load { i64, ptr }, ptr %l8
  %t34 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 %t32, { i64, ptr } { i64 4, ptr @.d611 }, { i64, ptr } %t33)
  store %"compiler/msgs:Msg" %t34, ptr %l9
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t35 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t35, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotIndexable(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 279, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 18, ptr @.d612 }, 1
  %t6 = extractvalue { i64, ptr } { i64 18, ptr @.d612 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 3, ptr @.d613 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotIterable(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 422, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 120, ptr @.d614 }, 1
  %t6 = extractvalue { i64, ptr } { i64 120, ptr @.d614 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 3, ptr @.d615 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotRegular(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 36, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 0, ptr @.d616 }, { i64, ptr } { i64 18, ptr @.d617 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotTheOperator(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 186, ptr %l5
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l6
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l7
  %t3 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t3, ptr %l8
  %t4 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t4, ptr %l9
  %t5 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t5, ptr %l10
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t6 = load { i64, ptr }, ptr %l6
  %t7 = extractvalue { i64, ptr } %t6, 1
  %t8 = extractvalue { i64, ptr } %t6, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = extractvalue { i64, ptr } { i64 3, ptr @.d618 }, 1
  %t10 = extractvalue { i64, ptr } { i64 3, ptr @.d618 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t9, i64 %t10)
  %t11 = load { i64, ptr }, ptr %l7
  %t12 = extractvalue { i64, ptr } %t11, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  call void @__olang_sb_put(ptr %s1, ptr %t12, i64 %t13)
  %t14 = extractvalue { i64, ptr } { i64 7, ptr @.d619 }, 1
  %t15 = extractvalue { i64, ptr } { i64 7, ptr @.d619 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t14, i64 %t15)
  %t16 = load { i64, ptr }, ptr %l8
  %t17 = extractvalue { i64, ptr } %t16, 1
  %t18 = extractvalue { i64, ptr } %t16, 0
  call void @__olang_sb_put(ptr %s1, ptr %t17, i64 %t18)
  %t19 = extractvalue { i64, ptr } { i64 56, ptr @.d620 }, 1
  %t20 = extractvalue { i64, ptr } { i64 56, ptr @.d620 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t19, i64 %t20)
  %t21 = load { i64, ptr }, ptr %l9
  %t22 = extractvalue { i64, ptr } %t21, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  call void @__olang_sb_put(ptr %s1, ptr %t22, i64 %t23)
  %t24 = extractvalue { i64, ptr } { i64 20, ptr @.d621 }, 1
  %t25 = extractvalue { i64, ptr } { i64 20, ptr @.d621 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t24, i64 %t25)
  %t26 = load { i64, ptr }, ptr %l10
  %t27 = extractvalue { i64, ptr } %t26, 1
  %t28 = extractvalue { i64, ptr } %t26, 0
  call void @__olang_sb_put(ptr %s1, ptr %t27, i64 %t28)
  %t29 = load ptr, ptr %s1
  %t30 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t31 = load i64, ptr %t30
  %t32 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t31)
  call void @llvm.memcpy.p0.p0.i64(ptr %t32, ptr %t29, i64 %t31, i1 false)
  %t33 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  store { i64, ptr } %t34, ptr %l11
  call void @__olang_sb_done(ptr %s1)
  %t35 = load { i64, ptr }, ptr %l11
  %t36 = extractvalue { i64, ptr } %t35, 0
  %t37 = extractvalue { i64, ptr } %t35, 1
  %t38 = mul i64 %t36, 1
  %t39 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t38)
  call void @llvm.memcpy.p0.p0.i64(ptr %t39, ptr %t37, i64 %t38, i1 false)
  %t40 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  store { i64, ptr } %t41, ptr %l12
  %t42 = load i32, ptr %l5
  %t43 = load { i64, ptr }, ptr %l12
  %t44 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v5, ptr %v5, ptr %v5, i32 %t42, { i64, ptr } { i64 3, ptr @.d622 }, { i64, ptr } %t43)
  store %"compiler/msgs:Msg" %t44, ptr %l13
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t45 = load %"compiler/msgs:Msg", ptr %l13
  store %"compiler/msgs:Msg" %t45, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDeclaredHere(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 309, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 17, ptr @.d623 }, 1
  %t6 = extractvalue { i64, ptr } { i64 17, ptr @.d623 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 0, ptr @.d624 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteFuncTypeScopes(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 296, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 102, ptr @.d625 }, 1
  %t3 = extractvalue { i64, ptr } { i64 102, ptr @.d625 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 30, ptr @.d626 }, 1
  %t8 = extractvalue { i64, ptr } { i64 30, ptr @.d626 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 0, ptr @.d627 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteHere(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 295, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 0, ptr @.d628 }, { i64, ptr } { i64 4, ptr @.d629 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteInLibrary(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 303, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 0, ptr @.d630 }, { i64, ptr } { i64 36, ptr @.d631 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteLoopCopy(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 535, ptr %l3
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l4
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l5
  %t3 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t3, ptr %l6
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t4 = extractvalue { i64, ptr } { i64 1, ptr @.d632 }, 1
  %t5 = extractvalue { i64, ptr } { i64 1, ptr @.d632 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t4, i64 %t5)
  %t6 = load { i64, ptr }, ptr %l4
  %t7 = extractvalue { i64, ptr } %t6, 1
  %t8 = extractvalue { i64, ptr } %t6, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = extractvalue { i64, ptr } { i64 89, ptr @.d633 }, 1
  %t10 = extractvalue { i64, ptr } { i64 89, ptr @.d633 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t9, i64 %t10)
  %t11 = load { i64, ptr }, ptr %l5
  %t12 = extractvalue { i64, ptr } %t11, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  call void @__olang_sb_put(ptr %s1, ptr %t12, i64 %t13)
  %t14 = extractvalue { i64, ptr } { i64 27, ptr @.d634 }, 1
  %t15 = extractvalue { i64, ptr } { i64 27, ptr @.d634 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t14, i64 %t15)
  %t16 = load { i64, ptr }, ptr %l6
  %t17 = extractvalue { i64, ptr } %t16, 1
  %t18 = extractvalue { i64, ptr } %t16, 0
  call void @__olang_sb_put(ptr %s1, ptr %t17, i64 %t18)
  %t19 = extractvalue { i64, ptr } { i64 7, ptr @.d635 }, 1
  %t20 = extractvalue { i64, ptr } { i64 7, ptr @.d635 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t19, i64 %t20)
  %t21 = load ptr, ptr %s1
  %t22 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t23 = load i64, ptr %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t23)
  call void @llvm.memcpy.p0.p0.i64(ptr %t24, ptr %t21, i64 %t23, i1 false)
  %t25 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  store { i64, ptr } %t26, ptr %l7
  call void @__olang_sb_done(ptr %s1)
  %t27 = load { i64, ptr }, ptr %l7
  %t28 = extractvalue { i64, ptr } %t27, 0
  %t29 = extractvalue { i64, ptr } %t27, 1
  %t30 = mul i64 %t28, 1
  %t31 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t30)
  call void @llvm.memcpy.p0.p0.i64(ptr %t31, ptr %t29, i64 %t30, i1 false)
  %t32 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  store { i64, ptr } %t33, ptr %l8
  %t34 = load i32, ptr %l3
  %t35 = load { i64, ptr }, ptr %l8
  %t36 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 %t34, { i64, ptr } { i64 0, ptr @.d636 }, { i64, ptr } %t35)
  store %"compiler/msgs:Msg" %t36, ptr %l9
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t37 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t37, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteLoopCopyLent(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 529, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 1, ptr @.d637 }, 1
  %t3 = extractvalue { i64, ptr } { i64 1, ptr @.d637 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 185, ptr @.d638 }, 1
  %t8 = extractvalue { i64, ptr } { i64 185, ptr @.d638 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 0, ptr @.d639 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteObligationOrigin(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 525, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 0, ptr @.d640 }, { i64, ptr } { i64 48, ptr @.d641 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteOtherSignature(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 306, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 1, ptr @.d642 }, 1
  %t3 = extractvalue { i64, ptr } { i64 1, ptr @.d642 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 42, ptr @.d643 }, 1
  %t8 = extractvalue { i64, ptr } { i64 42, ptr @.d643 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 0, ptr @.d644 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotePrivateSpelling(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 307, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = extractvalue { i64, ptr } { i64 1, ptr @.d645 }, 1
  %t4 = extractvalue { i64, ptr } { i64 1, ptr @.d645 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = load { i64, ptr }, ptr %l3
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 46, ptr @.d646 }, 1
  %t9 = extractvalue { i64, ptr } { i64 46, ptr @.d646 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load { i64, ptr }, ptr %l4
  %t11 = extractvalue { i64, ptr } %t10, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = extractvalue { i64, ptr } { i64 21, ptr @.d647 }, 1
  %t14 = extractvalue { i64, ptr } { i64 21, ptr @.d647 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t13, i64 %t14)
  %t15 = load ptr, ptr %s1
  %t16 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t17 = load i64, ptr %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t15, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t21 = load { i64, ptr }, ptr %l5
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l6
  %t28 = load i32, ptr %l2
  %t29 = load { i64, ptr }, ptr %l6
  %t30 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t28, { i64, ptr } { i64 0, ptr @.d648 }, { i64, ptr } %t29)
  store %"compiler/msgs:Msg" %t30, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t31 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t31, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteReadOnlyCopy(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 243, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 1, ptr @.d649 }, 1
  %t3 = extractvalue { i64, ptr } { i64 1, ptr @.d649 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 54, ptr @.d650 }, 1
  %t8 = extractvalue { i64, ptr } { i64 54, ptr @.d650 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 0, ptr @.d651 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteReadOnlyCopyOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 244, ptr %l4
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l5
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l6
  %t3 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t3, ptr %l7
  %t4 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t4, ptr %l8
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t5 = extractvalue { i64, ptr } { i64 1, ptr @.d652 }, 1
  %t6 = extractvalue { i64, ptr } { i64 1, ptr @.d652 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load { i64, ptr }, ptr %l5
  %t8 = extractvalue { i64, ptr } %t7, 1
  %t9 = extractvalue { i64, ptr } %t7, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = extractvalue { i64, ptr } { i64 10, ptr @.d653 }, 1
  %t11 = extractvalue { i64, ptr } { i64 10, ptr @.d653 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t10, i64 %t11)
  %t12 = load { i64, ptr }, ptr %l6
  %t13 = extractvalue { i64, ptr } %t12, 1
  %t14 = extractvalue { i64, ptr } %t12, 0
  call void @__olang_sb_put(ptr %s1, ptr %t13, i64 %t14)
  %t15 = extractvalue { i64, ptr } { i64 44, ptr @.d654 }, 1
  %t16 = extractvalue { i64, ptr } { i64 44, ptr @.d654 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t15, i64 %t16)
  %t17 = load { i64, ptr }, ptr %l7
  %t18 = extractvalue { i64, ptr } %t17, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  call void @__olang_sb_put(ptr %s1, ptr %t18, i64 %t19)
  %t20 = extractvalue { i64, ptr } { i64 4, ptr @.d655 }, 1
  %t21 = extractvalue { i64, ptr } { i64 4, ptr @.d655 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t20, i64 %t21)
  %t22 = load { i64, ptr }, ptr %l8
  %t23 = extractvalue { i64, ptr } %t22, 1
  %t24 = extractvalue { i64, ptr } %t22, 0
  call void @__olang_sb_put(ptr %s1, ptr %t23, i64 %t24)
  %t25 = extractvalue { i64, ptr } { i64 33, ptr @.d656 }, 1
  %t26 = extractvalue { i64, ptr } { i64 33, ptr @.d656 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t25, i64 %t26)
  %t27 = load ptr, ptr %s1
  %t28 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t29 = load i64, ptr %t28
  %t30 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t27, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  store { i64, ptr } %t32, ptr %l9
  call void @__olang_sb_done(ptr %s1)
  %t33 = load { i64, ptr }, ptr %l9
  %t34 = extractvalue { i64, ptr } %t33, 0
  %t35 = extractvalue { i64, ptr } %t33, 1
  %t36 = mul i64 %t34, 1
  %t37 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t36)
  call void @llvm.memcpy.p0.p0.i64(ptr %t37, ptr %t35, i64 %t36, i1 false)
  %t38 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l10
  %t40 = load i32, ptr %l4
  %t41 = load { i64, ptr }, ptr %l10
  %t42 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, i32 %t40, { i64, ptr } { i64 0, ptr @.d657 }, { i64, ptr } %t41)
  store %"compiler/msgs:Msg" %t42, ptr %l11
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t43 = load %"compiler/msgs:Msg", ptr %l11
  store %"compiler/msgs:Msg" %t43, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteSliceOfTemporary(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 533, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 0, ptr @.d658 }, { i64, ptr } { i64 145, ptr @.d659 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteStrBuildsHere(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 301, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 0, ptr @.d660 }, { i64, ptr } { i64 57, ptr @.d661 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteVecGrowsHere(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 298, ptr %l3
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l4
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l5
  %t3 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t3, ptr %l6
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t4 = extractvalue { i64, ptr } { i64 1, ptr @.d662 }, 1
  %t5 = extractvalue { i64, ptr } { i64 1, ptr @.d662 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t4, i64 %t5)
  %t6 = load { i64, ptr }, ptr %l4
  %t7 = extractvalue { i64, ptr } %t6, 1
  %t8 = extractvalue { i64, ptr } %t6, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = extractvalue { i64, ptr } { i64 20, ptr @.d663 }, 1
  %t10 = extractvalue { i64, ptr } { i64 20, ptr @.d663 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t9, i64 %t10)
  %t11 = load { i64, ptr }, ptr %l5
  %t12 = extractvalue { i64, ptr } %t11, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  call void @__olang_sb_put(ptr %s1, ptr %t12, i64 %t13)
  %t14 = extractvalue { i64, ptr } { i64 56, ptr @.d664 }, 1
  %t15 = extractvalue { i64, ptr } { i64 56, ptr @.d664 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t14, i64 %t15)
  %t16 = load { i64, ptr }, ptr %l6
  %t17 = extractvalue { i64, ptr } %t16, 1
  %t18 = extractvalue { i64, ptr } %t16, 0
  call void @__olang_sb_put(ptr %s1, ptr %t17, i64 %t18)
  %t19 = extractvalue { i64, ptr } { i64 11, ptr @.d665 }, 1
  %t20 = extractvalue { i64, ptr } { i64 11, ptr @.d665 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t19, i64 %t20)
  %t21 = load ptr, ptr %s1
  %t22 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t23 = load i64, ptr %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t23)
  call void @llvm.memcpy.p0.p0.i64(ptr %t24, ptr %t21, i64 %t23, i1 false)
  %t25 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  store { i64, ptr } %t26, ptr %l7
  call void @__olang_sb_done(ptr %s1)
  %t27 = load { i64, ptr }, ptr %l7
  %t28 = extractvalue { i64, ptr } %t27, 0
  %t29 = extractvalue { i64, ptr } %t27, 1
  %t30 = mul i64 %t28, 1
  %t31 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t30)
  call void @llvm.memcpy.p0.p0.i64(ptr %t31, ptr %t29, i64 %t30, i1 false)
  %t32 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  store { i64, ptr } %t33, ptr %l8
  %t34 = load i32, ptr %l3
  %t35 = load { i64, ptr }, ptr %l8
  %t36 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 %t34, { i64, ptr } { i64 0, ptr @.d666 }, { i64, ptr } %t35)
  store %"compiler/msgs:Msg" %t36, ptr %l9
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t37 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t37, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteVecGrowsInside(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 299, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 17, ptr @.d667 }, 1
  %t6 = extractvalue { i64, ptr } { i64 17, ptr @.d667 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 0, ptr @.d668 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteVecTaskHolds(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 300, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 28, ptr @.d669 }, 1
  %t3 = extractvalue { i64, ptr } { i64 28, ptr @.d669 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 17, ptr @.d670 }, 1
  %t8 = extractvalue { i64, ptr } { i64 17, ptr @.d670 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 0, ptr @.d671 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNumberDoesNotFlow(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 227, ptr %l3
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l4
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l5
  %t3 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t3, ptr %l6
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t4 = load { i64, ptr }, ptr %l4
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 20, ptr @.d672 }, 1
  %t8 = extractvalue { i64, ptr } { i64 20, ptr @.d672 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load { i64, ptr }, ptr %l5
  %t10 = extractvalue { i64, ptr } %t9, 1
  %t11 = extractvalue { i64, ptr } %t9, 0
  call void @__olang_sb_put(ptr %s1, ptr %t10, i64 %t11)
  %t12 = extractvalue { i64, ptr } { i64 18, ptr @.d673 }, 1
  %t13 = extractvalue { i64, ptr } { i64 18, ptr @.d673 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t12, i64 %t13)
  %t14 = load { i64, ptr }, ptr %l6
  %t15 = extractvalue { i64, ptr } %t14, 1
  %t16 = extractvalue { i64, ptr } %t14, 0
  call void @__olang_sb_put(ptr %s1, ptr %t15, i64 %t16)
  %t17 = extractvalue { i64, ptr } { i64 3, ptr @.d674 }, 1
  %t18 = extractvalue { i64, ptr } { i64 3, ptr @.d674 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t17, i64 %t18)
  %t19 = load ptr, ptr %s1
  %t20 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t21 = load i64, ptr %t20
  %t22 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t19, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  store { i64, ptr } %t24, ptr %l7
  call void @__olang_sb_done(ptr %s1)
  %t25 = load { i64, ptr }, ptr %l7
  %t26 = extractvalue { i64, ptr } %t25, 0
  %t27 = extractvalue { i64, ptr } %t25, 1
  %t28 = mul i64 %t26, 1
  %t29 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t28)
  call void @llvm.memcpy.p0.p0.i64(ptr %t29, ptr %t27, i64 %t28, i1 false)
  %t30 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  store { i64, ptr } %t31, ptr %l8
  %t32 = load i32, ptr %l3
  %t33 = load { i64, ptr }, ptr %l8
  %t34 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 %t32, { i64, ptr } { i64 3, ptr @.d675 }, { i64, ptr } %t33)
  store %"compiler/msgs:Msg" %t34, ptr %l9
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t35 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t35, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNumbersDoNotMeet(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 325, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = load { i64, ptr }, ptr %l3
  %t4 = extractvalue { i64, ptr } %t3, 1
  %t5 = extractvalue { i64, ptr } %t3, 0
  call void @__olang_sb_put(ptr %s1, ptr %t4, i64 %t5)
  %t6 = extractvalue { i64, ptr } { i64 5, ptr @.d676 }, 1
  %t7 = extractvalue { i64, ptr } { i64 5, ptr @.d676 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = load { i64, ptr }, ptr %l4
  %t9 = extractvalue { i64, ptr } %t8, 1
  %t10 = extractvalue { i64, ptr } %t8, 0
  call void @__olang_sb_put(ptr %s1, ptr %t9, i64 %t10)
  %t11 = extractvalue { i64, ptr } { i64 56, ptr @.d677 }, 1
  %t12 = extractvalue { i64, ptr } { i64 56, ptr @.d677 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = load ptr, ptr %s1
  %t14 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t15 = load i64, ptr %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t13, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t19 = load { i64, ptr }, ptr %l5
  %t20 = extractvalue { i64, ptr } %t19, 0
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = mul i64 %t20, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t22)
  call void @llvm.memcpy.p0.p0.i64(ptr %t23, ptr %t21, i64 %t22, i1 false)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l6
  %t26 = load i32, ptr %l2
  %t27 = load { i64, ptr }, ptr %l6
  %t28 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t26, { i64, ptr } { i64 3, ptr @.d678 }, { i64, ptr } %t27)
  store %"compiler/msgs:Msg" %t28, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t29, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperandNotBool(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 317, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = load { i64, ptr }, ptr %l3
  %t4 = extractvalue { i64, ptr } %t3, 1
  %t5 = extractvalue { i64, ptr } %t3, 0
  call void @__olang_sb_put(ptr %s1, ptr %t4, i64 %t5)
  %t6 = extractvalue { i64, ptr } { i64 21, ptr @.d679 }, 1
  %t7 = extractvalue { i64, ptr } { i64 21, ptr @.d679 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = load { i64, ptr }, ptr %l4
  %t9 = extractvalue { i64, ptr } %t8, 1
  %t10 = extractvalue { i64, ptr } %t8, 0
  call void @__olang_sb_put(ptr %s1, ptr %t9, i64 %t10)
  %t11 = load ptr, ptr %s1
  %t12 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t13 = load i64, ptr %t12
  %t14 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t13)
  call void @llvm.memcpy.p0.p0.i64(ptr %t14, ptr %t11, i64 %t13, i1 false)
  %t15 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t17 = load { i64, ptr }, ptr %l5
  %t18 = extractvalue { i64, ptr } %t17, 0
  %t19 = extractvalue { i64, ptr } %t17, 1
  %t20 = mul i64 %t18, 1
  %t21 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t20)
  call void @llvm.memcpy.p0.p0.i64(ptr %t21, ptr %t19, i64 %t20, i1 false)
  %t22 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l6
  %t24 = load i32, ptr %l2
  %t25 = load { i64, ptr }, ptr %l6
  %t26 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t24, { i64, ptr } { i64 2, ptr @.d680 }, { i64, ptr } %t25)
  store %"compiler/msgs:Msg" %t26, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t27 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t27, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperandNotInt(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 318, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = load { i64, ptr }, ptr %l3
  %t4 = extractvalue { i64, ptr } %t3, 1
  %t5 = extractvalue { i64, ptr } %t3, 0
  call void @__olang_sb_put(ptr %s1, ptr %t4, i64 %t5)
  %t6 = extractvalue { i64, ptr } { i64 25, ptr @.d681 }, 1
  %t7 = extractvalue { i64, ptr } { i64 25, ptr @.d681 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = load { i64, ptr }, ptr %l4
  %t9 = extractvalue { i64, ptr } %t8, 1
  %t10 = extractvalue { i64, ptr } %t8, 0
  call void @__olang_sb_put(ptr %s1, ptr %t9, i64 %t10)
  %t11 = load ptr, ptr %s1
  %t12 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t13 = load i64, ptr %t12
  %t14 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t13)
  call void @llvm.memcpy.p0.p0.i64(ptr %t14, ptr %t11, i64 %t13, i1 false)
  %t15 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t17 = load { i64, ptr }, ptr %l5
  %t18 = extractvalue { i64, ptr } %t17, 0
  %t19 = extractvalue { i64, ptr } %t17, 1
  %t20 = mul i64 %t18, 1
  %t21 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t20)
  call void @llvm.memcpy.p0.p0.i64(ptr %t21, ptr %t19, i64 %t20, i1 false)
  %t22 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l6
  %t24 = load i32, ptr %l2
  %t25 = load { i64, ptr }, ptr %l6
  %t26 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t24, { i64, ptr } { i64 2, ptr @.d682 }, { i64, ptr } %t25)
  store %"compiler/msgs:Msg" %t26, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t27 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t27, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperandNotNumber(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 319, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = load { i64, ptr }, ptr %l3
  %t4 = extractvalue { i64, ptr } %t3, 1
  %t5 = extractvalue { i64, ptr } %t3, 0
  call void @__olang_sb_put(ptr %s1, ptr %t4, i64 %t5)
  %t6 = extractvalue { i64, ptr } { i64 22, ptr @.d683 }, 1
  %t7 = extractvalue { i64, ptr } { i64 22, ptr @.d683 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = load { i64, ptr }, ptr %l4
  %t9 = extractvalue { i64, ptr } %t8, 1
  %t10 = extractvalue { i64, ptr } %t8, 0
  call void @__olang_sb_put(ptr %s1, ptr %t9, i64 %t10)
  %t11 = load ptr, ptr %s1
  %t12 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t13 = load i64, ptr %t12
  %t14 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t13)
  call void @llvm.memcpy.p0.p0.i64(ptr %t14, ptr %t11, i64 %t13, i1 false)
  %t15 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t17 = load { i64, ptr }, ptr %l5
  %t18 = extractvalue { i64, ptr } %t17, 0
  %t19 = extractvalue { i64, ptr } %t17, 1
  %t20 = mul i64 %t18, 1
  %t21 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t20)
  call void @llvm.memcpy.p0.p0.i64(ptr %t21, ptr %t19, i64 %t20, i1 false)
  %t22 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l6
  %t24 = load i32, ptr %l2
  %t25 = load { i64, ptr }, ptr %l6
  %t26 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t24, { i64, ptr } { i64 2, ptr @.d684 }, { i64, ptr } %t25)
  store %"compiler/msgs:Msg" %t26, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t27 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t27, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperandsDiffer(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 326, ptr %l3
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l4
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l5
  %t3 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t3, ptr %l6
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t4 = load { i64, ptr }, ptr %l4
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 35, ptr @.d685 }, 1
  %t8 = extractvalue { i64, ptr } { i64 35, ptr @.d685 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load { i64, ptr }, ptr %l5
  %t10 = extractvalue { i64, ptr } %t9, 1
  %t11 = extractvalue { i64, ptr } %t9, 0
  call void @__olang_sb_put(ptr %s1, ptr %t10, i64 %t11)
  %t12 = extractvalue { i64, ptr } { i64 5, ptr @.d686 }, 1
  %t13 = extractvalue { i64, ptr } { i64 5, ptr @.d686 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t12, i64 %t13)
  %t14 = load { i64, ptr }, ptr %l6
  %t15 = extractvalue { i64, ptr } %t14, 1
  %t16 = extractvalue { i64, ptr } %t14, 0
  call void @__olang_sb_put(ptr %s1, ptr %t15, i64 %t16)
  %t17 = load ptr, ptr %s1
  %t18 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t19 = load i64, ptr %t18
  %t20 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t17, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  store { i64, ptr } %t22, ptr %l7
  call void @__olang_sb_done(ptr %s1)
  %t23 = load { i64, ptr }, ptr %l7
  %t24 = extractvalue { i64, ptr } %t23, 0
  %t25 = extractvalue { i64, ptr } %t23, 1
  %t26 = mul i64 %t24, 1
  %t27 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t26)
  call void @llvm.memcpy.p0.p0.i64(ptr %t27, ptr %t25, i64 %t26, i1 false)
  %t28 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  store { i64, ptr } %t29, ptr %l8
  %t30 = load i32, ptr %l3
  %t31 = load { i64, ptr }, ptr %l8
  %t32 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 %t30, { i64, ptr } { i64 0, ptr @.d687 }, { i64, ptr } %t31)
  store %"compiler/msgs:Msg" %t32, ptr %l9
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t33 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t33, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperatorCallFails(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 343, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 20, ptr @.d688 }, 1
  %t3 = extractvalue { i64, ptr } { i64 20, ptr @.d688 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 52, ptr @.d689 }, 1
  %t8 = extractvalue { i64, ptr } { i64 52, ptr @.d689 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 3, ptr @.d690 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperatorResult(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 189, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 17, ptr @.d691 }, 1
  %t6 = extractvalue { i64, ptr } { i64 17, ptr @.d691 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 3, ptr @.d692 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eOptionNeedsValue(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 6, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = load { i64, ptr }, ptr %l3
  %t4 = extractvalue { i64, ptr } %t3, 1
  %t5 = extractvalue { i64, ptr } %t3, 0
  call void @__olang_sb_put(ptr %s1, ptr %t4, i64 %t5)
  %t6 = extractvalue { i64, ptr } { i64 25, ptr @.d693 }, 1
  %t7 = extractvalue { i64, ptr } { i64 25, ptr @.d693 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = load { i64, ptr }, ptr %l4
  %t9 = extractvalue { i64, ptr } %t8, 1
  %t10 = extractvalue { i64, ptr } %t8, 0
  call void @__olang_sb_put(ptr %s1, ptr %t9, i64 %t10)
  %t11 = load ptr, ptr %s1
  %t12 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t13 = load i64, ptr %t12
  %t14 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t13)
  call void @llvm.memcpy.p0.p0.i64(ptr %t14, ptr %t11, i64 %t13, i1 false)
  %t15 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t17 = load { i64, ptr }, ptr %l5
  %t18 = extractvalue { i64, ptr } %t17, 0
  %t19 = extractvalue { i64, ptr } %t17, 1
  %t20 = mul i64 %t18, 1
  %t21 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t20)
  call void @llvm.memcpy.p0.p0.i64(ptr %t21, ptr %t19, i64 %t20, i1 false)
  %t22 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l6
  %t24 = load i32, ptr %l2
  %t25 = load { i64, ptr }, ptr %l6
  %t26 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t24, { i64, ptr } { i64 2, ptr @.d694 }, { i64, ptr } %t25)
  store %"compiler/msgs:Msg" %t26, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t27 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t27, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eOptionNotForMode(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 5, ptr %l3
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l4
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l5
  %t3 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t3, ptr %l6
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t4 = load { i64, ptr }, ptr %l4
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 12, ptr @.d695 }, 1
  %t8 = extractvalue { i64, ptr } { i64 12, ptr @.d695 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load { i64, ptr }, ptr %l5
  %t10 = extractvalue { i64, ptr } %t9, 1
  %t11 = extractvalue { i64, ptr } %t9, 0
  call void @__olang_sb_put(ptr %s1, ptr %t10, i64 %t11)
  %t12 = extractvalue { i64, ptr } { i64 9, ptr @.d696 }, 1
  %t13 = extractvalue { i64, ptr } { i64 9, ptr @.d696 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t12, i64 %t13)
  %t14 = load { i64, ptr }, ptr %l6
  %t15 = extractvalue { i64, ptr } %t14, 1
  %t16 = extractvalue { i64, ptr } %t14, 0
  call void @__olang_sb_put(ptr %s1, ptr %t15, i64 %t16)
  %t17 = load ptr, ptr %s1
  %t18 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t19 = load i64, ptr %t18
  %t20 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t17, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  store { i64, ptr } %t22, ptr %l7
  call void @__olang_sb_done(ptr %s1)
  %t23 = load { i64, ptr }, ptr %l7
  %t24 = extractvalue { i64, ptr } %t23, 0
  %t25 = extractvalue { i64, ptr } %t23, 1
  %t26 = mul i64 %t24, 1
  %t27 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t26)
  call void @llvm.memcpy.p0.p0.i64(ptr %t27, ptr %t25, i64 %t26, i1 false)
  %t28 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  store { i64, ptr } %t29, ptr %l8
  %t30 = load i32, ptr %l3
  %t31 = load { i64, ptr }, ptr %l8
  %t32 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 %t30, { i64, ptr } { i64 2, ptr @.d697 }, { i64, ptr } %t31)
  store %"compiler/msgs:Msg" %t32, ptr %l9
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t33 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t33, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eOutputCannotWrite(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 12, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d698 }, { i64, ptr } { i64 15, ptr @.d699 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eOutputIsDir(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 10, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 8, ptr @.d700 }, 1
  %t3 = extractvalue { i64, ptr } { i64 8, ptr @.d700 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 40, ptr @.d701 }, 1
  %t8 = extractvalue { i64, ptr } { i64 40, ptr @.d701 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 3, ptr @.d702 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eOutputNoDir(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 11, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = extractvalue { i64, ptr } { i64 8, ptr @.d703 }, 1
  %t4 = extractvalue { i64, ptr } { i64 8, ptr @.d703 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = load { i64, ptr }, ptr %l3
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 24, ptr @.d704 }, 1
  %t9 = extractvalue { i64, ptr } { i64 24, ptr @.d704 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load { i64, ptr }, ptr %l4
  %t11 = extractvalue { i64, ptr } %t10, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = load ptr, ptr %s1
  %t14 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t15 = load i64, ptr %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t13, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t19 = load { i64, ptr }, ptr %l5
  %t20 = extractvalue { i64, ptr } %t19, 0
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = mul i64 %t20, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t22)
  call void @llvm.memcpy.p0.p0.i64(ptr %t23, ptr %t21, i64 %t22, i1 false)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l6
  %t26 = load i32, ptr %l2
  %t27 = load { i64, ptr }, ptr %l6
  %t28 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t26, { i64, ptr } { i64 3, ptr @.d705 }, { i64, ptr } %t27)
  store %"compiler/msgs:Msg" %t28, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t29, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eOverrideSignature(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 201, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 91, ptr @.d706 }, 1
  %t6 = extractvalue { i64, ptr } { i64 91, ptr @.d706 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 4, ptr @.d707 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eOwnCannotOutlive(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 221, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 4, ptr @.d708 }, { i64, ptr } { i64 65, ptr @.d709 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2ePatternType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 347, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = extractvalue { i64, ptr } { i64 31, ptr @.d710 }, 1
  %t4 = extractvalue { i64, ptr } { i64 31, ptr @.d710 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = load { i64, ptr }, ptr %l3
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 8, ptr @.d711 }, 1
  %t9 = extractvalue { i64, ptr } { i64 8, ptr @.d711 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load { i64, ptr }, ptr %l4
  %t11 = extractvalue { i64, ptr } %t10, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = load ptr, ptr %s1
  %t14 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t15 = load i64, ptr %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t13, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t19 = load { i64, ptr }, ptr %l5
  %t20 = extractvalue { i64, ptr } %t19, 0
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = mul i64 %t20, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t22)
  call void @llvm.memcpy.p0.p0.i64(ptr %t23, ptr %t21, i64 %t22, i1 false)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l6
  %t26 = load i32, ptr %l2
  %t27 = load { i64, ptr }, ptr %l6
  %t28 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t26, { i64, ptr } { i64 4, ptr @.d712 }, { i64, ptr } %t27)
  store %"compiler/msgs:Msg" %t28, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t29, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2ePayloadOutlived(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 403, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 4, ptr @.d713 }, { i64, ptr } { i64 106, ptr @.d714 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2ePreludeConstRedeclared(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 213, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 51, ptr @.d715 }, 1
  %t6 = extractvalue { i64, ptr } { i64 51, ptr @.d715 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 3, ptr @.d716 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eProtocolBothSpellings(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 199, ptr %l4
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l5
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l6
  %t3 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t3, ptr %l7
  %t4 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t4, ptr %l8
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t5 = load { i64, ptr }, ptr %l5
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 10, ptr @.d717 }, 1
  %t9 = extractvalue { i64, ptr } { i64 10, ptr @.d717 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load { i64, ptr }, ptr %l6
  %t11 = extractvalue { i64, ptr } %t10, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = extractvalue { i64, ptr } { i64 39, ptr @.d718 }, 1
  %t14 = extractvalue { i64, ptr } { i64 39, ptr @.d718 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t13, i64 %t14)
  %t15 = load { i64, ptr }, ptr %l7
  %t16 = extractvalue { i64, ptr } %t15, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  call void @__olang_sb_put(ptr %s1, ptr %t16, i64 %t17)
  %t18 = extractvalue { i64, ptr } { i64 5, ptr @.d719 }, 1
  %t19 = extractvalue { i64, ptr } { i64 5, ptr @.d719 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t18, i64 %t19)
  %t20 = load { i64, ptr }, ptr %l8
  %t21 = extractvalue { i64, ptr } %t20, 1
  %t22 = extractvalue { i64, ptr } %t20, 0
  call void @__olang_sb_put(ptr %s1, ptr %t21, i64 %t22)
  %t23 = extractvalue { i64, ptr } { i64 24, ptr @.d720 }, 1
  %t24 = extractvalue { i64, ptr } { i64 24, ptr @.d720 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t23, i64 %t24)
  %t25 = load ptr, ptr %s1
  %t26 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t27 = load i64, ptr %t26
  %t28 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t27)
  call void @llvm.memcpy.p0.p0.i64(ptr %t28, ptr %t25, i64 %t27, i1 false)
  %t29 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  store { i64, ptr } %t30, ptr %l9
  call void @__olang_sb_done(ptr %s1)
  %t31 = load { i64, ptr }, ptr %l9
  %t32 = extractvalue { i64, ptr } %t31, 0
  %t33 = extractvalue { i64, ptr } %t31, 1
  %t34 = mul i64 %t32, 1
  %t35 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t34)
  call void @llvm.memcpy.p0.p0.i64(ptr %t35, ptr %t33, i64 %t34, i1 false)
  %t36 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  store { i64, ptr } %t37, ptr %l10
  %t38 = load i32, ptr %l4
  %t39 = load { i64, ptr }, ptr %l10
  %t40 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, i32 %t38, { i64, ptr } { i64 3, ptr @.d721 }, { i64, ptr } %t39)
  store %"compiler/msgs:Msg" %t40, ptr %l11
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t41 = load %"compiler/msgs:Msg", ptr %l11
  store %"compiler/msgs:Msg" %t41, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eProtocolPrivate(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 200, ptr %l4
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l5
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l6
  %t3 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t3, ptr %l7
  %t4 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t4, ptr %l8
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t5 = load { i64, ptr }, ptr %l5
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 7, ptr @.d722 }, 1
  %t9 = extractvalue { i64, ptr } { i64 7, ptr @.d722 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load { i64, ptr }, ptr %l6
  %t11 = extractvalue { i64, ptr } %t10, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = extractvalue { i64, ptr } { i64 3, ptr @.d723 }, 1
  %t14 = extractvalue { i64, ptr } { i64 3, ptr @.d723 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t13, i64 %t14)
  %t15 = load { i64, ptr }, ptr %l7
  %t16 = extractvalue { i64, ptr } %t15, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  call void @__olang_sb_put(ptr %s1, ptr %t16, i64 %t17)
  %t18 = extractvalue { i64, ptr } { i64 46, ptr @.d724 }, 1
  %t19 = extractvalue { i64, ptr } { i64 46, ptr @.d724 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t18, i64 %t19)
  %t20 = load { i64, ptr }, ptr %l8
  %t21 = extractvalue { i64, ptr } %t20, 1
  %t22 = extractvalue { i64, ptr } %t20, 0
  call void @__olang_sb_put(ptr %s1, ptr %t21, i64 %t22)
  %t23 = extractvalue { i64, ptr } { i64 15, ptr @.d725 }, 1
  %t24 = extractvalue { i64, ptr } { i64 15, ptr @.d725 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t23, i64 %t24)
  %t25 = load ptr, ptr %s1
  %t26 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t27 = load i64, ptr %t26
  %t28 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t27)
  call void @llvm.memcpy.p0.p0.i64(ptr %t28, ptr %t25, i64 %t27, i1 false)
  %t29 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  store { i64, ptr } %t30, ptr %l9
  call void @__olang_sb_done(ptr %s1)
  %t31 = load { i64, ptr }, ptr %l9
  %t32 = extractvalue { i64, ptr } %t31, 0
  %t33 = extractvalue { i64, ptr } %t31, 1
  %t34 = mul i64 %t32, 1
  %t35 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t34)
  call void @llvm.memcpy.p0.p0.i64(ptr %t35, ptr %t33, i64 %t34, i1 false)
  %t36 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  store { i64, ptr } %t37, ptr %l10
  %t38 = load i32, ptr %l4
  %t39 = load { i64, ptr }, ptr %l10
  %t40 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, i32 %t38, { i64, ptr } { i64 3, ptr @.d726 }, { i64, ptr } %t39)
  store %"compiler/msgs:Msg" %t40, ptr %l11
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t41 = load %"compiler/msgs:Msg", ptr %l11
  store %"compiler/msgs:Msg" %t41, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eRangeNotInt(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 415, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 46, ptr @.d727 }, 1
  %t3 = extractvalue { i64, ptr } { i64 46, ptr @.d727 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 3, ptr @.d728 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eRangeStep(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 416, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d729 }, { i64, ptr } { i64 51, ptr @.d730 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyCopyArg(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 238, ptr %l4
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l5
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l6
  %t3 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t3, ptr %l7
  %t4 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t4, ptr %l8
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t5 = extractvalue { i64, ptr } { i64 1, ptr @.d731 }, 1
  %t6 = extractvalue { i64, ptr } { i64 1, ptr @.d731 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load { i64, ptr }, ptr %l5
  %t8 = extractvalue { i64, ptr } %t7, 1
  %t9 = extractvalue { i64, ptr } %t7, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = extractvalue { i64, ptr } { i64 41, ptr @.d732 }, 1
  %t11 = extractvalue { i64, ptr } { i64 41, ptr @.d732 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t10, i64 %t11)
  %t12 = load { i64, ptr }, ptr %l6
  %t13 = extractvalue { i64, ptr } %t12, 1
  %t14 = extractvalue { i64, ptr } %t12, 0
  call void @__olang_sb_put(ptr %s1, ptr %t13, i64 %t14)
  %t15 = extractvalue { i64, ptr } { i64 12, ptr @.d733 }, 1
  %t16 = extractvalue { i64, ptr } { i64 12, ptr @.d733 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t15, i64 %t16)
  %t17 = load { i64, ptr }, ptr %l7
  %t18 = extractvalue { i64, ptr } %t17, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  call void @__olang_sb_put(ptr %s1, ptr %t18, i64 %t19)
  %t20 = extractvalue { i64, ptr } { i64 49, ptr @.d734 }, 1
  %t21 = extractvalue { i64, ptr } { i64 49, ptr @.d734 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t20, i64 %t21)
  %t22 = load { i64, ptr }, ptr %l8
  %t23 = extractvalue { i64, ptr } %t22, 1
  %t24 = extractvalue { i64, ptr } %t22, 0
  call void @__olang_sb_put(ptr %s1, ptr %t23, i64 %t24)
  %t25 = load ptr, ptr %s1
  %t26 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t27 = load i64, ptr %t26
  %t28 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t27)
  call void @llvm.memcpy.p0.p0.i64(ptr %t28, ptr %t25, i64 %t27, i1 false)
  %t29 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  store { i64, ptr } %t30, ptr %l9
  call void @__olang_sb_done(ptr %s1)
  %t31 = load { i64, ptr }, ptr %l9
  %t32 = extractvalue { i64, ptr } %t31, 0
  %t33 = extractvalue { i64, ptr } %t31, 1
  %t34 = mul i64 %t32, 1
  %t35 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t34)
  call void @llvm.memcpy.p0.p0.i64(ptr %t35, ptr %t33, i64 %t34, i1 false)
  %t36 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  store { i64, ptr } %t37, ptr %l10
  %t38 = load i32, ptr %l4
  %t39 = load { i64, ptr }, ptr %l10
  %t40 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, i32 %t38, { i64, ptr } { i64 4, ptr @.d735 }, { i64, ptr } %t39)
  store %"compiler/msgs:Msg" %t40, ptr %l11
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t41 = load %"compiler/msgs:Msg", ptr %l11
  store %"compiler/msgs:Msg" %t41, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyCopyDecl(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 233, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = extractvalue { i64, ptr } { i64 24, ptr @.d736 }, 1
  %t4 = extractvalue { i64, ptr } { i64 24, ptr @.d736 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = load { i64, ptr }, ptr %l3
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 134, ptr @.d737 }, 1
  %t9 = extractvalue { i64, ptr } { i64 134, ptr @.d737 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load { i64, ptr }, ptr %l4
  %t11 = extractvalue { i64, ptr } %t10, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = load ptr, ptr %s1
  %t14 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t15 = load i64, ptr %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t13, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t19 = load { i64, ptr }, ptr %l5
  %t20 = extractvalue { i64, ptr } %t19, 0
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = mul i64 %t20, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t22)
  call void @llvm.memcpy.p0.p0.i64(ptr %t23, ptr %t21, i64 %t22, i1 false)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l6
  %t26 = load i32, ptr %l2
  %t27 = load { i64, ptr }, ptr %l6
  %t28 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t26, { i64, ptr } { i64 4, ptr @.d738 }, { i64, ptr } %t27)
  store %"compiler/msgs:Msg" %t28, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t29, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyCopyGlobal(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 234, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = extractvalue { i64, ptr } { i64 46, ptr @.d739 }, 1
  %t4 = extractvalue { i64, ptr } { i64 46, ptr @.d739 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = load { i64, ptr }, ptr %l3
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 32, ptr @.d740 }, 1
  %t9 = extractvalue { i64, ptr } { i64 32, ptr @.d740 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load { i64, ptr }, ptr %l4
  %t11 = extractvalue { i64, ptr } %t10, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = extractvalue { i64, ptr } { i64 19, ptr @.d741 }, 1
  %t14 = extractvalue { i64, ptr } { i64 19, ptr @.d741 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t13, i64 %t14)
  %t15 = load ptr, ptr %s1
  %t16 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t17 = load i64, ptr %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t15, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t21 = load { i64, ptr }, ptr %l5
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l6
  %t28 = load i32, ptr %l2
  %t29 = load { i64, ptr }, ptr %l6
  %t30 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t28, { i64, ptr } { i64 4, ptr @.d742 }, { i64, ptr } %t29)
  store %"compiler/msgs:Msg" %t30, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t31 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t31, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyCopyLent(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 239, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 86, ptr @.d743 }, 1
  %t3 = extractvalue { i64, ptr } { i64 86, ptr @.d743 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 4, ptr @.d744 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyCopyReturned(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 236, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = extractvalue { i64, ptr } { i64 22, ptr @.d745 }, 1
  %t4 = extractvalue { i64, ptr } { i64 22, ptr @.d745 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = load { i64, ptr }, ptr %l3
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 70, ptr @.d746 }, 1
  %t9 = extractvalue { i64, ptr } { i64 70, ptr @.d746 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load { i64, ptr }, ptr %l4
  %t11 = extractvalue { i64, ptr } %t10, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = extractvalue { i64, ptr } { i64 26, ptr @.d747 }, 1
  %t14 = extractvalue { i64, ptr } { i64 26, ptr @.d747 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t13, i64 %t14)
  %t15 = load ptr, ptr %s1
  %t16 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t17 = load i64, ptr %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t15, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t21 = load { i64, ptr }, ptr %l5
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l6
  %t28 = load i32, ptr %l2
  %t29 = load { i64, ptr }, ptr %l6
  %t30 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t28, { i64, ptr } { i64 4, ptr @.d748 }, { i64, ptr } %t29)
  store %"compiler/msgs:Msg" %t30, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t31 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t31, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyCopyStored(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 235, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = extractvalue { i64, ptr } { i64 22, ptr @.d749 }, 1
  %t4 = extractvalue { i64, ptr } { i64 22, ptr @.d749 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = load { i64, ptr }, ptr %l3
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 71, ptr @.d750 }, 1
  %t9 = extractvalue { i64, ptr } { i64 71, ptr @.d750 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load { i64, ptr }, ptr %l4
  %t11 = extractvalue { i64, ptr } %t10, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = load ptr, ptr %s1
  %t14 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t15 = load i64, ptr %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t13, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t19 = load { i64, ptr }, ptr %l5
  %t20 = extractvalue { i64, ptr } %t19, 0
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = mul i64 %t20, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t22)
  call void @llvm.memcpy.p0.p0.i64(ptr %t23, ptr %t21, i64 %t22, i1 false)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l6
  %t26 = load i32, ptr %l2
  %t27 = load { i64, ptr }, ptr %l6
  %t28 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t26, { i64, ptr } { i64 4, ptr @.d751 }, { i64, ptr } %t27)
  store %"compiler/msgs:Msg" %t28, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t29, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyCopyWrite(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 240, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 4, ptr @.d752 }, { i64, ptr } { i64 117, ptr @.d753 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyFuncValue(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 242, ptr %l3
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l4
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l5
  %t3 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t3, ptr %l6
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t4 = load { i64, ptr }, ptr %l4
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 49, ptr @.d754 }, 1
  %t8 = extractvalue { i64, ptr } { i64 49, ptr @.d754 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load { i64, ptr }, ptr %l5
  %t10 = extractvalue { i64, ptr } %t9, 1
  %t11 = extractvalue { i64, ptr } %t9, 0
  call void @__olang_sb_put(ptr %s1, ptr %t10, i64 %t11)
  %t12 = extractvalue { i64, ptr } { i64 110, ptr @.d755 }, 1
  %t13 = extractvalue { i64, ptr } { i64 110, ptr @.d755 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t12, i64 %t13)
  %t14 = load { i64, ptr }, ptr %l6
  %t15 = extractvalue { i64, ptr } %t14, 1
  %t16 = extractvalue { i64, ptr } %t14, 0
  call void @__olang_sb_put(ptr %s1, ptr %t15, i64 %t16)
  %t17 = load ptr, ptr %s1
  %t18 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t19 = load i64, ptr %t18
  %t20 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t17, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  store { i64, ptr } %t22, ptr %l7
  call void @__olang_sb_done(ptr %s1)
  %t23 = load { i64, ptr }, ptr %l7
  %t24 = extractvalue { i64, ptr } %t23, 0
  %t25 = extractvalue { i64, ptr } %t23, 1
  %t26 = mul i64 %t24, 1
  %t27 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t26)
  call void @llvm.memcpy.p0.p0.i64(ptr %t27, ptr %t25, i64 %t26, i1 false)
  %t28 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  store { i64, ptr } %t29, ptr %l8
  %t30 = load i32, ptr %l3
  %t31 = load { i64, ptr }, ptr %l8
  %t32 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 %t30, { i64, ptr } { i64 4, ptr @.d756 }, { i64, ptr } %t31)
  store %"compiler/msgs:Msg" %t32, ptr %l9
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t33 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t33, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyRefKept(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 237, ptr %l3
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l4
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l5
  %t3 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t3, ptr %l6
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t4 = extractvalue { i64, ptr } { i64 1, ptr @.d757 }, 1
  %t5 = extractvalue { i64, ptr } { i64 1, ptr @.d757 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t4, i64 %t5)
  %t6 = load { i64, ptr }, ptr %l4
  %t7 = extractvalue { i64, ptr } %t6, 1
  %t8 = extractvalue { i64, ptr } %t6, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = extractvalue { i64, ptr } { i64 28, ptr @.d758 }, 1
  %t10 = extractvalue { i64, ptr } { i64 28, ptr @.d758 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t9, i64 %t10)
  %t11 = load { i64, ptr }, ptr %l5
  %t12 = extractvalue { i64, ptr } %t11, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  call void @__olang_sb_put(ptr %s1, ptr %t12, i64 %t13)
  %t14 = extractvalue { i64, ptr } { i64 44, ptr @.d759 }, 1
  %t15 = extractvalue { i64, ptr } { i64 44, ptr @.d759 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t14, i64 %t15)
  %t16 = load { i64, ptr }, ptr %l6
  %t17 = extractvalue { i64, ptr } %t16, 1
  %t18 = extractvalue { i64, ptr } %t16, 0
  call void @__olang_sb_put(ptr %s1, ptr %t17, i64 %t18)
  %t19 = extractvalue { i64, ptr } { i64 35, ptr @.d760 }, 1
  %t20 = extractvalue { i64, ptr } { i64 35, ptr @.d760 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t19, i64 %t20)
  %t21 = load ptr, ptr %s1
  %t22 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t23 = load i64, ptr %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t23)
  call void @llvm.memcpy.p0.p0.i64(ptr %t24, ptr %t21, i64 %t23, i1 false)
  %t25 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  store { i64, ptr } %t26, ptr %l7
  call void @__olang_sb_done(ptr %s1)
  %t27 = load { i64, ptr }, ptr %l7
  %t28 = extractvalue { i64, ptr } %t27, 0
  %t29 = extractvalue { i64, ptr } %t27, 1
  %t30 = mul i64 %t28, 1
  %t31 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t30)
  call void @llvm.memcpy.p0.p0.i64(ptr %t31, ptr %t29, i64 %t30, i1 false)
  %t32 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  store { i64, ptr } %t33, ptr %l8
  %t34 = load i32, ptr %l3
  %t35 = load { i64, ptr }, ptr %l8
  %t36 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 %t34, { i64, ptr } { i64 4, ptr @.d761 }, { i64, ptr } %t35)
  store %"compiler/msgs:Msg" %t36, ptr %l9
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t37 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t37, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyRefWrite(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 290, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 4, ptr @.d762 }, { i64, ptr } { i64 73, ptr @.d763 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyToBuiltResult(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 231, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 90, ptr @.d764 }, 1
  %t3 = extractvalue { i64, ptr } { i64 90, ptr @.d764 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 1, ptr @.d765 }, 1
  %t8 = extractvalue { i64, ptr } { i64 1, ptr @.d765 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 9, ptr @.d766 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyToBuiltResultNo(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 232, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 9, ptr @.d767 }, { i64, ptr } { i64 151, ptr @.d768 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyToWritable(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 230, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 4, ptr @.d769 }, { i64, ptr } { i64 85, ptr @.d770 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReexportCycle(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 95, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 13, ptr @.d771 }, 1
  %t3 = extractvalue { i64, ptr } { i64 13, ptr @.d771 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 26, ptr @.d772 }, 1
  %t8 = extractvalue { i64, ptr } { i64 26, ptr @.d772 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 3, ptr @.d773 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReferenceNarrowed(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 264, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d774 }, { i64, ptr } { i64 98, ptr @.d775 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReferenceNarrowedLocal(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 265, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 29, ptr @.d776 }, 1
  %t3 = extractvalue { i64, ptr } { i64 29, ptr @.d776 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 62, ptr @.d777 }, 1
  %t8 = extractvalue { i64, ptr } { i64 62, ptr @.d777 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 3, ptr @.d778 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnBorrowAsBuilt(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 444, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d779 }, { i64, ptr } { i64 86, ptr @.d780 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnInCtor(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 448, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d781 }, { i64, ptr } { i64 77, ptr @.d782 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnInNoreturn(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 450, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d783 }, { i64, ptr } { i64 89, ptr @.d784 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnInTest(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 449, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d785 }, { i64, ptr } { i64 56, ptr @.d786 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnNeedsValue(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 456, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 22, ptr @.d787 }, 1
  %t3 = extractvalue { i64, ptr } { i64 22, ptr @.d787 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 27, ptr @.d788 }, 1
  %t8 = extractvalue { i64, ptr } { i64 27, ptr @.d788 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 2, ptr @.d789 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnOwnStorage(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 445, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d790 }, { i64, ptr } { i64 98, ptr @.d791 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnValueInVoid(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 455, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 2, ptr @.d792 }, { i64, ptr } { i64 30, ptr @.d793 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eScopeArgProgram(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 247, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 100, ptr @.d794 }, 1
  %t6 = extractvalue { i64, ptr } { i64 100, ptr @.d794 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 8, ptr @.d795 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eScopeArgsDisagree(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 258, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 4, ptr @.d796 }, { i64, ptr } { i64 79, ptr @.d797 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eScopeDecl(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 172, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 2, ptr @.d798 }, { i64, ptr } { i64 78, ptr @.d799 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eScopeMayNotOutlive(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 220, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d800 }, { i64, ptr } { i64 68, ptr @.d801 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eScopeObligationUnmet(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 263, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 4, ptr @.d802 }, { i64, ptr } { i64 112, ptr @.d803 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSetatResult(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 190, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d804 }, { i64, ptr } { i64 21, ptr @.d805 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSetatUndeclared(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 356, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 48, ptr @.d806 }, 1
  %t6 = extractvalue { i64, ptr } { i64 48, ptr @.d806 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 3, ptr @.d807 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eShadowsBuildConst(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 212, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 42, ptr @.d808 }, 1
  %t6 = extractvalue { i64, ptr } { i64 42, ptr @.d808 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 3, ptr @.d809 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eShadowsFunction(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 211, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 83, ptr @.d810 }, 1
  %t6 = extractvalue { i64, ptr } { i64 83, ptr @.d810 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 3, ptr @.d811 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eShadowsGlobal(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 210, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 66, ptr @.d812 }, 1
  %t6 = extractvalue { i64, ptr } { i64 66, ptr @.d812 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 3, ptr @.d813 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eShadowsType(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 214, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 34, ptr @.d814 }, 1
  %t6 = extractvalue { i64, ptr } { i64 34, ptr @.d814 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 3, ptr @.d815 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eShiftUnadapted(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 219, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 8, ptr @.d816 }, { i64, ptr } { i64 116, ptr @.d817 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSliceSplitValue(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 260, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 4, ptr @.d818 }, { i64, ptr } { i64 143, ptr @.d819 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnArgHoldsShort(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 482, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 2, ptr @.d820 }, { i64, ptr } { i64 108, ptr @.d821 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnArgTooShort(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 481, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 2, ptr @.d822 }, { i64, ptr } { i64 93, ptr @.d823 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnAtElement(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 467, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 8, ptr @.d824 }, { i64, ptr } { i64 173, ptr @.d825 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnCaptureTooShort(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 483, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 8, ptr @.d826 }, { i64, ptr } { i64 93, ptr @.d827 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnFallible(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 469, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 2, ptr @.d828 }, { i64, ptr } { i64 89, ptr @.d829 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnFuncTooShort(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 484, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 8, ptr @.d830 }, { i64, ptr } { i64 93, ptr @.d831 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnInDefer(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 465, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 9, ptr @.d832 }, { i64, ptr } { i64 66, ptr @.d833 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnLambdaParams(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 464, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 4, ptr @.d834 }, { i64, ptr } { i64 64, ptr @.d835 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnNotCall(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 468, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 2, ptr @.d836 }, { i64, ptr } { i64 20, ptr @.d837 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnOutsideJoin(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 466, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 2, ptr @.d838 }, { i64, ptr } { i64 66, ptr @.d839 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnResultTooShort(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 488, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d840 }, { i64, ptr } { i64 81, ptr @.d841 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnResultType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 486, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = extractvalue { i64, ptr } { i64 43, ptr @.d842 }, 1
  %t4 = extractvalue { i64, ptr } { i64 43, ptr @.d842 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = load { i64, ptr }, ptr %l3
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 8, ptr @.d843 }, 1
  %t9 = extractvalue { i64, ptr } { i64 8, ptr @.d843 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load { i64, ptr }, ptr %l4
  %t11 = extractvalue { i64, ptr } %t10, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = extractvalue { i64, ptr } { i64 25, ptr @.d844 }, 1
  %t14 = extractvalue { i64, ptr } { i64 25, ptr @.d844 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t13, i64 %t14)
  %t15 = load ptr, ptr %s1
  %t16 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t17 = load i64, ptr %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t15, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t21 = load { i64, ptr }, ptr %l5
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l6
  %t28 = load i32, ptr %l2
  %t29 = load { i64, ptr }, ptr %l6
  %t30 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t28, { i64, ptr } { i64 3, ptr @.d845 }, { i64, ptr } %t29)
  store %"compiler/msgs:Msg" %t30, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t31 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t31, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnResultVoid(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 485, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d846 }, { i64, ptr } { i64 51, ptr @.d847 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnTryInfallible(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 470, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 2, ptr @.d848 }, { i64, ptr } { i64 38, ptr @.d849 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpreadCount(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 256, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d850 }, { i64, ptr } { i64 107, ptr @.d851 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eStoreIntoUnknownScope(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 249, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d852 }, { i64, ptr } { i64 146, ptr @.d853 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eStoredRefOutlived(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 399, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d854 }, { i64, ptr } { i64 101, ptr @.d855 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eStrOfNothing(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 314, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 4, ptr @.d856 }, { i64, ptr } { i64 54, ptr @.d857 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eStrReceiverWritable(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 294, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 10, ptr @.d858 }, { i64, ptr } { i64 98, ptr @.d859 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eStrShape(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 197, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 4, ptr @.d860 }, { i64, ptr } { i64 18, ptr @.d861 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eStrStoresInReceiver(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 293, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 9, ptr @.d862 }, { i64, ptr } { i64 148, ptr @.d863 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTagUnknownScope(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 250, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = extractvalue { i64, ptr } { i64 6, ptr @.d864 }, 1
  %t4 = extractvalue { i64, ptr } { i64 6, ptr @.d864 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = load { i64, ptr }, ptr %l3
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 81, ptr @.d865 }, 1
  %t9 = extractvalue { i64, ptr } { i64 81, ptr @.d865 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load { i64, ptr }, ptr %l4
  %t11 = extractvalue { i64, ptr } %t10, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = extractvalue { i64, ptr } { i64 32, ptr @.d866 }, 1
  %t14 = extractvalue { i64, ptr } { i64 32, ptr @.d866 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t13, i64 %t14)
  %t15 = load ptr, ptr %s1
  %t16 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t17 = load i64, ptr %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t15, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t21 = load { i64, ptr }, ptr %l5
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l6
  %t28 = load i32, ptr %l2
  %t29 = load { i64, ptr }, ptr %l6
  %t30 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t28, { i64, ptr } { i64 3, ptr @.d867 }, { i64, ptr } %t29)
  store %"compiler/msgs:Msg" %t30, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t31 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t31, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTakesNoArgs(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 389, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 19, ptr @.d868 }, 1
  %t6 = extractvalue { i64, ptr } { i64 19, ptr @.d868 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 3, ptr @.d869 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetForeignMode(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 20, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = load { i64, ptr }, ptr %l3
  %t4 = extractvalue { i64, ptr } %t3, 1
  %t5 = extractvalue { i64, ptr } %t3, 0
  call void @__olang_sb_put(ptr %s1, ptr %t4, i64 %t5)
  %t6 = extractvalue { i64, ptr } { i64 47, ptr @.d870 }, 1
  %t7 = extractvalue { i64, ptr } { i64 47, ptr @.d870 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = load { i64, ptr }, ptr %l4
  %t9 = extractvalue { i64, ptr } %t8, 1
  %t10 = extractvalue { i64, ptr } %t8, 0
  call void @__olang_sb_put(ptr %s1, ptr %t9, i64 %t10)
  %t11 = extractvalue { i64, ptr } { i64 64, ptr @.d871 }, 1
  %t12 = extractvalue { i64, ptr } { i64 64, ptr @.d871 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = load ptr, ptr %s1
  %t14 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t15 = load i64, ptr %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t13, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t19 = load { i64, ptr }, ptr %l5
  %t20 = extractvalue { i64, ptr } %t19, 0
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = mul i64 %t20, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t22)
  call void @llvm.memcpy.p0.p0.i64(ptr %t23, ptr %t21, i64 %t22, i1 false)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l6
  %t26 = load i32, ptr %l2
  %t27 = load { i64, ptr }, ptr %l6
  %t28 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t26, { i64, ptr } { i64 4, ptr @.d872 }, { i64, ptr } %t27)
  store %"compiler/msgs:Msg" %t28, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t29, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetNativeForeign(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 19, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 9, ptr @.d873 }, 1
  %t3 = extractvalue { i64, ptr } { i64 9, ptr @.d873 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 102, ptr @.d874 }, 1
  %t8 = extractvalue { i64, ptr } { i64 102, ptr @.d874 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 3, ptr @.d875 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetNoBackend(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 21, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 29, ptr @.d876 }, 1
  %t3 = extractvalue { i64, ptr } { i64 29, ptr @.d876 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 85, ptr @.d877 }, 1
  %t8 = extractvalue { i64, ptr } { i64 85, ptr @.d877 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 4, ptr @.d878 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetNoClang(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 22, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 84, ptr @.d879 }, 1
  %t3 = extractvalue { i64, ptr } { i64 84, ptr @.d879 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 4, ptr @.d880 }, 1
  %t8 = extractvalue { i64, ptr } { i64 4, ptr @.d880 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 3, ptr @.d881 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetUnknown(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 17, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 16, ptr @.d882 }, 1
  %t3 = extractvalue { i64, ptr } { i64 16, ptr @.d882 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 187, ptr @.d883 }, 1
  %t8 = extractvalue { i64, ptr } { i64 187, ptr @.d883 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 3, ptr @.d884 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetUnsupported(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 18, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 26, ptr @.d885 }, 1
  %t3 = extractvalue { i64, ptr } { i64 26, ptr @.d885 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 65, ptr @.d886 }, 1
  %t8 = extractvalue { i64, ptr } { i64 65, ptr @.d886 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 3, ptr @.d887 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskClauseError(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 473, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d888 }, { i64, ptr } { i64 106, ptr @.d889 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskClauseLoopJump(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 472, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 81, ptr @.d890 }, 1
  %t6 = extractvalue { i64, ptr } { i64 81, ptr @.d890 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 3, ptr @.d891 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskClauseNeedsDefault(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 474, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d892 }, { i64, ptr } { i64 107, ptr @.d893 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskClauseReturns(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 471, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d894 }, { i64, ptr } { i64 82, ptr @.d895 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskDefaultExisting(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 476, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d896 }, { i64, ptr } { i64 118, ptr @.d897 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskDefaultInStatement(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 475, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d898 }, { i64, ptr } { i64 70, ptr @.d899 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i1
  %l14 = alloca i1
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i8
  %l18 = alloca ptr
  %l19 = alloca i8
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store ptr %l1, ptr %l7
  %t3 = load ptr, ptr %l7
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t3, i8 39)
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t4 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t4, ptr %l8
  %t5 = load { i64, ptr }, ptr %l8
  store { i64, ptr } %t5, ptr %l2
  store i64 0, ptr %l3
  %t6 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t6, ptr %l9
  %t7 = load { i64, ptr }, ptr %l9
  %t8 = extractvalue { i64, ptr } %t7, 0
  store i64 %t8, ptr %l10
  %t9 = load i64, ptr %l10
  store i64 %t9, ptr %l4
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t10 = load i64, ptr %l3
  store i64 %t10, ptr %l11
  %t11 = load i64, ptr %l4
  store i64 %t11, ptr %l12
  %t12 = load i64, ptr %l11
  %t13 = load i64, ptr %l12
  %t14 = icmp slt i64 %t12, %t13
  store i1 %t14, ptr %l13
  %t15 = load i1, ptr %l13
  %t16 = xor i1 %t15, true
  store i1 %t16, ptr %l14
  %t17 = load i1, ptr %l14
  br i1 %t17, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb5:
  br label %bb6
bb6:
  %t18 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t18, ptr %l15
  %t19 = load i64, ptr %l3
  store i64 %t19, ptr %l16
  %t20 = load i64, ptr %l16
  %t21 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t22 = load ptr, ptr %t21
  %t23 = getelementptr i8, ptr %t22, i64 %t20
  %t24 = load i8, ptr %t23
  store i8 %t24, ptr %l17
  %t25 = load i8, ptr %l17
  store i8 %t25, ptr %l5
  store ptr %l1, ptr %l18
  %t26 = load i8, ptr %l5
  store i8 %t26, ptr %l19
  %t27 = load i8, ptr %l19
  %t28 = call { i64, ptr } @compiler_2fmsgs_2eEsc(ptr %s2, i8 %t27)
  store { i64, ptr } %t28, ptr %l20
  br label %bb7
bb7:
  %t29 = load { i64, ptr }, ptr %l20
  %t30 = extractvalue { i64, ptr } %t29, 0
  %t31 = extractvalue { i64, ptr } %t29, 1
  %t32 = mul i64 %t30, 1
  %t33 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t32)
  call void @llvm.memcpy.p0.p0.i64(ptr %t33, ptr %t31, i64 %t32, i1 false)
  %t34 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t33, 1
  store { i64, ptr } %t35, ptr %l21
  %t36 = load ptr, ptr %l18
  %t37 = load { i64, ptr }, ptr %l21
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t36, { i64, ptr } %t37)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t38 = load i64, ptr %l3
  store i64 %t38, ptr %l22
  %t39 = load i64, ptr %l22
  %t40 = add i64 %t39, 1
  store i64 %t40, ptr %l23
  %t41 = load i64, ptr %l23
  store i64 %t41, ptr %l3
  call void @__olang_scope_close(ptr %s3)
  br label %bb3
bb10:
  call void @__olang_scope_close(ptr %s1)
  store ptr %l1, ptr %l24
  %t42 = load ptr, ptr %l24
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t42, i8 39)
  br label %bb11
bb11:
  store ptr %l1, ptr %l25
  %t43 = load ptr, ptr %l25
  %t44 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %t43)
  store { i64, ptr } %t44, ptr %l26
  br label %bb12
bb12:
  %t45 = load { i64, ptr }, ptr %l26
  store { i64, ptr } %t45, ptr %l27
  %t46 = load { i64, ptr }, ptr %l27
  %t47 = extractvalue { i64, ptr } %t46, 0
  store i64 %t47, ptr %l28
  %t48 = load i64, ptr %l28
  %t49 = mul i64 %t48, 1
  %t50 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t49)
  %t51 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  store { i64, ptr } %t52, ptr %l29
  %t53 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t54 = load ptr, ptr %t53
  %t55 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t56 = load ptr, ptr %t55
  %t57 = load i64, ptr %l28
  %t58 = mul i64 %t57, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t54, ptr %t56, i64 %t58, i1 false)
  %t59 = load { i64, ptr }, ptr %l29
  store { i64, ptr } %t59, ptr %l27
  call void @__olang_scope_close(ptr %s0)
  %t60 = load { i64, ptr }, ptr %l27
  store { i64, ptr } %t60, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTrailingComma(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 70, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 15, ptr @.d900 }, 1
  %t3 = extractvalue { i64, ptr } { i64 15, ptr @.d900 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 30, ptr @.d901 }, 1
  %t8 = extractvalue { i64, ptr } { i64 30, ptr @.d901 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 4, ptr @.d902 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTraitErrsUnwritten(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 108, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d903 }, { i64, ptr } { i64 83, ptr @.d904 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTraitNotAType(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 164, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 72, ptr @.d905 }, 1
  %t6 = extractvalue { i64, ptr } { i64 72, ptr @.d905 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 3, ptr @.d906 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTryErrorNotDeclared(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 364, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 87, ptr @.d907 }, 1
  %t6 = extractvalue { i64, ptr } { i64 87, ptr @.d907 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 2, ptr @.d908 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTryIndexNeedsLen(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 352, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 39, ptr @.d909 }, 1
  %t3 = extractvalue { i64, ptr } { i64 39, ptr @.d909 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 30, ptr @.d910 }, 1
  %t8 = extractvalue { i64, ptr } { i64 30, ptr @.d910 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 4, ptr @.d911 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTryMultiIndexNeedsTryat(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 187, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = extractvalue { i64, ptr } { i64 35, ptr @.d912 }, 1
  %t4 = extractvalue { i64, ptr } { i64 35, ptr @.d912 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = load { i64, ptr }, ptr %l3
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 12, ptr @.d913 }, 1
  %t9 = extractvalue { i64, ptr } { i64 12, ptr @.d913 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load { i64, ptr }, ptr %l4
  %t11 = extractvalue { i64, ptr } %t10, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = extractvalue { i64, ptr } { i64 47, ptr @.d914 }, 1
  %t14 = extractvalue { i64, ptr } { i64 47, ptr @.d914 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t13, i64 %t14)
  %t15 = load ptr, ptr %s1
  %t16 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t17 = load i64, ptr %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t15, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t21 = load { i64, ptr }, ptr %l5
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l6
  %t28 = load i32, ptr %l2
  %t29 = load { i64, ptr }, ptr %l6
  %t30 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t28, { i64, ptr } { i64 4, ptr @.d915 }, { i64, ptr } %t29)
  store %"compiler/msgs:Msg" %t30, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t31 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t31, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTryNothingFails(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 380, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 42, ptr @.d916 }, 1
  %t3 = extractvalue { i64, ptr } { i64 42, ptr @.d916 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 1, ptr @.d917 }, 1
  %t8 = extractvalue { i64, ptr } { i64 1, ptr @.d917 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 2, ptr @.d918 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTryNowhereToGo(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 363, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d919 }, { i64, ptr } { i64 65, ptr @.d920 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTryOnlyChecks(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 382, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 4, ptr @.d921 }, { i64, ptr } { i64 59, ptr @.d922 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTrySetatNeedsLen(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 411, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 43, ptr @.d923 }, 1
  %t3 = extractvalue { i64, ptr } { i64 43, ptr @.d923 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 33, ptr @.d924 }, 1
  %t8 = extractvalue { i64, ptr } { i64 33, ptr @.d924 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 4, ptr @.d925 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTrySliceNeedsLen(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 353, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 43, ptr @.d926 }, 1
  %t3 = extractvalue { i64, ptr } { i64 43, ptr @.d926 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 33, ptr @.d927 }, 1
  %t8 = extractvalue { i64, ptr } { i64 33, ptr @.d927 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 4, ptr @.d928 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTupleNotAValue(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 320, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d929 }, { i64, ptr } { i64 111, ptr @.d930 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgCount(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 130, ptr %l3
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l4
  %t2 = load i64, ptr %l1
  store i64 %t2, ptr %l5
  %t3 = load i64, ptr %l2
  store i64 %t3, ptr %l6
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t4 = extractvalue { i64, ptr } { i64 19, ptr @.d931 }, 1
  %t5 = extractvalue { i64, ptr } { i64 19, ptr @.d931 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t4, i64 %t5)
  %t6 = load { i64, ptr }, ptr %l4
  %t7 = extractvalue { i64, ptr } %t6, 1
  %t8 = extractvalue { i64, ptr } %t6, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = extractvalue { i64, ptr } { i64 11, ptr @.d932 }, 1
  %t10 = extractvalue { i64, ptr } { i64 11, ptr @.d932 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t9, i64 %t10)
  %t11 = load i64, ptr %l5
  %t12 = call ptr @__olang_sb_room(ptr %s1, i64 24)
  %t13 = call i64 @__olang_fmt_i64(ptr %t12, i64 %t11)
  call void @__olang_sb_add(ptr %s1, i64 %t13)
  %t14 = extractvalue { i64, ptr } { i64 8, ptr @.d933 }, 1
  %t15 = extractvalue { i64, ptr } { i64 8, ptr @.d933 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t14, i64 %t15)
  %t16 = load i64, ptr %l6
  %t17 = call ptr @__olang_sb_room(ptr %s1, i64 24)
  %t18 = call i64 @__olang_fmt_i64(ptr %t17, i64 %t16)
  call void @__olang_sb_add(ptr %s1, i64 %t18)
  %t19 = load ptr, ptr %s1
  %t20 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t21 = load i64, ptr %t20
  %t22 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t19, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  store { i64, ptr } %t24, ptr %l7
  call void @__olang_sb_done(ptr %s1)
  %t25 = load { i64, ptr }, ptr %l7
  %t26 = extractvalue { i64, ptr } %t25, 0
  %t27 = extractvalue { i64, ptr } %t25, 1
  %t28 = mul i64 %t26, 1
  %t29 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t28)
  call void @llvm.memcpy.p0.p0.i64(ptr %t29, ptr %t27, i64 %t28, i1 false)
  %t30 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  store { i64, ptr } %t31, ptr %l8
  %t32 = load i32, ptr %l3
  %t33 = load { i64, ptr }, ptr %l8
  %t34 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t32, { i64, ptr } { i64 2, ptr @.d934 }, { i64, ptr } %t33)
  store %"compiler/msgs:Msg" %t34, ptr %l9
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t35 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t35, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgNamedScope(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 160, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d935 }, { i64, ptr } { i64 101, ptr @.d936 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgsNotInferable(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 268, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 22, ptr @.d937 }, 1
  %t3 = extractvalue { i64, ptr } { i64 22, ptr @.d937 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 40, ptr @.d938 }, 1
  %t8 = extractvalue { i64, ptr } { i64 40, ptr @.d938 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 2, ptr @.d939 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgsOnNonGeneric(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 131, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 46, ptr @.d940 }, 1
  %t6 = extractvalue { i64, ptr } { i64 46, ptr @.d940 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 2, ptr @.d941 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeHoldsItself(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 127, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 64, ptr @.d942 }, 1
  %t6 = extractvalue { i64, ptr } { i64 64, ptr @.d942 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 3, ptr @.d943 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeMatchGuard(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 434, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 4, ptr @.d944 }, { i64, ptr } { i64 100, ptr @.d945 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeMatchUncovered(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 435, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 15, ptr @.d946 }, 1
  %t3 = extractvalue { i64, ptr } { i64 15, ptr @.d946 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 65, ptr @.d947 }, 1
  %t8 = extractvalue { i64, ptr } { i64 65, ptr @.d947 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 3, ptr @.d948 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeMismatch(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 226, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = extractvalue { i64, ptr } { i64 9, ptr @.d949 }, 1
  %t4 = extractvalue { i64, ptr } { i64 9, ptr @.d949 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = load { i64, ptr }, ptr %l3
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 8, ptr @.d950 }, 1
  %t9 = extractvalue { i64, ptr } { i64 8, ptr @.d950 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load { i64, ptr }, ptr %l4
  %t11 = extractvalue { i64, ptr } %t10, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = load ptr, ptr %s1
  %t14 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t15 = load i64, ptr %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t13, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t19 = load { i64, ptr }, ptr %l5
  %t20 = extractvalue { i64, ptr } %t19, 0
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = mul i64 %t20, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t22)
  call void @llvm.memcpy.p0.p0.i64(ptr %t23, ptr %t21, i64 %t22, i1 false)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l6
  %t26 = load i32, ptr %l2
  %t27 = load { i64, ptr }, ptr %l6
  %t28 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t26, { i64, ptr } { i64 3, ptr @.d951 }, { i64, ptr } %t27)
  store %"compiler/msgs:Msg" %t28, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t29, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeNameInUse(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 110, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 5, ptr @.d952 }, 1
  %t3 = extractvalue { i64, ptr } { i64 5, ptr @.d952 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 35, ptr @.d953 }, 1
  %t8 = extractvalue { i64, ptr } { i64 35, ptr @.d953 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 2, ptr @.d954 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeNotInferable(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 245, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d955 }, { i64, ptr } { i64 79, ptr @.d956 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeVarNamesType(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 173, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 14, ptr @.d957 }, 1
  %t3 = extractvalue { i64, ptr } { i64 14, ptr @.d957 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 60, ptr @.d958 }, 1
  %t8 = extractvalue { i64, ptr } { i64 60, ptr @.d958 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 2, ptr @.d959 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeVarNotInferable(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 174, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 14, ptr @.d960 }, 1
  %t3 = extractvalue { i64, ptr } { i64 14, ptr @.d960 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 93, ptr @.d961 }, 1
  %t8 = extractvalue { i64, ptr } { i64 93, ptr @.d961 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 2, ptr @.d962 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnboundedInstantiation(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 126, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d963 }, { i64, ptr } { i64 72, ptr @.d964 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnderscoreDeclared(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 209, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d965 }, { i64, ptr } { i64 64, ptr @.d966 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnhandledFallibleCall(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 342, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d967 }, { i64, ptr } { i64 65, ptr @.d968 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownBuildName(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 117, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = extractvalue { i64, ptr } { i64 13, ptr @.d969 }, 1
  %t4 = extractvalue { i64, ptr } { i64 13, ptr @.d969 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = load { i64, ptr }, ptr %l3
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 54, ptr @.d970 }, 1
  %t9 = extractvalue { i64, ptr } { i64 54, ptr @.d970 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load { i64, ptr }, ptr %l4
  %t11 = extractvalue { i64, ptr } %t10, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = extractvalue { i64, ptr } { i64 37, ptr @.d971 }, 1
  %t14 = extractvalue { i64, ptr } { i64 37, ptr @.d971 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t13, i64 %t14)
  %t15 = load ptr, ptr %s1
  %t16 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t17 = load i64, ptr %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t15, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t21 = load { i64, ptr }, ptr %l5
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l6
  %t28 = load i32, ptr %l2
  %t29 = load { i64, ptr }, ptr %l6
  %t30 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t28, { i64, ptr } { i64 3, ptr @.d972 }, { i64, ptr } %t29)
  store %"compiler/msgs:Msg" %t30, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t31 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t31, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownFlag(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 4, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = extractvalue { i64, ptr } { i64 16, ptr @.d973 }, 1
  %t4 = extractvalue { i64, ptr } { i64 16, ptr @.d973 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = load { i64, ptr }, ptr %l3
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 38, ptr @.d974 }, 1
  %t9 = extractvalue { i64, ptr } { i64 38, ptr @.d974 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load { i64, ptr }, ptr %l4
  %t11 = extractvalue { i64, ptr } %t10, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = load ptr, ptr %s1
  %t14 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t15 = load i64, ptr %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t13, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t19 = load { i64, ptr }, ptr %l5
  %t20 = extractvalue { i64, ptr } %t19, 0
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = mul i64 %t20, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t22)
  call void @llvm.memcpy.p0.p0.i64(ptr %t23, ptr %t21, i64 %t22, i1 false)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l6
  %t26 = load i32, ptr %l2
  %t27 = load { i64, ptr }, ptr %l6
  %t28 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t26, { i64, ptr } { i64 2, ptr @.d975 }, { i64, ptr } %t27)
  store %"compiler/msgs:Msg" %t28, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t29, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownFunction(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 104, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 25, ptr @.d976 }, 1
  %t3 = extractvalue { i64, ptr } { i64 25, ptr @.d976 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 0, ptr @.d977 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownFunctionMeant(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 105, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = extractvalue { i64, ptr } { i64 25, ptr @.d978 }, 1
  %t4 = extractvalue { i64, ptr } { i64 25, ptr @.d978 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = load { i64, ptr }, ptr %l3
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 17, ptr @.d979 }, 1
  %t9 = extractvalue { i64, ptr } { i64 17, ptr @.d979 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load { i64, ptr }, ptr %l4
  %t11 = extractvalue { i64, ptr } %t10, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = extractvalue { i64, ptr } { i64 2, ptr @.d980 }, 1
  %t14 = extractvalue { i64, ptr } { i64 2, ptr @.d980 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t13, i64 %t14)
  %t15 = load ptr, ptr %s1
  %t16 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t17 = load i64, ptr %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t15, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t21 = load { i64, ptr }, ptr %l5
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l6
  %t28 = load i32, ptr %l2
  %t29 = load { i64, ptr }, ptr %l6
  %t30 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t28, { i64, ptr } { i64 0, ptr @.d981 }, { i64, ptr } %t29)
  store %"compiler/msgs:Msg" %t30, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t31 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t31, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownImportStd(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 93, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = load { i64, ptr }, ptr %l3
  %t4 = extractvalue { i64, ptr } %t3, 1
  %t5 = extractvalue { i64, ptr } %t3, 0
  call void @__olang_sb_put(ptr %s1, ptr %t4, i64 %t5)
  %t6 = extractvalue { i64, ptr } { i64 46, ptr @.d982 }, 1
  %t7 = extractvalue { i64, ptr } { i64 46, ptr @.d982 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = load { i64, ptr }, ptr %l4
  %t9 = extractvalue { i64, ptr } %t8, 1
  %t10 = extractvalue { i64, ptr } %t8, 0
  call void @__olang_sb_put(ptr %s1, ptr %t9, i64 %t10)
  %t11 = extractvalue { i64, ptr } { i64 2, ptr @.d983 }, 1
  %t12 = extractvalue { i64, ptr } { i64 2, ptr @.d983 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = load ptr, ptr %s1
  %t14 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t15 = load i64, ptr %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t13, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t19 = load { i64, ptr }, ptr %l5
  %t20 = extractvalue { i64, ptr } %t19, 0
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = mul i64 %t20, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t22)
  call void @llvm.memcpy.p0.p0.i64(ptr %t23, ptr %t21, i64 %t22, i1 false)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l6
  %t26 = load i32, ptr %l2
  %t27 = load { i64, ptr }, ptr %l6
  %t28 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t26, { i64, ptr } { i64 3, ptr @.d984 }, { i64, ptr } %t27)
  store %"compiler/msgs:Msg" %t28, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t29, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownMethod(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 365, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = load { i64, ptr }, ptr %l3
  %t4 = extractvalue { i64, ptr } %t3, 1
  %t5 = extractvalue { i64, ptr } %t3, 0
  call void @__olang_sb_put(ptr %s1, ptr %t4, i64 %t5)
  %t6 = extractvalue { i64, ptr } { i64 15, ptr @.d985 }, 1
  %t7 = extractvalue { i64, ptr } { i64 15, ptr @.d985 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = load { i64, ptr }, ptr %l4
  %t9 = extractvalue { i64, ptr } %t8, 1
  %t10 = extractvalue { i64, ptr } %t8, 0
  call void @__olang_sb_put(ptr %s1, ptr %t9, i64 %t10)
  %t11 = load ptr, ptr %s1
  %t12 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t13 = load i64, ptr %t12
  %t14 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t13)
  call void @llvm.memcpy.p0.p0.i64(ptr %t14, ptr %t11, i64 %t13, i1 false)
  %t15 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t17 = load { i64, ptr }, ptr %l5
  %t18 = extractvalue { i64, ptr } %t17, 0
  %t19 = extractvalue { i64, ptr } %t17, 1
  %t20 = mul i64 %t18, 1
  %t21 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t20)
  call void @llvm.memcpy.p0.p0.i64(ptr %t21, ptr %t19, i64 %t20, i1 false)
  %t22 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l6
  %t24 = load i32, ptr %l2
  %t25 = load { i64, ptr }, ptr %l6
  %t26 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t24, { i64, ptr } { i64 3, ptr @.d986 }, { i64, ptr } %t25)
  store %"compiler/msgs:Msg" %t26, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t27 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t27, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownName(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 101, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 13, ptr @.d987 }, 1
  %t3 = extractvalue { i64, ptr } { i64 13, ptr @.d987 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 0, ptr @.d988 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownNumberType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 100, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = extractvalue { i64, ptr } { i64 13, ptr @.d989 }, 1
  %t4 = extractvalue { i64, ptr } { i64 13, ptr @.d989 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = load { i64, ptr }, ptr %l3
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 58, ptr @.d990 }, 1
  %t9 = extractvalue { i64, ptr } { i64 58, ptr @.d990 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load { i64, ptr }, ptr %l4
  %t11 = extractvalue { i64, ptr } %t10, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = extractvalue { i64, ptr } { i64 2, ptr @.d991 }, 1
  %t14 = extractvalue { i64, ptr } { i64 2, ptr @.d991 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t13, i64 %t14)
  %t15 = load ptr, ptr %s1
  %t16 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t17 = load i64, ptr %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t15, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t21 = load { i64, ptr }, ptr %l5
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l6
  %t28 = load i32, ptr %l2
  %t29 = load { i64, ptr }, ptr %l6
  %t30 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t28, { i64, ptr } { i64 2, ptr @.d992 }, { i64, ptr } %t29)
  store %"compiler/msgs:Msg" %t30, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t31 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t31, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownScopeName(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 119, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 83, ptr @.d993 }, 1
  %t6 = extractvalue { i64, ptr } { i64 83, ptr @.d993 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 3, ptr @.d994 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownType(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 98, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 13, ptr @.d995 }, 1
  %t3 = extractvalue { i64, ptr } { i64 13, ptr @.d995 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l4
  %t20 = load i32, ptr %l1
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t20, { i64, ptr } { i64 0, ptr @.d996 }, { i64, ptr } %t21)
  store %"compiler/msgs:Msg" %t22, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownTypeMeant(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 99, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = extractvalue { i64, ptr } { i64 13, ptr @.d997 }, 1
  %t4 = extractvalue { i64, ptr } { i64 13, ptr @.d997 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = load { i64, ptr }, ptr %l3
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 17, ptr @.d998 }, 1
  %t9 = extractvalue { i64, ptr } { i64 17, ptr @.d998 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load { i64, ptr }, ptr %l4
  %t11 = extractvalue { i64, ptr } %t10, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = extractvalue { i64, ptr } { i64 2, ptr @.d999 }, 1
  %t14 = extractvalue { i64, ptr } { i64 2, ptr @.d999 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t13, i64 %t14)
  %t15 = load ptr, ptr %s1
  %t16 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t17 = load i64, ptr %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t15, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t21 = load { i64, ptr }, ptr %l5
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l6
  %t28 = load i32, ptr %l2
  %t29 = load { i64, ptr }, ptr %l6
  %t30 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t28, { i64, ptr } { i64 0, ptr @.d1000 }, { i64, ptr } %t29)
  store %"compiler/msgs:Msg" %t30, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t31 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t31, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUsage(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 0, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 2, ptr @.d1001 }, { i64, ptr } { i64 105, ptr @.d1002 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eValueAfterEq(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 73, ptr %l4
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l5
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l6
  %t3 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t3, ptr %l7
  %t4 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t4, ptr %l8
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t5 = extractvalue { i64, ptr } { i64 43, ptr @.d1003 }, 1
  %t6 = extractvalue { i64, ptr } { i64 43, ptr @.d1003 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load { i64, ptr }, ptr %l5
  %t8 = extractvalue { i64, ptr } %t7, 1
  %t9 = extractvalue { i64, ptr } %t7, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = extractvalue { i64, ptr } { i64 3, ptr @.d1004 }, 1
  %t11 = extractvalue { i64, ptr } { i64 3, ptr @.d1004 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t10, i64 %t11)
  %t12 = load { i64, ptr }, ptr %l6
  %t13 = extractvalue { i64, ptr } %t12, 1
  %t14 = extractvalue { i64, ptr } %t12, 0
  call void @__olang_sb_put(ptr %s1, ptr %t13, i64 %t14)
  %t15 = extractvalue { i64, ptr } { i64 7, ptr @.d1005 }, 1
  %t16 = extractvalue { i64, ptr } { i64 7, ptr @.d1005 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t15, i64 %t16)
  %t17 = load { i64, ptr }, ptr %l7
  %t18 = extractvalue { i64, ptr } %t17, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  call void @__olang_sb_put(ptr %s1, ptr %t18, i64 %t19)
  %t20 = extractvalue { i64, ptr } { i64 4, ptr @.d1006 }, 1
  %t21 = extractvalue { i64, ptr } { i64 4, ptr @.d1006 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t20, i64 %t21)
  %t22 = load { i64, ptr }, ptr %l8
  %t23 = extractvalue { i64, ptr } %t22, 1
  %t24 = extractvalue { i64, ptr } %t22, 0
  call void @__olang_sb_put(ptr %s1, ptr %t23, i64 %t24)
  %t25 = extractvalue { i64, ptr } { i64 1, ptr @.d1007 }, 1
  %t26 = extractvalue { i64, ptr } { i64 1, ptr @.d1007 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t25, i64 %t26)
  %t27 = load ptr, ptr %s1
  %t28 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t29 = load i64, ptr %t28
  %t30 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t27, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  store { i64, ptr } %t32, ptr %l9
  call void @__olang_sb_done(ptr %s1)
  %t33 = load { i64, ptr }, ptr %l9
  %t34 = extractvalue { i64, ptr } %t33, 0
  %t35 = extractvalue { i64, ptr } %t33, 1
  %t36 = mul i64 %t34, 1
  %t37 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t36)
  call void @llvm.memcpy.p0.p0.i64(ptr %t37, ptr %t35, i64 %t36, i1 false)
  %t38 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l10
  %t40 = load i32, ptr %l4
  %t41 = load { i64, ptr }, ptr %l10
  %t42 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, i32 %t40, { i64, ptr } { i64 3, ptr @.d1008 }, { i64, ptr } %t41)
  store %"compiler/msgs:Msg" %t42, ptr %l11
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t43 = load %"compiler/msgs:Msg", ptr %l11
  store %"compiler/msgs:Msg" %t43, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eValueRefsOutlived(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 407, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 4, ptr @.d1009 }, { i64, ptr } { i64 91, ptr @.d1010 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eVarListCount(ptr %v0, i64 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 71, ptr %l2
  %t1 = load i64, ptr %l0
  store i64 %t1, ptr %l3
  %t2 = load i64, ptr %l1
  store i64 %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = load i64, ptr %l3
  %t4 = call ptr @__olang_sb_room(ptr %s1, i64 24)
  %t5 = call i64 @__olang_fmt_i64(ptr %t4, i64 %t3)
  call void @__olang_sb_add(ptr %s1, i64 %t5)
  %t6 = extractvalue { i64, ptr } { i64 34, ptr @.d1011 }, 1
  %t7 = extractvalue { i64, ptr } { i64 34, ptr @.d1011 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = load i64, ptr %l4
  %t9 = call ptr @__olang_sb_room(ptr %s1, i64 24)
  %t10 = call i64 @__olang_fmt_i64(ptr %t9, i64 %t8)
  call void @__olang_sb_add(ptr %s1, i64 %t10)
  %t11 = load ptr, ptr %s1
  %t12 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t13 = load i64, ptr %t12
  %t14 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t13)
  call void @llvm.memcpy.p0.p0.i64(ptr %t14, ptr %t11, i64 %t13, i1 false)
  %t15 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t17 = load { i64, ptr }, ptr %l5
  %t18 = extractvalue { i64, ptr } %t17, 0
  %t19 = extractvalue { i64, ptr } %t17, 1
  %t20 = mul i64 %t18, 1
  %t21 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t20)
  call void @llvm.memcpy.p0.p0.i64(ptr %t21, ptr %t19, i64 %t20, i1 false)
  %t22 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l6
  %t24 = load i32, ptr %l2
  %t25 = load { i64, ptr }, ptr %l6
  %t26 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t24, { i64, ptr } { i64 4, ptr @.d1012 }, { i64, ptr } %t25)
  store %"compiler/msgs:Msg" %t26, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t27 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t27, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eVecGrowsUnderTask(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 520, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = extractvalue { i64, ptr } { i64 1, ptr @.d1013 }, 1
  %t4 = extractvalue { i64, ptr } { i64 1, ptr @.d1013 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = load { i64, ptr }, ptr %l3
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 73, ptr @.d1014 }, 1
  %t9 = extractvalue { i64, ptr } { i64 73, ptr @.d1014 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load { i64, ptr }, ptr %l4
  %t11 = extractvalue { i64, ptr } %t10, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = extractvalue { i64, ptr } { i64 11, ptr @.d1015 }, 1
  %t14 = extractvalue { i64, ptr } { i64 11, ptr @.d1015 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t13, i64 %t14)
  %t15 = load ptr, ptr %s1
  %t16 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t17 = load i64, ptr %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t15, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t21 = load { i64, ptr }, ptr %l5
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l6
  %t28 = load i32, ptr %l2
  %t29 = load { i64, ptr }, ptr %l6
  %t30 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t28, { i64, ptr } { i64 4, ptr @.d1016 }, { i64, ptr } %t29)
  store %"compiler/msgs:Msg" %t30, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t31 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t31, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eVecHiddenViewStale(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 518, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = extractvalue { i64, ptr } { i64 22, ptr @.d1017 }, 1
  %t4 = extractvalue { i64, ptr } { i64 22, ptr @.d1017 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = load { i64, ptr }, ptr %l3
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 16, ptr @.d1018 }, 1
  %t9 = extractvalue { i64, ptr } { i64 16, ptr @.d1018 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = load { i64, ptr }, ptr %l4
  %t11 = extractvalue { i64, ptr } %t10, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  call void @__olang_sb_put(ptr %s1, ptr %t11, i64 %t12)
  %t13 = extractvalue { i64, ptr } { i64 16, ptr @.d1019 }, 1
  %t14 = extractvalue { i64, ptr } { i64 16, ptr @.d1019 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t13, i64 %t14)
  %t15 = load ptr, ptr %s1
  %t16 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t17 = load i64, ptr %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t15, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t21 = load { i64, ptr }, ptr %l5
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l6
  %t28 = load i32, ptr %l2
  %t29 = load { i64, ptr }, ptr %l6
  %t30 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t28, { i64, ptr } { i64 4, ptr @.d1020 }, { i64, ptr } %t29)
  store %"compiler/msgs:Msg" %t30, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t31 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t31, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eVecViewGivenGrowing(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 519, ptr %l4
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l5
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l6
  %t3 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t3, ptr %l7
  %t4 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t4, ptr %l8
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t5 = extractvalue { i64, ptr } { i64 14, ptr @.d1021 }, 1
  %t6 = extractvalue { i64, ptr } { i64 14, ptr @.d1021 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load { i64, ptr }, ptr %l5
  %t8 = extractvalue { i64, ptr } %t7, 1
  %t9 = extractvalue { i64, ptr } %t7, 0
  call void @__olang_sb_put(ptr %s1, ptr %t8, i64 %t9)
  %t10 = extractvalue { i64, ptr } { i64 14, ptr @.d1022 }, 1
  %t11 = extractvalue { i64, ptr } { i64 14, ptr @.d1022 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t10, i64 %t11)
  %t12 = load { i64, ptr }, ptr %l6
  %t13 = extractvalue { i64, ptr } %t12, 1
  %t14 = extractvalue { i64, ptr } %t12, 0
  call void @__olang_sb_put(ptr %s1, ptr %t13, i64 %t14)
  %t15 = extractvalue { i64, ptr } { i64 18, ptr @.d1023 }, 1
  %t16 = extractvalue { i64, ptr } { i64 18, ptr @.d1023 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t15, i64 %t16)
  %t17 = load { i64, ptr }, ptr %l7
  %t18 = extractvalue { i64, ptr } %t17, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  call void @__olang_sb_put(ptr %s1, ptr %t18, i64 %t19)
  %t20 = extractvalue { i64, ptr } { i64 30, ptr @.d1024 }, 1
  %t21 = extractvalue { i64, ptr } { i64 30, ptr @.d1024 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t20, i64 %t21)
  %t22 = load { i64, ptr }, ptr %l8
  %t23 = extractvalue { i64, ptr } %t22, 1
  %t24 = extractvalue { i64, ptr } %t22, 0
  call void @__olang_sb_put(ptr %s1, ptr %t23, i64 %t24)
  %t25 = extractvalue { i64, ptr } { i64 11, ptr @.d1025 }, 1
  %t26 = extractvalue { i64, ptr } { i64 11, ptr @.d1025 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t25, i64 %t26)
  %t27 = load ptr, ptr %s1
  %t28 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t29 = load i64, ptr %t28
  %t30 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t27, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  store { i64, ptr } %t32, ptr %l9
  call void @__olang_sb_done(ptr %s1)
  %t33 = load { i64, ptr }, ptr %l9
  %t34 = extractvalue { i64, ptr } %t33, 0
  %t35 = extractvalue { i64, ptr } %t33, 1
  %t36 = mul i64 %t34, 1
  %t37 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t36)
  call void @llvm.memcpy.p0.p0.i64(ptr %t37, ptr %t35, i64 %t36, i1 false)
  %t38 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l10
  %t40 = load i32, ptr %l4
  %t41 = load { i64, ptr }, ptr %l10
  %t42 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, i32 %t40, { i64, ptr } { i64 4, ptr @.d1026 }, { i64, ptr } %t41)
  store %"compiler/msgs:Msg" %t42, ptr %l11
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t43 = load %"compiler/msgs:Msg", ptr %l11
  store %"compiler/msgs:Msg" %t43, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eVecViewStale(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 517, ptr %l3
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l4
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l5
  %t3 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t3, ptr %l6
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t4 = extractvalue { i64, ptr } { i64 1, ptr @.d1027 }, 1
  %t5 = extractvalue { i64, ptr } { i64 1, ptr @.d1027 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t4, i64 %t5)
  %t6 = load { i64, ptr }, ptr %l4
  %t7 = extractvalue { i64, ptr } %t6, 1
  %t8 = extractvalue { i64, ptr } %t6, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = extractvalue { i64, ptr } { i64 19, ptr @.d1028 }, 1
  %t10 = extractvalue { i64, ptr } { i64 19, ptr @.d1028 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t9, i64 %t10)
  %t11 = load { i64, ptr }, ptr %l5
  %t12 = extractvalue { i64, ptr } %t11, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  call void @__olang_sb_put(ptr %s1, ptr %t12, i64 %t13)
  %t14 = extractvalue { i64, ptr } { i64 16, ptr @.d1029 }, 1
  %t15 = extractvalue { i64, ptr } { i64 16, ptr @.d1029 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t14, i64 %t15)
  %t16 = load { i64, ptr }, ptr %l6
  %t17 = extractvalue { i64, ptr } %t16, 1
  %t18 = extractvalue { i64, ptr } %t16, 0
  call void @__olang_sb_put(ptr %s1, ptr %t17, i64 %t18)
  %t19 = extractvalue { i64, ptr } { i64 16, ptr @.d1030 }, 1
  %t20 = extractvalue { i64, ptr } { i64 16, ptr @.d1030 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t19, i64 %t20)
  %t21 = load ptr, ptr %s1
  %t22 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t23 = load i64, ptr %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t23)
  call void @llvm.memcpy.p0.p0.i64(ptr %t24, ptr %t21, i64 %t23, i1 false)
  %t25 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  store { i64, ptr } %t26, ptr %l7
  call void @__olang_sb_done(ptr %s1)
  %t27 = load { i64, ptr }, ptr %l7
  %t28 = extractvalue { i64, ptr } %t27, 0
  %t29 = extractvalue { i64, ptr } %t27, 1
  %t30 = mul i64 %t28, 1
  %t31 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t30)
  call void @llvm.memcpy.p0.p0.i64(ptr %t31, ptr %t29, i64 %t30, i1 false)
  %t32 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  store { i64, ptr } %t33, ptr %l8
  %t34 = load i32, ptr %l3
  %t35 = load { i64, ptr }, ptr %l8
  %t36 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 %t34, { i64, ptr } { i64 4, ptr @.d1031 }, { i64, ptr } %t35)
  store %"compiler/msgs:Msg" %t36, ptr %l9
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t37 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t37, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eWildcardNotAlone(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 440, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 4, ptr @.d1032 }, { i64, ptr } { i64 61, ptr @.d1033 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eWriteIntoCallValue(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 291, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 3, ptr @.d1034 }, { i64, ptr } { i64 98, ptr @.d1035 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eWriteThroughAtBuilds(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 358, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 8, ptr @.d1036 }, { i64, ptr } { i64 171, ptr @.d1037 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eWriteThroughAtCall(ptr %v0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 360, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t1, { i64, ptr } { i64 4, ptr @.d1038 }, { i64, ptr } { i64 196, ptr @.d1039 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eWriteThroughAtNoSetat(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 357, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l2
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 28, ptr @.d1040 }, 1
  %t3 = extractvalue { i64, ptr } { i64 28, ptr @.d1040 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = extractvalue { i64, ptr } { i64 95, ptr @.d1041 }, 1
  %t8 = extractvalue { i64, ptr } { i64 95, ptr @.d1041 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l3
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l4
  %t22 = load i32, ptr %l1
  %t23 = load { i64, ptr }, ptr %l4
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t22, { i64, ptr } { i64 3, ptr @.d1042 }, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t24, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  store i32 %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l0
  store i32 %t1, ptr %l6
  %t2 = load i32, ptr %l6
  store i32 %t2, ptr %l3
  %t3 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t3, ptr %l7
  %t4 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t4, ptr %l4
  %t5 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t5, ptr %l8
  %t6 = load { i64, ptr }, ptr %l8
  store { i64, ptr } %t6, ptr %l5
  %t7 = load i32, ptr %l3
  %t8 = insertvalue %"compiler/msgs:Msg" undef, i32 %t7, 0
  %t9 = load { i64, ptr }, ptr %l4
  %t10 = insertvalue %"compiler/msgs:Msg" %t8, { i64, ptr } %t9, 1
  %t11 = load { i64, ptr }, ptr %l5
  %t12 = insertvalue %"compiler/msgs:Msg" %t10, { i64, ptr } %t11, 2
  store %"compiler/msgs:Msg" %t12, ptr %l9
  call void @__olang_scope_close(ptr %s0)
  %t13 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local void @olang_2einit_2ecompiler_2fmsgs() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @compiler_2fmsgs_2eEndOfLine_2einit()
  br label %bb1
bb1:
  call void @compiler_2fmsgs_2eEndOfFile_2einit()
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

declare void @__olang_sb_put(ptr, ptr, i64)
@.d0 = private constant [13 x i8] c" is bound as "
@.d1 = private constant [43 x i8] c" by an earlier alternative - split the case"
declare ptr @__olang_scope_alloc(ptr, i64)
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare void @__olang_sb_done(ptr)
@.d2 = private constant [4 x i8] c"S13c"
declare void @__olang_scope_close(ptr)
@.d3 = private constant [4 x i8] c"S13c"
@.d4 = private constant [86 x i8] c"every alternative binds the same names - bind it in each, write '_', or split the case"
@.d5 = private constant [9 x i8] c"expected "
declare ptr @__olang_sb_room(ptr, i64)
declare i64 @__olang_fmt_i64(ptr, i64)
declare void @__olang_sb_add(ptr, i64)
@.d6 = private constant [9 x i8] c" argument"
@.d7 = private constant [8 x i8] c", found "
@.d8 = private constant [3 x i8] c"E14"
@.d9 = private constant [9 x i8] c"expected "
@.d10 = private constant [4 x i8] c" to "
@.d11 = private constant [18 x i8] c" arguments, found "
@.d12 = private constant [3 x i8] c"E14"
@.d13 = private constant [73 x i8] c"an array's length is from 0 to the largest whose bytes fit an I64, found "
@.d14 = private constant [3 x i8] c"T7c"
@.d15 = private constant [66 x i8] c"an array inside an array or a struct is held by reference - write "
@.d16 = private constant [48 x i8] c"&, or a length, Array<T, N>, to hold it in place"
@.d17 = private constant [8 x i8] c"T7a, T7c"
@.d18 = private constant [61 x i8] c" takes one index - several are passed to a type's At or SetAt"
@.d19 = private constant [3 x i8] c"E31"
@.d20 = private constant [16 x i8] c"array parameter "
@.d21 = private constant [32 x i8] c" is passed by reference - write "
@.d22 = private constant [1 x i8] c"&"
@.d23 = private constant [3 x i8] c"D9a"
@.d24 = private constant [14 x i8] c" does not fit "
@.d25 = private constant [37 x i8] c" - a fixed length is part of the type"
@.d26 = private constant [3 x i8] c"T7d"
@.d27 = private constant [88 x i8] c" holds itself through the array it is declared over - hold the array in a struct: 'type "
@.d28 = private constant [14 x i8] c" struct(items "
@.d29 = private constant [3 x i8] c"&)'"
@.d30 = private constant [3 x i8] c"T29"
@.d31 = private constant [4 x i8] c"S12b"
@.d32 = private constant [94 x i8] c"'=>' gives a value, which only a match used as a value takes - a statement's case runs a block"
@.d33 = private constant [24 x i8] c"'=>' gives a value, and "
@.d34 = private constant [50 x i8] c" gives none - a clause that leaves is a block: '{ "
@.d35 = private constant [3 x i8] c" }'"
@.d36 = private constant [4 x i8] c"S12b"
@.d37 = private constant [23 x i8] c"this array's length is "
@.d38 = private constant [6 x i8] c", not "
@.d39 = private constant [4 x i8] c"E32b"
@.d40 = private constant [35 x i8] c"after 'is' or 'as' comes a case of "
@.d41 = private constant [8 x i8] c", found "
@.d42 = private constant [3 x i8] c"E32"
@.d43 = private constant [5 x i8] c"case "
@.d44 = private constant [49 x i8] c" carries nothing for 'as' to give - ask with 'is'"
@.d45 = private constant [3 x i8] c"E32"
@.d46 = private constant [62 x i8] c"this assertion aborts the program, evaluated while compiling: "
@.d47 = private constant [4 x i8] c"S18c"
@.d48 = private constant [4 x i8] c"S18c"
@.d49 = private constant [50 x i8] c"this assertion is false, evaluated while compiling"
@.d50 = private constant [52 x i8] c"this assertion is false, evaluated while compiling: "
@.d51 = private constant [4 x i8] c"S18c"
@.d52 = private constant [38 x i8] c"an assertion's message is text, found "
@.d53 = private constant [31 x i8] c" - write it as text: \22x is \22 $x"
@.d54 = private constant [4 x i8] c"S18a"
@.d55 = private constant [3 x i8] c"S17"
@.d56 = private constant [58 x i8] c"an error may not leave an assert's message - catch it here"
@.d57 = private constant [79 x i8] c" may not leave an assert's message - it is evaluated only when the assert fails"
@.d58 = private constant [3 x i8] c"S17"
@.d59 = private constant [3 x i8] c"S17"
@.d60 = private constant [95 x i8] c"an assert's message may not return - it is evaluated only when the assert fails, and gives text"
@.d61 = private constant [3 x i8] c"R9a"
@.d62 = private constant [164 x i8] c"a 'try ... catch' value is the element or what a clause gives, a copy either way, so nothing written into it is kept - write 'checked x[i].f = v' to check the store"
@.d63 = private constant [36 x i8] c" targets need as many values, found "
@.d64 = private constant [3 x i8] c"S4c"
@.d65 = private constant [52 x i8] c" declares SetAt but not At, which reading x[i] calls"
@.d66 = private constant [3 x i8] c"E31"
@.d67 = private constant [60 x i8] c"the atomic operations are methods of the integer types, and "
@.d68 = private constant [8 x i8] c" is none"
@.d69 = private constant [2 x i8] c"P9"
@.d70 = private constant [2 x i8] c"P9"
@.d71 = private constant [71 x i8] c"an atomic operation acts on a place - a variable, a field or an element"
@.d72 = private constant [2 x i8] c"P9"
@.d73 = private constant [62 x i8] c"this atomic operation writes its place, which must be writable"
@.d74 = private constant [3 x i8] c"E35"
@.d75 = private constant [44 x i8] c"nothing here can fail - write it without '!'"
@.d76 = private constant [25 x i8] c"the block opened on line "
@.d77 = private constant [20 x i8] c" has no '}' - found "
@.d78 = private constant [0 x i8] c""
@.d79 = private constant [3 x i8] c"O17"
@.d80 = private constant [153 x i8] c"this value's references live where its own storage does not, and the callee can store through it - declare it a reference where they live ('x T&y = ...')"
@.d81 = private constant [4 x i8] c"O17a"
@.d82 = private constant [114 x i8] c"this value's references live where its own storage does not, so it is not held by reference - use the value itself"
@.d83 = private constant [51 x i8] c" acts on the innermost loop, and there is none here"
@.d84 = private constant [3 x i8] c"S11"
@.d85 = private constant [42 x i8] c" is a build constant - choose another name"
@.d86 = private constant [3 x i8] c"B10"
@.d87 = private constant [8 x i8] c"-define "
@.d88 = private constant [1 x i8] c"="
@.d89 = private constant [14 x i8] c" does not fit "
@.d90 = private constant [11 x i8] c", which is "
@.d91 = private constant [4 x i8] c"B10c"
@.d92 = private constant [85 x i8] c" is a build constant, and a declaration giving it a default is immutable - drop 'mut'"
@.d93 = private constant [4 x i8] c"B10c"
@.d94 = private constant [91 x i8] c" is a build constant, and a default for it is a Bool, I32, I64, U64, F64 or String - found "
@.d95 = private constant [4 x i8] c"B10c"
@.d96 = private constant [8 x i8] c"O11, O12"
@.d97 = private constant [113 x i8] c"where this reference's referent lives is not known here, and the callee may build there - give it one known scope"
@.d98 = private constant [3 x i8] c"C2d"
@.d99 = private constant [113 x i8] c"this builds through a '&p' field whose scope is not known here - build where it lives, in the function that knows"
@.d100 = private constant [43 x i8] c" is a built-in type's name - choose another"
@.d101 = private constant [3 x i8] c"D3a"
@.d102 = private constant [107 x i8] c"'s Call relates its arguments' scopes, which a call through a function value cannot check - call it by name"
@.d103 = private constant [9 x i8] c"T22a, E31"
@.d104 = private constant [0 x i8] c""
@.d105 = private constant [21 x i8] c"cannot open this file"
@.d106 = private constant [27 x i8] c"the program cannot be run: "
@.d107 = private constant [3 x i8] c"B3g"
@.d108 = private constant [4 x i8] c"D16c"
@.d109 = private constant [84 x i8] c"a lambda's captures are read-only - capture a reference to change what is outside it"
@.d110 = private constant [4 x i8] c"S13f"
@.d111 = private constant [73 x i8] c"no value reaches this - an earlier 'case _' with no guard takes every one"
@.d112 = private constant [4 x i8] c"S12b"
@.d113 = private constant [66 x i8] c"this block can finish without leaving - give the value with '=> v'"
@.d114 = private constant [115 x i8] c" is the value being matched, so this compares it with itself - to take any value and test it, write 'case _ if ...'"
@.d115 = private constant [4 x i8] c"S13f"
@.d116 = private constant [13 x i8] c"unknown name "
@.d117 = private constant [101 x i8] c" - a name in a case is a value compared by '=='; to take any value and test it, write 'case _ if ...'"
@.d118 = private constant [4 x i8] c"S13f"
@.d119 = private constant [21 x i8] c"a case value here is "
@.d120 = private constant [8 x i8] c", found "
@.d121 = private constant [3 x i8] c"S13"
@.d122 = private constant [4 x i8] c"R11a"
@.d123 = private constant [78 x i8] c"a catch with no error types takes every error left, so no clause can follow it"
@.d124 = private constant [3 x i8] c"R11"
@.d125 = private constant [57 x i8] c"a clause here leaves, or gives the value with 'default v'"
@.d126 = private constant [28 x i8] c"the call does not fail with "
@.d127 = private constant [3 x i8] c"R14"
@.d128 = private constant [4 x i8] c"R11a"
@.d129 = private constant [58 x i8] c"an earlier clause already takes every error this one names"
@.d130 = private constant [28 x i8] c"the call does not fail with "
@.d131 = private constant [17 x i8] c" - it fails with "
@.d132 = private constant [3 x i8] c"R14"
@.d133 = private constant [4 x i8] c" is "
@.d134 = private constant [46 x i8] c"'s checked form, so it fails with every error "
@.d135 = private constant [11 x i8] c" can - add "
@.d136 = private constant [14 x i8] c" after its '?'"
@.d137 = private constant [4 x i8] c"E31a"
@.d138 = private constant [71 x i8] c" is a checked form, which only adds checks to its plain form - declare "
@.d139 = private constant [10 x i8] c" beside it"
@.d140 = private constant [4 x i8] c"E31a"
@.d141 = private constant [24 x i8] c"clang could not compile "
@.d142 = private constant [0 x i8] c""
@.d143 = private constant [66 x i8] c"a block's last value is not the clause's value - write '} default "
@.d144 = private constant [17 x i8] c"' after the block"
@.d145 = private constant [3 x i8] c"R11"
@.d146 = private constant [8 x i8] c"E27, S9e"
@.d147 = private constant [69 x i8] c"this comprehension's own calls can fail - write 'try T[e for x in c]'"
@.d148 = private constant [3 x i8] c"E27"
@.d149 = private constant [90 x i8] c"a comprehension's elements may not be or hold references yet - build the array with a loop"
@.d150 = private constant [52 x i8] c"both values of 'a if c else b' have one type, found "
@.d151 = private constant [5 x i8] c" and "
@.d152 = private constant [3 x i8] c"E28"
@.d153 = private constant [30 x i8] c" is defined in terms of itself"
@.d154 = private constant [3 x i8] c"B9a"
@.d155 = private constant [56 x i8] c" is not computed from literals and build constants alone"
@.d156 = private constant [3 x i8] c"B9a"
@.d157 = private constant [3 x i8] c"E28"
@.d158 = private constant [190 x i8] c"a conditional or a match gives a copy of the value it chooses, which this call would write and drop - call on the place itself, 'if c { f(a) } else { f(b) }', or hold the values by reference"
@.d159 = private constant [52 x i8] c" is mutable, so a top-level condition cannot read it"
@.d160 = private constant [3 x i8] c"B9a"
@.d161 = private constant [62 x i8] c" is not a build constant or an immutable global of this module"
@.d162 = private constant [3 x i8] c"B9a"
@.d163 = private constant [59 x i8] c": these numbers' types do not meet - convert one, as I64(n)"
@.d164 = private constant [3 x i8] c"T6b"
@.d165 = private constant [24 x i8] c"the condition beginning "
@.d166 = private constant [14 x i8] c" is not a Bool"
@.d167 = private constant [2 x i8] c"B9"
@.d168 = private constant [29 x i8] c"a condition is a Bool, found "
@.d169 = private constant [0 x i8] c""
@.d170 = private constant [28 x i8] c" cannot combine these values"
@.d171 = private constant [2 x i8] c"B9"
@.d172 = private constant [111 x i8] c" in a type argument is written in parentheses, as '(1 << 12)' - a bare '<' or '>' there reads as the list's own"
@.d173 = private constant [3 x i8] c"G21"
@.d174 = private constant [18 x i8] c"constant variable "
@.d175 = private constant [146 x i8] c" appears in no parameter's type as a whole argument, so no call can give it a value - introduce it in a parameter's type, or use a run-time length"
@.d176 = private constant [7 x i8] c"G4, G24"
@.d177 = private constant [88 x i8] c" is a constant variable of this declaration - a name means one thing, so name this apart"
@.d178 = private constant [8 x i8] c"G22, D3a"
@.d179 = private constant [55 x i8] c" is not a trait, so it cannot constrain a type variable"
@.d180 = private constant [3 x i8] c"G19"
@.d181 = private constant [33 x i8] c" does not satisfy the constraint "
@.d182 = private constant [4 x i8] c" on "
@.d183 = private constant [2 x i8] c": "
@.d184 = private constant [50 x i8] c" is sealed - only the types its own module gives '"
@.d185 = private constant [12 x i8] c"' satisfy it"
@.d186 = private constant [8 x i8] c"G19, T31"
@.d187 = private constant [33 x i8] c" does not satisfy the constraint "
@.d188 = private constant [4 x i8] c" on "
@.d189 = private constant [3 x i8] c"G19"
@.d190 = private constant [33 x i8] c" does not satisfy the constraint "
@.d191 = private constant [4 x i8] c" on "
@.d192 = private constant [59 x i8] c": it has no Hash - declare 'Hash() I64', agreeing with '=='"
@.d193 = private constant [9 x i8] c"G19, E10b"
@.d194 = private constant [33 x i8] c" does not satisfy the constraint "
@.d195 = private constant [4 x i8] c" on "
@.d196 = private constant [19 x i8] c": it has no method "
@.d197 = private constant [10 x i8] c" that fits"
@.d198 = private constant [3 x i8] c"G19"
@.d199 = private constant [18 x i8] c"the type of field "
@.d200 = private constant [7 x i8] c" names "
@.d201 = private constant [105 x i8] c", which only the constructor introduces - for a field to hold it, declare it the type's parameter: 'type "
@.d202 = private constant [1 x i8] c"<"
@.d203 = private constant [2 x i8] c">'"
@.d204 = private constant [4 x i8] c"G10d"
@.d205 = private constant [6 x i8] c"field "
@.d206 = private constant [58 x i8] c" takes its type from ':=', and the constructor introduces "
@.d207 = private constant [58 x i8] c", so its body is checked per call - write the field's type"
@.d208 = private constant [4 x i8] c"G10d"
@.d209 = private constant [22 x i8] c"the type arguments of "
@.d210 = private constant [55 x i8] c" cannot be inferred from these arguments - write them: "
@.d211 = private constant [10 x i8] c"<...>(...)"
@.d212 = private constant [4 x i8] c"G10c"
@.d213 = private constant [15 x i8] c" is not one of "
@.d214 = private constant [81 x i8] c"'s parameters, and a generic type's constructor introduces none of its own - add "
@.d215 = private constant [19 x i8] c" to the type's list"
@.d216 = private constant [4 x i8] c"G10d"
@.d217 = private constant [5 x i8] c"what "
@.d218 = private constant [65 x i8] c"'s constructor introduces cannot be inferred from these arguments"
@.d219 = private constant [4 x i8] c"G10d"
@.d220 = private constant [3 x i8] c"D8e"
@.d221 = private constant [61 x i8] c"a 'noreturn' call gives no value, so ':=' has no type to take"
@.d222 = private constant [3 x i8] c"D15"
@.d223 = private constant [91 x i8] c"':=' takes its type from the initializer, and null has none - write the type: 'x T& = null'"
@.d224 = private constant [55 x i8] c"a type is declared over a number or an array, not over "
@.d225 = private constant [38 x i8] c" - hold it in a struct's field instead"
@.d226 = private constant [3 x i8] c"T29"
@.d227 = private constant [18 x i8] c" is declared twice"
@.d228 = private constant [0 x i8] c""
@.d229 = private constant [11 x i8] c"two traits "
@.d230 = private constant [34 x i8] c" satisfies both declare a default "
@.d231 = private constant [25 x i8] c" - the call cannot choose"
@.d232 = private constant [4 x i8] c"M19e"
@.d233 = private constant [9 x i8] c"expected "
@.d234 = private constant [33 x i8] c" defaults, one per result, found "
@.d235 = private constant [3 x i8] c"R11"
@.d236 = private constant [3 x i8] c"R11"
@.d237 = private constant [80 x i8] c"this clause's block always leaves, so its default is never the value - remove it"
@.d238 = private constant [3 x i8] c"R11"
@.d239 = private constant [131 x i8] c"a default for a value holding references builds all it holds - a constructor call of numbers and written text, as 'List<String&>()'"
@.d240 = private constant [3 x i8] c"R11"
@.d241 = private constant [67 x i8] c"a try written as a statement gives no value, so it takes no default"
@.d242 = private constant [3 x i8] c"R11"
@.d243 = private constant [77 x i8] c"this call returns no value, so there is nothing for a default to stand in for"
@.d244 = private constant [63 x i8] c"a default is computed while compiling, and this one cannot be: "
@.d245 = private constant [3 x i8] c"D8a"
@.d246 = private constant [8 x i8] c"R11, O25"
@.d247 = private constant [83 x i8] c"a reference default lives where the call's result does - or is null, or built there"
@.d248 = private constant [4 x i8] c"S19b"
@.d249 = private constant [52 x i8] c"an error may not leave deferred code - catch it here"
@.d250 = private constant [62 x i8] c" may not leave deferred code - it runs while its block is left"
@.d251 = private constant [4 x i8] c"S19b"
@.d252 = private constant [4 x i8] c"S19b"
@.d253 = private constant [62 x i8] c"deferred code may not return - it runs while its block is left"
@.d254 = private constant [8 x i8] c"-define "
@.d255 = private constant [1 x i8] c"="
@.d256 = private constant [60 x i8] c": not a number - '0x' and '0b' take digits of their own base"
@.d257 = private constant [3 x i8] c"B10"
@.d258 = private constant [46 x i8] c"-define cannot redefine the built-in constant "
@.d259 = private constant [4 x i8] c"B10a"
@.d260 = private constant [8 x i8] c"-define "
@.d261 = private constant [1 x i8] c"="
@.d262 = private constant [20 x i8] c": beyond F64's range"
@.d263 = private constant [3 x i8] c"B10"
@.d264 = private constant [8 x i8] c"-define "
@.d265 = private constant [1 x i8] c"="
@.d266 = private constant [16 x i8] c": beyond 64 bits"
@.d267 = private constant [3 x i8] c"B10"
@.d268 = private constant [8 x i8] c"-define "
@.d269 = private constant [1 x i8] c"="
@.d270 = private constant [21 x i8] c": below I64's minimum"
@.d271 = private constant [3 x i8] c"B10"
@.d272 = private constant [8 x i8] c"-define "
@.d273 = private constant [1 x i8] c"="
@.d274 = private constant [31 x i8] c": the name is not an identifier"
@.d275 = private constant [3 x i8] c"B10"
@.d276 = private constant [33 x i8] c"-define takes Name=value, found '"
@.d277 = private constant [1 x i8] c"'"
@.d278 = private constant [3 x i8] c"B10"
@.d279 = private constant [8 x i8] c"-define "
@.d280 = private constant [1 x i8] c"="
@.d281 = private constant [15 x i8] c": defined twice"
@.d282 = private constant [3 x i8] c"B10"
@.d283 = private constant [13 x i8] c" targets for "
@.d284 = private constant [39 x i8] c" results - write '_' for one not wanted"
@.d285 = private constant [3 x i8] c"D8c"
@.d286 = private constant [2 x i8] c"C7"
@.d287 = private constant [111 x i8] c"'destruct' follows the constructor's body - close the body first: 'type T struct(...) { ... } destruct { ... }'"
@.d288 = private constant [3 x i8] c"D8c"
@.d289 = private constant [83 x i8] c"':=' declares each target, so each is a name or '_' - use '=' to assign into places"
@.d290 = private constant [58 x i8] c"only several results can be destructured, and this is one "
@.d291 = private constant [3 x i8] c"D8c"
@.d292 = private constant [3 x i8] c"E6a"
@.d293 = private constant [16 x i8] c"division by zero"
@.d294 = private constant [4 x i8] c"O25c"
@.d295 = private constant [95 x i8] c"this element can be stored through, so it lives exactly where the array is put - build it there"
@.d296 = private constant [4 x i8] c"O25c"
@.d297 = private constant [87 x i8] c"the array outlives what this element refers to - build the element where the array goes"
@.d298 = private constant [3 x i8] c"C7a"
@.d299 = private constant [40 x i8] c"this destructor does nothing - remove it"
@.d300 = private constant [11 x i8] c"end of file"
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@__olang_prog_scope = external thread_local(initialexec) global ptr
declare ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d301 = private constant [11 x i8] c"end of line"
@.d302 = private constant [4 x i8] c"E10a"
@.d303 = private constant [66 x i8] c"Eq takes one parameter of its receiver's own type and gives a Bool"
@.d304 = private constant [85 x i8] c" takes what it is given read-only - neither its receiver nor a parameter may be 'mut'"
@.d305 = private constant [10 x i8] c"E10a, E11c"
@.d306 = private constant [3 x i8] c"R1a"
@.d307 = private constant [84 x i8] c"'?' alone is what the body can fail with - write '?', or name the types: '? IoError'"
@.d308 = private constant [132 x i8] c" is an error type, which has no values - an error is raised and caught, never held; tell its words apart with catch clauses ('catch "
@.d309 = private constant [11 x i8] c".WORD { }')"
@.d310 = private constant [3 x i8] c"T20"
@.d311 = private constant [31 x i8] c"this function does not declare "
@.d312 = private constant [19 x i8] c" - add it after '?'"
@.d313 = private constant [2 x i8] c"R3"
@.d314 = private constant [1 x i8] c"'"
@.d315 = private constant [55 x i8] c"' is an error word, not a value - raise it with 'error "
@.d316 = private constant [36 x i8] c"', tell it apart with a catch clause"
@.d317 = private constant [3 x i8] c"T20"
@.d318 = private constant [26 x i8] c"this function's '?' names "
@.d319 = private constant [34 x i8] c", not this word - add it after '?'"
@.d320 = private constant [2 x i8] c"R3"
@.d321 = private constant [2 x i8] c"\5Ct"
@.d322 = private constant [2 x i8] c"\5Cn"
@.d323 = private constant [2 x i8] c"\5Cr"
@.d324 = private constant [2 x i8] c"\5C0"
declare void @__olang_check_failed(ptr)
@.c325 = private unnamed_addr constant [50 x i8] c"compiler/msgs.olang:40: reached unreachable code\0A\00"
@.d326 = private constant [2 x i8] c"\5Cx"
@.d327 = private constant [9 x i8] c"expected "
@.d328 = private constant [8 x i8] c", found "
@.d329 = private constant [0 x i8] c""
@.d330 = private constant [4 x i8] c"B11a"
@.d331 = private constant [45 x i8] c"explain takes one rule, as 'olang explain B1'"
@.d332 = private constant [4 x i8] c"T29f"
@.d333 = private constant [54 x i8] c"only a type over a number or an array extends its base"
@.d334 = private constant [108 x i8] c" cannot cross the C boundary - an extern parameter or result is a number, or a parameter an array of numbers"
@.d335 = private constant [2 x i8] c"X2"
@.d336 = private constant [8 x i8] c"O23, O11"
@.d337 = private constant [122 x i8] c"this stores into a '&p' field whose binding is not known through this path - store through a variable holding the instance"
@.d338 = private constant [6 x i8] c"field "
@.d339 = private constant [87 x i8] c" has a parameter's name - write it bare to take the parameter's value, or name it apart"
@.d340 = private constant [3 x i8] c"C2a"
@.d341 = private constant [2 x i8] c"T8"
@.d342 = private constant [94 x i8] c"Array<T, N>() takes no arguments - a filled one is a copy, as 'a Array<T, N> = Array<T>(N, v)'"
@.d343 = private constant [22 x i8] c" is beyond F64's range"
@.d344 = private constant [4 x i8] c"L12b"
@.d345 = private constant [3 x i8] c"S9e"
@.d346 = private constant [104 x i8] c"a loop's catch clause runs after the loop has ended, so it has no loop to break or continue - set a flag"
@.d347 = private constant [116 x i8] c" is already declared, and a for-in declares new names - choose another, or to loop while it is in c write 'for { if "
@.d348 = private constant [22 x i8] c" not in c { break } }'"
@.d349 = private constant [8 x i8] c"D3a, E29"
@.d350 = private constant [3 x i8] c"S9e"
@.d351 = private constant [90 x i8] c"this loop's own calls can fail - write 'for x in try c', with catch clauses after the body"
@.d352 = private constant [3 x i8] c"S9e"
@.d353 = private constant [59 x i8] c"nothing this loop calls by itself can fail - drop the 'try'"
@.d354 = private constant [95 x i8] c" is a method of the unsigned type of its float's width - convert first, as U64(x).F64FromBits()"
@.d355 = private constant [3 x i8] c"E33"
@.d356 = private constant [3 x i8] c"R1b"
@.d357 = private constant [82 x i8] c"a function type writes its error set - '? IoError' - since no body says what it is"
@.d358 = private constant [1 x i8] c"'"
@.d359 = private constant [102 x i8] c"' relates its arguments' scopes, which a call through a function value cannot check - call it directly"
@.d360 = private constant [4 x i8] c"T22a"
@.d361 = private constant [17 x i8] c"generic function "
@.d362 = private constant [25 x i8] c" is not a value - call it"
@.d363 = private constant [3 x i8] c"G12"
@.d364 = private constant [2 x i8] c"G6"
@.d365 = private constant [46 x i8] c"only a struct or a trait takes type parameters"
@.d366 = private constant [3 x i8] c"O1b"
@.d367 = private constant [103 x i8] c"a global holds only what lives as long as the program - store something built here, or another global's"
@.d368 = private constant [25 x i8] c"a guard is a Bool, found "
@.d369 = private constant [4 x i8] c"S13e"
@.d370 = private constant [2 x i8] c"B1"
@.d371 = private constant [27 x i8] c"help takes at most one mode"
@.d372 = private constant [68 x i8] c" cannot be written - only a local, a parameter or a 'mut' global can"
@.d373 = private constant [2 x i8] c"S6"
@.d374 = private constant [48 x i8] c"another import of this module is already named '"
@.d375 = private constant [32 x i8] c"' - give one an alias of its own"
@.d376 = private constant [2 x i8] c"M5"
@.d377 = private constant [1 x i8] c"'"
@.d378 = private constant [86 x i8] c"' is no identifier, so it cannot be this import's alias - write one: import Name \22...\22"
@.d379 = private constant [2 x i8] c"M4"
@.d380 = private constant [16 x i8] c"could not fetch "
@.d381 = private constant [45 x i8] c" with git - check the path and the connection"
@.d382 = private constant [4 x i8] c"M23a"
@.d383 = private constant [18 x i8] c"no .olang file at "
@.d384 = private constant [3 x i8] c"M23"
@.d385 = private constant [3 x i8] c"M23"
@.d386 = private constant [41 x i8] c"an import names its file without '.olang'"
@.d387 = private constant [7 x i8] c"import "
@.d388 = private constant [67 x i8] c" is private to its module - only a capitalized alias is re-exported"
@.d389 = private constant [3 x i8] c"M14"
@.d390 = private constant [28 x i8] c"this relative import leaves "
@.d391 = private constant [43 x i8] c" - name a module outside it by its own path"
@.d392 = private constant [3 x i8] c"M23"
@.d393 = private constant [31 x i8] c"olang.lock names no commit for "
@.d394 = private constant [41 x i8] c" - delete its line, or build with -update"
@.d395 = private constant [4 x i8] c"M23b"
@.d396 = private constant [48 x i8] c"could not fetch the commit olang.lock names for "
@.d397 = private constant [41 x i8] c" - delete its line, or build with -update"
@.d398 = private constant [10 x i8] c"M23b, M23c"
@.d399 = private constant [3 x i8] c"M23"
@.d400 = private constant [43 x i8] c"this import path is too long to name a file"
@.d401 = private constant [61 x i8] c" reaches a file another import of this module already reaches"
@.d402 = private constant [3 x i8] c"M16"
@.d403 = private constant [4 x i8] c"M23a"
@.d404 = private constant [97 x i8] c"a remote import's host, owner, repository and ref may hold only letters, digits, '.', '_' and '-'"
@.d405 = private constant [3 x i8] c"M23"
@.d406 = private constant [74 x i8] c"a remote import names a file in the repository: host/owner/repo[@ref]/path"
@.d407 = private constant [55 x i8] c" is a statement of its own, never part of an expression"
@.d408 = private constant [3 x i8] c"S3a"
@.d409 = private constant [30 x i8] c"an index is an integer, found "
@.d410 = private constant [3 x i8] c"E16"
@.d411 = private constant [6 x i8] c"index "
@.d412 = private constant [24 x i8] c" is outside the array's "
@.d413 = private constant [9 x i8] c" elements"
@.d414 = private constant [3 x i8] c"E16"
@.d415 = private constant [3 x i8] c"C2d"
@.d416 = private constant [162 x i8] c"this instance holds a reference to an argument it would outlive - make the argument where the instance goes, or the instance where the argument lives ('T&x(...)')"
@.d417 = private constant [3 x i8] c"C2d"
@.d418 = private constant [113 x i8] c"this instance would outlive what its '&p' field refers to - keep it in that block, or build it there ('T&x(...)')"
@.d419 = private constant [78 x i8] c" is beyond 64 bits - the largest decimal literal is U64's 18446744073709551615"
@.d420 = private constant [3 x i8] c"L10"
@.d421 = private constant [63 x i8] c" cannot be a reference - only a struct, an enum or an array can"
@.d422 = private constant [3 x i8] c"T24"
@.d423 = private constant [2 x i8] c"'&"
@.d424 = private constant [89 x i8] c"' after the type is read as a reference marker, not the operator '&' - parenthesize: '(x "
@.d425 = private constant [6 x i8] c" T) & "
@.d426 = private constant [1 x i8] c"'"
@.d427 = private constant [3 x i8] c"E32"
@.d428 = private constant [59 x i8] c"'is' and 'as' ask which case an enum value is, and this is "
@.d429 = private constant [3 x i8] c"E32"
@.d430 = private constant [2 x i8] c"M1"
@.d431 = private constant [41 x i8] c"a directory - a module is one .olang file"
@.d432 = private constant [5 x i8] c" and "
@.d433 = private constant [53 x i8] c" are different types, so they never name one instance"
@.d434 = private constant [4 x i8] c"E10c"
@.d435 = private constant [60 x i8] c"'a is b' asks whether two references name one instance, and "
@.d436 = private constant [5 x i8] c" and "
@.d437 = private constant [24 x i8] c" are not both references"
@.d438 = private constant [4 x i8] c"E10c"
@.d439 = private constant [3 x i8] c"P4c"
@.d440 = private constant [46 x i8] c"no task of this join can fail - drop the 'try'"
@.d441 = private constant [3 x i8] c"P4c"
@.d442 = private constant [79 x i8] c"a join takes catch clauses only as 'try join', and no task of this one can fail"
@.d443 = private constant [3 x i8] c"P4d"
@.d444 = private constant [93 x i8] c"a task of this join binds a target it leaves unwritten when it fails - this clause must leave"
@.d445 = private constant [8 x i8] c"S3, E11b"
@.d446 = private constant [100 x i8] c"text on a line of its own does nothing - a join continues onto the next line only inside parentheses"
@.d447 = private constant [32 x i8] c"this join's tasks can fail with "
@.d448 = private constant [64 x i8] c" - write 'try join', with catch clauses for what it handles here"
@.d449 = private constant [3 x i8] c"P4c"
@.d450 = private constant [60 x i8] c"a join piece is a text literal or a '$' rendering - write '$"
@.d451 = private constant [1 x i8] c"'"
@.d452 = private constant [4 x i8] c"E11b"
@.d453 = private constant [4 x i8] c"E11b"
@.d454 = private constant [77 x i8] c"'(' after a piece of text calls it - to join the value inside, write '$(...)'"
@.d455 = private constant [3 x i8] c"P1a"
@.d456 = private constant [49 x i8] c"this join spawns nothing, so it waits for nothing"
@.d457 = private constant [42 x i8] c" is a keyword, not a name - choose another"
@.d458 = private constant [2 x i8] c"L9"
@.d459 = private constant [99 x i8] c" is a keyword, not a name - a field named by one is reached only after '.', never by the name alone"
@.d460 = private constant [3 x i8] c"L9a"
@.d461 = private constant [7 x i8] c" takes "
@.d462 = private constant [10 x i8] c" parameter"
@.d463 = private constant [18 x i8] c", and this lambda "
@.d464 = private constant [4 x i8] c"D16a"
@.d465 = private constant [17 x i8] c"lambda parameter "
@.d466 = private constant [49 x i8] c" has no type, and nothing gives it one - write it"
@.d467 = private constant [4 x i8] c"D16a"
@.d468 = private constant [18 x i8] c"this result binds "
@.d469 = private constant [4 x i8] c" to "
@.d470 = private constant [94 x i8] c", which the call holds in an array, where an array is held by reference - write the result as "
@.d471 = private constant [1 x i8] c"&"
@.d472 = private constant [3 x i8] c"T7a"
@.d473 = private constant [4 x i8] c"D16b"
@.d474 = private constant [54 x i8] c"this value gives the lambda no result type - write one"
@.d475 = private constant [39 x i8] c"this lambda's signature disagrees with "
@.d476 = private constant [42 x i8] c" - leave that part out, or make them agree"
@.d477 = private constant [4 x i8] c"D16a"
@.d478 = private constant [19 x i8] c"this lambda keeps '"
@.d479 = private constant [91 x i8] c"' beyond the call, which a call through a function value cannot check - keep a copy instead"
@.d480 = private constant [4 x i8] c"T22a"
@.d481 = private constant [4 x i8] c"T22a"
@.d482 = private constant [93 x i8] c"this lambda relates its arguments' scopes, which a call through a function value cannot check"
@.d483 = private constant [3 x i8] c"E31"
@.d484 = private constant [16 x i8] c"Len gives an I64"
@.d485 = private constant [3 x i8] c"E31"
@.d486 = private constant [35 x i8] c"Less, which '<' calls, gives a Bool"
@.d487 = private constant [25 x i8] c"a line cannot begin with "
@.d488 = private constant [59 x i8] c" - the line before ended its statement; end that line with "
@.d489 = private constant [38 x i8] c", or put the expression in parentheses"
@.d490 = private constant [3 x i8] c"L18"
@.d491 = private constant [8 x i8] c"linking "
@.d492 = private constant [7 x i8] c" failed"
@.d493 = private constant [0 x i8] c""
@.d494 = private constant [26 x i8] c"this literal does not fit "
@.d495 = private constant [6 x i8] c", and "
@.d496 = private constant [20 x i8] c" does not flow into "
@.d497 = private constant [14 x i8] c" - convert one"
@.d498 = private constant [3 x i8] c"E6d"
@.d499 = private constant [45 x i8] c"this literal expression's value does not fit "
@.d500 = private constant [3 x i8] c"E4a"
@.d501 = private constant [14 x i8] c" does not fit "
@.d502 = private constant [2 x i8] c"T6"
@.d503 = private constant [5 x i8] c"case "
@.d504 = private constant [4 x i8] c" of "
@.d505 = private constant [42 x i8] c" is not covered - add it, or 'nomatch { }'"
@.d506 = private constant [4 x i8] c"S13a"
@.d507 = private constant [13 x i8] c"a match over "
@.d508 = private constant [73 x i8] c" gives a value only when its cases cover every value - add 'nomatch => v'"
@.d509 = private constant [4 x i8] c"S12b"
@.d510 = private constant [9 x i8] c"S12b, D8c"
@.d511 = private constant [116 x i8] c"a match gives one value - to give several, return them from each case of a match statement: 'case P { return a, b }'"
@.d512 = private constant [29 x i8] c"every value of this match is "
@.d513 = private constant [8 x i8] c", found "
@.d514 = private constant [4 x i8] c"S12b"
@.d515 = private constant [33 x i8] c"'@' has no built-in meaning, and "
@.d516 = private constant [19 x i8] c" declares no MatMul"
@.d517 = private constant [3 x i8] c"E31"
@.d518 = private constant [37 x i8] c" can fail here - write 'try (x in c)'"
@.d519 = private constant [3 x i8] c"E29"
@.d520 = private constant [15 x i8] c"'x in c' calls "
@.d521 = private constant [6 x i8] c", and "
@.d522 = private constant [9 x i8] c" has none"
@.d523 = private constant [3 x i8] c"E29"
@.d524 = private constant [70 x i8] c" cannot fail - the operation calling it has nowhere to handle an error"
@.d525 = private constant [3 x i8] c"E31"
@.d526 = private constant [19 x i8] c" inherits a method "
@.d527 = private constant [36 x i8] c" from its base - choose another name"
@.d528 = private constant [4 x i8] c"T29e"
@.d529 = private constant [22 x i8] c"the compiler supplies "
@.d530 = private constant [5 x i8] c" for "
@.d531 = private constant [22 x i8] c" - choose another name"
@.d532 = private constant [12 x i8] c"E23, E33, P9"
@.d533 = private constant [13 x i8] c" declares no "
@.d534 = private constant [73 x i8] c", and does not extend its base, which has one - declare it with 'extends'"
@.d535 = private constant [4 x i8] c"T29f"
@.d536 = private constant [37 x i8] c"only the prelude declares methods of "
@.d537 = private constant [59 x i8] c" - declare a type of your own over it: 'type T extends ...'"
@.d538 = private constant [4 x i8] c"M19d"
@.d539 = private constant [41 x i8] c"the end can be reached without returning "
@.d540 = private constant [53 x i8] c" - return on every path, or end it with 'unreachable'"
@.d541 = private constant [4 x i8] c"D10a"
@.d542 = private constant [29 x i8] c"the mode comes first: 'olang "
@.d543 = private constant [22 x i8] c"' and then its options"
@.d544 = private constant [2 x i8] c"B1"
@.d545 = private constant [13 x i8] c" needs a file"
@.d546 = private constant [2 x i8] c"B1"
@.d547 = private constant [23 x i8] c" takes exactly one file"
@.d548 = private constant [2 x i8] c"B1"
@.d549 = private constant [4 x i8] c"D11a"
@.d550 = private constant [99 x i8] c"':=' gives a local its initializer's permission - remove 'mut', or write the type: 'x mut T& = ...'"
@.d551 = private constant [59 x i8] c"a local is always writable - 'mut' is for a reference, and "
@.d552 = private constant [8 x i8] c" is none"
@.d553 = private constant [4 x i8] c"D11a"
@.d554 = private constant [77 x i8] c"a field is writable wherever its instance is - 'mut' is for a reference, and "
@.d555 = private constant [8 x i8] c" is none"
@.d556 = private constant [2 x i8] c"C3"
@.d557 = private constant [95 x i8] c"a by-value parameter is the callee's own copy, always writable - 'mut' is for a reference, and "
@.d558 = private constant [8 x i8] c" is none"
@.d559 = private constant [2 x i8] c"D9"
@.d560 = private constant [38 x i8] c"'mut' makes a reference writable, and "
@.d561 = private constant [16 x i8] c" is no reference"
@.d562 = private constant [4 x i8] c"T25b"
@.d563 = private constant [57 x i8] c" is an import's alias in this module - rename one of them"
@.d564 = private constant [3 x i8] c"M20"
@.d565 = private constant [35 x i8] c" is already declared in this module"
@.d566 = private constant [2 x i8] c"D2"
@.d567 = private constant [57 x i8] c" is already a type's name in this module - choose another"
@.d568 = private constant [2 x i8] c"D2"
@.d569 = private constant [3 x i8] c"T24"
@.d570 = private constant [73 x i8] c"a nested reference lives in its container's scope - write a bare '&' here"
@.d571 = private constant [17 x i8] c"nested more than "
@.d572 = private constant [48 x i8] c" levels deep - split it into locals or functions"
@.d573 = private constant [3 x i8] c"L21"
@.d574 = private constant [57 x i8] c"clang not found on PATH - install clang-20 (the IR is in "
@.d575 = private constant [1 x i8] c")"
@.d576 = private constant [0 x i8] c""
@.d577 = private constant [30 x i8] c"the specification has no rule "
@.d578 = private constant [4 x i8] c"B11a"
@.d579 = private constant [20 x i8] c"no specification at "
@.d580 = private constant [4 x i8] c"B11a"
@.d581 = private constant [13 x i8] c" has no case "
@.d582 = private constant [3 x i8] c"T17"
@.d583 = private constant [13 x i8] c" has no case "
@.d584 = private constant [17 x i8] c" - did you mean '"
@.d585 = private constant [2 x i8] c"'?"
@.d586 = private constant [3 x i8] c"T17"
@.d587 = private constant [16 x i8] c" has no member '"
@.d588 = private constant [1 x i8] c"'"
@.d589 = private constant [0 x i8] c""
@.d590 = private constant [3 x i8] c"D8e"
@.d591 = private constant [90 x i8] c"a 'noreturn' function never returns to its caller, so it fails with nothing - drop the '?'"
@.d592 = private constant [3 x i8] c"D8e"
@.d593 = private constant [109 x i8] c"a 'noreturn' function may not reach its end - end every path with a noreturn call, 'unreachable' or 'for { }'"
@.d594 = private constant [21 x i8] c" cannot be 'noreturn'"
@.d595 = private constant [3 x i8] c"D8e"
@.d596 = private constant [1 x i8] c"'"
@.d597 = private constant [135 x i8] c"' is not a mode - the modes are build, compile, test, interpret, format, explain and help, and a file ending in .olang is built and run"
@.d598 = private constant [2 x i8] c"B1"
@.d599 = private constant [1 x i8] c"'"
@.d600 = private constant [56 x i8] c"' is no olang file to run - a file's name ends in .olang"
@.d601 = private constant [2 x i8] c"B1"
@.d602 = private constant [2 x i8] c"S3"
@.d603 = private constant [78 x i8] c"this computes a value and discards it - only a call, '++' or '--' stands alone"
@.d604 = private constant [2 x i8] c"S4"
@.d605 = private constant [63 x i8] c"this cannot be written - a variable, an element or a member can"
@.d606 = private constant [40 x i8] c" is not a function, and declares no Call"
@.d607 = private constant [4 x i8] c"E13b"
@.d608 = private constant [42 x i8] c" does not extend its base, so it takes no "
@.d609 = private constant [22 x i8] c" - declare its method "
@.d610 = private constant [30 x i8] c", or declare it with 'extends'"
@.d611 = private constant [4 x i8] c"T29f"
@.d612 = private constant [18 x i8] c" cannot be indexed"
@.d613 = private constant [3 x i8] c"E16"
@.d614 = private constant [120 x i8] c" cannot be walked - 'for ... in' takes an array, a range, an iterator ('mut Next() T ? Exhausted') or a type with Iter()"
@.d615 = private constant [3 x i8] c"S9a"
@.d616 = private constant [0 x i8] c""
@.d617 = private constant [18 x i8] c"not a regular file"
@.d618 = private constant [3 x i8] c"'s "
@.d619 = private constant [7 x i8] c" takes "
@.d620 = private constant [56 x i8] c" besides its receiver - an ordinary method, not the one "
@.d621 = private constant [20 x i8] c" calls, which takes "
@.d622 = private constant [3 x i8] c"E31"
@.d623 = private constant [17 x i8] c" is declared here"
@.d624 = private constant [0 x i8] c""
@.d625 = private constant [102 x i8] c"a function type says where each reference argument and the result live, as the function does - write '"
@.d626 = private constant [30 x i8] c"', or pass a lambda calling it"
@.d627 = private constant [0 x i8] c""
@.d628 = private constant [0 x i8] c""
@.d629 = private constant [4 x i8] c"here"
@.d630 = private constant [0 x i8] c""
@.d631 = private constant [36 x i8] c"in the standard library's code, here"
@.d632 = private constant [1 x i8] c"'"
@.d633 = private constant [89 x i8] c"' is the loop's copy of an element, made in the loop's block - lend the element itself: '"
@.d634 = private constant [27 x i8] c"[i]', with 'for i in range "
@.d635 = private constant [7 x i8] c".Len()'"
@.d636 = private constant [0 x i8] c""
@.d637 = private constant [1 x i8] c"'"
@.d638 = private constant [185 x i8] c"' is the loop's copy of an element, in the loop's block - a call it is lent to by reference ties what it builds to that copy: take that parameter by value, or build from its fields here"
@.d639 = private constant [0 x i8] c""
@.d640 = private constant [0 x i8] c""
@.d641 = private constant [48 x i8] c"the callee requires it because of this statement"
@.d642 = private constant [1 x i8] c"'"
@.d643 = private constant [42 x i8] c"' is declared here, with another signature"
@.d644 = private constant [0 x i8] c""
@.d645 = private constant [1 x i8] c"'"
@.d646 = private constant [46 x i8] c"' is private to its module, and only a public "
@.d647 = private constant [21 x i8] c" meets the constraint"
@.d648 = private constant [0 x i8] c""
@.d649 = private constant [1 x i8] c"'"
@.d650 = private constant [54 x i8] c"' copies a place reached read-only, so it is read-only"
@.d651 = private constant [0 x i8] c""
@.d652 = private constant [1 x i8] c"'"
@.d653 = private constant [10 x i8] c"' copies '"
@.d654 = private constant [44 x i8] c"', reached read-only, so it is read-only - '"
@.d655 = private constant [4 x i8] c" := "
@.d656 = private constant [33 x i8] c".Clone()' would be one of its own"
@.d657 = private constant [0 x i8] c""
@.d658 = private constant [0 x i8] c""
@.d659 = private constant [145 x i8] c"this borrows a value made here, which lives only in this block - make the value where the borrow is kept ('x T&c = ...'), then slice or view that"
@.d660 = private constant [0 x i8] c""
@.d661 = private constant [57 x i8] c"built here, where the receiver's part it was handed lives"
@.d662 = private constant [1 x i8] c"'"
@.d663 = private constant [20 x i8] c"' may grow here, in "
@.d664 = private constant [56 x i8] c" - take the view after it, or copy the elements first: '"
@.d665 = private constant [11 x i8] c".ToArray()'"
@.d666 = private constant [0 x i8] c""
@.d667 = private constant [17 x i8] c" may grow it here"
@.d668 = private constant [0 x i8] c""
@.d669 = private constant [28 x i8] c"the task holding a view of '"
@.d670 = private constant [17 x i8] c"' is started here"
@.d671 = private constant [0 x i8] c""
@.d672 = private constant [20 x i8] c" does not flow into "
@.d673 = private constant [18 x i8] c" - convert it, as "
@.d674 = private constant [3 x i8] c"(x)"
@.d675 = private constant [3 x i8] c"T6b"
@.d676 = private constant [5 x i8] c" and "
@.d677 = private constant [56 x i8] c" do not meet - neither flows into the other; convert one"
@.d678 = private constant [3 x i8] c"T6b"
@.d679 = private constant [21 x i8] c" takes a Bool, found "
@.d680 = private constant [2 x i8] c"E7"
@.d681 = private constant [25 x i8] c" takes an integer, found "
@.d682 = private constant [2 x i8] c"E8"
@.d683 = private constant [22 x i8] c" takes numbers, found "
@.d684 = private constant [2 x i8] c"E6"
@.d685 = private constant [35 x i8] c" takes operands of one type, found "
@.d686 = private constant [5 x i8] c" and "
@.d687 = private constant [0 x i8] c""
@.d688 = private constant [20 x i8] c"this operator calls "
@.d689 = private constant [52 x i8] c", which can fail - write 'try' before the expression"
@.d690 = private constant [3 x i8] c"E31"
@.d691 = private constant [17 x i8] c" gives one result"
@.d692 = private constant [3 x i8] c"E31"
@.d693 = private constant [25 x i8] c" needs a value after it: "
@.d694 = private constant [2 x i8] c"B1"
@.d695 = private constant [12 x i8] c" applies to "
@.d696 = private constant [9 x i8] c", not to "
@.d697 = private constant [2 x i8] c"B1"
@.d698 = private constant [3 x i8] c"B3h"
@.d699 = private constant [15 x i8] c"cannot write it"
@.d700 = private constant [8 x i8] c"-output "
@.d701 = private constant [40 x i8] c" is a directory - name the file to write"
@.d702 = private constant [3 x i8] c"B3h"
@.d703 = private constant [8 x i8] c"-output "
@.d704 = private constant [24 x i8] c": there is no directory "
@.d705 = private constant [3 x i8] c"B3h"
@.d706 = private constant [91 x i8] c" does not have the signature of the default it overrides - match it, or choose another name"
@.d707 = private constant [4 x i8] c"M19e"
@.d708 = private constant [4 x i8] c"O10d"
@.d709 = private constant [65 x i8] c"this value lives in this function's own scope, which closes first"
@.d710 = private constant [31 x i8] c"a pattern here names a case of "
@.d711 = private constant [8 x i8] c", found "
@.d712 = private constant [4 x i8] c"S13b"
@.d713 = private constant [4 x i8] c"T17c"
@.d714 = private constant [106 x i8] c"this value's payload refers to storage the value would outlive - make that storage where the value is kept"
@.d715 = private constant [51 x i8] c" is a constant of the prelude - choose another name"
@.d716 = private constant [3 x i8] c"D3a"
@.d717 = private constant [10 x i8] c" declares "
@.d718 = private constant [39 x i8] c" twice, public and private - keep one: "
@.d719 = private constant [5 x i8] c", or "
@.d720 = private constant [24 x i8] c" for its own module only"
@.d721 = private constant [3 x i8] c"M6b"
@.d722 = private constant [7 x i8] c" needs "
@.d723 = private constant [3 x i8] c"'s "
@.d724 = private constant [46 x i8] c", which is private to its module - declare it "
@.d725 = private constant [15 x i8] c" to use it here"
@.d726 = private constant [3 x i8] c"M6b"
@.d727 = private constant [46 x i8] c"a range's bounds and step are integers, found "
@.d728 = private constant [3 x i8] c"S9b"
@.d729 = private constant [3 x i8] c"S9b"
@.d730 = private constant [51 x i8] c"a range only counts upward, so its step is positive"
@.d731 = private constant [1 x i8] c"'"
@.d732 = private constant [41 x i8] c"' writes through or keeps its parameter '"
@.d733 = private constant [12 x i8] c"', and this "
@.d734 = private constant [49 x i8] c" is a read-only copy - pass one of its own, made "
@.d735 = private constant [4 x i8] c"T25c"
@.d736 = private constant [24 x i8] c"this copies a read-only "
@.d737 = private constant [134 x i8] c", and a written type declares a writable one - declare it with ':=' for a read-only copy, borrow it read-only, or make one of its own "
@.d738 = private constant [4 x i8] c"T25c"
@.d739 = private constant [46 x i8] c"a mutable global holds no copy of a read-only "
@.d740 = private constant [32 x i8] c" - give it one of its own, made "
@.d741 = private constant [19 x i8] c", or drop its 'mut'"
@.d742 = private constant [4 x i8] c"T25c"
@.d743 = private constant [86 x i8] c"a read-only copy cannot be passed where it may be written - pass one of its own, made "
@.d744 = private constant [4 x i8] c"T25c"
@.d745 = private constant [22 x i8] c"a copy of a read-only "
@.d746 = private constant [70 x i8] c" cannot be returned as a writable value - return one of its own, made "
@.d747 = private constant [26 x i8] c", or a read-only reference"
@.d748 = private constant [4 x i8] c"T25c"
@.d749 = private constant [22 x i8] c"a copy of a read-only "
@.d750 = private constant [71 x i8] c" cannot be stored where it can be written - store one of its own, made "
@.d751 = private constant [4 x i8] c"T25c"
@.d752 = private constant [4 x i8] c"T25c"
@.d753 = private constant [117 x i8] c"this writes through a reference a read-only copy holds - a copy of a place reached read-only writes nothing it shares"
@.d754 = private constant [49 x i8] c" writes through or keeps its by-value parameter '"
@.d755 = private constant [110 x i8] c"', so it cannot be a function value - a caller of one may pass a read-only copy; work on one of its own, made "
@.d756 = private constant [4 x i8] c"T25c"
@.d757 = private constant [1 x i8] c"'"
@.d758 = private constant [28 x i8] c"' keeps what its parameter '"
@.d759 = private constant [44 x i8] c"' reaches where it can be written, and this "
@.d760 = private constant [35 x i8] c" is read-only - pass a writable one"
@.d761 = private constant [4 x i8] c"T25c"
@.d762 = private constant [4 x i8] c"T25b"
@.d763 = private constant [73 x i8] c"this writes through a read-only reference - one with no 'mut' in its type"
@.d764 = private constant [90 x i8] c"a built result is new storage and writable, and this reference is read-only - borrow it: '"
@.d765 = private constant [1 x i8] c"'"
@.d766 = private constant [9 x i8] c"T25c, O14"
@.d767 = private constant [9 x i8] c"T25c, O14"
@.d768 = private constant [151 x i8] c"a built result is new storage and writable, and this reference is read-only - return a copy, or borrow the result from the parameter it is read through"
@.d769 = private constant [4 x i8] c"T25c"
@.d770 = private constant [85 x i8] c"a read-only reference cannot become writable - pass a writable one, or drop the 'mut'"
@.d771 = private constant [13 x i8] c"re-exporting "
@.d772 = private constant [26 x i8] c" reaches this module again"
@.d773 = private constant [3 x i8] c"M17"
@.d774 = private constant [3 x i8] c"O25"
@.d775 = private constant [98 x i8] c"a reference never narrows - keep its scope: name where it lives ('x T&y'), or declare it with ':='"
@.d776 = private constant [29 x i8] c"a reference never narrows - '"
@.d777 = private constant [62 x i8] c"' lives in a block that closes first, and this keeps it longer"
@.d778 = private constant [3 x i8] c"O25"
@.d779 = private constant [3 x i8] c"O14"
@.d780 = private constant [86 x i8] c"this returns a parameter's data, and the result's bare '&' is built - borrow it: 'T&p'"
@.d781 = private constant [3 x i8] c"C2b"
@.d782 = private constant [77 x i8] c"a constructor gives no value - its fields are the instance; fail with 'error'"
@.d783 = private constant [3 x i8] c"D8e"
@.d784 = private constant [89 x i8] c"a 'noreturn' function never returns - end this path with a noreturn call or 'unreachable'"
@.d785 = private constant [3 x i8] c"S15"
@.d786 = private constant [56 x i8] c"a test has no result - a bare 'return' ends it as passed"
@.d787 = private constant [22 x i8] c"this function returns "
@.d788 = private constant [27 x i8] c", so 'return' needs a value"
@.d789 = private constant [2 x i8] c"D8"
@.d790 = private constant [3 x i8] c"O26"
@.d791 = private constant [98 x i8] c"this value refers to this function's own storage, which dies at the return - build it in '&return'"
@.d792 = private constant [2 x i8] c"D8"
@.d793 = private constant [30 x i8] c"this function returns no value"
@.d794 = private constant [100 x i8] c" lives in the program's scope, which a result reaches by being stored there, not by a scope argument"
@.d795 = private constant [8 x i8] c"E25, O1b"
@.d796 = private constant [4 x i8] c"O25e"
@.d797 = private constant [79 x i8] c"these arguments live in different scopes, and the signature requires one ('&p')"
@.d798 = private constant [2 x i8] c"O3"
@.d799 = private constant [78 x i8] c"a scope has no name to declare - write a bare '&', or '&x' for where 'x' lives"
@.d800 = private constant [3 x i8] c"O10"
@.d801 = private constant [68 x i8] c"this reference lives in a scope that may not outlive where it is put"
@.d802 = private constant [4 x i8] c"O10c"
@.d803 = private constant [112 x i8] c"the callee needs one argument's scope to outlive another's, and nothing here shows it - pass them from one scope"
@.d804 = private constant [3 x i8] c"E31"
@.d805 = private constant [21 x i8] c"SetAt gives no result"
@.d806 = private constant [48 x i8] c" declares At but not SetAt, which x[i] = v calls"
@.d807 = private constant [3 x i8] c"E31"
@.d808 = private constant [42 x i8] c" is a build constant - choose another name"
@.d809 = private constant [3 x i8] c"D3a"
@.d810 = private constant [83 x i8] c" names a function of this module - a name means one thing in it, so name this apart"
@.d811 = private constant [3 x i8] c"D3a"
@.d812 = private constant [66 x i8] c" is already declared in this module - a name means one thing in it"
@.d813 = private constant [3 x i8] c"D3a"
@.d814 = private constant [34 x i8] c" is a type's name - choose another"
@.d815 = private constant [3 x i8] c"D3a"
@.d816 = private constant [8 x i8] c"E8a, E4a"
@.d817 = private constant [116 x i8] c"this shift is past its literal's width, and nothing adapts it to a wider type - convert the literal, as I64(1) << 40"
@.d818 = private constant [4 x i8] c"O17a"
@.d819 = private constant [143 x i8] c"this value's references live where its own storage does not, so it is not sliced or viewed - index the value itself, or lend it whole to a call"
@.d820 = private constant [2 x i8] c"P2"
@.d821 = private constant [108 x i8] c"this argument refers to storage that closes before the join does - declare that at the join's level or wider"
@.d822 = private constant [2 x i8] c"P2"
@.d823 = private constant [93 x i8] c"this argument's storage closes before the join does - declare it at the join's level or wider"
@.d824 = private constant [8 x i8] c"E31b, P2"
@.d825 = private constant [173 x i8] c"a task is not handed x[i]: the element is copied here, and the copy would not last until the join - spawn a function that takes the collection and calls 'x[i].M(...)' itself"
@.d826 = private constant [8 x i8] c"P2, D16e"
@.d827 = private constant [93 x i8] c"this lambda captures a variable declared inside the join, which closes while the task may run"
@.d828 = private constant [2 x i8] c"P4"
@.d829 = private constant [89 x i8] c"this call can fail - write 'spawn try', and what its clauses do not take reaches the join"
@.d830 = private constant [8 x i8] c"P2, D16e"
@.d831 = private constant [93 x i8] c"this function value closes before the join does - make it outside, or spawn the lambda itself"
@.d832 = private constant [9 x i8] c"S19b, P1a"
@.d833 = private constant [66 x i8] c"a spawn in deferred code needs a join written in the deferred code"
@.d834 = private constant [4 x i8] c"D16e"
@.d835 = private constant [64 x i8] c"a spawned lambda takes no parameters - it captures what it needs"
@.d836 = private constant [2 x i8] c"P1"
@.d837 = private constant [20 x i8] c"'spawn' takes a call"
@.d838 = private constant [2 x i8] c"P1"
@.d839 = private constant [66 x i8] c"'spawn' is written inside a 'join' block, which waits for the task"
@.d840 = private constant [3 x i8] c"P1g"
@.d841 = private constant [81 x i8] c"this target closes before the join does - declare it at the join's level or wider"
@.d842 = private constant [43 x i8] c"a spawn target has exactly the call's type "
@.d843 = private constant [8 x i8] c", found "
@.d844 = private constant [25 x i8] c" - convert after the join"
@.d845 = private constant [3 x i8] c"P1g"
@.d846 = private constant [3 x i8] c"P1g"
@.d847 = private constant [51 x i8] c"this call returns nothing to bind - drop the target"
@.d848 = private constant [2 x i8] c"P4"
@.d849 = private constant [38 x i8] c"this task cannot fail - drop the 'try'"
@.d850 = private constant [3 x i8] c"D8d"
@.d851 = private constant [107 x i8] c"these results are passed as the arguments, so there must be as many - destructure them first: 'a, b := g()'"
@.d852 = private constant [3 x i8] c"O12"
@.d853 = private constant [146 x i8] c"where this place's references live is not known here, so nothing new is built into it - store what already lives there, or give it one known scope"
@.d854 = private constant [3 x i8] c"O20"
@.d855 = private constant [101 x i8] c"the container outlives what this refers to - build it where the container lives ('x T&c', 'f&c(...)')"
@.d856 = private constant [4 x i8] c"E11a"
@.d857 = private constant [54 x i8] c"'$' has nothing to render - this call returns no value"
@.d858 = private constant [10 x i8] c"E11c, T25c"
@.d859 = private constant [98 x i8] c"'$' renders read-only values too, so Str only reads its receiver - pass on what it holds read-only"
@.d860 = private constant [4 x i8] c"E11c"
@.d861 = private constant [18 x i8] c"Str gives a String"
@.d862 = private constant [9 x i8] c"E11c, O12"
@.d863 = private constant [148 x i8] c"'$' does not say where a value it renders lives, so Str builds and stores nothing where its receiver reaches - read it, and build what it needs here"
@.d864 = private constant [6 x i8] c"where "
@.d865 = private constant [81 x i8] c" lives is not known here, so nothing is declared to live there - read it through "
@.d866 = private constant [32 x i8] c", or declare the local with ':='"
@.d867 = private constant [3 x i8] c"O12"
@.d868 = private constant [19 x i8] c" takes no arguments"
@.d869 = private constant [3 x i8] c"E14"
@.d870 = private constant [47 x i8] c" builds and runs on this machine, and '-target "
@.d871 = private constant [64 x i8] c"' is another architecture or system - only compile builds for it"
@.d872 = private constant [4 x i8] c"B12a"
@.d873 = private constant [9 x i8] c"'-target "
@.d874 = private constant [102 x i8] c"': native is this machine's CPU - name the other architecture's CPU after ':', or none for its default"
@.d875 = private constant [3 x i8] c"B12"
@.d876 = private constant [29 x i8] c"this clang cannot build for '"
@.d877 = private constant [85 x i8] c"': its back end for that architecture cannot generate the BF16 code the runtime holds"
@.d878 = private constant [4 x i8] c"B12a"
@.d879 = private constant [84 x i8] c"clang not found on PATH - it is what builds the program, and what says what target '"
@.d880 = private constant [4 x i8] c"' is"
@.d881 = private constant [3 x i8] c"B12"
@.d882 = private constant [16 x i8] c"unknown target '"
@.d883 = private constant [187 x i8] c"' - write native, x86-64, x86-64-v2, x86-64-v3, x86-64-v4, a CPU clang knows ('clang --print-supported-cpus'), or a triple x86_64-linux-gnu or aarch64-linux-gnu, ':CPU' after it if wanted"
@.d884 = private constant [3 x i8] c"B12"
@.d885 = private constant [26 x i8] c"olang does not build for '"
@.d886 = private constant [65 x i8] c"' - it builds for x86_64 and aarch64 Linux with the GNU C library"
@.d887 = private constant [3 x i8] c"B12"
@.d888 = private constant [3 x i8] c"P4a"
@.d889 = private constant [106 x i8] c"an error may not leave a task's clause - catch it here; the task lets through what its clauses do not take"
@.d890 = private constant [81 x i8] c" may not leave a task's clause - it runs on the task, outside the spawner's loops"
@.d891 = private constant [3 x i8] c"P4a"
@.d892 = private constant [3 x i8] c"P4a"
@.d893 = private constant [107 x i8] c"this clause takes an error the targets would get no value for - end it with 'default v', or end the process"
@.d894 = private constant [3 x i8] c"P4a"
@.d895 = private constant [82 x i8] c"a task's clause runs on the task and may not return - it ends where its block does"
@.d896 = private constant [3 x i8] c"P4a"
@.d897 = private constant [118 x i8] c"a task's default is built where its result lands, and this names existing storage - build the value here, or give null"
@.d898 = private constant [3 x i8] c"P4a"
@.d899 = private constant [70 x i8] c"a spawn without targets gives no value, so its clauses take no default"
@.d900 = private constant [15 x i8] c"a comma before "
@.d901 = private constant [30 x i8] c" separates nothing - remove it"
@.d902 = private constant [4 x i8] c"L18a"
@.d903 = private constant [3 x i8] c"R1b"
@.d904 = private constant [83 x i8] c"a trait's method writes its error set - '? IoError' - since no body says what it is"
@.d905 = private constant [72 x i8] c" is a trait - a constraint on a type variable, never the type of a value"
@.d906 = private constant [3 x i8] c"T30"
@.d907 = private constant [87 x i8] c" can escape here, and this function does not declare it - add it after '?', or catch it"
@.d908 = private constant [2 x i8] c"R9"
@.d909 = private constant [39 x i8] c"'checked c[i]' checks against Len, and "
@.d910 = private constant [30 x i8] c" has neither CheckedAt nor Len"
@.d911 = private constant [4 x i8] c"E31a"
@.d912 = private constant [35 x i8] c"'checked' on several indices needs "
@.d913 = private constant [12 x i8] c" to declare "
@.d914 = private constant [47 x i8] c" - a check derived from Len checks one position"
@.d915 = private constant [4 x i8] c"E31a"
@.d916 = private constant [42 x i8] c"nothing here can fail - write it without '"
@.d917 = private constant [1 x i8] c"'"
@.d918 = private constant [2 x i8] c"R8"
@.d919 = private constant [3 x i8] c"R13"
@.d920 = private constant [65 x i8] c"an error tried here has nowhere to go - catch every one it can be"
@.d921 = private constant [4 x i8] c"E15a"
@.d922 = private constant [59 x i8] c"nothing here fails as written - write 'checked' to check it"
@.d923 = private constant [43 x i8] c"'checked c[i] = v' checks against Len, and "
@.d924 = private constant [33 x i8] c" has neither CheckedSetAt nor Len"
@.d925 = private constant [4 x i8] c"E31a"
@.d926 = private constant [43 x i8] c"'checked c[lo:hi]' checks against Len, and "
@.d927 = private constant [33 x i8] c" has neither CheckedSlice nor Len"
@.d928 = private constant [4 x i8] c"E31a"
@.d929 = private constant [3 x i8] c"D8c"
@.d930 = private constant [111 x i8] c"several results are not one value - destructure them ('a, b := f()'), or pass them as all of a call's arguments"
@.d931 = private constant [19 x i8] c"type arguments for "
@.d932 = private constant [11 x i8] c": expected "
@.d933 = private constant [8 x i8] c", found "
@.d934 = private constant [2 x i8] c"G7"
@.d935 = private constant [3 x i8] c"G11"
@.d936 = private constant [101 x i8] c"a type argument's reference marker is bare, as 'List<String&>' - its references live in the container"
@.d937 = private constant [22 x i8] c"the type arguments of "
@.d938 = private constant [40 x i8] c" cannot be inferred from these arguments"
@.d939 = private constant [2 x i8] c"G9"
@.d940 = private constant [46 x i8] c" is not generic, so it takes no type arguments"
@.d941 = private constant [2 x i8] c"G7"
@.d942 = private constant [64 x i8] c" cannot hold itself by value - hold it through a reference ('&')"
@.d943 = private constant [3 x i8] c"T16"
@.d944 = private constant [4 x i8] c"S13e"
@.d945 = private constant [100 x i8] c"a type match chooses its case while compiling, so it takes no guard - test the value inside the case"
@.d946 = private constant [15 x i8] c"no case covers "
@.d947 = private constant [65 x i8] c", which this generic is instantiated with - add one, or 'nomatch'"
@.d948 = private constant [3 x i8] c"G15"
@.d949 = private constant [9 x i8] c"expected "
@.d950 = private constant [8 x i8] c", found "
@.d951 = private constant [3 x i8] c"E12"
@.d952 = private constant [5 x i8] c"type "
@.d953 = private constant [35 x i8] c" is already declared in this module"
@.d954 = private constant [2 x i8] c"D2"
@.d955 = private constant [3 x i8] c"D15"
@.d956 = private constant [79 x i8] c"':=' takes its type from the initializer, and a call returning nothing has none"
@.d957 = private constant [14 x i8] c"type variable "
@.d958 = private constant [60 x i8] c" is named after a type - choose a name no type has, as '<T>'"
@.d959 = private constant [2 x i8] c"G1"
@.d960 = private constant [14 x i8] c"type variable "
@.d961 = private constant [93 x i8] c" appears in no parameter's type, so no call can infer it - introduce it in a parameter's type"
@.d962 = private constant [2 x i8] c"G4"
@.d963 = private constant [3 x i8] c"G17"
@.d964 = private constant [72 x i8] c"this generic's instantiations never end - each one requires a larger one"
@.d965 = private constant [3 x i8] c"D8c"
@.d966 = private constant [64 x i8] c"'_' discards a value and names nothing, so it cannot be declared"
@.d967 = private constant [3 x i8] c"E15"
@.d968 = private constant [65 x i8] c"this call can fail - write 'try', and catch or pass on its errors"
@.d969 = private constant [13 x i8] c"unknown name "
@.d970 = private constant [54 x i8] c" - if it is a build constant, define it with '-define "
@.d971 = private constant [37 x i8] c"=VALUE', or declare it with a default"
@.d972 = private constant [3 x i8] c"B10"
@.d973 = private constant [16 x i8] c"unknown option '"
@.d974 = private constant [38 x i8] c"' - 'olang help' lists the options of "
@.d975 = private constant [2 x i8] c"B1"
@.d976 = private constant [25 x i8] c"unknown function or type "
@.d977 = private constant [0 x i8] c""
@.d978 = private constant [25 x i8] c"unknown function or type "
@.d979 = private constant [17 x i8] c" - did you mean '"
@.d980 = private constant [2 x i8] c"'?"
@.d981 = private constant [0 x i8] c""
@.d982 = private constant [46 x i8] c" is no import here - std has it: 'import \22std/"
@.d983 = private constant [2 x i8] c"\22'"
@.d984 = private constant [3 x i8] c"M10"
@.d985 = private constant [15 x i8] c" has no method "
@.d986 = private constant [3 x i8] c"M19"
@.d987 = private constant [13 x i8] c"unknown name "
@.d988 = private constant [0 x i8] c""
@.d989 = private constant [13 x i8] c"unknown type "
@.d990 = private constant [58 x i8] c" - the numbers are named by kind and width: did you mean '"
@.d991 = private constant [2 x i8] c"'?"
@.d992 = private constant [2 x i8] c"T4"
@.d993 = private constant [83 x i8] c" names no variable visible here - a marker names where the reference lives, as '&x'"
@.d994 = private constant [3 x i8] c"O4a"
@.d995 = private constant [13 x i8] c"unknown type "
@.d996 = private constant [0 x i8] c""
@.d997 = private constant [13 x i8] c"unknown type "
@.d998 = private constant [17 x i8] c" - did you mean '"
@.d999 = private constant [2 x i8] c"'?"
@.d1000 = private constant [0 x i8] c""
@.d1001 = private constant [2 x i8] c"B1"
@.d1002 = private constant [105 x i8] c"nothing to do - write a file to build and run, as 'olang main.olang', or a mode ('olang help' lists them)"
@.d1003 = private constant [43 x i8] c"a declaration's value follows '=' - write '"
@.d1004 = private constant [3 x i8] c" = "
@.d1005 = private constant [7 x i8] c"', or '"
@.d1006 = private constant [4 x i8] c" := "
@.d1007 = private constant [1 x i8] c"'"
@.d1008 = private constant [3 x i8] c"D12"
@.d1009 = private constant [4 x i8] c"O25h"
@.d1010 = private constant [91 x i8] c"this value holds references into a scope the target outlives - build it where the target is"
@.d1011 = private constant [34 x i8] c" names need as many values, found "
@.d1012 = private constant [4 x i8] c"D12b"
@.d1013 = private constant [1 x i8] c"'"
@.d1014 = private constant [73 x i8] c"' may grow here while a task holds a view of it - give the task a copy: '"
@.d1015 = private constant [11 x i8] c".ToArray()'"
@.d1016 = private constant [4 x i8] c"M19g"
@.d1017 = private constant [22 x i8] c"this reads a view of '"
@.d1018 = private constant [16 x i8] c"' taken before '"
@.d1019 = private constant [16 x i8] c"' may have grown"
@.d1020 = private constant [4 x i8] c"M19g"
@.d1021 = private constant [14 x i8] c"this view of '"
@.d1022 = private constant [14 x i8] c"' is given to "
@.d1023 = private constant [18 x i8] c", which may grow '"
@.d1024 = private constant [30 x i8] c"' - copy the elements first: '"
@.d1025 = private constant [11 x i8] c".ToArray()'"
@.d1026 = private constant [4 x i8] c"M19g"
@.d1027 = private constant [1 x i8] c"'"
@.d1028 = private constant [19 x i8] c"' holds a view of '"
@.d1029 = private constant [16 x i8] c"' taken before '"
@.d1030 = private constant [16 x i8] c"' may have grown"
@.d1031 = private constant [4 x i8] c"M19g"
@.d1032 = private constant [4 x i8] c"S13f"
@.d1033 = private constant [61 x i8] c"'_' matches every value, so it is its case's only alternative"
@.d1034 = private constant [3 x i8] c"E31"
@.d1035 = private constant [98 x i8] c"this writes into a value a call gave back, a copy no one holds - store the whole element: x[i] = v"
@.d1036 = private constant [8 x i8] c"E31, O17"
@.d1037 = private constant [171 x i8] c"x[i] gives a copy, and the call can build into what it holds where the copy is - hold the elements by reference, or copy it where the collection lives ('t mut T&l = l[i]')"
@.d1038 = private constant [4 x i8] c"E31b"
@.d1039 = private constant [196 x i8] c"x[i] gives a copy of the element, which this call would write while it can reach the collection another way - write 't := x[i]', the call on 't', then 'x[i] = t', or hold the elements by reference"
@.d1040 = private constant [28 x i8] c"this writes through x[i] on "
@.d1041 = private constant [95 x i8] c", which declares At but not SetAt - the copy At gives back is never written back; declare SetAt"
@.d1042 = private constant [3 x i8] c"E31"
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2eU8_2eFormat(ptr %v0, i8 %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i8 %a2)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
