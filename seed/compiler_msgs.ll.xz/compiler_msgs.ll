; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
@G_2ecompiler_2fmsgs_2eEndOfFile = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\0B\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fmsgs_2eEndOfFile.k1 }>, align 8
@G_2ecompiler_2fmsgs_2eEndOfFile.k1 = internal global <{ [11 x i8] }> <{ [11 x i8] c"\65\6E\64\20\6F\66\20\66\69\6C\65" }>, align 8
@G_2ecompiler_2fmsgs_2eEndOfLine = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\0B\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fmsgs_2eEndOfLine.k1 }>, align 8
@G_2ecompiler_2fmsgs_2eEndOfLine.k1 = internal global <{ [11 x i8] }> <{ [11 x i8] c"\65\6E\64\20\6F\66\20\6C\69\6E\65" }>, align 8
define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAlreadyDeclared(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 25, ptr @.d0 }, 1
  %t6 = extractvalue { i64, ptr } { i64 25, ptr @.d0 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 490, { i64, ptr } { i64 0, ptr @.d1 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAltBindingType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 13, ptr @.d2 }, 1
  %t7 = extractvalue { i64, ptr } { i64 13, ptr @.d2 }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 43, ptr @.d3 }, 1
  %t14 = extractvalue { i64, ptr } { i64 43, ptr @.d3 }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 416, { i64, ptr } { i64 4, ptr @.d4 }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAltBindsOtherNames(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 414, { i64, ptr } { i64 4, ptr @.d5 }, { i64, ptr } { i64 86, ptr @.d6 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCount(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } { i64 9, ptr @.d7 }, 1
  %t5 = extractvalue { i64, ptr } { i64 9, ptr @.d7 }, 0
  %t7 = call i64 @__olang_fmt_i64(ptr null, i64 %a0)
  %t8 = add i64 %t5, %t7
  %t9 = extractvalue { i64, ptr } { i64 9, ptr @.d8 }, 1
  %t10 = extractvalue { i64, ptr } { i64 9, ptr @.d8 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 8, ptr @.d9 }, 1
  %t17 = extractvalue { i64, ptr } { i64 8, ptr @.d9 }, 0
  %t18 = add i64 %t15, %t17
  %t20 = call i64 @__olang_fmt_i64(ptr null, i64 %a2)
  %t21 = add i64 %t18, %t20
  %t22 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t21)
  call void @olang_textcopy(ptr %t22, ptr %t4, i64 %t5)
  %t23 = getelementptr i8, ptr %t22, i64 %t5
  %t24 = call i64 @__olang_fmt_i64(ptr %t23, i64 %a0)
  %t25 = getelementptr i8, ptr %t23, i64 %t7
  call void @olang_textcopy(ptr %t25, ptr %t9, i64 %t10)
  %t26 = getelementptr i8, ptr %t25, i64 %t10
  call void @olang_textcopy(ptr %t26, ptr %t13, i64 %t14)
  %t27 = getelementptr i8, ptr %t26, i64 %t14
  call void @olang_textcopy(ptr %t27, ptr %t16, i64 %t17)
  %t28 = getelementptr i8, ptr %t27, i64 %t17
  %t29 = call i64 @__olang_fmt_i64(ptr %t28, i64 %a2)
  %t30 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t22, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t41 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 244, { i64, ptr } { i64 3, ptr @.d10 }, { i64, ptr } %t38)
  store %"compiler/msgs:Msg" %t41, ptr %l9
  br label %bb1
bb1:
  %t42 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t42, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCountRange(ptr %v0, i64 %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } { i64 9, ptr @.d11 }, 1
  %t5 = extractvalue { i64, ptr } { i64 9, ptr @.d11 }, 0
  %t7 = call i64 @__olang_fmt_i64(ptr null, i64 %a0)
  %t8 = add i64 %t5, %t7
  %t9 = extractvalue { i64, ptr } { i64 4, ptr @.d12 }, 1
  %t10 = extractvalue { i64, ptr } { i64 4, ptr @.d12 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = call i64 @__olang_fmt_i64(ptr null, i64 %a1)
  %t14 = add i64 %t11, %t13
  %t15 = extractvalue { i64, ptr } { i64 18, ptr @.d13 }, 1
  %t16 = extractvalue { i64, ptr } { i64 18, ptr @.d13 }, 0
  %t17 = add i64 %t14, %t16
  %t19 = call i64 @__olang_fmt_i64(ptr null, i64 %a2)
  %t20 = add i64 %t17, %t19
  %t21 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t20)
  call void @olang_textcopy(ptr %t21, ptr %t4, i64 %t5)
  %t22 = getelementptr i8, ptr %t21, i64 %t5
  %t23 = call i64 @__olang_fmt_i64(ptr %t22, i64 %a0)
  %t24 = getelementptr i8, ptr %t22, i64 %t7
  call void @olang_textcopy(ptr %t24, ptr %t9, i64 %t10)
  %t25 = getelementptr i8, ptr %t24, i64 %t10
  %t26 = call i64 @__olang_fmt_i64(ptr %t25, i64 %a1)
  %t27 = getelementptr i8, ptr %t25, i64 %t13
  call void @olang_textcopy(ptr %t27, ptr %t15, i64 %t16)
  %t28 = getelementptr i8, ptr %t27, i64 %t16
  %t29 = call i64 @__olang_fmt_i64(ptr %t28, i64 %a2)
  %t30 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t21, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t41 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 245, { i64, ptr } { i64 3, ptr @.d14 }, { i64, ptr } %t38)
  store %"compiler/msgs:Msg" %t41, ptr %l9
  br label %bb1
bb1:
  %t42 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t42, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayByValueRunTime(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l8 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = extractvalue { i64, ptr } { i64 78, ptr @.d15 }, 1
  %t8 = extractvalue { i64, ptr } { i64 78, ptr @.d15 }, 0
  %t9 = add i64 %t6, %t8
  %t11 = extractvalue { i64, ptr } %t2, 1
  %t12 = extractvalue { i64, ptr } %t2, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 42, ptr @.d16 }, 1
  %t15 = extractvalue { i64, ptr } { i64 42, ptr @.d16 }, 0
  %t16 = add i64 %t13, %t15
  %t18 = extractvalue { i64, ptr } %t3, 1
  %t19 = extractvalue { i64, ptr } %t3, 0
  %t20 = add i64 %t16, %t19
  %t21 = extractvalue { i64, ptr } { i64 48, ptr @.d17 }, 1
  %t22 = extractvalue { i64, ptr } { i64 48, ptr @.d17 }, 0
  %t23 = add i64 %t20, %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t5, i64 %t6)
  %t25 = getelementptr i8, ptr %t24, i64 %t6
  call void @olang_textcopy(ptr %t25, ptr %t7, i64 %t8)
  %t26 = getelementptr i8, ptr %t25, i64 %t8
  call void @olang_textcopy(ptr %t26, ptr %t11, i64 %t12)
  %t27 = getelementptr i8, ptr %t26, i64 %t12
  call void @olang_textcopy(ptr %t27, ptr %t14, i64 %t15)
  %t28 = getelementptr i8, ptr %t27, i64 %t15
  call void @olang_textcopy(ptr %t28, ptr %t18, i64 %t19)
  %t29 = getelementptr i8, ptr %t28, i64 %t19
  call void @olang_textcopy(ptr %t29, ptr %t21, i64 %t22)
  %t30 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t24, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t41 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 139, { i64, ptr } { i64 3, ptr @.d18 }, { i64, ptr } %t38)
  store %"compiler/msgs:Msg" %t41, ptr %l8
  br label %bb1
bb1:
  %t42 = load %"compiler/msgs:Msg", ptr %l8
  store %"compiler/msgs:Msg" %t42, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayLengthNotInt(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 39, ptr @.d19 }, 1
  %t3 = extractvalue { i64, ptr } { i64 39, ptr @.d19 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 385, { i64, ptr } { i64 4, ptr @.d20 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayLengthRange(ptr %v0, i64 %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 73, ptr @.d21 }, 1
  %t3 = extractvalue { i64, ptr } { i64 73, ptr @.d21 }, 0
  %t5 = call i64 @__olang_fmt_i64(ptr null, i64 %a0)
  %t6 = add i64 %t3, %t5
  %t7 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t6)
  call void @olang_textcopy(ptr %t7, ptr %t2, i64 %t3)
  %t8 = getelementptr i8, ptr %t7, i64 %t3
  %t9 = call i64 @__olang_fmt_i64(ptr %t8, i64 %a0)
  %t10 = insertvalue { i64, ptr } undef, i64 %t6, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t7, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 141, { i64, ptr } { i64 3, ptr @.d22 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayNestedByValue(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 66, ptr @.d23 }, 1
  %t3 = extractvalue { i64, ptr } { i64 66, ptr @.d23 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 93, ptr @.d24 }, 1
  %t9 = extractvalue { i64, ptr } { i64 93, ptr @.d24 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 145, { i64, ptr } { i64 8, ptr @.d25 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayOfErrors(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 33, ptr @.d26 }, 1
  %t6 = extractvalue { i64, ptr } { i64 33, ptr @.d26 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 374, { i64, ptr } { i64 3, ptr @.d27 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayOneIndex(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 61, ptr @.d28 }, 1
  %t6 = extractvalue { i64, ptr } { i64 61, ptr @.d28 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 176, { i64, ptr } { i64 3, ptr @.d29 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayParamByValue(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 16, ptr @.d30 }, 1
  %t4 = extractvalue { i64, ptr } { i64 16, ptr @.d30 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 32, ptr @.d31 }, 1
  %t10 = extractvalue { i64, ptr } { i64 32, ptr @.d31 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 1, ptr @.d32 }, 1
  %t17 = extractvalue { i64, ptr } { i64 1, ptr @.d32 }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 158, { i64, ptr } { i64 3, ptr @.d33 }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayRunTimeIntoFixed(ptr %v0, i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l6 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t2 = load i64, ptr %l0, !tbaa !24
  %t3 = extractvalue { i64, ptr } { i64 60, ptr @.d34 }, 1
  %t4 = extractvalue { i64, ptr } { i64 60, ptr @.d34 }, 0
  %t6 = call i64 @__olang_fmt_i64(ptr null, i64 %t1)
  %t7 = add i64 %t4, %t6
  %t8 = extractvalue { i64, ptr } { i64 72, ptr @.d35 }, 1
  %t9 = extractvalue { i64, ptr } { i64 72, ptr @.d35 }, 0
  %t10 = add i64 %t7, %t9
  %t12 = call i64 @__olang_fmt_i64(ptr null, i64 %t2)
  %t13 = add i64 %t10, %t12
  %t14 = extractvalue { i64, ptr } { i64 2, ptr @.d36 }, 1
  %t15 = extractvalue { i64, ptr } { i64 2, ptr @.d36 }, 0
  %t16 = add i64 %t13, %t15
  %t17 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t16)
  call void @olang_textcopy(ptr %t17, ptr %t3, i64 %t4)
  %t18 = getelementptr i8, ptr %t17, i64 %t4
  %t19 = call i64 @__olang_fmt_i64(ptr %t18, i64 %t1)
  %t20 = getelementptr i8, ptr %t18, i64 %t6
  call void @olang_textcopy(ptr %t20, ptr %t8, i64 %t9)
  %t21 = getelementptr i8, ptr %t20, i64 %t9
  %t22 = call i64 @__olang_fmt_i64(ptr %t21, i64 %t2)
  %t23 = getelementptr i8, ptr %t21, i64 %t12
  call void @olang_textcopy(ptr %t23, ptr %t14, i64 %t15)
  %t24 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t17, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 212, { i64, ptr } { i64 3, ptr @.d37 }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l6
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l6
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eArraySizeMismatch(ptr %v0, i64 %a0, i64 %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 12, ptr @.d38 }, 1
  %t4 = extractvalue { i64, ptr } { i64 12, ptr @.d38 }, 0
  %t6 = call i64 @__olang_fmt_i64(ptr null, i64 %a0)
  %t7 = add i64 %t4, %t6
  %t8 = extractvalue { i64, ptr } { i64 23, ptr @.d39 }, 1
  %t9 = extractvalue { i64, ptr } { i64 23, ptr @.d39 }, 0
  %t10 = add i64 %t7, %t9
  %t12 = call i64 @__olang_fmt_i64(ptr null, i64 %a1)
  %t13 = add i64 %t10, %t12
  %t14 = extractvalue { i64, ptr } { i64 62, ptr @.d40 }, 1
  %t15 = extractvalue { i64, ptr } { i64 62, ptr @.d40 }, 0
  %t16 = add i64 %t13, %t15
  %t17 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t16)
  call void @olang_textcopy(ptr %t17, ptr %t3, i64 %t4)
  %t18 = getelementptr i8, ptr %t17, i64 %t4
  %t19 = call i64 @__olang_fmt_i64(ptr %t18, i64 %a0)
  %t20 = getelementptr i8, ptr %t18, i64 %t6
  call void @olang_textcopy(ptr %t20, ptr %t8, i64 %t9)
  %t21 = getelementptr i8, ptr %t20, i64 %t9
  %t22 = call i64 @__olang_fmt_i64(ptr %t21, i64 %a1)
  %t23 = getelementptr i8, ptr %t21, i64 %t12
  call void @olang_textcopy(ptr %t23, ptr %t14, i64 %t15)
  %t24 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t17, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 211, { i64, ptr } { i64 3, ptr @.d41 }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayTooManyArgs(ptr %v0, i64 %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 55, ptr @.d42 }, 1
  %t3 = extractvalue { i64, ptr } { i64 55, ptr @.d42 }, 0
  %t5 = call i64 @__olang_fmt_i64(ptr null, i64 %a0)
  %t6 = add i64 %t3, %t5
  %t7 = extractvalue { i64, ptr } { i64 70, ptr @.d43 }, 1
  %t8 = extractvalue { i64, ptr } { i64 70, ptr @.d43 }, 0
  %t9 = add i64 %t6, %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t9)
  call void @olang_textcopy(ptr %t10, ptr %t2, i64 %t3)
  %t11 = getelementptr i8, ptr %t10, i64 %t3
  %t12 = call i64 @__olang_fmt_i64(ptr %t11, i64 %a0)
  %t13 = getelementptr i8, ptr %t11, i64 %t5
  call void @olang_textcopy(ptr %t13, ptr %t7, i64 %t8)
  %t14 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t10, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 143, { i64, ptr } { i64 6, ptr @.d44 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayTypeHoldsItself(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = extractvalue { i64, ptr } { i64 88, ptr @.d45 }, 1
  %t8 = extractvalue { i64, ptr } { i64 88, ptr @.d45 }, 0
  %t9 = add i64 %t6, %t8
  %t11 = extractvalue { i64, ptr } %a1, 1
  %t12 = extractvalue { i64, ptr } %a1, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 14, ptr @.d46 }, 1
  %t15 = extractvalue { i64, ptr } { i64 14, ptr @.d46 }, 0
  %t16 = add i64 %t13, %t15
  %t18 = extractvalue { i64, ptr } %a2, 1
  %t19 = extractvalue { i64, ptr } %a2, 0
  %t20 = add i64 %t16, %t19
  %t21 = extractvalue { i64, ptr } { i64 3, ptr @.d47 }, 1
  %t22 = extractvalue { i64, ptr } { i64 3, ptr @.d47 }, 0
  %t23 = add i64 %t20, %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t5, i64 %t6)
  %t25 = getelementptr i8, ptr %t24, i64 %t6
  call void @olang_textcopy(ptr %t25, ptr %t7, i64 %t8)
  %t26 = getelementptr i8, ptr %t25, i64 %t8
  call void @olang_textcopy(ptr %t26, ptr %t11, i64 %t12)
  %t27 = getelementptr i8, ptr %t26, i64 %t12
  call void @olang_textcopy(ptr %t27, ptr %t14, i64 %t15)
  %t28 = getelementptr i8, ptr %t27, i64 %t15
  call void @olang_textcopy(ptr %t28, ptr %t18, i64 %t19)
  %t29 = getelementptr i8, ptr %t28, i64 %t19
  call void @olang_textcopy(ptr %t29, ptr %t21, i64 %t22)
  %t30 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t24, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t41 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 134, { i64, ptr } { i64 3, ptr @.d48 }, { i64, ptr } %t38)
  store %"compiler/msgs:Msg" %t41, ptr %l9
  br label %bb1
bb1:
  %t42 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t42, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrowInStatement(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 419, { i64, ptr } { i64 4, ptr @.d49 }, { i64, ptr } { i64 94, ptr @.d50 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrowLeaves(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 24, ptr @.d51 }, 1
  %t4 = extractvalue { i64, ptr } { i64 24, ptr @.d51 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 50, ptr @.d52 }, 1
  %t10 = extractvalue { i64, ptr } { i64 50, ptr @.d52 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 3, ptr @.d53 }, 1
  %t17 = extractvalue { i64, ptr } { i64 3, ptr @.d53 }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 420, { i64, ptr } { i64 4, ptr @.d54 }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAsNeedsCase(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 35, ptr @.d55 }, 1
  %t4 = extractvalue { i64, ptr } { i64 35, ptr @.d55 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 8, ptr @.d56 }, 1
  %t10 = extractvalue { i64, ptr } { i64 8, ptr @.d56 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t3, i64 %t4)
  %t17 = getelementptr i8, ptr %t16, i64 %t4
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t9, i64 %t10)
  %t19 = getelementptr i8, ptr %t18, i64 %t10
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 336, { i64, ptr } { i64 3, ptr @.d57 }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAsNothing(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 5, ptr @.d58 }, 1
  %t3 = extractvalue { i64, ptr } { i64 5, ptr @.d58 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 49, ptr @.d59 }, 1
  %t9 = extractvalue { i64, ptr } { i64 49, ptr @.d59 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 340, { i64, ptr } { i64 3, ptr @.d60 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertAborts(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 62, ptr @.d61 }, 1
  %t3 = extractvalue { i64, ptr } { i64 62, ptr @.d61 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 507, { i64, ptr } { i64 4, ptr @.d62 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertFalse(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 501, { i64, ptr } { i64 4, ptr @.d63 }, { i64, ptr } { i64 50, ptr @.d64 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertFalseMessage(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 52, ptr @.d65 }, 1
  %t3 = extractvalue { i64, ptr } { i64 52, ptr @.d65 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 502, { i64, ptr } { i64 4, ptr @.d66 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertMessageNotText(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a1, 1
  %t5 = extractvalue { i64, ptr } %a1, 0
  %t6 = extractvalue { i64, ptr } { i64 24, ptr @.d67 }, 1
  %t7 = extractvalue { i64, ptr } { i64 24, ptr @.d67 }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a0, 1
  %t11 = extractvalue { i64, ptr } %a0, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 31, ptr @.d68 }, 1
  %t14 = extractvalue { i64, ptr } { i64 31, ptr @.d68 }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 506, { i64, ptr } { i64 4, ptr @.d69 }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertMsgError(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 23, ptr @.d70 }, 1
  %t3 = extractvalue { i64, ptr } { i64 23, ptr @.d70 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 24, ptr @.d71 }, 1
  %t9 = extractvalue { i64, ptr } { i64 24, ptr @.d71 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 504, { i64, ptr } { i64 3, ptr @.d72 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertMsgLoopJump(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 15, ptr @.d73 }, 1
  %t7 = extractvalue { i64, ptr } { i64 15, ptr @.d73 }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 48, ptr @.d74 }, 1
  %t14 = extractvalue { i64, ptr } { i64 48, ptr @.d74 }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 505, { i64, ptr } { i64 3, ptr @.d75 }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertMsgReturns(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 79, ptr @.d76 }, 1
  %t6 = extractvalue { i64, ptr } { i64 79, ptr @.d76 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 503, { i64, ptr } { i64 3, ptr @.d77 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertStale(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 65, ptr @.d78 }, 1
  %t3 = extractvalue { i64, ptr } { i64 65, ptr @.d78 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 513, { i64, ptr } { i64 8, ptr @.d79 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssignIntoTried(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 277, { i64, ptr } { i64 3, ptr @.d80 }, { i64, ptr } { i64 164, ptr @.d81 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssignListCount(ptr %v0, i64 %a0, i64 %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = call i64 @__olang_fmt_i64(ptr null, i64 %a0)
  %t5 = extractvalue { i64, ptr } { i64 36, ptr @.d82 }, 1
  %t6 = extractvalue { i64, ptr } { i64 36, ptr @.d82 }, 0
  %t7 = add i64 %t4, %t6
  %t9 = call i64 @__olang_fmt_i64(ptr null, i64 %a1)
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t10)
  %t12 = call i64 @__olang_fmt_i64(ptr %t11, i64 %a0)
  %t13 = getelementptr i8, ptr %t11, i64 %t4
  call void @olang_textcopy(ptr %t13, ptr %t5, i64 %t6)
  %t14 = getelementptr i8, ptr %t13, i64 %t6
  %t15 = call i64 @__olang_fmt_i64(ptr %t14, i64 %a1)
  %t16 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t11, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t27 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 386, { i64, ptr } { i64 3, ptr @.d83 }, { i64, ptr } %t24)
  store %"compiler/msgs:Msg" %t27, ptr %l7
  br label %bb1
bb1:
  %t28 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAtUndeclared(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 52, ptr @.d84 }, 1
  %t6 = extractvalue { i64, ptr } { i64 52, ptr @.d84 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 345, { i64, ptr } { i64 3, ptr @.d85 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAtomicNotInteger(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 60, ptr @.d86 }, 1
  %t3 = extractvalue { i64, ptr } { i64 60, ptr @.d86 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 8, ptr @.d87 }, 1
  %t9 = extractvalue { i64, ptr } { i64 8, ptr @.d87 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 357, { i64, ptr } { i64 2, ptr @.d88 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAtomicNotPlace(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 265, { i64, ptr } { i64 2, ptr @.d89 }, { i64, ptr } { i64 71, ptr @.d90 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAtomicNotWritable(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 266, { i64, ptr } { i64 2, ptr @.d91 }, { i64, ptr } { i64 62, ptr @.d92 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBadEscape(ptr %v0, i8 %a0) #0 {
entry:
  %l1 = alloca i32
  %l3 = alloca { i64, ptr }
  %l6 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 60, ptr %l1
  %t3 = call { i64, ptr } @compiler_2fmsgs_2eEsc(ptr %s0, i8 %a0)
  store { i64, ptr } %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = extractvalue { i64, ptr } { i64 17, ptr @.d93 }, 1
  %t5 = extractvalue { i64, ptr } { i64 17, ptr @.d93 }, 0
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 1
  %t8 = extractvalue { i64, ptr } %t6, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 40, ptr @.d94 }, 1
  %t11 = extractvalue { i64, ptr } { i64 40, ptr @.d94 }, 0
  %t12 = add i64 %t9, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t7, i64 %t8)
  %t15 = getelementptr i8, ptr %t14, i64 %t8
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t25 = load i32, ptr %l1
  %t27 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t25, { i64, ptr } { i64 3, ptr @.d95 }, { i64, ptr } %t24)
  store %"compiler/msgs:Msg" %t27, ptr %l6
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t28 = load %"compiler/msgs:Msg", ptr %l6
  store %"compiler/msgs:Msg" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBangNothingFails(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 371, { i64, ptr } { i64 3, ptr @.d96 }, { i64, ptr } { i64 44, ptr @.d97 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBinDigit(ptr %v0, i8 %a0) #0 {
entry:
  %l1 = alloca i32
  %l3 = alloca { i64, ptr }
  %l6 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 64, ptr %l1
  %t3 = call { i64, ptr } @compiler_2fmsgs_2eEsc(ptr %s0, i8 %a0)
  store { i64, ptr } %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = extractvalue { i64, ptr } { i64 1, ptr @.d98 }, 1
  %t5 = extractvalue { i64, ptr } { i64 1, ptr @.d98 }, 0
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 1
  %t8 = extractvalue { i64, ptr } %t6, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 23, ptr @.d99 }, 1
  %t11 = extractvalue { i64, ptr } { i64 23, ptr @.d99 }, 0
  %t12 = add i64 %t9, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t7, i64 %t8)
  %t15 = getelementptr i8, ptr %t14, i64 %t8
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t25 = load i32, ptr %l1
  %t27 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t25, { i64, ptr } { i64 4, ptr @.d100 }, { i64, ptr } %t24)
  store %"compiler/msgs:Msg" %t27, ptr %l6
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t28 = load %"compiler/msgs:Msg", ptr %l6
  store %"compiler/msgs:Msg" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBinNoDigits(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 62, { i64, ptr } { i64 4, ptr @.d101 }, { i64, ptr } { i64 24, ptr @.d102 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBlockNotClosed(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 25, ptr @.d103 }, 1
  %t4 = extractvalue { i64, ptr } { i64 25, ptr @.d103 }, 0
  %t6 = call i64 @__olang_fmt_i64(ptr null, i64 %a0)
  %t7 = add i64 %t4, %t6
  %t8 = extractvalue { i64, ptr } { i64 20, ptr @.d104 }, 1
  %t9 = extractvalue { i64, ptr } { i64 20, ptr @.d104 }, 0
  %t10 = add i64 %t7, %t9
  %t12 = extractvalue { i64, ptr } %a1, 1
  %t13 = extractvalue { i64, ptr } %a1, 0
  %t14 = add i64 %t10, %t13
  %t15 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t14)
  call void @olang_textcopy(ptr %t15, ptr %t3, i64 %t4)
  %t16 = getelementptr i8, ptr %t15, i64 %t4
  %t17 = call i64 @__olang_fmt_i64(ptr %t16, i64 %a0)
  %t18 = getelementptr i8, ptr %t16, i64 %t6
  call void @olang_textcopy(ptr %t18, ptr %t8, i64 %t9)
  %t19 = getelementptr i8, ptr %t18, i64 %t9
  call void @olang_textcopy(ptr %t19, ptr %t12, i64 %t13)
  %t20 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t15, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 69, { i64, ptr } { i64 0, ptr @.d105 }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBorrowSplitScopes(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 249, { i64, ptr } { i64 3, ptr @.d106 }, { i64, ptr } { i64 153, ptr @.d107 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBorrowSplitValue(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 251, { i64, ptr } { i64 4, ptr @.d108 }, { i64, ptr } { i64 114, ptr @.d109 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBoundTwice(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 34, ptr @.d110 }, 1
  %t6 = extractvalue { i64, ptr } { i64 34, ptr @.d110 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 415, { i64, ptr } { i64 4, ptr @.d111 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBreakOutsideLoop(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 51, ptr @.d112 }, 1
  %t6 = extractvalue { i64, ptr } { i64 51, ptr @.d112 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 492, { i64, ptr } { i64 3, ptr @.d113 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuildConstRedeclared(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 42, ptr @.d114 }, 1
  %t6 = extractvalue { i64, ptr } { i64 42, ptr @.d114 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 119, { i64, ptr } { i64 3, ptr @.d115 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuildDefaultFit(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l11 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } { i64 8, ptr @.d116 }, 1
  %t6 = extractvalue { i64, ptr } { i64 8, ptr @.d116 }, 0
  %t8 = extractvalue { i64, ptr } %a0, 1
  %t9 = extractvalue { i64, ptr } %a0, 0
  %t10 = add i64 %t6, %t9
  %t11 = extractvalue { i64, ptr } { i64 1, ptr @.d117 }, 1
  %t12 = extractvalue { i64, ptr } { i64 1, ptr @.d117 }, 0
  %t13 = add i64 %t10, %t12
  %t15 = extractvalue { i64, ptr } %a1, 1
  %t16 = extractvalue { i64, ptr } %a1, 0
  %t17 = add i64 %t13, %t16
  %t18 = extractvalue { i64, ptr } { i64 14, ptr @.d118 }, 1
  %t19 = extractvalue { i64, ptr } { i64 14, ptr @.d118 }, 0
  %t20 = add i64 %t17, %t19
  %t22 = extractvalue { i64, ptr } %a2, 1
  %t23 = extractvalue { i64, ptr } %a2, 0
  %t24 = add i64 %t20, %t23
  %t25 = extractvalue { i64, ptr } { i64 11, ptr @.d119 }, 1
  %t26 = extractvalue { i64, ptr } { i64 11, ptr @.d119 }, 0
  %t27 = add i64 %t24, %t26
  %t29 = extractvalue { i64, ptr } %a3, 1
  %t30 = extractvalue { i64, ptr } %a3, 0
  %t31 = add i64 %t27, %t30
  %t32 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t31)
  call void @olang_textcopy(ptr %t32, ptr %t5, i64 %t6)
  %t33 = getelementptr i8, ptr %t32, i64 %t6
  call void @olang_textcopy(ptr %t33, ptr %t8, i64 %t9)
  %t34 = getelementptr i8, ptr %t33, i64 %t9
  call void @olang_textcopy(ptr %t34, ptr %t11, i64 %t12)
  %t35 = getelementptr i8, ptr %t34, i64 %t12
  call void @olang_textcopy(ptr %t35, ptr %t15, i64 %t16)
  %t36 = getelementptr i8, ptr %t35, i64 %t16
  call void @olang_textcopy(ptr %t36, ptr %t18, i64 %t19)
  %t37 = getelementptr i8, ptr %t36, i64 %t19
  call void @olang_textcopy(ptr %t37, ptr %t22, i64 %t23)
  %t38 = getelementptr i8, ptr %t37, i64 %t23
  call void @olang_textcopy(ptr %t38, ptr %t25, i64 %t26)
  %t39 = getelementptr i8, ptr %t38, i64 %t26
  call void @olang_textcopy(ptr %t39, ptr %t29, i64 %t30)
  %t40 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t32, 1
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t44 = extractvalue { i64, ptr } %t41, 1
  %t45 = mul i64 %t43, 1
  %t46 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t45)
  call void @llvm.memcpy.p0.p0.i64(ptr %t46, ptr %t44, i64 %t45, i1 false)
  %t47 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  %t51 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, i32 122, { i64, ptr } { i64 4, ptr @.d120 }, { i64, ptr } %t48)
  store %"compiler/msgs:Msg" %t51, ptr %l11
  br label %bb1
bb1:
  %t52 = load %"compiler/msgs:Msg", ptr %l11
  store %"compiler/msgs:Msg" %t52, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuildDefaultMut(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 85, ptr @.d121 }, 1
  %t6 = extractvalue { i64, ptr } { i64 85, ptr @.d121 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 120, { i64, ptr } { i64 4, ptr @.d122 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuildDefaultType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 91, ptr @.d123 }, 1
  %t7 = extractvalue { i64, ptr } { i64 91, ptr @.d123 }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t6, i64 %t7)
  %t15 = getelementptr i8, ptr %t14, i64 %t7
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t27 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 121, { i64, ptr } { i64 4, ptr @.d124 }, { i64, ptr } %t24)
  store %"compiler/msgs:Msg" %t27, ptr %l7
  br label %bb1
bb1:
  %t28 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuildIntoUnknownScope(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 238, { i64, ptr } { i64 8, ptr @.d125 }, { i64, ptr } { i64 113, ptr @.d126 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuildThroughUnknownScope(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 241, { i64, ptr } { i64 3, ptr @.d127 }, { i64, ptr } { i64 113, ptr @.d128 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuiltinTypeRedeclared(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 43, ptr @.d129 }, 1
  %t6 = extractvalue { i64, ptr } { i64 43, ptr @.d129 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 117, { i64, ptr } { i64 3, ptr @.d130 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCallValueObligations(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 107, ptr @.d131 }, 1
  %t6 = extractvalue { i64, ptr } { i64 107, ptr @.d131 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 485, { i64, ptr } { i64 9, ptr @.d132 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 40, { i64, ptr } { i64 0, ptr @.d133 }, { i64, ptr } { i64 21, ptr @.d134 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotRun(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 27, ptr @.d135 }, 1
  %t3 = extractvalue { i64, ptr } { i64 27, ptr @.d135 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 14, { i64, ptr } { i64 3, ptr @.d136 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaptureReadOnly(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 279, { i64, ptr } { i64 4, ptr @.d137 }, { i64, ptr } { i64 84, ptr @.d138 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCarriageReturn(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 51, { i64, ptr } { i64 2, ptr @.d139 }, { i64, ptr } { i64 52, ptr @.d140 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseAfterWildcard(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 433, { i64, ptr } { i64 4, ptr @.d141 }, { i64, ptr } { i64 73, ptr @.d142 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseBlockStays(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 422, { i64, ptr } { i64 4, ptr @.d143 }, { i64, ptr } { i64 66, ptr @.d144 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseIsPrivate(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 5, ptr @.d145 }, 1
  %t3 = extractvalue { i64, ptr } { i64 5, ptr @.d145 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 25, ptr @.d146 }, 1
  %t9 = extractvalue { i64, ptr } { i64 25, ptr @.d146 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 338, { i64, ptr } { i64 3, ptr @.d147 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseIsSubject(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 115, ptr @.d148 }, 1
  %t6 = extractvalue { i64, ptr } { i64 115, ptr @.d148 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 435, { i64, ptr } { i64 4, ptr @.d149 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseUnknownName(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 13, ptr @.d150 }, 1
  %t3 = extractvalue { i64, ptr } { i64 13, ptr @.d150 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 101, ptr @.d151 }, 1
  %t9 = extractvalue { i64, ptr } { i64 101, ptr @.d151 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 434, { i64, ptr } { i64 4, ptr @.d152 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseValueType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 21, ptr @.d153 }, 1
  %t4 = extractvalue { i64, ptr } { i64 21, ptr @.d153 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 8, ptr @.d154 }, 1
  %t10 = extractvalue { i64, ptr } { i64 8, ptr @.d154 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t3, i64 %t4)
  %t17 = getelementptr i8, ptr %t16, i64 %t4
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t9, i64 %t10)
  %t19 = getelementptr i8, ptr %t18, i64 %t10
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 417, { i64, ptr } { i64 3, ptr @.d155 }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCatchAfterCatchAll(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 362, { i64, ptr } { i64 4, ptr @.d156 }, { i64, ptr } { i64 78, ptr @.d157 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCatchMustLeave(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 366, { i64, ptr } { i64 3, ptr @.d158 }, { i64, ptr } { i64 57, ptr @.d159 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCatchNotProduced(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 28, ptr @.d160 }, 1
  %t3 = extractvalue { i64, ptr } { i64 28, ptr @.d160 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 494, { i64, ptr } { i64 3, ptr @.d161 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCatchUnreachable(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 363, { i64, ptr } { i64 4, ptr @.d162 }, { i64, ptr } { i64 58, ptr @.d163 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCatchWordNotProduced(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 28, ptr @.d164 }, 1
  %t4 = extractvalue { i64, ptr } { i64 28, ptr @.d164 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 17, ptr @.d165 }, 1
  %t10 = extractvalue { i64, ptr } { i64 17, ptr @.d165 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t3, i64 %t4)
  %t17 = getelementptr i8, ptr %t16, i64 %t4
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t9, i64 %t10)
  %t19 = getelementptr i8, ptr %t18, i64 %t10
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 452, { i64, ptr } { i64 3, ptr @.d166 }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCharNewline(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 57, { i64, ptr } { i64 3, ptr @.d167 }, { i64, ptr } { i64 40, ptr @.d168 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCheckedNotSuperset(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l11 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = extractvalue { i64, ptr } { i64 4, ptr @.d169 }, 1
  %t9 = extractvalue { i64, ptr } { i64 4, ptr @.d169 }, 0
  %t10 = add i64 %t7, %t9
  %t12 = extractvalue { i64, ptr } %a1, 1
  %t13 = extractvalue { i64, ptr } %a1, 0
  %t14 = add i64 %t10, %t13
  %t15 = extractvalue { i64, ptr } { i64 46, ptr @.d170 }, 1
  %t16 = extractvalue { i64, ptr } { i64 46, ptr @.d170 }, 0
  %t17 = add i64 %t14, %t16
  %t19 = extractvalue { i64, ptr } %a2, 1
  %t20 = extractvalue { i64, ptr } %a2, 0
  %t21 = add i64 %t17, %t20
  %t22 = extractvalue { i64, ptr } { i64 11, ptr @.d171 }, 1
  %t23 = extractvalue { i64, ptr } { i64 11, ptr @.d171 }, 0
  %t24 = add i64 %t21, %t23
  %t26 = extractvalue { i64, ptr } %a3, 1
  %t27 = extractvalue { i64, ptr } %a3, 0
  %t28 = add i64 %t24, %t27
  %t29 = extractvalue { i64, ptr } { i64 14, ptr @.d172 }, 1
  %t30 = extractvalue { i64, ptr } { i64 14, ptr @.d172 }, 0
  %t31 = add i64 %t28, %t30
  %t32 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t31)
  call void @olang_textcopy(ptr %t32, ptr %t6, i64 %t7)
  %t33 = getelementptr i8, ptr %t32, i64 %t7
  call void @olang_textcopy(ptr %t33, ptr %t8, i64 %t9)
  %t34 = getelementptr i8, ptr %t33, i64 %t9
  call void @olang_textcopy(ptr %t34, ptr %t12, i64 %t13)
  %t35 = getelementptr i8, ptr %t34, i64 %t13
  call void @olang_textcopy(ptr %t35, ptr %t15, i64 %t16)
  %t36 = getelementptr i8, ptr %t35, i64 %t16
  call void @olang_textcopy(ptr %t36, ptr %t19, i64 %t20)
  %t37 = getelementptr i8, ptr %t36, i64 %t20
  call void @olang_textcopy(ptr %t37, ptr %t22, i64 %t23)
  %t38 = getelementptr i8, ptr %t37, i64 %t23
  call void @olang_textcopy(ptr %t38, ptr %t26, i64 %t27)
  %t39 = getelementptr i8, ptr %t38, i64 %t27
  call void @olang_textcopy(ptr %t39, ptr %t29, i64 %t30)
  %t40 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t32, 1
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t44 = extractvalue { i64, ptr } %t41, 1
  %t45 = mul i64 %t43, 1
  %t46 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t45)
  call void @llvm.memcpy.p0.p0.i64(ptr %t46, ptr %t44, i64 %t45, i1 false)
  %t47 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  %t51 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, i32 180, { i64, ptr } { i64 4, ptr @.d173 }, { i64, ptr } %t48)
  store %"compiler/msgs:Msg" %t51, ptr %l11
  br label %bb1
bb1:
  %t52 = load %"compiler/msgs:Msg", ptr %l11
  store %"compiler/msgs:Msg" %t52, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCheckedWithoutPlain(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 71, ptr @.d174 }, 1
  %t7 = extractvalue { i64, ptr } { i64 71, ptr @.d174 }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 10, ptr @.d175 }, 1
  %t14 = extractvalue { i64, ptr } { i64 10, ptr @.d175 }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 179, { i64, ptr } { i64 4, ptr @.d176 }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eClangFailed(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 24, ptr @.d177 }, 1
  %t3 = extractvalue { i64, ptr } { i64 24, ptr @.d177 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 45, { i64, ptr } { i64 0, ptr @.d178 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eClauseLastValue(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 66, ptr @.d179 }, 1
  %t3 = extractvalue { i64, ptr } { i64 66, ptr @.d179 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 17, ptr @.d180 }, 1
  %t9 = extractvalue { i64, ptr } { i64 17, ptr @.d180 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 367, { i64, ptr } { i64 3, ptr @.d181 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCommaEndsLine(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 48, { i64, ptr } { i64 4, ptr @.d182 }, { i64, ptr } { i64 95, ptr @.d183 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eComprNeedsTry(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 408, { i64, ptr } { i64 8, ptr @.d184 }, { i64, ptr } { i64 69, ptr @.d185 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eComprehensionReferences(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 376, { i64, ptr } { i64 3, ptr @.d186 }, { i64, ptr } { i64 90, ptr @.d187 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondBranchTypes(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 52, ptr @.d188 }, 1
  %t4 = extractvalue { i64, ptr } { i64 52, ptr @.d188 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 5, ptr @.d189 }, 1
  %t10 = extractvalue { i64, ptr } { i64 5, ptr @.d189 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t3, i64 %t4)
  %t17 = getelementptr i8, ptr %t16, i64 %t4
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t9, i64 %t10)
  %t19 = getelementptr i8, ptr %t18, i64 %t10
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 325, { i64, ptr } { i64 3, ptr @.d190 }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondCycle(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 30, ptr @.d191 }, 1
  %t6 = extractvalue { i64, ptr } { i64 30, ptr @.d191 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 83, { i64, ptr } { i64 3, ptr @.d192 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondDecidedNotBool(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 531, { i64, ptr } { i64 2, ptr @.d193 }, { i64, ptr } { i64 38, ptr @.d194 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondGlobalInit(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 56, ptr @.d195 }, 1
  %t6 = extractvalue { i64, ptr } { i64 56, ptr @.d195 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 82, { i64, ptr } { i64 3, ptr @.d196 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondLentWritable(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 349, { i64, ptr } { i64 3, ptr @.d197 }, { i64, ptr } { i64 190, ptr @.d198 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondMutable(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 52, ptr @.d199 }, 1
  %t6 = extractvalue { i64, ptr } { i64 52, ptr @.d199 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 81, { i64, ptr } { i64 3, ptr @.d200 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondName(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 62, ptr @.d201 }, 1
  %t6 = extractvalue { i64, ptr } { i64 62, ptr @.d201 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 80, { i64, ptr } { i64 3, ptr @.d202 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondNoMeet(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 59, ptr @.d203 }, 1
  %t6 = extractvalue { i64, ptr } { i64 59, ptr @.d203 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 85, { i64, ptr } { i64 3, ptr @.d204 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondNotBool(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 24, ptr @.d205 }, 1
  %t3 = extractvalue { i64, ptr } { i64 24, ptr @.d205 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 14, ptr @.d206 }, 1
  %t9 = extractvalue { i64, ptr } { i64 14, ptr @.d206 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 86, { i64, ptr } { i64 2, ptr @.d207 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondNotBoolType(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 29, ptr @.d208 }, 1
  %t3 = extractvalue { i64, ptr } { i64 29, ptr @.d208 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 324, { i64, ptr } { i64 0, ptr @.d209 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondTooDeep(ptr %v0, i64 %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 64, ptr @.d210 }, 1
  %t3 = extractvalue { i64, ptr } { i64 64, ptr @.d210 }, 0
  %t5 = call i64 @__olang_fmt_i64(ptr null, i64 %a0)
  %t6 = add i64 %t3, %t5
  %t7 = extractvalue { i64, ptr } { i64 12, ptr @.d211 }, 1
  %t8 = extractvalue { i64, ptr } { i64 12, ptr @.d211 }, 0
  %t9 = add i64 %t6, %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t9)
  call void @olang_textcopy(ptr %t10, ptr %t2, i64 %t3)
  %t11 = getelementptr i8, ptr %t10, i64 %t3
  %t12 = call i64 @__olang_fmt_i64(ptr %t11, i64 %a0)
  %t13 = getelementptr i8, ptr %t11, i64 %t5
  call void @olang_textcopy(ptr %t13, ptr %t7, i64 %t8)
  %t14 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t10, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 515, { i64, ptr } { i64 3, ptr @.d212 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondTypes(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 28, ptr @.d213 }, 1
  %t6 = extractvalue { i64, ptr } { i64 28, ptr @.d213 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 84, { i64, ptr } { i64 2, ptr @.d214 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondUndecidable(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 60, ptr @.d215 }, 1
  %t3 = extractvalue { i64, ptr } { i64 60, ptr @.d215 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 528, { i64, ptr } { i64 3, ptr @.d216 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondUnknownBuild(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 13, ptr @.d217 }, 1
  %t3 = extractvalue { i64, ptr } { i64 13, ptr @.d217 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 530, { i64, ptr } { i64 3, ptr @.d218 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondUnseen(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 529, { i64, ptr } { i64 3, ptr @.d219 }, { i64, ptr } { i64 92, ptr @.d220 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eConditionConstant(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 405, { i64, ptr } { i64 3, ptr @.d221 }, { i64, ptr } { i64 107, ptr @.d222 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eConstraintDisagrees(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 87, ptr @.d223 }, 1
  %t6 = extractvalue { i64, ptr } { i64 87, ptr @.d223 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 127, { i64, ptr } { i64 3, ptr @.d224 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eConstraintNotTrait(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 133, ptr @.d225 }, 1
  %t6 = extractvalue { i64, ptr } { i64 133, ptr @.d225 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 147, { i64, ptr } { i64 7, ptr @.d226 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eConstraintSealed(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l13 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = extractvalue { i64, ptr } { i64 33, ptr @.d227 }, 1
  %t10 = extractvalue { i64, ptr } { i64 33, ptr @.d227 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 4, ptr @.d228 }, 1
  %t17 = extractvalue { i64, ptr } { i64 4, ptr @.d228 }, 0
  %t18 = add i64 %t15, %t17
  %t20 = extractvalue { i64, ptr } %a2, 1
  %t21 = extractvalue { i64, ptr } %a2, 0
  %t22 = add i64 %t18, %t21
  %t23 = extractvalue { i64, ptr } { i64 2, ptr @.d229 }, 1
  %t24 = extractvalue { i64, ptr } { i64 2, ptr @.d229 }, 0
  %t25 = add i64 %t22, %t24
  %t27 = extractvalue { i64, ptr } %a3, 1
  %t28 = extractvalue { i64, ptr } %a3, 0
  %t29 = add i64 %t25, %t28
  %t30 = extractvalue { i64, ptr } { i64 50, ptr @.d230 }, 1
  %t31 = extractvalue { i64, ptr } { i64 50, ptr @.d230 }, 0
  %t32 = add i64 %t29, %t31
  %t34 = extractvalue { i64, ptr } %a4, 1
  %t35 = extractvalue { i64, ptr } %a4, 0
  %t36 = add i64 %t32, %t35
  %t37 = extractvalue { i64, ptr } { i64 12, ptr @.d231 }, 1
  %t38 = extractvalue { i64, ptr } { i64 12, ptr @.d231 }, 0
  %t39 = add i64 %t36, %t38
  %t40 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t39)
  call void @olang_textcopy(ptr %t40, ptr %t7, i64 %t8)
  %t41 = getelementptr i8, ptr %t40, i64 %t8
  call void @olang_textcopy(ptr %t41, ptr %t9, i64 %t10)
  %t42 = getelementptr i8, ptr %t41, i64 %t10
  call void @olang_textcopy(ptr %t42, ptr %t13, i64 %t14)
  %t43 = getelementptr i8, ptr %t42, i64 %t14
  call void @olang_textcopy(ptr %t43, ptr %t16, i64 %t17)
  %t44 = getelementptr i8, ptr %t43, i64 %t17
  call void @olang_textcopy(ptr %t44, ptr %t20, i64 %t21)
  %t45 = getelementptr i8, ptr %t44, i64 %t21
  call void @olang_textcopy(ptr %t45, ptr %t23, i64 %t24)
  %t46 = getelementptr i8, ptr %t45, i64 %t24
  call void @olang_textcopy(ptr %t46, ptr %t27, i64 %t28)
  %t47 = getelementptr i8, ptr %t46, i64 %t28
  call void @olang_textcopy(ptr %t47, ptr %t30, i64 %t31)
  %t48 = getelementptr i8, ptr %t47, i64 %t31
  call void @olang_textcopy(ptr %t48, ptr %t34, i64 %t35)
  %t49 = getelementptr i8, ptr %t48, i64 %t35
  call void @olang_textcopy(ptr %t49, ptr %t37, i64 %t38)
  %t50 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t40, 1
  %t53 = extractvalue { i64, ptr } %t51, 0
  %t54 = extractvalue { i64, ptr } %t51, 1
  %t55 = mul i64 %t53, 1
  %t56 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t55)
  call void @llvm.memcpy.p0.p0.i64(ptr %t56, ptr %t54, i64 %t55, i1 false)
  %t57 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t56, 1
  %t61 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v5, ptr %v5, ptr %v5, i32 130, { i64, ptr } { i64 8, ptr @.d232 }, { i64, ptr } %t58)
  store %"compiler/msgs:Msg" %t61, ptr %l13
  br label %bb1
bb1:
  %t62 = load %"compiler/msgs:Msg", ptr %l13
  store %"compiler/msgs:Msg" %t62, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eConstraintUnmet(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = extractvalue { i64, ptr } { i64 33, ptr @.d233 }, 1
  %t8 = extractvalue { i64, ptr } { i64 33, ptr @.d233 }, 0
  %t9 = add i64 %t6, %t8
  %t11 = extractvalue { i64, ptr } %a1, 1
  %t12 = extractvalue { i64, ptr } %a1, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 4, ptr @.d234 }, 1
  %t15 = extractvalue { i64, ptr } { i64 4, ptr @.d234 }, 0
  %t16 = add i64 %t13, %t15
  %t18 = extractvalue { i64, ptr } %a2, 1
  %t19 = extractvalue { i64, ptr } %a2, 0
  %t20 = add i64 %t16, %t19
  %t21 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t20)
  call void @olang_textcopy(ptr %t21, ptr %t5, i64 %t6)
  %t22 = getelementptr i8, ptr %t21, i64 %t6
  call void @olang_textcopy(ptr %t22, ptr %t7, i64 %t8)
  %t23 = getelementptr i8, ptr %t22, i64 %t8
  call void @olang_textcopy(ptr %t23, ptr %t11, i64 %t12)
  %t24 = getelementptr i8, ptr %t23, i64 %t12
  call void @olang_textcopy(ptr %t24, ptr %t14, i64 %t15)
  %t25 = getelementptr i8, ptr %t24, i64 %t15
  call void @olang_textcopy(ptr %t25, ptr %t18, i64 %t19)
  %t26 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t21, 1
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t30 = extractvalue { i64, ptr } %t27, 1
  %t31 = mul i64 %t29, 1
  %t32 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t31)
  call void @llvm.memcpy.p0.p0.i64(ptr %t32, ptr %t30, i64 %t31, i1 false)
  %t33 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  %t37 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 128, { i64, ptr } { i64 3, ptr @.d235 }, { i64, ptr } %t34)
  store %"compiler/msgs:Msg" %t37, ptr %l9
  br label %bb1
bb1:
  %t38 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t38, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eConstraintUnmetHash(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = extractvalue { i64, ptr } { i64 33, ptr @.d236 }, 1
  %t8 = extractvalue { i64, ptr } { i64 33, ptr @.d236 }, 0
  %t9 = add i64 %t6, %t8
  %t11 = extractvalue { i64, ptr } %a1, 1
  %t12 = extractvalue { i64, ptr } %a1, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 4, ptr @.d237 }, 1
  %t15 = extractvalue { i64, ptr } { i64 4, ptr @.d237 }, 0
  %t16 = add i64 %t13, %t15
  %t18 = extractvalue { i64, ptr } %a2, 1
  %t19 = extractvalue { i64, ptr } %a2, 0
  %t20 = add i64 %t16, %t19
  %t21 = extractvalue { i64, ptr } { i64 59, ptr @.d238 }, 1
  %t22 = extractvalue { i64, ptr } { i64 59, ptr @.d238 }, 0
  %t23 = add i64 %t20, %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t5, i64 %t6)
  %t25 = getelementptr i8, ptr %t24, i64 %t6
  call void @olang_textcopy(ptr %t25, ptr %t7, i64 %t8)
  %t26 = getelementptr i8, ptr %t25, i64 %t8
  call void @olang_textcopy(ptr %t26, ptr %t11, i64 %t12)
  %t27 = getelementptr i8, ptr %t26, i64 %t12
  call void @olang_textcopy(ptr %t27, ptr %t14, i64 %t15)
  %t28 = getelementptr i8, ptr %t27, i64 %t15
  call void @olang_textcopy(ptr %t28, ptr %t18, i64 %t19)
  %t29 = getelementptr i8, ptr %t28, i64 %t19
  call void @olang_textcopy(ptr %t29, ptr %t21, i64 %t22)
  %t30 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t24, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t41 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 131, { i64, ptr } { i64 9, ptr @.d239 }, { i64, ptr } %t38)
  store %"compiler/msgs:Msg" %t41, ptr %l9
  br label %bb1
bb1:
  %t42 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t42, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eConstraintUnmetMethod(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l11 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = extractvalue { i64, ptr } { i64 33, ptr @.d240 }, 1
  %t9 = extractvalue { i64, ptr } { i64 33, ptr @.d240 }, 0
  %t10 = add i64 %t7, %t9
  %t12 = extractvalue { i64, ptr } %a1, 1
  %t13 = extractvalue { i64, ptr } %a1, 0
  %t14 = add i64 %t10, %t13
  %t15 = extractvalue { i64, ptr } { i64 4, ptr @.d241 }, 1
  %t16 = extractvalue { i64, ptr } { i64 4, ptr @.d241 }, 0
  %t17 = add i64 %t14, %t16
  %t19 = extractvalue { i64, ptr } %a2, 1
  %t20 = extractvalue { i64, ptr } %a2, 0
  %t21 = add i64 %t17, %t20
  %t22 = extractvalue { i64, ptr } { i64 19, ptr @.d242 }, 1
  %t23 = extractvalue { i64, ptr } { i64 19, ptr @.d242 }, 0
  %t24 = add i64 %t21, %t23
  %t26 = extractvalue { i64, ptr } %a3, 1
  %t27 = extractvalue { i64, ptr } %a3, 0
  %t28 = add i64 %t24, %t27
  %t29 = extractvalue { i64, ptr } { i64 10, ptr @.d243 }, 1
  %t30 = extractvalue { i64, ptr } { i64 10, ptr @.d243 }, 0
  %t31 = add i64 %t28, %t30
  %t32 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t31)
  call void @olang_textcopy(ptr %t32, ptr %t6, i64 %t7)
  %t33 = getelementptr i8, ptr %t32, i64 %t7
  call void @olang_textcopy(ptr %t33, ptr %t8, i64 %t9)
  %t34 = getelementptr i8, ptr %t33, i64 %t9
  call void @olang_textcopy(ptr %t34, ptr %t12, i64 %t13)
  %t35 = getelementptr i8, ptr %t34, i64 %t13
  call void @olang_textcopy(ptr %t35, ptr %t15, i64 %t16)
  %t36 = getelementptr i8, ptr %t35, i64 %t16
  call void @olang_textcopy(ptr %t36, ptr %t19, i64 %t20)
  %t37 = getelementptr i8, ptr %t36, i64 %t20
  call void @olang_textcopy(ptr %t37, ptr %t22, i64 %t23)
  %t38 = getelementptr i8, ptr %t37, i64 %t23
  call void @olang_textcopy(ptr %t38, ptr %t26, i64 %t27)
  %t39 = getelementptr i8, ptr %t38, i64 %t27
  call void @olang_textcopy(ptr %t39, ptr %t29, i64 %t30)
  %t40 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t32, 1
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t44 = extractvalue { i64, ptr } %t41, 1
  %t45 = mul i64 %t43, 1
  %t46 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t45)
  call void @llvm.memcpy.p0.p0.i64(ptr %t46, ptr %t44, i64 %t45, i1 false)
  %t47 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  %t51 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, i32 129, { i64, ptr } { i64 3, ptr @.d244 }, { i64, ptr } %t48)
  store %"compiler/msgs:Msg" %t51, ptr %l11
  br label %bb1
bb1:
  %t52 = load %"compiler/msgs:Msg", ptr %l11
  store %"compiler/msgs:Msg" %t52, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eContainerScopeUnbuildable(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 399, { i64, ptr } { i64 4, ptr @.d245 }, { i64, ptr } { i64 87, ptr @.d246 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eConversionRepresentation(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 15, ptr @.d247 }, 1
  %t7 = extractvalue { i64, ptr } { i64 15, ptr @.d247 }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 31, ptr @.d248 }, 1
  %t14 = extractvalue { i64, ptr } { i64 31, ptr @.d248 }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 267, { i64, ptr } { i64 3, ptr @.d249 }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eConvertNotNumber(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 18, ptr @.d250 }, 1
  %t7 = extractvalue { i64, ptr } { i64 18, ptr @.d250 }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 21, ptr @.d251 }, 1
  %t14 = extractvalue { i64, ptr } { i64 21, ptr @.d251 }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 268, { i64, ptr } { i64 3, ptr @.d252 }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCtorFieldNamesVar(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l11 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } { i64 18, ptr @.d253 }, 1
  %t6 = extractvalue { i64, ptr } { i64 18, ptr @.d253 }, 0
  %t8 = extractvalue { i64, ptr } %a0, 1
  %t9 = extractvalue { i64, ptr } %a0, 0
  %t10 = add i64 %t6, %t9
  %t11 = extractvalue { i64, ptr } { i64 7, ptr @.d254 }, 1
  %t12 = extractvalue { i64, ptr } { i64 7, ptr @.d254 }, 0
  %t13 = add i64 %t10, %t12
  %t15 = extractvalue { i64, ptr } %a1, 1
  %t16 = extractvalue { i64, ptr } %a1, 0
  %t17 = add i64 %t13, %t16
  %t18 = extractvalue { i64, ptr } { i64 105, ptr @.d255 }, 1
  %t19 = extractvalue { i64, ptr } { i64 105, ptr @.d255 }, 0
  %t20 = add i64 %t17, %t19
  %t22 = extractvalue { i64, ptr } %a2, 1
  %t23 = extractvalue { i64, ptr } %a2, 0
  %t24 = add i64 %t20, %t23
  %t25 = extractvalue { i64, ptr } { i64 1, ptr @.d256 }, 1
  %t26 = extractvalue { i64, ptr } { i64 1, ptr @.d256 }, 0
  %t27 = add i64 %t24, %t26
  %t29 = extractvalue { i64, ptr } %a3, 1
  %t30 = extractvalue { i64, ptr } %a3, 0
  %t31 = add i64 %t27, %t30
  %t32 = extractvalue { i64, ptr } { i64 2, ptr @.d257 }, 1
  %t33 = extractvalue { i64, ptr } { i64 2, ptr @.d257 }, 0
  %t34 = add i64 %t31, %t33
  %t35 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t34)
  call void @olang_textcopy(ptr %t35, ptr %t5, i64 %t6)
  %t36 = getelementptr i8, ptr %t35, i64 %t6
  call void @olang_textcopy(ptr %t36, ptr %t8, i64 %t9)
  %t37 = getelementptr i8, ptr %t36, i64 %t9
  call void @olang_textcopy(ptr %t37, ptr %t11, i64 %t12)
  %t38 = getelementptr i8, ptr %t37, i64 %t12
  call void @olang_textcopy(ptr %t38, ptr %t15, i64 %t16)
  %t39 = getelementptr i8, ptr %t38, i64 %t16
  call void @olang_textcopy(ptr %t39, ptr %t18, i64 %t19)
  %t40 = getelementptr i8, ptr %t39, i64 %t19
  call void @olang_textcopy(ptr %t40, ptr %t22, i64 %t23)
  %t41 = getelementptr i8, ptr %t40, i64 %t23
  call void @olang_textcopy(ptr %t41, ptr %t25, i64 %t26)
  %t42 = getelementptr i8, ptr %t41, i64 %t26
  call void @olang_textcopy(ptr %t42, ptr %t29, i64 %t30)
  %t43 = getelementptr i8, ptr %t42, i64 %t30
  call void @olang_textcopy(ptr %t43, ptr %t32, i64 %t33)
  %t44 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t35, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = extractvalue { i64, ptr } %t45, 1
  %t49 = mul i64 %t47, 1
  %t50 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t49)
  call void @llvm.memcpy.p0.p0.i64(ptr %t50, ptr %t48, i64 %t49, i1 false)
  %t51 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  %t55 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, i32 261, { i64, ptr } { i64 4, ptr @.d258 }, { i64, ptr } %t52)
  store %"compiler/msgs:Msg" %t55, ptr %l11
  br label %bb1
bb1:
  %t56 = load %"compiler/msgs:Msg", ptr %l11
  store %"compiler/msgs:Msg" %t56, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCtorFieldNoValue(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 6, ptr @.d259 }, 1
  %t3 = extractvalue { i64, ptr } { i64 6, ptr @.d259 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 74, ptr @.d260 }, 1
  %t9 = extractvalue { i64, ptr } { i64 74, ptr @.d260 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 157, { i64, ptr } { i64 2, ptr @.d261 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCtorGenericInferredField(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 6, ptr @.d262 }, 1
  %t4 = extractvalue { i64, ptr } { i64 6, ptr @.d262 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 58, ptr @.d263 }, 1
  %t10 = extractvalue { i64, ptr } { i64 58, ptr @.d263 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 58, ptr @.d264 }, 1
  %t17 = extractvalue { i64, ptr } { i64 58, ptr @.d264 }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 262, { i64, ptr } { i64 4, ptr @.d265 }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCtorTypeArgsNotInferable(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 22, ptr @.d266 }, 1
  %t4 = extractvalue { i64, ptr } { i64 22, ptr @.d266 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 55, ptr @.d267 }, 1
  %t10 = extractvalue { i64, ptr } { i64 55, ptr @.d267 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 10, ptr @.d268 }, 1
  %t17 = extractvalue { i64, ptr } { i64 10, ptr @.d268 }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 259, { i64, ptr } { i64 4, ptr @.d269 }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCtorVarOfGeneric(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = extractvalue { i64, ptr } { i64 15, ptr @.d270 }, 1
  %t8 = extractvalue { i64, ptr } { i64 15, ptr @.d270 }, 0
  %t9 = add i64 %t6, %t8
  %t11 = extractvalue { i64, ptr } %a1, 1
  %t12 = extractvalue { i64, ptr } %a1, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 81, ptr @.d271 }, 1
  %t15 = extractvalue { i64, ptr } { i64 81, ptr @.d271 }, 0
  %t16 = add i64 %t13, %t15
  %t18 = extractvalue { i64, ptr } %a2, 1
  %t19 = extractvalue { i64, ptr } %a2, 0
  %t20 = add i64 %t16, %t19
  %t21 = extractvalue { i64, ptr } { i64 19, ptr @.d272 }, 1
  %t22 = extractvalue { i64, ptr } { i64 19, ptr @.d272 }, 0
  %t23 = add i64 %t20, %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t5, i64 %t6)
  %t25 = getelementptr i8, ptr %t24, i64 %t6
  call void @olang_textcopy(ptr %t25, ptr %t7, i64 %t8)
  %t26 = getelementptr i8, ptr %t25, i64 %t8
  call void @olang_textcopy(ptr %t26, ptr %t11, i64 %t12)
  %t27 = getelementptr i8, ptr %t26, i64 %t12
  call void @olang_textcopy(ptr %t27, ptr %t14, i64 %t15)
  %t28 = getelementptr i8, ptr %t27, i64 %t15
  call void @olang_textcopy(ptr %t28, ptr %t18, i64 %t19)
  %t29 = getelementptr i8, ptr %t28, i64 %t19
  call void @olang_textcopy(ptr %t29, ptr %t21, i64 %t22)
  %t30 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t24, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t41 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 263, { i64, ptr } { i64 4, ptr @.d273 }, { i64, ptr } %t38)
  store %"compiler/msgs:Msg" %t41, ptr %l9
  br label %bb1
bb1:
  %t42 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t42, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCtorVarsNotInferable(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 5, ptr @.d274 }, 1
  %t3 = extractvalue { i64, ptr } { i64 5, ptr @.d274 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 65, ptr @.d275 }, 1
  %t9 = extractvalue { i64, ptr } { i64 65, ptr @.d275 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 260, { i64, ptr } { i64 4, ptr @.d276 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeclFromNoreturn(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 446, { i64, ptr } { i64 3, ptr @.d277 }, { i64, ptr } { i64 61, ptr @.d278 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeclFromNull(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 236, { i64, ptr } { i64 3, ptr @.d279 }, { i64, ptr } { i64 91, ptr @.d280 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeclaredOverAggregate(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 55, ptr @.d281 }, 1
  %t3 = extractvalue { i64, ptr } { i64 55, ptr @.d281 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 38, ptr @.d282 }, 1
  %t9 = extractvalue { i64, ptr } { i64 38, ptr @.d282 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 173, { i64, ptr } { i64 3, ptr @.d283 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeclaredTwice(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 18, ptr @.d284 }, 1
  %t6 = extractvalue { i64, ptr } { i64 18, ptr @.d284 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 154, { i64, ptr } { i64 0, ptr @.d285 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultAmbiguous(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 11, ptr @.d286 }, 1
  %t4 = extractvalue { i64, ptr } { i64 11, ptr @.d286 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 34, ptr @.d287 }, 1
  %t10 = extractvalue { i64, ptr } { i64 34, ptr @.d287 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 25, ptr @.d288 }, 1
  %t17 = extractvalue { i64, ptr } { i64 25, ptr @.d288 }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 381, { i64, ptr } { i64 4, ptr @.d289 }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultArgNoDefault(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 10, ptr @.d290 }, 1
  %t3 = extractvalue { i64, ptr } { i64 10, ptr @.d290 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 57, ptr @.d291 }, 1
  %t9 = extractvalue { i64, ptr } { i64 57, ptr @.d291 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 264, { i64, ptr } { i64 4, ptr @.d292 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultArgNotAllowed(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 351, { i64, ptr } { i64 4, ptr @.d293 }, { i64, ptr } { i64 67, ptr @.d294 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultCount(ptr %v0, i64 %a0, i64 %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 9, ptr @.d295 }, 1
  %t4 = extractvalue { i64, ptr } { i64 9, ptr @.d295 }, 0
  %t6 = call i64 @__olang_fmt_i64(ptr null, i64 %a0)
  %t7 = add i64 %t4, %t6
  %t8 = extractvalue { i64, ptr } { i64 33, ptr @.d296 }, 1
  %t9 = extractvalue { i64, ptr } { i64 33, ptr @.d296 }, 0
  %t10 = add i64 %t7, %t9
  %t12 = call i64 @__olang_fmt_i64(ptr null, i64 %a1)
  %t13 = add i64 %t10, %t12
  %t14 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t13)
  call void @olang_textcopy(ptr %t14, ptr %t3, i64 %t4)
  %t15 = getelementptr i8, ptr %t14, i64 %t4
  %t16 = call i64 @__olang_fmt_i64(ptr %t15, i64 %a0)
  %t17 = getelementptr i8, ptr %t15, i64 %t6
  call void @olang_textcopy(ptr %t17, ptr %t8, i64 %t9)
  %t18 = getelementptr i8, ptr %t17, i64 %t9
  %t19 = call i64 @__olang_fmt_i64(ptr %t18, i64 %a1)
  %t20 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t14, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 359, { i64, ptr } { i64 3, ptr @.d297 }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultDead(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 365, { i64, ptr } { i64 3, ptr @.d298 }, { i64, ptr } { i64 80, ptr @.d299 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultHoldsReferences(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 360, { i64, ptr } { i64 3, ptr @.d300 }, { i64, ptr } { i64 131, ptr @.d301 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultInStatement(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 364, { i64, ptr } { i64 3, ptr @.d302 }, { i64, ptr } { i64 67, ptr @.d303 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultNeedsCatch(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 369, { i64, ptr } { i64 3, ptr @.d304 }, { i64, ptr } { i64 54, ptr @.d305 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultNoValue(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 368, { i64, ptr } { i64 3, ptr @.d306 }, { i64, ptr } { i64 77, ptr @.d307 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultNotComputable(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 63, ptr @.d308 }, 1
  %t3 = extractvalue { i64, ptr } { i64 63, ptr @.d308 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 500, { i64, ptr } { i64 3, ptr @.d309 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultNotTrailing(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 80, ptr @.d310 }, 1
  %t6 = extractvalue { i64, ptr } { i64 80, ptr @.d310 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 159, { i64, ptr } { i64 3, ptr @.d311 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultOutsideTrait(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 19, ptr @.d312 }, 1
  %t3 = extractvalue { i64, ptr } { i64 19, ptr @.d312 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 35, ptr @.d313 }, 1
  %t9 = extractvalue { i64, ptr } { i64 35, ptr @.d313 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 190, { i64, ptr } { i64 4, ptr @.d314 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultScope(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 361, { i64, ptr } { i64 8, ptr @.d315 }, { i64, ptr } { i64 83, ptr @.d316 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultShadowsRequired(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 6, ptr @.d317 }, 1
  %t4 = extractvalue { i64, ptr } { i64 6, ptr @.d317 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 27, ptr @.d318 }, 1
  %t10 = extractvalue { i64, ptr } { i64 27, ptr @.d318 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 39, ptr @.d319 }, 1
  %t17 = extractvalue { i64, ptr } { i64 39, ptr @.d319 }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 192, { i64, ptr } { i64 4, ptr @.d320 }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeferErrorEscapes(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 352, { i64, ptr } { i64 4, ptr @.d321 }, { i64, ptr } { i64 52, ptr @.d322 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeferLoopJump(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 62, ptr @.d323 }, 1
  %t6 = extractvalue { i64, ptr } { i64 62, ptr @.d323 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 493, { i64, ptr } { i64 4, ptr @.d324 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeferReturns(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 438, { i64, ptr } { i64 4, ptr @.d325 }, { i64, ptr } { i64 62, ptr @.d326 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineBadNumber(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 8, ptr @.d327 }, 1
  %t4 = extractvalue { i64, ptr } { i64 8, ptr @.d327 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 1, ptr @.d328 }, 1
  %t10 = extractvalue { i64, ptr } { i64 1, ptr @.d328 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 60, ptr @.d329 }, 1
  %t17 = extractvalue { i64, ptr } { i64 60, ptr @.d329 }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 35, { i64, ptr } { i64 3, ptr @.d330 }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineBuiltin(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 46, ptr @.d331 }, 1
  %t3 = extractvalue { i64, ptr } { i64 46, ptr @.d331 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 39, { i64, ptr } { i64 4, ptr @.d332 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineFloatRange(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 8, ptr @.d333 }, 1
  %t4 = extractvalue { i64, ptr } { i64 8, ptr @.d333 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 1, ptr @.d334 }, 1
  %t10 = extractvalue { i64, ptr } { i64 1, ptr @.d334 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 20, ptr @.d335 }, 1
  %t17 = extractvalue { i64, ptr } { i64 20, ptr @.d335 }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 38, { i64, ptr } { i64 3, ptr @.d336 }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineIntRange(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 8, ptr @.d337 }, 1
  %t4 = extractvalue { i64, ptr } { i64 8, ptr @.d337 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 1, ptr @.d338 }, 1
  %t10 = extractvalue { i64, ptr } { i64 1, ptr @.d338 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 16, ptr @.d339 }, 1
  %t17 = extractvalue { i64, ptr } { i64 16, ptr @.d339 }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 36, { i64, ptr } { i64 3, ptr @.d340 }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineMissing(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 31, { i64, ptr } { i64 3, ptr @.d341 }, { i64, ptr } { i64 33, ptr @.d342 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineNegRange(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 8, ptr @.d343 }, 1
  %t4 = extractvalue { i64, ptr } { i64 8, ptr @.d343 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 1, ptr @.d344 }, 1
  %t10 = extractvalue { i64, ptr } { i64 1, ptr @.d344 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 21, ptr @.d345 }, 1
  %t17 = extractvalue { i64, ptr } { i64 21, ptr @.d345 }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 37, { i64, ptr } { i64 3, ptr @.d346 }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineNotName(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 8, ptr @.d347 }, 1
  %t4 = extractvalue { i64, ptr } { i64 8, ptr @.d347 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 1, ptr @.d348 }, 1
  %t10 = extractvalue { i64, ptr } { i64 1, ptr @.d348 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 31, ptr @.d349 }, 1
  %t17 = extractvalue { i64, ptr } { i64 31, ptr @.d349 }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 33, { i64, ptr } { i64 3, ptr @.d350 }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineShape(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 33, ptr @.d351 }, 1
  %t3 = extractvalue { i64, ptr } { i64 33, ptr @.d351 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 1, ptr @.d352 }, 1
  %t9 = extractvalue { i64, ptr } { i64 1, ptr @.d352 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 32, { i64, ptr } { i64 3, ptr @.d353 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineTwice(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 8, ptr @.d354 }, 1
  %t4 = extractvalue { i64, ptr } { i64 8, ptr @.d354 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 1, ptr @.d355 }, 1
  %t10 = extractvalue { i64, ptr } { i64 1, ptr @.d355 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 15, ptr @.d356 }, 1
  %t17 = extractvalue { i64, ptr } { i64 15, ptr @.d356 }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 34, { i64, ptr } { i64 3, ptr @.d357 }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestructCount(ptr %v0, i64 %a0, i64 %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = call i64 @__olang_fmt_i64(ptr null, i64 %a0)
  %t5 = extractvalue { i64, ptr } { i64 13, ptr @.d358 }, 1
  %t6 = extractvalue { i64, ptr } { i64 13, ptr @.d358 }, 0
  %t7 = add i64 %t4, %t6
  %t9 = call i64 @__olang_fmt_i64(ptr null, i64 %a1)
  %t10 = add i64 %t7, %t9
  %t11 = extractvalue { i64, ptr } { i64 39, ptr @.d359 }, 1
  %t12 = extractvalue { i64, ptr } { i64 39, ptr @.d359 }, 0
  %t13 = add i64 %t10, %t12
  %t14 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t13)
  %t15 = call i64 @__olang_fmt_i64(ptr %t14, i64 %a0)
  %t16 = getelementptr i8, ptr %t14, i64 %t4
  call void @olang_textcopy(ptr %t16, ptr %t5, i64 %t6)
  %t17 = getelementptr i8, ptr %t16, i64 %t6
  %t18 = call i64 @__olang_fmt_i64(ptr %t17, i64 %a1)
  %t19 = getelementptr i8, ptr %t17, i64 %t9
  call void @olang_textcopy(ptr %t19, ptr %t11, i64 %t12)
  %t20 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t14, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 389, { i64, ptr } { i64 3, ptr @.d360 }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestructInBody(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 73, { i64, ptr } { i64 2, ptr @.d361 }, { i64, ptr } { i64 111, ptr @.d362 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestructNotName(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 387, { i64, ptr } { i64 3, ptr @.d363 }, { i64, ptr } { i64 83, ptr @.d364 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestructOneValue(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 58, ptr @.d365 }, 1
  %t3 = extractvalue { i64, ptr } { i64 58, ptr @.d365 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 388, { i64, ptr } { i64 3, ptr @.d366 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestructTypeByValue(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 59, ptr @.d367 }, 1
  %t7 = extractvalue { i64, ptr } { i64 59, ptr @.d367 }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 1, ptr @.d368 }, 1
  %t14 = extractvalue { i64, ptr } { i64 1, ptr @.d368 }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 151, { i64, ptr } { i64 3, ptr @.d369 }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDigitSeparator(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 65, { i64, ptr } { i64 4, ptr @.d370 }, { i64, ptr } { i64 45, ptr @.d371 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDivideByZero(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 314, { i64, ptr } { i64 3, ptr @.d372 }, { i64, ptr } { i64 16, ptr @.d373 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDoubleReferenceMarker(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 150, { i64, ptr } { i64 3, ptr @.d374 }, { i64, ptr } { i64 41, ptr @.d375 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eElemNotInArrayScope(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 392, { i64, ptr } { i64 4, ptr @.d376 }, { i64, ptr } { i64 95, ptr @.d377 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eElemOutlived(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 393, { i64, ptr } { i64 4, ptr @.d378 }, { i64, ptr } { i64 87, ptr @.d379 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eElemRefShape(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 9, ptr @.d380 }, 1
  %t4 = extractvalue { i64, ptr } { i64 9, ptr @.d380 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 8, ptr @.d381 }, 1
  %t10 = extractvalue { i64, ptr } { i64 8, ptr @.d381 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 53, ptr @.d382 }, 1
  %t17 = extractvalue { i64, ptr } { i64 53, ptr @.d382 }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 214, { i64, ptr } { i64 4, ptr @.d383 }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eEmptyChar(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 58, { i64, ptr } { i64 3, ptr @.d384 }, { i64, ptr } { i64 23, ptr @.d385 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eEmptyDestructor(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 496, { i64, ptr } { i64 3, ptr @.d386 }, { i64, ptr } { i64 40, ptr @.d387 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local void @compiler_2fmsgs_2eEndOfFile_2einit() #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l3 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 11, ptr @.d388 }, ptr %l0, !tbaa !27
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l1, !tbaa !27
  %t2 = load { i64, ptr }, ptr @G_2ecompiler_2fmsgs_2eEndOfFile, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 0
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t4, 0
  store i64 %t5, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = icmp eq i64 %t3, %t7
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2fmsgs_2eEndOfFile, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = mul i64 %t14, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t11, ptr %t13, i64 %t15, i1 false)
  br label %bb3
bb2:
  %t16 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l5, !tbaa !24
  %t18 = load i64, ptr %l5, !tbaa !24
  %t19 = mul i64 %t18, 1
  %t20 = load ptr, ptr @__olang_prog_scope
  %t21 = call ptr @__olang_scope_alloc_zeroed(ptr %t20, i64 %t19)
  %t22 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l6, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = load i64, ptr %l5, !tbaa !24
  %t29 = mul i64 %t28, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t25, ptr %t27, i64 %t29, i1 false)
  %t30 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t30, ptr @G_2ecompiler_2fmsgs_2eEndOfFile, !tbaa !27
  br label %bb3
bb3:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmsgs_2eEndOfLine_2einit() #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l3 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 11, ptr @.d389 }, ptr %l0, !tbaa !27
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l1, !tbaa !27
  %t2 = load { i64, ptr }, ptr @G_2ecompiler_2fmsgs_2eEndOfLine, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 0
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t4, 0
  store i64 %t5, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = icmp eq i64 %t3, %t7
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2fmsgs_2eEndOfLine, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = mul i64 %t14, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t11, ptr %t13, i64 %t15, i1 false)
  br label %bb3
bb2:
  %t16 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l5, !tbaa !24
  %t18 = load i64, ptr %l5, !tbaa !24
  %t19 = mul i64 %t18, 1
  %t20 = load ptr, ptr @__olang_prog_scope
  %t21 = call ptr @__olang_scope_alloc_zeroed(ptr %t20, i64 %t19)
  %t22 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l6, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = load i64, ptr %l5, !tbaa !24
  %t29 = mul i64 %t28, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t25, ptr %t27, i64 %t29, i1 false)
  %t30 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t30, ptr @G_2ecompiler_2fmsgs_2eEndOfLine, !tbaa !27
  br label %bb3
bb3:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eEnumCaseInUse(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 10, ptr @.d390 }, 1
  %t3 = extractvalue { i64, ptr } { i64 10, ptr @.d390 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 20, ptr @.d391 }, 1
  %t9 = extractvalue { i64, ptr } { i64 20, ptr @.d391 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 153, { i64, ptr } { i64 3, ptr @.d392 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eEqShape(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 184, { i64, ptr } { i64 4, ptr @.d393 }, { i64, ptr } { i64 66, ptr @.d394 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eEqStrWrites(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 85, ptr @.d395 }, 1
  %t6 = extractvalue { i64, ptr } { i64 85, ptr @.d395 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 186, { i64, ptr } { i64 10, ptr @.d396 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrorAfterQuestion(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 78, { i64, ptr } { i64 3, ptr @.d397 }, { i64, ptr } { i64 84, ptr @.d398 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrorOutsideFunction(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 449, { i64, ptr } { i64 2, ptr @.d399 }, { i64, ptr } { i64 52, ptr @.d400 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrorTypeAsValue(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 132, ptr @.d401 }, 1
  %t7 = extractvalue { i64, ptr } { i64 132, ptr @.d401 }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 11, ptr @.d402 }, 1
  %t14 = extractvalue { i64, ptr } { i64 11, ptr @.d402 }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 375, { i64, ptr } { i64 3, ptr @.d403 }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrorUndeclared(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 31, ptr @.d404 }, 1
  %t3 = extractvalue { i64, ptr } { i64 31, ptr @.d404 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 19, ptr @.d405 }, 1
  %t9 = extractvalue { i64, ptr } { i64 19, ptr @.d405 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 454, { i64, ptr } { i64 2, ptr @.d406 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrorWordAsValue(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 1, ptr @.d407 }, 1
  %t4 = extractvalue { i64, ptr } { i64 1, ptr @.d407 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 55, ptr @.d408 }, 1
  %t10 = extractvalue { i64, ptr } { i64 55, ptr @.d408 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 36, ptr @.d409 }, 1
  %t17 = extractvalue { i64, ptr } { i64 36, ptr @.d409 }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 378, { i64, ptr } { i64 3, ptr @.d410 }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrorWordInUse(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 11, ptr @.d411 }, 1
  %t3 = extractvalue { i64, ptr } { i64 11, ptr @.d411 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 20, ptr @.d412 }, 1
  %t9 = extractvalue { i64, ptr } { i64 20, ptr @.d412 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 170, { i64, ptr } { i64 3, ptr @.d413 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrorWordIsPrivate(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 11, ptr @.d414 }, 1
  %t3 = extractvalue { i64, ptr } { i64 11, ptr @.d414 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 25, ptr @.d415 }, 1
  %t9 = extractvalue { i64, ptr } { i64 25, ptr @.d415 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 453, { i64, ptr } { i64 3, ptr @.d416 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrorWordNotInSet(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 26, ptr @.d417 }, 1
  %t3 = extractvalue { i64, ptr } { i64 26, ptr @.d417 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 34, ptr @.d418 }, 1
  %t9 = extractvalue { i64, ptr } { i64 34, ptr @.d418 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 451, { i64, ptr } { i64 2, ptr @.d419 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrorWordTooFar(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 26, ptr @.d420 }, 1
  %t3 = extractvalue { i64, ptr } { i64 26, ptr @.d420 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 68, ptr @.d421 }, 1
  %t9 = extractvalue { i64, ptr } { i64 68, ptr @.d421 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 450, { i64, ptr } { i64 3, ptr @.d422 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local { i64, ptr } @compiler_2fmsgs_2eEsc(ptr %v0, i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l30 = alloca i1
  %l35 = alloca i8
  %l36 = alloca i64
  %l37 = alloca i32
  %l38 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l42 = alloca %"std/prelude/text:StringBuilder"
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i8, ptr %l0, !tbaa !22
  %t3 = icmp eq i8 %t1, 9
  br i1 %t3, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 2, ptr @.d423 }, ptr %l5, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t5, ptr %l6, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l7, !tbaa !24
  %t8 = load i64, ptr %l7, !tbaa !24
  %t9 = mul i64 %t8, 1
  %t10 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l8, !tbaa !27
  %t13 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = load i64, ptr %l7, !tbaa !24
  %t18 = mul i64 %t17, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t14, ptr %t16, i64 %t18, i1 false)
  %t19 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t19, ptr %l6, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t20 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t20, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t21 = load i8, ptr %l0, !tbaa !22
  %t23 = icmp eq i8 %t21, 10
  br i1 %t23, label %bb4, label %bb5
bb4:
  store { i64, ptr } { i64 2, ptr @.d424 }, ptr %l11, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t25, ptr %l12, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t26, 0
  store i64 %t27, ptr %l13, !tbaa !24
  %t28 = load i64, ptr %l13, !tbaa !24
  %t29 = mul i64 %t28, 1
  %t30 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t29)
  %t31 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  store { i64, ptr } %t32, ptr %l14, !tbaa !27
  %t33 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = load i64, ptr %l13, !tbaa !24
  %t38 = mul i64 %t37, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t34, ptr %t36, i64 %t38, i1 false)
  %t39 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t39, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t40 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t40, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t41 = load i8, ptr %l0, !tbaa !22
  %t43 = icmp eq i8 %t41, 13
  br i1 %t43, label %bb7, label %bb8
bb7:
  store { i64, ptr } { i64 2, ptr @.d425 }, ptr %l17, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t45, ptr %l18, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 0
  store i64 %t47, ptr %l19, !tbaa !24
  %t48 = load i64, ptr %l19, !tbaa !24
  %t49 = mul i64 %t48, 1
  %t50 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t49)
  %t51 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  store { i64, ptr } %t52, ptr %l20, !tbaa !27
  %t53 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = load i64, ptr %l19, !tbaa !24
  %t58 = mul i64 %t57, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t54, ptr %t56, i64 %t58, i1 false)
  %t59 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t59, ptr %l18, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t60 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t60, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t61 = load i8, ptr %l0, !tbaa !22
  %t63 = icmp eq i8 %t61, 0
  br i1 %t63, label %bb10, label %bb11
bb10:
  store { i64, ptr } { i64 2, ptr @.d426 }, ptr %l23, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t65, ptr %l24, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 0
  store i64 %t67, ptr %l25, !tbaa !24
  %t68 = load i64, ptr %l25, !tbaa !24
  %t69 = mul i64 %t68, 1
  %t70 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t69)
  %t71 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  store { i64, ptr } %t72, ptr %l26, !tbaa !27
  %t73 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l25, !tbaa !24
  %t78 = mul i64 %t77, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t74, ptr %t76, i64 %t78, i1 false)
  %t79 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t79, ptr %l24, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t80 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t80, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t81 = load i8, ptr %l0, !tbaa !22
  %t84 = icmp ult i8 %t81, 32
  br i1 %t84, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb15
bb14:
  %t86 = load i8, ptr %l0, !tbaa !22
  %t89 = icmp uge i8 %t86, 127
  store i1 %t89, ptr %l30, !tbaa !21
  br label %bb15
bb15:
  %t91 = load i1, ptr %l30, !tbaa !21
  br i1 %t91, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s5
  %t92 = load i8, ptr %l0, !tbaa !22
  store i8 %t92, ptr %l35, !tbaa !22
  %t94 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s5, i64 16)
  %t95 = extractvalue { i32, i64 } %t94, 1
  %t96 = extractvalue { i32, i64 } %t94, 0
  store i32 %t96, ptr %l37
  %t97 = icmp ne i32 %t96, 0
  br i1 %t97, label %bb19, label %ok.98
ok.98:
  store i64 %t95, ptr %l36
  br label %bb18
bb17:
  br label %bb22
bb18:
  %t99 = load i8, ptr %l35, !tbaa !22
  %t100 = load i64, ptr %l36, !tbaa !24
  %t101 = call { i64, ptr } @std_2fprelude_2ftext_2eU8_2eFormat(ptr %s5, i8 %t99, i64 %t100)
  store { i64, ptr } %t101, ptr %l38
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @.c427)
  unreachable
bb20:
  %t102 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t105 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %s5, ptr %s5, { i64, ptr } %t102, i64 2, i8 48)
  store { i64, ptr } %t105, ptr %l40
  br label %bb21
bb21:
  %t106 = extractvalue { i64, ptr } { i64 2, ptr @.d428 }, 1
  %t107 = extractvalue { i64, ptr } { i64 2, ptr @.d428 }, 0
  %t108 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t108, 1
  %t110 = extractvalue { i64, ptr } %t108, 0
  %t111 = add i64 %t107, %t110
  %t112 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t111)
  call void @olang_textcopy(ptr %t112, ptr %t106, i64 %t107)
  %t113 = getelementptr i8, ptr %t112, i64 %t107
  call void @olang_textcopy(ptr %t113, ptr %t109, i64 %t110)
  %t114 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t112, 1
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t115, ptr %rv
  br label %ret
bb22:
  %t117 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t117, ptr %l42
  br label %bb23
bb23:
  %t118 = load %"std/prelude/text:StringBuilder", ptr %l42
  store %"std/prelude/text:StringBuilder" %t118, ptr %l2
  %t119 = load i8, ptr %l0, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 %t119)
  br label %bb24
bb24:
  %t123 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v0, ptr %l2)
  store { i64, ptr } %t123, ptr %l46
  br label %bb25
bb25:
  %t124 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t124, ptr %l47, !tbaa !27
  %t125 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t125, 0
  store i64 %t126, ptr %l48, !tbaa !24
  %t127 = load i64, ptr %l48, !tbaa !24
  %t128 = mul i64 %t127, 1
  %t129 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t128)
  %t130 = insertvalue { i64, ptr } undef, i64 %t127, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t129, 1
  store { i64, ptr } %t131, ptr %l49, !tbaa !27
  %t132 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = load i64, ptr %l48, !tbaa !24
  %t137 = mul i64 %t136, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t133, ptr %t135, i64 %t137, i1 false)
  %t138 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t138, ptr %l47, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t139 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t139, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eExpected(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 9, ptr @.d429 }, 1
  %t4 = extractvalue { i64, ptr } { i64 9, ptr @.d429 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 8, ptr @.d430 }, 1
  %t10 = extractvalue { i64, ptr } { i64 8, ptr @.d430 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t3, i64 %t4)
  %t17 = getelementptr i8, ptr %t16, i64 %t4
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t9, i64 %t10)
  %t19 = getelementptr i8, ptr %t18, i64 %t10
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 68, { i64, ptr } { i64 0, ptr @.d431 }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eExplainNeedsName(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l6 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } { i64 8, ptr @.d432 }, 1
  %t4 = extractvalue { i64, ptr } { i64 8, ptr @.d432 }, 0
  %t6 = extractvalue { i64, ptr } %t1, 1
  %t7 = extractvalue { i64, ptr } %t1, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 55, ptr @.d433 }, 1
  %t10 = extractvalue { i64, ptr } { i64 55, ptr @.d433 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %t2, 1
  %t14 = extractvalue { i64, ptr } %t2, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 6, ptr @.d434 }, 1
  %t17 = extractvalue { i64, ptr } { i64 6, ptr @.d434 }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 25, { i64, ptr } { i64 4, ptr @.d435 }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l6
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l6
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eExplainNeedsRule(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 24, { i64, ptr } { i64 4, ptr @.d436 }, { i64, ptr } { i64 45, ptr @.d437 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eExplainNoItem(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 1, ptr @.d438 }, 1
  %t4 = extractvalue { i64, ptr } { i64 1, ptr @.d438 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 26, ptr @.d439 }, 1
  %t10 = extractvalue { i64, ptr } { i64 26, ptr @.d439 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t3, i64 %t4)
  %t17 = getelementptr i8, ptr %t16, i64 %t4
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t9, i64 %t10)
  %t19 = getelementptr i8, ptr %t18, i64 %t10
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 26, { i64, ptr } { i64 4, ptr @.d440 }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eExtendsNotBase(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 171, { i64, ptr } { i64 4, ptr @.d441 }, { i64, ptr } { i64 54, ptr @.d442 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eExternType(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 108, ptr @.d443 }, 1
  %t6 = extractvalue { i64, ptr } { i64 108, ptr @.d443 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 163, { i64, ptr } { i64 2, ptr @.d444 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eFieldBindingUnknown(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 252, { i64, ptr } { i64 8, ptr @.d445 }, { i64, ptr } { i64 122, ptr @.d446 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eFieldHasParamName(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 6, ptr @.d447 }, 1
  %t3 = extractvalue { i64, ptr } { i64 6, ptr @.d447 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 87, ptr @.d448 }, 1
  %t9 = extractvalue { i64, ptr } { i64 87, ptr @.d448 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 155, { i64, ptr } { i64 3, ptr @.d449 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eFloatLiteralRange(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 22, ptr @.d450 }, 1
  %t6 = extractvalue { i64, ptr } { i64 22, ptr @.d450 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 317, { i64, ptr } { i64 4, ptr @.d451 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eForInClauseExit(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 411, { i64, ptr } { i64 3, ptr @.d452 }, { i64, ptr } { i64 104, ptr @.d453 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eForInNameExists(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 116, ptr @.d454 }, 1
  %t7 = extractvalue { i64, ptr } { i64 116, ptr @.d454 }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 22, ptr @.d455 }, 1
  %t14 = extractvalue { i64, ptr } { i64 22, ptr @.d455 }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 412, { i64, ptr } { i64 8, ptr @.d456 }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eForInNeedsTry(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 409, { i64, ptr } { i64 3, ptr @.d457 }, { i64, ptr } { i64 90, ptr @.d458 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eForInTryNothing(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 410, { i64, ptr } { i64 3, ptr @.d459 }, { i64, ptr } { i64 59, ptr @.d460 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eFormatterBuild(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 35, ptr @.d461 }, 1
  %t3 = extractvalue { i64, ptr } { i64 35, ptr @.d461 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 9, ptr @.d462 }, 1
  %t9 = extractvalue { i64, ptr } { i64 9, ptr @.d462 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 16, { i64, ptr } { i64 3, ptr @.d463 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eFormatterMissing(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 52, ptr @.d464 }, 1
  %t3 = extractvalue { i64, ptr } { i64 52, ptr @.d464 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 15, { i64, ptr } { i64 3, ptr @.d465 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eFromBitsReceiver(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 95, ptr @.d466 }, 1
  %t6 = extractvalue { i64, ptr } { i64 95, ptr @.d466 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 358, { i64, ptr } { i64 3, ptr @.d467 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eFuncTypeErrsUnwritten(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 113, { i64, ptr } { i64 3, ptr @.d468 }, { i64, ptr } { i64 82, ptr @.d469 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eFuncValueObligations(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 1, ptr @.d470 }, 1
  %t3 = extractvalue { i64, ptr } { i64 1, ptr @.d470 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 102, ptr @.d471 }, 1
  %t9 = extractvalue { i64, ptr } { i64 102, ptr @.d471 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 482, { i64, ptr } { i64 4, ptr @.d472 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eGenericNotAValue(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l6 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } { i64 18, ptr @.d473 }, 1
  %t4 = extractvalue { i64, ptr } { i64 18, ptr @.d473 }, 0
  %t6 = extractvalue { i64, ptr } %t1, 1
  %t7 = extractvalue { i64, ptr } %t1, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 75, ptr @.d474 }, 1
  %t10 = extractvalue { i64, ptr } { i64 75, ptr @.d474 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %t2, 1
  %t14 = extractvalue { i64, ptr } %t2, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 6, ptr @.d475 }, 1
  %t17 = extractvalue { i64, ptr } { i64 6, ptr @.d475 }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 383, { i64, ptr } { i64 3, ptr @.d476 }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l6
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l6
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eGenericNotStruct(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 172, { i64, ptr } { i64 2, ptr @.d477 }, { i64, ptr } { i64 46, ptr @.d478 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eGlobalAborts(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 73, ptr @.d479 }, 1
  %t3 = extractvalue { i64, ptr } { i64 73, ptr @.d479 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 508, { i64, ptr } { i64 2, ptr @.d480 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eGlobalHoldsShorter(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 397, { i64, ptr } { i64 3, ptr @.d481 }, { i64, ptr } { i64 103, ptr @.d482 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eGlobalReadsItself(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 21, ptr @.d483 }, 1
  %t7 = extractvalue { i64, ptr } { i64 21, ptr @.d483 }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 48, ptr @.d484 }, 1
  %t14 = extractvalue { i64, ptr } { i64 48, ptr @.d484 }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 532, { i64, ptr } { i64 3, ptr @.d485 }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eGlobalStale(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 76, ptr @.d486 }, 1
  %t3 = extractvalue { i64, ptr } { i64 76, ptr @.d486 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 514, { i64, ptr } { i64 6, ptr @.d487 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eGlobalsCycle(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 71, ptr @.d488 }, 1
  %t3 = extractvalue { i64, ptr } { i64 71, ptr @.d488 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 533, { i64, ptr } { i64 3, ptr @.d489 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eGuardNotBool(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 25, ptr @.d490 }, 1
  %t3 = extractvalue { i64, ptr } { i64 25, ptr @.d490 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 423, { i64, ptr } { i64 4, ptr @.d491 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eHelpOneMode(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 10, { i64, ptr } { i64 2, ptr @.d492 }, { i64, ptr } { i64 27, ptr @.d493 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eHexDigit(ptr %v0, i8 %a0) #0 {
entry:
  %l1 = alloca i32
  %l3 = alloca { i64, ptr }
  %l6 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 63, ptr %l1
  %t3 = call { i64, ptr } @compiler_2fmsgs_2eEsc(ptr %s0, i8 %a0)
  store { i64, ptr } %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = extractvalue { i64, ptr } { i64 1, ptr @.d494 }, 1
  %t5 = extractvalue { i64, ptr } { i64 1, ptr @.d494 }, 0
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 1
  %t8 = extractvalue { i64, ptr } %t6, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 28, ptr @.d495 }, 1
  %t11 = extractvalue { i64, ptr } { i64 28, ptr @.d495 }, 0
  %t12 = add i64 %t9, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t7, i64 %t8)
  %t15 = getelementptr i8, ptr %t14, i64 %t8
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t25 = load i32, ptr %l1
  %t27 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t25, { i64, ptr } { i64 4, ptr @.d496 }, { i64, ptr } %t24)
  store %"compiler/msgs:Msg" %t27, ptr %l6
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t28 = load %"compiler/msgs:Msg", ptr %l6
  store %"compiler/msgs:Msg" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eHexNoDigits(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 61, { i64, ptr } { i64 4, ptr @.d497 }, { i64, ptr } { i64 29, ptr @.d498 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eImmutable(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 68, ptr @.d499 }, 1
  %t6 = extractvalue { i64, ptr } { i64 68, ptr @.d499 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 282, { i64, ptr } { i64 2, ptr @.d500 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportAliasConflict(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 48, ptr @.d501 }, 1
  %t3 = extractvalue { i64, ptr } { i64 48, ptr @.d501 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 32, ptr @.d502 }, 1
  %t9 = extractvalue { i64, ptr } { i64 32, ptr @.d502 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 97, { i64, ptr } { i64 2, ptr @.d503 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportAliasInvalid(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 1, ptr @.d504 }, 1
  %t3 = extractvalue { i64, ptr } { i64 1, ptr @.d504 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 86, ptr @.d505 }, 1
  %t9 = extractvalue { i64, ptr } { i64 86, ptr @.d505 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 96, { i64, ptr } { i64 2, ptr @.d506 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportFetchFailed(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 16, ptr @.d507 }, 1
  %t3 = extractvalue { i64, ptr } { i64 16, ptr @.d507 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 45, ptr @.d508 }, 1
  %t9 = extractvalue { i64, ptr } { i64 45, ptr @.d508 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 89, { i64, ptr } { i64 4, ptr @.d509 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportFileNotFound(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 18, ptr @.d510 }, 1
  %t3 = extractvalue { i64, ptr } { i64 18, ptr @.d510 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 92, { i64, ptr } { i64 3, ptr @.d511 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportHasExtension(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 93, { i64, ptr } { i64 3, ptr @.d512 }, { i64, ptr } { i64 41, ptr @.d513 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportIsPrivate(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 7, ptr @.d514 }, 1
  %t3 = extractvalue { i64, ptr } { i64 7, ptr @.d514 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 67, ptr @.d515 }, 1
  %t9 = extractvalue { i64, ptr } { i64 67, ptr @.d515 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 100, { i64, ptr } { i64 3, ptr @.d516 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportLeavesRoot(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 28, ptr @.d517 }, 1
  %t3 = extractvalue { i64, ptr } { i64 28, ptr @.d517 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 43, ptr @.d518 }, 1
  %t9 = extractvalue { i64, ptr } { i64 43, ptr @.d518 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 94, { i64, ptr } { i64 3, ptr @.d519 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportLockNotACommit(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 31, ptr @.d520 }, 1
  %t3 = extractvalue { i64, ptr } { i64 31, ptr @.d520 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 41, ptr @.d521 }, 1
  %t9 = extractvalue { i64, ptr } { i64 41, ptr @.d521 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 88, { i64, ptr } { i64 4, ptr @.d522 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportLockedFetchFailed(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 48, ptr @.d523 }, 1
  %t3 = extractvalue { i64, ptr } { i64 48, ptr @.d523 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 41, ptr @.d524 }, 1
  %t9 = extractvalue { i64, ptr } { i64 41, ptr @.d524 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 90, { i64, ptr } { i64 10, ptr @.d525 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportPathTooLong(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 91, { i64, ptr } { i64 3, ptr @.d526 }, { i64, ptr } { i64 43, ptr @.d527 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportReachedTwice(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 61, ptr @.d528 }, 1
  %t6 = extractvalue { i64, ptr } { i64 61, ptr @.d528 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 102, { i64, ptr } { i64 3, ptr @.d529 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportRemoteBadName(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 87, { i64, ptr } { i64 4, ptr @.d530 }, { i64, ptr } { i64 97, ptr @.d531 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportRemoteNeedsFile(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 95, { i64, ptr } { i64 3, ptr @.d532 }, { i64, ptr } { i64 74, ptr @.d533 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eIncdecInExpression(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 55, ptr @.d534 }, 1
  %t6 = extractvalue { i64, ptr } { i64 55, ptr @.d534 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 329, { i64, ptr } { i64 3, ptr @.d535 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eIncdecNotNumber(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 23, ptr @.d536 }, 1
  %t7 = extractvalue { i64, ptr } { i64 23, ptr @.d536 }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t6, i64 %t7)
  %t15 = getelementptr i8, ptr %t14, i64 %t7
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t27 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 278, { i64, ptr } { i64 3, ptr @.d537 }, { i64, ptr } %t24)
  store %"compiler/msgs:Msg" %t27, ptr %l7
  br label %bb1
bb1:
  %t28 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eIndexNotInt(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 30, ptr @.d538 }, 1
  %t3 = extractvalue { i64, ptr } { i64 30, ptr @.d538 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 270, { i64, ptr } { i64 3, ptr @.d539 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eIndexOutOfRange(ptr %v0, i64 %a0, i64 %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 6, ptr @.d540 }, 1
  %t4 = extractvalue { i64, ptr } { i64 6, ptr @.d540 }, 0
  %t6 = call i64 @__olang_fmt_i64(ptr null, i64 %a0)
  %t7 = add i64 %t4, %t6
  %t8 = extractvalue { i64, ptr } { i64 24, ptr @.d541 }, 1
  %t9 = extractvalue { i64, ptr } { i64 24, ptr @.d541 }, 0
  %t10 = add i64 %t7, %t9
  %t12 = call i64 @__olang_fmt_i64(ptr null, i64 %a1)
  %t13 = add i64 %t10, %t12
  %t14 = extractvalue { i64, ptr } { i64 9, ptr @.d542 }, 1
  %t15 = extractvalue { i64, ptr } { i64 9, ptr @.d542 }, 0
  %t16 = add i64 %t13, %t15
  %t17 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t16)
  call void @olang_textcopy(ptr %t17, ptr %t3, i64 %t4)
  %t18 = getelementptr i8, ptr %t17, i64 %t4
  %t19 = call i64 @__olang_fmt_i64(ptr %t18, i64 %a0)
  %t20 = getelementptr i8, ptr %t18, i64 %t6
  call void @olang_textcopy(ptr %t20, ptr %t8, i64 %t9)
  %t21 = getelementptr i8, ptr %t20, i64 %t9
  %t22 = call i64 @__olang_fmt_i64(ptr %t21, i64 %a1)
  %t23 = getelementptr i8, ptr %t21, i64 %t12
  call void @olang_textcopy(ptr %t23, ptr %t14, i64 %t15)
  %t24 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t17, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 271, { i64, ptr } { i64 3, ptr @.d543 }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eInstanceOutlivesArg(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 396, { i64, ptr } { i64 3, ptr @.d544 }, { i64, ptr } { i64 162, ptr @.d545 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eInstanceOutlivesReferent(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 395, { i64, ptr } { i64 3, ptr @.d546 }, { i64, ptr } { i64 113, ptr @.d547 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eIntLiteralTooLarge(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 78, ptr @.d548 }, 1
  %t6 = extractvalue { i64, ptr } { i64 78, ptr @.d548 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 305, { i64, ptr } { i64 3, ptr @.d549 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eInvalidReferenceTarget(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 63, ptr @.d550 }, 1
  %t6 = extractvalue { i64, ptr } { i64 63, ptr @.d550 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 149, { i64, ptr } { i64 3, ptr @.d551 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eIsAsMarker(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } { i64 2, ptr @.d552 }, 1
  %t5 = extractvalue { i64, ptr } { i64 2, ptr @.d552 }, 0
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 89, ptr @.d553 }, 1
  %t11 = extractvalue { i64, ptr } { i64 89, ptr @.d553 }, 0
  %t12 = add i64 %t9, %t11
  %t14 = extractvalue { i64, ptr } %a1, 1
  %t15 = extractvalue { i64, ptr } %a1, 0
  %t16 = add i64 %t12, %t15
  %t17 = extractvalue { i64, ptr } { i64 6, ptr @.d554 }, 1
  %t18 = extractvalue { i64, ptr } { i64 6, ptr @.d554 }, 0
  %t19 = add i64 %t16, %t18
  %t21 = extractvalue { i64, ptr } %a2, 1
  %t22 = extractvalue { i64, ptr } %a2, 0
  %t23 = add i64 %t19, %t22
  %t24 = extractvalue { i64, ptr } { i64 1, ptr @.d555 }, 1
  %t25 = extractvalue { i64, ptr } { i64 1, ptr @.d555 }, 0
  %t26 = add i64 %t23, %t25
  %t27 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t4, i64 %t5)
  %t28 = getelementptr i8, ptr %t27, i64 %t5
  call void @olang_textcopy(ptr %t28, ptr %t7, i64 %t8)
  %t29 = getelementptr i8, ptr %t28, i64 %t8
  call void @olang_textcopy(ptr %t29, ptr %t10, i64 %t11)
  %t30 = getelementptr i8, ptr %t29, i64 %t11
  call void @olang_textcopy(ptr %t30, ptr %t14, i64 %t15)
  %t31 = getelementptr i8, ptr %t30, i64 %t15
  call void @olang_textcopy(ptr %t31, ptr %t17, i64 %t18)
  %t32 = getelementptr i8, ptr %t31, i64 %t18
  call void @olang_textcopy(ptr %t32, ptr %t21, i64 %t22)
  %t33 = getelementptr i8, ptr %t32, i64 %t22
  call void @olang_textcopy(ptr %t33, ptr %t24, i64 %t25)
  %t34 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t27, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = extractvalue { i64, ptr } %t35, 1
  %t39 = mul i64 %t37, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t39)
  call void @llvm.memcpy.p0.p0.i64(ptr %t40, ptr %t38, i64 %t39, i1 false)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  %t45 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 339, { i64, ptr } { i64 3, ptr @.d556 }, { i64, ptr } %t42)
  store %"compiler/msgs:Msg" %t45, ptr %l9
  br label %bb1
bb1:
  %t46 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t46, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eIsAsNotEnum(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 59, ptr @.d557 }, 1
  %t3 = extractvalue { i64, ptr } { i64 59, ptr @.d557 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 341, { i64, ptr } { i64 3, ptr @.d558 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eIsDirectory(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 42, { i64, ptr } { i64 2, ptr @.d559 }, { i64, ptr } { i64 41, ptr @.d560 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eIsNotOneType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 5, ptr @.d561 }, 1
  %t7 = extractvalue { i64, ptr } { i64 5, ptr @.d561 }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 53, ptr @.d562 }, 1
  %t14 = extractvalue { i64, ptr } { i64 53, ptr @.d562 }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 335, { i64, ptr } { i64 4, ptr @.d563 }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eIsNotReferences(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 60, ptr @.d564 }, 1
  %t4 = extractvalue { i64, ptr } { i64 60, ptr @.d564 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 5, ptr @.d565 }, 1
  %t10 = extractvalue { i64, ptr } { i64 5, ptr @.d565 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 24, ptr @.d566 }, 1
  %t17 = extractvalue { i64, ptr } { i64 24, ptr @.d566 }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 334, { i64, ptr } { i64 4, ptr @.d567 }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinCannotFail(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 470, { i64, ptr } { i64 3, ptr @.d568 }, { i64, ptr } { i64 46, ptr @.d569 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinCatchNeedsTry(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 471, { i64, ptr } { i64 3, ptr @.d570 }, { i64, ptr } { i64 79, ptr @.d571 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinClauseMustLeave(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 472, { i64, ptr } { i64 3, ptr @.d572 }, { i64, ptr } { i64 93, ptr @.d573 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinNextLine(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 404, { i64, ptr } { i64 8, ptr @.d574 }, { i64, ptr } { i64 100, ptr @.d575 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinNotTried(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 32, ptr @.d576 }, 1
  %t3 = extractvalue { i64, ptr } { i64 32, ptr @.d576 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 64, ptr @.d577 }, 1
  %t9 = extractvalue { i64, ptr } { i64 64, ptr @.d577 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 469, { i64, ptr } { i64 3, ptr @.d578 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinPiece(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 60, ptr @.d579 }, 1
  %t3 = extractvalue { i64, ptr } { i64 60, ptr @.d579 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 1, ptr @.d580 }, 1
  %t9 = extractvalue { i64, ptr } { i64 1, ptr @.d580 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 74, { i64, ptr } { i64 4, ptr @.d581 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinPieceCalled(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 331, { i64, ptr } { i64 4, ptr @.d582 }, { i64, ptr } { i64 77, ptr @.d583 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinWithoutSpawn(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 455, { i64, ptr } { i64 3, ptr @.d584 }, { i64, ptr } { i64 49, ptr @.d585 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eKeywordAsName(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 42, ptr @.d586 }, 1
  %t6 = extractvalue { i64, ptr } { i64 42, ptr @.d586 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 71, { i64, ptr } { i64 2, ptr @.d587 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eKeywordFieldRead(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 99, ptr @.d588 }, 1
  %t6 = extractvalue { i64, ptr } { i64 99, ptr @.d588 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 72, { i64, ptr } { i64 3, ptr @.d589 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLambdaArity(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i64 %a1, { i64, ptr } %a2, i64 %a3) #0 {
entry:
  %l11 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = extractvalue { i64, ptr } { i64 7, ptr @.d590 }, 1
  %t9 = extractvalue { i64, ptr } { i64 7, ptr @.d590 }, 0
  %t10 = add i64 %t7, %t9
  %t12 = call i64 @__olang_fmt_i64(ptr null, i64 %a1)
  %t13 = add i64 %t10, %t12
  %t14 = extractvalue { i64, ptr } { i64 10, ptr @.d591 }, 1
  %t15 = extractvalue { i64, ptr } { i64 10, ptr @.d591 }, 0
  %t16 = add i64 %t13, %t15
  %t18 = extractvalue { i64, ptr } %a2, 1
  %t19 = extractvalue { i64, ptr } %a2, 0
  %t20 = add i64 %t16, %t19
  %t21 = extractvalue { i64, ptr } { i64 18, ptr @.d592 }, 1
  %t22 = extractvalue { i64, ptr } { i64 18, ptr @.d592 }, 0
  %t23 = add i64 %t20, %t22
  %t25 = call i64 @__olang_fmt_i64(ptr null, i64 %a3)
  %t26 = add i64 %t23, %t25
  %t27 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t6, i64 %t7)
  %t28 = getelementptr i8, ptr %t27, i64 %t7
  call void @olang_textcopy(ptr %t28, ptr %t8, i64 %t9)
  %t29 = getelementptr i8, ptr %t28, i64 %t9
  %t30 = call i64 @__olang_fmt_i64(ptr %t29, i64 %a1)
  %t31 = getelementptr i8, ptr %t29, i64 %t12
  call void @olang_textcopy(ptr %t31, ptr %t14, i64 %t15)
  %t32 = getelementptr i8, ptr %t31, i64 %t15
  call void @olang_textcopy(ptr %t32, ptr %t18, i64 %t19)
  %t33 = getelementptr i8, ptr %t32, i64 %t19
  call void @olang_textcopy(ptr %t33, ptr %t21, i64 %t22)
  %t34 = getelementptr i8, ptr %t33, i64 %t22
  %t35 = call i64 @__olang_fmt_i64(ptr %t34, i64 %a3)
  %t36 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t27, 1
  %t39 = extractvalue { i64, ptr } %t37, 0
  %t40 = extractvalue { i64, ptr } %t37, 1
  %t41 = mul i64 %t39, 1
  %t42 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t41)
  call void @llvm.memcpy.p0.p0.i64(ptr %t42, ptr %t40, i64 %t41, i1 false)
  %t43 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t42, 1
  %t47 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 487, { i64, ptr } { i64 4, ptr @.d593 }, { i64, ptr } %t44)
  store %"compiler/msgs:Msg" %t47, ptr %l11
  br label %bb1
bb1:
  %t48 = load %"compiler/msgs:Msg", ptr %l11
  store %"compiler/msgs:Msg" %t48, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLambdaParamUntyped(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 17, ptr @.d594 }, 1
  %t3 = extractvalue { i64, ptr } { i64 17, ptr @.d594 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 49, ptr @.d595 }, 1
  %t9 = extractvalue { i64, ptr } { i64 49, ptr @.d595 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 489, { i64, ptr } { i64 4, ptr @.d596 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLambdaResultHeld(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } { i64 18, ptr @.d597 }, 1
  %t5 = extractvalue { i64, ptr } { i64 18, ptr @.d597 }, 0
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 4, ptr @.d598 }, 1
  %t11 = extractvalue { i64, ptr } { i64 4, ptr @.d598 }, 0
  %t12 = add i64 %t9, %t11
  %t14 = extractvalue { i64, ptr } %a1, 1
  %t15 = extractvalue { i64, ptr } %a1, 0
  %t16 = add i64 %t12, %t15
  %t17 = extractvalue { i64, ptr } { i64 94, ptr @.d599 }, 1
  %t18 = extractvalue { i64, ptr } { i64 94, ptr @.d599 }, 0
  %t19 = add i64 %t16, %t18
  %t21 = extractvalue { i64, ptr } %a2, 1
  %t22 = extractvalue { i64, ptr } %a2, 0
  %t23 = add i64 %t19, %t22
  %t24 = extractvalue { i64, ptr } { i64 1, ptr @.d600 }, 1
  %t25 = extractvalue { i64, ptr } { i64 1, ptr @.d600 }, 0
  %t26 = add i64 %t23, %t25
  %t27 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t4, i64 %t5)
  %t28 = getelementptr i8, ptr %t27, i64 %t5
  call void @olang_textcopy(ptr %t28, ptr %t7, i64 %t8)
  %t29 = getelementptr i8, ptr %t28, i64 %t8
  call void @olang_textcopy(ptr %t29, ptr %t10, i64 %t11)
  %t30 = getelementptr i8, ptr %t29, i64 %t11
  call void @olang_textcopy(ptr %t30, ptr %t14, i64 %t15)
  %t31 = getelementptr i8, ptr %t30, i64 %t15
  call void @olang_textcopy(ptr %t31, ptr %t17, i64 %t18)
  %t32 = getelementptr i8, ptr %t31, i64 %t18
  call void @olang_textcopy(ptr %t32, ptr %t21, i64 %t22)
  %t33 = getelementptr i8, ptr %t32, i64 %t22
  call void @olang_textcopy(ptr %t33, ptr %t24, i64 %t25)
  %t34 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t27, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = extractvalue { i64, ptr } %t35, 1
  %t39 = mul i64 %t37, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t39)
  call void @llvm.memcpy.p0.p0.i64(ptr %t40, ptr %t38, i64 %t39, i1 false)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  %t45 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 146, { i64, ptr } { i64 3, ptr @.d601 }, { i64, ptr } %t42)
  store %"compiler/msgs:Msg" %t45, ptr %l9
  br label %bb1
bb1:
  %t46 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t46, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLambdaResultUninferable(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 486, { i64, ptr } { i64 4, ptr @.d602 }, { i64, ptr } { i64 54, ptr @.d603 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLambdaSignature(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 39, ptr @.d604 }, 1
  %t3 = extractvalue { i64, ptr } { i64 39, ptr @.d604 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 42, ptr @.d605 }, 1
  %t9 = extractvalue { i64, ptr } { i64 42, ptr @.d605 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 488, { i64, ptr } { i64 4, ptr @.d606 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLambdaValueObligations(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 19, ptr @.d607 }, 1
  %t3 = extractvalue { i64, ptr } { i64 19, ptr @.d607 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 91, ptr @.d608 }, 1
  %t9 = extractvalue { i64, ptr } { i64 91, ptr @.d608 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 483, { i64, ptr } { i64 4, ptr @.d609 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLambdaValueRelates(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 484, { i64, ptr } { i64 4, ptr @.d610 }, { i64, ptr } { i64 93, ptr @.d611 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLenShape(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 183, { i64, ptr } { i64 3, ptr @.d612 }, { i64, ptr } { i64 16, ptr @.d613 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLengthsNotAValue(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 1, ptr @.d614 }, 1
  %t3 = extractvalue { i64, ptr } { i64 1, ptr @.d614 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 101, ptr @.d615 }, 1
  %t9 = extractvalue { i64, ptr } { i64 101, ptr @.d615 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 384, { i64, ptr } { i64 3, ptr @.d616 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLessNotBool(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 182, { i64, ptr } { i64 3, ptr @.d617 }, { i64, ptr } { i64 35, ptr @.d618 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLineBodyNotSimple(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 45, ptr @.d619 }, 1
  %t3 = extractvalue { i64, ptr } { i64 45, ptr @.d619 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 27, ptr @.d620 }, 1
  %t9 = extractvalue { i64, ptr } { i64 27, ptr @.d620 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 28, { i64, ptr } { i64 3, ptr @.d621 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLineBodyOnLine(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 27, { i64, ptr } { i64 3, ptr @.d622 }, { i64, ptr } { i64 72, ptr @.d623 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLineStartsWithOperator(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 25, ptr @.d624 }, 1
  %t4 = extractvalue { i64, ptr } { i64 25, ptr @.d624 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 59, ptr @.d625 }, 1
  %t10 = extractvalue { i64, ptr } { i64 59, ptr @.d625 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 38, ptr @.d626 }, 1
  %t17 = extractvalue { i64, ptr } { i64 38, ptr @.d626 }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 421, { i64, ptr } { i64 3, ptr @.d627 }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLinkFailed(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 8, ptr @.d628 }, 1
  %t3 = extractvalue { i64, ptr } { i64 8, ptr @.d628 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 7, ptr @.d629 }, 1
  %t9 = extractvalue { i64, ptr } { i64 7, ptr @.d629 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 46, { i64, ptr } { i64 0, ptr @.d630 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLiteralCtorFails(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 20, ptr @.d631 }, 1
  %t4 = extractvalue { i64, ptr } { i64 20, ptr @.d631 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 68, ptr @.d632 }, 1
  %t10 = extractvalue { i64, ptr } { i64 68, ptr @.d632 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t3, i64 %t4)
  %t17 = getelementptr i8, ptr %t16, i64 %t4
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t9, i64 %t10)
  %t19 = getelementptr i8, ptr %t18, i64 %t10
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 497, { i64, ptr } { i64 4, ptr @.d633 }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLiteralDoesNotMeet(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } { i64 26, ptr @.d634 }, 1
  %t5 = extractvalue { i64, ptr } { i64 26, ptr @.d634 }, 0
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 6, ptr @.d635 }, 1
  %t11 = extractvalue { i64, ptr } { i64 6, ptr @.d635 }, 0
  %t12 = add i64 %t9, %t11
  %t14 = extractvalue { i64, ptr } %a1, 1
  %t15 = extractvalue { i64, ptr } %a1, 0
  %t16 = add i64 %t12, %t15
  %t17 = extractvalue { i64, ptr } { i64 20, ptr @.d636 }, 1
  %t18 = extractvalue { i64, ptr } { i64 20, ptr @.d636 }, 0
  %t19 = add i64 %t16, %t18
  %t21 = extractvalue { i64, ptr } %a2, 1
  %t22 = extractvalue { i64, ptr } %a2, 0
  %t23 = add i64 %t19, %t22
  %t24 = extractvalue { i64, ptr } { i64 14, ptr @.d637 }, 1
  %t25 = extractvalue { i64, ptr } { i64 14, ptr @.d637 }, 0
  %t26 = add i64 %t23, %t25
  %t27 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t4, i64 %t5)
  %t28 = getelementptr i8, ptr %t27, i64 %t5
  call void @olang_textcopy(ptr %t28, ptr %t7, i64 %t8)
  %t29 = getelementptr i8, ptr %t28, i64 %t8
  call void @olang_textcopy(ptr %t29, ptr %t10, i64 %t11)
  %t30 = getelementptr i8, ptr %t29, i64 %t11
  call void @olang_textcopy(ptr %t30, ptr %t14, i64 %t15)
  %t31 = getelementptr i8, ptr %t30, i64 %t15
  call void @olang_textcopy(ptr %t31, ptr %t17, i64 %t18)
  %t32 = getelementptr i8, ptr %t31, i64 %t18
  call void @olang_textcopy(ptr %t32, ptr %t21, i64 %t22)
  %t33 = getelementptr i8, ptr %t32, i64 %t22
  call void @olang_textcopy(ptr %t33, ptr %t24, i64 %t25)
  %t34 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t27, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = extractvalue { i64, ptr } %t35, 1
  %t39 = mul i64 %t37, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t39)
  call void @llvm.memcpy.p0.p0.i64(ptr %t40, ptr %t38, i64 %t39, i1 false)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  %t45 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 312, { i64, ptr } { i64 3, ptr @.d638 }, { i64, ptr } %t42)
  store %"compiler/msgs:Msg" %t45, ptr %l9
  br label %bb1
bb1:
  %t46 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t46, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLiteralExprNoValue(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 311, { i64, ptr } { i64 3, ptr @.d639 }, { i64, ptr } { i64 62, ptr @.d640 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLiteralExprRange(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 45, ptr @.d641 }, 1
  %t3 = extractvalue { i64, ptr } { i64 45, ptr @.d641 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 217, { i64, ptr } { i64 3, ptr @.d642 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLiteralNeedsCtor(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 11, ptr @.d643 }, 1
  %t4 = extractvalue { i64, ptr } { i64 11, ptr @.d643 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 36, ptr @.d644 }, 1
  %t10 = extractvalue { i64, ptr } { i64 36, ptr @.d644 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 5, ptr @.d645 }, 1
  %t17 = extractvalue { i64, ptr } { i64 5, ptr @.d645 }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 218, { i64, ptr } { i64 4, ptr @.d646 }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLiteralRange(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 14, ptr @.d647 }, 1
  %t7 = extractvalue { i64, ptr } { i64 14, ptr @.d647 }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t6, i64 %t7)
  %t15 = getelementptr i8, ptr %t14, i64 %t7
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t27 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 213, { i64, ptr } { i64 2, ptr @.d648 }, { i64, ptr } %t24)
  store %"compiler/msgs:Msg" %t27, ptr %l7
  br label %bb1
bb1:
  %t28 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLongChar(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 59, { i64, ptr } { i64 3, ptr @.d649 }, { i64, ptr } { i64 71, ptr @.d650 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMainSignature(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 516, { i64, ptr } { i64 2, ptr @.d651 }, { i64, ptr } { i64 84, ptr @.d652 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMatchNotExhaustive(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 5, ptr @.d653 }, 1
  %t4 = extractvalue { i64, ptr } { i64 5, ptr @.d653 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 4, ptr @.d654 }, 1
  %t10 = extractvalue { i64, ptr } { i64 4, ptr @.d654 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 42, ptr @.d655 }, 1
  %t17 = extractvalue { i64, ptr } { i64 42, ptr @.d655 }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 429, { i64, ptr } { i64 4, ptr @.d656 }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMatchValueNeedsNomatch(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 13, ptr @.d657 }, 1
  %t3 = extractvalue { i64, ptr } { i64 13, ptr @.d657 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 73, ptr @.d658 }, 1
  %t9 = extractvalue { i64, ptr } { i64 73, ptr @.d658 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 430, { i64, ptr } { i64 4, ptr @.d659 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMatchValueNone(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 427, { i64, ptr } { i64 3, ptr @.d660 }, { i64, ptr } { i64 87, ptr @.d661 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMatchValueOne(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 431, { i64, ptr } { i64 9, ptr @.d662 }, { i64, ptr } { i64 116, ptr @.d663 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMatchValueTypes(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 29, ptr @.d664 }, 1
  %t4 = extractvalue { i64, ptr } { i64 29, ptr @.d664 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 8, ptr @.d665 }, 1
  %t10 = extractvalue { i64, ptr } { i64 8, ptr @.d665 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t3, i64 %t4)
  %t17 = getelementptr i8, ptr %t16, i64 %t4
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t9, i64 %t10)
  %t19 = getelementptr i8, ptr %t18, i64 %t10
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 428, { i64, ptr } { i64 4, ptr @.d666 }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMatmulUndeclared(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 33, ptr @.d667 }, 1
  %t3 = extractvalue { i64, ptr } { i64 33, ptr @.d667 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 19, ptr @.d668 }, 1
  %t9 = extractvalue { i64, ptr } { i64 19, ptr @.d668 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 322, { i64, ptr } { i64 3, ptr @.d669 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMemberIsPrivate(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 8, ptr @.d670 }, 1
  %t4 = extractvalue { i64, ptr } { i64 8, ptr @.d670 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 5, ptr @.d671 }, 1
  %t10 = extractvalue { i64, ptr } { i64 5, ptr @.d671 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 25, ptr @.d672 }, 1
  %t17 = extractvalue { i64, ptr } { i64 25, ptr @.d672 }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 275, { i64, ptr } { i64 3, ptr @.d673 }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMembershipNeedsTry(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 37, ptr @.d674 }, 1
  %t6 = extractvalue { i64, ptr } { i64 37, ptr @.d674 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 328, { i64, ptr } { i64 3, ptr @.d675 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMembershipNoMethod(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 15, ptr @.d676 }, 1
  %t4 = extractvalue { i64, ptr } { i64 15, ptr @.d676 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 6, ptr @.d677 }, 1
  %t10 = extractvalue { i64, ptr } { i64 6, ptr @.d677 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 9, ptr @.d678 }, 1
  %t17 = extractvalue { i64, ptr } { i64 9, ptr @.d678 }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 326, { i64, ptr } { i64 3, ptr @.d679 }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMembershipNotBool(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 32, ptr @.d680 }, 1
  %t6 = extractvalue { i64, ptr } { i64 32, ptr @.d680 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 327, { i64, ptr } { i64 3, ptr @.d681 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodAmbiguous(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 29, ptr @.d682 }, 1
  %t3 = extractvalue { i64, ptr } { i64 29, ptr @.d682 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 42, ptr @.d683 }, 1
  %t9 = extractvalue { i64, ptr } { i64 42, ptr @.d683 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 380, { i64, ptr } { i64 3, ptr @.d684 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodCalledAsFunction(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 42, ptr @.d685 }, 1
  %t7 = extractvalue { i64, ptr } { i64 42, ptr @.d685 }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 5, ptr @.d686 }, 1
  %t14 = extractvalue { i64, ptr } { i64 5, ptr @.d686 }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 204, { i64, ptr } { i64 3, ptr @.d687 }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodCannotFail(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 70, ptr @.d688 }, 1
  %t6 = extractvalue { i64, ptr } { i64 70, ptr @.d688 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 181, { i64, ptr } { i64 3, ptr @.d689 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodClashesInherited(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 19, ptr @.d690 }, 1
  %t7 = extractvalue { i64, ptr } { i64 19, ptr @.d690 }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 36, ptr @.d691 }, 1
  %t14 = extractvalue { i64, ptr } { i64 36, ptr @.d691 }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 193, { i64, ptr } { i64 4, ptr @.d692 }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodClashesSupplied(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 22, ptr @.d693 }, 1
  %t4 = extractvalue { i64, ptr } { i64 22, ptr @.d693 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 5, ptr @.d694 }, 1
  %t10 = extractvalue { i64, ptr } { i64 5, ptr @.d694 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 22, ptr @.d695 }, 1
  %t17 = extractvalue { i64, ptr } { i64 22, ptr @.d695 }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 194, { i64, ptr } { i64 12, ptr @.d696 }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodInUse(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 22, ptr @.d697 }, 1
  %t7 = extractvalue { i64, ptr } { i64 22, ptr @.d697 }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 15, ptr @.d698 }, 1
  %t14 = extractvalue { i64, ptr } { i64 15, ptr @.d698 }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 196, { i64, ptr } { i64 3, ptr @.d699 }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodIsPrivate(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 7, ptr @.d700 }, 1
  %t3 = extractvalue { i64, ptr } { i64 7, ptr @.d700 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 25, ptr @.d701 }, 1
  %t9 = extractvalue { i64, ptr } { i64 25, ptr @.d701 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 382, { i64, ptr } { i64 2, ptr @.d702 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodNotInherited(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 13, ptr @.d703 }, 1
  %t7 = extractvalue { i64, ptr } { i64 13, ptr @.d703 }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 73, ptr @.d704 }, 1
  %t14 = extractvalue { i64, ptr } { i64 73, ptr @.d704 }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 356, { i64, ptr } { i64 4, ptr @.d705 }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodOnBuiltinType(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 37, ptr @.d706 }, 1
  %t3 = extractvalue { i64, ptr } { i64 37, ptr @.d706 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 59, ptr @.d707 }, 1
  %t9 = extractvalue { i64, ptr } { i64 59, ptr @.d707 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 195, { i64, ptr } { i64 4, ptr @.d708 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodOnForeignType(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 12, ptr @.d709 }, 1
  %t3 = extractvalue { i64, ptr } { i64 12, ptr @.d709 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 34, ptr @.d710 }, 1
  %t9 = extractvalue { i64, ptr } { i64 34, ptr @.d710 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 191, { i64, ptr } { i64 3, ptr @.d711 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMissingReturn(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 41, ptr @.d712 }, 1
  %t3 = extractvalue { i64, ptr } { i64 41, ptr @.d712 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 53, ptr @.d713 }, 1
  %t9 = extractvalue { i64, ptr } { i64 53, ptr @.d713 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 491, { i64, ptr } { i64 4, ptr @.d714 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMissingTypeArgs(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 44, ptr @.d715 }, 1
  %t7 = extractvalue { i64, ptr } { i64 44, ptr @.d715 }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 6, ptr @.d716 }, 1
  %t14 = extractvalue { i64, ptr } { i64 6, ptr @.d716 }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 135, { i64, ptr } { i64 2, ptr @.d717 }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeFirst(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 29, ptr @.d718 }, 1
  %t3 = extractvalue { i64, ptr } { i64 29, ptr @.d718 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 22, ptr @.d719 }, 1
  %t9 = extractvalue { i64, ptr } { i64 22, ptr @.d719 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 9, { i64, ptr } { i64 2, ptr @.d720 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeNeedsFile(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 13, ptr @.d721 }, 1
  %t6 = extractvalue { i64, ptr } { i64 13, ptr @.d721 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 3, { i64, ptr } { i64 2, ptr @.d722 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeOneFile(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 23, ptr @.d723 }, 1
  %t6 = extractvalue { i64, ptr } { i64 23, ptr @.d723 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 2, { i64, ptr } { i64 2, ptr @.d724 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eModuleIdentityClash(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 37, ptr @.d725 }, 1
  %t3 = extractvalue { i64, ptr } { i64 37, ptr @.d725 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 46, ptr @.d726 }, 1
  %t9 = extractvalue { i64, ptr } { i64 46, ptr @.d726 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 534, { i64, ptr } { i64 4, ptr @.d727 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMutOnInferredLocal(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 401, { i64, ptr } { i64 4, ptr @.d728 }, { i64, ptr } { i64 99, ptr @.d729 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMutOnLocal(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 59, ptr @.d730 }, 1
  %t3 = extractvalue { i64, ptr } { i64 59, ptr @.d730 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 8, ptr @.d731 }, 1
  %t9 = extractvalue { i64, ptr } { i64 8, ptr @.d731 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 400, { i64, ptr } { i64 4, ptr @.d732 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMutOnValueField(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 77, ptr @.d733 }, 1
  %t3 = extractvalue { i64, ptr } { i64 77, ptr @.d733 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 8, ptr @.d734 }, 1
  %t9 = extractvalue { i64, ptr } { i64 8, ptr @.d734 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 166, { i64, ptr } { i64 2, ptr @.d735 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMutOnValueParam(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 95, ptr @.d736 }, 1
  %t3 = extractvalue { i64, ptr } { i64 95, ptr @.d736 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 8, ptr @.d737 }, 1
  %t9 = extractvalue { i64, ptr } { i64 8, ptr @.d737 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 165, { i64, ptr } { i64 2, ptr @.d738 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMutOnValueType(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 38, ptr @.d739 }, 1
  %t3 = extractvalue { i64, ptr } { i64 38, ptr @.d739 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 16, ptr @.d740 }, 1
  %t9 = extractvalue { i64, ptr } { i64 16, ptr @.d740 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 164, { i64, ptr } { i64 4, ptr @.d741 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNameClashesWithImport(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 57, ptr @.d742 }, 1
  %t6 = extractvalue { i64, ptr } { i64 57, ptr @.d742 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 103, { i64, ptr } { i64 3, ptr @.d743 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNameInUse(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 35, ptr @.d744 }, 1
  %t6 = extractvalue { i64, ptr } { i64 35, ptr @.d744 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 124, { i64, ptr } { i64 2, ptr @.d745 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNameIsType(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 57, ptr @.d746 }, 1
  %t6 = extractvalue { i64, ptr } { i64 57, ptr @.d746 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 118, { i64, ptr } { i64 2, ptr @.d747 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNamedScopeOnElement(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 144, { i64, ptr } { i64 3, ptr @.d748 }, { i64, ptr } { i64 73, ptr @.d749 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNeedlessGroup(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 76, { i64, ptr } { i64 4, ptr @.d750 }, { i64, ptr } { i64 113, ptr @.d751 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNegLiteralTooLarge(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 1, ptr @.d752 }, 1
  %t3 = extractvalue { i64, ptr } { i64 1, ptr @.d752 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 23, ptr @.d753 }, 1
  %t9 = extractvalue { i64, ptr } { i64 23, ptr @.d753 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 306, { i64, ptr } { i64 3, ptr @.d754 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNestedArrayLiteral(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 373, { i64, ptr } { i64 3, ptr @.d755 }, { i64, ptr } { i64 108, ptr @.d756 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNesting(ptr %v0, i64 %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 17, ptr @.d757 }, 1
  %t3 = extractvalue { i64, ptr } { i64 17, ptr @.d757 }, 0
  %t5 = call i64 @__olang_fmt_i64(ptr null, i64 %a0)
  %t6 = add i64 %t3, %t5
  %t7 = extractvalue { i64, ptr } { i64 48, ptr @.d758 }, 1
  %t8 = extractvalue { i64, ptr } { i64 48, ptr @.d758 }, 0
  %t9 = add i64 %t6, %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t9)
  call void @olang_textcopy(ptr %t10, ptr %t2, i64 %t3)
  %t11 = getelementptr i8, ptr %t10, i64 %t3
  %t12 = call i64 @__olang_fmt_i64(ptr %t11, i64 %a0)
  %t13 = getelementptr i8, ptr %t11, i64 %t5
  call void @olang_textcopy(ptr %t13, ptr %t7, i64 %t8)
  %t14 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t10, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 70, { i64, ptr } { i64 3, ptr @.d759 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoClang(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 57, ptr @.d760 }, 1
  %t3 = extractvalue { i64, ptr } { i64 57, ptr @.d760 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 1, ptr @.d761 }, 1
  %t9 = extractvalue { i64, ptr } { i64 1, ptr @.d761 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 44, { i64, ptr } { i64 0, ptr @.d762 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoMain(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 43, { i64, ptr } { i64 2, ptr @.d763 }, { i64, ptr } { i64 54, ptr @.d764 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoRule(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 30, ptr @.d765 }, 1
  %t3 = extractvalue { i64, ptr } { i64 30, ptr @.d765 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 30, { i64, ptr } { i64 4, ptr @.d766 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSpec(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 20, ptr @.d767 }, 1
  %t3 = extractvalue { i64, ptr } { i64 20, ptr @.d767 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 29, { i64, ptr } { i64 4, ptr @.d768 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSuchCase(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 13, ptr @.d769 }, 1
  %t7 = extractvalue { i64, ptr } { i64 13, ptr @.d769 }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t6, i64 %t7)
  %t15 = getelementptr i8, ptr %t14, i64 %t7
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t27 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 319, { i64, ptr } { i64 3, ptr @.d770 }, { i64, ptr } %t24)
  store %"compiler/msgs:Msg" %t27, ptr %l7
  br label %bb1
bb1:
  %t28 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSuchCaseMeant(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = extractvalue { i64, ptr } { i64 13, ptr @.d771 }, 1
  %t8 = extractvalue { i64, ptr } { i64 13, ptr @.d771 }, 0
  %t9 = add i64 %t6, %t8
  %t11 = extractvalue { i64, ptr } %a1, 1
  %t12 = extractvalue { i64, ptr } %a1, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 17, ptr @.d772 }, 1
  %t15 = extractvalue { i64, ptr } { i64 17, ptr @.d772 }, 0
  %t16 = add i64 %t13, %t15
  %t18 = extractvalue { i64, ptr } %a2, 1
  %t19 = extractvalue { i64, ptr } %a2, 0
  %t20 = add i64 %t16, %t19
  %t21 = extractvalue { i64, ptr } { i64 2, ptr @.d773 }, 1
  %t22 = extractvalue { i64, ptr } { i64 2, ptr @.d773 }, 0
  %t23 = add i64 %t20, %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t5, i64 %t6)
  %t25 = getelementptr i8, ptr %t24, i64 %t6
  call void @olang_textcopy(ptr %t25, ptr %t7, i64 %t8)
  %t26 = getelementptr i8, ptr %t25, i64 %t8
  call void @olang_textcopy(ptr %t26, ptr %t11, i64 %t12)
  %t27 = getelementptr i8, ptr %t26, i64 %t12
  call void @olang_textcopy(ptr %t27, ptr %t14, i64 %t15)
  %t28 = getelementptr i8, ptr %t27, i64 %t15
  call void @olang_textcopy(ptr %t28, ptr %t18, i64 %t19)
  %t29 = getelementptr i8, ptr %t28, i64 %t19
  call void @olang_textcopy(ptr %t29, ptr %t21, i64 %t22)
  %t30 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t24, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t41 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 320, { i64, ptr } { i64 3, ptr @.d774 }, { i64, ptr } %t38)
  store %"compiler/msgs:Msg" %t41, ptr %l9
  br label %bb1
bb1:
  %t42 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t42, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSuchErrorWord(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 13, ptr @.d775 }, 1
  %t7 = extractvalue { i64, ptr } { i64 13, ptr @.d775 }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t6, i64 %t7)
  %t15 = getelementptr i8, ptr %t14, i64 %t7
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t27 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 318, { i64, ptr } { i64 3, ptr @.d776 }, { i64, ptr } %t24)
  store %"compiler/msgs:Msg" %t27, ptr %l7
  br label %bb1
bb1:
  %t28 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSuchMember(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 16, ptr @.d777 }, 1
  %t7 = extractvalue { i64, ptr } { i64 16, ptr @.d777 }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 1, ptr @.d778 }, 1
  %t14 = extractvalue { i64, ptr } { i64 1, ptr @.d778 }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 274, { i64, ptr } { i64 0, ptr @.d779 }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoZeroValue(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 95, ptr @.d780 }, 1
  %t7 = extractvalue { i64, ptr } { i64 95, ptr @.d780 }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t6, i64 %t7)
  %t15 = getelementptr i8, ptr %t14, i64 %t7
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t27 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 499, { i64, ptr } { i64 4, ptr @.d781 }, { i64, ptr } %t24)
  store %"compiler/msgs:Msg" %t27, ptr %l7
  br label %bb1
bb1:
  %t28 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNonAscii(ptr %v0, i8 %a0) #0 {
entry:
  %l1 = alloca i32
  %l3 = alloca { i64, ptr }
  %l6 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 50, ptr %l1
  %t3 = call { i64, ptr } @compiler_2fmsgs_2eEsc(ptr %s0, i8 %a0)
  store { i64, ptr } %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = extractvalue { i64, ptr } { i64 16, ptr @.d782 }, 1
  %t5 = extractvalue { i64, ptr } { i64 16, ptr @.d782 }, 0
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 1
  %t8 = extractvalue { i64, ptr } %t6, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 25, ptr @.d783 }, 1
  %t11 = extractvalue { i64, ptr } { i64 25, ptr @.d783 }, 0
  %t12 = add i64 %t9, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t7, i64 %t8)
  %t15 = getelementptr i8, ptr %t14, i64 %t8
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t25 = load i32, ptr %l1
  %t27 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t25, { i64, ptr } { i64 2, ptr @.d784 }, { i64, ptr } %t24)
  store %"compiler/msgs:Msg" %t27, ptr %l6
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t28 = load %"compiler/msgs:Msg", ptr %l6
  store %"compiler/msgs:Msg" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoreturnErrors(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 444, { i64, ptr } { i64 3, ptr @.d785 }, { i64, ptr } { i64 90, ptr @.d786 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoreturnFallsOff(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 443, { i64, ptr } { i64 3, ptr @.d787 }, { i64, ptr } { i64 109, ptr @.d788 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoreturnHere(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 21, ptr @.d789 }, 1
  %t6 = extractvalue { i64, ptr } { i64 21, ptr @.d789 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 445, { i64, ptr } { i64 3, ptr @.d790 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotAMode(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 1, ptr @.d791 }, 1
  %t3 = extractvalue { i64, ptr } { i64 1, ptr @.d791 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 135, ptr @.d792 }, 1
  %t9 = extractvalue { i64, ptr } { i64 135, ptr @.d792 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 1, { i64, ptr } { i64 2, ptr @.d793 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotASource(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 1, ptr @.d794 }, 1
  %t3 = extractvalue { i64, ptr } { i64 1, ptr @.d794 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 56, ptr @.d795 }, 1
  %t9 = extractvalue { i64, ptr } { i64 56, ptr @.d795 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 8, { i64, ptr } { i64 2, ptr @.d796 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotAStatement(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 403, { i64, ptr } { i64 2, ptr @.d797 }, { i64, ptr } { i64 78, ptr @.d798 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotAnEnum(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 50, ptr @.d799 }, 1
  %t6 = extractvalue { i64, ptr } { i64 50, ptr @.d799 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 377, { i64, ptr } { i64 3, ptr @.d800 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotAssignable(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 276, { i64, ptr } { i64 2, ptr @.d801 }, { i64, ptr } { i64 63, ptr @.d802 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotCallable(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 40, ptr @.d803 }, 1
  %t6 = extractvalue { i64, ptr } { i64 40, ptr @.d803 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 330, { i64, ptr } { i64 4, ptr @.d804 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotExtendedOp(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = extractvalue { i64, ptr } { i64 42, ptr @.d805 }, 1
  %t8 = extractvalue { i64, ptr } { i64 42, ptr @.d805 }, 0
  %t9 = add i64 %t6, %t8
  %t11 = extractvalue { i64, ptr } %a1, 1
  %t12 = extractvalue { i64, ptr } %a1, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 22, ptr @.d806 }, 1
  %t15 = extractvalue { i64, ptr } { i64 22, ptr @.d806 }, 0
  %t16 = add i64 %t13, %t15
  %t18 = extractvalue { i64, ptr } %a2, 1
  %t19 = extractvalue { i64, ptr } %a2, 0
  %t20 = add i64 %t16, %t19
  %t21 = extractvalue { i64, ptr } { i64 30, ptr @.d807 }, 1
  %t22 = extractvalue { i64, ptr } { i64 30, ptr @.d807 }, 0
  %t23 = add i64 %t20, %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t5, i64 %t6)
  %t25 = getelementptr i8, ptr %t24, i64 %t6
  call void @olang_textcopy(ptr %t25, ptr %t7, i64 %t8)
  %t26 = getelementptr i8, ptr %t25, i64 %t8
  call void @olang_textcopy(ptr %t26, ptr %t11, i64 %t12)
  %t27 = getelementptr i8, ptr %t26, i64 %t12
  call void @olang_textcopy(ptr %t27, ptr %t14, i64 %t15)
  %t28 = getelementptr i8, ptr %t27, i64 %t15
  call void @olang_textcopy(ptr %t28, ptr %t18, i64 %t19)
  %t29 = getelementptr i8, ptr %t28, i64 %t19
  call void @olang_textcopy(ptr %t29, ptr %t21, i64 %t22)
  %t30 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t24, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t41 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 323, { i64, ptr } { i64 4, ptr @.d808 }, { i64, ptr } %t38)
  store %"compiler/msgs:Msg" %t41, ptr %l9
  br label %bb1
bb1:
  %t42 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t42, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotInModule(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 13, ptr @.d809 }, 1
  %t7 = extractvalue { i64, ptr } { i64 13, ptr @.d809 }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t6, i64 %t7)
  %t15 = getelementptr i8, ptr %t14, i64 %t7
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t27 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 205, { i64, ptr } { i64 0, ptr @.d810 }, { i64, ptr } %t24)
  store %"compiler/msgs:Msg" %t27, ptr %l7
  br label %bb1
bb1:
  %t28 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotIndexable(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 18, ptr @.d811 }, 1
  %t6 = extractvalue { i64, ptr } { i64 18, ptr @.d811 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 269, { i64, ptr } { i64 3, ptr @.d812 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotIterable(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 120, ptr @.d813 }, 1
  %t6 = extractvalue { i64, ptr } { i64 120, ptr @.d813 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 413, { i64, ptr } { i64 3, ptr @.d814 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotRegular(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 41, { i64, ptr } { i64 0, ptr @.d815 }, { i64, ptr } { i64 18, ptr @.d816 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotSliceable(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 17, ptr @.d817 }, 1
  %t6 = extractvalue { i64, ptr } { i64 17, ptr @.d817 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 272, { i64, ptr } { i64 4, ptr @.d818 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotTheOperator(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l13 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = extractvalue { i64, ptr } { i64 3, ptr @.d819 }, 1
  %t10 = extractvalue { i64, ptr } { i64 3, ptr @.d819 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 7, ptr @.d820 }, 1
  %t17 = extractvalue { i64, ptr } { i64 7, ptr @.d820 }, 0
  %t18 = add i64 %t15, %t17
  %t20 = extractvalue { i64, ptr } %a2, 1
  %t21 = extractvalue { i64, ptr } %a2, 0
  %t22 = add i64 %t18, %t21
  %t23 = extractvalue { i64, ptr } { i64 56, ptr @.d821 }, 1
  %t24 = extractvalue { i64, ptr } { i64 56, ptr @.d821 }, 0
  %t25 = add i64 %t22, %t24
  %t27 = extractvalue { i64, ptr } %a3, 1
  %t28 = extractvalue { i64, ptr } %a3, 0
  %t29 = add i64 %t25, %t28
  %t30 = extractvalue { i64, ptr } { i64 20, ptr @.d822 }, 1
  %t31 = extractvalue { i64, ptr } { i64 20, ptr @.d822 }, 0
  %t32 = add i64 %t29, %t31
  %t34 = extractvalue { i64, ptr } %a4, 1
  %t35 = extractvalue { i64, ptr } %a4, 0
  %t36 = add i64 %t32, %t35
  %t37 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t36)
  call void @olang_textcopy(ptr %t37, ptr %t7, i64 %t8)
  %t38 = getelementptr i8, ptr %t37, i64 %t8
  call void @olang_textcopy(ptr %t38, ptr %t9, i64 %t10)
  %t39 = getelementptr i8, ptr %t38, i64 %t10
  call void @olang_textcopy(ptr %t39, ptr %t13, i64 %t14)
  %t40 = getelementptr i8, ptr %t39, i64 %t14
  call void @olang_textcopy(ptr %t40, ptr %t16, i64 %t17)
  %t41 = getelementptr i8, ptr %t40, i64 %t17
  call void @olang_textcopy(ptr %t41, ptr %t20, i64 %t21)
  %t42 = getelementptr i8, ptr %t41, i64 %t21
  call void @olang_textcopy(ptr %t42, ptr %t23, i64 %t24)
  %t43 = getelementptr i8, ptr %t42, i64 %t24
  call void @olang_textcopy(ptr %t43, ptr %t27, i64 %t28)
  %t44 = getelementptr i8, ptr %t43, i64 %t28
  call void @olang_textcopy(ptr %t44, ptr %t30, i64 %t31)
  %t45 = getelementptr i8, ptr %t44, i64 %t31
  call void @olang_textcopy(ptr %t45, ptr %t34, i64 %t35)
  %t46 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t37, 1
  %t49 = extractvalue { i64, ptr } %t47, 0
  %t50 = extractvalue { i64, ptr } %t47, 1
  %t51 = mul i64 %t49, 1
  %t52 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t51)
  call void @llvm.memcpy.p0.p0.i64(ptr %t52, ptr %t50, i64 %t51, i1 false)
  %t53 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  %t57 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v5, ptr %v5, ptr %v5, i32 174, { i64, ptr } { i64 3, ptr @.d823 }, { i64, ptr } %t54)
  store %"compiler/msgs:Msg" %t57, ptr %l13
  br label %bb1
bb1:
  %t58 = load %"compiler/msgs:Msg", ptr %l13
  store %"compiler/msgs:Msg" %t58, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteCondValue(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 524, { i64, ptr } { i64 0, ptr @.d824 }, { i64, ptr } { i64 111, ptr @.d825 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDeclareWhere(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l13 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = extractvalue { i64, ptr } { i64 1, ptr @.d826 }, 1
  %t7 = extractvalue { i64, ptr } { i64 1, ptr @.d826 }, 0
  %t9 = extractvalue { i64, ptr } %a0, 1
  %t10 = extractvalue { i64, ptr } %a0, 0
  %t11 = add i64 %t7, %t10
  %t12 = extractvalue { i64, ptr } { i64 69, ptr @.d827 }, 1
  %t13 = extractvalue { i64, ptr } { i64 69, ptr @.d827 }, 0
  %t14 = add i64 %t11, %t13
  %t16 = extractvalue { i64, ptr } %a1, 1
  %t17 = extractvalue { i64, ptr } %a1, 0
  %t18 = add i64 %t14, %t17
  %t19 = extractvalue { i64, ptr } { i64 10, ptr @.d828 }, 1
  %t20 = extractvalue { i64, ptr } { i64 10, ptr @.d828 }, 0
  %t21 = add i64 %t18, %t20
  %t23 = extractvalue { i64, ptr } %a2, 1
  %t24 = extractvalue { i64, ptr } %a2, 0
  %t25 = add i64 %t21, %t24
  %t26 = extractvalue { i64, ptr } { i64 1, ptr @.d829 }, 1
  %t27 = extractvalue { i64, ptr } { i64 1, ptr @.d829 }, 0
  %t28 = add i64 %t25, %t27
  %t30 = extractvalue { i64, ptr } %a3, 1
  %t31 = extractvalue { i64, ptr } %a3, 0
  %t32 = add i64 %t28, %t31
  %t33 = extractvalue { i64, ptr } { i64 1, ptr @.d830 }, 1
  %t34 = extractvalue { i64, ptr } { i64 1, ptr @.d830 }, 0
  %t35 = add i64 %t32, %t34
  %t37 = extractvalue { i64, ptr } %a4, 1
  %t38 = extractvalue { i64, ptr } %a4, 0
  %t39 = add i64 %t35, %t38
  %t40 = extractvalue { i64, ptr } { i64 7, ptr @.d831 }, 1
  %t41 = extractvalue { i64, ptr } { i64 7, ptr @.d831 }, 0
  %t42 = add i64 %t39, %t41
  %t43 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t42)
  call void @olang_textcopy(ptr %t43, ptr %t6, i64 %t7)
  %t44 = getelementptr i8, ptr %t43, i64 %t7
  call void @olang_textcopy(ptr %t44, ptr %t9, i64 %t10)
  %t45 = getelementptr i8, ptr %t44, i64 %t10
  call void @olang_textcopy(ptr %t45, ptr %t12, i64 %t13)
  %t46 = getelementptr i8, ptr %t45, i64 %t13
  call void @olang_textcopy(ptr %t46, ptr %t16, i64 %t17)
  %t47 = getelementptr i8, ptr %t46, i64 %t17
  call void @olang_textcopy(ptr %t47, ptr %t19, i64 %t20)
  %t48 = getelementptr i8, ptr %t47, i64 %t20
  call void @olang_textcopy(ptr %t48, ptr %t23, i64 %t24)
  %t49 = getelementptr i8, ptr %t48, i64 %t24
  call void @olang_textcopy(ptr %t49, ptr %t26, i64 %t27)
  %t50 = getelementptr i8, ptr %t49, i64 %t27
  call void @olang_textcopy(ptr %t50, ptr %t30, i64 %t31)
  %t51 = getelementptr i8, ptr %t50, i64 %t31
  call void @olang_textcopy(ptr %t51, ptr %t33, i64 %t34)
  %t52 = getelementptr i8, ptr %t51, i64 %t34
  call void @olang_textcopy(ptr %t52, ptr %t37, i64 %t38)
  %t53 = getelementptr i8, ptr %t52, i64 %t38
  call void @olang_textcopy(ptr %t53, ptr %t40, i64 %t41)
  %t54 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t43, 1
  %t57 = extractvalue { i64, ptr } %t55, 0
  %t58 = extractvalue { i64, ptr } %t55, 1
  %t59 = mul i64 %t57, 1
  %t60 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t59)
  call void @llvm.memcpy.p0.p0.i64(ptr %t60, ptr %t58, i64 %t59, i1 false)
  %t61 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t60, 1
  %t65 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v5, ptr %v5, ptr %v5, i32 520, { i64, ptr } { i64 0, ptr @.d832 }, { i64, ptr } %t62)
  store %"compiler/msgs:Msg" %t65, ptr %l13
  br label %bb1
bb1:
  %t66 = load %"compiler/msgs:Msg", ptr %l13
  store %"compiler/msgs:Msg" %t66, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDeclareWritable(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } { i64 1, ptr @.d833 }, 1
  %t5 = extractvalue { i64, ptr } { i64 1, ptr @.d833 }, 0
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 43, ptr @.d834 }, 1
  %t11 = extractvalue { i64, ptr } { i64 43, ptr @.d834 }, 0
  %t12 = add i64 %t9, %t11
  %t14 = extractvalue { i64, ptr } %a1, 1
  %t15 = extractvalue { i64, ptr } %a1, 0
  %t16 = add i64 %t12, %t15
  %t17 = extractvalue { i64, ptr } { i64 5, ptr @.d835 }, 1
  %t18 = extractvalue { i64, ptr } { i64 5, ptr @.d835 }, 0
  %t19 = add i64 %t16, %t18
  %t21 = extractvalue { i64, ptr } %a2, 1
  %t22 = extractvalue { i64, ptr } %a2, 0
  %t23 = add i64 %t19, %t22
  %t24 = extractvalue { i64, ptr } { i64 21, ptr @.d836 }, 1
  %t25 = extractvalue { i64, ptr } { i64 21, ptr @.d836 }, 0
  %t26 = add i64 %t23, %t25
  %t27 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t4, i64 %t5)
  %t28 = getelementptr i8, ptr %t27, i64 %t5
  call void @olang_textcopy(ptr %t28, ptr %t7, i64 %t8)
  %t29 = getelementptr i8, ptr %t28, i64 %t8
  call void @olang_textcopy(ptr %t29, ptr %t10, i64 %t11)
  %t30 = getelementptr i8, ptr %t29, i64 %t11
  call void @olang_textcopy(ptr %t30, ptr %t14, i64 %t15)
  %t31 = getelementptr i8, ptr %t30, i64 %t15
  call void @olang_textcopy(ptr %t31, ptr %t17, i64 %t18)
  %t32 = getelementptr i8, ptr %t31, i64 %t18
  call void @olang_textcopy(ptr %t32, ptr %t21, i64 %t22)
  %t33 = getelementptr i8, ptr %t32, i64 %t22
  call void @olang_textcopy(ptr %t33, ptr %t24, i64 %t25)
  %t34 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t27, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = extractvalue { i64, ptr } %t35, 1
  %t39 = mul i64 %t37, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t39)
  call void @llvm.memcpy.p0.p0.i64(ptr %t40, ptr %t38, i64 %t39, i1 false)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  %t45 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 300, { i64, ptr } { i64 0, ptr @.d837 }, { i64, ptr } %t42)
  store %"compiler/msgs:Msg" %t45, ptr %l9
  br label %bb1
bb1:
  %t46 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t46, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDeclaredHere(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 17, ptr @.d838 }, 1
  %t6 = extractvalue { i64, ptr } { i64 17, ptr @.d838 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 299, { i64, ptr } { i64 0, ptr @.d839 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteFuncTypeScopes(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 102, ptr @.d840 }, 1
  %t3 = extractvalue { i64, ptr } { i64 102, ptr @.d840 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 30, ptr @.d841 }, 1
  %t9 = extractvalue { i64, ptr } { i64 30, ptr @.d841 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 286, { i64, ptr } { i64 0, ptr @.d842 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteGroupFunctionType(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 232, { i64, ptr } { i64 0, ptr @.d843 }, { i64, ptr } { i64 106, ptr @.d844 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteHeldIndexWhere(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 103, ptr @.d845 }, 1
  %t3 = extractvalue { i64, ptr } { i64 103, ptr @.d845 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 33, ptr @.d846 }, 1
  %t9 = extractvalue { i64, ptr } { i64 33, ptr @.d846 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 523, { i64, ptr } { i64 0, ptr @.d847 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteHere(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 285, { i64, ptr } { i64 0, ptr @.d848 }, { i64, ptr } { i64 4, ptr @.d849 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteInLibrary(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 293, { i64, ptr } { i64 0, ptr @.d850 }, { i64, ptr } { i64 36, ptr @.d851 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteLiteralLocal(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l11 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } { i64 1, ptr @.d852 }, 1
  %t6 = extractvalue { i64, ptr } { i64 1, ptr @.d852 }, 0
  %t8 = extractvalue { i64, ptr } %a0, 1
  %t9 = extractvalue { i64, ptr } %a0, 0
  %t10 = add i64 %t6, %t9
  %t11 = extractvalue { i64, ptr } { i64 5, ptr @.d853 }, 1
  %t12 = extractvalue { i64, ptr } { i64 5, ptr @.d853 }, 0
  %t13 = add i64 %t10, %t12
  %t15 = extractvalue { i64, ptr } %a1, 1
  %t16 = extractvalue { i64, ptr } %a1, 0
  %t17 = add i64 %t13, %t16
  %t18 = extractvalue { i64, ptr } { i64 61, ptr @.d854 }, 1
  %t19 = extractvalue { i64, ptr } { i64 61, ptr @.d854 }, 0
  %t20 = add i64 %t17, %t19
  %t22 = extractvalue { i64, ptr } %a2, 1
  %t23 = extractvalue { i64, ptr } %a2, 0
  %t24 = add i64 %t20, %t23
  %t25 = extractvalue { i64, ptr } { i64 1, ptr @.d855 }, 1
  %t26 = extractvalue { i64, ptr } { i64 1, ptr @.d855 }, 0
  %t27 = add i64 %t24, %t26
  %t29 = extractvalue { i64, ptr } %a3, 1
  %t30 = extractvalue { i64, ptr } %a3, 0
  %t31 = add i64 %t27, %t30
  %t32 = extractvalue { i64, ptr } { i64 7, ptr @.d856 }, 1
  %t33 = extractvalue { i64, ptr } { i64 7, ptr @.d856 }, 0
  %t34 = add i64 %t31, %t33
  %t35 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t34)
  call void @olang_textcopy(ptr %t35, ptr %t5, i64 %t6)
  %t36 = getelementptr i8, ptr %t35, i64 %t6
  call void @olang_textcopy(ptr %t36, ptr %t8, i64 %t9)
  %t37 = getelementptr i8, ptr %t36, i64 %t9
  call void @olang_textcopy(ptr %t37, ptr %t11, i64 %t12)
  %t38 = getelementptr i8, ptr %t37, i64 %t12
  call void @olang_textcopy(ptr %t38, ptr %t15, i64 %t16)
  %t39 = getelementptr i8, ptr %t38, i64 %t16
  call void @olang_textcopy(ptr %t39, ptr %t18, i64 %t19)
  %t40 = getelementptr i8, ptr %t39, i64 %t19
  call void @olang_textcopy(ptr %t40, ptr %t22, i64 %t23)
  %t41 = getelementptr i8, ptr %t40, i64 %t23
  call void @olang_textcopy(ptr %t41, ptr %t25, i64 %t26)
  %t42 = getelementptr i8, ptr %t41, i64 %t26
  call void @olang_textcopy(ptr %t42, ptr %t29, i64 %t30)
  %t43 = getelementptr i8, ptr %t42, i64 %t30
  call void @olang_textcopy(ptr %t43, ptr %t32, i64 %t33)
  %t44 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t35, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = extractvalue { i64, ptr } %t45, 1
  %t49 = mul i64 %t47, 1
  %t50 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t49)
  call void @llvm.memcpy.p0.p0.i64(ptr %t50, ptr %t48, i64 %t49, i1 false)
  %t51 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  %t55 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, i32 301, { i64, ptr } { i64 0, ptr @.d857 }, { i64, ptr } %t52)
  store %"compiler/msgs:Msg" %t55, ptr %l11
  br label %bb1
bb1:
  %t56 = load %"compiler/msgs:Msg", ptr %l11
  store %"compiler/msgs:Msg" %t56, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteLiteralRange(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l13 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = extractvalue { i64, ptr } { i64 27, ptr @.d858 }, 1
  %t7 = extractvalue { i64, ptr } { i64 27, ptr @.d858 }, 0
  %t9 = extractvalue { i64, ptr } %a0, 1
  %t10 = extractvalue { i64, ptr } %a0, 0
  %t11 = add i64 %t7, %t10
  %t12 = extractvalue { i64, ptr } { i64 2, ptr @.d859 }, 1
  %t13 = extractvalue { i64, ptr } { i64 2, ptr @.d859 }, 0
  %t14 = add i64 %t11, %t13
  %t16 = extractvalue { i64, ptr } %a1, 1
  %t17 = extractvalue { i64, ptr } %a1, 0
  %t18 = add i64 %t14, %t17
  %t19 = extractvalue { i64, ptr } { i64 10, ptr @.d860 }, 1
  %t20 = extractvalue { i64, ptr } { i64 10, ptr @.d860 }, 0
  %t21 = add i64 %t18, %t20
  %t23 = extractvalue { i64, ptr } %a2, 1
  %t24 = extractvalue { i64, ptr } %a2, 0
  %t25 = add i64 %t21, %t24
  %t26 = extractvalue { i64, ptr } { i64 1, ptr @.d861 }, 1
  %t27 = extractvalue { i64, ptr } { i64 1, ptr @.d861 }, 0
  %t28 = add i64 %t25, %t27
  %t30 = extractvalue { i64, ptr } %a3, 1
  %t31 = extractvalue { i64, ptr } %a3, 0
  %t32 = add i64 %t28, %t31
  %t33 = extractvalue { i64, ptr } { i64 12, ptr @.d862 }, 1
  %t34 = extractvalue { i64, ptr } { i64 12, ptr @.d862 }, 0
  %t35 = add i64 %t32, %t34
  %t37 = extractvalue { i64, ptr } %a4, 1
  %t38 = extractvalue { i64, ptr } %a4, 0
  %t39 = add i64 %t35, %t38
  %t40 = extractvalue { i64, ptr } { i64 7, ptr @.d863 }, 1
  %t41 = extractvalue { i64, ptr } { i64 7, ptr @.d863 }, 0
  %t42 = add i64 %t39, %t41
  %t43 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t42)
  call void @olang_textcopy(ptr %t43, ptr %t6, i64 %t7)
  %t44 = getelementptr i8, ptr %t43, i64 %t7
  call void @olang_textcopy(ptr %t44, ptr %t9, i64 %t10)
  %t45 = getelementptr i8, ptr %t44, i64 %t10
  call void @olang_textcopy(ptr %t45, ptr %t12, i64 %t13)
  %t46 = getelementptr i8, ptr %t45, i64 %t13
  call void @olang_textcopy(ptr %t46, ptr %t16, i64 %t17)
  %t47 = getelementptr i8, ptr %t46, i64 %t17
  call void @olang_textcopy(ptr %t47, ptr %t19, i64 %t20)
  %t48 = getelementptr i8, ptr %t47, i64 %t20
  call void @olang_textcopy(ptr %t48, ptr %t23, i64 %t24)
  %t49 = getelementptr i8, ptr %t48, i64 %t24
  call void @olang_textcopy(ptr %t49, ptr %t26, i64 %t27)
  %t50 = getelementptr i8, ptr %t49, i64 %t27
  call void @olang_textcopy(ptr %t50, ptr %t30, i64 %t31)
  %t51 = getelementptr i8, ptr %t50, i64 %t31
  call void @olang_textcopy(ptr %t51, ptr %t33, i64 %t34)
  %t52 = getelementptr i8, ptr %t51, i64 %t34
  call void @olang_textcopy(ptr %t52, ptr %t37, i64 %t38)
  %t53 = getelementptr i8, ptr %t52, i64 %t38
  call void @olang_textcopy(ptr %t53, ptr %t40, i64 %t41)
  %t54 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t43, 1
  %t57 = extractvalue { i64, ptr } %t55, 0
  %t58 = extractvalue { i64, ptr } %t55, 1
  %t59 = mul i64 %t57, 1
  %t60 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t59)
  call void @llvm.memcpy.p0.p0.i64(ptr %t60, ptr %t58, i64 %t59, i1 false)
  %t61 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t60, 1
  %t65 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v5, ptr %v5, ptr %v5, i32 302, { i64, ptr } { i64 0, ptr @.d864 }, { i64, ptr } %t62)
  store %"compiler/msgs:Msg" %t65, ptr %l13
  br label %bb1
bb1:
  %t66 = load %"compiler/msgs:Msg", ptr %l13
  store %"compiler/msgs:Msg" %t66, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteLiteralRangeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l11 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } { i64 27, ptr @.d865 }, 1
  %t6 = extractvalue { i64, ptr } { i64 27, ptr @.d865 }, 0
  %t8 = extractvalue { i64, ptr } %a0, 1
  %t9 = extractvalue { i64, ptr } %a0, 0
  %t10 = add i64 %t6, %t9
  %t11 = extractvalue { i64, ptr } { i64 2, ptr @.d866 }, 1
  %t12 = extractvalue { i64, ptr } { i64 2, ptr @.d866 }, 0
  %t13 = add i64 %t10, %t12
  %t15 = extractvalue { i64, ptr } %a1, 1
  %t16 = extractvalue { i64, ptr } %a1, 0
  %t17 = add i64 %t13, %t16
  %t18 = extractvalue { i64, ptr } { i64 21, ptr @.d867 }, 1
  %t19 = extractvalue { i64, ptr } { i64 21, ptr @.d867 }, 0
  %t20 = add i64 %t17, %t19
  %t22 = extractvalue { i64, ptr } %a2, 1
  %t23 = extractvalue { i64, ptr } %a2, 0
  %t24 = add i64 %t20, %t23
  %t25 = extractvalue { i64, ptr } { i64 12, ptr @.d868 }, 1
  %t26 = extractvalue { i64, ptr } { i64 12, ptr @.d868 }, 0
  %t27 = add i64 %t24, %t26
  %t29 = extractvalue { i64, ptr } %a3, 1
  %t30 = extractvalue { i64, ptr } %a3, 0
  %t31 = add i64 %t27, %t30
  %t32 = extractvalue { i64, ptr } { i64 7, ptr @.d869 }, 1
  %t33 = extractvalue { i64, ptr } { i64 7, ptr @.d869 }, 0
  %t34 = add i64 %t31, %t33
  %t35 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t34)
  call void @olang_textcopy(ptr %t35, ptr %t5, i64 %t6)
  %t36 = getelementptr i8, ptr %t35, i64 %t6
  call void @olang_textcopy(ptr %t36, ptr %t8, i64 %t9)
  %t37 = getelementptr i8, ptr %t36, i64 %t9
  call void @olang_textcopy(ptr %t37, ptr %t11, i64 %t12)
  %t38 = getelementptr i8, ptr %t37, i64 %t12
  call void @olang_textcopy(ptr %t38, ptr %t15, i64 %t16)
  %t39 = getelementptr i8, ptr %t38, i64 %t16
  call void @olang_textcopy(ptr %t39, ptr %t18, i64 %t19)
  %t40 = getelementptr i8, ptr %t39, i64 %t19
  call void @olang_textcopy(ptr %t40, ptr %t22, i64 %t23)
  %t41 = getelementptr i8, ptr %t40, i64 %t23
  call void @olang_textcopy(ptr %t41, ptr %t25, i64 %t26)
  %t42 = getelementptr i8, ptr %t41, i64 %t26
  call void @olang_textcopy(ptr %t42, ptr %t29, i64 %t30)
  %t43 = getelementptr i8, ptr %t42, i64 %t30
  call void @olang_textcopy(ptr %t43, ptr %t32, i64 %t33)
  %t44 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t35, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = extractvalue { i64, ptr } %t45, 1
  %t49 = mul i64 %t47, 1
  %t50 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t49)
  call void @llvm.memcpy.p0.p0.i64(ptr %t50, ptr %t48, i64 %t49, i1 false)
  %t51 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  %t55 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, i32 303, { i64, ptr } { i64 0, ptr @.d870 }, { i64, ptr } %t52)
  store %"compiler/msgs:Msg" %t55, ptr %l11
  br label %bb1
bb1:
  %t56 = load %"compiler/msgs:Msg", ptr %l11
  store %"compiler/msgs:Msg" %t56, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteLoopCopy(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } { i64 1, ptr @.d871 }, 1
  %t5 = extractvalue { i64, ptr } { i64 1, ptr @.d871 }, 0
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 89, ptr @.d872 }, 1
  %t11 = extractvalue { i64, ptr } { i64 89, ptr @.d872 }, 0
  %t12 = add i64 %t9, %t11
  %t14 = extractvalue { i64, ptr } %a1, 1
  %t15 = extractvalue { i64, ptr } %a1, 0
  %t16 = add i64 %t12, %t15
  %t17 = extractvalue { i64, ptr } { i64 27, ptr @.d873 }, 1
  %t18 = extractvalue { i64, ptr } { i64 27, ptr @.d873 }, 0
  %t19 = add i64 %t16, %t18
  %t21 = extractvalue { i64, ptr } %a2, 1
  %t22 = extractvalue { i64, ptr } %a2, 0
  %t23 = add i64 %t19, %t22
  %t24 = extractvalue { i64, ptr } { i64 7, ptr @.d874 }, 1
  %t25 = extractvalue { i64, ptr } { i64 7, ptr @.d874 }, 0
  %t26 = add i64 %t23, %t25
  %t27 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t4, i64 %t5)
  %t28 = getelementptr i8, ptr %t27, i64 %t5
  call void @olang_textcopy(ptr %t28, ptr %t7, i64 %t8)
  %t29 = getelementptr i8, ptr %t28, i64 %t8
  call void @olang_textcopy(ptr %t29, ptr %t10, i64 %t11)
  %t30 = getelementptr i8, ptr %t29, i64 %t11
  call void @olang_textcopy(ptr %t30, ptr %t14, i64 %t15)
  %t31 = getelementptr i8, ptr %t30, i64 %t15
  call void @olang_textcopy(ptr %t31, ptr %t17, i64 %t18)
  %t32 = getelementptr i8, ptr %t31, i64 %t18
  call void @olang_textcopy(ptr %t32, ptr %t21, i64 %t22)
  %t33 = getelementptr i8, ptr %t32, i64 %t22
  call void @olang_textcopy(ptr %t33, ptr %t24, i64 %t25)
  %t34 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t27, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = extractvalue { i64, ptr } %t35, 1
  %t39 = mul i64 %t37, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t39)
  call void @llvm.memcpy.p0.p0.i64(ptr %t40, ptr %t38, i64 %t39, i1 false)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  %t45 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 527, { i64, ptr } { i64 0, ptr @.d875 }, { i64, ptr } %t42)
  store %"compiler/msgs:Msg" %t45, ptr %l9
  br label %bb1
bb1:
  %t46 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t46, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteLoopCopyLent(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 1, ptr @.d876 }, 1
  %t3 = extractvalue { i64, ptr } { i64 1, ptr @.d876 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 185, ptr @.d877 }, 1
  %t9 = extractvalue { i64, ptr } { i64 185, ptr @.d877 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 521, { i64, ptr } { i64 0, ptr @.d878 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteMakeWhere(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l11 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } { i64 1, ptr @.d879 }, 1
  %t6 = extractvalue { i64, ptr } { i64 1, ptr @.d879 }, 0
  %t8 = extractvalue { i64, ptr } %a0, 1
  %t9 = extractvalue { i64, ptr } %a0, 0
  %t10 = add i64 %t6, %t9
  %t11 = extractvalue { i64, ptr } { i64 62, ptr @.d880 }, 1
  %t12 = extractvalue { i64, ptr } { i64 62, ptr @.d880 }, 0
  %t13 = add i64 %t10, %t12
  %t15 = extractvalue { i64, ptr } %a1, 1
  %t16 = extractvalue { i64, ptr } %a1, 0
  %t17 = add i64 %t13, %t16
  %t18 = extractvalue { i64, ptr } { i64 10, ptr @.d881 }, 1
  %t19 = extractvalue { i64, ptr } { i64 10, ptr @.d881 }, 0
  %t20 = add i64 %t17, %t19
  %t22 = extractvalue { i64, ptr } %a2, 1
  %t23 = extractvalue { i64, ptr } %a2, 0
  %t24 = add i64 %t20, %t23
  %t25 = extractvalue { i64, ptr } { i64 1, ptr @.d882 }, 1
  %t26 = extractvalue { i64, ptr } { i64 1, ptr @.d882 }, 0
  %t27 = add i64 %t24, %t26
  %t29 = extractvalue { i64, ptr } %a3, 1
  %t30 = extractvalue { i64, ptr } %a3, 0
  %t31 = add i64 %t27, %t30
  %t32 = extractvalue { i64, ptr } { i64 6, ptr @.d883 }, 1
  %t33 = extractvalue { i64, ptr } { i64 6, ptr @.d883 }, 0
  %t34 = add i64 %t31, %t33
  %t35 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t34)
  call void @olang_textcopy(ptr %t35, ptr %t5, i64 %t6)
  %t36 = getelementptr i8, ptr %t35, i64 %t6
  call void @olang_textcopy(ptr %t36, ptr %t8, i64 %t9)
  %t37 = getelementptr i8, ptr %t36, i64 %t9
  call void @olang_textcopy(ptr %t37, ptr %t11, i64 %t12)
  %t38 = getelementptr i8, ptr %t37, i64 %t12
  call void @olang_textcopy(ptr %t38, ptr %t15, i64 %t16)
  %t39 = getelementptr i8, ptr %t38, i64 %t16
  call void @olang_textcopy(ptr %t39, ptr %t18, i64 %t19)
  %t40 = getelementptr i8, ptr %t39, i64 %t19
  call void @olang_textcopy(ptr %t40, ptr %t22, i64 %t23)
  %t41 = getelementptr i8, ptr %t40, i64 %t23
  call void @olang_textcopy(ptr %t41, ptr %t25, i64 %t26)
  %t42 = getelementptr i8, ptr %t41, i64 %t26
  call void @olang_textcopy(ptr %t42, ptr %t29, i64 %t30)
  %t43 = getelementptr i8, ptr %t42, i64 %t30
  call void @olang_textcopy(ptr %t43, ptr %t32, i64 %t33)
  %t44 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t35, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = extractvalue { i64, ptr } %t45, 1
  %t49 = mul i64 %t47, 1
  %t50 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t49)
  call void @llvm.memcpy.p0.p0.i64(ptr %t50, ptr %t48, i64 %t49, i1 false)
  %t51 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  %t55 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, i32 518, { i64, ptr } { i64 0, ptr @.d884 }, { i64, ptr } %t52)
  store %"compiler/msgs:Msg" %t55, ptr %l11
  br label %bb1
bb1:
  %t56 = load %"compiler/msgs:Msg", ptr %l11
  store %"compiler/msgs:Msg" %t56, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteObligationOrigin(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 517, { i64, ptr } { i64 0, ptr @.d885 }, { i64, ptr } { i64 48, ptr @.d886 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteOtherSignature(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 1, ptr @.d887 }, 1
  %t3 = extractvalue { i64, ptr } { i64 1, ptr @.d887 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 42, ptr @.d888 }, 1
  %t9 = extractvalue { i64, ptr } { i64 42, ptr @.d888 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 296, { i64, ptr } { i64 0, ptr @.d889 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotePrivateSpelling(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 1, ptr @.d890 }, 1
  %t4 = extractvalue { i64, ptr } { i64 1, ptr @.d890 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 46, ptr @.d891 }, 1
  %t10 = extractvalue { i64, ptr } { i64 46, ptr @.d891 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 21, ptr @.d892 }, 1
  %t17 = extractvalue { i64, ptr } { i64 21, ptr @.d892 }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 297, { i64, ptr } { i64 0, ptr @.d893 }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteProtocolSpelling(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } { i64 1, ptr @.d894 }, 1
  %t5 = extractvalue { i64, ptr } { i64 1, ptr @.d894 }, 0
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 5, ptr @.d895 }, 1
  %t11 = extractvalue { i64, ptr } { i64 5, ptr @.d895 }, 0
  %t12 = add i64 %t9, %t11
  %t14 = extractvalue { i64, ptr } %a1, 1
  %t15 = extractvalue { i64, ptr } %a1, 0
  %t16 = add i64 %t12, %t15
  %t17 = extractvalue { i64, ptr } { i64 25, ptr @.d896 }, 1
  %t18 = extractvalue { i64, ptr } { i64 25, ptr @.d896 }, 0
  %t19 = add i64 %t16, %t18
  %t21 = extractvalue { i64, ptr } %a2, 1
  %t22 = extractvalue { i64, ptr } %a2, 0
  %t23 = add i64 %t19, %t22
  %t24 = extractvalue { i64, ptr } { i64 41, ptr @.d897 }, 1
  %t25 = extractvalue { i64, ptr } { i64 41, ptr @.d897 }, 0
  %t26 = add i64 %t23, %t25
  %t27 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t4, i64 %t5)
  %t28 = getelementptr i8, ptr %t27, i64 %t5
  call void @olang_textcopy(ptr %t28, ptr %t7, i64 %t8)
  %t29 = getelementptr i8, ptr %t28, i64 %t8
  call void @olang_textcopy(ptr %t29, ptr %t10, i64 %t11)
  %t30 = getelementptr i8, ptr %t29, i64 %t11
  call void @olang_textcopy(ptr %t30, ptr %t14, i64 %t15)
  %t31 = getelementptr i8, ptr %t30, i64 %t15
  call void @olang_textcopy(ptr %t31, ptr %t17, i64 %t18)
  %t32 = getelementptr i8, ptr %t31, i64 %t18
  call void @olang_textcopy(ptr %t32, ptr %t21, i64 %t22)
  %t33 = getelementptr i8, ptr %t32, i64 %t22
  call void @olang_textcopy(ptr %t33, ptr %t24, i64 %t25)
  %t34 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t27, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = extractvalue { i64, ptr } %t35, 1
  %t39 = mul i64 %t37, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t39)
  call void @llvm.memcpy.p0.p0.i64(ptr %t40, ptr %t38, i64 %t39, i1 false)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  %t45 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 298, { i64, ptr } { i64 0, ptr @.d898 }, { i64, ptr } %t42)
  store %"compiler/msgs:Msg" %t45, ptr %l9
  br label %bb1
bb1:
  %t46 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t46, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteReadOnlyCopy(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 1, ptr @.d899 }, 1
  %t3 = extractvalue { i64, ptr } { i64 1, ptr @.d899 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 54, ptr @.d900 }, 1
  %t9 = extractvalue { i64, ptr } { i64 54, ptr @.d900 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 233, { i64, ptr } { i64 0, ptr @.d901 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteReadOnlyCopyOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l11 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } { i64 1, ptr @.d902 }, 1
  %t6 = extractvalue { i64, ptr } { i64 1, ptr @.d902 }, 0
  %t8 = extractvalue { i64, ptr } %a0, 1
  %t9 = extractvalue { i64, ptr } %a0, 0
  %t10 = add i64 %t6, %t9
  %t11 = extractvalue { i64, ptr } { i64 10, ptr @.d903 }, 1
  %t12 = extractvalue { i64, ptr } { i64 10, ptr @.d903 }, 0
  %t13 = add i64 %t10, %t12
  %t15 = extractvalue { i64, ptr } %a1, 1
  %t16 = extractvalue { i64, ptr } %a1, 0
  %t17 = add i64 %t13, %t16
  %t18 = extractvalue { i64, ptr } { i64 44, ptr @.d904 }, 1
  %t19 = extractvalue { i64, ptr } { i64 44, ptr @.d904 }, 0
  %t20 = add i64 %t17, %t19
  %t22 = extractvalue { i64, ptr } %a2, 1
  %t23 = extractvalue { i64, ptr } %a2, 0
  %t24 = add i64 %t20, %t23
  %t25 = extractvalue { i64, ptr } { i64 4, ptr @.d905 }, 1
  %t26 = extractvalue { i64, ptr } { i64 4, ptr @.d905 }, 0
  %t27 = add i64 %t24, %t26
  %t29 = extractvalue { i64, ptr } %a3, 1
  %t30 = extractvalue { i64, ptr } %a3, 0
  %t31 = add i64 %t27, %t30
  %t32 = extractvalue { i64, ptr } { i64 33, ptr @.d906 }, 1
  %t33 = extractvalue { i64, ptr } { i64 33, ptr @.d906 }, 0
  %t34 = add i64 %t31, %t33
  %t35 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t34)
  call void @olang_textcopy(ptr %t35, ptr %t5, i64 %t6)
  %t36 = getelementptr i8, ptr %t35, i64 %t6
  call void @olang_textcopy(ptr %t36, ptr %t8, i64 %t9)
  %t37 = getelementptr i8, ptr %t36, i64 %t9
  call void @olang_textcopy(ptr %t37, ptr %t11, i64 %t12)
  %t38 = getelementptr i8, ptr %t37, i64 %t12
  call void @olang_textcopy(ptr %t38, ptr %t15, i64 %t16)
  %t39 = getelementptr i8, ptr %t38, i64 %t16
  call void @olang_textcopy(ptr %t39, ptr %t18, i64 %t19)
  %t40 = getelementptr i8, ptr %t39, i64 %t19
  call void @olang_textcopy(ptr %t40, ptr %t22, i64 %t23)
  %t41 = getelementptr i8, ptr %t40, i64 %t23
  call void @olang_textcopy(ptr %t41, ptr %t25, i64 %t26)
  %t42 = getelementptr i8, ptr %t41, i64 %t26
  call void @olang_textcopy(ptr %t42, ptr %t29, i64 %t30)
  %t43 = getelementptr i8, ptr %t42, i64 %t30
  call void @olang_textcopy(ptr %t43, ptr %t32, i64 %t33)
  %t44 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t35, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = extractvalue { i64, ptr } %t45, 1
  %t49 = mul i64 %t47, 1
  %t50 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t49)
  call void @llvm.memcpy.p0.p0.i64(ptr %t50, ptr %t48, i64 %t49, i1 false)
  %t51 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  %t55 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, i32 234, { i64, ptr } { i64 0, ptr @.d907 }, { i64, ptr } %t52)
  store %"compiler/msgs:Msg" %t55, ptr %l11
  br label %bb1
bb1:
  %t56 = load %"compiler/msgs:Msg", ptr %l11
  store %"compiler/msgs:Msg" %t56, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteRefillKept(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 26, ptr @.d908 }, 1
  %t4 = extractvalue { i64, ptr } { i64 26, ptr @.d908 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 53, ptr @.d909 }, 1
  %t10 = extractvalue { i64, ptr } { i64 53, ptr @.d909 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 77, ptr @.d910 }, 1
  %t17 = extractvalue { i64, ptr } { i64 77, ptr @.d910 }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 519, { i64, ptr } { i64 0, ptr @.d911 }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteSliceOfTemporary(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 525, { i64, ptr } { i64 0, ptr @.d912 }, { i64, ptr } { i64 145, ptr @.d913 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteStrBuildsHere(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 291, { i64, ptr } { i64 0, ptr @.d914 }, { i64, ptr } { i64 57, ptr @.d915 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteStrKeepCopies(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 1, ptr @.d916 }, 1
  %t4 = extractvalue { i64, ptr } { i64 1, ptr @.d916 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 24, ptr @.d917 }, 1
  %t10 = extractvalue { i64, ptr } { i64 24, ptr @.d917 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 106, ptr @.d918 }, 1
  %t17 = extractvalue { i64, ptr } { i64 106, ptr @.d918 }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 292, { i64, ptr } { i64 0, ptr @.d919 }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteTextCopyWhere(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 81, ptr @.d920 }, 1
  %t3 = extractvalue { i64, ptr } { i64 81, ptr @.d920 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 28, ptr @.d921 }, 1
  %t9 = extractvalue { i64, ptr } { i64 28, ptr @.d921 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 526, { i64, ptr } { i64 0, ptr @.d922 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteVecGrewHere(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 287, { i64, ptr } { i64 0, ptr @.d923 }, { i64, ptr } { i64 118, ptr @.d924 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteVecGrowsHere(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } { i64 1, ptr @.d925 }, 1
  %t5 = extractvalue { i64, ptr } { i64 1, ptr @.d925 }, 0
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 20, ptr @.d926 }, 1
  %t11 = extractvalue { i64, ptr } { i64 20, ptr @.d926 }, 0
  %t12 = add i64 %t9, %t11
  %t14 = extractvalue { i64, ptr } %a1, 1
  %t15 = extractvalue { i64, ptr } %a1, 0
  %t16 = add i64 %t12, %t15
  %t17 = extractvalue { i64, ptr } { i64 56, ptr @.d927 }, 1
  %t18 = extractvalue { i64, ptr } { i64 56, ptr @.d927 }, 0
  %t19 = add i64 %t16, %t18
  %t21 = extractvalue { i64, ptr } %a2, 1
  %t22 = extractvalue { i64, ptr } %a2, 0
  %t23 = add i64 %t19, %t22
  %t24 = extractvalue { i64, ptr } { i64 11, ptr @.d928 }, 1
  %t25 = extractvalue { i64, ptr } { i64 11, ptr @.d928 }, 0
  %t26 = add i64 %t23, %t25
  %t27 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t4, i64 %t5)
  %t28 = getelementptr i8, ptr %t27, i64 %t5
  call void @olang_textcopy(ptr %t28, ptr %t7, i64 %t8)
  %t29 = getelementptr i8, ptr %t28, i64 %t8
  call void @olang_textcopy(ptr %t29, ptr %t10, i64 %t11)
  %t30 = getelementptr i8, ptr %t29, i64 %t11
  call void @olang_textcopy(ptr %t30, ptr %t14, i64 %t15)
  %t31 = getelementptr i8, ptr %t30, i64 %t15
  call void @olang_textcopy(ptr %t31, ptr %t17, i64 %t18)
  %t32 = getelementptr i8, ptr %t31, i64 %t18
  call void @olang_textcopy(ptr %t32, ptr %t21, i64 %t22)
  %t33 = getelementptr i8, ptr %t32, i64 %t22
  call void @olang_textcopy(ptr %t33, ptr %t24, i64 %t25)
  %t34 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t27, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = extractvalue { i64, ptr } %t35, 1
  %t39 = mul i64 %t37, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t39)
  call void @llvm.memcpy.p0.p0.i64(ptr %t40, ptr %t38, i64 %t39, i1 false)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  %t45 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 288, { i64, ptr } { i64 0, ptr @.d929 }, { i64, ptr } %t42)
  store %"compiler/msgs:Msg" %t45, ptr %l9
  br label %bb1
bb1:
  %t46 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t46, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteVecGrowsInside(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 17, ptr @.d930 }, 1
  %t6 = extractvalue { i64, ptr } { i64 17, ptr @.d930 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 289, { i64, ptr } { i64 0, ptr @.d931 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteVecTaskHolds(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 28, ptr @.d932 }, 1
  %t3 = extractvalue { i64, ptr } { i64 28, ptr @.d932 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 17, ptr @.d933 }, 1
  %t9 = extractvalue { i64, ptr } { i64 17, ptr @.d933 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 290, { i64, ptr } { i64 0, ptr @.d934 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteViewRefusedBy(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 522, { i64, ptr } { i64 0, ptr @.d935 }, { i64, ptr } { i64 62, ptr @.d936 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteZeroByReference(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 1, ptr @.d937 }, 1
  %t3 = extractvalue { i64, ptr } { i64 1, ptr @.d937 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 49, ptr @.d938 }, 1
  %t9 = extractvalue { i64, ptr } { i64 49, ptr @.d938 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 294, { i64, ptr } { i64 0, ptr @.d939 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteZeroReferenceHasOne(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 33, ptr @.d940 }, 1
  %t4 = extractvalue { i64, ptr } { i64 33, ptr @.d940 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 5, ptr @.d941 }, 1
  %t10 = extractvalue { i64, ptr } { i64 5, ptr @.d941 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 26, ptr @.d942 }, 1
  %t17 = extractvalue { i64, ptr } { i64 26, ptr @.d942 }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 295, { i64, ptr } { i64 0, ptr @.d943 }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNulByte(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 52, { i64, ptr } { i64 2, ptr @.d944 }, { i64, ptr } { i64 45, ptr @.d945 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNumberDoesNotFlow(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = extractvalue { i64, ptr } { i64 20, ptr @.d946 }, 1
  %t8 = extractvalue { i64, ptr } { i64 20, ptr @.d946 }, 0
  %t9 = add i64 %t6, %t8
  %t11 = extractvalue { i64, ptr } %a1, 1
  %t12 = extractvalue { i64, ptr } %a1, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 18, ptr @.d947 }, 1
  %t15 = extractvalue { i64, ptr } { i64 18, ptr @.d947 }, 0
  %t16 = add i64 %t13, %t15
  %t18 = extractvalue { i64, ptr } %a2, 1
  %t19 = extractvalue { i64, ptr } %a2, 0
  %t20 = add i64 %t16, %t19
  %t21 = extractvalue { i64, ptr } { i64 3, ptr @.d948 }, 1
  %t22 = extractvalue { i64, ptr } { i64 3, ptr @.d948 }, 0
  %t23 = add i64 %t20, %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t5, i64 %t6)
  %t25 = getelementptr i8, ptr %t24, i64 %t6
  call void @olang_textcopy(ptr %t25, ptr %t7, i64 %t8)
  %t26 = getelementptr i8, ptr %t25, i64 %t8
  call void @olang_textcopy(ptr %t26, ptr %t11, i64 %t12)
  %t27 = getelementptr i8, ptr %t26, i64 %t12
  call void @olang_textcopy(ptr %t27, ptr %t14, i64 %t15)
  %t28 = getelementptr i8, ptr %t27, i64 %t15
  call void @olang_textcopy(ptr %t28, ptr %t18, i64 %t19)
  %t29 = getelementptr i8, ptr %t28, i64 %t19
  call void @olang_textcopy(ptr %t29, ptr %t21, i64 %t22)
  %t30 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t24, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t41 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 216, { i64, ptr } { i64 3, ptr @.d949 }, { i64, ptr } %t38)
  store %"compiler/msgs:Msg" %t41, ptr %l9
  br label %bb1
bb1:
  %t42 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t42, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNumbersDoNotMeet(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 5, ptr @.d950 }, 1
  %t7 = extractvalue { i64, ptr } { i64 5, ptr @.d950 }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 56, ptr @.d951 }, 1
  %t14 = extractvalue { i64, ptr } { i64 56, ptr @.d951 }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 315, { i64, ptr } { i64 3, ptr @.d952 }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperandNotBool(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 21, ptr @.d953 }, 1
  %t7 = extractvalue { i64, ptr } { i64 21, ptr @.d953 }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t6, i64 %t7)
  %t15 = getelementptr i8, ptr %t14, i64 %t7
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t27 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 307, { i64, ptr } { i64 2, ptr @.d954 }, { i64, ptr } %t24)
  store %"compiler/msgs:Msg" %t27, ptr %l7
  br label %bb1
bb1:
  %t28 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperandNotInt(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 25, ptr @.d955 }, 1
  %t7 = extractvalue { i64, ptr } { i64 25, ptr @.d955 }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t6, i64 %t7)
  %t15 = getelementptr i8, ptr %t14, i64 %t7
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t27 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 308, { i64, ptr } { i64 2, ptr @.d956 }, { i64, ptr } %t24)
  store %"compiler/msgs:Msg" %t27, ptr %l7
  br label %bb1
bb1:
  %t28 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperandNotNumber(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 22, ptr @.d957 }, 1
  %t7 = extractvalue { i64, ptr } { i64 22, ptr @.d957 }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t6, i64 %t7)
  %t15 = getelementptr i8, ptr %t14, i64 %t7
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t27 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 309, { i64, ptr } { i64 2, ptr @.d958 }, { i64, ptr } %t24)
  store %"compiler/msgs:Msg" %t27, ptr %l7
  br label %bb1
bb1:
  %t28 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperandsDiffer(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = extractvalue { i64, ptr } { i64 35, ptr @.d959 }, 1
  %t8 = extractvalue { i64, ptr } { i64 35, ptr @.d959 }, 0
  %t9 = add i64 %t6, %t8
  %t11 = extractvalue { i64, ptr } %a1, 1
  %t12 = extractvalue { i64, ptr } %a1, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 5, ptr @.d960 }, 1
  %t15 = extractvalue { i64, ptr } { i64 5, ptr @.d960 }, 0
  %t16 = add i64 %t13, %t15
  %t18 = extractvalue { i64, ptr } %a2, 1
  %t19 = extractvalue { i64, ptr } %a2, 0
  %t20 = add i64 %t16, %t19
  %t21 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t20)
  call void @olang_textcopy(ptr %t21, ptr %t5, i64 %t6)
  %t22 = getelementptr i8, ptr %t21, i64 %t6
  call void @olang_textcopy(ptr %t22, ptr %t7, i64 %t8)
  %t23 = getelementptr i8, ptr %t22, i64 %t8
  call void @olang_textcopy(ptr %t23, ptr %t11, i64 %t12)
  %t24 = getelementptr i8, ptr %t23, i64 %t12
  call void @olang_textcopy(ptr %t24, ptr %t14, i64 %t15)
  %t25 = getelementptr i8, ptr %t24, i64 %t15
  call void @olang_textcopy(ptr %t25, ptr %t18, i64 %t19)
  %t26 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t21, 1
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t30 = extractvalue { i64, ptr } %t27, 1
  %t31 = mul i64 %t29, 1
  %t32 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t31)
  call void @llvm.memcpy.p0.p0.i64(ptr %t32, ptr %t30, i64 %t31, i1 false)
  %t33 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  %t37 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 316, { i64, ptr } { i64 0, ptr @.d961 }, { i64, ptr } %t34)
  store %"compiler/msgs:Msg" %t37, ptr %l9
  br label %bb1
bb1:
  %t38 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t38, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperatorCallFails(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 20, ptr @.d962 }, 1
  %t3 = extractvalue { i64, ptr } { i64 20, ptr @.d962 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 52, ptr @.d963 }, 1
  %t9 = extractvalue { i64, ptr } { i64 52, ptr @.d963 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 333, { i64, ptr } { i64 3, ptr @.d964 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperatorResult(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 17, ptr @.d965 }, 1
  %t6 = extractvalue { i64, ptr } { i64 17, ptr @.d965 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 177, { i64, ptr } { i64 3, ptr @.d966 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eOptionNeedsValue(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 25, ptr @.d967 }, 1
  %t7 = extractvalue { i64, ptr } { i64 25, ptr @.d967 }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t6, i64 %t7)
  %t15 = getelementptr i8, ptr %t14, i64 %t7
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t27 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 6, { i64, ptr } { i64 2, ptr @.d968 }, { i64, ptr } %t24)
  store %"compiler/msgs:Msg" %t27, ptr %l7
  br label %bb1
bb1:
  %t28 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eOptionNotForMode(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = extractvalue { i64, ptr } { i64 12, ptr @.d969 }, 1
  %t8 = extractvalue { i64, ptr } { i64 12, ptr @.d969 }, 0
  %t9 = add i64 %t6, %t8
  %t11 = extractvalue { i64, ptr } %a1, 1
  %t12 = extractvalue { i64, ptr } %a1, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 9, ptr @.d970 }, 1
  %t15 = extractvalue { i64, ptr } { i64 9, ptr @.d970 }, 0
  %t16 = add i64 %t13, %t15
  %t18 = extractvalue { i64, ptr } %a2, 1
  %t19 = extractvalue { i64, ptr } %a2, 0
  %t20 = add i64 %t16, %t19
  %t21 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t20)
  call void @olang_textcopy(ptr %t21, ptr %t5, i64 %t6)
  %t22 = getelementptr i8, ptr %t21, i64 %t6
  call void @olang_textcopy(ptr %t22, ptr %t7, i64 %t8)
  %t23 = getelementptr i8, ptr %t22, i64 %t8
  call void @olang_textcopy(ptr %t23, ptr %t11, i64 %t12)
  %t24 = getelementptr i8, ptr %t23, i64 %t12
  call void @olang_textcopy(ptr %t24, ptr %t14, i64 %t15)
  %t25 = getelementptr i8, ptr %t24, i64 %t15
  call void @olang_textcopy(ptr %t25, ptr %t18, i64 %t19)
  %t26 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t21, 1
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t30 = extractvalue { i64, ptr } %t27, 1
  %t31 = mul i64 %t29, 1
  %t32 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t31)
  call void @llvm.memcpy.p0.p0.i64(ptr %t32, ptr %t30, i64 %t31, i1 false)
  %t33 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  %t37 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 5, { i64, ptr } { i64 2, ptr @.d971 }, { i64, ptr } %t34)
  store %"compiler/msgs:Msg" %t37, ptr %l9
  br label %bb1
bb1:
  %t38 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t38, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eOutputCannotWrite(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 13, { i64, ptr } { i64 3, ptr @.d972 }, { i64, ptr } { i64 15, ptr @.d973 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eOutputIsDir(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 8, ptr @.d974 }, 1
  %t3 = extractvalue { i64, ptr } { i64 8, ptr @.d974 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 40, ptr @.d975 }, 1
  %t9 = extractvalue { i64, ptr } { i64 40, ptr @.d975 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 11, { i64, ptr } { i64 3, ptr @.d976 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eOutputNoDir(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 8, ptr @.d977 }, 1
  %t4 = extractvalue { i64, ptr } { i64 8, ptr @.d977 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 24, ptr @.d978 }, 1
  %t10 = extractvalue { i64, ptr } { i64 24, ptr @.d978 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t3, i64 %t4)
  %t17 = getelementptr i8, ptr %t16, i64 %t4
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t9, i64 %t10)
  %t19 = getelementptr i8, ptr %t18, i64 %t10
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 12, { i64, ptr } { i64 3, ptr @.d979 }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eOverrideSignature(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 91, ptr @.d980 }, 1
  %t6 = extractvalue { i64, ptr } { i64 91, ptr @.d980 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 189, { i64, ptr } { i64 4, ptr @.d981 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eOwnCannotOutlive(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 209, { i64, ptr } { i64 4, ptr @.d982 }, { i64, ptr } { i64 65, ptr @.d983 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eOwnFromBareRefParam(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 210, { i64, ptr } { i64 4, ptr @.d984 }, { i64, ptr } { i64 89, ptr @.d985 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eParamTooLarge(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } { i64 10, ptr @.d986 }, 1
  %t5 = extractvalue { i64, ptr } { i64 10, ptr @.d986 }, 0
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 7, ptr @.d987 }, 1
  %t11 = extractvalue { i64, ptr } { i64 7, ptr @.d987 }, 0
  %t12 = add i64 %t9, %t11
  %t14 = call i64 @__olang_fmt_i64(ptr null, i64 %a1)
  %t15 = add i64 %t12, %t14
  %t16 = extractvalue { i64, ptr } { i64 70, ptr @.d988 }, 1
  %t17 = extractvalue { i64, ptr } { i64 70, ptr @.d988 }, 0
  %t18 = add i64 %t15, %t17
  %t20 = extractvalue { i64, ptr } %a2, 1
  %t21 = extractvalue { i64, ptr } %a2, 0
  %t22 = add i64 %t18, %t21
  %t23 = extractvalue { i64, ptr } { i64 2, ptr @.d989 }, 1
  %t24 = extractvalue { i64, ptr } { i64 2, ptr @.d989 }, 0
  %t25 = add i64 %t22, %t24
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @olang_textcopy(ptr %t26, ptr %t4, i64 %t5)
  %t27 = getelementptr i8, ptr %t26, i64 %t5
  call void @olang_textcopy(ptr %t27, ptr %t7, i64 %t8)
  %t28 = getelementptr i8, ptr %t27, i64 %t8
  call void @olang_textcopy(ptr %t28, ptr %t10, i64 %t11)
  %t29 = getelementptr i8, ptr %t28, i64 %t11
  %t30 = call i64 @__olang_fmt_i64(ptr %t29, i64 %a1)
  %t31 = getelementptr i8, ptr %t29, i64 %t14
  call void @olang_textcopy(ptr %t31, ptr %t16, i64 %t17)
  %t32 = getelementptr i8, ptr %t31, i64 %t17
  call void @olang_textcopy(ptr %t32, ptr %t20, i64 %t21)
  %t33 = getelementptr i8, ptr %t32, i64 %t21
  call void @olang_textcopy(ptr %t33, ptr %t23, i64 %t24)
  %t34 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t26, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = extractvalue { i64, ptr } %t35, 1
  %t39 = mul i64 %t37, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t39)
  call void @llvm.memcpy.p0.p0.i64(ptr %t40, ptr %t38, i64 %t39, i1 false)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  %t45 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 140, { i64, ptr } { i64 3, ptr @.d990 }, { i64, ptr } %t42)
  store %"compiler/msgs:Msg" %t45, ptr %l9
  br label %bb1
bb1:
  %t46 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t46, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2ePatternArity(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 5, ptr @.d991 }, 1
  %t4 = extractvalue { i64, ptr } { i64 5, ptr @.d991 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 7, ptr @.d992 }, 1
  %t10 = extractvalue { i64, ptr } { i64 7, ptr @.d992 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = call i64 @__olang_fmt_i64(ptr null, i64 %a1)
  %t14 = add i64 %t11, %t13
  %t15 = extractvalue { i64, ptr } { i64 64, ptr @.d993 }, 1
  %t16 = extractvalue { i64, ptr } { i64 64, ptr @.d993 }, 0
  %t17 = add i64 %t14, %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t17)
  call void @olang_textcopy(ptr %t18, ptr %t3, i64 %t4)
  %t19 = getelementptr i8, ptr %t18, i64 %t4
  call void @olang_textcopy(ptr %t19, ptr %t6, i64 %t7)
  %t20 = getelementptr i8, ptr %t19, i64 %t7
  call void @olang_textcopy(ptr %t20, ptr %t9, i64 %t10)
  %t21 = getelementptr i8, ptr %t20, i64 %t10
  %t22 = call i64 @__olang_fmt_i64(ptr %t21, i64 %a1)
  %t23 = getelementptr i8, ptr %t21, i64 %t13
  call void @olang_textcopy(ptr %t23, ptr %t15, i64 %t16)
  %t24 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t18, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 418, { i64, ptr } { i64 4, ptr @.d994 }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2ePatternType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 31, ptr @.d995 }, 1
  %t4 = extractvalue { i64, ptr } { i64 31, ptr @.d995 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 8, ptr @.d996 }, 1
  %t10 = extractvalue { i64, ptr } { i64 8, ptr @.d996 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t3, i64 %t4)
  %t17 = getelementptr i8, ptr %t16, i64 %t4
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t9, i64 %t10)
  %t19 = getelementptr i8, ptr %t18, i64 %t10
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 337, { i64, ptr } { i64 4, ptr @.d997 }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2ePayloadOutlived(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 394, { i64, ptr } { i64 4, ptr @.d998 }, { i64, ptr } { i64 106, ptr @.d999 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2ePayloadScopesDisagree(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 391, { i64, ptr } { i64 4, ptr @.d1000 }, { i64, ptr } { i64 101, ptr @.d1001 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2ePointNoDigit(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 66, { i64, ptr } { i64 3, ptr @.d1002 }, { i64, ptr } { i64 38, ptr @.d1003 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2ePreludeConstRedeclared(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 51, ptr @.d1004 }, 1
  %t6 = extractvalue { i64, ptr } { i64 51, ptr @.d1004 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 201, { i64, ptr } { i64 3, ptr @.d1005 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2ePrimCtorNotPrimitive(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 167, { i64, ptr } { i64 4, ptr @.d1006 }, { i64, ptr } { i64 106, ptr @.d1007 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2ePrimCtorParam(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 46, ptr @.d1008 }, 1
  %t3 = extractvalue { i64, ptr } { i64 46, ptr @.d1008 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 22, ptr @.d1009 }, 1
  %t9 = extractvalue { i64, ptr } { i64 22, ptr @.d1009 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 168, { i64, ptr } { i64 4, ptr @.d1010 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eProtocolBothSpellings(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l11 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = extractvalue { i64, ptr } { i64 10, ptr @.d1011 }, 1
  %t9 = extractvalue { i64, ptr } { i64 10, ptr @.d1011 }, 0
  %t10 = add i64 %t7, %t9
  %t12 = extractvalue { i64, ptr } %a1, 1
  %t13 = extractvalue { i64, ptr } %a1, 0
  %t14 = add i64 %t10, %t13
  %t15 = extractvalue { i64, ptr } { i64 39, ptr @.d1012 }, 1
  %t16 = extractvalue { i64, ptr } { i64 39, ptr @.d1012 }, 0
  %t17 = add i64 %t14, %t16
  %t19 = extractvalue { i64, ptr } %a2, 1
  %t20 = extractvalue { i64, ptr } %a2, 0
  %t21 = add i64 %t17, %t20
  %t22 = extractvalue { i64, ptr } { i64 5, ptr @.d1013 }, 1
  %t23 = extractvalue { i64, ptr } { i64 5, ptr @.d1013 }, 0
  %t24 = add i64 %t21, %t23
  %t26 = extractvalue { i64, ptr } %a3, 1
  %t27 = extractvalue { i64, ptr } %a3, 0
  %t28 = add i64 %t24, %t27
  %t29 = extractvalue { i64, ptr } { i64 24, ptr @.d1014 }, 1
  %t30 = extractvalue { i64, ptr } { i64 24, ptr @.d1014 }, 0
  %t31 = add i64 %t28, %t30
  %t32 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t31)
  call void @olang_textcopy(ptr %t32, ptr %t6, i64 %t7)
  %t33 = getelementptr i8, ptr %t32, i64 %t7
  call void @olang_textcopy(ptr %t33, ptr %t8, i64 %t9)
  %t34 = getelementptr i8, ptr %t33, i64 %t9
  call void @olang_textcopy(ptr %t34, ptr %t12, i64 %t13)
  %t35 = getelementptr i8, ptr %t34, i64 %t13
  call void @olang_textcopy(ptr %t35, ptr %t15, i64 %t16)
  %t36 = getelementptr i8, ptr %t35, i64 %t16
  call void @olang_textcopy(ptr %t36, ptr %t19, i64 %t20)
  %t37 = getelementptr i8, ptr %t36, i64 %t20
  call void @olang_textcopy(ptr %t37, ptr %t22, i64 %t23)
  %t38 = getelementptr i8, ptr %t37, i64 %t23
  call void @olang_textcopy(ptr %t38, ptr %t26, i64 %t27)
  %t39 = getelementptr i8, ptr %t38, i64 %t27
  call void @olang_textcopy(ptr %t39, ptr %t29, i64 %t30)
  %t40 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t32, 1
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t44 = extractvalue { i64, ptr } %t41, 1
  %t45 = mul i64 %t43, 1
  %t46 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t45)
  call void @llvm.memcpy.p0.p0.i64(ptr %t46, ptr %t44, i64 %t45, i1 false)
  %t47 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  %t51 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, i32 187, { i64, ptr } { i64 3, ptr @.d1015 }, { i64, ptr } %t48)
  store %"compiler/msgs:Msg" %t51, ptr %l11
  br label %bb1
bb1:
  %t52 = load %"compiler/msgs:Msg", ptr %l11
  store %"compiler/msgs:Msg" %t52, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eProtocolPrivate(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l11 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = extractvalue { i64, ptr } { i64 7, ptr @.d1016 }, 1
  %t9 = extractvalue { i64, ptr } { i64 7, ptr @.d1016 }, 0
  %t10 = add i64 %t7, %t9
  %t12 = extractvalue { i64, ptr } %a1, 1
  %t13 = extractvalue { i64, ptr } %a1, 0
  %t14 = add i64 %t10, %t13
  %t15 = extractvalue { i64, ptr } { i64 3, ptr @.d1017 }, 1
  %t16 = extractvalue { i64, ptr } { i64 3, ptr @.d1017 }, 0
  %t17 = add i64 %t14, %t16
  %t19 = extractvalue { i64, ptr } %a2, 1
  %t20 = extractvalue { i64, ptr } %a2, 0
  %t21 = add i64 %t17, %t20
  %t22 = extractvalue { i64, ptr } { i64 46, ptr @.d1018 }, 1
  %t23 = extractvalue { i64, ptr } { i64 46, ptr @.d1018 }, 0
  %t24 = add i64 %t21, %t23
  %t26 = extractvalue { i64, ptr } %a3, 1
  %t27 = extractvalue { i64, ptr } %a3, 0
  %t28 = add i64 %t24, %t27
  %t29 = extractvalue { i64, ptr } { i64 15, ptr @.d1019 }, 1
  %t30 = extractvalue { i64, ptr } { i64 15, ptr @.d1019 }, 0
  %t31 = add i64 %t28, %t30
  %t32 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t31)
  call void @olang_textcopy(ptr %t32, ptr %t6, i64 %t7)
  %t33 = getelementptr i8, ptr %t32, i64 %t7
  call void @olang_textcopy(ptr %t33, ptr %t8, i64 %t9)
  %t34 = getelementptr i8, ptr %t33, i64 %t9
  call void @olang_textcopy(ptr %t34, ptr %t12, i64 %t13)
  %t35 = getelementptr i8, ptr %t34, i64 %t13
  call void @olang_textcopy(ptr %t35, ptr %t15, i64 %t16)
  %t36 = getelementptr i8, ptr %t35, i64 %t16
  call void @olang_textcopy(ptr %t36, ptr %t19, i64 %t20)
  %t37 = getelementptr i8, ptr %t36, i64 %t20
  call void @olang_textcopy(ptr %t37, ptr %t22, i64 %t23)
  %t38 = getelementptr i8, ptr %t37, i64 %t23
  call void @olang_textcopy(ptr %t38, ptr %t26, i64 %t27)
  %t39 = getelementptr i8, ptr %t38, i64 %t27
  call void @olang_textcopy(ptr %t39, ptr %t29, i64 %t30)
  %t40 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t32, 1
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t44 = extractvalue { i64, ptr } %t41, 1
  %t45 = mul i64 %t43, 1
  %t46 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t45)
  call void @llvm.memcpy.p0.p0.i64(ptr %t46, ptr %t44, i64 %t45, i1 false)
  %t47 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  %t51 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, i32 188, { i64, ptr } { i64 3, ptr @.d1020 }, { i64, ptr } %t48)
  store %"compiler/msgs:Msg" %t51, ptr %l11
  br label %bb1
bb1:
  %t52 = load %"compiler/msgs:Msg", ptr %l11
  store %"compiler/msgs:Msg" %t52, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eQuickAlone(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 11, ptr @.d1021 }, 1
  %t3 = extractvalue { i64, ptr } { i64 11, ptr @.d1021 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 41, ptr @.d1022 }, 1
  %t9 = extractvalue { i64, ptr } { i64 41, ptr @.d1022 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 7, { i64, ptr } { i64 3, ptr @.d1023 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eRangeNotInt(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 46, ptr @.d1024 }, 1
  %t3 = extractvalue { i64, ptr } { i64 46, ptr @.d1024 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 406, { i64, ptr } { i64 3, ptr @.d1025 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eRangeStep(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 407, { i64, ptr } { i64 3, ptr @.d1026 }, { i64, ptr } { i64 51, ptr @.d1027 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyCopyArg(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l11 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } { i64 1, ptr @.d1028 }, 1
  %t6 = extractvalue { i64, ptr } { i64 1, ptr @.d1028 }, 0
  %t8 = extractvalue { i64, ptr } %a0, 1
  %t9 = extractvalue { i64, ptr } %a0, 0
  %t10 = add i64 %t6, %t9
  %t11 = extractvalue { i64, ptr } { i64 41, ptr @.d1029 }, 1
  %t12 = extractvalue { i64, ptr } { i64 41, ptr @.d1029 }, 0
  %t13 = add i64 %t10, %t12
  %t15 = extractvalue { i64, ptr } %a1, 1
  %t16 = extractvalue { i64, ptr } %a1, 0
  %t17 = add i64 %t13, %t16
  %t18 = extractvalue { i64, ptr } { i64 12, ptr @.d1030 }, 1
  %t19 = extractvalue { i64, ptr } { i64 12, ptr @.d1030 }, 0
  %t20 = add i64 %t17, %t19
  %t22 = extractvalue { i64, ptr } %a2, 1
  %t23 = extractvalue { i64, ptr } %a2, 0
  %t24 = add i64 %t20, %t23
  %t25 = extractvalue { i64, ptr } { i64 49, ptr @.d1031 }, 1
  %t26 = extractvalue { i64, ptr } { i64 49, ptr @.d1031 }, 0
  %t27 = add i64 %t24, %t26
  %t29 = extractvalue { i64, ptr } %a3, 1
  %t30 = extractvalue { i64, ptr } %a3, 0
  %t31 = add i64 %t27, %t30
  %t32 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t31)
  call void @olang_textcopy(ptr %t32, ptr %t5, i64 %t6)
  %t33 = getelementptr i8, ptr %t32, i64 %t6
  call void @olang_textcopy(ptr %t33, ptr %t8, i64 %t9)
  %t34 = getelementptr i8, ptr %t33, i64 %t9
  call void @olang_textcopy(ptr %t34, ptr %t11, i64 %t12)
  %t35 = getelementptr i8, ptr %t34, i64 %t12
  call void @olang_textcopy(ptr %t35, ptr %t15, i64 %t16)
  %t36 = getelementptr i8, ptr %t35, i64 %t16
  call void @olang_textcopy(ptr %t36, ptr %t18, i64 %t19)
  %t37 = getelementptr i8, ptr %t36, i64 %t19
  call void @olang_textcopy(ptr %t37, ptr %t22, i64 %t23)
  %t38 = getelementptr i8, ptr %t37, i64 %t23
  call void @olang_textcopy(ptr %t38, ptr %t25, i64 %t26)
  %t39 = getelementptr i8, ptr %t38, i64 %t26
  call void @olang_textcopy(ptr %t39, ptr %t29, i64 %t30)
  %t40 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t32, 1
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t44 = extractvalue { i64, ptr } %t41, 1
  %t45 = mul i64 %t43, 1
  %t46 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t45)
  call void @llvm.memcpy.p0.p0.i64(ptr %t46, ptr %t44, i64 %t45, i1 false)
  %t47 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  %t51 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, i32 227, { i64, ptr } { i64 4, ptr @.d1032 }, { i64, ptr } %t48)
  store %"compiler/msgs:Msg" %t51, ptr %l11
  br label %bb1
bb1:
  %t52 = load %"compiler/msgs:Msg", ptr %l11
  store %"compiler/msgs:Msg" %t52, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyCopyDecl(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 24, ptr @.d1033 }, 1
  %t4 = extractvalue { i64, ptr } { i64 24, ptr @.d1033 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 134, ptr @.d1034 }, 1
  %t10 = extractvalue { i64, ptr } { i64 134, ptr @.d1034 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t3, i64 %t4)
  %t17 = getelementptr i8, ptr %t16, i64 %t4
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t9, i64 %t10)
  %t19 = getelementptr i8, ptr %t18, i64 %t10
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 222, { i64, ptr } { i64 4, ptr @.d1035 }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyCopyGlobal(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 46, ptr @.d1036 }, 1
  %t4 = extractvalue { i64, ptr } { i64 46, ptr @.d1036 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 32, ptr @.d1037 }, 1
  %t10 = extractvalue { i64, ptr } { i64 32, ptr @.d1037 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 19, ptr @.d1038 }, 1
  %t17 = extractvalue { i64, ptr } { i64 19, ptr @.d1038 }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 223, { i64, ptr } { i64 4, ptr @.d1039 }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyCopyLent(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 86, ptr @.d1040 }, 1
  %t3 = extractvalue { i64, ptr } { i64 86, ptr @.d1040 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 228, { i64, ptr } { i64 4, ptr @.d1041 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyCopyRef(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 230, { i64, ptr } { i64 4, ptr @.d1042 }, { i64, ptr } { i64 109, ptr @.d1043 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyCopyReturned(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 22, ptr @.d1044 }, 1
  %t4 = extractvalue { i64, ptr } { i64 22, ptr @.d1044 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 70, ptr @.d1045 }, 1
  %t10 = extractvalue { i64, ptr } { i64 70, ptr @.d1045 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 26, ptr @.d1046 }, 1
  %t17 = extractvalue { i64, ptr } { i64 26, ptr @.d1046 }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 225, { i64, ptr } { i64 4, ptr @.d1047 }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyCopyStored(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 22, ptr @.d1048 }, 1
  %t4 = extractvalue { i64, ptr } { i64 22, ptr @.d1048 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 71, ptr @.d1049 }, 1
  %t10 = extractvalue { i64, ptr } { i64 71, ptr @.d1049 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t3, i64 %t4)
  %t17 = getelementptr i8, ptr %t16, i64 %t4
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t9, i64 %t10)
  %t19 = getelementptr i8, ptr %t18, i64 %t10
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 224, { i64, ptr } { i64 4, ptr @.d1050 }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyCopyWrite(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 229, { i64, ptr } { i64 4, ptr @.d1051 }, { i64, ptr } { i64 117, ptr @.d1052 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyFuncValue(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = extractvalue { i64, ptr } { i64 49, ptr @.d1053 }, 1
  %t8 = extractvalue { i64, ptr } { i64 49, ptr @.d1053 }, 0
  %t9 = add i64 %t6, %t8
  %t11 = extractvalue { i64, ptr } %a1, 1
  %t12 = extractvalue { i64, ptr } %a1, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 110, ptr @.d1054 }, 1
  %t15 = extractvalue { i64, ptr } { i64 110, ptr @.d1054 }, 0
  %t16 = add i64 %t13, %t15
  %t18 = extractvalue { i64, ptr } %a2, 1
  %t19 = extractvalue { i64, ptr } %a2, 0
  %t20 = add i64 %t16, %t19
  %t21 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t20)
  call void @olang_textcopy(ptr %t21, ptr %t5, i64 %t6)
  %t22 = getelementptr i8, ptr %t21, i64 %t6
  call void @olang_textcopy(ptr %t22, ptr %t7, i64 %t8)
  %t23 = getelementptr i8, ptr %t22, i64 %t8
  call void @olang_textcopy(ptr %t23, ptr %t11, i64 %t12)
  %t24 = getelementptr i8, ptr %t23, i64 %t12
  call void @olang_textcopy(ptr %t24, ptr %t14, i64 %t15)
  %t25 = getelementptr i8, ptr %t24, i64 %t15
  call void @olang_textcopy(ptr %t25, ptr %t18, i64 %t19)
  %t26 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t21, 1
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t30 = extractvalue { i64, ptr } %t27, 1
  %t31 = mul i64 %t29, 1
  %t32 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t31)
  call void @llvm.memcpy.p0.p0.i64(ptr %t32, ptr %t30, i64 %t31, i1 false)
  %t33 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  %t37 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 231, { i64, ptr } { i64 4, ptr @.d1055 }, { i64, ptr } %t34)
  store %"compiler/msgs:Msg" %t37, ptr %l9
  br label %bb1
bb1:
  %t38 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t38, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyRefKept(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } { i64 1, ptr @.d1056 }, 1
  %t5 = extractvalue { i64, ptr } { i64 1, ptr @.d1056 }, 0
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 28, ptr @.d1057 }, 1
  %t11 = extractvalue { i64, ptr } { i64 28, ptr @.d1057 }, 0
  %t12 = add i64 %t9, %t11
  %t14 = extractvalue { i64, ptr } %a1, 1
  %t15 = extractvalue { i64, ptr } %a1, 0
  %t16 = add i64 %t12, %t15
  %t17 = extractvalue { i64, ptr } { i64 44, ptr @.d1058 }, 1
  %t18 = extractvalue { i64, ptr } { i64 44, ptr @.d1058 }, 0
  %t19 = add i64 %t16, %t18
  %t21 = extractvalue { i64, ptr } %a2, 1
  %t22 = extractvalue { i64, ptr } %a2, 0
  %t23 = add i64 %t19, %t22
  %t24 = extractvalue { i64, ptr } { i64 35, ptr @.d1059 }, 1
  %t25 = extractvalue { i64, ptr } { i64 35, ptr @.d1059 }, 0
  %t26 = add i64 %t23, %t25
  %t27 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t4, i64 %t5)
  %t28 = getelementptr i8, ptr %t27, i64 %t5
  call void @olang_textcopy(ptr %t28, ptr %t7, i64 %t8)
  %t29 = getelementptr i8, ptr %t28, i64 %t8
  call void @olang_textcopy(ptr %t29, ptr %t10, i64 %t11)
  %t30 = getelementptr i8, ptr %t29, i64 %t11
  call void @olang_textcopy(ptr %t30, ptr %t14, i64 %t15)
  %t31 = getelementptr i8, ptr %t30, i64 %t15
  call void @olang_textcopy(ptr %t31, ptr %t17, i64 %t18)
  %t32 = getelementptr i8, ptr %t31, i64 %t18
  call void @olang_textcopy(ptr %t32, ptr %t21, i64 %t22)
  %t33 = getelementptr i8, ptr %t32, i64 %t22
  call void @olang_textcopy(ptr %t33, ptr %t24, i64 %t25)
  %t34 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t27, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = extractvalue { i64, ptr } %t35, 1
  %t39 = mul i64 %t37, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t39)
  call void @llvm.memcpy.p0.p0.i64(ptr %t40, ptr %t38, i64 %t39, i1 false)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  %t45 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 226, { i64, ptr } { i64 4, ptr @.d1060 }, { i64, ptr } %t42)
  store %"compiler/msgs:Msg" %t45, ptr %l9
  br label %bb1
bb1:
  %t46 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t46, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyRefWrite(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 280, { i64, ptr } { i64 4, ptr @.d1061 }, { i64, ptr } { i64 73, ptr @.d1062 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyToBuiltResult(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 90, ptr @.d1063 }, 1
  %t3 = extractvalue { i64, ptr } { i64 90, ptr @.d1063 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 1, ptr @.d1064 }, 1
  %t9 = extractvalue { i64, ptr } { i64 1, ptr @.d1064 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 220, { i64, ptr } { i64 9, ptr @.d1065 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyToBuiltResultNo(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 221, { i64, ptr } { i64 9, ptr @.d1066 }, { i64, ptr } { i64 151, ptr @.d1067 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyToWritable(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 219, { i64, ptr } { i64 4, ptr @.d1068 }, { i64, ptr } { i64 85, ptr @.d1069 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReexportCycle(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 13, ptr @.d1070 }, 1
  %t3 = extractvalue { i64, ptr } { i64 13, ptr @.d1070 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 26, ptr @.d1071 }, 1
  %t9 = extractvalue { i64, ptr } { i64 26, ptr @.d1071 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 101, { i64, ptr } { i64 3, ptr @.d1072 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eRefTypevarNotAggregate(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 25, ptr @.d1073 }, 1
  %t7 = extractvalue { i64, ptr } { i64 25, ptr @.d1073 }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 43, ptr @.d1074 }, 1
  %t14 = extractvalue { i64, ptr } { i64 43, ptr @.d1074 }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 257, { i64, ptr } { i64 3, ptr @.d1075 }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReferenceNarrowed(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 254, { i64, ptr } { i64 3, ptr @.d1076 }, { i64, ptr } { i64 98, ptr @.d1077 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReferenceNarrowedLocal(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 29, ptr @.d1078 }, 1
  %t3 = extractvalue { i64, ptr } { i64 29, ptr @.d1078 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 62, ptr @.d1079 }, 1
  %t9 = extractvalue { i64, ptr } { i64 62, ptr @.d1079 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 255, { i64, ptr } { i64 3, ptr @.d1080 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReferenceNarrowedReturned(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 256, { i64, ptr } { i64 9, ptr @.d1081 }, { i64, ptr } { i64 158, ptr @.d1082 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnBorrowAsBuilt(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 436, { i64, ptr } { i64 3, ptr @.d1083 }, { i64, ptr } { i64 86, ptr @.d1084 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnCount(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } { i64 22, ptr @.d1085 }, 1
  %t5 = extractvalue { i64, ptr } { i64 22, ptr @.d1085 }, 0
  %t7 = call i64 @__olang_fmt_i64(ptr null, i64 %a0)
  %t8 = add i64 %t5, %t7
  %t9 = extractvalue { i64, ptr } { i64 6, ptr @.d1086 }, 1
  %t10 = extractvalue { i64, ptr } { i64 6, ptr @.d1086 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 8, ptr @.d1087 }, 1
  %t17 = extractvalue { i64, ptr } { i64 8, ptr @.d1087 }, 0
  %t18 = add i64 %t15, %t17
  %t20 = call i64 @__olang_fmt_i64(ptr null, i64 %a2)
  %t21 = add i64 %t18, %t20
  %t22 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t21)
  call void @olang_textcopy(ptr %t22, ptr %t4, i64 %t5)
  %t23 = getelementptr i8, ptr %t22, i64 %t5
  %t24 = call i64 @__olang_fmt_i64(ptr %t23, i64 %a0)
  %t25 = getelementptr i8, ptr %t23, i64 %t7
  call void @olang_textcopy(ptr %t25, ptr %t9, i64 %t10)
  %t26 = getelementptr i8, ptr %t25, i64 %t10
  call void @olang_textcopy(ptr %t26, ptr %t13, i64 %t14)
  %t27 = getelementptr i8, ptr %t26, i64 %t14
  call void @olang_textcopy(ptr %t27, ptr %t16, i64 %t17)
  %t28 = getelementptr i8, ptr %t27, i64 %t17
  %t29 = call i64 @__olang_fmt_i64(ptr %t28, i64 %a2)
  %t30 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t22, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t41 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 439, { i64, ptr } { i64 3, ptr @.d1088 }, { i64, ptr } %t38)
  store %"compiler/msgs:Msg" %t41, ptr %l9
  br label %bb1
bb1:
  %t42 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t42, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnInCtor(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 440, { i64, ptr } { i64 3, ptr @.d1089 }, { i64, ptr } { i64 77, ptr @.d1090 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnInNoreturn(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 442, { i64, ptr } { i64 3, ptr @.d1091 }, { i64, ptr } { i64 89, ptr @.d1092 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnInTest(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 441, { i64, ptr } { i64 3, ptr @.d1093 }, { i64, ptr } { i64 56, ptr @.d1094 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnNeedsValue(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 22, ptr @.d1095 }, 1
  %t3 = extractvalue { i64, ptr } { i64 22, ptr @.d1095 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 27, ptr @.d1096 }, 1
  %t9 = extractvalue { i64, ptr } { i64 27, ptr @.d1096 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 448, { i64, ptr } { i64 2, ptr @.d1097 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnOwnStorage(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 437, { i64, ptr } { i64 3, ptr @.d1098 }, { i64, ptr } { i64 98, ptr @.d1099 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnScopeNone(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 126, { i64, ptr } { i64 3, ptr @.d1100 }, { i64, ptr } { i64 60, ptr @.d1101 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnTypeMismatch(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 22, ptr @.d1102 }, 1
  %t4 = extractvalue { i64, ptr } { i64 22, ptr @.d1102 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 8, ptr @.d1103 }, 1
  %t10 = extractvalue { i64, ptr } { i64 8, ptr @.d1103 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t3, i64 %t4)
  %t17 = getelementptr i8, ptr %t16, i64 %t4
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t9, i64 %t10)
  %t19 = getelementptr i8, ptr %t18, i64 %t10
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 243, { i64, ptr } { i64 2, ptr @.d1104 }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnValueInVoid(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 447, { i64, ptr } { i64 2, ptr @.d1105 }, { i64, ptr } { i64 30, ptr @.d1106 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eScopeArgCount(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 321, { i64, ptr } { i64 3, ptr @.d1107 }, { i64, ptr } { i64 39, ptr @.d1108 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eScopeArgNotAccepted(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 46, ptr @.d1109 }, 1
  %t6 = extractvalue { i64, ptr } { i64 46, ptr @.d1109 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 247, { i64, ptr } { i64 3, ptr @.d1110 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eScopeArgProgram(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 100, ptr @.d1111 }, 1
  %t6 = extractvalue { i64, ptr } { i64 100, ptr @.d1111 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 237, { i64, ptr } { i64 8, ptr @.d1112 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eScopeArgUnknown(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 81, ptr @.d1113 }, 1
  %t6 = extractvalue { i64, ptr } { i64 81, ptr @.d1113 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 242, { i64, ptr } { i64 3, ptr @.d1114 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eScopeArgsDisagree(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 248, { i64, ptr } { i64 4, ptr @.d1115 }, { i64, ptr } { i64 79, ptr @.d1116 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eScopeDecl(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 160, { i64, ptr } { i64 2, ptr @.d1117 }, { i64, ptr } { i64 78, ptr @.d1118 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eScopeMayNotOutlive(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 208, { i64, ptr } { i64 3, ptr @.d1119 }, { i64, ptr } { i64 68, ptr @.d1120 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eScopeObligationUnmet(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 253, { i64, ptr } { i64 4, ptr @.d1121 }, { i64, ptr } { i64 112, ptr @.d1122 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSemicolon(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 49, { i64, ptr } { i64 3, ptr @.d1123 }, { i64, ptr } { i64 94, ptr @.d1124 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSetatResult(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 178, { i64, ptr } { i64 3, ptr @.d1125 }, { i64, ptr } { i64 21, ptr @.d1126 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSetatUndeclared(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 48, ptr @.d1127 }, 1
  %t6 = extractvalue { i64, ptr } { i64 48, ptr @.d1127 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 346, { i64, ptr } { i64 3, ptr @.d1128 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eShadowsBuildConst(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 42, ptr @.d1129 }, 1
  %t6 = extractvalue { i64, ptr } { i64 42, ptr @.d1129 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 200, { i64, ptr } { i64 3, ptr @.d1130 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eShadowsFunction(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 83, ptr @.d1131 }, 1
  %t6 = extractvalue { i64, ptr } { i64 83, ptr @.d1131 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 199, { i64, ptr } { i64 3, ptr @.d1132 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eShadowsGlobal(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 66, ptr @.d1133 }, 1
  %t6 = extractvalue { i64, ptr } { i64 66, ptr @.d1133 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 198, { i64, ptr } { i64 3, ptr @.d1134 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eShadowsType(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 34, ptr @.d1135 }, 1
  %t6 = extractvalue { i64, ptr } { i64 34, ptr @.d1135 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 202, { i64, ptr } { i64 3, ptr @.d1136 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eShiftOutOfRange(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } { i64 9, ptr @.d1137 }, 1
  %t5 = extractvalue { i64, ptr } { i64 9, ptr @.d1137 }, 0
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 4, ptr @.d1138 }, 1
  %t11 = extractvalue { i64, ptr } { i64 4, ptr @.d1138 }, 0
  %t12 = add i64 %t9, %t11
  %t14 = call i64 @__olang_fmt_i64(ptr null, i64 %a1)
  %t15 = add i64 %t12, %t14
  %t16 = extractvalue { i64, ptr } { i64 25, ptr @.d1139 }, 1
  %t17 = extractvalue { i64, ptr } { i64 25, ptr @.d1139 }, 0
  %t18 = add i64 %t15, %t17
  %t20 = call i64 @__olang_fmt_i64(ptr null, i64 %a2)
  %t21 = add i64 %t18, %t20
  %t22 = extractvalue { i64, ptr } { i64 5, ptr @.d1140 }, 1
  %t23 = extractvalue { i64, ptr } { i64 5, ptr @.d1140 }, 0
  %t24 = add i64 %t21, %t23
  %t25 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t24)
  call void @olang_textcopy(ptr %t25, ptr %t4, i64 %t5)
  %t26 = getelementptr i8, ptr %t25, i64 %t5
  call void @olang_textcopy(ptr %t26, ptr %t7, i64 %t8)
  %t27 = getelementptr i8, ptr %t26, i64 %t8
  call void @olang_textcopy(ptr %t27, ptr %t10, i64 %t11)
  %t28 = getelementptr i8, ptr %t27, i64 %t11
  %t29 = call i64 @__olang_fmt_i64(ptr %t28, i64 %a1)
  %t30 = getelementptr i8, ptr %t28, i64 %t14
  call void @olang_textcopy(ptr %t30, ptr %t16, i64 %t17)
  %t31 = getelementptr i8, ptr %t30, i64 %t17
  %t32 = call i64 @__olang_fmt_i64(ptr %t31, i64 %a2)
  %t33 = getelementptr i8, ptr %t31, i64 %t20
  call void @olang_textcopy(ptr %t33, ptr %t22, i64 %t23)
  %t34 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t25, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = extractvalue { i64, ptr } %t35, 1
  %t39 = mul i64 %t37, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t39)
  call void @llvm.memcpy.p0.p0.i64(ptr %t40, ptr %t38, i64 %t39, i1 false)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  %t45 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 313, { i64, ptr } { i64 3, ptr @.d1141 }, { i64, ptr } %t42)
  store %"compiler/msgs:Msg" %t45, ptr %l9
  br label %bb1
bb1:
  %t46 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t46, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eShiftUnadapted(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 207, { i64, ptr } { i64 8, ptr @.d1142 }, { i64, ptr } { i64 116, ptr @.d1143 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSliceBoundNotInt(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 37, ptr @.d1144 }, 1
  %t3 = extractvalue { i64, ptr } { i64 37, ptr @.d1144 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 273, { i64, ptr } { i64 4, ptr @.d1145 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSliceNeedsLen(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 39, ptr @.d1146 }, 1
  %t3 = extractvalue { i64, ptr } { i64 39, ptr @.d1146 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 9, ptr @.d1147 }, 1
  %t9 = extractvalue { i64, ptr } { i64 9, ptr @.d1147 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 344, { i64, ptr } { i64 3, ptr @.d1148 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSliceSplitValue(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 250, { i64, ptr } { i64 4, ptr @.d1149 }, { i64, ptr } { i64 143, ptr @.d1150 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnArgHoldsShort(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 474, { i64, ptr } { i64 2, ptr @.d1151 }, { i64, ptr } { i64 108, ptr @.d1152 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnArgTooShort(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 473, { i64, ptr } { i64 2, ptr @.d1153 }, { i64, ptr } { i64 93, ptr @.d1154 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnAtElement(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 459, { i64, ptr } { i64 8, ptr @.d1155 }, { i64, ptr } { i64 173, ptr @.d1156 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnCaptureTooShort(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 475, { i64, ptr } { i64 8, ptr @.d1157 }, { i64, ptr } { i64 93, ptr @.d1158 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnFallible(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 461, { i64, ptr } { i64 2, ptr @.d1159 }, { i64, ptr } { i64 89, ptr @.d1160 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnFuncTooShort(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 476, { i64, ptr } { i64 8, ptr @.d1161 }, { i64, ptr } { i64 93, ptr @.d1162 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnInDefer(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 457, { i64, ptr } { i64 9, ptr @.d1163 }, { i64, ptr } { i64 66, ptr @.d1164 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnLambdaParams(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 456, { i64, ptr } { i64 4, ptr @.d1165 }, { i64, ptr } { i64 64, ptr @.d1166 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnNotCall(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 460, { i64, ptr } { i64 2, ptr @.d1167 }, { i64, ptr } { i64 20, ptr @.d1168 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnOutsideJoin(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 458, { i64, ptr } { i64 2, ptr @.d1169 }, { i64, ptr } { i64 66, ptr @.d1170 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnResultAsRef(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l11 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } { i64 43, ptr @.d1171 }, 1
  %t6 = extractvalue { i64, ptr } { i64 43, ptr @.d1171 }, 0
  %t8 = extractvalue { i64, ptr } %a0, 1
  %t9 = extractvalue { i64, ptr } %a0, 0
  %t10 = add i64 %t6, %t9
  %t11 = extractvalue { i64, ptr } { i64 8, ptr @.d1172 }, 1
  %t12 = extractvalue { i64, ptr } { i64 8, ptr @.d1172 }, 0
  %t13 = add i64 %t10, %t12
  %t15 = extractvalue { i64, ptr } %a1, 1
  %t16 = extractvalue { i64, ptr } %a1, 0
  %t17 = add i64 %t13, %t16
  %t18 = extractvalue { i64, ptr } { i64 12, ptr @.d1173 }, 1
  %t19 = extractvalue { i64, ptr } { i64 12, ptr @.d1173 }, 0
  %t20 = add i64 %t17, %t19
  %t22 = extractvalue { i64, ptr } %a2, 1
  %t23 = extractvalue { i64, ptr } %a2, 0
  %t24 = add i64 %t20, %t23
  %t25 = extractvalue { i64, ptr } { i64 10, ptr @.d1174 }, 1
  %t26 = extractvalue { i64, ptr } { i64 10, ptr @.d1174 }, 0
  %t27 = add i64 %t24, %t26
  %t29 = extractvalue { i64, ptr } %a3, 1
  %t30 = extractvalue { i64, ptr } %a3, 0
  %t31 = add i64 %t27, %t30
  %t32 = extractvalue { i64, ptr } { i64 30, ptr @.d1175 }, 1
  %t33 = extractvalue { i64, ptr } { i64 30, ptr @.d1175 }, 0
  %t34 = add i64 %t31, %t33
  %t35 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t34)
  call void @olang_textcopy(ptr %t35, ptr %t5, i64 %t6)
  %t36 = getelementptr i8, ptr %t35, i64 %t6
  call void @olang_textcopy(ptr %t36, ptr %t8, i64 %t9)
  %t37 = getelementptr i8, ptr %t36, i64 %t9
  call void @olang_textcopy(ptr %t37, ptr %t11, i64 %t12)
  %t38 = getelementptr i8, ptr %t37, i64 %t12
  call void @olang_textcopy(ptr %t38, ptr %t15, i64 %t16)
  %t39 = getelementptr i8, ptr %t38, i64 %t16
  call void @olang_textcopy(ptr %t39, ptr %t18, i64 %t19)
  %t40 = getelementptr i8, ptr %t39, i64 %t19
  call void @olang_textcopy(ptr %t40, ptr %t22, i64 %t23)
  %t41 = getelementptr i8, ptr %t40, i64 %t23
  call void @olang_textcopy(ptr %t41, ptr %t25, i64 %t26)
  %t42 = getelementptr i8, ptr %t41, i64 %t26
  call void @olang_textcopy(ptr %t42, ptr %t29, i64 %t30)
  %t43 = getelementptr i8, ptr %t42, i64 %t30
  call void @olang_textcopy(ptr %t43, ptr %t32, i64 %t33)
  %t44 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t35, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = extractvalue { i64, ptr } %t45, 1
  %t49 = mul i64 %t47, 1
  %t50 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t49)
  call void @llvm.memcpy.p0.p0.i64(ptr %t50, ptr %t48, i64 %t49, i1 false)
  %t51 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  %t55 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, i32 479, { i64, ptr } { i64 3, ptr @.d1176 }, { i64, ptr } %t52)
  store %"compiler/msgs:Msg" %t55, ptr %l11
  br label %bb1
bb1:
  %t56 = load %"compiler/msgs:Msg", ptr %l11
  store %"compiler/msgs:Msg" %t56, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnResultTooShort(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 480, { i64, ptr } { i64 3, ptr @.d1177 }, { i64, ptr } { i64 81, ptr @.d1178 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnResultType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 43, ptr @.d1179 }, 1
  %t4 = extractvalue { i64, ptr } { i64 43, ptr @.d1179 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 8, ptr @.d1180 }, 1
  %t10 = extractvalue { i64, ptr } { i64 8, ptr @.d1180 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 25, ptr @.d1181 }, 1
  %t17 = extractvalue { i64, ptr } { i64 25, ptr @.d1181 }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 478, { i64, ptr } { i64 3, ptr @.d1182 }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnResultVoid(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 477, { i64, ptr } { i64 3, ptr @.d1183 }, { i64, ptr } { i64 51, ptr @.d1184 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnResultsDisagree(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 481, { i64, ptr } { i64 3, ptr @.d1185 }, { i64, ptr } { i64 72, ptr @.d1186 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnTryInfallible(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 462, { i64, ptr } { i64 2, ptr @.d1187 }, { i64, ptr } { i64 38, ptr @.d1188 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpreadCount(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 246, { i64, ptr } { i64 3, ptr @.d1189 }, { i64, ptr } { i64 107, ptr @.d1190 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eStoreIntoUnknownScope(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 239, { i64, ptr } { i64 3, ptr @.d1191 }, { i64, ptr } { i64 146, ptr @.d1192 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eStoredRefOutlived(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 390, { i64, ptr } { i64 3, ptr @.d1193 }, { i64, ptr } { i64 101, ptr @.d1194 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eStrOfNothing(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 304, { i64, ptr } { i64 4, ptr @.d1195 }, { i64, ptr } { i64 54, ptr @.d1196 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eStrReceiverWritable(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 284, { i64, ptr } { i64 10, ptr @.d1197 }, { i64, ptr } { i64 98, ptr @.d1198 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eStrShape(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 185, { i64, ptr } { i64 4, ptr @.d1199 }, { i64, ptr } { i64 18, ptr @.d1200 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eStrStoresInReceiver(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 283, { i64, ptr } { i64 9, ptr @.d1201 }, { i64, ptr } { i64 148, ptr @.d1202 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eStringNewline(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 55, { i64, ptr } { i64 3, ptr @.d1203 }, { i64, ptr } { i64 62, ptr @.d1204 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTagUnknownScope(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 6, ptr @.d1205 }, 1
  %t4 = extractvalue { i64, ptr } { i64 6, ptr @.d1205 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 81, ptr @.d1206 }, 1
  %t10 = extractvalue { i64, ptr } { i64 81, ptr @.d1206 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 32, ptr @.d1207 }, 1
  %t17 = extractvalue { i64, ptr } { i64 32, ptr @.d1207 }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 240, { i64, ptr } { i64 3, ptr @.d1208 }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTakesNoArgs(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 19, ptr @.d1209 }, 1
  %t6 = extractvalue { i64, ptr } { i64 19, ptr @.d1209 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 379, { i64, ptr } { i64 3, ptr @.d1210 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetForeignMode(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 47, ptr @.d1211 }, 1
  %t7 = extractvalue { i64, ptr } { i64 47, ptr @.d1211 }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 64, ptr @.d1212 }, 1
  %t14 = extractvalue { i64, ptr } { i64 64, ptr @.d1212 }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 21, { i64, ptr } { i64 4, ptr @.d1213 }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetMissing(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 17, { i64, ptr } { i64 3, ptr @.d1214 }, { i64, ptr } { i64 55, ptr @.d1215 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetNativeForeign(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 9, ptr @.d1216 }, 1
  %t3 = extractvalue { i64, ptr } { i64 9, ptr @.d1216 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 102, ptr @.d1217 }, 1
  %t9 = extractvalue { i64, ptr } { i64 102, ptr @.d1217 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 20, { i64, ptr } { i64 3, ptr @.d1218 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetNoBackend(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 29, ptr @.d1219 }, 1
  %t3 = extractvalue { i64, ptr } { i64 29, ptr @.d1219 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 85, ptr @.d1220 }, 1
  %t9 = extractvalue { i64, ptr } { i64 85, ptr @.d1220 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 22, { i64, ptr } { i64 4, ptr @.d1221 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetNoClang(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 84, ptr @.d1222 }, 1
  %t3 = extractvalue { i64, ptr } { i64 84, ptr @.d1222 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 4, ptr @.d1223 }, 1
  %t9 = extractvalue { i64, ptr } { i64 4, ptr @.d1223 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 23, { i64, ptr } { i64 3, ptr @.d1224 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetUnknown(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 16, ptr @.d1225 }, 1
  %t3 = extractvalue { i64, ptr } { i64 16, ptr @.d1225 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 187, ptr @.d1226 }, 1
  %t9 = extractvalue { i64, ptr } { i64 187, ptr @.d1226 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 18, { i64, ptr } { i64 3, ptr @.d1227 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetUnsupported(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 26, ptr @.d1228 }, 1
  %t3 = extractvalue { i64, ptr } { i64 26, ptr @.d1228 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 65, ptr @.d1229 }, 1
  %t9 = extractvalue { i64, ptr } { i64 65, ptr @.d1229 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 19, { i64, ptr } { i64 3, ptr @.d1230 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskClauseError(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 465, { i64, ptr } { i64 3, ptr @.d1231 }, { i64, ptr } { i64 106, ptr @.d1232 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskClauseLoopJump(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 81, ptr @.d1233 }, 1
  %t6 = extractvalue { i64, ptr } { i64 81, ptr @.d1233 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 464, { i64, ptr } { i64 3, ptr @.d1234 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskClauseNeedsDefault(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 466, { i64, ptr } { i64 3, ptr @.d1235 }, { i64, ptr } { i64 107, ptr @.d1236 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskClauseReturns(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 463, { i64, ptr } { i64 3, ptr @.d1237 }, { i64, ptr } { i64 82, ptr @.d1238 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskDefaultExisting(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 468, { i64, ptr } { i64 3, ptr @.d1239 }, { i64, ptr } { i64 118, ptr @.d1240 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskDefaultInStatement(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 467, { i64, ptr } { i64 3, ptr @.d1241 }, { i64, ptr } { i64 70, ptr @.d1242 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 39)
  br label %bb2
bb2:
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb5:
  br label %bb6
bb6:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l15, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr i8, ptr %t22, i64 %t19
  %t24 = load i8, ptr %t23, !tbaa !32
  store ptr %l1, ptr %l18, !tbaa !29
  %t28 = call { i64, ptr } @compiler_2fmsgs_2eEsc(ptr %s2, i8 %t24)
  store { i64, ptr } %t28, ptr %l20
  br label %bb7
bb7:
  %t29 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 0
  %t31 = extractvalue { i64, ptr } %t29, 1
  %t32 = mul i64 %t30, 1
  %t33 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t32)
  call void @llvm.memcpy.p0.p0.i64(ptr %t33, ptr %t31, i64 %t32, i1 false)
  %t34 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t33, 1
  %t36 = load ptr, ptr %l18, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t36, { i64, ptr } %t35)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb9:
  %t38 = load i64, ptr %l3, !tbaa !24
  %t40 = add i64 %t38, 1
  store i64 %t40, ptr %l3, !tbaa !24
  br label %bb3
bb10:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 39)
  br label %bb11
bb11:
  %t44 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t44, ptr %l26
  br label %bb12
bb12:
  %t45 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t45, ptr %l27, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 0
  store i64 %t47, ptr %l28, !tbaa !24
  %t48 = load i64, ptr %l28, !tbaa !24
  %t49 = mul i64 %t48, 1
  %t50 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t49)
  %t51 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  store { i64, ptr } %t52, ptr %l29, !tbaa !27
  %t53 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = load i64, ptr %l28, !tbaa !24
  %t58 = mul i64 %t57, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t54, ptr %t56, i64 %t58, i1 false)
  %t59 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t59, ptr %l27, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t60 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t60, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTrailingComma(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 15, ptr @.d1243 }, 1
  %t3 = extractvalue { i64, ptr } { i64 15, ptr @.d1243 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 30, ptr @.d1244 }, 1
  %t9 = extractvalue { i64, ptr } { i64 30, ptr @.d1244 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 75, { i64, ptr } { i64 4, ptr @.d1245 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTraitErrsUnwritten(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 114, { i64, ptr } { i64 3, ptr @.d1246 }, { i64, ptr } { i64 83, ptr @.d1247 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTraitMethodGeneric(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 13, ptr @.d1248 }, 1
  %t3 = extractvalue { i64, ptr } { i64 13, ptr @.d1248 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 40, ptr @.d1249 }, 1
  %t9 = extractvalue { i64, ptr } { i64 40, ptr @.d1249 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 156, { i64, ptr } { i64 3, ptr @.d1250 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTraitNotAType(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 72, ptr @.d1251 }, 1
  %t6 = extractvalue { i64, ptr } { i64 72, ptr @.d1251 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 152, { i64, ptr } { i64 3, ptr @.d1252 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTryCatchOnSlice(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 495, { i64, ptr } { i64 3, ptr @.d1253 }, { i64, ptr } { i64 114, ptr @.d1254 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTryErrorNotDeclared(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 87, ptr @.d1255 }, 1
  %t6 = extractvalue { i64, ptr } { i64 87, ptr @.d1255 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 354, { i64, ptr } { i64 2, ptr @.d1256 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTryIndexNeedsLen(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 39, ptr @.d1257 }, 1
  %t3 = extractvalue { i64, ptr } { i64 39, ptr @.d1257 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 30, ptr @.d1258 }, 1
  %t9 = extractvalue { i64, ptr } { i64 30, ptr @.d1258 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 342, { i64, ptr } { i64 4, ptr @.d1259 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTryMultiIndexNeedsTryat(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 35, ptr @.d1260 }, 1
  %t4 = extractvalue { i64, ptr } { i64 35, ptr @.d1260 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 12, ptr @.d1261 }, 1
  %t10 = extractvalue { i64, ptr } { i64 12, ptr @.d1261 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 47, ptr @.d1262 }, 1
  %t17 = extractvalue { i64, ptr } { i64 47, ptr @.d1262 }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 175, { i64, ptr } { i64 4, ptr @.d1263 }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTryNothingFails(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 42, ptr @.d1264 }, 1
  %t3 = extractvalue { i64, ptr } { i64 42, ptr @.d1264 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 1, ptr @.d1265 }, 1
  %t9 = extractvalue { i64, ptr } { i64 1, ptr @.d1265 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 370, { i64, ptr } { i64 2, ptr @.d1266 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTryNowhereToGo(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 353, { i64, ptr } { i64 3, ptr @.d1267 }, { i64, ptr } { i64 65, ptr @.d1268 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTryOnlyChecks(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 372, { i64, ptr } { i64 4, ptr @.d1269 }, { i64, ptr } { i64 59, ptr @.d1270 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTrySetatNeedsLen(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 43, ptr @.d1271 }, 1
  %t3 = extractvalue { i64, ptr } { i64 43, ptr @.d1271 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 33, ptr @.d1272 }, 1
  %t9 = extractvalue { i64, ptr } { i64 33, ptr @.d1272 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 402, { i64, ptr } { i64 4, ptr @.d1273 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTrySliceNeedsLen(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 43, ptr @.d1274 }, 1
  %t3 = extractvalue { i64, ptr } { i64 43, ptr @.d1274 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 33, ptr @.d1275 }, 1
  %t9 = extractvalue { i64, ptr } { i64 33, ptr @.d1275 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 343, { i64, ptr } { i64 4, ptr @.d1276 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTupleNotAValue(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 310, { i64, ptr } { i64 3, ptr @.d1277 }, { i64, ptr } { i64 111, ptr @.d1278 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTwoPoints(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 67, { i64, ptr } { i64 3, ptr @.d1279 }, { i64, ptr } { i64 38, ptr @.d1280 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgCount(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } { i64 19, ptr @.d1281 }, 1
  %t5 = extractvalue { i64, ptr } { i64 19, ptr @.d1281 }, 0
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 11, ptr @.d1282 }, 1
  %t11 = extractvalue { i64, ptr } { i64 11, ptr @.d1282 }, 0
  %t12 = add i64 %t9, %t11
  %t14 = call i64 @__olang_fmt_i64(ptr null, i64 %a1)
  %t15 = add i64 %t12, %t14
  %t16 = extractvalue { i64, ptr } { i64 8, ptr @.d1283 }, 1
  %t17 = extractvalue { i64, ptr } { i64 8, ptr @.d1283 }, 0
  %t18 = add i64 %t15, %t17
  %t20 = call i64 @__olang_fmt_i64(ptr null, i64 %a2)
  %t21 = add i64 %t18, %t20
  %t22 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t21)
  call void @olang_textcopy(ptr %t22, ptr %t4, i64 %t5)
  %t23 = getelementptr i8, ptr %t22, i64 %t5
  call void @olang_textcopy(ptr %t23, ptr %t7, i64 %t8)
  %t24 = getelementptr i8, ptr %t23, i64 %t8
  call void @olang_textcopy(ptr %t24, ptr %t10, i64 %t11)
  %t25 = getelementptr i8, ptr %t24, i64 %t11
  %t26 = call i64 @__olang_fmt_i64(ptr %t25, i64 %a1)
  %t27 = getelementptr i8, ptr %t25, i64 %t14
  call void @olang_textcopy(ptr %t27, ptr %t16, i64 %t17)
  %t28 = getelementptr i8, ptr %t27, i64 %t17
  %t29 = call i64 @__olang_fmt_i64(ptr %t28, i64 %a2)
  %t30 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t22, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t41 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 136, { i64, ptr } { i64 2, ptr @.d1284 }, { i64, ptr } %t38)
  store %"compiler/msgs:Msg" %t41, ptr %l9
  br label %bb1
bb1:
  %t42 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t42, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgNamedScope(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 148, { i64, ptr } { i64 3, ptr @.d1285 }, { i64, ptr } { i64 101, ptr @.d1286 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgsNotInferable(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 22, ptr @.d1287 }, 1
  %t3 = extractvalue { i64, ptr } { i64 22, ptr @.d1287 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 40, ptr @.d1288 }, 1
  %t9 = extractvalue { i64, ptr } { i64 40, ptr @.d1288 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 258, { i64, ptr } { i64 2, ptr @.d1289 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgsOnNonGeneric(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 46, ptr @.d1290 }, 1
  %t6 = extractvalue { i64, ptr } { i64 46, ptr @.d1290 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 137, { i64, ptr } { i64 2, ptr @.d1291 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeDefinedThroughItself(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 41, ptr @.d1292 }, 1
  %t6 = extractvalue { i64, ptr } { i64 41, ptr @.d1292 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 169, { i64, ptr } { i64 0, ptr @.d1293 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeHasNoConstructor(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 5, ptr @.d1294 }, 1
  %t3 = extractvalue { i64, ptr } { i64 5, ptr @.d1294 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 52, ptr @.d1295 }, 1
  %t9 = extractvalue { i64, ptr } { i64 52, ptr @.d1295 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 203, { i64, ptr } { i64 0, ptr @.d1296 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeHoldsItself(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 64, ptr @.d1297 }, 1
  %t6 = extractvalue { i64, ptr } { i64 64, ptr @.d1297 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 133, { i64, ptr } { i64 3, ptr @.d1298 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeIsPrivate(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 5, ptr @.d1299 }, 1
  %t3 = extractvalue { i64, ptr } { i64 5, ptr @.d1299 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 25, ptr @.d1300 }, 1
  %t9 = extractvalue { i64, ptr } { i64 25, ptr @.d1300 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 115, { i64, ptr } { i64 2, ptr @.d1301 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeMatchGuard(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 425, { i64, ptr } { i64 4, ptr @.d1302 }, { i64, ptr } { i64 100, ptr @.d1303 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeMatchUncovered(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 15, ptr @.d1304 }, 1
  %t3 = extractvalue { i64, ptr } { i64 15, ptr @.d1304 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 65, ptr @.d1305 }, 1
  %t9 = extractvalue { i64, ptr } { i64 65, ptr @.d1305 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 426, { i64, ptr } { i64 3, ptr @.d1306 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeMatchValueCase(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 43, ptr @.d1307 }, 1
  %t6 = extractvalue { i64, ptr } { i64 43, ptr @.d1307 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 142, { i64, ptr } { i64 3, ptr @.d1308 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeMismatch(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 9, ptr @.d1309 }, 1
  %t4 = extractvalue { i64, ptr } { i64 9, ptr @.d1309 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 8, ptr @.d1310 }, 1
  %t10 = extractvalue { i64, ptr } { i64 8, ptr @.d1310 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t3, i64 %t4)
  %t17 = getelementptr i8, ptr %t16, i64 %t4
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t9, i64 %t10)
  %t19 = getelementptr i8, ptr %t18, i64 %t10
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 215, { i64, ptr } { i64 3, ptr @.d1311 }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeNameInUse(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 5, ptr @.d1312 }, 1
  %t3 = extractvalue { i64, ptr } { i64 5, ptr @.d1312 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 35, ptr @.d1313 }, 1
  %t9 = extractvalue { i64, ptr } { i64 35, ptr @.d1313 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 116, { i64, ptr } { i64 2, ptr @.d1314 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeNotAValue(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 23, ptr @.d1315 }, 1
  %t6 = extractvalue { i64, ptr } { i64 23, ptr @.d1315 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 109, { i64, ptr } { i64 0, ptr @.d1316 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeNotInferable(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 235, { i64, ptr } { i64 3, ptr @.d1317 }, { i64, ptr } { i64 79, ptr @.d1318 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeVarAsValue(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 32, ptr @.d1319 }, 1
  %t6 = extractvalue { i64, ptr } { i64 32, ptr @.d1319 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 138, { i64, ptr } { i64 3, ptr @.d1320 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeVarNamesType(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 14, ptr @.d1321 }, 1
  %t3 = extractvalue { i64, ptr } { i64 14, ptr @.d1321 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 60, ptr @.d1322 }, 1
  %t9 = extractvalue { i64, ptr } { i64 60, ptr @.d1322 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 161, { i64, ptr } { i64 2, ptr @.d1323 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeVarNotInferable(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 14, ptr @.d1324 }, 1
  %t3 = extractvalue { i64, ptr } { i64 14, ptr @.d1324 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 93, ptr @.d1325 }, 1
  %t9 = extractvalue { i64, ptr } { i64 93, ptr @.d1325 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 162, { i64, ptr } { i64 2, ptr @.d1326 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnboundedInstantiation(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 132, { i64, ptr } { i64 3, ptr @.d1327 }, { i64, ptr } { i64 72, ptr @.d1328 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnclosedChar(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 56, { i64, ptr } { i64 3, ptr @.d1329 }, { i64, ptr } { i64 30, ptr @.d1330 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnclosedComment(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 53, { i64, ptr } { i64 3, ptr @.d1331 }, { i64, ptr } { i64 43, ptr @.d1332 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnclosedString(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 54, { i64, ptr } { i64 3, ptr @.d1333 }, { i64, ptr } { i64 27, ptr @.d1334 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnderscoreDeclared(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 197, { i64, ptr } { i64 3, ptr @.d1335 }, { i64, ptr } { i64 64, ptr @.d1336 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnhandledFallibleCall(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 332, { i64, ptr } { i64 3, ptr @.d1337 }, { i64, ptr } { i64 65, ptr @.d1338 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownBuildName(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 13, ptr @.d1339 }, 1
  %t4 = extractvalue { i64, ptr } { i64 13, ptr @.d1339 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 54, ptr @.d1340 }, 1
  %t10 = extractvalue { i64, ptr } { i64 54, ptr @.d1340 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 37, ptr @.d1341 }, 1
  %t17 = extractvalue { i64, ptr } { i64 37, ptr @.d1341 }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 123, { i64, ptr } { i64 3, ptr @.d1342 }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownChar(ptr %v0, i8 %a0) #0 {
entry:
  %l1 = alloca i32
  %l3 = alloca { i64, ptr }
  %l6 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 47, ptr %l1
  %t3 = call { i64, ptr } @compiler_2fmsgs_2eEsc(ptr %s0, i8 %a0)
  store { i64, ptr } %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = extractvalue { i64, ptr } { i64 22, ptr @.d1343 }, 1
  %t5 = extractvalue { i64, ptr } { i64 22, ptr @.d1343 }, 0
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 1
  %t8 = extractvalue { i64, ptr } %t6, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 1, ptr @.d1344 }, 1
  %t11 = extractvalue { i64, ptr } { i64 1, ptr @.d1344 }, 0
  %t12 = add i64 %t9, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t7, i64 %t8)
  %t15 = getelementptr i8, ptr %t14, i64 %t8
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t25 = load i32, ptr %l1
  %t27 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t25, { i64, ptr } { i64 3, ptr @.d1345 }, { i64, ptr } %t24)
  store %"compiler/msgs:Msg" %t27, ptr %l6
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t28 = load %"compiler/msgs:Msg", ptr %l6
  store %"compiler/msgs:Msg" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownErrorType(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 19, ptr @.d1346 }, 1
  %t3 = extractvalue { i64, ptr } { i64 19, ptr @.d1346 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 112, { i64, ptr } { i64 2, ptr @.d1347 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownFlag(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 16, ptr @.d1348 }, 1
  %t4 = extractvalue { i64, ptr } { i64 16, ptr @.d1348 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 38, ptr @.d1349 }, 1
  %t10 = extractvalue { i64, ptr } { i64 38, ptr @.d1349 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t3, i64 %t4)
  %t17 = getelementptr i8, ptr %t16, i64 %t4
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t9, i64 %t10)
  %t19 = getelementptr i8, ptr %t18, i64 %t10
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 4, { i64, ptr } { i64 2, ptr @.d1350 }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownFunction(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 25, ptr @.d1351 }, 1
  %t3 = extractvalue { i64, ptr } { i64 25, ptr @.d1351 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 110, { i64, ptr } { i64 0, ptr @.d1352 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownFunctionMeant(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 25, ptr @.d1353 }, 1
  %t4 = extractvalue { i64, ptr } { i64 25, ptr @.d1353 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 17, ptr @.d1354 }, 1
  %t10 = extractvalue { i64, ptr } { i64 17, ptr @.d1354 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 2, ptr @.d1355 }, 1
  %t17 = extractvalue { i64, ptr } { i64 2, ptr @.d1355 }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 111, { i64, ptr } { i64 0, ptr @.d1356 }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownImport(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 18, ptr @.d1357 }, 1
  %t6 = extractvalue { i64, ptr } { i64 18, ptr @.d1357 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 98, { i64, ptr } { i64 3, ptr @.d1358 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownImportStd(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 46, ptr @.d1359 }, 1
  %t7 = extractvalue { i64, ptr } { i64 46, ptr @.d1359 }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 2, ptr @.d1360 }, 1
  %t14 = extractvalue { i64, ptr } { i64 2, ptr @.d1360 }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 99, { i64, ptr } { i64 3, ptr @.d1361 }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownMethod(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 15, ptr @.d1362 }, 1
  %t7 = extractvalue { i64, ptr } { i64 15, ptr @.d1362 }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t6, i64 %t7)
  %t15 = getelementptr i8, ptr %t14, i64 %t7
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t27 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 355, { i64, ptr } { i64 3, ptr @.d1363 }, { i64, ptr } %t24)
  store %"compiler/msgs:Msg" %t27, ptr %l7
  br label %bb1
bb1:
  %t28 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownName(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 13, ptr @.d1364 }, 1
  %t3 = extractvalue { i64, ptr } { i64 13, ptr @.d1364 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 107, { i64, ptr } { i64 0, ptr @.d1365 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownNameMeant(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 13, ptr @.d1366 }, 1
  %t4 = extractvalue { i64, ptr } { i64 13, ptr @.d1366 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 17, ptr @.d1367 }, 1
  %t10 = extractvalue { i64, ptr } { i64 17, ptr @.d1367 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 2, ptr @.d1368 }, 1
  %t17 = extractvalue { i64, ptr } { i64 2, ptr @.d1368 }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 108, { i64, ptr } { i64 0, ptr @.d1369 }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownNumberType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 13, ptr @.d1370 }, 1
  %t4 = extractvalue { i64, ptr } { i64 13, ptr @.d1370 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 58, ptr @.d1371 }, 1
  %t10 = extractvalue { i64, ptr } { i64 58, ptr @.d1371 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 2, ptr @.d1372 }, 1
  %t17 = extractvalue { i64, ptr } { i64 2, ptr @.d1372 }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 106, { i64, ptr } { i64 2, ptr @.d1373 }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownScopeName(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 83, ptr @.d1374 }, 1
  %t6 = extractvalue { i64, ptr } { i64 83, ptr @.d1374 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 125, { i64, ptr } { i64 3, ptr @.d1375 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownType(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 13, ptr @.d1376 }, 1
  %t3 = extractvalue { i64, ptr } { i64 13, ptr @.d1376 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 104, { i64, ptr } { i64 0, ptr @.d1377 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownTypeMeant(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 13, ptr @.d1378 }, 1
  %t4 = extractvalue { i64, ptr } { i64 13, ptr @.d1378 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 17, ptr @.d1379 }, 1
  %t10 = extractvalue { i64, ptr } { i64 17, ptr @.d1379 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 2, ptr @.d1380 }, 1
  %t17 = extractvalue { i64, ptr } { i64 2, ptr @.d1380 }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 105, { i64, ptr } { i64 0, ptr @.d1381 }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownTypeVar(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 22, ptr @.d1382 }, 1
  %t3 = extractvalue { i64, ptr } { i64 22, ptr @.d1382 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 424, { i64, ptr } { i64 0, ptr @.d1383 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUsage(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 0, { i64, ptr } { i64 2, ptr @.d1384 }, { i64, ptr } { i64 105, ptr @.d1385 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eValueAfterEq(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l11 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } { i64 43, ptr @.d1386 }, 1
  %t6 = extractvalue { i64, ptr } { i64 43, ptr @.d1386 }, 0
  %t8 = extractvalue { i64, ptr } %a0, 1
  %t9 = extractvalue { i64, ptr } %a0, 0
  %t10 = add i64 %t6, %t9
  %t11 = extractvalue { i64, ptr } { i64 3, ptr @.d1387 }, 1
  %t12 = extractvalue { i64, ptr } { i64 3, ptr @.d1387 }, 0
  %t13 = add i64 %t10, %t12
  %t15 = extractvalue { i64, ptr } %a1, 1
  %t16 = extractvalue { i64, ptr } %a1, 0
  %t17 = add i64 %t13, %t16
  %t18 = extractvalue { i64, ptr } { i64 7, ptr @.d1388 }, 1
  %t19 = extractvalue { i64, ptr } { i64 7, ptr @.d1388 }, 0
  %t20 = add i64 %t17, %t19
  %t22 = extractvalue { i64, ptr } %a2, 1
  %t23 = extractvalue { i64, ptr } %a2, 0
  %t24 = add i64 %t20, %t23
  %t25 = extractvalue { i64, ptr } { i64 4, ptr @.d1389 }, 1
  %t26 = extractvalue { i64, ptr } { i64 4, ptr @.d1389 }, 0
  %t27 = add i64 %t24, %t26
  %t29 = extractvalue { i64, ptr } %a3, 1
  %t30 = extractvalue { i64, ptr } %a3, 0
  %t31 = add i64 %t27, %t30
  %t32 = extractvalue { i64, ptr } { i64 1, ptr @.d1390 }, 1
  %t33 = extractvalue { i64, ptr } { i64 1, ptr @.d1390 }, 0
  %t34 = add i64 %t31, %t33
  %t35 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t34)
  call void @olang_textcopy(ptr %t35, ptr %t5, i64 %t6)
  %t36 = getelementptr i8, ptr %t35, i64 %t6
  call void @olang_textcopy(ptr %t36, ptr %t8, i64 %t9)
  %t37 = getelementptr i8, ptr %t36, i64 %t9
  call void @olang_textcopy(ptr %t37, ptr %t11, i64 %t12)
  %t38 = getelementptr i8, ptr %t37, i64 %t12
  call void @olang_textcopy(ptr %t38, ptr %t15, i64 %t16)
  %t39 = getelementptr i8, ptr %t38, i64 %t16
  call void @olang_textcopy(ptr %t39, ptr %t18, i64 %t19)
  %t40 = getelementptr i8, ptr %t39, i64 %t19
  call void @olang_textcopy(ptr %t40, ptr %t22, i64 %t23)
  %t41 = getelementptr i8, ptr %t40, i64 %t23
  call void @olang_textcopy(ptr %t41, ptr %t25, i64 %t26)
  %t42 = getelementptr i8, ptr %t41, i64 %t26
  call void @olang_textcopy(ptr %t42, ptr %t29, i64 %t30)
  %t43 = getelementptr i8, ptr %t42, i64 %t30
  call void @olang_textcopy(ptr %t43, ptr %t32, i64 %t33)
  %t44 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t35, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = extractvalue { i64, ptr } %t45, 1
  %t49 = mul i64 %t47, 1
  %t50 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t49)
  call void @llvm.memcpy.p0.p0.i64(ptr %t50, ptr %t48, i64 %t49, i1 false)
  %t51 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  %t55 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, i32 79, { i64, ptr } { i64 3, ptr @.d1391 }, { i64, ptr } %t52)
  store %"compiler/msgs:Msg" %t55, ptr %l11
  br label %bb1
bb1:
  %t56 = load %"compiler/msgs:Msg", ptr %l11
  store %"compiler/msgs:Msg" %t56, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eValueRefsOutlived(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 398, { i64, ptr } { i64 4, ptr @.d1392 }, { i64, ptr } { i64 91, ptr @.d1393 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eVarIsPrivate(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 25, ptr @.d1394 }, 1
  %t6 = extractvalue { i64, ptr } { i64 25, ptr @.d1394 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 206, { i64, ptr } { i64 2, ptr @.d1395 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eVarListCount(ptr %v0, i64 %a0, i64 %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = call i64 @__olang_fmt_i64(ptr null, i64 %a0)
  %t5 = extractvalue { i64, ptr } { i64 34, ptr @.d1396 }, 1
  %t6 = extractvalue { i64, ptr } { i64 34, ptr @.d1396 }, 0
  %t7 = add i64 %t4, %t6
  %t9 = call i64 @__olang_fmt_i64(ptr null, i64 %a1)
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t10)
  %t12 = call i64 @__olang_fmt_i64(ptr %t11, i64 %a0)
  %t13 = getelementptr i8, ptr %t11, i64 %t4
  call void @olang_textcopy(ptr %t13, ptr %t5, i64 %t6)
  %t14 = getelementptr i8, ptr %t13, i64 %t6
  %t15 = call i64 @__olang_fmt_i64(ptr %t14, i64 %a1)
  %t16 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t11, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t27 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 77, { i64, ptr } { i64 4, ptr @.d1397 }, { i64, ptr } %t24)
  store %"compiler/msgs:Msg" %t27, ptr %l7
  br label %bb1
bb1:
  %t28 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eVecGrowsUnderTask(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 1, ptr @.d1398 }, 1
  %t4 = extractvalue { i64, ptr } { i64 1, ptr @.d1398 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 73, ptr @.d1399 }, 1
  %t10 = extractvalue { i64, ptr } { i64 73, ptr @.d1399 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 11, ptr @.d1400 }, 1
  %t17 = extractvalue { i64, ptr } { i64 11, ptr @.d1400 }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 512, { i64, ptr } { i64 4, ptr @.d1401 }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eVecHiddenViewStale(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 22, ptr @.d1402 }, 1
  %t4 = extractvalue { i64, ptr } { i64 22, ptr @.d1402 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 16, ptr @.d1403 }, 1
  %t10 = extractvalue { i64, ptr } { i64 16, ptr @.d1403 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 16, ptr @.d1404 }, 1
  %t17 = extractvalue { i64, ptr } { i64 16, ptr @.d1404 }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 510, { i64, ptr } { i64 4, ptr @.d1405 }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eVecViewGivenGrowing(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l11 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } { i64 14, ptr @.d1406 }, 1
  %t6 = extractvalue { i64, ptr } { i64 14, ptr @.d1406 }, 0
  %t8 = extractvalue { i64, ptr } %a0, 1
  %t9 = extractvalue { i64, ptr } %a0, 0
  %t10 = add i64 %t6, %t9
  %t11 = extractvalue { i64, ptr } { i64 14, ptr @.d1407 }, 1
  %t12 = extractvalue { i64, ptr } { i64 14, ptr @.d1407 }, 0
  %t13 = add i64 %t10, %t12
  %t15 = extractvalue { i64, ptr } %a1, 1
  %t16 = extractvalue { i64, ptr } %a1, 0
  %t17 = add i64 %t13, %t16
  %t18 = extractvalue { i64, ptr } { i64 18, ptr @.d1408 }, 1
  %t19 = extractvalue { i64, ptr } { i64 18, ptr @.d1408 }, 0
  %t20 = add i64 %t17, %t19
  %t22 = extractvalue { i64, ptr } %a2, 1
  %t23 = extractvalue { i64, ptr } %a2, 0
  %t24 = add i64 %t20, %t23
  %t25 = extractvalue { i64, ptr } { i64 30, ptr @.d1409 }, 1
  %t26 = extractvalue { i64, ptr } { i64 30, ptr @.d1409 }, 0
  %t27 = add i64 %t24, %t26
  %t29 = extractvalue { i64, ptr } %a3, 1
  %t30 = extractvalue { i64, ptr } %a3, 0
  %t31 = add i64 %t27, %t30
  %t32 = extractvalue { i64, ptr } { i64 11, ptr @.d1410 }, 1
  %t33 = extractvalue { i64, ptr } { i64 11, ptr @.d1410 }, 0
  %t34 = add i64 %t31, %t33
  %t35 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t34)
  call void @olang_textcopy(ptr %t35, ptr %t5, i64 %t6)
  %t36 = getelementptr i8, ptr %t35, i64 %t6
  call void @olang_textcopy(ptr %t36, ptr %t8, i64 %t9)
  %t37 = getelementptr i8, ptr %t36, i64 %t9
  call void @olang_textcopy(ptr %t37, ptr %t11, i64 %t12)
  %t38 = getelementptr i8, ptr %t37, i64 %t12
  call void @olang_textcopy(ptr %t38, ptr %t15, i64 %t16)
  %t39 = getelementptr i8, ptr %t38, i64 %t16
  call void @olang_textcopy(ptr %t39, ptr %t18, i64 %t19)
  %t40 = getelementptr i8, ptr %t39, i64 %t19
  call void @olang_textcopy(ptr %t40, ptr %t22, i64 %t23)
  %t41 = getelementptr i8, ptr %t40, i64 %t23
  call void @olang_textcopy(ptr %t41, ptr %t25, i64 %t26)
  %t42 = getelementptr i8, ptr %t41, i64 %t26
  call void @olang_textcopy(ptr %t42, ptr %t29, i64 %t30)
  %t43 = getelementptr i8, ptr %t42, i64 %t30
  call void @olang_textcopy(ptr %t43, ptr %t32, i64 %t33)
  %t44 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t35, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = extractvalue { i64, ptr } %t45, 1
  %t49 = mul i64 %t47, 1
  %t50 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t49)
  call void @llvm.memcpy.p0.p0.i64(ptr %t50, ptr %t48, i64 %t49, i1 false)
  %t51 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  %t55 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, i32 511, { i64, ptr } { i64 4, ptr @.d1411 }, { i64, ptr } %t52)
  store %"compiler/msgs:Msg" %t55, ptr %l11
  br label %bb1
bb1:
  %t56 = load %"compiler/msgs:Msg", ptr %l11
  store %"compiler/msgs:Msg" %t56, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eVecViewStale(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } { i64 1, ptr @.d1412 }, 1
  %t5 = extractvalue { i64, ptr } { i64 1, ptr @.d1412 }, 0
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 19, ptr @.d1413 }, 1
  %t11 = extractvalue { i64, ptr } { i64 19, ptr @.d1413 }, 0
  %t12 = add i64 %t9, %t11
  %t14 = extractvalue { i64, ptr } %a1, 1
  %t15 = extractvalue { i64, ptr } %a1, 0
  %t16 = add i64 %t12, %t15
  %t17 = extractvalue { i64, ptr } { i64 16, ptr @.d1414 }, 1
  %t18 = extractvalue { i64, ptr } { i64 16, ptr @.d1414 }, 0
  %t19 = add i64 %t16, %t18
  %t21 = extractvalue { i64, ptr } %a2, 1
  %t22 = extractvalue { i64, ptr } %a2, 0
  %t23 = add i64 %t19, %t22
  %t24 = extractvalue { i64, ptr } { i64 16, ptr @.d1415 }, 1
  %t25 = extractvalue { i64, ptr } { i64 16, ptr @.d1415 }, 0
  %t26 = add i64 %t23, %t25
  %t27 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t4, i64 %t5)
  %t28 = getelementptr i8, ptr %t27, i64 %t5
  call void @olang_textcopy(ptr %t28, ptr %t7, i64 %t8)
  %t29 = getelementptr i8, ptr %t28, i64 %t8
  call void @olang_textcopy(ptr %t29, ptr %t10, i64 %t11)
  %t30 = getelementptr i8, ptr %t29, i64 %t11
  call void @olang_textcopy(ptr %t30, ptr %t14, i64 %t15)
  %t31 = getelementptr i8, ptr %t30, i64 %t15
  call void @olang_textcopy(ptr %t31, ptr %t17, i64 %t18)
  %t32 = getelementptr i8, ptr %t31, i64 %t18
  call void @olang_textcopy(ptr %t32, ptr %t21, i64 %t22)
  %t33 = getelementptr i8, ptr %t32, i64 %t22
  call void @olang_textcopy(ptr %t33, ptr %t24, i64 %t25)
  %t34 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t27, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = extractvalue { i64, ptr } %t35, 1
  %t39 = mul i64 %t37, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t39)
  call void @llvm.memcpy.p0.p0.i64(ptr %t40, ptr %t38, i64 %t39, i1 false)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  %t45 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 509, { i64, ptr } { i64 4, ptr @.d1416 }, { i64, ptr } %t42)
  store %"compiler/msgs:Msg" %t45, ptr %l9
  br label %bb1
bb1:
  %t46 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t46, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eWildcardNotAlone(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 432, { i64, ptr } { i64 4, ptr @.d1417 }, { i64, ptr } { i64 61, ptr @.d1418 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eWriteIntoCallValue(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 281, { i64, ptr } { i64 3, ptr @.d1419 }, { i64, ptr } { i64 98, ptr @.d1420 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eWriteThroughAtBuilds(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 348, { i64, ptr } { i64 8, ptr @.d1421 }, { i64, ptr } { i64 171, ptr @.d1422 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eWriteThroughAtCall(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 350, { i64, ptr } { i64 4, ptr @.d1423 }, { i64, ptr } { i64 196, ptr @.d1424 })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eWriteThroughAtNoSetat(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 28, ptr @.d1425 }, 1
  %t3 = extractvalue { i64, ptr } { i64 28, ptr @.d1425 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 95, ptr @.d1426 }, 1
  %t9 = extractvalue { i64, ptr } { i64 95, ptr @.d1426 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 347, { i64, ptr } { i64 3, ptr @.d1427 }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eZeroValueShared(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 93, ptr @.d1428 }, 1
  %t6 = extractvalue { i64, ptr } { i64 93, ptr @.d1428 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 498, { i64, ptr } { i64 4, ptr @.d1429 }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/msgs:Msg" undef, i32 %a0, 0
  %t10 = insertvalue %"compiler/msgs:Msg" %t8, { i64, ptr } %a1, 1
  %t12 = insertvalue %"compiler/msgs:Msg" %t10, { i64, ptr } %a2, 2
  store %"compiler/msgs:Msg" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local void @olang_2einit_2ecompiler_2fmsgs() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fmsgs_2eEndOfLine_2einit()
  br label %bb1
bb1:
  call void @compiler_2fmsgs_2eEndOfFile_2einit()
  br label %bb2
bb2:
  br label %ret
ret:
  ret void
}

@.d0 = private constant [25 x i8] c" is already declared here"
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d1 = private constant [0 x i8] c""
@.d2 = private constant [13 x i8] c" is bound as "
@.d3 = private constant [43 x i8] c" by an earlier alternative - split the case"
@.d4 = private constant [4 x i8] c"S13c"
@.d5 = private constant [4 x i8] c"S13c"
@.d6 = private constant [86 x i8] c"every alternative binds the same names - bind it in each, write '_', or split the case"
@.d7 = private constant [9 x i8] c"expected "
declare i64 @__olang_fmt_i64(ptr, i64)
@.d8 = private constant [9 x i8] c" argument"
@.d9 = private constant [8 x i8] c", found "
@.d10 = private constant [3 x i8] c"E14"
@.d11 = private constant [9 x i8] c"expected "
@.d12 = private constant [4 x i8] c" to "
@.d13 = private constant [18 x i8] c" arguments, found "
@.d14 = private constant [3 x i8] c"E14"
@.d15 = private constant [78 x i8] c" takes its array by value, so its length must be known while compiling - this "
@.d16 = private constant [42 x i8] c"'s is known only at run time: take it as '"
@.d17 = private constant [48 x i8] c"&', or pass a slice of a known length ('x[0:4]')"
@.d18 = private constant [3 x i8] c"D9a"
@.d19 = private constant [39 x i8] c"an array's length is an integer, found "
@.d20 = private constant [4 x i8] c"E13a"
@.d21 = private constant [73 x i8] c"an array's length is from 0 to the largest whose bytes fit an I64, found "
@.d22 = private constant [3 x i8] c"T7c"
@.d23 = private constant [66 x i8] c"an array inside an array or a struct is held by reference - write "
@.d24 = private constant [93 x i8] c"&, or make it of a known length where it is declared ('x := Array<T>(n)') to hold it in place"
@.d25 = private constant [8 x i8] c"T7a, T7d"
@.d26 = private constant [33 x i8] c" has no values to put in an array"
@.d27 = private constant [3 x i8] c"T20"
@.d28 = private constant [61 x i8] c" takes one index - several are passed to a type's At or SetAt"
@.d29 = private constant [3 x i8] c"E31"
@.d30 = private constant [16 x i8] c"array parameter "
@.d31 = private constant [32 x i8] c" is passed by reference - write "
@.d32 = private constant [1 x i8] c"&"
@.d33 = private constant [3 x i8] c"D9a"
@.d34 = private constant [60 x i8] c"this array's length is known only at run time, stored where "
@.d35 = private constant [72 x i8] c" elements are laid out - copy them through a slice of that length, 'v[0:"
@.d36 = private constant [2 x i8] c"]'"
@.d37 = private constant [3 x i8] c"T7d"
@.d38 = private constant [12 x i8] c"an array of "
@.d39 = private constant [23 x i8] c" elements stored where "
@.d40 = private constant [62 x i8] c" are laid out - fixed storage takes an array of its own length"
@.d41 = private constant [3 x i8] c"T7d"
@.d42 = private constant [55 x i8] c"Array takes one type argument, its element type, found "
@.d43 = private constant [70 x i8] c" - a length is never written in a type: 'Array<T>(n)' makes n elements"
@.d44 = private constant [6 x i8] c"G8, T7"
@.d45 = private constant [88 x i8] c" holds itself through the array it is declared over - hold the array in a struct: 'type "
@.d46 = private constant [14 x i8] c" struct(items "
@.d47 = private constant [3 x i8] c"&)'"
@.d48 = private constant [3 x i8] c"T29"
@.d49 = private constant [4 x i8] c"S12b"
@.d50 = private constant [94 x i8] c"'=>' gives a value, which only a match used as a value takes - a statement's case runs a block"
@.d51 = private constant [24 x i8] c"'=>' gives a value, and "
@.d52 = private constant [50 x i8] c" gives none - a clause that leaves is a block: '{ "
@.d53 = private constant [3 x i8] c" }'"
@.d54 = private constant [4 x i8] c"S12b"
@.d55 = private constant [35 x i8] c"after 'is' or 'as' comes a case of "
@.d56 = private constant [8 x i8] c", found "
@.d57 = private constant [3 x i8] c"E32"
@.d58 = private constant [5 x i8] c"case "
@.d59 = private constant [49 x i8] c" carries nothing for 'as' to give - ask with 'is'"
@.d60 = private constant [3 x i8] c"E32"
@.d61 = private constant [62 x i8] c"this assertion aborts the program, evaluated while compiling: "
@.d62 = private constant [4 x i8] c"S18c"
@.d63 = private constant [4 x i8] c"S18c"
@.d64 = private constant [50 x i8] c"this assertion is false, evaluated while compiling"
@.d65 = private constant [52 x i8] c"this assertion is false, evaluated while compiling: "
@.d66 = private constant [4 x i8] c"S18c"
@.d67 = private constant [24 x i8] c" message is text, found "
@.d68 = private constant [31 x i8] c" - write it as text: \22x is \22 $x"
@.d69 = private constant [4 x i8] c"S18a"
@.d70 = private constant [23 x i8] c"an error may not leave "
@.d71 = private constant [24 x i8] c" message - catch it here"
@.d72 = private constant [3 x i8] c"S17"
@.d73 = private constant [15 x i8] c" may not leave "
@.d74 = private constant [48 x i8] c" message - it is evaluated only where it is used"
@.d75 = private constant [3 x i8] c"S17"
@.d76 = private constant [79 x i8] c" message may not return - it is evaluated only where it is used, and gives text"
@.d77 = private constant [3 x i8] c"S17"
@.d78 = private constant [65 x i8] c"evaluated while compiling, this assertion stops on a stale view: "
@.d79 = private constant [8 x i8] c"S18c, K1"
@.d80 = private constant [3 x i8] c"R9a"
@.d81 = private constant [164 x i8] c"a 'try ... catch' value is the element or what a clause gives, a copy either way, so nothing written into it is kept - write 'checked x[i].f = v' to check the store"
@.d82 = private constant [36 x i8] c" targets need as many values, found "
@.d83 = private constant [3 x i8] c"S4c"
@.d84 = private constant [52 x i8] c" declares SetAt but not At, which reading x[i] calls"
@.d85 = private constant [3 x i8] c"E31"
@.d86 = private constant [60 x i8] c"the atomic operations are methods of the integer types, and "
@.d87 = private constant [8 x i8] c" is none"
@.d88 = private constant [2 x i8] c"P9"
@.d89 = private constant [2 x i8] c"P9"
@.d90 = private constant [71 x i8] c"an atomic operation acts on a place - a variable, a field or an element"
@.d91 = private constant [2 x i8] c"P9"
@.d92 = private constant [62 x i8] c"this atomic operation writes its place, which must be writable"
@.d93 = private constant [17 x i8] c"unknown escape '\5C"
@.d94 = private constant [40 x i8] c"' - the escapes are \5Cn \5Ct \5Cr \5C0 \5C\5C \5C' \5C\22"
@.d95 = private constant [3 x i8] c"L15"
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d96 = private constant [3 x i8] c"E35"
@.d97 = private constant [44 x i8] c"nothing here can fail - write it without '!'"
@.d98 = private constant [1 x i8] c"'"
@.d99 = private constant [23 x i8] c"' is not a binary digit"
@.d100 = private constant [4 x i8] c"L10c"
@.d101 = private constant [4 x i8] c"L10c"
@.d102 = private constant [24 x i8] c"'0b' needs binary digits"
@.d103 = private constant [25 x i8] c"the block opened on line "
@.d104 = private constant [20 x i8] c" has no '}' - found "
@.d105 = private constant [0 x i8] c""
@.d106 = private constant [3 x i8] c"O17"
@.d107 = private constant [153 x i8] c"this value's references live where its own storage does not, and the callee can store through it - declare it a reference where they live ('x T&y = ...')"
@.d108 = private constant [4 x i8] c"O17a"
@.d109 = private constant [114 x i8] c"this value's references live where its own storage does not, so it is not held by reference - use the value itself"
@.d110 = private constant [34 x i8] c" is bound twice in one alternative"
@.d111 = private constant [4 x i8] c"S13c"
@.d112 = private constant [51 x i8] c" acts on the innermost loop, and there is none here"
@.d113 = private constant [3 x i8] c"S11"
@.d114 = private constant [42 x i8] c" is a build constant - choose another name"
@.d115 = private constant [3 x i8] c"B10"
@.d116 = private constant [8 x i8] c"-define "
@.d117 = private constant [1 x i8] c"="
@.d118 = private constant [14 x i8] c" does not fit "
@.d119 = private constant [11 x i8] c", which is "
@.d120 = private constant [4 x i8] c"B10c"
@.d121 = private constant [85 x i8] c" is a build constant, and a declaration giving it a default is immutable - drop 'mut'"
@.d122 = private constant [4 x i8] c"B10c"
@.d123 = private constant [91 x i8] c" is a build constant, and a default for it is a Bool, I32, I64, U64, F64 or String - found "
@.d124 = private constant [4 x i8] c"B10c"
@.d125 = private constant [8 x i8] c"O11, O12"
@.d126 = private constant [113 x i8] c"where this reference's referent lives is not known here, and the callee may build there - give it one known scope"
@.d127 = private constant [3 x i8] c"C2d"
@.d128 = private constant [113 x i8] c"this builds through a '&p' field whose scope is not known here - build where it lives, in the function that knows"
@.d129 = private constant [43 x i8] c" is a built-in type's name - choose another"
@.d130 = private constant [3 x i8] c"D3a"
@.d131 = private constant [107 x i8] c"'s Call relates its arguments' scopes, which a call through a function value cannot check - call it by name"
@.d132 = private constant [9 x i8] c"T22a, E31"
@.d133 = private constant [0 x i8] c""
@.d134 = private constant [21 x i8] c"cannot open this file"
@.d135 = private constant [27 x i8] c"the program cannot be run: "
@.d136 = private constant [3 x i8] c"B3g"
@.d137 = private constant [4 x i8] c"D16c"
@.d138 = private constant [84 x i8] c"a lambda's captures are read-only - capture a reference to change what is outside it"
@.d139 = private constant [2 x i8] c"L3"
@.d140 = private constant [52 x i8] c"carriage return - save the file with LF line endings"
@.d141 = private constant [4 x i8] c"S13f"
@.d142 = private constant [73 x i8] c"no value reaches this - an earlier 'case _' with no guard takes every one"
@.d143 = private constant [4 x i8] c"S12b"
@.d144 = private constant [66 x i8] c"this block can finish without leaving - give the value with '=> v'"
@.d145 = private constant [5 x i8] c"case "
@.d146 = private constant [25 x i8] c" is private to its module"
@.d147 = private constant [3 x i8] c"M6a"
@.d148 = private constant [115 x i8] c" is the value being matched, so this compares it with itself - to take any value and test it, write 'case _ if ...'"
@.d149 = private constant [4 x i8] c"S13f"
@.d150 = private constant [13 x i8] c"unknown name "
@.d151 = private constant [101 x i8] c" - a name in a case is a value compared by '=='; to take any value and test it, write 'case _ if ...'"
@.d152 = private constant [4 x i8] c"S13f"
@.d153 = private constant [21 x i8] c"a case value here is "
@.d154 = private constant [8 x i8] c", found "
@.d155 = private constant [3 x i8] c"S13"
@.d156 = private constant [4 x i8] c"R11a"
@.d157 = private constant [78 x i8] c"a catch with no error types takes every error left, so no clause can follow it"
@.d158 = private constant [3 x i8] c"R11"
@.d159 = private constant [57 x i8] c"a clause here leaves, or gives the value with 'default v'"
@.d160 = private constant [28 x i8] c"the call does not fail with "
@.d161 = private constant [3 x i8] c"R14"
@.d162 = private constant [4 x i8] c"R11a"
@.d163 = private constant [58 x i8] c"an earlier clause already takes every error this one names"
@.d164 = private constant [28 x i8] c"the call does not fail with "
@.d165 = private constant [17 x i8] c" - it fails with "
@.d166 = private constant [3 x i8] c"R14"
@.d167 = private constant [3 x i8] c"L13"
@.d168 = private constant [40 x i8] c"character literal not closed on its line"
@.d169 = private constant [4 x i8] c" is "
@.d170 = private constant [46 x i8] c"'s checked form, so it fails with every error "
@.d171 = private constant [11 x i8] c" can - add "
@.d172 = private constant [14 x i8] c" after its '?'"
@.d173 = private constant [4 x i8] c"E31a"
@.d174 = private constant [71 x i8] c" is a checked form, which only adds checks to its plain form - declare "
@.d175 = private constant [10 x i8] c" beside it"
@.d176 = private constant [4 x i8] c"E31a"
@.d177 = private constant [24 x i8] c"clang could not compile "
@.d178 = private constant [0 x i8] c""
@.d179 = private constant [66 x i8] c"a block's last value is not the clause's value - write '} default "
@.d180 = private constant [17 x i8] c"' after the block"
@.d181 = private constant [3 x i8] c"R11"
@.d182 = private constant [4 x i8] c"L18a"
@.d183 = private constant [95 x i8] c"a comma never ends a line - items on different lines are separated by the line break; remove it"
@.d184 = private constant [8 x i8] c"E27, S9e"
@.d185 = private constant [69 x i8] c"this comprehension's own calls can fail - write 'try T[e for x in c]'"
@.d186 = private constant [3 x i8] c"E27"
@.d187 = private constant [90 x i8] c"a comprehension's elements may not be or hold references yet - build the array with a loop"
@.d188 = private constant [52 x i8] c"both values of 'a if c else b' have one type, found "
@.d189 = private constant [5 x i8] c" and "
@.d190 = private constant [3 x i8] c"E28"
@.d191 = private constant [30 x i8] c" is defined in terms of itself"
@.d192 = private constant [3 x i8] c"B9a"
@.d193 = private constant [2 x i8] c"B9"
@.d194 = private constant [38 x i8] c"a top-level condition is true or false"
@.d195 = private constant [56 x i8] c" is not computed from literals and build constants alone"
@.d196 = private constant [3 x i8] c"B9a"
@.d197 = private constant [3 x i8] c"E28"
@.d198 = private constant [190 x i8] c"a conditional or a match gives a copy of the value it chooses, which this call would write and drop - call on the place itself, 'if c { f(a) } else { f(b) }', or hold the values by reference"
@.d199 = private constant [52 x i8] c" is mutable, so a top-level condition cannot read it"
@.d200 = private constant [3 x i8] c"B9a"
@.d201 = private constant [62 x i8] c" is not a build constant or an immutable global of this module"
@.d202 = private constant [3 x i8] c"B9a"
@.d203 = private constant [59 x i8] c": these numbers' types do not meet - convert one, as I64(n)"
@.d204 = private constant [3 x i8] c"T6b"
@.d205 = private constant [24 x i8] c"the condition beginning "
@.d206 = private constant [14 x i8] c" is not a Bool"
@.d207 = private constant [2 x i8] c"B9"
@.d208 = private constant [29 x i8] c"a condition is a Bool, found "
@.d209 = private constant [0 x i8] c""
@.d210 = private constant [64 x i8] c"conditions decide branches holding further conditions more than "
@.d211 = private constant [12 x i8] c" levels deep"
@.d212 = private constant [3 x i8] c"B9c"
@.d213 = private constant [28 x i8] c" cannot combine these values"
@.d214 = private constant [2 x i8] c"B9"
@.d215 = private constant [60 x i8] c"this top-level condition cannot be decided while compiling: "
@.d216 = private constant [3 x i8] c"B9c"
@.d217 = private constant [13 x i8] c"unknown name "
@.d218 = private constant [3 x i8] c"B10"
@.d219 = private constant [3 x i8] c"B9c"
@.d220 = private constant [92 x i8] c"this top-level condition uses what exists only in the branches it decides, or does not check"
@.d221 = private constant [3 x i8] c"S8a"
@.d222 = private constant [107 x i8] c"this condition is the same on every build, so one branch is dead - depend on a build constant, or remove it"
@.d223 = private constant [87 x i8] c" is constrained differently elsewhere in this declaration - one constraint per variable"
@.d224 = private constant [3 x i8] c"G19"
@.d225 = private constant [133 x i8] c" is not a trait, so it cannot constrain a type variable - a type parameter's constraint is a trait, and a length is no parameter (T7)"
@.d226 = private constant [7 x i8] c"G6, G19"
@.d227 = private constant [33 x i8] c" does not satisfy the constraint "
@.d228 = private constant [4 x i8] c" on "
@.d229 = private constant [2 x i8] c": "
@.d230 = private constant [50 x i8] c" is sealed - only the types its own module gives '"
@.d231 = private constant [12 x i8] c"' satisfy it"
@.d232 = private constant [8 x i8] c"G19, T31"
@.d233 = private constant [33 x i8] c" does not satisfy the constraint "
@.d234 = private constant [4 x i8] c" on "
@.d235 = private constant [3 x i8] c"G19"
@.d236 = private constant [33 x i8] c" does not satisfy the constraint "
@.d237 = private constant [4 x i8] c" on "
@.d238 = private constant [59 x i8] c": it has no Hash - declare 'Hash() I64', agreeing with '=='"
@.d239 = private constant [9 x i8] c"G19, E10b"
@.d240 = private constant [33 x i8] c" does not satisfy the constraint "
@.d241 = private constant [4 x i8] c" on "
@.d242 = private constant [19 x i8] c": it has no method "
@.d243 = private constant [10 x i8] c" that fits"
@.d244 = private constant [3 x i8] c"G19"
@.d245 = private constant [4 x i8] c"O25a"
@.d246 = private constant [87 x i8] c"this container's scope cannot be built into from here - write through the global itself"
@.d247 = private constant [15 x i8] c" cannot become "
@.d248 = private constant [31 x i8] c" - their representations differ"
@.d249 = private constant [3 x i8] c"T29"
@.d250 = private constant [18 x i8] c" is no number, so "
@.d251 = private constant [21 x i8] c"(x) cannot convert it"
@.d252 = private constant [3 x i8] c"E26"
@.d253 = private constant [18 x i8] c"the type of field "
@.d254 = private constant [7 x i8] c" names "
@.d255 = private constant [105 x i8] c", which only the constructor introduces - for a field to hold it, declare it the type's parameter: 'type "
@.d256 = private constant [1 x i8] c"<"
@.d257 = private constant [2 x i8] c">'"
@.d258 = private constant [4 x i8] c"G10d"
@.d259 = private constant [6 x i8] c"field "
@.d260 = private constant [74 x i8] c" names no parameter of the constructor - give it a value, with '=' or ':='"
@.d261 = private constant [2 x i8] c"C4"
@.d262 = private constant [6 x i8] c"field "
@.d263 = private constant [58 x i8] c" takes its type from ':=', and the constructor introduces "
@.d264 = private constant [58 x i8] c", so its body is checked per call - write the field's type"
@.d265 = private constant [4 x i8] c"G10d"
@.d266 = private constant [22 x i8] c"the type arguments of "
@.d267 = private constant [55 x i8] c" cannot be inferred from these arguments - write them: "
@.d268 = private constant [10 x i8] c"<...>(...)"
@.d269 = private constant [4 x i8] c"G10c"
@.d270 = private constant [15 x i8] c" is not one of "
@.d271 = private constant [81 x i8] c"'s parameters, and a generic type's constructor introduces none of its own - add "
@.d272 = private constant [19 x i8] c" to the type's list"
@.d273 = private constant [4 x i8] c"G10d"
@.d274 = private constant [5 x i8] c"what "
@.d275 = private constant [65 x i8] c"'s constructor introduces cannot be inferred from these arguments"
@.d276 = private constant [4 x i8] c"G10d"
@.d277 = private constant [3 x i8] c"D8e"
@.d278 = private constant [61 x i8] c"a 'noreturn' call gives no value, so ':=' has no type to take"
@.d279 = private constant [3 x i8] c"D15"
@.d280 = private constant [91 x i8] c"':=' takes its type from the initializer, and null has none - write the type: 'x T& = null'"
@.d281 = private constant [55 x i8] c"a type is declared over a number or an array, not over "
@.d282 = private constant [38 x i8] c" - hold it in a struct's field instead"
@.d283 = private constant [3 x i8] c"T29"
@.d284 = private constant [18 x i8] c" is declared twice"
@.d285 = private constant [0 x i8] c""
@.d286 = private constant [11 x i8] c"two traits "
@.d287 = private constant [34 x i8] c" satisfies both declare a default "
@.d288 = private constant [25 x i8] c" - the call cannot choose"
@.d289 = private constant [4 x i8] c"M19e"
@.d290 = private constant [10 x i8] c"parameter "
@.d291 = private constant [57 x i8] c" declares no default, so 'default' cannot stand in for it"
@.d292 = private constant [4 x i8] c"E14a"
@.d293 = private constant [4 x i8] c"E14a"
@.d294 = private constant [67 x i8] c"'default' stands only for a parameter's declared default, in a call"
@.d295 = private constant [9 x i8] c"expected "
@.d296 = private constant [33 x i8] c" defaults, one per result, found "
@.d297 = private constant [3 x i8] c"R11"
@.d298 = private constant [3 x i8] c"R11"
@.d299 = private constant [80 x i8] c"this clause's block always leaves, so its default is never the value - remove it"
@.d300 = private constant [3 x i8] c"R11"
@.d301 = private constant [131 x i8] c"a default for a value holding references builds all it holds - a constructor call of numbers and written text, as 'List<String&>()'"
@.d302 = private constant [3 x i8] c"R11"
@.d303 = private constant [67 x i8] c"a try written as a statement gives no value, so it takes no default"
@.d304 = private constant [3 x i8] c"R11"
@.d305 = private constant [54 x i8] c"a default belongs to a catch clause: 'catch default v'"
@.d306 = private constant [3 x i8] c"R11"
@.d307 = private constant [77 x i8] c"this call returns no value, so there is nothing for a default to stand in for"
@.d308 = private constant [63 x i8] c"a default is computed while compiling, and this one cannot be: "
@.d309 = private constant [3 x i8] c"D8a"
@.d310 = private constant [80 x i8] c" has no default, but a parameter before it does - defaulted parameters come last"
@.d311 = private constant [3 x i8] c"D8a"
@.d312 = private constant [19 x i8] c"a default of trait "
@.d313 = private constant [35 x i8] c" is declared in that trait's module"
@.d314 = private constant [4 x i8] c"M19e"
@.d315 = private constant [8 x i8] c"R11, O25"
@.d316 = private constant [83 x i8] c"a reference default lives where the call's result does - or is null, or built there"
@.d317 = private constant [6 x i8] c"trait "
@.d318 = private constant [27 x i8] c" already requires a method "
@.d319 = private constant [39 x i8] c" - choose another name for this default"
@.d320 = private constant [4 x i8] c"M19e"
@.d321 = private constant [4 x i8] c"S19b"
@.d322 = private constant [52 x i8] c"an error may not leave deferred code - catch it here"
@.d323 = private constant [62 x i8] c" may not leave deferred code - it runs while its block is left"
@.d324 = private constant [4 x i8] c"S19b"
@.d325 = private constant [4 x i8] c"S19b"
@.d326 = private constant [62 x i8] c"deferred code may not return - it runs while its block is left"
@.d327 = private constant [8 x i8] c"-define "
@.d328 = private constant [1 x i8] c"="
@.d329 = private constant [60 x i8] c": not a number - '0x' and '0b' take digits of their own base"
@.d330 = private constant [3 x i8] c"B10"
@.d331 = private constant [46 x i8] c"-define cannot redefine the built-in constant "
@.d332 = private constant [4 x i8] c"B10a"
@.d333 = private constant [8 x i8] c"-define "
@.d334 = private constant [1 x i8] c"="
@.d335 = private constant [20 x i8] c": beyond F64's range"
@.d336 = private constant [3 x i8] c"B10"
@.d337 = private constant [8 x i8] c"-define "
@.d338 = private constant [1 x i8] c"="
@.d339 = private constant [16 x i8] c": beyond 64 bits"
@.d340 = private constant [3 x i8] c"B10"
@.d341 = private constant [3 x i8] c"B10"
@.d342 = private constant [33 x i8] c"-define needs Name=value after it"
@.d343 = private constant [8 x i8] c"-define "
@.d344 = private constant [1 x i8] c"="
@.d345 = private constant [21 x i8] c": below I64's minimum"
@.d346 = private constant [3 x i8] c"B10"
@.d347 = private constant [8 x i8] c"-define "
@.d348 = private constant [1 x i8] c"="
@.d349 = private constant [31 x i8] c": the name is not an identifier"
@.d350 = private constant [3 x i8] c"B10"
@.d351 = private constant [33 x i8] c"-define takes Name=value, found '"
@.d352 = private constant [1 x i8] c"'"
@.d353 = private constant [3 x i8] c"B10"
@.d354 = private constant [8 x i8] c"-define "
@.d355 = private constant [1 x i8] c"="
@.d356 = private constant [15 x i8] c": defined twice"
@.d357 = private constant [3 x i8] c"B10"
@.d358 = private constant [13 x i8] c" targets for "
@.d359 = private constant [39 x i8] c" results - write '_' for one not wanted"
@.d360 = private constant [3 x i8] c"D8c"
@.d361 = private constant [2 x i8] c"C7"
@.d362 = private constant [111 x i8] c"'destruct' follows the constructor's body - close the body first: 'type T struct(...) { ... } destruct { ... }'"
@.d363 = private constant [3 x i8] c"D8c"
@.d364 = private constant [83 x i8] c"':=' declares each target, so each is a name or '_' - use '=' to assign into places"
@.d365 = private constant [58 x i8] c"only several results can be destructured, and this is one "
@.d366 = private constant [3 x i8] c"D8c"
@.d367 = private constant [59 x i8] c" has a destructor, so it is held only by reference - write "
@.d368 = private constant [1 x i8] c"&"
@.d369 = private constant [3 x i8] c"C11"
@.d370 = private constant [4 x i8] c"L10b"
@.d371 = private constant [45 x i8] c"'_' in a number must stand between two digits"
@.d372 = private constant [3 x i8] c"E6a"
@.d373 = private constant [16 x i8] c"division by zero"
@.d374 = private constant [3 x i8] c"T24"
@.d375 = private constant [41 x i8] c"a type takes at most one reference marker"
@.d376 = private constant [4 x i8] c"O25c"
@.d377 = private constant [95 x i8] c"this element can be stored through, so it lives exactly where the array is put - build it there"
@.d378 = private constant [4 x i8] c"O25c"
@.d379 = private constant [87 x i8] c"the array outlives what this element refers to - build the element where the array goes"
@.d380 = private constant [9 x i8] c"expected "
@.d381 = private constant [8 x i8] c", found "
@.d382 = private constant [53 x i8] c" - they differ in whether the elements are references"
@.d383 = private constant [4 x i8] c"T25a"
@.d384 = private constant [3 x i8] c"L13"
@.d385 = private constant [23 x i8] c"empty character literal"
@.d386 = private constant [3 x i8] c"C7a"
@.d387 = private constant [40 x i8] c"this destructor does nothing - remove it"
@.d388 = private constant [11 x i8] c"end of file"
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@__olang_prog_scope = external thread_local(initialexec) global ptr
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d389 = private constant [11 x i8] c"end of line"
@.d390 = private constant [10 x i8] c"enum case "
@.d391 = private constant [20 x i8] c" is already declared"
@.d392 = private constant [3 x i8] c"T17"
@.d393 = private constant [4 x i8] c"E10a"
@.d394 = private constant [66 x i8] c"Eq takes one parameter of its receiver's own type and gives a Bool"
@.d395 = private constant [85 x i8] c" takes what it is given read-only - neither its receiver nor a parameter may be 'mut'"
@.d396 = private constant [10 x i8] c"E10a, E11c"
@.d397 = private constant [3 x i8] c"R1a"
@.d398 = private constant [84 x i8] c"'?' alone is what the body can fail with - write '?', or name the types: '? IoError'"
@.d399 = private constant [2 x i8] c"R3"
@.d400 = private constant [52 x i8] c"'error' fails a function, and this is not inside one"
@.d401 = private constant [132 x i8] c" is an error type, which has no values - an error is raised and caught, never held; tell its words apart with catch clauses ('catch "
@.d402 = private constant [11 x i8] c".WORD { }')"
@.d403 = private constant [3 x i8] c"T20"
@.d404 = private constant [31 x i8] c"this function does not declare "
@.d405 = private constant [19 x i8] c" - add it after '?'"
@.d406 = private constant [2 x i8] c"R3"
@.d407 = private constant [1 x i8] c"'"
@.d408 = private constant [55 x i8] c"' is an error word, not a value - raise it with 'error "
@.d409 = private constant [36 x i8] c"', tell it apart with a catch clause"
@.d410 = private constant [3 x i8] c"T20"
@.d411 = private constant [11 x i8] c"error word "
@.d412 = private constant [20 x i8] c" is already declared"
@.d413 = private constant [3 x i8] c"T19"
@.d414 = private constant [11 x i8] c"error word "
@.d415 = private constant [25 x i8] c" is private to its module"
@.d416 = private constant [3 x i8] c"M6a"
@.d417 = private constant [26 x i8] c"this function's '?' names "
@.d418 = private constant [34 x i8] c", not this word - add it after '?'"
@.d419 = private constant [2 x i8] c"R3"
@.d420 = private constant [26 x i8] c"an error set names one of "
@.d421 = private constant [68 x i8] c"'s first 64 words alone, and this is past them - name the type whole"
@.d422 = private constant [3 x i8] c"R1c"
@.d423 = private constant [2 x i8] c"\5Ct"
@.d424 = private constant [2 x i8] c"\5Cn"
@.d425 = private constant [2 x i8] c"\5Cr"
@.d426 = private constant [2 x i8] c"\5C0"
declare void @__olang_check_failed(ptr)
@.c427 = private unnamed_addr constant [45 x i8] c"compiler/msgs.olang:40: unreachable reached\0A\00"
@.d428 = private constant [2 x i8] c"\5Cx"
@.d429 = private constant [9 x i8] c"expected "
@.d430 = private constant [8 x i8] c", found "
@.d431 = private constant [0 x i8] c""
@.d432 = private constant [8 x i8] c"explain "
@.d433 = private constant [55 x i8] c" takes the name of one of its items, as 'olang explain "
@.d434 = private constant [6 x i8] c" main'"
@.d435 = private constant [4 x i8] c"B11b"
@.d436 = private constant [4 x i8] c"B11a"
@.d437 = private constant [45 x i8] c"explain takes one rule, as 'olang explain B1'"
@.d438 = private constant [1 x i8] c"'"
@.d439 = private constant [26 x i8] c"' is no top-level item of "
@.d440 = private constant [4 x i8] c"B11b"
@.d441 = private constant [4 x i8] c"T29f"
@.d442 = private constant [54 x i8] c"only a type over a number or an array extends its base"
@.d443 = private constant [108 x i8] c" cannot cross the C boundary - an extern parameter or result is a number, or a parameter an array of numbers"
@.d444 = private constant [2 x i8] c"X2"
@.d445 = private constant [8 x i8] c"O23, O11"
@.d446 = private constant [122 x i8] c"this stores into a '&p' field whose binding is not known through this path - store through a variable holding the instance"
@.d447 = private constant [6 x i8] c"field "
@.d448 = private constant [87 x i8] c" has a parameter's name - write it bare to take the parameter's value, or name it apart"
@.d449 = private constant [3 x i8] c"C2a"
@.d450 = private constant [22 x i8] c" is beyond F64's range"
@.d451 = private constant [4 x i8] c"L12b"
@.d452 = private constant [3 x i8] c"S9e"
@.d453 = private constant [104 x i8] c"a loop's catch clause runs after the loop has ended, so it has no loop to break or continue - set a flag"
@.d454 = private constant [116 x i8] c" is already declared, and a for-in declares new names - choose another, or to loop while it is in c write 'for { if "
@.d455 = private constant [22 x i8] c" not in c { break } }'"
@.d456 = private constant [8 x i8] c"D3a, E29"
@.d457 = private constant [3 x i8] c"S9e"
@.d458 = private constant [90 x i8] c"this loop's own calls can fail - write 'for x in try c', with catch clauses after the body"
@.d459 = private constant [3 x i8] c"S9e"
@.d460 = private constant [59 x i8] c"nothing this loop calls by itself can fail - drop the 'try'"
@.d461 = private constant [35 x i8] c"the formatter could not be built - "
@.d462 = private constant [9 x i8] c" says why"
@.d463 = private constant [3 x i8] c"B13"
@.d464 = private constant [52 x i8] c"the formatter's source is not beside this compiler: "
@.d465 = private constant [3 x i8] c"B13"
@.d466 = private constant [95 x i8] c" is a method of the unsigned type of its float's width - convert first, as U64(x).F64FromBits()"
@.d467 = private constant [3 x i8] c"E33"
@.d468 = private constant [3 x i8] c"R1b"
@.d469 = private constant [82 x i8] c"a function type writes its error set - '? IoError' - since no body says what it is"
@.d470 = private constant [1 x i8] c"'"
@.d471 = private constant [102 x i8] c"' relates its arguments' scopes, which a call through a function value cannot check - call it directly"
@.d472 = private constant [4 x i8] c"T22a"
@.d473 = private constant [18 x i8] c"generic function '"
@.d474 = private constant [75 x i8] c"' is not a value - call it, or name an instance by its type arguments, as '"
@.d475 = private constant [6 x i8] c"<I64>'"
@.d476 = private constant [3 x i8] c"G12"
@.d477 = private constant [2 x i8] c"G6"
@.d478 = private constant [46 x i8] c"only a struct or a trait takes type parameters"
@.d479 = private constant [73 x i8] c"this global's initializer aborts the program, evaluated while compiling: "
@.d480 = private constant [2 x i8] c"K2"
@.d481 = private constant [3 x i8] c"O1b"
@.d482 = private constant [103 x i8] c"a global holds only what lives as long as the program - store something built here, or another global's"
@.d483 = private constant [21 x i8] c"'s initializer reads "
@.d484 = private constant [48 x i8] c", which is not set until the initializer is done"
@.d485 = private constant [3 x i8] c"B5a"
@.d486 = private constant [76 x i8] c"evaluated while compiling, this global's initializer stops on a stale view: "
@.d487 = private constant [6 x i8] c"K2, K1"
@.d488 = private constant [71 x i8] c"these globals' initializers read each other, so none can be set first: "
@.d489 = private constant [3 x i8] c"B5a"
@.d490 = private constant [25 x i8] c"a guard is a Bool, found "
@.d491 = private constant [4 x i8] c"S13e"
@.d492 = private constant [2 x i8] c"B1"
@.d493 = private constant [27 x i8] c"help takes at most one mode"
@.d494 = private constant [1 x i8] c"'"
@.d495 = private constant [28 x i8] c"' is not a hexadecimal digit"
@.d496 = private constant [4 x i8] c"L10a"
@.d497 = private constant [4 x i8] c"L10a"
@.d498 = private constant [29 x i8] c"'0x' needs hexadecimal digits"
@.d499 = private constant [68 x i8] c" cannot be written - only a local, a parameter or a 'mut' global can"
@.d500 = private constant [2 x i8] c"S6"
@.d501 = private constant [48 x i8] c"another import of this module is already named '"
@.d502 = private constant [32 x i8] c"' - give one an alias of its own"
@.d503 = private constant [2 x i8] c"M5"
@.d504 = private constant [1 x i8] c"'"
@.d505 = private constant [86 x i8] c"' is no identifier, so it cannot be this import's alias - write one: import Name \22...\22"
@.d506 = private constant [2 x i8] c"M4"
@.d507 = private constant [16 x i8] c"could not fetch "
@.d508 = private constant [45 x i8] c" with git - check the path and the connection"
@.d509 = private constant [4 x i8] c"M23a"
@.d510 = private constant [18 x i8] c"no .olang file at "
@.d511 = private constant [3 x i8] c"M23"
@.d512 = private constant [3 x i8] c"M23"
@.d513 = private constant [41 x i8] c"an import names its file without '.olang'"
@.d514 = private constant [7 x i8] c"import "
@.d515 = private constant [67 x i8] c" is private to its module - only a capitalized alias is re-exported"
@.d516 = private constant [3 x i8] c"M14"
@.d517 = private constant [28 x i8] c"this relative import leaves "
@.d518 = private constant [43 x i8] c" - name a module outside it by its own path"
@.d519 = private constant [3 x i8] c"M23"
@.d520 = private constant [31 x i8] c"olang.lock names no commit for "
@.d521 = private constant [41 x i8] c" - delete its line, or build with -update"
@.d522 = private constant [4 x i8] c"M23b"
@.d523 = private constant [48 x i8] c"could not fetch the commit olang.lock names for "
@.d524 = private constant [41 x i8] c" - delete its line, or build with -update"
@.d525 = private constant [10 x i8] c"M23b, M23c"
@.d526 = private constant [3 x i8] c"M23"
@.d527 = private constant [43 x i8] c"this import path is too long to name a file"
@.d528 = private constant [61 x i8] c" reaches a file another import of this module already reaches"
@.d529 = private constant [3 x i8] c"M16"
@.d530 = private constant [4 x i8] c"M23a"
@.d531 = private constant [97 x i8] c"a remote import's host, owner, repository and ref may hold only letters, digits, '.', '_' and '-'"
@.d532 = private constant [3 x i8] c"M23"
@.d533 = private constant [74 x i8] c"a remote import names a file in the repository: host/owner/repo[@ref]/path"
@.d534 = private constant [55 x i8] c" is a statement of its own, never part of an expression"
@.d535 = private constant [3 x i8] c"S3a"
@.d536 = private constant [23 x i8] c" takes a number, found "
@.d537 = private constant [3 x i8] c"S3a"
@.d538 = private constant [30 x i8] c"an index is an integer, found "
@.d539 = private constant [3 x i8] c"E16"
@.d540 = private constant [6 x i8] c"index "
@.d541 = private constant [24 x i8] c" is outside the array's "
@.d542 = private constant [9 x i8] c" elements"
@.d543 = private constant [3 x i8] c"E16"
@.d544 = private constant [3 x i8] c"C2d"
@.d545 = private constant [162 x i8] c"this instance holds a reference to an argument it would outlive - make the argument where the instance goes, or the instance where the argument lives ('T&x(...)')"
@.d546 = private constant [3 x i8] c"C2d"
@.d547 = private constant [113 x i8] c"this instance would outlive what its '&p' field refers to - keep it in that block, or build it there ('T&x(...)')"
@.d548 = private constant [78 x i8] c" is beyond 64 bits - the largest decimal literal is U64's 18446744073709551615"
@.d549 = private constant [3 x i8] c"L10"
@.d550 = private constant [63 x i8] c" cannot be a reference - only a struct, an enum or an array can"
@.d551 = private constant [3 x i8] c"T24"
@.d552 = private constant [2 x i8] c"'&"
@.d553 = private constant [89 x i8] c"' after the type is read as a reference marker, not the operator '&' - parenthesize: '(x "
@.d554 = private constant [6 x i8] c" T) & "
@.d555 = private constant [1 x i8] c"'"
@.d556 = private constant [3 x i8] c"E32"
@.d557 = private constant [59 x i8] c"'is' and 'as' ask which case an enum value is, and this is "
@.d558 = private constant [3 x i8] c"E32"
@.d559 = private constant [2 x i8] c"M1"
@.d560 = private constant [41 x i8] c"a directory - a module is one .olang file"
@.d561 = private constant [5 x i8] c" and "
@.d562 = private constant [53 x i8] c" are different types, so they never name one instance"
@.d563 = private constant [4 x i8] c"E10c"
@.d564 = private constant [60 x i8] c"'a is b' asks whether two references name one instance, and "
@.d565 = private constant [5 x i8] c" and "
@.d566 = private constant [24 x i8] c" are not both references"
@.d567 = private constant [4 x i8] c"E10c"
@.d568 = private constant [3 x i8] c"P4c"
@.d569 = private constant [46 x i8] c"no task of this join can fail - drop the 'try'"
@.d570 = private constant [3 x i8] c"P4c"
@.d571 = private constant [79 x i8] c"a join takes catch clauses only as 'try join', and no task of this one can fail"
@.d572 = private constant [3 x i8] c"P4d"
@.d573 = private constant [93 x i8] c"a task of this join binds a target it leaves unwritten when it fails - this clause must leave"
@.d574 = private constant [8 x i8] c"S3, E11b"
@.d575 = private constant [100 x i8] c"text on a line of its own does nothing - a join continues onto the next line only inside parentheses"
@.d576 = private constant [32 x i8] c"this join's tasks can fail with "
@.d577 = private constant [64 x i8] c" - write 'try join', with catch clauses for what it handles here"
@.d578 = private constant [3 x i8] c"P4c"
@.d579 = private constant [60 x i8] c"a join piece is a text literal or a '$' rendering - write '$"
@.d580 = private constant [1 x i8] c"'"
@.d581 = private constant [4 x i8] c"E11b"
@.d582 = private constant [4 x i8] c"E11b"
@.d583 = private constant [77 x i8] c"'(' after a piece of text calls it - to join the value inside, write '$(...)'"
@.d584 = private constant [3 x i8] c"P1a"
@.d585 = private constant [49 x i8] c"this join spawns nothing, so it waits for nothing"
@.d586 = private constant [42 x i8] c" is a keyword, not a name - choose another"
@.d587 = private constant [2 x i8] c"L9"
@.d588 = private constant [99 x i8] c" is a keyword, not a name - a field named by one is reached only after '.', never by the name alone"
@.d589 = private constant [3 x i8] c"L9a"
@.d590 = private constant [7 x i8] c" takes "
@.d591 = private constant [10 x i8] c" parameter"
@.d592 = private constant [18 x i8] c", and this lambda "
@.d593 = private constant [4 x i8] c"D16a"
@.d594 = private constant [17 x i8] c"lambda parameter "
@.d595 = private constant [49 x i8] c" has no type, and nothing gives it one - write it"
@.d596 = private constant [4 x i8] c"D16a"
@.d597 = private constant [18 x i8] c"this result binds "
@.d598 = private constant [4 x i8] c" to "
@.d599 = private constant [94 x i8] c", which the call holds in an array, where an array is held by reference - write the result as "
@.d600 = private constant [1 x i8] c"&"
@.d601 = private constant [3 x i8] c"T7a"
@.d602 = private constant [4 x i8] c"D16b"
@.d603 = private constant [54 x i8] c"this value gives the lambda no result type - write one"
@.d604 = private constant [39 x i8] c"this lambda's signature disagrees with "
@.d605 = private constant [42 x i8] c" - leave that part out, or make them agree"
@.d606 = private constant [4 x i8] c"D16a"
@.d607 = private constant [19 x i8] c"this lambda keeps '"
@.d608 = private constant [91 x i8] c"' beyond the call, which a call through a function value cannot check - keep a copy instead"
@.d609 = private constant [4 x i8] c"T22a"
@.d610 = private constant [4 x i8] c"T22a"
@.d611 = private constant [93 x i8] c"this lambda relates its arguments' scopes, which a call through a function value cannot check"
@.d612 = private constant [3 x i8] c"E31"
@.d613 = private constant [16 x i8] c"Len gives an I64"
@.d614 = private constant [1 x i8] c"'"
@.d615 = private constant [101 x i8] c"' takes an array by value, an instance per length (G29), so it is no value - pass a lambda calling it"
@.d616 = private constant [3 x i8] c"G12"
@.d617 = private constant [3 x i8] c"E31"
@.d618 = private constant [35 x i8] c"Less, which '<' calls, gives a Bool"
@.d619 = private constant [45 x i8] c"a one-line body is one simple statement, not "
@.d620 = private constant [27 x i8] c" - write a block, '{ ... }'"
@.d621 = private constant [3 x i8] c"S1b"
@.d622 = private constant [3 x i8] c"S1b"
@.d623 = private constant [72 x i8] c"a one-line body stands on the line of its ':' - write a block, '{ ... }'"
@.d624 = private constant [25 x i8] c"a line cannot begin with "
@.d625 = private constant [59 x i8] c" - the line before ended its statement; end that line with "
@.d626 = private constant [38 x i8] c", or put the expression in parentheses"
@.d627 = private constant [3 x i8] c"L18"
@.d628 = private constant [8 x i8] c"linking "
@.d629 = private constant [7 x i8] c" failed"
@.d630 = private constant [0 x i8] c""
@.d631 = private constant [20 x i8] c"this literal enters "
@.d632 = private constant [68 x i8] c" through its constructor, which does not run on it while compiling: "
@.d633 = private constant [4 x i8] c"T29d"
@.d634 = private constant [26 x i8] c"this literal does not fit "
@.d635 = private constant [6 x i8] c", and "
@.d636 = private constant [20 x i8] c" does not flow into "
@.d637 = private constant [14 x i8] c" - convert one"
@.d638 = private constant [3 x i8] c"E6d"
@.d639 = private constant [3 x i8] c"E4a"
@.d640 = private constant [62 x i8] c"this literal expression has no value - it overflows every type"
@.d641 = private constant [45 x i8] c"this literal expression's value does not fit "
@.d642 = private constant [3 x i8] c"E4a"
@.d643 = private constant [11 x i8] c"a value of "
@.d644 = private constant [36 x i8] c" is made by its constructor - write "
@.d645 = private constant [5 x i8] c"(...)"
@.d646 = private constant [4 x i8] c"T29d"
@.d647 = private constant [14 x i8] c" does not fit "
@.d648 = private constant [2 x i8] c"T6"
@.d649 = private constant [3 x i8] c"L13"
@.d650 = private constant [71 x i8] c"character literal holds more than one character - text is written in \22\22"
@.d651 = private constant [2 x i8] c"B4"
@.d652 = private constant [84 x i8] c"main takes no parameters and returns no value: 'fn main() { }', or 'fn main() ? { }'"
@.d653 = private constant [5 x i8] c"case "
@.d654 = private constant [4 x i8] c" of "
@.d655 = private constant [42 x i8] c" is not covered - add it, or 'nomatch { }'"
@.d656 = private constant [4 x i8] c"S13a"
@.d657 = private constant [13 x i8] c"a match over "
@.d658 = private constant [73 x i8] c" gives a value only when its cases cover every value - add 'nomatch => v'"
@.d659 = private constant [4 x i8] c"S12b"
@.d660 = private constant [3 x i8] c"G30"
@.d661 = private constant [87 x i8] c"no clause of this match gives a value at this instance's length - add one, or 'nomatch'"
@.d662 = private constant [9 x i8] c"S12b, D8c"
@.d663 = private constant [116 x i8] c"a match gives one value - to give several, return them from each case of a match statement: 'case P { return a, b }'"
@.d664 = private constant [29 x i8] c"every value of this match is "
@.d665 = private constant [8 x i8] c", found "
@.d666 = private constant [4 x i8] c"S12b"
@.d667 = private constant [33 x i8] c"'@' has no built-in meaning, and "
@.d668 = private constant [19 x i8] c" declares no MatMul"
@.d669 = private constant [3 x i8] c"E31"
@.d670 = private constant [8 x i8] c"member '"
@.d671 = private constant [5 x i8] c"' of "
@.d672 = private constant [25 x i8] c" is private to its module"
@.d673 = private constant [3 x i8] c"M6a"
@.d674 = private constant [37 x i8] c" can fail here - write 'try (x in c)'"
@.d675 = private constant [3 x i8] c"E29"
@.d676 = private constant [15 x i8] c"'x in c' calls "
@.d677 = private constant [6 x i8] c", and "
@.d678 = private constant [9 x i8] c" has none"
@.d679 = private constant [3 x i8] c"E29"
@.d680 = private constant [32 x i8] c", which 'in' calls, gives a Bool"
@.d681 = private constant [3 x i8] c"E29"
@.d682 = private constant [29 x i8] c"two imported modules declare "
@.d683 = private constant [42 x i8] c" for this type - import only the one meant"
@.d684 = private constant [3 x i8] c"M22"
@.d685 = private constant [42 x i8] c" is a method - call it on its receiver: x."
@.d686 = private constant [5 x i8] c"(...)"
@.d687 = private constant [3 x i8] c"M19"
@.d688 = private constant [70 x i8] c" cannot fail - the operation calling it has nowhere to handle an error"
@.d689 = private constant [3 x i8] c"E31"
@.d690 = private constant [19 x i8] c" inherits a method "
@.d691 = private constant [36 x i8] c" from its base - choose another name"
@.d692 = private constant [4 x i8] c"T29e"
@.d693 = private constant [22 x i8] c"the compiler supplies "
@.d694 = private constant [5 x i8] c" for "
@.d695 = private constant [22 x i8] c" - choose another name"
@.d696 = private constant [12 x i8] c"E23, E33, P9"
@.d697 = private constant [22 x i8] c" already has a method "
@.d698 = private constant [15 x i8] c" in this module"
@.d699 = private constant [3 x i8] c"M21"
@.d700 = private constant [7 x i8] c"method "
@.d701 = private constant [25 x i8] c" is private to its module"
@.d702 = private constant [2 x i8] c"M6"
@.d703 = private constant [13 x i8] c" declares no "
@.d704 = private constant [73 x i8] c", and does not extend its base, which has one - declare it with 'extends'"
@.d705 = private constant [4 x i8] c"T29f"
@.d706 = private constant [37 x i8] c"only the prelude declares methods of "
@.d707 = private constant [59 x i8] c" - declare a type of your own over it: 'type T extends ...'"
@.d708 = private constant [4 x i8] c"M19d"
@.d709 = private constant [12 x i8] c"a method of "
@.d710 = private constant [34 x i8] c" is declared in that type's module"
@.d711 = private constant [3 x i8] c"M19"
@.d712 = private constant [41 x i8] c"the end can be reached without returning "
@.d713 = private constant [53 x i8] c" - return on every path, or end it with 'unreachable'"
@.d714 = private constant [4 x i8] c"D10a"
@.d715 = private constant [44 x i8] c" is generic - write its type arguments, as '"
@.d716 = private constant [6 x i8] c"<I32>'"
@.d717 = private constant [2 x i8] c"G7"
@.d718 = private constant [29 x i8] c"the mode comes first: 'olang "
@.d719 = private constant [22 x i8] c"' and then its options"
@.d720 = private constant [2 x i8] c"B1"
@.d721 = private constant [13 x i8] c" needs a file"
@.d722 = private constant [2 x i8] c"B1"
@.d723 = private constant [23 x i8] c" takes exactly one file"
@.d724 = private constant [2 x i8] c"B1"
@.d725 = private constant [37 x i8] c"this module has the same identity as "
@.d726 = private constant [46 x i8] c" - rename one, or import it by a relative path"
@.d727 = private constant [4 x i8] c"M22a"
@.d728 = private constant [4 x i8] c"D11a"
@.d729 = private constant [99 x i8] c"':=' gives a local its initializer's permission - remove 'mut', or write the type: 'x mut T& = ...'"
@.d730 = private constant [59 x i8] c"a local is always writable - 'mut' is for a reference, and "
@.d731 = private constant [8 x i8] c" is none"
@.d732 = private constant [4 x i8] c"D11a"
@.d733 = private constant [77 x i8] c"a field is writable wherever its instance is - 'mut' is for a reference, and "
@.d734 = private constant [8 x i8] c" is none"
@.d735 = private constant [2 x i8] c"C3"
@.d736 = private constant [95 x i8] c"a by-value parameter is the callee's own copy, always writable - 'mut' is for a reference, and "
@.d737 = private constant [8 x i8] c" is none"
@.d738 = private constant [2 x i8] c"D9"
@.d739 = private constant [38 x i8] c"'mut' makes a reference writable, and "
@.d740 = private constant [16 x i8] c" is no reference"
@.d741 = private constant [4 x i8] c"T25b"
@.d742 = private constant [57 x i8] c" is an import's alias in this module - rename one of them"
@.d743 = private constant [3 x i8] c"M20"
@.d744 = private constant [35 x i8] c" is already declared in this module"
@.d745 = private constant [2 x i8] c"D2"
@.d746 = private constant [57 x i8] c" is already a type's name in this module - choose another"
@.d747 = private constant [2 x i8] c"D2"
@.d748 = private constant [3 x i8] c"T24"
@.d749 = private constant [73 x i8] c"a nested reference lives in its container's scope - write a bare '&' here"
@.d750 = private constant [4 x i8] c"L18c"
@.d751 = private constant [113 x i8] c"parentheses group only a function type holding a comma of its own, as an item of a list - write this without them"
@.d752 = private constant [1 x i8] c"-"
@.d753 = private constant [23 x i8] c" is below I64's minimum"
@.d754 = private constant [3 x i8] c"L10"
@.d755 = private constant [3 x i8] c"E21"
@.d756 = private constant [108 x i8] c"there are no nested array literals - each array is a literal of its own: Array<I32, 2>[I32[1, 2], I32[3, 4]]"
@.d757 = private constant [17 x i8] c"nested more than "
@.d758 = private constant [48 x i8] c" levels deep - split it into locals or functions"
@.d759 = private constant [3 x i8] c"L21"
@.d760 = private constant [57 x i8] c"clang not found on PATH - install clang-20 (the IR is in "
@.d761 = private constant [1 x i8] c")"
@.d762 = private constant [0 x i8] c""
@.d763 = private constant [2 x i8] c"B4"
@.d764 = private constant [54 x i8] c"no main function - a program starts at 'fn main() { }'"
@.d765 = private constant [30 x i8] c"the specification has no rule "
@.d766 = private constant [4 x i8] c"B11a"
@.d767 = private constant [20 x i8] c"no specification at "
@.d768 = private constant [4 x i8] c"B11a"
@.d769 = private constant [13 x i8] c" has no case "
@.d770 = private constant [3 x i8] c"T17"
@.d771 = private constant [13 x i8] c" has no case "
@.d772 = private constant [17 x i8] c" - did you mean '"
@.d773 = private constant [2 x i8] c"'?"
@.d774 = private constant [3 x i8] c"T17"
@.d775 = private constant [13 x i8] c" has no word "
@.d776 = private constant [3 x i8] c"T19"
@.d777 = private constant [16 x i8] c" has no member '"
@.d778 = private constant [1 x i8] c"'"
@.d779 = private constant [0 x i8] c""
@.d780 = private constant [95 x i8] c" has no zero value, so this needs one - its constructor does not run on zeros while compiling: "
@.d781 = private constant [4 x i8] c"D13c"
@.d782 = private constant [16 x i8] c"non-ASCII byte '"
@.d783 = private constant [25 x i8] c"' - olang source is ASCII"
@.d784 = private constant [2 x i8] c"L1"
@.d785 = private constant [3 x i8] c"D8e"
@.d786 = private constant [90 x i8] c"a 'noreturn' function never returns to its caller, so it fails with nothing - drop the '?'"
@.d787 = private constant [3 x i8] c"D8e"
@.d788 = private constant [109 x i8] c"a 'noreturn' function may not reach its end - end every path with a noreturn call, 'unreachable' or 'for { }'"
@.d789 = private constant [21 x i8] c" cannot be 'noreturn'"
@.d790 = private constant [3 x i8] c"D8e"
@.d791 = private constant [1 x i8] c"'"
@.d792 = private constant [135 x i8] c"' is not a mode - the modes are build, compile, test, interpret, format, explain and help, and a file ending in .olang is built and run"
@.d793 = private constant [2 x i8] c"B1"
@.d794 = private constant [1 x i8] c"'"
@.d795 = private constant [56 x i8] c"' is no olang file to run - a file's name ends in .olang"
@.d796 = private constant [2 x i8] c"B1"
@.d797 = private constant [2 x i8] c"S3"
@.d798 = private constant [78 x i8] c"this computes a value and discards it - only a call, '++' or '--' stands alone"
@.d799 = private constant [50 x i8] c" is not an enum type, so it has no values 'T.Case'"
@.d800 = private constant [3 x i8] c"E22"
@.d801 = private constant [2 x i8] c"S4"
@.d802 = private constant [63 x i8] c"this cannot be written - a variable, an element or a member can"
@.d803 = private constant [40 x i8] c" is not a function, and declares no Call"
@.d804 = private constant [4 x i8] c"E13b"
@.d805 = private constant [42 x i8] c" does not extend its base, so it takes no "
@.d806 = private constant [22 x i8] c" - declare its method "
@.d807 = private constant [30 x i8] c", or declare it with 'extends'"
@.d808 = private constant [4 x i8] c"T29f"
@.d809 = private constant [13 x i8] c" declares no "
@.d810 = private constant [0 x i8] c""
@.d811 = private constant [18 x i8] c" cannot be indexed"
@.d812 = private constant [3 x i8] c"E16"
@.d813 = private constant [120 x i8] c" cannot be walked - 'for ... in' takes an array, a range, an iterator ('mut Next() T ? Exhausted') or a type with Iter()"
@.d814 = private constant [3 x i8] c"S9a"
@.d815 = private constant [0 x i8] c""
@.d816 = private constant [18 x i8] c"not a regular file"
@.d817 = private constant [17 x i8] c" cannot be sliced"
@.d818 = private constant [4 x i8] c"E16a"
@.d819 = private constant [3 x i8] c"'s "
@.d820 = private constant [7 x i8] c" takes "
@.d821 = private constant [56 x i8] c" besides its receiver - an ordinary method, not the one "
@.d822 = private constant [20 x i8] c" calls, which takes "
@.d823 = private constant [3 x i8] c"E31"
@.d824 = private constant [0 x i8] c""
@.d825 = private constant [111 x i8] c"this is the value that does not fit - each value a conditional or a match gives is stored as though alone (E28)"
@.d826 = private constant [1 x i8] c"'"
@.d827 = private constant [69 x i8] c"' is declared here, in a block that closes first - declare it where '"
@.d828 = private constant [10 x i8] c"' lives: '"
@.d829 = private constant [1 x i8] c" "
@.d830 = private constant [1 x i8] c"&"
@.d831 = private constant [7 x i8] c" = ...'"
@.d832 = private constant [0 x i8] c""
@.d833 = private constant [1 x i8] c"'"
@.d834 = private constant [43 x i8] c"' is declared read-only here - declare it '"
@.d835 = private constant [5 x i8] c" mut "
@.d836 = private constant [21 x i8] c"' to write through it"
@.d837 = private constant [0 x i8] c""
@.d838 = private constant [17 x i8] c" is declared here"
@.d839 = private constant [0 x i8] c""
@.d840 = private constant [102 x i8] c"a function type says where each reference argument and the result live, as the function does - write '"
@.d841 = private constant [30 x i8] c"', or pass a lambda calling it"
@.d842 = private constant [0 x i8] c""
@.d843 = private constant [0 x i8] c""
@.d844 = private constant [106 x i8] c"a function type of several results or error items is parenthesized whole in a list: '(fn(x I64) I64, I64)'"
@.d845 = private constant [103 x i8] c"the index is held here, for both the read and the write, in a block that closes first - make it where '"
@.d846 = private constant [33 x i8] c"' lives first, then index with it"
@.d847 = private constant [0 x i8] c""
@.d848 = private constant [0 x i8] c""
@.d849 = private constant [4 x i8] c"here"
@.d850 = private constant [0 x i8] c""
@.d851 = private constant [36 x i8] c"in the standard library's code, here"
@.d852 = private constant [1 x i8] c"'"
@.d853 = private constant [5 x i8] c"' is "
@.d854 = private constant [61 x i8] c", its literal's own type - declare the type it should have, '"
@.d855 = private constant [1 x i8] c" "
@.d856 = private constant [7 x i8] c" = ...'"
@.d857 = private constant [0 x i8] c""
@.d858 = private constant [27 x i8] c"the range's literals make '"
@.d859 = private constant [2 x i8] c"' "
@.d860 = private constant [10 x i8] c" - write '"
@.d861 = private constant [1 x i8] c"("
@.d862 = private constant [12 x i8] c")' here for "
@.d863 = private constant [7 x i8] c" values"
@.d864 = private constant [0 x i8] c""
@.d865 = private constant [27 x i8] c"the range's literals make '"
@.d866 = private constant [2 x i8] c"' "
@.d867 = private constant [21 x i8] c" - convert its end, '"
@.d868 = private constant [12 x i8] c"(...)', for "
@.d869 = private constant [7 x i8] c" values"
@.d870 = private constant [0 x i8] c""
@.d871 = private constant [1 x i8] c"'"
@.d872 = private constant [89 x i8] c"' is the loop's copy of an element, made in the loop's block - lend the element itself: '"
@.d873 = private constant [27 x i8] c"[i]', with 'for i in range "
@.d874 = private constant [7 x i8] c".Len()'"
@.d875 = private constant [0 x i8] c""
@.d876 = private constant [1 x i8] c"'"
@.d877 = private constant [185 x i8] c"' is the loop's copy of an element, in the loop's block - a call it is lent to by reference ties what it builds to that copy: take that parameter by value, or build from its fields here"
@.d878 = private constant [0 x i8] c""
@.d879 = private constant [1 x i8] c"'"
@.d880 = private constant [62 x i8] c"' is made here, in a block that closes first - make it where '"
@.d881 = private constant [10 x i8] c"' lives: '"
@.d882 = private constant [1 x i8] c"&"
@.d883 = private constant [6 x i8] c"(...)'"
@.d884 = private constant [0 x i8] c""
@.d885 = private constant [0 x i8] c""
@.d886 = private constant [48 x i8] c"the callee requires it because of this statement"
@.d887 = private constant [1 x i8] c"'"
@.d888 = private constant [42 x i8] c"' is declared here, with another signature"
@.d889 = private constant [0 x i8] c""
@.d890 = private constant [1 x i8] c"'"
@.d891 = private constant [46 x i8] c"' is private to its module, and only a public "
@.d892 = private constant [21 x i8] c" meets the constraint"
@.d893 = private constant [0 x i8] c""
@.d894 = private constant [1 x i8] c"'"
@.d895 = private constant [5 x i8] c"' is "
@.d896 = private constant [25 x i8] c"'s private spelling with "
@.d897 = private constant [41 x i8] c"'s parameters, so it is held to its shape"
@.d898 = private constant [0 x i8] c""
@.d899 = private constant [1 x i8] c"'"
@.d900 = private constant [54 x i8] c"' copies a place reached read-only, so it is read-only"
@.d901 = private constant [0 x i8] c""
@.d902 = private constant [1 x i8] c"'"
@.d903 = private constant [10 x i8] c"' copies '"
@.d904 = private constant [44 x i8] c"', reached read-only, so it is read-only - '"
@.d905 = private constant [4 x i8] c" := "
@.d906 = private constant [33 x i8] c".Clone()' would be one of its own"
@.d907 = private constant [0 x i8] c""
@.d908 = private constant [26 x i8] c"or refill the one kept - '"
@.d909 = private constant [53 x i8] c".Clear()', then put the elements in: one made where '"
@.d910 = private constant [77 x i8] c"' lives stays there, beside every one made before it, until that scope closes"
@.d911 = private constant [0 x i8] c""
@.d912 = private constant [0 x i8] c""
@.d913 = private constant [145 x i8] c"this borrows a value made here, which lives only in this block - make the value where the borrow is kept ('x T&c = ...'), then slice or view that"
@.d914 = private constant [0 x i8] c""
@.d915 = private constant [57 x i8] c"built here, where the receiver's part it was handed lives"
@.d916 = private constant [1 x i8] c"'"
@.d917 = private constant [24 x i8] c"' cannot be made where '"
@.d918 = private constant [106 x i8] c"' lives: a Str builds nothing where its receiver does - keep copies of what it reads instead of references"
@.d919 = private constant [0 x i8] c""
@.d920 = private constant [81 x i8] c"this text lives in a block that closes first - pass a copy, which is made where '"
@.d921 = private constant [28 x i8] c"' lives: write '$' before it"
@.d922 = private constant [0 x i8] c""
@.d923 = private constant [0 x i8] c""
@.d924 = private constant [118 x i8] c"the Vec grew here, after the view was taken; take the view after the growth, or copy the elements first: 'v.ToArray()'"
@.d925 = private constant [1 x i8] c"'"
@.d926 = private constant [20 x i8] c"' may grow here, in "
@.d927 = private constant [56 x i8] c" - take the view after it, or copy the elements first: '"
@.d928 = private constant [11 x i8] c".ToArray()'"
@.d929 = private constant [0 x i8] c""
@.d930 = private constant [17 x i8] c" may grow it here"
@.d931 = private constant [0 x i8] c""
@.d932 = private constant [28 x i8] c"the task holding a view of '"
@.d933 = private constant [17 x i8] c"' is started here"
@.d934 = private constant [0 x i8] c""
@.d935 = private constant [0 x i8] c""
@.d936 = private constant [62 x i8] c"the callee is no view of the element because of this statement"
@.d937 = private constant [1 x i8] c"'"
@.d938 = private constant [49 x i8] c"' holds it by reference, whose zero value is null"
@.d939 = private constant [0 x i8] c""
@.d940 = private constant [33 x i8] c"a reference has one, null - hold "
@.d941 = private constant [5 x i8] c" as '"
@.d942 = private constant [26 x i8] c"&' where this use names it"
@.d943 = private constant [0 x i8] c""
@.d944 = private constant [2 x i8] c"L1"
@.d945 = private constant [45 x i8] c"NUL byte in the source - is this a text file?"
@.d946 = private constant [20 x i8] c" does not flow into "
@.d947 = private constant [18 x i8] c" - convert it, as "
@.d948 = private constant [3 x i8] c"(x)"
@.d949 = private constant [3 x i8] c"T6b"
@.d950 = private constant [5 x i8] c" and "
@.d951 = private constant [56 x i8] c" do not meet - neither flows into the other; convert one"
@.d952 = private constant [3 x i8] c"T6b"
@.d953 = private constant [21 x i8] c" takes a Bool, found "
@.d954 = private constant [2 x i8] c"E7"
@.d955 = private constant [25 x i8] c" takes an integer, found "
@.d956 = private constant [2 x i8] c"E8"
@.d957 = private constant [22 x i8] c" takes numbers, found "
@.d958 = private constant [2 x i8] c"E6"
@.d959 = private constant [35 x i8] c" takes operands of one type, found "
@.d960 = private constant [5 x i8] c" and "
@.d961 = private constant [0 x i8] c""
@.d962 = private constant [20 x i8] c"this operator calls "
@.d963 = private constant [52 x i8] c", which can fail - write 'try' before the expression"
@.d964 = private constant [3 x i8] c"E31"
@.d965 = private constant [17 x i8] c" gives one result"
@.d966 = private constant [3 x i8] c"E31"
@.d967 = private constant [25 x i8] c" needs a value after it: "
@.d968 = private constant [2 x i8] c"B1"
@.d969 = private constant [12 x i8] c" applies to "
@.d970 = private constant [9 x i8] c", not to "
@.d971 = private constant [2 x i8] c"B1"
@.d972 = private constant [3 x i8] c"B3h"
@.d973 = private constant [15 x i8] c"cannot write it"
@.d974 = private constant [8 x i8] c"-output "
@.d975 = private constant [40 x i8] c" is a directory - name the file to write"
@.d976 = private constant [3 x i8] c"B3h"
@.d977 = private constant [8 x i8] c"-output "
@.d978 = private constant [24 x i8] c": there is no directory "
@.d979 = private constant [3 x i8] c"B3h"
@.d980 = private constant [91 x i8] c" does not have the signature of the default it overrides - match it, or choose another name"
@.d981 = private constant [4 x i8] c"M19e"
@.d982 = private constant [4 x i8] c"O10d"
@.d983 = private constant [65 x i8] c"this value lives in this function's own scope, which closes first"
@.d984 = private constant [4 x i8] c"O10d"
@.d985 = private constant [89 x i8] c"this value lives in this function's own scope, so it cannot satisfy anything longer-lived"
@.d986 = private constant [10 x i8] c"parameter "
@.d987 = private constant [7 x i8] c" holds "
@.d988 = private constant [70 x i8] c" bytes by value - a by-value parameter holds at most 128: take it as '"
@.d989 = private constant [2 x i8] c"&'"
@.d990 = private constant [3 x i8] c"D9c"
@.d991 = private constant [5 x i8] c"case "
@.d992 = private constant [7 x i8] c" holds "
@.d993 = private constant [64 x i8] c" fields, and a pattern names each - write '_' for one not wanted"
@.d994 = private constant [4 x i8] c"S13b"
@.d995 = private constant [31 x i8] c"a pattern here names a case of "
@.d996 = private constant [8 x i8] c", found "
@.d997 = private constant [4 x i8] c"S13b"
@.d998 = private constant [4 x i8] c"T17c"
@.d999 = private constant [106 x i8] c"this value's payload refers to storage the value would outlive - make that storage where the value is kept"
@.d1000 = private constant [4 x i8] c"T17c"
@.d1001 = private constant [101 x i8] c"this payload holds references into two scopes, and it lives in one - build what it holds in one scope"
@.d1002 = private constant [3 x i8] c"L12"
@.d1003 = private constant [38 x i8] c"a decimal point needs a digit after it"
@.d1004 = private constant [51 x i8] c" is a constant of the prelude - choose another name"
@.d1005 = private constant [3 x i8] c"D3a"
@.d1006 = private constant [4 x i8] c"T29d"
@.d1007 = private constant [106 x i8] c"only a type over a primitive has a constructor written this way - a struct writes 'struct(params) { ... }'"
@.d1008 = private constant [46 x i8] c"this constructor takes one parameter, of type "
@.d1009 = private constant [22 x i8] c" - the value it checks"
@.d1010 = private constant [4 x i8] c"T29d"
@.d1011 = private constant [10 x i8] c" declares "
@.d1012 = private constant [39 x i8] c" twice, public and private - keep one: "
@.d1013 = private constant [5 x i8] c", or "
@.d1014 = private constant [24 x i8] c" for its own module only"
@.d1015 = private constant [3 x i8] c"M6b"
@.d1016 = private constant [7 x i8] c" needs "
@.d1017 = private constant [3 x i8] c"'s "
@.d1018 = private constant [46 x i8] c", which is private to its module - declare it "
@.d1019 = private constant [15 x i8] c" to use it here"
@.d1020 = private constant [3 x i8] c"M6b"
@.d1021 = private constant [11 x i8] c"-quick and "
@.d1022 = private constant [41 x i8] c" each say how much to optimize - give one"
@.d1023 = private constant [3 x i8] c"B2g"
@.d1024 = private constant [46 x i8] c"a range's bounds and step are integers, found "
@.d1025 = private constant [3 x i8] c"S9b"
@.d1026 = private constant [3 x i8] c"S9b"
@.d1027 = private constant [51 x i8] c"a range only counts upward, so its step is positive"
@.d1028 = private constant [1 x i8] c"'"
@.d1029 = private constant [41 x i8] c"' writes through or keeps its parameter '"
@.d1030 = private constant [12 x i8] c"', and this "
@.d1031 = private constant [49 x i8] c" is a read-only copy - pass one of its own, made "
@.d1032 = private constant [4 x i8] c"T25c"
@.d1033 = private constant [24 x i8] c"this copies a read-only "
@.d1034 = private constant [134 x i8] c", and a written type declares a writable one - declare it with ':=' for a read-only copy, borrow it read-only, or make one of its own "
@.d1035 = private constant [4 x i8] c"T25c"
@.d1036 = private constant [46 x i8] c"a mutable global holds no copy of a read-only "
@.d1037 = private constant [32 x i8] c" - give it one of its own, made "
@.d1038 = private constant [19 x i8] c", or drop its 'mut'"
@.d1039 = private constant [4 x i8] c"T25c"
@.d1040 = private constant [86 x i8] c"a read-only copy cannot be passed where it may be written - pass one of its own, made "
@.d1041 = private constant [4 x i8] c"T25c"
@.d1042 = private constant [4 x i8] c"T25c"
@.d1043 = private constant [109 x i8] c"a reference a read-only copy holds is read-only - it cannot be passed or kept where it may be written through"
@.d1044 = private constant [22 x i8] c"a copy of a read-only "
@.d1045 = private constant [70 x i8] c" cannot be returned as a writable value - return one of its own, made "
@.d1046 = private constant [26 x i8] c", or a read-only reference"
@.d1047 = private constant [4 x i8] c"T25c"
@.d1048 = private constant [22 x i8] c"a copy of a read-only "
@.d1049 = private constant [71 x i8] c" cannot be stored where it can be written - store one of its own, made "
@.d1050 = private constant [4 x i8] c"T25c"
@.d1051 = private constant [4 x i8] c"T25c"
@.d1052 = private constant [117 x i8] c"this writes through a reference a read-only copy holds - a copy of a place reached read-only writes nothing it shares"
@.d1053 = private constant [49 x i8] c" writes through or keeps its by-value parameter '"
@.d1054 = private constant [110 x i8] c"', so it cannot be a function value - a caller of one may pass a read-only copy; work on one of its own, made "
@.d1055 = private constant [4 x i8] c"T25c"
@.d1056 = private constant [1 x i8] c"'"
@.d1057 = private constant [28 x i8] c"' keeps what its parameter '"
@.d1058 = private constant [44 x i8] c"' reaches where it can be written, and this "
@.d1059 = private constant [35 x i8] c" is read-only - pass a writable one"
@.d1060 = private constant [4 x i8] c"T25c"
@.d1061 = private constant [4 x i8] c"T25b"
@.d1062 = private constant [73 x i8] c"this writes through a read-only reference - one with no 'mut' in its type"
@.d1063 = private constant [90 x i8] c"a built result is new storage and writable, and this reference is read-only - borrow it: '"
@.d1064 = private constant [1 x i8] c"'"
@.d1065 = private constant [9 x i8] c"T25c, O14"
@.d1066 = private constant [9 x i8] c"T25c, O14"
@.d1067 = private constant [151 x i8] c"a built result is new storage and writable, and this reference is read-only - return a copy, or borrow the result from the parameter it is read through"
@.d1068 = private constant [4 x i8] c"T25c"
@.d1069 = private constant [85 x i8] c"a read-only reference cannot become writable - pass a writable one, or drop the 'mut'"
@.d1070 = private constant [13 x i8] c"re-exporting "
@.d1071 = private constant [26 x i8] c" reaches this module again"
@.d1072 = private constant [3 x i8] c"M17"
@.d1073 = private constant [25 x i8] c" cannot be held through '"
@.d1074 = private constant [43 x i8] c"&' - only a struct, an enum or an array can"
@.d1075 = private constant [3 x i8] c"G11"
@.d1076 = private constant [3 x i8] c"O25"
@.d1077 = private constant [98 x i8] c"a reference never narrows - keep its scope: name where it lives ('x T&y'), or declare it with ':='"
@.d1078 = private constant [29 x i8] c"a reference never narrows - '"
@.d1079 = private constant [62 x i8] c"' lives in a block that closes first, and this keeps it longer"
@.d1080 = private constant [3 x i8] c"O25"
@.d1081 = private constant [9 x i8] c"O25, O26a"
@.d1082 = private constant [158 x i8] c"this local flows into what the function returns, so it lives where the result goes - and its value lives elsewhere: make it here, or keep it out of the result"
@.d1083 = private constant [3 x i8] c"O14"
@.d1084 = private constant [86 x i8] c"this returns a parameter's data, and the result's bare '&' is built - borrow it: 'T&p'"
@.d1085 = private constant [22 x i8] c"this function returns "
@.d1086 = private constant [6 x i8] c" value"
@.d1087 = private constant [8 x i8] c", found "
@.d1088 = private constant [3 x i8] c"D8c"
@.d1089 = private constant [3 x i8] c"C2b"
@.d1090 = private constant [77 x i8] c"a constructor gives no value - its fields are the instance; fail with 'error'"
@.d1091 = private constant [3 x i8] c"D8e"
@.d1092 = private constant [89 x i8] c"a 'noreturn' function never returns - end this path with a noreturn call or 'unreachable'"
@.d1093 = private constant [3 x i8] c"S15"
@.d1094 = private constant [56 x i8] c"a test has no result - a bare 'return' ends it as passed"
@.d1095 = private constant [22 x i8] c"this function returns "
@.d1096 = private constant [27 x i8] c", so 'return' needs a value"
@.d1097 = private constant [2 x i8] c"D8"
@.d1098 = private constant [3 x i8] c"O26"
@.d1099 = private constant [98 x i8] c"this value refers to this function's own storage, which dies at the return - build it in '&return'"
@.d1100 = private constant [3 x i8] c"O26"
@.d1101 = private constant [60 x i8] c"'&return' names the result scope, and this function has none"
@.d1102 = private constant [22 x i8] c"this function returns "
@.d1103 = private constant [8 x i8] c", found "
@.d1104 = private constant [2 x i8] c"D8"
@.d1105 = private constant [2 x i8] c"D8"
@.d1106 = private constant [30 x i8] c"this function returns no value"
@.d1107 = private constant [3 x i8] c"E25"
@.d1108 = private constant [39 x i8] c"a call takes at most one scope argument"
@.d1109 = private constant [46 x i8] c" builds no result a scope argument could place"
@.d1110 = private constant [3 x i8] c"E25"
@.d1111 = private constant [100 x i8] c" lives in the program's scope, which a result reaches by being stored there, not by a scope argument"
@.d1112 = private constant [8 x i8] c"E25, O1b"
@.d1113 = private constant [81 x i8] c" is no local or parameter here - a scope argument names where the result is built"
@.d1114 = private constant [3 x i8] c"E25"
@.d1115 = private constant [4 x i8] c"O25e"
@.d1116 = private constant [79 x i8] c"these arguments live in different scopes, and the signature requires one ('&p')"
@.d1117 = private constant [2 x i8] c"O3"
@.d1118 = private constant [78 x i8] c"a scope has no name to declare - write a bare '&', or '&x' for where 'x' lives"
@.d1119 = private constant [3 x i8] c"O10"
@.d1120 = private constant [68 x i8] c"this reference lives in a scope that may not outlive where it is put"
@.d1121 = private constant [4 x i8] c"O10c"
@.d1122 = private constant [112 x i8] c"the callee needs one argument's scope to outlive another's, and nothing here shows it - pass them from one scope"
@.d1123 = private constant [3 x i8] c"L18"
@.d1124 = private constant [94 x i8] c"olang has no ';' - a statement ends where its line does; put the next one on a line of its own"
@.d1125 = private constant [3 x i8] c"E31"
@.d1126 = private constant [21 x i8] c"SetAt gives no result"
@.d1127 = private constant [48 x i8] c" declares At but not SetAt, which x[i] = v calls"
@.d1128 = private constant [3 x i8] c"E31"
@.d1129 = private constant [42 x i8] c" is a build constant - choose another name"
@.d1130 = private constant [3 x i8] c"D3a"
@.d1131 = private constant [83 x i8] c" names a function of this module - a name means one thing in it, so name this apart"
@.d1132 = private constant [3 x i8] c"D3a"
@.d1133 = private constant [66 x i8] c" is already declared in this module - a name means one thing in it"
@.d1134 = private constant [3 x i8] c"D3a"
@.d1135 = private constant [34 x i8] c" is a type's name - choose another"
@.d1136 = private constant [3 x i8] c"D3a"
@.d1137 = private constant [9 x i8] c"shifting "
@.d1138 = private constant [4 x i8] c" by "
@.d1139 = private constant [25 x i8] c" is outside its width of "
@.d1140 = private constant [5 x i8] c" bits"
@.d1141 = private constant [3 x i8] c"E8a"
@.d1142 = private constant [8 x i8] c"E8a, E4a"
@.d1143 = private constant [116 x i8] c"this shift is past its literal's width, and nothing adapts it to a wider type - convert the literal, as I64(1) << 40"
@.d1144 = private constant [37 x i8] c"a slice's bounds are integers, found "
@.d1145 = private constant [4 x i8] c"E16a"
@.d1146 = private constant [39 x i8] c"a slice with no end runs to Len(), and "
@.d1147 = private constant [9 x i8] c" has none"
@.d1148 = private constant [3 x i8] c"E31"
@.d1149 = private constant [4 x i8] c"O17a"
@.d1150 = private constant [143 x i8] c"this value's references live where its own storage does not, so it is not sliced or viewed - index the value itself, or lend it whole to a call"
@.d1151 = private constant [2 x i8] c"P2"
@.d1152 = private constant [108 x i8] c"this argument refers to storage that closes before the join does - declare that at the join's level or wider"
@.d1153 = private constant [2 x i8] c"P2"
@.d1154 = private constant [93 x i8] c"this argument's storage closes before the join does - declare it at the join's level or wider"
@.d1155 = private constant [8 x i8] c"E31b, P2"
@.d1156 = private constant [173 x i8] c"a task is not handed x[i]: the element is copied here, and the copy would not last until the join - spawn a function that takes the collection and calls 'x[i].M(...)' itself"
@.d1157 = private constant [8 x i8] c"P2, D16e"
@.d1158 = private constant [93 x i8] c"this lambda captures a variable declared inside the join, which closes while the task may run"
@.d1159 = private constant [2 x i8] c"P4"
@.d1160 = private constant [89 x i8] c"this call can fail - write 'spawn try', and what its clauses do not take reaches the join"
@.d1161 = private constant [8 x i8] c"P2, D16e"
@.d1162 = private constant [93 x i8] c"this function value closes before the join does - make it outside, or spawn the lambda itself"
@.d1163 = private constant [9 x i8] c"S19b, P1a"
@.d1164 = private constant [66 x i8] c"a spawn in deferred code needs a join written in the deferred code"
@.d1165 = private constant [4 x i8] c"D16e"
@.d1166 = private constant [64 x i8] c"a spawned lambda takes no parameters - it captures what it needs"
@.d1167 = private constant [2 x i8] c"P1"
@.d1168 = private constant [20 x i8] c"'spawn' takes a call"
@.d1169 = private constant [2 x i8] c"P1"
@.d1170 = private constant [66 x i8] c"'spawn' is written inside a 'join' block, which waits for the task"
@.d1171 = private constant [43 x i8] c"a spawn target has exactly the call's type "
@.d1172 = private constant [8 x i8] c", found "
@.d1173 = private constant [12 x i8] c" - declare '"
@.d1174 = private constant [10 x i8] c"' to give "
@.d1175 = private constant [30 x i8] c", built where its result lands"
@.d1176 = private constant [3 x i8] c"P1g"
@.d1177 = private constant [3 x i8] c"P1g"
@.d1178 = private constant [81 x i8] c"this target closes before the join does - declare it at the join's level or wider"
@.d1179 = private constant [43 x i8] c"a spawn target has exactly the call's type "
@.d1180 = private constant [8 x i8] c", found "
@.d1181 = private constant [25 x i8] c" - convert after the join"
@.d1182 = private constant [3 x i8] c"P1g"
@.d1183 = private constant [3 x i8] c"P1g"
@.d1184 = private constant [51 x i8] c"this call returns nothing to bind - drop the target"
@.d1185 = private constant [3 x i8] c"P1g"
@.d1186 = private constant [72 x i8] c"these targets live in different scopes, and the results are built in one"
@.d1187 = private constant [2 x i8] c"P4"
@.d1188 = private constant [38 x i8] c"this task cannot fail - drop the 'try'"
@.d1189 = private constant [3 x i8] c"D8d"
@.d1190 = private constant [107 x i8] c"these results are passed as the arguments, so there must be as many - destructure them first: 'a, b := g()'"
@.d1191 = private constant [3 x i8] c"O12"
@.d1192 = private constant [146 x i8] c"where this place's references live is not known here, so nothing new is built into it - store what already lives there, or give it one known scope"
@.d1193 = private constant [3 x i8] c"O20"
@.d1194 = private constant [101 x i8] c"the container outlives what this refers to - build it where the container lives ('x T&c', 'f&c(...)')"
@.d1195 = private constant [4 x i8] c"E11a"
@.d1196 = private constant [54 x i8] c"'$' has nothing to render - this call returns no value"
@.d1197 = private constant [10 x i8] c"E11c, T25c"
@.d1198 = private constant [98 x i8] c"'$' renders read-only values too, so Str only reads its receiver - pass on what it holds read-only"
@.d1199 = private constant [4 x i8] c"E11c"
@.d1200 = private constant [18 x i8] c"Str gives a String"
@.d1201 = private constant [9 x i8] c"E11c, O12"
@.d1202 = private constant [148 x i8] c"'$' does not say where a value it renders lives, so Str builds and stores nothing where its receiver reaches - read it, and build what it needs here"
@.d1203 = private constant [3 x i8] c"L14"
@.d1204 = private constant [62 x i8] c"string literal not closed on its line - write \5Cn for a newline"
@.d1205 = private constant [6 x i8] c"where "
@.d1206 = private constant [81 x i8] c" lives is not known here, so nothing is declared to live there - read it through "
@.d1207 = private constant [32 x i8] c", or declare the local with ':='"
@.d1208 = private constant [3 x i8] c"O12"
@.d1209 = private constant [19 x i8] c" takes no arguments"
@.d1210 = private constant [3 x i8] c"E14"
@.d1211 = private constant [47 x i8] c" builds and runs on this machine, and '-target "
@.d1212 = private constant [64 x i8] c"' is another architecture or system - only compile builds for it"
@.d1213 = private constant [4 x i8] c"B12a"
@.d1214 = private constant [3 x i8] c"B12"
@.d1215 = private constant [55 x i8] c"-target needs a target after it, as '-target x86-64-v3'"
@.d1216 = private constant [9 x i8] c"'-target "
@.d1217 = private constant [102 x i8] c"': native is this machine's CPU - name the other architecture's CPU after ':', or none for its default"
@.d1218 = private constant [3 x i8] c"B12"
@.d1219 = private constant [29 x i8] c"this clang cannot build for '"
@.d1220 = private constant [85 x i8] c"': its back end for that architecture cannot generate the BF16 code the runtime holds"
@.d1221 = private constant [4 x i8] c"B12a"
@.d1222 = private constant [84 x i8] c"clang not found on PATH - it is what builds the program, and what says what target '"
@.d1223 = private constant [4 x i8] c"' is"
@.d1224 = private constant [3 x i8] c"B12"
@.d1225 = private constant [16 x i8] c"unknown target '"
@.d1226 = private constant [187 x i8] c"' - write native, x86-64, x86-64-v2, x86-64-v3, x86-64-v4, a CPU clang knows ('clang --print-supported-cpus'), or a triple x86_64-linux-gnu or aarch64-linux-gnu, ':CPU' after it if wanted"
@.d1227 = private constant [3 x i8] c"B12"
@.d1228 = private constant [26 x i8] c"olang does not build for '"
@.d1229 = private constant [65 x i8] c"' - it builds for x86_64 and aarch64 Linux with the GNU C library"
@.d1230 = private constant [3 x i8] c"B12"
@.d1231 = private constant [3 x i8] c"P4a"
@.d1232 = private constant [106 x i8] c"an error may not leave a task's clause - catch it here; the task lets through what its clauses do not take"
@.d1233 = private constant [81 x i8] c" may not leave a task's clause - it runs on the task, outside the spawner's loops"
@.d1234 = private constant [3 x i8] c"P4a"
@.d1235 = private constant [3 x i8] c"P4a"
@.d1236 = private constant [107 x i8] c"this clause takes an error the targets would get no value for - end it with 'default v', or end the process"
@.d1237 = private constant [3 x i8] c"P4a"
@.d1238 = private constant [82 x i8] c"a task's clause runs on the task and may not return - it ends where its block does"
@.d1239 = private constant [3 x i8] c"P4a"
@.d1240 = private constant [118 x i8] c"a task's default is built where its result lands, and this names existing storage - build the value here, or give null"
@.d1241 = private constant [3 x i8] c"P4a"
@.d1242 = private constant [70 x i8] c"a spawn without targets gives no value, so its clauses take no default"
@.d1243 = private constant [15 x i8] c"a comma before "
@.d1244 = private constant [30 x i8] c" separates nothing - remove it"
@.d1245 = private constant [4 x i8] c"L18a"
@.d1246 = private constant [3 x i8] c"R1b"
@.d1247 = private constant [83 x i8] c"a trait's method writes its error set - '? IoError' - since no body says what it is"
@.d1248 = private constant [13 x i8] c"trait method "
@.d1249 = private constant [40 x i8] c" may not be generic in a type of its own"
@.d1250 = private constant [3 x i8] c"T35"
@.d1251 = private constant [72 x i8] c" is a trait - a constraint on a type variable, never the type of a value"
@.d1252 = private constant [3 x i8] c"T30"
@.d1253 = private constant [3 x i8] c"R10"
@.d1254 = private constant [114 x i8] c"a try statement discards its value, leaving a slice nothing - write 's := try a[lo:hi]' and catch where it is used"
@.d1255 = private constant [87 x i8] c" can escape here, and this function does not declare it - add it after '?', or catch it"
@.d1256 = private constant [2 x i8] c"R9"
@.d1257 = private constant [39 x i8] c"'checked c[i]' checks against Len, and "
@.d1258 = private constant [30 x i8] c" has neither CheckedAt nor Len"
@.d1259 = private constant [4 x i8] c"E31a"
@.d1260 = private constant [35 x i8] c"'checked' on several indices needs "
@.d1261 = private constant [12 x i8] c" to declare "
@.d1262 = private constant [47 x i8] c" - a check derived from Len checks one position"
@.d1263 = private constant [4 x i8] c"E31a"
@.d1264 = private constant [42 x i8] c"nothing here can fail - write it without '"
@.d1265 = private constant [1 x i8] c"'"
@.d1266 = private constant [2 x i8] c"R8"
@.d1267 = private constant [3 x i8] c"R13"
@.d1268 = private constant [65 x i8] c"an error tried here has nowhere to go - catch every one it can be"
@.d1269 = private constant [4 x i8] c"E15a"
@.d1270 = private constant [59 x i8] c"nothing here fails as written - write 'checked' to check it"
@.d1271 = private constant [43 x i8] c"'checked c[i] = v' checks against Len, and "
@.d1272 = private constant [33 x i8] c" has neither CheckedSetAt nor Len"
@.d1273 = private constant [4 x i8] c"E31a"
@.d1274 = private constant [43 x i8] c"'checked c[lo:hi]' checks against Len, and "
@.d1275 = private constant [33 x i8] c" has neither CheckedSlice nor Len"
@.d1276 = private constant [4 x i8] c"E31a"
@.d1277 = private constant [3 x i8] c"D8c"
@.d1278 = private constant [111 x i8] c"several results are not one value - destructure them ('a, b := f()'), or pass them as all of a call's arguments"
@.d1279 = private constant [3 x i8] c"L12"
@.d1280 = private constant [38 x i8] c"a number has at most one decimal point"
@.d1281 = private constant [19 x i8] c"type arguments for "
@.d1282 = private constant [11 x i8] c": expected "
@.d1283 = private constant [8 x i8] c", found "
@.d1284 = private constant [2 x i8] c"G7"
@.d1285 = private constant [3 x i8] c"G11"
@.d1286 = private constant [101 x i8] c"a type argument's reference marker is bare, as 'List<String&>' - its references live in the container"
@.d1287 = private constant [22 x i8] c"the type arguments of "
@.d1288 = private constant [40 x i8] c" cannot be inferred from these arguments"
@.d1289 = private constant [2 x i8] c"G9"
@.d1290 = private constant [46 x i8] c" is not generic, so it takes no type arguments"
@.d1291 = private constant [2 x i8] c"G7"
@.d1292 = private constant [41 x i8] c" is used while it is still being declared"
@.d1293 = private constant [0 x i8] c""
@.d1294 = private constant [5 x i8] c"type "
@.d1295 = private constant [52 x i8] c" has no constructor - an enum's values are its cases"
@.d1296 = private constant [0 x i8] c""
@.d1297 = private constant [64 x i8] c" cannot hold itself by value - hold it through a reference ('&')"
@.d1298 = private constant [3 x i8] c"T16"
@.d1299 = private constant [5 x i8] c"type "
@.d1300 = private constant [25 x i8] c" is private to its module"
@.d1301 = private constant [2 x i8] c"M6"
@.d1302 = private constant [4 x i8] c"S13e"
@.d1303 = private constant [100 x i8] c"a type match chooses its case while compiling, so it takes no guard - test the value inside the case"
@.d1304 = private constant [15 x i8] c"no case covers "
@.d1305 = private constant [65 x i8] c", which this generic is instantiated with - add one, or 'nomatch'"
@.d1306 = private constant [3 x i8] c"G15"
@.d1307 = private constant [43 x i8] c" is a type variable, so its cases are types"
@.d1308 = private constant [3 x i8] c"G13"
@.d1309 = private constant [9 x i8] c"expected "
@.d1310 = private constant [8 x i8] c", found "
@.d1311 = private constant [3 x i8] c"E12"
@.d1312 = private constant [5 x i8] c"type "
@.d1313 = private constant [35 x i8] c" is already declared in this module"
@.d1314 = private constant [2 x i8] c"D2"
@.d1315 = private constant [23 x i8] c" is a type, not a value"
@.d1316 = private constant [0 x i8] c""
@.d1317 = private constant [3 x i8] c"D15"
@.d1318 = private constant [79 x i8] c"':=' takes its type from the initializer, and a call returning nothing has none"
@.d1319 = private constant [32 x i8] c" is a type variable, not a value"
@.d1320 = private constant [3 x i8] c"G8b"
@.d1321 = private constant [14 x i8] c"type variable "
@.d1322 = private constant [60 x i8] c" is named after a type - choose a name no type has, as '<T>'"
@.d1323 = private constant [2 x i8] c"G1"
@.d1324 = private constant [14 x i8] c"type variable "
@.d1325 = private constant [93 x i8] c" appears in no parameter's type, so no call can infer it - introduce it in a parameter's type"
@.d1326 = private constant [2 x i8] c"G4"
@.d1327 = private constant [3 x i8] c"G17"
@.d1328 = private constant [72 x i8] c"this generic's instantiations never end - each one requires a larger one"
@.d1329 = private constant [3 x i8] c"L13"
@.d1330 = private constant [30 x i8] c"unterminated character literal"
@.d1331 = private constant [3 x i8] c"L4a"
@.d1332 = private constant [43 x i8] c"unterminated block comment - '##' closes it"
@.d1333 = private constant [3 x i8] c"L14"
@.d1334 = private constant [27 x i8] c"unterminated string literal"
@.d1335 = private constant [3 x i8] c"D8c"
@.d1336 = private constant [64 x i8] c"'_' discards a value and names nothing, so it cannot be declared"
@.d1337 = private constant [3 x i8] c"E15"
@.d1338 = private constant [65 x i8] c"this call can fail - write 'try', and catch or pass on its errors"
@.d1339 = private constant [13 x i8] c"unknown name "
@.d1340 = private constant [54 x i8] c" - if it is a build constant, define it with '-define "
@.d1341 = private constant [37 x i8] c"=VALUE', or declare it with a default"
@.d1342 = private constant [3 x i8] c"B10"
@.d1343 = private constant [22 x i8] c"unexpected character '"
@.d1344 = private constant [1 x i8] c"'"
@.d1345 = private constant [3 x i8] c"L16"
@.d1346 = private constant [19 x i8] c"unknown error type "
@.d1347 = private constant [2 x i8] c"R1"
@.d1348 = private constant [16 x i8] c"unknown option '"
@.d1349 = private constant [38 x i8] c"' - 'olang help' lists the options of "
@.d1350 = private constant [2 x i8] c"B1"
@.d1351 = private constant [25 x i8] c"unknown function or type "
@.d1352 = private constant [0 x i8] c""
@.d1353 = private constant [25 x i8] c"unknown function or type "
@.d1354 = private constant [17 x i8] c" - did you mean '"
@.d1355 = private constant [2 x i8] c"'?"
@.d1356 = private constant [0 x i8] c""
@.d1357 = private constant [18 x i8] c" is no import here"
@.d1358 = private constant [3 x i8] c"M10"
@.d1359 = private constant [46 x i8] c" is no import here - std has it: 'import \22std/"
@.d1360 = private constant [2 x i8] c"\22'"
@.d1361 = private constant [3 x i8] c"M10"
@.d1362 = private constant [15 x i8] c" has no method "
@.d1363 = private constant [3 x i8] c"M19"
@.d1364 = private constant [13 x i8] c"unknown name "
@.d1365 = private constant [0 x i8] c""
@.d1366 = private constant [13 x i8] c"unknown name "
@.d1367 = private constant [17 x i8] c" - did you mean '"
@.d1368 = private constant [2 x i8] c"'?"
@.d1369 = private constant [0 x i8] c""
@.d1370 = private constant [13 x i8] c"unknown type "
@.d1371 = private constant [58 x i8] c" - the numbers are named by kind and width: did you mean '"
@.d1372 = private constant [2 x i8] c"'?"
@.d1373 = private constant [2 x i8] c"T4"
@.d1374 = private constant [83 x i8] c" names no variable visible here - a marker names where the reference lives, as '&x'"
@.d1375 = private constant [3 x i8] c"O4a"
@.d1376 = private constant [13 x i8] c"unknown type "
@.d1377 = private constant [0 x i8] c""
@.d1378 = private constant [13 x i8] c"unknown type "
@.d1379 = private constant [17 x i8] c" - did you mean '"
@.d1380 = private constant [2 x i8] c"'?"
@.d1381 = private constant [0 x i8] c""
@.d1382 = private constant [22 x i8] c"unknown type variable "
@.d1383 = private constant [0 x i8] c""
@.d1384 = private constant [2 x i8] c"B1"
@.d1385 = private constant [105 x i8] c"nothing to do - write a file to build and run, as 'olang main.olang', or a mode ('olang help' lists them)"
@.d1386 = private constant [43 x i8] c"a declaration's value follows '=' - write '"
@.d1387 = private constant [3 x i8] c" = "
@.d1388 = private constant [7 x i8] c"', or '"
@.d1389 = private constant [4 x i8] c" := "
@.d1390 = private constant [1 x i8] c"'"
@.d1391 = private constant [3 x i8] c"D12"
@.d1392 = private constant [4 x i8] c"O25h"
@.d1393 = private constant [91 x i8] c"this value holds references into a scope the target outlives - build it where the target is"
@.d1394 = private constant [25 x i8] c" is private to its module"
@.d1395 = private constant [2 x i8] c"M6"
@.d1396 = private constant [34 x i8] c" names need as many values, found "
@.d1397 = private constant [4 x i8] c"D12b"
@.d1398 = private constant [1 x i8] c"'"
@.d1399 = private constant [73 x i8] c"' may grow here while a task holds a view of it - give the task a copy: '"
@.d1400 = private constant [11 x i8] c".ToArray()'"
@.d1401 = private constant [4 x i8] c"M19g"
@.d1402 = private constant [22 x i8] c"this reads a view of '"
@.d1403 = private constant [16 x i8] c"' taken before '"
@.d1404 = private constant [16 x i8] c"' may have grown"
@.d1405 = private constant [4 x i8] c"M19g"
@.d1406 = private constant [14 x i8] c"this view of '"
@.d1407 = private constant [14 x i8] c"' is given to "
@.d1408 = private constant [18 x i8] c", which may grow '"
@.d1409 = private constant [30 x i8] c"' - copy the elements first: '"
@.d1410 = private constant [11 x i8] c".ToArray()'"
@.d1411 = private constant [4 x i8] c"M19g"
@.d1412 = private constant [1 x i8] c"'"
@.d1413 = private constant [19 x i8] c"' holds a view of '"
@.d1414 = private constant [16 x i8] c"' taken before '"
@.d1415 = private constant [16 x i8] c"' may have grown"
@.d1416 = private constant [4 x i8] c"M19g"
@.d1417 = private constant [4 x i8] c"S13f"
@.d1418 = private constant [61 x i8] c"'_' matches every value, so it is its case's only alternative"
@.d1419 = private constant [3 x i8] c"E31"
@.d1420 = private constant [98 x i8] c"this writes into a value a call gave back, a copy no one holds - store the whole element: x[i] = v"
@.d1421 = private constant [8 x i8] c"E31, O17"
@.d1422 = private constant [171 x i8] c"x[i] gives a copy, and the call can build into what it holds where the copy is - hold the elements by reference, or copy it where the collection lives ('t mut T&l = l[i]')"
@.d1423 = private constant [4 x i8] c"E31b"
@.d1424 = private constant [196 x i8] c"x[i] gives a copy of the element, which this call would write while it can reach the collection another way - write 't := x[i]', the call on 't', then 'x[i] = t', or hold the elements by reference"
@.d1425 = private constant [28 x i8] c"this writes through x[i] on "
@.d1426 = private constant [95 x i8] c", which declares At but not SetAt - the copy At gives back is never written back; declare SetAt"
@.d1427 = private constant [3 x i8] c"E31"
@.d1428 = private constant [93 x i8] c"'s zero value holds references, which a fill would share - give a fill, or build the elements"
@.d1429 = private constant [4 x i8] c"D13c"
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2eU8_2eFormat(ptr %v0, i8 %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i8 %a2)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
