; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
@G_2ecompiler_2fmsgs_2eEndOfFile = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\0B\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fmsgs_2eEndOfFile.k1 }>, align 8
@G_2ecompiler_2fmsgs_2eEndOfFile.k1 = internal global <{ [11 x i8] }> <{ [11 x i8] c"\65\6E\64\20\6F\66\20\66\69\6C\65" }>, align 8
@G_2ecompiler_2fmsgs_2eEndOfLine = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\0B\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fmsgs_2eEndOfLine.k1 }>, align 8
@G_2ecompiler_2fmsgs_2eEndOfLine.k1 = internal global <{ [11 x i8] }> <{ [11 x i8] c"\65\6E\64\20\6F\66\20\6C\69\6E\65" }>, align 8
define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAltBindsOtherNames(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 489, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d0, i32 0, i32 1) }, { i64, ptr } { i64 86, ptr getelementptr inbounds (<{ i64, [86 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyCaseAlone(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 180, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d2, i32 0, i32 1) }, { i64, ptr } { i64 88, ptr getelementptr inbounds (<{ i64, [88 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyCaseNotAny(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 181, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d5, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyCopyOutlived(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 169, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d6, i32 0, i32 1) }, { i64, ptr } { i64 109, ptr getelementptr inbounds (<{ i64, [109 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyNeedsMarker(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 167, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d10, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyNotConverted(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 55, ptr getelementptr inbounds (<{ i64, [55 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 55, ptr getelementptr inbounds (<{ i64, [55 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 168, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d14, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyNotMember(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l10 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t12 = extractvalue { i64, ptr } %t2, 1
  %t13 = extractvalue { i64, ptr } %t2, 0
  %t14 = add i64 %t10, %t13
  %t15 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t19 = extractvalue { i64, ptr } %t3, 1
  %t20 = extractvalue { i64, ptr } %t3, 0
  %t21 = add i64 %t17, %t20
  %t22 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t24 = add i64 %t21, %t23
  %t26 = extractvalue { i64, ptr } %a2, 1
  %t27 = extractvalue { i64, ptr } %a2, 0
  %t28 = add i64 %t24, %t27
  %t29 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t30 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t31 = add i64 %t28, %t30
  %t32 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t31)
  call void @olang_textcopy(ptr %t32, ptr %t6, i64 %t7)
  %t33 = getelementptr i8, ptr %t32, i64 %t7
  call void @olang_textcopy(ptr %t33, ptr %t8, i64 %t9)
  %t34 = getelementptr i8, ptr %t33, i64 %t9
  call void @olang_textcopy(ptr %t34, ptr %t12, i64 %t13)
  %t35 = getelementptr i8, ptr %t34, i64 %t13
  call void @olang_textcopy(ptr %t35, ptr %t15, i64 %t16)
  %t36 = getelementptr i8, ptr %t35, i64 %t16
  call void @olang_textcopy(ptr %t36, ptr %t19, i64 %t20)
  %t37 = getelementptr i8, ptr %t36, i64 %t20
  call void @olang_textcopy(ptr %t37, ptr %t22, i64 %t23)
  %t38 = getelementptr i8, ptr %t37, i64 %t23
  call void @olang_textcopy(ptr %t38, ptr %t26, i64 %t27)
  %t39 = getelementptr i8, ptr %t38, i64 %t27
  call void @olang_textcopy(ptr %t39, ptr %t29, i64 %t30)
  %t40 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t32, 1
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t44 = extractvalue { i64, ptr } %t41, 1
  %t45 = mul i64 %t43, 1
  %t46 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t45)
  call void @llvm.memcpy.p0.p0.i64(ptr %t46, ptr %t44, i64 %t45, i1 false)
  %t47 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  %t51 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 172, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d19, i32 0, i32 1) }, { i64, ptr } %t48)
  store %"compiler/msgs:Msg" %t51, ptr %l10
  br label %bb1
bb1:
  %t52 = load %"compiler/msgs:Msg", ptr %l10
  store %"compiler/msgs:Msg" %t52, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyNotMemberCase(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 178, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d22, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyNotTrait(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 166, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d25, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyOpenInspected(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 97, ptr getelementptr inbounds (<{ i64, [97 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 97, ptr getelementptr inbounds (<{ i64, [97 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 177, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d28, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnySpawnedResult(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } { i64 91, ptr getelementptr inbounds (<{ i64, [91 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 91, ptr getelementptr inbounds (<{ i64, [91 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  %t12 = add i64 %t9, %t11
  %t14 = extractvalue { i64, ptr } %a1, 1
  %t15 = extractvalue { i64, ptr } %a1, 0
  %t16 = add i64 %t12, %t15
  %t17 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t19 = add i64 %t16, %t18
  %t21 = extractvalue { i64, ptr } %a2, 1
  %t22 = extractvalue { i64, ptr } %a2, 0
  %t23 = add i64 %t19, %t22
  %t24 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t25 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t26 = add i64 %t23, %t25
  %t27 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t4, i64 %t5)
  %t28 = getelementptr i8, ptr %t27, i64 %t5
  call void @olang_textcopy(ptr %t28, ptr %t7, i64 %t8)
  %t29 = getelementptr i8, ptr %t28, i64 %t8
  call void @olang_textcopy(ptr %t29, ptr %t10, i64 %t11)
  %t30 = getelementptr i8, ptr %t29, i64 %t11
  call void @olang_textcopy(ptr %t30, ptr %t14, i64 %t15)
  %t31 = getelementptr i8, ptr %t30, i64 %t15
  call void @olang_textcopy(ptr %t31, ptr %t17, i64 %t18)
  %t32 = getelementptr i8, ptr %t31, i64 %t18
  call void @olang_textcopy(ptr %t32, ptr %t21, i64 %t22)
  %t33 = getelementptr i8, ptr %t32, i64 %t22
  call void @olang_textcopy(ptr %t33, ptr %t24, i64 %t25)
  %t34 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t27, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = extractvalue { i64, ptr } %t35, 1
  %t39 = mul i64 %t37, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t39)
  call void @llvm.memcpy.p0.p0.i64(ptr %t40, ptr %t38, i64 %t39, i1 false)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  %t45 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 183, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d33, i32 0, i32 1) }, { i64, ptr } %t42)
  store %"compiler/msgs:Msg" %t45, ptr %l9
  br label %bb1
bb1:
  %t46 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t46, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyUnmet(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l8 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  %t9 = add i64 %t6, %t8
  %t11 = extractvalue { i64, ptr } %t2, 1
  %t12 = extractvalue { i64, ptr } %t2, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t18 = extractvalue { i64, ptr } %t3, 1
  %t19 = extractvalue { i64, ptr } %t3, 0
  %t20 = add i64 %t16, %t19
  %t21 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t20)
  call void @olang_textcopy(ptr %t21, ptr %t5, i64 %t6)
  %t22 = getelementptr i8, ptr %t21, i64 %t6
  call void @olang_textcopy(ptr %t22, ptr %t7, i64 %t8)
  %t23 = getelementptr i8, ptr %t22, i64 %t8
  call void @olang_textcopy(ptr %t23, ptr %t11, i64 %t12)
  %t24 = getelementptr i8, ptr %t23, i64 %t12
  call void @olang_textcopy(ptr %t24, ptr %t14, i64 %t15)
  %t25 = getelementptr i8, ptr %t24, i64 %t15
  call void @olang_textcopy(ptr %t25, ptr %t18, i64 %t19)
  %t26 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t21, 1
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t30 = extractvalue { i64, ptr } %t27, 1
  %t31 = mul i64 %t29, 1
  %t32 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t31)
  call void @llvm.memcpy.p0.p0.i64(ptr %t32, ptr %t30, i64 %t31, i1 false)
  %t33 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  %t37 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 170, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d36, i32 0, i32 1) }, { i64, ptr } %t34)
  store %"compiler/msgs:Msg" %t37, ptr %l8
  br label %bb1
bb1:
  %t38 = load %"compiler/msgs:Msg", ptr %l8
  store %"compiler/msgs:Msg" %t38, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCount(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t7 = call i64 @__olang_fmt_i64(ptr null, i64 %a0)
  %t8 = add i64 %t5, %t7
  %t9 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t20 = call i64 @__olang_fmt_i64(ptr null, i64 %a2)
  %t21 = add i64 %t18, %t20
  %t22 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t21)
  call void @olang_textcopy(ptr %t22, ptr %t4, i64 %t5)
  %t23 = getelementptr i8, ptr %t22, i64 %t5
  %t24 = call i64 @__olang_fmt_i64(ptr %t23, i64 %a0)
  %t25 = getelementptr i8, ptr %t23, i64 %t7
  call void @olang_textcopy(ptr %t25, ptr %t9, i64 %t10)
  %t26 = getelementptr i8, ptr %t25, i64 %t10
  call void @olang_textcopy(ptr %t26, ptr %t13, i64 %t14)
  %t27 = getelementptr i8, ptr %t26, i64 %t14
  call void @olang_textcopy(ptr %t27, ptr %t16, i64 %t17)
  %t28 = getelementptr i8, ptr %t27, i64 %t17
  %t29 = call i64 @__olang_fmt_i64(ptr %t28, i64 %a2)
  %t30 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t22, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t41 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 293, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d40, i32 0, i32 1) }, { i64, ptr } %t38)
  store %"compiler/msgs:Msg" %t41, ptr %l9
  br label %bb1
bb1:
  %t42 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t42, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayByValueRunTime(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l8 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = extractvalue { i64, ptr } { i64 78, ptr getelementptr inbounds (<{ i64, [78 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 78, ptr getelementptr inbounds (<{ i64, [78 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  %t9 = add i64 %t6, %t8
  %t11 = extractvalue { i64, ptr } %t2, 1
  %t12 = extractvalue { i64, ptr } %t2, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t18 = extractvalue { i64, ptr } %t3, 1
  %t19 = extractvalue { i64, ptr } %t3, 0
  %t20 = add i64 %t16, %t19
  %t21 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t23 = add i64 %t20, %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t5, i64 %t6)
  %t25 = getelementptr i8, ptr %t24, i64 %t6
  call void @olang_textcopy(ptr %t25, ptr %t7, i64 %t8)
  %t26 = getelementptr i8, ptr %t25, i64 %t8
  call void @olang_textcopy(ptr %t26, ptr %t11, i64 %t12)
  %t27 = getelementptr i8, ptr %t26, i64 %t12
  call void @olang_textcopy(ptr %t27, ptr %t14, i64 %t15)
  %t28 = getelementptr i8, ptr %t27, i64 %t15
  call void @olang_textcopy(ptr %t28, ptr %t18, i64 %t19)
  %t29 = getelementptr i8, ptr %t28, i64 %t19
  call void @olang_textcopy(ptr %t29, ptr %t21, i64 %t22)
  %t30 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t24, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t41 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 152, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d44, i32 0, i32 1) }, { i64, ptr } %t38)
  store %"compiler/msgs:Msg" %t41, ptr %l8
  br label %bb1
bb1:
  %t42 = load %"compiler/msgs:Msg", ptr %l8
  store %"compiler/msgs:Msg" %t42, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayLengthNotInt(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 461, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d46, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayOfErrors(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 450, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d48, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayOneIndex(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 61, ptr getelementptr inbounds (<{ i64, [61 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 61, ptr getelementptr inbounds (<{ i64, [61 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 223, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d50, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayRunTimeIntoFixed(ptr %v0, i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l6 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t2 = load i64, ptr %l0, !tbaa !24
  %t3 = extractvalue { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  %t6 = call i64 @__olang_fmt_i64(ptr null, i64 %t1)
  %t7 = add i64 %t4, %t6
  %t8 = extractvalue { i64, ptr } { i64 72, ptr getelementptr inbounds (<{ i64, [72 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 72, ptr getelementptr inbounds (<{ i64, [72 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t12 = call i64 @__olang_fmt_i64(ptr null, i64 %t2)
  %t13 = add i64 %t10, %t12
  %t14 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d53, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d53, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t17 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t16)
  call void @olang_textcopy(ptr %t17, ptr %t3, i64 %t4)
  %t18 = getelementptr i8, ptr %t17, i64 %t4
  %t19 = call i64 @__olang_fmt_i64(ptr %t18, i64 %t1)
  %t20 = getelementptr i8, ptr %t18, i64 %t6
  call void @olang_textcopy(ptr %t20, ptr %t8, i64 %t9)
  %t21 = getelementptr i8, ptr %t20, i64 %t9
  %t22 = call i64 @__olang_fmt_i64(ptr %t21, i64 %t2)
  %t23 = getelementptr i8, ptr %t21, i64 %t12
  call void @olang_textcopy(ptr %t23, ptr %t14, i64 %t15)
  %t24 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t17, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 261, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d54, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l6
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l6
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayTooManyArgs(ptr %v0, i64 %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 55, ptr getelementptr inbounds (<{ i64, [55 x i8] }>, ptr @.d55, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 55, ptr getelementptr inbounds (<{ i64, [55 x i8] }>, ptr @.d55, i32 0, i32 1) }, 0
  %t5 = call i64 @__olang_fmt_i64(ptr null, i64 %a0)
  %t6 = add i64 %t3, %t5
  %t7 = extractvalue { i64, ptr } { i64 70, ptr getelementptr inbounds (<{ i64, [70 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 70, ptr getelementptr inbounds (<{ i64, [70 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  %t9 = add i64 %t6, %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t9)
  call void @olang_textcopy(ptr %t10, ptr %t2, i64 %t3)
  %t11 = getelementptr i8, ptr %t10, i64 %t3
  %t12 = call i64 @__olang_fmt_i64(ptr %t11, i64 %a0)
  %t13 = getelementptr i8, ptr %t11, i64 %t5
  call void @olang_textcopy(ptr %t13, ptr %t7, i64 %t8)
  %t14 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t10, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 156, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d57, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrowInStatement(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 494, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d58, i32 0, i32 1) }, { i64, ptr } { i64 94, ptr getelementptr inbounds (<{ i64, [94 x i8] }>, ptr @.d59, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrowLeaves(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d61, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d61, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 495, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d63, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAsNeedsCase(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d65, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d65, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t3, i64 %t4)
  %t17 = getelementptr i8, ptr %t16, i64 %t4
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t9, i64 %t10)
  %t19 = getelementptr i8, ptr %t18, i64 %t10
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 410, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d66, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAsNothing(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d67, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d67, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 57, ptr getelementptr inbounds (<{ i64, [57 x i8] }>, ptr @.d68, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 57, ptr getelementptr inbounds (<{ i64, [57 x i8] }>, ptr @.d68, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 414, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d69, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertAborts(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d70, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d70, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 594, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d71, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertFalse(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 588, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d72, i32 0, i32 1) }, { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d73, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertMessageNotText(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a1, 1
  %t5 = extractvalue { i64, ptr } %a1, 0
  %t6 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d74, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d74, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a0, 1
  %t11 = extractvalue { i64, ptr } %a0, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d75, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d75, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 593, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d76, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertMsgError(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d77, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d77, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d78, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d78, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 591, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d79, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertMsgLoopJump(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d80, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d80, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d81, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d81, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 592, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d82, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertStale(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 65, ptr getelementptr inbounds (<{ i64, [65 x i8] }>, ptr @.d83, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 65, ptr getelementptr inbounds (<{ i64, [65 x i8] }>, ptr @.d83, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 600, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d84, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssignIntoTried(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 335, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d85, i32 0, i32 1) }, { i64, ptr } { i64 165, ptr getelementptr inbounds (<{ i64, [165 x i8] }>, ptr @.d86, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAtomicNotPlace(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 314, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d87, i32 0, i32 1) }, { i64, ptr } { i64 71, ptr getelementptr inbounds (<{ i64, [71 x i8] }>, ptr @.d88, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAtomicWidth(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 65, ptr getelementptr inbounds (<{ i64, [65 x i8] }>, ptr @.d89, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 65, ptr getelementptr inbounds (<{ i64, [65 x i8] }>, ptr @.d89, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d90, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d90, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 687, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d91, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBitOpCount(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d92, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d92, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 626, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d93, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBitOpNotInteger(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d94, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d94, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d95, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d95, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d96, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d96, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 625, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d97, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuildDefaultMut(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 85, ptr getelementptr inbounds (<{ i64, [85 x i8] }>, ptr @.d98, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 85, ptr getelementptr inbounds (<{ i64, [85 x i8] }>, ptr @.d98, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 124, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d99, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuildDefaultType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 91, ptr getelementptr inbounds (<{ i64, [91 x i8] }>, ptr @.d100, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 91, ptr getelementptr inbounds (<{ i64, [91 x i8] }>, ptr @.d100, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t6, i64 %t7)
  %t15 = getelementptr i8, ptr %t14, i64 %t7
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t27 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 125, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d101, i32 0, i32 1) }, { i64, ptr } %t24)
  store %"compiler/msgs:Msg" %t27, ptr %l7
  br label %bb1
bb1:
  %t28 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuildThroughUnknownScope(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 290, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d102, i32 0, i32 1) }, { i64, ptr } { i64 113, ptr getelementptr inbounds (<{ i64, [113 x i8] }>, ptr @.d103, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eByteSwapWidth(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d104, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d104, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = call i64 @__olang_fmt_i64(ptr null, i64 %a1)
  %t11 = add i64 %t8, %t10
  %t12 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d105, i32 0, i32 1) }, 1
  %t13 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d105, i32 0, i32 1) }, 0
  %t14 = add i64 %t11, %t13
  %t15 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t14)
  call void @olang_textcopy(ptr %t15, ptr %t4, i64 %t5)
  %t16 = getelementptr i8, ptr %t15, i64 %t5
  call void @olang_textcopy(ptr %t16, ptr %t6, i64 %t7)
  %t17 = getelementptr i8, ptr %t16, i64 %t7
  %t18 = call i64 @__olang_fmt_i64(ptr %t17, i64 %a1)
  %t19 = getelementptr i8, ptr %t17, i64 %t10
  call void @olang_textcopy(ptr %t19, ptr %t12, i64 %t13)
  %t20 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t15, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 686, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d106, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 44, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d107, i32 0, i32 1) }, { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d108, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseBlockStays(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 497, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d109, i32 0, i32 1) }, { i64, ptr } { i64 66, ptr getelementptr inbounds (<{ i64, [66 x i8] }>, ptr @.d110, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseIsPrivate(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d111, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d111, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d112, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d112, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 412, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d113, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseUnknownName(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d114, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d114, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 101, ptr getelementptr inbounds (<{ i64, [101 x i8] }>, ptr @.d115, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 101, ptr getelementptr inbounds (<{ i64, [101 x i8] }>, ptr @.d115, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 509, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d116, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseValueType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d117, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d117, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d118, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d118, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t3, i64 %t4)
  %t17 = getelementptr i8, ptr %t16, i64 %t4
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t9, i64 %t10)
  %t19 = getelementptr i8, ptr %t18, i64 %t10
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 492, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d119, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCatchAfterCatchAll(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 439, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d120, i32 0, i32 1) }, { i64, ptr } { i64 78, ptr getelementptr inbounds (<{ i64, [78 x i8] }>, ptr @.d121, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCatchLoneUnused(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 128, ptr getelementptr inbounds (<{ i64, [128 x i8] }>, ptr @.d122, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 128, ptr getelementptr inbounds (<{ i64, [128 x i8] }>, ptr @.d122, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 647, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d123, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCatchMustLeave(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 443, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d124, i32 0, i32 1) }, { i64, ptr } { i64 57, ptr getelementptr inbounds (<{ i64, [57 x i8] }>, ptr @.d125, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCatchUnreachable(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 440, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d126, i32 0, i32 1) }, { i64, ptr } { i64 58, ptr getelementptr inbounds (<{ i64, [58 x i8] }>, ptr @.d127, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtCompareWhat(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 87, ptr getelementptr inbounds (<{ i64, [87 x i8] }>, ptr @.d128, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 87, ptr getelementptr inbounds (<{ i64, [87 x i8] }>, ptr @.d128, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 652, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d129, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtMatchMissing(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d130, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d130, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d131, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d131, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 661, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d132, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtNotAValue(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 102, ptr getelementptr inbounds (<{ i64, [102 x i8] }>, ptr @.d133, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 102, ptr getelementptr inbounds (<{ i64, [102 x i8] }>, ptr @.d133, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d134, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d134, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 649, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d135, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCommaEndsLine(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 52, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d136, i32 0, i32 1) }, { i64, ptr } { i64 95, ptr getelementptr inbounds (<{ i64, [95 x i8] }>, ptr @.d137, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCommutesSameType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d138, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d138, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 86, ptr getelementptr inbounds (<{ i64, [86 x i8] }>, ptr @.d139, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 86, ptr getelementptr inbounds (<{ i64, [86 x i8] }>, ptr @.d139, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 226, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d140, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eComprNeedsTry(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 483, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d141, i32 0, i32 1) }, { i64, ptr } { i64 69, ptr getelementptr inbounds (<{ i64, [69 x i8] }>, ptr @.d142, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondBranchTypes(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d143, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d143, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d144, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d144, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t3, i64 %t4)
  %t17 = getelementptr i8, ptr %t16, i64 %t4
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t9, i64 %t10)
  %t19 = getelementptr i8, ptr %t18, i64 %t10
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 383, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d145, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondDecidedNotBool(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 620, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d146, i32 0, i32 1) }, { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d147, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondGlobalInit(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 56, ptr getelementptr inbounds (<{ i64, [56 x i8] }>, ptr @.d148, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 56, ptr getelementptr inbounds (<{ i64, [56 x i8] }>, ptr @.d148, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 86, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d149, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondLentWritable(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 421, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d150, i32 0, i32 1) }, { i64, ptr } { i64 190, ptr getelementptr inbounds (<{ i64, [190 x i8] }>, ptr @.d151, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondName(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d152, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d152, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 84, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d153, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondNotBool(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d154, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d154, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d155, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d155, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 90, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d156, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondNotBoolType(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d157, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d157, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 382, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d158, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondTypes(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d159, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d159, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 88, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d160, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eConditionConstant(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 480, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d161, i32 0, i32 1) }, { i64, ptr } { i64 107, ptr getelementptr inbounds (<{ i64, [107 x i8] }>, ptr @.d162, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eConstraintClosed(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l13 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d163, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d163, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d164, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d164, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t20 = extractvalue { i64, ptr } %a2, 1
  %t21 = extractvalue { i64, ptr } %a2, 0
  %t22 = add i64 %t18, %t21
  %t23 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d165, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d165, i32 0, i32 1) }, 0
  %t25 = add i64 %t22, %t24
  %t27 = extractvalue { i64, ptr } %a3, 1
  %t28 = extractvalue { i64, ptr } %a3, 0
  %t29 = add i64 %t25, %t28
  %t30 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d166, i32 0, i32 1) }, 1
  %t31 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d166, i32 0, i32 1) }, 0
  %t32 = add i64 %t29, %t31
  %t34 = extractvalue { i64, ptr } %a4, 1
  %t35 = extractvalue { i64, ptr } %a4, 0
  %t36 = add i64 %t32, %t35
  %t37 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d167, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d167, i32 0, i32 1) }, 0
  %t39 = add i64 %t36, %t38
  %t40 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t39)
  call void @olang_textcopy(ptr %t40, ptr %t7, i64 %t8)
  %t41 = getelementptr i8, ptr %t40, i64 %t8
  call void @olang_textcopy(ptr %t41, ptr %t9, i64 %t10)
  %t42 = getelementptr i8, ptr %t41, i64 %t10
  call void @olang_textcopy(ptr %t42, ptr %t13, i64 %t14)
  %t43 = getelementptr i8, ptr %t42, i64 %t14
  call void @olang_textcopy(ptr %t43, ptr %t16, i64 %t17)
  %t44 = getelementptr i8, ptr %t43, i64 %t17
  call void @olang_textcopy(ptr %t44, ptr %t20, i64 %t21)
  %t45 = getelementptr i8, ptr %t44, i64 %t21
  call void @olang_textcopy(ptr %t45, ptr %t23, i64 %t24)
  %t46 = getelementptr i8, ptr %t45, i64 %t24
  call void @olang_textcopy(ptr %t46, ptr %t27, i64 %t28)
  %t47 = getelementptr i8, ptr %t46, i64 %t28
  call void @olang_textcopy(ptr %t47, ptr %t30, i64 %t31)
  %t48 = getelementptr i8, ptr %t47, i64 %t31
  call void @olang_textcopy(ptr %t48, ptr %t34, i64 %t35)
  %t49 = getelementptr i8, ptr %t48, i64 %t35
  call void @olang_textcopy(ptr %t49, ptr %t37, i64 %t38)
  %t50 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t40, 1
  %t53 = extractvalue { i64, ptr } %t51, 0
  %t54 = extractvalue { i64, ptr } %t51, 1
  %t55 = mul i64 %t53, 1
  %t56 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t55)
  call void @llvm.memcpy.p0.p0.i64(ptr %t56, ptr %t54, i64 %t55, i1 false)
  %t57 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t56, 1
  %t61 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v5, ptr %v5, ptr %v5, i32 135, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d168, i32 0, i32 1) }, { i64, ptr } %t58)
  store %"compiler/msgs:Msg" %t61, ptr %l13
  br label %bb1
bb1:
  %t62 = load %"compiler/msgs:Msg", ptr %l13
  store %"compiler/msgs:Msg" %t62, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eConstraintSealed(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l13 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d169, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d169, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d170, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d170, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t20 = extractvalue { i64, ptr } %a2, 1
  %t21 = extractvalue { i64, ptr } %a2, 0
  %t22 = add i64 %t18, %t21
  %t23 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d171, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d171, i32 0, i32 1) }, 0
  %t25 = add i64 %t22, %t24
  %t27 = extractvalue { i64, ptr } %a3, 1
  %t28 = extractvalue { i64, ptr } %a3, 0
  %t29 = add i64 %t25, %t28
  %t30 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d172, i32 0, i32 1) }, 1
  %t31 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d172, i32 0, i32 1) }, 0
  %t32 = add i64 %t29, %t31
  %t34 = extractvalue { i64, ptr } %a4, 1
  %t35 = extractvalue { i64, ptr } %a4, 0
  %t36 = add i64 %t32, %t35
  %t37 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d173, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d173, i32 0, i32 1) }, 0
  %t39 = add i64 %t36, %t38
  %t40 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t39)
  call void @olang_textcopy(ptr %t40, ptr %t7, i64 %t8)
  %t41 = getelementptr i8, ptr %t40, i64 %t8
  call void @olang_textcopy(ptr %t41, ptr %t9, i64 %t10)
  %t42 = getelementptr i8, ptr %t41, i64 %t10
  call void @olang_textcopy(ptr %t42, ptr %t13, i64 %t14)
  %t43 = getelementptr i8, ptr %t42, i64 %t14
  call void @olang_textcopy(ptr %t43, ptr %t16, i64 %t17)
  %t44 = getelementptr i8, ptr %t43, i64 %t17
  call void @olang_textcopy(ptr %t44, ptr %t20, i64 %t21)
  %t45 = getelementptr i8, ptr %t44, i64 %t21
  call void @olang_textcopy(ptr %t45, ptr %t23, i64 %t24)
  %t46 = getelementptr i8, ptr %t45, i64 %t24
  call void @olang_textcopy(ptr %t46, ptr %t27, i64 %t28)
  %t47 = getelementptr i8, ptr %t46, i64 %t28
  call void @olang_textcopy(ptr %t47, ptr %t30, i64 %t31)
  %t48 = getelementptr i8, ptr %t47, i64 %t31
  call void @olang_textcopy(ptr %t48, ptr %t34, i64 %t35)
  %t49 = getelementptr i8, ptr %t48, i64 %t35
  call void @olang_textcopy(ptr %t49, ptr %t37, i64 %t38)
  %t50 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t40, 1
  %t53 = extractvalue { i64, ptr } %t51, 0
  %t54 = extractvalue { i64, ptr } %t51, 1
  %t55 = mul i64 %t53, 1
  %t56 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t55)
  call void @llvm.memcpy.p0.p0.i64(ptr %t56, ptr %t54, i64 %t55, i1 false)
  %t57 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t56, 1
  %t61 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v5, ptr %v5, ptr %v5, i32 134, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d174, i32 0, i32 1) }, { i64, ptr } %t58)
  store %"compiler/msgs:Msg" %t61, ptr %l13
  br label %bb1
bb1:
  %t62 = load %"compiler/msgs:Msg", ptr %l13
  store %"compiler/msgs:Msg" %t62, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eConstraintUnmetMethod(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l11 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d175, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d175, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t12 = extractvalue { i64, ptr } %a1, 1
  %t13 = extractvalue { i64, ptr } %a1, 0
  %t14 = add i64 %t10, %t13
  %t15 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d176, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d176, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t19 = extractvalue { i64, ptr } %a2, 1
  %t20 = extractvalue { i64, ptr } %a2, 0
  %t21 = add i64 %t17, %t20
  %t22 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d177, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d177, i32 0, i32 1) }, 0
  %t24 = add i64 %t21, %t23
  %t26 = extractvalue { i64, ptr } %a3, 1
  %t27 = extractvalue { i64, ptr } %a3, 0
  %t28 = add i64 %t24, %t27
  %t29 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d178, i32 0, i32 1) }, 1
  %t30 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d178, i32 0, i32 1) }, 0
  %t31 = add i64 %t28, %t30
  %t32 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t31)
  call void @olang_textcopy(ptr %t32, ptr %t6, i64 %t7)
  %t33 = getelementptr i8, ptr %t32, i64 %t7
  call void @olang_textcopy(ptr %t33, ptr %t8, i64 %t9)
  %t34 = getelementptr i8, ptr %t33, i64 %t9
  call void @olang_textcopy(ptr %t34, ptr %t12, i64 %t13)
  %t35 = getelementptr i8, ptr %t34, i64 %t13
  call void @olang_textcopy(ptr %t35, ptr %t15, i64 %t16)
  %t36 = getelementptr i8, ptr %t35, i64 %t16
  call void @olang_textcopy(ptr %t36, ptr %t19, i64 %t20)
  %t37 = getelementptr i8, ptr %t36, i64 %t20
  call void @olang_textcopy(ptr %t37, ptr %t22, i64 %t23)
  %t38 = getelementptr i8, ptr %t37, i64 %t23
  call void @olang_textcopy(ptr %t38, ptr %t26, i64 %t27)
  %t39 = getelementptr i8, ptr %t38, i64 %t27
  call void @olang_textcopy(ptr %t39, ptr %t29, i64 %t30)
  %t40 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t32, 1
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t44 = extractvalue { i64, ptr } %t41, 1
  %t45 = mul i64 %t43, 1
  %t46 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t45)
  call void @llvm.memcpy.p0.p0.i64(ptr %t46, ptr %t44, i64 %t45, i1 false)
  %t47 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  %t51 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, i32 133, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d179, i32 0, i32 1) }, { i64, ptr } %t48)
  store %"compiler/msgs:Msg" %t51, ptr %l11
  br label %bb1
bb1:
  %t52 = load %"compiler/msgs:Msg", ptr %l11
  store %"compiler/msgs:Msg" %t52, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eContractFalse(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d180, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d180, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a1, 1
  %t7 = extractvalue { i64, ptr } %a1, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d181, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d181, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a0, 1
  %t14 = extractvalue { i64, ptr } %a0, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d182, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d182, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 638, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d183, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eContractOutlivesNotParam(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 88, ptr getelementptr inbounds (<{ i64, [88 x i8] }>, ptr @.d184, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 88, ptr getelementptr inbounds (<{ i64, [88 x i8] }>, ptr @.d184, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 637, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d185, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eConversionDoesNotFit(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l8 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d186, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d186, i32 0, i32 1) }, 0
  %t9 = add i64 %t6, %t8
  %t11 = extractvalue { i64, ptr } %t2, 1
  %t12 = extractvalue { i64, ptr } %t2, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d187, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d187, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t18 = extractvalue { i64, ptr } %t3, 1
  %t19 = extractvalue { i64, ptr } %t3, 0
  %t20 = add i64 %t16, %t19
  %t21 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d188, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d188, i32 0, i32 1) }, 0
  %t23 = add i64 %t20, %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t5, i64 %t6)
  %t25 = getelementptr i8, ptr %t24, i64 %t6
  call void @olang_textcopy(ptr %t25, ptr %t7, i64 %t8)
  %t26 = getelementptr i8, ptr %t25, i64 %t8
  call void @olang_textcopy(ptr %t26, ptr %t11, i64 %t12)
  %t27 = getelementptr i8, ptr %t26, i64 %t12
  call void @olang_textcopy(ptr %t27, ptr %t14, i64 %t15)
  %t28 = getelementptr i8, ptr %t27, i64 %t15
  call void @olang_textcopy(ptr %t28, ptr %t18, i64 %t19)
  %t29 = getelementptr i8, ptr %t28, i64 %t19
  call void @olang_textcopy(ptr %t29, ptr %t21, i64 %t22)
  %t30 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t24, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t41 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 641, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d189, i32 0, i32 1) }, { i64, ptr } %t38)
  store %"compiler/msgs:Msg" %t41, ptr %l8
  br label %bb1
bb1:
  %t42 = load %"compiler/msgs:Msg", ptr %l8
  store %"compiler/msgs:Msg" %t42, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eConversionRepresentation(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d190, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d190, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d191, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d191, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 325, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d192, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eConvertNotNumber(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d193, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d193, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d194, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d194, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 326, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d195, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCtorFieldNamesVar(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l11 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d196, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d196, i32 0, i32 1) }, 0
  %t8 = extractvalue { i64, ptr } %a0, 1
  %t9 = extractvalue { i64, ptr } %a0, 0
  %t10 = add i64 %t6, %t9
  %t11 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d197, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d197, i32 0, i32 1) }, 0
  %t13 = add i64 %t10, %t12
  %t15 = extractvalue { i64, ptr } %a1, 1
  %t16 = extractvalue { i64, ptr } %a1, 0
  %t17 = add i64 %t13, %t16
  %t18 = extractvalue { i64, ptr } { i64 105, ptr getelementptr inbounds (<{ i64, [105 x i8] }>, ptr @.d198, i32 0, i32 1) }, 1
  %t19 = extractvalue { i64, ptr } { i64 105, ptr getelementptr inbounds (<{ i64, [105 x i8] }>, ptr @.d198, i32 0, i32 1) }, 0
  %t20 = add i64 %t17, %t19
  %t22 = extractvalue { i64, ptr } %a2, 1
  %t23 = extractvalue { i64, ptr } %a2, 0
  %t24 = add i64 %t20, %t23
  %t25 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d199, i32 0, i32 1) }, 1
  %t26 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d199, i32 0, i32 1) }, 0
  %t27 = add i64 %t24, %t26
  %t29 = extractvalue { i64, ptr } %a3, 1
  %t30 = extractvalue { i64, ptr } %a3, 0
  %t31 = add i64 %t27, %t30
  %t32 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d200, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d200, i32 0, i32 1) }, 0
  %t34 = add i64 %t31, %t33
  %t35 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t34)
  call void @olang_textcopy(ptr %t35, ptr %t5, i64 %t6)
  %t36 = getelementptr i8, ptr %t35, i64 %t6
  call void @olang_textcopy(ptr %t36, ptr %t8, i64 %t9)
  %t37 = getelementptr i8, ptr %t36, i64 %t9
  call void @olang_textcopy(ptr %t37, ptr %t11, i64 %t12)
  %t38 = getelementptr i8, ptr %t37, i64 %t12
  call void @olang_textcopy(ptr %t38, ptr %t15, i64 %t16)
  %t39 = getelementptr i8, ptr %t38, i64 %t16
  call void @olang_textcopy(ptr %t39, ptr %t18, i64 %t19)
  %t40 = getelementptr i8, ptr %t39, i64 %t19
  call void @olang_textcopy(ptr %t40, ptr %t22, i64 %t23)
  %t41 = getelementptr i8, ptr %t40, i64 %t23
  call void @olang_textcopy(ptr %t41, ptr %t25, i64 %t26)
  %t42 = getelementptr i8, ptr %t41, i64 %t26
  call void @olang_textcopy(ptr %t42, ptr %t29, i64 %t30)
  %t43 = getelementptr i8, ptr %t42, i64 %t30
  call void @olang_textcopy(ptr %t43, ptr %t32, i64 %t33)
  %t44 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t35, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = extractvalue { i64, ptr } %t45, 1
  %t49 = mul i64 %t47, 1
  %t50 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t49)
  call void @llvm.memcpy.p0.p0.i64(ptr %t50, ptr %t48, i64 %t49, i1 false)
  %t51 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  %t55 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, i32 310, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d201, i32 0, i32 1) }, { i64, ptr } %t52)
  store %"compiler/msgs:Msg" %t55, ptr %l11
  br label %bb1
bb1:
  %t56 = load %"compiler/msgs:Msg", ptr %l11
  store %"compiler/msgs:Msg" %t56, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCtorVarOfGeneric(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d202, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d202, i32 0, i32 1) }, 0
  %t9 = add i64 %t6, %t8
  %t11 = extractvalue { i64, ptr } %a1, 1
  %t12 = extractvalue { i64, ptr } %a1, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 81, ptr getelementptr inbounds (<{ i64, [81 x i8] }>, ptr @.d203, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 81, ptr getelementptr inbounds (<{ i64, [81 x i8] }>, ptr @.d203, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t18 = extractvalue { i64, ptr } %a2, 1
  %t19 = extractvalue { i64, ptr } %a2, 0
  %t20 = add i64 %t16, %t19
  %t21 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d204, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d204, i32 0, i32 1) }, 0
  %t23 = add i64 %t20, %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t5, i64 %t6)
  %t25 = getelementptr i8, ptr %t24, i64 %t6
  call void @olang_textcopy(ptr %t25, ptr %t7, i64 %t8)
  %t26 = getelementptr i8, ptr %t25, i64 %t8
  call void @olang_textcopy(ptr %t26, ptr %t11, i64 %t12)
  %t27 = getelementptr i8, ptr %t26, i64 %t12
  call void @olang_textcopy(ptr %t27, ptr %t14, i64 %t15)
  %t28 = getelementptr i8, ptr %t27, i64 %t15
  call void @olang_textcopy(ptr %t28, ptr %t18, i64 %t19)
  %t29 = getelementptr i8, ptr %t28, i64 %t19
  call void @olang_textcopy(ptr %t29, ptr %t21, i64 %t22)
  %t30 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t24, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t41 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 312, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d205, i32 0, i32 1) }, { i64, ptr } %t38)
  store %"compiler/msgs:Msg" %t41, ptr %l9
  br label %bb1
bb1:
  %t42 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t42, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCtorVarsNotInferable(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d206, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d206, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 65, ptr getelementptr inbounds (<{ i64, [65 x i8] }>, ptr @.d207, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 65, ptr getelementptr inbounds (<{ i64, [65 x i8] }>, ptr @.d207, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 309, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d208, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeclFromNoreturn(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 531, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d209, i32 0, i32 1) }, { i64, ptr } { i64 61, ptr getelementptr inbounds (<{ i64, [61 x i8] }>, ptr @.d210, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeclFromNull(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 285, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d211, i32 0, i32 1) }, { i64, ptr } { i64 92, ptr getelementptr inbounds (<{ i64, [92 x i8] }>, ptr @.d212, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeclaredOverAggregate(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 55, ptr getelementptr inbounds (<{ i64, [55 x i8] }>, ptr @.d213, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 55, ptr getelementptr inbounds (<{ i64, [55 x i8] }>, ptr @.d213, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d214, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d214, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 221, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d215, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultAmbiguous(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d216, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d216, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d217, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d217, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d218, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d218, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 457, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d219, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultArgNoDefault(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d220, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d220, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 57, ptr getelementptr inbounds (<{ i64, [57 x i8] }>, ptr @.d221, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 57, ptr getelementptr inbounds (<{ i64, [57 x i8] }>, ptr @.d221, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 313, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d222, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultDead(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 442, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d223, i32 0, i32 1) }, { i64, ptr } { i64 80, ptr getelementptr inbounds (<{ i64, [80 x i8] }>, ptr @.d224, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultHoldsReferences(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 437, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d225, i32 0, i32 1) }, { i64, ptr } { i64 131, ptr getelementptr inbounds (<{ i64, [131 x i8] }>, ptr @.d226, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultInStatement(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 441, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d227, i32 0, i32 1) }, { i64, ptr } { i64 67, ptr getelementptr inbounds (<{ i64, [67 x i8] }>, ptr @.d228, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultNeedsCatch(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 446, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d229, i32 0, i32 1) }, { i64, ptr } { i64 54, ptr getelementptr inbounds (<{ i64, [54 x i8] }>, ptr @.d230, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultNoValue(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 445, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d231, i32 0, i32 1) }, { i64, ptr } { i64 77, ptr getelementptr inbounds (<{ i64, [77 x i8] }>, ptr @.d232, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultScope(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 438, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d233, i32 0, i32 1) }, { i64, ptr } { i64 83, ptr getelementptr inbounds (<{ i64, [83 x i8] }>, ptr @.d234, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultShadowsRequired(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d235, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d235, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d236, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d236, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d237, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d237, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 240, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d238, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeferReturns(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 513, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d239, i32 0, i32 1) }, { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d240, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineBadNumber(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d241, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d241, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d242, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d242, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d243, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d243, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 39, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d244, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineIntRange(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d245, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d245, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d246, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d246, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d247, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d247, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 40, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d248, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineMissing(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 35, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d249, i32 0, i32 1) }, { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d250, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineNotName(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d251, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d251, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d252, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d252, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d253, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d253, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 37, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d254, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineTwice(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d255, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d255, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d256, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d256, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d257, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d257, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 38, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d258, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestroyInLoop(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l6 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d259, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d259, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %t1, 1
  %t7 = extractvalue { i64, ptr } %t1, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 76, ptr getelementptr inbounds (<{ i64, [76 x i8] }>, ptr @.d260, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 76, ptr getelementptr inbounds (<{ i64, [76 x i8] }>, ptr @.d260, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %t2, 1
  %t14 = extractvalue { i64, ptr } %t2, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d261, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d261, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 321, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d262, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l6
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l6
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestroyUsedAfter(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l8 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t4 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d263, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d263, i32 0, i32 1) }, 0
  %t7 = extractvalue { i64, ptr } %t1, 1
  %t8 = extractvalue { i64, ptr } %t1, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d264, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d264, i32 0, i32 1) }, 0
  %t12 = add i64 %t9, %t11
  %t14 = extractvalue { i64, ptr } %t2, 1
  %t15 = extractvalue { i64, ptr } %t2, 0
  %t16 = add i64 %t12, %t15
  %t17 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d265, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d265, i32 0, i32 1) }, 0
  %t19 = add i64 %t16, %t18
  %t21 = call i64 @__olang_fmt_i64(ptr null, i64 %a1)
  %t22 = add i64 %t19, %t21
  %t23 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d266, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d266, i32 0, i32 1) }, 0
  %t25 = add i64 %t22, %t24
  %t26 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t25)
  call void @olang_textcopy(ptr %t26, ptr %t4, i64 %t5)
  %t27 = getelementptr i8, ptr %t26, i64 %t5
  call void @olang_textcopy(ptr %t27, ptr %t7, i64 %t8)
  %t28 = getelementptr i8, ptr %t27, i64 %t8
  call void @olang_textcopy(ptr %t28, ptr %t10, i64 %t11)
  %t29 = getelementptr i8, ptr %t28, i64 %t11
  call void @olang_textcopy(ptr %t29, ptr %t14, i64 %t15)
  %t30 = getelementptr i8, ptr %t29, i64 %t15
  call void @olang_textcopy(ptr %t30, ptr %t17, i64 %t18)
  %t31 = getelementptr i8, ptr %t30, i64 %t18
  %t32 = call i64 @__olang_fmt_i64(ptr %t31, i64 %a1)
  %t33 = getelementptr i8, ptr %t31, i64 %t21
  call void @olang_textcopy(ptr %t33, ptr %t23, i64 %t24)
  %t34 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t26, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = extractvalue { i64, ptr } %t35, 1
  %t39 = mul i64 %t37, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t39)
  call void @llvm.memcpy.p0.p0.i64(ptr %t40, ptr %t38, i64 %t39, i1 false)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  %t45 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 320, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d267, i32 0, i32 1) }, { i64, ptr } %t42)
  store %"compiler/msgs:Msg" %t45, ptr %l8
  br label %bb1
bb1:
  %t46 = load %"compiler/msgs:Msg", ptr %l8
  store %"compiler/msgs:Msg" %t46, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestructCount(ptr %v0, i64 %a0, i64 %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = call i64 @__olang_fmt_i64(ptr null, i64 %a0)
  %t5 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d268, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d268, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t9 = call i64 @__olang_fmt_i64(ptr null, i64 %a1)
  %t10 = add i64 %t7, %t9
  %t11 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d269, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d269, i32 0, i32 1) }, 0
  %t13 = add i64 %t10, %t12
  %t14 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t13)
  %t15 = call i64 @__olang_fmt_i64(ptr %t14, i64 %a0)
  %t16 = getelementptr i8, ptr %t14, i64 %t4
  call void @olang_textcopy(ptr %t16, ptr %t5, i64 %t6)
  %t17 = getelementptr i8, ptr %t16, i64 %t6
  %t18 = call i64 @__olang_fmt_i64(ptr %t17, i64 %a1)
  %t19 = getelementptr i8, ptr %t17, i64 %t9
  call void @olang_textcopy(ptr %t19, ptr %t11, i64 %t12)
  %t20 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t14, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 465, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d270, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestructInBody(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 77, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d271, i32 0, i32 1) }, { i64, ptr } { i64 111, ptr getelementptr inbounds (<{ i64, [111 x i8] }>, ptr @.d272, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestructOneValue(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 58, ptr getelementptr inbounds (<{ i64, [58 x i8] }>, ptr @.d273, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 58, ptr getelementptr inbounds (<{ i64, [58 x i8] }>, ptr @.d273, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 464, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d274, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDocOneName(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l6 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d275, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d275, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %t1, 1
  %t7 = extractvalue { i64, ptr } %t1, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 59, ptr getelementptr inbounds (<{ i64, [59 x i8] }>, ptr @.d276, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 59, ptr getelementptr inbounds (<{ i64, [59 x i8] }>, ptr @.d276, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %t2, 1
  %t14 = extractvalue { i64, ptr } %t2, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d277, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d277, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 29, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d278, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l6
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l6
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eElemOutlived(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 469, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d279, i32 0, i32 1) }, { i64, ptr } { i64 87, ptr getelementptr inbounds (<{ i64, [87 x i8] }>, ptr @.d280, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eElemRefShape(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d281, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d281, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d282, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d282, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 53, ptr getelementptr inbounds (<{ i64, [53 x i8] }>, ptr @.d283, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 53, ptr getelementptr inbounds (<{ i64, [53 x i8] }>, ptr @.d283, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 263, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d284, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eEmbedPathUndecided(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 427, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d285, i32 0, i32 1) }, { i64, ptr } { i64 90, ptr getelementptr inbounds (<{ i64, [90 x i8] }>, ptr @.d286, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eEmptyChar(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 62, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d287, i32 0, i32 1) }, { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d288, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eEnumCaseInUse(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d289, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d289, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d290, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d290, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 186, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d291, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eEqShape(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 232, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d292, i32 0, i32 1) }, { i64, ptr } { i64 66, ptr getelementptr inbounds (<{ i64, [66 x i8] }>, ptr @.d293, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eEqStrWrites(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 85, ptr getelementptr inbounds (<{ i64, [85 x i8] }>, ptr @.d294, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 85, ptr getelementptr inbounds (<{ i64, [85 x i8] }>, ptr @.d294, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 234, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d295, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrSetArgUnwanted(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 59, ptr getelementptr inbounds (<{ i64, [59 x i8] }>, ptr @.d296, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 59, ptr getelementptr inbounds (<{ i64, [59 x i8] }>, ptr @.d296, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 198, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d297, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrVarNotType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 85, ptr getelementptr inbounds (<{ i64, [85 x i8] }>, ptr @.d298, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 85, ptr getelementptr inbounds (<{ i64, [85 x i8] }>, ptr @.d298, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d299, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d299, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 197, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d300, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrorOutsideFunction(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 534, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d301, i32 0, i32 1) }, { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d302, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrorSetHoldsItself(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d303, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d303, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d304, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d304, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 644, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d305, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrorTypeAsValue(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = extractvalue { i64, ptr } { i64 132, ptr getelementptr inbounds (<{ i64, [132 x i8] }>, ptr @.d306, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 132, ptr getelementptr inbounds (<{ i64, [132 x i8] }>, ptr @.d306, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t12 = extractvalue { i64, ptr } %t2, 1
  %t13 = extractvalue { i64, ptr } %t2, 0
  %t14 = add i64 %t10, %t13
  %t15 = extractvalue { i64, ptr } { i64 55, ptr getelementptr inbounds (<{ i64, [55 x i8] }>, ptr @.d307, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 55, ptr getelementptr inbounds (<{ i64, [55 x i8] }>, ptr @.d307, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t19 = extractvalue { i64, ptr } %t3, 1
  %t20 = extractvalue { i64, ptr } %t3, 0
  %t21 = add i64 %t17, %t20
  %t22 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d308, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d308, i32 0, i32 1) }, 0
  %t24 = add i64 %t21, %t23
  %t26 = extractvalue { i64, ptr } %t4, 1
  %t27 = extractvalue { i64, ptr } %t4, 0
  %t28 = add i64 %t24, %t27
  %t29 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d309, i32 0, i32 1) }, 1
  %t30 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d309, i32 0, i32 1) }, 0
  %t31 = add i64 %t28, %t30
  %t32 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t31)
  call void @olang_textcopy(ptr %t32, ptr %t6, i64 %t7)
  %t33 = getelementptr i8, ptr %t32, i64 %t7
  call void @olang_textcopy(ptr %t33, ptr %t8, i64 %t9)
  %t34 = getelementptr i8, ptr %t33, i64 %t9
  call void @olang_textcopy(ptr %t34, ptr %t12, i64 %t13)
  %t35 = getelementptr i8, ptr %t34, i64 %t13
  call void @olang_textcopy(ptr %t35, ptr %t15, i64 %t16)
  %t36 = getelementptr i8, ptr %t35, i64 %t16
  call void @olang_textcopy(ptr %t36, ptr %t19, i64 %t20)
  %t37 = getelementptr i8, ptr %t36, i64 %t20
  call void @olang_textcopy(ptr %t37, ptr %t22, i64 %t23)
  %t38 = getelementptr i8, ptr %t37, i64 %t23
  call void @olang_textcopy(ptr %t38, ptr %t26, i64 %t27)
  %t39 = getelementptr i8, ptr %t38, i64 %t27
  call void @olang_textcopy(ptr %t39, ptr %t29, i64 %t30)
  %t40 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t32, 1
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t44 = extractvalue { i64, ptr } %t41, 1
  %t45 = mul i64 %t43, 1
  %t46 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t45)
  call void @llvm.memcpy.p0.p0.i64(ptr %t46, ptr %t44, i64 %t45, i1 false)
  %t47 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  %t51 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 451, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d310, i32 0, i32 1) }, { i64, ptr } %t48)
  store %"compiler/msgs:Msg" %t51, ptr %l9
  br label %bb1
bb1:
  %t52 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t52, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrorUndeclared(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d311, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d311, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d312, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d312, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 539, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d313, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrorWordAsValue(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l8 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t4 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d314, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d314, i32 0, i32 1) }, 0
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 55, ptr getelementptr inbounds (<{ i64, [55 x i8] }>, ptr @.d315, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 55, ptr getelementptr inbounds (<{ i64, [55 x i8] }>, ptr @.d315, i32 0, i32 1) }, 0
  %t12 = add i64 %t9, %t11
  %t14 = extractvalue { i64, ptr } %t2, 1
  %t15 = extractvalue { i64, ptr } %t2, 0
  %t16 = add i64 %t12, %t15
  %t17 = extractvalue { i64, ptr } { i64 101, ptr getelementptr inbounds (<{ i64, [101 x i8] }>, ptr @.d316, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 101, ptr getelementptr inbounds (<{ i64, [101 x i8] }>, ptr @.d316, i32 0, i32 1) }, 0
  %t19 = add i64 %t16, %t18
  %t21 = extractvalue { i64, ptr } %t3, 1
  %t22 = extractvalue { i64, ptr } %t3, 0
  %t23 = add i64 %t19, %t22
  %t24 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d317, i32 0, i32 1) }, 1
  %t25 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d317, i32 0, i32 1) }, 0
  %t26 = add i64 %t23, %t25
  %t27 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t4, i64 %t5)
  %t28 = getelementptr i8, ptr %t27, i64 %t5
  call void @olang_textcopy(ptr %t28, ptr %t7, i64 %t8)
  %t29 = getelementptr i8, ptr %t28, i64 %t8
  call void @olang_textcopy(ptr %t29, ptr %t10, i64 %t11)
  %t30 = getelementptr i8, ptr %t29, i64 %t11
  call void @olang_textcopy(ptr %t30, ptr %t14, i64 %t15)
  %t31 = getelementptr i8, ptr %t30, i64 %t15
  call void @olang_textcopy(ptr %t31, ptr %t17, i64 %t18)
  %t32 = getelementptr i8, ptr %t31, i64 %t18
  call void @olang_textcopy(ptr %t32, ptr %t21, i64 %t22)
  %t33 = getelementptr i8, ptr %t32, i64 %t22
  call void @olang_textcopy(ptr %t33, ptr %t24, i64 %t25)
  %t34 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t27, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = extractvalue { i64, ptr } %t35, 1
  %t39 = mul i64 %t37, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t39)
  call void @llvm.memcpy.p0.p0.i64(ptr %t40, ptr %t38, i64 %t39, i1 false)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  %t45 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 454, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d318, i32 0, i32 1) }, { i64, ptr } %t42)
  store %"compiler/msgs:Msg" %t45, ptr %l8
  br label %bb1
bb1:
  %t46 = load %"compiler/msgs:Msg", ptr %l8
  store %"compiler/msgs:Msg" %t46, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrorWordIsPrivate(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d319, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d319, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d320, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d320, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 538, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d321, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrorWordOfMember(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d322, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d322, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d323, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d323, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d324, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d324, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 645, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d325, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrorWordTooFar(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d326, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d326, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 68, ptr getelementptr inbounds (<{ i64, [68 x i8] }>, ptr @.d327, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 68, ptr getelementptr inbounds (<{ i64, [68 x i8] }>, ptr @.d327, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 535, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d328, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local { i64, ptr } @compiler_2fmsgs_2eEsc(ptr %v0, i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l30 = alloca i1
  %l35 = alloca i8
  %l36 = alloca i64
  %l37 = alloca i32
  %l38 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l42 = alloca %"std/prelude/text:StringBuilder"
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i8, ptr %l0, !tbaa !22
  %t3 = icmp eq i8 %t1, 9
  br i1 %t3, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d329, i32 0, i32 1) }, ptr %l5, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t5, ptr %l6, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l7, !tbaa !24
  %t8 = load i64, ptr %l7, !tbaa !24
  %t9 = mul i64 %t8, 1
  %t10 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l8, !tbaa !27
  %t13 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = load i64, ptr %l7, !tbaa !24
  %t18 = mul i64 %t17, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t14, ptr %t16, i64 %t18, i1 false)
  %t19 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t19, ptr %l6, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t20 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t20, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t21 = load i8, ptr %l0, !tbaa !22
  %t23 = icmp eq i8 %t21, 10
  br i1 %t23, label %bb4, label %bb5
bb4:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d330, i32 0, i32 1) }, ptr %l11, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t25, ptr %l12, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t26, 0
  store i64 %t27, ptr %l13, !tbaa !24
  %t28 = load i64, ptr %l13, !tbaa !24
  %t29 = mul i64 %t28, 1
  %t30 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t29)
  %t31 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  store { i64, ptr } %t32, ptr %l14, !tbaa !27
  %t33 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = load i64, ptr %l13, !tbaa !24
  %t38 = mul i64 %t37, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t34, ptr %t36, i64 %t38, i1 false)
  %t39 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t39, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t40 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t40, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t41 = load i8, ptr %l0, !tbaa !22
  %t43 = icmp eq i8 %t41, 13
  br i1 %t43, label %bb7, label %bb8
bb7:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d331, i32 0, i32 1) }, ptr %l17, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t45, ptr %l18, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 0
  store i64 %t47, ptr %l19, !tbaa !24
  %t48 = load i64, ptr %l19, !tbaa !24
  %t49 = mul i64 %t48, 1
  %t50 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t49)
  %t51 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  store { i64, ptr } %t52, ptr %l20, !tbaa !27
  %t53 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = load i64, ptr %l19, !tbaa !24
  %t58 = mul i64 %t57, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t54, ptr %t56, i64 %t58, i1 false)
  %t59 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t59, ptr %l18, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t60 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t60, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t61 = load i8, ptr %l0, !tbaa !22
  %t63 = icmp eq i8 %t61, 0
  br i1 %t63, label %bb10, label %bb11
bb10:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d332, i32 0, i32 1) }, ptr %l23, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t65, ptr %l24, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 0
  store i64 %t67, ptr %l25, !tbaa !24
  %t68 = load i64, ptr %l25, !tbaa !24
  %t69 = mul i64 %t68, 1
  %t70 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t69)
  %t71 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  store { i64, ptr } %t72, ptr %l26, !tbaa !27
  %t73 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l25, !tbaa !24
  %t78 = mul i64 %t77, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t74, ptr %t76, i64 %t78, i1 false)
  %t79 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t79, ptr %l24, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t80 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t80, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t81 = load i8, ptr %l0, !tbaa !22
  %t84 = icmp ult i8 %t81, 32
  br i1 %t84, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb15
bb14:
  %t86 = load i8, ptr %l0, !tbaa !22
  %t89 = icmp uge i8 %t86, 127
  store i1 %t89, ptr %l30, !tbaa !21
  br label %bb15
bb15:
  %t91 = load i1, ptr %l30, !tbaa !21
  br i1 %t91, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s5
  %t92 = load i8, ptr %l0, !tbaa !22
  store i8 %t92, ptr %l35, !tbaa !22
  %t94 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s5, i64 16)
  %t95 = extractvalue { i32, i64 } %t94, 1
  %t96 = extractvalue { i32, i64 } %t94, 0
  store i32 %t96, ptr %l37
  %t97 = icmp ne i32 %t96, 0
  br i1 %t97, label %bb19, label %ok.98
ok.98:
  store i64 %t95, ptr %l36
  br label %bb18
bb17:
  br label %bb22
bb18:
  %t99 = load i8, ptr %l35, !tbaa !22
  %t100 = load i64, ptr %l36, !tbaa !24
  %t101 = call { i64, ptr } @std_2fprelude_2ftext_2eU8_2eFormat(ptr %s5, i8 %t99, i64 %t100)
  store { i64, ptr } %t101, ptr %l38
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_d2d351cc5daaf8b6_b531c4af6261323a)
  unreachable
bb20:
  %t102 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t105 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %s5, ptr %s5, { i64, ptr } %t102, i64 2, i8 48)
  store { i64, ptr } %t105, ptr %l40
  br label %bb21
bb21:
  %t106 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d333, i32 0, i32 1) }, 1
  %t107 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d333, i32 0, i32 1) }, 0
  %t108 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t108, 1
  %t110 = extractvalue { i64, ptr } %t108, 0
  %t111 = add i64 %t107, %t110
  %t112 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t111)
  call void @olang_textcopy(ptr %t112, ptr %t106, i64 %t107)
  %t113 = getelementptr i8, ptr %t112, i64 %t107
  call void @olang_textcopy(ptr %t113, ptr %t109, i64 %t110)
  %t114 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t112, 1
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t115, ptr %rv
  br label %ret
bb22:
  %t117 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t117, ptr %l42
  br label %bb23
bb23:
  %t118 = load %"std/prelude/text:StringBuilder", ptr %l42
  store %"std/prelude/text:StringBuilder" %t118, ptr %l2
  %t119 = load i8, ptr %l0, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 %t119)
  br label %bb24
bb24:
  %t123 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v0, ptr %l2)
  store { i64, ptr } %t123, ptr %l46
  br label %bb25
bb25:
  %t124 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t124, ptr %l47, !tbaa !27
  %t125 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t125, 0
  store i64 %t126, ptr %l48, !tbaa !24
  %t127 = load i64, ptr %l48, !tbaa !24
  %t128 = mul i64 %t127, 1
  %t129 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t128)
  %t130 = insertvalue { i64, ptr } undef, i64 %t127, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t129, 1
  store { i64, ptr } %t131, ptr %l49, !tbaa !27
  %t132 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = load i64, ptr %l48, !tbaa !24
  %t137 = mul i64 %t136, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t133, ptr %t135, i64 %t137, i1 false)
  %t138 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t138, ptr %l47, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t139 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t139, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eExplainNeedsName(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l6 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d334, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d334, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %t1, 1
  %t7 = extractvalue { i64, ptr } %t1, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 55, ptr getelementptr inbounds (<{ i64, [55 x i8] }>, ptr @.d335, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 55, ptr getelementptr inbounds (<{ i64, [55 x i8] }>, ptr @.d335, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %t2, 1
  %t14 = extractvalue { i64, ptr } %t2, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d336, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d336, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 26, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d337, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l6
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l6
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eExplainNoItem(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d338, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d338, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d339, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d339, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t3, i64 %t4)
  %t17 = getelementptr i8, ptr %t16, i64 %t4
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t9, i64 %t10)
  %t19 = getelementptr i8, ptr %t18, i64 %t10
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 27, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d340, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eExportGeneric(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 201, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d341, i32 0, i32 1) }, { i64, ptr } { i64 101, ptr getelementptr inbounds (<{ i64, [101 x i8] }>, ptr @.d342, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eExportMethod(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 200, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d343, i32 0, i32 1) }, { i64, ptr } { i64 108, ptr getelementptr inbounds (<{ i64, [108 x i8] }>, ptr @.d344, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eExportName(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d345, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d345, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 202, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d346, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eExportResult(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 133, ptr getelementptr inbounds (<{ i64, [133 x i8] }>, ptr @.d347, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 133, ptr getelementptr inbounds (<{ i64, [133 x i8] }>, ptr @.d347, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 204, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d348, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eExtendsNotBase(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 219, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d349, i32 0, i32 1) }, { i64, ptr } { i64 54, ptr getelementptr inbounds (<{ i64, [54 x i8] }>, ptr @.d350, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eExternResult(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 136, ptr getelementptr inbounds (<{ i64, [136 x i8] }>, ptr @.d351, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 136, ptr getelementptr inbounds (<{ i64, [136 x i8] }>, ptr @.d351, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 207, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d352, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eFieldBindingUnknown(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 301, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d353, i32 0, i32 1) }, { i64, ptr } { i64 122, ptr getelementptr inbounds (<{ i64, [122 x i8] }>, ptr @.d354, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eForInClauseExit(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 486, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d355, i32 0, i32 1) }, { i64, ptr } { i64 104, ptr getelementptr inbounds (<{ i64, [104 x i8] }>, ptr @.d356, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eForInNameExists(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 116, ptr getelementptr inbounds (<{ i64, [116 x i8] }>, ptr @.d357, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 116, ptr getelementptr inbounds (<{ i64, [116 x i8] }>, ptr @.d357, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d358, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d358, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 487, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d359, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eFromBitsReceiver(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 95, ptr getelementptr inbounds (<{ i64, [95 x i8] }>, ptr @.d360, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 95, ptr getelementptr inbounds (<{ i64, [95 x i8] }>, ptr @.d360, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 435, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d361, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eFromCaseName(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 635, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d362, i32 0, i32 1) }, { i64, ptr } { i64 96, ptr getelementptr inbounds (<{ i64, [96 x i8] }>, ptr @.d363, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eGenErrorNotDeclared(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l6 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t1, 1
  %t5 = extractvalue { i64, ptr } %t1, 0
  %t6 = extractvalue { i64, ptr } { i64 98, ptr getelementptr inbounds (<{ i64, [98 x i8] }>, ptr @.d364, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 98, ptr getelementptr inbounds (<{ i64, [98 x i8] }>, ptr @.d364, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %t2, 1
  %t11 = extractvalue { i64, ptr } %t2, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d365, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d365, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 431, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d366, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l6
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l6
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eGenErrors(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 79, ptr getelementptr inbounds (<{ i64, [79 x i8] }>, ptr @.d367, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 79, ptr getelementptr inbounds (<{ i64, [79 x i8] }>, ptr @.d367, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d368, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d368, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 520, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d369, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eGenReturnValue(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 519, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d370, i32 0, i32 1) }, { i64, ptr } { i64 73, ptr getelementptr inbounds (<{ i64, [73 x i8] }>, ptr @.d371, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eGenYieldsBorrow(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l3 = alloca i1
  %l5 = alloca { i64, ptr }
  %l11 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 522, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d372, i32 0, i32 1) })
  store i1 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i1, ptr %l3, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d373, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d373, i32 0, i32 1) }, 0
  %t11 = extractvalue { i64, ptr } %t7, 1
  %t12 = extractvalue { i64, ptr } %t7, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d373, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d373, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t17 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t16)
  call void @olang_textcopy(ptr %t17, ptr %t8, i64 %t9)
  %t18 = getelementptr i8, ptr %t17, i64 %t9
  call void @olang_textcopy(ptr %t18, ptr %t11, i64 %t12)
  %t19 = getelementptr i8, ptr %t18, i64 %t12
  call void @olang_textcopy(ptr %t19, ptr %t14, i64 %t15)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t17, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l5, !tbaa !27
  br label %bb4
bb3:
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d374, i32 0, i32 1) }, ptr %l5, !tbaa !27
  br label %bb4
bb4:
  %t30 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d375, i32 0, i32 1) }, 1
  %t31 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d375, i32 0, i32 1) }, 0
  %t32 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t32, 1
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t35 = add i64 %t31, %t34
  %t36 = extractvalue { i64, ptr } { i64 93, ptr getelementptr inbounds (<{ i64, [93 x i8] }>, ptr @.d376, i32 0, i32 1) }, 1
  %t37 = extractvalue { i64, ptr } { i64 93, ptr getelementptr inbounds (<{ i64, [93 x i8] }>, ptr @.d376, i32 0, i32 1) }, 0
  %t38 = add i64 %t35, %t37
  %t39 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t38)
  call void @olang_textcopy(ptr %t39, ptr %t30, i64 %t31)
  %t40 = getelementptr i8, ptr %t39, i64 %t31
  call void @olang_textcopy(ptr %t40, ptr %t33, i64 %t34)
  %t41 = getelementptr i8, ptr %t40, i64 %t34
  call void @olang_textcopy(ptr %t41, ptr %t36, i64 %t37)
  %t42 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t39, 1
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t46 = extractvalue { i64, ptr } %t43, 1
  %t47 = mul i64 %t45, 1
  %t48 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t47)
  call void @llvm.memcpy.p0.p0.i64(ptr %t48, ptr %t46, i64 %t47, i1 false)
  %t49 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  %t51 = load i32, ptr %l1
  %t53 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t51, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d377, i32 0, i32 1) }, { i64, ptr } %t50)
  store %"compiler/msgs:Msg" %t53, ptr %l11
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t54 = load %"compiler/msgs:Msg", ptr %l11
  store %"compiler/msgs:Msg" %t54, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eGenericNotStruct(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 220, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d378, i32 0, i32 1) }, { i64, ptr } { i64 55, ptr getelementptr inbounds (<{ i64, [55 x i8] }>, ptr @.d379, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eGlobalReadsItself(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d380, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d380, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d381, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d381, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 621, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d382, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportAliasConflict(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d383, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d383, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d384, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d384, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 101, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d385, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportLeavesRoot(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d386, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d386, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d387, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d387, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 98, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d388, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportLockNotACommit(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d389, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d389, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d390, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d390, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 92, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d391, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportReachedTwice(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 61, ptr getelementptr inbounds (<{ i64, [61 x i8] }>, ptr @.d392, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 61, ptr getelementptr inbounds (<{ i64, [61 x i8] }>, ptr @.d392, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 106, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d393, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportRemoteBadName(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 91, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d394, i32 0, i32 1) }, { i64, ptr } { i64 97, ptr getelementptr inbounds (<{ i64, [97 x i8] }>, ptr @.d395, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eIncdecInExpression(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 55, ptr getelementptr inbounds (<{ i64, [55 x i8] }>, ptr @.d396, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 55, ptr getelementptr inbounds (<{ i64, [55 x i8] }>, ptr @.d396, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 387, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d397, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eInstanceOutlivesReferent(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 471, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d398, i32 0, i32 1) }, { i64, ptr } { i64 113, ptr getelementptr inbounds (<{ i64, [113 x i8] }>, ptr @.d399, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eIntLiteralTooLarge(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 78, ptr getelementptr inbounds (<{ i64, [78 x i8] }>, ptr @.d400, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 78, ptr getelementptr inbounds (<{ i64, [78 x i8] }>, ptr @.d400, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 363, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d401, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eInvalidReferenceTarget(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 63, ptr getelementptr inbounds (<{ i64, [63 x i8] }>, ptr @.d402, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 63, ptr getelementptr inbounds (<{ i64, [63 x i8] }>, ptr @.d402, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 162, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d403, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eIsCaseWritten(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l10 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d404, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d404, i32 0, i32 1) }, 0
  %t8 = extractvalue { i64, ptr } %t1, 1
  %t9 = extractvalue { i64, ptr } %t1, 0
  %t10 = add i64 %t6, %t9
  %t11 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d405, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d405, i32 0, i32 1) }, 0
  %t13 = add i64 %t10, %t12
  %t15 = extractvalue { i64, ptr } %a1, 1
  %t16 = extractvalue { i64, ptr } %a1, 0
  %t17 = add i64 %t13, %t16
  %t18 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d406, i32 0, i32 1) }, 1
  %t19 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d406, i32 0, i32 1) }, 0
  %t20 = add i64 %t17, %t19
  %t22 = extractvalue { i64, ptr } %t3, 1
  %t23 = extractvalue { i64, ptr } %t3, 0
  %t24 = add i64 %t20, %t23
  %t25 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d406, i32 0, i32 1) }, 1
  %t26 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d406, i32 0, i32 1) }, 0
  %t27 = add i64 %t24, %t26
  %t29 = extractvalue { i64, ptr } %a2, 1
  %t30 = extractvalue { i64, ptr } %a2, 0
  %t31 = add i64 %t27, %t30
  %t32 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d407, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d407, i32 0, i32 1) }, 0
  %t34 = add i64 %t31, %t33
  %t35 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t34)
  call void @olang_textcopy(ptr %t35, ptr %t5, i64 %t6)
  %t36 = getelementptr i8, ptr %t35, i64 %t6
  call void @olang_textcopy(ptr %t36, ptr %t8, i64 %t9)
  %t37 = getelementptr i8, ptr %t36, i64 %t9
  call void @olang_textcopy(ptr %t37, ptr %t11, i64 %t12)
  %t38 = getelementptr i8, ptr %t37, i64 %t12
  call void @olang_textcopy(ptr %t38, ptr %t15, i64 %t16)
  %t39 = getelementptr i8, ptr %t38, i64 %t16
  call void @olang_textcopy(ptr %t39, ptr %t18, i64 %t19)
  %t40 = getelementptr i8, ptr %t39, i64 %t19
  call void @olang_textcopy(ptr %t40, ptr %t22, i64 %t23)
  %t41 = getelementptr i8, ptr %t40, i64 %t23
  call void @olang_textcopy(ptr %t41, ptr %t25, i64 %t26)
  %t42 = getelementptr i8, ptr %t41, i64 %t26
  call void @olang_textcopy(ptr %t42, ptr %t29, i64 %t30)
  %t43 = getelementptr i8, ptr %t42, i64 %t30
  call void @olang_textcopy(ptr %t43, ptr %t32, i64 %t33)
  %t44 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t35, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = extractvalue { i64, ptr } %t45, 1
  %t49 = mul i64 %t47, 1
  %t50 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t49)
  call void @llvm.memcpy.p0.p0.i64(ptr %t50, ptr %t48, i64 %t49, i1 false)
  %t51 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  %t55 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 393, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d408, i32 0, i32 1) }, { i64, ptr } %t52)
  store %"compiler/msgs:Msg" %t55, ptr %l10
  br label %bb1
bb1:
  %t56 = load %"compiler/msgs:Msg", ptr %l10
  store %"compiler/msgs:Msg" %t56, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eIsDirectory(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 46, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d409, i32 0, i32 1) }, { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d410, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eIsNullOfNull(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 395, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d411, i32 0, i32 1) }, { i64, ptr } { i64 80, ptr getelementptr inbounds (<{ i64, [80 x i8] }>, ptr @.d412, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eIsNullOfValue(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d413, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d413, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 394, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d414, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eIsOnlyNull(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 53, ptr getelementptr inbounds (<{ i64, [53 x i8] }>, ptr @.d415, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 53, ptr getelementptr inbounds (<{ i64, [53 x i8] }>, ptr @.d415, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d416, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d416, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 392, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d417, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinCannotFail(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 555, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d418, i32 0, i32 1) }, { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d419, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinCatchNeedsTry(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 556, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d420, i32 0, i32 1) }, { i64, ptr } { i64 79, ptr getelementptr inbounds (<{ i64, [79 x i8] }>, ptr @.d421, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinClauseMustLeave(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 557, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d422, i32 0, i32 1) }, { i64, ptr } { i64 93, ptr getelementptr inbounds (<{ i64, [93 x i8] }>, ptr @.d423, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinNextLine(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 479, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d424, i32 0, i32 1) }, { i64, ptr } { i64 100, ptr getelementptr inbounds (<{ i64, [100 x i8] }>, ptr @.d425, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinNotTried(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d426, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d426, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 64, ptr getelementptr inbounds (<{ i64, [64 x i8] }>, ptr @.d427, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 64, ptr getelementptr inbounds (<{ i64, [64 x i8] }>, ptr @.d427, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 554, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d428, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinPieceCalled(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 389, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d429, i32 0, i32 1) }, { i64, ptr } { i64 77, ptr getelementptr inbounds (<{ i64, [77 x i8] }>, ptr @.d430, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinWithoutSpawn(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 540, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d431, i32 0, i32 1) }, { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d432, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eKeywordFieldRead(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 99, ptr getelementptr inbounds (<{ i64, [99 x i8] }>, ptr @.d433, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 99, ptr getelementptr inbounds (<{ i64, [99 x i8] }>, ptr @.d433, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 76, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d434, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLambdaParamUntyped(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d435, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d435, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d436, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d436, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 576, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d437, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLambdaResultHeld(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d438, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d438, i32 0, i32 1) }, 0
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d439, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d439, i32 0, i32 1) }, 0
  %t12 = add i64 %t9, %t11
  %t14 = extractvalue { i64, ptr } %a1, 1
  %t15 = extractvalue { i64, ptr } %a1, 0
  %t16 = add i64 %t12, %t15
  %t17 = extractvalue { i64, ptr } { i64 94, ptr getelementptr inbounds (<{ i64, [94 x i8] }>, ptr @.d440, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 94, ptr getelementptr inbounds (<{ i64, [94 x i8] }>, ptr @.d440, i32 0, i32 1) }, 0
  %t19 = add i64 %t16, %t18
  %t21 = extractvalue { i64, ptr } %a2, 1
  %t22 = extractvalue { i64, ptr } %a2, 0
  %t23 = add i64 %t19, %t22
  %t24 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d441, i32 0, i32 1) }, 1
  %t25 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d441, i32 0, i32 1) }, 0
  %t26 = add i64 %t23, %t25
  %t27 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t4, i64 %t5)
  %t28 = getelementptr i8, ptr %t27, i64 %t5
  call void @olang_textcopy(ptr %t28, ptr %t7, i64 %t8)
  %t29 = getelementptr i8, ptr %t28, i64 %t8
  call void @olang_textcopy(ptr %t29, ptr %t10, i64 %t11)
  %t30 = getelementptr i8, ptr %t29, i64 %t11
  call void @olang_textcopy(ptr %t30, ptr %t14, i64 %t15)
  %t31 = getelementptr i8, ptr %t30, i64 %t15
  call void @olang_textcopy(ptr %t31, ptr %t17, i64 %t18)
  %t32 = getelementptr i8, ptr %t31, i64 %t18
  call void @olang_textcopy(ptr %t32, ptr %t21, i64 %t22)
  %t33 = getelementptr i8, ptr %t32, i64 %t22
  call void @olang_textcopy(ptr %t33, ptr %t24, i64 %t25)
  %t34 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t27, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = extractvalue { i64, ptr } %t35, 1
  %t39 = mul i64 %t37, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t39)
  call void @llvm.memcpy.p0.p0.i64(ptr %t40, ptr %t38, i64 %t39, i1 false)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  %t45 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 159, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d442, i32 0, i32 1) }, { i64, ptr } %t42)
  store %"compiler/msgs:Msg" %t45, ptr %l9
  br label %bb1
bb1:
  %t46 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t46, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLambdaResultUninferable(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 573, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d443, i32 0, i32 1) }, { i64, ptr } { i64 54, ptr getelementptr inbounds (<{ i64, [54 x i8] }>, ptr @.d444, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLambdaSignature(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d445, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d445, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d446, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d446, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 575, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d447, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLambdaValueObligations(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d448, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d448, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 91, ptr getelementptr inbounds (<{ i64, [91 x i8] }>, ptr @.d449, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 91, ptr getelementptr inbounds (<{ i64, [91 x i8] }>, ptr @.d449, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 568, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d450, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLaneCompare(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d451, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d451, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d452, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d452, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 684, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d453, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLaneLengths(ptr %v0, i64 %a0, i64 %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d454, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d454, i32 0, i32 1) }, 0
  %t6 = call i64 @__olang_fmt_i64(ptr null, i64 %a0)
  %t7 = add i64 %t4, %t6
  %t8 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d455, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d455, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t12 = call i64 @__olang_fmt_i64(ptr null, i64 %a1)
  %t13 = add i64 %t10, %t12
  %t14 = extractvalue { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d456, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d456, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t17 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t16)
  call void @olang_textcopy(ptr %t17, ptr %t3, i64 %t4)
  %t18 = getelementptr i8, ptr %t17, i64 %t4
  %t19 = call i64 @__olang_fmt_i64(ptr %t18, i64 %a0)
  %t20 = getelementptr i8, ptr %t18, i64 %t6
  call void @olang_textcopy(ptr %t20, ptr %t8, i64 %t9)
  %t21 = getelementptr i8, ptr %t20, i64 %t9
  %t22 = call i64 @__olang_fmt_i64(ptr %t21, i64 %a1)
  %t23 = getelementptr i8, ptr %t21, i64 %t12
  call void @olang_textcopy(ptr %t23, ptr %t14, i64 %t15)
  %t24 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t17, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 682, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d457, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLineBodyNotSimple(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d458, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d458, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d459, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d459, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 32, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d460, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLineBodyOnLine(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 31, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d461, i32 0, i32 1) }, { i64, ptr } { i64 72, ptr getelementptr inbounds (<{ i64, [72 x i8] }>, ptr @.d462, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLineStartsWithOperator(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d463, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d463, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 59, ptr getelementptr inbounds (<{ i64, [59 x i8] }>, ptr @.d464, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 59, ptr getelementptr inbounds (<{ i64, [59 x i8] }>, ptr @.d464, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d465, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d465, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 496, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d466, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLinkFailed(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d467, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d467, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d468, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d468, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 50, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d469, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLinkName(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 111, ptr getelementptr inbounds (<{ i64, [111 x i8] }>, ptr @.d470, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 111, ptr getelementptr inbounds (<{ i64, [111 x i8] }>, ptr @.d470, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 210, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d471, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLiteralExprRange(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d472, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d472, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 266, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d473, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMainSignature(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 603, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d474, i32 0, i32 1) }, { i64, ptr } { i64 84, ptr getelementptr inbounds (<{ i64, [84 x i8] }>, ptr @.d475, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMatchValueNeedsNomatch(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d476, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d476, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 73, ptr getelementptr inbounds (<{ i64, [73 x i8] }>, ptr @.d477, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 73, ptr getelementptr inbounds (<{ i64, [73 x i8] }>, ptr @.d477, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 505, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d478, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMatchValueTypes(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d479, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d479, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d480, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d480, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t3, i64 %t4)
  %t17 = getelementptr i8, ptr %t16, i64 %t4
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t9, i64 %t10)
  %t19 = getelementptr i8, ptr %t18, i64 %t10
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 503, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d481, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMatmulUndeclared(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d482, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d482, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d483, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d483, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 380, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d484, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMayBeNull(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l11 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d485, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d485, i32 0, i32 1) }, 0
  %t8 = extractvalue { i64, ptr } %a0, 1
  %t9 = extractvalue { i64, ptr } %a0, 0
  %t10 = add i64 %t6, %t9
  %t11 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d486, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d486, i32 0, i32 1) }, 0
  %t13 = add i64 %t10, %t12
  %t15 = extractvalue { i64, ptr } %a1, 1
  %t16 = extractvalue { i64, ptr } %a1, 0
  %t17 = add i64 %t13, %t16
  %t18 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d487, i32 0, i32 1) }, 1
  %t19 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d487, i32 0, i32 1) }, 0
  %t20 = add i64 %t17, %t19
  %t22 = extractvalue { i64, ptr } %a2, 1
  %t23 = extractvalue { i64, ptr } %a2, 0
  %t24 = add i64 %t20, %t23
  %t25 = extractvalue { i64, ptr } { i64 58, ptr getelementptr inbounds (<{ i64, [58 x i8] }>, ptr @.d488, i32 0, i32 1) }, 1
  %t26 = extractvalue { i64, ptr } { i64 58, ptr getelementptr inbounds (<{ i64, [58 x i8] }>, ptr @.d488, i32 0, i32 1) }, 0
  %t27 = add i64 %t24, %t26
  %t29 = extractvalue { i64, ptr } %a3, 1
  %t30 = extractvalue { i64, ptr } %a3, 0
  %t31 = add i64 %t27, %t30
  %t32 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d489, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d489, i32 0, i32 1) }, 0
  %t34 = add i64 %t31, %t33
  %t35 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t34)
  call void @olang_textcopy(ptr %t35, ptr %t5, i64 %t6)
  %t36 = getelementptr i8, ptr %t35, i64 %t6
  call void @olang_textcopy(ptr %t36, ptr %t8, i64 %t9)
  %t37 = getelementptr i8, ptr %t36, i64 %t9
  call void @olang_textcopy(ptr %t37, ptr %t11, i64 %t12)
  %t38 = getelementptr i8, ptr %t37, i64 %t12
  call void @olang_textcopy(ptr %t38, ptr %t15, i64 %t16)
  %t39 = getelementptr i8, ptr %t38, i64 %t16
  call void @olang_textcopy(ptr %t39, ptr %t18, i64 %t19)
  %t40 = getelementptr i8, ptr %t39, i64 %t19
  call void @olang_textcopy(ptr %t40, ptr %t22, i64 %t23)
  %t41 = getelementptr i8, ptr %t40, i64 %t23
  call void @olang_textcopy(ptr %t41, ptr %t25, i64 %t26)
  %t42 = getelementptr i8, ptr %t41, i64 %t26
  call void @olang_textcopy(ptr %t42, ptr %t29, i64 %t30)
  %t43 = getelementptr i8, ptr %t42, i64 %t30
  call void @olang_textcopy(ptr %t43, ptr %t32, i64 %t33)
  %t44 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t35, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = extractvalue { i64, ptr } %t45, 1
  %t49 = mul i64 %t47, 1
  %t50 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t49)
  call void @llvm.memcpy.p0.p0.i64(ptr %t50, ptr %t48, i64 %t49, i1 false)
  %t51 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  %t55 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, i32 401, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d490, i32 0, i32 1) }, { i64, ptr } %t52)
  store %"compiler/msgs:Msg" %t55, ptr %l11
  br label %bb1
bb1:
  %t56 = load %"compiler/msgs:Msg", ptr %l11
  store %"compiler/msgs:Msg" %t56, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMemberIsPrivate(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d491, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d491, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d492, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d492, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d493, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d493, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 333, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d494, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMembershipNotBool(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d495, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d495, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 385, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d496, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodAmbiguous(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d497, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d497, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d498, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d498, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 456, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d499, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodInUse(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d500, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d500, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d501, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d501, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 245, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d502, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodOnBuiltinType(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d503, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d503, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 59, ptr getelementptr inbounds (<{ i64, [59 x i8] }>, ptr @.d504, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 59, ptr getelementptr inbounds (<{ i64, [59 x i8] }>, ptr @.d504, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 244, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d505, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMissingTypeArgs(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d506, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d506, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d507, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d507, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 144, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d508, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeFirst(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d509, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d509, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d510, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d510, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 9, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d511, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeNoFiles(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d512, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d512, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 28, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d513, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeOneFile(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d514, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d514, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 2, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d515, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eModuleIdentityClash(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d516, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d516, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d517, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d517, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 623, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d518, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMutOnInferredLocal(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 477, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d519, i32 0, i32 1) }, { i64, ptr } { i64 99, ptr getelementptr inbounds (<{ i64, [99 x i8] }>, ptr @.d520, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMutOnValueParam(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 95, ptr getelementptr inbounds (<{ i64, [95 x i8] }>, ptr @.d521, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 95, ptr getelementptr inbounds (<{ i64, [95 x i8] }>, ptr @.d521, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d522, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d522, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 213, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d523, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNameClashesWithImport(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 57, ptr getelementptr inbounds (<{ i64, [57 x i8] }>, ptr @.d524, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 57, ptr getelementptr inbounds (<{ i64, [57 x i8] }>, ptr @.d524, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 107, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d525, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNameInUse(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d526, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d526, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 128, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d527, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNameIsType(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 57, ptr getelementptr inbounds (<{ i64, [57 x i8] }>, ptr @.d528, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 57, ptr getelementptr inbounds (<{ i64, [57 x i8] }>, ptr @.d528, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 122, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d529, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNarrowNotNumber(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d530, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d530, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d531, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d531, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 147, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d532, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNarrowedWrite(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 400, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d533, i32 0, i32 1) }, { i64, ptr } { i64 94, ptr getelementptr inbounds (<{ i64, [94 x i8] }>, ptr @.d534, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNestedArrayLiteral(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 449, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d535, i32 0, i32 1) }, { i64, ptr } { i64 108, ptr getelementptr inbounds (<{ i64, [108 x i8] }>, ptr @.d536, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNeverNull(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d537, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d537, i32 0, i32 1) }, 0
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d538, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d538, i32 0, i32 1) }, 0
  %t12 = add i64 %t9, %t11
  %t14 = extractvalue { i64, ptr } %a1, 1
  %t15 = extractvalue { i64, ptr } %a1, 0
  %t16 = add i64 %t12, %t15
  %t17 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d539, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d539, i32 0, i32 1) }, 0
  %t19 = add i64 %t16, %t18
  %t21 = extractvalue { i64, ptr } %a2, 1
  %t22 = extractvalue { i64, ptr } %a2, 0
  %t23 = add i64 %t19, %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t4, i64 %t5)
  %t25 = getelementptr i8, ptr %t24, i64 %t5
  call void @olang_textcopy(ptr %t25, ptr %t7, i64 %t8)
  %t26 = getelementptr i8, ptr %t25, i64 %t8
  call void @olang_textcopy(ptr %t26, ptr %t10, i64 %t11)
  %t27 = getelementptr i8, ptr %t26, i64 %t11
  call void @olang_textcopy(ptr %t27, ptr %t14, i64 %t15)
  %t28 = getelementptr i8, ptr %t27, i64 %t15
  call void @olang_textcopy(ptr %t28, ptr %t17, i64 %t18)
  %t29 = getelementptr i8, ptr %t28, i64 %t18
  call void @olang_textcopy(ptr %t29, ptr %t21, i64 %t22)
  %t30 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t24, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t41 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 404, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d540, i32 0, i32 1) }, { i64, ptr } %t38)
  store %"compiler/msgs:Msg" %t41, ptr %l9
  br label %bb1
bb1:
  %t42 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t42, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoRawValues(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d541, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d541, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d542, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d542, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 633, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d543, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoRule(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d544, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d544, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 34, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d545, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSuchCaseMeant(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d546, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d546, i32 0, i32 1) }, 0
  %t9 = add i64 %t6, %t8
  %t11 = extractvalue { i64, ptr } %a1, 1
  %t12 = extractvalue { i64, ptr } %a1, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d547, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d547, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t18 = extractvalue { i64, ptr } %a2, 1
  %t19 = extractvalue { i64, ptr } %a2, 0
  %t20 = add i64 %t16, %t19
  %t21 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d548, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d548, i32 0, i32 1) }, 0
  %t23 = add i64 %t20, %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t5, i64 %t6)
  %t25 = getelementptr i8, ptr %t24, i64 %t6
  call void @olang_textcopy(ptr %t25, ptr %t7, i64 %t8)
  %t26 = getelementptr i8, ptr %t25, i64 %t8
  call void @olang_textcopy(ptr %t26, ptr %t11, i64 %t12)
  %t27 = getelementptr i8, ptr %t26, i64 %t12
  call void @olang_textcopy(ptr %t27, ptr %t14, i64 %t15)
  %t28 = getelementptr i8, ptr %t27, i64 %t15
  call void @olang_textcopy(ptr %t28, ptr %t18, i64 %t19)
  %t29 = getelementptr i8, ptr %t28, i64 %t19
  call void @olang_textcopy(ptr %t29, ptr %t21, i64 %t22)
  %t30 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t24, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t41 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 378, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d549, i32 0, i32 1) }, { i64, ptr } %t38)
  store %"compiler/msgs:Msg" %t41, ptr %l9
  br label %bb1
bb1:
  %t42 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t42, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoZeroNonNull(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 68, ptr getelementptr inbounds (<{ i64, [68 x i8] }>, ptr @.d550, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 68, ptr getelementptr inbounds (<{ i64, [68 x i8] }>, ptr @.d550, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t6, i64 %t7)
  %t15 = getelementptr i8, ptr %t14, i64 %t7
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t27 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 405, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d551, i32 0, i32 1) }, { i64, ptr } %t24)
  store %"compiler/msgs:Msg" %t27, ptr %l7
  br label %bb1
bb1:
  %t28 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoreturnHere(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d552, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d552, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 530, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d553, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotAMode(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d554, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d554, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 164, ptr getelementptr inbounds (<{ i64, [164 x i8] }>, ptr @.d555, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 164, ptr getelementptr inbounds (<{ i64, [164 x i8] }>, ptr @.d555, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 1, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d556, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotASource(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d557, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d557, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 56, ptr getelementptr inbounds (<{ i64, [56 x i8] }>, ptr @.d558, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 56, ptr getelementptr inbounds (<{ i64, [56 x i8] }>, ptr @.d558, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 8, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d559, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotAStatement(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 478, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d560, i32 0, i32 1) }, { i64, ptr } { i64 78, ptr getelementptr inbounds (<{ i64, [78 x i8] }>, ptr @.d561, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotAnEnum(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d562, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d562, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 453, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d563, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotCallable(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d564, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d564, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 388, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d565, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotExtendedOp(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d566, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d566, i32 0, i32 1) }, 0
  %t9 = add i64 %t6, %t8
  %t11 = extractvalue { i64, ptr } %a1, 1
  %t12 = extractvalue { i64, ptr } %a1, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d567, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d567, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t18 = extractvalue { i64, ptr } %a2, 1
  %t19 = extractvalue { i64, ptr } %a2, 0
  %t20 = add i64 %t16, %t19
  %t21 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d568, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d568, i32 0, i32 1) }, 0
  %t23 = add i64 %t20, %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t5, i64 %t6)
  %t25 = getelementptr i8, ptr %t24, i64 %t6
  call void @olang_textcopy(ptr %t25, ptr %t7, i64 %t8)
  %t26 = getelementptr i8, ptr %t25, i64 %t8
  call void @olang_textcopy(ptr %t26, ptr %t11, i64 %t12)
  %t27 = getelementptr i8, ptr %t26, i64 %t12
  call void @olang_textcopy(ptr %t27, ptr %t14, i64 %t15)
  %t28 = getelementptr i8, ptr %t27, i64 %t15
  call void @olang_textcopy(ptr %t28, ptr %t18, i64 %t19)
  %t29 = getelementptr i8, ptr %t28, i64 %t19
  call void @olang_textcopy(ptr %t29, ptr %t21, i64 %t22)
  %t30 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t24, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t41 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 381, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d569, i32 0, i32 1) }, { i64, ptr } %t38)
  store %"compiler/msgs:Msg" %t41, ptr %l9
  br label %bb1
bb1:
  %t42 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t42, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotIndexable(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d570, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d570, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 327, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d571, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotIterable(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 120, ptr getelementptr inbounds (<{ i64, [120 x i8] }>, ptr @.d572, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 120, ptr getelementptr inbounds (<{ i64, [120 x i8] }>, ptr @.d572, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 488, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d573, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotRegular(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 45, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d574, i32 0, i32 1) }, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d575, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotSliceable(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d576, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d576, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 330, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d577, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteAnyMethod(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d578, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d578, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 185, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d579, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteCondValue(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 613, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d580, i32 0, i32 1) }, { i64, ptr } { i64 111, ptr getelementptr inbounds (<{ i64, [111 x i8] }>, ptr @.d581, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteContractCondition(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 642, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d582, i32 0, i32 1) }, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d583, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDeclareWhere(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l13 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d584, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d584, i32 0, i32 1) }, 0
  %t9 = extractvalue { i64, ptr } %a0, 1
  %t10 = extractvalue { i64, ptr } %a0, 0
  %t11 = add i64 %t7, %t10
  %t12 = extractvalue { i64, ptr } { i64 69, ptr getelementptr inbounds (<{ i64, [69 x i8] }>, ptr @.d585, i32 0, i32 1) }, 1
  %t13 = extractvalue { i64, ptr } { i64 69, ptr getelementptr inbounds (<{ i64, [69 x i8] }>, ptr @.d585, i32 0, i32 1) }, 0
  %t14 = add i64 %t11, %t13
  %t16 = extractvalue { i64, ptr } %a1, 1
  %t17 = extractvalue { i64, ptr } %a1, 0
  %t18 = add i64 %t14, %t17
  %t19 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d586, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d586, i32 0, i32 1) }, 0
  %t21 = add i64 %t18, %t20
  %t23 = extractvalue { i64, ptr } %a2, 1
  %t24 = extractvalue { i64, ptr } %a2, 0
  %t25 = add i64 %t21, %t24
  %t26 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d587, i32 0, i32 1) }, 1
  %t27 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d587, i32 0, i32 1) }, 0
  %t28 = add i64 %t25, %t27
  %t30 = extractvalue { i64, ptr } %a3, 1
  %t31 = extractvalue { i64, ptr } %a3, 0
  %t32 = add i64 %t28, %t31
  %t33 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d588, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d588, i32 0, i32 1) }, 0
  %t35 = add i64 %t32, %t34
  %t37 = extractvalue { i64, ptr } %a4, 1
  %t38 = extractvalue { i64, ptr } %a4, 0
  %t39 = add i64 %t35, %t38
  %t40 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d589, i32 0, i32 1) }, 1
  %t41 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d589, i32 0, i32 1) }, 0
  %t42 = add i64 %t39, %t41
  %t43 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t42)
  call void @olang_textcopy(ptr %t43, ptr %t6, i64 %t7)
  %t44 = getelementptr i8, ptr %t43, i64 %t7
  call void @olang_textcopy(ptr %t44, ptr %t9, i64 %t10)
  %t45 = getelementptr i8, ptr %t44, i64 %t10
  call void @olang_textcopy(ptr %t45, ptr %t12, i64 %t13)
  %t46 = getelementptr i8, ptr %t45, i64 %t13
  call void @olang_textcopy(ptr %t46, ptr %t16, i64 %t17)
  %t47 = getelementptr i8, ptr %t46, i64 %t17
  call void @olang_textcopy(ptr %t47, ptr %t19, i64 %t20)
  %t48 = getelementptr i8, ptr %t47, i64 %t20
  call void @olang_textcopy(ptr %t48, ptr %t23, i64 %t24)
  %t49 = getelementptr i8, ptr %t48, i64 %t24
  call void @olang_textcopy(ptr %t49, ptr %t26, i64 %t27)
  %t50 = getelementptr i8, ptr %t49, i64 %t27
  call void @olang_textcopy(ptr %t50, ptr %t30, i64 %t31)
  %t51 = getelementptr i8, ptr %t50, i64 %t31
  call void @olang_textcopy(ptr %t51, ptr %t33, i64 %t34)
  %t52 = getelementptr i8, ptr %t51, i64 %t34
  call void @olang_textcopy(ptr %t52, ptr %t37, i64 %t38)
  %t53 = getelementptr i8, ptr %t52, i64 %t38
  call void @olang_textcopy(ptr %t53, ptr %t40, i64 %t41)
  %t54 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t43, 1
  %t57 = extractvalue { i64, ptr } %t55, 0
  %t58 = extractvalue { i64, ptr } %t55, 1
  %t59 = mul i64 %t57, 1
  %t60 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t59)
  call void @llvm.memcpy.p0.p0.i64(ptr %t60, ptr %t58, i64 %t59, i1 false)
  %t61 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t60, 1
  %t65 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v5, ptr %v5, ptr %v5, i32 607, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d590, i32 0, i32 1) }, { i64, ptr } %t62)
  store %"compiler/msgs:Msg" %t65, ptr %l13
  br label %bb1
bb1:
  %t66 = load %"compiler/msgs:Msg", ptr %l13
  store %"compiler/msgs:Msg" %t66, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteFuncTypeScopes(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 102, ptr getelementptr inbounds (<{ i64, [102 x i8] }>, ptr @.d591, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 102, ptr getelementptr inbounds (<{ i64, [102 x i8] }>, ptr @.d591, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d592, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d592, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 344, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d593, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteGroupFunctionType(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 281, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d594, i32 0, i32 1) }, { i64, ptr } { i64 106, ptr getelementptr inbounds (<{ i64, [106 x i8] }>, ptr @.d595, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteLiteralRangeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l11 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d596, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d596, i32 0, i32 1) }, 0
  %t8 = extractvalue { i64, ptr } %a0, 1
  %t9 = extractvalue { i64, ptr } %a0, 0
  %t10 = add i64 %t6, %t9
  %t11 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d597, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d597, i32 0, i32 1) }, 0
  %t13 = add i64 %t10, %t12
  %t15 = extractvalue { i64, ptr } %a1, 1
  %t16 = extractvalue { i64, ptr } %a1, 0
  %t17 = add i64 %t13, %t16
  %t18 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d598, i32 0, i32 1) }, 1
  %t19 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d598, i32 0, i32 1) }, 0
  %t20 = add i64 %t17, %t19
  %t22 = extractvalue { i64, ptr } %a2, 1
  %t23 = extractvalue { i64, ptr } %a2, 0
  %t24 = add i64 %t20, %t23
  %t25 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d599, i32 0, i32 1) }, 1
  %t26 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d599, i32 0, i32 1) }, 0
  %t27 = add i64 %t24, %t26
  %t29 = extractvalue { i64, ptr } %a3, 1
  %t30 = extractvalue { i64, ptr } %a3, 0
  %t31 = add i64 %t27, %t30
  %t32 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d600, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d600, i32 0, i32 1) }, 0
  %t34 = add i64 %t31, %t33
  %t35 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t34)
  call void @olang_textcopy(ptr %t35, ptr %t5, i64 %t6)
  %t36 = getelementptr i8, ptr %t35, i64 %t6
  call void @olang_textcopy(ptr %t36, ptr %t8, i64 %t9)
  %t37 = getelementptr i8, ptr %t36, i64 %t9
  call void @olang_textcopy(ptr %t37, ptr %t11, i64 %t12)
  %t38 = getelementptr i8, ptr %t37, i64 %t12
  call void @olang_textcopy(ptr %t38, ptr %t15, i64 %t16)
  %t39 = getelementptr i8, ptr %t38, i64 %t16
  call void @olang_textcopy(ptr %t39, ptr %t18, i64 %t19)
  %t40 = getelementptr i8, ptr %t39, i64 %t19
  call void @olang_textcopy(ptr %t40, ptr %t22, i64 %t23)
  %t41 = getelementptr i8, ptr %t40, i64 %t23
  call void @olang_textcopy(ptr %t41, ptr %t25, i64 %t26)
  %t42 = getelementptr i8, ptr %t41, i64 %t26
  call void @olang_textcopy(ptr %t42, ptr %t29, i64 %t30)
  %t43 = getelementptr i8, ptr %t42, i64 %t30
  call void @olang_textcopy(ptr %t43, ptr %t32, i64 %t33)
  %t44 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t35, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = extractvalue { i64, ptr } %t45, 1
  %t49 = mul i64 %t47, 1
  %t50 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t49)
  call void @llvm.memcpy.p0.p0.i64(ptr %t50, ptr %t48, i64 %t49, i1 false)
  %t51 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  %t55 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, i32 361, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d601, i32 0, i32 1) }, { i64, ptr } %t52)
  store %"compiler/msgs:Msg" %t55, ptr %l11
  br label %bb1
bb1:
  %t56 = load %"compiler/msgs:Msg", ptr %l11
  store %"compiler/msgs:Msg" %t56, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteLoopCopy(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d602, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d602, i32 0, i32 1) }, 0
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 89, ptr getelementptr inbounds (<{ i64, [89 x i8] }>, ptr @.d603, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 89, ptr getelementptr inbounds (<{ i64, [89 x i8] }>, ptr @.d603, i32 0, i32 1) }, 0
  %t12 = add i64 %t9, %t11
  %t14 = extractvalue { i64, ptr } %a1, 1
  %t15 = extractvalue { i64, ptr } %a1, 0
  %t16 = add i64 %t12, %t15
  %t17 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d604, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d604, i32 0, i32 1) }, 0
  %t19 = add i64 %t16, %t18
  %t21 = extractvalue { i64, ptr } %a2, 1
  %t22 = extractvalue { i64, ptr } %a2, 0
  %t23 = add i64 %t19, %t22
  %t24 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d605, i32 0, i32 1) }, 1
  %t25 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d605, i32 0, i32 1) }, 0
  %t26 = add i64 %t23, %t25
  %t27 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t4, i64 %t5)
  %t28 = getelementptr i8, ptr %t27, i64 %t5
  call void @olang_textcopy(ptr %t28, ptr %t7, i64 %t8)
  %t29 = getelementptr i8, ptr %t28, i64 %t8
  call void @olang_textcopy(ptr %t29, ptr %t10, i64 %t11)
  %t30 = getelementptr i8, ptr %t29, i64 %t11
  call void @olang_textcopy(ptr %t30, ptr %t14, i64 %t15)
  %t31 = getelementptr i8, ptr %t30, i64 %t15
  call void @olang_textcopy(ptr %t31, ptr %t17, i64 %t18)
  %t32 = getelementptr i8, ptr %t31, i64 %t18
  call void @olang_textcopy(ptr %t32, ptr %t21, i64 %t22)
  %t33 = getelementptr i8, ptr %t32, i64 %t22
  call void @olang_textcopy(ptr %t33, ptr %t24, i64 %t25)
  %t34 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t27, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = extractvalue { i64, ptr } %t35, 1
  %t39 = mul i64 %t37, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t39)
  call void @llvm.memcpy.p0.p0.i64(ptr %t40, ptr %t38, i64 %t39, i1 false)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  %t45 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 616, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d606, i32 0, i32 1) }, { i64, ptr } %t42)
  store %"compiler/msgs:Msg" %t45, ptr %l9
  br label %bb1
bb1:
  %t46 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t46, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteMakeWhere(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l11 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d607, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d607, i32 0, i32 1) }, 0
  %t8 = extractvalue { i64, ptr } %a0, 1
  %t9 = extractvalue { i64, ptr } %a0, 0
  %t10 = add i64 %t6, %t9
  %t11 = extractvalue { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d608, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d608, i32 0, i32 1) }, 0
  %t13 = add i64 %t10, %t12
  %t15 = extractvalue { i64, ptr } %a1, 1
  %t16 = extractvalue { i64, ptr } %a1, 0
  %t17 = add i64 %t13, %t16
  %t18 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d609, i32 0, i32 1) }, 1
  %t19 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d609, i32 0, i32 1) }, 0
  %t20 = add i64 %t17, %t19
  %t22 = extractvalue { i64, ptr } %a2, 1
  %t23 = extractvalue { i64, ptr } %a2, 0
  %t24 = add i64 %t20, %t23
  %t25 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d610, i32 0, i32 1) }, 1
  %t26 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d610, i32 0, i32 1) }, 0
  %t27 = add i64 %t24, %t26
  %t29 = extractvalue { i64, ptr } %a3, 1
  %t30 = extractvalue { i64, ptr } %a3, 0
  %t31 = add i64 %t27, %t30
  %t32 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d611, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d611, i32 0, i32 1) }, 0
  %t34 = add i64 %t31, %t33
  %t35 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t34)
  call void @olang_textcopy(ptr %t35, ptr %t5, i64 %t6)
  %t36 = getelementptr i8, ptr %t35, i64 %t6
  call void @olang_textcopy(ptr %t36, ptr %t8, i64 %t9)
  %t37 = getelementptr i8, ptr %t36, i64 %t9
  call void @olang_textcopy(ptr %t37, ptr %t11, i64 %t12)
  %t38 = getelementptr i8, ptr %t37, i64 %t12
  call void @olang_textcopy(ptr %t38, ptr %t15, i64 %t16)
  %t39 = getelementptr i8, ptr %t38, i64 %t16
  call void @olang_textcopy(ptr %t39, ptr %t18, i64 %t19)
  %t40 = getelementptr i8, ptr %t39, i64 %t19
  call void @olang_textcopy(ptr %t40, ptr %t22, i64 %t23)
  %t41 = getelementptr i8, ptr %t40, i64 %t23
  call void @olang_textcopy(ptr %t41, ptr %t25, i64 %t26)
  %t42 = getelementptr i8, ptr %t41, i64 %t26
  call void @olang_textcopy(ptr %t42, ptr %t29, i64 %t30)
  %t43 = getelementptr i8, ptr %t42, i64 %t30
  call void @olang_textcopy(ptr %t43, ptr %t32, i64 %t33)
  %t44 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t35, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = extractvalue { i64, ptr } %t45, 1
  %t49 = mul i64 %t47, 1
  %t50 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t49)
  call void @llvm.memcpy.p0.p0.i64(ptr %t50, ptr %t48, i64 %t49, i1 false)
  %t51 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  %t55 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, i32 605, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d612, i32 0, i32 1) }, { i64, ptr } %t52)
  store %"compiler/msgs:Msg" %t55, ptr %l11
  br label %bb1
bb1:
  %t56 = load %"compiler/msgs:Msg", ptr %l11
  store %"compiler/msgs:Msg" %t56, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteNullableDecl(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 403, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d613, i32 0, i32 1) }, { i64, ptr } { i64 66, ptr getelementptr inbounds (<{ i64, [66 x i8] }>, ptr @.d614, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotePrivateSpelling(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d615, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d615, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d616, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d616, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d617, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d617, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 355, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d618, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteReadOnlyCopy(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d619, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d619, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 54, ptr getelementptr inbounds (<{ i64, [54 x i8] }>, ptr @.d620, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 54, ptr getelementptr inbounds (<{ i64, [54 x i8] }>, ptr @.d620, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 282, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d621, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteStrKeepCopies(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d622, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d622, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d623, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d623, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 106, ptr getelementptr inbounds (<{ i64, [106 x i8] }>, ptr @.d624, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 106, ptr getelementptr inbounds (<{ i64, [106 x i8] }>, ptr @.d624, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 350, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d625, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteTextCopyWhere(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 81, ptr getelementptr inbounds (<{ i64, [81 x i8] }>, ptr @.d626, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 81, ptr getelementptr inbounds (<{ i64, [81 x i8] }>, ptr @.d626, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d627, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d627, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 615, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d628, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteVecGrewHere(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 345, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d629, i32 0, i32 1) }, { i64, ptr } { i64 118, ptr getelementptr inbounds (<{ i64, [118 x i8] }>, ptr @.d630, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteVecTaskHolds(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d631, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d631, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d632, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d632, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 348, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d633, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteZeroReferenceHasOne(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d634, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d634, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d635, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d635, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d636, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d636, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 353, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d637, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNulByte(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 56, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d638, i32 0, i32 1) }, { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d639, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNullToArray(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 67, ptr getelementptr inbounds (<{ i64, [67 x i8] }>, ptr @.d640, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 67, ptr getelementptr inbounds (<{ i64, [67 x i8] }>, ptr @.d640, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a1, 1
  %t7 = extractvalue { i64, ptr } %a1, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d641, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d641, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a0, 1
  %t14 = extractvalue { i64, ptr } %a0, 0
  %t15 = add i64 %t11, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t3, i64 %t4)
  %t17 = getelementptr i8, ptr %t16, i64 %t4
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t9, i64 %t10)
  %t19 = getelementptr i8, ptr %t18, i64 %t10
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 408, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d642, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNumberDoesNotFlow(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d643, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d643, i32 0, i32 1) }, 0
  %t9 = add i64 %t6, %t8
  %t11 = extractvalue { i64, ptr } %a1, 1
  %t12 = extractvalue { i64, ptr } %a1, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d644, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d644, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t18 = extractvalue { i64, ptr } %a2, 1
  %t19 = extractvalue { i64, ptr } %a2, 0
  %t20 = add i64 %t16, %t19
  %t21 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d645, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d645, i32 0, i32 1) }, 0
  %t23 = add i64 %t20, %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t5, i64 %t6)
  %t25 = getelementptr i8, ptr %t24, i64 %t6
  call void @olang_textcopy(ptr %t25, ptr %t7, i64 %t8)
  %t26 = getelementptr i8, ptr %t25, i64 %t8
  call void @olang_textcopy(ptr %t26, ptr %t11, i64 %t12)
  %t27 = getelementptr i8, ptr %t26, i64 %t12
  call void @olang_textcopy(ptr %t27, ptr %t14, i64 %t15)
  %t28 = getelementptr i8, ptr %t27, i64 %t15
  call void @olang_textcopy(ptr %t28, ptr %t18, i64 %t19)
  %t29 = getelementptr i8, ptr %t28, i64 %t19
  call void @olang_textcopy(ptr %t29, ptr %t21, i64 %t22)
  %t30 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t24, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t41 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 265, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d646, i32 0, i32 1) }, { i64, ptr } %t38)
  store %"compiler/msgs:Msg" %t41, ptr %l9
  br label %bb1
bb1:
  %t42 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t42, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNumbersDoNotMeet(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d647, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d647, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 56, ptr getelementptr inbounds (<{ i64, [56 x i8] }>, ptr @.d648, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 56, ptr getelementptr inbounds (<{ i64, [56 x i8] }>, ptr @.d648, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 373, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d649, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperandNotInt(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d650, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d650, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t6, i64 %t7)
  %t15 = getelementptr i8, ptr %t14, i64 %t7
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t27 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 366, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d651, i32 0, i32 1) }, { i64, ptr } %t24)
  store %"compiler/msgs:Msg" %t27, ptr %l7
  br label %bb1
bb1:
  %t28 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperandNotNumber(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d652, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d652, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t6, i64 %t7)
  %t15 = getelementptr i8, ptr %t14, i64 %t7
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t27 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 367, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d653, i32 0, i32 1) }, { i64, ptr } %t24)
  store %"compiler/msgs:Msg" %t27, ptr %l7
  br label %bb1
bb1:
  %t28 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperatorCallFails(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d654, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d654, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d655, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d655, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 391, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d656, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperatorResult(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d657, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d657, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 224, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d658, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eOptionNeedsValue(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d659, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d659, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t6, i64 %t7)
  %t15 = getelementptr i8, ptr %t14, i64 %t7
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t27 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 6, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d660, i32 0, i32 1) }, { i64, ptr } %t24)
  store %"compiler/msgs:Msg" %t27, ptr %l7
  br label %bb1
bb1:
  %t28 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eOutputCannotWrite(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 13, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d661, i32 0, i32 1) }, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d662, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eOutputNoDir(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d663, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d663, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d664, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d664, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t3, i64 %t4)
  %t17 = getelementptr i8, ptr %t16, i64 %t4
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t9, i64 %t10)
  %t19 = getelementptr i8, ptr %t18, i64 %t10
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 12, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d665, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eOwnCannotOutlive(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 258, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d666, i32 0, i32 1) }, { i64, ptr } { i64 65, ptr getelementptr inbounds (<{ i64, [65 x i8] }>, ptr @.d667, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2ePatternArity(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d668, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d668, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d669, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d669, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = call i64 @__olang_fmt_i64(ptr null, i64 %a1)
  %t14 = add i64 %t11, %t13
  %t15 = extractvalue { i64, ptr } { i64 64, ptr getelementptr inbounds (<{ i64, [64 x i8] }>, ptr @.d670, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 64, ptr getelementptr inbounds (<{ i64, [64 x i8] }>, ptr @.d670, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t17)
  call void @olang_textcopy(ptr %t18, ptr %t3, i64 %t4)
  %t19 = getelementptr i8, ptr %t18, i64 %t4
  call void @olang_textcopy(ptr %t19, ptr %t6, i64 %t7)
  %t20 = getelementptr i8, ptr %t19, i64 %t7
  call void @olang_textcopy(ptr %t20, ptr %t9, i64 %t10)
  %t21 = getelementptr i8, ptr %t20, i64 %t10
  %t22 = call i64 @__olang_fmt_i64(ptr %t21, i64 %a1)
  %t23 = getelementptr i8, ptr %t21, i64 %t13
  call void @olang_textcopy(ptr %t23, ptr %t15, i64 %t16)
  %t24 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t18, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 493, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d671, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2ePayloadScopesDisagree(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 467, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d672, i32 0, i32 1) }, { i64, ptr } { i64 101, ptr getelementptr inbounds (<{ i64, [101 x i8] }>, ptr @.d673, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2ePreludeConstRedeclared(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d674, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d674, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 250, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d675, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2ePrimCtorParam(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d676, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d676, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d677, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d677, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 216, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d678, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eProtocolPrivate(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l11 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d679, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d679, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t12 = extractvalue { i64, ptr } %a1, 1
  %t13 = extractvalue { i64, ptr } %a1, 0
  %t14 = add i64 %t10, %t13
  %t15 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d680, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d680, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t19 = extractvalue { i64, ptr } %a2, 1
  %t20 = extractvalue { i64, ptr } %a2, 0
  %t21 = add i64 %t17, %t20
  %t22 = extractvalue { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d681, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d681, i32 0, i32 1) }, 0
  %t24 = add i64 %t21, %t23
  %t26 = extractvalue { i64, ptr } %a3, 1
  %t27 = extractvalue { i64, ptr } %a3, 0
  %t28 = add i64 %t24, %t27
  %t29 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d682, i32 0, i32 1) }, 1
  %t30 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d682, i32 0, i32 1) }, 0
  %t31 = add i64 %t28, %t30
  %t32 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t31)
  call void @olang_textcopy(ptr %t32, ptr %t6, i64 %t7)
  %t33 = getelementptr i8, ptr %t32, i64 %t7
  call void @olang_textcopy(ptr %t33, ptr %t8, i64 %t9)
  %t34 = getelementptr i8, ptr %t33, i64 %t9
  call void @olang_textcopy(ptr %t34, ptr %t12, i64 %t13)
  %t35 = getelementptr i8, ptr %t34, i64 %t13
  call void @olang_textcopy(ptr %t35, ptr %t15, i64 %t16)
  %t36 = getelementptr i8, ptr %t35, i64 %t16
  call void @olang_textcopy(ptr %t36, ptr %t19, i64 %t20)
  %t37 = getelementptr i8, ptr %t36, i64 %t20
  call void @olang_textcopy(ptr %t37, ptr %t22, i64 %t23)
  %t38 = getelementptr i8, ptr %t37, i64 %t23
  call void @olang_textcopy(ptr %t38, ptr %t26, i64 %t27)
  %t39 = getelementptr i8, ptr %t38, i64 %t27
  call void @olang_textcopy(ptr %t39, ptr %t29, i64 %t30)
  %t40 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t32, 1
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t44 = extractvalue { i64, ptr } %t41, 1
  %t45 = mul i64 %t43, 1
  %t46 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t45)
  call void @llvm.memcpy.p0.p0.i64(ptr %t46, ptr %t44, i64 %t45, i1 false)
  %t47 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  %t51 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, i32 236, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d683, i32 0, i32 1) }, { i64, ptr } %t48)
  store %"compiler/msgs:Msg" %t51, ptr %l11
  br label %bb1
bb1:
  %t52 = load %"compiler/msgs:Msg", ptr %l11
  store %"compiler/msgs:Msg" %t52, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eRaiseNotCaught(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 68, ptr getelementptr inbounds (<{ i64, [68 x i8] }>, ptr @.d684, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 68, ptr getelementptr inbounds (<{ i64, [68 x i8] }>, ptr @.d684, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d685, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d685, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 657, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d686, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eRangeNotInt(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d687, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d687, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 481, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d688, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eRangeStep(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 482, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d689, i32 0, i32 1) }, { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d690, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eRawAnonymous(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 632, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d691, i32 0, i32 1) }, { i64, ptr } { i64 66, ptr getelementptr inbounds (<{ i64, [66 x i8] }>, ptr @.d692, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadMaybeNull(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d693, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d693, i32 0, i32 1) }, 0
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d694, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d694, i32 0, i32 1) }, 0
  %t12 = add i64 %t9, %t11
  %t14 = extractvalue { i64, ptr } %a1, 1
  %t15 = extractvalue { i64, ptr } %a1, 0
  %t16 = add i64 %t12, %t15
  %t17 = extractvalue { i64, ptr } { i64 98, ptr getelementptr inbounds (<{ i64, [98 x i8] }>, ptr @.d695, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 98, ptr getelementptr inbounds (<{ i64, [98 x i8] }>, ptr @.d695, i32 0, i32 1) }, 0
  %t19 = add i64 %t16, %t18
  %t21 = extractvalue { i64, ptr } %a2, 1
  %t22 = extractvalue { i64, ptr } %a2, 0
  %t23 = add i64 %t19, %t22
  %t24 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d696, i32 0, i32 1) }, 1
  %t25 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d696, i32 0, i32 1) }, 0
  %t26 = add i64 %t23, %t25
  %t27 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t4, i64 %t5)
  %t28 = getelementptr i8, ptr %t27, i64 %t5
  call void @olang_textcopy(ptr %t28, ptr %t7, i64 %t8)
  %t29 = getelementptr i8, ptr %t28, i64 %t8
  call void @olang_textcopy(ptr %t29, ptr %t10, i64 %t11)
  %t30 = getelementptr i8, ptr %t29, i64 %t11
  call void @olang_textcopy(ptr %t30, ptr %t14, i64 %t15)
  %t31 = getelementptr i8, ptr %t30, i64 %t15
  call void @olang_textcopy(ptr %t31, ptr %t17, i64 %t18)
  %t32 = getelementptr i8, ptr %t31, i64 %t18
  call void @olang_textcopy(ptr %t32, ptr %t21, i64 %t22)
  %t33 = getelementptr i8, ptr %t32, i64 %t22
  call void @olang_textcopy(ptr %t33, ptr %t24, i64 %t25)
  %t34 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t27, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = extractvalue { i64, ptr } %t35, 1
  %t39 = mul i64 %t37, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t39)
  call void @llvm.memcpy.p0.p0.i64(ptr %t40, ptr %t38, i64 %t39, i1 false)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  %t45 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 406, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d697, i32 0, i32 1) }, { i64, ptr } %t42)
  store %"compiler/msgs:Msg" %t45, ptr %l9
  br label %bb1
bb1:
  %t46 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t46, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyCopyArg(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l11 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d698, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d698, i32 0, i32 1) }, 0
  %t8 = extractvalue { i64, ptr } %a0, 1
  %t9 = extractvalue { i64, ptr } %a0, 0
  %t10 = add i64 %t6, %t9
  %t11 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d699, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d699, i32 0, i32 1) }, 0
  %t13 = add i64 %t10, %t12
  %t15 = extractvalue { i64, ptr } %a1, 1
  %t16 = extractvalue { i64, ptr } %a1, 0
  %t17 = add i64 %t13, %t16
  %t18 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d700, i32 0, i32 1) }, 1
  %t19 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d700, i32 0, i32 1) }, 0
  %t20 = add i64 %t17, %t19
  %t22 = extractvalue { i64, ptr } %a2, 1
  %t23 = extractvalue { i64, ptr } %a2, 0
  %t24 = add i64 %t20, %t23
  %t25 = extractvalue { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d701, i32 0, i32 1) }, 1
  %t26 = extractvalue { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d701, i32 0, i32 1) }, 0
  %t27 = add i64 %t24, %t26
  %t29 = extractvalue { i64, ptr } %a3, 1
  %t30 = extractvalue { i64, ptr } %a3, 0
  %t31 = add i64 %t27, %t30
  %t32 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t31)
  call void @olang_textcopy(ptr %t32, ptr %t5, i64 %t6)
  %t33 = getelementptr i8, ptr %t32, i64 %t6
  call void @olang_textcopy(ptr %t33, ptr %t8, i64 %t9)
  %t34 = getelementptr i8, ptr %t33, i64 %t9
  call void @olang_textcopy(ptr %t34, ptr %t11, i64 %t12)
  %t35 = getelementptr i8, ptr %t34, i64 %t12
  call void @olang_textcopy(ptr %t35, ptr %t15, i64 %t16)
  %t36 = getelementptr i8, ptr %t35, i64 %t16
  call void @olang_textcopy(ptr %t36, ptr %t18, i64 %t19)
  %t37 = getelementptr i8, ptr %t36, i64 %t19
  call void @olang_textcopy(ptr %t37, ptr %t22, i64 %t23)
  %t38 = getelementptr i8, ptr %t37, i64 %t23
  call void @olang_textcopy(ptr %t38, ptr %t25, i64 %t26)
  %t39 = getelementptr i8, ptr %t38, i64 %t26
  call void @olang_textcopy(ptr %t39, ptr %t29, i64 %t30)
  %t40 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t32, 1
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t44 = extractvalue { i64, ptr } %t41, 1
  %t45 = mul i64 %t43, 1
  %t46 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t45)
  call void @llvm.memcpy.p0.p0.i64(ptr %t46, ptr %t44, i64 %t45, i1 false)
  %t47 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  %t51 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, i32 276, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d702, i32 0, i32 1) }, { i64, ptr } %t48)
  store %"compiler/msgs:Msg" %t51, ptr %l11
  br label %bb1
bb1:
  %t52 = load %"compiler/msgs:Msg", ptr %l11
  store %"compiler/msgs:Msg" %t52, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyCopyDecl(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d703, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d703, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 134, ptr getelementptr inbounds (<{ i64, [134 x i8] }>, ptr @.d704, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 134, ptr getelementptr inbounds (<{ i64, [134 x i8] }>, ptr @.d704, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t3, i64 %t4)
  %t17 = getelementptr i8, ptr %t16, i64 %t4
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t9, i64 %t10)
  %t19 = getelementptr i8, ptr %t18, i64 %t10
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 271, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d705, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyFuncValue(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = extractvalue { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d706, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d706, i32 0, i32 1) }, 0
  %t9 = add i64 %t6, %t8
  %t11 = extractvalue { i64, ptr } %a1, 1
  %t12 = extractvalue { i64, ptr } %a1, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 110, ptr getelementptr inbounds (<{ i64, [110 x i8] }>, ptr @.d707, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 110, ptr getelementptr inbounds (<{ i64, [110 x i8] }>, ptr @.d707, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t18 = extractvalue { i64, ptr } %a2, 1
  %t19 = extractvalue { i64, ptr } %a2, 0
  %t20 = add i64 %t16, %t19
  %t21 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t20)
  call void @olang_textcopy(ptr %t21, ptr %t5, i64 %t6)
  %t22 = getelementptr i8, ptr %t21, i64 %t6
  call void @olang_textcopy(ptr %t22, ptr %t7, i64 %t8)
  %t23 = getelementptr i8, ptr %t22, i64 %t8
  call void @olang_textcopy(ptr %t23, ptr %t11, i64 %t12)
  %t24 = getelementptr i8, ptr %t23, i64 %t12
  call void @olang_textcopy(ptr %t24, ptr %t14, i64 %t15)
  %t25 = getelementptr i8, ptr %t24, i64 %t15
  call void @olang_textcopy(ptr %t25, ptr %t18, i64 %t19)
  %t26 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t21, 1
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t30 = extractvalue { i64, ptr } %t27, 1
  %t31 = mul i64 %t29, 1
  %t32 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t31)
  call void @llvm.memcpy.p0.p0.i64(ptr %t32, ptr %t30, i64 %t31, i1 false)
  %t33 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  %t37 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 280, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d708, i32 0, i32 1) }, { i64, ptr } %t34)
  store %"compiler/msgs:Msg" %t37, ptr %l9
  br label %bb1
bb1:
  %t38 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t38, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyRefKept(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d709, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d709, i32 0, i32 1) }, 0
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d710, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d710, i32 0, i32 1) }, 0
  %t12 = add i64 %t9, %t11
  %t14 = extractvalue { i64, ptr } %a1, 1
  %t15 = extractvalue { i64, ptr } %a1, 0
  %t16 = add i64 %t12, %t15
  %t17 = extractvalue { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d711, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d711, i32 0, i32 1) }, 0
  %t19 = add i64 %t16, %t18
  %t21 = extractvalue { i64, ptr } %a2, 1
  %t22 = extractvalue { i64, ptr } %a2, 0
  %t23 = add i64 %t19, %t22
  %t24 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d712, i32 0, i32 1) }, 1
  %t25 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d712, i32 0, i32 1) }, 0
  %t26 = add i64 %t23, %t25
  %t27 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t4, i64 %t5)
  %t28 = getelementptr i8, ptr %t27, i64 %t5
  call void @olang_textcopy(ptr %t28, ptr %t7, i64 %t8)
  %t29 = getelementptr i8, ptr %t28, i64 %t8
  call void @olang_textcopy(ptr %t29, ptr %t10, i64 %t11)
  %t30 = getelementptr i8, ptr %t29, i64 %t11
  call void @olang_textcopy(ptr %t30, ptr %t14, i64 %t15)
  %t31 = getelementptr i8, ptr %t30, i64 %t15
  call void @olang_textcopy(ptr %t31, ptr %t17, i64 %t18)
  %t32 = getelementptr i8, ptr %t31, i64 %t18
  call void @olang_textcopy(ptr %t32, ptr %t21, i64 %t22)
  %t33 = getelementptr i8, ptr %t32, i64 %t22
  call void @olang_textcopy(ptr %t33, ptr %t24, i64 %t25)
  %t34 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t27, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = extractvalue { i64, ptr } %t35, 1
  %t39 = mul i64 %t37, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t39)
  call void @llvm.memcpy.p0.p0.i64(ptr %t40, ptr %t38, i64 %t39, i1 false)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  %t45 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 275, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d713, i32 0, i32 1) }, { i64, ptr } %t42)
  store %"compiler/msgs:Msg" %t45, ptr %l9
  br label %bb1
bb1:
  %t46 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t46, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyToBuiltResultNo(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 270, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d714, i32 0, i32 1) }, { i64, ptr } { i64 151, ptr getelementptr inbounds (<{ i64, [151 x i8] }>, ptr @.d715, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyToWritable(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 268, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d716, i32 0, i32 1) }, { i64, ptr } { i64 85, ptr getelementptr inbounds (<{ i64, [85 x i8] }>, ptr @.d717, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReexportCycle(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d718, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d718, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d719, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d719, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 105, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d720, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReferenceNarrowed(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 303, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d721, i32 0, i32 1) }, { i64, ptr } { i64 98, ptr getelementptr inbounds (<{ i64, [98 x i8] }>, ptr @.d722, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflCaseOther(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d723, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d723, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d724, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d724, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t3, i64 %t4)
  %t17 = getelementptr i8, ptr %t16, i64 %t4
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t9, i64 %t10)
  %t19 = getelementptr i8, ptr %t18, i64 %t10
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 677, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d725, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflCaseUnreachable(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 678, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d726, i32 0, i32 1) }, { i64, ptr } { i64 71, ptr getelementptr inbounds (<{ i64, [71 x i8] }>, ptr @.d727, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflDescNoMember(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d728, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d728, i32 0, i32 1) }, 0
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d729, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d729, i32 0, i32 1) }, 0
  %t12 = add i64 %t9, %t11
  %t14 = extractvalue { i64, ptr } %a1, 1
  %t15 = extractvalue { i64, ptr } %a1, 0
  %t16 = add i64 %t12, %t15
  %t17 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d730, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d730, i32 0, i32 1) }, 0
  %t19 = add i64 %t16, %t18
  %t21 = extractvalue { i64, ptr } %a2, 1
  %t22 = extractvalue { i64, ptr } %a2, 0
  %t23 = add i64 %t19, %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t4, i64 %t5)
  %t25 = getelementptr i8, ptr %t24, i64 %t5
  call void @olang_textcopy(ptr %t25, ptr %t7, i64 %t8)
  %t26 = getelementptr i8, ptr %t25, i64 %t8
  call void @olang_textcopy(ptr %t26, ptr %t10, i64 %t11)
  %t27 = getelementptr i8, ptr %t26, i64 %t11
  call void @olang_textcopy(ptr %t27, ptr %t14, i64 %t15)
  %t28 = getelementptr i8, ptr %t27, i64 %t15
  call void @olang_textcopy(ptr %t28, ptr %t17, i64 %t18)
  %t29 = getelementptr i8, ptr %t28, i64 %t18
  call void @olang_textcopy(ptr %t29, ptr %t21, i64 %t22)
  %t30 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t24, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t41 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 675, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d731, i32 0, i32 1) }, { i64, ptr } %t38)
  store %"compiler/msgs:Msg" %t41, ptr %l9
  br label %bb1
bb1:
  %t42 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t42, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflIndexNotConst(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 668, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d732, i32 0, i32 1) }, { i64, ptr } { i64 92, ptr getelementptr inbounds (<{ i64, [92 x i8] }>, ptr @.d733, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflNoDefault(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d734, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d734, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d735, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d735, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 66, ptr getelementptr inbounds (<{ i64, [66 x i8] }>, ptr @.d736, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 66, ptr getelementptr inbounds (<{ i64, [66 x i8] }>, ptr @.d736, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 672, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d737, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflOfArgs(ptr %v0, i64 %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d738, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d738, i32 0, i32 1) }, 0
  %t5 = call i64 @__olang_fmt_i64(ptr null, i64 %a0)
  %t6 = add i64 %t3, %t5
  %t7 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t6)
  call void @olang_textcopy(ptr %t7, ptr %t2, i64 %t3)
  %t8 = getelementptr i8, ptr %t7, i64 %t3
  %t9 = call i64 @__olang_fmt_i64(ptr %t8, i64 %a0)
  %t10 = insertvalue { i64, ptr } undef, i64 %t6, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t7, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 673, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d739, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflTypeNotValue(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l6 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d740, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d740, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %t1, 1
  %t7 = extractvalue { i64, ptr } %t1, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 61, ptr getelementptr inbounds (<{ i64, [61 x i8] }>, ptr @.d741, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 61, ptr getelementptr inbounds (<{ i64, [61 x i8] }>, ptr @.d741, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %t2, 1
  %t14 = extractvalue { i64, ptr } %t2, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d742, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d742, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 676, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d743, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l6
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l6
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReraiseWordNotInSet(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d744, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d744, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d745, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d745, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d746, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d746, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 656, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d747, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnBorrowAsBuilt(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 511, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d748, i32 0, i32 1) }, { i64, ptr } { i64 86, ptr getelementptr inbounds (<{ i64, [86 x i8] }>, ptr @.d749, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnCount(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d750, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d750, i32 0, i32 1) }, 0
  %t7 = call i64 @__olang_fmt_i64(ptr null, i64 %a0)
  %t8 = add i64 %t5, %t7
  %t9 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d751, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d751, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d752, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d752, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t20 = call i64 @__olang_fmt_i64(ptr null, i64 %a2)
  %t21 = add i64 %t18, %t20
  %t22 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t21)
  call void @olang_textcopy(ptr %t22, ptr %t4, i64 %t5)
  %t23 = getelementptr i8, ptr %t22, i64 %t5
  %t24 = call i64 @__olang_fmt_i64(ptr %t23, i64 %a0)
  %t25 = getelementptr i8, ptr %t23, i64 %t7
  call void @olang_textcopy(ptr %t25, ptr %t9, i64 %t10)
  %t26 = getelementptr i8, ptr %t25, i64 %t10
  call void @olang_textcopy(ptr %t26, ptr %t13, i64 %t14)
  %t27 = getelementptr i8, ptr %t26, i64 %t14
  call void @olang_textcopy(ptr %t27, ptr %t16, i64 %t17)
  %t28 = getelementptr i8, ptr %t27, i64 %t17
  %t29 = call i64 @__olang_fmt_i64(ptr %t28, i64 %a2)
  %t30 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t22, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t41 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 524, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d753, i32 0, i32 1) }, { i64, ptr } %t38)
  store %"compiler/msgs:Msg" %t41, ptr %l9
  br label %bb1
bb1:
  %t42 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t42, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnInCtor(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 525, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d754, i32 0, i32 1) }, { i64, ptr } { i64 77, ptr getelementptr inbounds (<{ i64, [77 x i8] }>, ptr @.d755, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnInTest(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 526, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d756, i32 0, i32 1) }, { i64, ptr } { i64 56, ptr getelementptr inbounds (<{ i64, [56 x i8] }>, ptr @.d757, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnOwnStorage(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 512, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d758, i32 0, i32 1) }, { i64, ptr } { i64 98, ptr getelementptr inbounds (<{ i64, [98 x i8] }>, ptr @.d759, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eScopeArgCount(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 379, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d760, i32 0, i32 1) }, { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d761, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eScopeArgsDisagree(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 297, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d762, i32 0, i32 1) }, { i64, ptr } { i64 79, ptr getelementptr inbounds (<{ i64, [79 x i8] }>, ptr @.d763, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eScopeObligationUnmet(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 302, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d764, i32 0, i32 1) }, { i64, ptr } { i64 112, ptr getelementptr inbounds (<{ i64, [112 x i8] }>, ptr @.d765, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSemicolon(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 53, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d766, i32 0, i32 1) }, { i64, ptr } { i64 94, ptr getelementptr inbounds (<{ i64, [94 x i8] }>, ptr @.d767, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eShadowsFunction(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 83, ptr getelementptr inbounds (<{ i64, [83 x i8] }>, ptr @.d768, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 83, ptr getelementptr inbounds (<{ i64, [83 x i8] }>, ptr @.d768, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 248, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d769, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eShadowsType(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d770, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d770, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 251, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d771, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSliceSplitValue(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 299, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d772, i32 0, i32 1) }, { i64, ptr } { i64 143, ptr getelementptr inbounds (<{ i64, [143 x i8] }>, ptr @.d773, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnArgHoldsShort(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 559, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d774, i32 0, i32 1) }, { i64, ptr } { i64 108, ptr getelementptr inbounds (<{ i64, [108 x i8] }>, ptr @.d775, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnArgTooShort(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 558, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d776, i32 0, i32 1) }, { i64, ptr } { i64 93, ptr getelementptr inbounds (<{ i64, [93 x i8] }>, ptr @.d777, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnCaptureTooShort(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 560, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d778, i32 0, i32 1) }, { i64, ptr } { i64 93, ptr getelementptr inbounds (<{ i64, [93 x i8] }>, ptr @.d779, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnFuncTooShort(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 561, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d780, i32 0, i32 1) }, { i64, ptr } { i64 93, ptr getelementptr inbounds (<{ i64, [93 x i8] }>, ptr @.d781, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnResultAsRef(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l11 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d782, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d782, i32 0, i32 1) }, 0
  %t8 = extractvalue { i64, ptr } %a0, 1
  %t9 = extractvalue { i64, ptr } %a0, 0
  %t10 = add i64 %t6, %t9
  %t11 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d783, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d783, i32 0, i32 1) }, 0
  %t13 = add i64 %t10, %t12
  %t15 = extractvalue { i64, ptr } %a1, 1
  %t16 = extractvalue { i64, ptr } %a1, 0
  %t17 = add i64 %t13, %t16
  %t18 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d784, i32 0, i32 1) }, 1
  %t19 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d784, i32 0, i32 1) }, 0
  %t20 = add i64 %t17, %t19
  %t22 = extractvalue { i64, ptr } %a2, 1
  %t23 = extractvalue { i64, ptr } %a2, 0
  %t24 = add i64 %t20, %t23
  %t25 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d785, i32 0, i32 1) }, 1
  %t26 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d785, i32 0, i32 1) }, 0
  %t27 = add i64 %t24, %t26
  %t29 = extractvalue { i64, ptr } %a3, 1
  %t30 = extractvalue { i64, ptr } %a3, 0
  %t31 = add i64 %t27, %t30
  %t32 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d786, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d786, i32 0, i32 1) }, 0
  %t34 = add i64 %t31, %t33
  %t35 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t34)
  call void @olang_textcopy(ptr %t35, ptr %t5, i64 %t6)
  %t36 = getelementptr i8, ptr %t35, i64 %t6
  call void @olang_textcopy(ptr %t36, ptr %t8, i64 %t9)
  %t37 = getelementptr i8, ptr %t36, i64 %t9
  call void @olang_textcopy(ptr %t37, ptr %t11, i64 %t12)
  %t38 = getelementptr i8, ptr %t37, i64 %t12
  call void @olang_textcopy(ptr %t38, ptr %t15, i64 %t16)
  %t39 = getelementptr i8, ptr %t38, i64 %t16
  call void @olang_textcopy(ptr %t39, ptr %t18, i64 %t19)
  %t40 = getelementptr i8, ptr %t39, i64 %t19
  call void @olang_textcopy(ptr %t40, ptr %t22, i64 %t23)
  %t41 = getelementptr i8, ptr %t40, i64 %t23
  call void @olang_textcopy(ptr %t41, ptr %t25, i64 %t26)
  %t42 = getelementptr i8, ptr %t41, i64 %t26
  call void @olang_textcopy(ptr %t42, ptr %t29, i64 %t30)
  %t43 = getelementptr i8, ptr %t42, i64 %t30
  call void @olang_textcopy(ptr %t43, ptr %t32, i64 %t33)
  %t44 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t35, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = extractvalue { i64, ptr } %t45, 1
  %t49 = mul i64 %t47, 1
  %t50 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t49)
  call void @llvm.memcpy.p0.p0.i64(ptr %t50, ptr %t48, i64 %t49, i1 false)
  %t51 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  %t55 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, i32 564, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d787, i32 0, i32 1) }, { i64, ptr } %t52)
  store %"compiler/msgs:Msg" %t55, ptr %l11
  br label %bb1
bb1:
  %t56 = load %"compiler/msgs:Msg", ptr %l11
  store %"compiler/msgs:Msg" %t56, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnResultsDisagree(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 566, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d788, i32 0, i32 1) }, { i64, ptr } { i64 72, ptr getelementptr inbounds (<{ i64, [72 x i8] }>, ptr @.d789, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eStoreIntoUnknownScope(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 288, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d790, i32 0, i32 1) }, { i64, ptr } { i64 146, ptr getelementptr inbounds (<{ i64, [146 x i8] }>, ptr @.d791, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eStrOfNothing(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 362, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d792, i32 0, i32 1) }, { i64, ptr } { i64 54, ptr getelementptr inbounds (<{ i64, [54 x i8] }>, ptr @.d793, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eStrStoresInReceiver(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 341, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d794, i32 0, i32 1) }, { i64, ptr } { i64 148, ptr getelementptr inbounds (<{ i64, [148 x i8] }>, ptr @.d795, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eStringNewline(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 59, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d796, i32 0, i32 1) }, { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d797, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetMissing(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 17, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d798, i32 0, i32 1) }, { i64, ptr } { i64 55, ptr getelementptr inbounds (<{ i64, [55 x i8] }>, ptr @.d799, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetNoClang(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 84, ptr getelementptr inbounds (<{ i64, [84 x i8] }>, ptr @.d800, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 84, ptr getelementptr inbounds (<{ i64, [84 x i8] }>, ptr @.d800, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d801, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d801, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 23, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d802, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetNoEmulator(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l6 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d803, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d803, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %t1, 1
  %t7 = extractvalue { i64, ptr } %t1, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d804, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d804, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %t2, 1
  %t14 = extractvalue { i64, ptr } %t2, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d805, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d805, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 24, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d806, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l6
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l6
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetUnknown(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d807, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d807, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 187, ptr getelementptr inbounds (<{ i64, [187 x i8] }>, ptr @.d808, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 187, ptr getelementptr inbounds (<{ i64, [187 x i8] }>, ptr @.d808, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 18, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d809, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskClauseReturns(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 548, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d810, i32 0, i32 1) }, { i64, ptr } { i64 82, ptr getelementptr inbounds (<{ i64, [82 x i8] }>, ptr @.d811, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskDefaultExisting(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 553, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d812, i32 0, i32 1) }, { i64, ptr } { i64 118, ptr getelementptr inbounds (<{ i64, [118 x i8] }>, ptr @.d813, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTrailingComma(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d814, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d814, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d815, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d815, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 79, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d816, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTraitContractOutlives(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 184, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d817, i32 0, i32 1) }, { i64, ptr } { i64 111, ptr getelementptr inbounds (<{ i64, [111 x i8] }>, ptr @.d818, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTryCatchOnSlice(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 582, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d819, i32 0, i32 1) }, { i64, ptr } { i64 114, ptr getelementptr inbounds (<{ i64, [114 x i8] }>, ptr @.d820, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTryNothingFails(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d821, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d821, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d822, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d822, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 447, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d823, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTupleNotAValue(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 368, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d824, i32 0, i32 1) }, { i64, ptr } { i64 111, ptr getelementptr inbounds (<{ i64, [111 x i8] }>, ptr @.d825, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTwoPoints(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 71, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d826, i32 0, i32 1) }, { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d827, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgCount(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d828, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d828, i32 0, i32 1) }, 0
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d829, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d829, i32 0, i32 1) }, 0
  %t12 = add i64 %t9, %t11
  %t14 = call i64 @__olang_fmt_i64(ptr null, i64 %a1)
  %t15 = add i64 %t12, %t14
  %t16 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d830, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d830, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t20 = call i64 @__olang_fmt_i64(ptr null, i64 %a2)
  %t21 = add i64 %t18, %t20
  %t22 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t21)
  call void @olang_textcopy(ptr %t22, ptr %t4, i64 %t5)
  %t23 = getelementptr i8, ptr %t22, i64 %t5
  call void @olang_textcopy(ptr %t23, ptr %t7, i64 %t8)
  %t24 = getelementptr i8, ptr %t23, i64 %t8
  call void @olang_textcopy(ptr %t24, ptr %t10, i64 %t11)
  %t25 = getelementptr i8, ptr %t24, i64 %t11
  %t26 = call i64 @__olang_fmt_i64(ptr %t25, i64 %a1)
  %t27 = getelementptr i8, ptr %t25, i64 %t14
  call void @olang_textcopy(ptr %t27, ptr %t16, i64 %t17)
  %t28 = getelementptr i8, ptr %t27, i64 %t17
  %t29 = call i64 @__olang_fmt_i64(ptr %t28, i64 %a2)
  %t30 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t22, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t41 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 145, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d831, i32 0, i32 1) }, { i64, ptr } %t38)
  store %"compiler/msgs:Msg" %t41, ptr %l9
  br label %bb1
bb1:
  %t42 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t42, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgNamedScope(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 161, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d832, i32 0, i32 1) }, { i64, ptr } { i64 101, ptr getelementptr inbounds (<{ i64, [101 x i8] }>, ptr @.d833, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgsSpaced(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 59, ptr getelementptr inbounds (<{ i64, [59 x i8] }>, ptr @.d834, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 59, ptr getelementptr inbounds (<{ i64, [59 x i8] }>, ptr @.d834, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d835, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d835, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 572, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d836, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeDefinedThroughItself(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d837, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d837, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 217, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d838, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeHasNoConstructor(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d839, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d839, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d840, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d840, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 252, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d841, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeHoldsItself(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 64, ptr getelementptr inbounds (<{ i64, [64 x i8] }>, ptr @.d842, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 64, ptr getelementptr inbounds (<{ i64, [64 x i8] }>, ptr @.d842, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 142, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d843, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeIsPrivate(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d844, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d844, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d845, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d845, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 119, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d846, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeNameInUse(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d847, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d847, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d848, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d848, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 120, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d849, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeNotAValue(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d850, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d850, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 113, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d851, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeNotInferable(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 284, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d852, i32 0, i32 1) }, { i64, ptr } { i64 79, ptr getelementptr inbounds (<{ i64, [79 x i8] }>, ptr @.d853, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeVarNamesType(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d854, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d854, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d855, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d855, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 194, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d856, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnboundedInstantiation(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 141, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d857, i32 0, i32 1) }, { i64, ptr } { i64 72, ptr getelementptr inbounds (<{ i64, [72 x i8] }>, ptr @.d858, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnclosedChar(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 60, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d859, i32 0, i32 1) }, { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d860, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownBuildName(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d861, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d861, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 54, ptr getelementptr inbounds (<{ i64, [54 x i8] }>, ptr @.d862, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 54, ptr getelementptr inbounds (<{ i64, [54 x i8] }>, ptr @.d862, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d863, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d863, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 127, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d864, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownFunctionMeant(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d865, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d865, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d866, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d866, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d867, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d867, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 115, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d868, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownImport(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d869, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d869, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 102, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d870, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownMethod(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d871, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d871, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t6, i64 %t7)
  %t15 = getelementptr i8, ptr %t14, i64 %t7
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t27 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 432, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d872, i32 0, i32 1) }, { i64, ptr } %t24)
  store %"compiler/msgs:Msg" %t27, ptr %l7
  br label %bb1
bb1:
  %t28 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownName(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d873, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d873, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 111, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d874, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownNumberType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d875, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d875, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 58, ptr getelementptr inbounds (<{ i64, [58 x i8] }>, ptr @.d876, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 58, ptr getelementptr inbounds (<{ i64, [58 x i8] }>, ptr @.d876, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d877, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d877, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 110, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d878, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownScopeName(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 83, ptr getelementptr inbounds (<{ i64, [83 x i8] }>, ptr @.d879, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 83, ptr getelementptr inbounds (<{ i64, [83 x i8] }>, ptr @.d879, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 129, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d880, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownTypeMeant(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d881, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d881, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d882, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d882, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d883, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d883, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 109, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d884, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownTypeVar(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d885, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d885, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 499, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d886, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUsage(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 0, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d887, i32 0, i32 1) }, { i64, ptr } { i64 105, ptr getelementptr inbounds (<{ i64, [105 x i8] }>, ptr @.d888, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eValueAfterEq(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l11 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d889, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d889, i32 0, i32 1) }, 0
  %t8 = extractvalue { i64, ptr } %a0, 1
  %t9 = extractvalue { i64, ptr } %a0, 0
  %t10 = add i64 %t6, %t9
  %t11 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d890, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d890, i32 0, i32 1) }, 0
  %t13 = add i64 %t10, %t12
  %t15 = extractvalue { i64, ptr } %a1, 1
  %t16 = extractvalue { i64, ptr } %a1, 0
  %t17 = add i64 %t13, %t16
  %t18 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d891, i32 0, i32 1) }, 1
  %t19 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d891, i32 0, i32 1) }, 0
  %t20 = add i64 %t17, %t19
  %t22 = extractvalue { i64, ptr } %a2, 1
  %t23 = extractvalue { i64, ptr } %a2, 0
  %t24 = add i64 %t20, %t23
  %t25 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d892, i32 0, i32 1) }, 1
  %t26 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d892, i32 0, i32 1) }, 0
  %t27 = add i64 %t24, %t26
  %t29 = extractvalue { i64, ptr } %a3, 1
  %t30 = extractvalue { i64, ptr } %a3, 0
  %t31 = add i64 %t27, %t30
  %t32 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d893, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d893, i32 0, i32 1) }, 0
  %t34 = add i64 %t31, %t33
  %t35 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t34)
  call void @olang_textcopy(ptr %t35, ptr %t5, i64 %t6)
  %t36 = getelementptr i8, ptr %t35, i64 %t6
  call void @olang_textcopy(ptr %t36, ptr %t8, i64 %t9)
  %t37 = getelementptr i8, ptr %t36, i64 %t9
  call void @olang_textcopy(ptr %t37, ptr %t11, i64 %t12)
  %t38 = getelementptr i8, ptr %t37, i64 %t12
  call void @olang_textcopy(ptr %t38, ptr %t15, i64 %t16)
  %t39 = getelementptr i8, ptr %t38, i64 %t16
  call void @olang_textcopy(ptr %t39, ptr %t18, i64 %t19)
  %t40 = getelementptr i8, ptr %t39, i64 %t19
  call void @olang_textcopy(ptr %t40, ptr %t22, i64 %t23)
  %t41 = getelementptr i8, ptr %t40, i64 %t23
  call void @olang_textcopy(ptr %t41, ptr %t25, i64 %t26)
  %t42 = getelementptr i8, ptr %t41, i64 %t26
  call void @olang_textcopy(ptr %t42, ptr %t29, i64 %t30)
  %t43 = getelementptr i8, ptr %t42, i64 %t30
  call void @olang_textcopy(ptr %t43, ptr %t32, i64 %t33)
  %t44 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t35, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = extractvalue { i64, ptr } %t45, 1
  %t49 = mul i64 %t47, 1
  %t50 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t49)
  call void @llvm.memcpy.p0.p0.i64(ptr %t50, ptr %t48, i64 %t49, i1 false)
  %t51 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  %t55 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, i32 83, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d894, i32 0, i32 1) }, { i64, ptr } %t52)
  store %"compiler/msgs:Msg" %t55, ptr %l11
  br label %bb1
bb1:
  %t56 = load %"compiler/msgs:Msg", ptr %l11
  store %"compiler/msgs:Msg" %t56, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eValueRefsOutlived(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 474, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d895, i32 0, i32 1) }, { i64, ptr } { i64 91, ptr getelementptr inbounds (<{ i64, [91 x i8] }>, ptr @.d896, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eVecGrowsUnderTask(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d897, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d897, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 73, ptr getelementptr inbounds (<{ i64, [73 x i8] }>, ptr @.d898, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 73, ptr getelementptr inbounds (<{ i64, [73 x i8] }>, ptr @.d898, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d899, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d899, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 599, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d900, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eVecViewGivenGrowing(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l11 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d901, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d901, i32 0, i32 1) }, 0
  %t8 = extractvalue { i64, ptr } %a0, 1
  %t9 = extractvalue { i64, ptr } %a0, 0
  %t10 = add i64 %t6, %t9
  %t11 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d902, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d902, i32 0, i32 1) }, 0
  %t13 = add i64 %t10, %t12
  %t15 = extractvalue { i64, ptr } %a1, 1
  %t16 = extractvalue { i64, ptr } %a1, 0
  %t17 = add i64 %t13, %t16
  %t18 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d903, i32 0, i32 1) }, 1
  %t19 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d903, i32 0, i32 1) }, 0
  %t20 = add i64 %t17, %t19
  %t22 = extractvalue { i64, ptr } %a2, 1
  %t23 = extractvalue { i64, ptr } %a2, 0
  %t24 = add i64 %t20, %t23
  %t25 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d904, i32 0, i32 1) }, 1
  %t26 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d904, i32 0, i32 1) }, 0
  %t27 = add i64 %t24, %t26
  %t29 = extractvalue { i64, ptr } %a3, 1
  %t30 = extractvalue { i64, ptr } %a3, 0
  %t31 = add i64 %t27, %t30
  %t32 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d905, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d905, i32 0, i32 1) }, 0
  %t34 = add i64 %t31, %t33
  %t35 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t34)
  call void @olang_textcopy(ptr %t35, ptr %t5, i64 %t6)
  %t36 = getelementptr i8, ptr %t35, i64 %t6
  call void @olang_textcopy(ptr %t36, ptr %t8, i64 %t9)
  %t37 = getelementptr i8, ptr %t36, i64 %t9
  call void @olang_textcopy(ptr %t37, ptr %t11, i64 %t12)
  %t38 = getelementptr i8, ptr %t37, i64 %t12
  call void @olang_textcopy(ptr %t38, ptr %t15, i64 %t16)
  %t39 = getelementptr i8, ptr %t38, i64 %t16
  call void @olang_textcopy(ptr %t39, ptr %t18, i64 %t19)
  %t40 = getelementptr i8, ptr %t39, i64 %t19
  call void @olang_textcopy(ptr %t40, ptr %t22, i64 %t23)
  %t41 = getelementptr i8, ptr %t40, i64 %t23
  call void @olang_textcopy(ptr %t41, ptr %t25, i64 %t26)
  %t42 = getelementptr i8, ptr %t41, i64 %t26
  call void @olang_textcopy(ptr %t42, ptr %t29, i64 %t30)
  %t43 = getelementptr i8, ptr %t42, i64 %t30
  call void @olang_textcopy(ptr %t43, ptr %t32, i64 %t33)
  %t44 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t35, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = extractvalue { i64, ptr } %t45, 1
  %t49 = mul i64 %t47, 1
  %t50 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t49)
  call void @llvm.memcpy.p0.p0.i64(ptr %t50, ptr %t48, i64 %t49, i1 false)
  %t51 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  %t55 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, i32 598, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d906, i32 0, i32 1) }, { i64, ptr } %t52)
  store %"compiler/msgs:Msg" %t55, ptr %l11
  br label %bb1
bb1:
  %t56 = load %"compiler/msgs:Msg", ptr %l11
  store %"compiler/msgs:Msg" %t56, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eWriteThroughAtCall(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 422, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d907, i32 0, i32 1) }, { i64, ptr } { i64 196, ptr getelementptr inbounds (<{ i64, [196 x i8] }>, ptr @.d908, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eWriteThroughAtNoSetat(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d909, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d909, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 95, ptr getelementptr inbounds (<{ i64, [95 x i8] }>, ptr @.d910, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 95, ptr getelementptr inbounds (<{ i64, [95 x i8] }>, ptr @.d910, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 419, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d911, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eYieldInLambda(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 515, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d912, i32 0, i32 1) }, { i64, ptr } { i64 67, ptr getelementptr inbounds (<{ i64, [67 x i8] }>, ptr @.d913, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eYieldPastDefer(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 518, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d914, i32 0, i32 1) }, { i64, ptr } { i64 121, ptr getelementptr inbounds (<{ i64, [121 x i8] }>, ptr @.d915, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local void @olang_2einit_2ecompiler_2fmsgs() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fmsgs_2eEndOfLine_2einit()
  br label %bb1
bb1:
  call void @compiler_2fmsgs_2eEndOfFile_2einit()
  br label %bb2
bb2:
  br label %ret
ret:
  ret void
}

@.d0 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"S13c" }>, align 8
@.d1 = private constant <{ i64, [86 x i8] }> <{ i64 0, [86 x i8] c"every alternative binds the same names - bind it in each, write '_', or split the case" }>, align 8
@.d2 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T34" }>, align 8
@.d3 = private constant <{ i64, [88 x i8] }> <{ i64 0, [88 x i8] c"a type case binding a name is its clause's only alternative - bind '_' to share a clause" }>, align 8
@.d4 = private constant <{ i64, [60 x i8] }> <{ i64 0, [60 x i8] c"a type case matches an 'any' of a closed trait, and this is " }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d5 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T34" }>, align 8
@.d6 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T32a" }>, align 8
@.d7 = private constant <{ i64, [109 x i8] }> <{ i64 0, [109 x i8] c"the 'any' outlives what this array's elements refer to - its copy keeps them: build them where the 'any' goes" }>, align 8
@.d8 = private constant <{ i64, [44 x i8] }> <{ i64 0, [44 x i8] c"an 'any' is always a reference - write 'any " }>, align 8
@.d9 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"&'" }>, align 8
@.d10 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T32" }>, align 8
@.d11 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"an '" }>, align 8
@.d12 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"' is never made an '" }>, align 8
@.d13 = private constant <{ i64, [55 x i8] }> <{ i64 0, [55 x i8] c"' - an 'any' is made from its instance's own type, once" }>, align 8
@.d14 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T32a" }>, align 8
@.d15 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" cannot be an 'any " }>, align 8
@.d16 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"&': " }>, align 8
@.d17 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" is closed, met by " }>, align 8
@.d18 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" alone" }>, align 8
@.d19 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"T32a, T31a" }>, align 8
@.d20 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c" is not one of the types " }>, align 8
@.d21 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" lists" }>, align 8
@.d22 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T34" }>, align 8
@.d23 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"'any' takes a trait, and " }>, align 8
@.d24 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" is none" }>, align 8
@.d25 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T32" }>, align 8
@.d26 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"'s trait " }>, align 8
@.d27 = private constant <{ i64, [97 x i8] }> <{ i64 0, [97 x i8] c" is open, so its instance's type is never asked for - use its methods, or add the method it lacks" }>, align 8
@.d28 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T34" }>, align 8
@.d29 = private constant <{ i64, [91 x i8] }> <{ i64 0, [91 x i8] c"a task calls a function or a function value, never through an 'any''s table - write 'spawn " }>, align 8
@.d30 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"fn() " }>, align 8
@.d31 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" { return " }>, align 8
@.d32 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" }()'" }>, align 8
@.d33 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"T32b, P1" }>, align 8
@.d34 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" cannot be an 'any " }>, align 8
@.d35 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"&': it does not satisfy " }>, align 8
@.d36 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T32a" }>, align 8
@.d37 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"expected " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d38 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" argument" }>, align 8
@.d39 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", found " }>, align 8
@.d40 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E14" }>, align 8
@.d41 = private constant <{ i64, [78 x i8] }> <{ i64 0, [78 x i8] c" takes its array by value, so its length must be known while compiling - this " }>, align 8
@.d42 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"'s is known only at run time: take it as '" }>, align 8
@.d43 = private constant <{ i64, [48 x i8] }> <{ i64 0, [48 x i8] c"&', or pass a slice of a known length ('x[0:4]')" }>, align 8
@.d44 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"D9a" }>, align 8
@.d45 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c"an array's length is an integer, found " }>, align 8
@.d46 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"E13a" }>, align 8
@.d47 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c" has no values to put in an array" }>, align 8
@.d48 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T20" }>, align 8
@.d49 = private constant <{ i64, [61 x i8] }> <{ i64 0, [61 x i8] c" takes one index - several are passed to a type's At or SetAt" }>, align 8
@.d50 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E31" }>, align 8
@.d51 = private constant <{ i64, [60 x i8] }> <{ i64 0, [60 x i8] c"this array's length is known only at run time, stored where " }>, align 8
@.d52 = private constant <{ i64, [72 x i8] }> <{ i64 0, [72 x i8] c" elements are laid out - copy them through a slice of that length, 'v[0:" }>, align 8
@.d53 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"]'" }>, align 8
@.d54 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T7d" }>, align 8
@.d55 = private constant <{ i64, [55 x i8] }> <{ i64 0, [55 x i8] c"Array takes one type argument, its element type, found " }>, align 8
@.d56 = private constant <{ i64, [70 x i8] }> <{ i64 0, [70 x i8] c" - a length is never written in a type: 'Array<T>(n)' makes n elements" }>, align 8
@.d57 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"G8, T7" }>, align 8
@.d58 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"S12b" }>, align 8
@.d59 = private constant <{ i64, [94 x i8] }> <{ i64 0, [94 x i8] c"'=>' gives a value, which only a match used as a value takes - a statement's case runs a block" }>, align 8
@.d60 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"'=>' gives a value, and " }>, align 8
@.d61 = private constant <{ i64, [50 x i8] }> <{ i64 0, [50 x i8] c" gives none - a clause that leaves is a block: '{ " }>, align 8
@.d62 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" }'" }>, align 8
@.d63 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"S12b" }>, align 8
@.d64 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"after 'as' comes a case of " }>, align 8
@.d65 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", found " }>, align 8
@.d66 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E32" }>, align 8
@.d67 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"case " }>, align 8
@.d68 = private constant <{ i64, [57 x i8] }> <{ i64 0, [57 x i8] c" carries nothing for 'as' to give - test for it with '=='" }>, align 8
@.d69 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E32" }>, align 8
@.d70 = private constant <{ i64, [62 x i8] }> <{ i64 0, [62 x i8] c"this assertion aborts the program, evaluated while compiling: " }>, align 8
@.d71 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"S18c" }>, align 8
@.d72 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"S18c" }>, align 8
@.d73 = private constant <{ i64, [50 x i8] }> <{ i64 0, [50 x i8] c"this assertion is false, evaluated while compiling" }>, align 8
@.d74 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c" message is text, found " }>, align 8
@.d75 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c" - write it as text: \22x is \22 $x" }>, align 8
@.d76 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"S18a" }>, align 8
@.d77 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"an error may not leave " }>, align 8
@.d78 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c" message - catch it here" }>, align 8
@.d79 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"S17" }>, align 8
@.d80 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c" may not leave " }>, align 8
@.d81 = private constant <{ i64, [48 x i8] }> <{ i64 0, [48 x i8] c" message - it is evaluated only where it is used" }>, align 8
@.d82 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"S17" }>, align 8
@.d83 = private constant <{ i64, [65 x i8] }> <{ i64 0, [65 x i8] c"evaluated while compiling, this assertion stops on a stale view: " }>, align 8
@.d84 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"S18c, K1" }>, align 8
@.d85 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"R9a" }>, align 8
@.d86 = private constant <{ i64, [165 x i8] }> <{ i64 0, [165 x i8] c"a 'try ... catch' value is the element or what a clause gives, a copy either way, so nothing written into it is kept - write into the collection itself, 'x[i].f = v'" }>, align 8
@.d87 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"P9" }>, align 8
@.d88 = private constant <{ i64, [71 x i8] }> <{ i64 0, [71 x i8] c"an atomic operation acts on a place - a variable, a field or an element" }>, align 8
@.d89 = private constant <{ i64, [65 x i8] }> <{ i64 0, [65 x i8] c"the atomic operations take integers of 8, 16, 32 or 64 bits, and " }>, align 8
@.d90 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c" is none - hold the value as one of those" }>, align 8
@.d91 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"P9, T4a" }>, align 8
@.d92 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"a rotation's count is an integer, found " }>, align 8
@.d93 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E37" }>, align 8
@.d94 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d95 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"' is a method of the integer types, and " }>, align 8
@.d96 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" is none" }>, align 8
@.d97 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E37" }>, align 8
@.d98 = private constant <{ i64, [85 x i8] }> <{ i64 0, [85 x i8] c" is a build constant, and a declaration giving it a default is immutable - drop 'mut'" }>, align 8
@.d99 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"B10c" }>, align 8
@.d100 = private constant <{ i64, [91 x i8] }> <{ i64 0, [91 x i8] c" is a build constant, and a default for it is a Bool, I32, I64, U64, F64 or String - found " }>, align 8
@.d101 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"B10c" }>, align 8
@.d102 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"C2d" }>, align 8
@.d103 = private constant <{ i64, [113 x i8] }> <{ i64 0, [113 x i8] c"this builds through a '&p' field whose scope is not known here - build where it lives, in the function that knows" }>, align 8
@.d104 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c" has no 'ByteSwap': its " }>, align 8
@.d105 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c" bits are no whole number of bytes" }>, align 8
@.d106 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"E37, T4a" }>, align 8
@.d107 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d108 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"cannot open this file" }>, align 8
@.d109 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"S12b" }>, align 8
@.d110 = private constant <{ i64, [66 x i8] }> <{ i64 0, [66 x i8] c"this block can finish without leaving - give the value with '=> v'" }>, align 8
@.d111 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"case " }>, align 8
@.d112 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c" is private to its module" }>, align 8
@.d113 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"M6a" }>, align 8
@.d114 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"unknown name " }>, align 8
@.d115 = private constant <{ i64, [101 x i8] }> <{ i64 0, [101 x i8] c" - a name in a case is a value compared by '=='; to take any value and test it, write 'case _ if ...'" }>, align 8
@.d116 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"S13f" }>, align 8
@.d117 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"a case value here is " }>, align 8
@.d118 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", found " }>, align 8
@.d119 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"S13" }>, align 8
@.d120 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"R11a" }>, align 8
@.d121 = private constant <{ i64, [78 x i8] }> <{ i64 0, [78 x i8] c"a catch with no error types takes every error left, so no clause can follow it" }>, align 8
@.d122 = private constant <{ i64, [128 x i8] }> <{ i64 0, [128 x i8] c" names no error type, so it names the error this clause took - and nothing uses it: write the error type meant, or 'catch' alone" }>, align 8
@.d123 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"R11b" }>, align 8
@.d124 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"R11" }>, align 8
@.d125 = private constant <{ i64, [57 x i8] }> <{ i64 0, [57 x i8] c"a clause here leaves, or gives the value with 'default v'" }>, align 8
@.d126 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"R11a" }>, align 8
@.d127 = private constant <{ i64, [58 x i8] }> <{ i64 0, [58 x i8] c"an earlier clause already takes every error this one names" }>, align 8
@.d128 = private constant <{ i64, [87 x i8] }> <{ i64 0, [87 x i8] c" is compared with an error word, an error type or a named set - 'e == T.WORD', 'e == T'" }>, align 8
@.d129 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"R11b" }>, align 8
@.d130 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"this match does not cover " }>, align 8
@.d131 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c" - add a case for it, or 'nomatch'" }>, align 8
@.d132 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"R11b" }>, align 8
@.d133 = private constant <{ i64, [102 x i8] }> <{ i64 0, [102 x i8] c" is the error this clause took: it is only rendered, compared, matched or raised again here - write '$" }>, align 8
@.d134 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"' where text is wanted" }>, align 8
@.d135 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"R11b" }>, align 8
@.d136 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"L18a" }>, align 8
@.d137 = private constant <{ i64, [95 x i8] }> <{ i64 0, [95 x i8] c"a comma never ends a line - items on different lines are separated by the line break; remove it" }>, align 8
@.d138 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" takes " }>, align 8
@.d139 = private constant <{ i64, [86 x i8] }> <{ i64 0, [86 x i8] c", its own receiver's type, so the operator reads both ways already - remove 'commutes'" }>, align 8
@.d140 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"E31c" }>, align 8
@.d141 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"E27, S9e" }>, align 8
@.d142 = private constant <{ i64, [69 x i8] }> <{ i64 0, [69 x i8] c"this comprehension's own calls can fail - write 'try T[e for x in c]'" }>, align 8
@.d143 = private constant <{ i64, [52 x i8] }> <{ i64 0, [52 x i8] c"both values of 'a if c else b' have one type, found " }>, align 8
@.d144 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" and " }>, align 8
@.d145 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E28" }>, align 8
@.d146 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"B9" }>, align 8
@.d147 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c"a top-level condition is true or false" }>, align 8
@.d148 = private constant <{ i64, [56 x i8] }> <{ i64 0, [56 x i8] c" is not computed from literals and build constants alone" }>, align 8
@.d149 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"B9a" }>, align 8
@.d150 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E28" }>, align 8
@.d151 = private constant <{ i64, [190 x i8] }> <{ i64 0, [190 x i8] c"a conditional or a match gives a copy of the value it chooses, which this call would write and drop - call on the place itself, 'if c { f(a) } else { f(b) }', or hold the values by reference" }>, align 8
@.d152 = private constant <{ i64, [62 x i8] }> <{ i64 0, [62 x i8] c" is not a build constant or an immutable global of this module" }>, align 8
@.d153 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"B9a" }>, align 8
@.d154 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"the condition beginning " }>, align 8
@.d155 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c" is not a Bool" }>, align 8
@.d156 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"B9" }>, align 8
@.d157 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"a condition is a Bool, found " }>, align 8
@.d158 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d159 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c" cannot combine these values" }>, align 8
@.d160 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"B9" }>, align 8
@.d161 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"S8a" }>, align 8
@.d162 = private constant <{ i64, [107 x i8] }> <{ i64 0, [107 x i8] c"this condition is the same on every build, so one branch is dead - depend on a build constant, or remove it" }>, align 8
@.d163 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c" does not satisfy the constraint " }>, align 8
@.d164 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" on " }>, align 8
@.d165 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d166 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" is closed, met by " }>, align 8
@.d167 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" alone" }>, align 8
@.d168 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"G19, T31a" }>, align 8
@.d169 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c" does not satisfy the constraint " }>, align 8
@.d170 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" on " }>, align 8
@.d171 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d172 = private constant <{ i64, [50 x i8] }> <{ i64 0, [50 x i8] c" is sealed - only the types its own module gives '" }>, align 8
@.d173 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"' satisfy it" }>, align 8
@.d174 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"G19, T31" }>, align 8
@.d175 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c" does not satisfy the constraint " }>, align 8
@.d176 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" on " }>, align 8
@.d177 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c": it has no method " }>, align 8
@.d178 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" that fits" }>, align 8
@.d179 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"G19" }>, align 8
@.d180 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"this call breaks " }>, align 8
@.d181 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"'s requirement '" }>, align 8
@.d182 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d183 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"D17e" }>, align 8
@.d184 = private constant <{ i64, [88 x i8] }> <{ i64 0, [88 x i8] c" is no parameter of this function - an 'outlives' item names its parameters and 'return'" }>, align 8
@.d185 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"D17d" }>, align 8
@.d186 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c" does not fit " }>, align 8
@.d187 = private constant <{ i64, [45 x i8] }> <{ i64 0, [45 x i8] c" - write a value that fits, or 'try x.Narrow<" }>, align 8
@.d188 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c">()' to fail with an error" }>, align 8
@.d189 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"D17g" }>, align 8
@.d190 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c" cannot become " }>, align 8
@.d191 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c" - their representations differ" }>, align 8
@.d192 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T29" }>, align 8
@.d193 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c" is no number, so " }>, align 8
@.d194 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"(x) cannot convert it" }>, align 8
@.d195 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E26" }>, align 8
@.d196 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"the type of field " }>, align 8
@.d197 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" names " }>, align 8
@.d198 = private constant <{ i64, [105 x i8] }> <{ i64 0, [105 x i8] c", which only the constructor introduces - for a field to hold it, declare it the type's parameter: 'type " }>, align 8
@.d199 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"<" }>, align 8
@.d200 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c">'" }>, align 8
@.d201 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"G10d" }>, align 8
@.d202 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c" is not one of " }>, align 8
@.d203 = private constant <{ i64, [81 x i8] }> <{ i64 0, [81 x i8] c"'s parameters, and a generic type's constructor introduces none of its own - add " }>, align 8
@.d204 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" to the type's list" }>, align 8
@.d205 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"G10d" }>, align 8
@.d206 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"what " }>, align 8
@.d207 = private constant <{ i64, [65 x i8] }> <{ i64 0, [65 x i8] c"'s constructor introduces cannot be inferred from these arguments" }>, align 8
@.d208 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"G10d" }>, align 8
@.d209 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"D8e" }>, align 8
@.d210 = private constant <{ i64, [61 x i8] }> <{ i64 0, [61 x i8] c"a 'noreturn' call gives no value, so ':=' has no type to take" }>, align 8
@.d211 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"D15" }>, align 8
@.d212 = private constant <{ i64, [92 x i8] }> <{ i64 0, [92 x i8] c"':=' takes its type from the initializer, and null has none - write the type: 'x T?& = null'" }>, align 8
@.d213 = private constant <{ i64, [55 x i8] }> <{ i64 0, [55 x i8] c"a type is declared over a number or an array, not over " }>, align 8
@.d214 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c" - hold it in a struct's field instead" }>, align 8
@.d215 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T29" }>, align 8
@.d216 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"two traits " }>, align 8
@.d217 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c" satisfies both declare a default " }>, align 8
@.d218 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c" - the call cannot choose" }>, align 8
@.d219 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"M19e" }>, align 8
@.d220 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"parameter " }>, align 8
@.d221 = private constant <{ i64, [57 x i8] }> <{ i64 0, [57 x i8] c" declares no default, so 'default' cannot stand in for it" }>, align 8
@.d222 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"E14a" }>, align 8
@.d223 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"R11" }>, align 8
@.d224 = private constant <{ i64, [80 x i8] }> <{ i64 0, [80 x i8] c"this clause's block always leaves, so its default is never the value - remove it" }>, align 8
@.d225 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"R11" }>, align 8
@.d226 = private constant <{ i64, [131 x i8] }> <{ i64 0, [131 x i8] c"a default for a value holding references builds all it holds - a constructor call of numbers and written text, as 'List<String&>()'" }>, align 8
@.d227 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"R11" }>, align 8
@.d228 = private constant <{ i64, [67 x i8] }> <{ i64 0, [67 x i8] c"a try written as a statement gives no value, so it takes no default" }>, align 8
@.d229 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"R11" }>, align 8
@.d230 = private constant <{ i64, [54 x i8] }> <{ i64 0, [54 x i8] c"a default belongs to a catch clause: 'catch default v'" }>, align 8
@.d231 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"R11" }>, align 8
@.d232 = private constant <{ i64, [77 x i8] }> <{ i64 0, [77 x i8] c"this call returns no value, so there is nothing for a default to stand in for" }>, align 8
@.d233 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"R11, O25" }>, align 8
@.d234 = private constant <{ i64, [83 x i8] }> <{ i64 0, [83 x i8] c"a reference default lives where the call's result does - or is null, or built there" }>, align 8
@.d235 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"trait " }>, align 8
@.d236 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c" already requires a method " }>, align 8
@.d237 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c" - choose another name for this default" }>, align 8
@.d238 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"M19e" }>, align 8
@.d239 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"S19b" }>, align 8
@.d240 = private constant <{ i64, [62 x i8] }> <{ i64 0, [62 x i8] c"deferred code may not return - it runs while its block is left" }>, align 8
@.d241 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"-define " }>, align 8
@.d242 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"=" }>, align 8
@.d243 = private constant <{ i64, [60 x i8] }> <{ i64 0, [60 x i8] c": not a number - '0x' and '0b' take digits of their own base" }>, align 8
@.d244 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"B10" }>, align 8
@.d245 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"-define " }>, align 8
@.d246 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"=" }>, align 8
@.d247 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c": beyond 64 bits" }>, align 8
@.d248 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"B10" }>, align 8
@.d249 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"B10" }>, align 8
@.d250 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c"-define needs Name=value after it" }>, align 8
@.d251 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"-define " }>, align 8
@.d252 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"=" }>, align 8
@.d253 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c": the name is not an identifier" }>, align 8
@.d254 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"B10" }>, align 8
@.d255 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"-define " }>, align 8
@.d256 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"=" }>, align 8
@.d257 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c": defined twice" }>, align 8
@.d258 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"B10" }>, align 8
@.d259 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d260 = private constant <{ i64, [76 x i8] }> <{ i64 0, [76 x i8] c".Destroy()' runs again in the loop's next turn, on what it ended - declare '" }>, align 8
@.d261 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"' inside the loop" }>, align 8
@.d262 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"C9b" }>, align 8
@.d263 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d264 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"' is used after '" }>, align 8
@.d265 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c".Destroy()' (line " }>, align 8
@.d266 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d267 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"C9b" }>, align 8
@.d268 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c" targets for " }>, align 8
@.d269 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c" results - write '_' for one not wanted" }>, align 8
@.d270 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"D8c" }>, align 8
@.d271 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"C7" }>, align 8
@.d272 = private constant <{ i64, [111 x i8] }> <{ i64 0, [111 x i8] c"'destruct' follows the constructor's body - close the body first: 'type T struct(...) { ... } destruct { ... }'" }>, align 8
@.d273 = private constant <{ i64, [58 x i8] }> <{ i64 0, [58 x i8] c"only several results can be destructured, and this is one " }>, align 8
@.d274 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"D8c" }>, align 8
@.d275 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"doc " }>, align 8
@.d276 = private constant <{ i64, [59 x i8] }> <{ i64 0, [59 x i8] c" takes at most the name of one of its items, as 'olang doc " }>, align 8
@.d277 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" main'" }>, align 8
@.d278 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"B14" }>, align 8
@.d279 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"O25c" }>, align 8
@.d280 = private constant <{ i64, [87 x i8] }> <{ i64 0, [87 x i8] c"the array outlives what this element refers to - build the element where the array goes" }>, align 8
@.d281 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"expected " }>, align 8
@.d282 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", found " }>, align 8
@.d283 = private constant <{ i64, [53 x i8] }> <{ i64 0, [53 x i8] c" - they differ in whether the elements are references" }>, align 8
@.d284 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T25a" }>, align 8
@.d285 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E38" }>, align 8
@.d286 = private constant <{ i64, [90 x i8] }> <{ i64 0, [90 x i8] c"this embed's path cannot be computed while compiling - write it so it can, or as a literal" }>, align 8
@.d287 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"L13" }>, align 8
@.d288 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"empty character literal" }>, align 8
@.d289 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"enum case " }>, align 8
@.d290 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c" is already declared" }>, align 8
@.d291 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T17" }>, align 8
@.d292 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"E10a" }>, align 8
@.d293 = private constant <{ i64, [66 x i8] }> <{ i64 0, [66 x i8] c"Eq takes one parameter of its receiver's own type and gives a Bool" }>, align 8
@.d294 = private constant <{ i64, [85 x i8] }> <{ i64 0, [85 x i8] c" takes what it is given read-only - neither its receiver nor a parameter may be 'mut'" }>, align 8
@.d295 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"E10a, E11c" }>, align 8
@.d296 = private constant <{ i64, [59 x i8] }> <{ i64 0, [59 x i8] c" has no error-set parameter, so its arguments end in no '?'" }>, align 8
@.d297 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"G1a" }>, align 8
@.d298 = private constant <{ i64, [85 x i8] }> <{ i64 0, [85 x i8] c" is an error-set parameter, not a type - it stands where an error set is written, '? " }>, align 8
@.d299 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d300 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"G1a" }>, align 8
@.d301 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"R3" }>, align 8
@.d302 = private constant <{ i64, [52 x i8] }> <{ i64 0, [52 x i8] c"'error' fails a function, and this is not inside one" }>, align 8
@.d303 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c" reaches itself through its member '" }>, align 8
@.d304 = private constant <{ i64, [49 x i8] }> <{ i64 0, [49 x i8] c"' - a set holds its members' errors, never itself" }>, align 8
@.d305 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T19a" }>, align 8
@.d306 = private constant <{ i64, [132 x i8] }> <{ i64 0, [132 x i8] c" is an error type, which has no values - an error is raised and caught, never held; tell its words apart with catch clauses ('catch " }>, align 8
@.d307 = private constant <{ i64, [55 x i8] }> <{ i64 0, [55 x i8] c".WORD { }'), or by the name a clause gives one ('catch " }>, align 8
@.d308 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c" e { if e == " }>, align 8
@.d309 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c".WORD { } }')" }>, align 8
@.d310 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T20" }>, align 8
@.d311 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"this function does not declare " }>, align 8
@.d312 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" - add it after '?'" }>, align 8
@.d313 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"R3" }>, align 8
@.d314 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d315 = private constant <{ i64, [55 x i8] }> <{ i64 0, [55 x i8] c"' is an error word, not a value - raise it with 'error " }>, align 8
@.d316 = private constant <{ i64, [101 x i8] }> <{ i64 0, [101 x i8] c"', tell it apart with a catch clause, or compare it with the error a clause took ('catch e { if e == " }>, align 8
@.d317 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" { } }')" }>, align 8
@.d318 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T20" }>, align 8
@.d319 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"error word " }>, align 8
@.d320 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c" is private to its module" }>, align 8
@.d321 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"M6a" }>, align 8
@.d322 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"word " }>, align 8
@.d323 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" is " }>, align 8
@.d324 = private constant <{ i64, [50 x i8] }> <{ i64 0, [50 x i8] c"'s too, a member of this set - name it another way" }>, align 8
@.d325 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T19a" }>, align 8
@.d326 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"an error set names one of " }>, align 8
@.d327 = private constant <{ i64, [68 x i8] }> <{ i64 0, [68 x i8] c"'s first 64 words alone, and this is past them - name the type whole" }>, align 8
@.d328 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"R1c" }>, align 8
@.d329 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\5Ct" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d330 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\5Cn" }>, align 8
@.d331 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\5Cr" }>, align 8
@.d332 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\5C0" }>, align 8
declare void @__olang_check_failed(ptr)
@.d333 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\5Cx" }>, align 8
@.d334 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"explain " }>, align 8
@.d335 = private constant <{ i64, [55 x i8] }> <{ i64 0, [55 x i8] c" takes the name of one of its items, as 'olang explain " }>, align 8
@.d336 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" main'" }>, align 8
@.d337 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"B11b" }>, align 8
@.d338 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d339 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"' is no top-level item of " }>, align 8
@.d340 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"B11b" }>, align 8
@.d341 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"X12" }>, align 8
@.d342 = private constant <{ i64, [101 x i8] }> <{ i64 0, [101 x i8] c"an export fn is one C function, and a generic one stands for many - declare it for the types C passes" }>, align 8
@.d343 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"X12" }>, align 8
@.d344 = private constant <{ i64, [108 x i8] }> <{ i64 0, [108 x i8] c"an export fn is one C calls by its name, and a method has no C name - declare a function taking the receiver" }>, align 8
@.d345 = private constant <{ i64, [62 x i8] }> <{ i64 0, [62 x i8] c" is the program's own name in C - name the export fn otherwise" }>, align 8
@.d346 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"X12" }>, align 8
@.d347 = private constant <{ i64, [133 x i8] }> <{ i64 0, [133 x i8] c" cannot go back to C - an export fn gives one number, Bool, extern type's reference, plain-data struct, or an array of these by value" }>, align 8
@.d348 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"X12" }>, align 8
@.d349 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T29f" }>, align 8
@.d350 = private constant <{ i64, [54 x i8] }> <{ i64 0, [54 x i8] c"only a type over a number or an array extends its base" }>, align 8
@.d351 = private constant <{ i64, [136 x i8] }> <{ i64 0, [136 x i8] c" cannot come back from C - an extern's result is one number of the twelve primitives, Bool, extern type's reference or plain-data struct" }>, align 8
@.d352 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"X2" }>, align 8
@.d353 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"O23, O11" }>, align 8
@.d354 = private constant <{ i64, [122 x i8] }> <{ i64 0, [122 x i8] c"this stores into a '&p' field whose binding is not known through this path - store through a variable holding the instance" }>, align 8
@.d355 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"S9e" }>, align 8
@.d356 = private constant <{ i64, [104 x i8] }> <{ i64 0, [104 x i8] c"a loop's catch clause runs after the loop has ended, so it has no loop to break or continue - set a flag" }>, align 8
@.d357 = private constant <{ i64, [116 x i8] }> <{ i64 0, [116 x i8] c" is already declared, and a for-in declares new names - choose another, or to loop while it is in c write 'for { if " }>, align 8
@.d358 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c" not in c { break } }'" }>, align 8
@.d359 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"D3a, E29" }>, align 8
@.d360 = private constant <{ i64, [95 x i8] }> <{ i64 0, [95 x i8] c" is a method of the unsigned type of its float's width - convert first, as U64(x).F64FromBits()" }>, align 8
@.d361 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E33" }>, align 8
@.d362 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T17e" }>, align 8
@.d363 = private constant <{ i64, [96 x i8] }> <{ i64 0, [96 x i8] c"a case of an enum with raw values may not be named 'From', which makes a case from its raw value" }>, align 8
@.d364 = private constant <{ i64, [98 x i8] }> <{ i64 0, [98 x i8] c" can escape here, and this generator's result does not say it fails with it - write 'Iterator<T ? " }>, align 8
@.d365 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c">', or catch it" }>, align 8
@.d366 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"R9, D18" }>, align 8
@.d367 = private constant <{ i64, [79 x i8] }> <{ i64 0, [79 x i8] c"a generator fails as its Next does - write its errors in its result: 'Iterator<" }>, align 8
@.d368 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" ? E>'" }>, align 8
@.d369 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"D18" }>, align 8
@.d370 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"D18a" }>, align 8
@.d371 = private constant <{ i64, [73 x i8] }> <{ i64 0, [73 x i8] c"a generator gives its values by 'yield' - 'return' ends it and takes none" }>, align 8
@.d372 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d373 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d374 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"a parameter" }>, align 8
@.d375 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"this generator yields what " }>, align 8
@.d376 = private constant <{ i64, [93 x i8] }> <{ i64 0, [93 x i8] c" refers to, which outlives no Next call it can be shown to - yield a copy ('$x', 'x.Clone()')" }>, align 8
@.d377 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"D18c, T22a" }>, align 8
@.d378 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"G6" }>, align 8
@.d379 = private constant <{ i64, [55 x i8] }> <{ i64 0, [55 x i8] c"only a struct, an enum or a trait takes type parameters" }>, align 8
@.d380 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"'s initializer reads " }>, align 8
@.d381 = private constant <{ i64, [48 x i8] }> <{ i64 0, [48 x i8] c", which is not set until the initializer is done" }>, align 8
@.d382 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"B5a" }>, align 8
@.d383 = private constant <{ i64, [48 x i8] }> <{ i64 0, [48 x i8] c"another import of this module is already named '" }>, align 8
@.d384 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"' - give one an alias of its own" }>, align 8
@.d385 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"M5" }>, align 8
@.d386 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c"this relative import leaves " }>, align 8
@.d387 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c" - name a module outside it by its own path" }>, align 8
@.d388 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"M23" }>, align 8
@.d389 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"olang.lock names no commit for " }>, align 8
@.d390 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c" - delete its line, or build with -update" }>, align 8
@.d391 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"M23b" }>, align 8
@.d392 = private constant <{ i64, [61 x i8] }> <{ i64 0, [61 x i8] c" reaches a file another import of this module already reaches" }>, align 8
@.d393 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"M16" }>, align 8
@.d394 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"M23a" }>, align 8
@.d395 = private constant <{ i64, [97 x i8] }> <{ i64 0, [97 x i8] c"a remote import's host, owner, repository and ref may hold only letters, digits, '.', '_' and '-'" }>, align 8
@.d396 = private constant <{ i64, [55 x i8] }> <{ i64 0, [55 x i8] c" is a statement of its own, never part of an expression" }>, align 8
@.d397 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"S3a" }>, align 8
@.d398 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"C2d" }>, align 8
@.d399 = private constant <{ i64, [113 x i8] }> <{ i64 0, [113 x i8] c"this instance would outlive what its '&p' field refers to - keep it in that block, or build it there ('T&x(...)')" }>, align 8
@.d400 = private constant <{ i64, [78 x i8] }> <{ i64 0, [78 x i8] c" is beyond 64 bits - the largest decimal literal is U64's 18446744073709551615" }>, align 8
@.d401 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"L10" }>, align 8
@.d402 = private constant <{ i64, [63 x i8] }> <{ i64 0, [63 x i8] c" cannot be a reference - only a struct, an enum or an array can" }>, align 8
@.d403 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T24" }>, align 8
@.d404 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"a case is tested with '" }>, align 8
@.d405 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"': '" }>, align 8
@.d406 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d407 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d408 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"E10c, E32" }>, align 8
@.d409 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"M1" }>, align 8
@.d410 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"a directory - a module is one .olang file" }>, align 8
@.d411 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"E10c" }>, align 8
@.d412 = private constant <{ i64, [80 x i8] }> <{ i64 0, [80 x i8] c"'null is null' tests nothing - 'is null' follows a reference or a function value" }>, align 8
@.d413 = private constant <{ i64, [62 x i8] }> <{ i64 0, [62 x i8] c"only a reference or a function value can be null, and this is " }>, align 8
@.d414 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"E10c" }>, align 8
@.d415 = private constant <{ i64, [53 x i8] }> <{ i64 0, [53 x i8] c"'is' tests for null and nothing else - compare with '" }>, align 8
@.d416 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d417 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"E10c" }>, align 8
@.d418 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"P4c" }>, align 8
@.d419 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c"no task of this join can fail - drop the 'try'" }>, align 8
@.d420 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"P4c" }>, align 8
@.d421 = private constant <{ i64, [79 x i8] }> <{ i64 0, [79 x i8] c"a join takes catch clauses only as 'try join', and no task of this one can fail" }>, align 8
@.d422 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"P4d" }>, align 8
@.d423 = private constant <{ i64, [93 x i8] }> <{ i64 0, [93 x i8] c"a task of this join binds a target it leaves unwritten when it fails - this clause must leave" }>, align 8
@.d424 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"S3, E11b" }>, align 8
@.d425 = private constant <{ i64, [100 x i8] }> <{ i64 0, [100 x i8] c"text on a line of its own does nothing - a join continues onto the next line only inside parentheses" }>, align 8
@.d426 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"this join's tasks can fail with " }>, align 8
@.d427 = private constant <{ i64, [64 x i8] }> <{ i64 0, [64 x i8] c" - write 'try join', with catch clauses for what it handles here" }>, align 8
@.d428 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"P4c" }>, align 8
@.d429 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"E11b" }>, align 8
@.d430 = private constant <{ i64, [77 x i8] }> <{ i64 0, [77 x i8] c"'(' after a piece of text calls it - to join the value inside, write '$(...)'" }>, align 8
@.d431 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"P1a" }>, align 8
@.d432 = private constant <{ i64, [49 x i8] }> <{ i64 0, [49 x i8] c"this join spawns nothing, so it waits for nothing" }>, align 8
@.d433 = private constant <{ i64, [99 x i8] }> <{ i64 0, [99 x i8] c" is a keyword, not a name - a field named by one is reached only after '.', never by the name alone" }>, align 8
@.d434 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"L9a" }>, align 8
@.d435 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"lambda parameter " }>, align 8
@.d436 = private constant <{ i64, [49 x i8] }> <{ i64 0, [49 x i8] c" has no type, and nothing gives it one - write it" }>, align 8
@.d437 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"D16a" }>, align 8
@.d438 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"this result binds " }>, align 8
@.d439 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" to " }>, align 8
@.d440 = private constant <{ i64, [94 x i8] }> <{ i64 0, [94 x i8] c", which the call holds in an array, where an array is held by reference - write the result as " }>, align 8
@.d441 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"&" }>, align 8
@.d442 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T7a" }>, align 8
@.d443 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"D16b" }>, align 8
@.d444 = private constant <{ i64, [54 x i8] }> <{ i64 0, [54 x i8] c"this value gives the lambda no result type - write one" }>, align 8
@.d445 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c"this lambda's signature disagrees with " }>, align 8
@.d446 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c" - leave that part out, or make them agree" }>, align 8
@.d447 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"D16a" }>, align 8
@.d448 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"this lambda keeps '" }>, align 8
@.d449 = private constant <{ i64, [91 x i8] }> <{ i64 0, [91 x i8] c"' beyond the call, which a call through a function value cannot check - keep a copy instead" }>, align 8
@.d450 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T22a" }>, align 8
@.d451 = private constant <{ i64, [47 x i8] }> <{ i64 0, [47 x i8] c" does not compare arrays - lane by lane it is '" }>, align 8
@.d452 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"', an Array<Bool>" }>, align 8
@.d453 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E39" }>, align 8
@.d454 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c"these arrays are of lengths " }>, align 8
@.d455 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" and " }>, align 8
@.d456 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c" - a lane operation takes arrays of one length" }>, align 8
@.d457 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E39" }>, align 8
@.d458 = private constant <{ i64, [45 x i8] }> <{ i64 0, [45 x i8] c"a one-line body is one simple statement, not " }>, align 8
@.d459 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c" - write a block, '{ ... }'" }>, align 8
@.d460 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"S1b" }>, align 8
@.d461 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"S1b" }>, align 8
@.d462 = private constant <{ i64, [72 x i8] }> <{ i64 0, [72 x i8] c"a one-line body stands on the line of its ':' - write a block, '{ ... }'" }>, align 8
@.d463 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"a line cannot begin with " }>, align 8
@.d464 = private constant <{ i64, [59 x i8] }> <{ i64 0, [59 x i8] c" - the line before ended its statement; end that line with " }>, align 8
@.d465 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c", or put the expression in parentheses" }>, align 8
@.d466 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"L18" }>, align 8
@.d467 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"linking " }>, align 8
@.d468 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" failed" }>, align 8
@.d469 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d470 = private constant <{ i64, [111 x i8] }> <{ i64 0, [111 x i8] c" names no library and no file - write a library's name, as 'link \22m\22', or a path to one, as 'link \22lib/libx.a\22'" }>, align 8
@.d471 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"X9" }>, align 8
@.d472 = private constant <{ i64, [45 x i8] }> <{ i64 0, [45 x i8] c"this literal expression's value does not fit " }>, align 8
@.d473 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E4a" }>, align 8
@.d474 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"B4" }>, align 8
@.d475 = private constant <{ i64, [84 x i8] }> <{ i64 0, [84 x i8] c"main takes no parameters and returns no value: 'fn main() { }', or 'fn main() ? { }'" }>, align 8
@.d476 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"a match over " }>, align 8
@.d477 = private constant <{ i64, [73 x i8] }> <{ i64 0, [73 x i8] c" gives a value only when its cases cover every value - add 'nomatch => v'" }>, align 8
@.d478 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"S12b" }>, align 8
@.d479 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"every value of this match is " }>, align 8
@.d480 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", found " }>, align 8
@.d481 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"S12b" }>, align 8
@.d482 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c"'@' has no built-in meaning, and " }>, align 8
@.d483 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" declares no MatMul" }>, align 8
@.d484 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E31" }>, align 8
@.d485 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d486 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"' is a " }>, align 8
@.d487 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c", which may be null, and " }>, align 8
@.d488 = private constant <{ i64, [58 x i8] }> <{ i64 0, [58 x i8] c" never is - test it first ('if x is not null'), or write '" }>, align 8
@.d489 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"!'" }>, align 8
@.d490 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T2c" }>, align 8
@.d491 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"member '" }>, align 8
@.d492 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"' of " }>, align 8
@.d493 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c" is private to its module" }>, align 8
@.d494 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"M6a" }>, align 8
@.d495 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c", which 'in' calls, gives a Bool" }>, align 8
@.d496 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E29" }>, align 8
@.d497 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"two imported modules declare " }>, align 8
@.d498 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c" for this type - import only the one meant" }>, align 8
@.d499 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"M22" }>, align 8
@.d500 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c" already has a method " }>, align 8
@.d501 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c" in this module" }>, align 8
@.d502 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"M21" }>, align 8
@.d503 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c"only the prelude declares methods of " }>, align 8
@.d504 = private constant <{ i64, [59 x i8] }> <{ i64 0, [59 x i8] c" - declare a type of your own over it: 'type T extends ...'" }>, align 8
@.d505 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"M19d" }>, align 8
@.d506 = private constant <{ i64, [44 x i8] }> <{ i64 0, [44 x i8] c" is generic - write its type arguments, as '" }>, align 8
@.d507 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"<I32>'" }>, align 8
@.d508 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"G7" }>, align 8
@.d509 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"the mode comes first: 'olang " }>, align 8
@.d510 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"' and then its options" }>, align 8
@.d511 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"B1" }>, align 8
@.d512 = private constant <{ i64, [50 x i8] }> <{ i64 0, [50 x i8] c" takes no files - its client names them as it goes" }>, align 8
@.d513 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"B1" }>, align 8
@.d514 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c" takes exactly one file" }>, align 8
@.d515 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"B1" }>, align 8
@.d516 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c"this module has the same identity as " }>, align 8
@.d517 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c" - rename one, or import it by a relative path" }>, align 8
@.d518 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"M22a" }>, align 8
@.d519 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"D11a" }>, align 8
@.d520 = private constant <{ i64, [99 x i8] }> <{ i64 0, [99 x i8] c"':=' gives a local its initializer's permission - remove 'mut', or write the type: 'x mut T& = ...'" }>, align 8
@.d521 = private constant <{ i64, [95 x i8] }> <{ i64 0, [95 x i8] c"a by-value parameter is the callee's own copy, always writable - 'mut' is for a reference, and " }>, align 8
@.d522 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" is none" }>, align 8
@.d523 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"D9" }>, align 8
@.d524 = private constant <{ i64, [57 x i8] }> <{ i64 0, [57 x i8] c" is an import's alias in this module - rename one of them" }>, align 8
@.d525 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"M20" }>, align 8
@.d526 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c" is already declared in this module" }>, align 8
@.d527 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"D2" }>, align 8
@.d528 = private constant <{ i64, [57 x i8] }> <{ i64 0, [57 x i8] c" is already a type's name in this module - choose another" }>, align 8
@.d529 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"D2" }>, align 8
@.d530 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"'Narrow' converts to a number type, and " }>, align 8
@.d531 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" is none" }>, align 8
@.d532 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"E26b" }>, align 8
@.d533 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"S8d" }>, align 8
@.d534 = private constant <{ i64, [94 x i8] }> <{ i64 0, [94 x i8] c"a narrowed payload field is read, never written - assign the whole case: e = Shape.Circle(...)" }>, align 8
@.d535 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E21" }>, align 8
@.d536 = private constant <{ i64, [108 x i8] }> <{ i64 0, [108 x i8] c"there are no nested array literals - each array is a literal of its own: Array<I32, 2>[I32[1, 2], I32[3, 4]]" }>, align 8
@.d537 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d538 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"' is a " }>, align 8
@.d539 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c", never null, so this is always " }>, align 8
@.d540 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T2c" }>, align 8
@.d541 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c" declares no raw values, so it has no '" }>, align 8
@.d542 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"' - name a raw type after 'enum'" }>, align 8
@.d543 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T17e" }>, align 8
@.d544 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"the specification has no rule " }>, align 8
@.d545 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"B11a" }>, align 8
@.d546 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c" has no case " }>, align 8
@.d547 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c" - did you mean '" }>, align 8
@.d548 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"'?" }>, align 8
@.d549 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T17" }>, align 8
@.d550 = private constant <{ i64, [68 x i8] }> <{ i64 0, [68 x i8] c" is never null, so it has no zero value - give it a value, or write " }>, align 8
@.d551 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T2c" }>, align 8
@.d552 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c" cannot be 'noreturn'" }>, align 8
@.d553 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"D8e" }>, align 8
@.d554 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d555 = private constant <{ i64, [164 x i8] }> <{ i64 0, [164 x i8] c"' is not a mode - the modes are build, compile, test, interpret, format, explain, help, doc, lsp, mcp, fix and bindgen, and a file ending in .olang is built and run" }>, align 8
@.d556 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"B1" }>, align 8
@.d557 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d558 = private constant <{ i64, [56 x i8] }> <{ i64 0, [56 x i8] c"' is no olang file to run - a file's name ends in .olang" }>, align 8
@.d559 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"B1" }>, align 8
@.d560 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"S3" }>, align 8
@.d561 = private constant <{ i64, [78 x i8] }> <{ i64 0, [78 x i8] c"this computes a value and discards it - only a call, '++' or '--' stands alone" }>, align 8
@.d562 = private constant <{ i64, [50 x i8] }> <{ i64 0, [50 x i8] c" is not an enum type, so it has no values 'T.Case'" }>, align 8
@.d563 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E22" }>, align 8
@.d564 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c" is not a function, and declares no Call" }>, align 8
@.d565 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"E13b" }>, align 8
@.d566 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c" does not extend its base, so it takes no " }>, align 8
@.d567 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c" - declare its method " }>, align 8
@.d568 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c", or declare it with 'extends'" }>, align 8
@.d569 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T29f" }>, align 8
@.d570 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c" cannot be indexed" }>, align 8
@.d571 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E16" }>, align 8
@.d572 = private constant <{ i64, [120 x i8] }> <{ i64 0, [120 x i8] c" cannot be walked - 'for ... in' takes an array, a range, an iterator ('mut Next() T ? Exhausted') or a type with Iter()" }>, align 8
@.d573 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"S9a" }>, align 8
@.d574 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d575 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"not a regular file" }>, align 8
@.d576 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c" cannot be sliced" }>, align 8
@.d577 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"E16a" }>, align 8
@.d578 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c" is declared here" }>, align 8
@.d579 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d580 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d581 = private constant <{ i64, [111 x i8] }> <{ i64 0, [111 x i8] c"this is the value that does not fit - each value a conditional or a match gives is stored as though alone (E28)" }>, align 8
@.d582 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d583 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"the condition" }>, align 8
@.d584 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d585 = private constant <{ i64, [69 x i8] }> <{ i64 0, [69 x i8] c"' is declared here, in a block that closes first - declare it where '" }>, align 8
@.d586 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"' lives: '" }>, align 8
@.d587 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d588 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"&" }>, align 8
@.d589 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" = ...'" }>, align 8
@.d590 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d591 = private constant <{ i64, [102 x i8] }> <{ i64 0, [102 x i8] c"a function type says where each reference argument and the result live, as the function does - write '" }>, align 8
@.d592 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"', or pass a lambda calling it" }>, align 8
@.d593 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d594 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d595 = private constant <{ i64, [106 x i8] }> <{ i64 0, [106 x i8] c"a function type of several results or error items is parenthesized whole in a list: '(fn(x I64) I64, I64)'" }>, align 8
@.d596 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"the range's literals make '" }>, align 8
@.d597 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"' " }>, align 8
@.d598 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c" - convert its end, '" }>, align 8
@.d599 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"(...)', for " }>, align 8
@.d600 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" values" }>, align 8
@.d601 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d602 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d603 = private constant <{ i64, [89 x i8] }> <{ i64 0, [89 x i8] c"' is the loop's copy of an element, made in the loop's block - lend the element itself: '" }>, align 8
@.d604 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"[i]', with 'for i in range " }>, align 8
@.d605 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c".Len()'" }>, align 8
@.d606 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d607 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d608 = private constant <{ i64, [62 x i8] }> <{ i64 0, [62 x i8] c"' is made here, in a block that closes first - make it where '" }>, align 8
@.d609 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"' lives: '" }>, align 8
@.d610 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"&" }>, align 8
@.d611 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"(...)'" }>, align 8
@.d612 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d613 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d614 = private constant <{ i64, [66 x i8] }> <{ i64 0, [66 x i8] c"the type is written here - write '?&' for '&' where it may be null" }>, align 8
@.d615 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d616 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c"' is private to its module, and only a public " }>, align 8
@.d617 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c" meets the constraint" }>, align 8
@.d618 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d619 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d620 = private constant <{ i64, [54 x i8] }> <{ i64 0, [54 x i8] c"' copies a place reached read-only, so it is read-only" }>, align 8
@.d621 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d622 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d623 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"' cannot be made where '" }>, align 8
@.d624 = private constant <{ i64, [106 x i8] }> <{ i64 0, [106 x i8] c"' lives: a Str builds nothing where its receiver does - keep copies of what it reads instead of references" }>, align 8
@.d625 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d626 = private constant <{ i64, [81 x i8] }> <{ i64 0, [81 x i8] c"this text lives in a block that closes first - pass a copy, which is made where '" }>, align 8
@.d627 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c"' lives: write '$' before it" }>, align 8
@.d628 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d629 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d630 = private constant <{ i64, [118 x i8] }> <{ i64 0, [118 x i8] c"the Vec grew here, after the view was taken; take the view after the growth, or copy the elements first: 'v.ToArray()'" }>, align 8
@.d631 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c"the task holding a view of '" }>, align 8
@.d632 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"' is started here" }>, align 8
@.d633 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d634 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c"a reference has one, null - hold " }>, align 8
@.d635 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" as '" }>, align 8
@.d636 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"&' where this use names it" }>, align 8
@.d637 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d638 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"L1" }>, align 8
@.d639 = private constant <{ i64, [45 x i8] }> <{ i64 0, [45 x i8] c"NUL byte in the source - is this a text file?" }>, align 8
@.d640 = private constant <{ i64, [67 x i8] }> <{ i64 0, [67 x i8] c"an array is never null - its zero value is the empty array: write '" }>, align 8
@.d641 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"', or no value, for an empty " }>, align 8
@.d642 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T2c" }>, align 8
@.d643 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c" does not flow into " }>, align 8
@.d644 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c" - convert it, as " }>, align 8
@.d645 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"(x)" }>, align 8
@.d646 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T6b" }>, align 8
@.d647 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" and " }>, align 8
@.d648 = private constant <{ i64, [56 x i8] }> <{ i64 0, [56 x i8] c" do not meet - neither flows into the other; convert one" }>, align 8
@.d649 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T6b" }>, align 8
@.d650 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c" takes an integer, found " }>, align 8
@.d651 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"E8" }>, align 8
@.d652 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c" takes numbers, found " }>, align 8
@.d653 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"E6" }>, align 8
@.d654 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"this operator calls " }>, align 8
@.d655 = private constant <{ i64, [52 x i8] }> <{ i64 0, [52 x i8] c", which can fail - write 'try' before the expression" }>, align 8
@.d656 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E31" }>, align 8
@.d657 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c" gives one result" }>, align 8
@.d658 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E31" }>, align 8
@.d659 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c" needs a value after it: " }>, align 8
@.d660 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"B1" }>, align 8
@.d661 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"B3h" }>, align 8
@.d662 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"cannot write it" }>, align 8
@.d663 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"-output " }>, align 8
@.d664 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c": there is no directory " }>, align 8
@.d665 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"B3h" }>, align 8
@.d666 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"O10d" }>, align 8
@.d667 = private constant <{ i64, [65 x i8] }> <{ i64 0, [65 x i8] c"this value lives in this function's own scope, which closes first" }>, align 8
@.d668 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"case " }>, align 8
@.d669 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" holds " }>, align 8
@.d670 = private constant <{ i64, [64 x i8] }> <{ i64 0, [64 x i8] c" fields, and a pattern names each - write '_' for one not wanted" }>, align 8
@.d671 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"S13b" }>, align 8
@.d672 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T17c" }>, align 8
@.d673 = private constant <{ i64, [101 x i8] }> <{ i64 0, [101 x i8] c"this payload holds references into two scopes, and it lives in one - build what it holds in one scope" }>, align 8
@.d674 = private constant <{ i64, [51 x i8] }> <{ i64 0, [51 x i8] c" is a constant of the prelude - choose another name" }>, align 8
@.d675 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"D3a" }>, align 8
@.d676 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c"this constructor takes one parameter, of type " }>, align 8
@.d677 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c" - the value it checks" }>, align 8
@.d678 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T29d" }>, align 8
@.d679 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" needs " }>, align 8
@.d680 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"'s " }>, align 8
@.d681 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c", which is private to its module - declare it " }>, align 8
@.d682 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c" to use it here" }>, align 8
@.d683 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"M6b" }>, align 8
@.d684 = private constant <{ i64, [68 x i8] }> <{ i64 0, [68 x i8] c"'error' raises a word, 'error T.WORD', or the error a clause took - " }>, align 8
@.d685 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c" is neither" }>, align 8
@.d686 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"R3" }>, align 8
@.d687 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c"a range's bounds and step are integers, found " }>, align 8
@.d688 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"S9b" }>, align 8
@.d689 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"S9b" }>, align 8
@.d690 = private constant <{ i64, [51 x i8] }> <{ i64 0, [51 x i8] c"a range only counts upward, so its step is positive" }>, align 8
@.d691 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T17e" }>, align 8
@.d692 = private constant <{ i64, [66 x i8] }> <{ i64 0, [66 x i8] c"only a declared enum has raw values - declare the enum with 'type'" }>, align 8
@.d693 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d694 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"' is a " }>, align 8
@.d695 = private constant <{ i64, [98 x i8] }> <{ i64 0, [98 x i8] c", which may be null - read through it where a test says it is not ('if x is not null'), or write '" }>, align 8
@.d696 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"!'" }>, align 8
@.d697 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T2c" }>, align 8
@.d698 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d699 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"' writes through or keeps its parameter '" }>, align 8
@.d700 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"', and this " }>, align 8
@.d701 = private constant <{ i64, [49 x i8] }> <{ i64 0, [49 x i8] c" is a read-only copy - pass one of its own, made " }>, align 8
@.d702 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T25c" }>, align 8
@.d703 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"this copies a read-only " }>, align 8
@.d704 = private constant <{ i64, [134 x i8] }> <{ i64 0, [134 x i8] c", and a written type declares a writable one - declare it with ':=' for a read-only copy, borrow it read-only, or make one of its own " }>, align 8
@.d705 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T25c" }>, align 8
@.d706 = private constant <{ i64, [49 x i8] }> <{ i64 0, [49 x i8] c" writes through or keeps its by-value parameter '" }>, align 8
@.d707 = private constant <{ i64, [110 x i8] }> <{ i64 0, [110 x i8] c"', so it cannot be a function value - a caller of one may pass a read-only copy; work on one of its own, made " }>, align 8
@.d708 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T25c" }>, align 8
@.d709 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d710 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c"' keeps what its parameter '" }>, align 8
@.d711 = private constant <{ i64, [44 x i8] }> <{ i64 0, [44 x i8] c"' reaches where it can be written, and this " }>, align 8
@.d712 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c" is read-only - pass a writable one" }>, align 8
@.d713 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T25c" }>, align 8
@.d714 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"T25c, O14" }>, align 8
@.d715 = private constant <{ i64, [151 x i8] }> <{ i64 0, [151 x i8] c"a built result is new storage and writable, and this reference is read-only - return a copy, or borrow the result from the parameter it is read through" }>, align 8
@.d716 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T25c" }>, align 8
@.d717 = private constant <{ i64, [85 x i8] }> <{ i64 0, [85 x i8] c"a read-only reference cannot become writable - pass a writable one, or drop the 'mut'" }>, align 8
@.d718 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"re-exporting " }>, align 8
@.d719 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c" reaches this module again" }>, align 8
@.d720 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"M17" }>, align 8
@.d721 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"O25" }>, align 8
@.d722 = private constant <{ i64, [98 x i8] }> <{ i64 0, [98 x i8] c"a reference never narrows - keep its scope: name where it lives ('x T&y'), or declare it with ':='" }>, align 8
@.d723 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"this case is " }>, align 8
@.d724 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"'s, and the value is " }>, align 8
@.d725 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"G34" }>, align 8
@.d726 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"G36" }>, align 8
@.d727 = private constant <{ i64, [71 x i8] }> <{ i64 0, [71 x i8] c"no type can reach this case - a case before it takes every type it does" }>, align 8
@.d728 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"a " }>, align 8
@.d729 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" has no '" }>, align 8
@.d730 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"' - its members are " }>, align 8
@.d731 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"G34" }>, align 8
@.d732 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"G33" }>, align 8
@.d733 = private constant <{ i64, [92 x i8] }> <{ i64 0, [92 x i8] c"a list known while compiling is indexed by a constant - this index is known only at run time" }>, align 8
@.d734 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"parameter '" }>, align 8
@.d735 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"' of " }>, align 8
@.d736 = private constant <{ i64, [66 x i8] }> <{ i64 0, [66 x i8] c" has no default - read 'p.Default' only where 'p.HasDefault' holds" }>, align 8
@.d737 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"G34" }>, align 8
@.d738 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c"'Of' takes one value, found " }>, align 8
@.d739 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"G34" }>, align 8
@.d740 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d741 = private constant <{ i64, [61 x i8] }> <{ i64 0, [61 x i8] c"' is a type, not a value - write it where a type goes, as 'x " }>, align 8
@.d742 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" = ...'" }>, align 8
@.d743 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"G38" }>, align 8
@.d744 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"the error raised again can be " }>, align 8
@.d745 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c", and this function's '?' names " }>, align 8
@.d746 = private constant <{ i64, [44 x i8] }> <{ i64 0, [44 x i8] c" - add it after '?', or test the error first" }>, align 8
@.d747 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"R3a" }>, align 8
@.d748 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"O14" }>, align 8
@.d749 = private constant <{ i64, [86 x i8] }> <{ i64 0, [86 x i8] c"this returns a parameter's data, and the result's bare '&' is built - borrow it: 'T&p'" }>, align 8
@.d750 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"this function returns " }>, align 8
@.d751 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" value" }>, align 8
@.d752 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", found " }>, align 8
@.d753 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"D8c" }>, align 8
@.d754 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"C2b" }>, align 8
@.d755 = private constant <{ i64, [77 x i8] }> <{ i64 0, [77 x i8] c"a constructor gives no value - its fields are the instance; fail with 'error'" }>, align 8
@.d756 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"S15" }>, align 8
@.d757 = private constant <{ i64, [56 x i8] }> <{ i64 0, [56 x i8] c"a test has no result - a bare 'return' ends it as passed" }>, align 8
@.d758 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"O26" }>, align 8
@.d759 = private constant <{ i64, [98 x i8] }> <{ i64 0, [98 x i8] c"this value refers to this function's own storage, which dies at the return - build it in '&return'" }>, align 8
@.d760 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E25" }>, align 8
@.d761 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c"a call takes at most one scope argument" }>, align 8
@.d762 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"O25e" }>, align 8
@.d763 = private constant <{ i64, [79 x i8] }> <{ i64 0, [79 x i8] c"these arguments live in different scopes, and the signature requires one ('&p')" }>, align 8
@.d764 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"O10c" }>, align 8
@.d765 = private constant <{ i64, [112 x i8] }> <{ i64 0, [112 x i8] c"the callee needs one argument's scope to outlive another's, and nothing here shows it - pass them from one scope" }>, align 8
@.d766 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"L18" }>, align 8
@.d767 = private constant <{ i64, [94 x i8] }> <{ i64 0, [94 x i8] c"olang has no ';' - a statement ends where its line does; put the next one on a line of its own" }>, align 8
@.d768 = private constant <{ i64, [83 x i8] }> <{ i64 0, [83 x i8] c" names a function of this module - a name means one thing in it, so name this apart" }>, align 8
@.d769 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"D3a" }>, align 8
@.d770 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c" is a type's name - choose another" }>, align 8
@.d771 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"D3a" }>, align 8
@.d772 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"O17a" }>, align 8
@.d773 = private constant <{ i64, [143 x i8] }> <{ i64 0, [143 x i8] c"this value's references live where its own storage does not, so it is not sliced or viewed - index the value itself, or lend it whole to a call" }>, align 8
@.d774 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"P2" }>, align 8
@.d775 = private constant <{ i64, [108 x i8] }> <{ i64 0, [108 x i8] c"this argument refers to storage that closes before the join does - declare that at the join's level or wider" }>, align 8
@.d776 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"P2" }>, align 8
@.d777 = private constant <{ i64, [93 x i8] }> <{ i64 0, [93 x i8] c"this argument's storage closes before the join does - declare it at the join's level or wider" }>, align 8
@.d778 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"P2, D16e" }>, align 8
@.d779 = private constant <{ i64, [93 x i8] }> <{ i64 0, [93 x i8] c"this lambda captures a variable declared inside the join, which closes while the task may run" }>, align 8
@.d780 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"P2, D16e" }>, align 8
@.d781 = private constant <{ i64, [93 x i8] }> <{ i64 0, [93 x i8] c"this function value closes before the join does - make it outside, or spawn the lambda itself" }>, align 8
@.d782 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c"a spawn target has exactly the call's type " }>, align 8
@.d783 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", found " }>, align 8
@.d784 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" - declare '" }>, align 8
@.d785 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"' to give " }>, align 8
@.d786 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c", built where its result lands" }>, align 8
@.d787 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"P1g" }>, align 8
@.d788 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"P1g" }>, align 8
@.d789 = private constant <{ i64, [72 x i8] }> <{ i64 0, [72 x i8] c"these targets live in different scopes, and the results are built in one" }>, align 8
@.d790 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"O12" }>, align 8
@.d791 = private constant <{ i64, [146 x i8] }> <{ i64 0, [146 x i8] c"where this place's references live is not known here, so nothing new is built into it - store what already lives there, or give it one known scope" }>, align 8
@.d792 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"E11a" }>, align 8
@.d793 = private constant <{ i64, [54 x i8] }> <{ i64 0, [54 x i8] c"'$' has nothing to render - this call returns no value" }>, align 8
@.d794 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"E11c, O12" }>, align 8
@.d795 = private constant <{ i64, [148 x i8] }> <{ i64 0, [148 x i8] c"'$' does not say where a value it renders lives, so Str builds and stores nothing where its receiver reaches - read it, and build what it needs here" }>, align 8
@.d796 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"L14" }>, align 8
@.d797 = private constant <{ i64, [62 x i8] }> <{ i64 0, [62 x i8] c"string literal not closed on its line - write \5Cn for a newline" }>, align 8
@.d798 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"B12" }>, align 8
@.d799 = private constant <{ i64, [55 x i8] }> <{ i64 0, [55 x i8] c"-target needs a target after it, as '-target x86-64-v3'" }>, align 8
@.d800 = private constant <{ i64, [84 x i8] }> <{ i64 0, [84 x i8] c"clang not found on PATH - it is what builds the program, and what says what target '" }>, align 8
@.d801 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"' is" }>, align 8
@.d802 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"B12" }>, align 8
@.d803 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"nothing here runs " }>, align 8
@.d804 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c" programs - install qemu-user (qemu-" }>, align 8
@.d805 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"), or name an emulator with OLANG_EMULATOR" }>, align 8
@.d806 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"B12a" }>, align 8
@.d807 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"unknown target '" }>, align 8
@.d808 = private constant <{ i64, [187 x i8] }> <{ i64 0, [187 x i8] c"' - write native, x86-64, x86-64-v2, x86-64-v3, x86-64-v4, a CPU clang knows ('clang --print-supported-cpus'), or a triple x86_64-linux-gnu or aarch64-linux-gnu, ':CPU' after it if wanted" }>, align 8
@.d809 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"B12" }>, align 8
@.d810 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"P4a" }>, align 8
@.d811 = private constant <{ i64, [82 x i8] }> <{ i64 0, [82 x i8] c"a task's clause runs on the task and may not return - it ends where its block does" }>, align 8
@.d812 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"P4a" }>, align 8
@.d813 = private constant <{ i64, [118 x i8] }> <{ i64 0, [118 x i8] c"a task's default is built where its result lands, and this names existing storage - build the value here, or give null" }>, align 8
@.d814 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"a comma before " }>, align 8
@.d815 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c" separates nothing - remove it" }>, align 8
@.d816 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"L18a" }>, align 8
@.d817 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"D17f, D17d" }>, align 8
@.d818 = private constant <{ i64, [111 x i8] }> <{ i64 0, [111 x i8] c"a trait's method states no 'outlives' - a call through an 'any' cannot check one; write it on the type's method" }>, align 8
@.d819 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"R10" }>, align 8
@.d820 = private constant <{ i64, [114 x i8] }> <{ i64 0, [114 x i8] c"a try statement discards its value, leaving a slice nothing - write 's := try a[lo:hi]' and catch where it is used" }>, align 8
@.d821 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"nothing here can fail - write it without '" }>, align 8
@.d822 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d823 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"R8" }>, align 8
@.d824 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"D8c" }>, align 8
@.d825 = private constant <{ i64, [111 x i8] }> <{ i64 0, [111 x i8] c"several results are not one value - destructure them ('a, b := f()'), or pass them as all of a call's arguments" }>, align 8
@.d826 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"L12" }>, align 8
@.d827 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c"a number has at most one decimal point" }>, align 8
@.d828 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"type arguments for " }>, align 8
@.d829 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c": expected " }>, align 8
@.d830 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", found " }>, align 8
@.d831 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"G7" }>, align 8
@.d832 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"G11" }>, align 8
@.d833 = private constant <{ i64, [101 x i8] }> <{ i64 0, [101 x i8] c"a type argument's reference marker is bare, as 'List<String&>' - its references live in the container" }>, align 8
@.d834 = private constant <{ i64, [59 x i8] }> <{ i64 0, [59 x i8] c"type arguments are written touching the name and the '(': '" }>, align 8
@.d835 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c"<...>(...)' - with spaces, '<' and '>' compare" }>, align 8
@.d836 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"G12" }>, align 8
@.d837 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c" is used while it is still being declared" }>, align 8
@.d838 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d839 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"type " }>, align 8
@.d840 = private constant <{ i64, [52 x i8] }> <{ i64 0, [52 x i8] c" has no constructor - an enum's values are its cases" }>, align 8
@.d841 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d842 = private constant <{ i64, [64 x i8] }> <{ i64 0, [64 x i8] c" cannot hold itself by value - hold it through a reference ('&')" }>, align 8
@.d843 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T16" }>, align 8
@.d844 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"type " }>, align 8
@.d845 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c" is private to its module" }>, align 8
@.d846 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"M6" }>, align 8
@.d847 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"type " }>, align 8
@.d848 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c" is already declared in this module" }>, align 8
@.d849 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"D2" }>, align 8
@.d850 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c" is a type, not a value" }>, align 8
@.d851 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d852 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"D15" }>, align 8
@.d853 = private constant <{ i64, [79 x i8] }> <{ i64 0, [79 x i8] c"':=' takes its type from the initializer, and a call returning nothing has none" }>, align 8
@.d854 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"type variable " }>, align 8
@.d855 = private constant <{ i64, [60 x i8] }> <{ i64 0, [60 x i8] c" is named after a type - choose a name no type has, as '<T>'" }>, align 8
@.d856 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"G1" }>, align 8
@.d857 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"G17" }>, align 8
@.d858 = private constant <{ i64, [72 x i8] }> <{ i64 0, [72 x i8] c"this generic's instantiations never end - each one requires a larger one" }>, align 8
@.d859 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"L13" }>, align 8
@.d860 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"unterminated character literal" }>, align 8
@.d861 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"unknown name " }>, align 8
@.d862 = private constant <{ i64, [54 x i8] }> <{ i64 0, [54 x i8] c" - if it is a build constant, define it with '-define " }>, align 8
@.d863 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c"=VALUE', or declare it with a default" }>, align 8
@.d864 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"B10" }>, align 8
@.d865 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"unknown function or type " }>, align 8
@.d866 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c" - did you mean '" }>, align 8
@.d867 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"'?" }>, align 8
@.d868 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d869 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c" is no import here" }>, align 8
@.d870 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"M10" }>, align 8
@.d871 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c" has no method " }>, align 8
@.d872 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"M19" }>, align 8
@.d873 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"unknown name " }>, align 8
@.d874 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d875 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"unknown type " }>, align 8
@.d876 = private constant <{ i64, [58 x i8] }> <{ i64 0, [58 x i8] c" - the numbers are named by kind and width: did you mean '" }>, align 8
@.d877 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"'?" }>, align 8
@.d878 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"T4" }>, align 8
@.d879 = private constant <{ i64, [83 x i8] }> <{ i64 0, [83 x i8] c" names no variable visible here - a marker names where the reference lives, as '&x'" }>, align 8
@.d880 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"O4a" }>, align 8
@.d881 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"unknown type " }>, align 8
@.d882 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c" - did you mean '" }>, align 8
@.d883 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"'?" }>, align 8
@.d884 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d885 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"unknown type variable " }>, align 8
@.d886 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d887 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"B1" }>, align 8
@.d888 = private constant <{ i64, [105 x i8] }> <{ i64 0, [105 x i8] c"nothing to do - write a file to build and run, as 'olang main.olang', or a mode ('olang help' lists them)" }>, align 8
@.d889 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c"a declaration's value follows '=' - write '" }>, align 8
@.d890 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d891 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"', or '" }>, align 8
@.d892 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" := " }>, align 8
@.d893 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d894 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"D12" }>, align 8
@.d895 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"O25h" }>, align 8
@.d896 = private constant <{ i64, [91 x i8] }> <{ i64 0, [91 x i8] c"this value holds references into a scope the target outlives - build it where the target is" }>, align 8
@.d897 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d898 = private constant <{ i64, [73 x i8] }> <{ i64 0, [73 x i8] c"' may grow here while a task holds a view of it - give the task a copy: '" }>, align 8
@.d899 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c".ToArray()'" }>, align 8
@.d900 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"M19g" }>, align 8
@.d901 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"this view of '" }>, align 8
@.d902 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"' is given to " }>, align 8
@.d903 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c", which may grow '" }>, align 8
@.d904 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"' - copy the elements first: '" }>, align 8
@.d905 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c".ToArray()'" }>, align 8
@.d906 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"M19g" }>, align 8
@.d907 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"E31b" }>, align 8
@.d908 = private constant <{ i64, [196 x i8] }> <{ i64 0, [196 x i8] c"x[i] gives a copy of the element, which this call would write while it can reach the collection another way - write 't := x[i]', the call on 't', then 'x[i] = t', or hold the elements by reference" }>, align 8
@.d909 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c"this writes through x[i] on " }>, align 8
@.d910 = private constant <{ i64, [95 x i8] }> <{ i64 0, [95 x i8] c", which declares At but not SetAt - the copy At gives back is never written back; declare SetAt" }>, align 8
@.d911 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E31" }>, align 8
@.d912 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"S20" }>, align 8
@.d913 = private constant <{ i64, [67 x i8] }> <{ i64 0, [67 x i8] c"a lambda is no generator - 'yield' in the function it is written in" }>, align 8
@.d914 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"S20" }>, align 8
@.d915 = private constant <{ i64, [121 x i8] }> <{ i64 0, [121 x i8] c"a yield with deferred code pending around it - a walk stopped there would never run it; yield outside the deferring block" }>, align 8
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2eU8_2eFormat(ptr %v0, i8 %a0, i64 %a1)
@olang_loc_d2d351cc5daaf8b6_b531c4af6261323a = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i8 %a2)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fmsgs_2eEndOfLine_2einit()
declare void @compiler_2fmsgs_2eEndOfFile_2einit()

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
